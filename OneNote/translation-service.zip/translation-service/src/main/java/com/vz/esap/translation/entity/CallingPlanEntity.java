package com.vz.esap.translation.entity;

import java.util.ArrayList;
import EsapEnumPkg.VzbVoipEnum;
import com.vz.esap.translation.order.model.request.DigitString;


public class CallingPlanEntity extends Entity {
	
	
	public static enum CallTypeEnum {
		
		DENY(VzbVoipEnum.CallingPlanCallType.DENY),
		ALLOW(VzbVoipEnum.CallingPlanCallType.ALLOW),
		TRANSFER1(VzbVoipEnum.CallingPlanCallType.TRANSFER1),
		TRANSFER2(VzbVoipEnum.CallingPlanCallType.TRANSFER2),
		TRANSFER3(VzbVoipEnum.CallingPlanCallType.TRANSFER3),
		AUTHORIZE(VzbVoipEnum.CallingPlanCallType.AUTHORIZE),
		NONE(-1);
		
		
		int esapEnum;
		private CallTypeEnum(int esapEnum){
			this.esapEnum = esapEnum;
		}
		public int getEsapEnum(){
			return esapEnum;
		}
		
		public static CallTypeEnum valueOf(int esapEnum){
			for(CallTypeEnum tn : CallTypeEnum.values())
				if( tn.getEsapEnum() == esapEnum )
					return tn;
			
			return null;
		}
	}

	
	
	
    private String departmentId;
    private String locationId;
    private String callingPlanId;
    private String callingPlanName;
    private IncomingCallingPlan incoming;
    private OutgoingCallingPlan outgoing;
    private String _default;
    private String telephone1;
    private String telephone2;
    private String telephone3;
    private ArrayList<DigitString> digitStrings;
  

    public String getDepartmentId() {
        return departmentId;
    }

    public void setDepartmentId(String departmentId) {
        this.departmentId = departmentId;
    }

    public String getLocationId() {
        return locationId;
    }

    public void setLocationId(String locationId) {
        this.locationId = locationId;
    }

    public String getCallingPlanId() {
        return callingPlanId;
    }

    public void setCallingPlanId(String callingPlanId) {
        this.callingPlanId = callingPlanId;
    }

    public String getCallingPlanName() {
        return callingPlanName;
    }

    public void setCallingPlanName(String calingPlanName) {
        this.callingPlanName = calingPlanName;
    }

    public IncomingCallingPlan getIncoming() {
        return incoming;
    }

    public void setIncoming(IncomingCallingPlan incoming) {
        this.incoming = incoming;
    }

    public OutgoingCallingPlan getOutgoing() {
        return outgoing;
    }

    public void setOutgoing(OutgoingCallingPlan outgoing) {
        this.outgoing = outgoing;
    }

    public String get_default() {
        return _default;
    }

    public void set_default(String _default) {
        this._default = _default;
    }

    public String getTelephone1() {
        return telephone1;
    }

    public void setTelephone1(String telephone1) {
        this.telephone1 = telephone1;
    }

    public String getTelephone2() {
        return telephone2;
    }

    public void setTelephone2(String telephone2) {
        this.telephone2 = telephone2;
    }

    public String getTelephone3() {
        return telephone3;
    }

    public void setTelephone3(String telephone3) {
        this.telephone3 = telephone3;
    }

    public void addToDigitStrings(DigitString ds){
    	if(digitStrings == null){
    		digitStrings = new ArrayList<DigitString>();
    		digitStrings.add(ds);
    	}
    	else
    		digitStrings.add(ds);
    }
    
    
    public ArrayList<DigitString> getDigitStrings() {
        return digitStrings;
    }

    public void setDigitStrings(ArrayList<DigitString> digitStrings) {
        this.digitStrings = digitStrings;
    }

	public int getEntityType() {
        return VzbVoipEnum.OrderEntity.CALLING_PLAN;
    }

    public String getEntityId() {
        return callingPlanId;
    }

    public String getEntityName() {
        return callingPlanName;
    }

}
