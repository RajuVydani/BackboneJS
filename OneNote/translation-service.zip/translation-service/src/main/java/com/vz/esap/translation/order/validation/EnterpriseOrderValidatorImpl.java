package com.vz.esap.translation.order.validation;

import static java.util.Arrays.stream;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.vz.esap.translation.enums.EsapEnum.FunctionCode;
import com.vz.esap.translation.enums.EsapEnum.OrderPass;
import com.vz.esap.translation.enums.EsapEnum.SolutionType;
import com.vz.esap.translation.order.model.request.ConvergedService;
import com.vz.esap.translation.order.model.request.Feature;
import com.vz.esap.translation.order.model.request.Specification;
import com.vz.esap.translation.order.model.request.TnRangeInfo;
import com.vz.esap.translation.order.model.request.VOIPOrderRequest;

import reactor.util.CollectionUtils;

/**
 * @author V864498 To Generate Validation Order for Enterprise
 *         Install/Change/Delete
 */
@Component
public class EnterpriseOrderValidatorImpl implements EnterpriseOrderValidator {
	private static final Logger LOG = LoggerFactory.getLogger(EnterpriseOrderValidatorImpl.class);

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.vz.esap.translation.order.validation.EnterpriseOrderValidator#validate(
	 * com.vz.esap.translation.order.model.request.VOIPOrderRequest)
	 */
	@Override
	public Set<String> validate(VOIPOrderRequest voipOrderRequest) {
		LOG.info("Entered validate");
		List<String> missingFields = new ArrayList<>();

		if (voipOrderRequest.getOrderHeader() == null) {
			missingFields.add("OrderHeader");
		}
		if (voipOrderRequest.getOrderHeader() != null && voipOrderRequest.getOrderHeader().getFunctionCode() == null) {
			missingFields.add("FunctionCode");
		}
		if (voipOrderRequest.getOrderHeader() != null && voipOrderRequest.getOrderHeader().getFunctionCode() != null
				&& voipOrderRequest.getOrderHeader().getFunctionCode()
						.equalsIgnoreCase(OrderPass.VALIDATE.toString())
						&& "I".equalsIgnoreCase(voipOrderRequest.getOrderHeader().getOrderType())) {
			
			ConvergedService convergedService = voipOrderRequest.getConvergedService();
			if (convergedService == null) {
				missingFields.add("ConvergedService");
			}
			if (convergedService != null && convergedService.getID().isEmpty()) {
				missingFields.add("EntityId");
			}
			if (voipOrderRequest.getLocation() == null) {
				missingFields.add("Virtual LocationEntity Info");// Check this for XO order whether applicable
			}

			if (convergedService != null) {

				if (SolutionType.ESIP_ESL.equals(voipOrderRequest.getOrderHeader().getSolutionType()))
					missingFields.addAll(validateEsipEsl(voipOrderRequest, missingFields));

				if (SolutionType.ESIP_EBL.equals(voipOrderRequest.getOrderHeader().getSolutionType()))
					missingFields.addAll(validateEsipEbl(voipOrderRequest, missingFields));
			}

			
		} else if (voipOrderRequest.getOrderHeader() != null
				&& voipOrderRequest.getOrderHeader().getFunctionCode() != null
				&& FunctionCode.LNP_ACTIVATE.toString()
						.equalsIgnoreCase(voipOrderRequest.getOrderHeader().getFunctionCode())
				&& "I".equalsIgnoreCase(voipOrderRequest.getOrderHeader().getOrderType())) {
			
			if (voipOrderRequest.getTnActivation() == null) {
				missingFields.add("TnActivation");
			}
			if (voipOrderRequest.getTnActivation() != null && voipOrderRequest.getTnActivation().getTnInfo() != null 
					&& voipOrderRequest.getTnActivation().getTnInfo().length <= 0) {
				missingFields.add("TnInfo's TN");
			}
			if (voipOrderRequest.getTnActivation() != null && voipOrderRequest.getTnActivation().getTnRangeInfo() != null
					&& voipOrderRequest.getTnActivation().getTnRangeInfo().length <= 0) {
				missingFields.add("TnRange's TN");
			}
			if (voipOrderRequest.getTnActivation() != null && voipOrderRequest.getTnActivation().getTnRangeInfo() != null
					&& voipOrderRequest.getTnActivation().getTnRangeInfo().length > 0) {
				
				for (TnRangeInfo tnRange : voipOrderRequest.getTnActivation().getTnRangeInfo()) {
					if(tnRange.getTnRangeStart() == null) {
						missingFields.add("TnRangeStart");
					}
					if(tnRange.getTnRangeEnd() == null) {
						missingFields.add("TnRangeEnd");
					}
				}
			}
		}
		
		Set<String> missingFieldsSet = new HashSet<>(missingFields);

		LOG.info("Exit validate");
		
		return missingFieldsSet;
	}

	/**
	 * @param voipOrderRequest
	 * @param missingFields
	 * @return missingFields
	 */
	List<String> validateEsipEsl(VOIPOrderRequest voipOrderRequest, List<String> missingFields) {
		LOG.info("Entered validateEsipEsl");

		List<Feature> deviceFeatures = stream(voipOrderRequest.getConvergedService().getFeature())
				.filter(locFeatureValues -> "FET_DE".equalsIgnoreCase(locFeatureValues.getCode())
						|| "FET_DE_LOC".equalsIgnoreCase(locFeatureValues.getCode()))
				.collect(Collectors.toList());

		if (CollectionUtils.isEmpty(deviceFeatures)) {
			missingFields.add("Device Info");
		}

		List<Feature> locFeatList = stream(voipOrderRequest.getConvergedService().getFeature())
				.filter(locFeature -> "FET_LOC_LVL".equalsIgnoreCase(locFeature.getCode()))
				.collect(Collectors.toList());

		if (!CollectionUtils.isEmpty(locFeatList)) {

			List<Specification> locSpecs = stream(locFeatList.get(0).getSpecification())
					.filter(trunkFeature -> "SP_XO_BW_PORT_NUM".equalsIgnoreCase(trunkFeature.getCode()))
					.collect(Collectors.toList());

			if (CollectionUtils.isEmpty(locSpecs)) {
				missingFields.add("Bw Portal Info");
			}

			locSpecs = stream(locFeatList.get(0).getSpecification())
					.filter(trunkFeature -> "SP_XO_GRO".equalsIgnoreCase(trunkFeature.getCode()))
					.collect(Collectors.toList());

			if (CollectionUtils.isEmpty(locSpecs)) {
				missingFields.add("Group BTN Info");
			}
		} else {
			missingFields.add("Virtual LocationEntity Info");
		}
		List<Feature> trunkFeatList = stream(voipOrderRequest.getConvergedService().getFeature())
				.filter(trunkFeature -> "FET_XO_TRU".equalsIgnoreCase(trunkFeature.getCode()))
				.collect(Collectors.toList());

		if (!CollectionUtils.isEmpty(trunkFeatList)) {

			missingFields.addAll(validateCommonTrunkFeatureSpecs(trunkFeatList, missingFields));

			List<Specification> trunkSpecs = stream(trunkFeatList.get(0).getSpecification())
					.filter(trunkFeature -> "SP_TRK".equalsIgnoreCase(trunkFeature.getCode()))
					.collect(Collectors.toList());

			if (CollectionUtils.isEmpty(trunkSpecs)) {
				missingFields.add("Trunk Info");
			}

			trunkSpecs = stream(trunkFeatList.get(0).getSpecification())
					.filter(trunkFeature -> "SP_XO_PILNUM".equalsIgnoreCase(trunkFeature.getCode()))
					.collect(Collectors.toList());

			if (CollectionUtils.isEmpty(trunkSpecs)) {
				missingFields.add("PILNUM Info");
			}
		} else {
			missingFields.add("Trunk Info");
		}

		LOG.info("Exit validateEsipEsl");

		return missingFields;
	}

	List<String> validateEsipEbl(VOIPOrderRequest voipOrderRequest, List<String> missingFields) {
		LOG.info("Entered validateEsipEbl");

		List<Feature> locFeatList = stream(voipOrderRequest.getConvergedService().getFeature())
				.filter(locFeature -> "FET_LOC_LVL".equalsIgnoreCase(locFeature.getCode()))
				.collect(Collectors.toList());

		if (!CollectionUtils.isEmpty(locFeatList)) {

			List<Specification> locTnSpecs = stream(locFeatList.get(0).getSpecification())
					.filter(trunkFeature -> "SP_XO_TNQ".equalsIgnoreCase(trunkFeature.getCode()))
					.collect(Collectors.toList());

			if (CollectionUtils.isEmpty(locTnSpecs)) {
				missingFields.add("Tn Quantity Info");// Check this for XO order whether applicable
			}

			List<Specification> locSpecs = stream(locFeatList.get(0).getSpecification())
					.filter(trunkFeature -> "SP_XO_ESL".equalsIgnoreCase(trunkFeature.getCode()))
					.collect(Collectors.toList());

			if (CollectionUtils.isEmpty(locSpecs)) {
				missingFields.add("ESL Info");
			}
		} else {
			missingFields.add("Virtual LocationEntity Info");
		}

		List<Feature> trunkFeatList = stream(voipOrderRequest.getConvergedService().getFeature())
				.filter(trunkFeature -> "FET_XO_TRU".equalsIgnoreCase(trunkFeature.getCode()))
				.collect(Collectors.toList());

		if (!CollectionUtils.isEmpty(trunkFeatList)) {

			missingFields.addAll(validateCommonTrunkFeatureSpecs(trunkFeatList, missingFields));

		} else {
			missingFields.add("Trunk Info");
		}

		LOG.info("Exit validateEsipEbl");

		return missingFields;
	}

	List<String> validateCommonTrunkFeatureSpecs(List<Feature> trunkFeatList, List<String> missingFields) {
		LOG.info("Entered validateCommonTrunkFeatureSpecs");

		List<Specification> trunkSpecs = stream(trunkFeatList.get(0).getSpecification())
				.filter(trunkFeature -> "SP_XO_TRU_GRP_NM".equalsIgnoreCase(trunkFeature.getCode()))
				.collect(Collectors.toList());

		if (CollectionUtils.isEmpty(trunkSpecs)) {
			missingFields.add("Trunk group info");
		}

		trunkSpecs = stream(trunkFeatList.get(0).getSpecification())
				.filter(trunkFeature -> "SP_XO_SIG".equalsIgnoreCase(trunkFeature.getCode()))
				.collect(Collectors.toList());

		if (CollectionUtils.isEmpty(trunkSpecs)) {
			missingFields.add("SIG Info");
		}

		LOG.info("Exit validateCommonTrunkFeatureSpecs");
		return missingFields;
	}

}