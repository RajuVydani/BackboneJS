package com.vz.esap.translation.util;

import java.math.BigInteger;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.vz.esap.translation.entity.Entity;
import com.vz.esap.translation.entity.TrunkGroupEntity;
import com.vz.esap.translation.order.model.request.ParamInfo;

/**
 * @author baigkh
 *
 */
public class GroupUtility extends OrderUtility {

	private static final Logger LOG = LoggerFactory.getLogger(GroupUtility.class);

	public static void setParam(TrunkGroupEntity group, ParamInfo param) {

		if (("NonPkgFeatures").equals(param.getName())) {
			if (param.getChildParams() != null)
				for (ParamInfo par2 : param.getChildParams())
					group.addNonPkgFeature(par2.getValue());
		} else if (("DisableFeatureList").equals(param.getName())) {
			if (param.getChildParams() != null)
				for (ParamInfo par2 : param.getChildParams())
					group.addDisableFeature(par2.getValue());
		} else if (("AdditionalAttribs").equals(param.getName())) {
			if (param.getChildParams() != null) {
				for (ParamInfo par2 : param.getChildParams())
					group.addAttrib(par2.getName(), par2.getValue());
			}
		}

		LOG.info("Name:" + param.getName() + " Value:" + param.getValue() + "ChildParamCnt:"
				+ (param.getChildParams() == null ? 0 : param.getChildParams().size()));

		if (("GroupId").equals(param.getName()))
			group.setGroupId(new Long(param.getValue()));
		else if (("CustomerId").equals(param.getName()))
			group.setCustomerId(param.getValue());
		else if (("LocationId").equals(param.getName()))
			group.setLocationId(param.getValue());
		else if (("DepartmentId").equals(param.getName()))
			group.setDepartmentId(param.getValue());
		else if (("GroupType").equals(param.getName()) && param.getValue() != null)
			group.setGroupType(Entity.GroupType.valueOf(param.getValue()));
		else if (("Name").equals(param.getName()))
			group.setName(param.getValue());
		else if (("MaxConcurrentCallLimit").equals(param.getName()) && param.getValue() != null)
			group.setMaxConcurrentCallLimit(new BigInteger(param.getValue()));
		else if (("CLIDFirstName").equals(param.getName()))
			group.setCLIDFirstName(param.getValue());
		else if (("CLIDLastName").equals(param.getName()))
			group.setCLIDLastName(param.getValue());
		else if (("TnCLIDFirstName").equals(param.getName()))
			group.setTnCLIDFirstName(param.getValue());
		else if (("TnCLIDLastName").equals(param.getName()))
			group.setTnCLIDLastName(param.getValue());
		else if (("SimpleFeaturePackage").equals(param.getName()))
			group.setSimpleFeaturePackage(param.getValue());
		else if (("TerminationOption").equals(param.getName()))
			group.setTerminationOption(param.getValue());
		else if (("ForwardToGroupId").equals(param.getName()) && param.getValue() != null)
			group.setForwardToGroupId(new Long(param.getValue()));
		else if (("InvitationTimer").equals(param.getName()) && param.getValue() != null)
			group.setInvitationTimer(new Integer(param.getValue()));
		else if (("CreateExtension").equals(param.getName()))
			group.setCreateExtension(getBooleanFromYN(param.getValue()));
		else if (("ForwardToGroupName").equals(param.getName()))
			group.setForwardToGroupName(param.getValue());
		else if (("ForwardToNumber").equals(param.getName()))
			group.setForwardToNumber(param.getValue());
		else if (("VMBoxNumber").equals(param.getName()))
			group.setVMNumber(param.getValue());
		else if (("VMPin").equals(param.getName()))
			group.setVmPin(param.getValue());
		else if (("VMType").equals(param.getName()))
			group.setVMType(param.getValue());
		else if (("LinePort").equals(param.getName()))
			group.setLinePort(param.getValue());
		else if (("Extension").equals(param.getName()))
			group.setExtension(param.getValue());
		else if (("PrivateNumber").equals(param.getName()))
			group.setPrivateNumber(param.getValue());
		else if (("PilotTN").equals(param.getName()))
			group.setPilotTN(param.getValue());
		else if (("FirstActiveTN").equals(param.getName()))
			group.setFirstActiveTN(param.getValue());
		else if (("LastActiveTN").equals(param.getName()))
			group.setLastActiveTN(param.getValue());
		else if (("LinePortLength").equals(param.getName()) && param.getValue() != null)
			group.setLinePortLength(new Integer(param.getValue()));
		else if (("HotCutIndicator").equals(param.getName())) {
			if (param.getValue() != null && param.getValue().equals("Y"))
				group.setHotCutIndicator(Boolean.TRUE);
		} else if (("CDDDIndicator").equals(param.getName())) {
			if (param.getValue() != null && param.getValue().equals("Y"))
				group.setCDDDIndicator(Boolean.TRUE);
		} else if (("PQInstanceId").equals(param.getName()) && param.getValue() != null) {
			try {
				group.setPqInstanceId(new Long(param.getValue()));
			} catch (NumberFormatException npe) {
				LOG.error("NumberFormatException {} ", npe.getMessage());
			}
		}
	}

	public static TrunkGroupEntity createInstanceFromParamInfo(ParamInfo parent) {

		if (parent == null)
			return null;

		TrunkGroupEntity group = new TrunkGroupEntity();

		if (parent.getChildParams() == null)
			return null;

		for (ParamInfo param : parent.getChildParams()) {
			setParam(group, param);
		}

		return group;
	}

}
