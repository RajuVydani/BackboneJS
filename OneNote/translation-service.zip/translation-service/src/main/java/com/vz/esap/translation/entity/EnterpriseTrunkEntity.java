package com.vz.esap.translation.entity;

import EsapEnumPkg.VzbVoipEnum;
import java.util.HashSet;

import com.vz.esap.translation.enums.EsapEnum.OrderEntity;
import com.vz.esap.translation.enums.EsapEnum.SolutionType;

public class EnterpriseTrunkEntity extends Entity {
   
   private Long enterpriseTrunkId;
   private String enterpriseTrunkName;
   private Integer maxRerouteAttempts;
   private Integer maxRerouteAttemptsPriority;
   private String customerId;
   private String routeExhaustAction;
   private String routeExhaustForwardTN;
   private String signalDirection;
   private String bwEntId;
   private String bwEtId;
   private String bwEslId;
   private String enterpriseId;   
   private String locationId;
   private String bwTrunkGroupId;
   private String redundancy;
   private String redundancyPriorityType;
   private String etType;
   private String orderingAlgorithm;
   private SolutionType solutionType;
   private String region;
   private long envOrderId;
   private long internalOrderId;
   private String provisionCategory;
   private EnterpriseTrunkEntity enterpriseTrunkEntity;
   private boolean isNewEt;
   private String asClli;
   
   public EnterpriseTrunkEntity getEnterpriseTrunkEntity() {
	return enterpriseTrunkEntity;
}

public void setEnterpriseTrunkEntity(EnterpriseTrunkEntity enterpriseTrunkEntity) {
	this.enterpriseTrunkEntity = enterpriseTrunkEntity;
}

public String getBwEtId() {
	return bwEtId;
}

public void setBwEtId(String bwEtId) {
	this.bwEtId = bwEtId;
}

public String getBwEslId() {
	return bwEslId;
}

public void setBwEslId(String bwEslId) {
	this.bwEslId = bwEslId;
}

public String getSignalDirection() {
	return signalDirection;
}

public void setSignalDirection(String signalDirection) {
	this.signalDirection = signalDirection;
}

public String getBwEntId() {
	return bwEntId;
}

public void setBwEntId(String bwEntId) {
	this.bwEntId = bwEntId;
}

@Override
   public int getEntityType() {
      return OrderEntity.ENTERPRISE_TRUNK.getIndex();
   }
   
   @Override
   public String getEntityName() {
      return enterpriseTrunkName;
   }
   
   @Override
   public String getEntityId() {
      if (enterpriseTrunkId == null) {
         return null;
      } else {
         return enterpriseTrunkId.toString();
      }
   }
   
   @Override
   public HashSet<ParentEntity> getParentList() {
      if (customerId != null) {
         addParentToList(new ParentEntity(VzbVoipEnum.OrderEntity.ENTERPRISE, null, customerId));
      }
      return super.getParentList();
   }
   
   public Long getEnterpriseTrunkId() {
      return enterpriseTrunkId;
   }
   
   public void setEnterpriseTrunkId(Long enterpriseTrunkId) {
      this.enterpriseTrunkId = enterpriseTrunkId;
   }
   
   public String getEnterpriseTrunkName() {
      return enterpriseTrunkName;
   }
   
   public void setEnterpriseTrunkName(String enterpriseTrunkName) {
      this.enterpriseTrunkName = enterpriseTrunkName;
   }
   
   public Integer getMaxRerouteAttempts() {
      return maxRerouteAttempts;
   }
   
   public void setMaxRerouteAttempts(Integer maxRerouteAttempts) {
      this.maxRerouteAttempts = maxRerouteAttempts;
   }
   
   public Integer getMaxRerouteAttemptsPriority() {
      return maxRerouteAttemptsPriority;
   }
   
   public void setMaxRerouteAttemptsPriority(Integer maxRerouteAttemptsPriority) {
      this.maxRerouteAttemptsPriority = maxRerouteAttemptsPriority;
   }
   
   public String getRouteExhaustAction() {
      return routeExhaustAction;
   }
   
   public void setRouteExhaustAction(String routeExhaustAction) {
      this.routeExhaustAction = routeExhaustAction;
   }
   
   public String getRouteExhaustForwardTN() {
      return routeExhaustForwardTN;
   }
   
   public void setRouteExhaustForwardTN(String routeExhaustForwardTN) {
      this.routeExhaustForwardTN = routeExhaustForwardTN;
   }
   
   public String getCustomerId() {
      return customerId;
   }
   
   public void setCustomerId(String customerId) {
      this.customerId = customerId;
   }

public String getEnterpriseId() {
	return enterpriseId;
}

public void setEnterpriseId(String enterpriseId) {
	this.enterpriseId = enterpriseId;
}

public String getLocationId() {
	return locationId;
}

public void setLocationId(String locationId) {
	this.locationId = locationId;
}

public String getBwTrunkGroupId() {
	return bwTrunkGroupId;
}

public void setBwTrunkGroupId(String bwTrunkGroupId) {
	this.bwTrunkGroupId = bwTrunkGroupId;
}

public String getRedundancy() {
	return redundancy;
}

public void setRedundancy(String redundancy) {
	this.redundancy = redundancy;
}

public String getEtType() {
	return etType;
}

public void setEtType(String etType) {
	this.etType = etType;
}

public String getOrderingAlgorithm() {
	return orderingAlgorithm;
}

public void setOrderingAlgorithm(String orderingAlgorithm) {
	this.orderingAlgorithm = orderingAlgorithm;
}

public String getRedundancyPriorityType() {
	return redundancyPriorityType;
}

public void setRedundancyPriorityType(String redundancyPriorityType) {
	this.redundancyPriorityType = redundancyPriorityType;
}

public SolutionType getSolutionType() {
	return solutionType;
}

public void setSolutionType(SolutionType solutionType) {
	this.solutionType = solutionType;
}

public String getRegion() {
	return region;
}

public void setRegion(String region) {
	this.region = region;
}

public long getEnvOrderId() {
	return envOrderId;
}

public void setEnvOrderId(long envOrderId) {
	this.envOrderId = envOrderId;
}

@Override
public String toString() {
	return "EnterpriseTrunkEntity [enterpriseTrunkId=" + enterpriseTrunkId + ", enterpriseTrunkName="
			+ enterpriseTrunkName + ", maxRerouteAttempts=" + maxRerouteAttempts + ", maxRerouteAttemptsPriority="
			+ maxRerouteAttemptsPriority + ", customerId=" + customerId + ", routeExhaustAction=" + routeExhaustAction
			+ ", routeExhaustForwardTN=" + routeExhaustForwardTN + ", signalDirection=" + signalDirection + ", bwEntId="
			+ bwEntId + ", bwEtId=" + bwEtId + ", bwEslId=" + bwEslId + ", enterpriseId=" + enterpriseId
			+ ", locationId=" + locationId + ", bwTrunkGroupId=" + bwTrunkGroupId + ", redundancy=" + redundancy
			+ ", redundancyPriorityType=" + redundancyPriorityType + ", etType=" + etType + ", orderingAlgorithm="
			+ orderingAlgorithm + ", solutionType=" + solutionType + ", region=" + region + ", envOrderId=" + envOrderId
			+ ", enterpriseTrunkEntity=" + enterpriseTrunkEntity + "]";
}

public long getInternalOrderId() {
	return internalOrderId;
}

public void setInternalOrderId(long internalOrderId) {
	this.internalOrderId = internalOrderId;
}

public String getProvisionCategory() {
	return provisionCategory;
}

public void setProvisionCategory(String provisionCategory) {
	this.provisionCategory = provisionCategory;
}

public boolean isNewEt() {
	return isNewEt;
}

public void setNewEt(boolean isNewEt) {
	this.isNewEt = isNewEt;
}

public String getAsClli() {
	return asClli;
}

public void setAsClli(String asClli) {
	this.asClli = asClli;
}
    
}
