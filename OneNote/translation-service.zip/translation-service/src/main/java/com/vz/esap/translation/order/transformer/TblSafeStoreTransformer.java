package com.vz.esap.translation.order.transformer;

import org.springframework.stereotype.Component;

import com.vz.esap.translation.dao.model.TblSafeStore;
import com.vz.esap.translation.exception.TranslatorException;

@Component
public interface TblSafeStoreTransformer {

	/**
	 * @param sequenceNumber
	 * @return tblSafeStoreObject
	 * @throws TranslatorException
	 */
	TblSafeStore prepareTblSafeStoreData(long sequenceNumber) throws TranslatorException;

}
