package com.vz.esap.translation.entity;

public class SharedCallAppearanceEntity {
    private String address;
    private String label;
    private String type;
    private String authUserID;
    private String deviceMapId;
       
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getLabel() {
		return label;
	}
	public void setLabel(String label) {
		this.label = label;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getAuthUserID() {
		return authUserID;
	}
	public void setAuthUserID(String authUserID) {
		this.authUserID = authUserID;
	}
	public String getDeviceMapId() {
		return deviceMapId;
	}
	public void setDeviceMapId(String deviceMapId) {
		this.deviceMapId = deviceMapId;
	}

   
}
