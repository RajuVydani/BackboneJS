package com.vz.esap.translation.order.parser;

import java.text.ParseException;
import java.util.List;

import com.vz.esap.translation.entity.LocationEntity;
import com.vz.esap.translation.exception.TranslatorException;
import com.vz.esap.translation.order.model.request.VOIPOrderRequest;

public interface LocationOrderParser {

	/**
	 * @param voipOrderRequest
	 * @return location
	 * @throws TranslatorException
	 * @throws ParseException
	 */
	LocationEntity parseLocationOrder(VOIPOrderRequest voipOrderRequest) throws TranslatorException, ParseException;

	/**
	 * @param voipOrderRequest
	 * @return
	 * @throws TranslatorException
	 * @throws ParseException
	 */
	List<LocationEntity> parseLocationOrders(VOIPOrderRequest voipOrderRequest)
			throws TranslatorException, ParseException;

}
