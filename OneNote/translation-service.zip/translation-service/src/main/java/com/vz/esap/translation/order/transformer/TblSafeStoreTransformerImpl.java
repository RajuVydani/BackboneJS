package com.vz.esap.translation.order.transformer;

import com.vz.esap.translation.dao.model.TblSafeStore;
import com.vz.esap.translation.exception.TranslatorException;
import com.vz.esap.translation.exception.TranslatorException.ErrorCode;
import com.vz.esap.translation.order.dao.VOIPOrderDaoImpl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Component
public class TblSafeStoreTransformerImpl implements TblSafeStoreTransformer {

	private static final Logger LOG = LoggerFactory.getLogger(VOIPOrderDaoImpl.class);

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.vz.esap.translation.order.transformer.TblSafeStoreTransformer#
	 * prepareTblSafeStoreData(long)
	 */
	@Override
	public TblSafeStore prepareTblSafeStoreData(long sequenceNumber) throws TranslatorException {
		LOG.info("Entered - prepareTblSafeStoreData");

		TblSafeStore tblSafeStoreObject = null;
		try {
			tblSafeStoreObject = new TblSafeStore();
			tblSafeStoreObject.setSequenceNo(sequenceNumber);
		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new TranslatorException(ErrorCode.TRANSFORMER_FAILURE,
					"Exception occured in prepareTblSafeStoreData");
		}
		LOG.info("Exit - prepareTblSafeStoreData");
		return tblSafeStoreObject;
	}

}
