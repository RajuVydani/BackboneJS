package com.vz.esap.translation.order.model.pc;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;

import com.fasterxml.jackson.annotation.JsonProperty;

@XmlAccessorType(XmlAccessType.FIELD)
public class Ecm {
	
	@XmlElement(name = "AddressId")
	@JsonProperty(value = "AddressId")
	private String addressId;

	@XmlElement(name = "EmergencyCode")
	@JsonProperty(value = "EmergencyCode")
	private EmergencyCode[] emergencyCode;

	public String getAddressId() {
		return addressId;
	}

	public void setAddressId(String AddressId) {
		this.addressId = AddressId;
	}

	public EmergencyCode[] getEmergencyCode() {
		return emergencyCode;
	}

	public void setEmergencyCode(EmergencyCode[] EmergencyCode) {
		this.emergencyCode = EmergencyCode;
	}

	@Override
	public String toString() {
		return "ClassPojo [AddressId = " + addressId + ", EmergencyCode = " + emergencyCode + "]";
	}
}
