package com.vz.esap.translation.order.service.trunk;

import java.util.Arrays;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.vz.esap.translation.dao.model.TblEnvOrder;
import com.vz.esap.translation.dao.model.TblOrder;
import com.vz.esap.translation.dao.model.TblOrderDetails;
import com.vz.esap.translation.dao.model.TblOrderService;
import com.vz.esap.translation.entity.Entity.GroupType;
import com.vz.esap.translation.entity.OrderManagerContactInfoEntity;
import com.vz.esap.translation.entity.TrunkGroupEntity;
import com.vz.esap.translation.enums.EsapEnum.FlowPath;
import com.vz.esap.translation.enums.EsapEnum.OrderEntity;
import com.vz.esap.translation.exception.GenericException;
import com.vz.esap.translation.exception.TranslatorException;
import com.vz.esap.translation.exception.TranslatorException.ErrorCode;
import com.vz.esap.translation.order.dao.VOIPOrderDao;
import com.vz.esap.translation.order.model.Order;
import com.vz.esap.translation.order.model.OrderHeader;
import com.vz.esap.translation.order.model.OrderHeader.SuppType;
import com.vz.esap.translation.order.model.request.ParamInfo;
import com.vz.esap.translation.order.model.request.VOIPOrderRequest;
import com.vz.esap.translation.order.model.response.VoipOrderResponse;
import com.vz.esap.translation.order.parser.OrderParser;
import com.vz.esap.translation.order.service.CancelOrderService;
import com.vz.esap.translation.order.service.OrderServiceBase;
import com.vz.esap.translation.order.service.VOIPResponseGenerator;
import com.vz.esap.translation.order.service.helper.OrderServiceHelperImpl;
import com.vz.esap.translation.order.transformer.EnterpriseTblOrderDataTransformer;
import com.vz.esap.translation.order.transformer.EnterpriseTblOrderServiceDataTransformer;
import com.vz.esap.translation.order.transformer.OrderManagerContactInfoTransformer;
import com.vz.esap.translation.order.transformer.TrunkGroupTransformer;
import com.vz.esap.translation.order.transformer.TrunkTblOrderDetailsDataTransformer;

import EsapEnumPkg.WorkOrderEnum;

/**
 * @author kalagsu
 *
 */
@Service
public class TrunkOrderServiceImpl extends OrderServiceBase implements TrunkOrderService {

	private static final Logger LOG = LoggerFactory.getLogger(TrunkOrderServiceImpl.class);

	@Autowired
	private TrunkGroupTransformer trunkGroupTransformer;

	@Autowired
	private VOIPOrderDao voipOrderDao;

	@Autowired
	private EnterpriseTblOrderServiceDataTransformer enterpriseTblOrderServiceData;

	@Autowired
	private EnterpriseTblOrderDataTransformer enterpriseTblOrderData;

	@Autowired
	private OrderManagerContactInfoTransformer orderManagerContactInfoTransformer;

	@Autowired
	private VOIPResponseGenerator voipResponseGenerator;

	@Autowired
	private TrunkTblOrderDetailsDataTransformer trunkTblOrderDetailsDataTransformerImpl;

	@Autowired
	private OrderServiceHelperImpl orderServiceHelperImpl;

	@Autowired
	private OrderParser orderParserImpl;
	
	@Autowired
	private CancelOrderService cancelOrderServiceImpl;

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.vz.esap.translation.order.service.trunk.TrunkOrderService#
	 * processReleaseOrder(com.vz.esap.translation.dao.model.TblOrderDetails,
	 * com.vz.esap.translation.dao.model.TblOrder,
	 * com.vz.esap.translation.dao.model.TblEnvOrder,
	 * com.vz.esap.translation.order.model.request.VOIPOrderRequest, java.util.List)
	 */
	@Override
	public VoipOrderResponse processReleaseOrder(TblOrderDetails tblOrderDetails, TblOrder tblOrderBeanValidation,
			TblEnvOrder tblEnvOrder, VOIPOrderRequest voipOrderRequest, List<TblOrderDetails> tblOrderDetailsList)
			throws GenericException {
		LOG.info("Entered - processReleaseOrder");

		VoipOrderResponse voipOrderResponse = null;
		TrunkGroupEntity trunkEntity = null;
		OrderHeader orderHeader = null;
		List<TblEnvOrder> tblEnvOrderListPrev = null;
		List<TblOrder> tblOrderListPrev = null;
		List<TblOrderDetails> tblOrderDetailsListPrev = null;
		TrunkGroupEntity trunkEntityPrev = null;
		boolean isNewTrunk;

		try {
			if ("C".equalsIgnoreCase(voipOrderRequest.getOrderHeader().getOrderType())) {
				LOG.info("Inside Trunk Group Change");
				//This will fetch n,r				
				trunkEntity = trunkGroupTransformer.transformOrderDetailsToTrunkGroup(
						tblOrderBeanValidation.getOrderId(), tblOrderDetails.getOrderDetailId(), null, false,
						Arrays.asList("o"));

				//This will fetch o,r
				trunkEntityPrev = trunkGroupTransformer.transformOrderDetailsToTrunkGroup(
						tblOrderBeanValidation.getOrderId(), tblOrderDetails.getOrderDetailId(), null, false,
						Arrays.asList("n"));
				
				//This will fetch if there is any TOD with n
				isNewTrunk = orderServiceHelperImpl.isNewEntityChangeOrder(tblOrderBeanValidation.getOrderId(),
						tblOrderDetails.getOrderDetailId());
				
				LOG.info("Trunk Id = {} Is New Trunk Entity = {}", trunkEntity.getGroupId(), isNewTrunk);
				
				trunkEntity.setNewTrunk(isNewTrunk);

			} else {
				trunkEntity = trunkGroupTransformer.transformOrderDetailsToTrunkGroup(
						tblOrderBeanValidation.getOrderId(), tblOrderDetails.getOrderDetailId(), "n", false, null);
			}

			if (trunkEntity == null) {
				throw new TranslatorException(ErrorCode.TRUNK_TRANSFORMATION_FAILURE,
						"Failed to get Trunk transformation");
			}
			LOG.debug("TrunkEntity : {} ", trunkEntity);

			int orderVersion = Integer.parseInt(voipOrderRequest.getOrderHeader().getWorkOrderVersion());
			LOG.info("Order version:: {}", orderVersion);

			if (orderVersion > 0) {

				VOIPOrderRequest voipOrderRequestPrev = orderParserImpl.getCorrectPrevPassVoipOrderRequest(voipOrderRequest);
				//voipOrderRequestPrev.getOrderHeader().setWorkOrderVersion(Integer.toString(orderVersion - 1));

				tblEnvOrderListPrev = orderServiceHelperImpl.getMatchingPrevPassEnvOrder(voipOrderRequestPrev, 0,
						WorkOrderEnum.OrderClassify.RELEASE);

				LOG.info("ENV ORDER ID PREVIOUS::{}", tblEnvOrderListPrev.get(0).getEnvOrderId());

				//Start : Flex Supp Fix
				
				if (GroupType.TWO_WAY.equals(trunkEntity.getGroupType())) {
					tblOrderListPrev = orderServiceHelperImpl.getMatchingPrevPassOrder(tblEnvOrderListPrev.get(0),
							OrderEntity.TWO_WAY);
					
				} else if (GroupType.INBOUND.equals(trunkEntity.getGroupType())) {
					tblOrderListPrev = orderServiceHelperImpl.getMatchingPrevPassOrder(tblEnvOrderListPrev.get(0),
							OrderEntity.INBOUND);
					
				} else if (GroupType.LINE.equals(trunkEntity.getGroupType())) {
					tblOrderListPrev = orderServiceHelperImpl.getMatchingPrevPassOrder(tblEnvOrderListPrev.get(0),
							OrderEntity.LINE);
					
				} else if (GroupType.PRI_DID.equals(trunkEntity.getGroupType())) {
					tblOrderListPrev = orderServiceHelperImpl.getMatchingPrevPassOrder(tblEnvOrderListPrev.get(0),
							OrderEntity.PRI_DID);
					
				} else if (GroupType.NON_PRI_DID.equals(trunkEntity.getGroupType())) {
					tblOrderListPrev = orderServiceHelperImpl.getMatchingPrevPassOrder(tblEnvOrderListPrev.get(0),
							OrderEntity.NON_PRI_DID);
					
				}
				
				//End : Flex Supp Fix

				if (tblOrderListPrev != null) {
					for (TblOrder tblOrderPrev : tblOrderListPrev) {
						
						if (tblOrderPrev.getAccountNumber().equalsIgnoreCase(trunkEntity.getName())) {
							
							tblOrderDetailsListPrev = orderServiceHelperImpl.getMatchingOrderDetails(tblOrderPrev);
							
							LOG.info("TBL_ORDER_DETAILS records size::{}", tblOrderDetailsListPrev.size());
						}
					}

					if (tblOrderDetailsListPrev != null && !tblOrderDetailsListPrev.isEmpty()) {

						trunkEntityPrev = trunkGroupTransformer.transformOrderDetailsToTrunkGroup(
								tblOrderDetailsListPrev.get(0).getOrderId(), tblOrderDetailsListPrev.get(0).getOrderDetailId(),
								"n", false, null);

						//Fix for Supp dueDate Scenario which is missing IB Trunk Data - Start
						trunkEntity.setDeviceMapId(trunkEntityPrev.getDeviceMapId());
						
						//Fix for Supp dueDate Scenario which is missing IB Trunk Data - End
						
						trunkEntityPrev.setEnvOrderId(tblEnvOrderListPrev.get(0).getEnvOrderId());
						trunkEntityPrev.setInternalOrderId(tblOrderDetailsListPrev.get(0).getOrderId());

						LOG.info("trunkEntityPrev::{}::{}", trunkEntityPrev.getGroupId(),
								trunkEntityPrev.getSignalingDirection());
						LOG.info("trunkEntity::{}::{}", trunkEntity.getGroupId(), trunkEntity.getSignalingDirection());
					}
				}
				
				if (voipOrderRequest.getOrderHeader().getSuppType().equals(SuppType.CANCEL.toString()))
					voipOrderRequest.getOrderHeader().setSuppType(SuppType.CANCEL.toString());
				else
					voipOrderRequest.getOrderHeader().setSuppType(SuppType.SUPP.toString());
			}

			orderHeader = createdOrderHeaderForTrunkOrder(voipOrderRequest, trunkEntity);
			LOG.info("Previous Trunk order status ===>>> {} ", !CollectionUtils.isEmpty(tblOrderListPrev) ? tblOrderListPrev.get(0).getOrderStatus() : "Not supp");
			createReleaseOrders(voipOrderRequest, tblOrderListPrev, orderHeader, trunkEntity, trunkEntityPrev, tblOrderDetailsList, tblOrderBeanValidation,
					WorkOrderEnum.Status.WO_INIT, tblEnvOrder);

			voipOrderResponse = voipResponseGenerator.prepareSuccessOrderResponse(voipOrderRequest);

		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new GenericException(GenericException.GENERIC_EXCEPTION,
					"Exception occured while providing input arguments-" + e);
		}

		LOG.info("Exit - processReleaseOrder");
		return voipOrderResponse;

	}

	/**
	 * @param orderHeader
	 * @param trunkEntity
	 * @param trunkEntityPrev
	 * @param tblOrderDetailsList
	 * @param tblOrderBeanValidation
	 * @param status
	 * @param tblEnvOrderObject
	 * @return isCreated
	 * @throws GenericException
	 * @throws TranslatorException
	 */
	public boolean createReleaseOrders(VOIPOrderRequest voipOrderRequest, List<TblOrder> tblOrderListPrev, OrderHeader orderHeader, TrunkGroupEntity trunkEntity,
			TrunkGroupEntity trunkEntityPrev, List<TblOrderDetails> tblOrderDetailsList,
			TblOrder tblOrderBeanValidation, int status, TblEnvOrder tblEnvOrderObject)
			throws GenericException, TranslatorException {
		LOG.info("Entered - createReleaseOrders");
		boolean isCreated = true;
		Order order = null;
		Order orderPrevPass = null;
		OrderManagerContactInfoEntity cnctInfo = null;
		TblOrder tblOrderObject = null;
		List<TblOrderService> tblOrderServiceList = null;
		long entityType = -1;
		ParamInfo headerParamInfo = null;
		ParamInfo entityParamInfo = null;

		try {
			order = new Order();
			orderHeader.setOrderStatus(status);

			order.setOrderHeader(orderHeader);

			if (trunkEntity == null) {
				trunkEntity = new TrunkGroupEntity();
			}

			// order
			LOG.info("createOrders start creating Trunk entity orders");
			cnctInfo = orderManagerContactInfoTransformer
					.transformValEnvOrderToOrdMgrContactInfo(tblEnvOrderObject.getEnvOrderId(), null);

			if (cnctInfo != null)
				orderHeader.setOrdMgrContactInfo(cnctInfo);
			if (null != tblEnvOrderObject.getEnvOrderId())
				orderHeader.setEnvOrderId(tblEnvOrderObject.getEnvOrderId());
			if (null != tblEnvOrderObject.getProjectId())
				orderHeader.setProjectId(tblEnvOrderObject.getProjectId());
			orderHeader.setEnvOrderId(tblEnvOrderObject.getEnvOrderId());
			orderHeader.setProjectId(tblEnvOrderObject.getProjectId());
			orderHeader.setCustomerId(tblEnvOrderObject.getEnterpriseId());
			orderHeader.setEnterpriseId(tblEnvOrderObject.getEnterpriseId());
			
			if(orderHeader.getLocationId() == null) {
				orderHeader.setLocationId(tblEnvOrderObject.getLocationId());
			}				

			order.setOrderHeader(orderHeader);
			order.setTrunkGroupEntity(trunkEntity);

			if ("TWO_WAY".equals(trunkEntity.getGroupType().toString()))
				entityType = 64L;
			else if ("INBOUND".equals(trunkEntity.getGroupType().toString()))
				entityType = 65L;
			else if ("PBX".equals(trunkEntity.getGroupType().toString()))
				entityType = 5L;
			else if ("KEY".equals(trunkEntity.getGroupType().toString()))
				entityType = 6L;
			else if ("LINE".equals(trunkEntity.getGroupType().toString()))
				entityType = 69L;
			else if ("PRI_DID".equals(trunkEntity.getGroupType().toString()))
				entityType = 70L;
			else if ("NON_PRI_DID".equals(trunkEntity.getGroupType().toString()))
				entityType = 73L;

			if ("I".equalsIgnoreCase(orderHeader.getEntityAction())) {
				if (trunkEntityPrev != null) {
					LOG.info("locationEntityPrev is not null");

					headerParamInfo = trunkTblOrderDetailsDataTransformerImpl
							.prepareTblOrderDetailsHeaderParamData(order, trunkEntityPrev, true);

					entityParamInfo = trunkTblOrderDetailsDataTransformerImpl
							.prepareTblOrderDetailsEntityParamDataForTrunk(trunkEntityPrev, trunkEntity, true, null);

					if (entityParamInfo != null && entityParamInfo.getAction() != null
							&& "C".equals(entityParamInfo.getAction())) {
						LOG.info("entityParamInfo.getAction(): {}", entityParamInfo.getAction());
						
						orderHeader.setEntityAction("C");

						entityParamInfo.addNotNullValChild("TG_INV_CHANGE", "Y", "n");						
						
					} else if (entityParamInfo != null && entityParamInfo.getAction() != null
							&& "NC".equals(entityParamInfo.getAction())) {
						LOG.info("entityParamInfo.getAction(): {}", entityParamInfo.getAction());
						orderHeader.setEntityAction("NC");
					}

				} else {
					headerParamInfo = trunkTblOrderDetailsDataTransformerImpl
							.prepareTblOrderDetailsHeaderParamData(order);

					entityParamInfo = trunkTblOrderDetailsDataTransformerImpl
							.prepareTblOrderDetailsEntityParamDataForTrunk(order, null);
				}
			} else if ("C".equalsIgnoreCase(orderHeader.getEntityAction())) {
				LOG.info("Inside createReleaseOrders For Trunk Change");
				
				if (trunkEntityPrev != null) {
					LOG.info("trunkEntityPrev is not null");

					headerParamInfo = trunkTblOrderDetailsDataTransformerImpl
							.prepareTblOrderDetailsHeaderParamData(order, trunkEntityPrev, true);						
										
					entityParamInfo = trunkTblOrderDetailsDataTransformerImpl
							.prepareTblOrderDetailsEntityParamDataForTrunk(trunkEntityPrev, trunkEntity, true, null);
					
					if (trunkEntity.isNewTrunk()) {
						LOG.info("Trunk is New Install For MAC Order Trunk Id = {}", trunkEntity.getGroupId());
						orderHeader.setEntityAction("I");
						entityParamInfo.setAction("n");

					} else {
						if (entityParamInfo != null && entityParamInfo.getAction() != null
								&& "C".equals(entityParamInfo.getAction())) {
							LOG.info("entityParamInfo.getAction(): {}", entityParamInfo.getAction());

							orderHeader.setEntityAction("C");

							entityParamInfo.addNotNullValChild("TG_INV_CHANGE", "Y", "n");

						} else if (entityParamInfo != null && entityParamInfo.getAction() != null
								&&"NC".equals( entityParamInfo.getAction())) {
							LOG.info("entityParamInfo.getAction(): {}", entityParamInfo.getAction());
							orderHeader.setEntityAction("NC");

						}
					}
				}
			}
			LOG.info("orderHeader.getEntityAction()-TG : {} ", orderHeader.getEntityAction());
			
			if (null != headerParamInfo && !"NC".equalsIgnoreCase(orderHeader.getEntityAction())) {
				
				//ESVRRS-18523 :: START :: Supp other on failed Entity fix.
				int orderVersion = Integer.parseInt(voipOrderRequest.getOrderHeader().getWorkOrderVersion());
				LOG.info("Order version:: {}", orderVersion);
				
				if (orderVersion > 0) {
					if(!CollectionUtils.isEmpty(tblOrderListPrev)) {
						LOG.info("Previous Trunk of type :: {}, order status :: {} ", trunkEntity.getGroupType().toString(), tblOrderListPrev.get(0).getOrderStatus() );
						LOG.info("Trunk records count - {}", tblOrderListPrev.size());
						if(WorkOrderEnum.Status.WO_FAILED == tblOrderListPrev.get(0).getOrderStatus()) {
							LOG.info("Creating reverse order for Trunk with order id {} ", tblOrderListPrev.get(0).getOrderId());
							// Reverse Order Creation..It may be EntityAction I OR C
							cancelOrderServiceImpl.createReverseOrder(voipOrderRequest, tblOrderListPrev, tblEnvOrderObject);
							LOG.info("Creating reverse order for trunk with order id {} COMPLETED !!!!", tblOrderListPrev.get(0).getOrderId());
							
							//Creating Forward order...
							LOG.info("Creating Forward Order..... ");
							
							headerParamInfo = trunkTblOrderDetailsDataTransformerImpl
									.prepareTblOrderDetailsHeaderParamData(order);
							
							entityParamInfo = trunkTblOrderDetailsDataTransformerImpl
									.prepareTblOrderDetailsEntityParamDataForTrunk(order, null);
							orderHeader.setEntityAction("I");
							LOG.info("Creating Forward Order.....COMPLETED !!! ");
						}
					}
				}
				//ESVRRS-18523 :: END
				
				headerParamInfo.addChildParam(entityParamInfo);

				// :create order
				tblOrderObject = enterpriseTblOrderData.prepareTblOrderDataFromOrder(order, entityType);
				voipOrderDao.createTblOrder(tblOrderObject);

				LOG.info("Tbl_Order Created for Group , Order Id : {}", tblOrderObject.getOrderId());

				// :create order Details
				LOG.info("createOrders start creating Group entity order details");

				if (entityParamInfo != null && entityParamInfo.getAction() != null)
					voipOrderDao.populateOrderDetails(tblOrderObject, headerParamInfo.getChildParams(),
							entityParamInfo.getAction(), 0, 0);
				else
					voipOrderDao.populateOrderDetails(tblOrderObject, headerParamInfo.getChildParams(), "n", 0, 0);

				// :create service entry for WF
				LOG.info("createOrders start creating service for customer entity");
				orderHeader.setFlowPath(FlowPath.valueOf(tblOrderObject.getFlowPath()));
				orderHeader.setTblOrderId(tblOrderObject.getOrderId());
				LOG.info("orderHeader.getEntityType() {}", orderHeader.getEntityType());
				orderHeader.setProvisionCategory(trunkEntity.getProvisionCategory());
				
				order.setOrderHeader(orderHeader);

				orderPrevPass = new Order();
				orderPrevPass.setOrderHeader(orderHeader);
				orderPrevPass.setTrunkGroupEntity(trunkEntityPrev);
				tblOrderServiceList = enterpriseTblOrderServiceData.prepareTblOrderServiceData(order, orderPrevPass,
						null);

				LOG.info("Retail Order Service Count : {}", tblOrderServiceList.size());

				for (TblOrderService tblOrderService : tblOrderServiceList) {
					voipOrderDao.createTblOrderService(tblOrderService);
				}

				voipOrderDao.updateTblOrderStatus(tblOrderObject.getOrderId(), WorkOrderEnum.Status.WO_INIT);

			} else if (trunkEntityPrev != null && "NC".equalsIgnoreCase(orderHeader.getEntityAction())) {
				LOG.info("deviceEntityPrev != null && \"NC\".equalsIgnoreCase(orderHeader.getEntityAction())");
				LOG.info("Order Version ==>> {}", orderHeader.getOrderVersion());

				int orderVersion = Integer.parseInt(orderHeader.getOrderVersion());

				if (orderVersion > 0) {
					orderServiceHelperImpl.handleSuppOrderWithNoChange(tblEnvOrderObject.getEnvOrderId(),
							trunkEntityPrev.getInternalOrderId(), tblEnvOrderObject);

				} else {
					LOG.info("This is MAC Device Scenario of Do Nothing");
				}
			}
		} catch (TranslatorException ex) {						
			LOG.error("Exception {} {}", ex.getMessage(), ex);
			throw new TranslatorException(ex.getErrorCode(), ex.getMessage());
		} catch (Exception e) {
			LOG.error("Exception {} {}", e.getMessage(), e);
			throw new GenericException(GenericException.GENERIC_EXCEPTION,
					"Exception occured while providing input arguments");
		}
		LOG.info("Exit - createReleaseOrders");
		return isCreated;
	}
}
