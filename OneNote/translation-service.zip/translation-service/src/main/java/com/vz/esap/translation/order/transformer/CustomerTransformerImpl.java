package com.vz.esap.translation.order.transformer;

/**
 * @author Niladri Chattaraj
 *
 */
import java.math.BigInteger;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.vz.esap.translation.dao.model.TblOrderDetails;
import com.vz.esap.translation.entity.CustomerEntity;
import com.vz.esap.translation.entity.CustomerEntity.QosIndicator;
import com.vz.esap.translation.entity.CustomerEntity.SlaType;
import com.vz.esap.translation.entity.LocationEntity;
import com.vz.esap.translation.entity.ParamInfo;
import com.vz.esap.translation.entity.TrunkGroupEntity;
import com.vz.esap.translation.entity.Entity.GroupType;
import com.vz.esap.translation.enums.EsapEnum.AuthFeatureType;
import com.vz.esap.translation.enums.EsapEnum.SolutionType;
import com.vz.esap.translation.exception.ApplicationInterfaceException;
import com.vz.esap.translation.exception.GenericException;
import com.vz.esap.translation.exception.TranslatorException;
import com.vz.esap.translation.exception.TranslatorException.ErrorCode;
import com.vz.esap.translation.order.dao.VOIPOrderDao;
import com.vz.esap.translation.order.model.request.VOIPOrderRequest;
import com.vz.esap.translation.order.service.helper.OrderServiceHelper;
import com.vz.esap.translation.util.OrderUtility;

import EsapEnumPkg.VzbVoipEnum;
import EsapEnumPkg.VzbVoipEnums;
import EsapEnumPkg.VzbVoipEnums.OrderPlatformEnum;

@Component
public class CustomerTransformerImpl implements CustomerTransformer {

	@Autowired
	private VOIPOrderDao voipOrderDao;

	@Autowired
	private ParamInfoTransformer paramInfoTransformer;

	@Autowired
	private OrderServiceHelper orderServiceHelper;

	private static final Logger LOG = LoggerFactory.getLogger(CustomerTransformerImpl.class);

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.vz.esap.translation.order.transformer.CustomerTransformer#
	 * transformOrderDetailsToCustomer(long, long, java.lang.String, boolean)
	 */
	@Override
	public CustomerEntity transformOrderDetailsToCustomer(long orderId, long parentId, String action, boolean delta, List<String> paramActionExclusionList)
			throws TranslatorException {
		LOG.info("CustomerTransformerImpl - transformOrderDetailsToCustomer");

		return createCustomerFromParamInfo(
				createCustomerParamInfoFromOrderDetails(orderId, parentId, action, delta, null), paramActionExclusionList);

	}

	/**
	 * @param parent
	 * @return customerEntity
	 * @throws TranslatorException
	 */
	private CustomerEntity createCustomerFromParamInfo(ParamInfo parent, List<String> paramActionExclusionList) throws TranslatorException {

		LOG.info("CustomerTransformerImpl - createCustomerFromParamInfo");
		CustomerEntity customerEntity = new CustomerEntity();

		try {
			for (ParamInfo param : parent.getChildParams()) {
				LOG.debug("Enterprise Params --- Name:{}  Value:{} ChildParamCnt:{}", param.getName(), param.getValue(),
						(param.getChildParams() == null ? 0 : param.getChildParams().size()));

				if (paramActionExclusionList != null && !paramActionExclusionList.isEmpty()) {
					boolean skip = false;
					for (String exclude : paramActionExclusionList) {
						if (exclude.equalsIgnoreCase(param.getAction())) {
							skip = true;
						}
					}
					if (skip)
						continue;
				}
				
				if (param.getName().equals("AuthService")) {
					LOG.info("********param.getChildParams() :: {} ", param.getChildParams());

					if (param.getChildParams() != null) {
						String svc = null;
						Boolean authorised = null;
						String featureQuantity = null;
						for (ParamInfo par2 : param.getChildParams()) {
							LOG.info("********Inside Params :: {}", par2.getName());
							if (par2.getName().equals("Name"))
								svc = par2.getValue();
							if (par2.getName().equals("Authorised") && par2.getValue() != null) {
								authorised = OrderUtility.getBooleanFromYN(par2.getValue());
							}
							if (par2.getName().equals("FeatureQuantity") && par2.getValue() != null) {
								featureQuantity =  par2.getValue();
							}
						}
						if(featureQuantity!=null) {
							customerEntity.prepareAuthService(svc, featureQuantity, authorised);
						}else {
							customerEntity.addAuthService(svc, authorised);
						}
					}
				} else if (param.getName().equals("SipDomains")) {
					if (param.getChildParams() != null)
						param.getChildParams().forEach(par2 -> customerEntity.addToSipDomains(par2.getValue()));
				} else if (param.getName().equals("CustomerId"))
					customerEntity.setCustomerId(param.getValue());
				else if (param.getName().equals("CustomerName"))
					customerEntity.setCustomerName(param.getValue());
				else if (param.getName().equals("RIVCustomer"))
					customerEntity.setRivCustomer(param.getValue());
				else if (param.getName().equals("OrderPlatform") && param.getValue() != null)
					customerEntity.setOrderPlatform(OrderPlatformEnum.getByAcronym(param.getValue()));
				else if (param.getName().equals("LOR"))
					customerEntity.setLOR(param.getValue());
				else if (param.getName().equals("DesignId"))
					customerEntity.setDesignId(Long.valueOf(param.getValue()));
				else if (param.getName().equals("SbcLoadSharingEnabled"))
					customerEntity.setSbcLoadSharing(param.getValue());
				else if (param.getName().equals("DefaultSubnet"))
					customerEntity.setDefaultSubnet(param.getValue());
				else if (param.getName().equals("ProductType"))
					customerEntity.setProductType(Integer.valueOf(param.getValue()));
				else if (param.getName().equals("ContactFirstName"))
					customerEntity.setContactFirstName(param.getValue());
				else if (param.getName().equals("ContactLastName"))
					customerEntity.setContactLastName(param.getValue());
				else if (param.getName().equals("ContactTitle"))
					customerEntity.setContactTitle(param.getValue());
				else if (param.getName().equals("ContactAddress1"))
					customerEntity.setContactAddress1(param.getValue());
				else if (param.getName().equals("ContactAddress2"))
					customerEntity.setContactAddress2(param.getValue());
				else if (param.getName().equals("ContactCity"))
					customerEntity.setContactCity(param.getValue());
				else if (param.getName().equals("ContactState"))
					customerEntity.setContactState(param.getValue());
				else if (param.getName().equals("ContactZip"))
					customerEntity.setContactZip(param.getValue());
				else if (param.getName().equals("ContactCountry"))
					customerEntity.setContactCountry(param.getValue());
				else if (param.getName().equals("ContactPhone1"))
					customerEntity.setContactPhone1(param.getValue());
				else if (param.getName().equals("ContactPhone2"))
					customerEntity.setContactPhone2(param.getValue());
				else if (param.getName().equals("ContactFax"))
					customerEntity.setContactFax(param.getValue());
				else if (param.getName().equals("ContactMobile"))
					customerEntity.setContactMobile(param.getValue());
				else if (param.getName().equals("ContactPager"))
					customerEntity.setContactPager(param.getValue());
				else if (param.getName().equals("ContactEmail"))
					customerEntity.setContactEmail(param.getValue());
				else if (param.getName().equals("RegionType"))
					customerEntity
							.setRegionType(Integer.valueOf(VzbVoipEnum.RegionType.valueByAcronym(param.getValue())));
				else if (param.getName().equals("AccountTeamName"))
					customerEntity.setAccountTeamName(param.getValue());
				else if (param.getName().equals("AccountTeamPhone"))
					customerEntity.setAccountTeamPhone(param.getValue());
				else if (param.getName().equals("AccountTeamEmail"))
					customerEntity.setAccountTeamEmail(param.getValue());
				else if (param.getName().equals("NonTrustedIPCalls"))
					customerEntity.setNonTrustedIPCalls(param.getValue());
				else if (param.getName().equals("AllowOnNet"))
					customerEntity.setAllowOnNet(param.getValue());
				else if (param.getName().equals("SipDomain"))
					customerEntity.setSipDomain(param.getValue());
				else if (param.getName().equals("XrefCustomerId"))
					customerEntity.setXrefCustomerId(param.getValue());
				else if (param.getName().equals("OrderComment"))
					customerEntity.setOrderComment(param.getValue());
				else if (param.getName().equals("BillingSystem") && param.getValue() != null)
					customerEntity.setBillingSystem(
							Integer.valueOf(VzbVoipEnum.BillingSystemType.valueByAcronym(param.getValue())));
				else if (param.getName().equals("VnetCorpId"))
					customerEntity.setVnetCorpId(new BigInteger(param.getValue()));
				else if (param.getName().equals("CentrexType") && param.getValue() != null)
					customerEntity
							.setCentrexType(Integer.valueOf(VzbVoipEnum.CentrexType.valueByAcronym(param.getValue())));
				else if (param.getName().equals("AgencyHierCode"))
					customerEntity.setAgencyHierCode(param.getValue());
				else if (param.getName().equals("ContractInd"))
					customerEntity.setContractInd(param.getValue());
				else if (param.getName().equals("CalnetSubContractInd"))
					customerEntity.setCalnetSubContractInd(param.getValue());
				else if (param.getName().equals("AdminFirstName"))
					customerEntity.setAdminFirstName(param.getValue());
				else if (param.getName().equals("AdminLastName"))
					customerEntity.setAdminLastName(param.getValue());
				else if (param.getName().equals("AdminEmail"))
					customerEntity.setAdminEmail(param.getValue());
				else if (param.getName().equals("AdminWebLoginId"))
					customerEntity.setAdminWebLoginId(param.getValue());
				else if (param.getName().equals("AdminPassword"))
					customerEntity.setAdminPassword(param.getValue());
				else if (param.getName().equals("ParentEnterpriseId"))
					customerEntity.setParentEnterpriseId(param.getValue());
				else if (param.getName().equals("EnterpriseCclIndicator"))
					customerEntity.setEnterpriseCclIndicator(OrderUtility.getBooleanFromYN(param.getValue()));
				else if (param.getName().equals("NewIPCCCustOnChange"))
					customerEntity.setIpccCustOnChg(OrderUtility.getBooleanFromYN(param.getValue())); // New
				// IPCC
				else if (param.getName().equals("TntCclInd"))
					customerEntity.setTntCclInd(Boolean.valueOf(param.getValue()));
				else if (param.getName().equals("QosIndicator") && param.getValue() != null)
					customerEntity.setQosIndicator(CustomerEntity.QosIndicator.valueOf(param.getValue()));
				else if (param.getName().equals("SlaType") && param.getValue() != null)
					customerEntity.setSlaType(CustomerEntity.SlaType.valueOf(param.getValue()));
				else if (param.getName().equals("CallingPlanId") && param.getValue() != null)
					customerEntity.setCallingPlanId(Integer.valueOf(param.getValue()));
				else if (param.getName().equals("BsAppServer"))
					customerEntity.setBsAppServer(param.getValue());
				else if (param.getName().equals("AsClli"))
					customerEntity.setAsClli(param.getValue());
				else if (param.getName().equals("VmPartitionId"))
					customerEntity.setVmPartitionId(param.getValue());
				else if (param.getName().equals("CommonCustomerId"))
					customerEntity.setCommonCustId(param.getValue());
				else if (param.getName().equals("CommonCustomerName"))
					customerEntity.setCommonCustName(param.getValue());
				else if (param.getName().equals("BillContactPriPhone"))
					customerEntity.setBillContactPriPhone(param.getValue());
				else if (param.getName().equals("BillContactAltPhone"))
					customerEntity.setBillContactAltPhone(param.getValue());
				else if (param.getName().equals("BillContactCell"))
					customerEntity.setBillContactCell(param.getValue());
				else if (param.getName().equals("BillContactPager"))
					customerEntity.setBillContactPager(param.getValue());
				else if (param.getName().equals("BillContactEmail"))
					customerEntity.setBillContactEmail(param.getValue());
				else if (param.getName().equals("BillContactAddr1"))
					customerEntity.setBillContactAddr1(param.getValue());
				else if (param.getName().equals("BillContactAddr2"))
					customerEntity.setBillContactAddr2(param.getValue());
				else if (param.getName().equals("BillContactCity"))
					customerEntity.setBillContactCity(param.getValue());
				else if (param.getName().equals("BillContactState"))
					customerEntity.setBillContactState(param.getValue());
				else if (param.getName().equals("BillContactZip"))
					customerEntity.setBillContactZip(param.getValue());
				else if (param.getName().equals("BillContactCountry"))
					customerEntity.setBillContactCountry(param.getValue());
				else if (param.getName().equals("SalesSegment") && param.getValue() != null)
					customerEntity.setSalesSegment(new Long(param.getValue()));
				else if (param.getName().equals("SalesRepId"))
					customerEntity.setSalesRepId(param.getValue());
				else if (param.getName().equals("SalesRepName"))
					customerEntity.setSalesRepName(param.getValue());
				else if (param.getName().equals("SalesRepPhone"))
					customerEntity.setSalesRepPhone(param.getValue());
				else if (param.getName().equals("SalesRepEmail"))
					customerEntity.setSalesRepEmail(param.getValue());
				else if (param.getName().equals("CustCorpId"))
					customerEntity.setCustCorpId(param.getValue());
				else if (param.getName().equals("OrderVerification") && param.getValue() != null)
					customerEntity.setOrderVerification(new Long(param.getValue()));
				else if (param.getName().equals("SupportName"))
					customerEntity.setSupportName(param.getValue());
				else if (param.getName().equals("SupportPhone"))
					customerEntity.setSupportPhone(param.getValue());
				else if (param.getName().equals("MicroNode"))
					customerEntity.setMicroNode(param.getValue());
				else if (param.getName().equals("EmeaServiceSupport") && param.getValue() != null)
					customerEntity.setEmeaServiceSupport(new Long(param.getValue()));
				else if (param.getName().equals("CustSensitivityLevel"))
					customerEntity.setCustSensitivityLevel(param.getValue());
				else if (param.getName().equals("CustGarmStatus") && param.getValue() != null)
					customerEntity.setCustGarmStatus(new Long(param.getValue()));
				else if (param.getName().equals("CustActiveInd") && param.getValue() != null)
					customerEntity.setCustActiveInd(new Long(param.getValue()));
				else if (param.getName().equals("BsBlockInd") && param.getValue() != null)
					customerEntity.setBsBlockInd(Integer.valueOf(param.getValue()));
				else if (param.getName().equals("NaspId"))
					customerEntity.setNaspId(param.getValue());

				// E2E Mar Changes
				else if (param.getName().equals("Address"))
					customerEntity.setVirtualAddrLine(param.getValue());
				else if (param.getName().equals("City"))
					customerEntity.setVirtualAddrCity(param.getValue());
				else if (param.getName().equals("State"))
					customerEntity.setVirtualAddrState(param.getValue());
				else if (param.getName().equals("Zip"))
					customerEntity.setVirtualAddrZip(param.getValue());
				else if (param.getName().equals("Country"))
					customerEntity.setVirtualAddrCountry(param.getValue());

				else if (param.getName().equals("GCHId"))
					customerEntity.setGchId(param.getValue());

				else if (param.getName().equals("LorId"))
					customerEntity.setLorId(param.getValue());
				else if (param.getName().equals("DesignId"))
					customerEntity.setDesignId(Long.valueOf(param.getValue()));

				// E2E Mar Service Optimization Changes
				else if (param.getName().equals("SOEnabled"))
					customerEntity.setSoEnabled(param.getValue());
				else if (param.getName().equals("USLDAndLocalBestPool"))
					customerEntity.setUsLDAndLocalBestPool(param.getValue());
				else if (param.getName().equals("USLDOnlyBestPool"))
					customerEntity.setUsLDOnlyBestPool(param.getValue());
				else if (param.getName().equals("EmeaApacBestPool"))
					customerEntity.setEmeaApacBestPool(param.getValue());
				else if (param.getName().equals("USLDAndLocalBestPlusPool"))
					customerEntity.setUsLDAndLocalBestPlusPool(param.getValue());

				else if (param.getName().equals("USLDAndLocalBestPlusPoolId"))
					customerEntity.setUsLDAndLocalBestPlusPoolId(param.getValue());
				else if (param.getName().equals("USLDAndLocalBestPlusCclPoolId"))
					customerEntity.setUsLDAndLocalBestPlusCclPoolId(param.getValue());
				else if (param.getName().equals("USLDOnlyBestPlusPool"))
					customerEntity.setUsLDOnlyBestPlusPool(param.getValue());

				else if (param.getName().equals("USLDOnlyBestPlusPoolId"))
					customerEntity.setUsLDOnlyBestPlusPoolId(param.getValue());
				else if (param.getName().equals("USLDOnlyBestPlusCclPoolId"))
					customerEntity.setUsLDOnlyBestPlusCclPoolId(param.getValue());
				else if (param.getName().equals("EmeaApacBestPlusPool"))
					customerEntity.setEmeaApacBestPlusPool(param.getValue());

				else if (param.getName().equals("EmeaApacBestPlusPoolId"))
					customerEntity.setEmeaApacBestPlusPoolId(param.getValue());
				else if (param.getName().equals("EmeaApacBestPlusCclPoolId"))
					customerEntity.setEmeaApacBestPlusCclPoolId(param.getValue());
				else if (param.getName().equals("EntepriseCountryCode"))
					customerEntity.setEntCountryCode(param.getValue());
				else if (param.getName().equals("EnterpriseTrunkingType") && param.getValue() != null)
					customerEntity.setEnterpriseTrunkingType(
							VzbVoipEnums.EnterpriseTrunkingTypeEnum.getByAcronym(param.getValue()));
				else if (param.getName().equals("CatalogueReferenceTime") && param.getValue() != null) {
					LOG.info("catalogReferencetime-->{}", param.getValue());
					customerEntity.setCatalogVersionTime(param.getValue());
				}

				// E2E Mar Changes End

				else if (param.getName().equals("MarketType"))
					customerEntity.setMarketType(param.getValue());
				else if (param.getName().equals("AdditionalAttribs")) {
					if (param.getChildParams() != null)
						for (ParamInfo par2 : param.getChildParams()) {
							customerEntity.addAttrib(par2.getName(), par2.getValue());
							if (null != par2 && null != par2.getName()
									&& par2.getName().equals("BroadsoftTNActivation")) {
								String broadsoftTNActivation = par2.getValue();
								if (null != broadsoftTNActivation && broadsoftTNActivation.equals("1")) {
									customerEntity.setBroadsoftTNActivation(1);
								} else if (null != broadsoftTNActivation && broadsoftTNActivation.equals("0")) {
									customerEntity.setBroadsoftTNActivation(0);
								}
							}
						}
				} else if (param.getName().equals("HotCutIndicator")) {
					if (param.getValue() != null && param.getValue().equals("Y"))
						customerEntity.setHotCutIndicator(Boolean.TRUE);
				} else if (param.getName().equals("CDDDIndicator")) {
					if (param.getValue() != null && param.getValue().equals("Y"))
						customerEntity.setCDDDIndicator(Boolean.TRUE);
				}
				else if (param.getName().equals("CummulativeCcl")) {
					LOG.info("cummulativeCcl-->{}", param.getValue());
					customerEntity.setCummulativeCcl(Long.valueOf(param.getValue()));

				} else if (param.getName().equals("BestPlusTier")) {
					LOG.info("BestPlusTier12-->{}", param.getValue());
					customerEntity.setBestPlusTier(param.getValue());

				}
				// XOO

				else if (param.getName().equals("BWEnterpriseId")) {
					LOG.info("BWEnterpriseId-->{}", param.getValue());
					customerEntity.setBwEnterpriseId(param.getValue());
				} else if (param.getName().equals("VoiceVPN")) {
					LOG.info("VoiceVPN-->{}", param.getValue());
					customerEntity.setVoiceVpn(param.getValue());// Anitha- default false
				} else if (param.getName().equals("SolutionType")) {
					customerEntity.setSolutionType(SolutionType.valueOf(param.getValue()));
					LOG.info("SolutionType.valueOf(param.getValue()) : {} ", SolutionType.valueOf(param.getValue()));
				}					
				else if (param.getName().equals("EnableEnterpriseExtensionDialing"))
					customerEntity.setEnableEnterpriseExtensionDialing(true);// Anitha- default true
				else if (param.getName().equals("Region")) {
					customerEntity.setRegion(param.getValue());
				} else if (param.getName().equals("AuthFeatureType")) {
					customerEntity.setAuthFeatureType(AuthFeatureType.valueOf(param.getValue()));
				}
				else if (param.getName().equals("ProvisionCategory")) {
					customerEntity.setProvisionCategory(param.getValue());
				}

				// XOO
			}

			if (customerEntity.getOrderPlatform() == null) {
				LOG.info("null check for riv customer-->{} -->{}", customerEntity.getRivCustomer(),
						customerEntity.getRivCustomer());
				if (null != customerEntity.getRivCustomer())
					if (customerEntity.getRivCustomer().equalsIgnoreCase("Y"))
						customerEntity.setOrderPlatform(OrderPlatformEnum.RIV);
					else
						customerEntity.setOrderPlatform(OrderPlatformEnum.NONRIV);
			}
		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new TranslatorException(ErrorCode.TRANSFORMER_FAILURE,
					"Exception occured in createCustomerFromParamInfo");
		}
		return customerEntity;
	}

	/**
	 * @param orderId
	 * @param parentId
	 * @param action
	 * @param delta
	 * @param paramName
	 * @return root
	 * @throws TranslatorException
	 */
	private ParamInfo createCustomerParamInfoFromOrderDetails(long orderId, long parentId, String action, boolean delta,
			String paramName) throws TranslatorException {
		LOG.info(
				"In CustomerTransformerImpl createCustomerParamInfoFromOrderDetails ordId:{} parentId:{} action:{} delta:{}",
				orderId, parentId, action, delta);
		ParamInfo root = null;
		TblOrderDetails tblOrderDetails = null;
		List<TblOrderDetails> ordDetails = null;
		String param_val = null;// OrderUtil.getConfigParamValue(dbcon, "SUPP_CANCEL", "SUPP_CANCEL"); :
		// This is TODO

		try {
			tblOrderDetails = new TblOrderDetails();
			tblOrderDetails.setOrderId(orderId);
			tblOrderDetails.setAction(action);
			tblOrderDetails.setParentId(parentId);
			tblOrderDetails.setParamName(paramName);
			ordDetails = voipOrderDao.getOrderDetailsWithActionAndParent(parentId, action, delta, paramName,
					tblOrderDetails);

			LOG.info("List Size:{}", ordDetails.size());

			boolean flag = true;
			if (param_val != null && param_val.equalsIgnoreCase("Y")) {
				flag = false;
			}
			if (flag) {
				if (ordDetails.size() <= 0) {
					LOG.info("Param details Not found for customer ");
					return null;
				}
			}
			root = new ParamInfo("CustomerEntity", null, null);
			root = paramInfoTransformer.transformOrderDetailsToParamInfo(ordDetails, root, 0, null);

			// return createInstanceFromOrderDetails(ordDetails);
		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new TranslatorException(ErrorCode.TRANSFORMER_FAILURE,
					"Exception occured in createCustomerParamInfoFromOrderDetails");
		}
		return root;
	}

	@Override
	public CustomerEntity enrichCustomerEntityWithInventory(VOIPOrderRequest voipOrderRequest,
			CustomerEntity customerEntity)
			throws IllegalAccessException, ApplicationInterfaceException, TranslatorException, GenericException {
		LOG.info("Entered enrichCustomerEntityWithInventory");

		CustomerEntity customerEntityInv = orderServiceHelper
				.getEntityDetailsFromInventory(customerEntity.getCustomerId(), CustomerEntity.class);

		// Copying Location Inv Details to Original Location Entity

		LOG.info("++Level 10+++++Original customer Entity : {} ", customerEntity);

		LOG.info("++Level 10+++++Changed customer Entity : {} ", customerEntity.getCustomerEntity());

		LOG.info("++Level 10+++++Original customer Entity customerEntityInv : {} ", customerEntityInv);

		LOG.info("++Level 10+++++Changed customer Entity customerEntityInv.getcustomerEntity() : {} ",
				customerEntityInv.getCustomerEntity());

		customerEntity = copyFields(customerEntityInv, customerEntity);

		LOG.info("++Level 11+++++Original customer Entity : {} ", customerEntity);

		LOG.info("++Level 11+++++Changed customer Entity : {} ", customerEntity.getCustomerEntity());

		if (customerEntity.getCustomerEntity() != null) {
			CustomerEntity customerEntityChanged = customerEntity.getCustomerEntity();

			// Copying trunkGrp Inv Details to Changed trunkGrp Entity
			copyFields(customerEntity, customerEntityChanged);

			LOG.info("++Level 3+++++Original Customer Entity : {} ", customerEntity);

			LOG.info("++Level 3+++++Changed Customer Entity : {} ", customerEntity.getCustomerEntity());

		}

		LOG.info("Exit enrichCustomerEntityWithInventory Customer Enriched = {} ", customerEntity);
		return customerEntity;
	}
	
	private CustomerEntity copyFields(CustomerEntity currentCustomerEntity, CustomerEntity resultCustomerEntity) {
		
		// Inventory -> original
		if (resultCustomerEntity.getCustomerId() == null && currentCustomerEntity.getCustomerId() != null) {
			resultCustomerEntity.setCustomerId(currentCustomerEntity.getCustomerId());
		}
		if (resultCustomerEntity.getCustomerName() == null && currentCustomerEntity.getCustomerName() != null) {
			resultCustomerEntity.setCustomerName(currentCustomerEntity.getCustomerName());
		}
		if (resultCustomerEntity.getRivCustomer() == null && currentCustomerEntity.getRivCustomer() != null) {
			resultCustomerEntity.setRivCustomer(currentCustomerEntity.getRivCustomer());
		}
		if (resultCustomerEntity.getOrderPlatform() == null && currentCustomerEntity.getOrderPlatform() != null) {
			resultCustomerEntity.setOrderPlatform(currentCustomerEntity.getOrderPlatform());
		}
		if (resultCustomerEntity.getLOR() == null && currentCustomerEntity.getLOR() != null) {
			resultCustomerEntity.setLOR(currentCustomerEntity.getLOR());
		}
		if (resultCustomerEntity.getDesignId() == null && currentCustomerEntity.getDesignId() != null) {
			resultCustomerEntity.setDesignId(currentCustomerEntity.getDesignId());
		}
		if (resultCustomerEntity.getSbcLoadSharing() == null && currentCustomerEntity.getSbcLoadSharing() != null) {
			resultCustomerEntity.setSbcLoadSharing(currentCustomerEntity.getSbcLoadSharing());
		}
		if (resultCustomerEntity.getDefaultSubnet() == null && currentCustomerEntity.getDefaultSubnet() != null) {
			resultCustomerEntity.setDefaultSubnet(currentCustomerEntity.getDefaultSubnet());
		}
		if (resultCustomerEntity.getProductType() == null && currentCustomerEntity.getProductType() != null) {
			resultCustomerEntity.setProductType(currentCustomerEntity.getProductType());
		}
		if (resultCustomerEntity.getContactFirstName() == null && currentCustomerEntity.getContactFirstName() != null) {
			resultCustomerEntity.setContactFirstName(currentCustomerEntity.getContactFirstName());
		}
		if (resultCustomerEntity.getContactLastName() == null && currentCustomerEntity.getContactLastName() != null) {
			resultCustomerEntity.setContactLastName(currentCustomerEntity.getContactLastName());
		}
		if (resultCustomerEntity.getContactTitle() == null && currentCustomerEntity.getContactTitle() != null) {
			resultCustomerEntity.setContactTitle(currentCustomerEntity.getContactTitle());
		}
		if (resultCustomerEntity.getContactAddress1() == null && currentCustomerEntity.getContactAddress1() != null) {
			resultCustomerEntity.setContactAddress1(currentCustomerEntity.getContactAddress1());
		}
		if (resultCustomerEntity.getContactAddress2() == null && currentCustomerEntity.getContactAddress2() != null) {
			resultCustomerEntity.setContactAddress2(currentCustomerEntity.getContactAddress2());
		}
		if (resultCustomerEntity.getContactCity() == null && currentCustomerEntity.getContactCity() != null) {
			resultCustomerEntity.setContactCity(currentCustomerEntity.getContactCity());
		}
		if (resultCustomerEntity.getContactState() == null && currentCustomerEntity.getContactState() != null) {
			resultCustomerEntity.setContactState(currentCustomerEntity.getContactState());
		}
		if (resultCustomerEntity.getContactZip() == null && currentCustomerEntity.getContactZip() != null) {
			resultCustomerEntity.setContactZip(currentCustomerEntity.getContactZip());
		}
		if (resultCustomerEntity.getContactCountry() == null && currentCustomerEntity.getContactCountry() != null) {
			resultCustomerEntity.setContactCountry(currentCustomerEntity.getContactCountry());
		}
		if (resultCustomerEntity.getContactPhone1() == null && currentCustomerEntity.getContactPhone1() != null) {
			resultCustomerEntity.setContactPhone1(currentCustomerEntity.getContactPhone1());
		}
		if (resultCustomerEntity.getContactPhone2() == null && currentCustomerEntity.getContactPhone2() != null) {
			resultCustomerEntity.setContactPhone2(currentCustomerEntity.getContactPhone2());
		}
		if (resultCustomerEntity.getContactFax() == null && currentCustomerEntity.getContactFax() != null) {
			resultCustomerEntity.setContactFax(currentCustomerEntity.getContactFax());
		}
		if (resultCustomerEntity.getContactMobile() == null && currentCustomerEntity.getContactMobile() != null) {
			resultCustomerEntity.setContactMobile(currentCustomerEntity.getContactMobile());
		}
		if (resultCustomerEntity.getContactPager() == null && currentCustomerEntity.getContactPager() != null) {
			resultCustomerEntity.setContactPager(currentCustomerEntity.getContactPager());
		}
		if (resultCustomerEntity.getContactEmail() == null && currentCustomerEntity.getContactEmail() != null) {
			resultCustomerEntity.setContactEmail(currentCustomerEntity.getContactEmail());
		}
		if (resultCustomerEntity.getRegionType() == null && currentCustomerEntity.getRegionType() != null) {
			resultCustomerEntity.setRegionType(currentCustomerEntity.getRegionType());
		}
		if (resultCustomerEntity.getAccountTeamName() == null && currentCustomerEntity.getAccountTeamName() != null) {
			resultCustomerEntity.setAccountTeamName(currentCustomerEntity.getAccountTeamName());
		}
		if (resultCustomerEntity.getAccountTeamPhone() == null && currentCustomerEntity.getAccountTeamPhone() != null) {
			resultCustomerEntity.setAccountTeamPhone(currentCustomerEntity.getAccountTeamPhone());
		}
		if (resultCustomerEntity.getBillingSystem() == null && currentCustomerEntity.getBillingSystem() != null) {
			resultCustomerEntity.setBillingSystem(currentCustomerEntity.getBillingSystem());
		}
		if (resultCustomerEntity.getCentrexType() == null && currentCustomerEntity.getCentrexType() != null) {
			resultCustomerEntity.setCentrexType(currentCustomerEntity.getCentrexType());
		}
		if (resultCustomerEntity.getEnterpriseCclIndicator() == null && currentCustomerEntity.getEnterpriseCclIndicator() != null) {
			resultCustomerEntity.setEnterpriseCclIndicator(currentCustomerEntity.getEnterpriseCclIndicator());
		}
		
		if (resultCustomerEntity.getBsAppServer() == null && currentCustomerEntity.getBsAppServer() != null) {
			resultCustomerEntity.setBsAppServer(currentCustomerEntity.getBsAppServer());
		}
		if (resultCustomerEntity.getNaspId() == null && currentCustomerEntity.getNaspId() != null) {
			resultCustomerEntity.setNaspId(currentCustomerEntity.getNaspId());
		}
		if (resultCustomerEntity.getGchId() == null && currentCustomerEntity.getGchId() != null) {
			resultCustomerEntity.setGchId(currentCustomerEntity.getGchId());
		}
		if (resultCustomerEntity.getSoEnabled() == null && currentCustomerEntity.getSoEnabled() != null) {
			resultCustomerEntity.setSoEnabled(currentCustomerEntity.getSoEnabled());
		}
		if (resultCustomerEntity.getEnterpriseTrunkingType() == null && currentCustomerEntity.getEnterpriseTrunkingType() != null) {
			resultCustomerEntity.setEnterpriseTrunkingType(currentCustomerEntity.getEnterpriseTrunkingType());
		}
		if (resultCustomerEntity.getCatalogVersionTime() == null && currentCustomerEntity.getCatalogVersionTime() != null) {
			resultCustomerEntity.setCatalogVersionTime(currentCustomerEntity.getCatalogVersionTime());
		}
		if (resultCustomerEntity.getAuthFeatureType() == null && currentCustomerEntity.getAuthFeatureType() != null) {
			resultCustomerEntity.setAuthFeatureType(currentCustomerEntity.getAuthFeatureType());
		}
		if (resultCustomerEntity.getAuthServices() == null && currentCustomerEntity.getAuthServices() != null) {
			resultCustomerEntity.setAuthServices(currentCustomerEntity.getAuthServices());
		}
		
		return resultCustomerEntity;
	}

	@Override
	public CustomerEntity customerEntityInventoryTocustomerEntityTransformer(Map<String, String> resultantRow) {
		// TODO Auto-generated method stub

		CustomerEntity customerEntity = new CustomerEntity();

		customerEntity.setBwEnterpriseId(resultantRow.get("ENTERPRISE_ID"));

		// CUST_TYPE
		customerEntity.setMarketType(resultantRow.get("CUST_MARKET"));
		// PLATFORM_INDICATOR
		customerEntity.setVmPartitionId(resultantRow.get("VM_PARTITION_ID"));
		// PUBIP
		// ON_NET_INTERCO

		customerEntity.setSipDomain(resultantRow.get("SIP_DOMAIN"));
		// AS_ID
		customerEntity.setEnterpriseCclIndicatorStr(resultantRow.get("ENTCCL_IND"));
		customerEntity.setIeanLength(
				resultantRow.get("ENTCCL_IND") != null ? Integer.parseInt(resultantRow.get("ENTCCL_IND")) : null);

		if (resultantRow.get("QOS_IND") != null) {

			if (QosIndicator.NONE.toString().equalsIgnoreCase(resultantRow.get("QOS_IND")))
				customerEntity.setQosIndicator(QosIndicator.NONE);
			else if (QosIndicator.PREMIUM.toString().equalsIgnoreCase(resultantRow.get("QOS_IND")))
				customerEntity.setQosIndicator(QosIndicator.PREMIUM);
			else if (QosIndicator.STANDARD.toString().equalsIgnoreCase(resultantRow.get("QOS_IND")))
				customerEntity.setQosIndicator(QosIndicator.PREMIUM);

		}
		customerEntity.setVnetCorpId(
				resultantRow.get("VNET_CORP_ID") != null ? new BigInteger(resultantRow.get("VNET_CORP_ID")) : null);

		customerEntity.setContractInd(resultantRow.get("CONTRACT_IND"));
		customerEntity.setAgencyHierCode(resultantRow.get("AGENCY_HIER_CODE"));

		customerEntity.setXrefCustomerId(resultantRow.get("XREF_CUSTOMER_ID"));
		customerEntity.setCallingPlanId(
				resultantRow.get("CALLING_PLAN_ID") != null ? Integer.parseInt(resultantRow.get("ENTCCL_IND")) : null);
		// AUTH_SERVICES_ID
		customerEntity.setCustActiveInd(
				resultantRow.get("ACTIVE_IND") != null ? Long.parseLong(resultantRow.get("ACTIVE_IND")) : null);

		customerEntity.setBsBlockInd(
				resultantRow.get("BS_BLOCK_IND") != null ? Integer.parseInt(resultantRow.get("BS_BLOCK_IND")) : null);
		customerEntity.setEnvOrderId(
				resultantRow.get("ENV_ORDER_ID") != null ? Integer.parseInt(resultantRow.get("ENV_ORDER_ID")) : null);
		// SBC_ACTIVATION_SYSTEM

		if (resultantRow.get("SLA_TYPE") != null) {

			if (SlaType.CORPORATE.toString().equalsIgnoreCase(resultantRow.get("SLA_TYPE")))
				customerEntity.setSlaType(SlaType.CORPORATE);
			else if (SlaType.SITE.toString().equalsIgnoreCase(resultantRow.get("SLA_TYPE")))
				customerEntity.setSlaType(SlaType.SITE);

		}

		customerEntity.setRivCustomer(resultantRow.get("RIV_CUSTOMER"));

		// SBC_MIG_IND
		// IPAC_FLAG

		customerEntity.setLOR(resultantRow.get("LOR_FLAG"));
		// ENT_TRUNK_CCL_SUM

		customerEntity.setSbcLoadSharing(resultantRow.get("LOAD_SHARING"));
		customerEntity.setSoEnabled(resultantRow.get("SO_ENABLED"));
		customerEntity.setUsLDAndLocalBestPool(resultantRow.get("US_LD_AND_LOCAL_BEST_POOL"));

		customerEntity.setUsLDOnlyBestPool(resultantRow.get("US_LD_ONLY_BEST_POOL"));
		customerEntity.setEmeaApacBestPool(resultantRow.get("EMEA_APAC_BEST_POOL"));
		customerEntity.setLorId(resultantRow.get("LOR_ID"));
		customerEntity.setContactAddress1(resultantRow.get("ADDRESS"));
		customerEntity.setContactCity(resultantRow.get("CITY"));
		customerEntity.setContactState(resultantRow.get("STATE"));
		customerEntity.setContactZip(resultantRow.get("ZIP"));

		customerEntity.setContactCountry(resultantRow.get("COUNTRY"));

		// HYBRID_IND
		// CUST_PRICE_BOOK_ID
		customerEntity.setContractInd(resultantRow.get("CONTRACT_ID"));

		// QUOTE_ID
		// APPROVED_CCL
		customerEntity.setDesignId(
				resultantRow.get("DESIGN_ID") != null ? Long.parseLong(resultantRow.get("DESIGN_ID")) : null);

		customerEntity.setUsLDAndLocalBestPlusPool(resultantRow.get("US_LD_AND_LOCAL_BEST_PLUS_POOL"));
		customerEntity.setUsLDOnlyBestPlusPool(resultantRow.get("US_LD_ONLY_BEST_PLUS_POOL"));
		customerEntity.setEmeaApacBestPlusPool(resultantRow.get("EMEA_APAC_BEST_PLUS_POOL"));
		customerEntity.setCatalogVersionTime(resultantRow.get("CATALOGUE_REFERENCE_TIME"));
		customerEntity.setDefaultSubnet(resultantRow.get("DEF_SUBNET"));

		// ENT_CUM_CCL
		customerEntity.setUsagePlan(resultantRow.get("USAGE_PLAN"));
		// BMT
		// E164
		customerEntity.setBwEnterpriseId(resultantRow.get("BW_ENTERPRISE_ID"));
		
		// POLICY_SERVICE_ID
		customerEntity.setServiceParameter(resultantRow.get("SERVICEPACK_SERVICE_ID"));		
		customerEntity.setCustomerName(resultantRow.get("BW_ENTERPRISE_ID"));

		return customerEntity;
	}

}
