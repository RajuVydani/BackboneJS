/**
 * 
 */
package com.vz.esap.translation.config;

import javax.sql.DataSource;

import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.core.io.support.ResourcePatternUtils;

/**
 * 
 * @author Shalini Manchala
 *
 */

@Configuration
@MapperScan(basePackages = "com.vz.esap.translation.dao.repository")
public class MyBatisConfig {

	@Autowired
	@Qualifier("getdataserviceDS")
	private DataSource getdataserviceDS;

	@Autowired
	private ResourceLoader resourceLoader;

	@Bean
	public SqlSessionFactory sqlSessionFactory() throws Exception {

		final SqlSessionFactoryBean sqlSessionFactory = new SqlSessionFactoryBean();
		sqlSessionFactory.setDataSource(getdataserviceDS);
		sqlSessionFactory.setConfigLocation(new ClassPathResource("mybatis-config.xml"));
		sqlSessionFactory.setFailFast(true);

		Resource[] mapperResource = ResourcePatternUtils.getResourcePatternResolver(resourceLoader)
				.getResources("classpath:/mapper/*.xml");
		sqlSessionFactory.setMapperLocations(mapperResource);
		return sqlSessionFactory.getObject();
	}
}
