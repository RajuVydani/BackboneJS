package com.vz.esap.translation.order.model;

import java.math.BigInteger;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;

import com.vz.esap.translation.entity.Entity;
import com.vz.esap.translation.entity.OrderManagerContactInfoEntity;
import com.vz.esap.translation.entity.ParamInfo;
import com.vz.esap.translation.enums.EsapEnum.AuthFeatureType;
import com.vz.esap.translation.enums.EsapEnum.FlowPath;
import com.vz.esap.translation.enums.EsapEnum.SolutionType;

import EsapEnumPkg.VzbVoipEnums.OrderPlatformEnum;

public class OrderHeader extends Entity {

	public static enum SuppType {
		SUPP, CANCEL;
	}

	private int entityType;
	private Long envOrderId;
	private Long tblOrderId;
	private Long sequenceNumber;
	private String orderNumber; // Manadatory
	private String masterOrderNumber;
	private String orderVersion;
	private BigInteger transactionId; // Mandatory
	private String locationId; // Mandatory
	private String region;
	private String minorOrderType;
	private String centrexType;
	private String serviceType;
	private String origin; // Mandatory
	private int envOrderType; // Mandatory
	private String orderType; // Mandatory
	private int orderClassify; // Mandatory
	private String projectId;
	private String suppType;
	private Date dueDate;
	private String customerId;
	private String bsAppServer;
	private String asClli;
	private String tinVersion;
	private String orderProTIN;
	private ArrayList<String> orderXMLs;
	private String interfaceSystem;
	private ParamInfo paramInfo;
	private boolean goodHeader = true;
	private boolean reversal = false;
	private boolean expedite = false;
	private boolean transitionFlag = false;
	private boolean hasFmcg = false;
	private boolean hasBulkOrder = false;
	private boolean hasDeviceBulkOrder = false;
	private String origSourceAddress = null;
	private String cust_Number;
	private String cnamUpdate;
	private Integer priority;
	private boolean globalTransaction = false;
	private String orderCreatedBy;
	private Timestamp orderReceiveTimeStamp = null;
	private String ContractInd;
	private String iOrderTIN;
	private String gchId;
	private Boolean hotCutIndicator;
	private Boolean CDDDIndicator;
	private OrderPlatformEnum orderPlatform;
	private String e2eiSensitivtyLevel;
	private String vzId;
	private String originatingSystem;
	private OrderManagerContactInfoEntity ordMgrContactInfo;
	private int orderStatus;
	private String bulkOrder;
	private String functionCode;
	private FlowPath flowPath;
	private String entityAction;
	private String NASPId;
	private String enterpriseId;
	private String lastSegment;
	private String msgSegmentNo;
	private String voipLocationId;
	private String workOrderNumber;
	private String workOrderVersion;
	// xoo
	private SolutionType solutionType;
	private AuthFeatureType authFeatureType;
	private boolean isSupp;
	private String provisionCategory;
	private String orderingAction;

	public Long getEnvOrderId() {
		return envOrderId;
	}

	public void setEnvOrderId(Long envOrderId) {
		this.envOrderId = envOrderId;
	}

	public String getOrderNumber() {
		return orderNumber;
	}

	public void setOrderNumber(String orderNumber) {
		this.orderNumber = orderNumber;
	}

	public String getMasterOrderNumber() {
		return masterOrderNumber;
	}

	public void setMasterOrderNumber(String masterOrderNumber) {
		this.masterOrderNumber = masterOrderNumber;
	}

	public String getOrderVersion() {
		return orderVersion;
	}

	public void setOrderVersion(String orderVersion) {
		this.orderVersion = orderVersion;
	}

	public BigInteger getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(BigInteger transactionId) {
		this.transactionId = transactionId;
	}

	public String getLocationId() {
		return locationId;
	}

	public void setLocationId(String locationId) {
		this.locationId = locationId;
	}

	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	public String getMinorOrderType() {
		return minorOrderType;
	}

	public void setMinorOrderType(String minorOrderType) {
		this.minorOrderType = minorOrderType;
	}

	public String getCentrexType() {
		return centrexType;
	}

	public void setCentrexType(String centrexType) {
		this.centrexType = centrexType;
	}

	public String getServiceType() {
		return serviceType;
	}

	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}

	public String getOrigin() {
		return origin;
	}

	public void setOrigin(String origin) {
		this.origin = origin;
	}

	public String getOrderType() {
		return orderType;
	}

	public void setOrderType(String orderType) {
		this.orderType = orderType;
	}

	public int getOrderClassify() {
		return orderClassify;
	}

	public void setOrderClassify(int orderClassify) {
		this.orderClassify = orderClassify;
	}

	public String getSuppType() {
		return suppType;
	}

	public void setSuppType(String suppType) {
		this.suppType = suppType;
	}

	public Date getDueDate() {
		return dueDate;
	}

	public void setDueDate(Date dueDate) {
		this.dueDate = dueDate;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getBsAppServer() {
		return bsAppServer;
	}

	public void setBsAppServer(String bsAppServer) {
		this.bsAppServer = bsAppServer;
	}

	public String getTinVersion() {
		return tinVersion;
	}

	public void setTinVersion(String tinVersion) {
		this.tinVersion = tinVersion;
	}

	public String getOrderProTIN() {
		return orderProTIN;
	}

	public void setOrderProTIN(String orderProTIN) {
		this.orderProTIN = orderProTIN;
	}

	public ArrayList<String> getOrderXMLs() {
		return orderXMLs;
	}

	public void setOrderXMLs(ArrayList<String> orderXMLs) {
		this.orderXMLs = orderXMLs;
	}

	public String getInterfaceSystem() {
		return interfaceSystem;
	}

	public void setInterfaceSystem(String interfaceSystem) {
		this.interfaceSystem = interfaceSystem;
	}

	public ParamInfo getParamInfo() {
		return paramInfo;
	}

	public void setParamInfo(ParamInfo paramInfo) {
		this.paramInfo = paramInfo;
	}

	public boolean isGoodHeader() {
		return goodHeader;
	}

	public void setGoodHeader(boolean goodHeader) {
		this.goodHeader = goodHeader;
	}

	public boolean isReversal() {
		return reversal;
	}

	public void setReversal(boolean reversal) {
		this.reversal = reversal;
	}

	public boolean isExpedite() {
		return expedite;
	}

	public void setExpedite(boolean expedite) {
		this.expedite = expedite;
	}

	public boolean isTransitionFlag() {
		return transitionFlag;
	}

	public void setTransitionFlag(boolean transitionFlag) {
		this.transitionFlag = transitionFlag;
	}

	public boolean isHasFmcg() {
		return hasFmcg;
	}

	public void setHasFmcg(boolean hasFmcg) {
		this.hasFmcg = hasFmcg;
	}

	public boolean isHasBulkOrder() {
		return hasBulkOrder;
	}

	public void setHasBulkOrder(boolean hasBulkOrder) {
		this.hasBulkOrder = hasBulkOrder;
	}

	public boolean isHasDeviceBulkOrder() {
		return hasDeviceBulkOrder;
	}

	public void setHasDeviceBulkOrder(boolean hasDeviceBulkOrder) {
		this.hasDeviceBulkOrder = hasDeviceBulkOrder;
	}

	public String getOrigSourceAddress() {
		return origSourceAddress;
	}

	public void setOrigSourceAddress(String origSourceAddress) {
		this.origSourceAddress = origSourceAddress;
	}

	public String getCust_Number() {
		return cust_Number;
	}

	public void setCust_Number(String cust_Number) {
		this.cust_Number = cust_Number;
	}

	public String getCnamUpdate() {
		return cnamUpdate;
	}

	public void setCnamUpdate(String cnamUpdate) {
		this.cnamUpdate = cnamUpdate;
	}

	public Integer getPriority() {
		return priority;
	}

	public void setPriority(Integer priority) {
		this.priority = priority;
	}

	public boolean isGlobalTransaction() {
		return globalTransaction;
	}

	public void setGlobalTransaction(boolean globalTransaction) {
		this.globalTransaction = globalTransaction;
	}

	public String getOrderCreatedBy() {
		return orderCreatedBy;
	}

	public void setOrderCreatedBy(String orderCreatedBy) {
		this.orderCreatedBy = orderCreatedBy;
	}

	public Timestamp getOrderReceiveTimeStamp() {
		return orderReceiveTimeStamp;
	}

	public void setOrderReceiveTimeStamp(Timestamp orderReceiveTimeStamp) {
		this.orderReceiveTimeStamp = orderReceiveTimeStamp;
	}

	public String getContractInd() {
		return ContractInd;
	}

	public void setContractInd(String contractInd) {
		ContractInd = contractInd;
	}

	public String getiOrderTIN() {
		return iOrderTIN;
	}

	public void setiOrderTIN(String iOrderTIN) {
		this.iOrderTIN = iOrderTIN;
	}

	public String getGchId() {
		return gchId;
	}

	public void setGchId(String gchId) {
		this.gchId = gchId;
	}

	public Boolean getHotCutIndicator() {
		return hotCutIndicator;
	}

	public void setHotCutIndicator(Boolean hotCutIndicator) {
		this.hotCutIndicator = hotCutIndicator;
	}

	public Boolean getCDDDIndicator() {
		return CDDDIndicator;
	}

	public void setCDDDIndicator(Boolean cDDDIndicator) {
		CDDDIndicator = cDDDIndicator;
	}

	public OrderPlatformEnum getOrderPlatform() {
		return orderPlatform;
	}

	public void setOrderPlatform(OrderPlatformEnum orderPlatform) {
		this.orderPlatform = orderPlatform;
	}

	public String getE2eiSensitivtyLevel() {
		return e2eiSensitivtyLevel;
	}

	public void setE2eiSensitivtyLevel(String e2eiSensitivtyLevel) {
		this.e2eiSensitivtyLevel = e2eiSensitivtyLevel;
	}

	public String getVzId() {
		return vzId;
	}

	public void setVzId(String vzId) {
		this.vzId = vzId;
	}

	public OrderManagerContactInfoEntity getOrdMgrContactInfo() {
		return ordMgrContactInfo;
	}

	public void setOrdMgrContactInfo(OrderManagerContactInfoEntity ordMgrContactInfo) {
		this.ordMgrContactInfo = ordMgrContactInfo;
	}

	public Long getSequenceNumber() {
		return sequenceNumber;
	}

	public void setSequenceNumber(Long sequenceNumber) {
		this.sequenceNumber = sequenceNumber;
	}

	@Override
	public int getEntityType() {
		return entityType;
	}

	@Override
	public String getEntityName() {
		return orderNumber;
	}

	@Override
	public String getEntityId() {
		if (envOrderId == null)
			return null;
		else
			return envOrderId.toString();
	}

	public String getOriginatingSystem() {
		return originatingSystem;
	}

	public void setOriginatingSystem(String originatingSystem) {
		this.originatingSystem = originatingSystem;
	}

	public int getOrderStatus() {
		return orderStatus;
	}

	public void setOrderStatus(int orderStatus) {
		this.orderStatus = orderStatus;
	}

	public String getProjectId() {
		return projectId;
	}

	public void setProjectId(String projectId) {
		this.projectId = projectId;
	}

	public String getBulkOrder() {
		return bulkOrder;
	}

	public void setBulkOrder(String bulkOrder) {
		this.bulkOrder = bulkOrder;
	}

	public int getEnvOrderType() {
		return envOrderType;
	}

	public void setEnvOrderType(int envOrderType) {
		this.envOrderType = envOrderType;
	}

	public String getFunctionCode() {
		return functionCode;
	}

	public void setFunctionCode(String functionCode) {
		this.functionCode = functionCode;
	}

	public FlowPath getFlowPath() {
		return flowPath;
	}

	public void setFlowPath(FlowPath flowPath) {
		this.flowPath = flowPath;
	}

	public String getEntityAction() {
		return entityAction;
	}

	public void setEntityAction(String entityAction) {
		this.entityAction = entityAction;
	}

	public void setEntityType(int entityType) {
		this.entityType = entityType;
	}

	public Long getTblOrderId() {
		return tblOrderId;
	}

	public void setTblOrderId(Long tblOrderId) {
		this.tblOrderId = tblOrderId;
	}

	public String getNASPId() {
		return NASPId;
	}

	public void setNASPId(String nASPId) {
		NASPId = nASPId;
	}

	public String getEnterpriseId() {
		return enterpriseId;
	}

	public void setEnterpriseId(String enterpriseId) {
		this.enterpriseId = enterpriseId;
	}

	public String getLastSegment() {
		return lastSegment;
	}

	public void setLastSegment(String lastSegment) {
		this.lastSegment = lastSegment;
	}

	public String getMsgSegmentNo() {
		return msgSegmentNo;
	}

	public void setMsgSegmentNo(String msgSegmentNo) {
		this.msgSegmentNo = msgSegmentNo;
	}

	public String getVoipLocationId() {
		return voipLocationId;
	}

	public void setVoipLocationId(String voipLocationId) {
		this.voipLocationId = voipLocationId;
	}

	public String getWorkOrderNumber() {
		return workOrderNumber;
	}

	public void setWorkOrderNumber(String workOrderNumber) {
		this.workOrderNumber = workOrderNumber;
	}

	public String getWorkOrderVersion() {
		return workOrderVersion;
	}

	public void setWorkOrderVersion(String workOrderVersion) {
		this.workOrderVersion = workOrderVersion;
	}

	public SolutionType getSolutionType() {
		return solutionType;
	}

	public void setSolutionType(SolutionType solutionType) {
		this.solutionType = solutionType;
	}

	public AuthFeatureType getAuthFeatureType() {
		return authFeatureType;
	}

	public void setAuthFeatureType(AuthFeatureType authFeatureType) {
		this.authFeatureType = authFeatureType;
	}

	public boolean isSupp() {
		return isSupp;
	}

	public void setSupp(boolean isSupp) {
		this.isSupp = isSupp;
	}

	public String getProvisionCategory() {
		return provisionCategory;
	}

	public void setProvisionCategory(String provisionCategory) {
		this.provisionCategory = provisionCategory;
	}

	public String getOrderingAction() {
		return orderingAction;
	}

	public void setOrderingAction(String orderingAction) {
		this.orderingAction = orderingAction;
	}
	
	public String getAsClli() {
		return asClli;
	}

	public void setAsClli(String asClli) {
		this.asClli = asClli;
	}
}
