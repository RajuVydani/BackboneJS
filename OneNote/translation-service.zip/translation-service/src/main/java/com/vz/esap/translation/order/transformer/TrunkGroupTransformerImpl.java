package com.vz.esap.translation.order.transformer;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.vz.esap.translation.dao.model.TblOrderDetails;
import com.vz.esap.translation.entity.Entity.GroupType;
import com.vz.esap.translation.entity.ParamInfo;
import com.vz.esap.translation.entity.PilotUser;
import com.vz.esap.translation.entity.TrunkGroupEntity;
import com.vz.esap.translation.enums.EsapEnum.AuthFeatureType;
import com.vz.esap.translation.enums.EsapEnum.SolutionType;
import com.vz.esap.translation.exception.ApplicationInterfaceException;
import com.vz.esap.translation.exception.GenericException;
import com.vz.esap.translation.exception.TranslatorException;
import com.vz.esap.translation.exception.TranslatorException.ErrorCode;
import com.vz.esap.translation.order.dao.VOIPOrderDao;
import com.vz.esap.translation.order.model.request.VOIPOrderRequest;
import com.vz.esap.translation.order.service.helper.OrderServiceHelper;
import com.vz.esap.translation.util.OrderUtility;

import EsapEnumPkg.WorkOrderEnum.Log;

@Component
public class TrunkGroupTransformerImpl implements TrunkGroupTransformer {

	private static final Logger LOG = LoggerFactory.getLogger(TrunkGroupTransformerImpl.class);

	@Autowired
	private VOIPOrderDao voipOrderDao;

	@Autowired
	private ParamInfoTransformer paramInfoTransformer;

	@Autowired
	private OrderServiceHelper orderServiceHelper;

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.vz.esap.translation.order.transformer.TrunkGroupTransformer#
	 * transformOrderDetailsToTrunkGroup(long, long, java.lang.String, boolean)
	 */
	@Override
	public TrunkGroupEntity transformOrderDetailsToTrunkGroup(long orderId, long parentId, String action, boolean delta,
			List<String> paramActionExclusionList) throws TranslatorException {
		LOG.info("TrunkGroupTransformerImpl - transformOrderDetailsToLocation");

		return createTrunkGroupFromParamInfo(
				createTrunkGroupParamInfoFromOrderDetails(orderId, parentId, action, delta, null),
				paramActionExclusionList);

	}

	/**
	 * @param orderId
	 * @param parentId
	 * @param action
	 * @param delta
	 * @param paramName
	 * @return root
	 * @throws TranslatorException
	 */
	private ParamInfo createTrunkGroupParamInfoFromOrderDetails(long orderId, long parentId, String action,
			boolean delta, String paramName) throws TranslatorException {
		LOG.info(
				"In TrunkGroupTransformerImpl createTrunkGroupParamInfoFromOrderDetails ordId:{} parentId:{} action:{} delta:{}",
				orderId, parentId, action, delta);
		ParamInfo root = null;
		TblOrderDetails tblOrderDetails = null;

		try {

			tblOrderDetails = new TblOrderDetails();
			tblOrderDetails.setOrderId(orderId);
			tblOrderDetails.setAction(action);
			tblOrderDetails.setParentId(parentId);
			tblOrderDetails.setParamName(paramName);
			List<TblOrderDetails> ordDetails = voipOrderDao.getOrderDetailsWithActionAndParent(parentId, action, delta,
					paramName, tblOrderDetails);

			LOG.info("List Size:{}", ordDetails.size());
			
//			LOG.debug("TOD Parent Id = {} ....... TOD Values = {}", ordDetails != null ? ordDetails.get(0).getParentId() : "No records.", ordDetails);
			/*
			 * String param_val = null;// OrderUtil.getConfigParamValue(dbcon,
			 * "SUPP_CANCEL", "SUPP_CANCEL"); Niladri: // This is TODO boolean flag = true;
			 * if (param_val != null && param_val.equalsIgnoreCase("Y")) { flag = false; }
			 * if (flag) { if (ordDetails.size() <= 0) {
			 * LOG.info("Param details Not found for customer "); return null; } }
			 */
			root = new ParamInfo("TrunkGroupEntity", null, null);
			root = paramInfoTransformer.transformOrderDetailsToParamInfo(ordDetails, root, 0, null);

			// return createInstanceFromOrderDetails(ordDetails);
		} catch (Exception e) {
			LOG.error("Exception {} ", e);
			throw new TranslatorException(ErrorCode.TRANSFORMER_FAILURE,
					"Exception occured in createTrunkGroupFromParamInfo");
		}

		return root;
	}

	/**
	 * @param parent
	 * @return trunkGroupEntity
	 * @throws TranslatorException
	 */
	private TrunkGroupEntity createTrunkGroupFromParamInfo(ParamInfo parent, List<String> paramActionExclusionList)
			throws TranslatorException {

		LOG.info("TrunkGroupTransformerImpl - createTrunkGroupFromParamInfo");

		TrunkGroupEntity trunkGroupEntity = new TrunkGroupEntity();
		ArrayList<String> trunkGrpIds = new ArrayList<String>();
		try {
			for (ParamInfo param : parent.getChildParams()) {

				if (paramActionExclusionList != null && !paramActionExclusionList.isEmpty()) {
					
					boolean skip = false;
					for (String exclude : paramActionExclusionList) {
						exclude = paramInfoTransformer.translateTODActToPIAct(exclude);
											
						if (exclude.equalsIgnoreCase(param.getAction())) {
							LOG.info("Param Excluded = {} For Actual Action = {} , The Excluding Action = {}",
									param.getName(), param.getAction(), exclude);
							skip = true;
						}
					}
					if (skip)
						continue;
				}
				
				if (param.getName().equals("GroupId")) {
					trunkGroupEntity.setGroupId(new Long(param.getValue()));
					trunkGrpIds.add(param.getValue());
				} else if (param.getName().equals("GroupType"))
					trunkGroupEntity.setGroupType(GroupType.valueOf(param.getValue()));
				else if (param.getName().equals("LocationId"))
					trunkGroupEntity.setLocationId(param.getValue());
				else if (param.getName().equals("CustomerId"))
					trunkGroupEntity.setCustomerId(param.getValue());
				else if (param.getName().equals("DepartmentId"))
					trunkGroupEntity.setDepartmentId(param.getValue());
				else if (param.getName().equals("Name"))
					trunkGroupEntity.setName(param.getValue());
				else if (param.getName().equals("ClidFirstName"))
					trunkGroupEntity.setCLIDFirstName(param.getValue());
				else if (param.getName().equals("ClidLastName"))
					trunkGroupEntity.setCLIDLastName(param.getValue());
				else if (param.getName().equals("TnCLIDFirstName"))
					trunkGroupEntity.setTnCLIDFirstName(param.getValue());
				else if (param.getName().equals("TnCLIDLastName"))
					trunkGroupEntity.setTnCLIDLastName(param.getValue());
				else if (param.getName().equals("SimpleFeaturePackage"))
					trunkGroupEntity.setSimpleFeaturePackage(param.getValue());

				else if (param.getName().equals("NonPkgFeatures") && param.getValue() != null) {
					if (param.getChildParams() != null)
						param.getChildParams().forEach(par2 -> trunkGroupEntity.addToNonPkgFeatures(par2.getValue()));
				} else if (param.getName().equals("DisableFeatureList") && param.getValue() != null) {
					if (param.getChildParams() != null)
						param.getChildParams()
								.forEach(par2 -> trunkGroupEntity.addToDisableFeatureList(par2.getValue()));
				} else if (param.getName().equals("LinePort"))
					trunkGroupEntity.setLinePort(param.getValue());
				// else if (param.getName().equals("Device"))
				// trunkGroupEntity.setTrunkCommittedSessionCount(param.getValue());
				else if (param.getName().equals("ForwardToGroupId"))
					trunkGroupEntity.setForwardToGroupId(new Long(param.getValue()));
				else if (param.getName().equals("ForwardToGroupName"))
					trunkGroupEntity.setForwardToGroupName(param.getValue());
				else if (param.getName().equals("InvitationTimer"))
					trunkGroupEntity.setInvitationTimer(new Integer(param.getValue()));
				else if (param.getName().equals("MaxConcurrentCallLimit"))
					trunkGroupEntity.setMaxConcurrentCallLimit(new BigInteger(param.getValue()));
				else if (param.getName().equals("TerminationOption"))
					trunkGroupEntity.setTerminationOption(param.getValue());
				else if (param.getName().equals("ForwardToNumber"))
					trunkGroupEntity.setForwardToNumber(param.getValue());

				else if (param.getName().equals("VmNumber"))
					trunkGroupEntity.setVMNumber(param.getValue());
				else if (param.getName().equals("VmType"))
					trunkGroupEntity.setVMType(param.getValue());
				else if (param.getName().equals("VmPin"))
					trunkGroupEntity.setVmPin(param.getValue());
				else if (param.getName().equals("Extension"))
					trunkGroupEntity.setExtension(param.getValue());
				else if (param.getName().equals("PrivateNumber"))
					trunkGroupEntity.setPrivateNumber(param.getValue());
				else if (param.getName().equalsIgnoreCase("PilotTN")) {
					trunkGroupEntity.setPilotTN(param.getValue());
					trunkGroupEntity.setPilotTn(param.getValue());
					}					
				// else if (param.getName().equals("KeyTNs"))
				// trunkGroupEntity.setKeyTNs(param.getValue());
				else if (param.getName().equals("LinePortLength"))
					trunkGroupEntity.setLinePortLength(new Integer(param.getValue()));
				else if (param.getName().equals("Autoflag"))
					trunkGroupEntity.setAutoflag(OrderUtility.getBooleanFromYN(param.getValue()));
				// else if (param.getName().equals("IeanLength"))
				// trunkGroupEntity.set(new Integer(param.getValue()));

				else if (param.getName().equals("LastActiveTN"))
					trunkGroupEntity.setLastActiveTN(param.getValue());
				else if (param.getName().equals("FirstActiveTN"))
					trunkGroupEntity.setFirstActiveTN(param.getValue());
				else if (param.getName().equals("CreateExtension"))
					trunkGroupEntity.setCreateExtension(OrderUtility.getBooleanFromYN(param.getValue()));
				else if (param.getName().equals("PqInstanceId"))
					trunkGroupEntity.setPqInstanceId(new Long(param.getValue()));
				// XOO

				else if (param.getName().equals("EnterpriseId"))
					trunkGroupEntity.setEnterpriseId(param.getValue());
				else if (param.getName().equals("LocationId"))
					trunkGroupEntity.setLocationId(param.getValue());
				else if (param.getName().equals("MaxActiveCalls"))
					trunkGroupEntity.setMaxActiveCalls(param.getValue());
				else if (param.getName().equals("MaxIncomingCalls"))
					trunkGroupEntity.setMaxIncomingCalls(param.getValue());
				else if (param.getName().equals("EnableBursting"))
					trunkGroupEntity.setEnableBursting(param.getValue());
				else if (param.getName().equals("BurstingMaxActiveCalls"))
					trunkGroupEntity.setBurstingMaxActiveCalls(param.getValue());
				else if (param.getName().equals("BurstingMaxActiveCallsUnlimited"))
					trunkGroupEntity.setBurstingMaxActiveCallsUnlimited(param.getValue());
				else if (param.getName().equals("BurstingMaxIncomingCalls"))
					trunkGroupEntity.setBurstingMaxIncomingCalls(param.getValue());
				else if (param.getName().equals("BurstingMaxOutgoingCalls"))
					trunkGroupEntity.setBurstingMaxOutgoingCalls(param.getValue());
				else if (param.getName().equals("AllowedUnscreenedCalls"))
					trunkGroupEntity.setAllowedUnscreenedCalls(param.getValue());
				else if (param.getName().equals("RequireAuthentication"))
					trunkGroupEntity.setRequireAuthentication(param.getValue());
				else if (param.getName().equals("OtgDtgIdentity"))
					trunkGroupEntity.setOtgDtgIdentity(param.getValue());
				else if (param.getName().equals("SipAuthenticationUserName"))
					trunkGroupEntity.setSipAuthenticationUserName(param.getValue());
				else if (param.getName().equals("SipAuthenticationPassword"))
					trunkGroupEntity.setSipAuthenticationPassword(param.getValue());
				else if (param.getName().equals("ContinuousOptionsSendingIntervalSeconds"))
					trunkGroupEntity.setContinuousOptionsSendingIntervalSeconds(param.getValue());
				else if (param.getName().equals("FailureOptionsSendingIntervalSeconds"))
					trunkGroupEntity.setFailureOptionsSendingIntervalSeconds(param.getValue());
				else if (param.getName().equals("FailureThresholdCounter"))
					trunkGroupEntity.setFailureThresholdCounter(param.getValue());
				else if (param.getName().equals("SuccessThresholdCounter"))
					trunkGroupEntity.setSuccessThresholdCounter(param.getValue());
				else if (param.getName().equals("InviteFailureThresholdWindowSeconds"))
					trunkGroupEntity.setInviteFailureThresholdWindowSeconds(param.getValue());
				else if (param.getName().equals("UseSystemCallingLineIdentityPolicy"))
					trunkGroupEntity.setUseSystemCallingLineIdentityPolicy(param.getValue());
				else if (param.getName().equals("UseSystemCLIDForScreenedCallsPolicy"))
					trunkGroupEntity.setUseSystemCLIDForScreenedCallsPolicy(param.getValue());
				else if (param.getName().equals("UseSystemUserLookupPolicy"))
					trunkGroupEntity.setUseSystemUserLookupPolicy(param.getValue());
				else if (param.getName().equals("CallingLineIdPhoneNumber"))
					trunkGroupEntity.setCallingLineIdPhoneNumber(param.getValue());
				else if (param.getName().equals("TimeZone"))
					trunkGroupEntity.setTimeZone(param.getValue());
				else if (param.getName().equals("TrunkCallCapacity"))
					trunkGroupEntity.setTrunkCallCapacity(Long.valueOf(param.getValue()));
				else if (param.getName().equals("CommittedSessionCount"))
					trunkGroupEntity.setCommittedSessionCount(param.getValue());
				else if (param.getName().equals("InternationalLDRestriction"))
					trunkGroupEntity.setInternationalLDRestriction(param.getValue());
/*				else if (param.getName().equalsIgnoreCase("PilotTn"))
					trunkGroupEntity.setPilotTn(param.getValue());*/
				else if (param.getName().equals("SignalingDirection"))
					trunkGroupEntity.setSignalingDirection(param.getValue());
				else if (param.getName().equals("SolutionType"))
					trunkGroupEntity.setSolutionType(SolutionType.valueOf(param.getValue()));
				else if (param.getName().equals("BWTrunkGroupId"))
					trunkGroupEntity.setBwTrunkGroupId(param.getValue());
				else if (param.getName().equals("DeviceMapId"))
					trunkGroupEntity.setDeviceMapId(Long.valueOf(param.getValue()));
				else if (param.getName().equals("ProvisionCategory"))
					trunkGroupEntity.setProvisionCategory(param.getValue());
				else if (param.getName().equals("AsClli"))
					trunkGroupEntity.setAsClli(param.getValue());
				// Start:EBL Change
				else if (param.getName().equals("VirtualTrunkGroupId"))
					trunkGroupEntity.setVirtualTrunkId(param.getValue());
				// End:EBL Change
				else if (param.getName().equals("Region"))
					trunkGroupEntity.setRegion(param.getValue());
				if (param.getName().equals("AuthFeatureType"))
					trunkGroupEntity.setAuthFeatureType(AuthFeatureType.valueOf(param.getValue()));
				if (param.getName().equals("PilotUser")) {
					if (param.getChildParams() != null) {
						PilotUser pilotUser = new PilotUser();

						for (ParamInfo par2 : param.getChildParams()) {
							if (par2.getName().equals("UserId"))
								pilotUser.setUserId(par2.getValue());
							if (par2.getName().equals("FirstName"))
								pilotUser.setFirstName(par2.getValue());
							if (par2.getName().equals("LastName"))
								pilotUser.setLastName(par2.getValue());
							if (par2.getName().equals("CallingLineIdFirstName"))
								pilotUser.setCallingLineIdFirstName(par2.getValue());
							if (par2.getName().equals("CallingLineIdLastName"))
								pilotUser.setCallingLineIdLastName(par2.getValue());
							if (par2.getName().equals("PhoneNumber"))
								pilotUser.setPhoneNumber(Long.valueOf(par2.getValue()));
							if (par2.getName().equals("LinePort"))
								pilotUser.setLinePort(par2.getValue());
							if (par2.getName().equals("DeviceLevel"))
								pilotUser.setDeviceLevel(par2.getValue());
							if (par2.getName().equals("DeviceName"))
								pilotUser.setDeviceName(par2.getValue());
						}
						trunkGroupEntity.setPilotUser(pilotUser);
					}
				}

			}

		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new TranslatorException(ErrorCode.TRANSFORMER_FAILURE,
					"Exception occured in createTrunkGroupFromParamInfo");
		}
		LOG.debug("TrunkGroupTransformerImpl - createTrunkGroupFromParamInfo - trunkGroupEntity : {}", trunkGroupEntity);
		LOG.info("Exit - createTrunkGroupFromParamInfo");
		return trunkGroupEntity;
	}

	/**
	 * @author Abhiram Varma
	 * @param voipOrderRequest,trunkEntity
	 * @return TrunkGroupEntity
	 * @throws IllegalAccessException,
	 *             ApplicationInterfaceException, TranslatorException,
	 *             GenericException
	 */
	@Override
	public TrunkGroupEntity enrichTrunkEntityWithInventory(VOIPOrderRequest voipOrderRequest,
			TrunkGroupEntity trunkEntity)
			throws IllegalAccessException, ApplicationInterfaceException, TranslatorException, GenericException {
		LOG.info("Entered enrichtrunkGroupEntityWithInventory");

		TrunkGroupEntity trunkGroupEntityInv = orderServiceHelper.getEntityDetailsFromInventory(
				trunkEntity.getGroupId() != null ? trunkEntity.getGroupId().toString() : null, TrunkGroupEntity.class);

		// Copying Location Inv Details to Original Location Entity

		LOG.debug("++Level 10+++++Original trunkGrp Entity : {} ", trunkEntity);

		LOG.debug("++Level 10+++++Changed trunkGrp Entity : {} ", trunkEntity.getTrunkGroupEntity());

		LOG.debug("++Level 10+++++Original trunkGrp Entity trunkEntityInv : {} ", trunkGroupEntityInv);

		LOG.debug("++Level 10+++++Changed trunkGrp Entity trunkEntityInv.gettrunkEntity() : {} ",
				trunkGroupEntityInv.getTrunkGroupEntity());

		trunkEntity = copyFields(trunkGroupEntityInv, trunkEntity);
		
		LOG.info("TrunkCallCapacity Original trunkEntity = {}", trunkEntity.getTrunkCallCapacity());
		LOG.info("TrunkCallCapacity Inventory trunkGroupEntityInv = {}", trunkGroupEntityInv.getTrunkCallCapacity());

		LOG.debug("++Level 11+++++Original trunkGrp Entity : {} ", trunkEntity);

		LOG.debug("++Level 11+++++Changed trunkGrp Entity : {} ", trunkEntity.getTrunkGroupEntity());

		if (trunkEntity.getTrunkGroupEntity() != null) {
			TrunkGroupEntity trunkEntityChanged = trunkEntity.getTrunkGroupEntity();

			LOG.info("TrunkCallCapacity Changed trunkEntityChanged Before Copy = {}",
					trunkEntityChanged.getTrunkCallCapacity());
			
			// Copying trunkGrp Inv Details to Changed trunkGrp Entity
			copyFields(trunkEntity, trunkEntityChanged);
			
			LOG.info("TrunkCallCapacity Changed trunkEntityChanged After Copy = {}",
					trunkEntityChanged.getTrunkCallCapacity());

			LOG.debug("++Level 3+++++Original trunkGrp Entity : {} ", trunkEntity);

			LOG.debug("++Level 3+++++Changed trunkGrp Entity : {} ", trunkEntity.getTrunkGroupEntity());

		}

		LOG.info("Exit enrichTrunkEntityWithInventory");
		return trunkEntity;
	}

	private TrunkGroupEntity copyFields(TrunkGroupEntity currentTrunkGrpEntity, TrunkGroupEntity resultTrunkGrpEntity) {
		LOG.info("Entered copyFields(currentTrunkGrpEntity, resultTrunkGrpEntity)");
		// Inventory -> original
		if (resultTrunkGrpEntity.getGroupId() == null && currentTrunkGrpEntity.getGroupId() != null) {
			resultTrunkGrpEntity.setGroupId(currentTrunkGrpEntity.getGroupId());
		}
		if (resultTrunkGrpEntity.getGroupType() == null && currentTrunkGrpEntity.getGroupType() != null) {
			resultTrunkGrpEntity.setGroupType(currentTrunkGrpEntity.getGroupType());
		}
		if (resultTrunkGrpEntity.getLocationId() == null && currentTrunkGrpEntity.getLocationId() != null) {
			resultTrunkGrpEntity.setLocationId(currentTrunkGrpEntity.getLocationId());
		}
		if (resultTrunkGrpEntity.getCustomerId() == null && currentTrunkGrpEntity.getCustomerId() != null) {
			resultTrunkGrpEntity.setCustomerId(currentTrunkGrpEntity.getCustomerId());
		}
		if (resultTrunkGrpEntity.getDepartmentId() == null && currentTrunkGrpEntity.getDepartmentId() != null) {
			resultTrunkGrpEntity.setDepartmentId(currentTrunkGrpEntity.getDepartmentId());
		}
		if (resultTrunkGrpEntity.getName() == null && currentTrunkGrpEntity.getName() != null) {
			resultTrunkGrpEntity.setName(currentTrunkGrpEntity.getName());
		}
		if (resultTrunkGrpEntity.getCLIDFirstName() == null && currentTrunkGrpEntity.getCLIDFirstName() != null) {
			resultTrunkGrpEntity.setCLIDFirstName(currentTrunkGrpEntity.getCLIDFirstName());
		}
		if (resultTrunkGrpEntity.getCLIDLastName() == null && currentTrunkGrpEntity.getCLIDLastName() != null) {
			resultTrunkGrpEntity.setCLIDLastName(currentTrunkGrpEntity.getCLIDLastName());
		}
		if (resultTrunkGrpEntity.getTnCLIDFirstName() == null && currentTrunkGrpEntity.getTnCLIDFirstName() != null) {
			resultTrunkGrpEntity.setTnCLIDFirstName(currentTrunkGrpEntity.getTnCLIDFirstName());
		}
		if (resultTrunkGrpEntity.getTnCLIDLastName() == null && currentTrunkGrpEntity.getTnCLIDLastName() != null) {
			resultTrunkGrpEntity.setTnCLIDLastName(currentTrunkGrpEntity.getTnCLIDLastName());
		}
		if (resultTrunkGrpEntity.getSimpleFeaturePackage() == null
				&& currentTrunkGrpEntity.getSimpleFeaturePackage() != null) {
			resultTrunkGrpEntity.setSimpleFeaturePackage(currentTrunkGrpEntity.getSimpleFeaturePackage());
		}
		if (resultTrunkGrpEntity.getLinePort() == null && currentTrunkGrpEntity.getLinePort() != null) {
			resultTrunkGrpEntity.setLinePort(currentTrunkGrpEntity.getLinePort());
		}
		if (resultTrunkGrpEntity.getForwardToGroupId() == null && currentTrunkGrpEntity.getForwardToGroupId() != null) {
			resultTrunkGrpEntity.setForwardToGroupId(currentTrunkGrpEntity.getForwardToGroupId());
		}
		if (resultTrunkGrpEntity.getForwardToGroupName() == null
				&& currentTrunkGrpEntity.getForwardToGroupName() != null) {
			resultTrunkGrpEntity.setForwardToGroupName(currentTrunkGrpEntity.getForwardToGroupName());
		}
		if (resultTrunkGrpEntity.getInvitationTimer() == null && currentTrunkGrpEntity.getInvitationTimer() != null) {
			resultTrunkGrpEntity.setInvitationTimer(currentTrunkGrpEntity.getInvitationTimer());
		}
		if (resultTrunkGrpEntity.getMaxConcurrentCallLimit() == null
				&& currentTrunkGrpEntity.getMaxConcurrentCallLimit() != null) {
			resultTrunkGrpEntity.setMaxConcurrentCallLimit(currentTrunkGrpEntity.getMaxConcurrentCallLimit());
		}
		if (resultTrunkGrpEntity.getTerminationOption() == null
				&& currentTrunkGrpEntity.getTerminationOption() != null) {
			resultTrunkGrpEntity.setTerminationOption(currentTrunkGrpEntity.getTerminationOption());
		}
		if (resultTrunkGrpEntity.getForwardToNumber() == null && currentTrunkGrpEntity.getForwardToNumber() != null) {
			resultTrunkGrpEntity.setForwardToNumber(currentTrunkGrpEntity.getForwardToNumber());
		}
		if (resultTrunkGrpEntity.getVMNumber() == null && currentTrunkGrpEntity.getVMNumber() != null) {
			resultTrunkGrpEntity.setVMNumber(currentTrunkGrpEntity.getVMNumber());
		}
		if (resultTrunkGrpEntity.getVMType() == null && currentTrunkGrpEntity.getVMType() != null) {
			resultTrunkGrpEntity.setVMType(currentTrunkGrpEntity.getVMType());
		}
		if (resultTrunkGrpEntity.getVmPin() == null && currentTrunkGrpEntity.getVmPin() != null) {
			resultTrunkGrpEntity.setVmPin(currentTrunkGrpEntity.getVmPin());
		}
		if (resultTrunkGrpEntity.getExtension() == null && currentTrunkGrpEntity.getExtension() != null) {
			resultTrunkGrpEntity.setExtension(currentTrunkGrpEntity.getExtension());
		}
		if (resultTrunkGrpEntity.getPrivateNumber() == null && currentTrunkGrpEntity.getPrivateNumber() != null) {
			resultTrunkGrpEntity.setPrivateNumber(currentTrunkGrpEntity.getPrivateNumber());
		}
		if (resultTrunkGrpEntity.getPilotTN() == null && currentTrunkGrpEntity.getPilotTN() != null) {
			resultTrunkGrpEntity.setPilotTN(currentTrunkGrpEntity.getPilotTN());
		}
		if (resultTrunkGrpEntity.getKeyTNs() == null && currentTrunkGrpEntity.getKeyTNs() != null) {
			resultTrunkGrpEntity.setKeyTNs(currentTrunkGrpEntity.getKeyTNs());
		}
		if (resultTrunkGrpEntity.getLinePortLength() == null && currentTrunkGrpEntity.getLinePortLength() != null) {
			resultTrunkGrpEntity.setLinePortLength(currentTrunkGrpEntity.getLinePortLength());
		}
		if (resultTrunkGrpEntity.getAutoflag() == null && currentTrunkGrpEntity.getAutoflag() != null) {
			resultTrunkGrpEntity.setAutoflag(currentTrunkGrpEntity.getAutoflag());
		}
		if (resultTrunkGrpEntity.getCreateExtension() == null && currentTrunkGrpEntity.getCreateExtension() != null) {
			resultTrunkGrpEntity.setCreateExtension(currentTrunkGrpEntity.getCreateExtension());
		}
		if (resultTrunkGrpEntity.getEnterpriseId() == null && currentTrunkGrpEntity.getEnterpriseId() != null) {
			resultTrunkGrpEntity.setEnterpriseId(currentTrunkGrpEntity.getEnterpriseId());
		}
		if (resultTrunkGrpEntity.getOtgDtgIdentity() == null && currentTrunkGrpEntity.getOtgDtgIdentity() != null) {
			resultTrunkGrpEntity.setOtgDtgIdentity(currentTrunkGrpEntity.getOtgDtgIdentity());
		}
		if (resultTrunkGrpEntity.getCommittedSessionCount() == null && currentTrunkGrpEntity.getCommittedSessionCount() != null) {
			resultTrunkGrpEntity.setCommittedSessionCount(currentTrunkGrpEntity.getCommittedSessionCount());
		}
		if (resultTrunkGrpEntity.getInternationalLDRestriction() == null && currentTrunkGrpEntity.getInternationalLDRestriction() != null) {
			resultTrunkGrpEntity.setInternationalLDRestriction(currentTrunkGrpEntity.getInternationalLDRestriction());
		}
		if (resultTrunkGrpEntity.getDeviceMapId() == null && currentTrunkGrpEntity.getDeviceMapId() != null) {
			resultTrunkGrpEntity.setDeviceMapId(currentTrunkGrpEntity.getDeviceMapId());
		}
		if (resultTrunkGrpEntity.getSignalingDirection() == null && currentTrunkGrpEntity.getSignalingDirection() != null) {
			resultTrunkGrpEntity.setSignalingDirection(currentTrunkGrpEntity.getSignalingDirection());
		}
		if (resultTrunkGrpEntity.getBwTrunkGroupId() == null && currentTrunkGrpEntity.getBwTrunkGroupId() != null) {
			resultTrunkGrpEntity.setBwTrunkGroupId(currentTrunkGrpEntity.getBwTrunkGroupId());
		}
		if (resultTrunkGrpEntity.getMaxActiveCalls() == null && currentTrunkGrpEntity.getMaxActiveCalls() != null) {
			resultTrunkGrpEntity.setMaxActiveCalls(currentTrunkGrpEntity.getMaxActiveCalls());
		}
		if (resultTrunkGrpEntity.getCallingLineIdPhoneNumber() == null && currentTrunkGrpEntity.getCallingLineIdPhoneNumber() != null) {
			resultTrunkGrpEntity.setCallingLineIdPhoneNumber(currentTrunkGrpEntity.getCallingLineIdPhoneNumber());
		}
		if (resultTrunkGrpEntity.getPilotTn() == null && currentTrunkGrpEntity.getPilotTn() != null) {
			resultTrunkGrpEntity.setPilotTn(currentTrunkGrpEntity.getPilotTn());
		}
		if (resultTrunkGrpEntity.getTrunkCallCapacity() == 0 && currentTrunkGrpEntity.getTrunkCallCapacity() != 0) {
			resultTrunkGrpEntity.setTrunkCallCapacity(currentTrunkGrpEntity.getTrunkCallCapacity());
		}
		
		//DeviceSeqId missing.
		LOG.info("Exit copyFields(currentTrunkGrpEntity, resultTrunkGrpEntity)");

		return resultTrunkGrpEntity;
	}

	/**
	 * @author Abhiram Varma
	 * 
	 */
	@Override
	public TrunkGroupEntity trunkGroupInventoryTotrunkGroupEntityTransformer(Map<String, String> resultantRow) {
		
		LOG.info("Entered trunkGroupInventoryTotrunkGroupEntityTransformer");

		LOG.info("Entered trunkGroupInventoryTotrunkGroupEntityTransformer");

		TrunkGroupEntity trunkGroupEntity = new TrunkGroupEntity();

		trunkGroupEntity
				.setGroupId(resultantRow.get("GROUP_ID") != null ? Long.valueOf(resultantRow.get("GROUP_ID")) : null);

		trunkGroupEntity.setLocationId(resultantRow.get("LOCATION_ID"));
		trunkGroupEntity.setDepartmentId(resultantRow.get("DEPARTMENT_ID"));
		trunkGroupEntity.setName(resultantRow.get("GROUP_NAME"));
		
		if (resultantRow.get("GROUP_TYPE") != null) {
			int groupType = Integer.parseInt(resultantRow.get("GROUP_TYPE"));
			if (GroupType.INBOUND.equals(GroupType.valueOf(groupType)))
				trunkGroupEntity.setGroupType(GroupType.INBOUND);
			else if (GroupType.KEY.equals(GroupType.valueOf(groupType)))
				trunkGroupEntity.setGroupType(GroupType.KEY);
			else if (GroupType.LINE.equals(GroupType.valueOf(groupType)))
				trunkGroupEntity.setGroupType(GroupType.LINE);
			else if (GroupType.NON_PRI_DID.equals(GroupType.valueOf(groupType)))
				trunkGroupEntity.setGroupType(GroupType.NON_PRI_DID);
			else if (GroupType.PBX.equals(GroupType.valueOf(groupType)))
				trunkGroupEntity.setGroupType(GroupType.PBX);
			else if (GroupType.TWO_WAY.equals(GroupType.valueOf(groupType)))
				trunkGroupEntity.setGroupType(GroupType.TWO_WAY);
			else if (GroupType.PRI_DID.equals(GroupType.valueOf(groupType)))
				trunkGroupEntity.setGroupType(GroupType.PRI_DID);
		}
		trunkGroupEntity.setSimpleFeaturePackage(resultantRow.get("PACKAGE_ID"));
		trunkGroupEntity.setDeviceMapId(
				resultantRow.get("DEVICE_MAP_ID") != null ? Long.valueOf(resultantRow.get("DEVICE_MAP_ID")) : null);
		trunkGroupEntity.setClidFirstName(resultantRow.get("CID_FIRST_NAME"));

		trunkGroupEntity.setClidLastName(resultantRow.get("CID_LAST_NAME"));

		trunkGroupEntity.setExtension(resultantRow.get("EXTENSION"));
		trunkGroupEntity.setPrivateNumber(resultantRow.get("PRIVATE_NUMBER"));
		trunkGroupEntity.setLinePort(resultantRow.get("LINE_PORT"));
		
		trunkGroupEntity.setEnvOrderId(
				resultantRow.get("ENV_ORDER_ID") != null ? Long.valueOf(resultantRow.get("ENV_ORDER_ID")) : null);
		trunkGroupEntity.setLinePortLength(
				resultantRow.get("LINE_PORT_LENGTH") != null ? Integer.valueOf(resultantRow.get("LINE_PORT_LENGTH"))
						: null);
		trunkGroupEntity.setInvitationTimer(
				resultantRow.get("INVITATION_TIMER") != null ? Integer.valueOf(resultantRow.get("INVITATION_TIMER"))
						: null);
		trunkGroupEntity.setPqInstanceId(
				resultantRow.get("PQ_INSTANCE_ID") != null ? Long.valueOf(resultantRow.get("PQ_INSTANCE_ID")) : null);
		// TG_ID not found
		trunkGroupEntity.setOtgDtgIdentity(resultantRow.get("OTG_ID"));
		
		trunkGroupEntity.setMaxActiveCalls(resultantRow.get("GROUPUSERLIMIT"));
		
		if(resultantRow.get("TRUNK_CALL_CAPACITY") != null) {
			trunkGroupEntity.setTrunkCallCapacity(Long.valueOf(resultantRow.get("TRUNK_CALL_CAPACITY")));
		}
		
		trunkGroupEntity.setPilotTN(resultantRow.get("PILOT_TN"));
		trunkGroupEntity.setCallingLineIdPhoneNumber(resultantRow.get("PILOT_TN"));
		
		LOG.info("Exit trunkGroupInventoryTotrunkGroupEntityTransformer");

		return trunkGroupEntity;
	}

}
