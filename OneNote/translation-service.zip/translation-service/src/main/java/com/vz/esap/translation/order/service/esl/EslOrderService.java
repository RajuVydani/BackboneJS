package com.vz.esap.translation.order.service.esl;

import java.util.Map;

import com.vz.esap.translation.exception.GenericException;
import com.vz.esap.translation.exception.TranslatorException;
import com.vz.esap.translation.order.model.request.VOIPOrderRequest;
import com.vz.esap.translation.order.model.response.VoipOrderResponse;

public interface EslOrderService {

	/**
	 * @param voipOrderRequest
	 * @param productDetails
	 * @return voipOrderResponse
	 * @throws GenericException
	 * @throws TranslatorException
	 */
	VoipOrderResponse createEslEsipValidateOrder(VOIPOrderRequest voipOrderRequest, Map<String, String> productDetails)
			throws GenericException, TranslatorException;

	/**
	 * @param voipOrderRequest
	 * @param productDetails
	 * @return voipOrderResponse
	 * @throws TranslatorException
	 * @throws GenericException 
	 */
	VoipOrderResponse createEslEsipReleaseOrder(VOIPOrderRequest voipOrderRequest, Map<String, String> productDetails)
			throws TranslatorException, GenericException;

	/**
	 * @param voipOrderRequest
	 * @return voipOrderResponse
	 * @throws TranslatorException
	 * @throws GenericException
	 */
	VoipOrderResponse configNbsDetails(VOIPOrderRequest voipOrderRequest) throws TranslatorException, GenericException;

	/**
	 * @param voipOrderRequest
	 * @return VoipOrderResponse
	 * @throws TranslatorException
	 * @throws GenericException
	 */
	VoipOrderResponse configCircuitInfo(VOIPOrderRequest voipOrderRequest) throws TranslatorException, GenericException;
	
	/**
	 * Disconn
	 * 
	 * @param voipOrderRequest
	 * @param productDetails TODO
	 * @return VoipOrderResponse
	 * @throws TranslatorException
	 * @throws GenericException
	 */
	VoipOrderResponse createEslEsipLocSuspOrder(VOIPOrderRequest voipOrderRequest, Map<String, String> productDetails)
			throws TranslatorException, GenericException;

	/**
	 * Disconn
	 * 
	 * @param voipOrderRequest
	 * @param productDetails TODO
	 * @return VoipOrderResponse
	 * @throws TranslatorException
	 * @throws GenericException
	 */
	VoipOrderResponse createEslEsipLocDeactOrder(VOIPOrderRequest voipOrderRequest, Map<String, String> productDetails)
			throws TranslatorException, GenericException;

	/**
	 * @param voipOrderRequest
	 * @return
	 * @throws TranslatorException
	 * @throws GenericException
	 */
	VoipOrderResponse getEsipLocationStatus(VOIPOrderRequest voipOrderRequest) throws TranslatorException, GenericException;

	/**
	 * @param voipOrderRequest
	 * @param productDetails
	 * @return
	 * @throws GenericException
	 */
	VoipOrderResponse createEslPreIntegrationTestOrder(VOIPOrderRequest voipOrderRequest, Map<String, String> productDetails)
			throws GenericException;

	/**
	 * @param voipOrderRequest
	 * @param productDetails
	 * @return
	 * @throws GenericException
	 */
	VoipOrderResponse createEslCompletionOrder(VOIPOrderRequest voipOrderRequest, Map<String, String> productDetails)
			throws GenericException;
}
