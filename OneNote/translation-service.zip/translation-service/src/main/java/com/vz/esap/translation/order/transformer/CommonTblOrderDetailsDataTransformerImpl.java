package com.vz.esap.translation.order.transformer;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.util.GregorianCalendar;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.vz.esap.translation.dao.model.TblOrder;
import com.vz.esap.translation.enums.EsapEnum;
import com.vz.esap.translation.enums.EsapEnum.AuthFeatureType;
import com.vz.esap.translation.enums.EsapEnum.SolutionType;
import com.vz.esap.translation.exception.GenericException;
import com.vz.esap.translation.order.model.request.ParamInfo;
import com.vz.esap.translation.order.model.request.VOIPOrderRequest;
import com.vz.esap.translation.order.service.helper.OrderServiceHelper;
import com.vz.esap.translation.util.OrderUtility;

@Component
public class CommonTblOrderDetailsDataTransformerImpl implements CommonTblOrderDetailsDataTransformer {
	
	@Autowired
	private OrderServiceHelper orderServiceHelperImpl;
	
	private static final Logger LOG = LoggerFactory.getLogger(CommonTblOrderDetailsDataTransformerImpl.class);

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.vz.esap.translation.order.transformer.
	 * CommonTblOrderDetailsDataTransformer#
	 * prepareTblOrderDetailsHeaderParamDataForCustomer(com.vz.esap.translation.
	 * order.model.request.VOIPOrderRequest,
	 * com.vz.esap.translation.dao.model.TblOrder)
	 */
	@Override
	public ParamInfo prepareTblOrderDetailsHeaderParamDataForCustomer(VOIPOrderRequest voipOrderRequest,
			TblOrder tblOrderObject) throws ParseException, GenericException {

		LOG.info("Entered - prepareTblOrderDetailsHeaderParamDataForCustomer");
		ParamInfo root = null;
		String action = null;
		int version = -1;
		
		try {
			
			if("C".equalsIgnoreCase(voipOrderRequest.getOrderHeader().getOrderType()))
				action = null;
			else
				action = voipOrderRequest.getOrderHeader().getOrderType();
			
			root = new ParamInfo("Header", null, action);

			root.addNotNullValChild("OrderNumber", voipOrderRequest.getOrderHeader().getWorkOrderNumber(), action);
			root.addNotNullValChild("EnvOrderId", tblOrderObject.getEnvOrderId(), action);
			root.addNotNullValChild("MasterOrderNumber", voipOrderRequest.getOrderHeader().getMasterOrderNumber(),
					action);
			root.addNotNullValChild("OrderVersion", voipOrderRequest.getOrderHeader().getWorkOrderVersion(), action);
			root.addNotNullValChild("TransactionId", voipOrderRequest.getOrderHeader().getTransactionID(), action);
			if(voipOrderRequest.getOrderHeader().getRegion() != null)
				root.addNotNullValChild("Region", voipOrderRequest.getOrderHeader().getRegion(), action);
			else if(voipOrderRequest.getLocation() != null && voipOrderRequest.getLocation().getLocationAddress() != null
					&& voipOrderRequest.getLocation().getLocationAddress().getCountryCode() != null)
				root.addNotNullValChild("Region", voipOrderRequest.getLocation().getLocationAddress().getCountryCode(), action);
			root.addNotNullValChild("MinorOrderType", voipOrderRequest.getOrderHeader().getMinorOrderType(), action);
			root.addNotNullValChild("CentrexType", voipOrderRequest.getOrderHeader().getCentrexType(), action);
			root.addNotNullValChild("ServiceType", voipOrderRequest.getOrderHeader().getServiceType(), action);
			root.addNotNullValChild("OriginatingSystem", voipOrderRequest.getOrderHeader().getOriginatingSystem(),
					action);
			root.addNotNullValChild("InterfaceSystem", voipOrderRequest.getOrderHeader().getInterfaceSystem(), action);
			root.addNotNullValChild("OrderType",
					EsapEnum.OrderType.getValue(voipOrderRequest.getOrderHeader().getOrderType().charAt(0)), action);
			root.addNotNullValChild("SuppType", voipOrderRequest.getOrderHeader().getSuppType(), action);
			// root.addNotNullValChild("OrderClassify", WorkOrderEnum.OrderClassify
			// .acronym(voipOrderRequest.getOrderHeader().getOrderClassify()),
			// action);
			root.addNotNullValChild("OrderClassify", voipOrderRequest.getOrderHeader().getFunctionCode(), action);
			// root.addNotNullValChild("DueDate", voipOrderRequest.getOrderHeader()
			// .getDueDate(), action);

			if (voipOrderRequest.getOrderHeader().getDueDate() != null) {
				SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
				Calendar calendar = GregorianCalendar.getInstance();
				calendar.setTime(format.parse(voipOrderRequest.getOrderHeader().getDueDate()));
				Object dueDate = calendar.getTime();
				root.addNotNullValChild("DueDate", dueDate, action);
			} else {
				// : if Due Date is missing in request then have due date logic here
			}
			root.addNotNullValChild("CustomerId", voipOrderRequest.getOrderHeader().getEnterpriseId(), action);
			if(voipOrderRequest.getOrderHeader().getLocationId() != null)
				root.addNotNullValChild("LocationId", voipOrderRequest.getOrderHeader().getLocationId(), action);
			else if(voipOrderRequest.getOrderHeader().getVoipLocationId() != null)
				root.addNotNullValChild("LocationId", voipOrderRequest.getOrderHeader().getVoipLocationId(), action);
				
			//root.addNotNullValChild("BsAppServer", inventoryUtil.getBSAppServer(voipOrderRequest), action);
			
			root.addNotNullValChild("BsAppServer", voipOrderRequest.getOrderHeader().getBsAppServer(), action);
			root.addNotNullValChild("AsClli", voipOrderRequest.getOrderHeader().getAsClli(), action);  //add broadsoft clli.

			root.addNotNullValChild("OrderProTIN", voipOrderRequest.getOrderHeader().getOrderProTIN(), action);
			root.addNotNullValChild("IOrderTIN", voipOrderRequest.getOrderHeader().getiOrderTIN(), action);
			root.addNotNullValChild("TINVersion", voipOrderRequest.getOrderHeader().getTinVersion(), action);
			root.addNotNullValChild("TransitionFlag", voipOrderRequest.getOrderHeader().getTransitionFlag() ? "Y" : "N",
					action);
			root.addNotNullValChild("Priority", voipOrderRequest.getOrderHeader().getPriority(), action);
			if (voipOrderRequest.getOrderHeader().getAttribMap() != null) {
				root.addChildParam(
						OrderUtility.getAttribParamInfo(voipOrderRequest.getOrderHeader().getAttribMap(), action));
			}
			root.addNotNullValChild("OrderCreatedBy", voipOrderRequest.getOrderHeader().getOrderCreatedBy(), action);
			if (voipOrderRequest.getOrderHeader().isHasBulkOrder()) {
				root.addNotNullValChild("BULK", "Y", action);
			}
			if (voipOrderRequest.getOrderHeader().isHotCutIndicator()) {
				root.addNotNullValChild("HotCutIndicator", "Y", action);
			}
			if (voipOrderRequest.getOrderHeader().isCDDDIndicator()) {
				root.addNotNullValChild("CDDDIndicator", "Y", action);
			}
			if (voipOrderRequest.getOrderHeader().getGCHId() != null) {
				root.addNotNullValChild("GCHId", voipOrderRequest.getOrderHeader().getGCHId(), action);
				LOG.info("GCHId :  {}", voipOrderRequest.getOrderHeader().getGCHId());
			}
			if (voipOrderRequest.getOrderHeader().getSolutionType() != null) {
				root.addNotNullValChild("SolutionType", voipOrderRequest.getOrderHeader().getSolutionType().toString(),
						action);				
				if(Arrays.asList(SolutionType.ESIP_ESL, SolutionType.ESIP_EBL)
						.contains(voipOrderRequest.getOrderHeader().getSolutionType())) {
					root.addNotNullValChild("AuthFeatureType", AuthFeatureType.FET_ESIP.toString(),	action);	
				}
				// TODO Niladri Ipflex Disconnect Review :: To avoid NPE for AuthFeatureType
				else if (SolutionType.IPFLEX.equals(voipOrderRequest.getOrderHeader().getSolutionType())
						&& !voipOrderRequest.getOrderHeader().getOrderType().equalsIgnoreCase("D")) {
					root.addNotNullValChild("AuthFeatureType", orderServiceHelperImpl.getAuthFeatureType(voipOrderRequest).toString(), action);
				} else if(SolutionType.HPBX.equals(voipOrderRequest.getOrderHeader().getSolutionType())) {
					root.addNotNullValChild("AuthFeatureType", AuthFeatureType.FET_HPBX.toString(),
							action);
				}				
			}
			
			version = Integer.parseInt(voipOrderRequest.getOrderHeader().getWorkOrderVersion());
			
			if(version > 0) {
				root.addNotNullValChild("SUPP", "Y", action);
			}
			
		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new GenericException(GenericException.GENERIC_EXCEPTION,
					"Exception occured in prepareTblOrderDetailsHeaderParamDataForCustomer");
		}

		LOG.info("Exit prepareTblOrderDetailsHeaderParamDataForCustomer");

		return root;
	}

}
