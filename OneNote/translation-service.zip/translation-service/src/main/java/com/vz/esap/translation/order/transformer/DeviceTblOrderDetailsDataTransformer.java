package com.vz.esap.translation.order.transformer;

import java.text.ParseException;
import java.util.ArrayList;

import com.vz.esap.translation.dao.model.TblOrder;
import com.vz.esap.translation.entity.DeviceEntity;
import com.vz.esap.translation.exception.TranslatorException;
import com.vz.esap.translation.order.model.Order;
import com.vz.esap.translation.order.model.request.ParamInfo;
import com.vz.esap.translation.order.model.request.VOIPOrderRequest;

/**
 * @author kalagsu
 *
 */
public interface DeviceTblOrderDetailsDataTransformer {

	/**
	 * @param order
	 * @return paramInfoList
	 * @throws TranslatorException
	 */
	public ParamInfo prepareTblOrderDetailsEntityParamDataForDevice(Order order, String action) throws TranslatorException;

	/**
	 * @param voipOrderRequest
	 * @param tblOrderObject
	 * @param device
	 * @return deviceParams
	 * @throws TranslatorException
	 */
	public ArrayList<ParamInfo> prepareTblOrderDetailsEntityParamDataForDevice(
			VOIPOrderRequest voipOrderRequest, TblOrder tblOrderObject,
			ArrayList<DeviceEntity> device) throws TranslatorException;

	/**
	 * @param order
	 * @return headerParams
	 * @throws ParseException
	 * @throws TranslatorException
	 */
	public ParamInfo prepareTblOrderDetailsHeaderParamData(Order order) throws ParseException, TranslatorException;
	
	
	/**
	 * @param oldDevice
	 * @param newDevice
	 * @param supp
	 * @param action
	 * @return paramInfo
	 * @throws ParseException
	 * @throws TranslatorException
	 */
	ParamInfo prepareTblOrderDetailsEntityParamDataForDevice(DeviceEntity oldDevice, DeviceEntity newDevice,
			boolean supp, String action) throws ParseException, TranslatorException;

	/**
	 * @param order
	 * @param deviceEntityPrev
	 * @param supp
	 * @return paramInfo
	 * @throws ParseException
	 * @throws TranslatorException
	 */
	ParamInfo prepareTblOrderDetailsHeaderParamData(Order order, DeviceEntity deviceEntityPrev, boolean supp)
			throws ParseException, TranslatorException;
	/**
	 * @param deviceList
	 * @param change
	 * @param object
	 * @return paramInfo
	 * @throws ParseException
	 * @throws TranslatorException
	 */
	ArrayList<ParamInfo> prepareTblOrderDetailsEntityParamDataForDevice(ArrayList<DeviceEntity> deviceList, boolean change,
			Object object) throws TranslatorException;
	
}
