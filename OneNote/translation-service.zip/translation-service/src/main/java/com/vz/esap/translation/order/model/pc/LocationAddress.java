package com.vz.esap.translation.order.model.pc;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;

import com.fasterxml.jackson.annotation.JsonProperty;

@XmlAccessorType(XmlAccessType.FIELD)
public class LocationAddress {
	
	@XmlElement(name = "CountryName")
	@JsonProperty(value = "CountryName")
	private String countryName;

	@XmlElement(name = "State")
	@JsonProperty(value = "State")
	private String state;

	@XmlElement(name = "AddressLine")
	@JsonProperty(value = "AddressLine")
	private String addressLine;

	@XmlElement(name = "Zip")
	@JsonProperty(value = "Zip")
	private String zip;

	@XmlElement(name = "CountryCode")
	@JsonProperty(value = "CountryCode")
	private String countryCode;

	@XmlElement(name = "City")
	@JsonProperty(value = "City")
	private String city;

	public String getCountryName() {
		return countryName;
	}

	public void setCountryName(String countryName) {
		this.countryName = countryName;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getAddressLine() {
		return addressLine;
	}

	public void setAddressLine(String addressLine) {
		this.addressLine = addressLine;
	}

	public String getZip() {
		return zip;
	}

	public void setZip(String zip) {
		this.zip = zip;
	}

	public String getCountryCode() {
		return countryCode;
	}

	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	@Override
	public String toString() {
		return "ClassPojo [CountryName = " + countryName + ", State = " + state
				+ ", AddressLine = " + addressLine + ", Zip = " + zip
				+ ", CountryCode = " + countryCode + ", City = " + city + "]";
	}
}
