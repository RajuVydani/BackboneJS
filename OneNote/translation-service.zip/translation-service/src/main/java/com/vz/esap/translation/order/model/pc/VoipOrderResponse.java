package com.vz.esap.translation.order.model.pc;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonRootName;

@JsonRootName(value = "")
// @JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
@JsonInclude(Include.NON_NULL)
public class VoipOrderResponse implements java.io.Serializable {

	private static final long serialVersionUID = 1L;

	@JsonProperty(value = "OrderHeader")
	private OrderHeader orderHeader;

	@JsonProperty(value = "OrderStatus")
	private OrderStatus orderStatus;

	@JsonProperty(value = "RouterSbcInfo")
	private RouterSbcInfo routerSbcInfo;

	@JsonProperty(value = "DNSInfo")
	private DNSInfo dnsInfo;

	@JsonProperty(value = "IPCCIDADNSInfo")
	private IPCCIDADNSInfo ipccIDADNSInfo;

	@JsonProperty(value = "SBCActivation")
	private String sbcActivation;

	@JsonProperty(value = "SBCRollback")
	private String sbcRollback;

	@JsonProperty(value = "SBCRollbackReason")
	private String sbcRollbackReason;

	@JsonProperty(value = "SBCRollbackComment")
	private String sbcRollbackComment;

	@JsonProperty(value = "ManualSBCSelection")
	private String manualSBCSelection;

	@JsonProperty(value = "VpnName")
	private String vpnName;

	@JsonProperty(value = "DNSFlag")
	private String dnsFlag;

	@JsonProperty(value = "BSNode")
	private String bsNode;

	@JsonProperty(value = "HomingTabPull")
	private String homingTabPull;

	@JsonProperty(value = "CircuitID")
	private String circuitID;

	@JsonProperty(value = "ProvisioningCancel")
	private String provisioningCancel;

	@JsonProperty(value = "HoldForCDDD")
	private String holdForCDDD;

	@JsonProperty(value = "HoldForHOTCUT")
	private String holdForHOTCUT;

	@JsonProperty(value = "TN")
	private String tn;

	@JsonProperty(value = "SBCDeactivation")
	private String sbcDeactivation;

	@JsonProperty(value = "TransitionType")
	private String transitionType;

	public OrderHeader getOrderHeader() {
		return orderHeader;
	}

	public void setOrderHeader(OrderHeader orderHeader) {
		this.orderHeader = orderHeader;
	}

	public OrderStatus getOrderStatus() {
		return orderStatus;
	}

	public void setOrderStatus(OrderStatus orderStatus) {
		this.orderStatus = orderStatus;
	}

	public RouterSbcInfo getRouterSbcInfo() {
		return routerSbcInfo;
	}

	public void setRouterSbcInfo(RouterSbcInfo routerSbcInfo) {
		this.routerSbcInfo = routerSbcInfo;
	}

	public String getSbcActivation() {
		return sbcActivation;
	}

	public void setSbcActivation(String sbcActivation) {
		this.sbcActivation = sbcActivation;
	}

	public String getSbcRollback() {
		return sbcRollback;
	}

	public void setSbcRollback(String sbcRollback) {
		this.sbcRollback = sbcRollback;
	}

	public String getSbcRollbackReason() {
		return sbcRollbackReason;
	}

	public void setSbcRollbackReason(String sbcRollbackReason) {
		this.sbcRollbackReason = sbcRollbackReason;
	}

	public String getSbcRollbackComment() {
		return sbcRollbackComment;
	}

	public void setSbcRollbackComment(String sbcRollbackComment) {
		this.sbcRollbackComment = sbcRollbackComment;
	}

	public String getManualSBCSelection() {
		return manualSBCSelection;
	}

	public void setManualSBCSelection(String manualSBCSelection) {
		this.manualSBCSelection = manualSBCSelection;
	}

	public String getVpnName() {
		return vpnName;
	}

	public void setVpnName(String vpnName) {
		this.vpnName = vpnName;
	}

	public String getDnsFlag() {
		return dnsFlag;
	}

	public void setDnsFlag(String dnsFlag) {
		this.dnsFlag = dnsFlag;
	}

	public String getBsNode() {
		return bsNode;
	}

	public void setBsNode(String bsNode) {
		this.bsNode = bsNode;
	}

	public String getHomingTabPull() {
		return homingTabPull;
	}

	public void setHomingTabPull(String homingTabPull) {
		this.homingTabPull = homingTabPull;
	}

	public String getCircuitID() {
		return circuitID;
	}

	public void setCircuitID(String circuitID) {
		this.circuitID = circuitID;
	}

	public String getProvisioningCancel() {
		return provisioningCancel;
	}

	public void setProvisioningCancel(String provisioningCancel) {
		this.provisioningCancel = provisioningCancel;
	}

	public String getHoldForCDDD() {
		return holdForCDDD;
	}

	public void setHoldForCDDD(String holdForCDDD) {
		this.holdForCDDD = holdForCDDD;
	}

	public String getHoldForHOTCUT() {
		return holdForHOTCUT;
	}

	public void setHoldForHOTCUT(String holdForHOTCUT) {
		this.holdForHOTCUT = holdForHOTCUT;
	}

	public String getTn() {
		return tn;
	}

	public void setTn(String tn) {
		this.tn = tn;
	}

	public String getSbcDeactivation() {
		return sbcDeactivation;
	}

	public void setSbcDeactivation(String sbcDeactivation) {
		this.sbcDeactivation = sbcDeactivation;
	}

	public String getTransitionType() {
		return transitionType;
	}

	public void setTransitionType(String transitionType) {
		this.transitionType = transitionType;
	}

	public DNSInfo getDnsInfo() {
		return dnsInfo;
	}

	public void setDnsInfo(DNSInfo dnsInfo) {
		this.dnsInfo = dnsInfo;
	}

	public IPCCIDADNSInfo getIpccIDADNSInfo() {
		return ipccIDADNSInfo;
	}

	public void setIpccIDADNSInfo(IPCCIDADNSInfo ipccIDADNSInfo) {
		this.ipccIDADNSInfo = ipccIDADNSInfo;
	}

	public Map<String, String> getEntityMap(OrderStatus orderstatus) {
		Map<String, String> entityMap = new HashMap<>();

		List<Entity> entities = orderstatus.getEntities();

		for (Entity entity : entities) {
			entityMap.put(entity.getType(), entity.getValue());
		}
		return entityMap;
	}

}
