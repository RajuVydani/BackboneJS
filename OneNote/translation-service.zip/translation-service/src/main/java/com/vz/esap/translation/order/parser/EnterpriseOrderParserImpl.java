package com.vz.esap.translation.order.parser;

import static java.util.Arrays.stream;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.vz.esap.translation.dao.repository.CustomCustomerMapper;
import com.vz.esap.translation.entity.AuthService;
import com.vz.esap.translation.entity.CustomerEntity;
import com.vz.esap.translation.enums.EsapEnum;
import com.vz.esap.translation.enums.EsapEnum.AuthFeatureType;
import com.vz.esap.translation.enums.EsapEnum.ChangeType;
import com.vz.esap.translation.enums.EsapEnum.SolutionType;
import com.vz.esap.translation.exception.GenericException;
import com.vz.esap.translation.exception.TranslatorException;
import com.vz.esap.translation.order.model.request.ChangeManagement;
import com.vz.esap.translation.order.model.request.ChangedElement;
import com.vz.esap.translation.order.model.request.Communication;
import com.vz.esap.translation.order.model.request.ConvergedService;
import com.vz.esap.translation.order.model.request.Feature;
import com.vz.esap.translation.order.model.request.GCMInfo;
import com.vz.esap.translation.order.model.request.LocationAddress;
import com.vz.esap.translation.order.model.request.PricingInfo;
import com.vz.esap.translation.order.model.request.PrimaryLocationContact;
import com.vz.esap.translation.order.model.request.SalesManagerContact;
import com.vz.esap.translation.order.model.request.Specification;
import com.vz.esap.translation.order.model.request.TsoMigrationEntReferenceData;
import com.vz.esap.translation.order.model.request.VOIPOrderRequest;
import com.vz.esap.translation.order.service.helper.OrderServiceHelper;

import EsapEnumPkg.VzbVoipEnum;
import EsapEnumPkg.VzbVoipEnums;
import EsapEnumPkg.VzbVoipEnums.OrderPlatformEnum;
import EsapEnumPkg.WorkOrderEnum;
import net.logstash.logback.encoder.org.apache.commons.lang.ArrayUtils;

@Component
public class EnterpriseOrderParserImpl implements EnterpriseOrderParser {
	
	private static final Logger LOG = LoggerFactory.getLogger(EnterpriseOrderParserImpl.class);

	@Autowired
	private CustomCustomerMapper customCustomerMapper;
	
	@Autowired
	private OrderServiceHelper orderServiceHelperImpl;

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.vz.esap.translation.order.parser.EnterpriseOrderParser#
	 * parseEnterpriseOrder(com.vz.esap.translation.order.model.request.
	 * VOIPOrderRequest)
	 */
	@Override
	public CustomerEntity parseEnterpriseOrder(VOIPOrderRequest voipOrderRequest)
			throws TranslatorException, ParseException, GenericException {

		LOG.info("Entered - parseEnterpriseOrder");
		CustomerEntity customer = null;
		SimpleDateFormat timestampformat;
		String cvt;
		ConvergedService convergedService = null;
		List<Feature> entFeatures = null;
		String catalogVersionTime;
		SimpleDateFormat formatter = null;
		SalesManagerContact salesManagerContact = null;
		Communication[] salesManagerContactCommunications = null;
		PrimaryLocationContact primaryLocationContact = null;
		Communication[] primaryLocationContactCommunications = null;
		Feature[] features = null;
		Specification[] specifications = null;
		String soEnabled = null;
		Boolean routeExhaustBool = null;
		LocationAddress locationAddress = null;
		long usLDAndLocalBestPool = 0;
		long usUsLDOnlyBestPool = 0;
		long emeaApacPool = 0;
		GCMInfo gcmInfo = null;
		TsoMigrationEntReferenceData tsoMigrationRefData = null;
		try {
			customer = new CustomerEntity();

			if (voipOrderRequest.getOrderHeader().getCentrexType() != null) {
				customer.setCentrexType(VzbVoipEnum.CentrexType.ENHANCED_IP_CENTREX);
			} else {
				customer.setCentrexType(VzbVoipEnum.CentrexType.ENHANCED_IP_CENTREX);
			}

			if ("US".equalsIgnoreCase(voipOrderRequest.getLocation().getLocationAddress().getCountryCode()))
				customer.setRegionType(VzbVoipEnum.RegionType.US);
			else if ("EMEA".equalsIgnoreCase(voipOrderRequest.getOrderHeader().getRegion()))
				customer.setRegionType(VzbVoipEnum.RegionType.EMEA);
			else if ("APAC".equalsIgnoreCase(voipOrderRequest.getOrderHeader().getRegion()))
				customer.setRegionType(VzbVoipEnum.RegionType.APAC);

			// defaults
			customer.setBsAppServer(voipOrderRequest.getOrderHeader().getBsAppServer());
			customer.setRivCustomer("Y");
			customer.setOrderPlatform(OrderPlatformEnum.E2EI);
			customer.setBillingSystem(VzbVoipEnum.BillingSystemType.PB);
			customer.setProductType(VzbVoipEnum.ProductType.VOIP);// 1 - VOIP
			customer.setEnterpriseCclIndicator(Boolean.TRUE);
			customer.setGchId(voipOrderRequest.getOrderHeader().getGCHId());
			customer.setNaspId(voipOrderRequest.getOrderHeader().getNASPId());
			customer.setEnterpriseTrunkingType(VzbVoipEnums.EnterpriseTrunkingTypeEnum.STANDARD);
			// xoo
			if (voipOrderRequest.getOrderHeader().getSolutionType() != null)
				customer.setSolutionType(voipOrderRequest.getOrderHeader().getSolutionType());

			if (SolutionType.ESIP_ESL.equals(voipOrderRequest.getOrderHeader().getSolutionType())) {
				customer.setAuthFeatureType(AuthFeatureType.FET_ESIP);
			} else if (SolutionType.IPFLEX.equals(voipOrderRequest.getOrderHeader().getSolutionType())) {
				customer.setAuthFeatureType(orderServiceHelperImpl.getAuthFeatureType(voipOrderRequest));
			} else if (SolutionType.HPBX.equals(voipOrderRequest.getOrderHeader().getSolutionType())) {
				customer.setAuthFeatureType(AuthFeatureType.FET_HPBX);
			}

			locationAddress = voipOrderRequest.getLocation().getLocationAddress();
			if (locationAddress != null) {
				if (locationAddress.getAddressLine() != null) {
					customer.setContactAddress1(locationAddress.getAddressLine());
				}
				if (locationAddress.getCountryCode() != null) {
					customer.setContactCountry(locationAddress.getCountryCode());
				}
				if (locationAddress.getCity() != null) {
					customer.setContactCity(locationAddress.getCity());
				}
				if (locationAddress.getState() != null) {
					customer.setContactState(locationAddress.getState());
				}
				if (locationAddress.getZip() != null) {
					customer.setContactZip(locationAddress.getZip());
				}
			}

			convergedService = voipOrderRequest.getConvergedService();

			entFeatures = stream(convergedService.getFeature())
					.filter(feat -> "EFET_VOIP_ENT_LVL".equalsIgnoreCase(feat.getCode())).collect(Collectors.toList());

			if (entFeatures != null && !entFeatures.isEmpty())
				customer.setCustomerId(entFeatures.get(0).getInstanceId());
			else
				customer.setCustomerId(voipOrderRequest.getOrderHeader().getEnterpriseId());

			if (convergedService != null && convergedService.getCatalogVersionTime() != null) {
				catalogVersionTime = convergedService.getCatalogVersionTime();
				formatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
				Date cvtDate = null;
				cvtDate = formatter.parse(catalogVersionTime);
				timestampformat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				cvt = timestampformat.format(cvtDate);
				customer.setCatalogVersionTime(cvt);
			}

			salesManagerContact = voipOrderRequest.getLocation().getSalesManagerContact();
			if (salesManagerContact != null) {
				if (salesManagerContact.getContactFirstName() != null) {
					customer.setAccountTeamFirstName(salesManagerContact.getContactFirstName());
				}
				if (salesManagerContact.getContactLastName() != null) {
					customer.setAccountTeamLastName(salesManagerContact.getContactLastName());
				}
				salesManagerContactCommunications = salesManagerContact.getCommunication();
				for (Communication salesManagerContactCommunication : salesManagerContactCommunications) {
					if (salesManagerContactCommunication != null) {
						if (salesManagerContactCommunication.getCountryDialing() != null) {
							customer.setAccountTeamCountryDialling(
									salesManagerContactCommunication.getCountryDialing());
						}
						if (salesManagerContactCommunication.getAreaDialing() != null) {
							customer.setAccountTeamAreaDialling(salesManagerContactCommunication.getAreaDialing());
						}
						if (salesManagerContactCommunication.getDialNumber() != null) {
							customer.setAccountTeamDialNumber(salesManagerContactCommunication.getDialNumber());
						}
						if (salesManagerContactCommunication.getURI() != null) {
							customer.setAccountTeamEmail(salesManagerContactCommunication.getURI());
						}
					}
				}
			}

			primaryLocationContact = voipOrderRequest.getLocation().getPrimaryLocationContact();

			if (primaryLocationContact != null) {
				if (primaryLocationContact.getContactFirstName() != null) {
					customer.setContactFirstName(primaryLocationContact.getContactFirstName());
				}
				if (primaryLocationContact.getContactLastName() != null) {
					customer.setContactLastName(primaryLocationContact.getContactLastName());
				}

				primaryLocationContactCommunications = primaryLocationContact.getCommunication();
				for (Communication communication : primaryLocationContactCommunications) {
					if (communication.getCountryDialing() != null) {
						customer.setCountryDialing(communication.getCountryDialing());
					}
					if (communication.getAreaDialing() != null) {
						customer.setAreaDialing(communication.getAreaDialing());
					}
					if (communication.getAreaDialing() != null) {
						customer.setDialNumber(communication.getDialNumber());
					}
					if (communication.getURI() != null) {
						customer.setContactEmail(communication.getURI());
					}
				}
			}
			List<AuthService> authServicesList = new ArrayList<>();	
			features = convergedService.getFeature();
			for (Feature feature : features) {
				if (feature.getActionCode() != null && "ADD".equalsIgnoreCase(feature.getActionCode())) {
					customer.setAction(EsapEnum.OrderAction.ADD);
				}
				if ("EFET_VOIP_ENT_LVL".equalsIgnoreCase(feature.getCode())) {
					customer.setE2EIFeature(feature.getCode());
				}
				// xoo
				if ("FET_AUT".equalsIgnoreCase(feature.getCode()))
					customer.addAuthService("Auto Attendant", true);
				
				if ("FET_CAL".equalsIgnoreCase(feature.getCode()))
					customer.addAuthService("Call Center", true);
				
				if ("FET_XO_AUT".equalsIgnoreCase(feature.getCode()))
					customer.addAuthService("Call Forwarding Not Reachable", true);

				if ("FET_XO_TFD".equalsIgnoreCase(feature.getCode()))
					customer.addAuthService("Worktime Feature", true);
				
				//Feature Quantity changes
				if ("FET_XO_WOR".equalsIgnoreCase(feature.getCode()) || "FET_IPA".equalsIgnoreCase(feature.getCode())) {
					
					String packageType = null;
					String featureQuantity = null;
					AuthService authService = new AuthService();
		
					for (Specification specification : feature.getSpecification()) {
						if ("SP_XO_PAC".equalsIgnoreCase(specification.getCode())) {
							packageType = specification.getValue();
						}
						if ("SP_QUA_XO".equalsIgnoreCase(specification.getCode())) {
							featureQuantity = specification.getValue();
						}
					}
						if(packageType != null) {
							authService.setName(feature.getName() + "-" + packageType);
							authService.setFeatureQuantity(featureQuantity);
							authService.setAuthorise(true);
						} else {
							authService.setName(feature.getName());
							authService.setFeatureQuantity(featureQuantity);
							authService.setAuthorise(true);
						}
					authServicesList.add(authService);	
				}
				
				// xoo
				specifications = feature.getSpecification();

				//Fix for PQ Order for feature without Spec
				if(specifications != null) {
					
					for (Specification specification : specifications) {
						if ("ESP_ENT_MIG_NEW_ENT_ID".equalsIgnoreCase(specification.getCode())) {
							customer.setNewEntId(specification.getValue());
						}
						if ("ESP_ENT_US_REF_ID".equalsIgnoreCase(specification.getCode())) {
							customer.setParentEnterpriseId(specification.getValue());
						}

						if ("SP_VOIP_SERVICE_OPT".equalsIgnoreCase(specification.getCode())
								&& specification.getValue() != null) {
							soEnabled = specification.getValue();
						}
						if (soEnabled != null) {

							if ("NO".equalsIgnoreCase(soEnabled)) {
								customer.setSoEnabled("0");
								customer.setEnterpriseCclIndicator(Boolean.FALSE);
							} else {
								customer.setSoEnabled("1");

								if ("ESP_ENT_TRNK_RTE_OFLW_AUTH".equalsIgnoreCase(specification.getCode())
										&& specification.getValue() != null
										&& customer.getOrderPlatform() == OrderPlatformEnum.E2EI) {
									String routeExhaust = specification.getValue();
									routeExhaustBool = "Yes".equals(routeExhaust) ? Boolean.TRUE : Boolean.FALSE;
								}
								if (null != routeExhaustBool)
									customer.addAuthService("Route Exhaust", routeExhaustBool.booleanValue());

								if ("SP_VOIP_ENT_LOCAL_LD_BEST_POOL".equalsIgnoreCase(specification.getCode())) {
									customer.setUsLDAndLocalBestPool(specification.getValue());
									customer.setAction(customer.getAction());
									usLDAndLocalBestPool = Long.parseLong(specification.getValue());

								}
								if ("SP_VOIP_ENT_LD_ONLY_BEST_POOL".equalsIgnoreCase(specification.getCode())) {
									customer.setUsLDOnlyBestPool(specification.getValue());
									customer.setAction(customer.getAction());
									usUsLDOnlyBestPool = Long.parseLong(specification.getValue());

								}

								if (customer.getRegionType() != 0
										&& (customer.getRegionType() == VzbVoipEnum.RegionType.EMEA
												|| customer.getRegionType() == VzbVoipEnum.RegionType.APAC)) {
									if ("SP_VOIP_ENT_NON_US_BEST_POOL".equalsIgnoreCase(specification.getCode())) {
										customer.setEmeaApacBestPool(specification.getValue());
										customer.setAction(customer.getAction());
										emeaApacPool = Long.parseLong(specification.getValue());
									}
								}

								if ("1".equals(customer.getSoEnabled())
										&& (usUsLDOnlyBestPool > 0 || usLDAndLocalBestPool > 0 || emeaApacPool > 0)) {
									customer.setEnterpriseCclIndicator(Boolean.TRUE);
								} else
									customer.setEnterpriseCclIndicator(Boolean.FALSE);
							}
						} else {
							customer.setSoEnabled("0");
							customer.setEnterpriseCclIndicator(Boolean.FALSE);
						}

						if ("1".equals(customer.getSoEnabled())) {
							tsoMigrationRefData = new TsoMigrationEntReferenceData();

							if ("ESP_ENT_REF_ID".equalsIgnoreCase(specification.getCode())
									&& specification.getValue() != null) {
								String refid = specification.getValue();
								tsoMigrationRefData.setEnterpriseReferenceId(Long.parseLong(refid));
							}

							if (null != voipOrderRequest.getOrderHeader().getEnterpriseId()
									&& null != tsoMigrationRefData) {
								tsoMigrationRefData.setNewEnterpriseId(voipOrderRequest.getOrderHeader().getEnterpriseId());
							}

							if (tsoMigrationRefData != null) {
								customer.setTsoMigrationEntReferenceData(tsoMigrationRefData);
							}
						}

						if(null != voipOrderRequest.getCustomer() && null != voipOrderRequest.getCustomer().getName()) {
							customer.setCustomerName(voipOrderRequest.getCustomer().getName());
							} else if ("ESP_ENTERPRISE_NAME".equalsIgnoreCase(specification.getCode())) {
							customer.setCustomerName(specification.getValue()); 
						}
								
						if ("ESP_NON_TRUSTED_IP_C".equalsIgnoreCase(specification.getCode())) {
							String nonTrusted = specification.getValue();
							if ("Y".equalsIgnoreCase(nonTrusted) || "Yes".equalsIgnoreCase(nonTrusted)) {
								customer.setNonTrustedIPCalls("Y");
							} else if ("N".equalsIgnoreCase(nonTrusted) || "No".equalsIgnoreCase(nonTrusted)) {
								customer.setNonTrustedIPCalls("N");
							}
						}
						if ("ESP_ALLOW_ON_NET".equalsIgnoreCase(specification.getCode())) {
							String allowOnNet = specification.getValue();
							if ("Y".equalsIgnoreCase(allowOnNet) || "Yes".equalsIgnoreCase(allowOnNet)) {
								customer.setAllowOnNet("Y");
							} else if ("N".equalsIgnoreCase(allowOnNet) || "No".equalsIgnoreCase(allowOnNet)) {
								customer.setAllowOnNet("N");
							}
						}
						if ("ESP_SIP_DOMAIN".equalsIgnoreCase(specification.getCode())) {
							customer.setSipDomain(specification.getValue());
						}
						if ("ESP_ADM_FST_NAME".equalsIgnoreCase(specification.getCode())) {
							customer.setAdminFirstName(specification.getValue());
						}
						if ("ESP_ADM_LST_NAME".equalsIgnoreCase(specification.getCode())) {
							customer.setAdminLastName(specification.getValue());
						}
						if ("ESP_ADM_LOGIN_ID".equalsIgnoreCase(specification.getCode())) {
							customer.setAdminWebLoginId(specification.getValue());
						}
						if ("ESP_ADM_PW".equalsIgnoreCase(specification.getCode())) {
							customer.setAdminPassword(specification.getValue());
						}
						if ("SP_VOIP_NUM_HOST_ENT_PRIZ_DIG".equalsIgnoreCase(specification.getCode())) {
							customer.setIeanLength(Integer.parseInt(specification.getValue()));
						}
						if ("ESP_CALL_REDIRECT_TO_TN_AUTH".equalsIgnoreCase(specification.getCode())) {
							customer.setAuthCFNR(specification.getValue());
						}
						if ("ESP_CALL_FW_AUTH".equalsIgnoreCase(specification.getCode())) {
							customer.setAuthPbxUnReachableFeature(specification.getValue());
						}
						if ("ESP_NCAR_ID".equalsIgnoreCase(specification.getCode())) {
							customer.setLOR("Y");
							customer.setLorId(specification.getValue());
						}
						if ("ESP_VMAIL_AUTH".equalsIgnoreCase(specification.getCode())) {
							String vmAuthorized = specification.getValue();
							if (vmAuthorized != null && vmAuthorized.trim().length() > 0
									&& ("Y".equals(vmAuthorized) || "Yes".equalsIgnoreCase(vmAuthorized))) {
								customer.addAuthService("Voice Mail Storage Options - 20 Messages", true);
								customer.addAuthService("Voice Mail Storage Options - 50 Messages", true);
							} else if (vmAuthorized != null && vmAuthorized.trim().length() > 0
									&& ("N".equals(vmAuthorized) || "No".equalsIgnoreCase(vmAuthorized))) {
								customer.addAuthService("Voice Mail Storage Options - 20 Messages", false);
								customer.addAuthService("Voice Mail Storage Options - 50 Messages", false);
							}
						}
						if ("ESP_INS_AUTH".equalsIgnoreCase(specification.getCode())) {
							String autoAttndntAuthorized = specification.getValue();
							customer.addAuthService("Auto Attendant", "Yes".equals(autoAttndntAuthorized) ? true : false);
						}
						if ("ESP_FET_PAK_AUTH".equalsIgnoreCase(specification.getCode())) {
							String intermediatFetAuthorized = specification.getValue();
							customer.addAuthService("Intermediate Feature Package",
									"Yes".equals(intermediatFetAuthorized) ? true : false);
						}
						if ("ESP_NCA_ID".equalsIgnoreCase(specification.getCode())) {
							customer.setNcaId(specification.getValue());
						}
						if ("SP_VOIP_ENT_TRUNK_PREM".equalsIgnoreCase(specification.getCode())) {
							String etPremium = specification.getValue();
							if (null != etPremium && etPremium.trim().length() > 0
									&& ("Y".equalsIgnoreCase(etPremium) || "YES".equalsIgnoreCase(etPremium)))
								customer.setEnterpriseTrunkingType(VzbVoipEnums.EnterpriseTrunkingTypeEnum.PREMIUM);
						}
						if ("ESP_ENT_TRNK_RTE_FLOW_AUTH".equalsIgnoreCase(specification.getCode())) {
							customer.setEtRouteOverflowAuthorization(specification.getValue());
						}
						if ("SP_VOIP_ENT_SERVICE_PLAN".equalsIgnoreCase(specification.getCode())) {
							customer.setEntServicePlan(specification.getValue());
						}
						if ("SP_VOIP_ENT_USAGE_PLAN".equalsIgnoreCase(specification.getCode())) {
							customer.setUsagePlan(specification.getValue());
						}
						if ("SP_VOIP_ENT_NUM_FREE_MIN".equalsIgnoreCase(specification.getCode())) {
							customer.setNumberOfFreeMinutes(specification.getValue());
						}
						if ("SP_VOIP_ENT_CUM_CCL".equalsIgnoreCase(specification.getCode())) {
							customer.setCummulativeCcl(Long.parseLong(specification.getValue()));
						}
						if ("ESP_ENT_COUNTRY".equalsIgnoreCase(specification.getCode())) {
							customer.setVirtualAddrCountry(specification.getValue());
						}
						if ("ESP_ENT_STATE".equalsIgnoreCase(specification.getCode())) {
							customer.setVirtualAddrState(specification.getValue());
						}
						if ("ESP_ENT_TRNK_RTE_OFLW_AUTH".equalsIgnoreCase(specification.getCode())) {
							customer.setRouteExhaust(specification.getValue());
						}
						if ("ESP_DESIGN_ID".equalsIgnoreCase(specification.getCode())) {
							customer.setDesignId(Long.parseLong(specification.getValue()));
						}
					}
					
				}
				

				/*
				 * if (customer.getContractInd() != null &&
				 * "C".equalsIgnoreCase(customer.getContractInd())) {
				 * customer.setAdminFirstName(null); customer.setAdminLastName(null);
				 * customer.setAdminEmail(null); customer.setAdminWebLoginId(null);
				 * customer.setAdminPassword(null); }
				 */
				// LOG.info("Assign 0 {} :",customer.getVirtualAddrCountry());
				if (customer.getVirtualAddrCountry() != null) {
					if ("US".equalsIgnoreCase(customer.getVirtualAddrCountry())) {
						voipOrderRequest.getOrderHeader().setRegion("US");
						customer.setRegionType(
								VzbVoipEnum.RegionType.valueByAcronym(voipOrderRequest.getOrderHeader().getRegion()));
						// LOG.info("Assign 1 {}
						// :",VzbVoipEnum.RegionType.valueByAcronym(voipOrderRequest.getOrderHeader().getRegion()));

					} else {
						customer.setRegionType(
								VzbVoipEnum.RegionType.valueByAcronym(voipOrderRequest.getOrderHeader().getRegion()));
						/*
						 * LOG.info("Assign 2 {} :",voipOrderRequest.getOrderHeader().getRegion());
						 * LOG.info("Assign 3 {} :",VzbVoipEnum.RegionType.valueByAcronym(
						 * voipOrderRequest.getOrderHeader().getRegion()));
						 */
					}
				}

				if ("EMEA".equals(voipOrderRequest.getOrderHeader().getRegion()) && voipOrderRequest.getOrderHeader()
						.getOrderClassify() == WorkOrderEnum.OrderClassify.INITIAL) {
					voipOrderRequest.getOrderHeader().setOrderClassify(WorkOrderEnum.OrderClassify.RELEASE);
				}
				if ("EMEA".equals(voipOrderRequest.getOrderHeader().getRegion())
						&& voipOrderRequest.getOrderHeader().getOrderClassify() != WorkOrderEnum.OrderClassify.CANCEL) {
					voipOrderRequest.getOrderHeader().setOrderClassify(WorkOrderEnum.OrderClassify.RELEASE);
				}

				customer.setContactPhone1(
						customer.getCountryDialing() + customer.getAreaDialing() + customer.getDialNumber());
				customer.setAccountTeamName(customer.getAccountTeamFirstName() + customer.getAccountTeamLastName());
				customer.setAccountTeamPhone(customer.getAccountTeamCountryDialling()
						+ customer.getAccountTeamAreaDialling() + customer.getAccountTeamDialNumber());
				
				if ("C".equalsIgnoreCase(voipOrderRequest.getOrderHeader().getOrderType())) {

					CustomerEntity changeCustomer = parseCustomerChangeOrder(voipOrderRequest);
					customer.setCustomerEntity(changeCustomer);
				}
			}

			if(!authServicesList.isEmpty()) {
				customer.setAuthService(authServicesList);
			}
			
			gcmInfo = parseGCMInfo(voipOrderRequest);
			if (gcmInfo != null) {
				customer.setGcmInfo(gcmInfo);
			}
		} catch (TranslatorException ex) {
			LOG.error("Exception {} ", ex.getMessage());
			throw new TranslatorException(ex.getErrorCode(), ex.getMessage());
		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new GenericException(GenericException.GENERIC_EXCEPTION,
					"Unexpected Error Occured while Enterprise Order\"");
		}

		LOG.info("Exit - parseEnterpriseOrder");
		return customer;
	}

	/**
	 * @param voipOrderRequest
	 * @return gcmInfo
	 * @throws TranslatorException
	 * @throws ParseException
	 */
	GCMInfo parseGCMInfo(VOIPOrderRequest voipOrderRequest) throws TranslatorException, ParseException {
		LOG.info("Enter parseGCMInfo api");
		GCMInfo gcmInfo = null;

		if (voipOrderRequest != null && voipOrderRequest.getAdditionalInfo() != null
				&& voipOrderRequest.getAdditionalInfo().getGCMInfo() != null) {
			gcmInfo = voipOrderRequest.getAdditionalInfo().getGCMInfo();

			List<String> billableFeaturesList = getBillableFeatures();

			PricingInfo[] pricingInfoList = gcmInfo.getPricingInfo();

			PricingInfo[] gcmPricingInfo = null;
			if (!ArrayUtils.isEmpty(pricingInfoList)) {
				gcmPricingInfo = new PricingInfo[pricingInfoList.length];
			}

			int index = 0;

			if (gcmPricingInfo != null) {
				for (PricingInfo pricingInfo : pricingInfoList) {

					String pricingFeatureCode = pricingInfo.getFeatureCode();

					Feature[] convergedServiceFeatures = voipOrderRequest.getConvergedService().getFeature();
					for (Feature feature : convergedServiceFeatures) {
						if (pricingFeatureCode != null && pricingFeatureCode.equalsIgnoreCase(feature.getCode())) {
							String instanceId = feature.getInstanceId();
							if (instanceId != null && instanceId.equals(pricingInfo.getFeatureInstanceId())) {
								Specification[] specifications = feature.getSpecification();
								
								//Fix for PQ Order for feature without Spec
								if(specifications != null) {

									for (Specification specification : specifications) {
										if ("ESP_PRICEBOOK_LINEITEM_ID".equalsIgnoreCase(specification.getCode())) {
											pricingInfo.setPbLi(specification.getValue());
										} /*
											 * else { if (billableFeaturesList.contains(pricingFeatureCode)) { throw new
											 * TranslatorException(TranslatorException.ErrorCode.INVALID_XML,
											 * "PBLI cannot be null for feature code " + pricingFeatureCode); } }
											 */
									}									
								}

								if ("FET_VOIP_BEST_PLUS".equalsIgnoreCase(pricingFeatureCode)) {
									Specification[] bestPlusSpecifications = feature.getSpecification();
									for (Specification bestPlusSpecification : bestPlusSpecifications) {
										if ("SP_VOIP_ENT_SERVICE_PLAN"
												.equalsIgnoreCase(bestPlusSpecification.getCode())) {
											String svcLvl = bestPlusSpecification.getValue();
											String svcLvlEnumName = null;
											if (svcLvl != null && svcLvl.equalsIgnoreCase("Local and LD")) {
												svcLvlEnumName = VzbVoipEnum.ServiceLevel
														.acronym(VzbVoipEnum.ServiceLevel.LD_LOCAL_AND_ON_NET);
											} else if (svcLvl != null && svcLvl.equalsIgnoreCase("LD Only")) {
												svcLvlEnumName = VzbVoipEnum.ServiceLevel
														.acronym(VzbVoipEnum.ServiceLevel.LD_AND_ON_NET);
											} else if (svcLvl != null && svcLvl.equalsIgnoreCase("Non-US")) {
												svcLvlEnumName = VzbVoipEnum.ServiceLevel
														.acronym(VzbVoipEnum.ServiceLevel.NON_US);
											}
											if (svcLvlEnumName != null) {
												pricingInfo.setServicePlan(svcLvlEnumName);
											}
										}
									}
								}
							}
						}
					}

					if (billableFeaturesList.contains(pricingFeatureCode)) {
						if (pricingInfo.getFeatureInstanceId() == null) {
							throw new TranslatorException(TranslatorException.ErrorCode.INVALID_XML,
									"FeatureInstanceId cannot be null for feature code " + pricingFeatureCode);
						}

						if (pricingInfo.getChargeType() == null) {
							throw new TranslatorException(TranslatorException.ErrorCode.INVALID_XML,
									"ChargeType cannot be null for feature code " + pricingFeatureCode);
						}

						if (pricingInfo.getChargeFrequency() == null) {
							throw new TranslatorException(TranslatorException.ErrorCode.INVALID_XML,
									"ChargeFrequency cannot be null for feature code " + pricingFeatureCode);
						}

						if (pricingInfo.getUnitOfMeasure() == null) {
							throw new TranslatorException(TranslatorException.ErrorCode.INVALID_XML,
									"UnitOfMeasure cannot be null for feature code " + pricingFeatureCode);
						}

						if (pricingInfo.getBillTime() == null) {
							throw new TranslatorException(TranslatorException.ErrorCode.INVALID_XML,
									"BillTime cannot be null for feature code " + pricingFeatureCode);
						}

						LOG.debug("pricingInfo.getCatalogVersionTime():" + pricingInfo.getCatalogVersionTime());
						if (pricingInfo.getCatalogVersionTime() != null) {
							try {
								SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
								SimpleDateFormat format2 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
								Date date = format1.parse(pricingInfo.getCatalogVersionTime());
								pricingInfo.setCatalogVersionTime(format2.format(date));
							} catch (Exception ex) {
								LOG.error("Exception {} ", ex.getMessage());
								throw new TranslatorException(TranslatorException.ErrorCode.INVALID_DATE,
										"Invalid CatelogVersionTime for feature code " + pricingFeatureCode);
							}
						}
					}
					gcmPricingInfo[index++] = pricingInfo;
					gcmInfo.setPricingInfo(gcmPricingInfo);
				}
			}

		}
		LOG.info("Exit parseGCMInfo api");
		return gcmInfo;
	}

	/**
	 * @return getBillableFeatures
	 */
	List<String> getBillableFeatures() {
		LOG.info("Enter getBillableFeatures api");
		List<String> getBillableFeatures = customCustomerMapper.getBillableFeatures();
		LOG.info("Exit getBillableFeatures api");
		return getBillableFeatures;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.vz.esap.translation.order.parser.EnterpriseOrderParser#parseCustomerChangeOrder(com.
	 * vz.esap.translation.order.model.request.VOIPOrderRequest)
	 */
	public CustomerEntity parseCustomerChangeOrder(VOIPOrderRequest voipOrderRequest) throws TranslatorException{

		CustomerEntity chanceCustomer = null;
		try {
			LOG.info("Entered - parseCustomerChangeOrder");
			
			ChangeManagement[] changeManagements = voipOrderRequest.getChangeManagement();

			if (changeManagements == null) {
				// TODO: Logic for the ADD
				return null;
			}

			chanceCustomer = new CustomerEntity();

			for (ChangeManagement changeManagement : changeManagements) {

				ChangedElement[] changeElements = changeManagement.getChangedElement();

				if (changeElements != null && changeElements.length > 0) {
					for (ChangedElement changedElement : changeElements) {

						List<Feature> entLvlFeature = stream(voipOrderRequest.getConvergedService().getFeature())
								.filter(feature -> "EFET_VOIP_ENT_LVL".equalsIgnoreCase(feature.getCode()))
								.collect(Collectors.toList());

						List<Feature> xoAutFeature = stream(voipOrderRequest.getConvergedService().getFeature())
								.filter(feature -> "FET_XO_AUT".equalsIgnoreCase(feature.getCode()))
								.collect(Collectors.toList());

						List<Feature> xoTedFeature = stream(voipOrderRequest.getConvergedService().getFeature())
								.filter(feature -> "FET_XO_TFD".equalsIgnoreCase(feature.getCode()))
								.collect(Collectors.toList());
						
						//3/25 : TO DO for similar to xoAutFeature(FET_XO_AUT) do for FET_AUT, FET_CAL
						
						
						
						if (!entLvlFeature.isEmpty()
								&& entLvlFeature.get(0).getCode().equalsIgnoreCase(changedElement.getFeatureCode())
								&& entLvlFeature.get(0).getInstanceId()
										.equalsIgnoreCase(changedElement.getFeatureInstanceId())) {

							if (changedElement.getChangeType() != null
									&& ChangeType.CHANGED.toString().equalsIgnoreCase(changedElement.getChangeType())
									&& changedElement.getSpecificationCode() != null) {

								createChangedCustomerEntity(chanceCustomer, changedElement.getSpecificationCode(),
										changedElement.getNewValue(),voipOrderRequest);

							}

						} else if (!xoAutFeature.isEmpty() && xoAutFeature.get(0).getCode().equalsIgnoreCase(changedElement.getFeatureCode())
								&& xoAutFeature.get(0).getInstanceId()
										.equalsIgnoreCase(changedElement.getFeatureInstanceId())) {
							if (changedElement.getChangeType() != null
									&& ChangeType.CHANGED.toString().equalsIgnoreCase(changedElement.getChangeType())
									&& changedElement.getSpecificationCode() != null) {

								createChangedCustomerEntity(chanceCustomer, changedElement.getSpecificationCode(),
										changedElement.getNewValue(),voipOrderRequest);

							}
						} else if (!xoTedFeature.isEmpty() && xoTedFeature.get(0).getCode().equalsIgnoreCase(changedElement.getFeatureCode()) && xoTedFeature
								.get(0).getInstanceId().equalsIgnoreCase(changedElement.getFeatureInstanceId())) {
							if (changedElement.getChangeType() != null
									&& ChangeType.CHANGED.toString().equalsIgnoreCase(changedElement.getChangeType())
									&& changedElement.getSpecificationCode() != null) {

								createChangedCustomerEntity(chanceCustomer, changedElement.getSpecificationCode(),
										changedElement.getNewValue(),voipOrderRequest);

							}
						}
					}
				}
			}
		} catch (Exception e) {
			LOG.error("Exception occured in parseCustomerChangeOrder- {}", e);
		}

		LOG.info("Exited - parseCustomerChangeOrder");
		return chanceCustomer;
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.vz.esap.translation.order.parser.EnterpriseOrderParser#createChangedCustomerEntity(com.
	 * vz.esap.translation.order.model.request.VOIPOrderRequest)
	 */
	public void createChangedCustomerEntity(CustomerEntity changedCustomer, String specCode, String specValue,VOIPOrderRequest voipOrderRequest) throws TranslatorException {
		String soEnabled = null;
		Boolean routeExhaustBool = null;
		LOG.info("Entered - createChangedCustomerntity");

		try {
			if (changedCustomer == null) {
				changedCustomer = new CustomerEntity();
			}

			if ("ESP_ENT_MIG_NEW_ENT_ID".equalsIgnoreCase(specCode)) {
				changedCustomer.setNewEntId(specValue);
			}
			if ("ESP_ENT_US_REF_ID".equalsIgnoreCase(specCode)) {
				changedCustomer.setParentEnterpriseId(specValue);
			}

			if ("SP_VOIP_SERVICE_OPT".equalsIgnoreCase(specCode)
					&& specValue != null) {
				soEnabled = specValue;
			}
			if (soEnabled == null) {
				changedCustomer.setSoEnabled("0");
				changedCustomer.setEnterpriseCclIndicator(Boolean.FALSE);
			}

			if ("ESP_ENT_TRNK_RTE_OFLW_AUTH".equalsIgnoreCase(specCode)
					&& specValue != null
					&& changedCustomer.getOrderPlatform() == OrderPlatformEnum.E2EI) {
				String routeExhaust = specValue;
				routeExhaustBool = "Yes".equals(routeExhaust) ? Boolean.TRUE : Boolean.FALSE;
			}
			if (null != routeExhaustBool)
				changedCustomer.addAuthService("Route Exhaust", routeExhaustBool.booleanValue());

			if ("SP_VOIP_ENT_LOCAL_LD_BEST_POOL".equalsIgnoreCase(specCode)) {
				changedCustomer.setUsLDAndLocalBestPool(specValue);
				changedCustomer.setAction(changedCustomer.getAction());

			}
			if ("SP_VOIP_ENT_LD_ONLY_BEST_POOL".equalsIgnoreCase(specCode)) {
				changedCustomer.setUsLDOnlyBestPool(specValue);
				changedCustomer.setAction(changedCustomer.getAction());

			}
			
			if ("SP_VOIP_ENT_NON_US_BEST_POOL".equalsIgnoreCase(specCode)) {
				changedCustomer.setEmeaApacBestPool(specValue);
				changedCustomer.setAction(changedCustomer.getAction());
			}

			if ("ESP_ENT_REF_ID".equalsIgnoreCase(specCode)
					&& specValue != null) {
				String refid = specValue;
				new TsoMigrationEntReferenceData().setEnterpriseReferenceId(Long.parseLong(refid));
			}


			if ("ESP_ENTERPRISE_NAME".equalsIgnoreCase(specCode)) {
				changedCustomer.setCustomerName(specValue);
			}
			if ("ESP_NON_TRUSTED_IP_C".equalsIgnoreCase(specCode)) {
				String nonTrusted = specValue;
				if ("Y".equalsIgnoreCase(nonTrusted) || "Yes".equalsIgnoreCase(nonTrusted)) {
					changedCustomer.setNonTrustedIPCalls("Y");
				} else if ("N".equalsIgnoreCase(nonTrusted) || "No".equalsIgnoreCase(nonTrusted)) {
					changedCustomer.setNonTrustedIPCalls("N");
				}
			}
			if ("ESP_ALLOW_ON_NET".equalsIgnoreCase(specCode)) {
				String allowOnNet = specValue;
				if ("Y".equalsIgnoreCase(allowOnNet) || "Yes".equalsIgnoreCase(allowOnNet)) {
					changedCustomer.setAllowOnNet("Y");
				} else if ("N".equalsIgnoreCase(allowOnNet) || "No".equalsIgnoreCase(allowOnNet)) {
					changedCustomer.setAllowOnNet("N");
				}
			}
			if ("ESP_SIP_DOMAIN".equalsIgnoreCase(specCode)) {
				changedCustomer.setSipDomain(specValue);
			}
			if ("ESP_ADM_FST_NAME".equalsIgnoreCase(specCode)) {
				changedCustomer.setAdminFirstName(specValue);
			}
			if ("ESP_ADM_LST_NAME".equalsIgnoreCase(specCode)) {
				changedCustomer.setAdminLastName(specValue);
			}
			if ("ESP_ADM_LOGIN_ID".equalsIgnoreCase(specCode)) {
				changedCustomer.setAdminWebLoginId(specValue);
			}
			if ("ESP_ADM_PW".equalsIgnoreCase(specCode)) {
				changedCustomer.setAdminPassword(specValue);
			}
			if ("SP_VOIP_NUM_HOST_ENT_PRIZ_DIG".equalsIgnoreCase(specCode)) {
				changedCustomer.setIeanLength(Integer.parseInt(specValue));
			}
			if ("ESP_CALL_REDIRECT_TO_TN_AUTH".equalsIgnoreCase(specCode)) {
				changedCustomer.setAuthCFNR(specValue);
			}
			if ("ESP_CALL_FW_AUTH".equalsIgnoreCase(specCode)) {
				changedCustomer.setAuthPbxUnReachableFeature(specValue);
			}
			if ("ESP_NCAR_ID".equalsIgnoreCase(specCode)) {
				changedCustomer.setLOR("Y");
				changedCustomer.setLorId(specValue);
			}
			if ("ESP_VMAIL_AUTH".equalsIgnoreCase(specCode)) {
				String vmAuthorized = specValue;
				if (vmAuthorized != null && vmAuthorized.trim().length() > 0
						&& ("Y".equals(vmAuthorized) || "Yes".equalsIgnoreCase(vmAuthorized))) {
					changedCustomer.addAuthService("Voice Mail Storage Options - 20 Messages", true);
					changedCustomer.addAuthService("Voice Mail Storage Options - 50 Messages", true);
				} else if (vmAuthorized != null && vmAuthorized.trim().length() > 0
						&& ("N".equals(vmAuthorized) || "No".equalsIgnoreCase(vmAuthorized))) {
					changedCustomer.addAuthService("Voice Mail Storage Options - 20 Messages", false);
					changedCustomer.addAuthService("Voice Mail Storage Options - 50 Messages", false);
				}
			}
			if ("ESP_INS_AUTH".equalsIgnoreCase(specCode)) {
				String autoAttndntAuthorized = specValue;
				changedCustomer.addAuthService("Auto Attendant", "Yes".equals(autoAttndntAuthorized) ? true : false);
			}
			if ("ESP_FET_PAK_AUTH".equalsIgnoreCase(specCode)) {
				String intermediatFetAuthorized = specValue;
				changedCustomer.addAuthService("Intermediate Feature Package",
						"Yes".equals(intermediatFetAuthorized) ? true : false);
			}
			if ("ESP_NCA_ID".equalsIgnoreCase(specCode)) {
				changedCustomer.setNcaId(specValue);
			}
			if ("SP_VOIP_ENT_TRUNK_PREM".equalsIgnoreCase(specCode)) {
				String etPremium = specValue;
				if (null != etPremium && etPremium.trim().length() > 0
						&& ("Y".equalsIgnoreCase(etPremium) || "YES".equalsIgnoreCase(etPremium)))
					changedCustomer.setEnterpriseTrunkingType(VzbVoipEnums.EnterpriseTrunkingTypeEnum.PREMIUM);
			}
			if ("ESP_ENT_TRNK_RTE_FLOW_AUTH".equalsIgnoreCase(specCode)) {
				changedCustomer.setEtRouteOverflowAuthorization(specValue);
			}
			if ("SP_VOIP_ENT_SERVICE_PLAN".equalsIgnoreCase(specCode)) {
				changedCustomer.setEntServicePlan(specValue);
			}
			if ("SP_VOIP_ENT_USAGE_PLAN".equalsIgnoreCase(specCode)) {
				changedCustomer.setUsagePlan(specValue);
			}
			if ("SP_VOIP_ENT_NUM_FREE_MIN".equalsIgnoreCase(specCode)) {
				changedCustomer.setNumberOfFreeMinutes(specValue);
			}
			if ("SP_VOIP_ENT_CUM_CCL".equalsIgnoreCase(specCode)) {
				changedCustomer.setCummulativeCcl(Long.parseLong(specValue));
			}
			if ("ESP_ENT_COUNTRY".equalsIgnoreCase(specCode)) {
				changedCustomer.setVirtualAddrCountry(specValue);
			}
			if ("ESP_ENT_STATE".equalsIgnoreCase(specCode)) {
				changedCustomer.setVirtualAddrState(specValue);
			}
			if ("ESP_ENT_TRNK_RTE_OFLW_AUTH".equalsIgnoreCase(specCode)) {
				changedCustomer.setRouteExhaust(specValue);
			}
			if ("ESP_DESIGN_ID".equalsIgnoreCase(specCode)) {
				changedCustomer.setDesignId(Long.parseLong(specValue));
			}
		} catch (Exception e) {
			LOG.error("Exception occured in parseCustomerChangeOrder- {}", e);
		}

		//not creating the createChangedSessionEntity method as "No Spec items" and session attribute is not exists in CustomerEntity - Need confirmation..
		LOG.info("Exited - createChangedCustomerEntity");
	}

}