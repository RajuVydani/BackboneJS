package com.vz.esap.translation.order.service.ipflex;

import java.util.Map;

import com.vz.esap.translation.exception.GenericException;
import com.vz.esap.translation.exception.TranslatorException;
import com.vz.esap.translation.order.model.request.VOIPOrderRequest;
import com.vz.esap.translation.order.model.response.VoipOrderResponse;

public interface IpFlexOrderService {

	/**
	 * @param voipOrderRequest
	 * @param productDetails
	 * @return
	 * @throws GenericException
	 * @throws TranslatorException
	 */
	VoipOrderResponse createIpFlexValidateOrder(VOIPOrderRequest voipOrderRequest, Map<String, String> productDetails)
			throws GenericException;
	
	/**
	 * @param voipOrderRequest
	 * @param productDetails
	 * @return
	 * @throws TranslatorException
	 * @throws GenericException
	 */
	VoipOrderResponse createIpFlexReleaseOrder(VOIPOrderRequest voipOrderRequest, Map<String, String> productDetails) throws TranslatorException, GenericException;
	
	/**
	 * @param voipOrderRequest
	 * @param productDetails
	 * @return
	 * @throws TranslatorException
	 * @throws GenericException
	 */
	VoipOrderResponse createIpFlexLocSuspOrder(VOIPOrderRequest voipOrderRequest, Map<String, String> productDetails)
			throws TranslatorException, GenericException;
	
	/**
	 * @param voipOrderRequest
	 * @param productDetails
	 * @return
	 * @throws TranslatorException
	 * @throws GenericException
	 */
	VoipOrderResponse createIpFlexLocDeactOrder(VOIPOrderRequest voipOrderRequest, Map<String, String> productDetails)
			throws TranslatorException, GenericException;
	
}
