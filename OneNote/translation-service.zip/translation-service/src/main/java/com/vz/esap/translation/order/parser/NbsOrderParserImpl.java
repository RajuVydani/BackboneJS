package com.vz.esap.translation.order.parser;

import static java.util.Arrays.stream;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.vz.esap.translation.entity.NbsEntity;
import com.vz.esap.translation.entity.Session;
import com.vz.esap.translation.enums.EsapEnum.ChangeType;
import com.vz.esap.translation.enums.EsapEnum.NbsType;
import com.vz.esap.translation.enums.EsapEnum.RedundancyPriorityType;
import com.vz.esap.translation.enums.EsapEnum.RedundancyType;
import com.vz.esap.translation.exception.TranslatorException;
import com.vz.esap.translation.exception.TranslatorException.ErrorCode;
import com.vz.esap.translation.order.model.request.ChangeManagement;
import com.vz.esap.translation.order.model.request.ChangedElement;
import com.vz.esap.translation.order.model.request.Feature;
import com.vz.esap.translation.order.model.request.Specification;
import com.vz.esap.translation.order.model.request.VOIPOrderRequest;

import net.logstash.logback.encoder.org.apache.commons.lang.ArrayUtils;
import reactor.util.CollectionUtils;

@Component
public class NbsOrderParserImpl implements NbsOrderParser {

	private static final Logger LOG = LoggerFactory.getLogger(NbsOrderParserImpl.class);

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.vz.esap.translation.order.parser.NbsOrderParser#parseNbsOrder(com.vz.esap
	 * .translation.order.model.request.VOIPOrderRequest)
	 */
	@Override
	public ArrayList<NbsEntity> parseNbsOrder(VOIPOrderRequest voipOrderRequest)
			throws TranslatorException, ParseException {

		LOG.info("Entered - parseNbsOrder");
		ArrayList<NbsEntity> nbsEntityList = new ArrayList<>();
		NbsEntity nbsEntity = null;
		List<Feature> trunkFeatures = null;
		RedundancyType redundancy = null;
		RedundancyPriorityType redundancyPriority = null;
		List<Feature> locFeatures = null;
		List<Feature> sesFeaturesList = null;
		String trunkInstanceIdChanged = null;
		List<String> trunkInstanceIdChangedList = null;
		Session session = null;
		List<Feature> trunkFeatList = null;
		List<Specification> trunkSessionCountSpec = null;
		List<Specification> xocomspec = null;
		int sessionCount = 0;
		String cpeIpAddress = null;
		String compressionType = null;

		try {

			if(voipOrderRequest.getNbsConfig() != null) {
				LOG.debug("Inside parseNbsOrder for getNbsConfig");
				nbsEntity = new NbsEntity();
				nbsEntity.setNbsClusterName(voipOrderRequest.getNbsConfig().getNBSCluster());
				nbsEntity.setExternalSigZoneIp(voipOrderRequest.getNbsConfig().getIPExt28());
				nbsEntity.setVlanId(voipOrderRequest.getNbsConfig().getVLan());
				nbsEntity.setIpVersion(voipOrderRequest.getNbsConfig().getIPVersion());
				nbsEntity.setVpnName(voipOrderRequest.getNbsConfig().getVpnName());
				nbsEntity.setSR1(voipOrderRequest.getNbsConfig().getSR1());
				nbsEntity.setSR2(voipOrderRequest.getNbsConfig().getSR2());
				nbsEntity.setSR3(voipOrderRequest.getNbsConfig().getSR3());
				nbsEntity.setSR4(voipOrderRequest.getNbsConfig().getSR4());
				nbsEntity.setIp28(voipOrderRequest.getNbsConfig().getIPExt28());
				nbsEntity.setNbsCircuitId(voipOrderRequest.getNbsConfig().getCircuitID());
				nbsEntityList.add(nbsEntity);
			}else {			
			trunkFeatures = stream(voipOrderRequest.getConvergedService().getFeature())
					.filter(trunkFeature -> "FET_XO_TRU".equalsIgnoreCase(trunkFeature.getCode()))
					.collect(Collectors.toList());
			
						
			LOG.info("In - parseNbsOrder NBS Trunk Related Feature Size : {}", trunkFeatures.size());
			// Start-NBS Change
			locFeatures = stream(voipOrderRequest.getConvergedService().getFeature())
					.filter(locFeature -> "FET_LOC_LVL".equalsIgnoreCase(locFeature.getCode()))
					.collect(Collectors.toList());
			LOG.info("In - parseNbsOrder NBS Location Related Feature Size : {}", locFeatures.size());

			for (Specification specification : locFeatures.get(0).getSpecification()) {

				LOG.info("In - parseNbsOrder NBS Location Related Spec : {} and Value : {}", specification.getCode(),
						specification.getValue());
				
				if ("SP_XO_RED".equalsIgnoreCase(specification.getCode())) {
					if ("PRIORITY".equalsIgnoreCase(specification.getValue()))
						redundancy = RedundancyType.PRIORITY;
					if ("Load Sharing".equalsIgnoreCase(specification.getValue()))
						redundancy = RedundancyType.LOADSHARING;
					if ("NONE".equalsIgnoreCase(specification.getValue()))
						redundancy = RedundancyType.NONE;
				}
				if ("SP_XO_REDPT".equalsIgnoreCase(specification.getCode())) {
					if ("PRIMARY".equalsIgnoreCase(specification.getValue()))
						redundancyPriority = RedundancyPriorityType.PRIMARY;
					if ("SECONDARY".equalsIgnoreCase(specification.getValue()))
						redundancyPriority = RedundancyPriorityType.SECONDARY;
				}
				if ("SP_XO_ESBC_IP".equalsIgnoreCase(specification.getCode())) {
					cpeIpAddress = specification.getValue();
				}
				
			}
			// End-NBS Change
			
			//Start: compressionType Fix
			sesFeaturesList = stream(voipOrderRequest.getConvergedService().getFeature())
					.filter(locFeature -> "FET_XO_SES".equalsIgnoreCase(locFeature.getCode()))
					.collect(Collectors.toList());

			if (!CollectionUtils.isEmpty(sesFeaturesList)) {

				for (Feature sesFeatures : sesFeaturesList) {

					xocomspec = stream(sesFeatures.getSpecification())
							.filter(spec -> "SP_XO_COM".equalsIgnoreCase(spec.getCode()))
							.collect(Collectors.toList());

					if (!CollectionUtils.isEmpty(xocomspec)) {
						compressionType = xocomspec.get(0).getValue();
					}
				}
			}
			//End: compressionType Fix	
			
			//Start: Trunk Change Fix:
			if(voipOrderRequest.getChangeManagement() != null) {
			for (ChangeManagement changeManagement : voipOrderRequest.getChangeManagement()) {
				trunkInstanceIdChangedList = new ArrayList<>();
				for (ChangedElement changedElement : changeManagement.getChangedElement()) {
					if ("ADDED".equalsIgnoreCase(changedElement.getChangeType())
							&& "FET_XO_TRU".equalsIgnoreCase(changedElement.getFeatureCode())) {
						trunkInstanceIdChanged = changedElement.getFeatureInstanceId();
						trunkInstanceIdChangedList.add(trunkInstanceIdChanged);
						LOG.info("TrunkInstanceIdChanged = {}", trunkInstanceIdChanged);
					}
				}
			}
			}
			//End: Trunk Change Fix:
			
			//Start Session Fix
			
			trunkFeatList = stream(voipOrderRequest.getConvergedService().getFeature())
					.filter(feature -> "FET_XO_TRU".equalsIgnoreCase(feature.getCode())).collect(Collectors.toList());

			
			if (!CollectionUtils.isEmpty(trunkFeatList)) {
				
				for (Feature trunkFeat : trunkFeatList) {
					
					if ("C".equalsIgnoreCase(voipOrderRequest.getOrderHeader().getOrderType())
							&& ("NONE".equalsIgnoreCase(trunkFeat.getActionCode())
									|| "ADD".equalsIgnoreCase(trunkFeat.getActionCode()))) {						
						
						trunkSessionCountSpec = stream(trunkFeat.getSpecification())
								.filter(spec -> "SP_TRK".equalsIgnoreCase(spec.getCode())).collect(Collectors.toList());
						LOG.info("Session Count Before = {}", sessionCount);
						
						if (!CollectionUtils.isEmpty(trunkSessionCountSpec)) {
							sessionCount = sessionCount + Integer.parseInt(trunkSessionCountSpec.get(0).getValue());
						}	
						LOG.info("Session Count After = {}", sessionCount);						
						
					} else {

						trunkSessionCountSpec = stream(trunkFeat.getSpecification())
								.filter(spec -> "SP_TRK".equalsIgnoreCase(spec.getCode())).collect(Collectors.toList());
						
						if (!CollectionUtils.isEmpty(trunkSessionCountSpec)) {
							sessionCount = sessionCount + Integer.parseInt(trunkSessionCountSpec.get(0).getValue());
						}	
					}
				}
				
				LOG.info("Session Total Count ={} ", sessionCount);
								
			}
			
			//End Session Fix
			
			for (Feature feature : trunkFeatures) {

				nbsEntity = new NbsEntity();
				nbsEntity.setTrunkGroupId(feature.getInstanceId());
				nbsEntity.setCustomerId(voipOrderRequest.getOrderHeader().getEnterpriseId());
				nbsEntity.setLocationId(voipOrderRequest.getOrderHeader().getLocationId());
				nbsEntity.setState(voipOrderRequest.getLocation().getLocationAddress().getState());
				nbsEntity.setCity(voipOrderRequest.getLocation().getLocationAddress().getCity());
				nbsEntity.setCountry(voipOrderRequest.getLocation().getLocationAddress().getCountryCode());
				nbsEntity.setRegion(voipOrderRequest.getLocation().getLocationAddress().getCountryCode());
				nbsEntity.setAsClli(voipOrderRequest.getOrderHeader().getAsClli()); //add broadsoft clli.
				nbsEntity.setBwCluster(voipOrderRequest.getOrderHeader().getBwCluster());									
			
				if(!ArrayUtils.isEmpty(voipOrderRequest.getCircuitInfo())) {
					nbsEntity.setNbsCircuitId(voipOrderRequest.getCircuitInfo()[0].getCircuitId());
					nbsEntity.setVpnName(voipOrderRequest.getCircuitInfo()[0].getVpnName()[0]);
				}

				for (Specification specs : feature.getSpecification()) {

					if ("SP_XO_SIG".equalsIgnoreCase(specs.getCode())) {
						if ("2 Way".equalsIgnoreCase(specs.getValue()))
							nbsEntity.setNbsType(NbsType.TWO_WAY);
						else if ("Inbound".equalsIgnoreCase(specs.getValue()))
							nbsEntity.setNbsType(NbsType.INBOUND);
					}
				}

				if (voipOrderRequest.getOrderHeader().getSolutionType() != null)
					nbsEntity.setSolutionType(voipOrderRequest.getOrderHeader().getSolutionType());
				// Start-NBS Change
				nbsEntity.setCpeIpAddress(cpeIpAddress);
				nbsEntity.setIpAddress(cpeIpAddress);
				nbsEntity.setAddress(cpeIpAddress);
				nbsEntity.setCpeServerFqdnPort("5060");
				nbsEntity.setCpeServerFqdn(null);
				nbsEntity.setCpePort("5060");
				nbsEntity.setRedundancy(redundancy);
				nbsEntity.setRedundancyPriorityType(redundancyPriority);
				if(redundancy.equals(RedundancyType.PRIORITY))
					nbsEntity.setPbxIpRedundancy1("");
				// End-NBS Change
				nbsEntity.setGroupUserLimit(String.valueOf(sessionCount));
				nbsEntity.setCompressionType(compressionType);
				
				//Start NBS Change Order:
				
					if ("C".equalsIgnoreCase(voipOrderRequest.getOrderHeader().getOrderType())) {

						if (!CollectionUtils.isEmpty(trunkInstanceIdChangedList)) {
							LOG.info("Trunk Present in Change Management For NBS");

							for (String trunkChangedId : trunkInstanceIdChangedList) {
								if (feature.getInstanceId().equalsIgnoreCase(trunkChangedId)) {
									LOG.info("NBS Trunk Instance Id Included In ADDED Change Management = {}",
											feature.getInstanceId());
									// Do Nothing

								} else {
									LOG.info("NBS Trunk Instance Id NOT Included In Change Management = {}",
											feature.getInstanceId());

									NbsEntity changeNbs = parseNbsChangeOrder(voipOrderRequest);
									nbsEntity.setNbsEntity(changeNbs);
								}
							}
						} else {
							LOG.info("No NBS Trunk in Change Management and Trunk Instance Id = {}",
									feature.getInstanceId());
							NbsEntity changeNbs = parseNbsChangeOrder(voipOrderRequest);
							nbsEntity.setNbsEntity(changeNbs);
						}
					}				
				nbsEntityList.add(nbsEntity);
			 }				
		 }
		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new TranslatorException(ErrorCode.PARSER_EXCEPTION, "Failed To Parse NBS Order");
		}
		LOG.info("Exited - parseNbsOrder");
		return nbsEntityList;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.vz.esap.translation.order.parser.NbsOrderParser#parseNbsChangeOrder(com.vz.
	 * esap.translation.order.model.request.VOIPOrderRequest)
	 */
	public NbsEntity parseNbsChangeOrder(VOIPOrderRequest voipOrderRequest) throws TranslatorException{

		LOG.info("Entered - parseNbsChangeOrder");
		
		ChangeManagement[] changeManagements = voipOrderRequest.getChangeManagement();

		if (changeManagements == null) {
			// TODO: Logic for the ADD
			return null;
		}

		NbsEntity chanceNbs = new NbsEntity();
		chanceNbs.setLocationId(voipOrderRequest.getConvergedService().getID());

		for (ChangeManagement changeManagement : changeManagements) {

			ChangedElement[] changeElements = changeManagement.getChangedElement();

			if (changeElements != null && changeElements.length > 0) {
				for (ChangedElement changedElement : changeElements) {

					List<Feature> xoTruFeature = stream(voipOrderRequest.getConvergedService().getFeature())
							.filter(feature -> "FET_XO_TRU".equalsIgnoreCase(feature.getCode()))
							.collect(Collectors.toList());

					List<Feature> xoLocLvlFeature = stream(voipOrderRequest.getConvergedService().getFeature())
							.filter(feature -> "FET_LOC_LVL".equalsIgnoreCase(feature.getCode()))
							.collect(Collectors.toList());

					if (!xoTruFeature.isEmpty() && xoTruFeature.get(0).getCode().equalsIgnoreCase(changedElement.getFeatureCode()) && xoTruFeature
							.get(0).getInstanceId().equalsIgnoreCase(changedElement.getFeatureInstanceId())) {
						if (changedElement.getChangeType() != null
								&& ChangeType.CHANGED.toString().equalsIgnoreCase(changedElement.getChangeType())
								&& changedElement.getSpecificationCode() != null) {

							createChangedNbsEntity(chanceNbs, changedElement.getSpecificationCode(),
									changedElement.getNewValue());

						}
					} else if (!xoLocLvlFeature.isEmpty() && xoLocLvlFeature.get(0).getCode().equalsIgnoreCase(changedElement.getFeatureCode())
							&& xoLocLvlFeature.get(0).getInstanceId()
									.equalsIgnoreCase(changedElement.getFeatureInstanceId())) {
						if (changedElement.getChangeType() != null
								&& ChangeType.CHANGED.toString().equalsIgnoreCase(changedElement.getChangeType())
								&& changedElement.getSpecificationCode() != null) {

							createChangedNbsEntity(chanceNbs, changedElement.getSpecificationCode(),
									changedElement.getNewValue());

						}
					} 
				}
			}
		}

		LOG.info("Exited - parseNbsChangeOrder");
		return chanceNbs;
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.vz.esap.translation.order.parser.NbsOrderParser#createChangedNbsEntity(com.vz.
	 * esap.translation.order.model.request.VOIPOrderRequest)
	 */

	public void createChangedNbsEntity(NbsEntity chanceNbs, String specCode, String specValue) throws TranslatorException{
		RedundancyType redundancy = null;
		RedundancyPriorityType redundancyPriority = null;
		LOG.info("Entered - createchanceTrunkGroupEntity");

		if (chanceNbs == null) {
			chanceNbs = new NbsEntity();
		}

		if ("SP_XO_RED".equalsIgnoreCase(specCode)) {
			if ("PRIORITY".equalsIgnoreCase(specValue))
				redundancy = RedundancyType.PRIORITY;
			if ("Load Sharing".equalsIgnoreCase(specValue))
				redundancy = RedundancyType.LOADSHARING;
			if ("NONE".equalsIgnoreCase(specValue))
				redundancy = RedundancyType.NONE;
			chanceNbs.setRedundancy(redundancy);
		}
		if ("SP_XO_REDPT".equalsIgnoreCase(specCode)) {
			if ("PRIMARY".equalsIgnoreCase(specValue))
				redundancyPriority = RedundancyPriorityType.PRIMARY;
			if ("SECONDARY".equalsIgnoreCase(specValue))
				redundancyPriority = RedundancyPriorityType.SECONDARY;
			chanceNbs.setRedundancyPriorityType(redundancyPriority);

		}
		
		//not creating the createChangedSessionEntity method as "No Spec items" and session attribute is not exists in TrunkGroupEntity - Need confirmation..
		LOG.info("Exited - createchanceTrunkGroupEntity");
	}
}
