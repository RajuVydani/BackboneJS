package com.vz.esap.translation.entity;

public class MultilineAppearanceEntity {
    private String lineKeys;
    private String callsPerLine;
    
    public MultilineAppearanceEntity() {}

    public MultilineAppearanceEntity(MultilineAppearanceEntity mla) {
        lineKeys = mla.lineKeys;
        callsPerLine = mla.callsPerLine;
    }
	public String getLineKeys() {
		return lineKeys;
	}
	public void setLineKeys(String lineKeys) {
		this.lineKeys = lineKeys;
	}
	public String getCallsPerLine() {
		return callsPerLine;
	}
	public void setCallsPerLine(String callsPerLine) {
		this.callsPerLine = callsPerLine;
	}
    
    
}
