package com.vz.esap.translation.dao.repository;

public interface CustomTblConfigParamsMapper  extends TblConfigParamsMapper  {
	
	
}