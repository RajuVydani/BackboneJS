package com.vz.esap.translation.entity;

public class AuthService {
	
	private static final long serialVersionUID = 1L;
	
	private String name;
	private String featureQuantity;
	private Boolean authorise;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getFeatureQuantity() {
		return featureQuantity;
	}
	public void setFeatureQuantity(String featureQuantity) {
		this.featureQuantity = featureQuantity;
	}
	public Boolean getAuthorise() {
		return authorise;
	}
	public void setAuthorise(Boolean authorise) {
		this.authorise = authorise;
	}
	

}
