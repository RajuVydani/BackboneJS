package com.vz.esap.translation.order.model.request;

import java.util.ArrayList;


import EsapEnumPkg.VzbVoipEnum;

public class CallingPlan {
	
	
	public static enum CallTypeEnum {
		
		DENY(VzbVoipEnum.CallingPlanCallType.DENY),
		ALLOW(VzbVoipEnum.CallingPlanCallType.ALLOW),
		TRANSFER1(VzbVoipEnum.CallingPlanCallType.TRANSFER1),
		TRANSFER2(VzbVoipEnum.CallingPlanCallType.TRANSFER2),
		TRANSFER3(VzbVoipEnum.CallingPlanCallType.TRANSFER3),
		AUTHORIZE(VzbVoipEnum.CallingPlanCallType.AUTHORIZE),
		NONE(-1);
		
		
		int esapEnum;
		private CallTypeEnum(int esapEnum){
			this.esapEnum = esapEnum;
		}
		public int getEsapEnum(){
			return esapEnum;
		}
		
		public static CallTypeEnum valueOf(int esapEnum){
			for(CallTypeEnum tn : CallTypeEnum.values())
				if( tn.getEsapEnum() == esapEnum )
					return tn;
			
			return null;
		}
	}

	private String departmentId;
	private String locationId;
	private String callingPlanId;
	private String callingPlanName;
	private IncomingCallingPlan incoming;
	private OutgoingCallingPlan outgoing;
	private String _default;
	private String telephone1;
	private String telephone2;
	private String telephone3;
	private ArrayList<DigitString> digitStrings;

	public CallingPlan() {
	}

	public CallingPlan(CallingPlan callingPlan) {
		this.departmentId = callingPlan.departmentId;
		this.locationId = callingPlan.locationId;
		this.callingPlanId = callingPlan.callingPlanId;
		this.callingPlanName = callingPlan.callingPlanName;
		this.incoming = callingPlan.incoming;
		this.outgoing = callingPlan.outgoing;
		this._default = callingPlan._default;
		this.telephone1 = callingPlan.telephone1;
		this.telephone2 = callingPlan.telephone2;
		this.telephone3 = callingPlan.telephone3;
		if (callingPlan.digitStrings != null)
			this.digitStrings = new ArrayList<DigitString>(callingPlan.digitStrings);
	}

	// public String toString() {
	// StringBuilder buffer = new StringBuilder();
	// buffer.append("<CallingPlan>").append("\n");
	// OrderUtil.appendXmlNode(buffer, "departmentId", departmentId);
	// OrderUtil.appendXmlNode(buffer, "locationId", locationId);
	// OrderUtil.appendXmlNode(buffer, "callingPlanId", callingPlanId);
	// OrderUtil.appendXmlNode(buffer, "callingPlanName", callingPlanName);
	// OrderUtil.appendXmlNode(buffer, "_default", _default);
	// OrderUtil.appendXmlNode(buffer, "telephone1", telephone1);
	// OrderUtil.appendXmlNode(buffer, "telephone2", telephone2);
	// OrderUtil.appendXmlNode(buffer, "telephone3", telephone3);
	// OrderUtil.appendXmlNode(buffer, "digitString", digitStrings);
	// if (incoming != null) {
	// buffer.append(this.incoming);
	// }
	// if (outgoing != null) {
	// buffer.append(this.outgoing);
	// }
	// buffer.append("</CallingPlan>").append("\n");
	//
	// return buffer.toString();
	// }

	public String getDepartmentId() {
		return departmentId;
	}

	public void setDepartmentId(String departmentId) {
		this.departmentId = departmentId;
	}

	public String getLocationId() {
		return locationId;
	}

	public void setLocationId(String locationId) {
		this.locationId = locationId;
	}

	public String getCallingPlanId() {
		return callingPlanId;
	}

	public void setCallingPlanId(String callingPlanId) {
		this.callingPlanId = callingPlanId;
	}

	public String getCallingPlanName() {
		return callingPlanName;
	}

	public void setCallingPlanName(String calingPlanName) {
		this.callingPlanName = calingPlanName;
	}

	public IncomingCallingPlan getIncoming() {
		return incoming;
	}

	public void setIncoming(IncomingCallingPlan incoming) {
		this.incoming = incoming;
	}

	public OutgoingCallingPlan getOutgoing() {
		return outgoing;
	}

	public void setOutgoing(OutgoingCallingPlan outgoing) {
		this.outgoing = outgoing;
	}

	public String get_default() {
		return _default;
	}

	public void set_default(String _default) {
		this._default = _default;
	}

	public String getTelephone1() {
		return telephone1;
	}

	public void setTelephone1(String telephone1) {
		this.telephone1 = telephone1;
	}

	public String getTelephone2() {
		return telephone2;
	}

	public void setTelephone2(String telephone2) {
		this.telephone2 = telephone2;
	}

	public String getTelephone3() {
		return telephone3;
	}

	public void setTelephone3(String telephone3) {
		this.telephone3 = telephone3;
	}

	public void addToDigitStrings(DigitString ds) {
		
		if (digitStrings == null) {
			digitStrings = new ArrayList<DigitString>();
			digitStrings.add(ds);
		} else
			digitStrings.add(ds);
	}

	public ArrayList<DigitString> getDigitStrings() {
		return digitStrings;
	}

	public void setDigitStrings(ArrayList<DigitString> digitStrings) {
		this.digitStrings = digitStrings;
	}

	public int getEntityType() {
		return VzbVoipEnum.OrderEntity.CALLING_PLAN;
	}

	public String getEntityId() {
		return callingPlanId;
	}

	public String getEntityName() {
		return callingPlanName;
	}

}
