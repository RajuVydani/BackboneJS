package com.vz.esap.translation.order.model.request;

public class TnActivation {

	private String tnCount;
	private TnInfo[] tnInfo;
	private TnRangeInfo[] tnRangeInfo;

	public String getTnCount() {
		return tnCount;
	}

	public void setTnCount(String tnCount) {
		this.tnCount = tnCount;
	}

	public TnInfo[] getTnInfo() {
		return tnInfo;
	}

	public void setTnInfo(TnInfo[] tnInfo) {
		this.tnInfo = tnInfo;
	}

	public TnRangeInfo[] getTnRangeInfo() {
		return tnRangeInfo;
	}

	public void setTnRangeInfo(TnRangeInfo[] tnRangeInfo) {
		this.tnRangeInfo = tnRangeInfo;
	}
}
