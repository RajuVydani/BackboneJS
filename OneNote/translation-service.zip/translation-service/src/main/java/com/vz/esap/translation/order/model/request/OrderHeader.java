package com.vz.esap.translation.order.model.request;

import java.util.LinkedHashMap;

import com.vz.esap.translation.enums.EsapEnum.AuthFeatureType;
import com.vz.esap.translation.enums.EsapEnum.SolutionType;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class OrderHeader {

	private String vzId;

	private String ContractInd;

	private String MinorOrderType;

	private String NASPId;

	private String MsgSegmentNo;

	private String SuppType;

	private String DueDate;
	private String WorkOrderNumber;

	private String LastSegment;

	private String DueDateType;

	private String masterOrderNumber;

	private String UNOServiceId;

	private String FunctionCode;

	private String TransactionID;

	private String BulkOrder;

	private String WorkOrderVersion;

	private String EnterpriseId;

	private String BwEnterpriseId;

	private String VOIPLocationId;

	private String OrderType;

	private String locationId;

	private int orderClassify;

	private String centrexType;

	private String GCHId;

	private String OriginatingSystem;

	private String ResponseType;

	private String Region;

	private String ServiceType;

	private boolean expedite;

	private String interfaceSystem;

	private String bsAppServer;

	private String orderProTIN;

	private String iOrderTIN;

	private String tinVersion;

	private Boolean transitionFlag = false;

	private int priority;

	protected LinkedHashMap<String, String> attribMap;

	private String orderCreatedBy;

	private boolean hasBulkOrder = false;

	private Boolean hotCutIndicator;

	private Boolean CDDDIndicator;

	private SolutionType SolutionType;

	private AuthFeatureType authFeatureType;

	private String origin;
	
	private String asClli;

	private String bwCluster;
	
	public LinkedHashMap<String, String> getAttribMap() {
		return attribMap;
	}

	public void setAttribMap(LinkedHashMap<String, String> attribMap) {
		this.attribMap = attribMap;
	}

	public String getContractInd() {
		return ContractInd;
	}

	public void setContractInd(String ContractInd) {
		this.ContractInd = ContractInd;
	}

	public String getMinorOrderType() {
		return MinorOrderType;
	}

	public void setMinorOrderType(String MinorOrderType) {
		this.MinorOrderType = MinorOrderType;
	}

	public String getNASPId() {
		return NASPId;
	}

	public void setNASPId(String NASPId) {
		this.NASPId = NASPId;
	}

	public String getMsgSegmentNo() {
		return MsgSegmentNo;
	}

	public void setMsgSegmentNo(String MsgSegmentNo) {
		this.MsgSegmentNo = MsgSegmentNo;
	}

	public String getSuppType() {
		return SuppType;
	}

	public void setSuppType(String SuppType) {
		this.SuppType = SuppType;
	}

	public String getDueDate() {
		return DueDate;
	}

	public void setDueDate(String DueDate) {
		this.DueDate = DueDate;
	}

	public String getWorkOrderNumber() {
		return WorkOrderNumber;
	}

	public void setWorkOrderNumber(String WorkOrderNumber) {
		this.WorkOrderNumber = WorkOrderNumber;
	}

	public String getLastSegment() {
		return LastSegment;
	}

	public void setLastSegment(String LastSegment) {
		this.LastSegment = LastSegment;
	}

	public String getDueDateType() {
		return DueDateType;
	}

	public void setDueDateType(String DueDateType) {
		this.DueDateType = DueDateType;
	}

	public String getUNOServiceId() {
		return UNOServiceId;
	}

	public void setUNOServiceId(String UNOServiceId) {
		this.UNOServiceId = UNOServiceId;
	}

	public String getFunctionCode() {
		return FunctionCode;
	}

	public void setFunctionCode(String FunctionCode) {
		this.FunctionCode = FunctionCode;
	}

	public String getTransactionID() {
		return TransactionID;
	}

	public void setTransactionID(String TransactionID) {
		this.TransactionID = TransactionID;
	}

	public String getBulkOrder() {
		return BulkOrder;
	}

	public void setBulkOrder(String BulkOrder) {
		this.BulkOrder = BulkOrder;
	}

	public String getWorkOrderVersion() {
		return WorkOrderVersion;
	}

	public void setWorkOrderVersion(String WorkOrderVersion) {
		this.WorkOrderVersion = WorkOrderVersion;
	}

	public String getEnterpriseId() {
		return EnterpriseId;
	}

	public void setEnterpriseId(String EnterpriseId) {
		this.EnterpriseId = EnterpriseId;
	}

	public String getVoipLocationId() {
		return VOIPLocationId;
	}

	public void setVoipLocationId(String VoipLocationId) {
		this.VOIPLocationId = VoipLocationId;
	}

	public String getOrderType() {
		return OrderType;
	}

	public void setOrderType(String OrderType) {
		this.OrderType = OrderType;
	}

	// public String getGchId() {
	// return GchId;
	// }
	//
	// public void setGchId(String GchId) {
	// this.GchId = GchId;
	// }

	public String getOriginatingSystem() {
		return OriginatingSystem;
	}

	public void setOriginatingSystem(String OriginatingSystem) {
		this.OriginatingSystem = OriginatingSystem;
	}

	public String getResponseType() {
		return ResponseType;
	}

	public void setResponseType(String ResponseType) {
		this.ResponseType = ResponseType;
	}

	public String toString() {
		return "ClassPojo [ContractInd = " + ContractInd + ", MinorOrderType = " + MinorOrderType + ", NASPId = "
				+ NASPId + ", MsgSegmentNo = " + MsgSegmentNo + ", SuppType = " + SuppType + ", DueDate = " + DueDate
				+ ", WorkOrderNumber = " + WorkOrderNumber + ", LastSegment = " + LastSegment + ", DueDateType = "
				+ DueDateType + ", UNOServiceId = " + UNOServiceId + ", FunctionCode = " + FunctionCode
				+ ", TransactionID = " + TransactionID + ", BulkOrder = " + BulkOrder + ", WorkOrderVersion = "
				+ WorkOrderVersion + ", EnterpriseId = " + EnterpriseId + ", VoipLocationId = " + VOIPLocationId
				+ ", OrderType = " + OrderType + ", GCHId = " + GCHId + ", OriginatingSystem = " + OriginatingSystem
				+ "]";
	}

	public String getRegion() {
		return Region;
	}

	public void setRegion(String region) {
		Region = region;
	}

	public String getServiceType() {
		return ServiceType;
	}

	public void setServiceType(String serviceType) {
		ServiceType = serviceType;
	}

	public String getGCHId() {
		return GCHId;
	}

	public void setGCHId(String gCHId) {
		GCHId = gCHId;
	}

	public String getLocationId() {
		return locationId;
	}

	public void setLocationId(String locationId) {
		this.locationId = locationId;
	}

	public String getCentrexType() {
		return centrexType;
	}

	public void setCentrexType(String centrexType) {
		this.centrexType = centrexType;
	}

	/**
	 * @return the orderClassify
	 */
	public int getOrderClassify() {
		return orderClassify;
	}

	/**
	 * @param orderClassify
	 *            the orderClassify to set
	 */
	public void setOrderClassify(int orderClassify) {
		this.orderClassify = orderClassify;
	}

	/**
	 * @return the expedite
	 */
	public boolean getExpedite() {
		return expedite;
	}

	/**
	 * @param expedite
	 *            the expedite to set
	 */
	public void setExpedite(boolean expedite) {
		this.expedite = expedite;
	}

	/**
	 * @return the masterOrderNumber
	 */
	public String getMasterOrderNumber() {
		return masterOrderNumber;
	}

	/**
	 * @param masterOrderNumber
	 *            the masterOrderNumber to set
	 */
	public void setMasterOrderNumber(String masterOrderNumber) {
		this.masterOrderNumber = masterOrderNumber;
	}

	/**
	 * @return the vzId
	 */
	public String getVzId() {
		return vzId;
	}

	/**
	 * @param vzId
	 *            the vzId to set
	 */
	public void setVzId(String vzId) {
		this.vzId = vzId;
	}

	public String getInterfaceSystem() {
		return interfaceSystem;
	}

	public void setInterfaceSystem(String interfaceSystem) {
		this.interfaceSystem = interfaceSystem;
	}

	public String getBsAppServer() {
		return bsAppServer;
	}

	public void setBsAppServer(String bsAppServer) {
		this.bsAppServer = bsAppServer;
	}

	public String getOrderProTIN() {
		return orderProTIN;
	}

	public void setOrderProTIN(String orderProTIN) {
		this.orderProTIN = orderProTIN;
	}

	public String getiOrderTIN() {
		return iOrderTIN;
	}

	public void setiOrderTIN(String iOrderTIN) {
		this.iOrderTIN = iOrderTIN;
	}

	public String getTinVersion() {
		return tinVersion;
	}

	public void setTinVersion(String tinVersion) {
		this.tinVersion = tinVersion;
	}

	public Boolean getTransitionFlag() {
		return transitionFlag;
	}

	public void setTransitionFlag(Boolean transitionFlag) {
		this.transitionFlag = transitionFlag;
	}

	public int getPriority() {
		return priority;
	}

	public void setPriority(int priority) {
		this.priority = priority;
	}

	public String getOrderCreatedBy() {
		return orderCreatedBy;
	}

	public void setOrderCreatedBy(String orderCreatedBy) {
		this.orderCreatedBy = orderCreatedBy;
	}

	public boolean isHasBulkOrder() {
		return hasBulkOrder;
	}

	public void setHasBulkOrder(boolean hasBulkOrder) {
		this.hasBulkOrder = hasBulkOrder;
	}

	public Boolean isHotCutIndicator() {
		if (hotCutIndicator == null)
			return Boolean.FALSE;
		return hotCutIndicator;
	}

	public void setHotCutIndicator(Boolean hotCutIndicator) {
		this.hotCutIndicator = hotCutIndicator;
	}

	public Boolean isCDDDIndicator() {
		if (CDDDIndicator == null)
			return Boolean.FALSE;
		return CDDDIndicator;
	}

	public void setCDDDIndicator(Boolean indicator) {
		CDDDIndicator = indicator;
	}

	public SolutionType getSolutionType() {
		return SolutionType;
	}

	public void setSolutionType(SolutionType solutionType) {
		this.SolutionType = solutionType;
	}

	public Boolean getHotCutIndicator() {
		return hotCutIndicator;
	}

	public Boolean getCDDDIndicator() {
		return CDDDIndicator;
	}

	public AuthFeatureType getAuthFeatureType() {
		return authFeatureType;
	}

	public void setAuthFeatureType(AuthFeatureType authFeatureType) {
		this.authFeatureType = authFeatureType;
	}

	public String getOrigin() {
		return origin;
	}

	public void setOrigin(String origin) {
		this.origin = origin;
	}

	public String getBwEnterpriseId() {
		return BwEnterpriseId;
	}

	public void setBwEnterpriseId(String bwEnterpriseId) {
		BwEnterpriseId = bwEnterpriseId;
	}
	
	public String getAsClli() {
		return asClli;
	}

	public void setAsClli(String asClli) {
		this.asClli = asClli;
	}

	public String getBwCluster() {
		return bwCluster;
	}

	public void setBwCluster(String bwCluster) {
		this.bwCluster = bwCluster;
	}

}
