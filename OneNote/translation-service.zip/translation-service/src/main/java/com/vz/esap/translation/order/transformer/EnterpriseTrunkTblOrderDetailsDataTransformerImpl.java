package com.vz.esap.translation.order.transformer;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.vz.esap.translation.entity.EnterpriseTrunkEntity;
import com.vz.esap.translation.enums.EsapEnum;
import com.vz.esap.translation.enums.EsapEnum.SolutionType;
import com.vz.esap.translation.exception.TranslatorException;
import com.vz.esap.translation.exception.TranslatorException.ErrorCode;
import com.vz.esap.translation.order.model.Order;
import com.vz.esap.translation.order.model.request.ParamInfo;
import com.vz.esap.translation.order.model.request.VOIPOrderRequest;
import com.vz.esap.translation.util.OrderUtility;

/**
 * @author chattni
 *
 */
@Component
public class EnterpriseTrunkTblOrderDetailsDataTransformerImpl
		implements EnterpriseTrunkTblOrderDetailsDataTransformer {

	private static final Logger LOG = LoggerFactory.getLogger(EnterpriseTrunkTblOrderDetailsDataTransformerImpl.class);
	private static final String ORDERING_ALGO = "OrderingAlgorithm";
	private static final String LOCATION_ID = "LocationId";
	private static final String CUSTOMER_ID = "CustomerId";
	private static final String REGION = "Region";
	// private static final String BS_APP_SERVER = "BsAppServer";
	private static final String HOT_CUT_IND = "HotCutIndicator";
	private static final String CDD_IND = "CDDDIndicator";

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.vz.esap.translation.order.transformer.
	 * EnterpriseTrunkTblOrderDetailsDataTransformer#
	 * prepareTblOrderDetailsEntityParamDataForET(java.util.List, java.lang.String)
	 */
	@Override
	public ArrayList<ParamInfo> prepareTblOrderDetailsEntityParamDataForET(List<EnterpriseTrunkEntity> ets,
			VOIPOrderRequest voipOrderRequest) {
		LOG.info("Enter prepareTblOrderDetailsEntityParamDataForET(ets, action)");

		String action = voipOrderRequest.getOrderHeader().getOrderType();
		ArrayList<ParamInfo> infos = new ArrayList<>();
		for (EnterpriseTrunkEntity et : ets) {
			ParamInfo root = new ParamInfo("EnterpriseTrunk", null, action);
			root.addNotNullValChild("EnterpriseTrunkName", et.getBwEtId(), action, ParamInfo.Tag.NAME);
			root.addNotNullValChild("EnterpriseTrunkId", et.getEnterpriseTrunkId(), action);
			root.addNotNullValChild("CustomerId", et.getCustomerId(), action);
			root.addNotNullValChild("MaxRerouteAttempts", et.getMaxRerouteAttempts(), action);
			root.addNotNullValChild("MaxRerouteAttemptsPriority", et.getMaxRerouteAttemptsPriority(), action);
			root.addNotNullValChild("RouteExhaustAction", et.getRouteExhaustAction(), action);
			root.addNotNullValChild("RouteExhaustForwardTN", et.getRouteExhaustForwardTN(), action);
			// XO Change
			root.addNotNullValChild("BWEnterpriseId", et.getBwEntId(), action);
			root.addNotNullValChild("BWEnterpriseTrunkId", et.getBwEtId(), action);
			root.addNotNullValChild("EnterpriseTrunkType", et.getEtType(), action);
			root.addNotNullValChild("SignalingDirection", et.getSignalDirection(), action);
			root.addNotNullValChild("RouteExhaustionAction", "NONE", action);
			root.addNotNullValChild("TrunkGroupId", et.getBwTrunkGroupId(), action);
			root.addNotNullValChild("Region", et.getRegion(), action);

			if ("Priority".equalsIgnoreCase(et.getRedundancy()))
				root.addNotNullValChild(ORDERING_ALGO, "OVERFLOW", action);
			else if ("None".equalsIgnoreCase(et.getRedundancy()))
				root.addNotNullValChild(ORDERING_ALGO, "OVERFLOW", action);
			else if ("Load Sharing".equalsIgnoreCase(et.getRedundancy()))
				root.addNotNullValChild(ORDERING_ALGO, "ORDERLOADBALANCING", action);

			root.addNotNullValChild("RedundancyPriorityType", et.getRedundancyPriorityType(), action);

			// XO Change
			root.addChildParam(OrderUtility.getAttribParamInfo(et.getAttribMap(), action));
			
			if(SolutionType.HPBX.equals(et.getSolutionType())) {
				root.addNotNullValChild("ProvisionCategory", "INV_ONLY", action);
				
			}
			
			root.addNotNullValChild("AsClli", voipOrderRequest.getOrderHeader().getAsClli(), action); //adding bs clli.
			
			infos.add(root);
		}
		LOG.info("Exit prepareTblOrderDetailsEntityParamDataForET");
		return infos;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.vz.esap.translation.order.transformer.
	 * EnterpriseTrunkTblOrderDetailsDataTransformer#
	 * prepareTblOrderDetailsEntityParamDataForET(com.vz.esap.translation.entity.
	 * EnterpriseTrunkEntity, java.lang.String)
	 */
	@Override
	public ParamInfo prepareTblOrderDetailsEntityParamDataForET(EnterpriseTrunkEntity et, String action) {

		LOG.info("Enter prepareTblOrderDetailsEntityParamDataForET(et, action)");

		ParamInfo root = new ParamInfo("EnterpriseTrunk", null, action);
		root.addNotNullValChild("EnterpriseTrunkName", et.getBwEtId(), action, ParamInfo.Tag.NAME);
		root.addNotNullValChild("EnterpriseTrunkId", et.getEnterpriseTrunkId(), action);
		root.addNotNullValChild("CustomerId", et.getCustomerId(), action);
		root.addNotNullValChild("MaxRerouteAttempts", et.getMaxRerouteAttempts(), action);
		root.addNotNullValChild("MaxRerouteAttemptsPriority", et.getMaxRerouteAttemptsPriority(), action);
		root.addNotNullValChild("RouteExhaustAction", et.getRouteExhaustAction(), action);
		root.addNotNullValChild("RouteExhaustForwardTN", et.getRouteExhaustForwardTN(), action);
		root.addChildParam(OrderUtility.getAttribParamInfo(et.getAttribMap(), action));
		// XO Chnages
		root.addNotNullValChild("BWEnterpriseId", et.getBwEntId(), action);
		root.addNotNullValChild("BWEnterpriseTrunkId", et.getBwEtId(), action);
		root.addNotNullValChild("EnterpriseTrunkType", et.getEtType(), action);
		root.addNotNullValChild("SignalingDirection", et.getSignalDirection(), action);
		root.addNotNullValChild("RouteExhaustionAction", "NONE", action);
		root.addNotNullValChild("TrunkGroupId", et.getBwTrunkGroupId(), action);
		root.addNotNullValChild(ORDERING_ALGO, et.getOrderingAlgorithm(), action);
		// XO Chnages

		LOG.info("Exit prepareTblOrderDetailsEntityParamDataForET");

		return root;
	}

	public ParamInfo prepareTblOrderDetailsEntityParamDataForET(EnterpriseTrunkEntity enterpriseTrunkEntityPrev,
			EnterpriseTrunkEntity enterpriseTrunkEntity, boolean supp, String action) {

		LOG.info(
				"Enter prepareTblOrderDetailsEntityParamDataForET(enterpriseTrunkEntityPrev, enterpriseTrunkEntity, supp, action)");

		ParamInfo root = new ParamInfo("EnterpriseTrunk", null, action);

		root.addChangeParam("CustomerId", enterpriseTrunkEntityPrev.getCustomerId(),
				enterpriseTrunkEntity.getCustomerId(), supp);
		root.addChangeParam("EnterpriseTrunkName", enterpriseTrunkEntityPrev.getBwEtId(),
				enterpriseTrunkEntity.getBwEtId(), supp);
		root.addChangeParam("EnterpriseTrunkId", enterpriseTrunkEntityPrev.getEnterpriseTrunkId(),
				enterpriseTrunkEntityPrev.getEnterpriseTrunkId(), supp);
		root.addChangeParam("MaxRerouteAttempts", enterpriseTrunkEntityPrev.getMaxRerouteAttempts(),
				enterpriseTrunkEntity.getMaxRerouteAttempts(), supp);
		root.addChangeParam("MaxRerouteAttemptsPriority", enterpriseTrunkEntityPrev.getMaxRerouteAttemptsPriority(),
				enterpriseTrunkEntity.getMaxRerouteAttemptsPriority(), supp);
		root.addChangeParam("RouteExhaustAction", enterpriseTrunkEntityPrev.getRouteExhaustAction(),
				enterpriseTrunkEntity.getRouteExhaustAction(), supp);
		root.addChangeParam("RouteExhaustForwardTN", enterpriseTrunkEntityPrev.getRouteExhaustForwardTN(),
				enterpriseTrunkEntity.getRouteExhaustForwardTN(), supp);

		root.addChangeParam("BWEnterpriseId", enterpriseTrunkEntityPrev.getBwEntId(),
				enterpriseTrunkEntity.getBwEntId(), supp);
		root.addChangeParam("BWEnterpriseTrunkId", enterpriseTrunkEntityPrev.getBwEtId(),
				enterpriseTrunkEntity.getBwEtId(), supp);
		root.addChangeParam("EnterpriseTrunkType", enterpriseTrunkEntityPrev.getEtType(),
				enterpriseTrunkEntity.getEtType(), supp);
		root.addChangeParam("SignalingDirection", enterpriseTrunkEntityPrev.getSignalDirection(),
				enterpriseTrunkEntity.getSignalDirection(), supp);
		root.addChangeParam("RouteExhaustionAction", "NONE", "NONE", supp); // TODO Verify this
		root.addChangeParam("TrunkGroupId", enterpriseTrunkEntityPrev.getBwTrunkGroupId(),
				enterpriseTrunkEntity.getBwTrunkGroupId(), supp);
		root.addChangeParam(ORDERING_ALGO, enterpriseTrunkEntityPrev.getOrderingAlgorithm(),
				enterpriseTrunkEntity.getOrderingAlgorithm(), supp);
		/*root.addChangeParam("RedundancyPriorityType", enterpriseTrunkEntityPrev.getRedundancyPriorityType(),
				enterpriseTrunkEntity.getRedundancyPriorityType(), supp);*/
				
		if(!enterpriseTrunkEntity.getSignalDirection().equals(enterpriseTrunkEntity.getSignalDirection())) {
			LOG.info("ET_BS_CHANGE = Y");
			
			root.addNotNullValChild("ET_BS_CHANGE", "Y", "n");
		}else {
			LOG.info("ET_BS_CHANGE = N");
			root.addNotNullValChild("ET_BS_CHANGE", "N", "n");
		}
		
		LOG.info("Exit prepareTblOrderDetailsEntityParamDataForET");

		return root;

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.vz.esap.translation.order.transformer.
	 * EnterpriseTrunkTblOrderDetailsDataTransformer#
	 * prepareTblOrderDetailsHeaderParamData(com.vz.esap.translation.order.model.
	 * Order, com.vz.esap.translation.entity.EnterpriseTrunkEntity, boolean)
	 */
	@Override
	public ParamInfo prepareTblOrderDetailsHeaderParamData(Order order, EnterpriseTrunkEntity oldETEntity, boolean supp)
			throws TranslatorException {

		LOG.info("Entered - prepareTblOrderDetailsHeaderParamData(order, oldETEntity, supp)");
		ParamInfo etParams = null;
		String action = null;

		try {

			int oldVersion = Integer.parseInt(order.getOrderHeader().getOrderVersion()) + 1;
			action = order.getOrderHeader().getOrderType();

			etParams = new ParamInfo("Header", null, action);
			etParams.addChangeParam("OrderNumber", order.getOrderHeader().getOrderNumber(),
					order.getOrderHeader().getOrderNumber(), supp);
			etParams.addChangeParam("EnvOrderId", order.getOrderHeader().getEnvOrderId(), order.getOrderHeader().getEnvOrderId(),
					supp);
			etParams.addChangeParam("MasterOrderNumber", order.getOrderHeader().getMasterOrderNumber(),
					order.getOrderHeader().getMasterOrderNumber(), supp);
			etParams.addChangeParam("OrderVersion", order.getOrderHeader().getOrderVersion(), order.getOrderHeader().getOrderVersion(), supp);
			etParams.addChangeParam("TransactionId", order.getOrderHeader().getTransactionId(),
					order.getOrderHeader().getTransactionId(), supp);

			if (order.getCustomerEntity() != null) {
				etParams.addChangeParam(REGION, order.getOrderHeader().getRegion(), order.getOrderHeader().getRegion(),
						supp);
			} else if (order.getEnterpriseTrunks() != null) {
				etParams.addChangeParam(REGION, order.getOrderHeader().getRegion(), order.getOrderHeader().getRegion(),
						supp);
			}

			etParams.addChangeParam("MinorOrderType", order.getOrderHeader().getMinorOrderType(),
					order.getOrderHeader().getMinorOrderType(), supp);
			etParams.addChangeParam("CentrexType", order.getOrderHeader().getCentrexType(),
					order.getOrderHeader().getCentrexType(), supp);
			etParams.addChangeParam("ServiceType", order.getOrderHeader().getServiceType(),
					order.getOrderHeader().getServiceType(), supp);
			etParams.addChangeParam("OriginatingSystem", order.getOrderHeader().getOriginatingSystem(),
					order.getOrderHeader().getOriginatingSystem(), supp);
			etParams.addChangeParam("InterfaceSystem", order.getOrderHeader().getInterfaceSystem(),
					order.getOrderHeader().getInterfaceSystem(), supp);
			etParams.addChangeParam("OrderType",
					EsapEnum.OrderType.getValue(order.getOrderHeader().getOrderType().charAt(0)),
					EsapEnum.OrderType.getValue(order.getOrderHeader().getOrderType().charAt(0)), supp);
			etParams.addChangeParam("SuppType", order.getOrderHeader().getSuppType(), order.getOrderHeader().getSuppType(), supp);
			etParams.addChangeParam("OrderClassify", order.getOrderHeader().getFunctionCode(),
					order.getOrderHeader().getFunctionCode(), supp);

			if (order.getOrderHeader().getDueDate() != null) {
				SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
				Calendar calendar = GregorianCalendar.getInstance();
				calendar.setTime(format.parse(order.getOrderHeader().getDueDate().toString()));
				Object dueDate = calendar.getTime();
				etParams.addNotNullValChild("DueDate", dueDate, action);
			}

			if (order.getLocation() != null && order.getLocation().getCustomerId() != null) {
				LOG.info("Customer Id = {}", order.getLocation().getCustomerId());
				etParams.addChangeParam(CUSTOMER_ID, order.getLocation().getCustomerId(),
						order.getLocation().getCustomerId(), supp);
			} else if (order.getOrderHeader().getCustomerId() != null) {
				LOG.info("Customer Id = {}", order.getOrderHeader().getCustomerId());
				etParams.addChangeParam(CUSTOMER_ID, order.getOrderHeader().getCustomerId(),
						order.getOrderHeader().getCustomerId(), supp);
			}

			etParams.addChangeParam(LOCATION_ID, order.getOrderHeader().getLocationId(),
					order.getOrderHeader().getLocationId(), supp);

			// root.addNotNullValChild(BS_APP_SERVER, order.getLocation().getBsAppServer(),
			// action); Fix This
			etParams.addChangeParam("OrderProTIN", order.getOrderHeader().getOrderProTIN(),
					order.getOrderHeader().getOrderProTIN(), supp);
			etParams.addChangeParam("IOrderTIN", order.getOrderHeader().getiOrderTIN(),
					order.getOrderHeader().getiOrderTIN(), supp);
			etParams.addChangeParam("TINVersion", order.getOrderHeader().getTinVersion(),
					order.getOrderHeader().getTinVersion(), supp);
			etParams.addChangeParam("TransitionFlag", order.getOrderHeader().isTransitionFlag() ? "Y" : "N",
					order.getOrderHeader().isTransitionFlag() ? "Y" : "N", supp);
			etParams.addChangeParam("Priority", order.getOrderHeader().getPriority(),
					order.getOrderHeader().getPriority(), supp);
			if (order.getOrderHeader().getAttribMap() != null) {
				etParams.addChildParam(OrderUtility.getAttribParamInfo(order.getOrderHeader().getAttribMap(), action));
			}
			if (order.getOrderHeader().getOrderCreatedBy() != null)
				etParams.addChangeParam("OrderCreatedBy", order.getOrderHeader().getOrderCreatedBy(),
						order.getOrderHeader().getOrderCreatedBy(), supp);
			if (order.getOrderHeader().isHasBulkOrder()) {
				etParams.addChangeParam("BULK", "Y", "Y", supp);
			}
			if (order.getOrderHeader().getHotCutIndicator() != null) {
				etParams.addChangeParam(HOT_CUT_IND, "Y", "Y", supp);
			}
			if (order.getOrderHeader().getCDDDIndicator() != null) {
				etParams.addChangeParam(CDD_IND, "Y", "Y", supp);
			}
			if (order.getOrderHeader().getSolutionType() != null) {
				etParams.addChangeParam("SolutionType", order.getOrderHeader().getSolutionType().toString(),
						order.getOrderHeader().getSolutionType().toString(), supp);
			}
			if (order.getOrderHeader().getAuthFeatureType() != null) {
				etParams.addChangeParam("AuthFeatureType", order.getLocation().getAuthFeatureType().toString(),
						order.getLocation().getAuthFeatureType().toString(), supp);
			}
			if (order.getOrderHeader().getGchId() != null) {
				LOG.info("order.getOrderHeader().getGchId(): {}", order.getOrderHeader().getGchId());
				etParams.addChangeParam("GCHId", order.getOrderHeader().getGchId(), order.getOrderHeader().getGchId(),
						supp);
			}
		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new TranslatorException(ErrorCode.TRANSFORMER_FAILURE,
					"Exception occured in prepareTblOrderDetailsEntityParamDataForCustomer");
		}

		LOG.info("Exit prepareTblOrderDetailsHeaderParamData");

		return etParams;
	}

	/**
	 * 
	 * @param enrichedETOrder
	 * @param change
	 * @param object
	 * @return
	 */
	public ArrayList<ParamInfo> prepareTblOrderDetailsEntityParamDataForET(List<EnterpriseTrunkEntity> enrichedETOrder,
			boolean change, Object object) {
		LOG.info("Enter prepareTblOrderDetailsEntityParamDataForET(ets, action)");

		ArrayList<ParamInfo> infos = new ArrayList<>();
		for (EnterpriseTrunkEntity et : enrichedETOrder) {
			EnterpriseTrunkEntity changedET = et.getEnterpriseTrunkEntity() != null ? et.getEnterpriseTrunkEntity()
					: new EnterpriseTrunkEntity();

			ParamInfo root = new ParamInfo("EnterpriseTrunk", null, booleanToStr(change));
			root.addChangeParam("EnterpriseTrunkName", changedET.getBwEtId(), et.getBwEtId(), change,
					ParamInfo.Tag.NAME);
			root.addChangeParam("EnterpriseTrunkId", changedET.getEnterpriseTrunkId(), et.getEnterpriseTrunkId(),
					change);
			root.addChangeParam("CustomerId", changedET.getCustomerId(), et.getCustomerId(), change);
			root.addChangeParam("MaxRerouteAttempts", changedET.getMaxRerouteAttempts(), et.getMaxRerouteAttempts(),
					change);
			root.addChangeParam("MaxRerouteAttemptsPriority", changedET.getMaxRerouteAttemptsPriority(),
					et.getMaxRerouteAttemptsPriority(), change);
			root.addChangeParam("RouteExhaustAction", changedET.getRouteExhaustAction(), et.getRouteExhaustAction(),
					change);
			root.addChangeParam("RouteExhaustForwardTN", changedET.getRouteExhaustForwardTN(),
					et.getRouteExhaustForwardTN(), change);
			// XO Change
			root.addChangeParam("BWEnterpriseId", changedET.getBwEntId(), et.getBwEntId(), change);
			root.addChangeParam("BWEnterpriseTrunkId", changedET.getBwEtId(), et.getBwEtId(), change);
			root.addChangeParam("EnterpriseTrunkType", changedET.getEtType(), et.getEtType(), change);
			root.addChangeParam("SignalingDirection", changedET.getSignalDirection(), et.getSignalDirection(), change);
			root.addChangeParam("RouteExhaustionAction", "NONE", "NONE", change);
			root.addChangeParam("TrunkGroupId", changedET.getBwTrunkGroupId(), et.getBwTrunkGroupId(), change);
			root.addChangeParam("Region", changedET.getRegion(), et.getRegion(), change);

			if ("Priority".equalsIgnoreCase(et.getRedundancy()))
				root.addChangeParam(ORDERING_ALGO, "OVERFLOW", "OVERFLOW", change);
			else if ("None".equalsIgnoreCase(et.getRedundancy()))
				root.addChangeParam(ORDERING_ALGO, "OVERFLOW", "OVERFLOW", change);
			else if ("Load Sharing".equalsIgnoreCase(et.getRedundancy()))
				root.addChangeParam(ORDERING_ALGO, "ORDERLOADBALANCING", "ORDERLOADBALANCING", change);

			root.addChangeParam("RedundancyPriorityType", changedET.getRedundancyPriorityType(),
					et.getRedundancyPriorityType(), change);
			
			root.addChangeParam("AsClli", et.getAsClli(), et.getAsClli(), change); //add broadsoft clli.
						
			infos.add(root);
		}

		LOG.info("Exit prepareTblOrderDetailsEntityParamDataForET");
		return infos;
	}

	/**
	 * @param bool
	 * @return boolean
	 */
	public static String booleanToStr(Boolean bool) {
		if (bool == null)
			return null;
		else
			return bool ? "C" : "N";
	}
}
