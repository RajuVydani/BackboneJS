package com.vz.esap.translation.dao.repository;

import java.util.HashMap;
import java.util.List;

import com.vz.esap.translation.dao.model.TblOrderPrioritySettings;

public interface CustomTblOrderPrioritySettingsMapper extends
		TblOrderPrioritySettingsMapper {

	List<TblOrderPrioritySettings> getOrderPrioritySettings(
			HashMap<String, String> ordPrioCols);

}