package com.vz.esap.translation.order.model.request;

public class ChangeManagement {

	private ChangedElement[] ChangedElement;

	private String ChangeSummaryVersion;

	public ChangedElement[] getChangedElement() {
		return ChangedElement;
	}

	public void setChangedElement(ChangedElement[] ChangedElement) {
		this.ChangedElement = ChangedElement;
	}

	public String getChangeSummaryVersion() {
		return ChangeSummaryVersion;
	}

	public void setChangeSummaryVersion(String ChangeSummaryVersion) {
		this.ChangeSummaryVersion = ChangeSummaryVersion;
	}

	public String toString() {
		return "ClassPojo [ChangedElement = " + ChangedElement + ", ChangeSummaryVersion = " + ChangeSummaryVersion
				+ "]";
	}
}