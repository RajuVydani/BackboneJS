package com.vz.esap.translation.order.parser;

import static java.util.Arrays.stream;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.vz.esap.translation.dao.repository.CustomCustomerMapper;
import com.vz.esap.translation.entity.DeviceEntity;
import com.vz.esap.translation.entity.Entity.GroupType;
import com.vz.esap.translation.enums.EsapEnum;
import com.vz.esap.translation.enums.EsapEnum.ChangeType;
import com.vz.esap.translation.enums.EsapEnum.SolutionType;
import com.vz.esap.translation.exception.TranslatorException;
import com.vz.esap.translation.order.entity.identifier.util.EntityIdentifireUtil;
import com.vz.esap.translation.order.model.request.ChangeManagement;
import com.vz.esap.translation.order.model.request.ChangedElement;
import com.vz.esap.translation.order.model.request.ConvergedService;
import com.vz.esap.translation.order.model.request.Feature;
import com.vz.esap.translation.order.model.request.Specification;
import com.vz.esap.translation.order.model.request.VOIPOrderRequest;
import com.vz.esap.translation.order.service.helper.OrderServiceHelper;

import EsapEnumPkg.RivSbcEnum;
import EsapEnumPkg.VzbVoipEnums.IPVersionEnum;
import reactor.util.CollectionUtils;

/**
 * @author kalagsu
 *
 */
@Component
public class DeviceOrderParserImpl implements DeviceOrderParser {
	
	private static final Logger LOG = LoggerFactory.getLogger(DeviceOrderParserImpl.class);
	
	@Autowired
	private EntityIdentifireUtil entityIdentifireUtil;

	@Autowired
	private CustomCustomerMapper customCustomerMapper;	

	@Autowired
	private OrderServiceHelper orderServiceHelperImpl;

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.vz.esap.translation.order.parser.DeviceOrderParser#parseDeviceOrder(com.
	 * vz.esap.translation.order.model.request.VOIPOrderRequest)
	 */
	@SuppressWarnings("unused")
	@Override
	public ArrayList<DeviceEntity> parseDeviceOrder(VOIPOrderRequest voipOrderRequest)
			throws TranslatorException, ParseException {

		LOG.info("Entered - parseDeviceOrder");
		DeviceEntity device = null;
		ArrayList<DeviceEntity> deviceList = null;
		ConvergedService convergedService = null;
		Feature[] features = null;
		List<Feature> deviceFeatures = null;
		Specification[] deviceSpecs = null;
		String stripCcInd = null;
		String huntStrategy = null;
		String huntStrEnum = null;
		String ipv6Enabled = null;
		boolean isCustProvEquip = false;
		String signalingDirection = null;
		String bwDeviceId = null;
		List<Feature>  nativeTrunkTypeFeatures = null;
		String nativeTrunkFeatures = null;
		boolean isLine = false;
		DeviceEntity deviceMetaData = null;
		List<Feature>  trunkLinePriLineFeatures = null;
		String trunkInstanceIdChanged = null;
		List<String> trunkInstanceIdChangedList = null;
		List<Feature> deviceLocFeatures = null;
	
		try {
			deviceList = new ArrayList<DeviceEntity>();
			convergedService = voipOrderRequest.getConvergedService();
			LOG.debug("DeviceEntity - parseTrunkGroup: convergedService: {}", convergedService);

			features = convergedService.getFeature();
			
			nativeTrunkTypeFeatures = stream(voipOrderRequest.getConvergedService().getFeature())
					.filter(trunkFeature -> "FET_PRILIN".equalsIgnoreCase(trunkFeature.getCode())
							|| "FET_XO_TRULIN".equalsIgnoreCase(trunkFeature.getCode())
							|| "FET_LIN".equalsIgnoreCase(trunkFeature.getCode())
							|| "FET_PRI".equalsIgnoreCase(trunkFeature.getCode())
							|| "FET_XO_TRUON".equalsIgnoreCase(trunkFeature.getCode()))
					.collect(Collectors.toList());

			//Start:PRI/LIN,TRU/LIN Fix
			
			trunkLinePriLineFeatures = stream(voipOrderRequest.getConvergedService().getFeature())
					.filter(trunkFeature -> "FET_PRILIN".equalsIgnoreCase(trunkFeature.getCode())
							|| "FET_XO_TRULIN".equalsIgnoreCase(trunkFeature.getCode()))
					.collect(Collectors.toList());
			
			//End:PRI/LIN,TRU/LIN Fix
			
			//Start: Device Change Fix:
			if (voipOrderRequest.getChangeManagement() != null) {
				for (ChangeManagement changeManagement : voipOrderRequest.getChangeManagement()) {
					trunkInstanceIdChangedList = new ArrayList<>();
					for (ChangedElement changedElement : changeManagement.getChangedElement()) {
						if ("ADDED".equalsIgnoreCase(changedElement.getChangeType())
								&& "FET_XO_TRU".equalsIgnoreCase(changedElement.getFeatureCode())) {
							trunkInstanceIdChanged = changedElement.getFeatureInstanceId();
							trunkInstanceIdChangedList.add(trunkInstanceIdChanged);
							LOG.info("TrunkInstanceIdChanged = {}", trunkInstanceIdChanged);
						}
					}
				}
			}
			
			//End: Device Change Fix:
			
			
			for (Feature feature : features) {

				LOG.debug("DeviceEntity - parseDeviceOrder: voipOrderRequest.getOrderHeader().getOrderType():"
						+ voipOrderRequest.getOrderHeader().getOrderType());

				deviceFeatures = stream(voipOrderRequest.getConvergedService().getFeature())
						.filter(deviceFeature -> deviceFeature.getCode().equalsIgnoreCase("EFET_VOIP_DEVICE_LVL")
								|| deviceFeature.getCode().equalsIgnoreCase("FET_DE")
								|| deviceFeature.getCode().equalsIgnoreCase("FET_DE_LOC"))
						.collect(Collectors.toList());
				
				deviceLocFeatures = stream(voipOrderRequest.getConvergedService().getFeature())
						.filter(deviceFeature -> deviceFeature.getCode().equalsIgnoreCase("FET_DE_LOC"))
						.collect(Collectors.toList());

				deviceSpecs = deviceFeatures.get(0).getSpecification();
				
				int index = 0;

				if (("FET_XO_TRU".equalsIgnoreCase(feature.getCode())
						|| "FET_XO_TRU_CON".equalsIgnoreCase(feature.getCode())
						|| "FET_XO_TRU_CON_LINE_LOC".equalsIgnoreCase(feature.getCode())
						|| "FET_HPBX_TRU".equalsIgnoreCase(feature.getCode()))
						&& ("I".equalsIgnoreCase(voipOrderRequest.getOrderHeader().getOrderType()) 
							|| "C".equalsIgnoreCase(voipOrderRequest.getOrderHeader().getOrderType())))
					{

					device = new DeviceEntity();
					device.setAsClli(voipOrderRequest.getOrderHeader().getAsClli()); //add broadsoft clli.
					device.setAuthFeatureType(orderServiceHelperImpl.getAuthFeatureType(voipOrderRequest));
					//device.setTransport(TransportProtocol.UDP.getValue());
					device.setCustomerId(voipOrderRequest.getOrderHeader().getEnterpriseId());
					if ("FET_XO_TRU".equalsIgnoreCase(feature.getCode())
							|| "FET_XO_TRU_CON".equalsIgnoreCase(feature.getCode())
							|| "FET_XO_TRU_CON_LINE_LOC".equalsIgnoreCase(feature.getCode())
							|| "FET_HPBX_TRU".equalsIgnoreCase(feature.getCode()))
						device.setTrunkId(feature.getInstanceId());

					if (deviceFeatures.get(0).getInstanceId() != null) {
						device.setDeviceMapId(new Long(deviceFeatures.get(0).getInstanceId()));
					}
					if (deviceFeatures.get(0).getActionCode() != null) {
						String entityAction = deviceFeatures.get(0).getActionCode();
						if ("ADD".equalsIgnoreCase(entityAction)) {
							device.setAction(EsapEnum.OrderAction.ADD);
						}
					}

					for (Specification specification : deviceSpecs) {

						if ("ESP_LOGICAL_DEVICE_NAME".equalsIgnoreCase(specification.getCode())) {
							device.setDeviceName(specification.getValue());
						}
						if ("ESP_CPE_DEVICE_ID".equalsIgnoreCase(specification.getCode())) {
							device.setDeviceNameId(specification.getValue());
						}
						if ("ESP_IP_ADDRESS_PRI".equalsIgnoreCase(specification.getCode())) {
							device.setAddress(specification.getValue());
						}
						if ("SP_VOIP_STRIP_COUN_CODE_INDCTR".equalsIgnoreCase(specification.getCode())) {
							stripCcInd = specification.getValue();
							if (stripCcInd != null) {
								if (stripCcInd.equals("Y") || stripCcInd.equals("Yes")) {
									device.setStripCcInd("Y");
								}
								if (stripCcInd.equals("N") || stripCcInd.equals("No")) {
									device.setStripCcInd("N");
								}
							}

						}

						if ("ESP_TERM_CALL_INDICATOR".equalsIgnoreCase(specification.getCode())) {
							device.setTermCallingInd(specification.getValue());
						}

						if ("ESP_CPE_DEVICE_CODEC".equalsIgnoreCase(specification.getCode())) {
							device.setCodec(specification.getValue());
						}

						if ("ESP_DEVICE_SCREENED_TN".equalsIgnoreCase(specification.getCode())) {
							device.setSTN(specification.getValue());
						}
						
						if ("SP_VOIP_FAIL_OVER_STRATEGY".equalsIgnoreCase(specification.getCode())) {
							huntStrategy = specification.getValue();
							if (huntStrategy != null) {
								if (huntStrategy.equalsIgnoreCase("Hunt")) {
									huntStrEnum = RivSbcEnum.HuntStrategy.acronym(RivSbcEnum.HuntStrategy.HUNT);
								} else if (huntStrategy != null && (huntStrategy.equalsIgnoreCase("Round Robin")
										|| huntStrategy.equalsIgnoreCase("RoundRobin"))) {
									huntStrEnum = RivSbcEnum.HuntStrategy.acronym(RivSbcEnum.HuntStrategy.ROUNDROBIN);
								}
							}
							if (huntStrEnum != null) {
								device.setGwyHunt(huntStrEnum);
							} else {
								throw new TranslatorException(TranslatorException.ErrorCode.INVALID_XML,
										"Invalid Fail Over Strategy");
							}
						}

						if ("ESP_FQDN".equalsIgnoreCase(specification.getCode())) {
							device.setGwyFqdn(specification.getValue());
						}

						if ("SP_VOIP_IP_VERSIONING".equalsIgnoreCase(specification.getCode())) {
							ipv6Enabled = specification.getValue();
							if (ipv6Enabled != null) {
								if (ipv6Enabled.equalsIgnoreCase("IPv6") || ipv6Enabled.equalsIgnoreCase("Yes")
										|| ipv6Enabled.equalsIgnoreCase("Y")) {
									device.setIpVersion(IPVersionEnum.IPv6);
								} else if (ipv6Enabled.equalsIgnoreCase("IPv4") || ipv6Enabled.equalsIgnoreCase("No")
										|| ipv6Enabled.equalsIgnoreCase("N")) {
									device.setIpVersion(IPVersionEnum.IPv4);
								}
							} else {
								device.setIpVersion(IPVersionEnum.IPv4);
							}
						} else {
							device.setIpVersion(IPVersionEnum.IPv4);
						}

						if ("ESP_IP_ADDRESS_SEC".equalsIgnoreCase(specification.getCode())) {
							device.setSecAddress(specification.getValue());
						}
						// cpe device

						if ("ESP_IS_CUST_PROV_EQUIP".equalsIgnoreCase(specification.getCode())) {
							isCustProvEquip = "Yes".equalsIgnoreCase(specification.getValue()) ? true : false;
						}

						// XOO
						if ("SP_TYPE_OF_FEATURE".equalsIgnoreCase(specification.getCode()))
							device.setFeatureType(specification.getValue());
						if ("SP_ZERO_SUP".equalsIgnoreCase(specification.getCode()))
							device.setZeroSupp(specification.getValue());
						if ("SP_BILL_FLAG".equalsIgnoreCase(specification.getCode()))
							device.setBillFlag(specification.getValue());
						if ("SP_PORT".equalsIgnoreCase(specification.getCode()))
							device.setLinePort(specification.getValue());
					}

					if (feature != null && ("FET_XO_TRU".equalsIgnoreCase(feature.getCode())
							|| "FET_XO_TRU_CON".equalsIgnoreCase(feature.getCode()))
							|| "FET_HPBX_TRU".equalsIgnoreCase(feature.getCode())) {
						for (Specification trunkSpec : feature.getSpecification()) {
							if ("SP_XO_SIG".equalsIgnoreCase(trunkSpec.getCode())) {
								if ("2 Way".equalsIgnoreCase(trunkSpec.getValue())) {
									signalingDirection = EsapEnum.SignalingDirection.TWO_WAY.toString();
									device.setTrunkType(GroupType.TWO_WAY);
									
								} else if ("Inbound".equalsIgnoreCase(trunkSpec.getValue())) {
									signalingDirection = EsapEnum.SignalingDirection.INBOUND.toString();
									device.setDeviceMapId(
											Long.valueOf(customCustomerMapper.getDeviceMapIdSeqNextVal()));
									device.setTrunkType(GroupType.INBOUND);
									
								}
								LOG.info("SignalingDirection In Parser : {}", signalingDirection);
								device.setSigDir(EsapEnum.SignalingDirection.valueOf(signalingDirection));
							}							
						}
					}
					
					//Start:PRI/LIN,TRU/LIN Fix					
					
					if(!CollectionUtils.isEmpty(trunkLinePriLineFeatures)) {						
						LOG.info("The Type of Flex is = {}", trunkLinePriLineFeatures.get(0).getCode());
						
						if ("FET_XO_TRU_CON_LINE_LOC".equalsIgnoreCase(feature.getCode())
								&& !CollectionUtils.isEmpty(deviceLocFeatures)) {
							LOG.info("Creating Device Map Id for Line part of TRU/PRI/LINE for FET_DEV_LOC");
							
							device.setDeviceMapId(Long.valueOf(deviceLocFeatures.get(0).getInstanceId()));
							
						} else if ("FET_XO_TRU_CON_LINE_LOC".equalsIgnoreCase(feature.getCode())) {
							LOG.info("Creating Device Map Id for Line part of TRU/PRI/LINE");
							
							device.setDeviceMapId(Long.valueOf(customCustomerMapper.getDeviceMapIdSeqNextVal()));
							
						}
						
						LOG.info("For Flex Type {} Device Map Id is {}", trunkLinePriLineFeatures.get(0).getCode(),
								device.getDeviceMapId());
					}
					 
					//End:PRI/LIN,TRU/LIN Fix
					
					if(!CollectionUtils.isEmpty(nativeTrunkTypeFeatures)) 
						nativeTrunkFeatures = nativeTrunkTypeFeatures.get(0).getCode();
					 else 
						 nativeTrunkFeatures = "NONE";
					
					isLine = "FET_XO_TRU_CON_LINE_LOC".equalsIgnoreCase(feature.getCode());
					
					if(!isLine && Arrays.asList("FET_PRILIN", "FET_PRI").contains(nativeTrunkFeatures)) {
						device.setTrunkType(GroupType.PRI_DID);
						device.setSigDir(EsapEnum.SignalingDirection.TWO_WAY);
					}else if(!isLine && Arrays.asList("FET_XO_TRULIN", "FET_XO_TRUON").contains(nativeTrunkFeatures)) {
						device.setTrunkType(GroupType.NON_PRI_DID);
						device.setSigDir(EsapEnum.SignalingDirection.TWO_WAY);
					}else if(isLine) {
						device.setTrunkType(GroupType.LINE);
					}
						
					if (Arrays.asList(SolutionType.ESIP_ESL, SolutionType.ESIP_EBL)
							.contains(voipOrderRequest.getOrderHeader().getSolutionType())) {
						bwDeviceId = entityIdentifireUtil.createBwDeviceId(deviceFeatures.get(0).getInstanceId(),
								signalingDirection != null ? signalingDirection : null);
						
					} else {						
						bwDeviceId = entityIdentifireUtil.createBwDeviceId(device.getDeviceMapId().toString(),
								signalingDirection != null ? signalingDirection : null);
						
					}
					device.setBwDeviceId(bwDeviceId);
					device.setDeviceName(bwDeviceId);
					
					
					//Start: Device Fix 
					
					deviceMetaData = orderServiceHelperImpl.getOrderCpeDeviceDetails(deviceFeatures.get(0),
							voipOrderRequest.getOrderHeader().getSolutionType(), device.getTrunkType());
					
					device.setDeviceType(deviceMetaData.getDeviceType());
					device.setIpAddress(deviceMetaData.getIpAddress());
					device.setTransportProtocol(deviceMetaData.getTransportProtocol());
					device.setPort(deviceMetaData.getPort());
					device.setProtocol(deviceMetaData.getProtocol());
					device.setDeviceTypeId(deviceMetaData.getDeviceTypeId());
					device.setDeviceId(deviceMetaData.getDeviceTypeId());
					device.setTransport(deviceMetaData.getTransportProtocol().toString());
					//End: Device Fix 
					//		Device esbcSignalingip
					List<Feature> locFeatures = null;
					locFeatures = stream(voipOrderRequest.getConvergedService().getFeature())
							.filter(locFeature -> "FET_LOC_LVL".equalsIgnoreCase(locFeature.getCode()))
							.collect(Collectors.toList());
					LOG.info("In -  Device Location Related Feature Size : {}", locFeatures.size());

					if(null != locFeatures && locFeatures.size() > 0) {
						for (Specification specification : locFeatures.get(0).getSpecification()) {
							if ("SP_XO_ESBC_IP".equalsIgnoreCase(specification.getCode())) {
								device.setCpeIpAddress( specification.getValue());
							}
						}
					}
					//Start: Device Change Fix:				
					
					if ("C".equalsIgnoreCase(voipOrderRequest.getOrderHeader().getOrderType())) {
						
						if (!CollectionUtils.isEmpty(trunkInstanceIdChangedList)) {
							LOG.info("Trunk Present in Change Management");
							
							for (String trunkChangedId : trunkInstanceIdChangedList) {
								if (feature.getInstanceId().equalsIgnoreCase(trunkChangedId)) {
									LOG.info("Trunk Instance Id Included In ADDED Change Management = {} And Device Id = {}",
											feature.getInstanceId(), device.getDeviceMapId());
									// Do Nothing

								} else {
									LOG.info("Trunk Instance Id NOT Included In Change Management = {} And Device Id = {}",
											feature.getInstanceId(), device.getDeviceMapId());

									DeviceEntity changeDevice = parseDeviceChangeOrder(voipOrderRequest);
									
									if(changeDevice.getDeviceMapId() == null) {
										changeDevice.setDeviceMapId(device.getDeviceMapId());
									}
									
									device.setDeviceEntity(changeDevice);
								}
							}
						} else {
							LOG.info("No Trunk in Change Management and Trunk Instance Id = {}",
									feature.getInstanceId());

							DeviceEntity changeDevice = parseDeviceChangeOrder(voipOrderRequest);							
							
							if(changeDevice.getDeviceMapId() == null) {
								changeDevice.setDeviceMapId(device.getDeviceMapId());
							}
							
							device.setDeviceEntity(changeDevice);
						}
					}				
					//End: Device Change Fix:
					
					deviceList.add(device);
				}
			}
		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new TranslatorException(TranslatorException.ErrorCode.ORDER_NOT_SAVABLE,
					"Unexpected Error Occured while Parsing Device Order");
		}
		LOG.info("Exited - parseDeviceOrder");
		return deviceList;

	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.vz.esap.translation.order.parser.DeviceOrderParser#parseDeviceChangeOrder(com.
	 * vz.esap.translation.order.model.request.VOIPOrderRequest)
	 */
	public DeviceEntity parseDeviceChangeOrder(VOIPOrderRequest voipOrderRequest) throws TranslatorException{

		LOG.info("Entered - parseDeviceChangeOrder");
		
		ChangeManagement[] changeManagements = voipOrderRequest.getChangeManagement();

		if (changeManagements == null) {
			// TODO: Logic for the ADD
			return null;
		}

		DeviceEntity chanceDevice = new DeviceEntity();
		chanceDevice.setLocationId(voipOrderRequest.getConvergedService().getID());		

		for (ChangeManagement changeManagement : changeManagements) {

			ChangedElement[] changeElements = changeManagement.getChangedElement();

			if (changeElements != null && changeElements.length > 0) {
				LOG.info("Entered - parseDeviceChangeOrder For Each ChangeElement");
				
				for (ChangedElement changedElement : changeElements) {

					List<Feature> deviceFeature = stream(voipOrderRequest.getConvergedService().getFeature())
							.filter(feature -> "EFET_VOIP_DEVICE_LVL".equalsIgnoreCase(feature.getCode()))
							.collect(Collectors.toList());

					List<Feature> deFeature = stream(voipOrderRequest.getConvergedService().getFeature())
							.filter(feature -> "FET_DE".equalsIgnoreCase(feature.getCode())
									|| "FET_DE_LOC".equalsIgnoreCase(feature.getCode()))
							.collect(Collectors.toList());

					List<Feature> xoTruFeature = stream(voipOrderRequest.getConvergedService().getFeature())
							.filter(feature -> "FET_XO_TRU".equalsIgnoreCase(feature.getCode()))
							.collect(Collectors.toList());

					List<Feature> xoTruConFeature = stream(voipOrderRequest.getConvergedService().getFeature())
							.filter(feature -> "FET_XO_TRU_CON".equalsIgnoreCase(feature.getCode()))
							.collect(Collectors.toList());

					List<Feature> xoTruConLineLocFeature = stream(voipOrderRequest.getConvergedService().getFeature())
							.filter(feature -> "FET_XO_TRU_CON_LINE_LOC".equalsIgnoreCase(feature.getCode()))
							.collect(Collectors.toList());

					if (!deviceFeature.isEmpty() && deviceFeature.get(0).getCode().equalsIgnoreCase(changedElement.getFeatureCode()) && deviceFeature
							.get(0).getInstanceId().equalsIgnoreCase(changedElement.getFeatureInstanceId())) {

						if (changedElement.getChangeType() != null
								&& ChangeType.CHANGED.toString().equalsIgnoreCase(changedElement.getChangeType())
								&& changedElement.getSpecificationCode() != null) {

							createChangedDeviceEntity(chanceDevice, changedElement.getSpecificationCode(),
									changedElement.getNewValue());

						}

					} else if (!deFeature.isEmpty() && deFeature.get(0).getCode().equalsIgnoreCase(changedElement.getFeatureCode())
							&& deFeature.get(0).getInstanceId()
									.equalsIgnoreCase(changedElement.getFeatureInstanceId())) {
						if (changedElement.getChangeType() != null
								&& ChangeType.CHANGED.toString().equalsIgnoreCase(changedElement.getChangeType())
								&& changedElement.getSpecificationCode() != null) {

							createChangedDeviceEntity(chanceDevice, changedElement.getSpecificationCode(),
									changedElement.getNewValue());

						}
					} else if (!xoTruFeature.isEmpty() &&  xoTruFeature.get(0).getCode().equalsIgnoreCase(changedElement.getFeatureCode()) && xoTruFeature
							.get(0).getInstanceId().equalsIgnoreCase(changedElement.getFeatureInstanceId())) {
						//Start: Device Change Fix: Niladri 1/24 : Do this for all
						
						for (Feature truFeat : xoTruFeature) {
							if (truFeat.getCode().equalsIgnoreCase(changedElement.getFeatureCode()) && truFeat
									.getInstanceId().equalsIgnoreCase(changedElement.getFeatureInstanceId())) {
								LOG.info("Inside xoTruFeature For Enriching Device Spec");
								if (changedElement.getChangeType() != null
										&& ChangeType.CHANGED.toString().equalsIgnoreCase(changedElement.getChangeType())
										&& changedElement.getSpecificationCode() != null) {

									createChangedDeviceEntity(chanceDevice, changedElement.getSpecificationCode(),
											changedElement.getNewValue());

								}
							}
						}
					} else if (!xoTruConFeature.isEmpty() &&  xoTruConFeature.get(0).getCode().equalsIgnoreCase(changedElement.getFeatureCode())
							&& xoTruConFeature.get(0).getInstanceId()
									.equalsIgnoreCase(changedElement.getFeatureInstanceId())) {
						if (changedElement.getChangeType() != null
								&& ChangeType.CHANGED.toString().equalsIgnoreCase(changedElement.getChangeType())
								&& changedElement.getSpecificationCode() != null) {

							createChangedDeviceEntity(chanceDevice, changedElement.getSpecificationCode(),
									changedElement.getNewValue());

						}
					} else if (!xoTruConLineLocFeature.isEmpty() &&  xoTruConLineLocFeature.get(0).getCode().equalsIgnoreCase(changedElement.getFeatureCode())
							&& xoTruConLineLocFeature.get(0).getInstanceId()
									.equalsIgnoreCase(changedElement.getFeatureInstanceId())) {
						if (changedElement.getChangeType() != null
								&& ChangeType.CHANGED.toString().equalsIgnoreCase(changedElement.getChangeType())
								&& changedElement.getSpecificationCode() != null) {

							createChangedDeviceEntity(chanceDevice, changedElement.getSpecificationCode(),
									changedElement.getNewValue());

						}
					} 
				}
			}
		}

		LOG.info("Exited - parseDeviceChangeOrder");
		return chanceDevice;
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.vz.esap.translation.order.parser.DeviceOrderParser#createChangedDeviceEntity(com.
	 * vz.esap.translation.order.model.request.VOIPOrderRequest)
	 */
	public void createChangedDeviceEntity(DeviceEntity changedDevice, String specCode, String specValue) throws TranslatorException{
		String huntStrEnum = null;
		String ipv6Enabled = null;
		LOG.info("Entered - createChangedDeviceEntity");

		if (changedDevice == null) {
			changedDevice = new DeviceEntity();
		}

		if ("ESP_LOGICAL_DEVICE_NAME".equalsIgnoreCase(specCode)) {
			changedDevice.setDeviceName(specValue);
		}
		if ("ESP_CPE_DEVICE_ID".equalsIgnoreCase(specCode)) {
			changedDevice.setDeviceNameId(specValue);
		}
		if ("ESP_IP_ADDRESS_PRI".equalsIgnoreCase(specCode)) {
			changedDevice.setAddress(specValue);
		}
		if ("SP_VOIP_STRIP_COUN_CODE_INDCTR".equalsIgnoreCase(specCode)) {
			String stripCcInd = specValue;
			if (stripCcInd != null) {
				if (stripCcInd.equals("Y") || stripCcInd.equals("Yes")) {
					changedDevice.setStripCcInd("Y");
				}
				if (stripCcInd.equals("N") || stripCcInd.equals("No")) {
					changedDevice.setStripCcInd("N");
				}
			}
		}
		if ("ESP_TERM_CALL_INDICATOR".equalsIgnoreCase(specCode)) {
			changedDevice.setTermCallingInd(specValue);
		}
		if ("ESP_CPE_DEVICE_CODEC".equalsIgnoreCase(specCode)) { // confirm
			changedDevice.setCodec(specValue);
		}
		if ("ESP_DEVICE_SCREENED_TN".equalsIgnoreCase(specCode)) {
			changedDevice.setSTN(specValue);
		}
		if ("SP_VOIP_FAIL_OVER_STRATEGY".equalsIgnoreCase(specCode)) {
			String huntStrategy = specValue;
			if (huntStrategy != null) {
				if (huntStrategy.equalsIgnoreCase("Hunt")) {
					huntStrEnum = RivSbcEnum.HuntStrategy.acronym(RivSbcEnum.HuntStrategy.HUNT);
				} else if (huntStrategy.equalsIgnoreCase("Round Robin")
						|| huntStrategy.equalsIgnoreCase("RoundRobin")) {
					huntStrEnum = RivSbcEnum.HuntStrategy.acronym(RivSbcEnum.HuntStrategy.ROUNDROBIN);
				}
			}
			if (huntStrEnum != null) {
				changedDevice.setGwyHunt(huntStrEnum);
			} else {
				throw new TranslatorException(TranslatorException.ErrorCode.INVALID_XML,
						"Invalid Fail Over Strategy");
			}
		}
		if ("ESP_FQDN".equalsIgnoreCase(specCode)) {
			changedDevice.setGwyFqdn(specValue);
		}
		if ("SP_VOIP_IP_VERSIONING".equalsIgnoreCase(specCode)) {
			ipv6Enabled = specValue;
			if (ipv6Enabled != null) {
				if (ipv6Enabled.equalsIgnoreCase("IPv6") || ipv6Enabled.equalsIgnoreCase("Yes")
						|| ipv6Enabled.equalsIgnoreCase("Y")) {
					changedDevice.setIpVersion(IPVersionEnum.IPv6);
				} else if (ipv6Enabled.equalsIgnoreCase("IPv4") || ipv6Enabled.equalsIgnoreCase("No")
						|| ipv6Enabled.equalsIgnoreCase("N")) {
					changedDevice.setIpVersion(IPVersionEnum.IPv4);
				}
			} else {
				changedDevice.setIpVersion(IPVersionEnum.IPv4);
			}
		
		}
		if ("ESP_IP_ADDRESS_SEC".equalsIgnoreCase(specCode)) {
			changedDevice.setSecAddress(specValue);
		}
		if ("SP_TYPE_OF_FEATURE".equalsIgnoreCase(specCode)) { 
			changedDevice.setFeatureType(specValue);
		}
		if ("SP_ZERO_SUP".equalsIgnoreCase(specCode)) {
			changedDevice.setZeroSupp(specValue);
		}
		if ("SP_BILL_FLAG".equalsIgnoreCase(specCode)) {
			changedDevice.setBillFlag(specValue);
		}
		if ("SP_PORT".equalsIgnoreCase(specCode)) {
			changedDevice.setLinePort(specValue);
		}

		//not creating the createChangedSessionEntity method as "No Spec items" and session attribute is not exists in DeviceEntity - Need confirmation..
		LOG.info("Exited - createChangedDeviceEntity");
	}

	
}