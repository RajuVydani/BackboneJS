package com.vz.esap.translation.connector.model;

public class Location {

	private String locationId;
	private String locationName;
	private int groupUserLimit;

	public String getLocationId() {
		return locationId;
	}

	public void setLocationId(String locationId) {
		this.locationId = locationId;
	}

	public String getLocationName() {
		return locationName;
	}

	public void setLocationName(String locationName) {
		this.locationName = locationName;
	}

	public int getGroupUserLimit() {
		return groupUserLimit;
	}

	public void setGroupUserLimit(int groupUserLimit) {
		this.groupUserLimit = groupUserLimit;
	}

}