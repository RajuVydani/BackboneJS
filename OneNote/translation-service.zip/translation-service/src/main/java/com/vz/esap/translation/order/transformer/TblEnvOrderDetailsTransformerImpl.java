package com.vz.esap.translation.order.transformer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.vz.esap.translation.dao.model.TblEnvOrderDetails;
import com.vz.esap.translation.dao.repository.CustomTblEnvOrderDetailsMapper;

/**
 * @author chattni
 *
 */
@Component
public class TblEnvOrderDetailsTransformerImpl implements TblEnvOrderDetailsTransformer {

	private static final Logger LOG = LoggerFactory.getLogger(TblEnvOrderDetailsTransformerImpl.class);

	@Autowired
	CustomTblEnvOrderDetailsMapper customTblEnvOrderDetailsMapper;

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.vz.esap.translation.order.transformer.TblEnvOrderDetailsTransformer#
	 * prepareTblEnvOrderDetails(long, java.lang.String, long, java.lang.String,
	 * java.lang.String, java.lang.String, java.lang.String, long, long, long)
	 */
	@Override
	public TblEnvOrderDetails prepareTblEnvOrderDetails(long envOrderId, String dataType, long seqNo, String paramType,
			String action, String paramName, String paramValue, long parentId, long flowStatus, long leaf) {
		LOG.info("Entered - prepareTblEnvOrderDetails");
		TblEnvOrderDetails tblEnvOrderDetails = new TblEnvOrderDetails();

		long envOrderDetailId = customTblEnvOrderDetailsMapper.getEnvOrderDetailsIdSeqNextVal(tblEnvOrderDetails);
		tblEnvOrderDetails.setEnvOrderDetailId(envOrderDetailId);

		tblEnvOrderDetails.setEnvOrderId(envOrderId);
		/* tblEnvOrderDetails.setDataType(Long.valueOf(dataType)); */
		tblEnvOrderDetails.setSeqNo(seqNo);
		tblEnvOrderDetails.setParamType(paramType);
		tblEnvOrderDetails.setAction(action);
		tblEnvOrderDetails.setParamName(paramName);
		tblEnvOrderDetails.setParamValue(paramValue);
		tblEnvOrderDetails.setParentId(parentId);
		tblEnvOrderDetails.setFlowStatus(flowStatus);
		tblEnvOrderDetails.setLeaf(leaf);

		tblEnvOrderDetails.setEnvOrderDetailId(envOrderDetailId);
		LOG.info("Exit - prepareTblEnvOrderDetails");
		return tblEnvOrderDetails;
	}

}
