package com.vz.esap.translation.order.transformer;

import org.springframework.stereotype.Component;

import com.vz.esap.translation.dao.model.TblEnvOrder;
import com.vz.esap.translation.dao.model.TblOrder;
import com.vz.esap.translation.exception.GenericException;
import com.vz.esap.translation.order.model.Order;
import com.vz.esap.translation.order.model.request.VOIPOrderRequest;

@Component
public interface EnterpriseTblOrderDataTransformer {

	/**
	 * @param voipOrderRequest
	 * @param tblEnvOrder
	 * @return tblOrder
	 */
	TblOrder prepareTblOrderData(VOIPOrderRequest voipOrderRequest, TblEnvOrder tblEnvOrder);

	/**
	 * @param order
	 * @param orderEntity
	 * @return tblOrder
	 * @throws GenericException 
	 */
	TblOrder prepareTblOrderDataFromOrder(Order order, Long orderEntity) throws GenericException;

}
