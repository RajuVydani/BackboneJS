/**
 * 
 */
package com.vz.esap.translation.order.model.request;

import com.vz.esap.translation.order.model.request.CallingPlan.CallTypeEnum;


public class DigitString {
	
	private Long id;
	private String value;
	private CallTypeEnum incoming;
	private CallTypeEnum outgoing;
	private CallTypeEnum fwdTransfer;
	private CallTypeEnum beingFwdTransfer;
	
//	public String toString(){
//        StringBuilder buffer = new StringBuilder();
//        buffer.append("<DigitString>").append("\n");
//        OrderUtil.appendXmlNode(buffer, "id", id);
//        OrderUtil.appendXmlNode(buffer, "value", value);
//        OrderUtil.appendXmlNode(buffer, "incoming", incoming);
//        OrderUtil.appendXmlNode(buffer, "outgoing", outgoing);
//        OrderUtil.appendXmlNode(buffer, "fwdTransfer", fwdTransfer);
//        OrderUtil.appendXmlNode(buffer, "beingFwdTransfer", beingFwdTransfer);
//        buffer.append("</DigitString>").append("\n");
//        return buffer.toString();
//
//	}
	
	public DigitString(){}
	
	public DigitString(DigitString ds){
		this.id = ds.id;
		this.value = ds.value;
		this.incoming = ds.incoming;
		this.outgoing = ds.outgoing;
		this.fwdTransfer = ds.fwdTransfer;
		this.beingFwdTransfer = ds.beingFwdTransfer;
	}
	
//	public DigitString(esap.vzbvoip.inventory.DigitStringBean invDs){
//		this.id = (long)invDs.getDigitStringId();
//		this.value = invDs.getDigitString();
//		if(invDs.getIAllow() >= 0)
//			this.incoming = CallingPlan.CallTypeEnum.valueOf((int)invDs.getIAllow());
//		if(invDs.getOAllow() >= 0)
//			this.outgoing = CallingPlan.CallTypeEnum.valueOf((int)invDs.getOAllow());
//		if(invDs.getFAllow() >= 0)
//			this.fwdTransfer = CallingPlan.CallTypeEnum.valueOf((int)invDs.getFAllow());
//		if(invDs.getBAllow() >= 0)
//			this.beingFwdTransfer = CallingPlan.CallTypeEnum.valueOf((int)invDs.getBAllow());
//	}
	
	public DigitString(esap.db.TblDigitStringsDbBean dbDs){
		this.id = (long)dbDs.getDigitStringId();
		this.value = dbDs.getDigitString();
	}

	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}


	public CallTypeEnum getBeingFwdTransfer() {
		return beingFwdTransfer;
	}


	public void setBeingFwdTransfer(CallTypeEnum beingFwdTransfer) {
		this.beingFwdTransfer = beingFwdTransfer;
	}


	public CallTypeEnum getFwdTransfer() {
		return fwdTransfer;
	}


	public void setFwdTransfer(CallTypeEnum fwdTransfer) {
		this.fwdTransfer = fwdTransfer;
	}


	public CallTypeEnum getIncoming() {
		return incoming;
	}


	public void setIncoming(CallTypeEnum incoming) {
		this.incoming = incoming;
	}


	public CallTypeEnum getOutgoing() {
		return outgoing;
	}


	public void setOutgoing(CallTypeEnum outgoing) {
		this.outgoing = outgoing;
	}
	
	
	
	public ParamInfo getParamInfo(String action){
		ParamInfo root = new ParamInfo("DigitString", null, action);
		
		root.addNotNullValChild("Id", id, action, ParamInfo.Tag.ID);
		root.addNotNullValChild("Value", value, action, ParamInfo.Tag.NAME);
		root.addNotNullValChild("Incoming", incoming, action);
		root.addNotNullValChild("Outgoing", outgoing, action);
		root.addNotNullValChild("FwdTransfer", fwdTransfer, action);
		root.addNotNullValChild("BeingFwdTransfer", beingFwdTransfer, action);
		
		return root;
		
	}
	
}
