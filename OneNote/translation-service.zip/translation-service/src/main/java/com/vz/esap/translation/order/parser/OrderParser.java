package com.vz.esap.translation.order.parser;

import java.util.Map;

import com.vz.esap.translation.exception.GenericException;
import com.vz.esap.translation.exception.TranslatorException;
import com.vz.esap.translation.order.model.request.VOIPOrderRequest;

public interface OrderParser {

	/**
	 * @param voipOrderRequest
	 * @return productDetails
	 * @throws TranslatorException
	 * @throws GenericException
	 */
	Map<String, String> getProductDetails(VOIPOrderRequest voipOrderRequest)
			throws TranslatorException, GenericException;
	
	
	/**
	 * @param voipOrderRequest
	 * @return VOIPOrderRequest
	 */
	VOIPOrderRequest getPrevPassVoipOrderRequest(VOIPOrderRequest voipOrderRequest);


	/**
	 * Gives correct previous version
	 * @param voipOrderRequest
	 * @return
	 * @thows GenericException
	 */
	VOIPOrderRequest getCorrectPrevPassVoipOrderRequest(VOIPOrderRequest voipOrderRequest) throws GenericException;

}
