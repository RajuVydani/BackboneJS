package com.vz.esap.translation.order.model.request;

public class Communication {

	private String AreaDialing;

	private String Extension;

	private String Channel;

	private String DialNumber;

	private String CountryDialing;

	private String URI;

	public String getAreaDialing() {
		return AreaDialing;
	}

	public void setAreaDialing(String AreaDialing) {
		this.AreaDialing = AreaDialing;
	}

	public String getExtension() {
		return Extension;
	}

	public void setExtension(String Extension) {
		this.Extension = Extension;
	}

	public String getChannel() {
		return Channel;
	}

	public void setChannel(String Channel) {
		this.Channel = Channel;
	}

	public String getDialNumber() {
		return DialNumber;
	}

	public void setDialNumber(String DialNumber) {
		this.DialNumber = DialNumber;
	}

	public String getCountryDialing() {
		return CountryDialing;
	}

	public void setCountryDialing(String CountryDialing) {
		this.CountryDialing = CountryDialing;
	}

	public String getURI() {
		return URI;
	}

	public void setURI(String URI) {
		this.URI = URI;
	}

	public String toString() {
		return "ClassPojo [AreaDialing = " + AreaDialing + ", Extension = " + Extension + ", Channel = " + Channel
				+ ", DialNumber = " + DialNumber + ", CountryDialing = " + CountryDialing + ", URI = " + URI + "]";
	}
}
