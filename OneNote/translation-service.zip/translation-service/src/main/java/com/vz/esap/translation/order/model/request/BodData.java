package com.vz.esap.translation.order.model.request;

public class BodData {

	private VOIPOrderRequest VOIPOrderRequest;

	public VOIPOrderRequest getVoipOrderRequest() {
		return VOIPOrderRequest;
	}

	public void setVoipOrderRequest(VOIPOrderRequest voipOrderRequest) {
		this.VOIPOrderRequest = voipOrderRequest;
	}

}
