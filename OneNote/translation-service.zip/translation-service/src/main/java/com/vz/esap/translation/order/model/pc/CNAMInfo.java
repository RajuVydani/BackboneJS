package com.vz.esap.translation.order.model.pc;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;

import com.fasterxml.jackson.annotation.JsonProperty;

@XmlAccessorType(XmlAccessType.FIELD)
public class CNAMInfo {
	
	@XmlElement(name = "CLIDLastName")
	@JsonProperty(value = "CLIDLastName")
	private String clidLastName;

	@XmlElement(name = "CLIDFirstName")
	@JsonProperty(value = "CLIDFirstName")
	private String clidFirstName;

	@XmlElement(name = "TrunkGroupInstanceId")
	@JsonProperty(value = "TrunkGroupInstanceId")
	private String trunkGroupInstanceId;

	public String getCLIDLastName() {
		return clidLastName;
	}

	public void setCLIDLastName(String CLIDLastName) {
		this.clidLastName = CLIDLastName;
	}

	public String getCLIDFirstName() {
		return clidFirstName;
	}

	public void setCLIDFirstName(String CLIDFirstName) {
		this.clidFirstName = CLIDFirstName;
	}

	public String getTrunkGroupInstanceId() {
		return trunkGroupInstanceId;
	}

	public void setTrunkGroupInstanceId(String TrunkGroupInstanceId) {
		this.trunkGroupInstanceId = TrunkGroupInstanceId;
	}

	@Override
	public String toString() {
		return "ClassPojo [CLIDLastName = " + clidLastName + ", CLIDFirstName = " + clidFirstName
				+ ", TrunkGroupInstanceId = " + trunkGroupInstanceId + "]";
	}
}
