package com.vz.esap.translation.order.model.request;

import com.vz.esap.translation.order.model.request.ParamInfo;

public class TsoMigrationLocReferenceData {

	private Long locationReferenceId;
	private String newLocationId;
	private String oldLocationId;

	public Long getLocationReferenceId() {
		return locationReferenceId;
	}

	public void setLocationReferenceId(Long locationReferenceId) {
		this.locationReferenceId = locationReferenceId;
	}

	public String getNewLocationId() {
		return newLocationId;
	}

	public void setNewLocationId(String newLocationId) {
		this.newLocationId = newLocationId;
	}

	public String getOldLocationId() {
		return oldLocationId;
	}

	public void setOldLocationId(String oldLocationId) {
		this.oldLocationId = oldLocationId;
	}

	public ParamInfo getParamInfo() {
		ParamInfo root = new ParamInfo("TsoMigrationLocReferenceData", null, "I");
		root.addNotNullValChild("LocationReferenceId", locationReferenceId, "I");
		root.addNotNullValChild("NewLocationId", newLocationId, "I");
		root.addNotNullValChild("OldLocationId", oldLocationId, "I");
		return root;
	}

	public ParamInfo getChangeParam(TsoMigrationLocReferenceData oldTsoMigLocData, boolean supp) {
		ParamInfo tsoMigLocParam = new ParamInfo("TsoMigrationReferenceData", null, null);
		tsoMigLocParam.addChangeParam("LocationReferenceId", oldTsoMigLocData.getLocationReferenceId(),
				locationReferenceId, supp);
		tsoMigLocParam.addChangeParam("NewLocationId", oldTsoMigLocData.getNewLocationId(), newLocationId, supp);
		tsoMigLocParam.addChangeParam("OldLocationId", oldTsoMigLocData.getOldLocationId(), oldLocationId, supp);

		return tsoMigLocParam;
	}

}
