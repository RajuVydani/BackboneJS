package com.vz.esap.translation.order.model.request;

public class TsoMigrationEntReferenceData {

	private Long enterpriseReferenceId;
	private String newEnterpriseId;
	private String oldEnterpriseId;

	public String getNewEnterpriseId() {
		return newEnterpriseId;
	}

	public void setNewEnterpriseId(String newEnterpriseId) {
		this.newEnterpriseId = newEnterpriseId;
	}

	public String getOldEnterpriseId() {
		return oldEnterpriseId;
	}

	public void setOldEnterpriseId(String oldEnterpriseId) {
		this.oldEnterpriseId = oldEnterpriseId;
	}

	public Long getEnterpriseReferenceId() {
		return enterpriseReferenceId;
	}

	public void setEnterpriseReferenceId(Long enterpriseReferenceId) {
		this.enterpriseReferenceId = enterpriseReferenceId;
	}

	public ParamInfo getParamInfo() {
		ParamInfo root = new ParamInfo("TsoMigrationEntReferenceData", null, "I");
		root.addNotNullValChild("EnterpriseReferenceId", enterpriseReferenceId, "I");
		root.addNotNullValChild("NewEnterpriseId", newEnterpriseId, "I");
		root.addNotNullValChild("OldEnterpriseId", oldEnterpriseId, "I");
		return root;
	}

	public String toString() {
		return this.enterpriseReferenceId + "-" + this.newEnterpriseId + "-" + this.oldEnterpriseId;
	}

}
