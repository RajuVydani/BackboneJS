package com.vz.esap.translation.order.model.request;

public class CNAMInfo {

	private String CLIDLastName;

	private String CLIDFirstName;

	private String TrunkGroupInstanceId;

	public String getCLIDLastName() {
		return CLIDLastName;
	}

	public void setCLIDLastName(String CLIDLastName) {
		this.CLIDLastName = CLIDLastName;
	}

	public String getCLIDFirstName() {
		return CLIDFirstName;
	}

	public void setCLIDFirstName(String CLIDFirstName) {
		this.CLIDFirstName = CLIDFirstName;
	}

	public String getTrunkGroupInstanceId() {
		return TrunkGroupInstanceId;
	}

	public void setTrunkGroupInstanceId(String TrunkGroupInstanceId) {
		this.TrunkGroupInstanceId = TrunkGroupInstanceId;
	}

	public String toString() {
		return "ClassPojo [CLIDLastName = " + CLIDLastName + ", CLIDFirstName = " + CLIDFirstName
				+ ", TrunkGroupInstanceId = " + TrunkGroupInstanceId + "]";
	}
}
