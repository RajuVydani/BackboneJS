package com.vz.esap.translation.entity;

public class SbcSigTier {
	private Integer sigTierId;
	private Integer cclTierLimit;
	private Integer maxSigThreshold;
	private Integer untrustedSigThreshold;

	public Integer getSigTierId() {
		return sigTierId;
	}

	public void setSigTierId(Integer sigTierId) {
		this.sigTierId = sigTierId;
	}

	public Integer getCclTierLimit() {
		return cclTierLimit;
	}

	public void setCclTierLimit(Integer cclTierLimit) {
		this.cclTierLimit = cclTierLimit;
	}

	public Integer getMaxSigThreshold() {
		return maxSigThreshold;
	}

	public void setMaxSigThreshold(Integer maxSigThreshold) {
		this.maxSigThreshold = maxSigThreshold;
	}

	public Integer getUntrustedSigThreshold() {
		return untrustedSigThreshold;
	}

	public void setUntrustedSigThreshold(Integer untrustedSigThreshold) {
		this.untrustedSigThreshold = untrustedSigThreshold;
	}

}
