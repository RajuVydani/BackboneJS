package com.vz.esap.translation.order.transformer;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.vz.esap.translation.dao.model.TblOrderDetails;
import com.vz.esap.translation.entity.CustomerEntity;
import com.vz.esap.translation.entity.EnterpriseTrunkEntity;
import com.vz.esap.translation.entity.Entity.ActiveStatus;
import com.vz.esap.translation.entity.NbsEntity;
import com.vz.esap.translation.entity.ParamInfo;
import com.vz.esap.translation.enums.EsapEnum.NbsType;
import com.vz.esap.translation.enums.EsapEnum.RedundancyPriorityType;
import com.vz.esap.translation.enums.EsapEnum.RedundancyType;
import com.vz.esap.translation.exception.ApplicationInterfaceException;
import com.vz.esap.translation.exception.GenericException;
import com.vz.esap.translation.exception.TranslatorException;
import com.vz.esap.translation.exception.TranslatorException.ErrorCode;
import com.vz.esap.translation.order.dao.VOIPOrderDao;
import com.vz.esap.translation.order.model.request.VOIPOrderRequest;
import com.vz.esap.translation.order.service.helper.OrderServiceHelper;
import com.vz.esap.translation.util.InventoryUtil;

@Component
public class NbsTransformerImpl implements NbsTransformer {

	private static final Logger LOG = LoggerFactory.getLogger(NbsTransformerImpl.class);
	@Autowired
	private VOIPOrderDao voipOrderDao;

	@Autowired
	private ParamInfoTransformer paramInfoTransformer;

	@Autowired
	private OrderServiceHelper orderServiceHelper;
	
	@Autowired
	private InventoryUtil inventoryUtil;

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.vz.esap.translation.order.transformer.NbsTransformer#
	 * transformOrderDetailsToNbs(long, long, java.lang.String, boolean)
	 */
	@Override
	public NbsEntity transformOrderDetailsToNbs(long orderId, long parentId, String action, boolean delta,
			List<String> paramActionExclusionList) throws TranslatorException {

		return createNbsFromParamInfo(createNbsParamInfoFromOrderDetails(orderId, parentId, action, delta, null),
				paramActionExclusionList);

	}

	/**
	 * @param parent
	 * @return nbsEntity
	 * @throws TranslatorException
	 */
	private NbsEntity createNbsFromParamInfo(ParamInfo parent, List<String> paramActionExclusionList)
			throws TranslatorException {

		LOG.info("CustomerTransformerImpl - createCustomerFromParamInfo");
		NbsEntity nbsEntity = null;

		try {
			nbsEntity = new NbsEntity();

			for (ParamInfo param : parent.getChildParams()) {
				LOG.info("Name:{}  Value:{} ChildParamCnt:{}", param.getName(), param.getValue(),
						(param.getChildParams() == null ? 0 : param.getChildParams().size()));
				// createXXXFromParamInfo(...)
				if (paramActionExclusionList != null && !paramActionExclusionList.isEmpty()) {
					boolean skip = false;
					for (String exclude : paramActionExclusionList) {
						exclude = paramInfoTransformer.translateTODActToPIAct(exclude);
						
						if (exclude.equalsIgnoreCase(param.getAction())) {
							LOG.info("Param Excluded = {} For Actual Action = {} , The Excluding Action = {}",
									param.getName(), param.getAction(), exclude);
							skip = true;
						}
					}
					if (skip)
						continue;
				}

				if (param.getValue() != null) {
					if (param.getName().equalsIgnoreCase("CustomerId"))
						nbsEntity.setCustomerId(param.getValue());
					else if (param.getName().equalsIgnoreCase("LocationId"))
						nbsEntity.setLocationId(param.getValue());
					else if (param.getName().equalsIgnoreCase("NbsClusterId"))
						nbsEntity.setNbsClusterId(param.getValue());
					else if (param.getName().equalsIgnoreCase("TrunkGroupId"))
						nbsEntity.setTrunkGroupId(param.getValue());
					else if (param.getName().equalsIgnoreCase("State"))
						nbsEntity.setState(param.getValue());
					else if (param.getName().equalsIgnoreCase("City"))
						nbsEntity.setCity(param.getValue());
					else if (param.getName().equalsIgnoreCase("Country"))
						nbsEntity.setCountry(param.getValue());
					else if (param.getName().equalsIgnoreCase("NbsType"))
						nbsEntity.setNbsType(NbsType.valueOf(param.getValue()));
					// Start-NBS Change
					else if (param.getName().equalsIgnoreCase("CpeIpAddress"))
						nbsEntity.setCpeIpAddress(param.getValue());
					else if (param.getName().equalsIgnoreCase("IpAddress"))
						nbsEntity.setIpAddress(param.getValue());
					else if (param.getName().equalsIgnoreCase("Address"))
						nbsEntity.setAddress(param.getValue());
					else if (param.getName().equalsIgnoreCase("CpeServerFqdnPort"))
						nbsEntity.setCpeServerFqdnPort(param.getValue());
					else if (param.getName().equalsIgnoreCase("CpeServerFqdn"))
						nbsEntity.setCpeServerFqdn(param.getValue());
					else if (param.getName().equalsIgnoreCase("CpePort"))
						nbsEntity.setCpePort(param.getValue());
					else if (param.getName().equalsIgnoreCase("RedundancyType"))
						nbsEntity.setRedundancy(RedundancyType.valueOf(param.getValue()));
					else if (param.getName().equalsIgnoreCase("RedundancyPriorityType"))
						nbsEntity.setRedundancyPriorityType(RedundancyPriorityType.valueOf(param.getValue()));
					else if (param.getName().equalsIgnoreCase("PbxIpRedundancy1"))
						nbsEntity.setPbxIpRedundancy1(param.getValue());
					else if (param.getName().equalsIgnoreCase("GroupUserLimit"))
						nbsEntity.setGroupUserLimit(param.getValue());
					else if (param.getName().equalsIgnoreCase("CompressionType"))
						nbsEntity.setCompressionType(param.getValue());
					else if (param.getName().equalsIgnoreCase("AsClli"))
						nbsEntity.setAsClli(param.getValue());
					else if (param.getName().equalsIgnoreCase("BwCluster"))
						nbsEntity.setBwCluster(param.getValue());
					// End-NBS Change
				}
			}
		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new TranslatorException(ErrorCode.TRANSFORMER_FAILURE, "Exception occured in createNbsFromParamInfo");
		}
		return nbsEntity;
	}

	/**
	 * @param orderId
	 * @param parentId
	 * @param action
	 * @param delta
	 * @param paramName
	 * @return nbsEntityParam
	 * @throws TranslatorException
	 */
	private ParamInfo createNbsParamInfoFromOrderDetails(long orderId, long parentId, String action, boolean delta,
			String paramName) throws TranslatorException {
		LOG.info("In NbsTransformerImpl createNbsParamInfoFromOrderDetails ordId:{} parentId:{} action:{} delta:{}",
				orderId, parentId, action, delta);
		ParamInfo nbsEntityParam = null;
		TblOrderDetails tblOrderDetails = null;
		List<TblOrderDetails> ordDetails = null;

		try {
			tblOrderDetails = new TblOrderDetails();
			tblOrderDetails.setOrderId(orderId);
			tblOrderDetails.setAction(action);
			tblOrderDetails.setParentId(parentId);
			tblOrderDetails.setParamName(paramName);
			ordDetails = voipOrderDao.getOrderDetailsWithActionAndParent(parentId, action, delta, paramName,
					tblOrderDetails);
			LOG.info("List Size:{}", ordDetails.size());
			/*
			 * String param_val = null;// OrderUtil.getConfigParamValue(dbcon,
			 * "SUPP_CANCEL", "SUPP_CANCEL"); :
			 * 
			 * // This is TODO boolean flag = true; if (param_val != null &&
			 * param_val.equalsIgnoreCase("Y")) { flag = false; } if (flag) { if
			 * (ordDetails.size() <= 0) { LOG.info("Param details Not found for customer ");
			 * return null; } }
			 */
			nbsEntityParam = new ParamInfo("SonusNbs", null, null);
			nbsEntityParam = paramInfoTransformer.transformOrderDetailsToParamInfo(ordDetails, nbsEntityParam, 0, null);

			// return createInstanceFromOrderDetails(ordDetails);
		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new TranslatorException(ErrorCode.TRANSFORMER_FAILURE,
					"Exception occured in createNbsParamInfoFromOrderDetails");
		}

		return nbsEntityParam;

	}

	/**
	 *
	 * @param nbsEntity
	 * @param paramName
	 * @return voipOrderRequest
	 * @throws TranslatorException, GenericException, IllegalAccessException, ApplicationInterfaceException
	 */
	
	@Override
	public NbsEntity enrichNbsEntityWithInventory(VOIPOrderRequest voipOrderRequest, NbsEntity nbsEntity)
			throws TranslatorException, GenericException, IllegalAccessException, ApplicationInterfaceException {
		LOG.info("Entered enrichNbsEntityWithInventory");
		
		String nbsClusterId = null;
		
		if (nbsEntity.getNbsClusterId() != null) {
			nbsClusterId = nbsEntity.getNbsClusterId();
		} else {
			nbsClusterId = inventoryUtil.getNbsClusterInfoIdFromTrunkId(nbsEntity.getTrunkGroupId());
		}

		NbsEntity nbsEntityInv = orderServiceHelper.getEntityDetailsFromInventory(nbsClusterId,
				NbsEntity.class);

		// Copying nbs Inv Details to Original nbs Entity

		LOG.info("++Level 10+++++Original customer Entity : {} ", nbsEntity);

		LOG.info("++Level 10+++++Changed customer Entity : {} ", nbsEntity.getNbsEntity());

		LOG.info("++Level 10+++++Original customer Entity nbsEntityInv : {} ", nbsEntityInv);

		LOG.info("++Level 10+++++Changed customer Entity nbsEntityInv.getnbsEntity() : {} ",
				nbsEntityInv.getNbsEntity());

		nbsEntity = copyFields(nbsEntityInv, nbsEntity);

		LOG.info("++Level 11+++++Original customer Entity : {} ", nbsEntity);

		LOG.info("++Level 11+++++Changed customer Entity : {} ", nbsEntity.getNbsEntity());

		if (nbsEntity.getNbsEntity() != null) {
			NbsEntity nbsEntityChanged = nbsEntity.getNbsEntity();

			// Copying nbs Inv Details to Changed nbs Entity
			copyFields(nbsEntity, nbsEntityChanged);

			LOG.info("++Level 3+++++Original Customer Entity : {} ", nbsEntity);

			LOG.info("++Level 3+++++Changed Customer Entity : {} ", nbsEntity.getNbsEntity());

		}

		LOG.info("Exit enrichnbsEntityWithInventory Nbs Entity Enriched = {} ", nbsEntity);
		return nbsEntity;
	}

	private NbsEntity copyFields(NbsEntity currentNbsEntity, NbsEntity resultNbsEntity) {
		
		// Inventory -> original
		if (resultNbsEntity.getCustomerId() == null && currentNbsEntity.getCustomerId() != null) {
			resultNbsEntity.setCustomerId(currentNbsEntity.getCustomerId());
		}
		if (resultNbsEntity.getLocationId() == null && currentNbsEntity.getLocationId() != null) {
			resultNbsEntity.setLocationId(currentNbsEntity.getLocationId());
		}
		if (resultNbsEntity.getNbsClusterId() == null && currentNbsEntity.getNbsClusterId() != null) {
			resultNbsEntity.setNbsClusterId(currentNbsEntity.getNbsClusterId());
		}
		if (resultNbsEntity.getTrunkGroupId() == null && currentNbsEntity.getTrunkGroupId() != null) {
			resultNbsEntity.setTrunkGroupId(currentNbsEntity.getTrunkGroupId());
		}
		if (resultNbsEntity.getState() == null && currentNbsEntity.getState() != null) {
			resultNbsEntity.setState(currentNbsEntity.getState());
		}
		if (resultNbsEntity.getCity() == null && currentNbsEntity.getCity() != null) {
			resultNbsEntity.setCity(currentNbsEntity.getCity());
		}
		if (resultNbsEntity.getCountry() == null && currentNbsEntity.getCountry() != null) {
			resultNbsEntity.setCountry(currentNbsEntity.getCountry());
		}
		if (resultNbsEntity.getNbsType() == null && currentNbsEntity.getNbsType() != null) {
			resultNbsEntity.setNbsType(currentNbsEntity.getNbsType());
		}
		if (resultNbsEntity.getCpeIpAddress() == null && currentNbsEntity.getCpeIpAddress() != null) {
			resultNbsEntity.setCpeIpAddress(currentNbsEntity.getCpeIpAddress());
		}
		if (resultNbsEntity.getCpeServerFqdnPort() == null && currentNbsEntity.getCpeServerFqdnPort() != null) {
			resultNbsEntity.setCpeServerFqdnPort(currentNbsEntity.getCpeServerFqdnPort());
		}
		if (resultNbsEntity.getCpeServerFqdn() == null && currentNbsEntity.getCpeServerFqdn() != null) {
			resultNbsEntity.setCpeServerFqdn(currentNbsEntity.getCpeServerFqdn());
		}
		if (resultNbsEntity.getCpePort() == null && currentNbsEntity.getCpePort() != null) {
			resultNbsEntity.setCpePort(currentNbsEntity.getCpePort());
		}
		if (resultNbsEntity.getRedundancy() == null && currentNbsEntity.getRedundancy() != null) {
			resultNbsEntity.setRedundancy(currentNbsEntity.getRedundancy());
		}
		if (resultNbsEntity.getRedundancyPriorityType() == null && currentNbsEntity.getRedundancyPriorityType() != null) {
			resultNbsEntity.setRedundancyPriorityType(currentNbsEntity.getRedundancyPriorityType());
		}
		if (resultNbsEntity.getPbxIpRedundancy1() == null && currentNbsEntity.getPbxIpRedundancy1() != null) {
			resultNbsEntity.setPbxIpRedundancy1(currentNbsEntity.getPbxIpRedundancy1());
		}

		return resultNbsEntity;
	}
	/**
	 *
	 * @param resultantRow
	 * @return NbsEntity
	 * @throws 
	 */
	
	@Override
	public NbsEntity nbsEntityInventoryToNbsEntityTransformer(Map<String, String> resultantRow) {
		LOG.info("Entered nbsEntityInventoryToNbsEntityTransformer");

		NbsEntity nbsEntity = new NbsEntity();

		nbsEntity.setNbsClusterId(resultantRow.get("NBS_CLUSTER_INFO_ID"));

		// NBS_POOL_ID not found
		if (resultantRow.get("NBS_TYPE") != null) {

			if (NbsType.INBOUND.toString().equalsIgnoreCase(resultantRow.get("NBS_TYPE")))
				nbsEntity.setNbsType(NbsType.INBOUND);
			else if (NbsType.TWO_WAY.toString().equalsIgnoreCase(resultantRow.get("NBS_TYPE")))
				nbsEntity.setNbsType(NbsType.TWO_WAY);
			else if (NbsType.BOTH.toString().equalsIgnoreCase(resultantRow.get("NBS_TYPE")))
				nbsEntity.setNbsType(NbsType.BOTH);
		}

		// BS_AS_MAPPING_ID not found
		// INTERNAL_PORT not found
		nbsEntity.setExternalSigZoneIp(resultantRow.get("EXTERNAL_28_IP_BLOCK"));
		nbsEntity.setExternalSigZonePort(resultantRow.get("EXTERNAL_PORT"));
		//
		//
		nbsEntity.setIp28(resultantRow.get("EXTERNAL_28_IP_BLOCK"));
		nbsEntity.setIp32(resultantRow.get("INTERNAL_32_IP"));
		nbsEntity.setCpeIpAddress(resultantRow.get("CPE_EXTERNAL_IP"));
		nbsEntity.setCpePort(resultantRow.get("CPE_EXTERNAL_PORT"));
		nbsEntity.setIp1(resultantRow.get("NIF_IP_1"));
		nbsEntity.setIp2(resultantRow.get("NIF_IP_2"));
		nbsEntity.setIp3(resultantRow.get("NIF_IP_3"));
		// NIF_IP_4 not found
		nbsEntity.setVpnId(resultantRow.get("CPE_EXTERNAL_PORT"));
		nbsEntity.setInternalSigZonePort(resultantRow.get("INTERNAL_PORT"));
		nbsEntity.setVpnName(resultantRow.get("VPN_NAME"));
		nbsEntity.setLocationId(resultantRow.get("LOCATION_ID"));
		nbsEntity.setLocationId(resultantRow.get("LOCATION_ID"));
		nbsEntity.setTrunkGroupId(resultantRow.get("GROUP_ID"));

		// EXTERNAL_IP_2W not found
		// EXTERNAL_IP_IB not found
		// WT_INTERNAL_PORT not found
		// WT_EXTERNAL_PORT not found
		if (resultantRow.get("STATUS") != null) {

			if (ActiveStatus.ACTIVE.toString().equalsIgnoreCase(resultantRow.get("STATUS")))
				nbsEntity.setActiveStatus(ActiveStatus.ACTIVE);
			else if (ActiveStatus.DELETE_PENDING.toString().equalsIgnoreCase(resultantRow.get("STATUS")))
				nbsEntity.setActiveStatus(ActiveStatus.DELETE_PENDING);
			else if (ActiveStatus.INACTIVE.toString().equalsIgnoreCase(resultantRow.get("STATUS")))
				nbsEntity.setActiveStatus(ActiveStatus.INACTIVE);
			else if (ActiveStatus.SUSPEND.toString().equalsIgnoreCase(resultantRow.get("STATUS")))
				nbsEntity.setActiveStatus(ActiveStatus.SUSPEND);

		}
		LOG.info("Exit nbsEntityInventoryToNbsEntityTransformer");
		return nbsEntity;
	}
}