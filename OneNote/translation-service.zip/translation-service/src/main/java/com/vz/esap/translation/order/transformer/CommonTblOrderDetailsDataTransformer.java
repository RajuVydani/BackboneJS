package com.vz.esap.translation.order.transformer;

import java.text.ParseException;

import com.vz.esap.translation.dao.model.TblOrder;
import com.vz.esap.translation.exception.GenericException;
import com.vz.esap.translation.order.model.request.ParamInfo;
import com.vz.esap.translation.order.model.request.VOIPOrderRequest;

public interface CommonTblOrderDetailsDataTransformer {

	/**
	 * @param voipOrderRequest
	 * @param tblOrderObject
	 * @return paramInfo
	 * @throws ParseException
	 * @throws GenericException 
	 */
	ParamInfo prepareTblOrderDetailsHeaderParamDataForCustomer(VOIPOrderRequest voipOrderRequest, TblOrder tblOrderObject) throws ParseException, GenericException;

}
