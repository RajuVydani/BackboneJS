package com.vz.esap.translation.order.transformer;

import java.math.BigInteger;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.vz.esap.translation.dao.model.TblOrderDetails;
import com.vz.esap.translation.entity.Entity;
import com.vz.esap.translation.entity.Entity.ActiveStatus;
import com.vz.esap.translation.entity.GroupTNEntity;
import com.vz.esap.translation.entity.ParamInfo;
import com.vz.esap.translation.entity.TNEntity;
import com.vz.esap.translation.entity.TNEntity.DeleteType;
import com.vz.esap.translation.entity.TNEntity.PortInType;
import com.vz.esap.translation.entity.TNEntity.PortOutType;
import com.vz.esap.translation.entity.TrunkGroupEntity;
import com.vz.esap.translation.enums.EsapEnum.AuthFeatureType;
import com.vz.esap.translation.enums.EsapEnum.TnType;
import com.vz.esap.translation.exception.GenericException;
import com.vz.esap.translation.exception.TranslatorException;
import com.vz.esap.translation.order.dao.VOIPOrderDao;
import com.vz.esap.translation.order.model.request.VOIPOrderRequest;
import com.vz.esap.translation.order.service.helper.OrderServiceHelper;
import com.vz.esap.translation.util.TNUtility;

import EsapEnumPkg.TNEnum;

/**
 * @author baigkh
 *
 */
@Component
public class GroupTnTransformerImpl implements GroupTnTransformer {

	private static final Logger LOG = LoggerFactory.getLogger(GroupTnTransformerImpl.class);

	@Autowired
	private VOIPOrderDao voipOrderDao;

	@Autowired
	private ParamInfoTransformer paramInfoTransformer;

	@Autowired
	private OrderServiceHelper orderServiceHelperImpl;

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.vz.esap.translation.order.transformer.GroupTnTransformer#
	 * transformOrderDetailsToGroupTn(long, long, java.lang.String, boolean)
	 */
	@Override
	public GroupTNEntity transformOrderDetailsToGroupTn(long orderId, long parentId, String action, boolean delta,
			List<String> paramActionExclusionList) throws TranslatorException {

		return createGroupTNFromParamInfo(createTNParamInfoFromOrderDetails(orderId, parentId, action, delta, null),
				paramActionExclusionList);

	}

	/**
	 * @param parent
	 * @return
	 * @throws TranslatorException
	 */
	private GroupTNEntity createGroupTNFromParamInfo(ParamInfo parent, List<String> paramActionExclusionList)
			throws TranslatorException {
		if (parent == null) {
			return null;
		}
		GroupTNEntity groupTN = new GroupTNEntity();
		if (parent.getChildParams() == null) {
			return groupTN;
		}
		for (ParamInfo param : parent.getChildParams()) {
			LOG.debug("Name: {} :: Value: {}", param.getName(), param.getValue());

			if (paramActionExclusionList != null && !paramActionExclusionList.isEmpty()) {
				boolean skip = false;
				for (String exclude : paramActionExclusionList) {
					if (exclude.equalsIgnoreCase(param.getAction())) {
						LOG.info("Excluded Action : {} for Param Name = {} and Param Value = {}", exclude,
								param.getName(), param.getValue());
						skip = true;
					}
				}
				if (skip)
					continue;
			}

			if (groupTN == null) {
				groupTN = new GroupTNEntity();
			}
			setParam(groupTN, param);

		}
		return groupTN;
	}

	/**
	 * @param parent
	 * @return deviceEntity
	 * @throws TranslatorException
	 */
	private void setParam(GroupTNEntity groupTN, ParamInfo parent) throws TranslatorException {
		LOG.debug("Name2: {} :: Value2: {}", parent.getName(), parent.getValue());
		LOG.debug("Entered CustomerTransformerImpl - setParam");

		if (parent.getName().equals("GroupTNId")) {
			groupTN.setGroupTNId(new Long(parent.getValue()));
		} else if (parent.getName().equals("DeviceName")) {
			groupTN.setDeviceName(parent.getValue());
		} else if (parent.getName().equals("EntityAction")) {
			groupTN.setEntityAction(parent.getValue());
		} else if (parent.getName().equals("LinePort")) {
			groupTN.setLinePort(parent.getValue());
		} else if (parent.getName().equals("SubscriberId")) {
			groupTN.setSubscriberId(parent.getValue());
		} else if (parent.getName().equals("TNRecord")) {
			LOG.info("Inside TNRecord");
			groupTN.setTnRecord(createInstanceFromParamInfo(parent));// TODO(TNUtility.createInstanceFromParamInfo(parent));
		} else if (parent.getName().equals("PrivateNumber")) {
			groupTN.setPrivateNumber(parent.getValue());
		} else if (parent.getName().equals("Extension")) {
			groupTN.setExtension(parent.getValue());
		} else if (parent.getName().equals("SipDomain")) {
			groupTN.setSipDomain(parent.getValue());
		} else if (parent.getName().equals("TnCLIDFirstName")) {
			groupTN.setTnCLIDFirstName(parent.getValue());
		} else if (parent.getName().equals("TnCLIDLastName")) {
			groupTN.setTnCLIDLastName(parent.getValue());
			/*
			 * } else if (param.getName().equals("FeaturePackage")) {
			 * groupTN.setFeaturePackage(param.getValue());
			 */
		} else if (parent.getName().equals("LinePort")) {
			groupTN.setLinePort(parent.getValue());
		} else if (parent.getName().equals("VMBoxNumber")) {
			groupTN.setVmBoxNumber(parent.getValue());
		} else if (parent.getName().equals("VMPin")) {
			groupTN.setVmPin(parent.getValue());
		} else if (parent.getName().equals("VMType")) {
			groupTN.setVmType(parent.getValue());
		} else if (parent.getName().equals("SequenceNo") && parent.getValue() != null) {
			groupTN.setSequenceNo(new Integer(parent.getValue()));
		} else if (parent.getName().equals("Group")) {
			groupTN.setTrunkGroupEntity(createGroupInstanceFromParamInfo(parent)); // TODO(GroupUtility.createInstanceFromParamInfo(parent));
		} else if (parent.getName().equals("NonPkgFeatures")) {
			if (parent.getChildParams() != null) {
				for (ParamInfo par2 : parent.getChildParams()) {
					groupTN.addNonPkgFeature(par2.getValue());
				}
			}
		} else if (parent.getName().equals("DisableFeatureList")) {
			if (parent.getChildParams() != null) {
				for (ParamInfo par2 : parent.getChildParams()) {
					groupTN.addDisableFeature(par2.getValue());
				}
			}
		} else if (parent.getName().equals("PkgDiffFeatures")) {
			if (parent.getChildParams() != null)
				for (ParamInfo par2 : parent.getChildParams())
					groupTN.addPkgDiffFeature(par2.getValue());
		} else if (parent.getName().equals("AdditionalAttribs")) {
			if (parent.getChildParams() != null) {
				for (ParamInfo par2 : parent.getChildParams()) {
					groupTN.addAttrib(par2.getName(), par2.getValue());
				}
			}
		} /*
			 * else if (parent.getName().equals("GroupTNFMCG")) { TODO: Check FMCG
			 * groupTN.setGroupTNFMCG(GroupTNFMCG .createInstanceFromParamInfo(param)); }
			 */ /*
				 * March Voip Feature Enhancement Changes
				 */else if (parent.getName().equals("UserFeatures")) {
			if (parent.getChildParams() != null) {
				for (ParamInfo par2 : parent.getChildParams()) {
					groupTN.addUserFeatures(par2.getValue());
				}
			}
		} else if (parent.getName().equals("HotCutIndicator")) {
			if (parent.getValue() != null && parent.getValue().equals("Y"))
				groupTN.setHotCutIndicator(Boolean.TRUE);
		} else if (parent.getName().equals("CDDDIndicator")) {
			if (parent.getValue() != null && parent.getValue().equals("Y"))
				groupTN.setCDDDIndicator(Boolean.TRUE);
		} else if (parent.getName().equals("Region")) {
			groupTN.setRegion(parent.getValue());
		} else if (parent.getName().equals("CustomerId")) {
			groupTN.setCustomerId(parent.getValue());
		} else if (parent.getName().equals("LocationId")) {
			groupTN.setLocationId(parent.getValue());
		} else if (parent.getName().equals("TnCount")) {
			groupTN.setTnCount(Long.valueOf(parent.getValue()));
		} else if (parent.getName().equals("TimeZone")) {
			groupTN.setTimeZoneId(parent.getValue());
		} else if (parent.getName().equals("DaylightSavingInd")) {
			groupTN.setDayLightSavingInd(parent.getValue());
		} else if (parent.getName().equals("AuthFeatureType")) {
			groupTN.setAuthFeatureType(AuthFeatureType.valueOf(parent.getValue()));
		} else if (parent.getName().equals("AsClli")) {
			groupTN.setAsClli(parent.getValue());
		}

		LOG.debug("Exited CustomerTransformerImpl - setParam");

	}

	/**
	 * @param orderId
	 * @param parentId
	 * @param action
	 * @param delta
	 * @param paramName
	 * @return paramInfo
	 * @throws TranslatorException
	 */// TODO Change name to TN
	private ParamInfo createTNParamInfoFromOrderDetails(long orderId, long parentId, String action, boolean delta,
			String paramName) throws TranslatorException {

		LOG.info("In GroupTnTransformerImpl createTNParamInfoFromOrderDetails ordId:{} parentId:{} action:{} delta:{}",
				orderId, parentId, action, delta);
		ParamInfo paramInfo = null;

		try {
			TblOrderDetails tblOrderDetails = new TblOrderDetails();
			tblOrderDetails.setOrderId(orderId);
			tblOrderDetails.setAction(action);
			tblOrderDetails.setParentId(parentId);
			tblOrderDetails.setParamName(paramName);
			List<TblOrderDetails> ordDetails = voipOrderDao.getOrderDetailsWithActionAndParent(parentId, action, delta,
					paramName, tblOrderDetails);

			LOG.info("List Size:{}", ordDetails.size());

			paramInfo = new ParamInfo("GroupTN", null, null);
			paramInfo = paramInfoTransformer.transformOrderDetailsToParamInfo(ordDetails, paramInfo, 0, null);

		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new TranslatorException(TranslatorException.ErrorCode.ORDER_NOT_SAVABLE,
					"Unexpected Error Occured while Parsing Trunk Order\"");
		}

		return paramInfo;

	}

	public static TNEntity createInstanceFromParamInfo(ParamInfo parent) {
		return createInstanceFromParamInfo(parent, null);
	}

	public static TNEntity createInstanceFromParamInfo(ParamInfo parent, TNEntity tn) {
		if (parent == null)
			return null;
		LOG.info("Name3: {} :: Value3:  {}", parent.getName(), parent.getValue());
		if (tn == null)
			tn = new TNEntity();

		if (parent.getChildParams() == null)
			return tn;

		for (ParamInfo param : parent.getChildParams()) {

			if (tn == null)
				tn = new TNEntity();

			if (param.getName().equals("TN")) {
				tn.setTn(param.getValue());
			}

			else if (param.getName().equals("TnPoolId") && param.getValue() != null)
				tn.setTNPoolId(new Long(param.getValue()));
			else if (param.getName().equals("CustomerId"))
				tn.setCustomerId(param.getValue());
			else if (param.getName().equals("LocationId"))
				tn.setLocationId(param.getValue());
			else if (param.getName().equals("PortingFlag"))
				tn.setPortingFlag(param.getValue());
			else if (param.getName().equals("Region"))
				tn.setRegion(param.getValue());
			else if (param.getName().equals("Territory"))
				tn.setTerritory(param.getValue());
			else if (param.getName().equals("PortStatus") && param.getValue() != null)
				tn.setPortStatus(TNEntity.PortStatus.valueOf(param.getValue()));
			else if (param.getName().equals("RealTrunkGroupNumber"))
				tn.setTrunkId(param.getValue());
			else if (param.getName().equals("SwitchCLLI"))
				tn.setSwitchClli(param.getValue());

			else if (param.getName().equals("ReplacementCLLI"))

				tn.setReplacementCLLI(param.getValue());

			else if (param.getName().equals("TnActivation") && param.getValue() != null)
				tn.setOnOffStatus(TNEntity.OnOffStatus.valueOf(param.getValue()));
			else if (param.getName().equals("TSPCode") && param.getValue() != null)
				tn.setTspCode(param.getValue());

			else if (("Lidb").equals(param.getName()))
				tn.setLidb(param.getValue());
			else if (("TnDisposition").equals(param.getName()))
				tn.setTnDisposition(param.getValue());
			else if (("EmergencyFirstName").equals(param.getName()))
				tn.setEmergencyFirstName(param.getValue());
			else if (("EmergencyMiddleName").equals(param.getName()) && param.getValue() != null)
				tn.setEmergencyMiddleName(param.getValue());
			else if (("EmergencyLastName").equals(param.getName()) && param.getValue() != null)
				tn.setEmergencyLastName(param.getValue());
			else if (("EmergencyBldngDesignator").equals(param.getName()))
				tn.setEmergencyBldngDesignator(param.getValue());
			else if (("EmergencyBldngValue").equals(param.getName()))
				tn.setEmergencyBldngValue(param.getValue());
			else if (("EmergencyFloorValue").equals(param.getName()))
				tn.setEmergencyFloorValue(param.getValue());
			else if (("EmergencyFloorDesignator").equals(param.getName()) && param.getValue() != null)
				tn.setEmergencyFloorDesignator(param.getValue());
			else if (("EmergencyRoomValue").equals(param.getName()) && param.getValue() != null)
				tn.setEmergencyRoomValue(param.getValue());
			else if (("EmergencyRoomDesignator").equals(param.getName()))
				tn.setEmergencyRoomDesignator(param.getValue());
			else if (("CnamOutBoundFirstName").equals(param.getName()))
				tn.setCnamOutBoundFirstName(param.getValue());
			else if (("CnamOutBoundLastName").equals(param.getName()))
				tn.setCnamOutBoundLastName(param.getValue());
			else if (("NewVerizonBTN").equals(param.getName()) && param.getValue() != null)
				tn.setNewVerizonBTN(param.getValue());
			else if (("TnTypeOrdering").equals(param.getName()) && param.getValue() != null)
				tn.setTnTypeOrdering(param.getValue());
			else if (("IndustryPortability").equals(param.getName()))
				tn.setIndustryPortability(param.getValue());
			else if (("PortingServiceAddress").equals(param.getName()))
				tn.setPortingServiceAddress(param.getValue());
			else if (("IldRestriction").equals(param.getName()))
				tn.setIldRestriction(param.getValue());
			else if (("CurrentLecBtn").equals(param.getName()) && param.getValue() != null)
				tn.setCurrentLecBtn(param.getValue());
			else if (("Nomadic911").equals(param.getName()) && param.getValue() != null)
				tn.setNomadic911(param.getValue());
			else if (("TnAssignment").equals(param.getName()))
				tn.setTnAssignment(param.getValue());
			else if (("PointToNumber").equals(param.getName()))
				tn.setPointToNumber(param.getValue());
			else if (("Provider").equals(param.getName()) && param.getValue() != null)
				tn.setProvider(param.getValue());
			else if (("HuntGroupSequence").equals(param.getName()) && param.getValue() != null)
				tn.setHuntGroupSequence(param.getValue());

			else if (param.getName().equals("PubIp") && param.getValue() != null) {
				Integer pubip = null;
				try {
					pubip = Integer.decode(param.getValue());
				} catch (Exception e) {
					LOG.error("Exception: {}", e.getMessage(), e);
				}
				tn.setPubIp(pubip);
			} else if (param.getName().equals("PubIpIn") && param.getValue() != null)// VOV
			{
				Integer pubipin = null;
				try {
					pubipin = Integer.decode(param.getValue());
				} catch (Exception e) {
					LOG.error("Exception: {}", e.getMessage(), e);
				}
				tn.setPubIpIn(pubipin);
			} else if (param.getName().equals("PubIpOut") && param.getValue() != null) {
				Integer pubipout = null;
				try {
					pubipout = Integer.decode(param.getValue());
				} catch (Exception e) {
					LOG.error("Exception: {}", e.getMessage(), e);
				}
				tn.setPubIpOut(pubipout);
			} else if (param.getName().equals("ExistingTN") && param.getValue() != null)
				tn.setExistingTN(TNUtility.getBooleanFromYN(param.getValue()));
			else if (param.getName().equals("Available") && param.getValue() != null)
				tn.setAvailable(TNUtility.getBooleanFromYN(param.getValue()));
			else if (param.getName().equals("STNInd") && param.getValue() != null)
				tn.setSTNInd(Long.decode(param.getValue()));
			else if (param.getName().equals("SubscriberId") && param.getValue() != null)
				tn.setSubscriberId(TNUtility.getLongFromString(param.getValue()));
			else if (param.getName().equals("GroupTNId") && param.getValue() != null)
				tn.setGroupTNId(TNUtility.getLongFromString(param.getValue()));
			else if (param.getName().equals("EntityAction") && param.getValue() != null)
				tn.setEntityAction(param.getValue());
			else if (param.getName().equals("LinePort") && param.getValue() != null)
				tn.setLinePort(param.getValue());
			else if (param.getName().equals("TnType") && param.getValue() != null) {
				LOG.debug("TnType param.getValue() : {} ", param.getValue());
				if (param.getValue().equalsIgnoreCase("TWO_WAY_TN"))
					tn.setTnTypeEnum(TnType.TWO_WAY_TN);
				else if (param.getValue().equalsIgnoreCase("INBOUND_TN"))
					tn.setTnTypeEnum(TnType.INBOUND_TN);
				else if (param.getValue().equalsIgnoreCase("DID_TN"))
					tn.setTnTypeEnum(TnType.DID_TN);
				else if (param.getValue().equalsIgnoreCase("LINE_TN"))
					tn.setTnTypeEnum(TnType.LINE_TN);
				LOG.debug("TnType :: {} ", param.getValue());
			}
			else if (param.getName().equals("DeviceName") && param.getValue() != null)
				tn.setDeviceName(param.getValue());
			else if (param.getName().equals("PortInType") && param.getValue() != null)
				tn.setPortInType(PortInType.valueOf(param.getValue()));
			else if (param.getName().equals("TNDeleteType") && param.getValue() != null)
				tn.setDeleteType(DeleteType.valueOf(param.getValue()));
			else if (param.getName().equals("PortOutType") && param.getValue() != null)
				tn.setPortOutType(PortOutType.valueOf(param.getValue()));
			else if (param.getName().equals("PortingIndicator") && param.getValue() != null)
				tn.setPortingIndicator(param.getValue());
			else if (param.getName().equals("SubStatus") && param.getValue() != null)
				tn.setSubStatus(param.getValue());
			else if (param.getName().equals("OriginalCarrierPrefix") && param.getValue() != null)
				tn.setOriginalCarrierPrefix(param.getValue());
			else if (param.getName().equals("GainingCarrierPrefix") && param.getValue() != null)
				tn.setGainingCarrierPrefix(param.getValue());
			else if (param.getName().equals("LosingCarrierPrefix") && param.getValue() != null)
				tn.setLosingCarrierPrefix(param.getValue());
			else if (param.getName().equals("GatewayNumber") && param.getValue() != null)
				tn.setGatewayNumber(param.getValue());
			else if (param.getName().equals("ActDeact") && param.getValue() != null) {
				try {
					tn.setActDeact(Integer.parseInt(param.getValue()));
				} catch (NumberFormatException e) {
					LOG.error("Exception: {}", e.getMessage(), e);
				}
			} else if (param.getName().equals("TransitionType") && param.getValue() != null)
				tn.setTransitionType(TNEnum.TransitionType.valueByAcronym(param.getValue()));
			else if (param.getName().equals("OldLocationId") && param.getValue() != null)
				tn.setOldLocationId(param.getValue());
			else if (param.getName().equals("OldLocationEmptyFlag") && param.getValue() != null) {
				if (param.getValue() == "Y")
					tn.setOldLocationEmptyFlag(Boolean.TRUE);
			}
			// This is done.. since for res TN orders, unline any other entity
			// orders,
			// the entity params are being persisted under root "TNRecord" tag
			// in TOD
			// Also, we want to populate locId and custId from header into
			// TNRecord obj
			// to continue how it was done before this change( root param in
			// TOD).
			else if (param.getName().equals("TNRecord"))
				createInstanceFromParamInfo(param, tn); // nila fix 1
			else if (param.getName().equals("AdditionalAttribs")) {
				if (param.getChildParams() != null)
					for (ParamInfo par2 : param.getChildParams())
						tn.addAttrib(par2.getName(), par2.getValue());
			} else if (param.getName().equals("HotCutIndicator")) {
				if (param.getValue() != null && param.getValue().equals("Y"))
					tn.setHotCutIndicator(Boolean.TRUE);
			} else if (param.getName().equals("CDDDIndicator")) {
				if (param.getValue() != null && param.getValue().equals("Y"))
					tn.setCDDDIndicator(Boolean.TRUE);
			} else if (param.getName().equals("PSALI") && param.getValue() != null) {
				tn.setPSALI(param.getValue());
			} else if (param.getName().equals("VerizonBTN") && param.getValue() != null) {
				LOG.info("in TNUTIL ->VerizonBTN-> : {}", param.getValue());

				tn.setVerizonBTN(param.getValue());
			}
		}
		return tn;
	}

	public static void setParam(TrunkGroupEntity group, ParamInfo param) {

		if (param.getName().equals("Device")) {
			// group.setDevice(DeviceUtil.createInstanceFromParamInfo(param));
			// TODO Check Device Enablement
		} else if (param.getName().equals("NonPkgFeatures")) {
			if (param.getChildParams() != null)
				for (ParamInfo par2 : param.getChildParams())
					group.addNonPkgFeature(par2.getValue());
		} else if (param.getName().equals("DisableFeatureList")) {
			if (param.getChildParams() != null)
				for (ParamInfo par2 : param.getChildParams())
					group.addDisableFeature(par2.getValue());
		} else if (param.getName().equals("AdditionalAttribs")) {
			if (param.getChildParams() != null)
				for (ParamInfo par2 : param.getChildParams())
					group.addAttrib(par2.getName(), par2.getValue());
		}

		LOG.debug("Name: {} :: Value: {} ::ChildParamCnt:", param.getName(), param.getValue(),
				(param.getChildParams() == null ? 0 : param.getChildParams().size()));

		if (param.getName().equals("GroupId"))
			group.setGroupId(new Long(param.getValue()));
		else if (param.getName().equals("CustomerId"))
			group.setCustomerId(param.getValue());
		else if (param.getName().equals("LocationId"))
			group.setLocationId(param.getValue());
		else if (param.getName().equals("DepartmentId"))
			group.setDepartmentId(param.getValue());
		else if (param.getName().equals("GroupType") && param.getValue() != null)
			group.setGroupType(Entity.GroupType.valueOf(param.getValue()));
		else if (param.getName().equals("Name"))
			group.setName(param.getValue());
		else if (param.getName().equals("MaxConcurrentCallLimit") && param.getValue() != null)
			group.setMaxConcurrentCallLimit(new BigInteger(param.getValue()));
		else if (param.getName().equals("CLIDFirstName"))
			group.setCLIDFirstName(param.getValue());
		else if (param.getName().equals("CLIDLastName"))
			group.setCLIDLastName(param.getValue());
		else if (param.getName().equals("TnCLIDFirstName"))
			group.setTnCLIDFirstName(param.getValue());
		else if (param.getName().equals("TnCLIDLastName"))
			group.setTnCLIDLastName(param.getValue());
		else if (param.getName().equals("SimpleFeaturePackage"))
			group.setSimpleFeaturePackage(param.getValue());
		else if (param.getName().equals("TerminationOption"))
			group.setTerminationOption(param.getValue());
		else if (param.getName().equals("ForwardToGroupId") && param.getValue() != null)
			group.setForwardToGroupId(new Long(param.getValue()));
		else if (param.getName().equals("InvitationTimer") && param.getValue() != null)
			group.setInvitationTimer(new Integer(param.getValue()));
		else if (param.getName().equals("CreateExtension"))
			group.setCreateExtension(TNUtility.getBooleanFromYN(param.getValue()));
		else if (param.getName().equals("ForwardToGroupName"))
			group.setForwardToGroupName(param.getValue());
		else if (param.getName().equals("ForwardToNumber"))
			group.setForwardToNumber(param.getValue());
		else if (param.getName().equals("VMBoxNumber"))
			group.setVMNumber(param.getValue());
		else if (param.getName().equals("VMBoxNumber"))
			group.setVMNumber(param.getValue());
		else if (param.getName().equals("VMPin"))
			group.setVmPin(param.getValue());
		else if (param.getName().equals("VMType"))
			group.setVMType(param.getValue());
		else if (param.getName().equals("LinePort"))
			group.setLinePort(param.getValue());
		else if (param.getName().equals("Extension"))
			group.setExtension(param.getValue());
		else if (param.getName().equals("PrivateNumber"))
			group.setPrivateNumber(param.getValue());
		else if (param.getName().equals("PilotTN"))
			group.setPilotTN(param.getValue());
		else if (param.getName().equals("FirstActiveTN"))
			group.setFirstActiveTN(param.getValue());
		else if (param.getName().equals("LastActiveTN"))
			group.setLastActiveTN(param.getValue());
		else if (param.getName().equals("LinePortLength") && param.getValue() != null)
			group.setLinePortLength(new Integer(param.getValue()));
		else if (param.getName().equals("HotCutIndicator")) {
			if (param.getValue() != null && param.getValue().equals("Y"))
				group.setHotCutIndicator(Boolean.TRUE);
		} else if (param.getName().equals("CDDDIndicator")) {
			if (param.getValue() != null && param.getValue().equals("Y"))
				group.setCDDDIndicator(Boolean.TRUE);
		} else if (param.getName().equals("PQInstanceId") && param.getValue() != null) {
			try {
				group.setPqInstanceId(new Long(param.getValue()));
			} catch (NumberFormatException npe) {

			}
		}
	}

	public static TrunkGroupEntity createGroupInstanceFromParamInfo(ParamInfo parent) {

		LOG.info("parent.getChildParams()  : {} ", parent.getChildParams());

		if (parent == null)
			return null;

		TrunkGroupEntity group = new TrunkGroupEntity();

		if (parent.getChildParams() == null)
			return null;

		for (ParamInfo param : parent.getChildParams()) {
			LOG.info("param.getName() : {}  ", param.getName());

			setParam(group, param);

		}

		// LogUtil.log(group);
		return group;
	}

	public GroupTNEntity enrichGroupTNEntityWithInventory(VOIPOrderRequest voipOrderRequest,
			GroupTNEntity groupTNEntity) throws TranslatorException, GenericException {

		LOG.info("Entered enrichGroupEntityWithInventory");

		LOG.info("++Level 9+++++Original groupTN Entity : {} ", groupTNEntity);

		LOG.info("++Level 9+++++Changed groupTN Entity : {} ", groupTNEntity.getGroupTNEntity());

		GroupTNEntity groupTNEntityInv = orderServiceHelperImpl
				.getEntityDetailsFromInventory(groupTNEntity.getLocationId(), GroupTNEntity.class);

		// Copying groupTN Inv Details to Original groupTN Entity

		LOG.info("++Level 10+++++Original groupTN Entity : {} ", groupTNEntity);

		LOG.info("++Level 10+++++Changed groupTN Entity : {} ", groupTNEntity.getGroupTNEntity());

		LOG.info("++Level 10+++++Original groupTN Entity locationEntityInv : {} ", groupTNEntityInv);

		LOG.info("++Level 10+++++Changed groupTN Entity groupTNEntityInv.getGroupTNEntity() : {} ",
				groupTNEntityInv.getGroupTNEntity());

		groupTNEntity = copyFields(groupTNEntityInv, groupTNEntity);

		LOG.info("++Level 11+++++Original groupTN Entity : {} ", groupTNEntity);

		LOG.info("++Level 11+++++Changed groupTN Entity : {} ", groupTNEntity.getGroupTNEntity());

		if (groupTNEntity.getGroupTNEntity() != null) {
			// Copying groupTN Inv Details to Changed groupTN Entity
			copyFields(groupTNEntity, groupTNEntity.getGroupTNEntity());

			LOG.info("++Level 3+++++Original groupTN Entity : {} ", groupTNEntity);

			LOG.info("++Level 3+++++Changed groupTN Entity : {} ", groupTNEntity.getGroupTNEntity());
		}

		LOG.info("Exit enrichgroupTNEntityWithInventory groupTN Enriched = {} ", groupTNEntity);

		return groupTNEntity;
	}

	/**
	 * @param currentGroupTNEntity
	 * @param resultGroupTNEntity
	 * @return
	 */
	private GroupTNEntity copyFields(GroupTNEntity currentGroupTNEntity, GroupTNEntity resultGroupTNEntity) {

		if (resultGroupTNEntity.getGroupTNId() == null && currentGroupTNEntity.getGroupTNId() != null) {
			resultGroupTNEntity.setGroupTNId(currentGroupTNEntity.getGroupTNId());
		}
		if (resultGroupTNEntity.getTnRecord() == null && currentGroupTNEntity.getTnRecord() != null) {
			resultGroupTNEntity.setTnRecord(currentGroupTNEntity.getTnRecord());
		}
		if (resultGroupTNEntity.getExtension() == null && currentGroupTNEntity.getExtension() != null) {
			resultGroupTNEntity.setExtension(currentGroupTNEntity.getExtension());
		}
		if (resultGroupTNEntity.getPrivateNumber() == null && currentGroupTNEntity.getPrivateNumber() != null) {
			resultGroupTNEntity.setPrivateNumber(currentGroupTNEntity.getPrivateNumber());
		}
		if (resultGroupTNEntity.getSipDomain() == null && currentGroupTNEntity.getSipDomain() != null) {
			resultGroupTNEntity.setSipDomain(currentGroupTNEntity.getSipDomain());
		}
		if (resultGroupTNEntity.getTnCLIDFirstName() == null && currentGroupTNEntity.getTnCLIDFirstName() != null) {
			resultGroupTNEntity.setTnCLIDFirstName(currentGroupTNEntity.getTnCLIDFirstName());
		}
		if (resultGroupTNEntity.getTnCLIDLastName() == null && currentGroupTNEntity.getTnCLIDLastName() != null) {
			resultGroupTNEntity.setTnCLIDLastName(currentGroupTNEntity.getTnCLIDLastName());
		}
		if (resultGroupTNEntity.getSequenceNo() == null && currentGroupTNEntity.getSequenceNo() != null) {
			resultGroupTNEntity.setSequenceNo(currentGroupTNEntity.getSequenceNo());
		}
		if (resultGroupTNEntity.getLinePort() == null && currentGroupTNEntity.getLinePort() != null) {
			resultGroupTNEntity.setLinePort(currentGroupTNEntity.getLinePort());
		}
		if (resultGroupTNEntity.getVmBoxNumber() == null && currentGroupTNEntity.getVmBoxNumber() != null) {
			resultGroupTNEntity.setVmBoxNumber(currentGroupTNEntity.getVmBoxNumber());
		}
		if (resultGroupTNEntity.getVmPin() == null && currentGroupTNEntity.getVmPin() != null) {
			resultGroupTNEntity.setVmPin(currentGroupTNEntity.getVmPin());
		}
		if (resultGroupTNEntity.getTrunkGroupEntity() == null && currentGroupTNEntity.getTrunkGroupEntity() != null) {
			resultGroupTNEntity.setTrunkGroupEntity(currentGroupTNEntity.getTrunkGroupEntity());
		}
		if (resultGroupTNEntity.getVmType() == null && currentGroupTNEntity.getVmType() != null) {
			resultGroupTNEntity.setVmType(currentGroupTNEntity.getVmType());
		}
		if (resultGroupTNEntity.getNonPkgFeatures() == null && currentGroupTNEntity.getNonPkgFeatures() != null) {
			resultGroupTNEntity.setNonPkgFeatures(currentGroupTNEntity.getNonPkgFeatures());
		}
		if (resultGroupTNEntity.getDisableFeatureList() == null
				&& currentGroupTNEntity.getDisableFeatureList() != null) {
			resultGroupTNEntity.setDisableFeatureList(currentGroupTNEntity.getDisableFeatureList());
		}
		if (resultGroupTNEntity.getSubscriberId() == null && currentGroupTNEntity.getSubscriberId() != null) {
			resultGroupTNEntity.setSubscriberId(currentGroupTNEntity.getSubscriberId());
		}
		if (resultGroupTNEntity.getPkgDiffFeatures() == null && currentGroupTNEntity.getPkgDiffFeatures() != null) {
			resultGroupTNEntity.setPkgDiffFeatures(currentGroupTNEntity.getPkgDiffFeatures());
		}
		if (resultGroupTNEntity.getUserFeatures() == null && currentGroupTNEntity.getUserFeatures() != null) {
			resultGroupTNEntity.setUserFeatures(currentGroupTNEntity.getUserFeatures());
		}
		if (resultGroupTNEntity.getRegion() == null && currentGroupTNEntity.getRegion() != null) {
			resultGroupTNEntity.setRegion(currentGroupTNEntity.getRegion());
		}
		if (resultGroupTNEntity.getCustomerId() == null && currentGroupTNEntity.getCustomerId() != null) {
			resultGroupTNEntity.setCustomerId(currentGroupTNEntity.getCustomerId());
		}
		if (resultGroupTNEntity.getLocationId() == null && currentGroupTNEntity.getLocationId() != null) {
			resultGroupTNEntity.setLocationId(currentGroupTNEntity.getLocationId());
		}		
		
		return resultGroupTNEntity;
	}

	/* (non-Javadoc)
	 * @see com.vz.esap.translation.order.transformer.GroupTnTransformer#groupTnEntityInventoryTogroupTnEntityTransformer(java.util.Map)
	 */
	@Override
	public GroupTNEntity groupTnEntityInventoryTogroupTnEntityTransformer(Map<String, String> resultantRow) {
		
		LOG.info("Entered groupTnEntityInventoryTogroupTnEntityTransformer");
		
		GroupTNEntity groupTNEntity = new GroupTNEntity();
		
		if(resultantRow.get("GROUP_TN_ID") != null) {
			groupTNEntity.setGroupTNId(Long.valueOf(resultantRow.get("GROUP_TN_ID")));
		}
		if(resultantRow.get("GROUP_ID") != null) {
			groupTNEntity.setGroupId(Long.valueOf(resultantRow.get("GROUP_ID")));
		}
		if(resultantRow.get("SEQUENCE_NO") != null) {
			groupTNEntity.setSequenceNo(Integer.valueOf(resultantRow.get("SEQUENCE_NO")));
		}
		groupTNEntity.setExtension(resultantRow.get("EXTENSION"));
		groupTNEntity.setPrivateNumber(resultantRow.get("PRIVATE_NUMBER"));
		groupTNEntity.setLinePort(resultantRow.get("LINE_PORT"));
		groupTNEntity.setTnCLIDFirstName(resultantRow.get("CID_FIRST_NAME"));
		groupTNEntity.setTnCLIDLastName(resultantRow.get("CID_LAST_NAME"));
		groupTNEntity.setVmBoxNumber(resultantRow.get("VM_BOX_NUM"));
		if(resultantRow.get("ENV_ORDER_ID") != null) {
			groupTNEntity.setEnvOrderId(Long.valueOf(resultantRow.get("ENV_ORDER_ID")));
		}
		groupTNEntity.setSubscriberId(resultantRow.get("SUB_ID"));

		LOG.info("Exit groupTnEntityInventoryTogroupTnEntityTransformer ");
		return groupTNEntity;
	}
	
	/* (non-Javadoc)
	 * @see com.vz.esap.translation.order.transformer.GroupTnTransformer#tnEntityInventoryToTnEntityTransformer(java.util.Map)
	 */
	@Override
	public TNEntity tnEntityInventoryToTnEntityTransformer(Map<String, String> resultantRow) {
		LOG.info("Entered tnEntityInventoryToTnEntityTransformer");
		TNEntity tnEntity = new TNEntity();
		
		if(resultantRow.get("TN_POOL_ID") != null) {
			tnEntity.setTNPoolId(Long.valueOf(resultantRow.get("TN_POOL_ID")));
		}
		
		// Updated ladder with DID_TN and LINE_TN 
		if(resultantRow.get("TN_TYPE") != null) {
			if(TnType.INBOUND_TN.getIndex() == Integer.valueOf(resultantRow.get("TN_TYPE"))) {
				tnEntity.setTnTypeEnum(TnType.INBOUND_TN);
			} else if(TnType.TWO_WAY_TN.getIndex() == Integer.valueOf(resultantRow.get("TN_TYPE"))) {
				tnEntity.setTnTypeEnum(TnType.TWO_WAY_TN);
			} else if(TnType.DID_TN.getIndex() == Integer.valueOf(resultantRow.get("TN_TYPE"))) {
				tnEntity.setTnTypeEnum(TnType.DID_TN);
			} else if(TnType.LINE_TN.getIndex() == Integer.valueOf(resultantRow.get("TN_TYPE"))) {
				tnEntity.setTnTypeEnum(TnType.LINE_TN);
			} 
		}
		
		tnEntity.setLocationId(resultantRow.get("LOCATION_ID"));
		tnEntity.setTn(resultantRow.get("TN"));
		
		if(resultantRow.get("TN_STATUS") != null) {
			if(Integer.valueOf(resultantRow.get("TN_STATUS")) == 1) {
				tnEntity.setActiveStatus(ActiveStatus.ACTIVE);
			} else if(Integer.valueOf(resultantRow.get("TN_STATUS")) == 2) {
				tnEntity.setActiveStatus(ActiveStatus.DELETE_PENDING);
			}
		}
		
		if(resultantRow.get("PORTED_STATUS") != null) {
			if(Integer.valueOf(resultantRow.get("PORTED_STATUS")) == 0) {
				tnEntity.setPortStatus(TNEntity.PortStatus.NATIVE);
			} else if(Integer.valueOf(resultantRow.get("PORTED_STATUS")) == 1) {
				tnEntity.setPortStatus(TNEntity.PortStatus.PORT_PENDING);
			}  else if(Integer.valueOf(resultantRow.get("PORTED_STATUS")) == 2) {
				tnEntity.setPortStatus(TNEntity.PortStatus.PORTED);
			}
		}
		
		tnEntity.setSubStatus(resultantRow.get("NPA_SPLIT_STATUS"));
		tnEntity.setSwitchClli(resultantRow.get("SWITCH_CLLI"));
		tnEntity.setTrunkId(resultantRow.get("TRUNK"));
		if(resultantRow.get("ACTIVE_IND") != null) {
			tnEntity.setsTnInd(Long.valueOf(resultantRow.get("ACTIVE_IND")));
		}
		if(resultantRow.get("STN_IND") != null) {
			tnEntity.setSTNInd(Long.valueOf(resultantRow.get("STN_IND")));
		}
		if(resultantRow.get("ACT_DEACT") != null) {
			tnEntity.setActDeact(Integer.valueOf(resultantRow.get("ACT_DEACT")));
		}
		tnEntity.setLidb(resultantRow.get("LI_IND"));
		if(resultantRow.get("PUBIP") != null) {
			tnEntity.setPubIp(Integer.valueOf(resultantRow.get("PUBIP")));
		}
		tnEntity.setTspCode(resultantRow.get("TSP_CODE"));
		tnEntity.setReplacementCLLI(resultantRow.get("REPLACEMENT_CLI"));
		if(resultantRow.get("TRANSITION_TYPE") != null) {
			tnEntity.setTransitionType(Integer.valueOf(resultantRow.get("TRANSITION_TYPE")));
		}
		tnEntity.setPSALI(resultantRow.get("PS_ALI"));
		tnEntity.setVerizonBTN(resultantRow.get("VERIZON_BTN"));
		if(resultantRow.get("PUBIP_IN") != null) {
			tnEntity.setPubIpIn(Integer.valueOf(resultantRow.get("PUBIP_IN")));
		}
		if(resultantRow.get("PUBIP_OUT") != null) {
			tnEntity.setPubIpOut(Integer.valueOf(resultantRow.get("PUBIP_OUT")));
		}
		if(resultantRow.get("TnAssignment") != null) {
			tnEntity.setTnAssignment(resultantRow.get("TnAssignment"));
		}
		LOG.info("Exit tnEntityInventoryToTnEntityTransformer");
		return tnEntity;
	}
}
