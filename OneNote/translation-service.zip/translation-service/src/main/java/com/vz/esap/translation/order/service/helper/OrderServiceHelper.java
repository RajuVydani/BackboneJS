package com.vz.esap.translation.order.service.helper;

import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.vz.esap.translation.connector.model.DBServiceResponse;
import com.vz.esap.translation.dao.model.TblEnvOrder;
import com.vz.esap.translation.dao.model.TblOrder;
import com.vz.esap.translation.dao.model.TblOrderDetails;
import com.vz.esap.translation.entity.DeviceEntity;
import com.vz.esap.translation.entity.Entity.GroupType;
import com.vz.esap.translation.enums.EsapEnum.AuthFeatureType;
import com.vz.esap.translation.enums.EsapEnum.LocationType;
import com.vz.esap.translation.enums.EsapEnum.OrderEntity;
import com.vz.esap.translation.enums.EsapEnum.SolutionType;
import com.vz.esap.translation.enums.EsapEnum.StatusCode;
import com.vz.esap.translation.exception.ApplicationInterfaceException;
import com.vz.esap.translation.exception.GenericException;
import com.vz.esap.translation.exception.TranslatorException;
import com.vz.esap.translation.order.dao.VOIPOrderDao;
import com.vz.esap.translation.order.model.OrderHeader;
import com.vz.esap.translation.order.model.request.Feature;
import com.vz.esap.translation.order.model.request.ParamInfo;
import com.vz.esap.translation.order.model.request.VOIPOrderRequest;
import com.vz.esap.translation.order.model.response.VoipOrderResponse;

/**
 * @author kalagsu
 *
 */
public interface OrderServiceHelper {

	/**
	 * @param voipOrderRequest
	 * @return tblEnvOrders
	 * @throws GenericException
	 */
	List<TblEnvOrder> getMatchingValidationEnvOrder(VOIPOrderRequest voipOrderRequest) throws GenericException;

	/**
	 * @param gchId
	 * @return dbServiceResponse
	 * @throws ApplicationInterfaceException
	 * @throws GenericException
	 */
	DBServiceResponse getEnterpriseInformationFromGchId(String gchId)
			throws ApplicationInterfaceException, GenericException;

	/**
	 * @param tblEnvOrder
	 * @return tblOrderList
	 * @throws TranslatorException
	 * @throws GenericException
	 */
	List<TblOrder> getMatchingPassOrder(TblEnvOrder tblEnvOrder) throws GenericException;

	/**
	 * @param tblOrderBean
	 * @return ordDetails
	 * @throws TranslatorException
	 * @throws GenericException
	 */
	List<TblOrderDetails> getMatchingOrderDetails(TblOrder tblOrderBean) throws TranslatorException, GenericException;

	/**
	 * @param voipOrderRequest
	 * @param tblOrderObject
	 * @param headerParamInfo
	 * @param isNewCustomer
	 *            TODO
	 * @return headerParamInfo
	 * @throws GenericException
	 */
	ParamInfo createEnterpriseOrderDetailsParamInfo(VOIPOrderRequest voipOrderRequest, TblOrder tblOrderObject,
			ParamInfo headerParamInfo, boolean isNewCustomer) throws GenericException;

	/**
	 * @param tblOrderObject
	 * @param virtualAddrCountry
	 * @return count
	 * @throws TranslatorException
	 * @throws GenericException
	 */
	Long createValidateOrderServices(TblOrder tblOrderObject, String virtualAddrCountry)
			throws TranslatorException, GenericException;

	/**
	 * @param voipOrderRequest
	 * @param tblOrderObject
	 * @param isNewCustomer
	 * @return count
	 * @throws TranslatorException
	 * @throws GenericException
	 */
	Long createEsipEslOrderDetails(VOIPOrderRequest voipOrderRequest, TblOrder tblOrderObject, boolean isNewCustomer)
			throws TranslatorException, GenericException;

	/**
	 * @param voipOrderRequest
	 * @param status
	 * @param tblEnvOrderObject
	 * @return tblOrderObject
	 * @throws TranslatorException
	 * @throws GenericException
	 */
	TblOrder createEsipEslOrderHeader(VOIPOrderRequest voipOrderRequest, int status, TblEnvOrder tblEnvOrderObject)
			throws TranslatorException, GenericException;

	/**
	 * @param voipOrderRequest
	 * @param status
	 * @return tblEnvOrderObject
	 * @throws TranslatorException
	 * @throws GenericException
	 */
	TblEnvOrder createEsipEslEnvOrder(VOIPOrderRequest voipOrderRequest, int status)
			throws TranslatorException, GenericException;

	/**
	 * @param voipOrderRequest
	 * @param headerParamInfo
	 * @param tblOrderObject
	 * @return paramInfo
	 * @throws GenericException
	 */
	ParamInfo createLocationOrderDetailsParamInfo(VOIPOrderRequest voipOrderRequest, ParamInfo headerParamInfo,
			TblOrder tblOrderObject) throws GenericException;

	/**
	 * @param voipOrderRequest
	 * @param headerParamInfo
	 * @return paramInfo
	 * @throws GenericException
	 */
	ParamInfo createETOrderDetailsParamInfo(VOIPOrderRequest voipOrderRequest, ParamInfo headerParamInfo)
			throws GenericException;

	/**
	 * @param voipOrderRequest
	 * @param headerParamInfo
	 * @param tblOrderObject
	 * @return headerParamInfo
	 * @throws GenericException
	 */
	ParamInfo createDeviceOrderDetailsParamInfo(VOIPOrderRequest voipOrderRequest, ParamInfo headerParamInfo,
			TblOrder tblOrderObject) throws GenericException;

	/**
	 * @param voipOrderRequest
	 * @param headerParamInfo
	 * @param tblOrderObject
	 * @return headerParamInfo
	 * @throws GenericException
	 */
	ParamInfo createTrunkGroupOrderDetailsParamInfo(VOIPOrderRequest voipOrderRequest, ParamInfo headerParamInfo,
			TblOrder tblOrderObject) throws GenericException;

	/**
	 * @param voipOrderRequest
	 * @param status
	 * @return tblEnvOrder
	 * @throws TranslatorException
	 * @throws GenericException
	 */
	TblEnvOrder createEsipEblEnvOrder(VOIPOrderRequest voipOrderRequest, int status)
			throws TranslatorException, GenericException;

	/**
	 * @param voipOrderRequest
	 * @param status
	 * @param tblEnvOrderObject
	 * @return tblOrder
	 * @throws TranslatorException
	 * @throws GenericException
	 */
	TblOrder createEsipEblOrderHeader(VOIPOrderRequest voipOrderRequest, int status, TblEnvOrder tblEnvOrderObject)
			throws TranslatorException, GenericException;

	/**
	 * @param voipOrderRequest
	 * @param tblOrderObject
	 * @return count
	 * @throws TranslatorException
	 * @throws GenericException
	 */
	Long createEsipEblOrderDetails(VOIPOrderRequest voipOrderRequest, TblOrder tblOrderObject)
			throws TranslatorException, GenericException;

	/**
	 * @param voipOrderRequest
	 * @param headerParamInfo
	 * @return
	 * @throws GenericException
	 */
	ParamInfo createGroupTNOrderDetailsParamInfo(VOIPOrderRequest voipOrderRequest, ParamInfo headerParamInfo)
			throws GenericException;

	/**
	 * @param voipOrderRequest
	 * @param headerParamInfo
	 * @param tblOrderObject
	 * @return headerParamInfo
	 * @throws GenericException
	 */
	ParamInfo createNbsOrderDetailsParamInfo(VOIPOrderRequest voipOrderRequest, ParamInfo headerParamInfo,
			TblOrder tblOrderObject) throws GenericException;

	/**
	 * @param wfService
	 * @param paramMap
	 * @return clli
	 * @throws GenericException
	 */
	String getClli(String wfService, Map<String, String> paramMap) throws GenericException;

	/**
	 * @param tblOrderBean
	 * @return
	 * @throws TranslatorException
	 * @throws GenericException
	 */
	List<TblOrderDetails> getMatchingTnOrderDetails(TblOrder tblOrderBean) throws TranslatorException, GenericException;

	/**
	 * IpFlex
	 * 
	 * @param voipOrderRequest
	 * @param status
	 * @return
	 * @throws TranslatorException
	 * @throws GenericException
	 */
	TblEnvOrder createIpFlexEnvOrder(VOIPOrderRequest voipOrderRequest, int status)
			throws TranslatorException, GenericException;

	/**
	 * IpFlex
	 * 
	 * @param voipOrderRequest
	 * @param status
	 * @param tblEnvOrderObject
	 * @return
	 * @throws TranslatorException
	 * @throws GenericException
	 */
	TblOrder createIpFlexOrderHeader(VOIPOrderRequest voipOrderRequest, int status, TblEnvOrder tblEnvOrderObject)
			throws TranslatorException, GenericException;

	/**
	 * IpFlex
	 * 
	 * @param voipOrderRequest
	 * @param tblOrderObject
	 * @param isNewCustomer
	 *            TODO
	 * @return
	 * @throws TranslatorException
	 * @throws GenericException
	 */
	Long createIpFlexOrderDetails(VOIPOrderRequest voipOrderRequest, TblOrder tblOrderObject,
			Map<String, String> productDetails, boolean isNewCustomer) throws TranslatorException, GenericException;

	/**
	 * @param eslId
	 * @return enterpriseId
	 * @throws ApplicationInterfaceException
	 * @throws GenericException
	 */
	String getEnterpriseInformationFromEsl(String eslId) throws ApplicationInterfaceException, GenericException;

	/**
	 * @param processName
	 * @param paramName
	 * @return dBServiceResponse
	 * @throws ApplicationInterfaceException
	 * @throws GenericException
	 */
	DBServiceResponse getConfigParamValue(String processName, String paramName)
			throws ApplicationInterfaceException, GenericException;

	/**
	 * @param tnCount
	 * @return isEligible
	 * @throws ApplicationInterfaceException
	 * @throws GenericException
	 */
	boolean isSystemBulkUpdateEligible(long tnCount) throws ApplicationInterfaceException, GenericException;

	List<TblEnvOrder> getMatchingPrevPassEnvOrder(VOIPOrderRequest prevVoipOrderRequest, int envOrderStatus,
			int envOrderClassify) throws GenericException;

	/**
	 * @param voipOrderRequest
	 * @return
	 * @throws GenericException
	 */
	AuthFeatureType getAuthFeatureType(VOIPOrderRequest voipOrderRequest) throws GenericException;

	/**
	 * @param eslId
	 * @return Map<String, String>
	 * @throws ApplicationInterfaceException
	 * @throws GenericException
	 */
	Map<String, String> getEnterpriseFromEsl(String eslId) throws ApplicationInterfaceException, GenericException;

	/**
	 * @param voipOrderRequest
	 * @param status
	 * @param statusExcluded
	 *            TODO
	 * @return tblEnvOrderList
	 * @throws GenericException
	 */
	List<TblEnvOrder> getMatchingReleaseEnvOrder(VOIPOrderRequest voipOrderRequest, long status,
			List<Long> statusExcluded) throws GenericException;

	/**
	 * @param voipOrderRequestCurrent
	 * @param objectSource
	 * @param currentEnvOrderId
	 * @throws GenericException
	 */
	<T> void handlePreviousOrder(VOIPOrderRequest voipOrderRequestCurrent, T orderEntity, Long currentEnvOrderId)
			throws GenericException;

	/**
	 * @param tblEnvOrder
	 * @param orderEntity
	 * @return TblOrderList
	 * @throws GenericException
	 */
	List<TblOrder> getMatchingPrevPassOrder(TblEnvOrder tblEnvOrder, OrderEntity orderEntity) throws GenericException;

	/**
	 * @param primaryId
	 * @param entityClass
	 * @return
	 * @throws TranslatorException
	 * @throws GenericException
	 */
	<T> T getEntityDetailsFromInventory(String primaryId, Class<T> entityClass)
			throws TranslatorException, GenericException;

	/**
	 * @param currentEnvOrderId
	 * @param prevOrderId
	 * @param tblEnvOrderObject
	 *            TODO
	 */
	void handleSuppOrderWithNoChange(long currentEnvOrderId, long prevOrderId, TblEnvOrder tblEnvOrderObject);

	/**
	 * @param voipOrderRequest
	 * @param status
	 * @return
	 * @throws TranslatorException
	 * @throws GenericException
	 */
	TblEnvOrder createHpbxEnvOrder(VOIPOrderRequest voipOrderRequest, int status)
			throws TranslatorException, GenericException;

	/**
	 * @param voipOrderRequest
	 * @param status
	 * @param tblEnvOrderObject
	 * @return
	 * @throws TranslatorException
	 * @throws GenericException
	 */
	TblOrder createHpbxOrderHeader(VOIPOrderRequest voipOrderRequest, int status, TblEnvOrder tblEnvOrderObject)
			throws TranslatorException, GenericException;

	/**
	 * @param voipOrderRequest
	 * @param tblOrderObject
	 * @param isNewCustomer
	 * @return
	 * @throws TranslatorException
	 * @throws GenericException
	 */
	Long createHpbxOrderDetails(VOIPOrderRequest voipOrderRequest, TblOrder tblOrderObject, boolean isNewCustomer)
			throws TranslatorException, GenericException;

	/**
	 * @param currentEntity
	 * @param resultEntity
	 * @param entityClass
	 * @return
	 * @throws ApplicationInterfaceException
	 * @throws IllegalAccessException
	 * @throws TranslatorException
	 */
	/*
	 * <T> T copyEntity(T currentEntity, T resultEntity, Class<T> entityClass)
	 * throws ApplicationInterfaceException, IllegalAccessException,
	 * TranslatorException;
	 */
	/**
	 * TODO Disconn
	 * 
	 * @param voipLocationId
	 * @return String
	 * @throws ApplicationInterfaceException
	 * @throws GenericException
	 */
	String findRemoteLocationEnterpriseId(String voipLocationId) throws ApplicationInterfaceException, GenericException;

	/**
	 * TODO Disconn - Commented out Non usage
	 * 
	 * @param voipLocationId
	 * @return
	 * @throws TranslatorException
	 * @throws GenericException
	 */
	// void
	// populateEslEsipLocSuspendOrDeactivateLocationOrderDetails(VOIPOrderRequest
	// voipOrderRequest, TblOrder tblOrderObject) throws TranslatorException,
	// GenericException;

	/**
	 * TODO Disconn - Commented out Non usage
	 * 
	 * @param voipLocationId
	 * @return
	 * @throws TranslatorException
	 * @throws GenericException
	 */
	// void
	// populateEslEsipLocSuspendOrDeactivateEnterpriseOrderDetails(VOIPOrderRequest
	// voipOrderRequest, TblOrder tblOrderObject) throws TranslatorException,
	// GenericException;

	/**
	 * Disconn - Commented out Non usage
	 * 
	 * @param voipLocationId
	 * @return void
	 * @throws TranslatorException
	 * @throws GenericException
	 */
	void populateEblEsipLocSuspendOrDeactivateOrderDetails(VOIPOrderRequest voipOrderRequest, TblOrder tblOrderObject)
			throws TranslatorException, GenericException;

	/**
	 * Disconn
	 * 
	 * @param voipLocationId
	 * @return void
	 * @throws TranslatorException
	 * @throws GenericException
	 */
	public void createLocationOrderFromInventoryDetails(VOIPOrderRequest voipOrderRequest,
			TblEnvOrder tblEnvOrderObject) throws TranslatorException, GenericException;

	/**
	 * Disconn
	 * 
	 * @param voipLocationId
	 * @return void
	 * @throws TranslatorException
	 * @throws GenericException
	 */
	public void createEnterpriseOrder(VOIPOrderRequest voipOrderRequest, TblEnvOrder tblEnvOrderObject)
			throws TranslatorException, GenericException;

	/**
	 * Disconn
	 * 
	 * @param voipLocationId
	 * @return void
	 * @throws TranslatorException
	 * @throws GenericException
	 */
	public void createTNOrderFromInventoryDetails(VOIPOrderRequest voipOrderRequest, TblEnvOrder tblEnvOrderObject)
			throws TranslatorException, GenericException;

	/**
	 * @param voipOrderRequest
	 * @param tblOrderObject
	 * @throws TranslatorException
	 * @throws GenericException
	 */
	void populateEslEsipLocSuspendOrDeactivateOrderDetails(VOIPOrderRequest voipOrderRequest, TblOrder tblOrderObject)
			throws TranslatorException, GenericException;

	/**
	 * @param voipOrderRequest
	 * @param dbServiceResponseTblCust
	 * @return
	 * @throws GenericException
	 */
	boolean isNewEsipEnterprise(VOIPOrderRequest voipOrderRequest, DBServiceResponse dbServiceResponseTblCust)
			throws GenericException;

	/**
	 * @param deviceFeature
	 * @param solutionType
	 * @param trunkType
	 * @return
	 * @throws ApplicationInterfaceException
	 * @throws GenericException
	 */
	DeviceEntity getOrderCpeDeviceDetails(Feature deviceFeature, SolutionType solutionType, GroupType trunkType)
			throws ApplicationInterfaceException, GenericException;

	/**
	 * @param voipOrderRequest
	 * @param milestone
	 * @param statusCode
	 * @param errorDescription
	 * @return VoipOrderResponse
	 * @throws GenericException
	 * @throws JsonProcessingException
	 * @throws TranslatorException
	 */
	VoipOrderResponse handleTranslationException(VOIPOrderRequest voipOrderRequest, String milestone,
			StatusCode statusCode, String errorDescription)
			throws GenericException, JsonProcessingException, TranslatorException;

	/**
	 * @param voipOrderRequest
	 * @return
	 */
	String getMinorOrderType(VOIPOrderRequest voipOrderRequest);

	/**
	 * @param solutionTypeStr
	 * @return
	 */
	SolutionType getSolutionTypeFromBodReuest(String solutionTypeStr);

	/**
	 * @param functionCode
	 * @return
	 */
	long getUpstreamTaskIdFromFunctionCode(String functionCode);

	/**
	 * @param envOrderId
	 * @param flowPath
	 * @return
	 * @throws GenericException
	 */
	boolean hasNewTnOrder(long envOrderId, String flowPath) throws GenericException;

	/**
	 * @param orderId
	 * @param parentId
	 * @return
	 */
	boolean isNewEntityChangeOrder(long orderId, long parentId);

	/**
	 * @param voipOrderType
	 * @return
	 * @throws GenericException
	 */
	String getVoipOrderType(String voipOrderType) throws GenericException;

	/**
	 * @param enterpriseId
	 * @param locations
	 * @return
	 * @throws GenericException
	 * @throws ApplicationInterfaceException
	 * @throws TranslatorException
	 */
	boolean isOtherActiveLocationPresentUnderEnterpriseInBw(String enterpriseId, List<String> locations)
			throws ApplicationInterfaceException, GenericException, TranslatorException;

	/**
	 * @param voipLocationId
	 * @return void
	 * @throws TranslatorException
	 * @throws GenericException
	 */
	public void createDeviceOrderFromInventoryDetails(VOIPOrderRequest voipOrderRequest, TblEnvOrder tblEnvOrderObject)
			throws TranslatorException, GenericException;

	/**
	 * @param voipLocationId
	 * @return void
	 * @throws TranslatorException
	 * @throws GenericException
	 */
	public void createEnterpriseOrderFromInventoryDetails(VOIPOrderRequest voipOrderRequest,
			TblEnvOrder tblEnvOrderObject) throws TranslatorException, GenericException;

	/**
	 * @param gchId
	 * @param locationId
	 * @param locationType
	 * @return
	 * @throws ApplicationInterfaceException
	 * @throws GenericException
	 */
	DBServiceResponse getEnterpriseInformationFromGchId(VOIPOrderRequest voipOrderRequest, LocationType locationType)
			throws ApplicationInterfaceException, GenericException;

	/**
	 * @param voipOrderRequest
	 * @param productDetails
	 * @return
	 * @throws TranslatorException
	 * @throws GenericException
	 */
	VoipOrderResponse createTnPortActivationOrder(VOIPOrderRequest voipOrderRequest, Map<String, String> productDetails)
			throws TranslatorException, GenericException;

	/**
	 * @param voipOrderRequest
	 * @return
	 * @throws GenericException
	 */
	public boolean isEnterpriseCreatedInPreviousOrder(VOIPOrderRequest voipOrderRequest) throws GenericException;

	/**
	 * @param gchId
	 * @param voipOrderRequest
	 * @return
	 * @throws ApplicationInterfaceException
	 * @throws GenericException
	 */
	DBServiceResponse getEnterpriseInformationFromGchId(String gchId, VOIPOrderRequest voipOrderRequest)
			throws ApplicationInterfaceException, GenericException;

	/**
	 * @param voipOrderRequestCurrent
	 * @param voipOrderDao
	 * @param tblEnvOrderId
	 * @param status
	 * @return 
	 * @throws GenericException
	 */
	public void updateTblEnvOrderStatusWithCurrOrdFlow(VOIPOrderRequest voipOrderRequestCurrent, Long tblEnvOrderId);
	
	/**
	 * @param voipOrderRequest
	 * @throws TranslatorException
	 * @throws GenericException
	 */
	void handleOrdersInProgress(VOIPOrderRequest voipOrderRequest) throws TranslatorException, GenericException;
	
	/**
	 * @param tblEnvOrderId
	 * @param paramInfo
	 * @param orderHeader
	 * @return
	 * @throws ApplicationInterfaceException
	 * @throws GenericException
	 */
	public ParamInfo updateParamInfoForLocationid(long tblEnvOrderId, ParamInfo paramInfo,OrderHeader orderHeader) throws ApplicationInterfaceException, GenericException;

	/**
	 * @param voipOrderRequest
	 * @return 
	 * @throws GenericException*/
	public List<TblEnvOrder> getPrevPassEnvOrder(VOIPOrderRequest voipOrderRequest) throws GenericException;
/**
 * 
 * @param tblEnvOrderObject
 * @param string
 * @param string2
 * @throws GenericException 
 * @throws TranslatorException 
 */
	void insertEnterpriseFlagintoTOD(TblEnvOrder tblEnvOrderObject, String string, String string2) throws TranslatorException, GenericException;
}