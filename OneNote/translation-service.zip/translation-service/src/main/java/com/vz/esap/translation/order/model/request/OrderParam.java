package com.vz.esap.translation.order.model.request;

public class OrderParam {

	private String in_order_number;
	private String in_order_version;
	private int t_cnt;
	private String in_sp_xo_tru_con_line_loc;

	public String getIn_order_number() {
		return in_order_number;
	}

	public void setIn_order_number(String in_order_number) {
		this.in_order_number = in_order_number;
	}

	public String getIn_order_version() {
		return in_order_version;
	}

	public void setIn_order_version(String in_order_version) {
		this.in_order_version = in_order_version;
	}

	public int getT_cnt() {
		return t_cnt;
	}

	public void setT_cnt(int t_cnt) {
		this.t_cnt = t_cnt;
	}

	public String getIn_sp_xo_tru_con_line_loc() {
		return in_sp_xo_tru_con_line_loc;
	}

	public void setIn_sp_xo_tru_con_line_loc(String in_sp_xo_tru_con_line_loc) {
		this.in_sp_xo_tru_con_line_loc = in_sp_xo_tru_con_line_loc;
	}

}
