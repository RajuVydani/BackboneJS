package com.vz.esap.translation.order.service.nbs;

import java.util.List;

import com.vz.esap.translation.dao.model.TblEnvOrder;
import com.vz.esap.translation.dao.model.TblOrder;
import com.vz.esap.translation.dao.model.TblOrderDetails;
import com.vz.esap.translation.exception.GenericException;
import com.vz.esap.translation.exception.TranslatorException;
import com.vz.esap.translation.order.model.request.VOIPOrderRequest;
import com.vz.esap.translation.order.model.response.VoipOrderResponse;

/**
 * @author kalagsu
 *
 */
public interface NbsOrderService {

	/**
	 * @param tblOrderDetails
	 * @param tblOrderBean
	 * @param tblEnvOrder
	 * @param voipOrderRequest
	 * @param tblOrderDetailsList
	 * @return voipOrderResponse
	 * @throws GenericException
	 * @throws TranslatorException
	 */
	VoipOrderResponse processReleaseOrder(TblOrderDetails tblOrderDetails, TblOrder tblOrderBean,
			TblEnvOrder tblEnvOrder, VOIPOrderRequest voipOrderRequest, List<TblOrderDetails> tblOrderDetailsList) throws GenericException, TranslatorException;

	/**
	 * @param tblEnvOrder
	 * @return
	 * @throws GenericException 
	 * @throws TranslatorException 
	 */
	String isNbsProvisioningRequired(TblEnvOrder tblEnvOrder) throws TranslatorException, GenericException;
}
