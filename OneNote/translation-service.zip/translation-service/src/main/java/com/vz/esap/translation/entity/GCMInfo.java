package com.vz.esap.translation.entity;

import java.util.ArrayList;
import java.util.List;

public class GCMInfo {

	private String custPriceBookid;
	private String contractId;
	private String quoteId;
	private String productId;
	private List<GCMPricingInfo> pricingInfo;

	public void setCustomerPriceBookId(String customerPriceBookId) {
		this.custPriceBookid = customerPriceBookId;
	}

	public String getCustomerPriceBookId() {
		return this.custPriceBookid;
	}
	
	public void setContractId(String contractId) {
		this.contractId = contractId;
	}

	public String getContractId() {
		return contractId;
	}
	
	public void setQuoteId(String quoteId) {
		this.quoteId = quoteId;
	}

	public String getQuoteId() {
		return this.quoteId;
	}
	
	public void setProductId(String productIdentifier) {
		this.productId = productIdentifier;
	}

	public String getProductId() {
		return productId;
	}

	public void setPricingInfo(List<GCMPricingInfo> priceInfoLst) {
		this.pricingInfo = priceInfoLst;
	}
	
	public List<GCMPricingInfo> getPricingInfo() {
		return this.pricingInfo;
	}

//	
//	public ParamInfo getChangeParam(GCMInfo oldGcmInfo, boolean supp) {
//		ParamInfo gcmParam = new ParamInfo("BillableFeatureInfo", null, null);
//		gcmParam.addChangeParam("CustomerPriceBookId", oldGcmInfo.getCustomerPriceBookId(), custPriceBookid, supp);
//    	gcmParam.addChangeParam("ContractId", oldGcmInfo.getContractId(), contractId, supp);
//    	gcmParam.addChangeParam("QuoteId", oldGcmInfo.getQuoteId(), quoteId, supp);
//    	gcmParam.addChangeParam("ProductIdentifier", oldGcmInfo.getProductId(), productId, supp);
//    	List<GCMPricingInfo> oldPriceInfoLst = oldGcmInfo.getPricingInfo();
//    	if (pricingInfo != null && pricingInfo.size() > 0) {
//    		if (oldPriceInfoLst == null) {
//    			for (GCMPricingInfo priceInfo : pricingInfo) {
//    				gcmParam.addChildParam(priceInfo.getParamInfo("I"));
//    			}
//    		} else {
//    			for (GCMPricingInfo priceInfo : pricingInfo) {
//    				boolean foundMatch = false;
//    				for (GCMPricingInfo oldPriceInfo : oldPriceInfoLst) {
//    					if (priceInfo.getFeatureInstanceId() != null && oldPriceInfo.getFeatureInstanceId() != null
//    							&& priceInfo.getFeatureInstanceId().equals(oldPriceInfo.getFeatureInstanceId())) {
//    						foundMatch = true;
//    						priceInfo.getChangeParam(oldPriceInfo, supp);
//    						break;
//    					}
//    				}
//    				if (!foundMatch) {
//    					gcmParam.addChildParam(priceInfo.getParamInfo("I"));
//    					foundMatch = false;
//    				}
//    			}
//    			
//    			for (GCMPricingInfo oldPriceInfo : oldPriceInfoLst) {
//    				boolean foundDeleteMatch = true;
//    				for (GCMPricingInfo priceInfo : pricingInfo) {
//    					if (priceInfo.getFeatureInstanceId() != null && oldPriceInfo.getFeatureInstanceId() != null
//    							&& priceInfo.getFeatureInstanceId().equals(oldPriceInfo.getFeatureInstanceId())) {
//    						foundDeleteMatch = false;
//    						break;
//    					}
//    				}
//    				if (foundDeleteMatch) {
//    					gcmParam.addChildParam(oldPriceInfo.getParamInfo("O"));
//    					foundDeleteMatch = false;
//    				}
//    			}
//    		}
//    	} else if (oldPriceInfoLst != null) {
//    		for (GCMPricingInfo oldPriceInfo : oldPriceInfoLst) {
//    			gcmParam.addChildParam(oldPriceInfo.getParamInfo("O"));
//    		}
//    	}
//		return gcmParam;
//	}
	
		
}

	
