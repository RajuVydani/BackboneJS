package com.vz.esap.translation.order.model.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_EMPTY)
public class SafeStoreDataBean {

	public String TransactionId;
	public String OrderType;
	public String MsgSegmentNo;
	public String WorkOrderVersion;
	public String WorkOrderNumber;
	public String FunctionCode;
	public String GCHId;
	public String EnterpriseId;
	public String upstreamRec;
	public String UNOServiceId;

	public String getUNOServiceId() {
		return UNOServiceId;
	}

	public void setUNOServiceId(String uNOServiceId) {
		UNOServiceId = uNOServiceId;
	}

	public String getTransactionId() {
		return TransactionId;
	}

	public void setTransactionId(String transactionId) {
		TransactionId = transactionId;
	}

	public String getOrderType() {
		return OrderType;
	}

	public void setOrderType(String orderType) {
		OrderType = orderType;
	}

	public String getMsgSegmentNo() {
		return MsgSegmentNo;
	}

	public void setMsgSegmentNo(String msgSegmentNo) {
		MsgSegmentNo = msgSegmentNo;
	}

	public String getWorkOrderVersion() {
		return WorkOrderVersion;
	}

	public void setWorkOrderVersion(String workOrderVersion) {
		WorkOrderVersion = workOrderVersion;
	}

	public String getWorkOrderNumber() {
		return WorkOrderNumber;
	}

	public void setWorkOrderNumber(String workOrderNumber) {
		WorkOrderNumber = workOrderNumber;
	}

	public String getFunctionCode() {
		return FunctionCode;
	}

	public void setFunctionCode(String functionCode) {
		FunctionCode = functionCode;
	}

	public String getGCHId() {
		return GCHId;
	}

	public void setGCHId(String gCHId) {
		GCHId = gCHId;
	}

	public String getEnterpriseId() {
		return EnterpriseId;
	}

	public void setEnterpriseId(String enterpriseId) {
		EnterpriseId = enterpriseId;
	}

	public String getUpstreamRec() {
		return upstreamRec;
	}

	public void setUpstreamRec(String upstreamRec) {
		this.upstreamRec = upstreamRec;
	}

}
