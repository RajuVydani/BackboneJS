package com.vz.esap.translation.constant;

public class GenericConstant {

	public static final String INVALID_DATA = "INVALID_DATA";
	public static final String GENERIC_EXCEPTION = "GENERIC_EXCEPTION";
	}
