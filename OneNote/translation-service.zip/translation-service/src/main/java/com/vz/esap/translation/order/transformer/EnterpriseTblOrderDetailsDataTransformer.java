package com.vz.esap.translation.order.transformer;

import java.text.ParseException;

import org.springframework.stereotype.Component;

import com.vz.esap.translation.dao.model.TblOrder;
import com.vz.esap.translation.entity.CustomerEntity;
import com.vz.esap.translation.exception.TranslatorException;
import com.vz.esap.translation.order.model.Order;
import com.vz.esap.translation.order.model.request.ParamInfo;
import com.vz.esap.translation.order.model.request.VOIPOrderRequest;

@Component
public interface EnterpriseTblOrderDetailsDataTransformer {

	/**
	 * @param voipOrderRequest
	 * @param tblOrderObject
	 * @param customer
	 * @return root
	 * @throws TranslatorException
	 */
	ParamInfo prepareTblOrderDetailsEntityParamDataForCustomer(VOIPOrderRequest voipOrderRequest,
			TblOrder tblOrderObject, CustomerEntity customer) throws TranslatorException;

	/**
	 * @param order
	 * @return root
	 * @throws ParseException
	 * @throws TranslatorException
	 */
	ParamInfo prepareTblOrderDetailsHeaderParamData(Order order) throws ParseException, TranslatorException;

	/**
	 * @param order
	 * @return root
	 */
	ParamInfo prepareTblOrderDetailsEntityParamDataForCustomer(Order order, String action);

	/**
	 * @param oldCustomerEntity
	 * @param newCustomerEntity
	 * @param supp
	 * @param action
	 * @return paramInfo
	 */
	ParamInfo prepareTblOrderDetailsEntityParamDataForCustomer(CustomerEntity oldCustomerEntity,
			CustomerEntity newCustomerEntity, boolean supp, String action);

	/**
	 * @param order
	 * @param oldCustomerEntity
	 * @param supp
	 * @return paramInfo
	 * @throws TranslatorException
	 * @throws ParseException
	 */
	ParamInfo prepareTblOrderDetailsHeaderParamData(Order order, CustomerEntity oldCustomerEntity, boolean supp)
			throws ParseException, TranslatorException;

	/**
	 * 
	 * @param customer
	 * @param customerEntity
	 * @param b
	 * @param object
	 * @return
	 * @throws TranslatorException 
	 */
	ParamInfo prepareTblOrderDetailsEntityParamDataForLocation(CustomerEntity customer, CustomerEntity customerEntity,
			boolean b, Object object) throws TranslatorException;

}
