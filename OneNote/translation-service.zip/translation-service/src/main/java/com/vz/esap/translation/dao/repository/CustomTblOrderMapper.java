package com.vz.esap.translation.dao.repository;

import java.util.Map;

import com.vz.esap.translation.dao.model.TblOrder;

public interface CustomTblOrderMapper extends TblOrderMapper{

	long createTblOrder(TblOrder tblOrderObject);
	
	void updateTblOrderStatus(Map<String, Object> params);

	void updateOrderId(Map<String, Object> params);
}