package com.vz.esap.translation.order.validation.device;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.vz.esap.translation.entity.CustomerEntity;
import com.vz.esap.translation.order.model.request.ConvergedService;
import com.vz.esap.translation.order.model.request.VOIPOrderRequest;

/**
 * @author kalagsu
 *
 */
@Component
public class DeviceOrderValidatorImpl implements DeviceOrderValidator {
	private static final Logger LOG = LoggerFactory.getLogger(DeviceOrderValidatorImpl.class);

	private CustomerEntity customer;

	public CustomerEntity getCustomer() {
		return customer;
	}

	public void setCustomer(CustomerEntity customer) {
		this.customer = customer;
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.vz.esap.translation.order.validation.device.DeviceOrderValidator#validate
	 * (com.vz.esap.translation.order.model.request.VOIPOrderRequest)
	 */
@Override	
public List<String> validate(VOIPOrderRequest voipOrderRequest) {
		LOG.info("DeviceOrderValidatorImpl - validate");
		
		List<String> missingFields = new ArrayList<String>();
		ConvergedService convergedService = voipOrderRequest
				.getConvergedService();
		if (convergedService.getID() == null) {
			missingFields.add("CustomerId");
		}
		if (voipOrderRequest.getLocation() == null) {
			missingFields.add("Virtual LocationEntity Info");
		}
		return missingFields;
	}


}
