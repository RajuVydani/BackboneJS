package com.vz.esap.translation.order.transformer;

import com.vz.esap.translation.dao.model.TblEnvOrder;
import com.vz.esap.translation.exception.TranslatorException;
import com.vz.esap.translation.order.model.Order;
import com.vz.esap.translation.order.model.request.VOIPOrderRequest;

//@Component
public interface EnterpriseEnvelopOrderTransformer {

	/**
	 * @param order
	 * @param voipOrderRequest TODO
	 * @return tblEnvOrderObject
	 * @throws TranslatorException
	 */
	TblEnvOrder createTblEnvOrderFromOrder(Order order, VOIPOrderRequest voipOrderRequest) throws TranslatorException;

	/**
	 * @param voipOrderRequest
	 * @param status
	 * @return tblEnvOrderObject
	 */
	TblEnvOrder createTblEnvOrderFromVOIPOrderRequest(VOIPOrderRequest voipOrderRequest, int status);
}
