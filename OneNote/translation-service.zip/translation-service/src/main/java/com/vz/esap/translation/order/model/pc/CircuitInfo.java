package com.vz.esap.translation.order.model.pc;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;

import com.fasterxml.jackson.annotation.JsonProperty;

@XmlAccessorType(XmlAccessType.FIELD)
public class CircuitInfo {
	
	@XmlElement(name = "EBIId")
	@JsonProperty(value = "EBIId")
	private String ebiId;

	@XmlElement(name = "CircuitId")
	@JsonProperty(value = "CircuitId")
	private String circuitId;

	@XmlElement(name = "VpnName")
	@JsonProperty(value = "VpnName")
	private String[] vpnName;

	@XmlElement(name = "IpAddress")
	@JsonProperty(value = "IpAddress")
	private String ipAddress;

	public String getEBIId() {
		return ebiId;
	}

	public void setEBIId(String EBIId) {
		this.ebiId = EBIId;
	}

	public String getCircuitId() {
		return circuitId;
	}

	public void setCircuitId(String CircuitId) {
		this.circuitId = CircuitId;
	}

	public String[] getVpnName() {
		return vpnName;
	}

	public void setVpnName(String[] VpnName) {
		this.vpnName = VpnName;
	}

	public String getIpAddress() {
		return ipAddress;
	}

	public void setIpAddress(String IpAddress) {
		this.ipAddress = IpAddress;
	}

	@Override
	public String toString() {
		return "ClassPojo [EBIId = " + ebiId + ", CircuitId = " + circuitId + ", VpnName = " + vpnName
				+ ", IpAddress = " + ipAddress + "]";
	}
}
