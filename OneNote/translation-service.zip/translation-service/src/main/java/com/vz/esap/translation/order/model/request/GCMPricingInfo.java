package com.vz.esap.translation.order.model.request;

public class GCMPricingInfo {

	private String featInstId;
	private String featCode;
	private String chargeType;
	private String currencyCode;
	private String ChargeFrq;
	private String uom;
	private String billTime;
	private String pbLi;
	private String catelogReferenceTime;
	private String servicePlan;

	public String getFeatureInstanceId() {
		return this.featInstId;
	}

	public String getFeatureCode() {
		return this.featCode;
	}

	public String getChargeType() {
		return this.chargeType;
	}

	public String getCurrencyCode() {
		return this.currencyCode;
	}

	public String getChargeFrequency() {
		return this.ChargeFrq;
	}

	public String getUnitOfMeasure() {
		return this.uom;
	}

	public String getBillTime() {
		return this.billTime;
	}

	public void setFeatureInstanceId(String featInstId) {
		this.featInstId = featInstId;
	}

	public void setFeatureCode(String featCode) {
		this.featCode = featCode;
	}

	public void setChargeType(String chargeType) {
		this.chargeType = chargeType;
	}

	public void setCurrencyCode(String currCode) {
		this.currencyCode = currCode;
	}

	public void setChargeFrequency(String chargeFrq) {
		this.ChargeFrq = chargeFrq;
	}

	public void setUnitOfMeasure(String uom) {
		this.uom = uom;
	}

	public void setBillTime(String billTime) {
		this.billTime = billTime;
	}

	public String getPbLi() {
		return pbLi;
	}

	public void setPbLi(String pbLi) {
		this.pbLi = pbLi;
	}

	public ParamInfo getParamInfo(String action) {
		ParamInfo priceInfoParam = new ParamInfo("PricingInfo", null, action);

		priceInfoParam.addNotNullValChild("PBLI", pbLi, action);
		priceInfoParam.addNotNullValChild("FeatureInstanceId", featInstId, action);
		priceInfoParam.addNotNullValChild("FeatureCode", featCode, action);
		priceInfoParam.addNotNullValChild("ChargeType", chargeType, action);
		priceInfoParam.addNotNullValChild("CurrencyCode", currencyCode, action);
		priceInfoParam.addNotNullValChild("ChargeFrequency", ChargeFrq, action);
		priceInfoParam.addNotNullValChild("UnitOfMeasure", uom, action);
		priceInfoParam.addNotNullValChild("BillTime", billTime, action);
		priceInfoParam.addNotNullValChild("CatalogueReferenceTime", catelogReferenceTime, action);
		priceInfoParam.addNotNullValChild("ServicePlan", servicePlan, action);
		return priceInfoParam;
	}

	// public ParamInfo getChangeParam(GCMPricingInfo oldPriceInfo, boolean supp) {
	// ParamInfo priceInfoParam = new ParamInfo("PricingInfo", null, null);
	// priceInfoParam.addChangeParam("PBLI", oldPriceInfo.getPbLi(), pbLi, supp);
	// priceInfoParam.addChangeParam("FeatureInstanceId",
	// oldPriceInfo.getFeatureInstanceId(), featInstId, supp);
	// priceInfoParam.addChangeParam("FeatureCode", oldPriceInfo.getFeatureCode(),
	// featCode, supp);
	// priceInfoParam.addChangeParam("ChargeType", oldPriceInfo.getChargeType(),
	// chargeType, supp);
	// priceInfoParam.addChangeParam("CurrencyCode", oldPriceInfo.getCurrencyCode(),
	// currencyCode, supp);
	// priceInfoParam.addChangeParam("ChargeFrequency",
	// oldPriceInfo.getChargeFrequency(), ChargeFrq, supp);
	// priceInfoParam.addChangeParam("UnitOfMeasure",
	// oldPriceInfo.getUnitOfMeasure(), uom, supp);
	// priceInfoParam.addChangeParam("BillTime", oldPriceInfo.getBillTime(),
	// billTime, supp);
	// priceInfoParam.addChangeParam("CatalogueReferenceTime",
	// oldPriceInfo.getCatelogReferenceTime(), catelogReferenceTime, supp);
	// priceInfoParam.addChangeParam("ServicePlan", oldPriceInfo.getServicePlan(),
	// servicePlan, supp);
	//
	// return priceInfoParam;
	// }

	// public static GCMPricingInfo createInstanceFromParamInfo(ParamInfo param) {
	// GCMPricingInfo pricingInfo = null;
	// if (param != null && param.getChildParams() != null) {
	// pricingInfo = new GCMPricingInfo();
	// for (ParamInfo childParam : param.getChildParams()) {
	// if (childParam.getName().equals("FeatureInstanceId")) {
	// pricingInfo.setFeatureInstanceId(childParam.getValue());
	// } else if (childParam.getName().equals("FeatureCode")) {
	// pricingInfo.setFeatureCode(childParam.getValue());
	// } else if (childParam.getName().equals("ChargeType")) {
	// pricingInfo.setChargeType(childParam.getValue());
	// } else if (childParam.getName().equals("CurrencyCode")) {
	// pricingInfo.setCurrencyCode(childParam.getValue());
	// } else if (childParam.getName().equals("ChargeFrequency")) {
	// pricingInfo.setChargeFrequency(childParam.getValue());
	// } else if (childParam.getName().equals("UnitOfMeasure")) {
	// pricingInfo.setUnitOfMeasure(childParam.getValue());
	// } else if (childParam.getName().equals("BillTime")) {
	// pricingInfo.setBillTime(childParam.getValue());
	// } else if (childParam.getName().equals("PBLI")) {
	// pricingInfo.setPbLi(childParam.getValue());
	// } else if (childParam.getName().equals("CatalogueReferenceTime")) {
	// pricingInfo.setCatelogReferenceTime(childParam.getValue());
	// } else if (childParam.getName().equals("ServicePlan")) {
	// pricingInfo.setServicePlan(childParam.getValue());
	// }
	// }
	// }
	// return pricingInfo;
	// }

	public void setCatelogReferenceTime(String crt) {
		this.catelogReferenceTime = crt;
	}

	public String getCatelogReferenceTime() {
		return catelogReferenceTime;
	}

	public String getServicePlan() {
		return servicePlan;
	}

	public void setServicePlan(String servicePlan) {
		this.servicePlan = servicePlan;
	}

}
