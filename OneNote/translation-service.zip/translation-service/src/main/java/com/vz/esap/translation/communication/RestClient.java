package com.vz.esap.translation.communication;

import org.apache.commons.codec.binary.Base64;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.vz.esap.translation.exception.ApplicationInterfaceException;
import com.vz.esap.translation.exception.GenericException;

@Service("restClientHelper")
public class RestClient {

	private static final Logger LOG = LoggerFactory.getLogger(RestClient.class);

	/**
	 * @param inputdata
	 * @param url
	 * @param svcUserName
	 * @param svcPassword
	 * @param responseClassObj
	 * @param httpMethod
	 *            TODO
	 * @return response
	 * @throws ApplicationInterfaceException
	 * @throws GenericException
	 */
	public Object invokeService(Object inputdata, String url, String svcUserName, String svcPassword,
			Class responseClassObj, HttpMethod httpMethod) throws ApplicationInterfaceException, GenericException {
		LOG.info("Sending request to URL: {}", url);

		RestTemplate restTemplate = new RestTemplate();
		String plainClientCredentials = null;
		String base64ClientCredentials = null;
		HttpEntity<Object> input = null;
		ResponseEntity<Object> response = null;
		HttpHeaders headers = null;

		if (svcUserName != null && svcPassword != null && (httpMethod == null || HttpMethod.POST.equals(httpMethod))) {

			plainClientCredentials = svcUserName + ":" + svcPassword;
			base64ClientCredentials = new String(Base64.encodeBase64(plainClientCredentials.getBytes()));

			headers = new HttpHeaders();
			headers.add("Authorization", "Basic " + base64ClientCredentials);

			headers.setContentType(MediaType.APPLICATION_JSON);
			input = new HttpEntity<>(inputdata, headers);

			try {
				response = restTemplate.exchange(url, HttpMethod.POST, input, responseClassObj);

			} catch (Exception e) {
				throw new GenericException(GenericException.GENERIC_EXCEPTION,
						"Unexpected Error Occur while POST message");
			}
		} else {
			try {
				if (httpMethod == null || HttpMethod.POST.equals(httpMethod)) {
					response = (ResponseEntity<Object>) restTemplate.postForObject(url, inputdata, responseClassObj);

				} else if (HttpMethod.GET.equals(httpMethod)) {
					response = (ResponseEntity<Object>) restTemplate.getForObject(url, responseClassObj);

				}

			} catch (Exception e) {
				throw new ApplicationInterfaceException(e.getMessage());
			}
		}
		LOG.info("Received response :<{}>", response);
		return response.getBody();
	}
}