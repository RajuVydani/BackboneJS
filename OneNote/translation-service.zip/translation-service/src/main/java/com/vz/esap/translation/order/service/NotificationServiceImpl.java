package com.vz.esap.translation.order.service;

import org.dozer.DozerBeanMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.vz.esap.translation.communication.RestClient;
import com.vz.esap.translation.enums.EsapEnum.FunctionCode;
import com.vz.esap.translation.enums.EsapEnum.OrderPass;
import com.vz.esap.translation.exception.GenericException;
import com.vz.esap.translation.order.model.response.ResponseObject;
import com.vz.esap.translation.order.model.response.VoipOrderResponse;

/**
 * @author chattni
 *
 */
@Component
public class NotificationServiceImpl implements NotificationService {

	private static final Logger LOG = LoggerFactory.getLogger(NotificationServiceImpl.class);

	@Value("${ordering.pcReceiverUrl}")
	private String pcReceiverUrl;

	@Value("${ordering.svcUsername}")
	private String svcUsername;

	@Value("${ordering.svcPassword}")
	private String svcPassword;

	@Value("${spring.activemq.queue}")
	private String mqDestination;

	@Autowired
	private RestClient restClientHelper;

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.vz.esap.translation.order.service.NotificationService#notifyFailures(com.
	 * vz.esap.translation.order.model.response.VoipOrderResponse)
	 */
	@Override
	public ResponseObject notifyFailures(VoipOrderResponse voipOrderResponseInt) throws GenericException {

		ObjectMapper mapper = null;
		ResponseObject responseObject = null;
		try {

			com.vz.esap.translation.order.model.pc.VoipOrderResponse voipOrderResponse = transformVoipOrderResponse(
					voipOrderResponseInt);

			mapper = new ObjectMapper();
			LOG.info("Entered into notifyFailures: voipOrderResponse:{}",
					mapper.writerWithDefaultPrettyPrinter().writeValueAsString(voipOrderResponse));

			if (voipOrderResponseInt.getOrderHeader() != null && OrderPass.VALIDATE.toString()
					.equalsIgnoreCase(voipOrderResponseInt.getOrderHeader().getFunctionCode())) {
				responseObject = (ResponseObject) restClientHelper.invokeService(voipOrderResponse, pcReceiverUrl,
						svcUsername, svcPassword, ResponseObject.class, null);
			} else {
				responseObject = (ResponseObject) restClientHelper.invokeService(voipOrderResponse, pcReceiverUrl,
						svcUsername, svcPassword, ResponseObject.class, null);
			}

			LOG.info("In Try  notifyFailures: ResponseObject :{}", responseObject);

		} catch (Exception ex) {
			LOG.info("Exception while calling Notify Service:{}", ex.getMessage());
			throw new GenericException(GenericException.GENERIC_EXCEPTION, "Unexpected Error During Notifying PC");
		}
		LOG.info("Exit from notifyFailures: responseObject:{}", responseObject);
		return responseObject;
	}

	// :added for Success Notification
	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.vz.esap.translation.order.service.NotificationService#notifySuccess(com.
	 * vz.esap.translation.order.model.response.VoipOrderResponse)
	 */
	@Override
	public ResponseObject notifySuccess(VoipOrderResponse voipOrderResponseInt) throws GenericException {

		ObjectMapper mapper = null;
		ResponseObject responseObject = null;

		try {

			com.vz.esap.translation.order.model.pc.VoipOrderResponse voipOrderResponse = transformVoipOrderResponse(
					voipOrderResponseInt);

			mapper = new ObjectMapper();
			LOG.info("Entered into notifySuccess: voipOrderResponse:{}",
					mapper.writerWithDefaultPrettyPrinter().writeValueAsString(voipOrderResponse));

			if (voipOrderResponseInt.getOrderHeader() != null && FunctionCode.VALIDATE.toString()
					.equalsIgnoreCase(voipOrderResponseInt.getOrderHeader().getFunctionCode()))
				responseObject = (ResponseObject) restClientHelper.invokeService(voipOrderResponse, pcReceiverUrl,
						svcUsername, svcPassword, ResponseObject.class, null);
			else {
				responseObject = (ResponseObject) restClientHelper.invokeService(voipOrderResponse, pcReceiverUrl,
						svcUsername, svcPassword, ResponseObject.class, null);
			}

			LOG.info("In Try  notifySuccess: ResponseObject :{}", responseObject);

		} catch (Exception ex) {
			LOG.info("Exception while calling Notify Service:{}", ex.getMessage());
			throw new GenericException(GenericException.GENERIC_EXCEPTION, "Unexpected Error During Notifying PC");
		}
		LOG.info("Exit from notifySuccess: responseObject:{}", responseObject);
		return responseObject;

	}

	private com.vz.esap.translation.order.model.pc.VoipOrderResponse transformVoipOrderResponse(VoipOrderResponse res)
			throws JsonProcessingException {

		ObjectMapper mapper = new ObjectMapper();
		LOG.debug("Entered into transformVoipOrderResponse with Original Response:{}",
				mapper.writerWithDefaultPrettyPrinter().writeValueAsString(res));

		com.vz.esap.translation.order.model.pc.VoipOrderResponse resp = new DozerBeanMapper().map(res,
				com.vz.esap.translation.order.model.pc.VoipOrderResponse.class);
		
		LOG.debug("Message Ready For PC:{}",
				mapper.writerWithDefaultPrettyPrinter().writeValueAsString(resp));

		return resp;
	}

	public void setRestClient(RestClient restClient) {
		this.restClientHelper = restClient;
	}

}
