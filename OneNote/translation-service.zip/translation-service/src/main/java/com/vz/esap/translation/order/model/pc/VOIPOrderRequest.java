package com.vz.esap.translation.order.model.pc;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

@XmlRootElement(name = "VOIPOrderRequest")
@XmlAccessorType(XmlAccessType.FIELD)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
public class VOIPOrderRequest implements java.io.Serializable {

	private static final long serialVersionUID = 5664846645733319592L;

	private long sequenceNumber;

	@XmlElement(name = "VerificationData")
	@JsonProperty(value = "VerificationData")
	private VerificationData verificationData;

	public VerificationData getVerificationData() {
		return verificationData;
	}

	public void setVerificationData(VerificationData verificationData) {
		this.verificationData = verificationData;
	}

	public PortingInfo[] getPortingInfo() {
		return portingInfo;
	}

	public void setPortingInfo(PortingInfo[] portingInfo) {
		this.portingInfo = portingInfo;
	}

	public RouterConfig[] getRouterConfig() {
		return routerConfig;
	}

	public void setRouterConfig(RouterConfig[] routerConfig) {
		this.routerConfig = routerConfig;
	}

	public AdditionalInfo getAdditionalInfo() {
		return additionalInfo;
	}

	public void setAdditionalInfo(AdditionalInfo additionalInfo) {
		this.additionalInfo = additionalInfo;
	}

	public Location getLocation() {
		return location;
	}

	public void setLocation(Location location) {
		this.location = location;
	}

	public CircuitInfo[] getCircuitInfo() {
		return circuitInfo;
	}

	public void setCircuitInfo(CircuitInfo[] circuitInfo) {
		this.circuitInfo = circuitInfo;
	}

	public ConvergedService getConvergedService() {
		return convergedService;
	}

	public void setConvergedService(ConvergedService convergedService) {
		this.convergedService = convergedService;
	}

	public OrderHeader getOrderHeader() {
		return orderHeader;
	}

	public void setOrderHeader(OrderHeader orderHeader) {
		this.orderHeader = orderHeader;
	}

	public ChangeManagement[] getChangeManagement() {
		return changeManagement;
	}

	public void setChangeManagement(ChangeManagement[] changeManagement) {
		this.changeManagement = changeManagement;
	}

	@XmlElement(name = "PortingInfo")
	@JsonProperty(value = "PortingInfo")
	private PortingInfo[] portingInfo;

	@XmlElement(name = "RouterConfig")
	@JsonProperty(value = "RouterConfig")
	private RouterConfig[] routerConfig;

	@XmlElement(name = "AdditionalInfo")
	@JsonProperty(value = "AdditionalInfo")
	private AdditionalInfo additionalInfo;

	@XmlElement(name = "Location")
	@JsonProperty(value = "Location")
	private Location location;

	@XmlElement(name = "CircuitInfo")
	@JsonProperty(value = "CircuitInfo")
	private CircuitInfo[] circuitInfo;

	@XmlElement(name = "ConvergedService")
	@JsonProperty(value = "ConvergedService")
	private ConvergedService convergedService;

	@XmlElement(name = "OrderHeader")
	@JsonProperty(value = "OrderHeader")
	private OrderHeader orderHeader;

	@XmlElement(name = "ChangeManagement")
	@JsonProperty(value = "ChangeManagement")
	private ChangeManagement[] changeManagement;

	@XmlElement(name = "Customer")
	@JsonProperty(value = "Customer")
	private Customer customer;

	@Override
	public String toString() {
		return "ClassPojo [VerificationData = " + verificationData + ", PortingInfo = " + portingInfo
				+ ", RouterConfig = " + routerConfig + ", AdditionalInfo = " + additionalInfo + ", Location = "
				+ location + ", CircuitInfo = " + circuitInfo + ", ConvergedService = " + convergedService
				+ ", OrderHeader = " + orderHeader + ", ChangeManagement = " + changeManagement + "]";
	}

	/**
	 * @return the sequenceNumber
	 */
	public long getSequenceNumber() {
		return sequenceNumber;
	}

	/**
	 * @param sequenceNumber
	 *            the sequenceNumber to set
	 */
	public void setSequenceNumber(long sequenceNumber) {
		this.sequenceNumber = sequenceNumber;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
}
