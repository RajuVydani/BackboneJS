package com.vz.esap.translation.rules;

public class TranslationRules {

	public void test() {
		
		// This is test method

	}

}
