package com.vz.esap.translation.entity;

import java.util.ArrayList;
import java.util.HashSet;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ParamInfo implements Cloneable {

	private static final Logger LOG = LoggerFactory.getLogger(ParamInfo.class);

	public static enum Tag {
		NON_ORD, NAME, ID, WF;
	}

	private long orderDetailId;
	private long parentId;
	private long flowStatus;

	private String name;
	private String value;
	private String action;
	private int seqNo;
	private ArrayList<ParamInfo> childParams = new ArrayList<ParamInfo>();
	private HashSet<Tag> tagSet = new HashSet<Tag>();

	public ParamInfo(long orderDetailId, long parentId, long flowStatus, String name, String value, String action,
			HashSet<Tag> tagSet) {
		this.name = name;
		this.value = value;
		this.action = action;
		this.seqNo = 0;
		this.tagSet = tagSet;
		this.orderDetailId = orderDetailId;
		this.parentId = parentId;
		this.flowStatus = flowStatus;
	}

	public ParamInfo(String name, String value, String action, int seqNo, Tag tag) {
		this.name = name;
		this.value = value;
		this.action = action;
		this.seqNo = seqNo;
		if (tag != null) {
			tagSet.add(tag);
		}
	}

	public ParamInfo(String name, String value, String action, HashSet<Tag> tagSet) {
		this.name = name;
		this.value = value;
		this.action = action;
		this.seqNo = 0;
		this.tagSet = tagSet;
	}

	public ParamInfo(String name, String value, String action, Tag tag) {
		this.name = name;
		this.value = value;
		this.action = action;
		this.seqNo = 0;
		if (tag != null) {
			tagSet.add(tag);
		}
	}

	public ParamInfo(String name, String value, String action) {
		this.name = name;
		this.value = value;
		this.action = action;
		this.seqNo = 0;
	}

	public ParamInfo(ParamInfo pi) {
		this.name = pi.getName();
		this.value = pi.getValue();
		this.action = pi.getAction();
		this.seqNo = pi.getSeqNo();
		if (pi.getTagSet() != null)
			this.tagSet = new HashSet<ParamInfo.Tag>(pi.getTagSet());
		if (pi.getChildParams() != null) {
			for (ParamInfo childPi : pi.getChildParams())
				addChildParam(new ParamInfo(childPi));
		}
	}
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public HashSet<Tag> getTagSet() {
		return tagSet;
	}

	public void setTagSet(HashSet<Tag> tagSet) {
		this.tagSet = tagSet;
	}

	public boolean hasTag(Tag t) {
		return tagSet != null ? tagSet.contains(t) : false;
	}

	public void addTag(Tag tag) {
		if (tag != null)
			tagSet.add(tag);
	}

	public int getSeqNo() {
		return seqNo;
	}

	public void setSeqNo(int seqNo) {
		this.seqNo = seqNo;
	}

	public ArrayList<ParamInfo> getChildParams() {
		return childParams;
	}

	public void setChildParams(ArrayList<ParamInfo> childParams) {
		this.childParams = childParams;
	}

	public void addChildParams(ArrayList<ParamInfo> childPars) {
		if (childPars == null)
			return;

		if (childParams == null)
			childParams = new ArrayList<ParamInfo>();

		childParams.addAll(childPars);
	}

	public void addChildParam(ParamInfo childParam, Tag tag) {
		if (childParam == null)
			return;

		childParam.addTag(tag);
		addChildParam(childParam);
	}

	public void addChildParam(ParamInfo childParam) {
		if (childParam == null)
			return;

		if (childParams == null)
			childParams = new ArrayList<ParamInfo>();

		childParams.add(childParam);
		if (action == null && childParam.getAction() != null)
			setAction("C");
	}

	public void addChildParamSetAction(ParamInfo childParam) {
		addChildParam(childParam);
		if (childParam.getAction() != null)
			setAction(childParam.getAction());
	}

	public void addChangeParam(String paramName, Object oldValue, Object newValue, boolean forSupp) {
		addChangeParam(paramName, oldValue, newValue, forSupp, null);
	}

	public void addRecapParam(String paramName, Object oldValue, Object newValue, boolean forSupp) {
		if (oldValue != null)
			addChildParam(new ParamInfo(paramName, oldValue.toString(), null));
		else if (newValue != null)
			addChildParam(new ParamInfo(paramName, newValue.toString(), null));
	}

	public String addChangeParamReturnAction(String paramName, Object oldValue, Object newValue, boolean forSupp,
			Tag tag) {
		ArrayList<ParamInfo> changeParams = addAndReturnChangeParams(paramName, oldValue, newValue, forSupp, tag);
		if (changeParams.size() == 2)
			return "C";
		else if (changeParams.size() == 1)
			return changeParams.get(0).getAction();
		else
			return null;
	}

	public void addChangeParam(String paramName, Object oldValue, Object newValue, boolean forSupp, Tag tag) {
		addAndReturnChangeParams(paramName, oldValue, newValue, forSupp, tag);
	}

	public ArrayList<ParamInfo> addAndReturnChangeParams(String paramName, Object oldValue, Object newValue,
			boolean forSupp, Tag tag) {
		ParamInfo inParam = null;
		ParamInfo outParam = null;
		ParamInfo recapParam = null;
		ArrayList<ParamInfo> ret = new ArrayList<ParamInfo>();

		if (forSupp) {
			if (oldValue != null && !oldValue.equals(newValue))
				outParam = new ParamInfo(paramName, oldValue.toString(), "O", tag);
			if (newValue != null && !newValue.equals(oldValue))
				inParam = new ParamInfo(paramName, newValue.toString(), "I", tag);
			if (oldValue != null && newValue != null && newValue.equals(oldValue))
				recapParam = new ParamInfo(paramName, oldValue.toString(), null, tag);

			// New
			if (oldValue == null && newValue != null)
				outParam = new ParamInfo(paramName, "", "O", tag);
			if (oldValue != null && newValue == null)
				inParam = new ParamInfo(paramName, "", "I", tag);
		} else {
			if (oldValue != null && (newValue == null || oldValue.equals(newValue)))
				recapParam = new ParamInfo(paramName, oldValue.toString(), null, tag);
			else {
				if (oldValue != null && !oldValue.equals(newValue))
					outParam = new ParamInfo(paramName, oldValue.toString(), "O", tag);
				if (newValue != null && !newValue.equals(oldValue))
					inParam = new ParamInfo(paramName, newValue.toString(), "I", tag);
				// New
				if (oldValue == null && newValue != null)
					outParam = new ParamInfo(paramName, "", "O", tag);
			}
		}

		// If there is some action at child level
		// set parent action to change
		if (inParam != null) {
			ret.add(inParam);
			this.addChildParam(inParam);
			if (inParam.getAction() != null) {
				LOG.info("change param " + paramName + " new:" + inParam.getValue());
				this.setAction("C");
			}
		}

		if (outParam != null) {
			ret.add(outParam);
			this.addChildParam(outParam);
			if (outParam.getAction() != null) {
				this.setAction("C");
				LOG.info("change param " + paramName + " old:" + outParam.getValue());
			}
		}

		if (recapParam != null) {
			ret.add(recapParam);
			this.addChildParam(recapParam);
		}

		return ret;
	}

	public void addNotNullValChild(String name, Object value, String action) {
		addNotNullValChild(name, value, action, null);
	}

	public void addNotNullValChild(String name, Object value, String action, Tag tag) {
		if (value == null)
			return;
		else
			addChildParam(new ParamInfo(name, value.toString(), action, tag));
	}

	public ParamInfo findParam(String name) {
		if (this.name.equals(name))
			return this;

		ParamInfo matchParam = null;
		if (childParams != null)
			for (ParamInfo childParam : childParams) {
				matchParam = childParam.findParam(name);
				if (matchParam != null)
					break;
			}

		return matchParam;
	}

	public ParamInfo findChildParam(String name) {
		ParamInfo matchParam = null;
		if (childParams != null)
			for (ParamInfo childParam : childParams) {
				if (childParam.getName().equals(name)) {
					matchParam = childParam;
					break;
				}
			}

		return matchParam;
	}

	public ArrayList<ParamInfo> findChildrenParam(String name) {
		ArrayList<ParamInfo> matchParams = new ArrayList<ParamInfo>();
		if (childParams != null)
			for (ParamInfo childParam : childParams) {
				if (childParam.getName().equals(name)) {
					matchParams.add(childParam);
				}
			}

		return matchParams;
	}

	public String findParamValue(String name) {
		ParamInfo pi = findParam(name);
		if (pi != null)
			return pi.getValue();
		else
			return null;
	}

	public static HashSet<Tag> stringToTagSet(String tagStr) {
		if (tagStr == null)
			return null;

		if (tagStr.indexOf(',') == -1)
			return null;

		HashSet<Tag> rTags = new HashSet<Tag>();

		String[] tokens = tagStr.split(",");
		for (int i = 0; i < tokens.length; i++) {
			if (tokens[i] == null || tokens[i].equals(""))
				continue;

			try {
			} catch (NumberFormatException e) {
				continue;
			}
			int ordinal = Integer.parseInt(tokens[i]);
			if (ordinal < Tag.values().length)
				rTags.add(Tag.values()[ordinal]);
		}

		return rTags;
	}	


	@Override
	public String toString() {
		return "ParamInfo [name=" + name + ", value=" + value + ", action=" + action + ", seqNo=" + seqNo
				+ ", childParams=" + childParams + ", tagSet=" + tagSet + "]";
	}

	public long getOrderDetailId() {
		return orderDetailId;
	}

	public void setOrderDetailId(long orderDetailId) {
		this.orderDetailId = orderDetailId;
	}

	public long getParentId() {
		return parentId;
	}

	public void setParentId(long parentId) {
		this.parentId = parentId;
	}

	public long getFlowStatus() {
		return flowStatus;
	}

	public void setFlowStatus(long flowStatus) {
		this.flowStatus = flowStatus;
	}

}
