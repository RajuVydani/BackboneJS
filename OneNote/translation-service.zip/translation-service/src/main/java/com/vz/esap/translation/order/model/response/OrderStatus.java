package com.vz.esap.translation.order.model.response;

import java.util.Date;
import java.util.List;

import javax.xml.bind.annotation.XmlElement;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonRootName;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

@JsonRootName(value = "OrderStatus")
@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
public class OrderStatus {

	@XmlElement(name = "System")
	@JsonProperty(value = "System")
	private String system;

	@XmlElement(name = "StatusCode")
	@JsonProperty(value = "StatusCode")
	private String statusCode;

	@XmlElement(name = "TimeStamp")
	@JsonProperty(value = "TimeStamp")
	private Date timeStamp;

	@XmlElement(name = "StatusDescription")
	@JsonProperty(value = "StatusDescription")
	private String statusDescription;

	@XmlElement(name = "Milestone")
	@JsonProperty(value = "Milestone")
	private String milestone;

	@XmlElement(name = "EntityType")
	@JsonProperty(value = "EntityType")
	private String entityType;

	@XmlElement(name = "EntityValue")
	@JsonProperty(value = "EntityValue")
	private String entityValue;

	@XmlElement(name = "Entity", type = Entity.class)
	@JsonProperty(value = "Entity")
	private List<Entity> entities;

	public Date getTimeStamp() {
		return timeStamp;
	}

	public void setTimeStamp(Date timeStamp) {
		this.timeStamp = timeStamp;
	}

	public String getSystem() {
		return system;
	}

	public void setSystem(String system) {
		this.system = system;
	}

	public String getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}

	public String getStatusDescription() {
		return statusDescription;
	}

	public void setStatusDescription(String statusDescription) {
		this.statusDescription = statusDescription;
	}

	public String getMilestone() {
		return milestone;
	}

	public void setMilestone(String milestone) {
		this.milestone = milestone;
	}

	public String getEntityType() {
		return entityType;
	}

	public void setEntityType(String entityType) {
		this.entityType = entityType;
	}

	public String getEntityValue() {
		return entityValue;
	}

	public void setEntityValue(String entityValue) {
		this.entityValue = entityValue;
	}

	public List<Entity> getEntities() {
		return entities;
	}

	public void setEntities(List<Entity> entities) {
		this.entities = entities;
	}

}
