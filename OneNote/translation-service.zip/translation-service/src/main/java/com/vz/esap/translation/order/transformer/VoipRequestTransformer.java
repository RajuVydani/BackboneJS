package com.vz.esap.translation.order.transformer;

import java.util.Map;

import com.vz.esap.translation.connector.model.DBServiceResponse;
import com.vz.esap.translation.enums.EsapEnum.ResourceVerb;
import com.vz.esap.translation.exception.TranslatorException;
import com.vz.esap.translation.order.model.Order;
import com.vz.esap.translation.order.model.request.VOIPOrderRequest;

public interface VoipRequestTransformer {

	/**
	 * @param voipOrderRequest
	 * @return order
	 * @throws TranslatorException
	 */
	Order transformVoipOrderRequestToOrder(VOIPOrderRequest voipOrderRequest) throws TranslatorException;

	/**
	 * @param voipOrderRequest
	 * @param productDetails
	 * @param dbServiceResponse
	 * @param isNewCustomer
	 * @return voipOrderRequest
	 * @throws TranslatorException
	 */
	VOIPOrderRequest enrichVoipRequestWithEnterprise(VOIPOrderRequest voipOrderRequest,
			Map<String, String> productDetails, DBServiceResponse dbServiceResponse, boolean isNewCustomer)
			throws TranslatorException;

	/**
	 * @param voipOrderRequest
	 * @param productDetails
	 * @param dbServiceResponse
	 * @param isNewCustomer
	 * @return voipOrderRequest
	 * @throws TranslatorException
	 */
	VOIPOrderRequest enrichVoipRequestWithEt(VOIPOrderRequest voipOrderRequest, Map<String, String> productDetails,
			DBServiceResponse dbServiceResponse, boolean isNewCustomer) throws TranslatorException;

	/**
	 * @param voipOrderRequest
	 * @return voipOrderRequest
	 * @throws TranslatorException
	 */
	VOIPOrderRequest enrichVoipRequestWithTrunkGroup(VOIPOrderRequest voipOrderRequest) throws TranslatorException;

	/**
	 * @param voipOrderRequest
	 * @param dbServiceResponse
	 * @param isNewCustomer
	 * @param productDetails
	 * @return VOIPOrderRequest
	 * @throws TranslatorException
	 */
	VOIPOrderRequest modifyOrderHeader(VOIPOrderRequest voipOrderRequest, DBServiceResponse dbServiceResponse,
			boolean isNewCustomer, Map<String, String> productDetails) throws TranslatorException;

	/**
	 * @param voipOrderRequest
	 * @param productDetails
	 * @param dbServiceResponse
	 * @param isNewCustomer
	 * @return VOIPOrderRequest
	 * @throws TranslatorException
	 */
	VOIPOrderRequest enrichVoipRequestWithLocation(VOIPOrderRequest voipOrderRequest,
			Map<String, String> productDetails, DBServiceResponse dbServiceResponse, boolean isNewCustomer)
			throws TranslatorException;

	/**
	 * @param voipOrderRequest
	 * @return VOIPOrderRequest
	 * @throws TranslatorException
	 */
	VOIPOrderRequest enrichVoipRequestWithDevice(VOIPOrderRequest voipOrderRequest) throws TranslatorException;

	
	/**
	 * @param verb
	 * @param locationId
	 * @param workOrderNumber
	 * @param workOrderVersion
	 * @param unoServiceId
	 * @param transactionID
	 * @param msgSegmentNo
	 * @param orderType
	 * @param gchId
	 * @param solutionType
	 * @return
	 * @throws TranslatorException
	 */
	VOIPOrderRequest createVoipOrderRequestFromRequestUri(ResourceVerb verb, String locationId, String workOrderNumber,
			String workOrderVersion, String unoServiceId, String transactionID, String msgSegmentNo, String orderType,
			String gchId, String solutionType) throws TranslatorException;

}
