package com.vz.esap.translation.dao.repository;

import java.util.List;

import org.springframework.stereotype.Component;

import com.vz.esap.translation.dao.model.TblEnvOrderDetails;

@Component
public interface CustomTblEnvOrderDetailsMapper extends TblEnvOrderDetailsMapper {

	public long getEnvOrderDetailsIdSeqNextVal(TblEnvOrderDetails tblEnvOrderDetails);

	public List<TblEnvOrderDetails> getCustomTblEnvOrderDetailsForDefiniteActionAndParentId(
			TblEnvOrderDetails tblEnvOrderDetails);

	public List<TblEnvOrderDetails> getCustomTblEnvOrderDetailsForDefiniteActionAndParentName(
			TblEnvOrderDetails tblEnvOrderDetails);

	public List<TblEnvOrderDetails> getCustomTblEnvOrderDetailsForDefiniteActionAndNoParent(
			TblEnvOrderDetails tblEnvOrderDetails);

	public List<TblEnvOrderDetails> getCustomTblEnvOrderDetailsForNoActionAndParentId(
			TblEnvOrderDetails tblEnvOrderDetails);

	public List<TblEnvOrderDetails> getCustomTblEnvOrderDetailsForNoActionAndParentName(
			TblEnvOrderDetails tblEnvOrderDetails);

	public List<TblEnvOrderDetails> getCustomTblEnvOrderDetailsForNoActionAndNoParent(
			TblEnvOrderDetails tblEnvOrderDetails);
	
	public List<TblEnvOrderDetails> getCustomTblEnvOrderDetails(
			TblEnvOrderDetails tblEnvOrderDetails);

}
