package com.vz.esap.translation.order.transformer;

import static java.util.Arrays.stream;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.vz.esap.translation.dao.model.TblOrder;
import com.vz.esap.translation.entity.AuthService;
import com.vz.esap.translation.entity.CustomerEntity;
import com.vz.esap.translation.enums.EsapEnum;
import com.vz.esap.translation.enums.EsapEnum.SolutionType;
import com.vz.esap.translation.exception.TranslatorException;
import com.vz.esap.translation.exception.TranslatorException.ErrorCode;
import com.vz.esap.translation.order.model.Order;
import com.vz.esap.translation.order.model.request.DigitString;
import com.vz.esap.translation.order.model.request.Feature;
import com.vz.esap.translation.order.model.request.ParamInfo;
import com.vz.esap.translation.order.model.request.Specification;
import com.vz.esap.translation.order.model.request.VOIPOrderRequest;
import com.vz.esap.translation.util.OrderUtility;

/**
 * @author chattni
 *
 */
@Component
public class EnterpriseTblOrderDetailsDataTransformerImpl implements EnterpriseTblOrderDetailsDataTransformer {

	private static final Logger LOG = LoggerFactory.getLogger(EnterpriseTblOrderDetailsDataTransformerImpl.class);

	private static final String LOCATION_ID = "LocationId";
	private static final String REGION = "Region";
	private static final String CUSTOMER_ID = "CustomerId";
	// private static final String BS_APP_SERVER = "BsAppServer";
	private static final String ADMIN_LASTNAME = "AdminLastName";
	private static final String HOT_CUT_IND = "HotCutIndicator";
	private static final String CDD_IND = "CDDDIndicator";

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.vz.esap.translation.order.transformer.
	 * EnterpriseTblOrderDetailsDataTransformer#
	 * prepareTblOrderDetailsEntityParamDataForCustomer(com.vz.esap.translation.
	 * order.model.request.VOIPOrderRequest,
	 * com.vz.esap.translation.dao.model.TblOrder,
	 * com.vz.esap.translation.entity.CustomerEntity)
	 */
	@Override
	public ParamInfo prepareTblOrderDetailsEntityParamDataForCustomer(VOIPOrderRequest voipOrderRequest,
			TblOrder tblOrderObject, CustomerEntity customer) throws TranslatorException {

		LOG.info("Entered - prepareTblOrderDetailsEntityParamDataForCustomer");
		ParamInfo root = null;
		String action = null;
		List<Feature> entFeats = null;
		boolean hasBwEntIdAssigned = false;
		
		try {
			action = voipOrderRequest.getOrderHeader().getOrderType();
			root = new ParamInfo("Enterprise", null, action);

			// root.addNotNullValChild("EnterpriseId", customer.getCustomerId(),
			// action);
			root.addNotNullValChild("CustomerId", customer.getCustomerId(), action, ParamInfo.Tag.ID);
			root.addNotNullValChild("CustomerName", customer.getCustomerName(), action, ParamInfo.Tag.NAME);
			root.addNotNullValChild("LOR", (customer.getLOR() != null ? customer.getLOR() : "N"), action);
			root.addNotNullValChild("SbcLoadSharingEnabled",
					(customer.getSbcLoadSharing() != null ? customer.getSbcLoadSharing() : "N"), action);
			root.addNotNullValChild("DefaultSubnet",
					(customer.getDefaultSubnet() != null ? customer.getDefaultSubnet() : "N"), action);
			root.addNotNullValChild("RIVCustomer", customer.getRivCustomer(), action);
			root.addNotNullValChild("OrderPlatform", customer.getOrderPlatform(), action);
			root.addNotNullValChild("ProductType", customer.getProductType(), action);
			root.addNotNullValChild("ContactFirstName", customer.getContactFirstName(), action);
			root.addNotNullValChild("ContactLastName", customer.getContactLastName(), action);
			root.addNotNullValChild("ContactTitle", customer.getContactTitle(), action);
			root.addNotNullValChild("ContactAddress1", customer.getContactAddress1(), action);
			root.addNotNullValChild("ContactAddress2", customer.getContactAddress2(), action);
			root.addNotNullValChild("ContactCity", customer.getContactCity(), action);
			root.addNotNullValChild("ContactState", customer.getContactState(), action);
			root.addNotNullValChild("ContactZip", customer.getContactZip(), action);
			root.addNotNullValChild("ContactCountry", customer.getContactCountry(), action);
			root.addNotNullValChild("ContactPhone1", customer.getContactPhone1(), action);
			root.addNotNullValChild("ContactPhone2", customer.getContactPhone2(), action);
			root.addNotNullValChild("ContactFax", customer.getContactFax(), action);
			root.addNotNullValChild("ContactMobile", customer.getContactMobile(), action);
			root.addNotNullValChild("ContactPager", customer.getContactPager(), action);
			root.addNotNullValChild("ContactEmail", customer.getContactEmail(), action);
			// root.addNotNullValChild("RegionType", customer.getRegionTypeStr(customer),
			// action); // code not set in bau
			root.addNotNullValChild("RegionType", voipOrderRequest.getOrderHeader().getRegion(), action);
			if (voipOrderRequest.getLocation() != null && voipOrderRequest.getLocation().getLocationAddress() != null
					&& voipOrderRequest.getLocation().getLocationAddress().getCountryCode() != null)
				root.addNotNullValChild("Region", voipOrderRequest.getLocation().getLocationAddress().getCountryCode(),
						action);
			root.addNotNullValChild("AccountTeamName", customer.getAccountTeamName(), action);
			root.addNotNullValChild("AccountTeamPhone", customer.getAccountTeamPhone(), action);
			root.addNotNullValChild("AccountTeamEmail", customer.getAccountTeamEmail(), action);
			root.addNotNullValChild("NonTrustedIPCalls", customer.getNonTrustedIPCalls(), action);
			root.addNotNullValChild("AllowOnNet", customer.getAllowOnNet(), action);
			root.addNotNullValChild("SipDomain", customer.getSipDomain(), action);
			root.addNotNullValChild("OrderComment", customer.getOrderComment(), action);
			root.addNotNullValChild("XrefCustomerId", customer.getXrefCustomerId(), action);
			root.addNotNullValChild("BillingSystem", customer.getBillingSystemStr(), action);
			root.addNotNullValChild("VnetCorpId", customer.getVnetCorpId(), action);
			root.addNotNullValChild("CentrexType", customer.getCentrexTypeStr(), action);
			root.addNotNullValChild("AgencyHierCode", customer.getAgencyHierCode(), action);
			root.addNotNullValChild("ContractInd", customer.getContractInd(), action);
			root.addNotNullValChild("CalnetSubContractInd", customer.getCalnetSubContractInd(), action);
			if ((customer.getContractInd() != null && !customer.getContractInd().equalsIgnoreCase("S"))
					|| (customer.getContractInd() == null)) {
				root.addNotNullValChild("AdminFirstName", customer.getAdminFirstName(), action);
				root.addNotNullValChild(ADMIN_LASTNAME, customer.getAdminLastName(), action);
				root.addNotNullValChild("AdminEmail", customer.getAdminEmail(), action);
				root.addNotNullValChild("AdminWebLoginId", customer.getAdminWebLoginId(), action);
				root.addNotNullValChild("AdminPassword", customer.getAdminPassword(), action);
			}
			root.addNotNullValChild("EnterpriseCclIndicator", customer.getEnterpriseCclIndicatorStr(), action);
			root.addNotNullValChild("NewIPCCCustOnChange", customer.getIpccCustOnChgStr(), action);
			root.addNotNullValChild("TntCclInd", customer.getTntCclIndStr(), action);
			root.addNotNullValChild("BsAppServer", customer.getBsAppServer(), action);
			root.addNotNullValChild("QosIndicator", customer.getQosIndicator(), action);
			root.addNotNullValChild("SlaType", customer.getSlaType(), action);
			root.addNotNullValChild("CallingPlanId", customer.getCallingPlanId(), action);
			root.addNotNullValChild("IEANLength", customer.getIeanLength(), action);
			root.addNotNullValChild("VmPartitionId", customer.getVmPartitionId(), action, ParamInfo.Tag.NON_ORD);
			root.addNotNullValChild("CommonCustomerId", customer.getCommonCustId(), action);
			root.addNotNullValChild("CommonCustomerName", customer.getCommonCustName(), action);
			root.addNotNullValChild("BillContactPriPhone", customer.getBillContactPriPhone(), action);
			root.addNotNullValChild("BillContactAltPhone", customer.getBillContactAltPhone(), action);
			root.addNotNullValChild("BillContactCell", customer.getBillContactCell(), action);
			root.addNotNullValChild("BillContactPager", customer.getBillContactPager(), action);
			root.addNotNullValChild("BillContactEmail", customer.getBillContactEmail(), action);
			root.addNotNullValChild("BillContactAddr1", customer.getBillContactAddr1(), action);
			root.addNotNullValChild("BillContactAddr2", customer.getBillContactAddr2(), action);
			root.addNotNullValChild("BillContactCity", customer.getBillContactCity(), action);
			root.addNotNullValChild("BillContactState", customer.getBillContactState(), action);
			root.addNotNullValChild("BillContactZip", customer.getBillContactZip(), action);
			root.addNotNullValChild("BillContactCountry", customer.getBillContactCountry(), action);
			root.addNotNullValChild("SalesSegment", customer.getSalesSegment(), action);
			root.addNotNullValChild("SalesRepId", customer.getSalesRepId(), action);
			root.addNotNullValChild("SalesRepName", customer.getSalesRepName(), action);
			root.addNotNullValChild("SalesRepPhone", customer.getSalesRepPhone(), action);
			root.addNotNullValChild("SalesRepEmail", customer.getSalesRepEmail(), action);
			root.addNotNullValChild("CustCorpId", customer.getCustCorpId(), action);
			root.addNotNullValChild("OrderVerification", customer.getOrderVerification(), action);
			root.addNotNullValChild("SupportName", customer.getSupportName(), action);
			root.addNotNullValChild("SupportPhone", customer.getSupportPhone(), action);
			root.addNotNullValChild("EmeaServiceSupport", customer.getEmeaServiceSupport(), action);
			root.addNotNullValChild("CustSensitivityLevel", customer.getCustSensitivityLevel(), action);
			root.addNotNullValChild("CustGarmStatus", customer.getCustGarmStatus(), action);
			root.addNotNullValChild("CustActiveInd", customer.getCustActiveInd(), action);
			root.addNotNullValChild("BsBlockInd", customer.getBsBlockInd(), action);
			root.addNotNullValChild("MicroNode", customer.getMicroNode(), action);
			root.addNotNullValChild("MarketType", customer.getMarketType(), action);
			root.addNotNullValChild("NaspId", customer.getNaspId(), action);

			root.addNotNullValChild("Address", customer.getVirtualAddrLine(), action);

			if(voipOrderRequest.getLocation() != null && voipOrderRequest.getLocation().getLocationAddress() != null) {
				root.addNotNullValChild("City", voipOrderRequest.getLocation().getLocationAddress().getCity(), action);
				root.addNotNullValChild("State", voipOrderRequest.getLocation().getLocationAddress().getState(), action);
				root.addNotNullValChild("Zip", voipOrderRequest.getLocation().getLocationAddress().getZip(), action);
				root.addNotNullValChild("Country", voipOrderRequest.getLocation().getLocationAddress().getCountryCode(),
						action);
				
			}
			
			LOG.info("customer.getGchId()= {}", customer.getGchId());
			root.addNotNullValChild("GCHId", customer.getGchId(), action);
			root.addNotNullValChild("LorId", customer.getLorId(), action);
			root.addNotNullValChild("SOEnabled", customer.getSoEnabled(), action);
			root.addNotNullValChild("USLDAndLocalBestPool", customer.getUsLDAndLocalBestPool(), action);
			root.addNotNullValChild("USLDOnlyBestPool", customer.getUsLDOnlyBestPool(), action);
			root.addNotNullValChild("USLDAndLocalBestPlusPoolId", customer.getUsLDAndLocalBestPlusPoolId(), action);
			root.addNotNullValChild("USLDAndLocalBestPlusPool", customer.getUsLDAndLocalBestPlusPool(), action);
			root.addNotNullValChild("USLDOnlyBestPlusPoolId", customer.getUsLDOnlyBestPlusPoolId(), action);
			root.addNotNullValChild("USLDOnlyBestPlusPool", customer.getUsLDOnlyBestPlusPool(), action);
			root.addNotNullValChild("EmeaApacBestPool", customer.getEmeaApacBestPool(), action);
			root.addNotNullValChild("EmeaApacBestPlusPoolId", customer.getEmeaApacBestPlusPoolId(), action);
			root.addNotNullValChild("EmeaApacBestPlusPool", customer.getEmeaApacBestPlusPool(), action);
			root.addNotNullValChild("USLDAndLocalBestPlusCclPoolId", customer.getUsLDAndLocalBestPlusCclPoolId(),
					action);
			root.addNotNullValChild("USLDAndLocalBestPlusCclPool", customer.getUsLDAndLocalBestPlusCclPool(), action);
			root.addNotNullValChild("USLDOnlyBestPlusCclPoolId", customer.getUsLDOnlyBestPlusCclPoolId(), action);
			root.addNotNullValChild("USLDOnlyBestPlusCclPool", customer.getUsLDOnlyBestPlusCclPool(), action);
			root.addNotNullValChild("EmeaApacBestPlusCclPoolId", customer.getEmeaApacBestPlusCclPoolId(), action);
			root.addNotNullValChild("EmeaApacBestPlusCclPool", customer.getEmeaApacBestPlusCclPool(), action);
			root.addNotNullValChild("EntepriseCountryCode", customer.getEntCountryCode(), action);
			root.addNotNullValChild("DesignId", customer.getDesignId(), action);
			root.addNotNullValChild("EnterpriseTrunkingType", customer.getEnterpriseTrunkingType(), action);
			root.addNotNullValChild("CatalogueReferenceTime", customer.getCatalogVersionTime(), action);
			if (customer.getAuthFeatureType() != null)
				root.addNotNullValChild("AuthFeatureType", customer.getAuthFeatureType().toString(), action);
			// XO
			if (voipOrderRequest.getConvergedService() != null) {
				entFeats = stream(voipOrderRequest.getConvergedService().getFeature())
						.filter(feat -> feat.getCode().equalsIgnoreCase("EFET_VOIP_ENT_LVL")).collect(Collectors.toList());
				
			}
			

			if(!CollectionUtils.isEmpty(entFeats)) {
				for (Specification spec : entFeats.get(0).getSpecification()) {
					if ("BW_ENTERPRISE_ID".equalsIgnoreCase(spec.getCode())) {
						root.addNotNullValChild("BWEnterpriseId", spec.getValue(), action);
						hasBwEntIdAssigned = true;
					}
						
					if ("VOICE_VPN".equalsIgnoreCase(spec.getCode()))
						root.addNotNullValChild("VoiceVPN", spec.getValue(), action);
					if ("EnableEnterpriseExtensionDialing".equalsIgnoreCase(spec.getCode()))
						root.addNotNullValChild("EnableEnterpriseExtensionDialing", spec.getValue(), action);// Anitha Fix
																												// this
				}
				
				//Added for HPBX
				if(SolutionType.HPBX.equals(voipOrderRequest.getOrderHeader().getSolutionType())) {
					root.addNotNullValChild("ProvisionCategory", "INV_ONLY", action);
				}
			}
			

			// XO
			if (customer.getAuthServices() != null) {
				root.addChildParam(new ParamInfo("AUTHORIZE", "YES", null));
				for (Map.Entry<String, Boolean> entry : customer.getAuthServices().entrySet()) {
					ParamInfo authParam = new ParamInfo("AuthService", null, action);
					authParam.addChildParam(new ParamInfo("Name", entry.getKey(), action));
					if (entry.getValue() != null)
						authParam.addChildParam(new ParamInfo("Authorised", entry.getValue() ? "Y" : "N", action));
					root.addChildParam(authParam, ParamInfo.Tag.NON_ORD);
				}
			}

			//Feature Quantity changes		
			if(customer.getAuthService() != null) {
				for(AuthService authService : customer.getAuthService()) {
					ParamInfo custAuth = new ParamInfo("AuthService", null, action);
					custAuth.addNotNullValChild("Name", authService.getName(), action);
					custAuth.addNotNullValChild("FeatureQuantity", authService.getFeatureQuantity(), action);
					custAuth.addNotNullValChild("Authorised", authService.getAuthorise(), action);
					root.addChildParam(custAuth);
				}
			}
			
			if (customer.getDigitStrings() != null) {
				for (DigitString ds : customer.getDigitStrings())
					root.addChildParam(ds.getParamInfo(action));
			}

			if (customer.getAttribMap() != null) // check this
				root.addChildParam(OrderUtility.getAttribParamInfo(customer.getAttribMap(), action));
			if (customer.getSipDomains() != null)// check this
				root.addChildParam(OrderUtility.getCollectionParamInfo(customer.getSipDomains(), action, "SipDomains",
						"SipDomain"));

			/* New ParamName for the BroadSoft AppServer select from user */
			root.addNotNullValChild("BSAS_STATE", "INITIAL", action);
			if (customer.getHotCutIndicator() != null && customer.getHotCutIndicator() == Boolean.TRUE)
				root.addNotNullValChild("HotCutIndicator", "Y", action);
			if (customer.getCDDDIndicator() != null && customer.getCDDDIndicator() == Boolean.TRUE)
				root.addNotNullValChild("CDDDIndicator", "Y", action);

			if (customer.getGcmInfo() != null) {
				root.addChildParam(customer.getGcmInfo().getParamInfo(action));
			}

			if (customer.getTsoMigrationEntReferenceData() != null) {
				root.addChildParam(customer.getTsoMigrationEntReferenceData().getParamInfo());
			}
			
			if (!hasBwEntIdAssigned && customer != null && customer.getBwEnterpriseId() != null) {
				root.addNotNullValChild("BWEnterpriseId", customer.getBwEnterpriseId(), action);
				hasBwEntIdAssigned = true;
			}

			root.addNotNullValChild("CummulativeCcl", customer.getCummulativeCcl(), action);
			root.addNotNullValChild("AsClli", voipOrderRequest.getOrderHeader().getAsClli(), action); //adding bs clli.
			LOG.info("Exit prepareTblOrderDetailsEntityParamData");
		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new TranslatorException(ErrorCode.TRANSFORMER_FAILURE,
					"Exception occured in prepareTblOrderDetailsEntityParamDataForCustomer");
		}
		return root;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.vz.esap.translation.order.transformer.
	 * EnterpriseTblOrderDetailsDataTransformer#
	 * prepareTblOrderDetailsHeaderParamData(com.vz.esap.translation.order.model.
	 * Order)
	 */
	@Override
	public ParamInfo prepareTblOrderDetailsHeaderParamData(Order order) throws ParseException, TranslatorException {

		LOG.info("Entered - prepareTblOrderDetailsHeaderParamData");
		ParamInfo root = null;
		String action = null;

		try {
			action = order.getOrderHeader().getOrderType();

			root = new ParamInfo("Header", null, action);

			root.addNotNullValChild("OrderNumber", order.getOrderHeader().getOrderNumber(), action);
			root.addNotNullValChild("EnvOrderId", order.getOrderHeader().getEnvOrderId(), action);
			root.addNotNullValChild("MasterOrderNumber", order.getOrderHeader().getMasterOrderNumber(), action);
			root.addNotNullValChild("OrderVersion", order.getOrderHeader().getOrderVersion(), action);
			root.addNotNullValChild("TransactionId", order.getOrderHeader().getTransactionId(), action);

			if (order.getCustomerEntity() != null) {
				root.addNotNullValChild("Region", order.getCustomerEntity().getRegion(), action);
			}

			else if (order.getEnterpriseTrunks() != null) {
				root.addNotNullValChild("Region", order.getEnterpriseTrunks().get(0).getRegion(), action);
			}

			root.addNotNullValChild("MinorOrderType", order.getOrderHeader().getMinorOrderType(), action);
			root.addNotNullValChild("CentrexType", order.getOrderHeader().getCentrexType(), action);
			root.addNotNullValChild("ServiceType", order.getOrderHeader().getServiceType(), action);
			root.addNotNullValChild("OriginatingSystem", order.getOrderHeader().getOriginatingSystem(), action);
			root.addNotNullValChild("InterfaceSystem", order.getOrderHeader().getInterfaceSystem(), action);
			root.addNotNullValChild("OrderType",
					EsapEnum.OrderType.getValue(order.getOrderHeader().getOrderType().charAt(0)), action);
			root.addNotNullValChild("SuppType", order.getOrderHeader().getSuppType(), action);
			root.addNotNullValChild("OrderClassify", order.getOrderHeader().getFunctionCode(), action);

			if (order.getOrderHeader().getDueDate() != null) {
				SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
				Calendar calendar = GregorianCalendar.getInstance();
				calendar.setTime(format.parse(order.getOrderHeader().getDueDate().toString()));
				Object dueDate = calendar.getTime();
				root.addNotNullValChild("DueDate", dueDate, action);
			}
			root.addNotNullValChild("CustomerId", order.getOrderHeader().getCustomerId(), action);
			root.addNotNullValChild("LocationId", order.getOrderHeader().getLocationId(), action);
			root.addNotNullValChild("BsAppServer", order.getOrderHeader().getBsAppServer(), action);
			root.addNotNullValChild("OrderProTIN", order.getOrderHeader().getOrderProTIN(), action);
			root.addNotNullValChild("IOrderTIN", order.getOrderHeader().getiOrderTIN(), action);
			root.addNotNullValChild("TINVersion", order.getOrderHeader().getTinVersion(), action);
			root.addNotNullValChild("TransitionFlag", order.getOrderHeader().isTransitionFlag() ? "Y" : "N", action);
			root.addNotNullValChild("Priority", order.getOrderHeader().getPriority(), action);
			if (order.getOrderHeader().getAttribMap() != null) {
				root.addChildParam(OrderUtility.getAttribParamInfo(order.getOrderHeader().getAttribMap(), action));
			}
			if (order.getOrderHeader().getOrderCreatedBy() != null)
				root.addNotNullValChild("OrderCreatedBy", order.getOrderHeader().getOrderCreatedBy(), action);
			if (order.getOrderHeader().isHasBulkOrder()) {
				root.addNotNullValChild("BULK", "Y", action);
			}
			if (order.getOrderHeader().getHotCutIndicator() != null) {
				root.addNotNullValChild("HotCutIndicator", "Y", action);
			}
			if (order.getOrderHeader().getCDDDIndicator() != null) {
				root.addNotNullValChild("CDDDIndicator", "Y", action);
			}
			if (order.getOrderHeader().getSolutionType() != null) {
				root.addNotNullValChild("SolutionType", order.getOrderHeader().getSolutionType().toString(), action);
			}
			if (order.getOrderHeader().getAuthFeatureType() != null) {
				root.addNotNullValChild("AuthFeatureType", order.getOrderHeader().getAuthFeatureType().toString(),
						action);
			}
			if (order.getOrderHeader().getGchId() != null) {
				LOG.info("order.getOrderHeader().getGchId(): {}", order.getOrderHeader().getGchId());
				root.addNotNullValChild("GCHId", order.getOrderHeader().getGchId(), action);
			}
		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new TranslatorException(ErrorCode.TRANSFORMER_FAILURE,
					"Exception occured in prepareTblOrderDetailsEntityParamDataForCustomer");
		}

		LOG.info("Exit prepareTblOrderDetailsHeaderParamData");

		return root;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.vz.esap.translation.order.transformer.
	 * EnterpriseTblOrderDetailsDataTransformer#
	 * prepareTblOrderDetailsEntityParamDataForCustomer(com.vz.esap.translation.
	 * order.model.Order)
	 */
	@Override
	public ParamInfo prepareTblOrderDetailsEntityParamDataForCustomer(Order order, String action) {
		LOG.info("Entered - prepareTblOrderDetailsEntityParamDataForCustomer");

		if (order.getCustomer() == null)
			return null;

		if (action == null)
			action = order.getOrderHeader().getOrderType();

		ParamInfo root = new ParamInfo("Enterprise", null, action);

		/*
		 * if (isMigrate) root.addNotNullValChild("EnterpriseId",
		 * order.getCustomer().getCustomerId(), action);
		 */
		root.addNotNullValChild("CustomerId", order.getCustomer().getCustomerId(), action, ParamInfo.Tag.ID);
		root.addNotNullValChild("CustomerName", order.getCustomer().getCustomerName(), action, ParamInfo.Tag.NAME);
		root.addNotNullValChild("LOR", (order.getCustomer().getLOR() != null ? order.getCustomer().getLOR() : "N"),
				action);
		root.addNotNullValChild("SbcLoadSharingEnabled",
				(order.getCustomer().getSbcLoadSharing() != null ? order.getCustomer().getSbcLoadSharing() : "N"),
				action);
		root.addNotNullValChild("DefaultSubnet",
				(order.getCustomer().getDefaultSubnet() != null ? order.getCustomer().getDefaultSubnet() : "N"),
				action);
		root.addNotNullValChild("RIVCustomer", order.getCustomer().getRivCustomer(), action);
		root.addNotNullValChild("OrderPlatform", order.getCustomer().getOrderPlatform(), action);
		root.addNotNullValChild("ProductType", order.getCustomer().getProductType(), action);
		root.addNotNullValChild("ContactFirstName", order.getCustomer().getContactFirstName(), action);
		root.addNotNullValChild("ContactLastName", order.getCustomer().getContactLastName(), action);
		root.addNotNullValChild("ContactTitle", order.getCustomer().getContactTitle(), action);
		root.addNotNullValChild("ContactAddress1", order.getCustomer().getContactAddress1(), action);
		root.addNotNullValChild("ContactAddress2", order.getCustomer().getContactAddress2(), action);
		root.addNotNullValChild("ContactCity", order.getCustomer().getContactCity(), action);
		root.addNotNullValChild("ContactState", order.getCustomer().getContactState(), action);
		root.addNotNullValChild("ContactZip", order.getCustomer().getContactZip(), action);
		root.addNotNullValChild("ContactCountry", order.getCustomer().getContactCountry(), action);
		root.addNotNullValChild("ContactPhone1", order.getCustomer().getContactPhone1(), action);
		root.addNotNullValChild("ContactPhone2", order.getCustomer().getContactPhone2(), action);
		root.addNotNullValChild("ContactFax", order.getCustomer().getContactFax(), action);
		root.addNotNullValChild("ContactMobile", order.getCustomer().getContactMobile(), action);
		root.addNotNullValChild("ContactPager", order.getCustomer().getContactPager(), action);
		root.addNotNullValChild("ContactEmail", order.getCustomer().getContactEmail(), action);
		// root.addNotNullValChild("RegionType",
		// order.getCustomer().getRegionTypeStr(order.getCustomer()), action);
		root.addNotNullValChild("RegionType", order.getOrderHeader().getRegion(), action);
		root.addNotNullValChild("AccountTeamName", order.getCustomer().getAccountTeamName(), action);
		root.addNotNullValChild("AccountTeamPhone", order.getCustomer().getAccountTeamPhone(), action);
		root.addNotNullValChild("AccountTeamEmail", order.getCustomer().getAccountTeamEmail(), action);
		root.addNotNullValChild("NonTrustedIPCalls", order.getCustomer().getNonTrustedIPCalls(), action);
		root.addNotNullValChild("AllowOnNet", order.getCustomer().getAllowOnNet(), action);
		root.addNotNullValChild("SipDomain", order.getCustomer().getSipDomain(), action);
		root.addNotNullValChild("OrderComment", order.getCustomer().getOrderComment(), action);
		root.addNotNullValChild("XrefCustomerId", order.getCustomer().getXrefCustomerId(), action);
		root.addNotNullValChild("BillingSystem", order.getCustomer().getBillingSystemStr(), action);
		root.addNotNullValChild("VnetCorpId", order.getCustomer().getVnetCorpId(), action);
		root.addNotNullValChild("CentrexType", order.getCustomer().getCentrexTypeStr(), action);
		root.addNotNullValChild("AgencyHierCode", order.getCustomer().getAgencyHierCode(), action);
		root.addNotNullValChild("ContractInd", order.getCustomer().getContractInd(), action);
		root.addNotNullValChild("CalnetSubContractInd", order.getCustomer().getCalnetSubContractInd(), action);
		if ((order.getCustomer().getContractInd() != null
				&& !order.getCustomer().getContractInd().equalsIgnoreCase("S"))
				|| (order.getCustomer().getContractInd() == null)) {
			root.addNotNullValChild("AdminFirstName", order.getCustomer().getAdminFirstName(), action);
			root.addNotNullValChild("AdminLastName", order.getCustomer().getAdminLastName(), action);
			root.addNotNullValChild("AdminEmail", order.getCustomer().getAdminEmail(), action);
			root.addNotNullValChild("AdminWebLoginId", order.getCustomer().getAdminWebLoginId(), action);
			root.addNotNullValChild("AdminPassword", order.getCustomer().getAdminPassword(), action);
		}
		root.addNotNullValChild("EnterpriseCclIndicator", order.getCustomer().getEnterpriseCclIndicatorStr(), action);
		root.addNotNullValChild("NewIPCCCustOnChange", order.getCustomer().getIpccCustOnChgStr(), action); // New IPCC
		root.addNotNullValChild("TntCclInd", order.getCustomer().getTntCclIndStr(), action);
		root.addNotNullValChild("BsAppServer", order.getCustomer().getBsAppServer(), action);
		root.addNotNullValChild("QosIndicator", order.getCustomer().getQosIndicator(), action);
		root.addNotNullValChild("SlaType", order.getCustomer().getSlaType(), action);
		root.addNotNullValChild("CallingPlanId", order.getCustomer().getCallingPlanId(), action);
		root.addNotNullValChild("IEANLength", order.getCustomer().getIeanLength(), action);
		root.addNotNullValChild("VmPartitionId", order.getCustomer().getVmPartitionId(), action, ParamInfo.Tag.NON_ORD);
		root.addNotNullValChild("CommonCustomerId", order.getCustomer().getCommonCustId(), action);
		root.addNotNullValChild("CommonCustomerName", order.getCustomer().getCommonCustName(), action);
		root.addNotNullValChild("BillContactPriPhone", order.getCustomer().getBillContactPriPhone(), action);
		root.addNotNullValChild("BillContactAltPhone", order.getCustomer().getBillContactAltPhone(), action);
		root.addNotNullValChild("BillContactCell", order.getCustomer().getBillContactCell(), action);
		root.addNotNullValChild("BillContactPager", order.getCustomer().getBillContactPager(), action);
		root.addNotNullValChild("BillContactEmail", order.getCustomer().getBillContactEmail(), action);
		root.addNotNullValChild("BillContactAddr1", order.getCustomer().getBillContactAddr1(), action);
		root.addNotNullValChild("BillContactAddr2", order.getCustomer().getBillContactAddr2(), action);
		root.addNotNullValChild("BillContactCity", order.getCustomer().getBillContactCity(), action);
		root.addNotNullValChild("BillContactState", order.getCustomer().getBillContactState(), action);
		root.addNotNullValChild("BillContactZip", order.getCustomer().getBillContactZip(), action);
		root.addNotNullValChild("BillContactCountry", order.getCustomer().getBillContactCountry(), action);
		root.addNotNullValChild("SalesSegment", order.getCustomer().getSalesSegment(), action);
		root.addNotNullValChild("SalesRepId", order.getCustomer().getSalesRepId(), action);
		root.addNotNullValChild("SalesRepName", order.getCustomer().getSalesRepName(), action);
		root.addNotNullValChild("SalesRepPhone", order.getCustomer().getSalesRepPhone(), action);
		root.addNotNullValChild("SalesRepEmail", order.getCustomer().getSalesRepEmail(), action);
		root.addNotNullValChild("CustCorpId", order.getCustomer().getCustCorpId(), action);
		root.addNotNullValChild("OrderVerification", order.getCustomer().getOrderVerification(), action);
		root.addNotNullValChild("SupportName", order.getCustomer().getSupportName(), action);
		root.addNotNullValChild("SupportPhone", order.getCustomer().getSupportPhone(), action);
		root.addNotNullValChild("EmeaServiceSupport", order.getCustomer().getEmeaServiceSupport(), action);
		root.addNotNullValChild("CustSensitivityLevel", order.getCustomer().getCustSensitivityLevel(), action);
		root.addNotNullValChild("CustGarmStatus", order.getCustomer().getCustGarmStatus(), action);
		root.addNotNullValChild("CustActiveInd", order.getCustomer().getCustActiveInd(), action);
		root.addNotNullValChild("BsBlockInd", order.getCustomer().getBsBlockInd(), action);
		root.addNotNullValChild("MicroNode", order.getCustomer().getMicroNode(), action);
		root.addNotNullValChild("MarketType", order.getCustomer().getMarketType(), action);
		root.addNotNullValChild("NaspId", order.getCustomer().getNaspId(), action);

		// E2E Mar Changes
		// Virtual Address
		root.addNotNullValChild("Address", order.getCustomer().getVirtualAddrLine(), action);
		root.addNotNullValChild("City", order.getCustomer().getVirtualAddrCity(), action);
		root.addNotNullValChild("State", order.getCustomer().getVirtualAddrState(), action);
		root.addNotNullValChild("Zip", order.getCustomer().getVirtualAddrZip(), action);
		root.addNotNullValChild("Country", order.getCustomer().getVirtualAddrCountry(), action);

		LOG.info("order.getCustomer().getGchId()=", order.getCustomer().getGchId());
		root.addNotNullValChild("GCHId", order.getCustomer().getGchId(), action);
		root.addNotNullValChild("LorId", order.getCustomer().getLorId(), action);
		// E2E Service Optimization Changes
		root.addNotNullValChild("SOEnabled", order.getCustomer().getSoEnabled(), action);
		root.addNotNullValChild("USLDAndLocalBestPool", order.getCustomer().getUsLDAndLocalBestPool(), action);
		root.addNotNullValChild("USLDOnlyBestPool", order.getCustomer().getUsLDOnlyBestPool(), action);
		root.addNotNullValChild("USLDAndLocalBestPlusPoolId", order.getCustomer().getUsLDAndLocalBestPlusPoolId(),
				action);
		root.addNotNullValChild("USLDAndLocalBestPlusPool", order.getCustomer().getUsLDAndLocalBestPlusPool(), action);
		root.addNotNullValChild("USLDOnlyBestPlusPoolId", order.getCustomer().getUsLDOnlyBestPlusPoolId(), action);
		root.addNotNullValChild("USLDOnlyBestPlusPool", order.getCustomer().getUsLDOnlyBestPlusPool(), action);
		root.addNotNullValChild("EmeaApacBestPool", order.getCustomer().getEmeaApacBestPool(), action);
		root.addNotNullValChild("EmeaApacBestPlusPoolId", order.getCustomer().getEmeaApacBestPlusPoolId(), action);
		root.addNotNullValChild("EmeaApacBestPlusPool", order.getCustomer().getEmeaApacBestPlusPool(), action);
		root.addNotNullValChild("USLDAndLocalBestPlusCclPoolId", order.getCustomer().getUsLDAndLocalBestPlusCclPoolId(),
				action);
		root.addNotNullValChild("USLDOnlyBestPlusCclPoolId", order.getCustomer().getUsLDOnlyBestPlusCclPoolId(),
				action);
		root.addNotNullValChild("EmeaApacBestPlusCclPoolId", order.getCustomer().getEmeaApacBestPlusCclPoolId(),
				action);
		root.addNotNullValChild("ParentEnterpriseId", order.getCustomer().getParentEnterpriseId(), action);

		// XO
		root.addNotNullValChild("BWEnterpriseId", order.getCustomer().getBwEnterpriseId(), action);
		root.addNotNullValChild("VoiceVPN", order.getCustomer().getVoiceVpn(), action);
		root.addNotNullValChild("EnableEnterpriseExtensionDialing",
				order.getCustomer().getEnableEnterpriseExtensionDialing(), action);

		// XO

		// root.addNotNullValChild("EnterpriseServicePlan",
		// order.getCustomer().getEntServicePlan(), action);
		root.addNotNullValChild("EntepriseCountryCode", order.getCustomer().getEntCountryCode(), action);
		root.addNotNullValChild("DesignId", order.getCustomer().getDesignId(), action);
		root.addNotNullValChild("EnterpriseTrunkingType", order.getCustomer().getEnterpriseTrunkingType(), action);
		root.addNotNullValChild("CatalogueReferenceTime", order.getCustomer().getCatalogVersionTime(), action);
		// E2E Mar Changes End

		// root.addNotNullValChild("SbcAutomation",
		// order.getCustomer().getSbcAutomationStr(), action);

		if (order.getCustomer().getAuthServices() != null) {
			// root.addChildParam(new ParamInfo("AUTHORIZE", null, null));
			root.addChildParam(new ParamInfo("AUTHORIZE", "YES", null));
			for (Map.Entry<String, Boolean> entry : order.getCustomer().getAuthServices().entrySet()) {
				ParamInfo authParam = new ParamInfo("AuthService", null, action);
				authParam.addChildParam(new ParamInfo("Name", entry.getKey(), action));
				if (entry.getValue() != null)
					authParam.addChildParam(new ParamInfo("Authorised", entry.getValue() ? "Y" : "N", action));
				root.addChildParam(authParam, ParamInfo.Tag.NON_ORD);
			}
		}

		if (order.getCustomer().getAuthService() != null) {
			for (AuthService authServiceList :order.getCustomer().getAuthService()) {
				ParamInfo custAuthFeat = new ParamInfo("AuthService", null, action);
				custAuthFeat.addChildParam(new ParamInfo("Name", authServiceList.getName(), action));		
				custAuthFeat.addChildParam(new ParamInfo("FeatureQuantity", authServiceList.getFeatureQuantity(), action));		
				custAuthFeat.addChildParam(new ParamInfo("Authorised", OrderUtility.booleanToStr(authServiceList.getAuthorise()) , action));
				root.addChildParam(custAuthFeat);
			}
		}
		
		if (order.getCustomer().getDigitStrings() != null) {
			for (DigitString ds : order.getCustomer().getDigitStrings())
				root.addChildParam(ds.getParamInfo(action));
		}

		root.addChildParam(OrderUtility.getAttribParamInfo(order.getCustomer().getAttribMap(), action));
		root.addChildParam(OrderUtility.getCollectionParamInfo(order.getCustomer().getSipDomains(), action,
				"SipDomains", "SipDomain"));

		/* New ParamName for the BroadSoft AppServer select from user */
		root.addNotNullValChild("BSAS_STATE", "INITIAL", action);
		if (order.getCustomer().getHotCutIndicator() != null
				&& order.getCustomer().getHotCutIndicator() == Boolean.TRUE)
			root.addNotNullValChild("HotCutIndicator", "Y", action);
		if (order.getCustomer().getCDDDIndicator() != null && order.getCustomer().getCDDDIndicator() == Boolean.TRUE)
			root.addNotNullValChild("CDDDIndicator", "Y", action);

		if (order.getCustomer().getGcmInfo() != null) {
			root.addChildParam(order.getCustomer().getGcmInfo().getParamInfo(action));
		}

		if (order.getCustomer().getTsoMigrationEntReferenceData() != null) {
			root.addChildParam(order.getCustomer().getTsoMigrationEntReferenceData().getParamInfo());
		}
		// if (customer!=null && order.getCustomer().getSoEnabled() !=null &&
		// order.getCustomer().getSoEnabled().equals("1")) {

		root.addNotNullValChild("CummulativeCcl", order.getCustomer().getCummulativeCcl(), action);
		/*
		 * root.addNotNullValChild("BestPlusTier",
		 * order.getCustomer().getBestPlusTier(), action);
		 */

		// }

		return root;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.vz.esap.translation.order.transformer.
	 * EnterpriseTblOrderDetailsDataTransformer#
	 * prepareTblOrderDetailsEntityParamDataForCustomer(com.vz.esap.translation.
	 * entity.CustomerEntity, com.vz.esap.translation.entity.CustomerEntity,
	 * boolean, java.lang.String)
	 */
	@Override
	public ParamInfo prepareTblOrderDetailsEntityParamDataForCustomer(CustomerEntity oldCustomerEntity,
			CustomerEntity newCustomerEntity, boolean supp, String action) {

		LOG.info("Entering prepareTbloldCustomerEntityDetailsEntityParamDataForLocation(old, new, supp) SUPP value: {}",
				supp);

		ParamInfo enterpriseParam = new ParamInfo("Enterprise", null, null);

		enterpriseParam.addChangeParam("CustomerId", oldCustomerEntity.getCustomerId(),
				newCustomerEntity.getCustomerId(), supp, ParamInfo.Tag.ID);
		enterpriseParam.addChangeParam("CustomerName", oldCustomerEntity.getCustomerName(),
				newCustomerEntity.getCustomerName(), supp, ParamInfo.Tag.NAME);
		enterpriseParam.addChangeParam("LOR", "N", "N", supp);
		enterpriseParam.addChangeParam("SbcLoadSharingEnabled",
				(oldCustomerEntity.getSbcLoadSharing() != null ? oldCustomerEntity.getSbcLoadSharing() : "N"),
				newCustomerEntity.getSbcLoadSharing(), supp);
		enterpriseParam.addChangeParam("DefaultSubnet",
				(oldCustomerEntity.getDefaultSubnet() != null ? oldCustomerEntity.getDefaultSubnet() : "N"),
				newCustomerEntity.getDefaultSubnet(), supp);
		enterpriseParam.addChangeParam("RIVCustomer", oldCustomerEntity.getRivCustomer(),
				newCustomerEntity.getRivCustomer(), supp);
		enterpriseParam.addChangeParam("OrderPlatform", oldCustomerEntity.getOrderPlatform(),
				newCustomerEntity.getOrderPlatform(), supp);
		enterpriseParam.addChangeParam("ProductType", oldCustomerEntity.getProductType(),
				newCustomerEntity.getProductType(), supp);
		enterpriseParam.addChangeParam("ContactFirstName", oldCustomerEntity.getContactFirstName(),
				newCustomerEntity.getContactFirstName(), supp);
		enterpriseParam.addChangeParam("ContactLastName", oldCustomerEntity.getContactLastName(),
				newCustomerEntity.getContactLastName(), supp);
		enterpriseParam.addChangeParam("ContactTitle", oldCustomerEntity.getContactTitle(),
				newCustomerEntity.getContactTitle(), supp);
		enterpriseParam.addChangeParam("ContactAddress1", oldCustomerEntity.getContactAddress1(),
				newCustomerEntity.getContactAddress1(), supp);
		enterpriseParam.addChangeParam("ContactAddress2", oldCustomerEntity.getContactAddress2(),
				newCustomerEntity.getContactAddress2(), supp);
		enterpriseParam.addChangeParam("ContactCity", oldCustomerEntity.getContactCity(),
				newCustomerEntity.getContactCity(), supp);
		enterpriseParam.addChangeParam("ContactState", oldCustomerEntity.getContactState(),
				newCustomerEntity.getContactState(), supp);
		enterpriseParam.addChangeParam("ContactZip", oldCustomerEntity.getContactZip(),
				newCustomerEntity.getContactZip(), supp);
		enterpriseParam.addChangeParam("ContactCountry", oldCustomerEntity.getContactCountry(),
				newCustomerEntity.getContactCountry(), supp);
		/*enterpriseParam.addChangeParam("ContactPhone1", oldCustomerEntity.getContactPhone1(),
				newCustomerEntity.getContactPhone1(), supp);*/
		enterpriseParam.addChangeParam("ContactPhone2", oldCustomerEntity.getContactPhone2(),
				newCustomerEntity.getContactPhone2(), supp);
		enterpriseParam.addChangeParam("ContactFax", oldCustomerEntity.getContactFax(),
				newCustomerEntity.getContactFax(), supp);
		enterpriseParam.addChangeParam("ContactMobile", oldCustomerEntity.getContactMobile(),
				newCustomerEntity.getContactMobile(), supp);
		enterpriseParam.addChangeParam("ContactPager", oldCustomerEntity.getContactPager(),
				newCustomerEntity.getContactPager(), supp);
		enterpriseParam.addChangeParam("ContactEmail", oldCustomerEntity.getContactEmail(),
				newCustomerEntity.getContactEmail(), supp);
		enterpriseParam.addChangeParam("RegionType", newCustomerEntity.getRegion(), newCustomerEntity.getRegion(),
				supp);
		enterpriseParam.addChangeParam("AccountTeamName", oldCustomerEntity.getAccountTeamName(),
				newCustomerEntity.getAccountTeamName(), supp);
		enterpriseParam.addChangeParam("AccountTeamPhone", oldCustomerEntity.getAccountTeamPhone(),
				newCustomerEntity.getAccountTeamPhone(), supp);
		enterpriseParam.addChangeParam("AccountTeamEmail", oldCustomerEntity.getAccountTeamEmail(),
				newCustomerEntity.getAccountTeamEmail(), supp);
		enterpriseParam.addChangeParam("NonTrustedIPCalls", oldCustomerEntity.getNonTrustedIPCalls(),
				newCustomerEntity.getNonTrustedIPCalls(), supp);
		enterpriseParam.addChangeParam("AllowOnNet", oldCustomerEntity.getAllowOnNet(),
				newCustomerEntity.getAllowOnNet(), supp);
		enterpriseParam.addChangeParam("SipDomain", oldCustomerEntity.getSipDomain(), newCustomerEntity.getSipDomain(),
				supp);
		enterpriseParam.addChangeParam("OrderComment", oldCustomerEntity.getOrderComment(),
				newCustomerEntity.getOrderComment(), supp);
		enterpriseParam.addChangeParam("XrefCustomerId", oldCustomerEntity.getXrefCustomerId(),
				newCustomerEntity.getXrefCustomerId(), supp);
		enterpriseParam.addChangeParam("BillingSystem", oldCustomerEntity.getBillingSystemStr(),
				newCustomerEntity.getBillingSystemStr(), supp);
		enterpriseParam.addChangeParam("VnetCorpId", oldCustomerEntity.getVnetCorpId(),
				newCustomerEntity.getVnetCorpId(), supp);
		enterpriseParam.addChangeParam("CentrexType", oldCustomerEntity.getCentrexTypeStr(),
				newCustomerEntity.getCentrexTypeStr(), supp);
		enterpriseParam.addChangeParam("AgencyHierCode", oldCustomerEntity.getAgencyHierCode(),
				newCustomerEntity.getAgencyHierCode(), supp);
		enterpriseParam.addChangeParam("ContractInd", oldCustomerEntity.getContractInd(),
				newCustomerEntity.getContractInd(), supp);
		enterpriseParam.addChangeParam("CalnetSubContractInd", oldCustomerEntity.getCalnetSubContractInd(),
				newCustomerEntity.getCalnetSubContractInd(), supp);
		if ((oldCustomerEntity.getContractInd() != null && !oldCustomerEntity.getContractInd().equalsIgnoreCase("S"))
				|| (oldCustomerEntity.getContractInd() == null)) {
			enterpriseParam.addChangeParam("AdminFirstName", oldCustomerEntity.getAdminFirstName(),
					newCustomerEntity.getAdminFirstName(), supp);
			enterpriseParam.addChangeParam("AdminLastName", oldCustomerEntity.getAdminLastName(),
					newCustomerEntity.getAdminLastName(), supp);
			enterpriseParam.addChangeParam("AdminEmail", oldCustomerEntity.getAdminEmail(),
					newCustomerEntity.getAdminEmail(), supp);
			enterpriseParam.addChangeParam("AdminWebLoginId", oldCustomerEntity.getAdminWebLoginId(),
					newCustomerEntity.getAdminWebLoginId(), supp);
			enterpriseParam.addChangeParam("AdminPassword", oldCustomerEntity.getAdminPassword(),
					newCustomerEntity.getAdminPassword(), supp);
		}
		enterpriseParam.addChangeParam("EnterpriseCclIndicator", oldCustomerEntity.getEnterpriseCclIndicatorStr(),
				newCustomerEntity.getEnterpriseCclIndicatorStr(), supp);
		enterpriseParam.addChangeParam("NewIPCCCustOnChange", oldCustomerEntity.getIpccCustOnChgStr(),
				newCustomerEntity.getIpccCustOnChgStr(), supp); // New IPCC
		enterpriseParam.addChangeParam("TntCclInd", oldCustomerEntity.getTntCclIndStr(),
				newCustomerEntity.getTntCclIndStr(), supp);
		enterpriseParam.addChangeParam("BsAppServer", oldCustomerEntity.getBsAppServer(),
				newCustomerEntity.getBsAppServer(), supp);
		enterpriseParam.addChangeParam("QosIndicator", oldCustomerEntity.getQosIndicator(),
				newCustomerEntity.getQosIndicator(), supp);
		enterpriseParam.addChangeParam("SlaType", oldCustomerEntity.getSlaType(), newCustomerEntity.getSlaType(), supp);
		enterpriseParam.addChangeParam("CallingPlanId", oldCustomerEntity.getCallingPlanId(),
				newCustomerEntity.getCallingPlanId(), supp);
		enterpriseParam.addChangeParam("IEANLength", oldCustomerEntity.getIeanLength(),
				newCustomerEntity.getIeanLength(), supp);
		enterpriseParam.addChangeParam("VmPartitionId", oldCustomerEntity.getVmPartitionId(),
				newCustomerEntity.getVmPartitionId(), supp, ParamInfo.Tag.NON_ORD);
		enterpriseParam.addChangeParam("CommonCustomerId", oldCustomerEntity.getCommonCustId(),
				newCustomerEntity.getCommonCustId(), supp);
		enterpriseParam.addChangeParam("CommonCustomerName", oldCustomerEntity.getCommonCustName(),
				newCustomerEntity.getCommonCustName(), supp);
		enterpriseParam.addChangeParam("BillContactPriPhone", oldCustomerEntity.getBillContactPriPhone(),
				newCustomerEntity.getBillContactPriPhone(), supp);
		enterpriseParam.addChangeParam("BillContactAltPhone", oldCustomerEntity.getBillContactAltPhone(),
				newCustomerEntity.getBillContactAltPhone(), supp);
		enterpriseParam.addChangeParam("BillContactCell", oldCustomerEntity.getBillContactCell(),
				newCustomerEntity.getBillContactCell(), supp);
		enterpriseParam.addChangeParam("BillContactPager", oldCustomerEntity.getBillContactPager(),
				newCustomerEntity.getBillContactPager(), supp);
		enterpriseParam.addChangeParam("BillContactEmail", oldCustomerEntity.getBillContactEmail(),
				newCustomerEntity.getBillContactEmail(), supp);
		enterpriseParam.addChangeParam("BillContactAddr1", oldCustomerEntity.getBillContactAddr1(),
				newCustomerEntity.getBillContactAddr1(), supp);
		enterpriseParam.addChangeParam("BillContactAddr2", oldCustomerEntity.getBillContactAddr2(),
				newCustomerEntity.getBillContactAddr2(), supp);
		enterpriseParam.addChangeParam("BillContactCity", oldCustomerEntity.getBillContactCity(),
				newCustomerEntity.getBillContactCity(), supp);
		enterpriseParam.addChangeParam("BillContactState", oldCustomerEntity.getBillContactState(),
				newCustomerEntity.getBillContactState(), supp);
		enterpriseParam.addChangeParam("BillContactZip", oldCustomerEntity.getBillContactZip(),
				newCustomerEntity.getBillContactZip(), supp);
		enterpriseParam.addChangeParam("BillContactCountry", oldCustomerEntity.getBillContactCountry(),
				newCustomerEntity.getBillContactCountry(), supp);
		enterpriseParam.addChangeParam("SalesSegment", oldCustomerEntity.getSalesSegment(),
				newCustomerEntity.getSalesSegment(), supp);
		enterpriseParam.addChangeParam("SalesRepId", oldCustomerEntity.getSalesRepId(),
				newCustomerEntity.getSalesRepId(), supp);
		enterpriseParam.addChangeParam("SalesRepName", oldCustomerEntity.getSalesRepName(),
				newCustomerEntity.getSalesRepName(), supp);
		enterpriseParam.addChangeParam("SalesRepPhone", oldCustomerEntity.getSalesRepPhone(),
				newCustomerEntity.getSalesRepPhone(), supp);
		enterpriseParam.addChangeParam("SalesRepEmail", oldCustomerEntity.getSalesRepEmail(),
				newCustomerEntity.getSalesRepEmail(), supp);
		enterpriseParam.addChangeParam("CustCorpId", oldCustomerEntity.getCustCorpId(),
				newCustomerEntity.getCustCorpId(), supp);
		enterpriseParam.addChangeParam("OrderVerification", oldCustomerEntity.getOrderVerification(),
				newCustomerEntity.getOrderVerification(), supp);
		enterpriseParam.addChangeParam("SupportName", oldCustomerEntity.getSupportName(),
				newCustomerEntity.getSupportName(), supp);
		enterpriseParam.addChangeParam("SupportPhone", oldCustomerEntity.getSupportPhone(),
				newCustomerEntity.getSupportPhone(), supp);
		enterpriseParam.addChangeParam("EmeaServiceSupport", oldCustomerEntity.getEmeaServiceSupport(),
				newCustomerEntity.getEmeaServiceSupport(), supp);
		enterpriseParam.addChangeParam("CustSensitivityLevel", oldCustomerEntity.getCustSensitivityLevel(),
				newCustomerEntity.getCustSensitivityLevel(), supp);
		enterpriseParam.addChangeParam("CustGarmStatus", oldCustomerEntity.getCustGarmStatus(),
				newCustomerEntity.getCustGarmStatus(), supp);
		enterpriseParam.addChangeParam("CustActiveInd", oldCustomerEntity.getCustActiveInd(),
				newCustomerEntity.getCustActiveInd(), supp);
		enterpriseParam.addChangeParam("BsBlockInd", oldCustomerEntity.getBsBlockInd(),
				newCustomerEntity.getBsBlockInd(), supp);
		enterpriseParam.addChangeParam("MicroNode", oldCustomerEntity.getMicroNode(), newCustomerEntity.getMicroNode(),
				supp);
		enterpriseParam.addChangeParam("MarketType", oldCustomerEntity.getMarketType(),
				newCustomerEntity.getMarketType(), supp);
		enterpriseParam.addChangeParam("NaspId", oldCustomerEntity.getNaspId(), newCustomerEntity.getNaspId(), supp);

		enterpriseParam.addChangeParam("Address", oldCustomerEntity.getVirtualAddrLine(),
				newCustomerEntity.getVirtualAddrLine(), supp);
		enterpriseParam.addChangeParam("City", oldCustomerEntity.getVirtualAddrCity(),
				newCustomerEntity.getVirtualAddrCity(), supp);
		enterpriseParam.addChangeParam("State", oldCustomerEntity.getVirtualAddrState(),
				newCustomerEntity.getVirtualAddrState(), supp);
		enterpriseParam.addChangeParam("Zip", oldCustomerEntity.getVirtualAddrZip(),
				newCustomerEntity.getVirtualAddrZip(), supp);
		enterpriseParam.addChangeParam("Country", oldCustomerEntity.getVirtualAddrCountry(),
				newCustomerEntity.getVirtualAddrCountry(), supp);

		LOG.info("oldCustomerEntity.getGchId() = {}", oldCustomerEntity.getGchId());
		
		enterpriseParam.addChangeParam("GCHId", oldCustomerEntity.getGchId(), newCustomerEntity.getGchId(), supp);
		enterpriseParam.addChangeParam("LorId", oldCustomerEntity.getLorId(), newCustomerEntity.getLorId(), supp);
		enterpriseParam.addChangeParam("SOEnabled", oldCustomerEntity.getSoEnabled(), newCustomerEntity.getSoEnabled(),
				supp);
		enterpriseParam.addChangeParam("USLDAndLocalBestPool", oldCustomerEntity.getUsLDAndLocalBestPool(),
				newCustomerEntity.getUsLDAndLocalBestPool(), supp);
		enterpriseParam.addChangeParam("USLDOnlyBestPool", oldCustomerEntity.getUsLDOnlyBestPool(),
				newCustomerEntity.getUsLDOnlyBestPool(), supp);
		enterpriseParam.addChangeParam("USLDAndLocalBestPlusPoolId", oldCustomerEntity.getUsLDAndLocalBestPlusPoolId(),
				newCustomerEntity.getUsLDAndLocalBestPlusPoolId(), supp);
		enterpriseParam.addChangeParam("USLDAndLocalBestPlusPool", oldCustomerEntity.getUsLDAndLocalBestPlusPool(),
				newCustomerEntity.getUsLDAndLocalBestPlusPool(), supp);
		enterpriseParam.addChangeParam("USLDOnlyBestPlusPoolId", oldCustomerEntity.getUsLDOnlyBestPlusPoolId(),
				newCustomerEntity.getUsLDOnlyBestPlusPoolId(), supp);
		enterpriseParam.addChangeParam("USLDOnlyBestPlusPool", oldCustomerEntity.getUsLDOnlyBestPlusPool(),
				newCustomerEntity.getUsLDOnlyBestPlusPool(), supp);
		enterpriseParam.addChangeParam("EmeaApacBestPool", oldCustomerEntity.getEmeaApacBestPool(),
				newCustomerEntity.getEmeaApacBestPool(), supp);
		enterpriseParam.addChangeParam("EmeaApacBestPlusPoolId", oldCustomerEntity.getEmeaApacBestPlusPoolId(),
				newCustomerEntity.getEmeaApacBestPlusPoolId(), supp);
		enterpriseParam.addChangeParam("EmeaApacBestPlusPool", oldCustomerEntity.getEmeaApacBestPlusPool(),
				newCustomerEntity.getEmeaApacBestPlusPool(), supp);
		enterpriseParam.addChangeParam("USLDAndLocalBestPlusCclPoolId",
				oldCustomerEntity.getUsLDAndLocalBestPlusCclPoolId(),
				newCustomerEntity.getUsLDAndLocalBestPlusCclPoolId(), supp);
		enterpriseParam.addChangeParam("USLDOnlyBestPlusCclPoolId", oldCustomerEntity.getUsLDOnlyBestPlusCclPoolId(),
				newCustomerEntity.getUsLDOnlyBestPlusCclPoolId(), supp);
		enterpriseParam.addChangeParam("EmeaApacBestPlusCclPoolId", oldCustomerEntity.getEmeaApacBestPlusCclPoolId(),
				newCustomerEntity.getEmeaApacBestPlusCclPoolId(), supp);
		enterpriseParam.addChangeParam("ParentEnterpriseId", oldCustomerEntity.getParentEnterpriseId(),
				newCustomerEntity.getParentEnterpriseId(), supp);

		enterpriseParam.addChangeParam("BWEnterpriseId", oldCustomerEntity.getBwEnterpriseId(),
				newCustomerEntity.getBwEnterpriseId(), supp);
		enterpriseParam.addChangeParam("VoiceVPN", oldCustomerEntity.getVoiceVpn(), newCustomerEntity.getVoiceVpn(),
				supp);
		enterpriseParam.addChangeParam("EnableEnterpriseExtensionDialing",
				oldCustomerEntity.getEnableEnterpriseExtensionDialing(),
				newCustomerEntity.getEnableEnterpriseExtensionDialing(), supp);

		enterpriseParam.addChangeParam("EntepriseCountryCode", oldCustomerEntity.getEntCountryCode(),
				newCustomerEntity.getEntCountryCode(), supp);
		enterpriseParam.addChangeParam("DesignId", oldCustomerEntity.getDesignId(), newCustomerEntity.getDesignId(),
				supp);
		enterpriseParam.addChangeParam("EnterpriseTrunkingType", oldCustomerEntity.getEnterpriseTrunkingType(),
				newCustomerEntity.getEnterpriseTrunkingType(), supp);
		enterpriseParam.addChangeParam("CatalogueReferenceTime", oldCustomerEntity.getCatalogVersionTime(),
				newCustomerEntity.getCatalogVersionTime(), supp);
		

		if (newCustomerEntity.getAuthServices() != null) {
			enterpriseParam.addChildParam(new ParamInfo("AUTHORIZE", "YES", null));
			for (Map.Entry<String, Boolean> entry : newCustomerEntity.getAuthServices().entrySet()) {
				ParamInfo authParam = new ParamInfo("AuthService", null, action);
				authParam.addChildParam(new ParamInfo("Name", entry.getKey(), action));
				if (entry.getValue() != null)
					authParam.addChildParam(new ParamInfo("Authorised", entry.getValue() ? "Y" : "N", action));
				enterpriseParam.addChildParam(authParam, ParamInfo.Tag.NON_ORD);
			}
		}
		if (oldCustomerEntity.getAuthService() != null) {
			for (AuthService authServiceList :oldCustomerEntity.getAuthService()) {
				ParamInfo custAuthFeat = new ParamInfo("AuthService", null, action);
				custAuthFeat.addChildParam(new ParamInfo("Name", authServiceList.getName(), action));		
				custAuthFeat.addChildParam(new ParamInfo("FeatureQuantity", authServiceList.getFeatureQuantity(), action));		
				custAuthFeat.addChildParam(new ParamInfo("Authorised", OrderUtility.booleanToStr(authServiceList.getAuthorise()) , action));
				enterpriseParam.addChildParam(custAuthFeat);
			}
		}
		
		if (oldCustomerEntity.getDigitStrings() != null) {
			for (DigitString ds : oldCustomerEntity.getDigitStrings())
				enterpriseParam.addChildParam(ds.getParamInfo(action));
		}

		enterpriseParam.addChildParam(OrderUtility.getAttribParamInfo(oldCustomerEntity.getAttribMap(), action));
		enterpriseParam.addChildParam(OrderUtility.getCollectionParamInfo(oldCustomerEntity.getSipDomains(), action,
				"SipDomains", "SipDomain"));

		enterpriseParam.addChangeParam("BSAS_STATE", "INITIAL", "INITIAL", supp);
		if (oldCustomerEntity.getHotCutIndicator() != null && oldCustomerEntity.getHotCutIndicator() == Boolean.TRUE)
			enterpriseParam.addChangeParam("HotCutIndicator", "Y", newCustomerEntity.getHotCutIndicator(), supp);
		if (oldCustomerEntity.getCDDDIndicator() != null && oldCustomerEntity.getCDDDIndicator() == Boolean.TRUE)
			enterpriseParam.addChangeParam("CDDDIndicator", "Y", newCustomerEntity.getCDDDIndicator(), supp);

		if (oldCustomerEntity.getGcmInfo() != null) {
			enterpriseParam.addChildParam(oldCustomerEntity.getGcmInfo().getParamInfo(action));
		}

		if (oldCustomerEntity.getTsoMigrationEntReferenceData() != null) {
			enterpriseParam.addChildParam(oldCustomerEntity.getTsoMigrationEntReferenceData().getParamInfo());
		}
		
		enterpriseParam.addChangeParam("CummulativeCcl", oldCustomerEntity.getCummulativeCcl(),
				newCustomerEntity.getCummulativeCcl(), supp);
		
		if(newCustomerEntity.getAuthServices() != null) {
			enterpriseParam.addNotNullValChild("ENT_AUTH_BS_CHANGE", "Y", "n");
			//enterpriseParam.addNotNullValChild("ENT_BS_CHANGE", "Y", "n");
		}else {
			enterpriseParam.addNotNullValChild("ENT_AUTH_BS_CHANGE", "N", "n");
			//enterpriseParam.addNotNullValChild("ENT_BS_CHANGE", "Y", "n");
		}

		return enterpriseParam;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.vz.esap.translation.order.transformer.
	 * EnterpriseTblOrderDetailsDataTransformer#
	 * prepareTblOrderDetailsHeaderParamData(com.vz.esap.translation.order.model.
	 * Order, com.vz.esap.translation.entity.CustomerEntity, boolean)
	 */
	@Override
	public ParamInfo prepareTblOrderDetailsHeaderParamData(Order order, CustomerEntity oldCustomer, boolean supp)
			throws ParseException, TranslatorException {

		LOG.info("Entered - prepareTblOrderDetailsHeaderParamData");
		ParamInfo root = null;
		String action = null;

		try {

			action = order.getOrderHeader().getOrderType();

			root = new ParamInfo("Header", null, action);
			root.addChangeParam("OrderNumber", order.getOrderHeader().getOrderNumber(),
					order.getOrderHeader().getOrderNumber(), supp);
			root.addChangeParam("EnvOrderId", order.getOrderHeader().getEnvOrderId(), order.getOrderHeader().getEnvOrderId(),
					supp);
			root.addChangeParam("MasterOrderNumber", order.getOrderHeader().getMasterOrderNumber(),
					order.getOrderHeader().getMasterOrderNumber(), supp);
			root.addChangeParam("OrderVersion", order.getOrderHeader().getOrderVersion(), order.getOrderHeader().getOrderVersion(), supp);
			root.addChangeParam("TransactionId", order.getOrderHeader().getTransactionId(),
					order.getOrderHeader().getTransactionId(), supp);

			if (order.getCustomerEntity() != null) {
				root.addChangeParam(REGION, order.getOrderHeader().getRegion(), order.getOrderHeader().getRegion(),
						supp);
			}

			else if (order.getEnterpriseTrunks() != null) {
				root.addChangeParam(REGION, order.getEnterpriseTrunks().get(0).getRegion(),
						order.getEnterpriseTrunks().get(0).getRegion(), supp);
			}

			root.addChangeParam("MinorOrderType", order.getOrderHeader().getMinorOrderType(),
					order.getOrderHeader().getMinorOrderType(), supp);
			root.addChangeParam("CentrexType", order.getOrderHeader().getCentrexType(),
					order.getOrderHeader().getCentrexType(), supp);
			root.addChangeParam("ServiceType", order.getOrderHeader().getServiceType(),
					order.getOrderHeader().getServiceType(), supp);
			root.addChangeParam("OriginatingSystem", order.getOrderHeader().getOriginatingSystem(),
					order.getOrderHeader().getOriginatingSystem(), supp);
			root.addChangeParam("InterfaceSystem", order.getOrderHeader().getInterfaceSystem(),
					order.getOrderHeader().getInterfaceSystem(), supp);
			root.addChangeParam("OrderType",
					EsapEnum.OrderType.getValue(order.getOrderHeader().getOrderType().charAt(0)),
					EsapEnum.OrderType.getValue(order.getOrderHeader().getOrderType().charAt(0)), supp);
			root.addChangeParam("SuppType", order.getOrderHeader().getSuppType(), order.getOrderHeader().getSuppType(), supp);
			root.addChangeParam("OrderClassify", order.getOrderHeader().getFunctionCode(),
					order.getOrderHeader().getFunctionCode(), supp);

			if (order.getOrderHeader().getDueDate() != null) {
				SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
				Calendar calendar = GregorianCalendar.getInstance();
				calendar.setTime(format.parse(order.getOrderHeader().getDueDate().toString()));
				Object dueDate = calendar.getTime();
				root.addNotNullValChild("DueDate", dueDate, action);
			}
			if (order.getCustomer().getCustomerId() != null)
				root.addChangeParam(CUSTOMER_ID, order.getCustomer().getCustomerId(),
						order.getCustomer().getCustomerId(), true);
			else if (order.getOrderHeader().getCustomerId() != null)
				root.addChangeParam(CUSTOMER_ID, order.getOrderHeader().getCustomerId(),
						order.getOrderHeader().getCustomerId(), true);

		
			root.addChangeParam(LOCATION_ID, order.getOrderHeader().getLocationId(),
					order.getOrderHeader().getLocationId(), true);
			// root.addNotNullValChild(BS_APP_SERVER, order.getLocation().getBsAppServer(),
			// action); Fix This
			root.addChangeParam("OrderProTIN", order.getOrderHeader().getOrderProTIN(),
					order.getOrderHeader().getOrderProTIN(), supp);
			root.addChangeParam("IOrderTIN", order.getOrderHeader().getiOrderTIN(),
					order.getOrderHeader().getiOrderTIN(), supp);
			root.addChangeParam("TINVersion", order.getOrderHeader().getTinVersion(),
					order.getOrderHeader().getTinVersion(), supp);
			root.addChangeParam("TransitionFlag", order.getOrderHeader().isTransitionFlag() ? "Y" : "N",
					order.getOrderHeader().isTransitionFlag() ? "Y" : "N", supp);
			root.addChangeParam("Priority", order.getOrderHeader().getPriority(), order.getOrderHeader().getPriority(),
					supp);
			if (order.getOrderHeader().getAttribMap() != null) {
				root.addChildParam(OrderUtility.getAttribParamInfo(order.getOrderHeader().getAttribMap(), action));
			}

			if (order.getOrderHeader().getOrderCreatedBy() != null)
				root.addChangeParam("OrderCreatedBy", order.getOrderHeader().getOrderCreatedBy(),
						order.getOrderHeader().getOrderCreatedBy(), supp);
			if (order.getOrderHeader().isHasBulkOrder()) {
				root.addChangeParam("BULK", "Y", "Y", supp);
			}
			if (order.getOrderHeader().getHotCutIndicator() != null) {
				root.addChangeParam(HOT_CUT_IND, "Y", "Y", supp);
			}
			if (order.getOrderHeader().getCDDDIndicator() != null) {
				root.addChangeParam(CDD_IND, "Y", "Y", supp);
			}
			if (order.getOrderHeader().getSolutionType() != null) {
				root.addChangeParam("SolutionType", order.getOrderHeader().getSolutionType().toString(),
						order.getOrderHeader().getSolutionType().toString(), supp);
			}
			if (order.getOrderHeader().getAuthFeatureType() != null) {
				root.addChangeParam("AuthFeatureType", order.getOrderHeader().getAuthFeatureType(),
						order.getOrderHeader().getAuthFeatureType(), supp);
			}
			if (order.getOrderHeader().getGchId() != null) {
				LOG.info("order.getOrderHeader().getGchId(): {}", order.getOrderHeader().getGchId());
				root.addChangeParam("GCHId", order.getOrderHeader().getGchId(), order.getOrderHeader().getGchId(),
						supp);
			}
		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new TranslatorException(ErrorCode.TRANSFORMER_FAILURE,
					"Exception occured in prepareTblOrderDetailsEntityParamDataForCustomer");
		}

		LOG.info("Exit prepareTblOrderDetailsHeaderParamData");

		return root;
	}

	/**@author Abhiram Varma
	 * @param changedcustomerEntity,change
	 * @return ParamInfo
	 * @throws TranslatorException
	 */
	@Override
	public ParamInfo prepareTblOrderDetailsEntityParamDataForLocation(CustomerEntity customer,
			CustomerEntity changedcustomerEntity, boolean change, Object object) throws TranslatorException {

		LOG.info("Entered - prepareTblOrderDetailsEntityParamDataForCustomer");
		ParamInfo root = null;
		// String action = null;
		List<Feature> entFeats = null;
		try {
			
			if(changedcustomerEntity == null)
				changedcustomerEntity=new CustomerEntity();
			// action = voipOrderRequest.getOrderHeader().getOrderType();
//			root = new ParamInfo("Enterprise", null, booleanToStr(change));
			root = new ParamInfo("Enterprise", null, null);

			// root.addNotNullValChild("EnterpriseId", customer.getCustomerId(),
			// action);
			root.addChangeParam("CustomerId", customer.getCustomerId(), changedcustomerEntity.getCustomerId(), change,
					ParamInfo.Tag.ID);
			root.addChangeParam("CustomerName", customer.getCustomerName(), changedcustomerEntity.getCustomerName(),
					change, ParamInfo.Tag.NAME);
			root.addChangeParam("LOR", (customer.getLOR() != null ? customer.getLOR() : "N"),
					(changedcustomerEntity.getLOR() != null ? changedcustomerEntity.getLOR() : "N"), change);
			root.addChangeParam("SbcLoadSharingEnabled",
					(customer.getSbcLoadSharing() != null ? customer.getSbcLoadSharing() : "N"),
					(changedcustomerEntity.getSbcLoadSharing() != null ? changedcustomerEntity.getSbcLoadSharing()
							: "N"),
					change);
			root.addChangeParam("DefaultSubnet",
					(customer.getDefaultSubnet() != null ? customer.getDefaultSubnet() : "N"),
					(changedcustomerEntity.getDefaultSubnet() != null ? changedcustomerEntity.getDefaultSubnet() : "N"),
					change);
			root.addChangeParam("RIVCustomer", customer.getRivCustomer(), changedcustomerEntity.getRivCustomer(),
					change);
			root.addChangeParam("OrderPlatform", customer.getOrderPlatform(), changedcustomerEntity.getOrderPlatform(),
					change);
			root.addChangeParam("ProductType", customer.getProductType(), changedcustomerEntity.getProductType(),
					change);
			root.addChangeParam("ContactFirstName", customer.getContactFirstName(),
					changedcustomerEntity.getContactFirstName(), change);
			root.addChangeParam("ContactLastName", customer.getContactLastName(),
					changedcustomerEntity.getContactLastName(), change);
			root.addChangeParam("ContactTitle", customer.getContactTitle(), changedcustomerEntity.getContactTitle(),
					change);
			root.addChangeParam("ContactAddress1", customer.getContactAddress1(),
					changedcustomerEntity.getContactAddress1(), change);
			root.addChangeParam("ContactAddress2", customer.getContactAddress2(),
					changedcustomerEntity.getContactAddress2(), change);
			root.addChangeParam("ContactCity", customer.getContactCity(), changedcustomerEntity.getContactCity(),
					change);
			root.addChangeParam("ContactState", customer.getContactState(), changedcustomerEntity.getContactState(),
					change);
			root.addChangeParam("ContactZip", customer.getContactZip(), changedcustomerEntity.getContactZip(), change);
			root.addChangeParam("ContactCountry", customer.getContactCountry(),
					changedcustomerEntity.getContactCountry(), change);
			root.addChangeParam("ContactPhone1", customer.getContactPhone1(), changedcustomerEntity.getContactPhone1(),
					change);
			root.addChangeParam("ContactPhone2", customer.getContactPhone2(), changedcustomerEntity.getContactPhone2(),
					change);
			root.addChangeParam("ContactFax", customer.getContactFax(), changedcustomerEntity.getContactFax(), change);
			root.addChangeParam("ContactMobile", customer.getContactMobile(), changedcustomerEntity.getContactMobile(),
					change);
			root.addChangeParam("ContactPager", customer.getContactPager(), changedcustomerEntity.getContactPager(),
					change);
			root.addChangeParam("ContactEmail", customer.getContactEmail(), changedcustomerEntity.getContactEmail(),
					change);
			// root.addNotNullValChild("RegionType", customer.getRegionTypeStr(customer),
			// action); // code not set in bau
			// root.addNotNullValChild("RegionType",
			// voipOrderRequest.getOrderHeader().getRegion(), action);
			// if (voipOrderRequest.getLocation() != null &&
			// voipOrderRequest.getLocation().getLocationAddress() != null
			// && voipOrderRequest.getLocation().getLocationAddress().getCountryCode() !=
			// null)
			// root.addNotNullValChild("Region",
			// voipOrderRequest.getLocation().getLocationAddress().getCountryCode(),
			// action);
			root.addChangeParam("AccountTeamName", customer.getAccountTeamName(),
					changedcustomerEntity.getAccountTeamName(), change);
			root.addChangeParam("AccountTeamPhone", customer.getAccountTeamPhone(),
					changedcustomerEntity.getAccountTeamPhone(), change);
			root.addChangeParam("AccountTeamEmail", customer.getAccountTeamEmail(),
					changedcustomerEntity.getAccountTeamEmail(), change);
			root.addChangeParam("NonTrustedIPCalls", customer.getNonTrustedIPCalls(),
					changedcustomerEntity.getNonTrustedIPCalls(), change);
			root.addChangeParam("AllowOnNet", customer.getAllowOnNet(), changedcustomerEntity.getAllowOnNet(), change);
			root.addChangeParam("SipDomain", customer.getSipDomain(), changedcustomerEntity.getSipDomain(), change);
			root.addChangeParam("OrderComment", customer.getOrderComment(), changedcustomerEntity.getOrderComment(),
					change);
			root.addChangeParam("XrefCustomerId", customer.getXrefCustomerId(),
					changedcustomerEntity.getXrefCustomerId(), change);
			root.addChangeParam("BillingSystem", customer.getBillingSystemStr(),
					changedcustomerEntity.getBillingSystemStr(), change);
			root.addChangeParam("VnetCorpId", customer.getVnetCorpId(), changedcustomerEntity.getVnetCorpId(), change);
			root.addChangeParam("CentrexType", customer.getCentrexTypeStr(), changedcustomerEntity.getCentrexTypeStr(),
					change);
			root.addChangeParam("AgencyHierCode", customer.getAgencyHierCode(),
					changedcustomerEntity.getAgencyHierCode(), change);
			root.addChangeParam("ContractInd", customer.getContractInd(), changedcustomerEntity.getContractInd(),
					change);
			root.addChangeParam("CalnetSubContractInd", customer.getCalnetSubContractInd(),
					changedcustomerEntity.getCalnetSubContractInd(), change);
			if ((customer.getContractInd() != null && !customer.getContractInd().equalsIgnoreCase("S"))
					|| (customer.getContractInd() == null)) {
				root.addChangeParam("AdminFirstName", customer.getAdminFirstName(),
						changedcustomerEntity.getAdminFirstName(), change);
				root.addChangeParam(ADMIN_LASTNAME, customer.getAdminLastName(),
						changedcustomerEntity.getAdminLastName(), change);
				root.addChangeParam("AdminEmail", customer.getAdminEmail(), changedcustomerEntity.getAdminEmail(),
						change);
				root.addChangeParam("AdminWebLoginId", customer.getAdminWebLoginId(),
						changedcustomerEntity.getAdminWebLoginId(), change);
				root.addChangeParam("AdminPassword", customer.getAdminPassword(),
						changedcustomerEntity.getAdminPassword(), change);
			}
			root.addChangeParam("EnterpriseCclIndicator", customer.getEnterpriseCclIndicatorStr(),
					changedcustomerEntity.getEnterpriseCclIndicatorStr(), change);
			root.addChangeParam("NewIPCCCustOnChange", customer.getIpccCustOnChgStr(),
					changedcustomerEntity.getIpccCustOnChgStr(), change);
			root.addChangeParam("TntCclInd", customer.getTntCclIndStr(), changedcustomerEntity.getTntCclIndStr(),
					change);
			root.addChangeParam("BsAppServer", customer.getBsAppServer(), changedcustomerEntity.getBsAppServer(),
					change);
			root.addChangeParam("QosIndicator", customer.getQosIndicator(), changedcustomerEntity.getQosIndicator(),
					change);
			root.addChangeParam("SlaType", customer.getSlaType(), changedcustomerEntity.getSlaType(), change);
			root.addChangeParam("CallingPlanId", customer.getCallingPlanId(), changedcustomerEntity.getCallingPlanId(),
					change);
			root.addChangeParam("IEANLength", customer.getIeanLength(), changedcustomerEntity.getIeanLength(), change);
			root.addChangeParam("VmPartitionId", customer.getVmPartitionId(), changedcustomerEntity.getVmPartitionId(),
					change, ParamInfo.Tag.NON_ORD);
			root.addChangeParam("CommonCustomerId", customer.getCommonCustId(), changedcustomerEntity.getCommonCustId(),
					change);
			root.addChangeParam("CommonCustomerName", customer.getCommonCustName(),
					changedcustomerEntity.getCommonCustName(), change);
			root.addChangeParam("BillContactPriPhone", customer.getBillContactPriPhone(),
					changedcustomerEntity.getBillContactPriPhone(), change);
			root.addChangeParam("BillContactAltPhone", customer.getBillContactAltPhone(),
					changedcustomerEntity.getBillContactAltPhone(), change);
			root.addChangeParam("BillContactCell", customer.getBillContactCell(),
					changedcustomerEntity.getBillContactCell(), change);
			root.addChangeParam("BillContactPager", customer.getBillContactPager(),
					changedcustomerEntity.getBillContactPager(), change);
			root.addChangeParam("BillContactEmail", customer.getBillContactEmail(),
					changedcustomerEntity.getBillContactEmail(), change);
			root.addChangeParam("BillContactAddr1", customer.getBillContactAddr1(),
					changedcustomerEntity.getBillContactAddr1(), change);
			root.addChangeParam("BillContactAddr2", customer.getBillContactAddr2(),
					changedcustomerEntity.getBillContactAddr2(), change);
			root.addChangeParam("BillContactCity", customer.getBillContactCity(),
					changedcustomerEntity.getBillContactCity(), change);
			root.addChangeParam("BillContactState", customer.getBillContactState(),
					changedcustomerEntity.getBillContactState(), change);
			root.addChangeParam("BillContactZip", customer.getBillContactZip(),
					changedcustomerEntity.getBillContactZip(), change);
			root.addChangeParam("BillContactCountry", customer.getBillContactCountry(),
					changedcustomerEntity.getBillContactCountry(), change);
			root.addChangeParam("SalesSegment", customer.getSalesSegment(), changedcustomerEntity.getSalesSegment(),
					change);
			root.addChangeParam("SalesRepId", customer.getSalesRepId(), changedcustomerEntity.getSalesRepId(), change);
			root.addChangeParam("SalesRepName", customer.getSalesRepName(), changedcustomerEntity.getSalesRepName(),
					change);
			root.addChangeParam("SalesRepPhone", customer.getSalesRepPhone(), changedcustomerEntity.getSalesRepPhone(),
					change);
			root.addChangeParam("SalesRepEmail", customer.getSalesRepEmail(), changedcustomerEntity.getSalesRepEmail(),
					change);
			root.addChangeParam("CustCorpId", customer.getCustCorpId(), changedcustomerEntity.getCustCorpId(), change);
			root.addChangeParam("OrderVerification", customer.getOrderVerification(),
					changedcustomerEntity.getOrderVerification(), change);
			root.addChangeParam("SupportName", customer.getSupportName(), changedcustomerEntity.getSupportName(),
					change);
			root.addChangeParam("SupportPhone", customer.getSupportPhone(), changedcustomerEntity.getSupportPhone(),
					change);
			root.addChangeParam("EmeaServiceSupport", customer.getEmeaServiceSupport(),
					changedcustomerEntity.getEmeaServiceSupport(), change);
			root.addChangeParam("CustSensitivityLevel", customer.getCustSensitivityLevel(),
					changedcustomerEntity.getCustSensitivityLevel(), change);
			root.addChangeParam("CustGarmStatus", customer.getCustGarmStatus(),
					changedcustomerEntity.getCustGarmStatus(), change);
			root.addChangeParam("CustActiveInd", customer.getCustActiveInd(), changedcustomerEntity.getCustActiveInd(),
					change);
			root.addChangeParam("BsBlockInd", customer.getBsBlockInd(), changedcustomerEntity.getBsBlockInd(), change);
			root.addChangeParam("MicroNode", customer.getMicroNode(), changedcustomerEntity.getMicroNode(), change);
			root.addChangeParam("MarketType", customer.getMarketType(), changedcustomerEntity.getMarketType(), change);
			root.addChangeParam("NaspId", customer.getNaspId(), changedcustomerEntity.getNaspId(), change);

			root.addChangeParam("Address", customer.getVirtualAddrLine(), changedcustomerEntity.getVirtualAddrLine(),
					change);

			// root.addNotNullValChild("City",
			// voipOrderRequest.getLocation().getLocationAddress().getCity(), action);
			// root.addNotNullValChild("State",
			// voipOrderRequest.getLocation().getLocationAddress().getState(), action);
			// root.addNotNullValChild("Zip",
			// voipOrderRequest.getLocation().getLocationAddress().getZip(), action);
			// root.addNotNullValChild("Country",
			// voipOrderRequest.getLocation().getLocationAddress().getCountryCode(),
			// action);
			LOG.info("customer.getGchId()= {}", customer.getGchId());
			root.addChangeParam("GCHId", customer.getGchId(), changedcustomerEntity.getGchId(), change);
			root.addChangeParam("LorId", customer.getLorId(), changedcustomerEntity.getLorId(), change);
			root.addChangeParam("SOEnabled", customer.getSoEnabled(), changedcustomerEntity.getSoEnabled(), change);
			root.addChangeParam("USLDAndLocalBestPool", customer.getUsLDAndLocalBestPool(),
					changedcustomerEntity.getUsLDAndLocalBestPool(), change);
			root.addChangeParam("USLDOnlyBestPool", customer.getUsLDOnlyBestPool(),
					changedcustomerEntity.getUsLDOnlyBestPool(), change);
			root.addChangeParam("USLDAndLocalBestPlusPoolId", customer.getUsLDAndLocalBestPlusPoolId(),
					changedcustomerEntity.getUsLDAndLocalBestPlusPoolId(), change);
			root.addChangeParam("USLDAndLocalBestPlusPool", customer.getUsLDAndLocalBestPlusPool(),
					changedcustomerEntity.getUsLDAndLocalBestPlusPool(), change);
			root.addChangeParam("USLDOnlyBestPlusPoolId", customer.getUsLDOnlyBestPlusPoolId(),
					changedcustomerEntity.getUsLDOnlyBestPlusPoolId(), change);
			root.addChangeParam("USLDOnlyBestPlusPool", customer.getUsLDOnlyBestPlusPool(),
					changedcustomerEntity.getUsLDOnlyBestPlusPool(), change);
			root.addChangeParam("EmeaApacBestPool", customer.getEmeaApacBestPool(),
					changedcustomerEntity.getEmeaApacBestPool(), change);
			root.addChangeParam("EmeaApacBestPlusPoolId", customer.getEmeaApacBestPlusPoolId(),
					changedcustomerEntity.getEmeaApacBestPlusPoolId(), change);
			root.addChangeParam("EmeaApacBestPlusPool", customer.getEmeaApacBestPlusPool(),
					changedcustomerEntity.getEmeaApacBestPlusPool(), change);
			root.addChangeParam("USLDAndLocalBestPlusCclPoolId", customer.getUsLDAndLocalBestPlusCclPoolId(),
					changedcustomerEntity.getUsLDAndLocalBestPlusCclPoolId(), change);
			root.addChangeParam("USLDAndLocalBestPlusCclPool", customer.getUsLDAndLocalBestPlusCclPool(),
					changedcustomerEntity.getUsLDAndLocalBestPlusCclPool(), change);
			root.addChangeParam("USLDOnlyBestPlusCclPoolId", customer.getUsLDOnlyBestPlusCclPoolId(),
					changedcustomerEntity.getUsLDOnlyBestPlusCclPoolId(), change);
			root.addChangeParam("USLDOnlyBestPlusCclPool", customer.getUsLDOnlyBestPlusCclPool(),
					changedcustomerEntity.getUsLDOnlyBestPlusCclPool(), change);
			root.addChangeParam("EmeaApacBestPlusCclPoolId", customer.getEmeaApacBestPlusCclPoolId(),
					changedcustomerEntity.getEmeaApacBestPlusCclPoolId(), change);
			root.addChangeParam("EmeaApacBestPlusCclPool", customer.getEmeaApacBestPlusCclPool(),
					changedcustomerEntity.getEmeaApacBestPlusCclPool(), change);
			root.addChangeParam("EntepriseCountryCode", customer.getEntCountryCode(),
					changedcustomerEntity.getEntCountryCode(), change);
			root.addChangeParam("DesignId", customer.getDesignId(), changedcustomerEntity.getDesignId(), change);
			root.addChangeParam("EnterpriseTrunkingType", customer.getEnterpriseTrunkingType(),
					changedcustomerEntity.getEnterpriseTrunkingType(), change);
			root.addChangeParam("CatalogueReferenceTime", customer.getCatalogVersionTime(),
					changedcustomerEntity.getCatalogVersionTime(), change);
			if (customer.getAuthFeatureType() != null)
				root.addChangeParam("AuthFeatureType",
						customer.getAuthFeatureType() != null ? customer.getAuthFeatureType().toString() : null,
						changedcustomerEntity.getAuthFeatureType() != null
								? changedcustomerEntity.getAuthFeatureType().toString()
								: null,
						change);
			// XO
			// entFeats = stream(voipOrderRequest.getConvergedService().getFeature())
			// .filter(feat ->
			// feat.getCode().equalsIgnoreCase("EFET_VOIP_ENT_LVL")).collect(Collectors.toList());

			// for (Specification spec : entFeats.get(0).getSpecification()) {
			// if ("BW_ENTERPRISE_ID".equalsIgnoreCase(spec.getCode()))
			// root.addNotNullValChild("BWEnterpriseId", spec.getValue(), action);
			// if ("VOICE_VPN".equalsIgnoreCase(spec.getCode()))
			// root.addNotNullValChild("VoiceVPN", spec.getValue(), action);
			// if ("EnableEnterpriseExtensionDialing".equalsIgnoreCase(spec.getCode()))
			// root.addNotNullValChild("EnableEnterpriseExtensionDialing", spec.getValue(),
			// action);// Anitha Fix
			// this
			// }

			// XO
			if (customer.getAuthServices() != null) {
				root.addChildParam(new ParamInfo("AUTHORIZE", "YES", null));
				for (Map.Entry<String, Boolean> entry : customer.getAuthServices().entrySet()) {
					ParamInfo authParam = new ParamInfo("AuthService", null, booleanToStr(change));
					authParam.addChildParam(new ParamInfo("Name", entry.getKey(), booleanToStr(change)));
					if (entry.getValue() != null)
						authParam.addChildParam(
								new ParamInfo("Authorised", entry.getValue() ? "Y" : "N", booleanToStr(change)));
					root.addChildParam(authParam, ParamInfo.Tag.NON_ORD);
				}
			}

			if (customer.getAuthService() != null) {
				for (AuthService authServiceList :customer.getAuthService()) {
					ParamInfo custAuthFeat = new ParamInfo("AuthService", null, booleanToStr(change));
					custAuthFeat.addChildParam(new ParamInfo("Name", authServiceList.getName(), booleanToStr(change)));		
					custAuthFeat.addChildParam(new ParamInfo("FeatureQuantity", authServiceList.getFeatureQuantity(), booleanToStr(change)));		
					custAuthFeat.addChildParam(new ParamInfo("Authorised", OrderUtility.booleanToStr(authServiceList.getAuthorise()) , booleanToStr(change)));
					root.addChildParam(custAuthFeat);
				}
			}
			
			if (customer.getDigitStrings() != null) {
				for (DigitString ds : customer.getDigitStrings())
					root.addChildParam(ds.getParamInfo(booleanToStr(change)));
			}

			if (customer.getAttribMap() != null) // check this
				root.addChildParam(OrderUtility.getAttribParamInfo(customer.getAttribMap(), booleanToStr(change)));
			if (customer.getSipDomains() != null)// check this
				root.addChildParam(OrderUtility.getCollectionParamInfo(customer.getSipDomains(), booleanToStr(change),
						"SipDomains", "SipDomain"));

			/* New ParamName for the BroadSoft AppServer select from user */
			root.addChangeParam("BSAS_STATE", "INITIAL", "INITIAL", change);
			if (customer.getHotCutIndicator() != null && customer.getHotCutIndicator() == Boolean.TRUE)
				root.addChangeParam("HotCutIndicator", "Y", "Y", change);
			if (customer.getCDDDIndicator() != null && customer.getCDDDIndicator() == Boolean.TRUE)
				root.addChangeParam("CDDDIndicator", "Y", "Y", change);

			if (customer.getGcmInfo() != null) {
				root.addChildParam(customer.getGcmInfo().getParamInfo(booleanToStr(change)));
			}

			if (customer.getTsoMigrationEntReferenceData() != null) {
				root.addChildParam(customer.getTsoMigrationEntReferenceData().getParamInfo());
			}

			root.addChangeParam("CummulativeCcl", customer.getCummulativeCcl(),
					changedcustomerEntity.getCummulativeCcl(), change);
			LOG.info("Exit prepareTblOrderDetailsEntityParamData");
		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new TranslatorException(ErrorCode.TRANSFORMER_FAILURE,
					"Exception occured in prepareTblOrderDetailsEntityParamDataForCustomer");
		}
		return root;
	}

	/**
	 * @param bool
	 * @return boolean
	 */
	public static String booleanToStr(Boolean bool) {
		if (bool == null)
			return null;
		else
			return bool ? "C" : "N";
	}

}
