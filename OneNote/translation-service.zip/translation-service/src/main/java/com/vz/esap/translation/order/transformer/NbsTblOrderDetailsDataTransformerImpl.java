package com.vz.esap.translation.order.transformer;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.vz.esap.translation.dao.model.TblOrder;
import com.vz.esap.translation.entity.NbsEntity;
import com.vz.esap.translation.enums.EsapEnum;
import com.vz.esap.translation.exception.TranslatorException;
import com.vz.esap.translation.exception.TranslatorException.ErrorCode;
import com.vz.esap.translation.order.model.Order;
import com.vz.esap.translation.order.model.request.ParamInfo;
import com.vz.esap.translation.order.model.request.VOIPOrderRequest;
import com.vz.esap.translation.util.OrderUtility;

@Component
public class NbsTblOrderDetailsDataTransformerImpl implements NbsTblOrderDetailsDataTransformer {

	private static final Logger LOG = LoggerFactory.getLogger(NbsTblOrderDetailsDataTransformerImpl.class);

	private static final String LOCATION_ID = "LocationId";
	private static final String CUSTOMER_ID = "CustomerId";
	private static final String REGION = "Region";
	// private static final String BS_APP_SERVER = "BsAppServer";
	private static final String HOT_CUT_IND = "HotCutIndicator";
	private static final String CDD_IND = "CDDDIndicator";

	private static final String SONUSNBS = "SonusNbs";

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.vz.esap.translation.order.transformer.NbsTblOrderDetailsDataTransformer#
	 * prepareTblOrderDetailsEntityParamDataForNbs(com.vz.esap.translation.order.
	 * model.request.VOIPOrderRequest, com.vz.esap.translation.dao.model.TblOrder,
	 * java.util.ArrayList)
	 */
	@Override
	public ArrayList<ParamInfo> prepareTblOrderDetailsEntityParamDataForNbs(VOIPOrderRequest voipOrderRequest,
			TblOrder tblOrderObject, ArrayList<NbsEntity> nbsEntityList, ParamInfo paramRoot) {
		LOG.info("Entered - prepareTblOrderDetailsEntityParamDataForNbs(voipOrderRequest, tblOrderObject, nbsEntityList, paramRoot)");

		if (nbsEntityList == null)
			return null;
		ArrayList<ParamInfo> paramInfoList = new ArrayList<ParamInfo>();
		String action = voipOrderRequest.getOrderHeader().getOrderType();
		ParamInfo root = null;

		for (NbsEntity nbsEntity : nbsEntityList) {

			if (paramRoot == null) {
				root = new ParamInfo("SonusNbs", null, action);
			} else {
				LOG.info(" paramRoot = {}", paramRoot);
				root = paramRoot;
			}

			if ("SonusNbs".equalsIgnoreCase(root.getName())) {
				LOG.info(" Inside paramRoot = {}", root.getName());
				if (nbsEntity.getNbsClusterId() != null)
					root.addChildParam(
							new ParamInfo("NbsClusterId", nbsEntity.getNbsClusterId(), action, ParamInfo.Tag.ID));
				root.addChildParam(new ParamInfo("CustomerId", nbsEntity.getCustomerId(), action));
				root.addChildParam(new ParamInfo("LocationId", nbsEntity.getLocationId(), action));
				root.addChildParam(new ParamInfo("TrunkGroupId", nbsEntity.getTrunkGroupId(), action));
				root.addChildParam(new ParamInfo("State", nbsEntity.getState(), action));
				root.addChildParam(new ParamInfo("City", nbsEntity.getCity(), action));
				root.addChildParam(new ParamInfo("Country", nbsEntity.getCountry(), action));
				root.addChildParam(new ParamInfo("Region", nbsEntity.getCountry(), action));
				if (nbsEntity.getNbsType() != null)
					root.addChildParam(new ParamInfo("NbsType", nbsEntity.getNbsType().toString(), action));
				if (nbsEntity.getCpeIpAddress() != null) {
					root.addChildParam(new ParamInfo("CpeIpAddress", nbsEntity.getCpeIpAddress(), action));
					root.addChildParam(new ParamInfo("IpAddress", nbsEntity.getIpAddress(), action));
					root.addChildParam(new ParamInfo("Address", nbsEntity.getAddress(), action));
				}
				root.addChildParam(new ParamInfo("CpeServerFqdnPort", nbsEntity.getCpeServerFqdnPort(), action));
				root.addChildParam(new ParamInfo("CpeServerFqdn", nbsEntity.getCpeServerFqdn(), action));
				root.addChildParam(new ParamInfo("CpePort", nbsEntity.getCpePort(), action));
				if (nbsEntity.getRedundancy() != null)
					root.addChildParam(new ParamInfo("RedundancyType", nbsEntity.getRedundancy().toString(), action));
				if (nbsEntity.getRedundancyPriorityType() != null)
					root.addChildParam(new ParamInfo("RedundancyPriorityType",
							nbsEntity.getRedundancyPriorityType().toString(), action));
				root.addChildParam(new ParamInfo("PbxIpRedundancy1", nbsEntity.getPbxIpRedundancy1(), action));
				root.addChildParam(new ParamInfo("GroupUserLimit", nbsEntity.getGroupUserLimit(), action));
				root.addChildParam(new ParamInfo("CompressionType", nbsEntity.getCompressionType(), action));
				root.addChildParam(new ParamInfo("AsClli", voipOrderRequest.getOrderHeader().getAsClli(), action));
				root.addChildParam(new ParamInfo("BwCluster", voipOrderRequest.getOrderHeader().getBwCluster(), action));

				
			} else if ("NbsConfig".equalsIgnoreCase(root.getName())) {
				LOG.info(" Inside paramRoot = {}", root.getName());
				root.addChildParam(new ParamInfo("NbsCluster", nbsEntity.getNbsClusterName(), action));
				/*
				 * root.addChildParam(new ParamInfo("BwCluster", "BwCluster", action));
				 * root.addChildParam(new ParamInfo("InternalPort", "InternalPort", action));
				 * root.addChildParam(new ParamInfo("InternalIp", "InternalIp", action));
				 * root.addChildParam(new ParamInfo("ExternalPort", "ExternalPort", action));
				 */
				root.addChildParam(new ParamInfo("ExternalIp", nbsEntity.getIp28(), action));
				root.addChildParam(new ParamInfo("Vlan", nbsEntity.getVlanId(), action));
				/*
				 * root.addChildParam(new ParamInfo("NifSubIntIp1", "NifSubIntIp1", action));
				 * root.addChildParam(new ParamInfo("NifSubIntIp2", "NifSubIntIp2", action));
				 * root.addChildParam(new ParamInfo("NifSubIntIp3", "NifSubIntIp3", action));
				 * root.addChildParam(new ParamInfo("NifSubIntIp4", "NifSubIntIp4", action));
				 * root.addChildParam(new ParamInfo("nifNextHop", "nifNextHop", action));
				 */
				root.addChildParam(new ParamInfo("IPVersion", nbsEntity.getIpVersion(), action));
				/* root.addChildParam(new ParamInfo("VpnId", "VpnId", action)); */
				root.addChildParam(new ParamInfo("VpnName", nbsEntity.getVpnName(), action));
				root.addChildParam(new ParamInfo("Sr1", nbsEntity.getSR1(), action));
				root.addChildParam(new ParamInfo("Sr2", nbsEntity.getSR2(), action));
				root.addChildParam(new ParamInfo("Sr3", nbsEntity.getSR3(), action));
				root.addChildParam(new ParamInfo("Sr4", nbsEntity.getSR4(), action));
				root.addChildParam(new ParamInfo("IPExt28", nbsEntity.getIp28(), action));
				/* root.addChildParam(new ParamInfo("IPInt32", nbsEntity.getIp32(), action)); */
				root.addChildParam(new ParamInfo("NbsCircuitId", nbsEntity.getNbsCircuitId(), action));
			} else if ("CircuitInfo".equalsIgnoreCase(root.getName())) {
				LOG.info(" Inside paramRoot = {}", root.getName());
				root.addChildParam(new ParamInfo("CircuitId", nbsEntity.getNbsCircuitId(), action));
				root.addChildParam(new ParamInfo("VpnName", nbsEntity.getVpnName(), action));
			}

			// To BE Used for IPSM:

			paramInfoList.add(root);
		}
		LOG.info("Exit - prepareTblOrderDetailsEntityParamDataForNbs(voipOrderRequest, tblOrderObject, nbsEntityList, paramRoot)");
		return paramInfoList;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.vz.esap.translation.order.transformer.NbsTblOrderDetailsDataTransformer#
	 * prepareTblOrderDetailsHeaderParamData(com.vz.esap.translation.order.model.
	 * Order)
	 */
	@Override
	public ParamInfo prepareTblOrderDetailsHeaderParamData(Order order) throws ParseException, TranslatorException {

		LOG.info("Entered - prepareTblOrderDetailsHeaderParamData(order)");
		ParamInfo root = null;
		String action = null;
		try {

			action = order.getOrderHeader().getOrderType();
			root = new ParamInfo("Header", null, action);

			root.addNotNullValChild("OrderNumber", order.getOrderHeader().getOrderNumber(), action);
			root.addNotNullValChild("EnvOrderId", order.getOrderHeader().getEnvOrderId(), action);
			root.addNotNullValChild("MasterOrderNumber", order.getOrderHeader().getMasterOrderNumber(), action);
			root.addNotNullValChild("OrderVersion", order.getOrderHeader().getOrderVersion(), action);
			root.addNotNullValChild("TransactionId", order.getOrderHeader().getTransactionId(), action);
			root.addNotNullValChild("Region", order.getOrderHeader().getRegion(), action);
			root.addNotNullValChild("MinorOrderType", order.getOrderHeader().getMinorOrderType(), action);
			root.addNotNullValChild("CentrexType", order.getOrderHeader().getCentrexType(), action);
			root.addNotNullValChild("ServiceType", order.getOrderHeader().getServiceType(), action);
			root.addNotNullValChild("OriginatingSystem", order.getOrderHeader().getOriginatingSystem(), action);
			root.addNotNullValChild("InterfaceSystem", order.getOrderHeader().getInterfaceSystem(), action);
			root.addNotNullValChild("OrderType",
					EsapEnum.OrderType.getValue(order.getOrderHeader().getOrderType().charAt(0)), action);
			root.addNotNullValChild("SuppType", order.getOrderHeader().getSuppType(), action);
			root.addNotNullValChild("OrderClassify", order.getOrderHeader().getFunctionCode(), action);

			if (order.getOrderHeader().getDueDate() != null) {
				SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
				Date date = format.parse(order.getOrderHeader().getDueDate().toString());
				Calendar calendar = GregorianCalendar.getInstance();
				calendar.setTime(date);
				Object dueDate = calendar.getTime();
				root.addNotNullValChild("DueDate", dueDate, action);
			}
			root.addNotNullValChild("CustomerId", order.getOrderHeader().getCustomerId(), action);
			root.addNotNullValChild("LocationId", order.getOrderHeader().getLocationId(), action);
			// root.addNotNullValChild("BsAppServer", order.getCustomer().getBsAppServer(),
			// action); Fix This
			root.addNotNullValChild("OrderProTIN", order.getOrderHeader().getOrderProTIN(), action);
			root.addNotNullValChild("IOrderTIN", order.getOrderHeader().getiOrderTIN(), action);
			root.addNotNullValChild("TINVersion", order.getOrderHeader().getTinVersion(), action);
			root.addNotNullValChild("TransitionFlag", order.getOrderHeader().isTransitionFlag() ? "Y" : "N", action);
			root.addNotNullValChild("Priority", order.getOrderHeader().getPriority(), action);
			if (order.getOrderHeader().getAttribMap() != null) {
				root.addChildParam(OrderUtility.getAttribParamInfo(order.getOrderHeader().getAttribMap(), action));
			}
			if (order.getOrderHeader().getOrderCreatedBy() != null)
				root.addNotNullValChild("OrderCreatedBy", order.getOrderHeader().getOrderCreatedBy(), action);
			if (order.getOrderHeader().isHasBulkOrder()) {
				root.addNotNullValChild("BULK", "Y", action);
			}
			if (order.getOrderHeader().getHotCutIndicator() != null) {
				root.addNotNullValChild("HotCutIndicator", "Y", action);
			}
			if (order.getOrderHeader().getCDDDIndicator() != null) {
				root.addNotNullValChild("CDDDIndicator", "Y", action);
			}

			if (order.getOrderHeader().getSolutionType() != null) {
				root.addNotNullValChild("SolutionType", order.getOrderHeader().getSolutionType().toString(), action);
			}

		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new TranslatorException(ErrorCode.TRANSFORMER_FAILURE,
					"Exception occured in prepareTblOrderDetailsHeaderParamData(order)");
		}

		LOG.info("Exit prepareTblOrderDetailsHeaderParamData(order)");

		return root;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.vz.esap.translation.order.transformer.NbsTblOrderDetailsDataTransformer#
	 * prepareTblOrderDetailsEntityParamDataForNbs(com.vz.esap.translation.order.
	 * model.Order)
	 */
	@Override
	public ParamInfo prepareTblOrderDetailsEntityParamDataForNbs(Order order) throws TranslatorException {
		LOG.info("Entered - prepareTblOrderDetailsEntityParamDataForNbs(order)");

		ParamInfo root = null;
		String action = null;

		try {
			action = order.getOrderHeader().getOrderType();
			root = new ParamInfo("SonusNbs", null, action);

			if (order.getNbsEntity().getNbsClusterId() != null)
				root.addChildParam(new ParamInfo("NbsClusterId", order.getNbsEntity().getNbsClusterId(), action,
						ParamInfo.Tag.ID));
			root.addChildParam(new ParamInfo("CustomerId", order.getNbsEntity().getCustomerId(), action));
			root.addChildParam(new ParamInfo("LocationId", order.getNbsEntity().getLocationId(), action));
			root.addChildParam(new ParamInfo("TrunkGroupId", order.getNbsEntity().getTrunkGroupId(), action));
			root.addChildParam(new ParamInfo("State", order.getNbsEntity().getState(), action));
			root.addChildParam(new ParamInfo("City", order.getNbsEntity().getCity(), action));
			root.addChildParam(new ParamInfo("Country", order.getNbsEntity().getCountry(), action));
			root.addChildParam(new ParamInfo("Region", order.getNbsEntity().getCountry(), action));
			
			if(order.getNbsEntity().getNbsType() != null) {
				root.addChildParam(new ParamInfo("NbsType", order.getNbsEntity().getNbsType().toString(), action));
			}
			root.addChildParam(new ParamInfo("GroupUserLimit", order.getNbsEntity().getGroupUserLimit(), action));
			// Start-NBS Change
			if (order.getNbsEntity().getCpeIpAddress() != null) {
				root.addChildParam(new ParamInfo("CpeIpAddress", order.getNbsEntity().getCpeIpAddress(), action));
				root.addChildParam(new ParamInfo("IpAddress", order.getNbsEntity().getIpAddress(), action));
				root.addChildParam(new ParamInfo("Address", order.getNbsEntity().getAddress(), action));
			}
			root.addChildParam(new ParamInfo("CpeServerFqdnPort", order.getNbsEntity().getCpeServerFqdnPort(), action));
			root.addChildParam(new ParamInfo("CpeServerFqdn", order.getNbsEntity().getCpeServerFqdn(), action));
			root.addChildParam(new ParamInfo("CpePort", order.getNbsEntity().getCpePort(), action));
			
			if(order.getNbsEntity().getRedundancy() != null) {
				root.addChildParam(
						new ParamInfo("RedundancyType", order.getNbsEntity().getRedundancy().toString(), action));
			}
			
			if(order.getNbsEntity().getRedundancyPriorityType() != null) {
				root.addChildParam(new ParamInfo("RedundancyPriorityType",
						order.getNbsEntity().getRedundancyPriorityType().toString(), action));
			}			
			
			root.addChildParam(new ParamInfo("PbxIpRedundancy1", order.getNbsEntity().getPbxIpRedundancy1(), action));
			root.addChildParam(new ParamInfo("CompressionType", order.getNbsEntity().getCompressionType(), action));
			root.addChildParam(new ParamInfo("BwCluster", order.getNbsEntity().getBwCluster(), action));

			/*
			 * root.addChildParam(new ParamInfo("NbsCluster",
			 * order.getNbsEntity().getNbsClusterName(), action)); root.addChildParam(new
			 * ParamInfo("BwCluster", "BwCluster", action)); root.addChildParam(new
			 * ParamInfo("InternalPort", "InternalPort", action)); root.addChildParam(new
			 * ParamInfo("InternalIp", "InternalIp", action)); root.addChildParam(new
			 * ParamInfo("ExternalPort", "ExternalPort", action)); root.addChildParam(new
			 * ParamInfo("ExternalIp", "ExternalIp", action)); root.addChildParam(new
			 * ParamInfo("Vlan", order.getNbsEntity().getVlanId(), action));
			 * root.addChildParam(new ParamInfo("NifSubIntIp1", "NifSubIntIp1", action));
			 * root.addChildParam(new ParamInfo("NifSubIntIp2", "NifSubIntIp2", action));
			 * root.addChildParam(new ParamInfo("NifSubIntIp3", "NifSubIntIp3", action));
			 * root.addChildParam(new ParamInfo("NifSubIntIp4", "NifSubIntIp4", action));
			 * root.addChildParam(new ParamInfo("nifNextHop", "nifNextHop", action));
			 * root.addChildParam(new ParamInfo("IPVersion",
			 * order.getNbsEntity().getIpVersion(), action)); root.addChildParam(new
			 * ParamInfo("VpnId", "VpnId", action)); root.addChildParam(new
			 * ParamInfo("VpnName", order.getNbsEntity().getVpnName(), action));
			 * root.addChildParam(new ParamInfo("Sr1", order.getNbsEntity().getSR1(),
			 * action)); root.addChildParam(new ParamInfo("Sr2",
			 * order.getNbsEntity().getSR2(), action)); root.addChildParam(new
			 * ParamInfo("Sr3", order.getNbsEntity().getSR3(), action));
			 * root.addChildParam(new ParamInfo("Sr4", order.getNbsEntity().getSR4(),
			 * action)); root.addChildParam(new ParamInfo("IPExt28",
			 * order.getNbsEntity().getIp28(), action)); root.addChildParam(new
			 * ParamInfo("IPInt32", order.getNbsEntity().getIp32(), action));
			 * root.addChildParam(new ParamInfo("NbsCircuitId",
			 * order.getNbsEntity().getNbsCircuitId(), action));
			 */

			LOG.info("Exit prepareTblOrderDetailsEntityParamDataForNbs(order)");
		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new TranslatorException(ErrorCode.TRANSFORMER_FAILURE,
					"Exception occured in prepareTblOrderDetailsEntityParamDataForNbs(order)");
		}
		return root;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.vz.esap.translation.order.transformer.NbsTblOrderDetailsDataTransformer#
	 * prepareTblOrderDetailsEntityParamDataForNbs(com.vz.esap.translation.entity.
	 * NbsEntity, com.vz.esap.translation.entity.NbsEntity, boolean,
	 * java.lang.String)
	 */
	@Override
	public ParamInfo prepareTblOrderDetailsEntityParamDataForNbs(NbsEntity nbsEntityPrev, NbsEntity nbsEntity,
			boolean supp, String action) throws TranslatorException {
		LOG.info("Entered - prepareTblOrderDetailsEntityParamDataForNbs(nbsEntityPrev, nbsEntity, supp, action)");

		ParamInfo root = null;

		try {
			root = new ParamInfo("SonusNbs", null, null);

			if (nbsEntityPrev.getNbsClusterId() != null) {
				root.addChildParam(
						new ParamInfo("NbsClusterId", nbsEntityPrev.getNbsClusterId(), action, ParamInfo.Tag.ID));
			}
			root.addChangeParam("GroupUserLimit", nbsEntityPrev.getGroupUserLimit(), nbsEntityPrev.getGroupUserLimit(), supp);
			root.addChangeParam("CustomerId", nbsEntityPrev.getCustomerId(), nbsEntityPrev.getCustomerId(), supp);
			root.addChangeParam("LocationId", nbsEntityPrev.getLocationId(), nbsEntityPrev.getLocationId(), supp);
			root.addChangeParam("TrunkGroupId", nbsEntityPrev.getTrunkGroupId(), nbsEntity.getTrunkGroupId(), supp);
			root.addChangeParam("State", nbsEntityPrev.getState(), nbsEntity.getState(), supp);
			root.addChangeParam("City", nbsEntityPrev.getCity(), nbsEntity.getCity(), supp);
			root.addChangeParam("Country", nbsEntityPrev.getCountry(), nbsEntity.getCountry(), supp);
			root.addChangeParam("Region", nbsEntityPrev.getRegion(), nbsEntity.getRegion(), supp);
			root.addChangeParam("NbsType", nbsEntityPrev.getNbsType(), nbsEntity.getNbsType(), supp);
			if (nbsEntityPrev.getCpeIpAddress() != null) {
				root.addChangeParam("CpeIpAddress", nbsEntityPrev.getCpeIpAddress(), nbsEntityPrev.getCpeIpAddress(), supp);
				root.addChangeParam("IpAddress", nbsEntityPrev.getIpAddress(), nbsEntityPrev.getIpAddress(), supp);
				root.addChangeParam("Address", nbsEntityPrev.getAddress(), nbsEntityPrev.getAddress(), supp);
			}
			
			root.addChangeParam("CpeServerFqdnPort", nbsEntityPrev.getCpeServerFqdnPort(),
					nbsEntityPrev.getCpeServerFqdnPort(), supp);
			root.addChangeParam("CpeServerFqdn", nbsEntityPrev.getCpeServerFqdn(), nbsEntityPrev.getCpeServerFqdn(), supp);
			root.addChangeParam("CpePort", nbsEntityPrev.getCpePort(), nbsEntityPrev.getCpePort(), supp);

			if(nbsEntityPrev.getRedundancy() != null && nbsEntity.getRedundancy() != null) {
				root.addChangeParam("RedundancyType", nbsEntityPrev.getRedundancy().toString(),
						nbsEntityPrev.getRedundancy().toString(), supp);
			}
			
			if(nbsEntityPrev.getRedundancyPriorityType() != null && nbsEntity.getRedundancyPriorityType() != null) {
				root.addChangeParam("RedundancyPriorityType", nbsEntityPrev.getRedundancyPriorityType().toString(),
						nbsEntityPrev.getRedundancyPriorityType().toString(), supp);
			}			
			
			root.addChangeParam("PbxIpRedundancy1", nbsEntityPrev.getPbxIpRedundancy1(),
					nbsEntityPrev.getPbxIpRedundancy1(), supp);
			root.addChangeParam("CompressionType", nbsEntityPrev.getCompressionType(), nbsEntityPrev.getCompressionType(), supp);
			root.addChangeParam("BwCluster", nbsEntityPrev.getBwCluster(), nbsEntityPrev.getBwCluster(), supp);

		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new TranslatorException(ErrorCode.TRANSFORMER_FAILURE,
					"Exception occured in prepareTblOrderDetailsEntityParamDataForNbs(nbsEntityPrev, nbsEntity, supp, action)");
		}
		LOG.info("Exit prepareTblOrderDetailsEntityParamDataForNbs(nbsEntityPrev, nbsEntity, supp, action)");
		return root;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.vz.esap.translation.order.transformer.NbsTblOrderDetailsDataTransformer#
	 * prepareTblOrderDetailsHeaderParamData(com.vz.esap.translation.order.model.
	 * Order, com.vz.esap.translation.entity.NbsEntity, boolean)
	 */
	@Override
	public ParamInfo prepareTblOrderDetailsHeaderParamData(Order order, NbsEntity oldNbsEntity, boolean supp)
			throws TranslatorException {

		LOG.info("Entered - prepareTblOrderDetailsHeaderParamData(order, oldNbsEntity, supp)");
		ParamInfo nbsParams = null;
		String action = null;
		try {

			int oldVersion = Integer.parseInt(order.getOrderHeader().getOrderVersion()) + 1;
			action = order.getOrderHeader().getOrderType();

			nbsParams = new ParamInfo("Header", null, action);

			nbsParams.addChangeParam("OrderNumber", order.getOrderHeader().getOrderNumber(),
					order.getOrderHeader().getOrderNumber(), supp);
			nbsParams.addChangeParam("EnvOrderId", order.getOrderHeader().getEnvOrderId(), order.getOrderHeader().getEnvOrderId(),
					supp);
			nbsParams.addChangeParam("MasterOrderNumber", order.getOrderHeader().getMasterOrderNumber(),
					order.getOrderHeader().getMasterOrderNumber(), supp);
			nbsParams.addChangeParam("OrderVersion", order.getOrderHeader().getOrderVersion(), order.getOrderHeader().getOrderVersion(), supp);
			nbsParams.addChangeParam("TransactionId", order.getOrderHeader().getTransactionId(),
					order.getOrderHeader().getTransactionId(), supp);
			nbsParams.addChangeParam(REGION, order.getOrderHeader().getRegion(), order.getOrderHeader().getRegion(),
					supp);
			nbsParams.addChangeParam("MinorOrderType", order.getOrderHeader().getMinorOrderType(),
					order.getOrderHeader().getMinorOrderType(), supp);
			nbsParams.addChangeParam("CentrexType", order.getOrderHeader().getCentrexType(),
					order.getOrderHeader().getCentrexType(), supp);
			nbsParams.addChangeParam("ServiceType", order.getOrderHeader().getServiceType(),
					order.getOrderHeader().getServiceType(), supp);
			nbsParams.addChangeParam("OriginatingSystem", order.getOrderHeader().getOriginatingSystem(),
					order.getOrderHeader().getOriginatingSystem(), supp);
			nbsParams.addChangeParam("InterfaceSystem", order.getOrderHeader().getInterfaceSystem(),
					order.getOrderHeader().getInterfaceSystem(), supp);
			nbsParams.addChangeParam("OrderType",
					EsapEnum.OrderType.getValue(order.getOrderHeader().getOrderType().charAt(0)),
					EsapEnum.OrderType.getValue(order.getOrderHeader().getOrderType().charAt(0)), supp);
			nbsParams.addChangeParam("SuppType", order.getOrderHeader().getSuppType(), order.getOrderHeader().getSuppType(), supp);
			nbsParams.addChangeParam("OrderClassify", order.getOrderHeader().getFunctionCode(),
					order.getOrderHeader().getFunctionCode(), supp);

			if (order.getOrderHeader().getDueDate() != null) {
				SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
				Date date = format.parse(order.getOrderHeader().getDueDate().toString());
				Calendar calendar = GregorianCalendar.getInstance();
				calendar.setTime(date);
				Object dueDate = calendar.getTime();
				nbsParams.addNotNullValChild("DueDate", dueDate, action);
			}

			if (order.getLocation() != null && order.getLocation().getCustomerId() != null)
				nbsParams.addChangeParam(CUSTOMER_ID, order.getLocation().getCustomerId(),
						order.getLocation().getCustomerId(), true);

			else if (order.getOrderHeader().getCustomerId() != null)
				nbsParams.addChangeParam(CUSTOMER_ID, order.getOrderHeader().getCustomerId(),
						order.getOrderHeader().getCustomerId(), true);

			else if (oldNbsEntity.getCustomerId() != null)
				nbsParams.addChangeParam(CUSTOMER_ID, oldNbsEntity.getCustomerId(), oldNbsEntity.getCustomerId(), true);
			
			nbsParams.addChangeParam(LOCATION_ID, order.getOrderHeader().getLocationId(), order.getOrderHeader().getLocationId(), true);
			// nbsParams.addNotNullValChild("BsAppServer",
			// order.getCustomer().getBsAppServer(),
			// action); Fix This
			nbsParams.addChangeParam("OrderProTIN", order.getOrderHeader().getOrderProTIN(),
					order.getOrderHeader().getOrderProTIN(), supp);
			nbsParams.addChangeParam("IOrderTIN", order.getOrderHeader().getiOrderTIN(),
					order.getOrderHeader().getiOrderTIN(), supp);
			nbsParams.addChangeParam("TINVersion", order.getOrderHeader().getTinVersion(),
					order.getOrderHeader().getTinVersion(), supp);
			nbsParams.addChangeParam("TransitionFlag", order.getOrderHeader().isTransitionFlag() ? "Y" : "N",
					order.getOrderHeader().isTransitionFlag() ? "Y" : "N", supp);
			nbsParams.addChangeParam("Priority", order.getOrderHeader().getPriority(),
					order.getOrderHeader().getPriority(), supp);
			if (order.getOrderHeader().getAttribMap() != null) {
				nbsParams.addChildParam(OrderUtility.getAttribParamInfo(order.getOrderHeader().getAttribMap(), action));
			}
			if (order.getOrderHeader().getOrderCreatedBy() != null)
				nbsParams.addChangeParam("OrderCreatedBy", order.getOrderHeader().getOrderCreatedBy(),
						order.getOrderHeader().getOrderCreatedBy(), supp);
			if (order.getOrderHeader().isHasBulkOrder()) {
				nbsParams.addChangeParam("BULK", "Y", "Y", supp);
			}
			if (order.getOrderHeader().getHotCutIndicator() != null) {
				nbsParams.addChangeParam(HOT_CUT_IND, "Y", "Y", supp);
			}
			if (order.getOrderHeader().getCDDDIndicator() != null) {
				nbsParams.addChangeParam(CDD_IND, "Y", "Y", supp);
			}

			if (order.getOrderHeader().getSolutionType() != null) {
				nbsParams.addChangeParam("SolutionType", order.getOrderHeader().getSolutionType().toString(),
						order.getOrderHeader().getSolutionType().toString(), supp);
			}

		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new TranslatorException(ErrorCode.TRANSFORMER_FAILURE,
					"Exception occured in prepareTblOrderDetailsHeaderParamData(order, oldNbsEntity, supp)");
		}

		LOG.info("Exit prepareTblOrderDetailsHeaderParamData(order, oldNbsEntity, supp)");

		return nbsParams;
	}

	/**
	 * @param enrichedNbsEntityList,change
	 * @return ArrayList<ParamInfo>
	 */
	@Override
	public ArrayList<ParamInfo> prepareTblOrderDetailsEntityParamDataForNbs(
			ArrayList<NbsEntity> enrichedNbsEntityList, boolean change, Object object) {
		LOG.info("Entered - prepareTblOrderDetailsEntityParamDataForNbs");
		
		if (enrichedNbsEntityList == null) {
			return null;
		}
			
		ArrayList<ParamInfo> paramInfoList = new ArrayList<>();
		ParamInfo nbsParam = null;

		for (NbsEntity oldNbsEntity : enrichedNbsEntityList) {
			
			NbsEntity newNbsEntity = oldNbsEntity.getNbsEntity() != null ? oldNbsEntity.getNbsEntity() : new NbsEntity();

			nbsParam = new ParamInfo("SonusNbs", null, null);
			LOG.info(" paramRoot = {}", nbsParam);

			if (SONUSNBS.equalsIgnoreCase(nbsParam.getName())) {
				LOG.info(" Inside paramRoot = {}", nbsParam.getName());						
				nbsParam.addChangeParam("GroupUserLimit", oldNbsEntity.getGroupUserLimit(), newNbsEntity.getGroupUserLimit(), change);
				nbsParam.addChangeParam("NbsClusterId", oldNbsEntity.getNbsClusterId(), newNbsEntity.getNbsClusterId(), change);
				nbsParam.addChangeParam("CustomerId", oldNbsEntity.getCustomerId(), newNbsEntity.getCustomerId(), change);
				nbsParam.addChangeParam("LocationId", oldNbsEntity.getLocationId(), newNbsEntity.getLocationId(), change);
				nbsParam.addChangeParam("TrunkGroupId", oldNbsEntity.getTrunkGroupId(), newNbsEntity.getTrunkGroupId(), change);
				nbsParam.addChangeParam("State", oldNbsEntity.getState(), newNbsEntity.getState(), change);
				nbsParam.addChangeParam("City", oldNbsEntity.getCity(), newNbsEntity.getCity(), change);
				nbsParam.addChangeParam("Country", oldNbsEntity.getCountry(), newNbsEntity.getCountry(), change);
				nbsParam.addChangeParam("Region", oldNbsEntity.getCountry(), newNbsEntity.getCountry(), change);
				if(oldNbsEntity.getNbsType() != null && newNbsEntity.getNbsType() != null) {
					nbsParam.addChangeParam("NbsType", oldNbsEntity.getNbsType().toString(), newNbsEntity.getNbsType().toString(), change);
				} 
				if (oldNbsEntity.getCpeIpAddress() != null) {
					nbsParam.addChangeParam("CpeIpAddress", oldNbsEntity.getCpeIpAddress(), newNbsEntity.getCpeIpAddress(), change);
				}
				nbsParam.addChangeParam("CpeServerFqdnPort", oldNbsEntity.getCpeServerFqdnPort(), newNbsEntity.getCpeServerFqdnPort(), change);
				nbsParam.addChangeParam("CpeServerFqdn", oldNbsEntity.getCpeServerFqdn(), newNbsEntity.getCpeServerFqdn(), change);
				nbsParam.addChangeParam("CpePort", oldNbsEntity.getCpePort(), newNbsEntity.getCpePort(), change);
				if(oldNbsEntity.getRedundancy() != null && newNbsEntity.getRedundancy() != null) {
					nbsParam.addChangeParam("RedundancyType", oldNbsEntity.getRedundancy().toString(), newNbsEntity.getRedundancy().toString(), change);
				}
				if (oldNbsEntity.getRedundancyPriorityType() != null && newNbsEntity.getRedundancyPriorityType() != null) {
					nbsParam.addChangeParam("RedundancyPriorityType", oldNbsEntity.getRedundancyPriorityType().toString(), newNbsEntity.getRedundancyPriorityType().toString(), change);
				}
				nbsParam.addChangeParam("PbxIpRedundancy1", oldNbsEntity.getPbxIpRedundancy1(), newNbsEntity.getPbxIpRedundancy1(), change);
				nbsParam.addChangeParam("NbsClusterId", oldNbsEntity.getNbsClusterId(), newNbsEntity.getNbsClusterId(), change);
				nbsParam.addChangeParam("AsClli", oldNbsEntity.getAsClli(), oldNbsEntity.getAsClli(), change);
				nbsParam.addChangeParam("BwCluster", oldNbsEntity.getBwCluster(), oldNbsEntity.getBwCluster(), change);
				
			} else if ("NbsConfig".equalsIgnoreCase(nbsParam.getName())) {
				LOG.info(" Inside paramRoot = {}", nbsParam.getName());
				
				nbsParam.addChangeParam("NbsCluster", oldNbsEntity.getNbsClusterName(), newNbsEntity.getNbsClusterName(), change);
				nbsParam.addChangeParam("ExternalIp", oldNbsEntity.getIp28(), newNbsEntity.getIp28(), change);
				nbsParam.addChangeParam("Vlan", oldNbsEntity.getVlanId(), newNbsEntity.getVlanId(), change);
				nbsParam.addChangeParam("IPVersion", oldNbsEntity.getIpVersion(), newNbsEntity.getIpVersion(), change);
				nbsParam.addChangeParam("VpnName", oldNbsEntity.getVpnName(), newNbsEntity.getVpnName(), change);
				nbsParam.addChangeParam("Sr1", oldNbsEntity.getSR1(), newNbsEntity.getSR1(), change);
				nbsParam.addChangeParam("Sr2", oldNbsEntity.getSR2(), newNbsEntity.getSR2(), change);
				nbsParam.addChangeParam("Sr3", oldNbsEntity.getSR3(), newNbsEntity.getSR3(), change);
				nbsParam.addChangeParam("Sr4", oldNbsEntity.getSR4(), newNbsEntity.getSR4(), change);
				nbsParam.addChangeParam("IPExt28", oldNbsEntity.getIp28(), newNbsEntity.getIp28(), change);
				nbsParam.addChangeParam("NbsCircuitId", oldNbsEntity.getNbsCircuitId(), newNbsEntity.getNbsCircuitId(), change);
				if(oldNbsEntity.getNbsType() != null && newNbsEntity.getNbsType() != null) {
					nbsParam.addChangeParam("NbsType", oldNbsEntity.getNbsType().toString(), newNbsEntity.getNbsType().toString(), change);
				}
			} else if ("CircuitInfo".equalsIgnoreCase(nbsParam.getName())) {
				LOG.info(" Inside paramRoot = {}", nbsParam.getName());
				nbsParam.addChangeParam("CircuitId", oldNbsEntity.getNbsCircuitId(), newNbsEntity.getNbsCircuitId(), change);
				nbsParam.addChangeParam("VpnName", oldNbsEntity.getVpnName(), newNbsEntity.getVpnName(), change);
			}

			paramInfoList.add(nbsParam);
		}
		LOG.info("Exit - prepareTblOrderDetailsEntityParamDataForNbs");
		return paramInfoList;
	}

	/**
	 * @param bool
	 * @return boolean
	 */
	public static String booleanToStr(Boolean bool) {
		if (bool == null)
			return null;
		else
			return bool ? "C" : "N";
	}
}
