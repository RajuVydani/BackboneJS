package com.vz.esap.translation.order.model.request;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.ListIterator;
import java.util.TreeMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ParamInfo implements Cloneable {
	private static final Logger LOG = LoggerFactory.getLogger(ParamInfo.class);

	public static enum Tag {
		NON_ORD, NAME, ID, WF;
	}

	private String name;
	private String value;
	private String action;
	private long seqNo;
	private ArrayList<ParamInfo> childParams = new ArrayList<ParamInfo>();
	private HashSet<Tag> tagSet = new HashSet<Tag>();

	public ParamInfo(String name, String value, String action, int seqNo, Tag tag) {
		this.name = name;
		this.value = value;
		this.action = action;
		this.seqNo = seqNo;
		if (tag != null) {
			tagSet.add(tag);
		}
	}

	public ParamInfo(String name, String value, String action, HashSet<Tag> tagSet) {
		this.name = name;
		this.value = value;
		this.action = action;
		this.seqNo = 0;
		this.tagSet = tagSet;
	}

	public ParamInfo(String name, String value, String action, Tag tag) {
		this.name = name;
		this.value = value;
		this.action = action;
		this.seqNo = 0;
		if (tag != null) {
			tagSet.add(tag);
		}
	}

	public ParamInfo(String name, String value, String action) {
		this.name = name;
		this.value = value;
		this.action = action;
		this.seqNo = 0;
	}

	public ParamInfo(ParamInfo pi) {
		this.name = pi.getName();
		this.value = pi.getValue();
		this.action = pi.getAction();
		this.seqNo = pi.getSeqNo();
		if (pi.getTagSet() != null)
			this.tagSet = new HashSet<ParamInfo.Tag>(pi.getTagSet());
		if (pi.getChildParams() != null) {
			for (ParamInfo childPi : pi.getChildParams())
				addChildParam(new ParamInfo(childPi));
		}
	}

	public ParamInfo clone() {
		ParamInfo cloneInfo = null;
		try {
			cloneInfo = (ParamInfo) super.clone();
			ArrayList<ParamInfo> cp = new ArrayList<ParamInfo>();
			HashSet<Tag> ts = new HashSet<Tag>();
			if (cloneInfo.childParams != null) {
				for (ParamInfo pi : cloneInfo.childParams)
					cp.add(pi.clone());
			}
			if (cloneInfo.tagSet != null) {
				ts.addAll(cloneInfo.tagSet);
			}
			cloneInfo.childParams = cp;
			cloneInfo.tagSet = ts;
		} catch (Exception e) {
			LOG.error("Exception: {}", e.getMessage(), e);
		}
		return cloneInfo;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public HashSet<Tag> getTagSet() {
		return tagSet;
	}

	public void setTagSet(HashSet<Tag> tagSet) {
		this.tagSet = tagSet;
	}

	public boolean hasTag(Tag t) {
		return tagSet != null ? tagSet.contains(t) : false;
	}

	public void addTag(Tag tag) {
		if (tag != null)
			tagSet.add(tag);
	}

	public long getSeqNo() {
		return seqNo;
	}

	public void setSeqNo(long seqNo) {
		this.seqNo = seqNo;
	}

	public ArrayList<ParamInfo> getChildParams() {
		return childParams;
	}

	public void setChildParams(ArrayList<ParamInfo> childParams) {
		this.childParams = childParams;
	}

	public void addChildParams(ArrayList<ParamInfo> childPars) {
		if (childPars == null)
			return;

		if (childParams == null)
			childParams = new ArrayList<ParamInfo>();

		childParams.addAll(childPars);
	}

	public void addChildParam(ParamInfo childParam, Tag tag) {
		if (childParam == null)
			return;

		childParam.addTag(tag);
		addChildParam(childParam);
	}

	public void addChildParam(ParamInfo childParam) {

		// Below Logging is for Testing Purpose Change this to Debug after Testing is
		// done.
		if (childParam != null)
			LOG.debug("Entered - addChildParam with Param Name ={}, Param Value = {} , Param Action = {} ",
					childParam.getName(), childParam.getValue(), childParam.getAction());
		try {
			if (childParam == null)
				return;

			if (childParams == null)
				childParams = new ArrayList<ParamInfo>();

			childParams.add(childParam);
			if (action == null && childParam.getAction() != null && !"NC".equalsIgnoreCase(childParam.getAction()))
				setAction("C");
		} catch (Exception e) {
			LOG.error("Exception: {}", e.getMessage(), e);
		}

	}

	public void addChildParamSetAction(ParamInfo childParam) {
		addChildParam(childParam);
		if (childParam.getAction() != null)
			setAction(childParam.getAction());
	}

	public void addChangeParam(String paramName, Object oldValue, Object newValue, boolean forSupp) {
		addChangeParam(paramName, oldValue, newValue, forSupp, null);
	}

	public void addRecapParam(String paramName, Object oldValue, Object newValue, boolean forSupp) {
		if (oldValue != null)
			addChildParam(new ParamInfo(paramName, oldValue.toString(), null));
		else if (newValue != null)
			addChildParam(new ParamInfo(paramName, newValue.toString(), null));
	}

	public String addChangeParamReturnAction(String paramName, Object oldValue, Object newValue, boolean forSupp,
			Tag tag) {
		ArrayList<ParamInfo> changeParams = addAndReturnChangeParams(paramName, oldValue, newValue, forSupp, tag);
		if (changeParams.size() == 2)
			return "C";
		else if (changeParams.size() == 1)
			return changeParams.get(0).getAction();
		else
			return null;
	}

	public void addChangeParam(String paramName, Object oldValue, Object newValue, boolean forSupp, Tag tag) {
		addAndReturnChangeParams(paramName, oldValue, newValue, forSupp, tag);
	}

	public ArrayList<ParamInfo> addAndReturnChangeParams(String paramName, Object oldValue, Object newValue,
			boolean forSupp, Tag tag) {

		ParamInfo inParam = null;
		ParamInfo outParam = null;
		ParamInfo recapParam = null;
		ArrayList<ParamInfo> ret = new ArrayList<>();
		boolean notChanged = true;

		if (forSupp) {
			if (oldValue != null && !oldValue.equals(newValue))
				outParam = new ParamInfo(paramName, oldValue.toString(), "O", tag);
			if (newValue != null && !newValue.equals(oldValue))
				inParam = new ParamInfo(paramName, newValue.toString(), "I", tag);
			if (oldValue != null && newValue != null && newValue.equals(oldValue))
				recapParam = new ParamInfo(paramName, oldValue.toString(), null, tag);

			// New
			if (oldValue == null && newValue != null)
				outParam = new ParamInfo(paramName, "", "O", tag);
			if (oldValue != null && newValue == null)
				inParam = new ParamInfo(paramName, "", "I", tag);
		} else {
			if (oldValue != null && (newValue == null || oldValue.equals(newValue)))
				recapParam = new ParamInfo(paramName, oldValue.toString(), null, tag);
			else {
				if (oldValue != null && !oldValue.equals(newValue))
					outParam = new ParamInfo(paramName, oldValue.toString(), "O", tag);
				if (newValue != null && !newValue.equals(oldValue))
					inParam = new ParamInfo(paramName, newValue.toString(), "I", tag);
				// New
				if (oldValue == null && newValue != null)
					outParam = new ParamInfo(paramName, "", "O", tag);
			}
		}

		// If there is some action at child level
		// set parent action to change
		if (inParam != null) {
			ret.add(inParam);
			this.addChildParam(inParam);
			if (inParam.getAction() != null) {
				LOG.info("change param : {} , new: {} ,  action: {},  ", paramName, inParam.getValue(),
						inParam.getAction());
				this.setAction("C");
				notChanged = false;
			}
		}

		if (outParam != null) {
			ret.add(outParam);
			this.addChildParam(outParam);
			if (outParam.getAction() != null) {
				this.setAction("C");
				LOG.info("change param: {},  old: {}, action: {} ", paramName, outParam.getValue(),
						outParam.getAction());
				notChanged = false;
			}
		}

		if (recapParam != null && !"C".equalsIgnoreCase(this.getAction())) {
			ret.add(recapParam);
			this.addChildParam(recapParam);
			// New Logic For XO Supp:
			this.setAction("NC");
		}

		// New Logic for XO
		if (recapParam != null && "C".equalsIgnoreCase(this.getAction())) {
			ret.add(recapParam);
			this.addChildParam(recapParam);
			// New Logic For XO Supp:
			// this.setAction("NC");
		}
		return ret;
	}

	public void addNotNullValChild(String name, Object value, String action) {
		addNotNullValChild(name, value, action, null);
	}

	public void addNotNullValChild(String name, Object value, String action, Tag tag) {
		if (value == null)
			return;
		else
			addChildParam(new ParamInfo(name, value.toString(), action, tag));
	}

	public int removeChildParam(String nam) {
		return removeChildParams(nam, null, false, "ONE");
	}

	public int removeChildParam(String nam, String val) {
		return removeChildParams(nam, val, true, "ONE");
	}

	public int removeChildParams(String nam) {
		return removeChildParams(nam, null, false, "ALL");
	}

	public int removeChildParams(String nam, String val) {
		return removeChildParams(nam, val, true, "ALL");
	}

	public int removeChildParams(String nam, String val, boolean matchVal, String which) {
		LOG.info("Entered removeChildParams with (" + nam + "," + val + "," + matchVal + "," + which + ")");
		int ret = 0;
		if (childParams == null || childParams.size() <= 0 || which == null || nam == null
				|| !which.equalsIgnoreCase("ONE") && !which.equalsIgnoreCase("ALL")) {
			LOG.info("Invalid input params");
			return ret;
		}

		ArrayList<Integer> matchList = new ArrayList<Integer>();
		for (int idx = 0; idx < childParams.size(); idx++) {
			ParamInfo childParam = childParams.get(idx);
			if (childParam == null || childParam.getName() == null)
				continue;
			LOG.info("Child Name: {} , Child Value: {} ", childParam.getName(), childParam.getValue());
			if (childParam.getName().equals(nam) && (!matchVal || childParam.getValue() == null && val == null
					|| childParam.getValue() != null && val != null && childParam.getValue().equals(val))) {
				matchList.add(idx);
				if (which.equalsIgnoreCase("ONE"))
					break;
			}
		}
		ret = matchList.size();
		int adjust = 0;
		for (Integer childIdx : matchList) {
			int adjustedIdx = childIdx - adjust++;
			// childParams.get(childIdx).setValue(childParams.get(childIdx).getValue() +
			// "X");
			LOG.info("Removing Child : {}, Name: {},  ", childIdx, childParams.get(adjustedIdx).getName());
			childParams.remove(adjustedIdx);
		}
		return ret;
	}

	public ParamInfo findParam(String name) {
		if (this.name.equals(name))
			return this;

		ParamInfo matchParam = null;
		if (childParams != null)
			for (ParamInfo childParam : childParams) {
				matchParam = childParam.findParam(name);
				if (matchParam != null)
					break;
			}

		return matchParam;
	}

	public ParamInfo findChildParam(String name) {
		ParamInfo matchParam = null;
		if (childParams != null)
			for (ParamInfo childParam : childParams) {
				if (childParam.getName().equals(name)) {
					matchParam = childParam;
					break;
				}
			}

		return matchParam;
	}

	public ArrayList<ParamInfo> findChildrenParam(String name) {
		ArrayList<ParamInfo> matchParams = new ArrayList<ParamInfo>();
		if (childParams != null)
			for (ParamInfo childParam : childParams) {
				if (childParam.getName().equals(name)) {
					matchParams.add(childParam);
				}
			}

		return matchParams;
	}

	public String findParamValue(String name) {
		ParamInfo pi = findParam(name);
		if (pi != null)
			return pi.getValue();
		else
			return null;
	}

	public static HashSet<Tag> stringToTagSet(String tagStr) {
		if (tagStr == null)
			return null;

		if (tagStr.indexOf(',') == -1)
			return null;

		HashSet<Tag> rTags = new HashSet<Tag>();

		String[] tokens = tagStr.split(",");
		for (int i = 0; i < tokens.length; i++) {
			if (tokens[i] == null || tokens[i].equals(""))
				continue;

			try {
			} catch (NumberFormatException e) {
				continue;
			}
			int ordinal = Integer.parseInt(tokens[i]);
			if (ordinal < Tag.values().length)
				rTags.add(Tag.values()[ordinal]);
		}

		return rTags;
	}

	public static boolean strMatch(String str1, String str2) {
		return (str1 == null && str2 == null || str1 != null && str2 != null && str1.equals(str2));
	}

	public ParamInfo getNextParam(String name, String value, String action, String flag, HashSet<ParamInfo> skip) {
		if (skip == null || !skip.contains(this)) {
			if (skip != null)
				skip.add(this);
			boolean nmatch = false;
			boolean vmatch = false;
			boolean amatch = false;
			if (flag.indexOf("N") < 0 || strMatch(this.name, name))
				nmatch = true;
			if (nmatch && (flag.indexOf("V") < 0 || strMatch(this.value, value)))
				vmatch = true;
			if (vmatch && (flag.indexOf("A") < 0 || strMatch(this.action, action)))
				amatch = true;
			if (amatch)
				return this;
		}
		if (childParams != null)
			for (ParamInfo cpi : childParams) {
				ParamInfo tmp = cpi.getNextParam(name, value, action, flag, skip);
				if (tmp != null)
					return tmp;
			}
		return null;
	}

	public static String tagSetToString(HashSet<Tag> tags) {
		StringBuilder ret = new StringBuilder();
		if (tags == null || tags.size() <= 0)
			return ret.toString();
		for (Tag nextTag : tags)
			ret.append(",").append(nextTag.ordinal());
		ret.append(",");
		return ret.toString();
	}

	public String xmlNode() {
		return "<" + xmlString() + "/>";
	}

	public String xmlString() {
		return name + " value=\"" + value + "\" action=\"" + action + "\" seqNo=\"" + seqNo + "tagSet=\""
				+ ParamInfo.tagSetToString(tagSet) + "\"";
	}

	/*
	 * public String toXML(int level) { String lvlTab = ""; for (int i=0; i<level;
	 * i++) lvlTab += " "; String out = "\n" + lvlTab + "<" + xmlString() + ">"; if
	 * (childParams != null) for (ParamInfo cpi: childParams) out += cpi.toXML(level
	 * + 1); out += "\n" + lvlTab + "</" + name + ">"; return out; }
	 */
	public String toXML(int level) {
		StringBuilder lvlTab = new StringBuilder();
		StringBuilder out = new StringBuilder();
		for (int i = 0; i < level; i++)
			lvlTab.append(" ");
		out.append("\n").append(lvlTab).append("<").append(xmlString()).append(">");
		if (childParams != null)
			for (ParamInfo cpi : childParams)
				out.append(cpi.toXML(level + 1));
		out.append("\n").append(lvlTab).append("</").append(name).append(">");
		return out.toString();
	}

	public boolean isLeaf() {
		return childParams == null || childParams.size() <= 0;
	}

	public boolean isLastNonLeaf() {
		if (isLeaf())
			return false;
		for (ParamInfo pi : childParams)
			if (!pi.isLeaf())
				return false;
		return true;
	}

	public void delSubtreeByTag(Tag t) {
		HashSet<ParamInfo> delChld = new HashSet<ParamInfo>();
		if (!isLeaf()) {
			for (ParamInfo pi : childParams)
				if (pi.hasTag(t))
					delChld.add(pi);
				else
					pi.delSubtreeByTag(t);
			for (ParamInfo nextChld : delChld)
				childParams.remove(nextChld);
		}
	}

	public void setAllAction(String act) {
		action = act;
		if (!isLeaf())
			for (ParamInfo pi : childParams)
				pi.setAllAction(act);
	}

	public ParamInfo getIdChild() {
		if (isLeaf())
			return this;
		for (ParamInfo nextPi : childParams)
			if (nextPi.hasTag(Tag.ID))
				return nextPi;
		return null;
	}

	public static boolean findChanges(ParamInfo old, ParamInfo newPi, HashSet<ParamInfo> del, HashSet<ParamInfo> recap,
			HashSet<ParamInfo> add, HashMap<ParamInfo, ParamInfo> mod) {
		if (!match(old, newPi))
			return false;
		HashMap<ParamInfo, ParamInfo> newFoundMap = new HashMap<ParamInfo, ParamInfo>();
		ArrayList<ParamInfo> branch = new ArrayList<ParamInfo>();
		branch.add(old);
		branch.add(null);
		if (old.childParams != null)
			for (ParamInfo ocpi : old.childParams) {
				branch.add(1, ocpi);
				TreeMap<Integer, ArrayList<ArrayList<ParamInfo>>> tmap = findAllPartialBranches(branch, newPi,
						newFoundMap);
				if (!tmap.containsKey(Integer.valueOf(-2)) || tmap.get(Integer.valueOf(-2)) == null
						|| tmap.get(Integer.valueOf(-2)).size() <= 0) {
					del.add(ocpi);
					continue;
				} else {
					ArrayList<ParamInfo> nBranch = tmap.get(Integer.valueOf(-2)).get(0);
					ParamInfo ncpi = nBranch.get(1);
					if (ncpi.childParams == null || ncpi.childParams.size() <= 0)
						recap.add(ocpi);
					else
						mod.put(ocpi, ncpi);
					newPi.childParams.remove(ncpi);
				}
			}
		if (newPi.childParams != null)
			add.addAll(newPi.childParams);
		for (ParamInfo dcpi : del)
			old.childParams.remove(dcpi);
		for (ParamInfo rcpi : recap)
			old.childParams.remove(rcpi);
		for (ParamInfo mcpi : mod.keySet())
			old.childParams.remove(mcpi);
		return true;
	}

	public static TreeMap<Integer, ArrayList<ArrayList<ParamInfo>>> findAllPartialBranches(ArrayList<ParamInfo> nodes,
			ParamInfo root, HashMap<ParamInfo, ParamInfo> foundMap) {
		ArrayList<ArrayList<ParamInfo>> tmpPiListList = new ArrayList<ArrayList<ParamInfo>>();
		HashSet<ParamInfo> visitedSet = new HashSet<ParamInfo>();
		HashSet<ParamInfo> notLast = new HashSet<ParamInfo>();
		do
			if (tmpPiListList.size() <= 0 || tmpPiListList.get(tmpPiListList.size() - 1).size() > 0)
				tmpPiListList.add(new ArrayList<ParamInfo>());
		while (root.findPartialBranch(nodes, tmpPiListList, foundMap, visitedSet, notLast, 0));
		TreeMap<Integer, ArrayList<ArrayList<ParamInfo>>> ret = new TreeMap<Integer, ArrayList<ArrayList<ParamInfo>>>();
		for (ArrayList<ParamInfo> nextBranch : tmpPiListList) {
			Integer key = Integer.valueOf(-1 * nextBranch.size());
			if (!ret.containsKey(key))
				ret.put(key, new ArrayList<ArrayList<ParamInfo>>());
			ret.get(key).add(nextBranch);
		}
		return ret;
	}

	public boolean findPartialBranch(ArrayList<ParamInfo> nodes, ArrayList<ArrayList<ParamInfo>> results,
			HashMap<ParamInfo, ParamInfo> foundMap, HashSet<ParamInfo> visitedNodes, HashSet<ParamInfo> notLast,
			int level) {
		if (visitedNodes.contains(this))
			return false;
		ArrayList<ParamInfo> result = results.get(results.size() - 1);
		boolean notInResult = result.size() <= level || result.get(level) != this;
		ParamInfo node = nodes.get(level);
		if (notInResult && foundMap.containsKey(node))
			result.add(foundMap.get(node));
		else if (notInResult) {
			ParamInfo idChild = getIdChild();
			ParamInfo idChildNode = node.getIdChild();
			if (strMatch(idChild.name, idChildNode.name) && strMatch(idChild.value, idChildNode.value)) {
				result.add(this);
				foundMap.put(node, this);
			} else
				return false;
		}
		if (nodes.size() > level && childParams != null)
			for (ParamInfo cpi : childParams)
				if (cpi.findPartialBranch(nodes, results, foundMap, visitedNodes, notLast, level + 1)) {
					notLast.add(this);
					return true;
				}
		visitedNodes.add(this);
		return !notLast.contains(this);
	}

	public static ParamInfo find(ParamInfo param, ArrayList<ParamInfo> list, HashSet<ParamInfo> skip) {
		if (param == null || list == null || list.size() <= 0)
			return null;
		for (ParamInfo pi : list)
			if (!skip.contains(pi) && match(pi, param))
				return pi;
		return null;
	}

	public static boolean match(ParamInfo first, ParamInfo second) {
		if (first == null && second == null)
			return true;
		if (first == null || second == null)
			return false;
		if (!strMatch(first.name, second.name))
			return false;
		ParamInfo firstId = first.getIdChild();
		ParamInfo secondId = second.getIdChild();
		if (firstId == null || secondId == null)
			return false;
		return strMatch(firstId.name, secondId.name) && strMatch(firstId.value, secondId.value);
	}

	public static String applyChangesToCurrent(ParamInfo old, ParamInfo newPi, ParamInfo cur) throws Exception {
		if (old == null || newPi == null || cur == null)
			return "FAILURE";
		String ret = "SUCCESS";
		ArrayList<ParamInfo> nextBranch = new ArrayList<ParamInfo>();
		// log.info("Old Tree XML [[\n" + old.toXML(0) + "\n]]");
		// log.info("New Tree XML [[\n" + newPi.toXML(0) + "\n]]");
		// log.info("Cur Tree XML [[\n" + cur.toXML(0) + "\n]]");
		old.setAllAction("old");
		newPi.setAllAction("new");
		cur.setAllAction("");
		HashMap<ParamInfo, ParamInfo> newFoundMap = new HashMap<ParamInfo, ParamInfo>();
		HashMap<ParamInfo, ParamInfo> curFoundMap = new HashMap<ParamInfo, ParamInfo>();
		boolean skipNextIteration = false;
		while (skipNextIteration || getNextParamBranch(old, nextBranch, 0)) {
			skipNextIteration = false;
			if (nextBranch == null || nextBranch.size() < 2)
				continue;
			ParamInfo curNextToLast = null;
			ParamInfo nextToLast = nextBranch.get(nextBranch.size() - 2);
			if (!nextToLast.isLastNonLeaf())
				continue;
			ParamInfo last = nextBranch.get(nextBranch.size() - 1);
			if (!last.hasTag(Tag.ID))
				continue;
			TreeMap<Integer, ArrayList<ArrayList<ParamInfo>>> curTmap = null;
			TreeMap<Integer, ArrayList<ArrayList<ParamInfo>>> tmap = findAllPartialBranches(nextBranch, newPi,
					newFoundMap);
			if (tmap.size() <= 0)
				throw new Exception("NO_TREE");
			for (Integer nextLen : tmap.keySet()) {
				nextLen = -1 * nextLen;
				if (nextLen > nextBranch.size())
					throw new Exception("Branch longer than original");
				if (nextLen < nextBranch.size()) {
					ArrayList<ParamInfo> copyOfNextBranch = new ArrayList<ParamInfo>(nextBranch);
					int brSize = copyOfNextBranch.size();
					for (int i = nextLen + 1; i < brSize; i++)
						copyOfNextBranch.remove(nextLen + 1);
					ParamInfo prunedRoot = nextBranch.get(nextLen.intValue());
					while (getNextParamBranch(old, nextBranch, 0)) {
						if (nextBranch.size() <= 0)
							break;
						if (nextBranch.size() < nextLen + 1 || nextBranch.get(nextLen.intValue()) != prunedRoot) {
							skipNextIteration = true;
							break;
						}
					}
					curTmap = findAllPartialBranches(copyOfNextBranch, cur, curFoundMap);
					if (curTmap == null || curTmap.size() <= 0)
						throw new Exception("NO CUR TREE");
					for (Integer nextCurLen : curTmap.keySet()) {
						nextCurLen *= -1;
						if (nextLen + 1 > nextCurLen)
							throw new Exception("BRANCH ALREADY DELETED");
						ArrayList<ParamInfo> curBranch = curTmap.get(nextCurLen.intValue()).get(0);
						if (curBranch == null || curBranch.size() < 2)
							continue;
						curNextToLast = curBranch.get(curBranch.size() - 2);
						ParamInfo curLast = curBranch.get(curBranch.size() - 1);
						if (curNextToLast.childParams == null)
							throw new Exception("INTERNAL ERROR");
						for (ParamInfo ncPi : curNextToLast.childParams)
							if (ncPi == curLast) {
								curNextToLast.childParams.remove(curLast);
								curFoundMap.remove(copyOfNextBranch.get(curBranch.size() - 1));
								break;
							}
						break;
					}
					if (nextToLast.childParams == null)
						throw new Exception("INTERNAL ERROR");
					for (ParamInfo noPi : nextToLast.childParams)
						if (noPi == last) {
							nextToLast.childParams.remove(last);
							break;
						}
					if (skipNextIteration)
						continue;
					break;
				} else // if (nextLen == nextBranch.size())
				{
					curTmap = findAllPartialBranches(nextBranch, cur, curFoundMap);
					if (curTmap == null || curTmap.size() <= 0 || curTmap.get(-1 * nextLen) == null
							|| curTmap.get(-1 * nextLen).size() <= 0)
						throw new Exception("NO CUR TREE");
					for (ArrayList<ParamInfo> curBranch : curTmap.get(-1 * nextLen)) {
						if (curBranch.size() != nextBranch.size() || curBranch.size() < 2)
							continue;
						curNextToLast = curBranch.get(nextBranch.size() - 2);
					}
					if (tmap.get(-1 * nextLen) == null || tmap.get(-1 * nextLen).size() <= 0)
						throw new Exception("INTERNAL ERROR: Empty or null new branch");
					ArrayList<ParamInfo> newNextBranch = tmap.get(-1 * nextLen).get(0);
					ParamInfo newNextToLast = newNextBranch.get(newNextBranch.size() - 2);
					HashSet<ParamInfo> delSet = new HashSet<ParamInfo>();
					HashSet<ParamInfo> recapSet = new HashSet<ParamInfo>();
					HashSet<ParamInfo> addSet = new HashSet<ParamInfo>();
					HashMap<ParamInfo, ParamInfo> modMap = new HashMap<ParamInfo, ParamInfo>();
					if (!findChanges(nextToLast, newNextToLast, delSet, recapSet, addSet, modMap))
						throw new Exception("INTERNAL ERROR: Change nodes mismatched");
					HashSet<ParamInfo> skip = new HashSet<ParamInfo>();
					for (ParamInfo delPi : delSet) {
						ParamInfo foundPi = null;
						if ((foundPi = ParamInfo.find(delPi, curNextToLast.childParams, skip)) == null)
							throw new Exception("Param already deleted from cur");
						else
							curNextToLast.childParams.remove(foundPi);
						skip.add(foundPi);
					}
					for (ParamInfo addPi : addSet) {
						if ((ParamInfo.find(addPi, curNextToLast.childParams, skip)) == null) {
							ParamInfo clonePi = addPi.clone();
							skip.add(clonePi);
							curNextToLast.childParams.add(clonePi);
						} else
							throw new Exception("Param already present in cur");
					}
					for (ParamInfo modPi : modMap.keySet()) {
						ParamInfo foundPi = null;
						if ((foundPi = ParamInfo.find(modPi, curNextToLast.childParams, skip)) == null)
							throw new Exception("Changed Param deleted from cur");
						else {
							skip.add(foundPi);
							for (ParamInfo newCcpi : modMap.get(modPi).childParams) {
								if (newCcpi.hasTag(Tag.ID))
									continue;
								if (ParamInfo.find(newCcpi, foundPi.childParams, skip) != null)
									throw new Exception("Child of changed Param already present in child of cur");
								else {
									ParamInfo clonePi = newCcpi.clone();
									skip.add(clonePi);
									foundPi.childParams.add(clonePi);
								}
							}
						}
					}
				}
				break;
			}
		}
		return ret;
	}

	public static boolean getNextParamBranch(ParamInfo root, ArrayList<ParamInfo> nodes, int level) {
		boolean isOpen = nodes.size() <= level;
		boolean isLast = nodes.size() == level + 1;
		if (isOpen)
			nodes.add(root);
		boolean isHit = nodes.size() > level && nodes.get(level) == root;
		if (!isLast && !isHit)
			return false;
		if (isLast && !isOpen) {
			if (isHit)
				nodes.remove(nodes.size() - 1);
			return false;
		}
		if (root.getChildParams().size() > 0)
			for (ParamInfo nextChild : root.getChildParams()) {
				if (getNextParamBranch(nextChild, nodes, level + 1))
					return true;
			}
		else if (isOpen)
			return true;
		return false;
	}

	public boolean hasAction(String act) {
		if (act == null)
			return false;

		if (act.equals(this.action))
			return true;

		if (childParams != null)
			for (ParamInfo param : childParams) {
				if (param.hasAction(act))
					return true;
			}

		return false;

	}

	public void reverseAction() {
		if ("I".equals(action))
			action = "O";
		else if ("O".equals(action))
			action = "I";

		if (childParams != null) {
			for (ParamInfo pi : childParams)
				pi.reverseAction();
		}
	}

	public ParamInfo removeFirstParam(String paramName) {

		LOG.debug("ParamInfo.removeFirstParam:" + paramName);

		return removeParam(paramName, childParams, false);
	}

	public void removeAllParams(String paramName) {

		LOG.debug("ParamInfo.removeAllParam:" + paramName);

		removeParam(paramName, childParams, true);
	}

	private ParamInfo removeParam(String paramName, ArrayList<ParamInfo> childParams2, boolean removeAll) {
		if (childParams2 == null)
			return null;

		for (ListIterator<ParamInfo> it = childParams2.listIterator(); it.hasNext();) {
			ParamInfo pi = it.next();
			if (pi.getName().equals(paramName)) {
				it.remove();
				if (!removeAll)
					return pi;
			} else if (pi.getChildParams() != null) {
				ParamInfo removedPI = removeParam(paramName, pi.getChildParams(), removeAll);
				if (!removeAll && removedPI != null)
					return removedPI;
			}
		}

		return null;
	}

	@Override
	public String toString() {
		return "ParamInfo [name=" + name + ", value=" + value + ", action=" + action + ", seqNo=" + seqNo
				+ ", childParams=" + childParams + ", tagSet=" + tagSet + "]";
	}

	public void addNonChangingParam(String paramName, Object oldValue, Object newValue, boolean forSupp) {
		if (newValue != null && oldValue != null)
			addChangeParam(paramName, oldValue, newValue, forSupp);
		else if (newValue != null && oldValue == null)
			addChildParam(new ParamInfo(paramName, newValue.toString(), null));
		else if (newValue == null && oldValue != null)
			addChildParam(new ParamInfo(paramName, oldValue.toString(), null));

	}

	public void removeChildrenParamByAction(String action) {
		if (childParams != null) {
			for (ListIterator<ParamInfo> itr = childParams.listIterator(); itr.hasNext();) {
				ParamInfo pi = itr.next();
				if (pi.getAction() != null && pi.getAction().equals(action)) {
					itr.remove();
				} else
					pi.removeChildrenParamByAction(action);
			}
		}
	}

	public ParamInfo getNewParamInfo() {
		ParamInfo newParamInfo = new ParamInfo(this);
		newParamInfo.removeChildrenParamByAction("O");
		return newParamInfo;
	}

	public ParamInfo getOldParamInfo() {
		ParamInfo oldParamInfo = new ParamInfo(this);
		oldParamInfo.removeChildrenParamByAction("I");
		return oldParamInfo;
	}

}
