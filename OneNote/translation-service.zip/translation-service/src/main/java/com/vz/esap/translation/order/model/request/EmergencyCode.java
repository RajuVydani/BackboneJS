package com.vz.esap.translation.order.model.request;

public class EmergencyCode {

	private String EmergencyNumber;

	private String EmergencyCode;

	public String getEmergencyNumber() {
		return EmergencyNumber;
	}

	public void setEmergencyNumber(String EmergencyNumber) {
		this.EmergencyNumber = EmergencyNumber;
	}

	public String getEmergencyCode() {
		return EmergencyCode;
	}

	public void setEmergencyCode(String EmergencyCode) {
		this.EmergencyCode = EmergencyCode;
	}

	public String toString() {
		return "ClassPojo [EmergencyNumber = " + EmergencyNumber + ", EmergencyCode = " + EmergencyCode + "]";
	}
}
