package com.vz.esap.translation.entity;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.vz.esap.translation.enums.EsapEnum;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.vz.esap.translation.enums.EsapEnum.OrderAction;
import com.vz.esap.translation.order.transformer.ParamInfoTransformer;

import EsapEnumPkg.VzbVoipEnum;

public abstract class Entity {

	@Autowired
	ParamInfoTransformer paramInfoTransformer;

	private static final Logger LOG = LoggerFactory.getLogger(Entity.class);

	public static enum GroupType {
		PBX(VzbVoipEnum.TrunkGroupType.PBX), KEY(VzbVoipEnum.TrunkGroupType.KEY), TWO_WAY(
				EsapEnum.TrunkGroupType.TWO_WAY.ordinal() + 1), INBOUND(
						EsapEnum.TrunkGroupType.INBOUND.ordinal() + 1), PRI_DID(
								EsapEnum.TrunkGroupType.PRI_DID.ordinal() + 1), LINE(
										EsapEnum.TrunkGroupType.LINE.ordinal() + 1), NON_PRI_DID(
												EsapEnum.TrunkGroupType.NON_PRI_DID.ordinal() + 1);
		int esapEnum;

		private GroupType(int esapEnum) {
			this.esapEnum = esapEnum;
		}

		public int getEsapEnum() {
			return esapEnum;
		}

		public static GroupType valueOf(int esapEnum) {
			for (GroupType as : GroupType.values())
				if (as.getEsapEnum() == esapEnum)
					return as;

			return null;
		}
	}

	public static enum Service {
		BS, VM, IASA, ICP;
	}

	public static enum ActiveStatus {

		ACTIVE(VzbVoipEnum.ActiveInd.ACTIVE), DELETE_PENDING(VzbVoipEnum.ActiveInd.DELETE_PENDING), INACTIVE(
				VzbVoipEnum.ActiveInd.INACTIVE), SUSPEND(VzbVoipEnum.ActiveInd.SUSPEND);

		int esapEnum;

		private ActiveStatus(int esapEnum) {
			this.esapEnum = esapEnum;
		}

		public int getEsapEnum() {
			return esapEnum;
		}

		public static ActiveStatus valueOf(int esapEnum) {
			for (ActiveStatus as : ActiveStatus.values())
				if (as.getEsapEnum() == esapEnum)
					return as;

			return null;
		}
	}

	public abstract int getEntityType();

	public abstract String getEntityName();

	public abstract String getEntityId();

	protected LinkedHashMap<String, String> attribMap;
	protected HashSet<ParentEntity> parentList;
	protected List<Service> skipService;

	protected ActiveStatus activeStatus;

	protected Integer broadsoftTNActivation;
	public String serviceParameter;
	private OrderAction action;
	private boolean attribTaskParamsReversed;
	private Boolean hotCutIndicator;
	private Boolean CDDDIndicator;
	private Boolean r2rMigration;

	public List<Service> getSkipService() {
		return skipService;
	}

	public void setSkipService(List<Service> skipService) {
		this.skipService = skipService;
	}

	// skip Service functionality

	public boolean searchSkipService(String serviceName) {

		boolean result = false;
		if (null != skipService && skipService.size() > 0) {
			for (Service s : skipService) {
				if (s.name().equalsIgnoreCase(serviceName)) {
					result = true;
					break;
				}
			}
		}
		return result;
	}

	public LinkedHashMap<String, String> getAttribMap() {
		return attribMap;
	}

	public void setAttribMap(LinkedHashMap<String, String> attribMap) {
		this.attribMap = attribMap;
	}

	public String getAttrib(String name) {
		String value = null;

		if (attribMap != null)
			value = attribMap.get(name);

		return value;
	}

	public String removeAttrib(String name) {
		String value = null;
		if (attribMap != null) {
			Object obj = attribMap.remove(name);
			if (obj != null) {
				value = obj.toString();
				LOG.info("removed object: {}: {}", name, value);
			}
		}
		return value;
	}

	public void addAttrib(String name, long value) {
		if (null != name) {
			addAttrib(name, "" + value);
		}
	}

	public void addAttrib(String name, String value) {
		try {
			if (attribMap == null)
				attribMap = new LinkedHashMap<String, String>();
			if (null != name) {
				if (null != attribMap.get(name)) {
					LOG.info("Removing attribute name={} value = {}", name, attribMap.get(name));
					attribMap.remove(name);
				}
				LOG.info("Adding as attribute name= {} value = {}", name, value);
				attribMap.put(name, value);
			} else {
				LOG.info("unable to add as attribute name= {} value = ", name, value);
			}
		} catch (Exception e) {
			LOG.error("Exception: {}", e.getMessage(), e);
		}
	}

	public void addAttribIfNotExist(String name, String value) {
		if (attribMap == null)
			attribMap = new LinkedHashMap<String, String>();
		if (null != name) {
			if (!attribMap.containsKey(name)) {
				attribMap.put(name, value);
				LOG.info("Adding: {} = {}", name, value);
			}
		}
	}

	public void addAttribIfExist(String name, String value) {
		if (attribMap == null)
			attribMap = new LinkedHashMap<String, String>();
		if (null != name) {
			if (attribMap.containsKey(value))
				attribMap.remove(name);
			attribMap.put(name, value);
		}
	}

	public void addAllAttrib(Map<String, String> map) {
		if (null == map)
			return;
		Iterator<Map.Entry<String, String>> it = map.entrySet().iterator();
		while (it.hasNext()) {
			Map.Entry<String, String> pairs = (Map.Entry<String, String>) it.next();
			String key = (String) pairs.getKey();
			String value = (String) pairs.getValue();
			addAttrib(key, value);
		}
	}

	public HashSet<ParentEntity> getParentList() {
		addParentToList(new ParentEntity(getEntityType(), getEntityName(), getEntityId(), true));
		return parentList;
	}

	public void addParentToList(ParentEntity parent) {
		if (parentList == null)
			parentList = new HashSet<ParentEntity>();

		parentList.add(parent);
	}

	public ActiveStatus getActiveStatus() {
		return activeStatus;
	}

	public void setActiveStatus(ActiveStatus activeStatus) {
		this.activeStatus = activeStatus;
	}

	public Entity() {
	}

	public Entity(Entity entity) {
		this.activeStatus = entity.activeStatus;

		if (entity.attribMap != null) {
			attribMap = new LinkedHashMap<String, String>();
			attribMap.putAll(entity.attribMap);
		}

		if (entity.parentList != null) {
			parentList = new HashSet<ParentEntity>();
			parentList.addAll(entity.parentList);
		}

		if (entity.skipService != null) {
			skipService = new ArrayList<Service>();
			skipService.addAll(entity.skipService);
		}

	}

	public ParamInfo getParamInfo(String action) {
		return paramInfoTransformer.getAttribParamInfo(getAttribMap(), action);
	}

	public ParamInfo getParamInfo(Entity oldEntity) {
		return paramInfoTransformer.getAttribParamInfo(oldEntity.attribMap, attribMap);
	}

	public boolean isContainer() {
		return false;
	}

	public boolean isDeleteCascade() {
		// Relevant only for containers
		return false;
	}

	public Integer getBroadsoftTNActivation() {
		return broadsoftTNActivation;
	}

	public boolean isBroadsoftTNActivationEnabled() {
		if (null != broadsoftTNActivation) {
			try {
				if (broadsoftTNActivation.intValue() == 1) {
					return true;
				}
			} catch (Exception e) {
				LOG.error("Exception: {}", e.getMessage(), e);
				return false;
			}
		}
		return false;
	}

	public void setBroadsoftTNActivation(Integer broadsoftTNActivation) {
		this.broadsoftTNActivation = broadsoftTNActivation;
	}

	public String getServiceParameter() {
		return serviceParameter;
	}

	public void setServiceParameter(String serviceParameter) {
		this.serviceParameter = serviceParameter;
	}

	/*
	 * public String toString() { StringBuffer buffer = new StringBuffer(); if
	 * (attribMap != null) for (Map.Entry<String, String> entry :
	 * attribMap.entrySet()) {
	 * buffer.append(entry.getKey()).append("=").append(entry.getValue()).append(
	 * "\n"); } buffer.append("action:" + action + "parentList=" + parentList +
	 * ", skipService=" + skipService + ", activeStatus=" + activeStatus +
	 * ", broadsoftTNActivation=" + broadsoftTNActivation + ", serviceParameter=" +
	 * serviceParameter + "]"); buffer.append("hotCutIndicator:" + hotCutIndicator +
	 * ", CDDDIndicator:" + CDDDIndicator); return buffer.toString(); }
	 */

	public OrderAction getAction() {
		return action;
	}

	public void setAction(OrderAction action) {
		this.action = action;
	}

	public boolean isAttribTaskParamsReversed() {
		return attribTaskParamsReversed;
	}

	public void setAttribTaskParamsReversed(boolean attribTaskParamsReversed) {
		this.attribTaskParamsReversed = attribTaskParamsReversed;
	}

	public Boolean getHotCutIndicator() {
		return hotCutIndicator;
	}

	public void setHotCutIndicator(Boolean hotCutIndicator) {
		this.hotCutIndicator = hotCutIndicator;
	}

	public Boolean getCDDDIndicator() {
		return CDDDIndicator;
	}

	public void setCDDDIndicator(Boolean indicator) {
		CDDDIndicator = indicator;
	}

	/*
	 * public void copyDeltaParam(Object oldParam, Object newParam){ if(newParam !=
	 * null) oldParam = newParam; }
	 */

	public void setR2RMigration(Boolean r2r) {
		this.r2rMigration = r2r;
	}

	public Boolean isR2RMigration() {
		if (this.r2rMigration == null)
			return Boolean.FALSE;
		return this.r2rMigration;
	}

}
