package com.vz.esap.translation.order.transformer;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.vz.esap.translation.dao.model.TblEnvOrderDetails;
import com.vz.esap.translation.entity.OrderManagerContactInfoEntity;
import com.vz.esap.translation.exception.GenericException;
import com.vz.esap.translation.order.dao.VOIPOrderDao;

@Component
public class OrderManagerContactInfoTransformerImpl implements OrderManagerContactInfoTransformer {

	@Autowired
	private VOIPOrderDao voipOrderDao;

	private static final Logger LOG = LoggerFactory.getLogger(OrderManagerContactInfoTransformerImpl.class);

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.vz.esap.translation.order.transformer.OrderManagerContactInfoTransformer#
	 * transformValEnvOrderToOrdMgrContactInfo(long, java.lang.String)
	 */
	@Override
	public OrderManagerContactInfoEntity transformValEnvOrderToOrdMgrContactInfo(long envOrderId, String action)
			throws GenericException {

		LOG.info("OrderManagerContactInfoTransformerImpl - transformValEnvOrderToOrdMgrContactInfo");

		OrderManagerContactInfoEntity orderManagerContact = null;
		TblEnvOrderDetails tblEnvOrderDetails = null;
		List<TblEnvOrderDetails> tblEnvOrderDetailsList = null;

		try {
			tblEnvOrderDetails = new TblEnvOrderDetails();
			tblEnvOrderDetails.setEnvOrderId(envOrderId);
			tblEnvOrderDetails.setParentId(0L);
			tblEnvOrderDetails.setAction(action);
			tblEnvOrderDetails.setParamName(null);

			tblEnvOrderDetailsList = voipOrderDao.getEnvOrderDetails(tblEnvOrderDetails);
			// :Todo is tblEnvOrderDetailsList is null exception handling

			orderManagerContact = new OrderManagerContactInfoEntity();

			for (TblEnvOrderDetails tblEnvOrderDetail : tblEnvOrderDetailsList) {
				if (tblEnvOrderDetail.getParamName() != null) {
					if(tblEnvOrderDetail.getParamName().equalsIgnoreCase("OrderManagerPhone")) {
						orderManagerContact.setPhone(tblEnvOrderDetail.getParamValue());
					}
					if (tblEnvOrderDetail.getParamName().equalsIgnoreCase("OrderManagerEmail")) {
						orderManagerContact.setEmail(tblEnvOrderDetail.getParamValue());
					}
					if (tblEnvOrderDetail.getParamName().equalsIgnoreCase("OrderManagerFirstName")) {
						orderManagerContact.setFirstName(tblEnvOrderDetail.getParamValue());
					}
					if (tblEnvOrderDetail.getParamName().equalsIgnoreCase("OrderManagerLastName")) {
						orderManagerContact.setLastName(tblEnvOrderDetail.getParamValue());
					}
				}
			}
		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new GenericException(GenericException.GENERIC_EXCEPTION, "Exception in the provide input arguments");
		}

		return orderManagerContact;
	}

}
