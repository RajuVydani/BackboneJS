package com.vz.esap.translation.order.service;

import java.util.List;
import java.util.Map;

import com.vz.esap.translation.dao.model.TblEnvOrder;
import com.vz.esap.translation.dao.model.TblOrder;
import com.vz.esap.translation.exception.GenericException;
import com.vz.esap.translation.exception.TranslatorException;
import com.vz.esap.translation.order.model.request.VOIPOrderRequest;
import com.vz.esap.translation.order.model.response.VoipOrderResponse;

/**
 * @author chattni
 *
 */
public interface CancelOrderService {

	
	/**
	 * @param voipOrderRequest
	 * @return
	 * @throws TranslatorException
	 * @throws GenericException
	 */
	VoipOrderResponse createCancelWorkOrder(VOIPOrderRequest voipOrderRequest) throws TranslatorException, GenericException;

	
	/**
	 * @param voipOrderRequest
	 * @param tblEnvOrderListOrig
	 * @param tblOrderListOrig
	 * @param tblEnvOrderCurrent
	 * @throws TranslatorException 
	 * @throws GenericException 
	 */
	void createReverseOrder(VOIPOrderRequest voipOrderRequest,
			List<TblOrder> tblOrderListOrig, TblEnvOrder tblEnvOrderCurrent) throws TranslatorException, GenericException;

	
}
