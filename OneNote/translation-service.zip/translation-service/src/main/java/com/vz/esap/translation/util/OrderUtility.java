package com.vz.esap.translation.util;

import java.util.Collection;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Map;

import org.apache.http.client.utils.URIBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.vz.esap.translation.order.model.request.ParamInfo;

import EsapEnumPkg.WorkOrderEnum;

/**
 * @author baigkh
 *
 */
public class OrderUtility {
	
	private static final Logger LOG = LoggerFactory.getLogger(OrderUtility.class);

	/**
	 * @param orderType
	 * @return orderType_ENUM
	 */
	public static long getOrderTypeEnum(char orderType) {
		switch (orderType) {
		case 'I':
			return WorkOrderEnum.OrderType.IN;
		case 'D':
			return WorkOrderEnum.OrderType.OUT;
		case 'C':
			return WorkOrderEnum.OrderType.CHANGE;
		case 'M':
			return WorkOrderEnum.OrderType.ADD_SECOND;
		case 'N':
			return WorkOrderEnum.OrderType.ADD_DELTA;
		case 'X':
			return WorkOrderEnum.OrderType.DELETE_DELTA;
		default:
			return -1;
		}
	}

	/**
	 * @param orderType
	 * @return orderType_ENUM
	 */
	public static String getOrderTypeChar(int orderType) {
		switch (orderType) {
		case WorkOrderEnum.OrderType.IN:
			return "I";
		case WorkOrderEnum.OrderType.OUT:
			return "D";
		case WorkOrderEnum.OrderType.CHANGE:
			return "C";
		case WorkOrderEnum.OrderType.ADD_SECOND:
			return "M";
		case WorkOrderEnum.OrderType.ADD_DELTA:
			return "N";
		case WorkOrderEnum.OrderType.DELETE_DELTA:
			return "X";
		default:
			return null;
		}
	}

	/**
	 * @param centrexType
	 * @param nocase
	 * @param vals
	 * @return boolean
	 */
	public static boolean isOneOf(String centrexType, boolean nocase, String... vals) {
		if (vals == null) {
			return false;
		}
		for (String nextone : vals) {
			if ((centrexType == null && nextone == null) || (centrexType != null && nextone != null)
					&& (nocase ? nextone.equalsIgnoreCase(centrexType) : nextone.equals(centrexType))) {
				return true;
			}
		}
		return false;
	}

	/**
	 * @param attribMap
	 * @param action
	 * @return root
	 */
	public static ParamInfo getAttribParamInfo(LinkedHashMap<String, String> attribMap, String action) {
		if (attribMap == null) {
			return null;
		}
		ParamInfo root = new ParamInfo("AdditionalAttribs", null, action);
		for (Map.Entry<String, String> attrib : attribMap.entrySet()) {
			root.addChildParam(new ParamInfo(attrib.getKey(), attrib.getValue(), action));
		}
		return root;
	}

	/**
	 * @param strList
	 * @param action
	 * @param parentName
	 * @param childName
	 * @return root
	 */
	public static ParamInfo getCollectionParamInfo(HashSet<String> strList, String action, String parentName,
			String childName) {
		if (strList == null) {
			return null;
		}
		ParamInfo root = new ParamInfo(parentName, null, action);
		for (String str : strList) {
			root.addChildParam(new ParamInfo(childName, str, action));
		}
		return root;
	}

	public static ParamInfo getNonPkgParamInfo(Collection<String> features, String action) {
		return getCollectionParamInfo(features, action, "NonPkgFeatures", "NonPkgFeature");
	}

	public static ParamInfo getCollectionParamInfo(Collection<String> strList, String action, String parentName,
			String childName) {
		if (strList == null)
			return null;

		ParamInfo root = new ParamInfo(parentName, null, action);

		for (String str : strList)
			root.addChildParam(new ParamInfo(childName, str, action));

		return root;
	}

	/*
	 * March Voip Feature Enhancement Changes
	 */

	public static ParamInfo getUserFeatInfo(Collection<String> features, String action) {
		return getCollectionParamInfo(features, action, "UserFeatures", "UserFeature");
	}

	/**
	 * @param val
	 * @return Boolean
	 */
	public static Boolean getBooleanFromYN(String val) {
		
		if (val == null)
			return false;
		else if ("Y".equalsIgnoreCase(val))
			return true;
		else
			return false;
	}

	/**
	 * @param bool
	 * @return String
	 */
	public static String booleanToStr(Boolean bool) {
		if (bool == null)
			return null;
		else
			return bool ? "Y" : "N";
	}

	/**
	 * @param Long
	 * @return String
	 */
	public static String longToString(Long val) {
		if (val == null)
			return null;
		return Long.toString(val);
	}

	/**
	 * @param val
	 * @return
	 */
	public static Long getLongFromString(String val) {
		
		if (val == null)
			return null;
		long lval = Long.decode(val);
		
		if (lval <= 0) 
			return null;
		else 
			return lval;
	}

/*	public static void main(String[] args) {
		
		Map<String, String> pathvar = new HashMap<>();
		pathvar.put("EnterpriseId", "142425");
		pathvar.put("locationContextPath", "location");
		
		Map<String, String> queryParam = new HashMap<>();
		queryParam.put("name", "Nily");
		queryParam.put("age", "22");
		
		System.out.println(createUrl("Http", "localHost:9809", "/bw/enterprise", pathvar, queryParam));
	}
	*/
	
	/**
	 * @param protocol
	 * @param hostPort
	 * @param contextUri
	 * @param pathvar
	 * @param queryParam
	 * @return
	 */
	public static String createUrl(String protocol, String hostPort, String contextUri, Map<String, String> pathvar,
			Map<String, String> queryParam) {
		LOG.info("Entered createUrl");

		StringBuilder resultantPath = new StringBuilder();
		resultantPath.append(contextUri);
		
		String url = null;

		/*for (Map.Entry<String, String> pathVarEntry : pathvar.entrySet()) {
			resultantPath.append("/" + pathVarEntry.getValue());
		}*/
		
		resultantPath.append("/" + pathvar.get("EnterpriseId"));
		resultantPath.append("/" + pathvar.get("locationContextPath"));

		URIBuilder builder = new URIBuilder();
		builder.setScheme(protocol);
		builder.setHost(hostPort);
		builder.setPath(resultantPath.toString());

		if (queryParam != null) {
			for (Map.Entry<String, String> queryParamEntry : queryParam.entrySet()) {
				builder.addParameter(queryParamEntry.getKey(), queryParamEntry.getValue());
			}
		}

		url = builder.toString();
		
		LOG.info("Exit createUrl with URL = {}", url);
		return url;
	}
}
