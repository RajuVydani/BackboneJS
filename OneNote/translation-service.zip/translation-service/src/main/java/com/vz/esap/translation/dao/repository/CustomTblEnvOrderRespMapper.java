package com.vz.esap.translation.dao.repository;

import com.vz.esap.translation.dao.model.TblEnvOrderResp;

public interface CustomTblEnvOrderRespMapper {

	void insertTblEnvOrderRespData(TblEnvOrderResp tblEnvOrderResp);
}