package com.vz.esap.translation.dao.repository;

import java.util.Map;

import org.springframework.stereotype.Component;

import com.vz.esap.translation.order.model.request.OrderParam;

@Component
public interface ProcLorUsNonTsoMapper extends TblLorTnDetailsMapper {
	 
	/*@Select(value = {
			"{ call ESAP.LOR_US_NON_TSO ( #{in_order_number, mode=IN, jdbcType=VARCHAR, javaType=String },"
			+ "  #{in_order_version, mode=IN, jdbcType=VARCHAR, javaType=String},"
			+ "  #{t_cnt, mode=OUT, jdbcType=NUMERIC, javaType=Integer} ) }" })
	@Options(statementType = StatementType.CALLABLE)*/
	public Integer getServiceCapIdCount(OrderParam params);
	public Integer getReserveTNObjects(Map<String, Object> params);
	public void getChangedTnDetails(OrderParam params);

}
