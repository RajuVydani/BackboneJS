package com.vz.esap.translation.order.transformer;

import java.util.List;
import java.util.Map;

import com.vz.esap.translation.entity.NbsEntity;
import com.vz.esap.translation.exception.ApplicationInterfaceException;
import com.vz.esap.translation.exception.GenericException;
import com.vz.esap.translation.exception.TranslatorException;
import com.vz.esap.translation.order.model.request.VOIPOrderRequest;

/**
 * @author kalagsu
 *
 */
public interface NbsTransformer {

	/**
	 * @param orderId
	 * @param parentId
	 * @param action
	 * @param delta
	 * @return nbsEntity
	 * @throws TranslatorException
	 */
	NbsEntity transformOrderDetailsToNbs(long orderId, long parentId, String action, boolean delta, List<String> paramActionExclusionList)
			throws TranslatorException;

	/**
	 * 
	 * @param voipOrderRequest
	 * @param nbsEntity
	 * @return
	 * @throws TranslatorException
	 * @throws GenericException
	 * @throws IllegalAccessException
	 * @throws ApplicationInterfaceException
	 */
	NbsEntity enrichNbsEntityWithInventory(VOIPOrderRequest voipOrderRequest, NbsEntity nbsEntity)
			throws TranslatorException, GenericException, IllegalAccessException, ApplicationInterfaceException;

	/**
	 * 
	 * @param resultantRow
	 * @return
	 */
	NbsEntity nbsEntityInventoryToNbsEntityTransformer(Map<String, String> resultantRow);

}
