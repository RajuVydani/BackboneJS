package com.vz.esap.translation.order.parser;

import java.text.ParseException;
import java.util.ArrayList;

import com.vz.esap.translation.entity.DeviceEntity;
import com.vz.esap.translation.exception.TranslatorException;
import com.vz.esap.translation.order.model.request.VOIPOrderRequest;

public interface DeviceOrderParser {
	
	/**
	 * @param voipOrderRequest
	 * @return deviceList
	 * @throws TranslatorException
	 * @throws ParseException
	 */
	public ArrayList<DeviceEntity> parseDeviceOrder(VOIPOrderRequest voipOrderRequest) throws TranslatorException, ParseException;

}
