package com.vz.esap.translation.order.transformer;

import java.math.BigInteger;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static java.util.Arrays.stream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.vz.esap.translation.dao.model.TblOrder;
import com.vz.esap.translation.entity.AccountAuthCode;
import com.vz.esap.translation.entity.AuthService;
import com.vz.esap.translation.entity.AccountAuthCode.CodeType;
import com.vz.esap.translation.entity.DeviceEntity;
import com.vz.esap.translation.entity.ECMInfo;
import com.vz.esap.translation.entity.LocationEntity;
import com.vz.esap.translation.entity.LocationEntity.TypeOfLocEnum;
import com.vz.esap.translation.entity.VmAccess;
import com.vz.esap.translation.enums.EsapEnum;
import com.vz.esap.translation.enums.EsapEnum.AuthFeatureType;
import com.vz.esap.translation.enums.EsapEnum.Language;
import com.vz.esap.translation.enums.EsapEnum.LocationType;
import com.vz.esap.translation.enums.EsapEnum.SolutionType;
import com.vz.esap.translation.enums.EsapEnum.VoipServiceType;
import com.vz.esap.translation.exception.GenericException;
import com.vz.esap.translation.exception.TranslatorException;
import com.vz.esap.translation.exception.TranslatorException.ErrorCode;
import com.vz.esap.translation.order.entity.identifier.util.EntityIdentifireUtil;
import com.vz.esap.translation.order.model.Order;
import com.vz.esap.translation.order.model.request.DigitString;
import com.vz.esap.translation.order.model.request.Feature;
import com.vz.esap.translation.order.model.request.ParamInfo;
import com.vz.esap.translation.order.model.request.Specification;
import com.vz.esap.translation.order.model.request.VOIPOrderRequest;
import com.vz.esap.translation.util.InventoryUtil;
import com.vz.esap.translation.util.OrderUtility;

/**
 * @author chattni
 *
 */
@Component
public class LocationTblOrderDetailsDataTransformerImpl implements LocationTblOrderDetailsDataTransformer {

	private static final Logger LOG = LoggerFactory.getLogger(LocationTblOrderDetailsDataTransformerImpl.class);

	private static final String LOCATION_ID = "LocationId";
	private static final String CUSTOMER_ID = "CustomerId";
	private static final String REGION = "Region";
	private static final String BS_APP_SERVER = "BsAppServer";
	private static final String ADMIN_LASTNAME = "AdminLastName";
	private static final String CONFIG_CPLAN = "CONFIG_CPLAN";
	private static final String HOT_CUT_IND = "HotCutIndicator";
	private static final String CDD_IND = "CDDDIndicator";
	private static final String SIPCLIENT = "SIPCLIENT";
	private static final String ACTION = "Action";

	@Autowired
	private EntityIdentifireUtil entityIdentifireUtil;

	@Autowired
	private InventoryUtil inventoryUtil;
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.vz.esap.translation.order.transformer.
	 * LocationTblOrderDetailsDataTransformer#
	 * prepareTblOrderDetailsEntityParamDataForLocation(com.vz.esap.translation.
	 * order.model.Order)
	 */
	@Override
	public ParamInfo prepareTblOrderDetailsEntityParamDataForLocation(Order order, String action) {
		LOG.info("Entered - prepareTblOrderDetailsEntityParamDataForLocation(order, action)");

		if (action == null)
			action = order.getOrderHeader().getOrderType();

		ParamInfo root = new ParamInfo("Location", null, action);

		// ADD VCE PARAM
		if (order.getLocation().getVce() != null) {
			root.addNotNullValChild("VCE", order.getLocation().getVce(), action);
		}
		root.addNotNullValChild(LOCATION_ID, order.getLocation().getLocationId(), action, ParamInfo.Tag.ID);
		root.addNotNullValChild(CUSTOMER_ID, order.getLocation().getCustomerId(), action, ParamInfo.Tag.ID);
		if (order.getOrderHeader().getRegion() != null)
			root.addNotNullValChild(REGION, order.getOrderHeader().getRegion(), action);
		else if (order.getLocation().getRegion() != null)
			root.addNotNullValChild(REGION, order.getLocation().getRegion(), action);
		root.addNotNullValChild("Description", order.getLocation().getDescription(), action);
		root.addNotNullValChild("VARRS", order.getLocation().getVARRS(), action);
		root.addNotNullValChild("MarketType", order.getLocation().getMarketType(), action);
		root.addNotNullValChild("Name", order.getLocation().getName(), action, ParamInfo.Tag.NAME);
		root.addNotNullValChild("Address", order.getLocation().getAddress(), action);
		root.addNotNullValChild("City", order.getLocation().getCity(), action);
		root.addNotNullValChild("State", order.getLocation().getState(), action);
		root.addNotNullValChild("Zip", order.getLocation().getZip(), action);
		root.addNotNullValChild("Country", order.getLocation().getCountry(), action);
		root.addNotNullValChild("TimeZone", order.getLocation().getTimeZone(), action);
		root.addNotNullValChild("DaylightSavingInd", order.getLocation().getDaylightSavingInd(), action);
		root.addNotNullValChild("WebLanguage", order.getLocation().getWebLanguage(), action);
		root.addNotNullValChild("VmLanguage", order.getLocation().getVmLanguage(), action);
		root.addNotNullValChild("ContactName", order.getLocation().getContactName(), action);
		root.addNotNullValChild("ContactPhone", order.getLocation().getContactPhone(), action);
		root.addNotNullValChild("ContactEmail", order.getLocation().getContactEmail(), action);
		root.addNotNullValChild("AcctTeamName", order.getLocation().getAcctTeamName(), action);
		root.addNotNullValChild("AcctTeamPhone", order.getLocation().getAcctTeamPhone(), action);
		root.addNotNullValChild("AcctTeamEmail", order.getLocation().getAcctTeamEmail(), action);
		root.addNotNullValChild("SipDomain", order.getLocation().getSipDomain(), action);
		root.addNotNullValChild("ParentDomain", order.getLocation().getParentDomain(), action);
		root.addNotNullValChild("BillingType", order.getLocation().getBillingType(), action);
		root.addNotNullValChild("PhysicalLocationId", order.getLocation().getPhysicalLocationId(), action);
		root.addNotNullValChild("PhysicalLocationName", order.getLocation().getPhysicalLocationName(), action);
		root.addNotNullValChild("CallForwardPlanName", order.getLocation().getCallForwardPlanName(), action);
		root.addNotNullValChild("DialingCountryCode", order.getLocation().getDialingCountryCode(), action);
		root.addNotNullValChild("MaxConcurrentCalls", order.getLocation().getMaxConcurrentCalls(), action);
		root.addNotNullValChild("MaxConcurrentOffNet", order.getLocation().getMaxConcurrentOffNet(), action);
		root.addNotNullValChild("MaxConcurrentSlg", order.getLocation().getMaxConcurrentSlg(), action);
		root.addNotNullValChild("MaxConcurrentInbound", order.getLocation().getMaxConcurrentInbound(), action);
		root.addNotNullValChild("MaxNg", order.getLocation().getMaxNg(), action);
		root.addNotNullValChild("ServiceLevel", order.getLocation().getServiceLevel(), action);
		root.addNotNullValChild("PrivateNumberLength", order.getLocation().getPrivateNumberLength(), action);
		root.addNotNullValChild("NpaNxx", order.getLocation().getNpaNxx(), action);
		root.addNotNullValChild("AccessType", order.getLocation().getAccessType(), action);
		root.addNotNullValChild("AccessCategory", order.getLocation().getAccessCategory(), action);
		root.addNotNullValChild("SbcAccessType", order.getLocation().getSbcAccessType(), action);
		root.addNotNullValChild("VpnName", order.getLocation().getVpnName(), action);
		root.addNotNullValChild("ESBCSignalingIP", order.getLocation().getEsbcSignalingIP(), action);
		root.addNotNullValChild("CircuitId", order.getLocation().getCircuitId(), action);
		root.addNotNullValChild("EnterpriseTrunkId", order.getLocation().getEnterpriseTrunkId(), action);
		root.addNotNullValChild("PQInstanceId", order.getLocation().getPqInstanceId(), action);
		root.addNotNullValChild("DesignId", order.getLocation().getDesignId(), action);
		root.addNotNullValChild("TypeOfMigration", order.getLocation().getMigrationType(), action);
		// R10 changes
		if (order.getLocation().getCountry() != null && order.getLocation().getCountry().equals("DE")) {
			root.addNotNullValChild("EmergencyNumber", order.getLocation().getEmerNumber(), action);
			root.addNotNullValChild("EmergencyMappingCode", order.getLocation().getEmerMappingCode(), action);
			root.addNotNullValChild("AddressId", order.getLocation().getAddressID(), action);
			root.addNotNullValChild("EmerLocationCodeId", order.getLocation().getEmerLocationCodeId(), action);
		}
		if (null != order.getLocation().getPreselectedVpnName()
				&& order.getLocation().getPreselectedVpnName().isEmpty()) {
			ParamInfo vpnnames = new ParamInfo("PRESELECTED_VPNNAME", null, action);
			for (String vpnname : order.getLocation().getPreselectedVpnName()) {
				if (null != vpnname && vpnname.trim().length() > 0)
					vpnnames.addNotNullValChild(vpnname, "", action, (ParamInfo.Tag) null);
			}
			root.addChildParam(vpnnames);
		}
		root.addNotNullValChild("LocationComment", order.getLocation().getLocationComment(), action);
		root.addNotNullValChild("AdvantageClub", order.getLocation().getAdvantageClub(), action);
		root.addNotNullValChild("NetcomSvcId", order.getLocation().getNetcomSvcId(), action);
		root.addNotNullValChild("ManagedFlag", order.getLocation().getManagedFlag(), action);
		root.addNotNullValChild("UunetSiteId", order.getLocation().getUunetSiteId(), action);
		root.addNotNullValChild("TotalSubscribers", order.getLocation().getTotalSubscribers(), action);
		root.addNotNullValChild("TotalVoiceMailAccts", order.getLocation().getTotalVoiceMailAccts(), action);
		root.addNotNullValChild("TotalPublicNumbers", order.getLocation().getTotalPublicNumbers(), action);
		root.addNotNullValChild("QosIndicator", order.getLocation().getQosIndicator(), action);
		root.addNotNullValChild("IxPlusID", order.getLocation().getIxPlusID(), action);
		root.addNotNullValChild("IxPlusRegion", order.getLocation().getIxPlusRegion(), action);
		root.addNotNullValChild("EmergencyCallLine", order.getLocation().getEmergencyCallLine(), action);
		root.addNotNullValChild("CallingPartyNumber", order.getLocation().getCallingPartyNumber(), action);
		root.addNotNullValChild("CallingPartyPrivacy", order.getLocation().getCallingPartyPrivacy(), action);
		root.addNotNullValChild("StationLevelId", order.getLocation().getStationLevelId(), action);
		root.addNotNullValChild("PendingRPID", order.getLocation().getPendingRPID(), action);
		root.addNotNullValChild("OverrideSubPrivate", booleanToStr(order.getLocation().getOverrideSubPrivate()),
				action);
		root.addNotNullValChild("OverrideCidName", booleanToStr(order.getLocation().getOverrideCidName()), action);
		root.addNotNullValChild("OverrideCidNum", order.getLocation().getOverrideCidNum(), action);
		root.addNotNullValChild(BS_APP_SERVER, order.getLocation().getBsAppServer(), action);
		root.addNotNullValChild("ExtensionLength", order.getLocation().getExtensionLength(), action);
		root.addNotNullValChild("Clin", order.getLocation().getClin(), action);
		root.addNotNullValChild("Cv2Service", order.getLocation().getCv2Service(), action);
		root.addNotNullValChild("VoipServiceType", order.getLocation().getVoipServiceType(), action);
		root.addNotNullValChild("LocationType", order.getLocation().getLocationType(), action);
		root.addNotNullValChild("HybridServiceType", order.getLocation().getHybridServiceType(), action);
		root.addNotNullValChild("IsPureHipcLocation", order.getLocation().isPureHipcLocation(), action);
		root.addNotNullValChild("LinePortLength", order.getLocation().getLinePortLength(), action);
		root.addNotNullValChild("EnableCallPark", order.getLocation().getEnableCallPark(), action);
		if (order.getLocation().getVmSmdiAuthToggle() != null)
			root.addNotNullValChild("PremiseVMSMDI", order.getLocation().getVmSmdiAuthToggle(), action);
		if (order.getLocation().getEnableAccountCode() != null)
			root.addNotNullValChild("EnableAccountCode", order.getLocation().getEnableAccountCode(), action);
		if (order.getLocation().getEnableAuthCode() != null)
			root.addNotNullValChild("EnableAuthCode", order.getLocation().getEnableAuthCode(), action);
		if (order.getLocation().getPubIp() != null)
			root.addNotNullValChild("PubIp", order.getLocation().getPubIpStr(), action);
		if (order.getLocation().getPubIpIn() != null)
			root.addNotNullValChild("PubIpIn", order.getLocation().getPubIpInStr(), action);
		if (order.getLocation().getPubIpOut() != null)
			root.addNotNullValChild("PubIpOut", order.getLocation().getPubIpOutStr(), action);
		// ------XO Attributes-----
		root.addNotNullValChild("EnterpriseId", order.getOrderHeader().getEnterpriseId(), action);
		root.addNotNullValChild("AdminFirstName", order.getLocation().getAdminFirstName(), action);
		root.addNotNullValChild(ADMIN_LASTNAME, order.getLocation().getAdminLastName(), action);
		root.addNotNullValChild("AdminEmail", order.getLocation().getAdminEmail(), action);
		root.addNotNullValChild("AdminWebLoginId", order.getLocation().getAdminWebLoginId(), action);
		root.addNotNullValChild("AdminPassword", order.getLocation().getAdminPassword(), action);
		root.addNotNullValChild(ADMIN_LASTNAME, order.getLocation().getAdminLastName(), action);
		root.addNotNullValChild("DomainName", order.getLocation().getDomainName(), action);
		root.addNotNullValChild("BillingTN", order.getLocation().getBillingTN(), action);
		root.addNotNullValChild("BroadworksPortalNumber", order.getLocation().getBroadworksPortalNumber(), action);
		root.addNotNullValChild("GroupUserLimit", order.getLocation().getGroupUserLimit(), action);
		root.addNotNullValChild("Redundency", order.getLocation().getRedundancy(), action);
		root.addNotNullValChild("RedundencyId", order.getLocation().getRedundancyId(), action);
		root.addNotNullValChild("RedundancyPriorityType", order.getLocation().getRedundancyPriorityType(), action);
		root.addNotNullValChild("TNQuantity", order.getLocation().getTnQuantity(), action);
		root.addNotNullValChild("BWEnterpriseId", order.getLocation().getBwEnterpriseId(), action);
		root.addNotNullValChild("BsTimeZone", order.getLocation().getBsTimeZone(), action);
		root.addNotNullValChild("VpnPortSpeed", order.getLocation().getVpnPortSpeed(), action);
		root.addNotNullValChild("PortSpeed", order.getLocation().getPortSpeed(), action);
		root.addNotNullValChild("VpnPortType", order.getLocation().getVpnPortType(), action);
		root.addNotNullValChild("VgeCont", order.getLocation().getVgeCont(), action);

		root.addNotNullValChild("MaxActiveCalls", order.getLocation().getMaxActiveCalls(), action);
		root.addNotNullValChild("MaxActiveIncomingCalls", order.getLocation().getMaxActiveIncomingCalls(), action);
		root.addNotNullValChild("MaxActiveOutgoingCalls", order.getLocation().getMaxActiveOutgoingCalls(), action);

		if (order.getLocation().getAuthServices() != null) {
			for (Map.Entry<String, Boolean> entry : order.getLocation().getAuthServices().entrySet()) {
				ParamInfo locFeat = new ParamInfo("LocationFeature", null, action);
				locFeat.addNotNullValChild("Name", entry.getKey(), action);
				locFeat.addNotNullValChild("Feature", entry.getKey(), action);
				locFeat.addNotNullValChild("Authorized", OrderUtility.booleanToStr(entry.getValue()) , action);
				root.addChildParam(locFeat);
			}
		}
		
		if (order.getLocation().getAuthServices() != null) {
			for (Map.Entry<String, Boolean> entry : order.getLocation().getAuthServices().entrySet()) {
				ParamInfo locFeat = new ParamInfo("AuthService", null, action);
				locFeat.addNotNullValChild("Name", entry.getKey(), action);				
				locFeat.addNotNullValChild("Authorized", OrderUtility.booleanToStr(entry.getValue()) , action);
				root.addChildParam(locFeat);
			}
		}
		
		if (order.getLocation().getAuthService() != null) {
			for (AuthService authServiceList : order.getLocation().getAuthService()) {
				ParamInfo locFeat = new ParamInfo("LocationFeature", null, action);
				locFeat.addNotNullValChild("Name", authServiceList.getName(), action);	
				locFeat.addNotNullValChild("Feature", authServiceList.getName(), action);	
				locFeat.addNotNullValChild("FeatureQuantity", authServiceList.getFeatureQuantity(), action);		
				locFeat.addNotNullValChild("Authorised", OrderUtility.booleanToStr(authServiceList.getAuthorise()) , action);
				root.addChildParam(locFeat);
			}
		}
		
		if (order.getLocation().getSession() != null) {
			ParamInfo sessionParam = new ParamInfo("Session", null, action);
			// Start EBL
			sessionParam.addChildParam(new ParamInfo("SessionId",
					String.valueOf(order.getLocation().getSession().getInstanceId()), action));
			// End EBL
			sessionParam.addChildParam(
					new ParamInfo("Quantity", String.valueOf(order.getLocation().getSession().getQuantity()), action));
			sessionParam
					.addChildParam(new ParamInfo("PortSpeed", order.getLocation().getSession().getPortSpeed(), action));
			sessionParam.addChildParam(
					new ParamInfo("CompressionType", order.getLocation().getSession().getCompressionType(), action));
			sessionParam.addChildParam(
					new ParamInfo("MaxQuantity", order.getLocation().getSession().getMaxQuantity(), action));

			root.addChildParam(sessionParam, ParamInfo.Tag.NON_ORD);
		}
		// Start EBL
				
		if (order.getLocation().getBwLocationId() != null) {			
			root.addNotNullValChild("BWLocationId", order.getLocation().getBwLocationId(), action);
			root.addNotNullValChild("EslId", order.getLocation().getBwLocationId(), action);			
			
		} else if(order.getLocation().getEslId() != null){
			root.addNotNullValChild("EslId", order.getLocation().getEslId(), action);
			root.addNotNullValChild("BWLocationId", order.getLocation().getEslId(), action);

		} else {
			root.addNotNullValChild("BWLocationId", order.getLocation().getLocationId(), action);

		}
		
		if (order.getLocation().getPreBuildLocId() != null)
			root.addNotNullValChild("PreBuildLocId", order.getLocation().getPreBuildLocId(), action);
		
		if (order.getLocation().getEblId() != null)
			root.addNotNullValChild("EblId", order.getLocation().getEblId(), action);
		if (order.getLocation().getTypeOfLoc() != null)
			root.addNotNullValChild("TypeOfLoc", order.getLocation().getTypeOfLoc(), action);
		if (order.getLocation().getHubLocationId() != null)
			root.addChildParam(new ParamInfo("HubLocationId", order.getLocation().getHubLocationId(), action));
		// End EBL
		// ------XO Attributes-----
		if (order.getLocation().getHubGatewayDeviceId() > 0)
			root.addChildParam(new ParamInfo("HubGatewayDeviceId",
					String.valueOf(order.getLocation().getHubGatewayDeviceId()), action));
		if (null != order.getLocation().getLocationMask() && order.getLocation().getLocationMask() > 0)
			root.addChildParam(
					new ParamInfo("LocationMask", String.valueOf(order.getLocation().getLocationMask()), action));
		if (null != order.getLocation().getaNumMask() && order.getLocation().getaNumMask() > 0)
			root.addNotNullValChild("ANumMask", String.valueOf(order.getLocation().getaNumMask()), action);
		if (null != order.getLocation().getbNumMask() && order.getLocation().getbNumMask() > 0)
			root.addNotNullValChild("BNumMask", String.valueOf(order.getLocation().getbNumMask()), action);
		if (order.getLocation().getCallingPlan() != null) {
			if ("I".equalsIgnoreCase(action))
				root.addChildParam(new ParamInfo(CONFIG_CPLAN, "ADD", action, ParamInfo.Tag.WF));
			else if ("O".equalsIgnoreCase(action))
				root.addChildParam(new ParamInfo(CONFIG_CPLAN, "DEL", action, ParamInfo.Tag.WF));
		}
		Map<String, BigInteger> featurePackageMap = order.getLocation().getFeaturePackage();
		if (featurePackageMap != null) {
			for (String name : featurePackageMap.keySet()) {
				ParamInfo fpParam = new ParamInfo("FeaturePackage", (String) null, action);
				fpParam.addChildParam(new ParamInfo("Name", name, action));
				fpParam.addChildParam(new ParamInfo("VmBoxSize", featurePackageMap.get(name).toString(), action));
				root.addChildParam(fpParam);
			}
		}
		ArrayList<VmAccess> vmaList = order.getLocation().getVmAccessList();
		if (vmaList != null) {
			LOG.info("Add [{}] VM Access", vmaList.size());
			String publicNumber = null;
			String privateNumber = null;
			String subscriberId = null;
			if (vmaList.isEmpty())
				if ("I".equalsIgnoreCase(action))
					root.addChildParam(new ParamInfo("VMA", "ADD", action, ParamInfo.Tag.WF));
				else if ("O".equalsIgnoreCase(action))
					root.addChildParam(new ParamInfo("VMA", "DEL", action, ParamInfo.Tag.WF));
			for (int i = 0; i < vmaList.size(); i++) {
				publicNumber = vmaList.get(i).getPublicNumber();
				privateNumber = vmaList.get(i).getPrivateNumber();
				subscriberId = vmaList.get(i).getSubscriberId();

				ParamInfo vmaParam = new ParamInfo("VoiceMailAccess", (String) null, action);
				vmaParam.addNotNullValChild("PublicNumber", publicNumber, action);
				vmaParam.addNotNullValChild("PrivateNumber", privateNumber, action);
				vmaParam.addNotNullValChild("SubscriberId", subscriberId, action);
				root.addChildParam(vmaParam);
			}
		}
		// IR #1076573
		ArrayList<AccountAuthCode> acctAccountAuthCodes = order.getLocation().getAccountAuthCodes();
		if (acctAccountAuthCodes != null) {
			LOG.info("Add [{}] AcctAuthCode", acctAccountAuthCodes);
			String acctAuthCode = null;
			String acctAuthDesc = null;
			CodeType codeType = null;
			for (AccountAuthCode accountAuthCode : acctAccountAuthCodes) {
				acctAuthCode = accountAuthCode.getCode();
				acctAuthDesc = accountAuthCode.getDescription();
				codeType = accountAuthCode.getCodeType();
				ParamInfo acctAuthCodeParam = new ParamInfo("AccountAuthCode", (String) null, action);
				acctAuthCodeParam.addNotNullValChild("Code", acctAuthCode, action);
				acctAuthCodeParam.addNotNullValChild("Desc", acctAuthDesc, action);
				acctAuthCodeParam.addNotNullValChild("Type", codeType, action);
				root.addChildParam(acctAuthCodeParam);
			}
		}
		ArrayList<String> ppName = order.getLocation().getPrefixPlanName();
		if (order.getLocation().getPrefixPlanName() != null) {
			ParamInfo ppnParam = new ParamInfo("PrefixPlan", (String) null, action);
			for (String ppNameStr : ppName) {
				ppnParam.addChildParam(new ParamInfo("PrefixPlanName", ppNameStr, action));
			}
			root.addChildParam(ppnParam);
		}

		ArrayList<DeviceEntity> devices = order.getLocation().getDevices();
		if (devices != null) {
			for (DeviceEntity device : devices) {
				ParamInfo dvParam = new ParamInfo("CpeGatewayDevice", (String) null, action);
				if (null != action && "I".equals(action)) {
					LOG.info("LocationUtil.getParamInfo.action for I ==> {}", action);
					dvParam.addNotNullValChild(ACTION, "I", action);
				} else if (null != action && "C".equals(action)) {
					LOG.info("LocationUtil.getParamInfo.action for C ==> {}", action);
					dvParam.addNotNullValChild(ACTION, "C", action);
				} else if (null != action && "O".equals(action)) {
					LOG.info("LocationUtil.getParamInfo.action for O ==> {}", action);
					dvParam.addNotNullValChild(ACTION, "O", action);
				}
				root.addChildParam(dvParam);
			}
		}
		/** SBC Changes */
		if (order.getLocation().getSipClientEnabledFlag() != null) {
			if (order.getLocation().getSipClientEnabledFlag().equalsIgnoreCase("Y"))
				root.addChildParam(new ParamInfo(SIPCLIENT, "ENABLE", action, ParamInfo.Tag.WF));
			else if (order.getLocation().getSipClientEnabledFlag().equalsIgnoreCase("N"))
				root.addChildParam(new ParamInfo(SIPCLIENT, "DISABLE", action, ParamInfo.Tag.WF));

			ParamInfo sbcRoot = new ParamInfo("SBC", null, action);

			if (order.getLocation().getSipClientEnabledFlag() != null)
				sbcRoot.addChildParam(
						new ParamInfo("SipClientEnabledFlag", order.getLocation().getSipClientEnabledFlag(), action));
			if (order.getLocation().getStrCustFqdn() != null)
				sbcRoot.addNotNullValChild("CustFqdn", order.getLocation().getStrCustFqdn(), action);
			if (order.getLocation().getStrCustIpAddr() != null)
				sbcRoot.addChildParam(new ParamInfo("CustIpAddr", order.getLocation().getStrCustIpAddr(), action));
			if (order.getLocation().getIntCustPort() != 0)
				sbcRoot.addChildParam(
						new ParamInfo("CustPort", ((Integer) order.getLocation().getIntCustPort()).toString(), action));

			root.addChildParam(sbcRoot);
		}
		if (order.getLocation().getDigitStrings() != null) {
			for (DigitString ds : order.getLocation().getDigitStrings())
				root.addChildParam(ds.getParamInfo(action));
		}
		root.addNotNullValChild("SbcEnabled", booleanToStr(order.getLocation().getSbcEnabled()), action);
		root.addNotNullValChild("SbcProvMethod", order.getLocation().getSbcProvMethod(), action);
		root.addNotNullValChild("SipClientEnabled", order.getLocation().getSipClientEnabledFlag(), action);
		if (order.getLocation().getBillingActivated() != null) {
			LOG.info("BillingActivated: " + (order.getLocation().getBillingActivated().booleanValue() ? "Y" : "N")
					+ " action: " + action);
			root.addNotNullValChild("BillingActivated", order.getLocation().getBillingActivated() != null
					&& order.getLocation().getBillingActivated().booleanValue() ? "Y" : "N", action);
		}
		if (order.getLocation().getHotCutIndicator() != null
				&& order.getLocation().getHotCutIndicator() == Boolean.TRUE)
			root.addNotNullValChild(HOT_CUT_IND, "Y", action);
		if (order.getLocation().getCDDDIndicator() != null && order.getLocation().getCDDDIndicator() == Boolean.TRUE)
			root.addNotNullValChild(CDD_IND, "Y", action);
		if (order.getLocation().getGcmInfo() != null) {
			root.addNotNullValChild("GCMInfo", order.getLocation().getGcmInfo(), action);
		}
		if (null != order.getLocation().getEcmInfo()) {
			for (ECMInfo ecmInfo : order.getLocation().getEcmInfo())
				root.addNotNullValChild("ECMInfo", ecmInfo.getParamInfo(action), action);
		}
		if (null != order.getLocation().getTsoMigrationLocReferenceData()) {
			root.addChildParam(order.getLocation().getTsoMigrationLocReferenceData().getParamInfo());

		}
		if (order.getLocation().getIsE2E() != null && order.getLocation().getIsE2E().equals(Boolean.TRUE))
			root.addNotNullValChild("isE2E", "Y", action);
		LOG.info("Exit - prepareTblOrderDetailsEntityParamDataForLocation");
		return root;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.vz.esap.translation.order.transformer.
	 * LocationTblOrderDetailsDataTransformer#prepareTblOrderDetailsHeaderParamData(
	 * com.vz.esap.translation.order.model.Order)
	 */
	@Override
	public ParamInfo prepareTblOrderDetailsHeaderParamData(Order order) throws ParseException, TranslatorException {

		LOG.info("Entered - prepareTblOrderDetailsHeaderParamData");
		ParamInfo root = null;
		String action = null;
		try {
			action = order.getOrderHeader().getOrderType();

			root = new ParamInfo("Header", null, action);
			root.addNotNullValChild("OrderNumber", order.getOrderHeader().getOrderNumber(), action);
			root.addNotNullValChild("EnvOrderId", order.getOrderHeader().getEnvOrderId(), action);
			root.addNotNullValChild("MasterOrderNumber", order.getOrderHeader().getMasterOrderNumber(), action);
			root.addNotNullValChild("OrderVersion", order.getOrderHeader().getOrderVersion(), action);
			root.addNotNullValChild("TransactionId", order.getOrderHeader().getTransactionId(), action);
			root.addNotNullValChild(REGION, order.getOrderHeader().getRegion(), action);
			root.addNotNullValChild("MinorOrderType", order.getOrderHeader().getMinorOrderType(), action);
			root.addNotNullValChild("CentrexType", order.getOrderHeader().getCentrexType(), action);
			root.addNotNullValChild("ServiceType", order.getOrderHeader().getServiceType(), action);
			root.addNotNullValChild("OriginatingSystem", order.getOrderHeader().getOriginatingSystem(), action);
			root.addNotNullValChild("InterfaceSystem", order.getOrderHeader().getInterfaceSystem(), action);
			root.addNotNullValChild("OrderType",
					EsapEnum.OrderType.getValue(order.getOrderHeader().getOrderType().charAt(0)), action);
			root.addNotNullValChild("SuppType", order.getOrderHeader().getSuppType(), action);
			root.addNotNullValChild("OrderClassify", order.getOrderHeader().getFunctionCode(), action);

			if (order.getOrderHeader().getDueDate() != null) {
				SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
				Calendar calendar = GregorianCalendar.getInstance();
				calendar.setTime(format.parse(order.getOrderHeader().getDueDate().toString()));
				Object dueDate = calendar.getTime();
				root.addNotNullValChild("DueDate", dueDate, action);
			}

			if (order.getLocation().getCustomerId() != null)
				root.addNotNullValChild(CUSTOMER_ID, order.getLocation().getCustomerId(), action);
			else if (order.getOrderHeader().getCustomerId() != null)
				root.addNotNullValChild(CUSTOMER_ID, order.getOrderHeader().getCustomerId(), action);

						
			root.addNotNullValChild(LOCATION_ID, order.getOrderHeader().getLocationId(), action);
			root.addNotNullValChild(BS_APP_SERVER, order.getLocation().getBsAppServer(), action);
			root.addNotNullValChild("OrderProTIN", order.getOrderHeader().getOrderProTIN(), action);
			root.addNotNullValChild("IOrderTIN", order.getOrderHeader().getiOrderTIN(), action);
			root.addNotNullValChild("TINVersion", order.getOrderHeader().getTinVersion(), action);
			root.addNotNullValChild("TransitionFlag", order.getOrderHeader().isTransitionFlag() ? "Y" : "N", action);
			root.addNotNullValChild("Priority", order.getOrderHeader().getPriority(), action);
			if (order.getLocation().getAuthFeatureType() != null)
				root.addNotNullValChild("AuthFeatureType", order.getLocation().getAuthFeatureType().toString(), action);
			if (order.getOrderHeader().getAttribMap() != null) {
				root.addChildParam(OrderUtility.getAttribParamInfo(order.getOrderHeader().getAttribMap(), action));
			}
			if (order.getOrderHeader().getOrderCreatedBy() != null)
				root.addNotNullValChild("OrderCreatedBy", order.getOrderHeader().getOrderCreatedBy(), action);
			if (order.getOrderHeader().isHasBulkOrder()) {
				root.addNotNullValChild("BULK", "Y", action);
			}
			if (order.getOrderHeader().getHotCutIndicator() != null) {
				root.addNotNullValChild(HOT_CUT_IND, "Y", action);
			}
			if (order.getOrderHeader().getCDDDIndicator() != null) {
				root.addNotNullValChild(CDD_IND, "Y", action);
			}
		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new TranslatorException(ErrorCode.TRANSFORMER_FAILURE,
					"Exception occured in prepareTblOrderDetailsHeaderParamData");
		}
		LOG.info("Exit prepareTblOrderDetailsHeaderParamData");
		return root;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.vz.esap.translation.order.transformer.
	 * LocationTblOrderDetailsDataTransformer#
	 * prepareTblOrderDetailsEntityParamDataForLocation(com.vz.esap.translation.
	 * order.model.request.VOIPOrderRequest,
	 * com.vz.esap.translation.dao.model.TblOrder,
	 * com.vz.esap.translation.entity.LocationEntity)
	 */
	@Override
	public ParamInfo prepareTblOrderDetailsEntityParamDataForLocation(VOIPOrderRequest voipOrderRequest,
			TblOrder tblOrderObject, LocationEntity location, String action) throws GenericException {
		LOG.info("Entered - prepareTblOrderDetailsEntityParamDataForLocation(voipOrderRequest, tblOrderObject, location, action)");

		if (action == null)
			voipOrderRequest.getOrderHeader().getOrderType();

		ParamInfo root = new ParamInfo("Location", null, action);

		// ADD VCE PARAM
		if (location.getVce() != null) {
			root.addNotNullValChild("VCE", location.getVce(), action);
		}
		root.addNotNullValChild(LOCATION_ID, location.getLocationId(), action, ParamInfo.Tag.ID);

		if (location.getCustomerId() != null)
			root.addNotNullValChild(CUSTOMER_ID, location.getCustomerId(), action);
		if (voipOrderRequest.getOrderHeader().getEnterpriseId() != null)
			root.addNotNullValChild(CUSTOMER_ID, voipOrderRequest.getOrderHeader().getEnterpriseId(), action);

		root.addNotNullValChild("Description", location.getDescription(), action);
		if (voipOrderRequest.getOrderHeader().getRegion() != null)
			root.addNotNullValChild(REGION, voipOrderRequest.getOrderHeader().getRegion(), action);
		else if (location.getRegion() != null)
			root.addNotNullValChild(REGION, location.getRegion(), action);
		else if (voipOrderRequest.getLocation() != null && voipOrderRequest.getLocation().getLocationAddress() != null
				&& voipOrderRequest.getLocation().getLocationAddress().getCountryCode() != null)
			root.addNotNullValChild(REGION, voipOrderRequest.getLocation().getLocationAddress().getCountryCode(),
					action);
		root.addNotNullValChild("VARRS", location.getVARRS(), action);
		root.addNotNullValChild("MarketType", location.getMarketType(), action);
		root.addNotNullValChild("Name", location.getName(), action, ParamInfo.Tag.NAME);
		root.addNotNullValChild("Address", location.getAddress(), action);
		root.addNotNullValChild("City", location.getCity(), action);
		root.addNotNullValChild("State", location.getState(), action);
		root.addNotNullValChild("Zip", location.getZip(), action);
		root.addNotNullValChild("Country", location.getCountry(), action);
		root.addNotNullValChild("TimeZone", location.getTimeZone(), action);
		root.addNotNullValChild("DaylightSavingInd", location.getDaylightSavingInd(), action);

		if (location.getWebLanguage() != null && location.getWebLanguage().contains("English (US)")) {
			root.addNotNullValChild("WebLanguage", Language.US_ENGLISH.ordinal(), action);
			root.addNotNullValChild("VmLanguage", Language.US_ENGLISH.ordinal(), action);
		} else {
			root.addNotNullValChild("WebLanguage", location.getWebLanguage(), action);
			root.addNotNullValChild("VmLanguage", location.getVmLanguage(), action);
		}

		if (location.getAuthFeatureType() != null)
			root.addNotNullValChild("AuthFeatureType", location.getAuthFeatureType().toString(), action);

		root.addNotNullValChild("ContactName", location.getContactName(), action);
		root.addNotNullValChild("ContactPhone", location.getContactPhone(), action);
		root.addNotNullValChild("ContactEmail", location.getContactEmail(), action);
		root.addNotNullValChild("AcctTeamName", location.getAcctTeamName(), action);
		root.addNotNullValChild("AcctTeamPhone", location.getAcctTeamPhone(), action);
		root.addNotNullValChild("AcctTeamEmail", location.getAcctTeamEmail(), action);
		root.addNotNullValChild("SipDomain", location.getSipDomain(), action);
		root.addNotNullValChild("ParentDomain", location.getParentDomain(), action);
		root.addNotNullValChild("BillingType", location.getBillingType(), action);
		root.addNotNullValChild("PhysicalLocationId", location.getPhysicalLocationId(), action);
		root.addNotNullValChild("PhysicalLocationName", location.getPhysicalLocationName(), action);
		root.addNotNullValChild("CallForwardPlanName", location.getCallForwardPlanName(), action);
		root.addNotNullValChild("DialingCountryCode", location.getDialingCountryCode(), action);
		root.addNotNullValChild("MaxConcurrentCalls", location.getMaxConcurrentCalls(), action);
		root.addNotNullValChild("MaxConcurrentOffNet", location.getMaxConcurrentOffNet(), action);
		root.addNotNullValChild("MaxConcurrentSlg", location.getMaxConcurrentSlg(), action);
		root.addNotNullValChild("MaxConcurrentInbound", location.getMaxConcurrentInbound(), action);
		root.addNotNullValChild("MaxNg", location.getMaxNg(), action);
		root.addNotNullValChild("LocationCclIndicator", location.getLocationCclIndicator(), action);
		root.addNotNullValChild("ServiceLevel", location.getServiceLevel(), action);
		root.addNotNullValChild("PrivateNumberLength", location.getPrivateNumberLength(), action);
		root.addNotNullValChild("NpaNxx", location.getNpaNxx(), action);
		root.addNotNullValChild("AccessType", location.getAccessType(), action);
		root.addNotNullValChild("AccessCategory", location.getAccessCategory(), action);
		root.addNotNullValChild("SbcAccessType", location.getSbcAccessType(), action);
		root.addNotNullValChild("VpnName", location.getVpnName(), action);
		root.addNotNullValChild("CircuitId", location.getCircuitId(), action);
		root.addNotNullValChild("EnterpriseTrunkId", location.getEnterpriseTrunkId(), action);
		root.addNotNullValChild("PQInstanceId", location.getPqInstanceId(), action);
		root.addNotNullValChild("DesignId", location.getDesignId(), action);
		root.addNotNullValChild("TypeOfMigration", location.getMigrationType(), action);
		// R10 changes
		if (location.getCountry() != null && location.getCountry().equals("DE")) {
			root.addNotNullValChild("EmergencyNumber", location.getEmerNumber(), action);
			root.addNotNullValChild("EmergencyMappingCode", location.getEmerMappingCode(), action);
			root.addNotNullValChild("AddressId", location.getAddressID(), action);
			root.addNotNullValChild("EmerLocationCodeId", location.getEmerLocationCodeId(), action);
		}
		if (null != location.getPreselectedVpnName() && location.getPreselectedVpnName().isEmpty()) {
			ParamInfo vpnnames = new ParamInfo("PRESELECTED_VPNNAME", null, action);
			for (String vpnname : location.getPreselectedVpnName()) {
				if (null != vpnname && vpnname.trim().length() > 0)
					vpnnames.addNotNullValChild(vpnname, "", action, (ParamInfo.Tag) null);
			}
			root.addChildParam(vpnnames);
		}
		root.addNotNullValChild("LocationComment", location.getLocationComment(), action);
		root.addNotNullValChild("AdvantageClub", location.getAdvantageClub(), action);
		root.addNotNullValChild("NetcomSvcId", location.getNetcomSvcId(), action);
		root.addNotNullValChild("ManagedFlag", location.getManagedFlag(), action);
		root.addNotNullValChild("UunetSiteId", location.getUunetSiteId(), action);
		root.addNotNullValChild("TotalSubscribers", location.getTotalSubscribers(), action);
		root.addNotNullValChild("TotalVoiceMailAccts", location.getTotalVoiceMailAccts(), action);
		root.addNotNullValChild("TotalPublicNumbers", location.getTotalPublicNumbers(), action);
		root.addNotNullValChild("QosIndicator", location.getQosIndicator(), action);
		root.addNotNullValChild("IxPlusID", location.getIxPlusID(), action);
		root.addNotNullValChild("IxPlusRegion", location.getIxPlusRegion(), action);
		root.addNotNullValChild("EmergencyCallLine", location.getEmergencyCallLine(), action);
		root.addNotNullValChild("CallingPartyNumber", location.getCallingPartyNumber(), action);
		root.addNotNullValChild("CallingPartyPrivacy", location.getCallingPartyPrivacy(), action);
		root.addNotNullValChild("StationLevelId", location.getStationLevelId(), action);
		root.addNotNullValChild("PendingRPID", location.getPendingRPID(), action);
		root.addNotNullValChild(BS_APP_SERVER, location.getBsAppServer(), action);
		root.addNotNullValChild("AsClli", voipOrderRequest.getOrderHeader().getAsClli(), action);
		root.addNotNullValChild("ExtensionLength", location.getExtensionLength(), action);
		root.addNotNullValChild("Clin", location.getClin(), action);
		root.addNotNullValChild("Cv2Service", location.getCv2Service(), action);
		root.addNotNullValChild("VoipServiceType", location.getVoipServiceType(), action);
		root.addNotNullValChild("LocationType", location.getLocationType(), action);
		root.addNotNullValChild("HybridServiceType", location.getHybridServiceType(), action);
		root.addNotNullValChild("IsPureHipcLocation", booleanToStr(location.isPureHipcLocation()), action);
		root.addNotNullValChild("LinePortLength", location.getLinePortLength(), action);
		if (location.getEnableCallPark() != null)
			root.addChildParam(new ParamInfo("EnableCallPark", booleanToStr(location.getEnableCallPark()), action)); // enums??
		if (location.getVmSmdiAuthToggle() != null)
			root.addChildParam(new ParamInfo("PremiseVMSMDI", booleanToStr(location.getVmSmdiAuthToggle()), action));
		if (location.getEnableAccountCode() != null)
			root.addChildParam(
					new ParamInfo("EnableAccountCode", booleanToStr(location.getEnableAccountCode()), action));
		if (location.getEnableAuthCode() != null)
			root.addChildParam(new ParamInfo("EnableAuthCode", booleanToStr(location.getEnableAuthCode()), action));
		if (location.getPubIp() != null)
			root.addChildParam(new ParamInfo("PubIp", booleanToStr(location.getPubIp()), action));
		if (location.getPubIpIn() != null)
			root.addChildParam(new ParamInfo("PubIpIn", booleanToStr(location.getPubIpIn()), action));
		if (location.getPubIpOut() != null)
			root.addChildParam(new ParamInfo("PubIpOut", booleanToStr(location.getPubIpOut()), action));
		root.addNotNullValChild("BlockAllCalls", booleanToStr(location.getBlockAllCalls()), action); // enums??
		root.addNotNullValChild("Expedite", booleanToStr(location.getExpedite()), action);
		root.addNotNullValChild("HighVolume", booleanToStr(location.getHighVolume()), action);
		root.addNotNullValChild("AfterHourInstallFee", booleanToStr(location.getAfterHourInstallFee()), action);
		root.addNotNullValChild("EnhancedANIInd", booleanToStr(location.getEnhancedANIInd()), action);
		root.addNotNullValChild("STN", location.getsTn(), action);
		root.addNotNullValChild("AlternativeCallerIdFlag", location.getAltCallerIdFlag(), action);
		root.addNotNullValChild("CallingNameInd", booleanToStr(location.getCallingNameInd()), action);
		root.addNotNullValChild("SubAgencyHierCode", location.getSubAgencyHierCode(), action);
		root.addNotNullValChild("LocalDirAssistance", location.getLocalDirAssistance(), action);
		root.addNotNullValChild("NatDirAssistance", location.getNatDirAssistance(), action);
		root.addNotNullValChild("CidTn", location.getCidTn(), action);
		root.addNotNullValChild("TrunkType", location.getTrunkType(), action);
		root.addNotNullValChild("SwitchClli", location.getSwitchClli(), action);
		root.addNotNullValChild("Trunk", location.getTrunk(), action);
		root.addNotNullValChild("SiebelOrder", location.getSiebelOrder(), action);
		root.addNotNullValChild("BillAcctNum", location.getBillAcctNum(), action);
		root.addNotNullValChild("PublicGtwyDpid", location.getPublicGtwyDpid(), action);
		root.addNotNullValChild("DefaultGtwyDpid", location.getDefaultGtwyDpid(), action);
		root.addNotNullValChild("AbbrDialingCode", location.getAbbrDialingCode(), action);
		root.addNotNullValChild("VmType", location.getVmType(), action);
		root.addNotNullValChild("VmCpeIpAddress", location.getVmCpeIpAddress(), action);
		root.addNotNullValChild("EmerLocationCode", location.getEmerLocationCode(), action);
		root.addNotNullValChild("ProductionIndicator", location.getProductionIndicator(), action);
		root.addNotNullValChild("IASAOrderId", location.getIasaOrderId(), action);
		root.addNotNullValChild("Territory", location.getTerritory(), action);
		root.addNotNullValChild("LocRegion", location.getLocRegion(), action);
		root.addNotNullValChild("BillingSystem", location.getBillingSystem(), action);
		root.addNotNullValChild("PBBAN", location.getPBBAN(), action);
		root.addNotNullValChild("TransportType", location.getTransportType(), action);
		root.addNotNullValChild("PrefixPlanId", location.getPrefixPlanId(), action);
		root.addNotNullValChild("ProductId", location.getProductId(), action);
		root.addNotNullValChild("ConfigAllowed", location.getConfigAllowed(), action);
		// ------XO Attributes-----
		// location.getEslId() + ".vm.xohost.com"
		
		String bwEnterpriseId = null;
		List<Specification> bwEntIdSpec = null;
		List<Feature> entFeat = null;
		List<Feature> hpbxPreBuiltLocFeat = null;
		
		if (voipOrderRequest.getConvergedService() != null
				&& voipOrderRequest.getConvergedService().getFeature() != null) {
			
			entFeat = stream(voipOrderRequest.getConvergedService().getFeature())
					.filter(feat -> "EFET_VOIP_ENT_LVL".equalsIgnoreCase(feat.getCode())).collect(Collectors.toList());

			if (!CollectionUtils.isEmpty(entFeat)) {

				bwEntIdSpec = stream(entFeat.get(0).getSpecification())
						.filter(spec -> "BW_ENTERPRISE_ID".equalsIgnoreCase(spec.getCode()))
						.collect(Collectors.toList());
			}
			
			hpbxPreBuiltLocFeat = stream(voipOrderRequest.getConvergedService().getFeature())
					.filter(feature -> feature.getCode().equalsIgnoreCase("FET_HPBX_LOC_LVL_LOC")
							|| feature.getCode().equalsIgnoreCase("FET_HPBX_LOC_LVL"))
					.collect(Collectors.toList());
		
			
			if (!CollectionUtils.isEmpty(hpbxPreBuiltLocFeat) && location.getBwLocationId() != null
					&& location.getLocationId() != null
					&& !location.getBwLocationId().equalsIgnoreCase(location.getLocationId())) {
				for (Feature locFeat : hpbxPreBuiltLocFeat) {
					if (location.getLocationId().equalsIgnoreCase(locFeat.getInstanceId())) {
						root.addNotNullValChild("ProvisionCategory", "INV_ONLY", action);

					}
				}
			}	
			
			if(TypeOfLocEnum.HPBX_EBL.equals(location.getTypeOfLoc())) {
				root.addNotNullValChild("ProvisionCategory", "INV_ONLY", action);
			}
		}
		
		if(!CollectionUtils.isEmpty(bwEntIdSpec)) {			
			bwEnterpriseId = bwEntIdSpec.get(0).getValue();
		} else if (SolutionType.HPBX.equals(voipOrderRequest.getOrderHeader().getSolutionType())) {
			Map<String, String> resultmap = inventoryUtil.getTblEnterpriseFromEnterpriseId(location.getCustomerId(),
					null, null);

			bwEnterpriseId = resultmap.get("BW_ENTERPRISE_ID");

		} else {
			bwEnterpriseId = entityIdentifireUtil.createBwEnterpriseId(voipOrderRequest.getOrderHeader().getGCHId(),
					voipOrderRequest.getOrderHeader().getSolutionType(), null,
					voipOrderRequest.getOrderHeader().getEnterpriseId());
		}
		
		String domainName = null;
		if (location.getAuthFeatureType() != null && AuthFeatureType.FET_HPBX.equals(location.getAuthFeatureType())) {

			domainName = entityIdentifireUtil.getHpbxDomainName();

		} else {
			domainName = bwEnterpriseId.toLowerCase() + ".vm.xohost.com";
		}
		
		root.addNotNullValChild("EnterpriseId", voipOrderRequest.getOrderHeader().getEnterpriseId(), action);

		if (location.getEslId() != null) {
			root.addNotNullValChild("AdminFirstName", location.getEslId().toLowerCase(), action);
			root.addNotNullValChild(ADMIN_LASTNAME, location.getEslId().toLowerCase(), action);
			root.addNotNullValChild("AdminEmail", location.getEslId() + "@" + domainName, action);
			root.addNotNullValChild("AdminWebLoginId", location.getEslId() + "@" + domainName, action);
			root.addNotNullValChild("AdminPassword", location.getEslId().toLowerCase(), action);
			root.addNotNullValChild(ADMIN_LASTNAME, location.getEslId().toLowerCase(), action);
		} else {
			root.addNotNullValChild("AdminFirstName", location.getLocationId().toLowerCase(), action);
			root.addNotNullValChild(ADMIN_LASTNAME, location.getLocationId().toLowerCase(), action);
			root.addNotNullValChild("AdminEmail", location.getLocationId() + "@" + domainName, action);
			root.addNotNullValChild("AdminWebLoginId", location.getLocationId() + "@" + domainName, action);
			root.addNotNullValChild("AdminPassword", location.getLocationId().toLowerCase(), action);
			root.addNotNullValChild(ADMIN_LASTNAME, location.getLocationId().toLowerCase(), action);
		}

		root.addNotNullValChild("DomainName", domainName, action);
		root.addNotNullValChild("BillingTN", location.getBillingTN(), action);
		root.addNotNullValChild("BroadworksPortalNumber", location.getBroadworksPortalNumber(), action);
		root.addNotNullValChild("GroupUserLimit", location.getGroupUserLimit(), action);
		root.addNotNullValChild("Redundency", location.getRedundancy(), action);
		root.addNotNullValChild("RedundencyId", location.getRedundancyId(), action);
		root.addNotNullValChild("RedundancyPriorityType", location.getRedundancyPriorityType(), action);
		root.addNotNullValChild("TNQuantity", location.getTnQuantity(), action);
		root.addNotNullValChild("BWEnterpriseId", location.getBwEnterpriseId(), action);
		root.addNotNullValChild("BsTimeZone", location.getBsTimeZone(), action);
		root.addNotNullValChild("VpnPortSpeed", location.getVpnPortSpeed(), action);
		root.addNotNullValChild("PortSpeed", location.getPortSpeed(), action);
		root.addNotNullValChild("VpnPortType", location.getVpnPortType(), action);
		root.addNotNullValChild("VgeCont", location.getVgeCont(), action);

		root.addNotNullValChild("MaxActiveCalls", location.getMaxActiveCalls(), action);
		root.addNotNullValChild("MaxActiveIncomingCalls", location.getMaxActiveIncomingCalls(), action);
		root.addNotNullValChild("MaxActiveOutgoingCalls", location.getMaxActiveOutgoingCalls(), action);
		root.addNotNullValChild("ESBCSignalingIP", location.getEsbcSignalingIP(), action);

		if (location.getAuthServices() != null) {
			for (Map.Entry<String, Boolean> entry : location.getAuthServices().entrySet()) {
				ParamInfo locFeat = new ParamInfo("LocationFeature", null, action);
				locFeat.addNotNullValChild("Feature", entry.getKey(), action);
				locFeat.addNotNullValChild("DeltaCount", entry.getValue(), action);
				root.addChildParam(locFeat);
			}
		}
		
		//Feature Quantity changes		
		if(location.getAuthService() != null) {
			for(AuthService authService : location.getAuthService()) {
				ParamInfo locAuth = new ParamInfo("LocationFeature", null, action);
				locAuth.addNotNullValChild("Name", authService.getName(), action);
				locAuth.addNotNullValChild("Feature", authService.getName(), action);
				locAuth.addNotNullValChild("FeatureQuantity", authService.getFeatureQuantity(), action);
				locAuth.addNotNullValChild("Authorised", authService.getAuthorise(), action);
				root.addChildParam(locAuth);
			}
		}

		if (location.getSession() != null) {
			ParamInfo sessionParam = new ParamInfo("Session", null, action);

			sessionParam.addChildParam(
					new ParamInfo("SessionId", String.valueOf(location.getSession().getInstanceId()), action));
			sessionParam.addChildParam(
					new ParamInfo("Quantity", String.valueOf(location.getSession().getQuantity()), action));
			sessionParam.addChildParam(new ParamInfo("PortSpeed", location.getSession().getPortSpeed(), action));
			sessionParam.addChildParam(
					new ParamInfo("CompressionType", location.getSession().getCompressionType(), action));
			sessionParam.addChildParam(new ParamInfo("MaxQuantity", location.getSession().getMaxQuantity(), action));

			root.addChildParam(sessionParam, ParamInfo.Tag.NON_ORD);
		}
		
				
		if (location.getBwLocationId() != null && location.getEslId() != null) {			
			root.addNotNullValChild("BWLocationId", location.getBwLocationId(), action);
			root.addNotNullValChild("EslId", location.getEslId(), action);
			
		} else if(location.getBwLocationId() == null && location.getEslId() != null){
			root.addNotNullValChild("EslId", location.getEslId(), action);
			root.addNotNullValChild("BWLocationId", location.getEslId(), action);
			
		} else if (location.getBwLocationId() != null && location.getVoipServiceType() != null
				&& VoipServiceType.HOSTED_PBX.toString().equals(location.getVoipServiceType())) {
			root.addNotNullValChild("BWLocationId", location.getBwLocationId(), action);
			
		} else {
			root.addNotNullValChild("BWLocationId", location.getLocationId(), action);
		}
			
		if (location.getPreBuildLocId() != null)
			root.addNotNullValChild("PreBuildLocId", location.getPreBuildLocId(), action);

		if (location.getTypeOfLoc() != null)
			root.addNotNullValChild("TypeOfLoc", location.getTypeOfLoc(), action);
		// End EBL
		// ------XO Attributes-----
		if (location.getHubGatewayDeviceId() > 0)
			root.addChildParam(
					new ParamInfo("HubGatewayDeviceId", String.valueOf(location.getHubGatewayDeviceId()), action));
		if (null != location.getLocationMask() && location.getLocationMask() > 0)
			root.addChildParam(new ParamInfo("LocationMask", String.valueOf(location.getLocationMask()), action));
		if (null != location.getaNumMask() && location.getaNumMask() > 0)
			root.addNotNullValChild("ANumMask", location.getaNumMask(), action);
		if (null != location.getbNumMask() && location.getbNumMask() > 0)
			root.addNotNullValChild("BNumMask", location.getbNumMask(), action);
		if (location.getCallingPlan() != null) {
			if ("I".equalsIgnoreCase(action))
				root.addChildParam(new ParamInfo(CONFIG_CPLAN, "ADD", action, ParamInfo.Tag.WF));
			else if ("O".equalsIgnoreCase(action))
				root.addChildParam(new ParamInfo(CONFIG_CPLAN, "DEL", action, ParamInfo.Tag.WF));
		}
		Map<String, BigInteger> featurePackageMap = location.getFeaturePackage();
		if (featurePackageMap != null) {
			for (String name : featurePackageMap.keySet()) {
				ParamInfo fpParam = new ParamInfo("FeaturePackage", (String) null, action);
				fpParam.addChildParam(new ParamInfo("Name", name.toString(), action));
				fpParam.addChildParam(new ParamInfo("VmBoxSize", featurePackageMap.get(name).toString(), action));
				root.addChildParam(fpParam);
			}
		}
		ArrayList<VmAccess> vmaList = location.getVmAccessList();
		if (vmaList != null) {
			LOG.info("Add [{}] VM Access", vmaList.size());
			String publicNumber = null;
			String privateNumber = null;
			String subscriberId = null;
			if (vmaList.isEmpty())
				if ("I".equalsIgnoreCase(action))
					root.addChildParam(new ParamInfo("VMA", "ADD", action, ParamInfo.Tag.WF));
				else if ("O".equalsIgnoreCase(action))
					root.addChildParam(new ParamInfo("VMA", "DEL", action, ParamInfo.Tag.WF));

			for (int i = 0; i < vmaList.size(); i++) {
				publicNumber = vmaList.get(i).getPublicNumber();
				privateNumber = vmaList.get(i).getPrivateNumber();
				subscriberId = vmaList.get(i).getSubscriberId();

				ParamInfo vmaParam = new ParamInfo("VoiceMailAccess", (String) null, action);
				vmaParam.addNotNullValChild("PublicNumber", publicNumber, action);
				vmaParam.addNotNullValChild("PrivateNumber", privateNumber, action);
				vmaParam.addNotNullValChild("SubscriberId", subscriberId, action);
				root.addChildParam(vmaParam);
			}
		}
		// IR #1076573
		ArrayList<AccountAuthCode> acctAccountAuthCodes = location.getAccountAuthCodes();
		if (acctAccountAuthCodes != null) {
			LOG.info("Add [{}] AcctAuthCode", acctAccountAuthCodes);
			String acctAuthCode = null;
			String acctAuthDesc = null;
			CodeType codeType = null;
			for (AccountAuthCode accountAuthCode : acctAccountAuthCodes) {
				acctAuthCode = accountAuthCode.getCode();
				acctAuthDesc = accountAuthCode.getDescription();
				codeType = accountAuthCode.getCodeType();
				ParamInfo acctAuthCodeParam = new ParamInfo("AccountAuthCode", (String) null, action);
				acctAuthCodeParam.addNotNullValChild("Code", acctAuthCode, action);
				acctAuthCodeParam.addNotNullValChild("Desc", acctAuthDesc, action);
				acctAuthCodeParam.addNotNullValChild("Type", codeType, action);
				root.addChildParam(acctAuthCodeParam);
			}
		}
		ArrayList<String> ppName = location.getPrefixPlanName();
		if (location.getPrefixPlanName() != null) {
			ParamInfo ppnParam = new ParamInfo("PrefixPlan", (String) null, action);
			for (String ppNameStr : ppName) {
				ppnParam.addChildParam(new ParamInfo("PrefixPlanName", ppNameStr, action));
			}
			root.addChildParam(ppnParam);
		}
		ArrayList<DeviceEntity> devices = location.getDevices();
		if (devices != null) {
			for (DeviceEntity device : devices) {
				ParamInfo dvParam = new ParamInfo("CpeGatewayDevice", (String) null, action);
				if (null != action && "I".equals(action)) {
					LOG.info("LocationUtil.getParamInfo.action for I ==> {}", action);
					dvParam.addNotNullValChild(ACTION, "I", action);
				} else if (null != action && "C".equals(action)) {
					LOG.info("LocationUtil.getParamInfo.action for C ==> {}", action);
					dvParam.addNotNullValChild(ACTION, "C", action);
				} else if (null != action && "O".equals(action)) {
					LOG.info("LocationUtil.getParamInfo.action for O ==> {}", action);
					dvParam.addNotNullValChild(ACTION, "O", action);
				}
				root.addChildParam(dvParam);
			}
		}
		/** SBC Changes */
		if (location.getSipClientEnabledFlag() != null) {
			if (location.getSipClientEnabledFlag().equalsIgnoreCase("Y"))
				root.addChildParam(new ParamInfo(SIPCLIENT, "ENABLE", action, ParamInfo.Tag.WF));
			else if (location.getSipClientEnabledFlag().equalsIgnoreCase("N"))
				root.addChildParam(new ParamInfo(SIPCLIENT, "DISABLE", action, ParamInfo.Tag.WF));

			ParamInfo sbcRoot = new ParamInfo("SBC", null, action);

			if (location.getSipClientEnabledFlag() != null)
				sbcRoot.addChildParam(
						new ParamInfo("SipClientEnabledFlag", location.getSipClientEnabledFlag(), action));

			if (location.getStrCustFqdn() != null)
				sbcRoot.addChildParam(new ParamInfo("CustFqdn", location.getStrCustFqdn(), action));

			if (location.getStrCustIpAddr() != null)
				sbcRoot.addChildParam(new ParamInfo("CustIpAddr", location.getStrCustIpAddr(), action));

			if (location.getIntCustPort() != 0)
				sbcRoot.addChildParam(
						new ParamInfo("CustPort", ((Integer) location.getIntCustPort()).toString(), action));

			root.addChildParam(sbcRoot);
		}
		if (location.getTypeOfLoc() != null)
			root.addChildParam(new ParamInfo("TypeOfLoc", location.getTypeOfLoc().toString(), action));
		if (location.getHubLocationId() != null)
			root.addChildParam(new ParamInfo("HubLocationId", location.getHubLocationId(), action));
		if (location.getFmcLocation() != null)
			root.addChildParam(new ParamInfo("FmcLocation", location.getFmcLocation(), action));
		if (location.getDigitStrings() != null) {
			for (DigitString ds : location.getDigitStrings())
				root.addChildParam(ds.getParamInfo(action));
		}
		root.addNotNullValChild("SbcEnabled",

				booleanToStr(location.getSbcEnabled()), action);
		root.addNotNullValChild("SbcProvMethod", location.getSbcProvMethod(), action);
		root.addNotNullValChild("SipClientEnabled", location.getSipClientEnabledFlag(), action);

		if (location.getBillingActivated() != null) {
			LOG.info("BillingActivated: {} action {} " ,(location.getBillingActivated().booleanValue() ? "Y" : "N") , action);
			root.addNotNullValChild("BillingActivated",
					location.getBillingActivated() != null && location.getBillingActivated().booleanValue() ? "Y" : "N",
					action);
		}
		if (location.getHotCutIndicator() != null && location.getHotCutIndicator() == Boolean.TRUE)
			root.addNotNullValChild(HOT_CUT_IND, "Y", action);
		if (location.getCDDDIndicator() != null && location.getCDDDIndicator() == Boolean.TRUE)
			root.addNotNullValChild(CDD_IND, "Y", action);
		if (location.getGcmInfo() != null) {
			root.addNotNullValChild("GCMInfo", location.getGcmInfo(), action);
		}
		if (null != location.getEcmInfo()) {
			for (ECMInfo ecmInfo : location.getEcmInfo())
				root.addNotNullValChild("ECMInfo", ecmInfo.getParamInfo(action), action);
		}
		if (null != location.getTsoMigrationLocReferenceData()) {
			root.addChildParam(location.getTsoMigrationLocReferenceData().getParamInfo());

		}
		if (location.getIsE2E() != null && location.getIsE2E().equals(Boolean.TRUE))
			root.addNotNullValChild("isE2E", "Y", action);

		if (location.getCircuitId() != null) {
			root.addChildParam(new ParamInfo("CircuitId", location.getCircuitId(), action));
		}
		if (location.getVpnName() != null) {
			root.addChildParam(new ParamInfo("VpnName", location.getVpnName(), action));
		}
		LOG.info("Exit - prepareTblOrderDetailsEntityParamDataForLocation");

		return root;

	}

	/**
	 * @param bool
	 * @return boolean
	 */
	public static String booleanToStr(Boolean bool) {
		if (bool == null)
			return null;
		else
			return bool ? "Y" : "N";
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.vz.esap.translation.order.transformer.
	 * LocationTblOrderDetailsDataTransformer#
	 * prepareTblOrderDetailsEntityParamDataForLocation(com.vz.esap.translation.
	 * entity.LocationEntity, com.vz.esap.translation.entity.LocationEntity,
	 * boolean, java.lang.String)
	 */
	@Override
	public ParamInfo prepareTblOrderDetailsEntityParamDataForLocation(LocationEntity oldLoc, LocationEntity newLoc,
			boolean change, String action) {
		LOG.info("Entering prepareTblOrderDetailsEntityParamDataForLocation(old, new, supp) CHANGE value: {}", change);

		ParamInfo locParam = new ParamInfo("Location", null, null);

		if (oldLoc.getLocationId() != null)
			locParam.addChildParam(new ParamInfo("LocationId", oldLoc.getLocationId().toString(), null));

		boolean modProp = false;
		ArrayList<ParamInfo> pi = null;
		locParam.addChangeParam("LocationId", oldLoc.getLocationId(), oldLoc.getLocationId(), change, ParamInfo.Tag.ID);
		locParam.addChangeParam("CustomerId", oldLoc.getCustomerId(), oldLoc.getCustomerId(), change);
		locParam.addChangeParam("Description", oldLoc.getDescription(), oldLoc.getDescription(), change);
		locParam.addChangeParam("MarketType", oldLoc.getMarketType(), newLoc.getMarketType(), change);
		locParam.addChangeParam("VoipServiceType", oldLoc.getVoipServiceType(), newLoc.getVoipServiceType(), change);
		locParam.addChangeParam("LocationType", oldLoc.getLocationType(), newLoc.getLocationType(), change);
		String hybridSvcAction = locParam.addChangeParamReturnAction("HybridServiceType", oldLoc.getHybridServiceType(),
				newLoc.getHybridServiceType(), change, null);
		locParam.addChangeParam("IsPureHipcLocation", booleanToStr(oldLoc.isPureHipcLocation()),
				booleanToStr(newLoc.isPureHipcLocation()), change);
		locParam.addChangeParam("Name", oldLoc.getName(), oldLoc.getName(), change, ParamInfo.Tag.ID);
		locParam.addChangeParam("Address", oldLoc.getAddress(), newLoc.getAddress(), change);
		locParam.addChangeParam("ProductId", oldLoc.getProductId(), newLoc.getProductId(), change);
		locParam.addChangeParam("City", oldLoc.getCity(), newLoc.getCity(), change);
		locParam.addChangeParam("State", oldLoc.getState(), newLoc.getState(), change);
		locParam.addChangeParam("Zip", oldLoc.getZip(), newLoc.getZip(), change);
		locParam.addChangeParam("Country", oldLoc.getCountry(), newLoc.getCountry(), change);
		locParam.addChangeParam(REGION, oldLoc.getRegion(), newLoc.getRegion(), change);
		locParam.addChangeParam("PhysicalLocationId", oldLoc.getPhysicalLocationId(), newLoc.getPhysicalLocationId(),
				change);
		locParam.addChangeParam("PhysicalLocationName", oldLoc.getPhysicalLocationName(),
				newLoc.getPhysicalLocationName(), change);
		locParam.addChangeParam("CallForwardPlanName", oldLoc.getCallForwardPlanName(), newLoc.getCallForwardPlanName(),
				change);
		locParam.addChangeParam("DialingCountryCode", oldLoc.getDialingCountryCode(), newLoc.getDialingCountryCode(),
				change);
		locParam.addChangeParam("EnterpriseTrunkId", oldLoc.getEnterpriseTrunkId(), newLoc.getEnterpriseTrunkId(),
				change);
		locParam.addChangeParam("PQInstanceId", oldLoc.getPqInstanceId(), newLoc.getPqInstanceId(), change);
		locParam.addChangeParam("DesignId", oldLoc.getDesignId(), newLoc.getDesignId(), change);
		locParam.addChangeParam("TypeOfMigration", oldLoc.getMigrationType(), newLoc.getMigrationType(), change);

		String tzAction = locParam.addChangeParamReturnAction("TimeZone", oldLoc.getTimeZone(), oldLoc.getTimeZone(),
				change, null);
		if (tzAction != null) {
			locParam.addNotNullValChild("TZ_CHANGE", "Y", null);
		}
		locParam.addChangeParam("DaylightSavingInd", oldLoc.getDaylightSavingInd(), oldLoc.getDaylightSavingInd(),
				change);
		locParam.addChangeParam("WebLanguage", oldLoc.getWebLanguage(), newLoc.getWebLanguage(), change);
		locParam.addChangeParam("VmLanguage", oldLoc.getVmLanguage(), newLoc.getVmLanguage(), change);
		locParam.addChangeParam("ContactName", oldLoc.getContactName(), newLoc.getContactName(), change);
		locParam.addChangeParam("ContactPhone", oldLoc.getContactPhone(), newLoc.getContactPhone(), change);
		locParam.addChangeParam("ContactEmail", oldLoc.getContactEmail(), newLoc.getContactEmail(), change);
		locParam.addChangeParam("AcctTeamName", oldLoc.getAcctTeamName(), newLoc.getAcctTeamName(), change);
		locParam.addChangeParam("AcctTeamPhone", oldLoc.getAcctTeamPhone(), newLoc.getAcctTeamPhone(), change);
		locParam.addChangeParam("AcctTeamEmail", oldLoc.getAcctTeamEmail(), newLoc.getAcctTeamEmail(), change);

		locParam.addChangeParam("SipDomain", oldLoc.getSipDomain(), newLoc.getSipDomain(), change);
		locParam.addChangeParam("ParentDomain", oldLoc.getParentDomain(), newLoc.getParentDomain(), change);
		locParam.addChangeParam("BillingType", oldLoc.getBillingType(), newLoc.getBillingType(), change);
		pi = locParam.addAndReturnChangeParams("MaxConcurrentCalls", oldLoc.getMaxConcurrentCalls(),
				newLoc.getMaxConcurrentCalls(), change, null);
		if (pi != null && pi.size() > 1)
			modProp = true;
		locParam.addChangeParam("MaxConcurrentOffNet", oldLoc.getMaxConcurrentOffNet(), newLoc.getMaxConcurrentOffNet(),
				change);
		locParam.addChangeParam("MaxConcurrentSlg", oldLoc.getMaxConcurrentSlg(), newLoc.getMaxConcurrentSlg(), change);
		locParam.addChangeParam("MaxConcurrentInbound", oldLoc.getMaxConcurrentInbound(),
				newLoc.getMaxConcurrentInbound(), change);
		locParam.addChangeParam("MaxNg", oldLoc.getMaxNg(), newLoc.getMaxNg(), change);
		
		if(oldLoc.getLocationCclIndicator() != null)
			locParam.addChangeParam("LocationCclIndicator", booleanToStr(oldLoc.getLocationCclIndicator()),
				booleanToStr(newLoc.getLocationCclIndicator()), change);
		else
			locParam.addChangeParam("LocationCclIndicator", booleanToStr(newLoc.getLocationCclIndicator()),
				booleanToStr(newLoc.getLocationCclIndicator()), change);	
		locParam.addChangeParam("ServiceLevel", oldLoc.getServiceLevel(), newLoc.getServiceLevel(), change);
		locParam.addChangeParam("NpaNxx", oldLoc.getNpaNxx(), newLoc.getNpaNxx(), change);
		locParam.addChangeParam("VARRS", oldLoc.getVARRS(), newLoc.getVARRS(), change);
		locParam.addChangeParam("AccessType", oldLoc.getAccessType(), newLoc.getAccessType(), change);
		locParam.addChangeParam("AccessCategory", oldLoc.getAccessCategory(), newLoc.getAccessCategory(), change);
		locParam.addChangeParam("SbcAccessType", oldLoc.getSbcAccessType(), newLoc.getSbcAccessType(), change);
		locParam.addChangeParam("VpnName", oldLoc.getVpnName(), newLoc.getVpnName(), change);
		locParam.addChangeParam("CircuitId", oldLoc.getCircuitId(), newLoc.getCircuitId(), change);
		locParam.addChangeParam("LocationComment", oldLoc.getLocationComment(), newLoc.getLocationComment(), change);
		locParam.addChangeParam("AdvantageClub", oldLoc.getAdvantageClub(), newLoc.getAdvantageClub(), change);

		locParam.addChangeParam("NetcomSvcId", oldLoc.getNetcomSvcId(), newLoc.getNetcomSvcId(), change);
		locParam.addChangeParam("ManagedFlag", oldLoc.getManagedFlag(), newLoc.getManagedFlag(), change);
		locParam.addChangeParam("UunetSiteId", oldLoc.getUunetSiteId(), newLoc.getUunetSiteId(), change);
		locParam.addChangeParam("TotalSubscribers", oldLoc.getTotalSubscribers(), newLoc.getTotalSubscribers(), change);
		locParam.addChangeParam("TotalVoiceMailAccts", oldLoc.getTotalVoiceMailAccts(), newLoc.getTotalVoiceMailAccts(),
				change);
		locParam.addChangeParam("TotalPublicNumbers", oldLoc.getTotalPublicNumbers(), newLoc.getTotalPublicNumbers(),
				change);
		locParam.addChangeParam("IxPlusID", oldLoc.getIxPlusID(), newLoc.getIxPlusID(), change);
		locParam.addChangeParam("IxPlusRegion", oldLoc.getIxPlusRegion(), newLoc.getIxPlusRegion(), change);
		locParam.addChangeParam("CallingPartyNumber", oldLoc.getCallingPartyNumber(), newLoc.getCallingPartyNumber(),
				change);
		locParam.addChangeParam("EmergencyCallLine", oldLoc.getEmergencyCallLine(), newLoc.getEmergencyCallLine(),
				change);
		locParam.addChangeParam("PendingRPID", oldLoc.getPendingRPID(), newLoc.getPendingRPID(), change);
		locParam.addChangeParam("CallingPartyPrivacy", oldLoc.getCallingPartyPrivacy(), newLoc.getCallingPartyPrivacy(),
				change);
		locParam.addChangeParam("StationLevelId", oldLoc.getStationLevelId(), newLoc.getStationLevelId(), change);
		locParam.addChangeParam("BsAppServer", oldLoc.getBsAppServer(), newLoc.getBsAppServer(), change);
		locParam.addChangeParam("AsClli", oldLoc.getAsClli(), oldLoc.getAsClli(), change);
		locParam.addChangeParam("PrivateNumberLength", oldLoc.getPrivateNumberLength(), newLoc.getPrivateNumberLength(),
				change);
		locParam.addChangeParam("LinePortLength", oldLoc.getLinePortLength(), newLoc.getLinePortLength(), change);
		pi = locParam.addAndReturnChangeParams("ExtensionLength", oldLoc.getExtensionLength(),
				newLoc.getExtensionLength(), change, null);
		if (pi != null && pi.size() > 1)
			modProp = true;
		locParam.addChangeParam("Clin", oldLoc.getClin(), newLoc.getClin(), change);
		locParam.addChangeParam("Cv2Service", oldLoc.getCv2Service(), newLoc.getCv2Service(), change);
		locParam.addChangeParam("BlockAllCalls", booleanToStr(oldLoc.getBlockAllCalls()),
				booleanToStr(newLoc.getBlockAllCalls()), change);
		locParam.addChangeParam("Expedite", booleanToStr(oldLoc.getExpedite()), booleanToStr(newLoc.getExpedite()),
				change);
		locParam.addChangeParam("HighVolume", booleanToStr(oldLoc.getHighVolume()),
				booleanToStr(newLoc.getHighVolume()), change);
		locParam.addChangeParam("AfterHourInstallFee", booleanToStr(oldLoc.getAfterHourInstallFee()),
				booleanToStr(newLoc.getAfterHourInstallFee()), change);
		if(oldLoc.getEnhancedANIInd() != null)		
			locParam.addChangeParam("EnhancedANIInd", booleanToStr(oldLoc.getEnhancedANIInd()),
					booleanToStr(newLoc.getEnhancedANIInd()), change);
					
		locParam.addChangeParam("SubAgencyHierCode", oldLoc.getSubAgencyHierCode(), newLoc.getSubAgencyHierCode(),
				change);
		locParam.addChangeParam("PubIp", oldLoc.getPubIpStr(), newLoc.getPubIpStr(), change);
		locParam.addChangeParam("PubIpIn", oldLoc.getPubIpInStr(), newLoc.getPubIpInStr(), change);
		locParam.addChangeParam("PubIpOut", oldLoc.getPubIpOutStr(), newLoc.getPubIpOutStr(), change);
		locParam.addChangeParam("LocalDirAssistance", oldLoc.getLocalDirAssistance(), newLoc.getLocalDirAssistance(),
				change);
		locParam.addChangeParam("NatDirAssistance", oldLoc.getNatDirAssistance(), newLoc.getNatDirAssistance(), change);
		locParam.addChangeParam("CidTn", oldLoc.getCidTn(), newLoc.getCidTn(), change);
		locParam.addChangeParam("TrunkType", oldLoc.getTrunkType(), newLoc.getTrunkType(), change);
		locParam.addChangeParam("SwitchClli", oldLoc.getSwitchClli(), newLoc.getSwitchClli(), change);
		locParam.addChangeParam("Trunk", oldLoc.getTrunk(), newLoc.getTrunk(), change);
		locParam.addChangeParam("SiebelOrder", oldLoc.getSiebelOrder(), newLoc.getSiebelOrder(), change);
		locParam.addChangeParam("BillAcctNum", oldLoc.getBillAcctNum(), newLoc.getBillAcctNum(), change);
		locParam.addChangeParam("PublicGtwyDpid", oldLoc.getPublicGtwyDpid(), newLoc.getPublicGtwyDpid(), change);
		locParam.addChangeParam("DefaultGtwyDpid", oldLoc.getDefaultGtwyDpid(), newLoc.getDefaultGtwyDpid(), change);
		locParam.addChangeParam("AbbrDialingCode", oldLoc.getAbbrDialingCode(), newLoc.getAbbrDialingCode(), change);
		locParam.addChangeParam("VmType", oldLoc.getVmType(), newLoc.getVmType(), change);
		String vmCpeAct = locParam.addChangeParamReturnAction("VmCpeIpAddress", oldLoc.getVmCpeIpAddress(),
				newLoc.getVmCpeIpAddress(), change, null);
		locParam.addChangeParam("QosIndicator", oldLoc.getQosIndicator(), newLoc.getQosIndicator(), change);

		locParam.addChangeParam("EmerLocationCode", oldLoc.getEmerLocationCode(), newLoc.getEmerLocationCode(), change);
		locParam.addChangeParam("HubGatewayDeviceId", oldLoc.getHubGatewayDeviceId(), newLoc.getHubGatewayDeviceId(),
				change);
		locParam.addChangeParam("LocationMask", oldLoc.getLocationMask(), newLoc.getLocationMask(), change);

		locParam.addChangeParam("IASAOrderId", oldLoc.getIasaOrderId(), newLoc.getIasaOrderId(), change);
		locParam.addChangeParam("Territory", oldLoc.getTerritory(), newLoc.getTerritory(), change);
		locParam.addChangeParam("LocRegion", oldLoc.getLocRegion(), newLoc.getLocRegion(), change);
		locParam.addChangeParam("PBBAN", oldLoc.getPBBAN(), newLoc.getPBBAN(), change);
		locParam.addChangeParam("PrefixPlanId", oldLoc.getPrefixPlanId(), oldLoc.getPrefixPlanId(), change);
		locParam.addChangeParam("BillingSystem", oldLoc.getBillingSystem(), newLoc.getBillingSystem(), change);
		locParam.addChangeParam("ConfigAllowed", oldLoc.getConfigAllowed(), newLoc.getConfigAllowed(), change);
		LOG.info("Supp change on Signaling IP", oldLoc.getEsbcSignalingIP() + "--->" + newLoc.getEsbcSignalingIP());
		locParam.addChangeParam("ESBCSignalingIP", oldLoc.getEsbcSignalingIP(), newLoc.getEsbcSignalingIP(), change);

		if (modProp)
			locParam.addChildParam(new ParamInfo("MOD_PROP", null, null, ParamInfo.Tag.WF));

		if (oldLoc.getFeaturePackage() != null && newLoc.getFeaturePackage() == null) {
			Map<String, BigInteger> featurePackageMap = oldLoc.getFeaturePackage();
			for (String name : featurePackageMap.keySet()) {
				ParamInfo fpParam = new ParamInfo("FeaturePackage", (String) null, change ? "O" : null);
				fpParam.addChildParam(new ParamInfo("Name", name, change ? "O" : null));
				fpParam.addChildParam(
						new ParamInfo("VmBoxSize", featurePackageMap.get(name).toString(), change ? "O" : null));
				locParam.addChildParam(fpParam);
			}
			locParam.setAction("C");
		} else if (oldLoc.getFeaturePackage() == null && newLoc.getFeaturePackage() != null) {
			Map<String, BigInteger> featurePackageMap = newLoc.getFeaturePackage();
			for (String name : featurePackageMap.keySet()) {
				ParamInfo fpParam = new ParamInfo("FeaturePackage", (String) null, "I");
				fpParam.addChildParam(new ParamInfo("Name", name, "I"));
				fpParam.addChildParam(new ParamInfo("VmBoxSize", featurePackageMap.get(name).toString(), "I"));
				locParam.addChildParam(fpParam);
			}
			locParam.setAction("C");
		} else if (oldLoc.getFeaturePackage() != null && newLoc.getFeaturePackage() != null) {
			// Verify
			for (Map.Entry<String, BigInteger> entry : newLoc.getFeaturePackage().entrySet()) {
				if (oldLoc.getFeaturePackage().containsKey(entry.getKey())) {
					ParamInfo fpParam = new ParamInfo("FeaturePackage", (String) null, null);
					fpParam.addChildParam(new ParamInfo("Name", entry.getKey(), null));
					fpParam.addChangeParam("VmBoxSize", oldLoc.getFeaturePackage().get(entry.getKey()).toString(),
							entry.getValue().toString(), true);
					locParam.addChildParam(fpParam);
					if (fpParam.getAction() != null)
						locParam.setAction(fpParam.getAction());
				} else {
					ParamInfo fpParam = new ParamInfo("FeaturePackage", (String) null, "I");
					fpParam.addChildParam(new ParamInfo("Name", entry.getKey(), "I"));
					if (entry.getValue() != null)
						fpParam.addChildParam(new ParamInfo("VmBoxSize", entry.getValue().toString(), "I"));
					locParam.addChildParam(fpParam);
					locParam.setAction("C");
				}

			}
			for (Map.Entry<String, BigInteger> entry : oldLoc.getFeaturePackage().entrySet()) {
				if (!newLoc.getFeaturePackage().containsKey(entry.getKey())) {
					ParamInfo fpParam = new ParamInfo("FeaturePackage", (String) null, "O");
					fpParam.addChildParam(new ParamInfo("Name", entry.getKey(), "O"));
					if (entry.getValue() != null)
						fpParam.addChildParam(new ParamInfo("VmBoxSize", entry.getValue().toString(), "O"));
					locParam.addChildParam(fpParam);
					locParam.setAction("C");
				}
			}
		}
		locParam.addChangeParam("TypeOfLoc", oldLoc.getTypeOfLoc(), newLoc.getTypeOfLoc(), change);
		locParam.addChangeParam("HubLocationId", oldLoc.getHubLocationId(), newLoc.getHubLocationId(), change);
		locParam.addChangeParam("FmcLocation", oldLoc.getFmcLocation(), newLoc.getFmcLocation(), change);

		locParam.addChangeParam("SbcEnabled", booleanToStr(oldLoc.getSbcEnabled()),
				booleanToStr(newLoc.getSbcEnabled()), change);
		locParam.addChangeParam("SipClientEnabled", oldLoc.getSipClientEnabledFlag(), newLoc.getSipClientEnabledFlag(),
				change);
		locParam.addChangeParam("SbcProvMethod", oldLoc.getSbcProvMethod(), newLoc.getSbcProvMethod(), change);
		locParam.addChangeParam("AlternativeCallerIdFlag", oldLoc.getAltCallerIdFlag(), newLoc.getAltCallerIdFlag(),
				change);
		if (newLoc.getPortOutType() != null)
			locParam.addChildParam(new ParamInfo("PortOutType", newLoc.getPortOutType(), "I"));

		// ------XO Attributes-----
		locParam.addChangeParam("AdminFirstName", oldLoc.getAdminFirstName(), newLoc.getAdminFirstName(), change);
		locParam.addChangeParam(ADMIN_LASTNAME, oldLoc.getAdminLastName(), newLoc.getAdminLastName(), change);
		locParam.addChangeParam("AdminEmail", oldLoc.getAdminEmail(), newLoc.getAdminEmail(), change);
		locParam.addChangeParam("AdminWebLoginId", oldLoc.getAdminWebLoginId(), newLoc.getAdminWebLoginId(), change);
		locParam.addChangeParam("AdminPassword", oldLoc.getAdminPassword(), newLoc.getAdminPassword(), change);
		locParam.addChangeParam("DomainName", oldLoc.getDomainName(), newLoc.getDomainName(), change);
		locParam.addChangeParam("BillingTN", oldLoc.getBillingTN(), newLoc.getBillingTN(), change);
		locParam.addChangeParam("BroadworksPortalNumber", oldLoc.getBroadworksPortalNumber(),
				newLoc.getBroadworksPortalNumber(), change);
				
		LOG.info("oldLoc.getGroupUserLimit() --> {}, newLoc.getGroupUserLimit() --> {}", oldLoc.getGroupUserLimit(),
				newLoc.getGroupUserLimit());
		locParam.addChangeParam("GroupUserLimit", oldLoc.getGroupUserLimit(), newLoc.getGroupUserLimit(), change);
		locParam.addChangeParam("Redundency", oldLoc.getRedundancy(), newLoc.getRedundancy(), change);		
		locParam.addChangeParam("RedundencyId", oldLoc.getRedundancyId(), newLoc.getRedundancyId(), change);
		locParam.addChangeParam("RedundancyPriorityType", oldLoc.getRedundancyPriorityType(),
				newLoc.getRedundancyPriorityType(), change);
		locParam.addChangeParam("TNQuantity", newLoc.getTnQuantity(), newLoc.getTnQuantity(), change);
		locParam.addChangeParam("BWEnterpriseId", oldLoc.getBwEnterpriseId(), newLoc.getBwEnterpriseId(), change);
		locParam.addChangeParam("BsTimeZone", oldLoc.getBsTimeZone(), newLoc.getBsTimeZone(), change);

		locParam.addChangeParam("VpnPortSpeed", oldLoc.getVpnPortSpeed(), newLoc.getVpnPortSpeed(), change);
		locParam.addChangeParam("PortSpeed", oldLoc.getPortSpeed(), newLoc.getPortSpeed(), change);
		locParam.addChangeParam("VpnPortType", oldLoc.getVpnPortType(), newLoc.getVpnPortType(), change);
		locParam.addChangeParam("VgeCont", oldLoc.getVgeCont(), newLoc.getVgeCont(), change);

		locParam.addChangeParam("BWEnterpriseId", oldLoc.getBwEnterpriseId(), newLoc.getBwEnterpriseId(), change);
		locParam.addChangeParam("BsTimeZone", oldLoc.getBsTimeZone(), newLoc.getBsTimeZone(), change);
		locParam.addChangeParam("VpnPortType", oldLoc.getVpnPortType(), newLoc.getVpnPortType(), change);
		locParam.addChangeParam("VgeCont", oldLoc.getVgeCont(), newLoc.getVgeCont(), change);

		locParam.addChangeParam("MaxActiveCalls", oldLoc.getMaxActiveCalls(), newLoc.getMaxActiveCalls(), change);
		locParam.addChangeParam("MaxActiveIncomingCalls", oldLoc.getMaxActiveIncomingCalls(),
				newLoc.getMaxActiveIncomingCalls(), change);
		locParam.addChangeParam("MaxActiveOutgoingCalls", oldLoc.getMaxActiveOutgoingCalls(),
				newLoc.getMaxActiveOutgoingCalls(), change);

		if (newLoc.getAuthServices() != null) {
			for (Map.Entry<String, Boolean> entry : newLoc.getAuthServices().entrySet()) {
				ParamInfo locFeat = new ParamInfo("LocationFeature", null, action);
				locFeat.addNotNullValChild("Feature", entry.getKey(), action);
				locFeat.addNotNullValChild("DeltaCount", entry.getValue(), action);

				locParam.addChildParam(locFeat);
			}
		}
		if (oldLoc.getAuthService() != null) {
			for (AuthService authServiceList :oldLoc.getAuthService()) {
				ParamInfo authFeat = new ParamInfo("LocationFeature", null, action);
				authFeat.addNotNullValChild("Name", authServiceList.getName(), action);	
				authFeat.addNotNullValChild("Feature", authServiceList.getName(), action);	
				authFeat.addNotNullValChild("FeatureQuantity", authServiceList.getFeatureQuantity(), action);		
				authFeat.addNotNullValChild("Authorised", OrderUtility.booleanToStr(authServiceList.getAuthorise()) , action);
				locParam.addChildParam(authFeat);
			}
		}
		if (newLoc.getSession() != null) {
			ParamInfo sessionParam = new ParamInfo("Session", null, action);
			sessionParam.addChildParam(
					new ParamInfo("SessionId", String.valueOf(newLoc.getSession().getInstanceId()), action));
			sessionParam.addChildParam(
					new ParamInfo("Quantity", String.valueOf(newLoc.getSession().getQuantity()), action));
			sessionParam.addChildParam(new ParamInfo("PortSpeed", newLoc.getSession().getPortSpeed(), action));
			sessionParam
					.addChildParam(new ParamInfo("CompressionType", newLoc.getSession().getCompressionType(), action));
			sessionParam.addChildParam(new ParamInfo("MaxQuantity", newLoc.getSession().getMaxQuantity(), action));

			locParam.addChildParam(sessionParam, ParamInfo.Tag.NON_ORD);
		}
		// Start EBL
		
		if (oldLoc.getBwLocationId() != null && oldLoc.getEslId() != null
				&& VoipServiceType.ENTERPRISE_SIP.toString().equals(oldLoc.getVoipServiceType())) {
			locParam.addChangeParam("EslId", oldLoc.getEslId(), newLoc.getEslId(), change);
			locParam.addChangeParam("BWLocationId", oldLoc.getBwLocationId(), newLoc.getBwLocationId(), change);
			
		} else if(oldLoc.getBwLocationId() == null && oldLoc.getEslId() != null
				&& VoipServiceType.ENTERPRISE_SIP.toString().equals(oldLoc.getVoipServiceType())){
			locParam.addChangeParam("EslId", oldLoc.getEslId(), newLoc.getEslId(), change);
			locParam.addChangeParam("BWLocationId", oldLoc.getEslId(), newLoc.getEslId(), change);
			
		} else if (oldLoc.getBwLocationId() != null && oldLoc.getVoipServiceType() != null
				&& VoipServiceType.HOSTED_PBX.toString().equals(oldLoc.getVoipServiceType())) {
			locParam.addChangeParam("BWLocationId", oldLoc.getBwLocationId(), newLoc.getBwLocationId(), change);
			
		} else {
			locParam.addChangeParam("BWLocationId", oldLoc.getLocationId(), newLoc.getLocationId(), change);
		}
		
		if (oldLoc.getPreBuildLocId() != null)
			locParam.addChangeParam("PreBuildLocId", oldLoc.getPreBuildLocId(), newLoc.getPreBuildLocId(), change);
		
		if (oldLoc.getEblId() != null)
			locParam.addChangeParam("EblId", oldLoc.getEblId(), newLoc.getEblId(), change);
		if (oldLoc.getTypeOfLoc() != null)
			locParam.addChangeParam("TypeOfLoc", oldLoc.getTypeOfLoc(), newLoc.getTypeOfLoc(), change);
		if (oldLoc.getHubLocationId() != null)
			locParam.addChangeParam("HubLocationId", oldLoc.getHubLocationId(), newLoc.getHubLocationId(), change);
		// End EBL
		// ------XO Attributes-----	
		//Feature Changes:
		boolean isAuthFeatureChanged = false;
		
		if((oldLoc.getRedundancyId() != null && !oldLoc.getRedundancyId().equalsIgnoreCase(newLoc.getRedundancyId()))
				|| (oldLoc.getRedundancyPriorityType() != null && !oldLoc.getRedundancyPriorityType().equals(newLoc.getRedundancyPriorityType()))
				|| (oldLoc.getGroupUserLimit() != null && !oldLoc.getGroupUserLimit().equals(newLoc.getGroupUserLimit()))) {
			LOG.info("LOC_BS_CHANGE = Y");
			
			locParam.addNotNullValChild("LOC_BS_CHANGE", "Y", "n");
		} else {
			LOG.info("LOC_BS_CHANGE = N");
			locParam.addNotNullValChild("LOC_BS_CHANGE", "N", "n");
		}
		
		if(oldLoc.getGroupUserLimit() != null && !oldLoc.getGroupUserLimit().equalsIgnoreCase(newLoc.getGroupUserLimit())) {
			LOG.info("LOC_CALL_BS_CHANGE = Y");
			
			locParam.addNotNullValChild("LOC_CALL_BS_CHANGE", "Y", "n");
		}else {
			LOG.info("LOC_CALL_BS_CHANGE = N");
			locParam.addNotNullValChild("LOC_CALL_BS_CHANGE", "N", "n");
		}
		
		if (isAuthFeatureChanged) {
			LOG.info("LOC_AUTH_BS_CHANGE = Y");
			
			locParam.addNotNullValChild("LOC_AUTH_BS_CHANGE", "Y", "n");
		}else {
			LOG.info("LOC_AUTH_BS_CHANGE = N");
			locParam.addNotNullValChild("LOC_AUTH_BS_CHANGE", "N", "n");
		}
		
		LOG.info("Exit prepareTblOrderDetailsEntityParamDataForLocation(old, new, supp) with Action: {}",
				locParam.getAction());
		return locParam;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.vz.esap.translation.order.transformer.
	 * LocationTblOrderDetailsDataTransformer#prepareTblOrderDetailsHeaderParamData(
	 * com.vz.esap.translation.order.model.Order,
	 * com.vz.esap.translation.entity.LocationEntity, boolean)
	 */
	@Override
	public ParamInfo prepareTblOrderDetailsHeaderParamData(Order order, LocationEntity oldLoc, boolean supp)
			throws ParseException, TranslatorException {

		LOG.info("Entered - prepareTblOrderDetailsHeaderParamData(orderPrevPass, oldLoc, voipOrderRequest, supp)");
		ParamInfo root = null;
		String action = null;
		try {

			int oldVersion = Integer.parseInt(order.getOrderHeader().getOrderVersion()) + 1;

			action = order.getOrderHeader().getOrderType();

			root = new ParamInfo("Header", null, action);
			root.addChangeParam("OrderNumber", order.getOrderHeader().getOrderNumber(),
					order.getOrderHeader().getOrderNumber(), supp);
			root.addChangeParam("EnvOrderId", order.getOrderHeader().getEnvOrderId(), order.getOrderHeader().getEnvOrderId(), supp);
			root.addChangeParam("MasterOrderNumber", order.getOrderHeader().getMasterOrderNumber(),
					order.getOrderHeader().getMasterOrderNumber(), supp);
			root.addChangeParam("OrderVersion", order.getOrderHeader().getOrderVersion(), order.getOrderHeader().getOrderVersion(), supp);
			root.addChangeParam("TransactionId", order.getOrderHeader().getTransactionId(),
					order.getOrderHeader().getTransactionId(), supp);
			
			if (order.getOrderHeader().getRegion() != null) {
				root.addChangeParam(REGION, order.getOrderHeader().getRegion(), order.getOrderHeader().getRegion(), supp);
				
			} else {
				
				root.addChangeParam(REGION, "US", "US", supp);
			}
			
			
			root.addChangeParam("MinorOrderType", order.getOrderHeader().getMinorOrderType(),
					order.getOrderHeader().getMinorOrderType(), supp);
			root.addChangeParam("CentrexType", order.getOrderHeader().getCentrexType(),
					order.getOrderHeader().getCentrexType(), supp);
			root.addChangeParam("ServiceType", order.getOrderHeader().getServiceType(),
					order.getOrderHeader().getServiceType(), supp);
			root.addChangeParam("OriginatingSystem", order.getOrderHeader().getOriginatingSystem(),
					order.getOrderHeader().getOriginatingSystem(), supp);
			root.addChangeParam("InterfaceSystem", order.getOrderHeader().getInterfaceSystem(),
					order.getOrderHeader().getInterfaceSystem(), supp);
			root.addChangeParam("OrderType",
					EsapEnum.OrderType.getValue(order.getOrderHeader().getOrderType().charAt(0)),
					EsapEnum.OrderType.getValue(order.getOrderHeader().getOrderType().charAt(0)), supp);
			root.addChangeParam("SuppType", order.getOrderHeader().getSuppType(), order.getOrderHeader().getSuppType(), supp);
			root.addChangeParam("OrderClassify", order.getOrderHeader().getFunctionCode(),
					order.getOrderHeader().getFunctionCode(), supp);

			if (order.getOrderHeader().getDueDate() != null) {
				SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
				Calendar calendar = GregorianCalendar.getInstance();
				calendar.setTime(format.parse(order.getOrderHeader().getDueDate().toString()));
				Object dueDate = calendar.getTime();
				root.addNotNullValChild("DueDate", dueDate, action);
			}

			if (order.getLocation().getCustomerId() != null)
				root.addChangeParam(CUSTOMER_ID, order.getLocation().getCustomerId(), 
						order.getLocation().getCustomerId(), true);
			else if (order.getOrderHeader().getCustomerId() != null)
				root.addChangeParam(CUSTOMER_ID, order.getOrderHeader().getCustomerId(), 
						order.getOrderHeader().getCustomerId(), true);

			root.addChangeParam(LOCATION_ID, order.getOrderHeader().getLocationId(), 
					order.getOrderHeader().getLocationId(), true);
			
			// root.addNotNullValChild(BS_APP_SERVER, order.getLocation().getBsAppServer(),
			// action); Fix This
			root.addChangeParam("OrderProTIN", order.getOrderHeader().getOrderProTIN(),
					order.getOrderHeader().getOrderProTIN(), supp);
			root.addChangeParam("IOrderTIN", order.getOrderHeader().getiOrderTIN(),
					order.getOrderHeader().getiOrderTIN(), supp);
			root.addChangeParam("TINVersion", order.getOrderHeader().getTinVersion(),
					order.getOrderHeader().getTinVersion(), supp);
			root.addChangeParam("TransitionFlag", order.getOrderHeader().isTransitionFlag() ? "Y" : "N",
					order.getOrderHeader().isTransitionFlag() ? "Y" : "N", supp);
			root.addChangeParam("Priority", order.getOrderHeader().getPriority(), order.getOrderHeader().getPriority(),
					supp);
			if (order.getLocation().getAuthFeatureType() != null)
				root.addChangeParam("AuthFeatureType", order.getLocation().getAuthFeatureType().toString(),
						order.getLocation().getAuthFeatureType().toString(), supp);
			if (order.getOrderHeader().getAttribMap() != null) {
				root.addChildParam(OrderUtility.getAttribParamInfo(order.getOrderHeader().getAttribMap(), action));
			}
			if (order.getOrderHeader().getOrderCreatedBy() != null)
				root.addChangeParam("OrderCreatedBy", order.getOrderHeader().getOrderCreatedBy(),
						order.getOrderHeader().getOrderCreatedBy(), supp);
			if (order.getOrderHeader().isHasBulkOrder()) {
				root.addChangeParam("BULK", "Y", "Y", supp);
			}
			if (order.getOrderHeader().getHotCutIndicator() != null) {
				root.addChangeParam(HOT_CUT_IND, "Y", "Y", supp);
			}
			if (order.getOrderHeader().getCDDDIndicator() != null) {
				root.addChangeParam(CDD_IND, "Y", "Y", supp);
			}

		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new TranslatorException(ErrorCode.TRANSFORMER_FAILURE,
					"Exception occured in prepareTblOrderDetailsHeaderParamData");
		}
		LOG.info("Entered - prepareTblOrderDetailsHeaderParamData(orderPrevPass, oldLoc, voipOrderRequest, supp)");
		return root;
	}

	
}
