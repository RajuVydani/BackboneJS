package com.vz.esap.translation.order.model.pc;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;

import com.fasterxml.jackson.annotation.JsonProperty;

@XmlAccessorType(XmlAccessType.FIELD)
public class PortingInfo {
	
	@XmlElement(name = "PortingFlag")
	@JsonProperty(value = "PortingFlag")
	private String portingFlag;

	@XmlElement(name = "GainingCarrierPrefix")
	@JsonProperty(value = "GainingCarrierPrefix")
	private String gainingCarrierPrefix;

	@XmlElement(name = "SubStatus")
	@JsonProperty(value = "SubStatus")
	private String subStatus;

	@XmlElement(name = "PortingIndicator")
	@JsonProperty(value = "PortingIndicator")
	private String portingIndicator;

	@XmlElement(name = "LosingCarrierPrefix")
	@JsonProperty(value = "LosingCarrierPrefix")
	private String losingCarrierPrefix;

	@XmlElement(name = "TN")
	@JsonProperty(value = "TN")
	private String tn;

	@XmlElement(name = "OriginalCarrierPrefix")
	@JsonProperty(value = "OriginalCarrierPrefix")
	private String originalCarrierPrefix;

	@XmlElement(name = "GatewayNumber")
	@JsonProperty(value = "GatewayNumber")
	private String gatewayNumber;

	public String getPortingFlag() {
		return portingFlag;
	}

	public void setPortingFlag(String portingFlag) {
		this.portingFlag = portingFlag;
	}

	public String getGainingCarrierPrefix() {
		return gainingCarrierPrefix;
	}

	public void setGainingCarrierPrefix(String gainingCarrierPrefix) {
		this.gainingCarrierPrefix = gainingCarrierPrefix;
	}

	public String getSubStatus() {
		return subStatus;
	}

	public void setSubStatus(String subStatus) {
		this.subStatus = subStatus;
	}

	public String getPortingIndicator() {
		return portingIndicator;
	}

	public void setPortingIndicator(String portingIndicator) {
		this.portingIndicator = portingIndicator;
	}

	public String getLosingCarrierPrefix() {
		return losingCarrierPrefix;
	}

	public void setLosingCarrierPrefix(String losingCarrierPrefix) {
		this.losingCarrierPrefix = losingCarrierPrefix;
	}

	public String getTn() {
		return tn;
	}

	public void setTn(String tn) {
		this.tn = tn;
	}

	public String getOriginalCarrierPrefix() {
		return originalCarrierPrefix;
	}

	public void setOriginalCarrierPrefix(String originalCarrierPrefix) {
		this.originalCarrierPrefix = originalCarrierPrefix;
	}

	public String getGatewayNumber() {
		return gatewayNumber;
	}

	public void setGatewayNumber(String gatewayNumber) {
		this.gatewayNumber = gatewayNumber;
	}

	@Override
	public String toString() {
		return "ClassPojo [PortingFlag = " + portingFlag + ", GainingCarrierPrefix = " + gainingCarrierPrefix
				+ ", SubStatus = " + subStatus + ", PortingIndicator = " + portingIndicator + ", LosingCarrierPrefix = "
				+ losingCarrierPrefix + ", TN = " + tn + ", OriginalCarrierPrefix = " + originalCarrierPrefix
				+ ", GatewayNumber = " + gatewayNumber + "]";
	}
}
