package com.vz.esap.translation.service;

import java.util.Arrays;
import java.util.Map;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.vz.esap.translation.constant.TranslationConstant;
import com.vz.esap.translation.enums.EsapEnum.RoutingEnd;
import com.vz.esap.translation.enums.EsapEnum.SolutionType;
import com.vz.esap.translation.exception.GenericException;
import com.vz.esap.translation.exception.TranslatorException;
import com.vz.esap.translation.exception.TranslatorException.ErrorCode;
import com.vz.esap.translation.order.model.OrderHeader.SuppType;
import com.vz.esap.translation.order.model.request.VOIPOrderRequest;
import com.vz.esap.translation.order.model.response.VoipOrderResponse;
import com.vz.esap.translation.order.parser.OrderParser;
import com.vz.esap.translation.order.service.CancelOrderService;
import com.vz.esap.translation.order.service.OrderServiceBase;
import com.vz.esap.translation.order.service.ebl.EblOrderService;
import com.vz.esap.translation.order.service.esl.EslOrderService;
import com.vz.esap.translation.order.service.helper.OrderServiceHelper;
import com.vz.esap.translation.order.service.hpbx.HpbxOrderService;
import com.vz.esap.translation.order.service.ipflex.IpFlexOrderService;
import com.vz.esap.translation.order.validation.EnterpriseOrderValidator;
import com.vz.esap.translation.util.InventoryUtil;

/**
 * @author chattni
 *
 */
@Service
public class OrderRouterImpl extends OrderServiceBase implements OrderRouter {

	@Autowired
	private OrderParser orderParserImpl;

	@Autowired
	private EslOrderService eslOrderServiceImpl;

	@Autowired
	private EnterpriseOrderValidator enterpriseOrderValidator;

	@Autowired
	private IpFlexOrderService ipFlexOrderServiceImpl;

	@Autowired
	private EblOrderService eblOrderServiceImpl;

	@Autowired
	private CancelOrderService cancelOrderServiceImpl;

	@Autowired
	private HpbxOrderService hpbxOrderServiceImpl;

	@Autowired
	private OrderServiceHelper orderServiceHelperImpl;

	private static final Logger LOG = LoggerFactory.getLogger(OrderRouterImpl.class);

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.vz.esap.translation.service.OrderRouter#routeOrder(com.vz.esap.
	 * translation.order.model.request.VOIPOrderRequest)
	 */
	@Override
	public VoipOrderResponse routeOrder(VOIPOrderRequest voipOrderRequest)
			throws TranslatorException, GenericException {
		LOG.info("Entered - routeOrder");
		VoipOrderResponse voipOrderResponse = null;
		Map<String, String> productDetails = orderParserImpl.getProductDetails(voipOrderRequest);

		voipOrderRequest = setSolutionTypeInOrderHeader(voipOrderRequest, productDetails.get("SolutionType"));
		RoutingEnd routingSwitch = getRoutingEnd(voipOrderRequest, productDetails);

		switch (routingSwitch) {
		case ESL_I_VAL:
		case ESL_C_VAL:
			voipOrderResponse = eslOrderServiceImpl.createEslEsipValidateOrder(voipOrderRequest, productDetails);
			break;
		case ESL_I_REL:
		case ESL_C_REL:
			voipOrderResponse = eslOrderServiceImpl.createEslEsipReleaseOrder(voipOrderRequest, productDetails);
			break;
		case EBL_I_VAL:
		case EBL_C_VAL:
			voipOrderResponse = eblOrderServiceImpl.createEblEsipValidateOrder(voipOrderRequest, productDetails);
			break;
		case EBL_I_REL:
		case EBL_C_REL:
			voipOrderResponse = eblOrderServiceImpl.createEblEsipReleaseOrder(voipOrderRequest, productDetails);
			break;
		case IPFLEX_I_VAL:
		case IPFLEX_C_VAL:
			voipOrderResponse = ipFlexOrderServiceImpl.createIpFlexValidateOrder(voipOrderRequest, productDetails);
			break;
		case IPFLEX_I_REL:
		case IPFLEX_C_REL:
			voipOrderResponse = ipFlexOrderServiceImpl.createIpFlexReleaseOrder(voipOrderRequest, productDetails);
			break;
		case HPBX_I_VAL:
		case HPBX_C_VAL:
			voipOrderResponse = hpbxOrderServiceImpl.createHpbxValidateOrder(voipOrderRequest, productDetails);
			break;
		case HPBX_I_REL:
		case HPBX_C_REL:
			voipOrderResponse = hpbxOrderServiceImpl.createHpbxReleaseOrder(voipOrderRequest, productDetails);
			break;
		case NBS_PROV_CONFIG:
			voipOrderResponse = eslOrderServiceImpl.configNbsDetails(voipOrderRequest);
			break;
		case CIRCUIT_INFO:
			voipOrderResponse = eslOrderServiceImpl.configCircuitInfo(voipOrderRequest);
			break;
		case SUP_CANCEL:
			voipOrderResponse = cancelOrderServiceImpl.createCancelWorkOrder(voipOrderRequest);
			break;
		case ESL_D_REL_SUSPEND:
			voipOrderResponse = eslOrderServiceImpl.createEslEsipLocSuspOrder(voipOrderRequest, productDetails);
			break;
		case ESL_D_REL_DEACTIVATE:
			voipOrderResponse = eslOrderServiceImpl.createEslEsipLocDeactOrder(voipOrderRequest, productDetails);
			break;
		case EBL_D_REL_SUSPEND:
			voipOrderResponse = eblOrderServiceImpl.createEblEsipLocSuspOrder(voipOrderRequest, productDetails);
			break;
		case EBL_D_REL_DEACTIVATE:
			voipOrderResponse = eblOrderServiceImpl.createEblEsipLocDeactOrder(voipOrderRequest, productDetails);
			break;
		case ESIP_GET_LOC_INFO:
			voipOrderResponse = eslOrderServiceImpl.getEsipLocationStatus(voipOrderRequest);
			break;
		case LNP_ACTIVATE:
			voipOrderResponse = orderServiceHelperImpl.createTnPortActivationOrder(voipOrderRequest, productDetails);
			break;
		case IPFELX_D_REL_DEACTIVATE:
			voipOrderResponse = ipFlexOrderServiceImpl.createIpFlexLocDeactOrder(voipOrderRequest, productDetails);
			break;
		case IPFLEX_D_REL_SUSPEND:
			voipOrderResponse = ipFlexOrderServiceImpl.createIpFlexLocSuspOrder(voipOrderRequest, productDetails);
			break;
		case ESL_PIT:
			voipOrderResponse = eslOrderServiceImpl.createEslPreIntegrationTestOrder(voipOrderRequest, productDetails);
			break;
		case LOC_ACTIVATE:
			voipOrderResponse = eslOrderServiceImpl.createEslCompletionOrder(voipOrderRequest, productDetails);
			break;
		case HPBX_D_REL_SUSPEND:
			voipOrderResponse = hpbxOrderServiceImpl.createHpbxLocSuspendOrder(voipOrderRequest, productDetails);
			break;
		case HPBX_D_REL_DEACTIVATE:
			voipOrderResponse = hpbxOrderServiceImpl.createHpbxLocDeactivateOrder(voipOrderRequest, productDetails);
			break;

		default:
			LOG.info("Unable to find the valid routing switch");
			break;
		}
		LOG.info("Exit - routeOrder");
		return voipOrderResponse;
	}

	/**
	 * @param voipOrderRequest
	 * @param productDetails
	 * @return routingEndpoint
	 * @throws TranslatorException
	 * @throws GenericException
	 */
	RoutingEnd getRoutingEnd(VOIPOrderRequest voipOrderRequest, Map<String, String> productDetails)
			throws TranslatorException, GenericException {
		LOG.info("Entered - getRoutingEnd");
		RoutingEnd routingEndpoint = RoutingEnd.EMPTY;

		Set<String> missingFields = enterpriseOrderValidator.validate(voipOrderRequest);

		if (!CollectionUtils.isEmpty(missingFields)) {
			LOG.info("Missing Field : {}", missingFields);
			throw new TranslatorException(ErrorCode.MANDATORY_FIELDS_MISSING,
					"Exception thrown for missing mandatory fields");
		}

		if (productDetails != null && productDetails.get("SolutionType") != null
				&& "I".equalsIgnoreCase(voipOrderRequest.getOrderHeader().getOrderType())) {

			if (voipOrderRequest.getOrderHeader().getFunctionCode()
					.equals(TranslationConstant.FUNCTION_CODE_VALIDATE)) {

				if ("ESIP_ESL".equalsIgnoreCase(productDetails.get("SolutionType")))
					routingEndpoint = RoutingEnd.ESL_I_VAL;

				if ("ESIP_EBL".equalsIgnoreCase(productDetails.get("SolutionType")))
					routingEndpoint = RoutingEnd.EBL_I_VAL;

				if ("IPFLEX".equalsIgnoreCase(productDetails.get("SolutionType")))
					routingEndpoint = RoutingEnd.IPFLEX_I_VAL;

				if ("HPBX".equalsIgnoreCase(productDetails.get("SolutionType")))
					routingEndpoint = RoutingEnd.HPBX_I_VAL;
			}

			if (voipOrderRequest.getOrderHeader().getFunctionCode().equals(TranslationConstant.FUNCTION_CODE_RELEASE)) {

				if ("ESIP_ESL".equalsIgnoreCase(productDetails.get("SolutionType")))
					routingEndpoint = RoutingEnd.ESL_I_REL;

				if ("ESIP_EBL".equalsIgnoreCase(productDetails.get("SolutionType")))
					routingEndpoint = RoutingEnd.EBL_I_REL;

				if ("IPFLEX".equalsIgnoreCase(productDetails.get("SolutionType")))
					routingEndpoint = RoutingEnd.IPFLEX_I_REL;

				if ("HPBX".equalsIgnoreCase(productDetails.get("SolutionType")))
					routingEndpoint = RoutingEnd.HPBX_I_REL;

				if (voipOrderRequest.getOrderHeader().getSuppType() != null && SuppType.CANCEL.toString()
						.equalsIgnoreCase(voipOrderRequest.getOrderHeader().getSuppType())) {
					LOG.info("Supp Type is : {}", voipOrderRequest.getOrderHeader().getSuppType());
					routingEndpoint = RoutingEnd.SUP_CANCEL;
				}

			}
		} else if (productDetails != null && productDetails.get("SolutionType") != null
				&& "C".equalsIgnoreCase(voipOrderRequest.getOrderHeader().getOrderType())) {

			if (voipOrderRequest.getOrderHeader().getFunctionCode()
					.equals(TranslationConstant.FUNCTION_CODE_VALIDATE)) {

				if ("ESIP_ESL".equalsIgnoreCase(productDetails.get("SolutionType")))
					routingEndpoint = RoutingEnd.ESL_C_VAL;

				if ("ESIP_EBL".equalsIgnoreCase(productDetails.get("SolutionType")))
					routingEndpoint = RoutingEnd.EBL_C_VAL;

				if ("IPFLEX".equalsIgnoreCase(productDetails.get("SolutionType")))
					routingEndpoint = RoutingEnd.IPFLEX_C_VAL;

				if ("HPBX".equalsIgnoreCase(productDetails.get("SolutionType")))
					routingEndpoint = RoutingEnd.HPBX_C_VAL;
			}

			if (voipOrderRequest.getOrderHeader().getFunctionCode().equals(TranslationConstant.FUNCTION_CODE_RELEASE)) {

				if ("ESIP_ESL".equalsIgnoreCase(productDetails.get("SolutionType")))
					routingEndpoint = RoutingEnd.ESL_C_REL;

				if ("ESIP_EBL".equalsIgnoreCase(productDetails.get("SolutionType")))
					routingEndpoint = RoutingEnd.EBL_C_REL;

				if ("IPFLEX".equalsIgnoreCase(productDetails.get("SolutionType")))
					routingEndpoint = RoutingEnd.IPFLEX_C_REL;

				if ("HPBX".equalsIgnoreCase(productDetails.get("SolutionType")))
					routingEndpoint = RoutingEnd.HPBX_C_REL;

				if (voipOrderRequest.getOrderHeader().getSuppType() != null && SuppType.CANCEL.toString()
						.equalsIgnoreCase(voipOrderRequest.getOrderHeader().getSuppType())) {
					LOG.info("Supp Type is : {}", voipOrderRequest.getOrderHeader().getSuppType());
					routingEndpoint = RoutingEnd.SUP_CANCEL;
				}

			}
		} else if (productDetails != null && productDetails.get("SolutionType") != null
				&& "D".equalsIgnoreCase(voipOrderRequest.getOrderHeader().getOrderType())) {
			if (voipOrderRequest.getOrderHeader().getFunctionCode()
					.equals(TranslationConstant.FUNCTION_CODE_REL_SUSPEND)) {

				if ("ESIP_ESL".equalsIgnoreCase(productDetails.get("SolutionType")))
					routingEndpoint = RoutingEnd.ESL_D_REL_SUSPEND;

				if ("ESIP_EBL".equalsIgnoreCase(productDetails.get("SolutionType")))
					routingEndpoint = RoutingEnd.EBL_D_REL_SUSPEND;

				if ("IPFLEX".equalsIgnoreCase(productDetails.get("SolutionType")))
					routingEndpoint = RoutingEnd.IPFLEX_D_REL_SUSPEND;
				// HPBX REL_SUSPEND
				if ("HPBX".equalsIgnoreCase(productDetails.get("SolutionType")))
					routingEndpoint = RoutingEnd.HPBX_D_REL_SUSPEND;
			}
			if (voipOrderRequest.getOrderHeader().getFunctionCode()
					.equals(TranslationConstant.FUNCTION_CODE_REL_DEACTIVATE)) {

				if ("ESIP_ESL".equalsIgnoreCase(productDetails.get("SolutionType")))
					routingEndpoint = RoutingEnd.ESL_D_REL_DEACTIVATE;

				if ("ESIP_EBL".equalsIgnoreCase(productDetails.get("SolutionType")))
					routingEndpoint = RoutingEnd.EBL_D_REL_DEACTIVATE;

				if ("IPFLEX".equalsIgnoreCase(productDetails.get("SolutionType")))
					routingEndpoint = RoutingEnd.IPFELX_D_REL_DEACTIVATE;
				// HPBX REL_DEACTIVATE
				if ("HPBX".equalsIgnoreCase(productDetails.get("SolutionType")))
					routingEndpoint = RoutingEnd.HPBX_D_REL_DEACTIVATE;
			}
		}

		if (voipOrderRequest.getOrderHeader().getFunctionCode()
				.equals(TranslationConstant.FUNCTION_CODE_NBS_PROV_CONFIG)) {
			routingEndpoint = RoutingEnd.NBS_PROV_CONFIG;
			LOG.info("NBS Config Is {}", voipOrderRequest.getNbsConfig().toString());
		} else if (voipOrderRequest.getOrderHeader().getFunctionCode()
				.equals(TranslationConstant.FUNCTION_CODE_CIRCUIT_INFO)) {
			routingEndpoint = RoutingEnd.CIRCUIT_INFO;
			LOG.info("Circuit Info Is {}", Arrays.toString(voipOrderRequest.getCircuitInfo()));
		} else if (voipOrderRequest.getOrderHeader().getFunctionCode()
				.equals(TranslationConstant.FUNCTION_CODE_GET_LOC_INFO)) {

			if (Arrays.asList(SolutionType.ESIP_ESL.toString(), SolutionType.ESIP_EBL.toString())
					.contains(productDetails.get("SolutionType")))
				routingEndpoint = RoutingEnd.ESIP_GET_LOC_INFO;

		} else if (voipOrderRequest.getOrderHeader().getFunctionCode().equals(TranslationConstant.LNP_ACTIVATE)) {

			if (Arrays
					.asList(SolutionType.ESIP_ESL.toString(), SolutionType.ESIP_EBL.toString(),
							SolutionType.IPFLEX.toString(), SolutionType.HPBX.toString())
					.contains(productDetails.get("SolutionType")))
				routingEndpoint = RoutingEnd.LNP_ACTIVATE;

		} else if (Arrays
				.asList(SolutionType.ESIP_ESL.toString(), SolutionType.IPFLEX.toString(), SolutionType.HPBX.toString(),
						SolutionType.ESIP_EBL.toString())
				.contains(productDetails.get("SolutionType"))
				&& voipOrderRequest.getOrderHeader().getFunctionCode().equals(TranslationConstant.FUNCTION_CODE_PIT)) {
			routingEndpoint = RoutingEnd.ESL_PIT;

		} else if (Arrays
				.asList(SolutionType.ESIP_ESL.toString(), SolutionType.IPFLEX.toString(), SolutionType.HPBX.toString(),
						SolutionType.ESIP_EBL.toString())
				.contains(productDetails.get("SolutionType"))
				&& voipOrderRequest.getOrderHeader().getFunctionCode()
						.equals(TranslationConstant.FUNCTION_CODE_LOC_ACTIVATE)) {
			routingEndpoint = RoutingEnd.LOC_ACTIVATE;

		}

		LOG.info("Exit - getRoutingEnd : {}", routingEndpoint);
		return routingEndpoint;
	}

}
