package com.vz.esap.translation.enums;

import java.util.ArrayList;
import java.util.List;

public enum RequestHeaders {

  VECUserId("uid"),
  CompanyIdAndPortalId("vzbecpdid"),
  ApplicationId("applicationid"),
  EmailId("email_address"),
  ServerIP("service_ip_address"),
  ServerName("service_server_name"),
  LoginDateTime("issued_at");

	private String headerName;

	RequestHeaders(String headerName) {
		this.headerName = headerName;
	}

	/**
	 * get header name
	 * @return
	 */
	public String getHeaderName() {
		return headerName;
	}

	/**
	 * List of header names
	 * 
	 * @return
	 */
	public static List<String> headerNames() {

		List<String> headerNameList = new ArrayList<>();
		for (RequestHeaders name : RequestHeaders.values()) {
			headerNameList.add(name.getHeaderName());
		}
		return headerNameList;
	}

	/**
	 * Get the respective enum name for the given header value
	 * 
	 * @param headerName
	 * @return
	 */
	public static String getHeaderDescription(String headerName) {
		String headerDesc = null;
		for (RequestHeaders requestHeader : RequestHeaders.values()) {
			if (requestHeader.getHeaderName().equals(headerName)) {
				headerDesc = requestHeader.name();
				break;
			}

		}
		return headerDesc;
	}

}