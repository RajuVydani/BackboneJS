
package com.vz.esap.translation.connector.dto;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "statusCode", "statusDescription", "bsConfigData", "configParams" })
public class ConfigDetailResponse {

	@JsonProperty("statusCode")
	private Long statusCode;

	@JsonProperty("statusDescription")
	private String statusDescription;

	@JsonProperty("bsConfigData")
	private Object bsConfigData;

	@JsonProperty("configParams")
	private List<ConfigParam> configParams = new ArrayList<ConfigParam>();

	@JsonIgnore
	private Map<String, Object> additionalProperties = new HashMap<String, Object>();

	@JsonProperty("statusCode")
	public Long getStatusCode() {
		return statusCode;
	}

	@JsonProperty("statusCode")
	public void setStatusCode(Long statusCode) {
		this.statusCode = statusCode;
	}

	@JsonProperty("statusDescription")
	public String getStatusDescription() {
		return statusDescription;
	}

	@JsonProperty("statusDescription")
	public void setStatusDescription(String statusDescription) {
		this.statusDescription = statusDescription;
	}

	@JsonProperty("bsConfigData")
	public Object getBsConfigData() {
		return bsConfigData;
	}

	@JsonProperty("bsConfigData")
	public void setBsConfigData(Object bsConfigData) {
		this.bsConfigData = bsConfigData;
	}

	@JsonProperty("configParams")
	public List<ConfigParam> getConfigParams() {
		return configParams;
	}

	@JsonProperty("configParams")
	public void setConfigParams(List<ConfigParam> configParams) {
		this.configParams = configParams;
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}

	@JsonAnyGetter
	public Map<String, Object> getAdditionalProperties() {
		return this.additionalProperties;
	}

	@JsonAnySetter
	public void setAdditionalProperty(String name, Object value) {
		this.additionalProperties.put(name, value);
	}

	@Override
	public int hashCode() {
		return new HashCodeBuilder().append(statusCode).append(statusDescription).append(bsConfigData)
				.append(configParams).append(additionalProperties).toHashCode();
	}

	@Override
	public boolean equals(Object other) {
		if (other == this) {
			return true;
		}
		if ((other instanceof ConfigDetailResponse) == false) {
			return false;
		}
		ConfigDetailResponse rhs = ((ConfigDetailResponse) other);
		return new EqualsBuilder().append(statusCode, rhs.statusCode).append(statusDescription, rhs.statusDescription)
				.append(bsConfigData, rhs.bsConfigData).append(configParams, rhs.configParams)
				.append(additionalProperties, rhs.additionalProperties).isEquals();
	}

}
