package com.vz.esap.translation.order.service.tn;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.vz.esap.translation.dao.model.TblEnvOrder;
import com.vz.esap.translation.dao.model.TblOrder;
import com.vz.esap.translation.dao.model.TblOrderDetails;
import com.vz.esap.translation.dao.model.TblOrderService;
import com.vz.esap.translation.entity.GroupTNEntity;
import com.vz.esap.translation.enums.EsapEnum;
import com.vz.esap.translation.enums.EsapEnum.FlowPath;
import com.vz.esap.translation.enums.EsapEnum.OrderEntity;
import com.vz.esap.translation.enums.EsapEnum.TnType;
import com.vz.esap.translation.exception.GenericException;
import com.vz.esap.translation.exception.TranslatorException;
import com.vz.esap.translation.order.dao.VOIPOrderDao;
import com.vz.esap.translation.order.model.Order;
import com.vz.esap.translation.order.model.OrderHeader;
import com.vz.esap.translation.order.model.OrderHeader.SuppType;
import com.vz.esap.translation.order.model.request.ParamInfo;
import com.vz.esap.translation.order.model.request.VOIPOrderRequest;
import com.vz.esap.translation.order.model.response.VoipOrderResponse;
import com.vz.esap.translation.order.parser.OrderParser;
import com.vz.esap.translation.order.service.CancelOrderService;
import com.vz.esap.translation.order.service.OrderServiceBase;
import com.vz.esap.translation.order.service.helper.OrderServiceHelperImpl;
import com.vz.esap.translation.order.transformer.EnterpriseTblOrderDataTransformer;
import com.vz.esap.translation.order.transformer.EnterpriseTblOrderServiceDataTransformer;
import com.vz.esap.translation.order.transformer.GroupTnTransformer;
import com.vz.esap.translation.order.transformer.TNTblOrderDetailsDataTransformer;

import EsapEnumPkg.WorkOrderEnum;
import reactor.util.CollectionUtils;

/**
 * @author baigkh
 *
 */
@Service
public class GroupTnOrderServiceImpl extends OrderServiceBase implements GroupTnOrderService {

	private static final Logger LOG = LoggerFactory.getLogger(GroupTnOrderServiceImpl.class);

	@Autowired
	private VOIPOrderDao voipOrderDao;

	@Autowired
	private EnterpriseTblOrderServiceDataTransformer enterpriseTblOrderServiceData;

	@Autowired
	private EnterpriseTblOrderDataTransformer enterpriseTblOrderData;

	@Autowired
	private GroupTnTransformer groupTnTransformer;

	@Autowired
	private TNTblOrderDetailsDataTransformer tnTblOrderDetailsData;

	@Autowired
	private OrderParser orderParserImpl;

	@Autowired
	private OrderServiceHelperImpl orderServiceHelperImpl;
	
	@Autowired
	private CancelOrderService cancelOrderServiceImpl;

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.vz.esap.translation.order.service.device.DeviceOrderService#
	 * processReleaseOrder(com.vz.esap.translation.dao.model.TblOrderDetails,
	 * com.vz.esap.translation.dao.model.TblOrder,
	 * com.vz.esap.translation.dao.model.TblEnvOrder,
	 * com.vz.esap.translation.order.model.request.VOIPOrderRequest, java.util.List)
	 */
	@Override
	public VoipOrderResponse processReleaseOrder(List<TblOrderDetails> batchTNOrderDetails,
			TblOrder tblOrderBeanValidation, TblEnvOrder tblEnvOrder, VOIPOrderRequest voipOrderRequest,
			List<TblOrderDetails> tblOrderDetailsList) throws GenericException {
		LOG.info("Entered - GroupTnOrderService.processReleaseOrder");

		VoipOrderResponse voipOrderResponse = null;
		OrderHeader orderHeader = null;
		GroupTNEntity grpTNEntity = null;
		GroupTNEntity grpTNEntityPrev = null;
		int orderVersion = 0;
		List<TnType> tnTypeList = null;
		List<TnType> tnListDistinct = null;
		boolean hasNewTnOrderForward = false;
		GroupTNEntity grpTNEntityAdd = null;
		GroupTNEntity grpTNEntityRemoved = null;
		List<String> tnActionList = null;
		List<String> tnActionListDistinct = null;
		GroupTNEntity grpTNEntityAddSysUpd = null;
		GroupTNEntity grpTNEntityRemovedSysUpd = null;

		try {
			if ("C".equalsIgnoreCase(voipOrderRequest.getOrderHeader().getOrderType())) {
				LOG.info("Going for TN MAC");
				//LOG.info("Going for Changed TN Entity");
				//retrieves n,r
				/*grpTNEntity = groupTnTransformer.transformOrderDetailsToGroupTn(tblOrderBeanValidation.getOrderId(),
						batchTNOrderDetails.get(0).getOrderDetailId(), null, false, Arrays.asList("o"));*/

				//LOG.info("Going for Inv TN Entity");
				//retrieves o,r
				/*grpTNEntityPrev = groupTnTransformer.transformOrderDetailsToGroupTn(tblOrderBeanValidation.getOrderId(),
						batchTNOrderDetails.get(0).getOrderDetailId(), null, false, Arrays.asList("n"));*/
				
				
				
				grpTNEntity = groupTnTransformer.transformOrderDetailsToGroupTn(tblOrderBeanValidation.getOrderId(),
						batchTNOrderDetails.get(0).getOrderDetailId(), "n", false, null);
				
				if (grpTNEntity == null) {
					LOG.info("GrpTNEntity for new is null so going for old 1");
					grpTNEntity = groupTnTransformer.transformOrderDetailsToGroupTn(tblOrderBeanValidation.getOrderId(),
							batchTNOrderDetails.get(0).getOrderDetailId(), "o", false, null);
					
				}	
				
			} else {
				grpTNEntity = groupTnTransformer.transformOrderDetailsToGroupTn(tblOrderBeanValidation.getOrderId(),
						batchTNOrderDetails.get(0).getOrderDetailId(), "n", false, null);
				
			}

			tnTypeList = new ArrayList<>();
			tnActionList = new ArrayList<>();
			
			for (TblOrderDetails detail : batchTNOrderDetails) {
				
				orderHeader = createOrderHeaderForGroupTnOrder(voipOrderRequest, grpTNEntity);
				orderHeader.setOrderingAction(orderHeader.getEntityAction());

				if ("I".equalsIgnoreCase(voipOrderRequest.getOrderHeader().getOrderType())) {
					grpTNEntity = groupTnTransformer.transformOrderDetailsToGroupTn(tblOrderBeanValidation.getOrderId(),
							detail.getOrderDetailId(), "n", false, null);

					LOG.info("+++++++++INSTALL grpTNEntity TN Count+++++++++ {}", grpTNEntity.getTnCount());
					LOG.info("Start the createReleaseOrders for TN for Install TN--> {}",
							grpTNEntity.getTnRecord().getTn());

					createReleaseOrders(voipOrderRequest, orderHeader, grpTNEntity, WorkOrderEnum.Status.WO_INIT,
							tblEnvOrder);

					LOG.info("END the createReleaseOrders for TN for Install TN--> {}",
							grpTNEntity.getTnRecord().getTn());
					
					//Start : Multiple TN Type Handle Install
					if (grpTNEntity != null && grpTNEntity.getTnRecord() != null && grpTNEntity.getTnRecord().getTnType() != null) {
						
						LOG.info("For TN = {} TN Type = {} TN Action = {}", grpTNEntity.getTnRecord().getTn(),
								grpTNEntity.getTnRecord().getTnType(), grpTNEntity.getEntityAction());
						
						tnTypeList.add(grpTNEntity.getTnRecord().getTnType());
						tnActionList.add(grpTNEntity.getEntityAction());
						
						
						if ("ADD".equalsIgnoreCase(grpTNEntity.getEntityAction())) {
							
							grpTNEntityAddSysUpd = grpTNEntity;
							
							LOG.info("grpTNEntityAddSysUpd.getEntityAction() --> {}", grpTNEntityAddSysUpd.getEntityAction());
						}
						
						
					}								
					//End : Multiple TN Type Handle Install

				} else if ("C".equalsIgnoreCase(voipOrderRequest.getOrderHeader().getOrderType())) {

					LOG.info("Inside MAC for TN and Order Details = {}", detail.getOrderDetailId());

					LOG.info("Getting Group TN for TOD action n");
					grpTNEntityAdd = groupTnTransformer.transformOrderDetailsToGroupTn(
							tblOrderBeanValidation.getOrderId(), detail.getOrderDetailId(), "n", false, null);

					LOG.info("Getting Group TN for TOD action o");
					grpTNEntityRemoved = groupTnTransformer.transformOrderDetailsToGroupTn(
							tblOrderBeanValidation.getOrderId(), detail.getOrderDetailId(), "o", false, null);
					
					if (grpTNEntityAdd != null && "ADD".equalsIgnoreCase(grpTNEntityAdd.getEntityAction())
							&& grpTNEntityAdd.getTnRecord() != null) {

						LOG.info("START MAC createReleaseOrders for ADD TN for TN = {} and Group TN Entity Action = {}",
								grpTNEntityAdd.getTnRecord().getTn(), grpTNEntityAdd.getEntityAction());

						createReleaseOrders(voipOrderRequest, orderHeader, grpTNEntityAdd, WorkOrderEnum.Status.WO_INIT,
								tblEnvOrder);

						LOG.info("END the createReleaseOrders for TN MAC for ADD TN--> {}",
								grpTNEntityAdd.getTnRecord().getTn());

						LOG.info("For TN = {} TN Type = {} TN Action = {}", grpTNEntityAdd.getTnRecord().getTn(),
								grpTNEntityAdd.getTnRecord().getTnType(), grpTNEntityAdd.getEntityAction());

						tnTypeList.add(grpTNEntityAdd.getTnRecord().getTnType());
						tnActionList.add(grpTNEntityAdd.getEntityAction());
						
						LOG.info("Getting Group TN for TOD action n For SysUpd");
						grpTNEntityAddSysUpd = groupTnTransformer.transformOrderDetailsToGroupTn(
								tblOrderBeanValidation.getOrderId(), detail.getOrderDetailId(), "n", false, null);

						LOG.info("grpTNEntityAddSysUpd.getTnRecord().getTnType() = {}",
								grpTNEntityAddSysUpd.getTnRecord().getTnType());

					} else if (grpTNEntityRemoved != null && (Arrays.asList("REMOVE", "REMOVED", "CANCEL").contains(
							grpTNEntityRemoved.getEntityAction()) && grpTNEntityRemoved.getTnRecord() != null)) {

						LOG.info(
								"START MAC createReleaseOrders for DELETE TN for TN = {} and Group TN Entity Action = {}",
								grpTNEntityRemoved.getTnRecord().getTn(), grpTNEntityRemoved.getEntityAction());

						createReleaseOrders(voipOrderRequest, orderHeader, grpTNEntityRemoved,
								WorkOrderEnum.Status.WO_INIT, tblEnvOrder);

						LOG.info("END the createReleaseOrders for TN MAC for DEL TN --> {}",
								grpTNEntityRemoved.getTnRecord().getTn());

						LOG.info("For TN = {} TN Type = {} TN Action = {}", grpTNEntityRemoved.getTnRecord().getTn(),
								grpTNEntityRemoved.getTnRecord().getTnType(), grpTNEntityRemoved.getEntityAction());

						tnTypeList.add(grpTNEntityRemoved.getTnRecord().getTnType());
						tnActionList.add(grpTNEntityRemoved.getEntityAction());
						
						LOG.info("Getting Group TN for TOD action o for Sys Upd");
						grpTNEntityRemovedSysUpd = groupTnTransformer.transformOrderDetailsToGroupTn(
								tblOrderBeanValidation.getOrderId(), detail.getOrderDetailId(), "o", false, null);
					}
				}
			}
			LOG.info("Trunk Type Size before distinct - {}", tnTypeList.size());
			
			orderVersion = Integer.parseInt(voipOrderRequest.getOrderHeader().getWorkOrderVersion());
			LOG.info("Order version:: {}", orderVersion);
			
			if (orderVersion != 0) {
				orderServiceHelperImpl.handlePreviousOrder(voipOrderRequest, null, tblEnvOrder.getEnvOrderId());
			}
			
			hasNewTnOrderForward = orderServiceHelperImpl.hasNewTnOrder(tblEnvOrder.getEnvOrderId(),
					FlowPath.F.toString());
			
			
			//Start : Multiple TN Type Handle
			if (hasNewTnOrderForward) {
				LOG.info("Into System Update hasNewTnOrderForward");
				
				
				tnActionListDistinct = tnActionList.stream().distinct().collect(Collectors.toList());
				LOG.info("TN Action Size after distinct - {}", tnActionListDistinct.size());
				
				tnListDistinct = tnTypeList.stream().distinct().collect(Collectors.toList());				
				LOG.info("Trunk Type Size after distinct - {}", tnListDistinct.size());
				
				
				
				for (TnType tnType : tnListDistinct) {
					if (grpTNEntity != null && grpTNEntity.getTnRecord() != null) {
						grpTNEntity.getTnRecord().setTnType(tnType);	
						
					}

					for (String tnAction : tnActionListDistinct) {
						
						LOG.info("TN Type = {} and TN Action = {}", tnType, tnAction);
						
						if ("C".equalsIgnoreCase(voipOrderRequest.getOrderHeader().getOrderType())) {

							if ("ADD".equalsIgnoreCase(tnAction)) {
								orderHeader.setOrderingAction("I");
								orderHeader.setEntityAction("NC");
								orderHeader.setOrderType("I");

								if (grpTNEntityAddSysUpd != null) {
									grpTNEntityAddSysUpd.setEntityAction(tnAction);

								}

								if (grpTNEntityAddSysUpd.getTnRecord() != null && tnType != null) {
									grpTNEntityAddSysUpd.getTnRecord().setTnType(tnType);

									LOG.info("For System Update grpTNEntityAddSysUpd.getTnRecord().getTnType() = {}",
											grpTNEntityAddSysUpd.getTnRecord().getTnType());

								}

								createSystemUpdateReleaseOrders(orderHeader, grpTNEntityAddSysUpd, grpTNEntityPrev,
										WorkOrderEnum.Status.WO_INIT, tblEnvOrder);

							}

							if ("REMOVE".equalsIgnoreCase(tnAction) || "CANCEL".equalsIgnoreCase(tnAction)) {
								orderHeader.setOrderingAction("D");
								orderHeader.setOrderType("D");
								orderHeader.setFunctionCode("REL_DEACTIVATE");

								if (grpTNEntityRemovedSysUpd != null) {
									grpTNEntityRemovedSysUpd.setEntityAction(tnAction);

								}

								createSystemUpdateReleaseOrders(orderHeader, grpTNEntityRemovedSysUpd, grpTNEntityPrev,
										WorkOrderEnum.Status.WO_INIT, tblEnvOrder);

							}

						} else {
							//If CANCEL - Reverse Order will be created by handle previous pass for non Change Order
							if (!"CANCEL".equalsIgnoreCase(tnAction)) {
								createSystemUpdateReleaseOrders(orderHeader, grpTNEntityAddSysUpd, grpTNEntityPrev,
										WorkOrderEnum.Status.WO_INIT, tblEnvOrder);
								
							}							
						}					
					}
				}
			}
			
			//End : Multiple TN Type Handle
			
		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new GenericException(GenericException.GENERIC_EXCEPTION, "Exception in the provide input arguments");
		}

		LOG.info("Exit -  GroupTnOrderService.processReleaseOrder");
		return voipOrderResponse;

	}

	/**
	 * @param orderHeader
	 * @param deviceEntity
	 * @param tblOrderDetailsList
	 * @param tblOrderBeanValidation
	 * @param status
	 * @param tblEnvOrderObject
	 * @return isCreated
	 * @throws TranslatorException
	 * @throws GenericException
	 */
	long createReleaseOrders(VOIPOrderRequest voipOrderRequest, OrderHeader orderHeader, GroupTNEntity groupTnEntity,
			int status, TblEnvOrder tblEnvOrderObject) throws TranslatorException, GenericException {
		LOG.info("Entered - createReleaseOrders for TN --> {}", groupTnEntity.getTnRecord().getTn());
		Order order = null;
		TblOrder tblOrderObject = null;
		List<TblOrderService> tblOrderServiceList = null;
		List<TblEnvOrder> tblEnvOrderListPrev = null;
		List<TblOrder> tblOrderListPrev = null;
		List<TblOrderDetails> tblOrderDetailsListPrev = null;
		GroupTNEntity grpTNEntityPrev = null;
		boolean isTNDropped = false;
		long tblOrderId = -1;

		try {
			order = new Order();

			orderHeader.setOrderStatus(status);
			order.setOrderHeader(orderHeader);

			if (groupTnEntity == null) {
				groupTnEntity = new GroupTNEntity();
			}
			// :create order
			LOG.info("createOrders start creating GroupTnEntity orders");

			if (null != tblEnvOrderObject.getEnvOrderId())
				orderHeader.setEnvOrderId(tblEnvOrderObject.getEnvOrderId());
			if (null != tblEnvOrderObject.getProjectId())
				orderHeader.setProjectId(tblEnvOrderObject.getProjectId());
			orderHeader.setEnvOrderId(tblEnvOrderObject.getEnvOrderId());
			orderHeader.setProjectId(tblEnvOrderObject.getProjectId());
			orderHeader.setCustomerId(tblEnvOrderObject.getEnterpriseId());
			orderHeader.setEnterpriseId(tblEnvOrderObject.getEnterpriseId());
			orderHeader.setLocationId(tblEnvOrderObject.getLocationId());
			orderHeader.setRegion(tblEnvOrderObject.getRegion());

			LOG.info("groupTnEntity:"+groupTnEntity);
			order.setOrderHeader(orderHeader);
			order.setGroupTnEntity(groupTnEntity);
			// :create order

			int orderVersion = Integer.parseInt(voipOrderRequest.getOrderHeader().getWorkOrderVersion());
			LOG.info("Order version:: {}", orderVersion);

			if (orderVersion > 0) {
				VOIPOrderRequest voipOrderRequestPrev = orderParserImpl.getCorrectPrevPassVoipOrderRequest(voipOrderRequest);
				//voipOrderRequestPrev.getOrderHeader().setWorkOrderVersion(Integer.toString(orderVersion - 1));

				tblEnvOrderListPrev = orderServiceHelperImpl.getMatchingPrevPassEnvOrder(voipOrderRequestPrev, 0,
						WorkOrderEnum.OrderClassify.RELEASE);

				LOG.info("ENV ORDER ID FOR TN::{}", tblEnvOrderListPrev.get(0).getEnvOrderId());
				
				if (TnType.TWO_WAY_TN.equals(groupTnEntity.getTnRecord().getTnType())) {
					tblOrderListPrev = orderServiceHelperImpl.getMatchingPrevPassOrder(tblEnvOrderListPrev.get(0),
							OrderEntity.TWO_WAY_TN);
				} else if (TnType.INBOUND_TN.equals(groupTnEntity.getTnRecord().getTnType())) {
					tblOrderListPrev = orderServiceHelperImpl.getMatchingPrevPassOrder(tblEnvOrderListPrev.get(0),
							OrderEntity.INBOUND_TN);
				} else if (TnType.DID_TN.equals(groupTnEntity.getTnRecord().getTnType())) {
					tblOrderListPrev = orderServiceHelperImpl.getMatchingPrevPassOrder(tblEnvOrderListPrev.get(0),
							OrderEntity.DID_TN);
				} else if (TnType.LINE_TN.equals(groupTnEntity.getTnRecord().getTnType())) {
					tblOrderListPrev = orderServiceHelperImpl.getMatchingPrevPassOrder(tblEnvOrderListPrev.get(0),
							OrderEntity.LINE_TN);
				}
				
				long prevMatchingTnOrderId = -1;
				
				for (TblOrder tblOrderPrev : tblOrderListPrev) {
					LOG.info("TBL ORDER ID INSIDE LOOP:: {} And Account Id:: {}", tblOrderPrev.getOrderId(),
							tblOrderPrev.getAccountNumber());
					
					if (tblOrderPrev.getAccountNumber().equalsIgnoreCase(groupTnEntity.getTnRecord().getTn())
							&& !"CANCEL".equalsIgnoreCase(groupTnEntity.getEntityAction())) {
						
						LOG.info("Inside TN Order loop for TN Matched = {} For Previous Order Id = {}",
								groupTnEntity.getTnRecord().getTn(), tblOrderPrev.getOrderId());
						
						prevMatchingTnOrderId = tblOrderPrev.getOrderId();
						
						tblOrderDetailsListPrev = orderServiceHelperImpl.getMatchingTnOrderDetails(tblOrderPrev);	
						
						LOG.info("TBL_ORDER_DETAILS records size::{}", tblOrderDetailsListPrev.size());						
					}
					
					if(tblOrderPrev.getAccountNumber().equalsIgnoreCase(groupTnEntity.getTnRecord().getTn())
							&& "CANCEL".equalsIgnoreCase(groupTnEntity.getEntityAction())) {
						isTNDropped = true;
					}
				}
				if (!CollectionUtils.isEmpty(tblOrderDetailsListPrev)) {
					
					LOG.info("Starting Flow For Previous Order Details");
				
					grpTNEntityPrev = groupTnTransformer.transformOrderDetailsToGroupTn(
							prevMatchingTnOrderId, tblOrderDetailsListPrev.get(0).getOrderDetailId(),
							"n", false, null);
					
					if (tblEnvOrderListPrev != null) {
						grpTNEntityPrev.setEnvOrderId(tblEnvOrderListPrev.get(0).getEnvOrderId());
						//Fix for Supp dueDate Scenario which is missing IB Trunk Data - Start						
						groupTnEntity.setDeviceName(grpTNEntityPrev.getDeviceName());
						groupTnEntity.getTnRecord().setDeviceName(grpTNEntityPrev.getDeviceName());
						//Fix for Supp dueDate Scenario which is missing IB Trunk Data - End
					}
					grpTNEntityPrev.setInternalOrderId(tblOrderDetailsListPrev.get(0).getOrderId());

					LOG.info("grpTNEntityPrev::{}::{}", grpTNEntityPrev.getLocationId(),
							grpTNEntityPrev.getGroupTNId());
					LOG.info("grpTNEntity::{}::{}", groupTnEntity.getLocationId(), groupTnEntity.getGroupTNId());
					
				}
				if (voipOrderRequest.getOrderHeader().getSuppType() != null
						&& voipOrderRequest.getOrderHeader().getSuppType().equals(SuppType.CANCEL.toString()))
					voipOrderRequest.getOrderHeader().setSuppType(SuppType.CANCEL.toString());
				else
					voipOrderRequest.getOrderHeader().setSuppType(SuppType.SUPP.toString());
			}
			if (groupTnEntity.getTnRecord() != null && !isTNDropped) {
				LOG.info("THE TN = {} WITH TN TYPE {}", groupTnEntity.getTnRecord().getTn(),
						groupTnEntity.getTnRecord().getTnType());

				if (TnType.TWO_WAY_TN.equals(groupTnEntity.getTnRecord().getTnType())) {
					tblOrderObject = enterpriseTblOrderData.prepareTblOrderDataFromOrder(order, 67L);
					orderHeader.setEntityType(EsapEnum.OrderEntity.TWO_WAY_TN.getIndex());
					
				} else if (TnType.INBOUND_TN.equals(groupTnEntity.getTnRecord().getTnType())) {
					tblOrderObject = enterpriseTblOrderData.prepareTblOrderDataFromOrder(order, 68L);
					orderHeader.setEntityType(EsapEnum.OrderEntity.INBOUND_TN.getIndex());
					
				} else if (TnType.DID_TN.equals(groupTnEntity.getTnRecord().getTnType())) {
					tblOrderObject = enterpriseTblOrderData.prepareTblOrderDataFromOrder(order, 72L);
					orderHeader.setEntityType(EsapEnum.OrderEntity.DID_TN.getIndex());
					
				} else if (TnType.LINE_TN.equals(groupTnEntity.getTnRecord().getTnType())) {
					tblOrderObject = enterpriseTblOrderData.prepareTblOrderDataFromOrder(order, 71L);
					orderHeader.setEntityType(EsapEnum.OrderEntity.LINE_TN.getIndex());
				}
				
				if (tblOrderObject == null) {
					throw new TranslatorException(TranslatorException.ErrorCode.ORDER_CREATION_FAILURE,
							"Exception is occured while creating Order in createReleaseOrders");
				}
			}
			
			ParamInfo headerParamInfo = null;
			ParamInfo entityParamInfo = null;
			String action = null;
			
			if ("I".equalsIgnoreCase(orderHeader.getOrderingAction()) && !isTNDropped) {				
				if (grpTNEntityPrev != null) {
					LOG.info("grpTNEntityPrev is not null");
					headerParamInfo = tnTblOrderDetailsData.prepareTblOrderDetailsHeaderParamData(order,
							grpTNEntityPrev, true);

					LOG.info("grpTNEntityPrev.getTnRecord() --> {}", grpTNEntityPrev.getTnRecord());
					LOG.info("grpTNEntityPrev.getDeviceName() --> {}", grpTNEntityPrev.getDeviceName());
					
					entityParamInfo = tnTblOrderDetailsData.prepareTblOrderDetailsEntityParamDataForGroupTn(
							grpTNEntityPrev, groupTnEntity, true, null);
					
					if (entityParamInfo != null && entityParamInfo.getAction() != null
							&& entityParamInfo.getAction().equals("C")) {
						LOG.info("entityParamInfo.getAction(): {}", entityParamInfo.getAction());

						orderHeader.setEntityAction("C");
						entityParamInfo.addNotNullValChild("TN_INV_CHANGE", "Y", "n");

					} else if (entityParamInfo != null && entityParamInfo.getAction() != null
							&& entityParamInfo.getAction().equals("NC")) {
						LOG.info("entityParamInfo.getAction(): {}", entityParamInfo.getAction());
						orderHeader.setEntityAction("NC");
						entityParamInfo.addNotNullValChild("TN_INV_CHANGE", "N", "n");
					}
				} else {
					LOG.info("createOrders start creating TN entity order details");
					headerParamInfo = tnTblOrderDetailsData.prepareTblOrderDetailsHeaderParamData(order);
					entityParamInfo = tnTblOrderDetailsData.prepareTblOrderDetailsEntityParamDataForGroupTn(order);
				}
				
			} else if ("C".equalsIgnoreCase(orderHeader.getOrderingAction()) && !isTNDropped) {
				
				LOG.info("Inside \"C\".equalsIgnoreCase(orderHeader.getOrderingAction()) && !isTNDropped");
				
				if (grpTNEntityPrev != null) {
					LOG.info("grpTNEntityPrev is not null");

					headerParamInfo = tnTblOrderDetailsData.prepareTblOrderDetailsHeaderParamData(order,
							grpTNEntityPrev, true);

					entityParamInfo = tnTblOrderDetailsData.prepareTblOrderDetailsEntityParamDataForGroupTn(
							grpTNEntityPrev, groupTnEntity, true, null);

					if (entityParamInfo != null && entityParamInfo.getAction() != null
							&& entityParamInfo.getAction().equals("C")) {
						LOG.info("entityParamInfo.getAction(): {}", entityParamInfo.getAction());

						orderHeader.setEntityAction("C");
						entityParamInfo.addNotNullValChild("TN_INV_CHANGE", "Y", "n");

					} else if (entityParamInfo != null && entityParamInfo.getAction() != null
							&& entityParamInfo.getAction().equals("NC")) {
						LOG.info("entityParamInfo.getAction(): {}", entityParamInfo.getAction());
						orderHeader.setEntityAction("NC");
						entityParamInfo.addNotNullValChild("TN_INV_CHANGE", "N", "n");
					}
					
				} else {
					
					LOG.info(
							"createOrders start creating TN entity order details for TN = {} for Group TN Entity Action = {}",
							order.getGroupTnEntity().getTnRecord().getTn(), order.getGroupTnEntity().getEntityAction());
					LOG.info("1111order.getOrderHeader().getOrderType() -->{}", order.getOrderHeader().getOrderType());
					LOG.info("1111order.getOrderHeader().getEntityAction() -->{}", order.getOrderHeader().getEntityAction());

					if ("ADD".equalsIgnoreCase(order.getGroupTnEntity().getEntityAction())) {
						action = "I";
						
					} else if ("REMOVE".equalsIgnoreCase(order.getGroupTnEntity().getEntityAction())
							|| "CANCEL".equalsIgnoreCase(order.getGroupTnEntity().getEntityAction())) {
						action = "O";

					}
					
					headerParamInfo = tnTblOrderDetailsData.prepareTblOrderDetailsHeaderParamData(order, action);
					entityParamInfo = tnTblOrderDetailsData.prepareTblOrderDetailsEntityParamDataForGroupTn(order,
							action);
					
					LOG.info("1111entityParamInfo.getAction() -->{}", entityParamInfo.getAction());
				}
			}
			
			LOG.info("orderHeader.getEntityAction()-TN : {} ", orderHeader.getEntityAction());
			LOG.info("isTNDropped = {} ", isTNDropped);
						
			if (null != headerParamInfo && !"NC".equalsIgnoreCase(orderHeader.getEntityAction()) && !isTNDropped) {
				
				LOG.info(
						"INSIDE null != headerParamInfo && !\"NC\".equalsIgnoreCase(orderHeader.getEntityAction()) && !isTNDropped");
				
				//ESVRRS-18523 :: START :: Supp other on failed Entity fix.
				LOG.info("Order version:: {}", orderVersion);
				
				if (orderVersion > 0) {
					List<TblOrder> tblOrderListSysUpdatePrev = null;
					LOG.info("Previous TN of type :: {}, order status :: {} ", orderHeader.getEntityType(), tblOrderListPrev.get(0).getOrderStatus() );
					LOG.info("TN records count - {}", tblOrderListPrev.size());
					if(WorkOrderEnum.Status.WO_FAILED == tblOrderListPrev.get(0).getOrderStatus()) {
						LOG.info("Creating reverse order for TN with order id {} ", tblOrderListPrev.get(0).getOrderId());
						// Reverse Order Creation..It may be EntityAction I OR C
						cancelOrderServiceImpl.createReverseOrder(voipOrderRequest, tblOrderListPrev, tblEnvOrderObject);
						LOG.info("Creating reverse order for TN with order id {} COMPLETED !!!!", tblOrderListPrev.get(0).getOrderId());
						
						//Creating Forward order...
						LOG.info("Creating Forward Order..... ");
						headerParamInfo = tnTblOrderDetailsData.prepareTblOrderDetailsHeaderParamData(order);
						entityParamInfo = tnTblOrderDetailsData.prepareTblOrderDetailsEntityParamDataForGroupTn(order);
						orderHeader.setEntityAction("I");
						LOG.info("Creating Forward Order.....COMPLETED !!! ");
					}
					
					//Handling failed System Update.
					tblOrderListSysUpdatePrev = orderServiceHelperImpl.getMatchingPrevPassOrder(tblEnvOrderListPrev.get(0),
							OrderEntity.SYSTEM_UPDATE);
					
					if(WorkOrderEnum.Status.WO_FAILED == tblOrderListSysUpdatePrev.get(0).getOrderStatus()) {
						LOG.info("Creating reverse order for SystemUpdate with order id {} ", tblOrderListSysUpdatePrev.get(0).getOrderId());
						// Reverse Order Creation..It may be EntityAction I OR C
						cancelOrderServiceImpl.createReverseOrder(voipOrderRequest, tblOrderListSysUpdatePrev, tblEnvOrderObject);
						LOG.info("Creating reverse order for SystemUpdate with order id {} COMPLETED !!!!", tblOrderListSysUpdatePrev.get(0).getOrderId());
					}
				}
				//ESVRRS-18523 :: END
				
				headerParamInfo.addChildParam(entityParamInfo);
				voipOrderDao.createTblOrder(tblOrderObject);

				LOG.info("Tbl_Order Created for TN , Order Id : {}", tblOrderObject.getOrderId());

				// :create order Details tnTblOrderDetailsData
				
				if (entityParamInfo != null && entityParamInfo.getAction() != null) {
					
					LOG.info("TN entityParamInfo.getAction() --> {}", entityParamInfo.getAction());
					
					voipOrderDao.populateOrderDetails(tblOrderObject, headerParamInfo.getChildParams(),
							entityParamInfo.getAction(), 0, 0);
					
				} else {
					voipOrderDao.populateOrderDetails(tblOrderObject, headerParamInfo.getChildParams(), "n", 0, 0);
					
				}

				// :create service entry for WF
				LOG.info("createOrders start creating service for TN entity");
				orderHeader.setFlowPath(FlowPath.valueOf(tblOrderObject.getFlowPath()));
				orderHeader.setTblOrderId(tblOrderObject.getOrderId());
				orderHeader.setAction(EsapEnum.OrderAction.I);

				order.setOrderHeader(orderHeader);

				tblOrderServiceList = enterpriseTblOrderServiceData.prepareTblOrderServiceData(order, null, null);
				LOG.info("Retail Order Service Count : {}", tblOrderServiceList.size());

				for (TblOrderService tblOrderService : tblOrderServiceList) {
					voipOrderDao.createTblOrderService(tblOrderService);
				}

				voipOrderDao.updateTblOrderStatus(tblOrderObject.getOrderId(), WorkOrderEnum.Status.WO_INIT);

			} else if (grpTNEntityPrev != null && "NC".equalsIgnoreCase(orderHeader.getEntityAction()) && !isTNDropped) {
				// No internal Order id for groupTN
				orderServiceHelperImpl.handleSuppOrderWithNoChange(tblEnvOrderObject.getEnvOrderId(),
						grpTNEntityPrev.getInternalOrderId(), tblEnvOrderObject);

			}
			
			if(tblOrderObject != null) {
				tblOrderId = tblOrderObject.getOrderId();
			}
			
		} catch (TranslatorException ex) {
			LOG.error("Exception {} {}", ex.getMessage(), ex);
			throw new TranslatorException(ex.getErrorCode(), ex.getMessage());
		} catch (Exception e) {
			LOG.error("Exception {} {}", e.getMessage(), e);
			throw new GenericException(GenericException.GENERIC_EXCEPTION,
					"Exception in the provide input arguments-" + e);
		}
		LOG.info("Exit - createReleaseOrders");
		return tblOrderId;
	}

	@Override
	public long createSystemUpdateReleaseOrders(OrderHeader orderHeader, GroupTNEntity groupTnEntity,
			GroupTNEntity grpTNEntityPrev, int status, TblEnvOrder tblEnvOrderObject)
			throws TranslatorException, GenericException {
		LOG.info("Entered - createSystemUpdateOrders");
		Order order = null;
		TblOrder tblOrderObject = null;
		List<TblOrderService> tblOrderServiceList = null;
		ParamInfo headerParamInfo = null;
		ParamInfo entityParamInfo = null;
		
		try {
			order = new Order();
			
			if (orderHeader == null) {
				orderHeader = new OrderHeader();
			}

			orderHeader.setOrderStatus(status);
			order.setOrderHeader(orderHeader);

			if (groupTnEntity == null) {
				groupTnEntity = new GroupTNEntity();
			}

			// :create order
			LOG.info("createOrders start creating System Update TN entity orders");

			if (null != tblEnvOrderObject.getEnvOrderId())
				orderHeader.setEnvOrderId(tblEnvOrderObject.getEnvOrderId());
			if (null != tblEnvOrderObject.getProjectId())
				orderHeader.setProjectId(tblEnvOrderObject.getProjectId());
			orderHeader.setEnvOrderId(tblEnvOrderObject.getEnvOrderId());
			orderHeader.setProjectId(tblEnvOrderObject.getProjectId());
			orderHeader.setCustomerId(tblEnvOrderObject.getEnterpriseId());
			orderHeader.setEnterpriseId(tblEnvOrderObject.getEnterpriseId());
			orderHeader.setLocationId(tblEnvOrderObject.getLocationId());
			orderHeader.setRegion(tblEnvOrderObject.getRegion());

			order.setOrderHeader(orderHeader);
			order.setGroupTnEntity(groupTnEntity);

			// 23 is SYSTEM_UPDATE
			tblOrderObject = enterpriseTblOrderData.prepareTblOrderDataFromOrder(order, 23L);
			voipOrderDao.createTblOrder(tblOrderObject);
			
			LOG.info("Tbl_Order Created for System Update , Order Id : {}", tblOrderObject.getOrderId());

			// :create order Details tnTblOrderDetailsData
			LOG.info("createOrders start creating System Update entity order details");
			
			headerParamInfo = tnTblOrderDetailsData.prepareTblOrderDetailsHeaderParamData(order);
			entityParamInfo = tnTblOrderDetailsData.prepareTblOrderDetailsEntityParamDataForSystemUpdate(order,
					null);

			if (null != headerParamInfo) {
				headerParamInfo.addChildParam(entityParamInfo);
				if (entityParamInfo != null && entityParamInfo.getAction() != null)
					voipOrderDao.populateOrderDetails(tblOrderObject, headerParamInfo.getChildParams(),
							entityParamInfo.getAction(), 0, 0);
				else
					voipOrderDao.populateOrderDetails(tblOrderObject, headerParamInfo.getChildParams(), "n", 0, 0);

			}

			// :create service entry for WF
			LOG.info(
					"createOrders start creating service for System Update entity for EntityAction ={} And OrderingAction ={}",
					orderHeader.getEntityAction(), orderHeader.getOrderingAction());						
			
			if("I".equalsIgnoreCase(orderHeader.getOrderingAction()) 
					&& "NC".equalsIgnoreCase(orderHeader.getEntityAction())) {
				orderHeader.setEntityAction("I");
				
			}else if("I".equalsIgnoreCase(orderHeader.getOrderingAction()) 
					&& "C".equalsIgnoreCase(orderHeader.getEntityAction())) {
				orderHeader.setEntityAction("C");
				
			}else if("C".equalsIgnoreCase(orderHeader.getOrderingAction())) {
				orderHeader.setEntityAction("C");
				
			}else if("D".equalsIgnoreCase(orderHeader.getOrderingAction())) {
				orderHeader.setEntityAction("O");
				
			}
			
			orderHeader.setFlowPath(FlowPath.valueOf(tblOrderObject.getFlowPath()));
			orderHeader.setTblOrderId(tblOrderObject.getOrderId());
			orderHeader.setEntityType(EsapEnum.OrderEntity.SYSTEM_UPDATE.getIndex());

			order.setOrderHeader(orderHeader);

			tblOrderServiceList = enterpriseTblOrderServiceData.prepareTblOrderServiceData(order, null, null);

			LOG.info("Retail Order Service Count : {}", tblOrderServiceList.size());

			for (TblOrderService tblOrderService : tblOrderServiceList) {
				voipOrderDao.createTblOrderService(tblOrderService);
			}

			voipOrderDao.updateTblOrderStatus(tblOrderObject.getOrderId(), WorkOrderEnum.Status.WO_INIT);

		} catch (TranslatorException ex) {
			LOG.error("Exception {} ", ex.getMessage());
			throw new TranslatorException(ex.getErrorCode(), ex.getMessage());
		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new GenericException(GenericException.GENERIC_EXCEPTION, "Exception in the provide input arguments");
		}
		LOG.info("Exit - createSystemUpdateOrders");
		return tblOrderObject.getOrderId();
	}

}
