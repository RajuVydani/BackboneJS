package com.vz.esap.translation.order.model.pc;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;

import com.fasterxml.jackson.annotation.JsonProperty;

@XmlAccessorType(XmlAccessType.FIELD)
public class Specification {

	@XmlElement(name = "Name")
	@JsonProperty(value = "Name")
	private String name;

	@XmlElement(name = "Value")
	@JsonProperty(value = "Value")
	private String value;

	@XmlElement(name = "Code")
	@JsonProperty(value = "Code")
	private String code;

	@XmlElement(name = "ValueCode")
	@JsonProperty(value = "ValueCode")
	private String valueCode;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getValueCode() {
		return valueCode;
	}

	public void setValueCode(String valueCode) {
		this.valueCode = valueCode;
	}

	@Override
	public String toString() {
		return "ClassPojo [Name = " + name + ", Value = " + value + ", Code = " + code + ", ValueCode = " + valueCode
				+ "]";
	}
}
