package com.vz.esap.translation.order.parser;

import java.sql.SQLException;
import java.text.ParseException;
import java.util.ArrayList;

import com.vz.esap.translation.entity.GroupTNEntity;
import com.vz.esap.translation.entity.TrunkGroupEntity;
import com.vz.esap.translation.exception.TranslatorException;
import com.vz.esap.translation.order.model.request.VOIPOrderRequest;

public interface TNOrderParser {

	/**
	 * @param voipOrderRequest
	 * @return 5
	 * @throws TranslatorException
	 * @throws ParseException
	 */
	public int fetchTNDetailsFromPC(VOIPOrderRequest voipOrderRequest) throws TranslatorException;

	/**
	 * @param voipOrderRequest
	 * @param trunkGrpList
	 * @param stRange
	 * @param endRange
	 * @param tnCount TODO
	 * @return groupTNEntityList
	 * @throws TranslatorException
	 * @throws SQLException
	 */
	public ArrayList<GroupTNEntity> processGroupTNS(VOIPOrderRequest voipOrderRequest,
			ArrayList<TrunkGroupEntity> trunkGrpList, int stRange, int endRange, long tnCount)
			throws TranslatorException;

	int fetchChangeTNDetailsFromPC(VOIPOrderRequest voipOrderRequest) throws TranslatorException;

}
