package com.vz.esap.translation.order.model.pc;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;

import com.fasterxml.jackson.annotation.JsonProperty;

@XmlAccessorType(XmlAccessType.FIELD)
public class EmergencyCode {
	
	@XmlElement(name = "EmergencyNumber")
	@JsonProperty(value = "EmergencyNumber")
	private String emergencyNumber;

	@XmlElement(name = "EmergencyCode")
	@JsonProperty(value = "EmergencyCode")
	private String emergencyCode;

	public String getEmergencyNumber() {
		return emergencyNumber;
	}

	public void setEmergencyNumber(String EmergencyNumber) {
		this.emergencyNumber = EmergencyNumber;
	}

	public String getEmergencyCode() {
		return emergencyCode;
	}

	public void setEmergencyCode(String EmergencyCode) {
		this.emergencyCode = EmergencyCode;
	}

	@Override
	public String toString() {
		return "ClassPojo [EmergencyNumber = " + emergencyNumber + ", EmergencyCode = " + emergencyCode + "]";
	}
}
