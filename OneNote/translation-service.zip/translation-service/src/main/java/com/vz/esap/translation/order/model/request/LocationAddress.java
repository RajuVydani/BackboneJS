package com.vz.esap.translation.order.model.request;

public class LocationAddress {

	private String CountryName;

	private String State;

	private String AddressLine;

	private String Zip;

	private String CountryCode;

	private String City;

	public String getCountryName() {
		return CountryName;
	}

	public void setCountryName(String CountryName) {
		this.CountryName = CountryName;
	}

	public String getState() {
		return State;
	}

	public void setState(String State) {
		this.State = State;
	}

	public String getAddressLine() {
		return AddressLine;
	}

	public void setAddressLine(String AddressLine) {
		this.AddressLine = AddressLine;
	}

	public String getZip() {
		return Zip;
	}

	public void setZip(String Zip) {
		this.Zip = Zip;
	}

	public String getCountryCode() {
		return CountryCode;
	}

	public void setCountryCode(String CountryCode) {
		this.CountryCode = CountryCode;
	}

	public String getCity() {
		return City;
	}

	public void setCity(String City) {
		this.City = City;
	}

	public String toString() {
		return "ClassPojo [CountryName = " + CountryName + ", State = " + State + ", AddressLine = " + AddressLine
				+ ", Zip = " + Zip + ", CountryCode = " + CountryCode + ", City = " + City + "]";
	}
}
