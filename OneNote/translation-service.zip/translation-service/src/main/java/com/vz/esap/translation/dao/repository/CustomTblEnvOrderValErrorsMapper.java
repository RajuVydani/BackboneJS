package com.vz.esap.translation.dao.repository;

import com.vz.esap.translation.dao.model.TblEnvOrderValErrors;

public interface CustomTblEnvOrderValErrorsMapper extends
		TblEnvOrderValErrorsMapper {

	long persistTblEnvOrderValErrors(
			TblEnvOrderValErrors tblEnvOrderValErrorsObject);

}