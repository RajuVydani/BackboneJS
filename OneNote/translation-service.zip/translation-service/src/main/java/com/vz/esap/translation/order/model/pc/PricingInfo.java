package com.vz.esap.translation.order.model.pc;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;

import com.fasterxml.jackson.annotation.JsonProperty;

@XmlAccessorType(XmlAccessType.FIELD)
public class PricingInfo {

	@XmlElement(name = "ChargeType")
	@JsonProperty(value = "ChargeType")
	private String chargeType;

	@XmlElement(name = "CatalogVersionTime")
	@JsonProperty(value = "CatalogVersionTime")
	private String catalogVersionTime;

	@XmlElement(name = "UnitOfMeasure")
	@JsonProperty(value = "UnitOfMeasure")
	private String unitOfMeasure;

	@XmlElement(name = "BillTime")
	@JsonProperty(value = "BillTime")
	private String billTime;

	@XmlElement(name = "FeatureInstanceId")
	@JsonProperty(value = "FeatureInstanceId")
	private String featureInstanceId;

	@XmlElement(name = "ChargeFrequency")
	@JsonProperty(value = "ChargeFrequency")
	private String chargeFrequency;

	@XmlElement(name = "FeatureCode")
	@JsonProperty(value = "FeatureCode")
	private String featureCode;

	@XmlElement(name = "CurrencyCode")
	@JsonProperty(value = "CurrencyCode")
	private String currencyCode;

	public String getChargeType() {
		return chargeType;
	}

	public void setChargeType(String chargeType) {
		this.chargeType = chargeType;
	}

	public String getCatalogVersionTime() {
		return catalogVersionTime;
	}

	public void setCatalogVersionTime(String catalogVersionTime) {
		this.catalogVersionTime = catalogVersionTime;
	}

	public String getUnitOfMeasure() {
		return unitOfMeasure;
	}

	public void setUnitOfMeasure(String unitOfMeasure) {
		this.unitOfMeasure = unitOfMeasure;
	}

	public String getBillTime() {
		return billTime;
	}

	public void setBillTime(String billTime) {
		this.billTime = billTime;
	}

	public String getFeatureInstanceId() {
		return featureInstanceId;
	}

	public void setFeatureInstanceId(String featureInstanceId) {
		this.featureInstanceId = featureInstanceId;
	}

	public String getChargeFrequency() {
		return chargeFrequency;
	}

	public void setChargeFrequency(String chargeFrequency) {
		this.chargeFrequency = chargeFrequency;
	}

	public String getFeatureCode() {
		return featureCode;
	}

	public void setFeatureCode(String featureCode) {
		this.featureCode = featureCode;
	}

	public String getCurrencyCode() {
		return currencyCode;
	}

	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}

	@Override
	public String toString() {
		return "ClassPojo [ChargeType = " + chargeType + ", CatalogVersionTime = " + catalogVersionTime
				+ ", UnitOfMeasure = " + unitOfMeasure + ", BillTime = " + billTime + ", FeatureInstanceId = "
				+ featureInstanceId + ", ChargeFrequency = " + chargeFrequency + ", FeatureCode = " + featureCode
				+ ", CurrencyCode = " + currencyCode + "]";
	}
}
