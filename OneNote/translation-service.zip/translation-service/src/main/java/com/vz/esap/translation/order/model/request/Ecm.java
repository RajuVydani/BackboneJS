package com.vz.esap.translation.order.model.request;

public class Ecm {

	private String AddressId;

	private EmergencyCode[] EmergencyCode;

	public String getAddressId() {
		return AddressId;
	}

	public void setAddressId(String AddressId) {
		this.AddressId = AddressId;
	}

	public EmergencyCode[] getEmergencyCode() {
		return EmergencyCode;
	}

	public void setEmergencyCode(EmergencyCode[] EmergencyCode) {
		this.EmergencyCode = EmergencyCode;
	}

	public String toString() {
		return "ClassPojo [AddressId = " + AddressId + ", EmergencyCode = " + EmergencyCode + "]";
	}
}
