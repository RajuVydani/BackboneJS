package com.vz.esap.translation.order.transformer;

import java.util.LinkedHashMap;
import java.util.List;

import com.vz.esap.translation.dao.model.TblOrderDetails;
import com.vz.esap.translation.entity.ParamInfo;
import com.vz.esap.translation.exception.GenericException;

public interface ParamInfoTransformer {

	/**
	 * @param oldAttribs
	 * @param newAttribs
	 * @return ParamInfo
	 */
	ParamInfo getAttribParamInfo(LinkedHashMap<String, String> oldAttribs, LinkedHashMap<String, String> newAttribs);

	/**
	 * @param ordDetails
	 * @param parentParam
	 * @param startIdx
	 * @param parentTOD
	 * @return ParamInfo
	 * @throws GenericException 
	 */
	ParamInfo transformOrderDetailsToParamInfo(List<TblOrderDetails> ordDetails, ParamInfo parentParam, int startIdx,
			TblOrderDetails parentTOD) throws GenericException;

	/**
	 * @param attribMap
	 * @param action
	 * @return ParamInfo
	 */
	ParamInfo getAttribParamInfo(LinkedHashMap<String, String> attribMap, String action);

	/**
	 * @param todAct
	 * @return
	 */
	String translateTODActToPIAct(String todAct);

	
}
