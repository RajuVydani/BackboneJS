package com.vz.esap.translation.order.parser;

import static java.util.Arrays.stream;

import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.vz.esap.translation.dao.model.TblEnvOrder;
import com.vz.esap.translation.enums.EsapEnum.FunctionCode;
import com.vz.esap.translation.enums.EsapEnum.SolutionType;
import com.vz.esap.translation.exception.GenericException;
import com.vz.esap.translation.exception.TranslatorException;
import com.vz.esap.translation.order.model.OrderHeader.SuppType;
import com.vz.esap.translation.order.model.request.ConvergedService;
import com.vz.esap.translation.order.model.request.Feature;
import com.vz.esap.translation.order.model.request.OrderHeader;
import com.vz.esap.translation.order.model.request.VOIPOrderRequest;
import com.vz.esap.translation.order.service.helper.OrderServiceHelper;
import com.vz.esap.translation.util.InventoryUtil;

import EsapEnumPkg.WorkOrderEnum;

/**
 * @author chattni
 *
 */
@Component
public class OrderParserImpl implements OrderParser {

	private static final Logger LOG = LoggerFactory.getLogger(OrderParserImpl.class);

	@Autowired
	private OrderServiceHelper orderServiceHelperImpl;

	@Autowired
	private InventoryUtil inventoryUtil;

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.vz.esap.translation.order.parser.OrderParser#getProductDetails(com.vz.
	 * esap.translation.order.model.request.VOIPOrderRequest)
	 */
	@Override
	public Map<String, String> getProductDetails(VOIPOrderRequest voipOrderRequest)
			throws TranslatorException, GenericException {
		LOG.info("Entered getProductDetails for Legacy Solution Type : {} and Function Code as :{}",
				voipOrderRequest.getOrderHeader().getSolutionType(),
				voipOrderRequest.getOrderHeader().getFunctionCode());
		Map<String, String> productDetails = null;
		ConvergedService convergedService = null;
		productDetails = new HashMap<>();
		convergedService = voipOrderRequest.getConvergedService();
				
		if (voipOrderRequest.getOrderHeader().getFunctionCode().equalsIgnoreCase(FunctionCode.VALIDATE.toString())
				&& convergedService != null && convergedService.getFeature() != null
				&& "I".equalsIgnoreCase(voipOrderRequest.getOrderHeader().getOrderType())) {

			//Start: Session Fix Changes 
			List<Feature> esipPortFeat = stream(voipOrderRequest.getConvergedService().getFeature())
					.filter(feature -> "FET_ESI".equalsIgnoreCase(feature.getCode())).collect(Collectors.toList());

			LOG.debug("Is ESIP Port Present: {}", esipPortFeat);

			if (voipOrderRequest.getOrderHeader().getSolutionType() != null) {

				if ("SL_ESIP".equalsIgnoreCase(voipOrderRequest.getOrderHeader().getSolutionType().toString())
						&& esipPortFeat != null && !esipPortFeat.isEmpty())
					productDetails.put("SolutionType", SolutionType.ESIP_ESL.toString());
				else if ("SL_ESIP".equalsIgnoreCase(voipOrderRequest.getOrderHeader().getSolutionType().toString())
						&& esipPortFeat != null && esipPortFeat.isEmpty())
					productDetails.put("SolutionType", SolutionType.ESIP_EBL.toString());
				else if ("SL_IP_FLEX".equalsIgnoreCase(voipOrderRequest.getOrderHeader().getSolutionType().toString()))
					productDetails.put("SolutionType", SolutionType.IPFLEX.toString());
				else if ("PR_XO_HPBX".equalsIgnoreCase(voipOrderRequest.getOrderHeader().getSolutionType().toString()))
					productDetails.put("SolutionType", SolutionType.HPBX.toString());
			}
			
			//End: Session Fix Changes

			if (convergedService.getType() != null)
				productDetails.put("ProductType", convergedService.getType());

			for (Feature feature : convergedService.getFeature()) {
				if ("EFET_VOIP_ENT_LVL".equalsIgnoreCase(feature.getCode()))
					productDetails.put("EnterpriseFeatureType", feature.getCode());
				else if ("EFET_VOIP_LOC_LVL".equalsIgnoreCase(feature.getCode()))
					productDetails.put("LocationFeatureType", feature.getCode());
				else if ("FET_LOC_LVL".equalsIgnoreCase(feature.getCode()))
					productDetails.put("LocationFeatureType", feature.getCode());
			}
		} else if (voipOrderRequest.getOrderHeader().getFunctionCode().equalsIgnoreCase(FunctionCode.RELEASE.toString())
				&& "I".equalsIgnoreCase(voipOrderRequest.getOrderHeader().getOrderType())) {

			LOG.debug("Inside getProductDetails For Release with Lagacy Solution Type : {} And SUPP Type as : {} ",
					voipOrderRequest.getOrderHeader().getSolutionType(),
					voipOrderRequest.getOrderHeader().getSuppType());

			if (!SuppType.CANCEL.toString().equalsIgnoreCase(voipOrderRequest.getOrderHeader().getSuppType())) {

				List<TblEnvOrder> tblEnvOrderList = orderServiceHelperImpl
						.getMatchingValidationEnvOrder(voipOrderRequest);

				LOG.debug("Order Category : {}", tblEnvOrderList.get(0).getOrderCategory());

				if ("ESIP_ESL".equalsIgnoreCase(tblEnvOrderList.get(0).getOrderCategory()))
					productDetails.put("SolutionType", SolutionType.ESIP_ESL.toString());
				else if ("ESIP_EBL".equalsIgnoreCase(tblEnvOrderList.get(0).getOrderCategory()))
					productDetails.put("SolutionType", SolutionType.ESIP_EBL.toString());
				else if ("IPFLEX".equalsIgnoreCase(tblEnvOrderList.get(0).getOrderCategory()))
					productDetails.put("SolutionType", SolutionType.IPFLEX.toString());
				else if ("HPBX".equalsIgnoreCase(tblEnvOrderList.get(0).getOrderCategory()))
					productDetails.put("SolutionType", SolutionType.HPBX.toString());

			} else {

				VOIPOrderRequest voipOrderRequestPrev = getPrevPassVoipOrderRequest(voipOrderRequest);

				List<TblEnvOrder> tblEnvOrderList = orderServiceHelperImpl
						.getMatchingPrevPassEnvOrder(voipOrderRequestPrev, 0, WorkOrderEnum.OrderClassify.RELEASE);

				LOG.debug("Order Category : {}", tblEnvOrderList.get(0).getOrderCategory());

				if ("ESIP_ESL".equalsIgnoreCase(tblEnvOrderList.get(0).getOrderCategory()))
					productDetails.put("SolutionType", SolutionType.ESIP_ESL.toString());
				else if ("ESIP_EBL".equalsIgnoreCase(tblEnvOrderList.get(0).getOrderCategory()))
					productDetails.put("SolutionType", SolutionType.ESIP_EBL.toString());
				else if ("IPFLEX".equalsIgnoreCase(tblEnvOrderList.get(0).getOrderCategory()))
					productDetails.put("SolutionType", SolutionType.IPFLEX.toString());
				else if ("HPBX".equalsIgnoreCase(tblEnvOrderList.get(0).getOrderCategory()))
					productDetails.put("SolutionType", SolutionType.HPBX.toString());

			}

		} else if (FunctionCode.NBS_PROV_CONFIG.toString()
				.equalsIgnoreCase(voipOrderRequest.getOrderHeader().getFunctionCode())) {
			productDetails.put("SolutionType", SolutionType.ESIP_ESL.toString());
			
		} else if ("C".equalsIgnoreCase(voipOrderRequest.getOrderHeader().getOrderType())
				|| "D".equalsIgnoreCase(voipOrderRequest.getOrderHeader().getOrderType())) {

			Set<String> selectColumnSet = new HashSet<>();
			selectColumnSet.add("LOCATION_TYPE");

			Map<String, String> resultantRow = inventoryUtil.getTblLocationFromLocationId(
					voipOrderRequest.getOrderHeader().getVoipLocationId(), null, selectColumnSet);
			
			LOG.info("MACD Incoming Location Type --> {}", resultantRow.get("LOCATION_TYPE"));

			switch (resultantRow.get("LOCATION_TYPE")) {
			case "5":
				productDetails.put("SolutionType", SolutionType.ESIP_ESL.toString());
				break;

			case "6":
				productDetails.put("SolutionType", SolutionType.ESIP_EBL.toString());
				break;
				
			case "7":
				productDetails.put("SolutionType", SolutionType.HPBX.toString());
				break;
				
			case "8":
				productDetails.put("SolutionType", SolutionType.HPBX.toString());
				break;

			case "9":
				productDetails.put("SolutionType", SolutionType.IPFLEX.toString());
				break;

			default:
				break;
			}
		} else if (FunctionCode.CIRCUIT_INFO.toString()
				.equalsIgnoreCase(voipOrderRequest.getOrderHeader().getFunctionCode())) {

			List<TblEnvOrder> tblEnvOrderList = orderServiceHelperImpl
					.getMatchingValidationEnvOrder(voipOrderRequest);

			LOG.debug("Order Category : {}", tblEnvOrderList.get(0).getOrderCategory());

			if ("ESIP_ESL".equalsIgnoreCase(tblEnvOrderList.get(0).getOrderCategory()))
				productDetails.put("SolutionType", SolutionType.ESIP_ESL.toString());
			else if ("ESIP_EBL".equalsIgnoreCase(tblEnvOrderList.get(0).getOrderCategory()))
				productDetails.put("SolutionType", SolutionType.ESIP_EBL.toString());
			else if ("IPFLEX".equalsIgnoreCase(tblEnvOrderList.get(0).getOrderCategory()))
				productDetails.put("SolutionType", SolutionType.IPFLEX.toString());
			else if ("HPBX".equalsIgnoreCase(tblEnvOrderList.get(0).getOrderCategory()))
				productDetails.put("SolutionType", SolutionType.HPBX.toString());
			
		} else if (Arrays.asList(FunctionCode.GET_LOC_INFO.toString(), FunctionCode.LNP_ACTIVATE.toString())
				.contains(voipOrderRequest.getOrderHeader().getFunctionCode())) {

			Set<String> selectColumnSet = new HashSet<>();
			selectColumnSet.add("LOCATION_TYPE");

			Map<String, String> resultantRow = inventoryUtil.getTblLocationFromLocationId(
					voipOrderRequest.getOrderHeader().getVoipLocationId(), null, selectColumnSet);

			LOG.info("Incoming Location Type --> {}",(resultantRow!=null && resultantRow.get("LOCATION_TYPE") != null)? resultantRow.get("LOCATION_TYPE"):"Location doesn't exists");

			if (resultantRow!=null && resultantRow.get("LOCATION_TYPE") != null) {
				
				switch (resultantRow.get("LOCATION_TYPE")) {
				case "5":
					productDetails.put("SolutionType", SolutionType.ESIP_ESL.toString());
					break;

				case "6":
					productDetails.put("SolutionType", SolutionType.ESIP_EBL.toString());
					break;

				case "7":
					productDetails.put("SolutionType", SolutionType.HPBX.toString());
					break;

				case "8":
					productDetails.put("SolutionType", SolutionType.HPBX.toString());
					break;

				case "9":
					productDetails.put("SolutionType", SolutionType.IPFLEX.toString());
					break;

				default:
					break;

				}
			} else {
				productDetails.put("SolutionType", orderServiceHelperImpl
						.getSolutionTypeFromBodReuest(voipOrderRequest.getOrderHeader().getSolutionType().toString())
						.toString());

			}
			
		} else if (FunctionCode.PIT.toString()
				.equalsIgnoreCase(voipOrderRequest.getOrderHeader().getFunctionCode())) {

			List<TblEnvOrder> tblEnvOrderList = orderServiceHelperImpl
					.getMatchingValidationEnvOrder(voipOrderRequest);

			LOG.info("Order Category : {}", tblEnvOrderList.get(0).getOrderCategory());

			if ("ESIP_ESL".equalsIgnoreCase(tblEnvOrderList.get(0).getOrderCategory()))
				productDetails.put("SolutionType", SolutionType.ESIP_ESL.toString());
			else if ("ESIP_EBL".equalsIgnoreCase(tblEnvOrderList.get(0).getOrderCategory()))
				productDetails.put("SolutionType", SolutionType.ESIP_EBL.toString());
			else if ("IPFLEX".equalsIgnoreCase(tblEnvOrderList.get(0).getOrderCategory()))
				productDetails.put("SolutionType", SolutionType.IPFLEX.toString());
			else if ("HPBX".equalsIgnoreCase(tblEnvOrderList.get(0).getOrderCategory()))
				productDetails.put("SolutionType", SolutionType.HPBX.toString());
			
		}  else if (FunctionCode.LOC_ACTIVATE_COMPLETE.toString()
				.equalsIgnoreCase(voipOrderRequest.getOrderHeader().getFunctionCode())) {

			List<TblEnvOrder> tblEnvOrderList = orderServiceHelperImpl
					.getMatchingValidationEnvOrder(voipOrderRequest);

			LOG.info("Order Category : {}", tblEnvOrderList.get(0).getOrderCategory());

			if ("ESIP_ESL".equalsIgnoreCase(tblEnvOrderList.get(0).getOrderCategory()))
				productDetails.put("SolutionType", SolutionType.ESIP_ESL.toString());
			else if ("ESIP_EBL".equalsIgnoreCase(tblEnvOrderList.get(0).getOrderCategory()))
				productDetails.put("SolutionType", SolutionType.ESIP_EBL.toString());
			else if ("IPFLEX".equalsIgnoreCase(tblEnvOrderList.get(0).getOrderCategory()))
				productDetails.put("SolutionType", SolutionType.IPFLEX.toString());
			else if ("HPBX".equalsIgnoreCase(tblEnvOrderList.get(0).getOrderCategory()))
				productDetails.put("SolutionType", SolutionType.HPBX.toString());
			
		} 

		LOG.info("Product Details are : ProductType : {}, LocationFeatureType : {}, SolutionType: {}, ",
				productDetails.get("ProductType"), productDetails.get("LocationFeatureType"),
				productDetails.get("SolutionType"));

		LOG.info("Exited getProductDetails");

		return productDetails;

	}

	@Override
	public VOIPOrderRequest getPrevPassVoipOrderRequest(VOIPOrderRequest voipOrderRequest) {
		LOG.info("Entered getPrevPassVoipOrderRequest");

		int version = Integer.parseInt(voipOrderRequest.getOrderHeader().getWorkOrderVersion());

		VOIPOrderRequest voipOrderRequestPrev = new VOIPOrderRequest();
		OrderHeader orderHeader = new OrderHeader();

		orderHeader.setWorkOrderVersion(Integer.toString(version - 1));
		orderHeader.setWorkOrderNumber(voipOrderRequest.getOrderHeader().getWorkOrderNumber());
		orderHeader.setRegion(voipOrderRequest.getOrderHeader().getRegion());
		orderHeader.setCentrexType(voipOrderRequest.getOrderHeader().getCentrexType());
		orderHeader.setMasterOrderNumber(voipOrderRequest.getOrderHeader().getMasterOrderNumber());

		voipOrderRequestPrev.setOrderHeader(orderHeader);

		LOG.info("Exited getPrevPassVoipOrderRequest");
		return voipOrderRequestPrev;
	}
	
	@Override
	public VOIPOrderRequest getCorrectPrevPassVoipOrderRequest(VOIPOrderRequest voipOrderRequest) throws GenericException{
		LOG.info("Entered getCorrectPrevPassVoipOrderRequest");

		VOIPOrderRequest voipOrderRequestPrev = new VOIPOrderRequest();
		OrderHeader orderHeader = new OrderHeader();

		
		orderHeader.setWorkOrderNumber(voipOrderRequest.getOrderHeader().getWorkOrderNumber());
		orderHeader.setRegion(voipOrderRequest.getOrderHeader().getRegion());
		orderHeader.setCentrexType(voipOrderRequest.getOrderHeader().getCentrexType());
		orderHeader.setMasterOrderNumber(voipOrderRequest.getOrderHeader().getMasterOrderNumber());
		
		List<TblEnvOrder> tblEnvOrders = orderServiceHelperImpl.getPrevPassEnvOrder(voipOrderRequest);
		if(CollectionUtils.isNotEmpty(tblEnvOrders)) {
			orderHeader.setWorkOrderVersion(Long.toString(tblEnvOrders.get(0).getVersionNumber()));
		} else {
			throw new GenericException("Failed when getting order version", "No Valid Previous Order");
		}
		voipOrderRequestPrev.setOrderHeader(orderHeader);
		
		LOG.info("Exited getPrevPassVoipOrderRequest");
		return voipOrderRequestPrev;
	}

}
