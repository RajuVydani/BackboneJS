package com.vz.esap.translation.order.parser;

import java.text.ParseException;

import com.vz.esap.translation.entity.CustomerEntity;
import com.vz.esap.translation.exception.GenericException;
import com.vz.esap.translation.exception.TranslatorException;
import com.vz.esap.translation.order.model.request.VOIPOrderRequest;

public interface EnterpriseOrderParser {
	
	/**
	 * @param voipOrderRequest
	 * @return customer
	 * @throws TranslatorException
	 * @throws ParseException
	 * @throws GenericException
	 */
	CustomerEntity parseEnterpriseOrder(VOIPOrderRequest voipOrderRequest) throws TranslatorException, ParseException, GenericException;

}
