package com.vz.esap.translation.order.parser;

import java.text.ParseException;
import java.util.ArrayList;

import com.vz.esap.translation.entity.TrunkGroupEntity;
import com.vz.esap.translation.exception.TranslatorException;
import com.vz.esap.translation.order.model.request.ParamInfo;
import com.vz.esap.translation.order.model.request.VOIPOrderRequest;

/**
 * @author kalagsu
 *
 */
//@FunctionalInterface
public interface TrunkOrderParser {

	/**
	 * @param voipOrderRequest
	 * @return trunkGroupEntityList
	 * @throws TranslatorException
	 * @throws ParseException
	 */
	public  ArrayList<TrunkGroupEntity> parseTrunkOrder(VOIPOrderRequest voipOrderRequest) throws TranslatorException, ParseException;

	/**
	 * @param voipOrderRequest
	 * @param headerParamInfo
	 * @return
	 * @throws TranslatorException
	 * @throws ParseException
	 */
	ArrayList<TrunkGroupEntity> parseTrunkOrder(VOIPOrderRequest voipOrderRequest, ParamInfo headerParamInfo)
			throws TranslatorException, ParseException;

}
