package com.vz.esap.translation.order.model;

import java.util.List;

import com.vz.esap.translation.entity.CustomerEntity;
import com.vz.esap.translation.entity.DeviceEntity;
import com.vz.esap.translation.entity.EnterpriseTrunkEntity;
import com.vz.esap.translation.entity.GroupTNEntity;
import com.vz.esap.translation.entity.LocationEntity;
import com.vz.esap.translation.entity.NbsEntity;
import com.vz.esap.translation.entity.TrunkGroupEntity;

public class Order {

	private OrderHeader orderHeader;
	private CustomerEntity customerEntity;
	private List<EnterpriseTrunkEntity> enterpriseTrunkEntities;
	private LocationEntity locationEntity;
	private TrunkGroupEntity trunkGroupEntity;
	private DeviceEntity deviceEntity;
	private NbsEntity nbsEntity;
	private GroupTNEntity groupTnEntity;

	public GroupTNEntity getGroupTnEntity() {
		return groupTnEntity;
	}

	public void setGroupTnEntity(GroupTNEntity groupTnEntity) {
		this.groupTnEntity = groupTnEntity;
	}

	public OrderHeader getOrderHeader() {
		return orderHeader;
	}

	public void setOrderHeader(OrderHeader orderHeader) {
		this.orderHeader = orderHeader;
	}

	public CustomerEntity getCustomer() {
		return customerEntity;
	}

	public void setCustomer(CustomerEntity customerEntity) {
		this.customerEntity = customerEntity;
	}

	public List<EnterpriseTrunkEntity> getEnterpriseTrunks() {
		return enterpriseTrunkEntities;
	}

	public void setEnterpriseTrunks(List<EnterpriseTrunkEntity> enterpriseTrunkEntities) {
		this.enterpriseTrunkEntities = enterpriseTrunkEntities;
	}

	public LocationEntity getLocation() {
		return locationEntity;
	}

	public void setLocationEntity(LocationEntity locationEntity) {
		this.locationEntity = locationEntity;
	}

	public TrunkGroupEntity getTrunkGroupEntity() {
		return trunkGroupEntity;
	}

	public void setTrunkGroupEntity(TrunkGroupEntity trunkGroupEntity) {
		this.trunkGroupEntity = trunkGroupEntity;
	}

	public DeviceEntity getDeviceEntity() {
		return deviceEntity;
	}

	public void setDeviceEntity(DeviceEntity deviceEntity) {
		this.deviceEntity = deviceEntity;
	}

	public CustomerEntity getCustomerEntity() {
		return customerEntity;
	}

	public void setCustomerEntity(CustomerEntity customerEntity) {
		this.customerEntity = customerEntity;
	}

	public List<EnterpriseTrunkEntity> getEnterpriseTrunkEntities() {
		return enterpriseTrunkEntities;
	}

	public void setEnterpriseTrunkEntities(List<EnterpriseTrunkEntity> enterpriseTrunkEntities) {
		this.enterpriseTrunkEntities = enterpriseTrunkEntities;
	}

	public NbsEntity getNbsEntity() {
		return nbsEntity;
	}

	public void setNbsEntity(NbsEntity nbsEntity) {
		this.nbsEntity = nbsEntity;
	}

	public LocationEntity getLocationEntity() {
		return locationEntity;
	}

}
