package com.vz.esap.translation.order.service.helper;

import static java.util.Arrays.stream;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.ReflectionUtils;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.vz.esap.translation.communication.RestClient;
import com.vz.esap.translation.connector.model.DBServiceResponse;
import com.vz.esap.translation.connector.model.Location;
import com.vz.esap.translation.connector.model.LocationResponse;
import com.vz.esap.translation.connector.model.TblRow;
import com.vz.esap.translation.connector.service.InventoryDomainDataServiceImpl;
import com.vz.esap.translation.constant.TranslationConstant;
import com.vz.esap.translation.dao.model.TblEnvOrder;
import com.vz.esap.translation.dao.model.TblOrder;
import com.vz.esap.translation.dao.model.TblOrderDetails;
import com.vz.esap.translation.dao.model.TblOrderExample;
import com.vz.esap.translation.dao.model.TblOrderService;
import com.vz.esap.translation.dao.model.TblPendingWoTaskDbBean;
import com.vz.esap.translation.dao.model.TblSafeStore;
import com.vz.esap.translation.dao.repository.CustomTblEnvOrderMapper;
import com.vz.esap.translation.dao.repository.CustomTblOrderMapper;
import com.vz.esap.translation.dao.repository.CustomTblOrderServiceMapper;
import com.vz.esap.translation.entity.CustomerEntity;
import com.vz.esap.translation.entity.DeviceEntity;
import com.vz.esap.translation.entity.EnterpriseTrunkEntity;
import com.vz.esap.translation.entity.Entity.GroupType;
import com.vz.esap.translation.entity.GroupTNEntity;
import com.vz.esap.translation.entity.LocationEntity;
import com.vz.esap.translation.entity.NbsEntity;
import com.vz.esap.translation.entity.TNEntity;
import com.vz.esap.translation.entity.TrunkGroupEntity;
import com.vz.esap.translation.enums.EsapEnum;
import com.vz.esap.translation.enums.EsapEnum.AuthFeatureType;
import com.vz.esap.translation.enums.EsapEnum.DeviceType;
import com.vz.esap.translation.enums.EsapEnum.FlowPath;
import com.vz.esap.translation.enums.EsapEnum.FunctionCode;
import com.vz.esap.translation.enums.EsapEnum.InternalOrderStatus;
import com.vz.esap.translation.enums.EsapEnum.LocationType;
import com.vz.esap.translation.enums.EsapEnum.MinorOrderType;
import com.vz.esap.translation.enums.EsapEnum.OrderAction;
import com.vz.esap.translation.enums.EsapEnum.OrderEntity;
import com.vz.esap.translation.enums.EsapEnum.OrderOrigin;
import com.vz.esap.translation.enums.EsapEnum.OrderRequestType;
import com.vz.esap.translation.enums.EsapEnum.OrderType;
import com.vz.esap.translation.enums.EsapEnum.PcMilestone;
import com.vz.esap.translation.enums.EsapEnum.PcResponseType;
import com.vz.esap.translation.enums.EsapEnum.RollbackReason;
import com.vz.esap.translation.enums.EsapEnum.SolutionType;
import com.vz.esap.translation.enums.EsapEnum.StatusCode;
import com.vz.esap.translation.enums.EsapEnum.TnType;
import com.vz.esap.translation.enums.EsapEnum.TransportProtocol;
import com.vz.esap.translation.exception.ApplicationInterfaceException;
import com.vz.esap.translation.exception.GenericException;
import com.vz.esap.translation.exception.TranslatorException;
import com.vz.esap.translation.exception.TranslatorException.ErrorCode;
import com.vz.esap.translation.order.dao.VOIPOrderDao;
import com.vz.esap.translation.order.model.Order;
import com.vz.esap.translation.order.model.request.ChangedElement;
import com.vz.esap.translation.order.model.request.Feature;
import com.vz.esap.translation.order.model.request.OrderHeader;
import com.vz.esap.translation.order.model.request.ParamInfo;
import com.vz.esap.translation.order.model.request.Specification;
import com.vz.esap.translation.order.model.request.TnInfo;
import com.vz.esap.translation.order.model.request.TnRangeInfo;
import com.vz.esap.translation.order.model.request.VOIPOrderRequest;
import com.vz.esap.translation.order.model.response.VoipOrderResponse;
import com.vz.esap.translation.order.parser.DeviceOrderParser;
import com.vz.esap.translation.order.parser.EnterpriseOrderParser;
import com.vz.esap.translation.order.parser.EnterpriseTrunkOrderParser;
import com.vz.esap.translation.order.parser.LocationOrderParser;
import com.vz.esap.translation.order.parser.NbsOrderParser;
import com.vz.esap.translation.order.parser.OrderParser;
import com.vz.esap.translation.order.parser.TNOrderParser;
import com.vz.esap.translation.order.parser.TrunkOrderParser;
import com.vz.esap.translation.order.service.CancelOrderService;
import com.vz.esap.translation.order.service.NotificationService;
import com.vz.esap.translation.order.service.OrderServiceBase;
import com.vz.esap.translation.order.service.RollbackOrderService;
import com.vz.esap.translation.order.service.VOIPResponseGenerator;
import com.vz.esap.translation.order.transformer.CommonTblOrderDetailsDataTransformer;
import com.vz.esap.translation.order.transformer.CustomerTransformer;
import com.vz.esap.translation.order.transformer.DeviceTblOrderDetailsDataTransformer;
import com.vz.esap.translation.order.transformer.DeviceTransformer;
import com.vz.esap.translation.order.transformer.EnterpriseEnvelopOrderTransformer;
import com.vz.esap.translation.order.transformer.EnterpriseTblOrderDataTransformer;
import com.vz.esap.translation.order.transformer.EnterpriseTblOrderDetailsDataTransformer;
import com.vz.esap.translation.order.transformer.EnterpriseTblOrderServiceDataTransformer;
import com.vz.esap.translation.order.transformer.EnterpriseTrunkTblOrderDetailsDataTransformerImpl;
import com.vz.esap.translation.order.transformer.EnterpriseTrunkTransformer;
import com.vz.esap.translation.order.transformer.GroupTnTransformer;
import com.vz.esap.translation.order.transformer.LocationTblOrderDetailsDataTransformer;
import com.vz.esap.translation.order.transformer.LocationTransformer;
import com.vz.esap.translation.order.transformer.NbsTblOrderDetailsDataTransformer;
import com.vz.esap.translation.order.transformer.NbsTransformer;
import com.vz.esap.translation.order.transformer.TNTblOrderDetailsDataTransformer;
import com.vz.esap.translation.order.transformer.TblSafeStoreTransformer;
import com.vz.esap.translation.order.transformer.TrunkGroupTransformer;
import com.vz.esap.translation.order.transformer.TrunkTblOrderDetailsDataTransformer;
import com.vz.esap.translation.order.transformer.VoipRequestTransformer;
import com.vz.esap.translation.order.validation.EnterpriseOrderValidator;
import com.vz.esap.translation.util.InventoryUtil;
import com.vz.esap.translation.util.OrderUtility;

import EsapEnumPkg.WorkOrderEnum;
import EsapEnumPkg.WorkOrderEnum.OrderClassify;

/**
 * @author chattni
 *
 */
@Component
public class OrderServiceHelperImpl extends OrderServiceBase implements OrderServiceHelper {

	private static final Logger LOG = LoggerFactory.getLogger(OrderServiceHelperImpl.class);

	@Value("${bw.hostPort}")
	private String hostPort;

	@Value("${bw.svcUsername}")
	private String svcUsername;

	@Value("${bw.svcPassword}")
	private String svcPassword;

	@Value("${bw.entDetailscontextUri}")
	private String entDetailscontextUri;

	@Value("${bw.locDetailscontextUri}")
	private String locDetailscontextUri;

	@Autowired
	private RestClient restClientHelper;

	@Autowired
	private VOIPOrderDao voipOrderDao;

	@Autowired
	private VOIPResponseGenerator voipResponseGenerator;

	@Autowired
	private InventoryDomainDataServiceImpl inventoryDomainDataServiceImpl;

	@Autowired
	private EnterpriseOrderParser enterpriseOrderParser;

	@Autowired
	private NotificationService notificationService;

	@Autowired
	private EnterpriseOrderValidator enterpriseOrderValidator;

	@Autowired
	private CommonTblOrderDetailsDataTransformer commonTblOrderDetailsDataTransformerImpl;

	@Autowired
	private EnterpriseTblOrderDetailsDataTransformer enterpriseTblOrderDetailsData;

	@Autowired
	private EnterpriseTblOrderServiceDataTransformer enterpriseTblOrderServiceData;

	@Autowired
	private EnterpriseTblOrderDataTransformer enterpriseTblOrderData;

	@Autowired
	private EnterpriseEnvelopOrderTransformer enterpriseEnvelopOrderData;

	@Autowired
	private LocationOrderParser locationOrderParser;

	@Autowired
	private LocationTblOrderDetailsDataTransformer locationTblOrderDetailsData;

	@Autowired
	private EnterpriseTrunkOrderParser enterpriseTrunkOrderParserImpl;

	@Autowired
	private EnterpriseTrunkTblOrderDetailsDataTransformerImpl enterpriseTrunkTblOrderDetailsDataTransformerImpl;

	@Autowired
	private DeviceOrderParser deviceOrderParser;

	@Autowired
	private DeviceTblOrderDetailsDataTransformer deviceTblOrderDetailsData;

	@Autowired
	private TrunkOrderParser trunkOrderParser;

	@Autowired
	private TrunkTblOrderDetailsDataTransformer trunkTblOrderDetailsData;

	@Autowired
	private TNOrderParser tnOrderParser;

	@Autowired
	private TNTblOrderDetailsDataTransformer tnTblOrderDetailsData;

	@Autowired
	private NbsOrderParser nbsOrderParserImpl;

	@Autowired
	NbsTblOrderDetailsDataTransformer nbsTblOrderDetailsDataTransformerImpl;

	@Autowired
	RollbackOrderService rollbackOrderService;

	@Autowired
	private LocationTransformer locationTransformerImpl;

	@Autowired
	private CancelOrderService cancelOrderServiceImpl;

	@Autowired
	private CustomTblEnvOrderMapper customTblEnvOrderMapper;

	@Autowired
	private InventoryUtil inventoryUtil;

	@Autowired
	private DeviceTransformer deviceTransformer;

	@Autowired
	private TrunkGroupTransformer trunkGroupTransformer;

	@Autowired
	private EnterpriseTrunkTransformer enterpriseTrunkTransformer;

	@Autowired
	private NbsTransformer nbsTransformer;

	@Autowired
	private CustomerTransformer customerTransformer;

	@Autowired
	private GroupTnTransformer groupTnTransformer;

	@Autowired
	private CustomTblOrderMapper customTblOrderMapper;

	@Autowired
	private CustomTblOrderServiceMapper customTblOrderServiceMapper;

	@Autowired
	private NotificationService notificationServiceImpl;

	@Autowired
	private OrderServiceBase groupTnOrderServiceImpl;

	@Autowired
	private DeviceTblOrderDetailsDataTransformer deviceTblOrderDetailsDataTransformerImpl;

	@Autowired
	private VoipRequestTransformer voipRequestTransformerImpl;

	@Autowired
	private TblSafeStoreTransformer tblSafeStoreTransformer;

	@Autowired
	private OrderParser orderParserImpl;

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.vz.esap.translation.order.service.helper.OrderServiceHelper#
	 * getMatchingValidationEnvOrder(com.vz.esap.translation.order.model.request.
	 * VOIPOrderRequest)
	 */
	@Override
	public List<TblEnvOrder> getMatchingValidationEnvOrder(VOIPOrderRequest voipOrderRequest) throws GenericException {
		List<TblEnvOrder> tblEnvOrders = null;
		TblEnvOrder tblEnvOrderObject = null;
		LOG.info("Entered getMatchingValidationEnvOrder");

		try {
			tblEnvOrderObject = new TblEnvOrder();
			tblEnvOrderObject.setOrderNumber(voipOrderRequest.getOrderHeader().getWorkOrderNumber());
			if (voipOrderRequest.getOrderHeader().getMasterOrderNumber() != null)
				tblEnvOrderObject.setMasterOrderNumber(voipOrderRequest.getOrderHeader().getMasterOrderNumber());
			tblEnvOrderObject.setVersionNumber(Long.valueOf(voipOrderRequest.getOrderHeader().getWorkOrderVersion()));
			if (voipOrderRequest.getOrderHeader().getRegion() == null) {
				tblEnvOrderObject.setRegion("US");
			} else {
				tblEnvOrderObject.setRegion(voipOrderRequest.getOrderHeader().getRegion());
			}
			tblEnvOrderObject.setOrderStatus(Long.valueOf(WorkOrderEnum.Status.WO_COMPLETE));
			tblEnvOrderObject.setOrderClassify(Long.valueOf(WorkOrderEnum.OrderClassify.VALIDATE));
			if (null != voipOrderRequest.getOrderHeader().getCentrexType() && OrderUtility
					.isOneOf(voipOrderRequest.getOrderHeader().getCentrexType(), true, "IPAC", "IPAC1", "IPAC2")) {
				tblEnvOrderObject.setProjectId("RA");
			} else {
				tblEnvOrderObject.setProjectId("R");
			}
			tblEnvOrders = voipOrderDao.getTableEnvOrder(tblEnvOrderObject);

			if (tblEnvOrders.isEmpty() || tblEnvOrders.get(0) == null || tblEnvOrders.get(0).getEnvOrderId() == null) {
				throw new TranslatorException(TranslatorException.ErrorCode.VALIDATION_NOT_COMPLETE,
						"Validation is not complete for TIN:"
								+ voipOrderRequest.getOrderHeader().getMasterOrderNumber());
			}
			LOG.info("Validation Env Order Id {}", tblEnvOrders.get(0).getEnvOrderId());

		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new GenericException(GenericException.GENERIC_EXCEPTION,
					"Exception occured in getMatchingValidationEnvOrder");
		}
		LOG.info("Exit getMatchingValidationEnvOrder");

		return tblEnvOrders;
	}

	/*
	 * (non-Javadoc) SUPP
	 * 
	 * @see com.vz.esap.translation.order.service.helper.OrderServiceHelper#
	 * getMatchingPrevPassEnvOrder(com.vz.esap.translation.order.model.request.
	 * VOIPOrderRequest)
	 */
	@Override
	public List<TblEnvOrder> getMatchingPrevPassEnvOrder(VOIPOrderRequest prevVoipOrderRequest, int envOrderStatus,
			int envOrderClassify) throws GenericException {
		List<TblEnvOrder> tblEnvOrders = null;
		TblEnvOrder tblEnvOrderObject = null;
		LOG.info("Entered getMatchingPrevPassEnvOrder for Version={} ",
				prevVoipOrderRequest.getOrderHeader().getWorkOrderVersion());

		try {
			tblEnvOrderObject = new TblEnvOrder();
			tblEnvOrderObject.setOrderNumber(prevVoipOrderRequest.getOrderHeader().getWorkOrderNumber());
			if (prevVoipOrderRequest.getOrderHeader().getMasterOrderNumber() != null)
				tblEnvOrderObject.setMasterOrderNumber(prevVoipOrderRequest.getOrderHeader().getMasterOrderNumber());
			tblEnvOrderObject
					.setVersionNumber(Long.valueOf(prevVoipOrderRequest.getOrderHeader().getWorkOrderVersion()));
			if (prevVoipOrderRequest.getOrderHeader().getRegion() == null) {
				tblEnvOrderObject.setRegion("US");
			} else {
				tblEnvOrderObject.setRegion(prevVoipOrderRequest.getOrderHeader().getRegion());
			}

			if (envOrderStatus != 0)
				tblEnvOrderObject.setOrderStatus(Long.valueOf(envOrderStatus));

			// tblEnvOrderObject.setOrderStatus(Long.valueOf(WorkOrderEnum.Status.WO_INIT));

			if (envOrderClassify != 0)
				tblEnvOrderObject.setOrderClassify(Long.valueOf(envOrderClassify));
			else
				tblEnvOrderObject.setOrderClassify(Long.valueOf(WorkOrderEnum.OrderClassify.RELEASE));

			if (null != prevVoipOrderRequest.getOrderHeader().getCentrexType() && OrderUtility
					.isOneOf(prevVoipOrderRequest.getOrderHeader().getCentrexType(), true, "IPAC", "IPAC1", "IPAC2")) {
				tblEnvOrderObject.setProjectId("RA");
			} else {
				tblEnvOrderObject.setProjectId("R");
			}
			tblEnvOrders = voipOrderDao.getTableEnvOrder(tblEnvOrderObject);

			if (tblEnvOrders.isEmpty() || tblEnvOrders.get(0) == null || tblEnvOrders.get(0).getEnvOrderId() == null) {
				LOG.error("TblEnvOrderList: {} TblEnvOrderList Size: {}", tblEnvOrders, tblEnvOrders.size());
				throw new TranslatorException(TranslatorException.ErrorCode.ENV_ORDER_NOT_FOUND,
						"Env Order Not Found for Order Number=:"
								+ prevVoipOrderRequest.getOrderHeader().getWorkOrderNumber());
			}
			LOG.info("Matching Env Order Id {}", tblEnvOrders.get(0).getEnvOrderId());

		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new GenericException(GenericException.GENERIC_EXCEPTION,
					"Exception occured in getMatchingPrevPassEnvOrder");
		}

		LOG.info("Exit getMatchingPrevPassEnvOrder");
		return tblEnvOrders;
	}

	@Override
	public List<TblOrder> getMatchingPrevPassOrder(TblEnvOrder tblEnvOrder, OrderEntity orderEntity)
			throws GenericException {
		LOG.info("Entered getMatchingPrevPassOrder for Entity = {} and Envelop Order Id = {}", orderEntity,
				tblEnvOrder.getEnvOrderId());
		List<TblOrder> tblOrderList = null;
		TblOrder tblOrder = null;

		try {
			tblOrder = new TblOrder();
			tblOrder.setEnvOrderId(tblEnvOrder.getEnvOrderId());
			tblOrderList = voipOrderDao.getPrevTblOrder(tblOrder, orderEntity);

			if (tblOrderList.isEmpty() && !OrderEntity.LOCATION.equals(orderEntity)) {

				tblOrderList = voipOrderDao.getPrevTblOrder(tblOrder, OrderEntity.LOCATION);
			}

		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new GenericException(GenericException.GENERIC_EXCEPTION,
					"Exception occured in getMatchingPrevPassOrder");
		}
		LOG.info("Exit getMatchingPrevPassOrder");
		return tblOrderList;
	}

	/**
	 * SUPP
	 * 
	 * @param tblEnvOrder
	 * @param orderEntity
	 * @return
	 * @throws GenericException
	 */
	public List<TblOrder> getMatchingPrevPassOrder(TblEnvOrder tblEnvOrder, OrderEntity orderEntity, String entId)
			throws GenericException {
		LOG.info("Entered getMatchingPrevPassOrder");
		List<TblOrder> tblOrderList = null;
		TblOrder tblOrder = null;

		try {
			tblOrder = new TblOrder();
			tblOrder.setEnvOrderId(tblEnvOrder.getEnvOrderId());
			tblOrderList = voipOrderDao.getPrevTblOrder(tblOrder, orderEntity);// TODO need to be modified.

		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new GenericException(GenericException.GENERIC_EXCEPTION,
					"Exception occured in getMatchingPrevPassOrder");
		}
		LOG.info("Exit getMatchingPrevPassOrder");
		return tblOrderList;
	}

	@Override
	public List<TblEnvOrder> getMatchingReleaseEnvOrder(VOIPOrderRequest voipOrderRequest, long status,
			List<Long> statusExcluded) throws GenericException {
		List<TblEnvOrder> tblEnvOrders = null;
		TblEnvOrder tblEnvOrderObject = null;
		LOG.info("Entered getMatchingReleaseEnvOrder");

		try {
			tblEnvOrderObject = new TblEnvOrder();
			tblEnvOrderObject.setOrderNumber(voipOrderRequest.getOrderHeader().getWorkOrderNumber());
			if (voipOrderRequest.getOrderHeader().getMasterOrderNumber() != null)
				tblEnvOrderObject.setMasterOrderNumber(voipOrderRequest.getOrderHeader().getMasterOrderNumber());
			tblEnvOrderObject.setVersionNumber(Long.valueOf(voipOrderRequest.getOrderHeader().getWorkOrderVersion()));
			if (voipOrderRequest.getOrderHeader().getRegion() == null) {
				tblEnvOrderObject.setRegion("US");
			} else {
				tblEnvOrderObject.setRegion(voipOrderRequest.getOrderHeader().getRegion());
			}

			if (status != 0)
				tblEnvOrderObject.setOrderStatus(status);

			tblEnvOrderObject.setOrderClassify(Long.valueOf(WorkOrderEnum.OrderClassify.RELEASE));
			if (null != voipOrderRequest.getOrderHeader().getCentrexType() && OrderUtility
					.isOneOf(voipOrderRequest.getOrderHeader().getCentrexType(), true, "IPAC", "IPAC1", "IPAC2")) {
				tblEnvOrderObject.setProjectId("RA");
			} else {
				tblEnvOrderObject.setProjectId("R");
			}
			tblEnvOrders = voipOrderDao.getTableEnvOrder(tblEnvOrderObject, statusExcluded);

			if (tblEnvOrders.isEmpty() || tblEnvOrders.get(0) == null || tblEnvOrders.get(0).getEnvOrderId() == null) {
				throw new TranslatorException(TranslatorException.ErrorCode.RELEASE_ORDER_NOT_FOUND,
						"Release Order Not Found:" + voipOrderRequest.getOrderHeader().getMasterOrderNumber());
			}
			LOG.info("Release Env Order Id {}", tblEnvOrders.get(0).getEnvOrderId());

		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new GenericException(GenericException.GENERIC_EXCEPTION,
					"Exception occured in getMatchingReleaseEnvOrder");
		}
		LOG.info("Exit getMatchingReleaseEnvOrder");

		return tblEnvOrders;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.vz.esap.translation.order.service.helper.OrderServiceHelper#
	 * getEnterpriseInformationFromGchId(java.lang.String)
	 */
	@Override
	public DBServiceResponse getEnterpriseInformationFromGchId(String gchId)
			throws ApplicationInterfaceException, GenericException {
		LOG.info("Entered getEnterpriseInformationFromGchId");
		DBServiceResponse dbServiceResponse = null;
		Set<String> selectColumnSet = null;
		List<String[]> whereClauseList = null;
		DBServiceResponse dbServiceResponseCustomer = null;
		String enterpriseId = null;
		Set<String> selectColumnSetEnt = null;
		List<String[]> whereClauseListEnt = null;

		try {
			selectColumnSet = new HashSet<>();
			selectColumnSet.add("GCH_ID");
			selectColumnSet.add("CUSTOMER_ID");

			whereClauseList = new ArrayList<>();
			whereClauseList.add(new String[] { "GCH_ID", gchId });

			dbServiceResponseCustomer = inventoryDomainDataServiceImpl.searchInventory("TBL_CUSTOMER", selectColumnSet,
					whereClauseList);

			for (TblRow tblRows : dbServiceResponseCustomer.getTableRows()) {
				enterpriseId = tblRows.getTblRow().get("CUSTOMER_ID").getValue();
				LOG.info("Enterprise Id : {}", enterpriseId);
			}

			LOG.info("Number of record: {}", dbServiceResponseCustomer.getNumberOfRecords());

			if (dbServiceResponseCustomer.getNumberOfRecords() > 0) {
				LOG.info("Enterprise is present ");
				selectColumnSetEnt = new HashSet<>();
				selectColumnSetEnt.add("ENTERPRISE_ID");
				selectColumnSetEnt.add("BW_ENTERPRISE_ID");
				selectColumnSetEnt.add("ENV_ORDER_ID");

				whereClauseListEnt = new ArrayList<>();
				whereClauseListEnt.add(new String[] { "ENTERPRISE_ID", enterpriseId });

				dbServiceResponse = inventoryDomainDataServiceImpl.searchInventory("TBL_ENTERPRISE", selectColumnSetEnt,
						whereClauseListEnt);
			} else {
				dbServiceResponse = dbServiceResponseCustomer;
			}

		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new GenericException(GenericException.GENERIC_EXCEPTION,
					"Exception occured in getEnterpriseInformationFromGchId");
		}

		LOG.info("Exit getEnterpriseInformationFromGchId");
		return dbServiceResponse;

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.vz.esap.translation.order.service.helper.OrderServiceHelper#
	 * getEnterpriseInformationFromGchId(java.lang.String,
	 * com.vz.esap.translation.order.model.request.VOIPOrderRequest) ------This
	 * overloaded method is used by ESL to get the enterprise for multiple GCH under
	 * same ESL.
	 */
	@Override
	public DBServiceResponse getEnterpriseInformationFromGchId(String gchId, VOIPOrderRequest voipOrderRequest)
			throws ApplicationInterfaceException, GenericException {
		LOG.info("Entered getEnterpriseInformationFromGchId");
		DBServiceResponse dbServiceResponse = null;
		Set<String> selectColumnSet = null;
		List<String[]> whereClauseList = null;
		DBServiceResponse dbServiceResponseCustomer = null;
		String enterpriseId = null;
		Set<String> selectColumnSetEnt = null;
		List<String[]> whereClauseListEnt = null;
		int orderVersion = 0;
		List<TblEnvOrder> tblEnvOrderListPrev = null;

		try {
			selectColumnSet = new HashSet<>();
			selectColumnSet.add("GCH_ID");
			selectColumnSet.add("CUSTOMER_ID");
			selectColumnSet.add("ENV_ORDER_ID");

			whereClauseList = new ArrayList<>();
			whereClauseList.add(new String[] { "GCH_ID", gchId });

			dbServiceResponseCustomer = inventoryDomainDataServiceImpl.searchInventory("TBL_CUSTOMER", selectColumnSet,
					whereClauseList);

			for (TblRow tblRows : dbServiceResponseCustomer.getTableRows()) {
				enterpriseId = tblRows.getTblRow().get("CUSTOMER_ID").getValue();
				LOG.info("Enterprise Id : {}", enterpriseId);
			}

			LOG.info("Number of record: {}", dbServiceResponseCustomer.getNumberOfRecords());

			if (dbServiceResponseCustomer.getNumberOfRecords() > 0) {
				LOG.info("Customer NumberOfRecords > 0");
				if (dbServiceResponseCustomer.getNumberOfRecords() > 1) {
					LOG.info("Same GCH ID and VPN used for multiple ESL:: Customer NumberOfRecords > 1");
					orderVersion = Integer.parseInt(voipOrderRequest.getOrderHeader().getWorkOrderVersion());
					if (orderVersion == 0 && "I".equalsIgnoreCase(voipOrderRequest.getOrderHeader().getOrderType())) {
						LOG.info("User previous EnterpriseId when same GCH ID and VPN used. :: SUPP");
						// Getting EnterpriseIds for given VPN.
						DBServiceResponse dbServiceResponseTblLoc = null;
						List<Feature> features = null;
						features = stream(voipOrderRequest.getConvergedService().getFeature())
								.filter(feature -> "EXT_FET_VPN".equalsIgnoreCase(feature.getCode())
										|| "FET_LOC_LVL".equalsIgnoreCase(feature.getCode()))
								.collect(Collectors.toList());

						if (!CollectionUtils.isEmpty(features)) {
							for (Specification vpnSpec : features.get(0).getSpecification()) {
								if ("SP_VPN_NAME".equalsIgnoreCase(vpnSpec.getCode())
										|| "ESP_XO_ASSOCIATED_VPN_NAME".equalsIgnoreCase(vpnSpec.getCode())) {

									LOG.info("VPN Name is = {}", vpnSpec.getValue());
									dbServiceResponseTblLoc = inventoryUtil.getLocationFromVpnName(vpnSpec.getValue());
									break;
								}
							}
						}

						String custEntId = null;
						if (dbServiceResponseTblLoc != null) {
							for (TblRow tblRows : dbServiceResponseCustomer.getTableRows()) {
								custEntId = tblRows.getTblRow().get("CUSTOMER_ID").getValue();
								LOG.info("Enterprise Id : {}", enterpriseId);

								for (TblRow tblVpnRows : dbServiceResponseTblLoc.getTableRows()) {
									if (tblVpnRows.getTblRow() != null
											&& tblVpnRows.getTblRow().get("ENTERPRISE_ID") != null
											&& tblVpnRows.getTblRow().get("ENTERPRISE_ID").getValue() != null) {

										LOG.info(
												"For ENTERPRISE_ID From TBL_LOCATION = {} And ENTERPRISE_ID From TBL_ENTERPRISE = {}",
												tblVpnRows.getTblRow().get("ENTERPRISE_ID").getValue(), custEntId);

										if (tblVpnRows.getTblRow().get("ENTERPRISE_ID").getValue()
												.equalsIgnoreCase(custEntId)) {
											LOG.info("isMatchingEnterprise :: TRUE");
											enterpriseId = custEntId;
											break;
										}
									}
								}
							}
						}
					}
					if (orderVersion > 0) {
						LOG.info("Same GCH ID and VPN used for multiple ESL :: SUPP");
						VOIPOrderRequest voipOrderRequestPrev = orderParserImpl.getCorrectPrevPassVoipOrderRequest(voipOrderRequest);
						LOG.info("SUPP Order version:: {}",
								voipOrderRequestPrev.getOrderHeader().getWorkOrderVersion());
						//voipOrderRequestPrev.getOrderHeader().setWorkOrderVersion(Integer.toString(orderVersion - 1));
						tblEnvOrderListPrev = getMatchingPrevPassEnvOrder(voipOrderRequestPrev, 0,
								WorkOrderEnum.OrderClassify.RELEASE);
						if (tblEnvOrderListPrev != null && !tblEnvOrderListPrev.isEmpty()) {
							enterpriseId = tblEnvOrderListPrev.get(0).getEnterpriseId();
							LOG.info("Enterprise Id for Previous Version :: {}", enterpriseId);
						}
					}
					if ("C".equalsIgnoreCase(voipOrderRequest.getOrderHeader().getOrderType())) {
						LOG.info("Same GCH ID and VPN used for multiple ESL :: Change Order");
						Map<String, String> locRows = null;
						String voipLocationId = null;
						voipLocationId = voipOrderRequest.getOrderHeader().getVoipLocationId();
						LOG.info("voipLocationId::{}", voipLocationId);
						locRows = inventoryUtil.getTblLocationFromLocationId(voipLocationId, null, null);
						if (locRows != null && locRows.get("ENTERPRISE_ID") != null) {
							enterpriseId = locRows.get("ENTERPRISE_ID");
							LOG.info("Enterprise Id for Install order fetched from Inventory :: {}", enterpriseId);
						}
					}
				}
				LOG.info("Enterprise is present ");
				selectColumnSetEnt = new HashSet<>();
				selectColumnSetEnt.add("ENTERPRISE_ID");
				selectColumnSetEnt.add("BW_ENTERPRISE_ID");
				selectColumnSetEnt.add("ENV_ORDER_ID");

				whereClauseListEnt = new ArrayList<>();
				whereClauseListEnt.add(new String[] { "ENTERPRISE_ID", enterpriseId });

				dbServiceResponse = inventoryDomainDataServiceImpl.searchInventory("TBL_ENTERPRISE", selectColumnSetEnt,
						whereClauseListEnt);
			} else {
				dbServiceResponse = dbServiceResponseCustomer;
			}

		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new GenericException(GenericException.GENERIC_EXCEPTION,
					"Exception occured in getEnterpriseInformationFromGchId");
		}

		LOG.info("Exit getEnterpriseInformationFromGchId");
		return dbServiceResponse;

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.vz.esap.translation.order.service.helper.OrderServiceHelper#
	 * getMatchingPassOrder(com.vz.esap.translation.dao.model.TblEnvOrder)
	 */
	@Override
	public List<TblOrder> getMatchingPassOrder(TblEnvOrder tblEnvOrder) throws GenericException {
		LOG.info("Entered getMatchingPassOrder");
		List<TblOrder> tblOrderList = null;
		TblOrder tblOrder = null;

		try {
			tblOrder = new TblOrder();
			tblOrder.setEnvOrderId(tblEnvOrder.getEnvOrderId());
			tblOrderList = voipOrderDao.getTblOrder(tblOrder);

		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new GenericException(GenericException.GENERIC_EXCEPTION, "Exception occured in getMatchingPassOrder");
		}
		LOG.info("Exit getMatchingPassOrder");
		return tblOrderList;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.vz.esap.translation.order.service.helper.OrderServiceHelper#
	 * getMatchingOrderDetails(com.vz.esap.translation.dao.model.TblOrder)
	 */
	@Override
	public List<TblOrderDetails> getMatchingOrderDetails(TblOrder tblOrderBean)
			throws TranslatorException, GenericException {
		LOG.info("Entered getMatchingOrderDetails");

		List<TblOrderDetails> ordDetails = null;
		TblOrderDetails tblOrderDetails = null;
		try {
			tblOrderDetails = new TblOrderDetails();
			tblOrderDetails.setOrderId(tblOrderBean.getOrderId());

			ordDetails = voipOrderDao.getOrderDetailsEntities(tblOrderDetails);

		} catch (Exception e) {
			LOG.error("Exception {} ", e);
			throw new GenericException(GenericException.GENERIC_EXCEPTION,
					"Exception occured in getMatchingOrderDetails");
		}
		LOG.info("Exit getMatchingOrderDetails");
		return ordDetails;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.vz.esap.translation.order.service.helper.OrderServiceHelper#
	 * createEnterpriseOrderDetailsParamInfo(com.vz.esap.translation.order.model.
	 * request.VOIPOrderRequest, com.vz.esap.translation.dao.model.TblOrder,
	 * com.vz.esap.translation.order.model.request.ParamInfo)
	 */
	@Override
	public ParamInfo createEnterpriseOrderDetailsParamInfo(VOIPOrderRequest voipOrderRequest, TblOrder tblOrderObject,
			ParamInfo headerParamInfo, boolean isNewCustomer) throws GenericException {
		LOG.info("Entered createEnterpriseOrderDetails");
		VoipOrderResponse voipOrderResponse;
		String errorCode;
		String errorDescription;
		CustomerEntity customer = null;
		ParamInfo entityParamInfo = null;
		Set<String> missingFields = null;
		String errorMessage = null;
		try {
			// create CustomerEntity Object
			customer = enterpriseOrderParser.parseEnterpriseOrder(voipOrderRequest);
			populateCustomerRegion(voipOrderRequest, customer);
			missingFields = enterpriseOrderValidator.validate(voipOrderRequest);

			if (missingFields.size() > 0) {
				voipOrderResponse = voipResponseGenerator.prepareFailureOrderResponse(missingFields, "enterprise",
						voipOrderRequest);
				errorCode = voipOrderResponse.getOrderStatus().getMilestone();
				errorDescription = voipOrderResponse.getOrderStatus().getStatusDescription();
				LOG.error("OrderServiceImpl - processCurrentSegmentOrder - Error Description : {}, :{}",
						errorDescription, errorCode);
				// notificationService.notifyFailures(voipOrderResponse);

				throw new TranslatorException(TranslatorException.ErrorCode.ESAP_MISSING_REQUIRED_DATA,
						errorDescription);
			}

			if (isNewCustomer)
				errorMessage = checkDataIntegrity(customer);

			if (errorMessage != null) {
				voipOrderResponse = voipResponseGenerator.prepareFailureOrderResponse(errorMessage, voipOrderRequest);
				LOG.info("voipOrderResponse: {}", voipOrderResponse);
				errorCode = voipOrderResponse.getOrderStatus().getMilestone();
				errorDescription = voipOrderResponse.getOrderStatus().getStatusDescription();
				LOG.error("OrderServiceImpl - processCurrentSegmentOrder - Error Description : {}, :{}",
						errorDescription, errorCode);
				// notificationService.notifyFailures(voipOrderResponse);

				throw new TranslatorException(TranslatorException.ErrorCode.ESAP_DATA_ALREADY_EXISTS, errorDescription);
			}

			if ("C".equalsIgnoreCase(voipOrderRequest.getOrderHeader().getOrderType())
					&& customer.getCustomerEntity() != null) {

				LOG.info("++Level 1+++++Original Customer Entity : {} ", customer);

				LOG.info("++Level 1+++++Changed Customer Entity : {} ", customer.getCustomerEntity());

				customer = customerTransformer.enrichCustomerEntityWithInventory(voipOrderRequest, customer);

				LOG.info("++Level 2+++++Original Customer Entity : {} ", customer);

				LOG.info("++Level 2+++++Changed Customer Entity : {} ", customer.getCustomerEntity());

				// create order Details for Customer
				entityParamInfo = enterpriseTblOrderDetailsData.prepareTblOrderDetailsEntityParamDataForLocation(
						customer, customer.getCustomerEntity(), true, null);

			} else if ("C".equalsIgnoreCase(voipOrderRequest.getOrderHeader().getOrderType())) {

				// create order Details for Customer
				entityParamInfo = enterpriseTblOrderDetailsData
						.prepareTblOrderDetailsEntityParamDataForCustomer(voipOrderRequest, tblOrderObject, customer);
			} else if ("I".equalsIgnoreCase(voipOrderRequest.getOrderHeader().getOrderType())) {

				// create order Details for Customer
				entityParamInfo = enterpriseTblOrderDetailsData
						.prepareTblOrderDetailsEntityParamDataForCustomer(voipOrderRequest, tblOrderObject, customer);
			}

			// create order Details for Ent
			headerParamInfo.addChildParam(entityParamInfo);

		} catch (Exception e) {
			LOG.error("Exception {} ", e);
			throw new GenericException(GenericException.GENERIC_EXCEPTION,
					"Exception occured in createEnterpriseOrderDetailsParamInfo");
		}
		LOG.info("Exit createEnterpriseOrderDetails");
		return headerParamInfo;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.vz.esap.translation.order.service.helper.OrderServiceHelper#
	 * createValidateOrderServices(com.vz.esap.translation.dao.model.TblOrder,
	 * java.lang.String)
	 */
	@Override
	public Long createValidateOrderServices(TblOrder tblOrderObject, String virtualAddrCountry)
			throws TranslatorException, GenericException {

		LOG.info("Entered createValidateOrderServices");
		long count = -1;
		List<TblOrderService> tblOrderServiceList = null;
		try {
			// create service entry for WF
			tblOrderServiceList = enterpriseTblOrderServiceData.prepareTblOrderServiceDataValidate(virtualAddrCountry,
					tblOrderObject);

			for (TblOrderService tblOrderService : tblOrderServiceList) {
				count = voipOrderDao.createTblOrderService(tblOrderService);
				if (count <= 0) {
					count = 0;
					break;
				} else {
					count++;
				}
			}

			if (count <= 0) {
				throw new TranslatorException(TranslatorException.ErrorCode.SERVICE_ORDER_CREATION_FAILURE,
						"Failed to create Order Services");
			}

			tblOrderServiceList.forEach(tblOrderService -> {
				LOG.info("Initiate TblOrderService for Service : {}", tblOrderService.getService());
			});

		} catch (TranslatorException te) {
			LOG.error("Exception {} ", te.getMessage());
			throw new TranslatorException(te.getErrorCode(), te.getErrorDesc());
		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new GenericException(GenericException.GENERIC_EXCEPTION,
					"Exception occured while createEsipEslOrderServices");
		}
		LOG.info("Exit createEsipEslOrderServices");
		return count;

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.vz.esap.translation.order.service.helper.OrderServiceHelper#
	 * createEsipEslOrderDetails(com.vz.esap.translation.order.model.request.
	 * VOIPOrderRequest, com.vz.esap.translation.dao.model.TblOrder, boolean)
	 */
	@Override
	public Long createEsipEslOrderDetails(VOIPOrderRequest voipOrderRequest, TblOrder tblOrderObject,
			boolean isNewCustomer) throws TranslatorException, GenericException {

		LOG.info("Entered createEsipEslOrderDetails");
		long count = -1;
		ParamInfo headerParamInfo = null;
		List<Feature> features = null;

		try {

			headerParamInfo = commonTblOrderDetailsDataTransformerImpl
					.prepareTblOrderDetailsHeaderParamDataForCustomer(voipOrderRequest, tblOrderObject);

			features = stream(voipOrderRequest.getConvergedService().getFeature())
					.filter(feature -> feature.getCode().equalsIgnoreCase("EFET_VOIP_ENT_LVL"))
					.collect(Collectors.toList());
			if (!features.isEmpty() && !features.get(0).getActionCode().equalsIgnoreCase("NONE")) {
				headerParamInfo = createEnterpriseOrderDetailsParamInfo(voipOrderRequest, tblOrderObject,
						headerParamInfo, false);
			}

			features = stream(voipOrderRequest.getConvergedService().getFeature())
					.filter(feature -> feature.getCode().equalsIgnoreCase("FET_XO_TRU")).collect(Collectors.toList());
			
			boolean trunkPresent = features.stream().anyMatch(featuresList -> "ADD".equalsIgnoreCase(featuresList.getActionCode()));
			
			features = stream(voipOrderRequest.getConvergedService().getFeature())
					.filter(feature -> feature.getCode().equalsIgnoreCase("FET_LOC_LVL")).collect(Collectors.toList());
			if (trunkPresent || !features.isEmpty() && !features.get(0).getActionCode().equalsIgnoreCase("NONE")) {
				headerParamInfo = createLocationOrderDetailsParamInfo(voipOrderRequest, headerParamInfo,
						tblOrderObject);
			}

			features = stream(voipOrderRequest.getConvergedService().getFeature())
					.filter(feature -> feature.getCode().equalsIgnoreCase("FET_DE")
							|| feature.getCode().equalsIgnoreCase("FET_DE_LOC"))
					.collect(Collectors.toList());
			if (trunkPresent || !features.isEmpty() && !features.get(0).getActionCode().equalsIgnoreCase("NONE")) {
				headerParamInfo = createDeviceOrderDetailsParamInfo(voipOrderRequest, headerParamInfo, tblOrderObject);
			}
			
			features = stream(voipOrderRequest.getConvergedService().getFeature())
					.filter(feature -> feature.getCode().equalsIgnoreCase("FET_XO_TRU")).collect(Collectors.toList());
			if (trunkPresent || !features.isEmpty() && !features.get(0).getActionCode().equalsIgnoreCase("NONE")) {				
				headerParamInfo = createTrunkGroupOrderDetailsParamInfo(voipOrderRequest, headerParamInfo,
						tblOrderObject);
			}

			features = stream(voipOrderRequest.getConvergedService().getFeature())
					.filter(feature -> feature.getCode().equalsIgnoreCase("EFET_VOIP_ENT_TRUNK"))
					.collect(Collectors.toList());
			if (trunkPresent || !features.isEmpty() && !features.get(0).getActionCode().equalsIgnoreCase("NONE")) {
				headerParamInfo = createETOrderDetailsParamInfo(voipOrderRequest, headerParamInfo);
			}

			features = stream(voipOrderRequest.getConvergedService().getFeature())
					.filter(feature -> feature.getCode().equalsIgnoreCase("FET_XO_TRU")).collect(Collectors.toList());
			if (trunkPresent || !features.isEmpty() && !features.get(0).getActionCode().equalsIgnoreCase("NONE")) {
				headerParamInfo = createNbsOrderDetailsParamInfo(voipOrderRequest, headerParamInfo, tblOrderObject);
			}

			if ("I".equalsIgnoreCase(voipOrderRequest.getOrderHeader().getOrderType())) {
				voipOrderDao.populateOrderDetails(tblOrderObject, headerParamInfo.getChildParams(), "n", 0, 0);
			} else if ("C".equalsIgnoreCase(voipOrderRequest.getOrderHeader().getOrderType())) {
				voipOrderDao.populateOrderDetails(tblOrderObject, headerParamInfo.getChildParams(), "c", 0, 0);
			}

		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new GenericException(GenericException.GENERIC_EXCEPTION,
					"Exception occured while createEsipEslOrderDetails");
		}
		LOG.info("Exit createEsipEslOrderDetails");
		return count;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.vz.esap.translation.order.service.helper.OrderServiceHelper#
	 * createEsipEslOrderHeader(com.vz.esap.translation.order.model.request.
	 * VOIPOrderRequest, int, com.vz.esap.translation.dao.model.TblEnvOrder)
	 */
	@Override
	public TblOrder createEsipEslOrderHeader(VOIPOrderRequest voipOrderRequest, int status,
			TblEnvOrder tblEnvOrderObject) throws TranslatorException, GenericException {
		LOG.info("Entered createEsipEslOrderHeader");
		TblOrder tblOrderObject = null;
		long count = -1;
		try {
			// create order
			tblOrderObject = enterpriseTblOrderData.prepareTblOrderData(voipOrderRequest, tblEnvOrderObject);
			tblOrderObject.setOrderStatus(Long.valueOf(status));

			count = voipOrderDao.createTblOrder(tblOrderObject);
			if (count <= 0) {
				throw new TranslatorException(TranslatorException.ErrorCode.ORDER_CREATION_FAILURE,
						"Failed to create Order");
			}
		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new GenericException(GenericException.GENERIC_EXCEPTION,
					"Exception occured while createEsipEslOrderHeader");
		}
		LOG.info("Exit createEsipEslOrderHeader");
		return tblOrderObject;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.vz.esap.translation.order.service.helper.OrderServiceHelper#
	 * createEsipEslEnvOrder(com.vz.esap.translation.order.model.request.
	 * VOIPOrderRequest, int)
	 */
	@Override
	public TblEnvOrder createEsipEslEnvOrder(VOIPOrderRequest voipOrderRequest, int status)
			throws TranslatorException, GenericException {
		LOG.info("Entered createEsipEslEnvOrder");
		TblEnvOrder tblEnvOrderObject = null;
		long count = -1;
		try {
			// create env order
			tblEnvOrderObject = enterpriseEnvelopOrderData.createTblEnvOrderFromVOIPOrderRequest(voipOrderRequest,
					status);
			count = voipOrderDao.createEnvelopOrder(tblEnvOrderObject);
			if (count <= 0) {
				throw new TranslatorException(ErrorCode.ENV_ORDER_CREATION_FAILURE, "Failed to create env Order");
			}
			// TODO Disconn - To avoid NPE if Location is null DONE
			if (voipOrderRequest.getLocation() != null) {
				// create env order details for order manager
				count = createEnvOrderDetailsOrderManagerInfo(tblEnvOrderObject.getEnvOrderId(), voipOrderRequest);
				if (count <= 0) {
					throw new TranslatorException(ErrorCode.ENV_ORDER_DETAILS_CREATION_FAILURE,
							"Failed to create env Order manager");
				}
			}

		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new GenericException(GenericException.GENERIC_EXCEPTION,
					"Exception occured while createEsipEslEnvOrder");
		}
		LOG.info("Exit createEsipEslEnvOrder");
		return tblEnvOrderObject;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.vz.esap.translation.order.service.helper.OrderServiceHelper#
	 * createLocationOrderDetailsParamInfo(com.vz.esap.translation.order.model.
	 * request.VOIPOrderRequest,
	 * com.vz.esap.translation.order.model.request.ParamInfo,
	 * com.vz.esap.translation.dao.model.TblOrder)
	 */
	@Override
	public ParamInfo createLocationOrderDetailsParamInfo(VOIPOrderRequest voipOrderRequest, ParamInfo headerParamInfo,
			TblOrder tblOrderObject) throws GenericException {
		LOG.info("Entered createLocationOrderDetailsParamInfo");
		LocationEntity location = null;
		ParamInfo locationParamInfo = null;
		List<LocationEntity> locations = null;

		try {
			// create LocationEntity Object
			if (SolutionType.HPBX.equals(voipOrderRequest.getOrderHeader().getSolutionType())) {
				locations = locationOrderParser.parseLocationOrders(voipOrderRequest);
			} else {
				location = locationOrderParser.parseLocationOrder(voipOrderRequest);

				locations = new ArrayList<>();
				locations.add(location);
			}

			if ("C".equalsIgnoreCase(voipOrderRequest.getOrderHeader().getOrderType())
					&& locations.get(0).getLocationEntity() != null) {

				LOG.info("\"C\".equalsIgnoreCase(voipOrderRequest.getOrderHeader().getOrderType())\r\n"
						+ "					&& locations.get(0).getLocationEntity() != null");

				// location is old Existing Version |||| location.getLocationEntity() is New
				// Changed Version
				location = locationTransformerImpl.enrichLocationEntityWithInventory(voipOrderRequest,
						locations.get(0));

				// create order Details for Loc
				locationParamInfo = locationTblOrderDetailsData.prepareTblOrderDetailsEntityParamDataForLocation(
						location, locations.get(0).getLocationEntity(), true, null);

				headerParamInfo.addChildParam(locationParamInfo);

			} else if ("C".equalsIgnoreCase(voipOrderRequest.getOrderHeader().getOrderType())) {

				LOG.info("\"C\".equalsIgnoreCase(voipOrderRequest.getOrderHeader().getOrderType())");

				// create order Details for Loc
				locationParamInfo = locationTblOrderDetailsData.prepareTblOrderDetailsEntityParamDataForLocation(
						voipOrderRequest, tblOrderObject, locations.get(0), null);

				headerParamInfo.addChildParam(locationParamInfo);

			} else if ("I".equalsIgnoreCase(voipOrderRequest.getOrderHeader().getOrderType())) {

				// create order Details for Loc
				for (LocationEntity locationEntity : locations) {
					locationParamInfo = locationTblOrderDetailsData.prepareTblOrderDetailsEntityParamDataForLocation(
							voipOrderRequest, tblOrderObject, locationEntity, null);

					headerParamInfo.addChildParam(locationParamInfo);
				}
			}

		} catch (Exception e) {
			LOG.error("Exception Stack  {} ", e);
			LOG.error("Exception {} ", e.getMessage());
			throw new GenericException(GenericException.GENERIC_EXCEPTION,
					"Exception occured in createLocationOrderDetailsParamInfo");
		}
		LOG.info("Exit createLocationOrderDetailsParamInfo");
		return headerParamInfo;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.vz.esap.translation.order.service.helper.OrderServiceHelper#
	 * createETOrderDetailsParamInfo(com.vz.esap.translation.order.model.request.
	 * VOIPOrderRequest, com.vz.esap.translation.order.model.request.ParamInfo)
	 */
	@Override
	public ParamInfo createETOrderDetailsParamInfo(VOIPOrderRequest voipOrderRequest, ParamInfo headerParamInfo)
			throws GenericException {
		LOG.info("Entered createETOrderDetailsParamInfo");

		List<EnterpriseTrunkEntity> enterpriseTrunkList = null;
		List<EnterpriseTrunkEntity> enrichedETOrder = new ArrayList<EnterpriseTrunkEntity>();
		ArrayList<ParamInfo> entityParamInfoETList = null;
		ArrayList<EnterpriseTrunkEntity> newETOrder = new ArrayList<>();

		try {

			// create order Details for ET
			enterpriseTrunkList = enterpriseTrunkOrderParserImpl.parseEnterpriseTrunkOrder(voipOrderRequest);

			if ("C".equalsIgnoreCase(voipOrderRequest.getOrderHeader().getOrderType()) && enterpriseTrunkList != null
					&& !enterpriseTrunkList.isEmpty()) {

				LOG.info("ET Size = {}", enterpriseTrunkList.size());
				for (EnterpriseTrunkEntity enterpriseTrunkEntity : enterpriseTrunkList) {

					LOG.info("For Each ET in Change Order ET Id = {} , Redundancy Priority Type = {} ",
							enterpriseTrunkEntity.getEnterpriseTrunkId(),
							enterpriseTrunkEntity.getRedundancyPriorityType());
					LOG.debug("++Level 1+++++Original EnterpriseTrunk Entity : {} ", enterpriseTrunkEntity);
					LOG.debug("++Level 1+++++Changed EnterpriseTrunk Entity : {} ",
							enterpriseTrunkEntity.getEnterpriseTrunkEntity());

					if (enterpriseTrunkEntity.getEnterpriseTrunkEntity() != null) {
						enterpriseTrunkEntity = enterpriseTrunkTransformer
								.enrichEnterpriseTrunkEntityWithInventory(voipOrderRequest, enterpriseTrunkEntity);

						enrichedETOrder.add(enterpriseTrunkEntity);

					} else {
						newETOrder.add(enterpriseTrunkEntity);

					}

					LOG.debug("++Level 2+++++Original EnterpriseTrunk Entity : {} ", enterpriseTrunkEntity);
					LOG.debug("++Level 2+++++Changed EnterpriseTrunk Entity : {} ",
							enterpriseTrunkEntity.getEnterpriseTrunkEntity());
				}

				if (!CollectionUtils.isEmpty(enrichedETOrder)) {
					LOG.info("Inside enrichedETOrder");
					entityParamInfoETList = enterpriseTrunkTblOrderDetailsDataTransformerImpl
							.prepareTblOrderDetailsEntityParamDataForET(enrichedETOrder, true, null);

					// create order Details for Trunk Group
					headerParamInfo.addChildParams(entityParamInfoETList);

				}
				if (!CollectionUtils.isEmpty(newETOrder)) {
					LOG.info("Inside newETOrder");
					entityParamInfoETList = enterpriseTrunkTblOrderDetailsDataTransformerImpl
							.prepareTblOrderDetailsEntityParamDataForET(newETOrder,
									voipOrderRequest);

					// create order Details for Trunk Group
					headerParamInfo.addChildParams(entityParamInfoETList);

				}
			} else if ("I".equalsIgnoreCase(voipOrderRequest.getOrderHeader().getOrderType())) {

				// create order Details for Device
				entityParamInfoETList = enterpriseTrunkTblOrderDetailsDataTransformerImpl
						.prepareTblOrderDetailsEntityParamDataForET(enterpriseTrunkList,
								voipOrderRequest);

				headerParamInfo.addChildParams(entityParamInfoETList);
			}
		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new GenericException(GenericException.GENERIC_EXCEPTION,
					"Exception occured in createETOrderDetailsParamInfo");
		}
		LOG.info("Exit createETOrderDetailsParamInfo");
		return headerParamInfo;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.vz.esap.translation.order.service.helper.OrderServiceHelper#
	 * createDeviceOrderDetailsParamInfo(com.vz.esap.translation.order.model.request
	 * .VOIPOrderRequest, com.vz.esap.translation.order.model.request.ParamInfo,
	 * com.vz.esap.translation.dao.model.TblOrder)
	 */
	@Override
	public ParamInfo createDeviceOrderDetailsParamInfo(VOIPOrderRequest voipOrderRequest, ParamInfo headerParamInfo,
			TblOrder tblOrderObject) throws GenericException {
		LOG.info("Entered createDeviceOrderDetailsParamInfo");
		ArrayList<DeviceEntity> device = null;
		// DeviceEntity deviceEntity=null;
		ArrayList<DeviceEntity> enrichedDevice = new ArrayList<>();
		ArrayList<ParamInfo> deviceParamInfo = null;
		boolean deviceExistingChangedEntityPresent = false;
		boolean deviceAddedChangedEntityPresent = false;
		ArrayList<DeviceEntity> changedDevWithAdd = new ArrayList<>();

		try {

			// create Device Object
			device = deviceOrderParser.parseDeviceOrder(voipOrderRequest);
			// create order Details for Device create DeviceEntity Object
			LOG.info("Total Number Of Devices = {}", device.size());

			if ("C".equalsIgnoreCase(voipOrderRequest.getOrderHeader().getOrderType())
					&& !CollectionUtils.isEmpty(device)) {
				LOG.info("Entered Change Order For Device");

				for (DeviceEntity deviceEntity : device) {

					LOG.debug("++Level 1+++++Original Device Entity : {} ", device);
					LOG.debug("++Level 1+++++Changed Device Entity : {} ", deviceEntity.getDeviceEntity());

					if (deviceEntity.getDeviceEntity() != null) {
						LOG.info("Entered Enriching Device");
						deviceEntity = deviceTransformer.enrichDeviceEntityWithInventory(voipOrderRequest,
								deviceEntity);
						enrichedDevice.add(deviceEntity);
						deviceExistingChangedEntityPresent = true;

					} else {
						changedDevWithAdd.add(deviceEntity);
						deviceAddedChangedEntityPresent = true;

					}
					LOG.debug("++Level 2+++++Original Device Entity : {} ", device);
					LOG.debug("++Level 2+++++Changed Device Entity : {} ", deviceEntity.getDeviceEntity());

				}

				if (deviceExistingChangedEntityPresent) {
					LOG.info("Entered deviceExistingChangedEntityPresent");
					deviceParamInfo = deviceTblOrderDetailsData
							.prepareTblOrderDetailsEntityParamDataForDevice(enrichedDevice, true, null);

					headerParamInfo.addChildParams(deviceParamInfo);
				}

				if (deviceAddedChangedEntityPresent) {
					LOG.info("Entered deviceAddedChangedEntityPresent");
					deviceParamInfo = deviceTblOrderDetailsData.prepareTblOrderDetailsEntityParamDataForDevice(
							voipOrderRequest, tblOrderObject, changedDevWithAdd);

					headerParamInfo.addChildParams(deviceParamInfo);
				}

			} else if ("I".equalsIgnoreCase(voipOrderRequest.getOrderHeader().getOrderType())) {

				// create order Details for Device
				deviceParamInfo = deviceTblOrderDetailsData
						.prepareTblOrderDetailsEntityParamDataForDevice(voipOrderRequest, tblOrderObject, device);

				headerParamInfo.addChildParams(deviceParamInfo);
			}
		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new GenericException(GenericException.GENERIC_EXCEPTION,
					"Exception occured in createDeviceOrderDetailsParamInfo");
		}
		LOG.info("Exit createDeviceOrderDetailsParamInfo");
		return headerParamInfo;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.vz.esap.translation.order.service.helper.OrderServiceHelper#
	 * createTrunkGroupOrderDetailsParamInfo(com.vz.esap.translation.order.model.
	 * request.VOIPOrderRequest,
	 * com.vz.esap.translation.order.model.request.ParamInfo,
	 * com.vz.esap.translation.dao.model.TblOrder)
	 */
	@Override
	public ParamInfo createTrunkGroupOrderDetailsParamInfo(VOIPOrderRequest voipOrderRequest, ParamInfo headerParamInfo,
			TblOrder tblOrderObject) throws GenericException {
		LOG.info("Entered createTrunkGroupOrderDetailsParamInfo");

		ArrayList<TrunkGroupEntity> trunkGrp = null;
		ArrayList<TrunkGroupEntity> enrichedTrunkGrp = new ArrayList<>();
		ArrayList<ParamInfo> trunkGrpParamInfos = null;
		ArrayList<TrunkGroupEntity> newTrunkGrp = new ArrayList<>();

		try {
			// create Trunk Group Object
			// trunkGrp = trunkOrderParser.parseTrunkOrder(voipOrderRequest);

			trunkGrp = trunkOrderParser.parseTrunkOrder(voipOrderRequest, headerParamInfo);

			LOG.info("Trunk Entity Size = {}", trunkGrp.size());

			if ("C".equalsIgnoreCase(voipOrderRequest.getOrderHeader().getOrderType())) {

				for (TrunkGroupEntity trunkEntity : trunkGrp) {
					LOG.info("For Trunk Id = {}", trunkEntity.getGroupId());
					LOG.debug("++Level 1+++++Original Trunk Entity : {} ", trunkEntity);

					LOG.debug("++Level 1+++++Changed Trunk Entity : {} ", trunkEntity.getTrunkGroupEntity());

					if (trunkEntity.getTrunkGroupEntity() != null) {
						trunkEntity = trunkGroupTransformer.enrichTrunkEntityWithInventory(voipOrderRequest,
								trunkEntity);

						enrichedTrunkGrp.add(trunkEntity);
					} else {
						newTrunkGrp.add(trunkEntity);
					}

					LOG.debug("++Level 2+++++Original Trunk Entity : {} ", trunkEntity);

					LOG.debug("++Level 2+++++Changed Trunk Entity : {} ", trunkEntity.getTrunkGroupEntity());
				}

				if (!CollectionUtils.isEmpty(enrichedTrunkGrp)) {
					LOG.info("Inside enrichedTrunkGrp");
					trunkGrpParamInfos = trunkTblOrderDetailsData
							.prepareTblOrderDetailsEntityParamDataForTrunk(enrichedTrunkGrp, true, null);

					// create order Details for Trunk Group
					headerParamInfo.addChildParams(trunkGrpParamInfos);
				}
				if (!CollectionUtils.isEmpty(newTrunkGrp)) {
					LOG.info("Inside newTrunkGrp");
					trunkGrpParamInfos = trunkTblOrderDetailsData.prepareTblOrderDetailsEntityParamDataForTrunk(
							voipOrderRequest, tblOrderObject, newTrunkGrp);

					// create order Details for Trunk Group
					headerParamInfo.addChildParams(trunkGrpParamInfos);
				}

			} else if ("I".equalsIgnoreCase(voipOrderRequest.getOrderHeader().getOrderType())) {

				// create order Details for Trunk
				trunkGrpParamInfos = trunkTblOrderDetailsData
						.prepareTblOrderDetailsEntityParamDataForTrunk(voipOrderRequest, tblOrderObject, trunkGrp);

				// create order Details for Trunk Group
				headerParamInfo.addChildParams(trunkGrpParamInfos);
			}
		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new GenericException(GenericException.GENERIC_EXCEPTION,
					"Exception occured in createTrunkGroupOrderDetailsParamInfo");
		}
		LOG.info("Exit createTrunkGroupOrderDetailsParamInfo");
		return headerParamInfo;
	}

	// Start EBL
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.vz.esap.translation.order.service.helper.OrderServiceHelper#
	 * createEsipEblEnvOrder(com.vz.esap.translation.order.model.request.
	 * VOIPOrderRequest, int)
	 */
	@Override
	public TblEnvOrder createEsipEblEnvOrder(VOIPOrderRequest voipOrderRequest, int status)
			throws TranslatorException, GenericException {
		LOG.info("Entered createEsipEblEnvOrder");
		TblEnvOrder tblEnvOrderObject = null;
		long count = -1;

		try {
			// craete env order
			tblEnvOrderObject = enterpriseEnvelopOrderData.createTblEnvOrderFromVOIPOrderRequest(voipOrderRequest,
					status);
			if (tblEnvOrderObject == null) {
				throw new TranslatorException(TranslatorException.ErrorCode.ORDER_CREATION_FAILURE,
						"Failed to create Order");
			}

			count = voipOrderDao.createEnvelopOrder(tblEnvOrderObject);
			if (count <= 0) {
				throw new TranslatorException(ErrorCode.ENV_ORDER_CREATION_FAILURE, "Failed to create env Order");
			}

			if (voipOrderRequest.getLocation() != null) {
				// craete env order details for order manager
				count = createEnvOrderDetailsOrderManagerInfo(tblEnvOrderObject.getEnvOrderId(), voipOrderRequest);
				if (count <= 0) {
					throw new TranslatorException(ErrorCode.ENV_ORDER_MGR_CREATION_FAILURE,
							"Failed to create env Order manager");
				}
			}

		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new GenericException(GenericException.GENERIC_EXCEPTION,
					"Exception occured while createEsipEslOrderHeader");
		}
		LOG.info("Exit createEsipEblEnvOrder");

		return tblEnvOrderObject;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.vz.esap.translation.order.service.helper.OrderServiceHelper#
	 * createEsipEblOrderHeader(com.vz.esap.translation.order.model.request.
	 * VOIPOrderRequest, int, com.vz.esap.translation.dao.model.TblEnvOrder)
	 */
	@Override
	public TblOrder createEsipEblOrderHeader(VOIPOrderRequest voipOrderRequest, int status,
			TblEnvOrder tblEnvOrderObject) throws TranslatorException, GenericException {
		LOG.info("Entered createEsipEblOrderHeader");
		TblOrder tblOrderObject = null;
		long count = -1;

		try {
			// create order
			tblOrderObject = enterpriseTblOrderData.prepareTblOrderData(voipOrderRequest, tblEnvOrderObject);
			if (tblOrderObject == null) {
				throw new TranslatorException(TranslatorException.ErrorCode.ORDER_CREATION_FAILURE,
						"Failed to create Order");
			}
			tblOrderObject.setOrderStatus(Long.valueOf(status));

			count = voipOrderDao.createTblOrder(tblOrderObject);
			if (count <= 0) {
				throw new TranslatorException(TranslatorException.ErrorCode.ORDER_CREATION_FAILURE,
						"Failed to create Order");
			}
		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new GenericException(GenericException.GENERIC_EXCEPTION,
					"Exception occured while createEsipEslOrderHeader");
		}
		LOG.info("Exit createEsipEblOrderHeader");
		return tblOrderObject;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.vz.esap.translation.order.service.helper.OrderServiceHelper#
	 * createEsipEblOrderDetails(com.vz.esap.translation.order.model.request.
	 * VOIPOrderRequest, com.vz.esap.translation.dao.model.TblOrder)
	 */
	@Override
	public Long createEsipEblOrderDetails(VOIPOrderRequest voipOrderRequest, TblOrder tblOrderObject)
			throws TranslatorException, GenericException {

		LOG.info("Entered createEsipEblOrderDetails");
		long count = -1;
		ParamInfo headerParamInfo = null;
		List<Specification> specs = null;
		List<Feature> features = null;
		List<ChangedElement> changeElementSpecs = null;

		try {

			headerParamInfo = commonTblOrderDetailsDataTransformerImpl
					.prepareTblOrderDetailsHeaderParamDataForCustomer(voipOrderRequest, tblOrderObject);

			features = stream(voipOrderRequest.getConvergedService().getFeature())
					.filter(feature -> feature.getCode().equalsIgnoreCase("FET_LOC_LVL")).collect(Collectors.toList());

			if (!features.isEmpty() && !features.get(0).getActionCode().equalsIgnoreCase("NONE")) {
				headerParamInfo = createLocationOrderDetailsParamInfo(voipOrderRequest, headerParamInfo,
						tblOrderObject);
			}

			features = stream(voipOrderRequest.getConvergedService().getFeature())
					.filter(feature -> feature.getCode().equalsIgnoreCase("FET_XO_TRU")).collect(Collectors.toList());

			if (!features.isEmpty() && !features.get(0).getActionCode().equalsIgnoreCase("NONE")) {
				headerParamInfo = createTrunkGroupOrderDetailsParamInfo(voipOrderRequest, headerParamInfo,
						tblOrderObject);
			}

			specs = stream(stream(voipOrderRequest.getConvergedService().getFeature())
					.filter(feature -> feature.getCode().equalsIgnoreCase("FET_LOC_LVL")).collect(Collectors.toList())
					.get(0).getSpecification())
							.filter(spec -> spec.getCode() != null && spec.getCode().equalsIgnoreCase("SP_XO_TNQ"))
							.collect(Collectors.toList());

			if (voipOrderRequest.getChangeManagement() != null) {
				changeElementSpecs = stream(voipOrderRequest.getChangeManagement()[0].getChangedElement())
						.filter(changeElement -> changeElement.getFeatureCode().equalsIgnoreCase("FET_LOC_LVL")
								&& changeElement.getSpecificationCode() != null
								&& changeElement.getSpecificationCode().equalsIgnoreCase("SP_XO_TNQ"))
						.collect(Collectors.toList());
			}

			if (!CollectionUtils.isEmpty(specs) || !CollectionUtils.isEmpty(changeElementSpecs)) {
				headerParamInfo = createGroupTNOrderDetailsParamInfo(voipOrderRequest, headerParamInfo);
			}

			if ("I".equalsIgnoreCase(voipOrderRequest.getOrderHeader().getOrderType())) {
				count = voipOrderDao.populateOrderDetails(tblOrderObject, headerParamInfo.getChildParams(), "n", 0, 0);
			} else if ("C".equalsIgnoreCase(voipOrderRequest.getOrderHeader().getOrderType())) {
				count = voipOrderDao.populateOrderDetails(tblOrderObject, headerParamInfo.getChildParams(), "c", 0, 0);
			}

			if (count <= 0) {
				throw new TranslatorException(TranslatorException.ErrorCode.ORDER_DETAILS_CREATION_FAILURE,
						"Failed to create Order Details");
			}
		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new GenericException(GenericException.GENERIC_EXCEPTION,
					"Exception occured while createEsipEslOrderHeader");
		}
		LOG.info("Exit createEsipEblOrderDetails");
		return count;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.vz.esap.translation.order.service.helper.OrderServiceHelper#
	 * createGroupTNOrderDetailsParamInfo(com.vz.esap.translation.order.model.
	 * request. VOIPOrderRequest,
	 * com.vz.esap.translation.order.model.request.ParamInfo,
	 * com.vz.esap.translation.dao.model.TblOrder)
	 */
	@Override
	public ParamInfo createGroupTNOrderDetailsParamInfo(VOIPOrderRequest voipOrderRequest, ParamInfo headerParamInfo)
			throws GenericException {
		LOG.info("Entered createGroupTNOrderDetailsParamInfo");

		long tnCount = 0;
		ArrayList<TrunkGroupEntity> trunkGrp = null;
		ArrayList<ParamInfo> grpTNsParamInfos = null;
		ArrayList<GroupTNEntity> groupTNList = null;
		List<ChangedElement> changeElementSpecs = null;
		ArrayList<TrunkGroupEntity> trunkGrpInvList = null;
		List<String> distinctTrunks = null;
		TrunkGroupEntity trunkGrpInv = null;
		ArrayList<GroupTNEntity> groupTNListMacd = null;

		try {

			if ("C".equalsIgnoreCase(voipOrderRequest.getOrderHeader().getOrderType())) {

				changeElementSpecs = stream(voipOrderRequest.getChangeManagement()[0].getChangedElement())
						.filter(changeElement -> (changeElement.getFeatureCode().equalsIgnoreCase("FET_LOC_LVL")
								|| changeElement.getFeatureCode().equalsIgnoreCase("FET_HPBX_LOC_LVL"))
								&& changeElement.getSpecificationCode() != null
								&& changeElement.getSpecificationCode().equalsIgnoreCase("SP_XO_TNQ"))
						.collect(Collectors.toList());

				// This is Change ADD TN scenario
				/*
				 * if (!CollectionUtils.isEmpty(changeElementSpecs) &&
				 * "ADDED".equalsIgnoreCase(changeElementSpecs.get(0).getChangeType())) { //
				 * pull TN info for Add TN from PC DB by doing DB dip into staging table tnCount
				 * = tnOrderParser.fetchTNDetailsFromPC(voipOrderRequest);
				 * 
				 * distinctTrunks =
				 * voipOrderDao.getDistinctTrunkFromTnDetails(voipOrderRequest); trunkGrpInvList
				 * = new ArrayList<>(); for (String trunkId : distinctTrunks) { // Fetch Trunk
				 * From Inventory: trunkGrpInv = getEntityDetailsFromInventory(trunkId,
				 * TrunkGroupEntity.class); trunkGrpInvList.add(trunkGrpInv);
				 * 
				 * LOG.info("Inside Create Distunct Trunk for Trunk Entity = {}", trunkGrpInv);
				 * }
				 * 
				 * groupTNList = tnOrderParser.processGroupTNS(voipOrderRequest,
				 * trunkGrpInvList, 0, 0, tnCount); grpTNsParamInfos =
				 * tnTblOrderDetailsData.prepareTODEtityDataForGroups(groupTNList, "I");
				 * 
				 * }
				 */

				if (!CollectionUtils.isEmpty(changeElementSpecs)
						&& ("REMOVED".equalsIgnoreCase(changeElementSpecs.get(0).getChangeType())
								|| "CHANGED".equalsIgnoreCase(changeElementSpecs.get(0).getChangeType())
								|| "ADDED".equalsIgnoreCase(changeElementSpecs.get(0).getChangeType())
								|| "CANCEL".equalsIgnoreCase(changeElementSpecs.get(0).getChangeType()))) {
					// pull TN info for Remove TN from PC DB by doing DB dip into staging table

					tnCount = tnOrderParser.fetchTNDetailsFromPC(voipOrderRequest);

					LOG.info("MAC ADD TN Count = {}", tnCount);

					if (tnCount > 0) {
						distinctTrunks = voipOrderDao.getDistinctTrunkFromTnDetails(voipOrderRequest);

						trunkGrpInvList = new ArrayList<>();

						for (String trunkId : distinctTrunks) {
							// Fetch Trunk From Inventory:
							LOG.info("Trunk Id From TN data= {}", trunkId);

							trunkGrpInv = getEntityDetailsFromInventory(trunkId, TrunkGroupEntity.class);

							LOG.info("Trunk Id From Inventory Trunk data= {}", trunkGrpInv.getGroupId());

							trunkGrpInvList.add(trunkGrpInv);

							LOG.debug("Inside Create Distunct Trunk for Trunk Entity = {}", trunkGrpInv);
						}

						groupTNList = tnOrderParser.processGroupTNS(voipOrderRequest, trunkGrpInvList, 0, 0, tnCount);

						for (GroupTNEntity groupTNEntity : groupTNList) {
							LOG.info("Group TN entity Action = {} For TN = {}", groupTNEntity.getEntityAction(),
									groupTNEntity.getTnRecord().getTn());

							groupTNListMacd = new ArrayList<>();
							groupTNListMacd.add(groupTNEntity);

							if ("ADD".equalsIgnoreCase(groupTNEntity.getEntityAction())) {

								grpTNsParamInfos = tnTblOrderDetailsData.prepareTODEtityDataForGroups(groupTNListMacd,
										"I");

								LOG.info("grpTNsParamInfos Size = {}", grpTNsParamInfos.size());

							} else if (Arrays.asList("REMOVE", "REMOVED", "CANCEL")
									.contains(groupTNEntity.getEntityAction())) {

								grpTNsParamInfos = tnTblOrderDetailsData.prepareTODEtityDataForGroups(groupTNListMacd,
										"O");

								LOG.info("grpTNsParamInfos Size = {}", grpTNsParamInfos.size());

							}
							headerParamInfo.addChildParams((ArrayList<ParamInfo>) grpTNsParamInfos);
						}
					}

					/*
					 * tnOrderParser.fetchChangeTNDetailsFromPC(voipOrderRequest);
					 * 
					 * trunkGrpInvList = new ArrayList<>(); groupTNList = new ArrayList<>();
					 * 
					 * // This give all the TNs to be removed+Changed from TBL_LOR_TN_CHNG_DETAILS
					 * List<TblLorTnChngDetails> tblLorTnChngDetailsList = voipOrderDao
					 * .getChangedTnDetails(voipOrderRequest);
					 * 
					 * LOG.info("tblLorTnChngDetailsList {}", tblLorTnChngDetailsList.size());
					 * 
					 * for (TblLorTnChngDetails tblLorTnChngDetails : tblLorTnChngDetailsList) {
					 * LOG.info("tblLorTnChngDetails.getChangeType {}",
					 * tblLorTnChngDetails.getChangeType());
					 * 
					 * if ("Removed".equalsIgnoreCase(tblLorTnChngDetails.getChangeType())) {
					 * LOG.info("TN To Be Removed = {}", tblLorTnChngDetails.getFetInsId());
					 * 
					 * GroupTNEntity groupTNEntity = getEntityDetailsFromInventory(
					 * tblLorTnChngDetails.getFetInsId(), GroupTNEntity.class);
					 * 
					 * if (groupTNEntity != null && groupTNEntity.getTnRecord() != null &&
					 * groupTNEntity.getTnRecord().getTrunkId() != null) { LOG.info("Trunk Id- {}",
					 * groupTNEntity.getTnRecord().getTrunkId());
					 * 
					 * trunkGrpInv =
					 * getEntityDetailsFromInventory(groupTNEntity.getTnRecord().getTrunkId(),
					 * TrunkGroupEntity.class); trunkGrpInvList.add(trunkGrpInv);
					 * 
					 * groupTNEntity.setAction(EsapEnum.OrderAction.DELETE);
					 * groupTNList.add(groupTNEntity); } } else if
					 * ("Changed".equalsIgnoreCase(tblLorTnChngDetails.getChangeType())) {
					 * LOG.info("TN To Be Changed = {}", tblLorTnChngDetails.getFetInsId());
					 * 
					 * GroupTNEntity groupTNEntity = getEntityDetailsFromInventory(
					 * tblLorTnChngDetails.getFetInsId(), GroupTNEntity.class);
					 * 
					 * if (groupTNEntity != null && groupTNEntity.getTnRecord() != null &&
					 * groupTNEntity.getTnRecord().getTrunkId() != null) { LOG.info("Trunk Id- {}",
					 * groupTNEntity.getTnRecord().getTrunkId());
					 * 
					 * trunkGrpInv =
					 * getEntityDetailsFromInventory(groupTNEntity.getTnRecord().getTrunkId(),
					 * TrunkGroupEntity.class); trunkGrpInvList.add(trunkGrpInv);
					 * 
					 * groupTNEntity.setAction(EsapEnum.OrderAction.MODIFY);
					 * groupTNList.add(groupTNEntity); } } }
					 * 
					 * LOG.info("groupTNList size-{}", groupTNList);
					 * 
					 * grpTNsParamInfos =
					 * tnTblOrderDetailsData.prepareTODEtityDataForGroups(groupTNList, null);
					 */
				}
			} else if ("I".equalsIgnoreCase(voipOrderRequest.getOrderHeader().getOrderType())) {

				// pull TN info for Add TN from PC DB by doing DB dip into staging table
				tnCount = tnOrderParser.fetchTNDetailsFromPC(voipOrderRequest);
				trunkGrp = trunkOrderParser.parseTrunkOrder(voipOrderRequest);

				// Temporary for Test Environment

				if (tnCount > 0) {
					groupTNList = tnOrderParser.processGroupTNS(voipOrderRequest, trunkGrp, 0, 0, tnCount);
					LOG.info("Install groupTNList size-{}", groupTNList.size());
				}
				grpTNsParamInfos = tnTblOrderDetailsData.prepareTODEtityDataForGroups(groupTNList, "I");

				headerParamInfo.addChildParams((ArrayList<ParamInfo>) grpTNsParamInfos);
			}

			// headerParamInfo.addChildParams((ArrayList<ParamInfo>) grpTNsParamInfos);

		} catch (Exception e) {
			LOG.error("Exception {} ", e);
			throw new GenericException(GenericException.GENERIC_EXCEPTION,
					"Exception occured in createGroupTNOrderDetailsParamInfo");
		}
		LOG.info("Exit createGroupTNOrderDetailsParamInfo");
		return headerParamInfo;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.vz.esap.translation.order.service.helper.OrderServiceHelper#
	 * createNbsOrderDetailsParamInfo(com.vz.esap.translation.order.model. request.
	 * VOIPOrderRequest, com.vz.esap.translation.order.model.request.ParamInfo,
	 * com.vz.esap.translation.dao.model.TblOrder)
	 */
	@Override
	public ParamInfo createNbsOrderDetailsParamInfo(VOIPOrderRequest voipOrderRequest, ParamInfo headerParamInfo,
			TblOrder tblOrderObject) throws GenericException {
		LOG.info("Entered createNbsOrderDetailsParamInfo");

		ArrayList<NbsEntity> nbsEntityList = null;
		ArrayList<NbsEntity> enrichedNbsEntityList = new ArrayList<>();
		ArrayList<ParamInfo> nbsEntityParamInfos = null;
		ArrayList<NbsEntity> newNbsEntityList = new ArrayList<>();

		try {
			// create Nbs Object
			nbsEntityList = nbsOrderParserImpl.parseNbsOrder(voipOrderRequest);

			if ("C".equalsIgnoreCase(voipOrderRequest.getOrderHeader().getOrderType()) && nbsEntityList != null
					&& !nbsEntityList.isEmpty()) {

				boolean hasNbsChanged = false;
				for (NbsEntity nbsEntity : nbsEntityList) {

					LOG.debug("++Level 1+++++Original Nbs Entity : {} ", nbsEntity);
					LOG.debug("++Level 1+++++Changed Nbs Entity : {} ", nbsEntity.getNbsEntity());

					if (nbsEntity.getNbsEntity() != null) {
						nbsEntity = nbsTransformer.enrichNbsEntityWithInventory(voipOrderRequest, nbsEntity);

						// create order Details for Trunk
						enrichedNbsEntityList.add(nbsEntity);
						hasNbsChanged = true;

					} else {
						newNbsEntityList.add(nbsEntity);
					}

					LOG.debug("++Level 2+++++Original Nbs Entity : {} ", nbsEntity);
					LOG.debug("++Level 2+++++Changed Nbs Entity : {} ", nbsEntity.getNbsEntity());
				}

				if (!CollectionUtils.isEmpty(enrichedNbsEntityList)) {
					LOG.info("Inside enrichedNbsEntityList");
					nbsEntityParamInfos = nbsTblOrderDetailsDataTransformerImpl
							.prepareTblOrderDetailsEntityParamDataForNbs(enrichedNbsEntityList, true, null);

					headerParamInfo.addChildParams(nbsEntityParamInfos);
				}
				if (!CollectionUtils.isEmpty(newNbsEntityList)) {
					LOG.info("Inside newNbsEntityList");
					nbsEntityParamInfos = nbsTblOrderDetailsDataTransformerImpl
							.prepareTblOrderDetailsEntityParamDataForNbs(voipOrderRequest, tblOrderObject,
									newNbsEntityList, null);

					headerParamInfo.addChildParams(nbsEntityParamInfos);
				}
			} else if ("I".equalsIgnoreCase(voipOrderRequest.getOrderHeader().getOrderType())) {

				// create order Details for Nbs
				nbsEntityParamInfos = nbsTblOrderDetailsDataTransformerImpl.prepareTblOrderDetailsEntityParamDataForNbs(
						voipOrderRequest, tblOrderObject, nbsEntityList, null);

				headerParamInfo.addChildParams(nbsEntityParamInfos);
			}

		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new GenericException(GenericException.GENERIC_EXCEPTION,
					"Exception occured in createNbsOrderDetailsParamInfo");
		}
		LOG.info("Exit createNbsOrderDetailsParamInfo");
		return headerParamInfo;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.vz.esap.translation.order.service.helper.OrderServiceHelper#getClli(
	 * java. lang.String, java.util.Map)
	 */
	@Override
	public String getClli(String wfService, Map<String, String> paramMap) throws GenericException {
		LOG.info("Entered getClli");

		String clli = null;
		String clliType = null;
		String processName = null;
		DBServiceResponse dbServiceResponse = null;
		Set<String> selectColumnSet = null;
		List<String[]> whereClauseList = null;

		try {
			clliType = EsapEnum.ClliType.getValue(wfService);

			if (clliType != null && "UNKNOWN".equalsIgnoreCase(clliType))
				return "BLANK_CLLI";

			if (!paramMap.isEmpty() && paramMap.get("PROCESS_NAME") != null)
				processName = paramMap.get("PROCESS_NAME");

			selectColumnSet = new HashSet<>();
			selectColumnSet.add("PARAM_NAME");
			selectColumnSet.add("PARAM_VALUE");

			whereClauseList = new ArrayList<>();
			whereClauseList.add(new String[] { "PARAM_NAME", clliType });
			whereClauseList.add(new String[] { "PROCESS_NAME", processName });

			dbServiceResponse = inventoryDomainDataServiceImpl.searchInventory("TBL_CONFIG_PARAMS", selectColumnSet,
					whereClauseList);

			for (TblRow tblRows : dbServiceResponse.getTableRows()) {
				if (tblRows.getTblRow() != null && tblRows.getTblRow().get("PARAM_VALUE") != null
						&& tblRows.getTblRow().get("PARAM_VALUE").getValue() != null) {
					clli = tblRows.getTblRow().get("PARAM_VALUE").getValue();
					LOG.info("clli : {}", clli);
				} else {
					throw new TranslatorException(ErrorCode.CLLI_MISSING, "CLLI missing for Workflow : " + wfService);
				}
			}

		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new GenericException(GenericException.GENERIC_EXCEPTION, "Exception occured in getClli");
		}
		LOG.info("Exit getClli");
		return clli;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.vz.esap.translation.order.service.helper.OrderServiceHelper#
	 * getMatchingTnOrderDetails(com.vz.esap.translation.dao.model.TblOrder)
	 */
	@Override
	public List<TblOrderDetails> getMatchingTnOrderDetails(TblOrder tblOrderBean)
			throws TranslatorException, GenericException {
		LOG.info("Entered getMatchingTnOrderDetails");

		List<TblOrderDetails> ordDetailsList = new ArrayList<TblOrderDetails>();
		TblOrderDetails tblOrderDetails = null;
		try {
			tblOrderDetails = new TblOrderDetails();
			tblOrderDetails.setOrderId(tblOrderBean.getOrderId());

			ordDetailsList = voipOrderDao.getTnOrderDetailsEntities(tblOrderDetails);

		} catch (Exception e) {
			LOG.error("Exception {} ", e);
			throw new GenericException(GenericException.GENERIC_EXCEPTION,
					"Exception occured in getMatchingTnOrderDetails");
		}
		LOG.info("Exit getMatchingTnOrderDetails");
		return ordDetailsList;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.vz.esap.translation.order.service.helper.OrderServiceHelper#
	 * createIpFlexEnvOrder
	 * (com.vz.esap.translation.order.model.request.VOIPOrderRequest, int)
	 */
	@Override
	public TblEnvOrder createIpFlexEnvOrder(VOIPOrderRequest voipOrderRequest, int status)
			throws TranslatorException, GenericException {
		LOG.info("Entered createIpFlexEnvOrder");
		TblEnvOrder tblEnvOrderObject = null;
		long count = -1;

		try {
			// create env order
			tblEnvOrderObject = enterpriseEnvelopOrderData.createTblEnvOrderFromVOIPOrderRequest(voipOrderRequest,
					status);
			if (tblEnvOrderObject == null) {
				throw new TranslatorException(TranslatorException.ErrorCode.ORDER_CREATION_FAILURE,
						"Failed to create Order");
			}

			count = voipOrderDao.createEnvelopOrder(tblEnvOrderObject);
			if (count <= 0) {
				throw new TranslatorException(ErrorCode.ENV_ORDER_CREATION_FAILURE, "Failed to create env Order");
			}

			// TODO Niladri Ipflex Disconnect Review :: To avoid NPE if Location is null
			if (voipOrderRequest.getLocation() != null) {
				// craete env order details for order manager
				count = createEnvOrderDetailsOrderManagerInfo(tblEnvOrderObject.getEnvOrderId(), voipOrderRequest);
				if (count <= 0) {
					throw new TranslatorException(ErrorCode.ENV_ORDER_MGR_CREATION_FAILURE,
							"Failed to create env Order manager");
				}
			}

		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new GenericException(GenericException.GENERIC_EXCEPTION,
					"Exception occured while createIpFlexEnvOrder");
		}
		LOG.info("Exit createIpFlexEnvOrder");

		return tblEnvOrderObject;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.vz.esap.translation.order.service.helper.OrderServiceHelper#
	 * createIpFlexOrderHeader
	 * (com.vz.esap.translation.order.model.request.VOIPOrderRequest, int,
	 * com.vz.esap.translation.dao.model.TblEnvOrder)
	 */
	@Override
	public TblOrder createIpFlexOrderHeader(VOIPOrderRequest voipOrderRequest, int status,
			TblEnvOrder tblEnvOrderObject) throws TranslatorException, GenericException {
		LOG.info("Entered createIpFlexOrderHeader");
		TblOrder tblOrderObject = null;
		long count = -1;

		try {
			// create order
			tblOrderObject = enterpriseTblOrderData.prepareTblOrderData(voipOrderRequest, tblEnvOrderObject);
			if (tblOrderObject == null) {
				throw new TranslatorException(TranslatorException.ErrorCode.ORDER_CREATION_FAILURE,
						"Failed to create Order");
			}
			tblOrderObject.setOrderStatus(Long.valueOf(status));

			count = voipOrderDao.createTblOrder(tblOrderObject);
			if (count <= 0) {
				throw new TranslatorException(TranslatorException.ErrorCode.ORDER_CREATION_FAILURE,
						"Failed to create Order");
			}
		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new GenericException(GenericException.GENERIC_EXCEPTION,
					"Exception occured while createIpFlexOrderHeader");
		}
		LOG.info("Exit createIpFlexOrderHeader");
		return tblOrderObject;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.vz.esap.translation.order.service.helper.OrderServiceHelper#
	 * createIpFlexOrderDetails
	 * (com.vz.esap.translation.order.model.request.VOIPOrderRequest,
	 * com.vz.esap.translation.dao.model.TblOrder)
	 */
	@Override
	public Long createIpFlexOrderDetails(VOIPOrderRequest voipOrderRequest, TblOrder tblOrderObject,
			Map<String, String> productDetails, boolean isNewCustomer) throws TranslatorException, GenericException {

		LOG.info("Entered createIpFlexOrderDetails");
		long count = -1;
		ParamInfo headerParamInfo = null;
		List<Specification> specs = null;
		List<ChangedElement> changeElementSpecs = null;
		List<Feature> features = null;

		try {

			// if (isNewCustomer)
			headerParamInfo = commonTblOrderDetailsDataTransformerImpl
					.prepareTblOrderDetailsHeaderParamDataForCustomer(voipOrderRequest, tblOrderObject);

			// Start Flex change fix
			features = stream(voipOrderRequest.getConvergedService().getFeature())
					.filter(feature -> feature.getCode().equalsIgnoreCase("EFET_VOIP_ENT_LVL"))
					.collect(Collectors.toList());
			if (!features.isEmpty() && !features.get(0).getActionCode().equalsIgnoreCase("NONE")) {
				headerParamInfo = createEnterpriseOrderDetailsParamInfo(voipOrderRequest, tblOrderObject,
						headerParamInfo, false);
			}

			features = stream(voipOrderRequest.getConvergedService().getFeature())
					.filter(feature -> feature.getCode().equalsIgnoreCase("FET_LOC_LVL")).collect(Collectors.toList());
			if (!features.isEmpty() && !features.get(0).getActionCode().equalsIgnoreCase("NONE")) {
				headerParamInfo = createLocationOrderDetailsParamInfo(voipOrderRequest, headerParamInfo,
						tblOrderObject);
			}

			// Start Flex Device change fix
			features = stream(voipOrderRequest.getConvergedService().getFeature())
					.filter(feature -> feature.getCode().equalsIgnoreCase("FET_DE")
							|| feature.getCode().equalsIgnoreCase("FET_DE_LOC"))
					.collect(Collectors.toList());

			if (!features.isEmpty() && voipOrderRequest.getOrderHeader() != null
					&& !"C".equalsIgnoreCase(voipOrderRequest.getOrderHeader().getOrderType()) && !features.get(0).getActionCode().equalsIgnoreCase("NONE")) {
				headerParamInfo = createDeviceOrderDetailsParamInfo(voipOrderRequest, headerParamInfo, tblOrderObject);
			}
			// End Flex Device change fix

			features = stream(voipOrderRequest.getConvergedService().getFeature())
					.filter(feature -> "FET_XO_TRU".equalsIgnoreCase(feature.getCode())
							|| "FET_XO_TRU_CON_LINE_LOC".equalsIgnoreCase(feature.getCode())
							|| "FET_XO_TRU_CON".equalsIgnoreCase(feature.getCode()))
					.collect(Collectors.toList());

			if (!features.isEmpty() && !features.get(0).getActionCode().equalsIgnoreCase("NONE")) {
				headerParamInfo = createTrunkGroupOrderDetailsParamInfo(voipOrderRequest, headerParamInfo,
						tblOrderObject);
			}
			// End Flex change fix

			specs = stream(stream(voipOrderRequest.getConvergedService().getFeature())
					.filter(feature -> feature.getCode().equalsIgnoreCase("FET_LOC_LVL")).collect(Collectors.toList())
					.get(0).getSpecification()).filter(spec -> spec.getCode().equalsIgnoreCase("SP_XO_TNQ"))
							.collect(Collectors.toList());

			if (voipOrderRequest.getChangeManagement() != null) {
				changeElementSpecs = stream(voipOrderRequest.getChangeManagement()[0].getChangedElement())
						.filter(changeElement -> "FET_LOC_LVL".equalsIgnoreCase(changeElement.getFeatureCode())
								&& "SP_XO_TNQ".equalsIgnoreCase(changeElement.getSpecificationCode()))
						.collect(Collectors.toList());
			}

			if (!CollectionUtils.isEmpty(specs) || !CollectionUtils.isEmpty(changeElementSpecs)) {
				headerParamInfo = createGroupTNOrderDetailsParamInfo(voipOrderRequest, headerParamInfo);
			}

			if ("I".equalsIgnoreCase(voipOrderRequest.getOrderHeader().getOrderType())) {
				count = voipOrderDao.populateOrderDetails(tblOrderObject, headerParamInfo.getChildParams(), "n", 0, 0);
			} else if ("C".equalsIgnoreCase(voipOrderRequest.getOrderHeader().getOrderType())) {
				count = voipOrderDao.populateOrderDetails(tblOrderObject, headerParamInfo.getChildParams(), "c", 0, 0);
			}
			if (count <= 0) {
				throw new TranslatorException(TranslatorException.ErrorCode.ORDER_DETAILS_CREATION_FAILURE,
						"Failed to create Order Details");
			}
		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new GenericException(GenericException.GENERIC_EXCEPTION,
					"Exception occured while createIpFlexOrderDetails");
		}
		LOG.info("Exit createIpFlexOrderDetails");
		return count;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.vz.esap.translation.order.service.helper.OrderServiceHelper#
	 * getEnterpriseInformationFromEsl(java.lang.String)
	 */
	@Override
	public String getEnterpriseInformationFromEsl(String eslId) throws ApplicationInterfaceException, GenericException {

		LOG.info("Entered getEnterpriseInformationFromEsl");
		DBServiceResponse dbServiceResponse = null;
		Set<String> selectColumnSet = null;
		List<String[]> whereClauseList = null;
		String enterpriseId = null;

		try {
			selectColumnSet = new HashSet<>();
			selectColumnSet.add("ENTERPRISE_ID");
			selectColumnSet.add("LOCATION_ID");

			whereClauseList = new ArrayList<>();
			whereClauseList.add(new String[] { "LOCATION_ID", eslId });

			dbServiceResponse = inventoryDomainDataServiceImpl.searchInventory("TBL_LOCATION", selectColumnSet,
					whereClauseList);

			for (TblRow tblRows : dbServiceResponse.getTableRows()) {
				enterpriseId = tblRows.getTblRow().get("ENTERPRISE_ID").getValue();
				LOG.info("Enterprise Id : {}", enterpriseId);
			}

		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new GenericException(GenericException.GENERIC_EXCEPTION,
					"Exception occured in getEnterpriseInformationFromEsl");
		}

		LOG.info("Exit getEnterpriseInformationFromEsl");
		return enterpriseId;

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.vz.esap.translation.order.service.helper.OrderServiceHelper#
	 * getConfigParamValue(java.lang.String, java.lang.String)
	 */
	@Override
	public DBServiceResponse getConfigParamValue(String processName, String paramName)
			throws ApplicationInterfaceException, GenericException {

		LOG.info("Entered getConfigParamValue");
		DBServiceResponse dbServiceResponse = null;
		Set<String> selectColumnSet = null;
		List<String[]> whereClauseList = null;

		try {
			selectColumnSet = new HashSet<>();
			selectColumnSet.add("PARAM_NAME");
			selectColumnSet.add("PARAM_VALUE");

			whereClauseList = new ArrayList<>();
			whereClauseList.add(new String[] { "PARAM_NAME", paramName });
			whereClauseList.add(new String[] { "PROCESS_NAME", processName });

			dbServiceResponse = inventoryDomainDataServiceImpl.searchInventory("TBL_CONFIG_PARAMS", selectColumnSet,
					whereClauseList);

		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new GenericException(GenericException.GENERIC_EXCEPTION, "Exception occured in getConfigParamValue");
		}

		LOG.info("Exit getConfigParamValue PROCESS_NAME : {} , PARAM_NAME : {} , The Response is : {}", processName,
				paramName, dbServiceResponse);
		return dbServiceResponse;

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.vz.esap.translation.order.service.helper.OrderServiceHelper#
	 * isSystemBulkUpdateEligible(long)
	 */
	@Override
	public boolean isSystemBulkUpdateEligible(long tnCount) throws ApplicationInterfaceException, GenericException {

		LOG.info("Entered isSystemBulkUpdateEligible For TN Count : {}", tnCount);
		DBServiceResponse dbServiceResponse = null;
		boolean isSystemUpdateFlagOn = false;
		boolean isSystemUpdateCountFlagOn = false;

		try {

			dbServiceResponse = getConfigParamValue("OrderManager", "SYSTEM_UPDATE_TN_FXO");

			for (TblRow tblRows : dbServiceResponse.getTableRows()) {
				if (tblRows.getTblRow() != null && tblRows.getTblRow().get("PARAM_VALUE") != null
						&& tblRows.getTblRow().get("PARAM_VALUE").getValue() != null
						&& tblRows.getTblRow().get("PARAM_VALUE").getValue().equalsIgnoreCase("1")) {

					isSystemUpdateFlagOn = true;

					LOG.info("System Update is ON : {}", tblRows.getTblRow().get("PARAM_VALUE").getValue());
				}
			}

			if (isSystemUpdateFlagOn == true) {
				dbServiceResponse = getConfigParamValue("OrderManager", "SYSTEM_UPDATE_COUNT_TN_FXO");

				for (TblRow tblRows : dbServiceResponse.getTableRows()) {
					if (tblRows.getTblRow() != null && tblRows.getTblRow().get("PARAM_VALUE") != null
							&& tblRows.getTblRow().get("PARAM_VALUE").getValue() != null) {

						if (Long.valueOf(tblRows.getTblRow().get("PARAM_VALUE").getValue()) >= tnCount)
							isSystemUpdateCountFlagOn = true;

						LOG.info("System Update Count : {}", tblRows.getTblRow().get("PARAM_VALUE").getValue());
					}
				}
			}

		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new GenericException(GenericException.GENERIC_EXCEPTION,
					"Exception occured in isSystemBulkUpdateEligible");
		}

		LOG.info("Exit isSystemBulkUpdateEligible Flag is : {}", isSystemUpdateFlagOn && isSystemUpdateCountFlagOn);
		return (isSystemUpdateFlagOn && isSystemUpdateCountFlagOn);

	}

	/**
	 * @param objectSource
	 * @param objectDest
	 * @return Map<String
	 * @throws ApplicationInterfaceException
	 * @throws IllegalAccessException
	 */
	<T> Map<String, Map<String, String>> entityDifferences(T objectSource, T objectDest)
			throws ApplicationInterfaceException, IllegalAccessException {

		HashSet<String> supportedType = new HashSet<>();
		supportedType.add(TranslationConstant.CUSTOMER_ENTITY_CLASS);
		supportedType.add(TranslationConstant.LOCATION_ENTITY_CLASS);
		supportedType.add(TranslationConstant.DEVICE_ENTITY_CLASS);
		supportedType.add(TranslationConstant.ENTERPRISE_TRUNK_ENTITY_CLASS);
		supportedType.add(TranslationConstant.TRUNK_GROUP_ENTITY_CLASS);
		supportedType.add(TranslationConstant.NBS_ENTITY_CLASS);

		String entityClassTypeSource = objectSource.getClass().getSimpleName(); // Removed upper case as it is not
																				// passing switch case

		String entityClassTypeDest = objectDest.getClass().getSimpleName(); // Source and Destination mismatch error
																			// coming
		if (!entityClassTypeSource.equals(entityClassTypeDest))
			throw new ApplicationInterfaceException("Source and Destination Mismatch");

		if (!supportedType.contains(entityClassTypeSource))
			throw new ApplicationInterfaceException("Unsupported dataype");

		Map<String, Map<String, String>> resultantMap = new HashMap<>();

		switch (entityClassTypeSource) {
		case TranslationConstant.CUSTOMER_ENTITY_CLASS:
			for (Field field : CustomerEntity.class.getDeclaredFields()) {
				LOG.info("Field Name {}: ", field.getName());
				ReflectionUtils.makeAccessible(field); // field.setAccessible(true);​
				if (field.get(objectSource) != null && !field.get(objectSource).equals(field.get(objectDest))) {

					Map<String, String> valueCompareMap = new HashMap<>();
					valueCompareMap.put(String.valueOf(field.get(objectSource)), String.valueOf(field.get(objectDest)));
					resultantMap.put(field.getName(), valueCompareMap);
				}
			}
			break;

		case TranslationConstant.LOCATION_ENTITY_CLASS:
			for (Field field : LocationEntity.class.getDeclaredFields()) {
				LOG.info("Field Name {}: ", field.getName());
				ReflectionUtils.makeAccessible(field); // field.setAccessible(true);​
				if (field.get(objectSource) != null && !field.get(objectSource).equals(field.get(objectDest))) {

					Map<String, String> valueCompareMap = new HashMap<>();
					valueCompareMap.put(String.valueOf(field.get(objectSource)), String.valueOf(field.get(objectDest)));
					resultantMap.put(field.getName(), valueCompareMap);
				}
			}
			break;

		case TranslationConstant.DEVICE_ENTITY_CLASS:
			for (Field field : DeviceEntity.class.getDeclaredFields()) {
				LOG.info("Field Name {}: ", field.getName());
				ReflectionUtils.makeAccessible(field); // field.setAccessible(true);​
				Object fields = field.get(objectSource);
				if (field.get(objectSource) != null && !field.get(objectSource).equals(field.get(objectDest))) {

					Map<String, String> valueCompareMap = new HashMap<>();
					valueCompareMap.put(String.valueOf(field.get(objectSource)), String.valueOf(field.get(objectDest)));
					resultantMap.put(field.getName(), valueCompareMap);
				}
			}
			break;

		case TranslationConstant.ENTERPRISE_TRUNK_ENTITY_CLASS:
			for (Field field : EnterpriseTrunkEntity.class.getDeclaredFields()) {
				LOG.info("Field Name {}: ", field.getName());
				ReflectionUtils.makeAccessible(field); // field.setAccessible(true);​
				if (field.get(objectSource) != null && !field.get(objectSource).equals(field.get(objectDest))) {

					Map<String, String> valueCompareMap = new HashMap<>();
					valueCompareMap.put(String.valueOf(field.get(objectSource)), String.valueOf(field.get(objectDest)));
					resultantMap.put(field.getName(), valueCompareMap);
				}
			}
			break;

		case TranslationConstant.TRUNK_GROUP_ENTITY_CLASS:
			for (Field field : TrunkGroupEntity.class.getDeclaredFields()) {
				LOG.info("Field Name {}: ", field.getName());
				ReflectionUtils.makeAccessible(field); // field.setAccessible(true);​
				if (field.get(objectSource) != null && !field.get(objectSource).equals(field.get(objectDest))) {

					Map<String, String> valueCompareMap = new HashMap<>();
					valueCompareMap.put(String.valueOf(field.get(objectSource)), String.valueOf(field.get(objectDest)));
					resultantMap.put(field.getName(), valueCompareMap);
				}
			}
			break;

		case TranslationConstant.NBS_ENTITY_CLASS:
			for (Field field : NbsEntity.class.getDeclaredFields()) {
				LOG.info("Field Name {}: ", field.getName());
				ReflectionUtils.makeAccessible(field); // field.setAccessible(true);​
				if (field.get(objectSource) != null && !field.get(objectSource).equals(field.get(objectDest))) {

					Map<String, String> valueCompareMap = new HashMap<>();
					valueCompareMap.put(String.valueOf(field.get(objectSource)), String.valueOf(field.get(objectDest)));
					resultantMap.put(field.getName(), valueCompareMap);
				}
			}
			break;
		}
		return resultantMap;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.vz.esap.translation.order.service.helper
	 * .OrderServiceHelper#getAuthFeatureType(com.vz.esap.translation.order.model.
	 * request.VOIPOrderRequest)
	 */
	@Override
	public AuthFeatureType getAuthFeatureType(VOIPOrderRequest voipOrderRequest) throws GenericException {
		LOG.info("Entered getAuthFeatureType");

		AuthFeatureType authFeatureType = null;
		List<Feature> nativeTrunkTypeFeatures = null;
		String nativeTrunkFeatures = null;

		try {

			if (Arrays.asList(SolutionType.ESIP_ESL, SolutionType.ESIP_EBL)
					.contains(voipOrderRequest.getOrderHeader().getSolutionType())) {
				authFeatureType = AuthFeatureType.FET_ESIP;

			} else if (Arrays.asList(SolutionType.HPBX).contains(voipOrderRequest.getOrderHeader().getSolutionType())) {
				authFeatureType = AuthFeatureType.FET_HPBX;

			} else {
				if (voipOrderRequest.getConvergedService() != null
						&& voipOrderRequest.getConvergedService().getFeature() != null) {
					nativeTrunkTypeFeatures = stream(voipOrderRequest.getConvergedService().getFeature())
							.filter(trunkFeature -> trunkFeature.getCode().equalsIgnoreCase("FET_PRILIN")
									|| trunkFeature.getCode().equalsIgnoreCase("FET_XO_TRULIN")
									|| trunkFeature.getCode().equalsIgnoreCase("FET_LIN")
									|| trunkFeature.getCode().equalsIgnoreCase("FET_PRI")
									|| trunkFeature.getCode().equalsIgnoreCase("FET_XO_TRUON"))
							.collect(Collectors.toList());

					if (!CollectionUtils.isEmpty(nativeTrunkTypeFeatures))
						nativeTrunkFeatures = nativeTrunkTypeFeatures.get(0).getCode();
					else
						nativeTrunkFeatures = "NONE";

					if (Arrays.asList("FET_PRI", "FET_XO_TRUON").contains(nativeTrunkFeatures)) {
						authFeatureType = AuthFeatureType.FET_DID;
					} else if (Arrays.asList("FET_LIN").contains(nativeTrunkFeatures)) {
						authFeatureType = AuthFeatureType.FET_LINE;
					} else if (Arrays.asList("FET_PRILIN", "FET_XO_TRULIN").contains(nativeTrunkFeatures)) {
						authFeatureType = AuthFeatureType.FET_DID_LINE;
					}
				}
			}
		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new GenericException(GenericException.GENERIC_EXCEPTION, "Exception occured in getAuthFeatureType");
		}

		LOG.info("Exit getAuthFeatureType");
		return authFeatureType;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.vz.esap.translation.order.service.helper.OrderServiceHelper#
	 * getEnterpriseFromEsl(java.lang.String)
	 */
	@Override
	public Map<String, String> getEnterpriseFromEsl(String eslId)
			throws ApplicationInterfaceException, GenericException {

		LOG.info("Entered getEnterpriseFromEsl");
		DBServiceResponse dbServiceResponse = null;
		Set<String> selectColumnSet = null;
		List<String[]> whereClauseList = null;
		Map<String, String> resultMap = null;

		try {
			resultMap = new HashMap<>();

			selectColumnSet = new HashSet<>();
			selectColumnSet.add("ENTERPRISE_ID");
			selectColumnSet.add("LOCATION_ID");
			selectColumnSet.add("SIP_DOMAIN");

			whereClauseList = new ArrayList<>();
			whereClauseList.add(new String[] { "LOCATION_ID", eslId });

			dbServiceResponse = inventoryDomainDataServiceImpl.searchInventory("TBL_LOCATION", selectColumnSet,
					whereClauseList);

			for (TblRow tblRows : dbServiceResponse.getTableRows()) {
				if (tblRows.getTblRow().get("ENTERPRISE_ID").getValue() != null)
					resultMap.put("ENTERPRISE_ID", tblRows.getTblRow().get("ENTERPRISE_ID").getValue());
				if (tblRows.getTblRow().get("SIP_DOMAIN").getValue() != null)
					resultMap.put("SIP_DOMAIN", tblRows.getTblRow().get("SIP_DOMAIN").getValue());
			}

		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new GenericException(GenericException.GENERIC_EXCEPTION,
					"Exception occured in getEnterpriseInformationFromEsl");
		}

		LOG.info("Exit getEnterpriseFromEsl");
		return resultMap;

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.vz.esap.translation.order.service.helper.OrderServiceHelper#
	 * handlePreviousOrder(com.vz.esap.translation.order.model.request.
	 * VOIPOrderRequest, java.lang.Object, java.lang.Long)
	 */
	@Override
	public <T> void handlePreviousOrder(VOIPOrderRequest voipOrderRequestCurrent, T orderEntity, Long currentEnvOrderId)
			throws GenericException {

		LOG.info("Entered handlePreviousOrder");
		LOG.info("currentEnvOrderId::{}", currentEnvOrderId);

		List<TblEnvOrder> tblEnvOrderListPrev = null;
		List<TblOrder> tblOrderListPrev = null;
		List<TblOrder> tblOrderListMoved = null;
		boolean isMatchOrderFound = false;

		try {

			tblOrderListMoved = new ArrayList<>();

			int orderVersion = Integer.parseInt(voipOrderRequestCurrent.getOrderHeader().getWorkOrderVersion());

			VOIPOrderRequest voipOrderRequestPrev = orderParserImpl.getCorrectPrevPassVoipOrderRequest(voipOrderRequestCurrent);

			//voipOrderRequestPrev.getOrderHeader().setWorkOrderVersion(Integer.toString(orderVersion - 1));
			tblEnvOrderListPrev = getMatchingPrevPassEnvOrder(voipOrderRequestPrev, 0, 0);
			tblOrderListPrev = getMatchingPrevPassOrder(tblEnvOrderListPrev.get(0), null);

			// Cancelling Previous Env Order
			voipOrderDao.updateTblEnvOrderStatus(tblEnvOrderListPrev.get(0).getEnvOrderId(),
					WorkOrderEnum.Status.WO_CANCELLED);

			for (TblOrder prevTblOrder : tblOrderListPrev) {

				LOG.info("prevTblOrder Id :{}, prevTblOrder.getApptypeId(): {}, prevTblOrder.getOrderStatus(): {}",
						prevTblOrder.getOrderId(), prevTblOrder.getApptypeId(), prevTblOrder.getOrderStatus());

				if (prevTblOrder.getApptypeId() == OrderRequestType.INDEPENDENT_INTERNAL_ORDER.ordinal()) {
					if (prevTblOrder.getOrderStatus() != WorkOrderEnum.Status.WO_COMPLETE) {
						LOG.info("Inside INDEPENDENT_INTERNAL_ORDER For WO_COMPLETE");

						voipOrderDao.moveTblOrder(currentEnvOrderId, prevTblOrder.getOrderId());

						tblOrderListMoved.add(prevTblOrder);
					}
				} else if (prevTblOrder.getApsState() == WorkOrderEnum.OrderRequestType.INTERNAL_ORDER
						&& voipOrderRequestPrev.getOrderHeader().getOrderType() == OrderType.getValueReverse("CHANGE")
						&& "IASA".equals(voipOrderRequestPrev.getOrderHeader().getOrigin())
						&& prevTblOrder.getUpstreamTaskId() == OrderEntity.DEVICE.ordinal()) {

					if (prevTblOrder.getOrderStatus() != WorkOrderEnum.Status.WO_COMPLETE) {
						LOG.info("Inside INTERNAL_ORDER, DEVICE For WO_COMPLETE");
						// tblOrderListMoved.add(prevTblOrder); Do Move Order
						voipOrderDao.moveTblOrder(currentEnvOrderId, prevTblOrder.getOrderId());
						tblOrderListMoved.add(prevTblOrder);
					}
				} else if (prevTblOrder.getFlowPath().equals("R")) {
					if (prevTblOrder.getOrderStatus() != WorkOrderEnum.Status.WO_COMPLETE) {
						LOG.info("Inside FlowPath=R For WO_COMPLETE");
						// tblOrderListMoved.add(prevTblOrder); Do Move Order
						voipOrderDao.moveTblOrder(currentEnvOrderId, prevTblOrder.getOrderId());
						tblOrderListMoved.add(prevTblOrder);
					}
				} else if (prevTblOrder.getUpstreamTaskId() == OrderEntity.KEY.ordinal()
						&& prevTblOrder.getApsState() == WorkOrderEnum.OrderRequestType.INTERNAL_ORDER
						&& prevTblOrder.getOrderType().equals("C")) {
					if (prevTblOrder.getOrderStatus() != WorkOrderEnum.Status.WO_COMPLETE
							&& prevTblOrder.getOrderStatus() != WorkOrderEnum.Status.WO_CANCELLED) {
						LOG.info("Inside KEY For Not in WO_COMPLETE , WO_CANCELLED");
						// tblOrderListMoved.add(prevTblOrder); Do Move Order
						voipOrderDao.moveTblOrder(currentEnvOrderId, prevTblOrder.getOrderId());
						tblOrderListMoved.add(prevTblOrder);
					} // Commented as not required
				} /*
					 * else if (prevTblOrder.getUpstreamTaskId() ==
					 * OrderEntity.SYSTEM_UPDATE.ordinal()) { LOG.info("Inside SYSTEM_UPDATE");
					 * 
					 * List<TblOrderDetails> tblOrderDetailsList = voipOrderDao
					 * .getOrderDetailParam(prevTblOrder.getOrderId());
					 * 
					 * if (tblOrderDetailsList.isEmpty()) {
					 * voipOrderDao.updateTblOrderStatus(prevTblOrder.getOrderId(),
					 * WorkOrderEnum.Status.WO_REPLACED); } }
					 */

				isMatchOrderFound = handlePrevOrderNotInCurrentOrder(prevTblOrder, currentEnvOrderId);

				if (!isMatchOrderFound) {
					// :Cancelling Previous order
					voipOrderDao.updateTblOrderStatus(prevTblOrder.getOrderId(), WorkOrderEnum.Status.WO_CANCELLED);
					// :Cancelling Previous order Service
					// Fix this for Drop Scenario
					// voipOrderDao.updateOrderServiceStatus(prevTblOrder.getOrderId(), 0,
					// WorkOrderEnum.Status.WO_CANCELLED);
				}
			}
			voipOrderRequestCurrent.getOrderHeader().setWorkOrderVersion(Integer.toString(orderVersion));
		} catch (Exception e) {
			LOG.error("Exception occured - handleSupplementOrder {} ", e);
			throw new GenericException(GenericException.GENERIC_EXCEPTION,
					"Exception occured in handleSupplementOrder");
		}
		LOG.info("WOV in handlePreviousOrder::" + voipOrderRequestCurrent.getOrderHeader().getWorkOrderVersion());
		LOG.info("Exit handlePreviousOrder");
	}

	/**
	 * @param prevTblOrder
	 * @param currentEnvOrderId
	 * @return isMatchFound
	 * @throws GenericException
	 */
	boolean handlePrevOrderNotInCurrentOrder(TblOrder prevTblOrder, long currentEnvOrderId) throws GenericException {

		LOG.info("Entered handlePrevOrderNotInCurrentOrder for Previous Order = {} , And Previous Order Task Id = {}",
				prevTblOrder.getOrderId(), prevTblOrder.getUpstreamTaskId());

		TblEnvOrder tblEnvOrder = null;
		List<TblOrder> tblOrderListCurrent = null;
		boolean isMatchFound = false;
		TblOrder tblOrderMatchFound = null;
		boolean isRevCurrTnOrderPresent = false;

		try {

			tblEnvOrder = new TblEnvOrder();
			tblEnvOrder.setEnvOrderId(currentEnvOrderId);
			tblOrderListCurrent = voipOrderDao.getTblOrder(tblEnvOrder);

			InternalOrderStatus internalStatus = getOrderCompletionStatus(prevTblOrder);
			LOG.info("internalStatus of Previous Order = {}", internalStatus);

			for (TblOrder tblOrder : tblOrderListCurrent) {
				LOG.info("Tbl_Order_id = {} ,UpstreamTaskId={}", tblOrder.getOrderId(), tblOrder.getUpstreamTaskId());

				// Start :Fix for TN Remove SUPP issue

				/*
				 * if ((tblOrder.getUpstreamTaskId() == 67 || tblOrder.getUpstreamTaskId() == 68
				 * || tblOrder.getUpstreamTaskId() == 71 || tblOrder.getUpstreamTaskId() == 72)
				 * && "R".equalsIgnoreCase(tblOrder.getFlowPath())) {
				 * 
				 * isRevCurrTnOrderPresent = true;
				 * 
				 * LOG.info("isRevCurrTnOrderPresent --> {}", isRevCurrTnOrderPresent);
				 * 
				 * }
				 * 
				 */

				// End :Fix for TN Remove SUPP issue

				if (tblOrder.getUpstreamTaskId() == prevTblOrder.getUpstreamTaskId()
						&& tblOrder.getAccountNumber().equalsIgnoreCase(prevTblOrder.getAccountNumber())) {
					LOG.info("Matching Order Found");
					isMatchFound = true;
					tblOrderMatchFound = tblOrder;
					break;
				}

				// Match Not found for this previous Order
				// This Entity is not Current order and hence Prev Order needs to be
				// cancelled. And a reverse Order needs to be prepared
				LOG.info("tblOrder.getUpstreamTaskId() = {}, prevTblOrder.getUpstreamTaskId() = {}",
						tblOrder.getUpstreamTaskId(), prevTblOrder.getUpstreamTaskId());
			}

			if (isMatchFound) {
				// This is cancel of previous Orders for RollbackReason.NO_CHANGE
				LOG.info("This is cancel of previous Orders for RollbackReason.NO_CHANGE");
				cancelOrder(prevTblOrder, internalStatus, RollbackReason.NO_CHANGE, null, null, true,
						tblOrderMatchFound, currentEnvOrderId);
			} else {

				// Start :Fix for TN Remove SUPP issue

				// Copy exsting for SUpp scenario
				if (prevTblOrder.getUpstreamTaskId() == 23L && !hasNewTnOrder(currentEnvOrderId, FlowPath.F.toString())
						&& !hasNewTnOrder(currentEnvOrderId, FlowPath.R.toString())
						&& !prevTblOrder.getFlowPath().equalsIgnoreCase(FlowPath.R.toString())) {

					voipOrderDao.moveTblOrder(currentEnvOrderId, prevTblOrder.getOrderId());

					isMatchFound = true;

				} else if (prevTblOrder.getUpstreamTaskId() != 1 && !prevTblOrder.getFlowPath().equalsIgnoreCase(FlowPath.R.toString())) {
					LOG.info("This is cancel of previous Orders for RollbackReason.ENTITY_DROPPED");
					cancelOrder(prevTblOrder, internalStatus, RollbackReason.ENTITY_DROPPED, null, null, false,
							tblOrderMatchFound, currentEnvOrderId);

				}

				/*
				 * if (isRevCurrTnOrderPresent) { // This is cancel of previous Orders LOG.
				 * info("This is cancel of previous Orders for RollbackReason.ENTITY_DROPPED");
				 * cancelOrder(prevTblOrder, internalStatus, RollbackReason.ENTITY_DROPPED,
				 * null, null, false, tblOrderMatchFound, currentEnvOrderId);
				 * 
				 * } else { // Do Nothing . This is the scenario where the Supp and change is
				 * only add TN }
				 */

				// End :Fix for TN Remove SUPP issue
			}
		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new GenericException(GenericException.GENERIC_EXCEPTION,
					"Exception occured in handlePrevOrderNotInCurrentOrder");
		}

		LOG.info("Exit handlePrevOrderNotInCurrentOrder");

		return isMatchFound;
	}

	/**
	 * @param prevOrder
	 * @param status
	 * @param reason
	 * @param localOrderMatch
	 * @param forwardOrder
	 * @param hasChanged
	 * @param currentOrder
	 * @param currentEnvOrderId
	 *            TODO
	 * @throws GenericException
	 * @throws TranslatorException
	 */
	public void cancelOrder(TblOrder prevOrder, InternalOrderStatus status, RollbackReason reason,
			TblOrder localOrderMatch, Order forwardOrder, boolean hasChanged, TblOrder currentOrder,
			long currentEnvOrderId) throws TranslatorException, GenericException {

		LOG.info(
				"Entered cancelOrder with currentOrderId = {} , prevOrderId = {} , "
						+ "currentEnvOrderId = {} , Previous Order Status = {} , RollBack Reason = {}",
				currentOrder, prevOrder, currentEnvOrderId, status, reason);

		List<TblOrder> currentOrderList = null;
		TblEnvOrder currentEnvOrder = null;

		if (currentOrder != null) {
			currentOrderList = voipOrderDao.getTblOrder(currentOrder);
			if (currentOrderList != null && currentOrderList.get(0) != null) {
				currentEnvOrder = customTblEnvOrderMapper.selectByPrimaryKey(currentOrderList.get(0).getEnvOrderId());
			}
		} else {
			currentEnvOrder = customTblEnvOrderMapper.selectByPrimaryKey(currentEnvOrderId);
		}

		TblEnvOrder prevEnvOrder = null;
		if (prevOrder != null) {

			prevEnvOrder = customTblEnvOrderMapper.selectByPrimaryKey(prevOrder.getEnvOrderId());
		} else {
			throw new TranslatorException(ErrorCode.TBL_ORDER_RECORD_NOT_FOUND, "Previous Order Can not be null");
		}

		if (reason.equals(RollbackReason.NO_CHANGE) && !hasChanged) {

			LOG.info("Inside :::::: reason.equals(RollbackReason.NO_CHANGE) && !hasChanged");

			if (prevOrder.getOrderStatus() == WorkOrderEnum.Status.WO_REVERSED) {
				LOG.info("Order has been already reversed, ignore and go to next prev.");
			} else if (status.equals(InternalOrderStatus.PENDING) && !prevOrder.getFlowPath().equals("D")) {

				voipOrderDao.updateTblOrderStatus(prevOrder.getOrderId(), WorkOrderEnum.Status.WO_CANCELLED);

			} else if (status.equals(InternalOrderStatus.PARTIALLY_COMPLETE) || prevOrder.getFlowPath().equals("D")) {
				// TODO Need to implement this
			} else if (status.equals(InternalOrderStatus.COMPLETE) || prevOrder.getFlowPath().equals("D")) {
				// TODO Need to implement this
			}
		} else if (!reason.equals(RollbackReason.NO_CHANGE) && !hasChanged) {

			LOG.info("Inside :::::: !reason.equals(RollbackReason.NO_CHANGE) && !hasChanged");

			if (status.equals(InternalOrderStatus.PENDING) && !prevOrder.getFlowPath().equals("D")) {

				voipOrderDao.updateTblOrderStatus(prevOrder.getOrderId(), WorkOrderEnum.Status.WO_CANCELLED);

			} else if (status.equals(InternalOrderStatus.PARTIALLY_COMPLETE)
					|| status.equals(InternalOrderStatus.COMPLETE) || prevOrder.getFlowPath().equals("D")) {

				if (currentEnvOrder == null)
					throw new TranslatorException(ErrorCode.TBL_ORDER_RECORD_NOT_FOUND,
							"Current Env Order Can not be null");

				OrderHeader orderHeader = new OrderHeader();
				orderHeader.setWorkOrderNumber(currentEnvOrder.getOrderNumber());
				orderHeader.setSuppType(null);

				VOIPOrderRequest voipOrderRequest = new VOIPOrderRequest();
				voipOrderRequest.setOrderHeader(orderHeader);

				cancelOrderServiceImpl.createReverseOrder(voipOrderRequest,
						Arrays.asList(prevOrder), currentEnvOrder);

			}
		} else if (reason.equals(RollbackReason.NO_CHANGE) && hasChanged) {
			LOG.info("Inside :::::: reason.equals(RollbackReason.NO_CHANGE) && hasChanged");

			// :Cancelling Previous order
			voipOrderDao.updateTblOrderStatus(prevOrder.getOrderId(), WorkOrderEnum.Status.WO_CANCELLED);
			// :Cancelling Previous order Service
			// Fix this for Drop Scenario
			// voipOrderDao.updateOrderServiceStatus(prevTblOrder.getOrderId(), 0,
			// WorkOrderEnum.Status.WO_CANCELLED);

		}
		LOG.info("Exit cancelOrder");
	}

	/**
	 * @param prevOrder
	 * @return status
	 */
	public InternalOrderStatus getOrderCompletionStatus(TblOrder prevOrder) {
		LOG.info("Entered getOrderCompletionStatus got Previous Order Id = {} and Status = {}", prevOrder.getOrderId(),
				prevOrder.getOrderStatus());
		InternalOrderStatus status = null;

		try {
			if (prevOrder.getOrderStatus() == WorkOrderEnum.Status.WO_INIT
					|| prevOrder.getOrderStatus() == WorkOrderEnum.Status.WO_REPLACED
					|| prevOrder.getOrderStatus() == WorkOrderEnum.Status.WO_REVERSED
					|| prevOrder.getOrderStatus() == WorkOrderEnum.Status.WO_CANCELLED
					|| prevOrder.getOrderStatus() == WorkOrderEnum.Status.WO_ABORT)
				status = InternalOrderStatus.PENDING;
			else if (prevOrder.getOrderStatus() == WorkOrderEnum.Status.WO_COMPLETE)
				status = InternalOrderStatus.COMPLETE;
			else {
				if (isOrderPartiallyComplete(prevOrder))
					status = InternalOrderStatus.PARTIALLY_COMPLETE;
				else
					status = InternalOrderStatus.PENDING;
			}

		} catch (Exception e) {
			LOG.error("Exception Occured -" + e.getMessage());
		}
		LOG.info("Exit getOrderCompletionStatus with InternalOrder Status = {}", status);
		return status;
	}

	public boolean isOrderPartiallyComplete(TblOrder prevOrder) {

		// SELECT
		// ORDER_ID,SEQ_NO,SERVICE,SERVICE_STATUS,CLLI,INITIAL_FLAG,AQM_WORK_ID,SKIP_FLAG
		// FROM TBL_ORDER_SERVICE where Order_id = prevOrderId
		// in VoipOrderDAO via custom mybetis mapper. New method name in VoipOrderDAO-
		// getOrderServiceList(..) and call this method below instead of null

		List<TblOrderService> svcList = voipOrderDao.getOrderServiceList(prevOrder);

		for (TblOrderService svc : svcList) {
			// Skip skipped or to be skipped services
			if (svc.getSkipFlag() == 1)
				continue;
			return isServicePartiallyComplete(svc);
		}
		return false;
	}

	/**
	 * @param svc
	 * @return boolean
	 */
	public boolean isServicePartiallyComplete(TblOrderService svc) {

		// We are just looking at first service
		// No aqmWorkId, nothing done on that service
		if (svc.getServiceStatus() == WorkOrderEnum.Status.WO_INIT
				|| svc.getServiceStatus() == WorkOrderEnum.Status.WO_RELEASED || svc.getAqmWorkId() <= 0)
			return false;

		// Service completed, so some work done.
		if (svc.getServiceStatus() == WorkOrderEnum.Status.WO_COMPLETE)
			return true;

		// Return TRUE for ESAP AUTO TASK SERVICE ALWAYS
		if (svc.getService() != null && "VZB_ESAP_AUTO_TASK".equals(svc.getService())) {
			return true;
		}

		// If there is pendingWoTask or if AqmTaskId is null
		// no task has been started for the service.
		// service/order may be in released status
		TblPendingWoTaskDbBean pendingWoTask = getPendingWoTask(svc.getOrderId(), svc.getService());
		if (pendingWoTask == null || pendingWoTask.getAqmTaskId() <= 0)
			return false;

		// Now check if the failed PendingWoTask is the first executed task of
		// the service
		if (isFirstExecutedTask(svc.getAqmWorkId(), pendingWoTask.getAqmTaskId())) {
			if (isTaskAtomic(svc.getService(), svc.getAqmWorkId(), pendingWoTask.getAqmTaskId()))
				return false;
			else
				return true;
		} else
			return true;

	}

	/**
	 * @param orderId
	 * @param service
	 * @return tblPendingWoTaskDbBean
	 */
	public TblPendingWoTaskDbBean getPendingWoTask(long orderId, String service) {

		// SELECT
		// ORDER_ID,APPTYPE_ID,PRIORITY,RECVD_DATE,PENDING_WO_TYPE,BASE_CLLI,SERVICE,
		// SEQ_NO,DEVICE,WF_STATUS,AQM_TASK_ID,AQM_TASK_OUTPUT,AQM_TASK_OUTPUT_OPTIONAL,
		// AQM_TASK_COMPLETION_STATUS,ORDER_STATUS,CONNECTION_TYPE,PREVIOUS_TASK_ID,
		// ESAP_CLUSTER FROM TBL_PENDING_WO_TASK where Order_id = prevOrderId and
		// Service = service
		// in VoipOrderDAO via custom mybetis mapper. New method name in VoipOrderDAO-
		// getPendingWoTaskList(..) and call this method below instead of null
		// When Mybetis will generate TblPendingWoTask then delete
		// TblPendingWoTaskDbBean and
		// refactor and remane TblPendingWoTaskDbBean with the mybetis generated model
		// class.

		TblPendingWoTaskDbBean tblPendingWoTaskDbBean = null;

		return tblPendingWoTaskDbBean;
	}

	/**
	 * @param aqmWorkId
	 * @param aqmTaskId
	 * @return firstTask
	 */
	public boolean isFirstExecutedTask(long aqmWorkId, long aqmTaskId) {

		// SELECT
		// TASK_ID,QUEUE_ID,WORKSTEP_ID,WORK_ID,OUTPUT,START_DATE,DATE_ENDED,DUE_DATE,ORIG_DUE_DATE,
		// READY_STATUS,LOCK_STATUS,LOCK_OWNER_ID,ENABLE_STATUS,NO_DEPENDENTS,OUTPUT_OPTIONAL,
		// MOVED_FROM_Q_ID,COMPLETION_STATUS,ACCEPT_STATUS,OPTIONAL_STATUS,EST_COMP_DATE,
		// COMPLETED_BY,NO_DEPS_TAKEN,REQUIRED_STATUS,ROLLBACK,COMPLETION_IND,SEQUENCE_ID
		// ,PARENT_TASK_ID,TIMEOUT_COUNT,REPEAT_COUNT,NESTED_TEMPLATE_ID,INSTANCE_NUMBER,
		// DURATION,MANUAL_TASK_STATUS FROM AQM_TASK where Work_Id=? and
		// Order by sequence_id
		// in VoipOrderDAO via custom mybetis mapper. New method name in VoipOrderDAO-
		// getAqmTaskList(..) and call this method below instead of null
		// When Mybetis will generate TblPendingWoTask then delete
		// TblPendingWoTaskDbBean and
		// refactor and remane TblPendingWoTaskDbBean with the mybetis generated model
		// class.

		boolean firstTask = false;

		/*
		 * for (AqmTaskDbBean aqmTask : (ArrayList<AqmTaskDbBean>) taskQ
		 * .getResultArrayList()) { // Skipped task if (aqmTask.getStartDate() == 0 ||
		 * aqmTask.getRequiredStatus() == 1) continue;
		 * 
		 * if (aqmTask.getTaskId() == aqmTaskId) { firstTask = true; }
		 * 
		 * break; }
		 */

		return firstTask;
	}

	/**
	 * @param service
	 * @param aqmWorkId
	 * @param aqmTaskId
	 * @return atomicTask
	 */
	public boolean isTaskAtomic(String service, long aqmWorkId, long aqmTaskId) {

		boolean atomicTask = false;

		// TODO: 10/15 : Implement below
		// SELECT atomic_task FROM tbl_service_task st, aqm_task at, aqm_workstep aw
		// WHERE at.workstep_id = aw.workstep_id AND aw.name = st.task
		// AND at.task_id = ?
		// AND st.service = ?

		return atomicTask;
	}

	/**
	 * @param orderServiceBase
	 * @param voipOrderRequest
	 * @param responseClass
	 * @return T
	 */
	public <T> T getOldEntity(VOIPOrderRequest voipOrderRequest, Class<T> responseClass) {

		LOG.info("Entered getOldEntity");

		List<TblEnvOrder> tblEnvOrderListPrev = null;

		String responseClassType = null;
		T response = null;
		VOIPOrderRequest voipOrderRequestPrev = null;

		try {

			HashSet<String> supportedType = new HashSet<>();
			supportedType.add(TranslationConstant.CUSTOMER_ENTITY_CLASS);
			supportedType.add(TranslationConstant.LOCATION_ENTITY_CLASS);

			// responseClassType = responseClass.getSimpleName().toUpperCase(); commented,
			// in switch case it won't match.
			responseClassType = responseClass.getSimpleName();

			if (!supportedType.contains(responseClassType))
				throw new ApplicationInterfaceException("Unsupported dataype");

			int orderVersion = Integer.parseInt(voipOrderRequest.getOrderHeader().getWorkOrderVersion());
			OrderServiceBase.LOG.info("Order version:: {}", orderVersion);

			if (orderVersion > 0) {

				voipOrderRequestPrev = orderParserImpl.getCorrectPrevPassVoipOrderRequest(voipOrderRequest);;
				//voipOrderRequestPrev.getOrderHeader().setWorkOrderVersion(Integer.toString(orderVersion - 1));

				tblEnvOrderListPrev = getMatchingPrevPassEnvOrder(voipOrderRequestPrev, 0, OrderClassify.RELEASE);

				switch (responseClassType) {
				case TranslationConstant.LOCATION_ENTITY_CLASS:

					response = getOldEntity(tblEnvOrderListPrev.get(0), responseClass);

					break;

				default:
					break;
				}
			}

		} catch (Exception e) {
			LOG.error("Exception Info -" + e);
		}

		LOG.info("Exit getOldEntity");
		return response;
	}

	/**
	 * @param tblEnvOrder
	 * @param responseClass
	 * @return T
	 */
	@SuppressWarnings("unchecked")
	public <T> T getOldEntity(TblEnvOrder tblEnvOrder, Class<T> responseClass) {

		LOG.info("Entered getOldEntity");

		LocationEntity locationEntity = null;
		// List<TblEnvOrder> tblEnvOrderListPrev = null;
		List<TblOrder> tblOrderListPrev = null;
		List<TblOrderDetails> tblOrderDetailsListPrev = null;
		LocationEntity locationEntityPrev = null;
		String responseClassType = null;
		T response = null;

		try {

			HashSet<String> supportedType = new HashSet<>();
			supportedType.add(TranslationConstant.CUSTOMER_ENTITY_CLASS);
			supportedType.add(TranslationConstant.LOCATION_ENTITY_CLASS);

			// responseClassType = responseClass.getSimpleName().toUpperCase(); commented,
			// in switch case it won't match.
			responseClassType = responseClass.getSimpleName();
			if (!supportedType.contains(responseClassType))
				throw new ApplicationInterfaceException("Unsupported dataype");

			switch (responseClassType) {
			case TranslationConstant.LOCATION_ENTITY_CLASS:

				tblOrderListPrev = getMatchingPrevPassOrder(tblEnvOrder, OrderEntity.LOCATION);

				if (tblOrderListPrev.isEmpty()) {
					return response;
				}

				locationEntity = new LocationEntity(); // initialized this code as it is not initialized .
				for (TblOrder tblOrderPrev : tblOrderListPrev) {

					if (tblOrderPrev.getAccountNumber().equalsIgnoreCase(locationEntity.getLocationId())) {

						tblOrderDetailsListPrev = getMatchingOrderDetails(tblOrderPrev);
						LOG.info("TBL_ORDER_DETAILS records size::{}", tblOrderDetailsListPrev.size());
					}
				}

				if (tblOrderDetailsListPrev != null && tblOrderDetailsListPrev.isEmpty()) {
					return response;
				}

				if (tblOrderDetailsListPrev != null
						&& "Location".equalsIgnoreCase(tblOrderDetailsListPrev.get(0).getParamName())) {

					locationEntityPrev = locationTransformerImpl.transformOrderDetailsToLocation(
							tblOrderListPrev.get(0).getOrderId(), tblOrderDetailsListPrev.get(0).getOrderDetailId(),
							"n", false, null);

					// Commented below as this tblEnvOrderListPrev is not populate.
					/*
					 * if(tblEnvOrderListPrev != null) {
					 * locationEntityPrev.setEnvOrderId(tblEnvOrderListPrev.get(0).getEnvOrderId());
					 * }
					 */
					response = (T) locationEntityPrev;
				}
				break;

			default:
				break;
			}

		} catch (Exception e) {
			LOG.error("Exception Info -" + e);
		}

		LOG.info("Exit getOldEntity");
		return response;
	}

	@Override
	public <T> T getEntityDetailsFromInventory(String primaryId, Class<T> entityClass)
			throws TranslatorException, GenericException {
		LOG.info("Entered getEntityDetailsFromInventory for Entity Class = {}", entityClass);

		HashSet<String> supportedType = new HashSet<>();
		supportedType.add(TranslationConstant.LOCATION_ENTITY);
		supportedType.add(TranslationConstant.DEVICE_ENTITY);
		supportedType.add(TranslationConstant.TRUNK_GROUP_ENTITY);
		supportedType.add(TranslationConstant.ENTERPRISE_TRUNK_ENTITY);
		supportedType.add(TranslationConstant.NBS_ENTTY);
		supportedType.add(TranslationConstant.CUSTOMER_ENTITY);
		supportedType.add(TranslationConstant.GROUP_TN_ENTITY);
		supportedType.add(TranslationConstant.TN_ENTITY);

		String entityType = entityClass.getSimpleName().toUpperCase();
		TNEntity tnEntity = null;

		if (!supportedType.contains(entityType))
			throw new TranslatorException(ErrorCode.UNSUPPORTED_TABLE_TYPE, "Unsupported Table Type");

		T response = null;
		Map<String, String> resultantRow = null;

		switch (entityType) {
		case TranslationConstant.LOCATION_ENTITY:
			resultantRow = inventoryUtil.getTblLocationFromLocationId(primaryId, resultantRow, null);
			LocationEntity locationEntityInv = locationTransformerImpl
					.locationInventoryToLocationEntityTransformer(resultantRow);
			LOG.info("In Helper locationEntityInv.getGroupUserLimit() ---> : {} ",
					locationEntityInv.getGroupUserLimit());
			response = (T) locationEntityInv;
			break;
		case TranslationConstant.DEVICE_ENTITY:
			resultantRow = inventoryUtil.getTblDeviceFromDeviceId(primaryId, resultantRow, null);
			DeviceEntity deviceEntityInv = deviceTransformer.deviceInventoryToDeviceEntityTransformer(resultantRow);
			response = (T) deviceEntityInv;
			break;
		case TranslationConstant.TRUNK_GROUP_ENTITY:
			resultantRow = inventoryUtil.getTblGroupFromGroupId(primaryId, resultantRow, null);
			TrunkGroupEntity trunkGroupEntity = trunkGroupTransformer
					.trunkGroupInventoryTotrunkGroupEntityTransformer(resultantRow);
			response = (T) trunkGroupEntity;
			break;
		case TranslationConstant.ENTERPRISE_TRUNK_ENTITY:
			resultantRow = inventoryUtil.gettblESIPENTERPRISETRUNKFromEnterpriseTrunkId(primaryId, resultantRow, null);
			EnterpriseTrunkEntity enterpriseTrunkEntity = enterpriseTrunkTransformer
					.enterpriseTrunkInventoryToEnterpriseTrunkEntityTransformer(resultantRow);
			response = (T) enterpriseTrunkEntity;
			break;
		case TranslationConstant.NBS_ENTTY:
			resultantRow = inventoryUtil.gettblNbsInfofromClusterId(primaryId, resultantRow, null);
			NbsEntity nbsEntity = nbsTransformer.nbsEntityInventoryToNbsEntityTransformer(resultantRow);
			response = (T) nbsEntity;
			break;
		case TranslationConstant.CUSTOMER_ENTITY:
			resultantRow = inventoryUtil.getTblEnterpriseFromEnterpriseId(primaryId, resultantRow, null);
			CustomerEntity customerEntity = customerTransformer
					.customerEntityInventoryTocustomerEntityTransformer(resultantRow);
			response = (T) customerEntity;
			break;
		case TranslationConstant.GROUP_TN_ENTITY:
			GroupTNEntity groupTNEntity = null;
			tnEntity = getEntityDetailsFromInventory(primaryId, TNEntity.class); // passing TN here.

			if (tnEntity != null && tnEntity.getTnPoolId() != null) {
				LOG.info("TnPoolId = {} And TN = {}", tnEntity.getTnPoolId(), tnEntity.getTn());

				resultantRow = inventoryUtil.getTblGroupTnFromGroupTnId(tnEntity.getTnPoolId().toString(), resultantRow,
						null);
				groupTNEntity = groupTnTransformer.groupTnEntityInventoryTogroupTnEntityTransformer(resultantRow);
				groupTNEntity.setTnRecord(tnEntity);

				LOG.info("GroupTnId-{}", groupTNEntity.getGroupTNId());
			}
			response = (T) groupTNEntity;
			break;
		case TranslationConstant.TN_ENTITY:
			resultantRow = inventoryUtil.getTblTnFromTnPoolId(primaryId, resultantRow, null);
			resultantRow = inventoryUtil.getTnAssignmentFromTn(primaryId, resultantRow);
			tnEntity = groupTnTransformer.tnEntityInventoryToTnEntityTransformer(resultantRow);
			response = (T) tnEntity;
			break;
		default:
			break;
		}

		LOG.info("Exit getEntityDetailsFromInventory");

		return response;
	}

	// Implement this logic --> copy from currentEntity.abc to resultEntity.abc if
	// and only if resultEntity.abc != null or empty
	/*
	 * @Override public <T> T copyEntity(T currentEntity, T resultEntity, Class<T>
	 * entityClass) throws ApplicationInterfaceException, IllegalAccessException,
	 * TranslatorException {
	 * 
	 * try {
	 * 
	 * HashSet<String> supportedType = new HashSet<>();
	 * supportedType.add(TranslationConstant.CUSTOMER_ENTITY);
	 * supportedType.add(TranslationConstant.LOCATION_ENTITY);
	 * 
	 * String entityType = entityClass.getSimpleName().toUpperCase();
	 * 
	 * if (!supportedType.contains(entityType)) throw new
	 * TranslatorException(ErrorCode.UNSUPPORTED_TABLE_TYPE,
	 * "Unsupported Table Type");
	 * 
	 * switch (entityType) { case TranslationConstant.CUSTOMER_ENTITY:
	 * 
	 * for (Field field : CustomerEntity.class.getDeclaredFields()) {
	 * LOG.info("Field Name {}:", field.getName()); field.setAccessible(true);
	 * 
	 * if (field.get(currentEntity) != null) { if
	 * ("customerName".equals(field.getName().toString())) {
	 * LOG.info("skip field========== {} ============", field.getName().toString());
	 * continue; } LOG.info(field.get(currentEntity).toString());
	 * field.set(resultEntity, field.get(currentEntity)); } }
	 * 
	 * break;
	 * 
	 * case TranslationConstant.LOCATION_ENTITY: // Calling copyfields method. for
	 * (Field field : LocationEntity.class.getDeclaredFields()) {
	 * LOG.info("Field Name : {} , Field Value : {} +++++", field.getName(),
	 * field.get(currentEntity)); field.setAccessible(true);
	 * 
	 * if (field.get(currentEntity) != null) { if
	 * ("locationEntity".equalsIgnoreCase(field.getName())) {
	 * LOG.info("skip field========== {} ============", field.getName()); continue;
	 * } LOG.info("Not Null Field Value : {}", field.get(currentEntity));
	 * field.set(resultEntity, field.get(currentEntity)); } }
	 * 
	 * break;
	 * 
	 * default: break; }
	 * 
	 * LOG.info("currentEntity = {}", currentEntity); LOG.info("resultEntity = {}",
	 * resultEntity); } catch (IllegalArgumentException e) {
	 * LOG.error("Exception Occured- {}", e.getMessage()); } catch
	 * (IllegalAccessException e) { LOG.error("Exception Occured- {}",
	 * e.getMessage()); } return resultEntity; }
	 */

	@Override
	public void handleSuppOrderWithNoChange(long currentEnvOrderId, long prevOrderId,
			TblEnvOrder currTblEnvOrderObject) {
		LOG.info("Entered handleSuppOrderWithNoChange");
		TblOrder tblOrder = new TblOrder();

		tblOrder.setOrderId(prevOrderId);
		tblOrder.setEnvOrderId(currentEnvOrderId);
		tblOrder.setVersionNo(currTblEnvOrderObject.getVersionNumber().toString());
		customTblOrderMapper.updateByPrimaryKeySelective(tblOrder);

		List<TblOrderDetails> tblOrderDetailList = voipOrderDaoImpl.getOrderDetailsEntriesPerOrder(tblOrder);
		if(null !=  tblOrderDetailList) {
			for(TblOrderDetails tblOrderDetail : tblOrderDetailList) {
				if("OrderVersion".equalsIgnoreCase(tblOrderDetail.getParamName())) {								
					LOG.info("Current TOD Order Version ==>> {}", tblOrderDetail.getParamValue());
					tblOrderDetail.setParamValue(currTblEnvOrderObject.getVersionNumber().toString());
					voipOrderDao.updateTblOrderDetailParamValue(tblOrderDetail);
				}
			}
		}
		
		/*
		 * TblOrderService tblOrderService = new TblOrderService();
		 * TblOrderServiceExample tblOrderServiceExample = new TblOrderServiceExample();
		 * 
		 * tblOrderServiceExample.createCriteria().andOrderIdEqualTo(customerEntityPrev.
		 * getInternalOrderId());
		 * customTblOrderServiceMapper.updateByExample(tblOrderService,
		 * tblOrderServiceExample);
		 */

		LOG.info("Exit handleSuppOrderWithNoChange");
	}

	// HPBX Start
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.vz.esap.translation.order.service.helper.OrderServiceHelper#
	 * createHpbxEnvOrder(com.vz.esap.translation.order.model.request.
	 * VOIPOrderRequest, int)
	 */
	@Override
	public TblEnvOrder createHpbxEnvOrder(VOIPOrderRequest voipOrderRequest, int status)
			throws TranslatorException, GenericException {
		LOG.info("Entered createHpbxEnvOrder");
		TblEnvOrder tblEnvOrderObject = null;
		long count = -1;
		try {
			// create env order
			tblEnvOrderObject = enterpriseEnvelopOrderData.createTblEnvOrderFromVOIPOrderRequest(voipOrderRequest,
					status);
			count = voipOrderDao.createEnvelopOrder(tblEnvOrderObject);
			if (count <= 0) {
				throw new TranslatorException(ErrorCode.ENV_ORDER_CREATION_FAILURE, "Failed to create env Order");
			}

			// create env order details for order manager
			count = createEnvOrderDetailsOrderManagerInfo(tblEnvOrderObject.getEnvOrderId(), voipOrderRequest);
			if (count <= 0) {
				throw new TranslatorException(ErrorCode.ENV_ORDER_DETAILS_CREATION_FAILURE,
						"Failed to create env Order manager");
			}

		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new GenericException(GenericException.GENERIC_EXCEPTION,
					"Exception occured while createHpbxEnvOrder");
		}
		LOG.info("Exit createHpbxEnvOrder");
		return tblEnvOrderObject;
	}

	@Override
	public TblOrder createHpbxOrderHeader(VOIPOrderRequest voipOrderRequest, int status, TblEnvOrder tblEnvOrderObject)
			throws TranslatorException, GenericException {
		LOG.info("Entered createHpbxOrderHeader");
		TblOrder tblOrderObject = null;
		long count = -1;
		try {
			// create order
			tblOrderObject = enterpriseTblOrderData.prepareTblOrderData(voipOrderRequest, tblEnvOrderObject);
			tblOrderObject.setOrderStatus(Long.valueOf(status));

			count = voipOrderDao.createTblOrder(tblOrderObject);
			if (count <= 0) {
				throw new TranslatorException(TranslatorException.ErrorCode.ORDER_CREATION_FAILURE,
						"Failed to create Order");
			}
		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new GenericException(GenericException.GENERIC_EXCEPTION,
					"Exception occured while createHpbxOrderHeader");
		}
		LOG.info("Exit createHpbxOrderHeader");
		return tblOrderObject;
	}

	@Override
	public Long createHpbxOrderDetails(VOIPOrderRequest voipOrderRequest, TblOrder tblOrderObject,
			boolean isNewCustomer) throws TranslatorException, GenericException {

		LOG.info("Entered createHpbxOrderDetails");
		long count = -1;
		ParamInfo headerParamInfo = null;
		List<Feature> features = null;
		List<Specification> specs = null;
		List<ChangedElement> changeElementSpecs = null;

		try {

			headerParamInfo = commonTblOrderDetailsDataTransformerImpl
					.prepareTblOrderDetailsHeaderParamDataForCustomer(voipOrderRequest, tblOrderObject);

			features = stream(voipOrderRequest.getConvergedService().getFeature())
					.filter(feature -> "EFET_VOIP_ENT_LVL".equalsIgnoreCase(feature.getCode()))
					.collect(Collectors.toList());

			if (!features.isEmpty() && !features.get(0).getActionCode().equalsIgnoreCase("NONE")) {
				headerParamInfo = createEnterpriseOrderDetailsParamInfo(voipOrderRequest, tblOrderObject,
						headerParamInfo, false);
			}

			features = stream(voipOrderRequest.getConvergedService().getFeature())
					.filter(feature -> "FET_LOC_LVL".equalsIgnoreCase(feature.getCode())
							|| "FET_HPBX_LOC_LVL".equalsIgnoreCase(feature.getCode())
							|| "FET_HPBX_LOC_LVL_LOC".equalsIgnoreCase(feature.getCode()))
					.collect(Collectors.toList());
			if (!features.isEmpty() && !features.get(0).getActionCode().equalsIgnoreCase("NONE")) {
				headerParamInfo = createLocationOrderDetailsParamInfo(voipOrderRequest, headerParamInfo,
						tblOrderObject);
			}

			features = stream(voipOrderRequest.getConvergedService().getFeature())
					.filter(feature -> "FET_DE".equalsIgnoreCase(feature.getCode())
							|| "FET_DE_LOC".equalsIgnoreCase(feature.getCode()))
					.collect(Collectors.toList());
			if (!features.isEmpty() && !features.get(0).getActionCode().equalsIgnoreCase("NONE")) {
				headerParamInfo = createDeviceOrderDetailsParamInfo(voipOrderRequest, headerParamInfo, tblOrderObject);
			}

			features = stream(voipOrderRequest.getConvergedService().getFeature())
					.filter(feature -> "FET_XO_TRU".equalsIgnoreCase(feature.getCode())
							|| "FET_HPBX_TRU".equalsIgnoreCase(feature.getCode())
							|| "FET_HPBX_TRU_LOC".equalsIgnoreCase(feature.getCode()))
					.collect(Collectors.toList());
			if (!features.isEmpty() && !features.get(0).getActionCode().equalsIgnoreCase("NONE")) {
				headerParamInfo = createTrunkGroupOrderDetailsParamInfo(voipOrderRequest, headerParamInfo,
						tblOrderObject);
			}

			features = stream(voipOrderRequest.getConvergedService().getFeature())
					.filter(feature -> "EFET_VOIP_ENT_TRUNK".equalsIgnoreCase(feature.getCode()))
					.collect(Collectors.toList());
			if (!features.isEmpty() && !features.get(0).getActionCode().equalsIgnoreCase("NONE")) {
				headerParamInfo = createETOrderDetailsParamInfo(voipOrderRequest, headerParamInfo);
			}

			List<Feature> list = stream(voipOrderRequest.getConvergedService().getFeature())
					.filter(feature -> "FET_HPBX_LOC_LVL".equalsIgnoreCase(feature.getCode()))
					.collect(Collectors.toList());

			if (!CollectionUtils.isEmpty(list)) {
				specs = stream(list.get(0).getSpecification())
						.filter(spec -> "SP_XO_TNQ".equalsIgnoreCase(spec.getCode())).collect(Collectors.toList());
			}

			if (voipOrderRequest.getChangeManagement() != null) {
				changeElementSpecs = stream(voipOrderRequest.getChangeManagement()[0].getChangedElement())
						.filter(changeElement -> "FET_LOC_LVL".equalsIgnoreCase(changeElement.getFeatureCode())
								&& "SP_XO_TNQ".equalsIgnoreCase(changeElement.getSpecificationCode()))
						.collect(Collectors.toList());
			}

			if (!CollectionUtils.isEmpty(specs) || !CollectionUtils.isEmpty(changeElementSpecs)) {
				headerParamInfo = createGroupTNOrderDetailsParamInfo(voipOrderRequest, headerParamInfo);
			}

			if ("I".equalsIgnoreCase(voipOrderRequest.getOrderHeader().getOrderType())) {
				voipOrderDao.populateOrderDetails(tblOrderObject, headerParamInfo.getChildParams(), "n", 0, 0);
			} else if ("C".equalsIgnoreCase(voipOrderRequest.getOrderHeader().getOrderType())) {
				voipOrderDao.populateOrderDetails(tblOrderObject, headerParamInfo.getChildParams(), "c", 0, 0);
			}

		} catch (Exception e) {
			LOG.error("Exception {} ", e);
			throw new GenericException(GenericException.GENERIC_EXCEPTION,
					"Exception occured while createHpbxOrderDetails");
		}
		LOG.info("Exit createHpbxOrderDetails");
		return count;
	}

	/**
	 * TODO - Disconn
	 * 
	 * @param voipOrderRequest
	 * @param tblOrderObject
	 * @throws TranslatorException
	 * @throws GenericException
	 */
	@Override
	public void populateEblEsipLocSuspendOrDeactivateOrderDetails(VOIPOrderRequest voipOrderRequest,
			TblOrder tblOrderObject) throws TranslatorException, GenericException {
		LOG.info("Entered populateEblEsipLocSuspendOrDeactivateOrderDetails");
		ParamInfo headerParamInfo = null;
		ParamInfo locationParamInfo = null;
		LocationEntity locationEntityInv = null;
		try {
			headerParamInfo = commonTblOrderDetailsDataTransformerImpl
					.prepareTblOrderDetailsHeaderParamDataForCustomer(voipOrderRequest, tblOrderObject);

			LOG.info("populateEblEsipLocSuspendOrDeactivateOrderDetails::Got headerParamInfo");

			locationEntityInv = getEntityDetailsFromInventory(voipOrderRequest.getOrderHeader().getVoipLocationId(),
					LocationEntity.class);

			locationParamInfo = locationTblOrderDetailsData.prepareTblOrderDetailsEntityParamDataForLocation(
					voipOrderRequest, tblOrderObject, locationEntityInv, null);

			headerParamInfo.addChildParam(locationParamInfo);

			// TODO Disconn Niladri - Check entity for EBL REL_SUSPEND, REL_DEACTIVATE DONE
			voipOrderDao.populateOrderDetails(tblOrderObject, headerParamInfo.getChildParams(), "o", 0, 0);

			LOG.info(
					"populateEblEsipLocSuspendOrDeactivateOrderDetails::Completed voipOrderDao.populateOrderDetails()");

			LOG.info("Leaving populateEblEsipLocSuspendOrDeactivateOrderDetails");
		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new GenericException(GenericException.GENERIC_EXCEPTION,
					"Exception occured in populateEblEsipLocSuspendOrDeactivateOrderDetails");
		}
	}

	/**
	 * TODO - Disconn
	 * 
	 * @param voipOrderRequest
	 * @param tblOrderObject
	 * @throws TranslatorException
	 * @throws GenericException
	 */
	@Override
	public void populateEslEsipLocSuspendOrDeactivateOrderDetails(VOIPOrderRequest voipOrderRequest,
			TblOrder tblOrderObject) throws TranslatorException, GenericException {
		LOG.info("Entered populateEslEsipLocSuspendOrDeactivateOrderDetails");
		ParamInfo headerParamInfo = null;
		ParamInfo locationParamInfo = null;
		LocationEntity locationEntityInv = null;
		try {
			headerParamInfo = commonTblOrderDetailsDataTransformerImpl
					.prepareTblOrderDetailsHeaderParamDataForCustomer(voipOrderRequest, tblOrderObject);

			LOG.info("populateEslEsipLocSuspendOrDeactivateOrderDetails::Got headerParamInfo");

			locationEntityInv = getEntityDetailsFromInventory(voipOrderRequest.getOrderHeader().getVoipLocationId(),
					LocationEntity.class);

			// TODO: Niladri action name-- Done
			locationParamInfo = locationTblOrderDetailsData.prepareTblOrderDetailsEntityParamDataForLocation(
					voipOrderRequest, tblOrderObject, locationEntityInv, null);

			headerParamInfo.addChildParam(locationParamInfo);

			// TODO: Niladri -- check action "n" -- Done
			voipOrderDao.populateOrderDetails(tblOrderObject, headerParamInfo.getChildParams(), "o", 0, 0);

			LOG.info(
					"populateEslEsipLocSuspendOrDeactivateOrderDetails::Completed voipOrderDao.populateOrderDetails()");

			LOG.info("Leaving populateEslEsipLocSuspendOrDeactivateOrderDetails");
		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new GenericException(GenericException.GENERIC_EXCEPTION,
					"Exception occured in populateEslEsipLocSuspendOrDeactivateOrderDetails");
		}
	}

	/**
	 * TODO Disconn Niladri - Revisit where clause list DONE
	 * 
	 * @param location
	 *            Id
	 * @throws ApplicationInterfaceException,
	 *             GenericException
	 */
	@Override
	public String findRemoteLocationEnterpriseId(String voipLocationId)
			throws ApplicationInterfaceException, GenericException {
		LOG.info("Entered findRemoteLocationEnterpriseId");
		DBServiceResponse dbServiceResponse = null;
		Set<String> selectColumnSet = null;
		List<String[]> whereClauseList = null;
		String enterpriseId = null;
		try {
			selectColumnSet = new HashSet<>();
			selectColumnSet.add("ENTERPRISE_ID");
			selectColumnSet.add("LOCATION_ID");
			selectColumnSet.add("ACTIVE_IND");

			// TODO Disconn Nilardi - Need to revisit the where caluse DONE

			whereClauseList = new ArrayList<>();
			whereClauseList.add(new String[] { "HUB_LOCATION_ID", voipLocationId });
			whereClauseList.add(new String[] { "ACTIVE_IND", "1" });

			dbServiceResponse = inventoryDomainDataServiceImpl.searchInventory("TBL_LOCATION", selectColumnSet,
					whereClauseList);

			for (TblRow tblRows : dbServiceResponse.getTableRows()) {
				enterpriseId = tblRows.getTblRow().get("ENTERPRISE_ID").getValue();
				LOG.info("Enterprise Id : {}", enterpriseId);

			}
		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new GenericException(GenericException.GENERIC_EXCEPTION, "Exception occured in findRemoteLocation");
		}
		LOG.info("Exit findRemoteLocationEnterpriseId");
		return enterpriseId;
	}

	/**
	 * Disconn
	 * 
	 * @param voipLocationId
	 * @return void
	 * @throws TranslatorException
	 * @throws GenericException
	 */
	public void createEnterpriseOrder(VOIPOrderRequest voipOrderRequest, TblEnvOrder tblEnvOrderObject)
			throws TranslatorException, GenericException {
		String customerId = null;
		TblOrder tblOrderObject = null;
		com.vz.esap.translation.order.model.Order order = null;
		com.vz.esap.translation.order.model.Order orderPrevPass = null;
		com.vz.esap.translation.order.model.OrderHeader orderHeader = null;
		List<TblOrderService> tblOrderServiceList = null;
		long serviceCounts = -1;
		long detailCounts = -1;
		CustomerEntity customerEntityInv = null;
		LocationEntity locationEntityInv = null;
		ParamInfo headerParamInfo = null;
		ParamInfo customerParamInfo = null;
		try {
			locationEntityInv = getEntityDetailsFromInventory(voipOrderRequest.getOrderHeader().getVoipLocationId(),
					LocationEntity.class);
			if (locationEntityInv != null && locationEntityInv.getCustomerId() != null) {
				customerId = locationEntityInv.getCustomerId();
				LOG.info("Customer Id : {}", customerId);
				voipOrderRequest.getOrderHeader().setEnterpriseId(customerId);
			}

			customerEntityInv = getEntityDetailsFromInventory(voipOrderRequest.getOrderHeader().getEnterpriseId(),
					CustomerEntity.class);

			// Creating tbl order services
			orderHeader = createdOrderHeaderForEnterpriseOrder(voipOrderRequest, customerEntityInv);
			orderHeader.setOrderStatus(WorkOrderEnum.Status.WO_INIT);
			orderHeader.setOrderType("o");

			if (null != tblEnvOrderObject.getEnvOrderId())
				orderHeader.setEnvOrderId(tblEnvOrderObject.getEnvOrderId());
			if (null != tblEnvOrderObject.getProjectId())
				orderHeader.setProjectId(tblEnvOrderObject.getProjectId());

			orderHeader.setEntityAction("O");
			orderHeader.setEntityType(EsapEnum.OrderEntity.ENTERPRISE.getIndex());

			order = new Order();
			order.setOrderHeader(orderHeader);
			order.setCustomerEntity(customerEntityInv);

			// Create order for Enterprise
			tblOrderObject = enterpriseTblOrderData.prepareTblOrderDataFromOrder(order, 1L);
			voipOrderDao.createTblOrder(tblOrderObject);

			orderHeader.setFlowPath(FlowPath.valueOf(tblOrderObject.getFlowPath()));
			orderHeader.setTblOrderId(tblOrderObject.getOrderId());

			// Create enterprise order details
			headerParamInfo = commonTblOrderDetailsDataTransformerImpl
					.prepareTblOrderDetailsHeaderParamDataForCustomer(voipOrderRequest, tblOrderObject);

			customerParamInfo = enterpriseTblOrderDetailsData.prepareTblOrderDetailsEntityParamDataForCustomer(
					voipOrderRequest, tblOrderObject, customerEntityInv);

			headerParamInfo.addChildParam(customerParamInfo);

			voipOrderDao.populateOrderDetails(tblOrderObject, headerParamInfo.getChildParams(), "o", 0, 0);

			// TODO Niladri has to customize this method for ESL REL_DEACTIVATE
			tblOrderServiceList = enterpriseTblOrderServiceData.prepareTblOrderServiceData(order, orderPrevPass, null);

			LOG.info("Retail Order Service Count : {}", tblOrderServiceList.size());

			for (TblOrderService tblOrderService : tblOrderServiceList) {
				serviceCounts += voipOrderDao.createTblOrderService(tblOrderService);
			}

			voipOrderDao.updateTblOrderStatus(tblOrderObject.getOrderId(), WorkOrderEnum.Status.WO_INIT);

			LOG.info("Info {}-{}", detailCounts, serviceCounts);
		} catch (TranslatorException ex) {
			LOG.error("Exception {} ", ex.getMessage());
			throw new TranslatorException(ex.getErrorCode(), ex.getMessage());
		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new GenericException(GenericException.GENERIC_EXCEPTION, "Exception in the provide input arguments");
		}
	}

	/**
	 * @param voipLocationId
	 * @return void
	 * @throws TranslatorException
	 * @throws GenericException
	 */
	public void createLocationOrderFromInventoryDetails(VOIPOrderRequest voipOrderRequest,
			TblEnvOrder tblEnvOrderObject) throws GenericException, TranslatorException {
		LOG.info("Enetered createLocationOrder");

		String virtualAddrCountry = null;
		String customerId = null;
		TblOrder tblOrderObject = null;
		com.vz.esap.translation.order.model.Order order = null;
		com.vz.esap.translation.order.model.OrderHeader orderHeader = null;
		List<TblOrderService> tblOrderServiceList = null;
		long serviceCounts = -1;
		long detailCounts = -1;
		LocationEntity locationEntityInv = null;
		ParamInfo headerParamInfo = null;
		ParamInfo locationParamInfo = null;
		try {
			locationEntityInv = getEntityDetailsFromInventory(voipOrderRequest.getOrderHeader().getVoipLocationId(),
					LocationEntity.class);

			if (locationEntityInv != null && locationEntityInv.getCustomerId() != null) {
				customerId = locationEntityInv.getCustomerId();
				LOG.info("Customer Id : {}", customerId);
				voipOrderRequest.getOrderHeader().setEnterpriseId(customerId);
			}

			if (locationEntityInv != null && locationEntityInv.getLocRegion() != null)
				virtualAddrCountry = locationEntityInv.getLocRegion();
			else
				virtualAddrCountry = "US";
			LOG.info("EslOrderServiceImpl:: virtualAddrCountry - {}", virtualAddrCountry);
			voipOrderRequest.getOrderHeader().setRegion(virtualAddrCountry);
			
			locationEntityInv.setAsClli(voipOrderRequest.getOrderHeader().getAsClli()); //add broadsoft clli.
			
			// Creating tbl order services
			orderHeader = createdOrderHeaderForLocationOrder(voipOrderRequest, locationEntityInv);
			orderHeader.setOrderStatus(WorkOrderEnum.Status.WO_INIT);

			if (null != tblEnvOrderObject.getEnvOrderId())
				orderHeader.setEnvOrderId(tblEnvOrderObject.getEnvOrderId());
			if (null != tblEnvOrderObject.getProjectId())
				orderHeader.setProjectId(tblEnvOrderObject.getProjectId());

			orderHeader.setEntityType(EsapEnum.OrderEntity.LOCATION.getIndex());

			order = new Order();
			order.setOrderHeader(orderHeader);
			order.setLocationEntity(locationEntityInv);

			// Create Order
			tblOrderObject = enterpriseTblOrderData.prepareTblOrderDataFromOrder(order, 3L);

			if (null != tblEnvOrderObject.getMinorOrderType())
				orderHeader.setMinorOrderType(tblEnvOrderObject.getMinorOrderType());

			voipOrderDao.createTblOrder(tblOrderObject);

			orderHeader.setFlowPath(FlowPath.valueOf(tblOrderObject.getFlowPath()));
			orderHeader.setTblOrderId(tblOrderObject.getOrderId());

			// Create Order Details
			headerParamInfo = commonTblOrderDetailsDataTransformerImpl
					.prepareTblOrderDetailsHeaderParamDataForCustomer(voipOrderRequest, tblOrderObject);

			locationParamInfo = locationTblOrderDetailsData.prepareTblOrderDetailsEntityParamDataForLocation(
					voipOrderRequest, tblOrderObject, locationEntityInv, null);

			headerParamInfo.addChildParam(locationParamInfo);

			voipOrderDao.populateOrderDetails(tblOrderObject, headerParamInfo.getChildParams(), "o", 0, 0);

			// Craete Order Service
			tblOrderServiceList = enterpriseTblOrderServiceData.prepareTblOrderServiceData(order, null, null);

			LOG.info("Retail Order Service Count : {}", tblOrderServiceList.size());

			for (TblOrderService tblOrderService : tblOrderServiceList) {
				serviceCounts += voipOrderDao.createTblOrderService(tblOrderService);
			}

			voipOrderDao.updateTblOrderStatus(tblOrderObject.getOrderId(), WorkOrderEnum.Status.WO_INIT);

			LOG.info("Info {}-{}", detailCounts, serviceCounts);
		} catch (TranslatorException ex) {
			LOG.error("Exception {} ", ex.getMessage());
			throw new TranslatorException(ex.getErrorCode(), ex.getMessage());
		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new GenericException(GenericException.GENERIC_EXCEPTION, "Exception in the provide input arguments");
		}
	}

	/**
	 * @param voipOrderRequest
	 * @param tblEnvOrderObject
	 * @throws TranslatorException
	 * @throws GenericException
	 */
	@Override
	public void createTNOrderFromInventoryDetails(VOIPOrderRequest voipOrderRequest, TblEnvOrder tblEnvOrderObject)
			throws TranslatorException, GenericException {
		LOG.info("Entering createTNOrderFromInventoryDetails");
		List<String> tnsList = null;
		com.vz.esap.translation.order.model.Order order = null;
		com.vz.esap.translation.order.model.OrderHeader orderHeader = null;
		GroupTNEntity groupTNEntity = null;
		TblOrder tblOrderObject = null;
		ParamInfo headerParamInfo = null;
		ParamInfo entityParamInfo = null;
		List<TnType> tnTypeList = null;
		List<TblOrderService> tblOrderServiceList = null;
		long serviceCounts = -1;
		String entityAction = null;
		List<TnType> tnListDistinct = null;
		String todAction = null;

		try {

			if (voipOrderRequest.getTnActivation() != null) {

				tnsList = getTnListForActivation(voipOrderRequest);

			} else {
				tnsList = inventoryUtil.getTNsFromLocationId(voipOrderRequest.getOrderHeader().getVoipLocationId());

			}

			if (Arrays.asList(OrderAction.ADD.getValue()).contains(voipOrderRequest.getOrderHeader().getOrderType())) {
				todAction = "n";

			} else if (Arrays.asList(OrderAction.DELETE.getValue(), OrderAction.DISCONNECT.getValue())
					.contains(voipOrderRequest.getOrderHeader().getOrderType())) {
				todAction = "o";

			}

			tnTypeList = new ArrayList<>();
			for (String tn : tnsList) {

				LOG.info("+++++++++++++++++++++++++START CREATION OF ORDER FOR TN = {} ++++++++++++++++++++++++++", tn);

				groupTNEntity = getEntityDetailsFromInventory(tn, GroupTNEntity.class);

				if (groupTNEntity == null) {
					groupTNEntity = new GroupTNEntity();
				}
				
				groupTNEntity.setAsClli(voipOrderRequest.getOrderHeader().getAsClli()); //add broadsoft clli.
				
				order = new Order();
				orderHeader = createOrderHeaderForGroupTnOrder(voipOrderRequest, groupTNEntity);
				orderHeader.setOrderStatus(WorkOrderEnum.Status.WO_INIT);

				// :create order
				LOG.info("createOrders start creating GroupTnEntity orders");
				if (null != tblEnvOrderObject.getEnvOrderId())
					orderHeader.setEnvOrderId(tblEnvOrderObject.getEnvOrderId());
				if (null != tblEnvOrderObject.getProjectId())
					orderHeader.setProjectId(tblEnvOrderObject.getProjectId());

				orderHeader.setEnvOrderId(tblEnvOrderObject.getEnvOrderId());
				orderHeader.setProjectId(tblEnvOrderObject.getProjectId());
				orderHeader.setCustomerId(tblEnvOrderObject.getEnterpriseId());
				orderHeader.setEnterpriseId(tblEnvOrderObject.getEnterpriseId());
				orderHeader.setLocationId(tblEnvOrderObject.getLocationId());
				orderHeader.setRegion(tblEnvOrderObject.getRegion());

				entityAction = orderHeader.getEntityAction();
				orderHeader.setOrderingAction(voipOrderRequest.getOrderHeader().getFunctionCode());

				order.setOrderHeader(orderHeader);
				order.setGroupTnEntity(groupTNEntity);

				if (groupTNEntity.getTnRecord() != null) {

					tnTypeList.add(groupTNEntity.getTnRecord().getTnType());

					LOG.info("groupTnEntity.getTnRecord().getTn() {}", groupTNEntity.getTnRecord().getTn());
					LOG.info("groupTnEntity.getTnRecord().getTnType() {}", groupTNEntity.getTnRecord().getTnType());
					LOG.debug("groupTnEntity.getTnRecord() {}", groupTNEntity.getTnRecord());
					LOG.info("order.getGroupTnEntity().getTnRecord().getTn() {}",
							order.getGroupTnEntity().getTnRecord().getTn());

					if (TnType.TWO_WAY_TN.equals(groupTNEntity.getTnRecord().getTnType())) {
						tblOrderObject = enterpriseTblOrderData.prepareTblOrderDataFromOrder(order, 67L);
						orderHeader.setEntityType(EsapEnum.OrderEntity.TWO_WAY_TN.getIndex());
					} else if (TnType.INBOUND_TN.equals(groupTNEntity.getTnRecord().getTnType())) {
						tblOrderObject = enterpriseTblOrderData.prepareTblOrderDataFromOrder(order, 68L);
						orderHeader.setEntityType(EsapEnum.OrderEntity.INBOUND_TN.getIndex());
					} else if (TnType.DID_TN.equals(groupTNEntity.getTnRecord().getTnType())) {
						tblOrderObject = enterpriseTblOrderData.prepareTblOrderDataFromOrder(order, 72L);
						orderHeader.setEntityType(EsapEnum.OrderEntity.DID_TN.getIndex());
					} else if (TnType.LINE_TN.equals(groupTNEntity.getTnRecord().getTnType())) {
						tblOrderObject = enterpriseTblOrderData.prepareTblOrderDataFromOrder(order, 71L);
						orderHeader.setEntityType(EsapEnum.OrderEntity.LINE_TN.getIndex());
					}
				}

				voipOrderDao.createTblOrder(tblOrderObject);

				orderHeader.setFlowPath(FlowPath.valueOf(tblOrderObject.getFlowPath()));
				orderHeader.setTblOrderId(tblOrderObject.getOrderId());
				orderHeader.setOrderClassify(WorkOrderEnum.OrderClassify.LNP_ACTIVATE);
				order.setOrderHeader(orderHeader);

				headerParamInfo = tnTblOrderDetailsData.prepareTblOrderDetailsHeaderParamData(order);
				entityParamInfo = tnTblOrderDetailsData.prepareTblOrderDetailsEntityParamDataForGroupTn(order);

				headerParamInfo.addChildParam(entityParamInfo);

				voipOrderDao.populateOrderDetails(tblOrderObject, headerParamInfo.getChildParams(), todAction, 0, 0);

				// Craete Order Service
				tblOrderServiceList = enterpriseTblOrderServiceData.prepareTblOrderServiceData(order, null, null);

				orderHeader.setEntityAction(entityAction);

				LOG.info("Retail Order Service Count : {}", tblOrderServiceList.size());

				for (TblOrderService tblOrderService : tblOrderServiceList) {
					serviceCounts += voipOrderDao.createTblOrderService(tblOrderService);
				}

				voipOrderDao.updateTblOrderStatus(tblOrderObject.getOrderId(), WorkOrderEnum.Status.WO_INIT);
			}

			// Start : Multiple TN Type Handle
			LOG.info("Trunk Type Size before distinct - {}", tnTypeList.size());
			tnListDistinct = tnTypeList.stream().distinct().collect(Collectors.toList());
			LOG.info("Trunk Type Size after distinct - {}", tnListDistinct.size());

			if (groupTNEntity != null && groupTNEntity.getTnRecord() != null) {
				for (TnType tnType : tnListDistinct) {
					groupTNEntity.getTnRecord().setTnType(tnType);

					groupTnOrderServiceImpl.createSystemUpdateReleaseOrders(orderHeader, groupTNEntity, null,
							WorkOrderEnum.Status.WO_INIT, tblEnvOrderObject);
				}
			}

			LOG.info("Exit createTNOrder");

		} catch (TranslatorException ex) {
			LOG.error("Exception {} ", ex.getMessage());
			throw new TranslatorException(ex.getErrorCode(), ex.getMessage());

		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new GenericException(GenericException.GENERIC_EXCEPTION,
					"Generic Exception in createTNOrderFromInventoryDetails");

		}
	}

	/**
	 * @param voipOrderRequest
	 * @param tnsListInv
	 * @return tnsList
	 */
	private List<String> getTnListForActivation(VOIPOrderRequest voipOrderRequest) {
		LOG.info("Begin getTnListForActivation");

		List<String> tnsList = new ArrayList<>();
		/* To handle NPE */
		if (voipOrderRequest.getTnActivation().getTnInfo() != null
				&& voipOrderRequest.getTnActivation().getTnInfo().length > 0) {
			for (TnInfo tnInfo : voipOrderRequest.getTnActivation().getTnInfo()) {
				tnsList.add(tnInfo.getTn());
				LOG.info("TN From TN Info = {}", tnInfo.getTn());
			}
		}
		long startValue;
		long endValue;
		/* To handle NPE */
		if (voipOrderRequest.getTnActivation().getTnRangeInfo() != null
				&& voipOrderRequest.getTnActivation().getTnRangeInfo().length > 0) {
			for (TnRangeInfo tnRangeInfo : voipOrderRequest.getTnActivation().getTnRangeInfo()) {
				startValue = Long.parseLong(tnRangeInfo.getTnRangeStart());
				endValue = Long.parseLong(tnRangeInfo.getTnRangeEnd());

				LOG.info("Start TN = {}", startValue);
				LOG.info("End TN = {}", endValue);

				String tn;
				while (endValue >= startValue) {
					tn = String.valueOf(startValue);

					tnsList.add(tn);
					LOG.info("TN From Range = {}", startValue);

					startValue = startValue + 1;
				}
			}
		}
		LOG.info("Exit getTnListForActivation");
		return tnsList;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.vz.esap.translation.order.service.helper.OrderServiceHelper#
	 * isNewEsipEnterprise(com.vz.esap.translation.order.model.request.
	 * VOIPOrderRequest, com.vz.esap.translation.connector.model.DBServiceResponse)
	 */
	@Override
	public boolean isNewEsipEnterprise(VOIPOrderRequest voipOrderRequest, DBServiceResponse dbServiceResponseTblCust)
			throws GenericException {
		LOG.info("Entered isNewEsipEnterprise");

		List<Feature> features = null;
		boolean isNewEsipEnterprise = false;
		DBServiceResponse dbServiceResponseTblLoc = null;
		String enterpriseId = null;
		LocationType locationType = null;
		int version;
		String locationId = null;

		try {

			version = Integer.parseInt(voipOrderRequest.getOrderHeader().getWorkOrderVersion());

			if (voipOrderRequest.getConvergedService() != null
					&& voipOrderRequest.getConvergedService().getFeature() != null
					&& Arrays.asList(SolutionType.ESIP_ESL, SolutionType.ESIP_EBL)
							.contains(voipOrderRequest.getOrderHeader().getSolutionType())) {

				features = stream(voipOrderRequest.getConvergedService().getFeature())
						.filter(feature -> "EXT_FET_VPN".equalsIgnoreCase(feature.getCode())
								|| "FET_LOC_LVL".equalsIgnoreCase(feature.getCode()))
						.collect(Collectors.toList());

				if (!CollectionUtils.isEmpty(features)) {
					for (Specification vpnSpec : features.get(0).getSpecification()) {
						if ("SP_VPN_NAME".equalsIgnoreCase(vpnSpec.getCode())
								|| "ESP_XO_ASSOCIATED_VPN_NAME".equalsIgnoreCase(vpnSpec.getCode())) {

							LOG.info("VPN Name is = {}", vpnSpec.getValue());

							dbServiceResponseTblLoc = inventoryUtil.getLocationFromVpnName(vpnSpec.getValue());

							break;
						}
					}
				}
			}

			if (Arrays
					.asList(OrderType.getValueReverse("OUT"), OrderType.getValueReverse("CHANGE"),
							OrderType.getValueReverse("SUSPEND"), OrderType.getValueReverse("DISCONNECT"))
					.contains(voipOrderRequest.getOrderHeader().getOrderType())) {
				// These are MACD order which is always existing customer
				isNewEsipEnterprise = false;

			} else {

				if ((dbServiceResponseTblCust.getNumberOfRecords() == 0 || dbServiceResponseTblLoc == null)
						&& Arrays.asList(SolutionType.ESIP_ESL, SolutionType.ESIP_EBL)
								.contains(voipOrderRequest.getOrderHeader().getSolutionType())) {
					// New Customer and New Enterprise as GCH ID is new and VPN do not exits
					isNewEsipEnterprise = true;

				} else if (dbServiceResponseTblCust.getNumberOfRecords() > 0 && dbServiceResponseTblLoc != null
						&& dbServiceResponseTblLoc.getNumberOfRecords() == 0
						&& Arrays.asList(SolutionType.ESIP_ESL, SolutionType.ESIP_EBL)
								.contains(voipOrderRequest.getOrderHeader().getSolutionType())) {
					// New Enterprise for existing Customer GCH ID is existing and VPN does not
					// exist
					isNewEsipEnterprise = true;

				} else if (dbServiceResponseTblCust.getNumberOfRecords() > 0 && dbServiceResponseTblLoc != null
						&& dbServiceResponseTblLoc.getNumberOfRecords() > 0
						&& Arrays.asList(SolutionType.ESIP_ESL, SolutionType.ESIP_EBL)
								.contains(voipOrderRequest.getOrderHeader().getSolutionType())) {
					// Existing Customer GCH ID is existing and VPN does exist so lets check and
					// compare the Enterprise Id
					boolean isMatchingEnterprise = isMatchingEnterprise(dbServiceResponseTblCust,
							dbServiceResponseTblLoc);

					if (isMatchingEnterprise) {
						// This means that the GCH Id and VPN belongs to same Enterprise Hence its
						// existing Enterprise
						isNewEsipEnterprise = false;
					} else {
						isNewEsipEnterprise = true;
					}

				} else if (dbServiceResponseTblCust.getNumberOfRecords() == 0
						&& Arrays.asList(SolutionType.IPFLEX, SolutionType.HPBX)
								.contains(voipOrderRequest.getOrderHeader().getSolutionType())) {
					// This is new Enterprise for brand new Customer
					isNewEsipEnterprise = true;

				} else if (dbServiceResponseTblCust.getNumberOfRecords() > 0 && Arrays.asList(SolutionType.IPFLEX)
						.contains(voipOrderRequest.getOrderHeader().getSolutionType())) {

					// This is the scenario where the Enterprise is there for existing customer.
					// Below logic finds out whether the new enetrprise is needed or not

					for (TblRow tblRows : dbServiceResponseTblCust.getTableRows()) {
						enterpriseId = tblRows.getTblRow().get("ENTERPRISE_ID").getValue();

						if (enterpriseId == null) {
							enterpriseId = tblRows.getTblRow().get("CUSTOMER_ID").getValue();

						}

						LOG.info("ENTERPRISE_ID : {}", enterpriseId);
					}

					locationType = inventoryUtil.getLocationTypeFromEnterpriseId(enterpriseId);

					LOG.info("locationType : {}", locationType);

					locationId = inventoryUtil.getLocationIdFromEnterpriseId(enterpriseId, locationType.getIndex());

					LOG.info("locationId from existing Enterprise: {} . LocationId from BOD: {}", locationId,
							voipOrderRequest.getOrderHeader().getVoipLocationId());

					if (locationId != null
							&& voipOrderRequest.getOrderHeader().getVoipLocationId().equalsIgnoreCase(locationId)) {

						isNewEsipEnterprise = false;

					} else {
						isNewEsipEnterprise = true;
					}

				} else if (dbServiceResponseTblCust.getNumberOfRecords() > 0 && Arrays.asList(SolutionType.HPBX)
						.contains(voipOrderRequest.getOrderHeader().getSolutionType())) {

					// This is the scenario where the Enterprise is there for existing customer.
					// Below logic finds out whether the new enetrprise is needed or not

					for (TblRow tblRows : dbServiceResponseTblCust.getTableRows()) {
						enterpriseId = tblRows.getTblRow().get("ENTERPRISE_ID").getValue();

						if (enterpriseId == null) {
							enterpriseId = tblRows.getTblRow().get("CUSTOMER_ID").getValue();

						}

						LOG.info("ENTERPRISE_ID : {}", enterpriseId);
					}

					locationType = inventoryUtil.getLocationTypeFromEnterpriseId(enterpriseId);

					LOG.info("locationType : {}", locationType);

					// This is Supp scenario and we need to see if customer already exist
					if (version != 0) {

						locationId = inventoryUtil.getLocationIdFromEnterpriseId(enterpriseId,
								LocationType.HPBX_EBL.getIndex());

						LOG.info("locationId from existing Enterprise: {} . LocationId from BOD: {}", locationId,
								voipOrderRequest.getOrderHeader().getVoipLocationId());

						/*
						 * if (locationId != null &&
						 * voipOrderRequest.getOrderHeader().getVoipLocationId().equalsIgnoreCase(
						 * locationId)) {
						 * 
						 * isNewEsipEnterprise = false;
						 * 
						 * } else { isNewEsipEnterprise = true;
						 * 
						 * }
						 */

						// If an Enterprise contains at least one HPBX EBL this means the customer is
						// existing:
						if (locationId != null) {

							isNewEsipEnterprise = false;

						} else {
							isNewEsipEnterprise = true;

						}

					} else {

						if (locationType != null
								&& Arrays.asList(LocationType.ESIP_ESL, LocationType.ESIP_EBL, LocationType.IPFLEX)
										.contains(locationType)
								&& SolutionType.HPBX.equals(voipOrderRequest.getOrderHeader().getSolutionType())) {

							// This is the scenario where non HPBX customer is placing flex order
							isNewEsipEnterprise = true;

						} else {

							isNewEsipEnterprise = false;
						}
					}
				}
			}
		} catch (Exception e) {
			LOG.error("Exception {} ", e);
			throw new GenericException(GenericException.GENERIC_EXCEPTION, "Exception occured in isNewEsipEnterprise");
		}
		LOG.info("Exit isNewEsipEnterprise With isNewEsipEnterprise = {}", isNewEsipEnterprise);
		return isNewEsipEnterprise;
	}

	/**
	 * @param dbServiceResponseTblCust
	 * @param dbServiceResponseTblLoc
	 * @return isMatchingEnterprise
	 */
	public boolean isMatchingEnterprise(DBServiceResponse dbServiceResponseTblCust,
			DBServiceResponse dbServiceResponseTblLoc) {
		LOG.info("Entered isMatchingEnterprise");

		boolean isMatchingEnterprise = false;
		String entId = null;

		for (TblRow tblRows : dbServiceResponseTblCust.getTableRows()) {
			if (tblRows.getTblRow() != null && tblRows.getTblRow().get("ENTERPRISE_ID") != null
					&& tblRows.getTblRow().get("ENTERPRISE_ID").getValue() != null) {

				entId = tblRows.getTblRow().get("ENTERPRISE_ID").getValue();
				LOG.info("The ENTERPRISE_ID = {}", entId);
			}
		}

		for (TblRow tblRows : dbServiceResponseTblLoc.getTableRows()) {
			if (tblRows.getTblRow() != null && tblRows.getTblRow().get("ENTERPRISE_ID") != null
					&& tblRows.getTblRow().get("ENTERPRISE_ID").getValue() != null) {

				LOG.info("For ENTERPRISE_ID From TBL_LOCATION = {} And ENTERPRISE_ID From TBL_ENTERPRISE = {}",
						tblRows.getTblRow().get("ENTERPRISE_ID").getValue(), entId);

				if (tblRows.getTblRow().get("ENTERPRISE_ID").getValue().equalsIgnoreCase(entId)) {
					isMatchingEnterprise = true;
				}
			}
		}

		LOG.info("Exit isMatchingEnterprise");
		return isMatchingEnterprise;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.vz.esap.translation.order.service.helper.OrderServiceHelper#
	 * getOrderCpeDeviceDetails(com.vz.esap.translation.order.model.request.
	 * VOIPOrderRequest)
	 */
	@Override
	public DeviceEntity getOrderCpeDeviceDetails(Feature deviceFeature, SolutionType solutionType, GroupType trunkType)
			throws ApplicationInterfaceException, GenericException {
		LOG.info("Entered getOrderCpeDeviceDetails");

		final String processName = "ORDER_MANAGER";
		final String paramGroup = "DEVICE";
		final String status = "E";

		List<String> esipCustomUuidList;
		String deviceUeId = null;

		DeviceEntity device = null;

		if (Arrays.asList(SolutionType.ESIP_ESL, SolutionType.ESIP_EBL, SolutionType.HPBX).contains(solutionType)) {
			esipCustomUuidList = inventoryUtil.getParamValue("ESIP_CUSTOM_UUID", processName, paramGroup, status);
			deviceUeId = esipCustomUuidList.get(0);

		} else if (Arrays.asList(SolutionType.IPFLEX).contains(solutionType)) {

			List<Specification> ueidSpecs = stream(deviceFeature.getSpecification())
					.filter(feature -> feature.getCode().equalsIgnoreCase("ESP_CPE_UEID")).collect(Collectors.toList());

			if (!CollectionUtils.isEmpty(ueidSpecs)) {
				deviceUeId = ueidSpecs.get(0).getValue();
				LOG.info("Device UEID = {}", deviceUeId);

				if (EsapEnum.FxoCpeUeid.getValue(deviceUeId) != null) {
					deviceUeId = EsapEnum.FxoCpeUeid.getValue(deviceUeId);
				}
			}
		}

		LOG.info("FXO Device UEID = {}", deviceUeId);

		// Get Trunk Type as param name
		String protocolParamName = null;
		if (Arrays.asList(GroupType.TWO_WAY, GroupType.INBOUND).contains(trunkType)) {
			protocolParamName = "TWO_WAY_INBOUND";

		} else if (Arrays.asList(GroupType.PRI_DID, GroupType.NON_PRI_DID).contains(trunkType)) {
			protocolParamName = "DID";

		} else if (Arrays.asList(GroupType.LINE).contains(trunkType)) {
			protocolParamName = "LINE";

		}
		LOG.info("Device protocolParamName = {}", protocolParamName);

		List<String> deviceProtocol = inventoryUtil.getParamValue(protocolParamName, processName, "DEVICE_PROTOCOL",
				status);

		LOG.info("Device deviceProtocol = {}", deviceProtocol);

		Map<String, String> deviceResultantRowMap = inventoryUtil.getDeviceDetails(deviceUeId, deviceProtocol.get(0));

		device = createDeviceMetadataEntity(deviceResultantRowMap, solutionType, trunkType);

		LOG.info("Exit getOrderCpeDeviceDetails");
		return device;
	}

	/**
	 * @param deviceResultantRowMap
	 * @param solutionType
	 * @return device
	 * @throws ApplicationInterfaceException
	 */
	DeviceEntity createDeviceMetadataEntity(Map<String, String> deviceResultantRowMap, SolutionType solutionType,
			GroupType trunkType) throws ApplicationInterfaceException {
		LOG.info("Entered createDeviceMetadataEntity");

		final String processName = "ORDER_MANAGER";
		final String status = "E";

		DeviceEntity device = new DeviceEntity();

		if (deviceResultantRowMap.get("DEVICE_REALTYPE_ID") != null) {
			device.setDeviceType(Integer.valueOf(deviceResultantRowMap.get("DEVICE_REALTYPE_ID")));

			LOG.info("DEVICE_REALTYPE_ID = {}", deviceResultantRowMap.get("DEVICE_REALTYPE_ID"));
		}

		if (deviceResultantRowMap.get("DEVICE_BSTYPE") != null) {
			device.setDeviceBsType(Integer.valueOf(deviceResultantRowMap.get("DEVICE_BSTYPE")));

			LOG.info("DEVICE_BSTYPE = {}", deviceResultantRowMap.get("DEVICE_BSTYPE"));
		}

		if (deviceResultantRowMap.get("DEVICE_TYPE_ID") != null) {
			device.setDeviceTypeId(deviceResultantRowMap.get("DEVICE_TYPE_ID"));

			LOG.info("DEVICE_TYPE_ID = {}", deviceResultantRowMap.get("DEVICE_TYPE_ID"));
		}

		if (deviceResultantRowMap.get("PROTOCOL") != null) {
			device.setProtocol(deviceResultantRowMap.get("PROTOCOL"));

			LOG.info("PROTOCOL = {}", deviceResultantRowMap.get("PROTOCOL"));
		}

		String paramName = null;
		if (Arrays.asList(SolutionType.ESIP_ESL, SolutionType.ESIP_EBL, SolutionType.HPBX).contains(solutionType)) {
			paramName = SolutionType.SL_ESIP.toString();

		} else if (Arrays.asList(SolutionType.IPFLEX).contains(solutionType)) {
			paramName = SolutionType.SL_IP_FLEX.toString();

		}

		List<String> deviceTransportProtocol = inventoryUtil.getParamValue(paramName, processName,
				"DEVICE_TRANPORT_PROTOCOL", status);

		if (!CollectionUtils.isEmpty(deviceTransportProtocol)
				&& TransportProtocol.UDP.getValue().equalsIgnoreCase(deviceTransportProtocol.get(0))) {
			device.setTransportProtocol(TransportProtocol.UDP);

			LOG.info("Device Transportprotocol = {}", deviceTransportProtocol.get(0));

		} else if (!CollectionUtils.isEmpty(deviceTransportProtocol)
				&& TransportProtocol.TCP.getValue().equalsIgnoreCase(deviceTransportProtocol.get(0))) {
			device.setTransportProtocol(TransportProtocol.TCP);

			LOG.info("Device Transportprotocol = {}", deviceTransportProtocol.get(0));
		}

		List<String> deviceDefaultPort = inventoryUtil.getParamValue("DEVICE_DEFAULT_PORT", processName, "DEVICE",
				status);

		if (!CollectionUtils.isEmpty(deviceDefaultPort) && !Arrays.asList(GroupType.LINE).contains(trunkType)) {
			device.setPort(deviceDefaultPort.get(0));

			LOG.info("Device Default Port = {}", deviceDefaultPort.get(0));

		}

		device.setIpAddress(null);

		LOG.info("Exit createDeviceMetadataEntity");
		return device;
	}

	public DeviceType getDeviceTypeFromDeviceTypeId(int deviceTypeId) {

		if (deviceTypeId == DeviceType.SIP_DEVICE.ordinal())
			return DeviceType.SIP_DEVICE;
		else if (deviceTypeId == DeviceType.ENTPRISE_GTWY.ordinal())
			return DeviceType.ENTPRISE_GTWY;
		else if (deviceTypeId == DeviceType.EST_STATIC_DEVGW_01.ordinal())
			return DeviceType.EST_STATIC_DEVGW_01;
		else if (deviceTypeId == DeviceType.CPE_LOCAL_GTWY.ordinal())
			return DeviceType.CPE_LOCAL_GTWY;
		else if (deviceTypeId == DeviceType.CPE_ENTPRISE_GTWY_SHARED.ordinal())
			return DeviceType.CPE_ENTPRISE_GTWY_SHARED;
		else
			return null;
	}

	@Override
	public VoipOrderResponse handleTranslationException(VOIPOrderRequest voipOrderRequest, String milestone,
			StatusCode statusCode, String errorDescription)
			throws GenericException, JsonProcessingException, TranslatorException {
		LOG.info("Entered handleTranslationException");

		ObjectMapper mapper = new ObjectMapper();

		VoipOrderResponse voipOrderResponse = voipResponseGenerator.preparePCMilestone(voipOrderRequest, milestone,
				statusCode, "RESPONSE");

		LOG.debug("VOIP ORDER TRANSLATION FAILED::::: {}",
				mapper.writerWithDefaultPrettyPrinter().writeValueAsString(voipOrderResponse));

		if (!OrderOrigin.GUI.toString().equalsIgnoreCase(voipOrderRequest.getOrderHeader().getOriginatingSystem())) {
			notificationServiceImpl.notifyFailures(voipOrderResponse);

		}

		List<TblEnvOrder> tblEnvOrders = voipOrderDaoImpl
				.getTableEnvOrderFromOrderHeader(voipOrderRequest.getOrderHeader());

		if (tblEnvOrders != null && !CollectionUtils.isEmpty(tblEnvOrders)) {
			LOG.info("Order Already Created with Env Order Id= {}", tblEnvOrders.get(0).getEnvOrderId());
		} else {

			TblEnvOrder tblEnvOrderObject = createEsipEslEnvOrder(voipOrderRequest,
					WorkOrderEnum.Status.WO_TRANSLATION_FAIL);

			createEsipEslOrderHeader(voipOrderRequest, WorkOrderEnum.Status.WO_TRANSLATION_FAIL, tblEnvOrderObject);
		}

		LOG.info("Exit handleTranslationException");
		return voipOrderResponse;
	}

	@Override
	public String getMinorOrderType(VOIPOrderRequest voipOrderRequest) {
		LOG.info("Enetered getMinorOrderType");
		String minorOrderType = null;

		if (OrderAction.ADD.getValue().equalsIgnoreCase(voipOrderRequest.getOrderHeader().getOrderType())) {

			if (Arrays.asList(SolutionType.ESIP_EBL, SolutionType.HPBX)
					.contains(voipOrderRequest.getOrderHeader().getSolutionType()))
				minorOrderType = MinorOrderType.LOC_ADD.toString();
			else
				minorOrderType = MinorOrderType.INSTALL.toString();
		} else if (OrderAction.DELETE.getValue().equalsIgnoreCase(voipOrderRequest.getOrderHeader().getOrderType())
				|| OrderAction.DISCONNECT.getValue()
						.equalsIgnoreCase(voipOrderRequest.getOrderHeader().getOrderType())) {
			minorOrderType = MinorOrderType.OUT.toString();
		}
		LOG.info("Exit getMinorOrderType with Minor Order Type = {}", minorOrderType);
		return minorOrderType;
	}

	@Override
	public SolutionType getSolutionTypeFromBodReuest(String solutionTypeStr) {
		LOG.info("Entered getSolutionTypeFromBodReuest");
		SolutionType solutionType = null;

		if (SolutionType.SL_ESIP.toString().equals(solutionTypeStr)) {
			solutionType = SolutionType.ESIP_ESL;
		} else if (SolutionType.SL_IP_FLEX.toString().equals(solutionTypeStr)) {
			solutionType = SolutionType.IPFLEX;
		} else if (SolutionType.PR_XO_HPBX.toString().equals(solutionTypeStr)) {
			solutionType = SolutionType.HPBX;
		}
		LOG.info("Entered getSolutionTypeFromBodReuest");
		return solutionType;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.vz.esap.translation.order.service.helper.OrderServiceHelper#
	 * getUpstreamTaskIdFromFunctionCode(com.vz.esap.translation.enums.EsapEnum.
	 * FunctionCode)
	 */
	@Override
	public long getUpstreamTaskIdFromFunctionCode(String functionCode) {
		LOG.info("Entered getUpstreamTaskIdFromFunctionCode");

		long upstreamTaskId = -1;

		if (FunctionCode.VALIDATE.toString().equals(functionCode)) {
			upstreamTaskId = OrderEntity.VALIDATION.ordinal();
		} else if (FunctionCode.REL_SUSPEND.toString().equals(functionCode)) {
			upstreamTaskId = OrderEntity.LOCATION.ordinal();
		} else if (FunctionCode.REL_DEACTIVATE.toString().equals(functionCode)) {
			upstreamTaskId = OrderEntity.LOCATION.ordinal();
		} else {
			upstreamTaskId = 13L;
		}

		LOG.info("Entered getUpstreamTaskIdFromFunctionCode With Upstream Task Id ={}", upstreamTaskId);
		return upstreamTaskId;
	}

	@Override
	public boolean hasNewTnOrder(long envOrderId, String flowPath) throws GenericException {
		LOG.info("Entered hasNewTnOrder");

		boolean hasNewTnOrder = false;

		TblOrderExample tblOrderExampleMapper = new TblOrderExample();
		tblOrderExampleMapper.createCriteria().andEnvOrderIdEqualTo(envOrderId)
				.andOrderStatusEqualTo(Long.valueOf(WorkOrderEnum.Status.WO_INIT))
				.andUpstreamTaskIdIn(Arrays.asList(Long.valueOf(OrderEntity.TWO_WAY_TN.ordinal()),
						Long.valueOf(OrderEntity.INBOUND_TN.ordinal()), Long.valueOf(OrderEntity.LINE_TN.ordinal()),
						Long.valueOf(OrderEntity.DID_TN.ordinal())))
				.andFlowPathEqualTo(flowPath);

		List<TblOrder> tblOrderList = customTblOrderMapper.selectByExample(tblOrderExampleMapper);

		if (!CollectionUtils.isEmpty(tblOrderList)) {
			hasNewTnOrder = true;
		}

		LOG.info("Exit hasNewTnOrder with value = {}", hasNewTnOrder);
		return hasNewTnOrder;
	}

	@Override
	public boolean isNewEntityChangeOrder(long orderId, long parentId) {
		LOG.info("Entered isNewEntityChangeOrder For Order Id = {} and Parent Id = {}", orderId, parentId);
		boolean isNewEntityOrder = false;

		TblOrderDetails tblOrderDetails = new TblOrderDetails();
		tblOrderDetails.setOrderId(orderId);
		tblOrderDetails.setParentId(parentId);

		// Action = n is not a new device in Chnage Order
		List<TblOrderDetails> ordDetails = voipOrderDao.getOrderDetailsWithActionAndParent(parentId, null, false, null,
				tblOrderDetails);

		LOG.info("ordDetails ===>>>> {}", ordDetails);

		for (TblOrderDetails tod : ordDetails) {
			if (Arrays.asList("n", "r", "o").contains(tod.getAction())) {
				isNewEntityOrder = false;
				break;

			}

			if ("c".equalsIgnoreCase(tod.getAction())) {
				isNewEntityOrder = true;

			}
		}

		LOG.info("Exit isNewEntityChangeOrder = {}", isNewEntityOrder);
		return isNewEntityOrder;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.vz.esap.translation.order.service.helper.OrderServiceHelper#
	 * getVoipOrderType(java.lang.String)
	 */
	@Override
	public String getVoipOrderType(String voipOrderType) throws GenericException {
		LOG.info("Entered getVoipOrderType");

		String orderType = voipOrderType.substring(0, 1);

		if (OrderType.getValueReverse("DISCONNECT").equalsIgnoreCase(orderType)) {
			orderType = OrderType.getValueReverse("OUT");
		}

		LOG.info("Exit getVoipOrderType For OrderType = {}", orderType);
		return orderType;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.vz.esap.translation.order.service.helper.OrderServiceHelper#
	 * isActiveLocationPresentForBwEnterpriseId(java.lang.String, java.util.List)
	 */
	@Override
	public boolean isOtherActiveLocationPresentUnderEnterpriseInBw(String enterpriseId, List<String> excludedLocations)
			throws ApplicationInterfaceException, GenericException, TranslatorException {
		LOG.info("Entered isActiveLocationPresentForBwEnterpriseId");

		// RestTemplate restTemplate = new RestTemplate(); // commented for Unit Test
		RestTemplate restTemplate = getRestTemplate();// Added for Unit Test and it returns same new RestTemplate Object
		boolean isOtherActiveLocPresent = false;
		Map<String, String> pathvar = new HashMap<>();
		pathvar.put("EnterpriseId", enterpriseId);
		pathvar.put("locationContextPath", locDetailscontextUri);

		String url = OrderUtility.createUrl(TranslationConstant.HTTP_PROTOCOL, hostPort, entDetailscontextUri, pathvar,
				null);

		LocationResponse locationResponse = (LocationResponse) restTemplate.getForObject(url, LocationResponse.class);

		if (locationResponse == null) {
			throw new GenericException("GENERIC_EXCEPTION",
					"Generic Exception in isActiveLocationPresentForBwEnterpriseId");

		}

		if (locationResponse.getStatusCode() != 0) {
			throw new GenericException("GENERIC_EXCEPTION",
					"Generic Exception in isActiveLocationPresentForBwEnterpriseId");

		}

		if (locationResponse.getEnterprise() != null
				&& !CollectionUtils.isEmpty(locationResponse.getEnterprise().getLocation())) {

			for (Location location : locationResponse.getEnterprise().getLocation()) {
				LOG.info("BW Location Id ---> {}", location.getLocationId());

				if (isOtherActiveLocPresent) {
					break;
				}
				for (String incomingLoc : excludedLocations) {
					if (!incomingLoc.equalsIgnoreCase(location.getLocationId())) {
						isOtherActiveLocPresent = true;
						break;
					}
				}
			}
		}

		LOG.info("Exit isActiveLocationPresentForBwEnterpriseId with result as {}", isOtherActiveLocPresent);
		return isOtherActiveLocPresent;
	}

	public RestTemplate getRestTemplate() {
		// TODO Auto-generated method stub
		return new RestTemplate();
	}

	/**
	 * Todo Review Niladri/Sunil
	 * 
	 * @param voipLocationId
	 * @return void
	 * @throws TranslatorException
	 * @throws GenericException
	 */
	@Override
	public void createDeviceOrderFromInventoryDetails(VOIPOrderRequest voipOrderRequest, TblEnvOrder tblEnvOrderObject)
			throws TranslatorException, GenericException {
		LOG.info("Entered createDeviceOrderFromInventoryDetails()");
		LocationEntity locationEntityInv = null;
		String customerId = null;
		DeviceEntity deviceEntityInv = null;
		com.vz.esap.translation.order.model.Order order = null;
		com.vz.esap.translation.order.model.OrderHeader orderHeader = null;
		List<Map<String, String>> devicesByLocationId = null;
		String entityAction = null;
		TblOrder tblOrderObject = null;
		ParamInfo headerParamInfo = null;
		ParamInfo entityParamInfo = null;
		List<TblOrderService> tblOrderServiceList = null;
		long serviceCounts = -1;
		String virtualAddrCountry = null;
		try {
			locationEntityInv = getEntityDetailsFromInventory(voipOrderRequest.getOrderHeader().getVoipLocationId(),
					LocationEntity.class);

			if (locationEntityInv != null && locationEntityInv.getCustomerId() != null) {
				customerId = locationEntityInv.getCustomerId();
				LOG.info("Customer Id : {}", customerId);
				voipOrderRequest.getOrderHeader().setEnterpriseId(customerId);
			}
			if (locationEntityInv != null && locationEntityInv.getLocRegion() != null)
				virtualAddrCountry = locationEntityInv.getLocRegion();
			else
				virtualAddrCountry = "US";
			LOG.info("virtualAddrCountry - {}", virtualAddrCountry);

			devicesByLocationId = inventoryUtil
					.getDevicesFromLocationId(voipOrderRequest.getOrderHeader().getVoipLocationId());

			LOG.info("Number of Devices - {}", devicesByLocationId.size());

			for (Map<String, String> map : devicesByLocationId) {
				String deviceMapId = map.get("DEVICE_MAP_ID");
				LOG.info("Placing Order for Device - {}", deviceMapId);
				deviceEntityInv = getEntityDetailsFromInventory(deviceMapId, DeviceEntity.class);
				
				deviceEntityInv.setAsClli(voipOrderRequest.getOrderHeader().getAsClli()); //add broadsoft clli.

				order = new Order();
				orderHeader = createdOrderHeaderForDeviceOrder(voipOrderRequest, deviceEntityInv);
				orderHeader.setOrderStatus(WorkOrderEnum.Status.WO_INIT);

				// :create order
				LOG.info("Start creating orders for Device -{}", deviceMapId);

				if (null != tblEnvOrderObject.getEnvOrderId())
					orderHeader.setEnvOrderId(tblEnvOrderObject.getEnvOrderId());
				if (null != tblEnvOrderObject.getProjectId())
					orderHeader.setProjectId(tblEnvOrderObject.getProjectId());

				orderHeader.setEnvOrderId(tblEnvOrderObject.getEnvOrderId());
				orderHeader.setProjectId(tblEnvOrderObject.getProjectId());
				orderHeader.setCustomerId(tblEnvOrderObject.getEnterpriseId());
				orderHeader.setEnterpriseId(tblEnvOrderObject.getEnterpriseId());
				orderHeader.setLocationId(tblEnvOrderObject.getLocationId());
				orderHeader.setRegion(tblEnvOrderObject.getRegion());
				orderHeader.setOrderingAction(voipOrderRequest.getOrderHeader().getFunctionCode());

				entityAction = orderHeader.getEntityAction();

				order.setOrderHeader(orderHeader);
				order.setDeviceEntity(deviceEntityInv);

				tblOrderObject = enterpriseTblOrderData.prepareTblOrderDataFromOrder(order, 4L);

				voipOrderDao.createTblOrder(tblOrderObject);

				orderHeader.setFlowPath(FlowPath.valueOf(tblOrderObject.getFlowPath()));
				orderHeader.setTblOrderId(tblOrderObject.getOrderId());
				order.setOrderHeader(orderHeader);

				headerParamInfo = deviceTblOrderDetailsDataTransformerImpl.prepareTblOrderDetailsHeaderParamData(order,
						deviceEntityInv, true);

				ArrayList<DeviceEntity> deviceList = new ArrayList<>();
				deviceList.add(deviceEntityInv);

				ArrayList<ParamInfo> entityParamInfos = null;

				entityParamInfos = deviceTblOrderDetailsDataTransformerImpl
						.prepareTblOrderDetailsEntityParamDataForDevice(voipOrderRequest, tblOrderObject, deviceList);

				headerParamInfo.addChildParam(entityParamInfos.get(0));

				voipOrderDao.populateOrderDetails(tblOrderObject, headerParamInfo.getChildParams(), "o", 0, 0);

				// Craete Order Service
				tblOrderServiceList = enterpriseTblOrderServiceData.prepareTblOrderServiceData(order, null, null);

				orderHeader.setEntityAction(entityAction);

				LOG.info("Retail Order Service Count : {}", tblOrderServiceList.size());

				for (TblOrderService tblOrderService : tblOrderServiceList) {
					serviceCounts += voipOrderDao.createTblOrderService(tblOrderService);
				}

				voipOrderDao.updateTblOrderStatus(tblOrderObject.getOrderId(), WorkOrderEnum.Status.WO_INIT);
			}
			LOG.info("Leaving createDeviceOrderFromInventoryDetails()");
		} catch (TranslatorException ex) {
			LOG.error("Exception {} ", ex.getMessage());
			throw new TranslatorException(ex.getErrorCode(), ex.getMessage());
		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new GenericException(GenericException.GENERIC_EXCEPTION, "Exception in the provide input arguments");
		}
	}

	/**
	 * 
	 * @param voipLocationId
	 * @return void
	 * @throws TranslatorException
	 * @throws GenericException
	 */
	@Override
	public void createEnterpriseOrderFromInventoryDetails(VOIPOrderRequest voipOrderRequest,
			TblEnvOrder tblEnvOrderObject) throws TranslatorException, GenericException {
		LOG.info("Entered createEnterpriseOrderFromInventoryDetails()");
		String customerId = null;
		TblOrder tblOrderObject = null;
		com.vz.esap.translation.order.model.Order order = null;
		com.vz.esap.translation.order.model.Order orderPrevPass = null;
		com.vz.esap.translation.order.model.OrderHeader orderHeader = null;
		List<TblOrderService> tblOrderServiceList = null;
		long serviceCounts = -1;
		long detailCounts = -1;
		CustomerEntity customerEntityInv = null;
		LocationEntity locationEntityInv = null;
		ParamInfo headerParamInfo = null;
		ParamInfo customerParamInfo = null;
		try {
			locationEntityInv = getEntityDetailsFromInventory(voipOrderRequest.getOrderHeader().getVoipLocationId(),
					LocationEntity.class);
			if (locationEntityInv != null && locationEntityInv.getCustomerId() != null) {
				customerId = locationEntityInv.getCustomerId();
				LOG.info("Customer Id : {}", customerId);
				voipOrderRequest.getOrderHeader().setEnterpriseId(customerId);
			}
			customerEntityInv = getEntityDetailsFromInventory(voipOrderRequest.getOrderHeader().getEnterpriseId(),
					CustomerEntity.class);
			
			customerEntityInv.setAsClli(voipOrderRequest.getOrderHeader().getAsClli()); //add broadsoft clli.

			// Creating tbl order services
			orderHeader = createdOrderHeaderForEnterpriseOrder(voipOrderRequest, customerEntityInv);
			orderHeader.setOrderStatus(WorkOrderEnum.Status.WO_INIT);

			if (null != tblEnvOrderObject.getEnvOrderId())
				orderHeader.setEnvOrderId(tblEnvOrderObject.getEnvOrderId());
			if (null != tblEnvOrderObject.getProjectId())
				orderHeader.setProjectId(tblEnvOrderObject.getProjectId());

			orderHeader.setEntityType(EsapEnum.OrderEntity.ENTERPRISE.getIndex());

			order = new Order();
			order.setOrderHeader(orderHeader);
			order.setCustomerEntity(customerEntityInv);

			// Create order for Enterprise
			tblOrderObject = enterpriseTblOrderData.prepareTblOrderDataFromOrder(order, 1L);

			if (null != tblEnvOrderObject.getMinorOrderType())
				orderHeader.setMinorOrderType(tblEnvOrderObject.getMinorOrderType());

			voipOrderDao.createTblOrder(tblOrderObject);

			orderHeader.setFlowPath(FlowPath.valueOf(tblOrderObject.getFlowPath()));
			orderHeader.setTblOrderId(tblOrderObject.getOrderId());

			// Create enterprise order details
			headerParamInfo = commonTblOrderDetailsDataTransformerImpl
					.prepareTblOrderDetailsHeaderParamDataForCustomer(voipOrderRequest, tblOrderObject);

			customerParamInfo = enterpriseTblOrderDetailsData.prepareTblOrderDetailsEntityParamDataForCustomer(
					voipOrderRequest, tblOrderObject, customerEntityInv);

			headerParamInfo.addChildParam(customerParamInfo);

			voipOrderDao.populateOrderDetails(tblOrderObject, headerParamInfo.getChildParams(), "o", 0, 0);

			tblOrderServiceList = enterpriseTblOrderServiceData.prepareTblOrderServiceData(order, orderPrevPass, null);

			LOG.info("Retail Order Service Count Enterprise: {}", tblOrderServiceList.size());

			for (TblOrderService tblOrderService : tblOrderServiceList) {
				serviceCounts += voipOrderDao.createTblOrderService(tblOrderService);
			}

			voipOrderDao.updateTblOrderStatus(tblOrderObject.getOrderId(), WorkOrderEnum.Status.WO_INIT);

			LOG.info("Info {}-{}", detailCounts, serviceCounts);

			LOG.info("Leaving createEnterpriseOrderFromInventoryDetails()");
		} catch (TranslatorException ex) {
			LOG.error("Exception {} ", ex.getMessage());
			throw new TranslatorException(ex.getErrorCode(), ex.getMessage());
		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new GenericException(GenericException.GENERIC_EXCEPTION, "Exception in the provide input arguments");
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.vz.esap.translation.order.service.helper.OrderServiceHelper#
	 * getEnterpriseInformationFromGchId(java.lang.String, java.lang.String)
	 */
	@Override
	public DBServiceResponse getEnterpriseInformationFromGchId(VOIPOrderRequest voipOrderRequest,
			LocationType locationType) throws ApplicationInterfaceException, GenericException {
		LOG.info("Entered getEnterpriseInformationFromGchId(gchId, locationId)");
		DBServiceResponse dbServiceResponse = null;
		Set<String> selectColumnSet = null;
		List<String[]> whereClauseList = null;
		DBServiceResponse dbServiceResponseCustomer = null;
		String enterpriseId = null;
		Set<String> selectColumnSetEnt = null;
		List<String[]> whereClauseListEnt = null;
		List<String> enterpriseIdList = null;
		DBServiceResponse dbServiceResponseLoc = null;
		String entAvailforlocation = null;
		List<String> entAvailforlocationList = null;
		String invLocationId = null;
		boolean isLocIdMatchFound = false;
		String gchId = null;
		String locationId = null;

		try {
			gchId = voipOrderRequest.getOrderHeader().getGCHId();
			locationId = voipOrderRequest.getOrderHeader().getVoipLocationId();
			// 1. Get all Enterprise from the GCH Id
			selectColumnSet = new HashSet<>();
			selectColumnSet.add("GCH_ID");
			selectColumnSet.add("CUSTOMER_ID");

			whereClauseList = new ArrayList<>();
			whereClauseList.add(new String[] { "GCH_ID", gchId });

			dbServiceResponseCustomer = inventoryDomainDataServiceImpl.searchInventory("TBL_CUSTOMER", selectColumnSet,
					whereClauseList);

			LOG.info("Number of record from the TBL_CUSTOMER: {}", dbServiceResponseCustomer.getNumberOfRecords());

			enterpriseIdList = new ArrayList<>();
			for (TblRow tblRows : dbServiceResponseCustomer.getTableRows()) {
				enterpriseId = tblRows.getTblRow().get("CUSTOMER_ID").getValue();
				LOG.info("Enterprise Id : {}", enterpriseId);
				if (enterpriseId != null)
					enterpriseIdList.add(enterpriseId);
			}

			// enterpriseIdList contains all the enterprise for this GCHID
			LOG.info("Enterprise List size is {} for the GCHId {}", enterpriseIdList.size(), gchId);

			// 2. Get all Enterprise whose Location Type matches the Location Type of the
			// order
			if (!CollectionUtils.isEmpty(enterpriseIdList)) {

				entAvailforlocationList = new ArrayList<>();
				for (String entId : enterpriseIdList) {

					selectColumnSet = new HashSet<>();
					selectColumnSet.add("LOCATION_ID");
					selectColumnSet.add("ENTERPRISE_ID");

					whereClauseList = new ArrayList<>();
					whereClauseList.add(new String[] { "ENTERPRISE_ID", entId });
					whereClauseList.add(new String[] { "LOCATION_TYPE", String.valueOf(locationType.getIndex()) });

					dbServiceResponseLoc = inventoryDomainDataServiceImpl.searchInventory("TBL_LOCATION",
							selectColumnSet, whereClauseList);

					for (TblRow tblRows : dbServiceResponseLoc.getTableRows()) {
						entAvailforlocation = tblRows.getTblRow().get("ENTERPRISE_ID").getValue();
						invLocationId = tblRows.getTblRow().get("LOCATION_ID").getValue();

						LOG.info(
								"From multiple Enterprises the Enterprise Id with Location present is : {} and locationType : {} and Location Id : {}",
								entAvailforlocation, locationType, invLocationId);

						if (invLocationId.equalsIgnoreCase(locationId)) {
							entAvailforlocationList = new ArrayList<>();

							if (entAvailforlocation != null)
								entAvailforlocationList.add(entAvailforlocation);
							isLocIdMatchFound = true;
							break;

						} else {
							entAvailforlocationList.add(entAvailforlocation);

						}
					}
					// entAvailforlocationList contains all the enterprise whose Location Type
					// matches the Location Type of the Order
					LOG.info("Location List size is {} for the GCHId {}, Location Type {}",
							entAvailforlocationList.size(), gchId, locationType);

					if (isLocIdMatchFound) {
						break;
					}
				}
			}

			// 3. Get all Enterprise details whose Location Type matches the Location Type
			// of the order

			// sonar Fix added && entAvailforlocationList.get(0)!=null
			// in Sonar NullPointerException might be thrown as 'entAvailforlocationList' is
			// nullable here
			if (entAvailforlocationList != null && entAvailforlocationList.size() > 0) {

				LOG.info("Enterprise is present ");
				selectColumnSetEnt = new HashSet<>();
				selectColumnSetEnt.add("ENTERPRISE_ID");
				selectColumnSetEnt.add("BW_ENTERPRISE_ID");
				selectColumnSetEnt.add("ENV_ORDER_ID");

				whereClauseListEnt = new ArrayList<>();
				whereClauseListEnt.add(new String[] { "ENTERPRISE_ID", entAvailforlocationList.get(0) });

				dbServiceResponse = inventoryDomainDataServiceImpl.searchInventory("TBL_ENTERPRISE", selectColumnSetEnt,
						whereClauseListEnt);
			}

			// Install order enterprise should be used in change order as well.
			if ("C".equalsIgnoreCase(voipOrderRequest.getOrderHeader().getOrderType())) {
				LOG.info("Same Enterprise should be used in Change Order");
				Map<String, String> locRows = null;
				String voipLocationId = null;
				voipLocationId = voipOrderRequest.getOrderHeader().getVoipLocationId();
				LOG.info("voipLocationId::{}", voipLocationId);
				locRows = inventoryUtil.getTblLocationFromLocationId(voipLocationId, null, null);
				if (locRows != null && locRows.get("ENTERPRISE_ID") != null) {
					enterpriseId = locRows.get("ENTERPRISE_ID");
					LOG.info("Enterprise Id for Install order fetched from Inventory :: {}", enterpriseId);
				}

				LOG.info("Enterprise is present :: Change Order ");
				selectColumnSetEnt = new HashSet<>();
				selectColumnSetEnt.add("ENTERPRISE_ID");
				selectColumnSetEnt.add("BW_ENTERPRISE_ID");
				selectColumnSetEnt.add("ENV_ORDER_ID");

				whereClauseListEnt = new ArrayList<>();
				whereClauseListEnt.add(new String[] { "ENTERPRISE_ID", enterpriseId });

				dbServiceResponse = inventoryDomainDataServiceImpl.searchInventory("TBL_ENTERPRISE", selectColumnSetEnt,
						whereClauseListEnt);
			}

			if (dbServiceResponse == null) {

				dbServiceResponse = new DBServiceResponse();
				dbServiceResponse.setNumberOfRecords(0L);

			}

		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new GenericException(GenericException.GENERIC_EXCEPTION,
					"Exception occured in getEnterpriseInformationFromGchId");
		}

		LOG.info("Exit getEnterpriseInformationFromGchId(gchId, locationId)");
		return dbServiceResponse;

	}

	@Override
	public VoipOrderResponse createTnPortActivationOrder(VOIPOrderRequest voipOrderRequest,
			Map<String, String> productDetails) throws TranslatorException, GenericException {
		LOG.info("Entered createTnPortActivationOrder for Solution Type = {}",
				voipOrderRequest.getOrderHeader().getSolutionType());

		VoipOrderResponse voipOrderResponse = null;
		long sequenceNumber = -1;
		TblSafeStore tblSafeStoreObject = null;
		TblEnvOrder tblEnvOrderObject = null;
		String virtualAddrCountry = null;
		String customerId = null;
		DBServiceResponse dbServiceResponse = null;

		try {

			if (voipOrderRequest.getOrderHeader().getGCHId() == null)
				throw new TranslatorException(ErrorCode.ESAP_MISSING_REQUIRED_DATA,
						"GCHID is not present in the request BOD");
			dbServiceResponse = getEnterpriseInformationFromGchId(voipOrderRequest.getOrderHeader().getGCHId());

			voipOrderRequest = voipRequestTransformerImpl.modifyOrderHeader(voipOrderRequest, dbServiceResponse, false,
					productDetails);

			LocationEntity locationEntityInv = getEntityDetailsFromInventory(
					voipOrderRequest.getOrderHeader().getVoipLocationId(), LocationEntity.class);

			if (locationEntityInv != null && locationEntityInv.getLocRegion() != null)
				virtualAddrCountry = locationEntityInv.getLocRegion();
			else
				virtualAddrCountry = "US";

			LOG.info("EblOrderServiceImpl:: virtualAddrCountry - {}", virtualAddrCountry);
			voipOrderRequest.getOrderHeader().setRegion(virtualAddrCountry);

			if (locationEntityInv != null && locationEntityInv.getCustomerId() != null) {
				customerId = locationEntityInv.getCustomerId();
				LOG.info("Customer Id : {}", customerId);
				voipOrderRequest.getOrderHeader().setEnterpriseId(customerId);
			}

			sequenceNumber = voipOrderRequest.getSequenceNumber();
			LOG.info("TblSafeOrder  SequenceNo : {}", sequenceNumber);

			// Update TblSafeStore
			tblSafeStoreObject = tblSafeStoreTransformer.prepareTblSafeStoreData(sequenceNumber);
			voipOrderDao.updateTblSafeStoreTranslationStartTime(tblSafeStoreObject);

			// Create Env Order

			if (SolutionType.ESIP_EBL.equals(voipOrderRequest.getOrderHeader().getSolutionType())) {
				tblEnvOrderObject = createEsipEblEnvOrder(voipOrderRequest, WorkOrderEnum.Status.WO_RECV_SEGMENT);

			} else if (SolutionType.IPFLEX.equals(voipOrderRequest.getOrderHeader().getSolutionType())) {
				tblEnvOrderObject = createIpFlexEnvOrder(voipOrderRequest, WorkOrderEnum.Status.WO_RECV_SEGMENT);

			} else if (SolutionType.HPBX.equals(voipOrderRequest.getOrderHeader().getSolutionType())) {
				tblEnvOrderObject = createHpbxEnvOrder(voipOrderRequest, WorkOrderEnum.Status.WO_RECV_SEGMENT);

			}

			createTNOrderFromInventoryDetails(voipOrderRequest, tblEnvOrderObject);
			LOG.info("TN order is placed");

			voipOrderResponse = voipResponseGenerator.prepareSuccessOrderResponse(voipOrderRequest);

			voipOrderDao.createParentChildOrderRelationship(tblEnvOrderObject);

			if (tblEnvOrderObject != null && tblEnvOrderObject.getEnvOrderId() != null) {
				voipOrderDao.updateTblEnvOrderStatus(tblEnvOrderObject.getEnvOrderId(), WorkOrderEnum.Status.WO_INIT);
			}

			notificationServiceImpl.notifySuccess(voipResponseGenerator.preparePCMilestone(voipOrderRequest,
					PcMilestone.ORDER_ACCEPTANCE.getValue(), StatusCode.ESP_SUCCESS, PcResponseType.ORDER.getValue()));

		} catch (TranslatorException ex) {
			LOG.error("Exception {} ", ex.getMessage());
			throw new TranslatorException(ex.getErrorCode(), ex.getMessage());

		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new GenericException(GenericException.GENERIC_EXCEPTION,
					"Generic Exception in createTnPortActivationOrder");

		}
		LOG.info("Exiting createTnPortActivationOrder");
		return voipOrderResponse;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.vz.esap.translation.order.service.helper.OrderServiceHelper#
	 * getMatchingValidationEnvOrder(com.vz.esap.translation.order.model.request.
	 * VOIPOrderRequest)
	 */
	@Override
	public boolean isEnterpriseCreatedInPreviousOrder(VOIPOrderRequest voipOrderRequest) throws GenericException {
		boolean enterpriseCreatedinPerviousVer = false;
		TblEnvOrder tblEnvOrderObject = null;
		List<TblEnvOrder> tblEnvOrders = null;
		LOG.info("Entered isEnterpriseCreatedInPreviousOrder");

		try {
			tblEnvOrderObject = new TblEnvOrder();
			tblEnvOrderObject.setOrderNumber(voipOrderRequest.getOrderHeader().getWorkOrderNumber());
			if (voipOrderRequest.getOrderHeader().getMasterOrderNumber() != null)
				tblEnvOrderObject.setMasterOrderNumber(voipOrderRequest.getOrderHeader().getMasterOrderNumber());
			if (voipOrderRequest.getOrderHeader().getRegion() == null) {
				tblEnvOrderObject.setRegion("US");
			} else {
				tblEnvOrderObject.setRegion(voipOrderRequest.getOrderHeader().getRegion());
			}
			tblEnvOrderObject.setOrderClassify(Long.valueOf(WorkOrderEnum.OrderClassify.RELEASE));
			if (null != voipOrderRequest.getOrderHeader().getCentrexType() && OrderUtility
					.isOneOf(voipOrderRequest.getOrderHeader().getCentrexType(), true, "IPAC", "IPAC1", "IPAC2")) {
				tblEnvOrderObject.setProjectId("RA");
			} else {
				tblEnvOrderObject.setProjectId("R");
			}
			//tblEnvOrderObject.setVersionNumber(0L); // always check for for version zero;
			int currentVersion = Integer.parseInt(voipOrderRequest.getOrderHeader().getWorkOrderVersion());
			if(currentVersion > 0) {
				VOIPOrderRequest voipOrderRequestPrev = orderParserImpl.getCorrectPrevPassVoipOrderRequest(voipOrderRequest);
				tblEnvOrderObject.setVersionNumber(Long.parseLong(voipOrderRequestPrev.getOrderHeader().getWorkOrderVersion())); // check for previous version;
			} else {
				tblEnvOrderObject.setVersionNumber(0L);
			}

			tblEnvOrders = voipOrderDao.getTableEnvOrder(tblEnvOrderObject);

			if (!tblEnvOrders.isEmpty() && tblEnvOrders.get(0) != null) {
				// get the Enterprise entity if one created for this env order
				List<TblOrder> tblOrderList = null;
				TblOrder tblOrder = null;
				tblOrder = new TblOrder();
				tblOrder.setEnvOrderId(tblEnvOrders.get(0).getEnvOrderId());
				tblOrderList = voipOrderDao.getPrevTblOrder(tblOrder, OrderEntity.ENTERPRISE);
				if (!tblOrderList.isEmpty() && tblOrderList.get(0) != null) {
					LOG.info("isEnterpriseCreatedInPreviousOrder:: V0 order does have entrprise entity for env order"
							+ tblEnvOrders.get(0).getEnvOrderId());
					enterpriseCreatedinPerviousVer = true;
				}
			}

		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new GenericException(GenericException.GENERIC_EXCEPTION,
					"Exception occured in isEnterpriseCreatedInPreviousOrder");
		}
		LOG.info("Exit isEnterpriseCreatedInPreviousOrder");

		return enterpriseCreatedinPerviousVer;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.vz.esap.translation.order.service.helper.OrderServiceHelper#
	 * updateTblEnvOrderStatusWithCurrOrdFlow(com.vz.esap.translation.order.model.
	 * request.VOIPOrderRequest, java.lang.Long)
	 */
	@Override
	public void updateTblEnvOrderStatusWithCurrOrdFlow(VOIPOrderRequest voipOrderRequestCurrent, Long tblEnvOrderId) {// throws
																														// GenericException
																														// {
		LOG.info("Entered updateTblEnvOrderStatusWithCurrOrdFlow.\n currentEnvOrderId::{}", tblEnvOrderId);

		List<TblEnvOrder> tblEnvOrderListCurrent = null;
		List<TblOrder> tblOrderListCurrent = null;
		try {

			tblEnvOrderListCurrent = getMatchingPrevPassEnvOrder(voipOrderRequestCurrent, 0, 0);
			tblOrderListCurrent = getMatchingPrevPassOrder(tblEnvOrderListCurrent.get(0), null);

			updateOverAllTblEnvStatus(tblOrderListCurrent, tblEnvOrderId, voipOrderRequestCurrent);

		} catch (Exception e) {
			LOG.info("Exception {} ", e.getMessage());
			voipOrderDao.updateTblEnvOrderStatus(tblEnvOrderId, WorkOrderEnum.Status.WO_INIT);
			// throw new GenericException(GenericException.GENERIC_EXCEPTION,
			// "Exception occured in updateTblEnvOrderStatusWithPrevOrdFlow");
		}
		LOG.info("Exit updateTblEnvOrderStatusWithCurrOrdFlow");

	}

	/**
	 * @param tblOrderList
	 * @param tblEnvOrderId
	 */
	public void updateOverAllTblEnvStatus(List<TblOrder> tblOrderList, Long tblEnvOrderId, VOIPOrderRequest voipOrderRequest) {
		LOG.info("Enter updateOverAllTblEnvStatus");
		int status = WorkOrderEnum.Status.WO_INIT;
		String workGroup = null;
		boolean init = false;
		boolean failed = false;
		boolean complete = true;

		try {
			for (TblOrder tblOrder : tblOrderList) {
				 if(tblOrder.getOrderStatus() == WorkOrderEnum.Status.WO_FAILED ) {
					 failed = true; 
					 break;
				 } 
			}
			
			for (TblOrder tblOrder : tblOrderList) {
				 if(tblOrder.getOrderStatus() == WorkOrderEnum.Status.WO_INIT) {
					 init = true; 
					 break;
				 }
			}
								
			for (TblOrder tblOrder : tblOrderList) {
				 if(tblOrder.getOrderStatus() != WorkOrderEnum.Status.WO_COMPLETE) {
					 complete = false;
					 break;
				 }
			}
			
			
			if(failed) {
				status = WorkOrderEnum.Status.WO_FAILED;
				try {
				workGroup = getPrevEnvOrderWorkGroup(voipOrderRequest);
				} catch(Exception e1) {
					workGroup = null;
					LOG.info("Exception {} ", e1.getMessage());
				}
			} else if(init) {
				status = WorkOrderEnum.Status.WO_INIT;
			} else if(complete) {
				status = WorkOrderEnum.Status.WO_COMPLETE;
			}
			
			voipOrderDao.updateTblEnvOrderStatusAndWorkGroup(tblEnvOrderId, status, workGroup);
		} catch (Exception e) {
			LOG.info("Exception {} ", e.getMessage());
		}
		LOG.info("Exit updateOverAllTblEnvStatus");
	}
	
	/**
	 * @param voipOrderRequest
	 * @return 
	 * @throws GenericException 
	 */
	public String  getPrevEnvOrderWorkGroup(VOIPOrderRequest voipOrderRequest) throws GenericException{
		List<TblEnvOrder> tblEnvOrders = getPrevPassEnvOrder(voipOrderRequest);
		if(!CollectionUtils.isEmpty(tblEnvOrders)) {
			return tblEnvOrders.get(0).getWorkGroup();
		} else {
			return null;
		}
	}
	
	/* (non-Javadoc)
	 * @see com.vz.esap.translation.order.service.helper.OrderServiceHelper#handleOrdersInProgress(com.vz.esap.translation.order.model.request.VOIPOrderRequest)
	 */
	public void handleOrdersInProgress(VOIPOrderRequest voipOrderRequest) throws TranslatorException, GenericException {
		LOG.info("Entered handleOrdersInProgress");
		
		List<TblEnvOrder> tblEnvOrderListPrev = null;
		TblEnvOrder tblEnvOrderObject = null;
		
		try {
			int orderVersion = Integer.parseInt(voipOrderRequest.getOrderHeader().getWorkOrderVersion());
			VOIPOrderRequest voipOrderRequestPrev = orderParserImpl.getCorrectPrevPassVoipOrderRequest(voipOrderRequest);
			//voipOrderRequestPrev.getOrderHeader().setWorkOrderVersion(Integer.toString(orderVersion - 1));
			//Getting previous version env order
			tblEnvOrderListPrev = getMatchingPrevPassEnvOrder(voipOrderRequestPrev, 0,
					WorkOrderEnum.OrderClassify.RELEASE);
			
			LOG.info("Order:: {} :: Version :: {} :: ProductType :: {} :: EnvOrderId :: status :: {}", 
						voipOrderRequest.getOrderHeader().getWorkOrderNumber(),
						voipOrderRequest.getOrderHeader().getWorkOrderVersion(),
						voipOrderRequest.getOrderHeader().getSolutionType().toString(),
						tblEnvOrderListPrev.get(0).getEnvOrderId(),
						tblEnvOrderListPrev.get(0).getOrderStatus()
					);
			if(WorkOrderEnum.Status.WO_IN_PROGRESS == tblEnvOrderListPrev.get(0).getOrderStatus()
					|| WorkOrderEnum.Status.WO_INIT == tblEnvOrderListPrev.get(0).getOrderStatus()
					|| WorkOrderEnum.Status.WO_RELEASED == tblEnvOrderListPrev.get(0).getOrderStatus()
					|| WorkOrderEnum.Status.WO_SCHEDULED == tblEnvOrderListPrev.get(0).getOrderStatus()
					) {
				LOG.info("Order:: {} is \"InProgress\" status :: EnvOrderId :: {}", voipOrderRequest.getOrderHeader().getWorkOrderNumber(), tblEnvOrderListPrev.get(0).getEnvOrderId());
				//Creating Env order record.
				if(SolutionType.ESIP_ESL.toString().equalsIgnoreCase(voipOrderRequest.getOrderHeader().getSolutionType().toString())) {
					tblEnvOrderObject = createEsipEslEnvOrder(voipOrderRequest, WorkOrderEnum.Status.WO_TRANSLATION_FAIL);
				} else if(SolutionType.ESIP_EBL.toString().equalsIgnoreCase(voipOrderRequest.getOrderHeader().getSolutionType().toString())) {
					tblEnvOrderObject = createEsipEblEnvOrder(voipOrderRequest, WorkOrderEnum.Status.WO_TRANSLATION_FAIL);
				} else if(SolutionType.IPFLEX.toString().equalsIgnoreCase(voipOrderRequest.getOrderHeader().getSolutionType().toString())) {
					tblEnvOrderObject = createIpFlexEnvOrder(voipOrderRequest, WorkOrderEnum.Status.WO_TRANSLATION_FAIL);
				} else if(SolutionType.HPBX.toString().equalsIgnoreCase(voipOrderRequest.getOrderHeader().getSolutionType().toString())) {
					tblEnvOrderObject = createHpbxEnvOrder(voipOrderRequest, WorkOrderEnum.Status.WO_TRANSLATION_FAIL);
				}
				
				if(tblEnvOrderObject != null && tblEnvOrderObject.getEnvOrderId() != null) {
				//Update Error Code.
				voipOrderDaoImpl.updateTblEnvOrderError(tblEnvOrderObject.getEnvOrderId(), "TRAN_0001");
				}
			
				LOG.error("Supp is not allowed when previous order is in PROGRESS");
				throw new GenericException("TRAN_0001", "Previous order in progress");
			} else {
				LOG.info("Order is not \"InProgress\" status, Status is :: {}", tblEnvOrderListPrev.get(0).getOrderStatus());
			}
		} catch (TranslatorException ex) {
			LOG.error("Exception {} {} ", ex.getMessage(), ex);
			throw new TranslatorException(ex.getErrorCode(), ex.getMessage());
		} catch (Exception e) {
			LOG.error("Exception {} {}", e.getMessage(), e);
			throw new GenericException(GenericException.GENERIC_EXCEPTION, "Exception in handleOrdersInProgress");
		}
		
		LOG.info("Exit handleOrdersInProgress");
	}
	
	@Override
	public ParamInfo updateParamInfoForLocationid(long tblEnvOrderId, ParamInfo paramInfo,
			com.vz.esap.translation.order.model.OrderHeader orderHeader)
			throws ApplicationInterfaceException, GenericException {
		LOG.info("Enter updateParamInfoForLocationid enter paraminfo" + paramInfo );
		if(orderHeader.getSolutionType().equals(SolutionType.HPBX)) {
			TblOrder tblordertemp = new TblOrder();
			tblordertemp.setEnvOrderId(tblEnvOrderId);
			List<TblOrder> tbLorderList = voipOrderDao.getPrevTblOrder(tblordertemp, OrderEntity.LOCATION);
			if(null != tbLorderList && !tbLorderList.isEmpty()) {			
				for(TblOrder tblOrderRec : tbLorderList) {
					LOG.info("Enter updateParamInfoForLocationid got location orders" + tblOrderRec );
					List<TblOrderDetails> tblOrderDetailList = voipOrderDaoImpl.getOrderDetailsEntriesPerOrder(tblOrderRec);
					if(null !=  tblOrderDetailList) {
						for(TblOrderDetails tblOrderDetail : tblOrderDetailList) {
							LOG.info("Enter updateParamInfoForLocationid got table order details" + tblOrderDetail );
							if(tblOrderDetail.getParamName().equalsIgnoreCase("TypeOfLoc")) {
								if(null != tblOrderDetail.getParamValue() && "HPBX_ECH".equalsIgnoreCase(tblOrderDetail.getParamValue())) {
									LOG.info("Enter updateParamInfoForLocationid got location type as HPBX ECH change params" + tblOrderDetail );
									paramInfo.removeChildParam("LocationId");
									paramInfo.addNotNullValChild("LocationId", tblOrderRec.getAccountNumber(), orderHeader.getOrderType());
									LOG.info("UpdateParamInfoForLocationid exit paraminfo" + paramInfo );
									return paramInfo;
								}
								break;				
							}
						}
					}
					
				}
			}
		}
		
		LOG.info("UpdateParamInfoForLocationid exit paraminfo" + paramInfo );
		return paramInfo;
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.vz.esap.translation.order.service.helper.OrderServiceHelper#
	 * getPrevPassEnvOrder(com.vz.esap.translation.order.model.request.
	 * VOIPOrderRequest)
	 */
	@Override
	public List<TblEnvOrder> getPrevPassEnvOrder(VOIPOrderRequest voipOrderRequest) throws GenericException {
	
		TblEnvOrder tblEnvOrderObject = null;
		List<TblEnvOrder> tblEnvOrders = null;
		LOG.info("Entered getPrevPassEnvOrder");

		try {
			tblEnvOrderObject = new TblEnvOrder();
			tblEnvOrderObject.setOrderNumber(voipOrderRequest.getOrderHeader().getWorkOrderNumber());
			tblEnvOrderObject.setVersionNumber(Long.parseLong(voipOrderRequest.getOrderHeader().getWorkOrderVersion()));
			if (voipOrderRequest.getOrderHeader().getRegion() == null) {
				tblEnvOrderObject.setRegion("US");
			} else {
				tblEnvOrderObject.setRegion(voipOrderRequest.getOrderHeader().getRegion());
			}
			if(voipOrderRequest.getOrderHeader().getFunctionCode() == null) {
				tblEnvOrderObject.setOrderClassify(Long.valueOf(WorkOrderEnum.OrderClassify.RELEASE));
			} else if(voipOrderRequest.getOrderHeader().getFunctionCode().equals((WorkOrderEnum.OrderClassify.name(WorkOrderEnum.OrderClassify.VALIDATE)))){
				tblEnvOrderObject.setOrderClassify(Long.valueOf(WorkOrderEnum.OrderClassify.VALIDATE));
			} else if(voipOrderRequest.getOrderHeader().getFunctionCode().equals((WorkOrderEnum.OrderClassify.name(WorkOrderEnum.OrderClassify.RELEASE)))){
				tblEnvOrderObject.setOrderClassify(Long.valueOf(WorkOrderEnum.OrderClassify.RELEASE));
			} else {
				tblEnvOrderObject.setOrderClassify(Long.valueOf(WorkOrderEnum.OrderClassify.RELEASE));
			}
			if (null != voipOrderRequest.getOrderHeader().getCentrexType() && OrderUtility
					.isOneOf(voipOrderRequest.getOrderHeader().getCentrexType(), true, "IPAC", "IPAC1", "IPAC2")) {
				tblEnvOrderObject.setProjectId("RA");
			} else {
				tblEnvOrderObject.setProjectId("R");
			}
			

			tblEnvOrders = voipOrderDao.getPrevVersionTableEnvOrder(tblEnvOrderObject);

		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new GenericException(GenericException.GENERIC_EXCEPTION,
					"Exception occured in isEnterpriseCreatedInPreviousOrder");
		}
		LOG.info("Exit getPrevPassEnvOrder");

		return tblEnvOrders;
	}
	
	@Override
	public void insertEnterpriseFlagintoTOD(TblEnvOrder tblEnvOrderObject, String param_name, String param_value) throws TranslatorException, GenericException {
		
		LOG.info("Enter insertEnterpriseFlagInotTOD : {}, With param_name :{},param_value:{} ",tblEnvOrderObject,param_name,param_value);
		TblOrder order =new TblOrder();
		order.setEnvOrderId(tblEnvOrderObject.getEnvOrderId());
		List<TblOrder> orderList=voipOrderDao.getTblOrder(order);
		if(!CollectionUtils.isEmpty(orderList)) {
		for(TblOrder tblorder:orderList)
		{
			if(tblorder.getUpstreamTaskId()!=null && tblorder.getUpstreamTaskId()==3)
			{
			List<TblOrderDetails> tblOrderDetailsList = getMatchingOrderDetails(tblorder);
			if(!CollectionUtils.isEmpty(tblOrderDetailsList)) {
				TblOrderDetails  tblOrderDetails=	tblOrderDetailsList.get(0);
				voipOrderDao.createTblOrderDetails(tblOrderDetails,param_name,param_value);
			}
			}
		}
			
		}
		
		LOG.info("Exit insertEnterpriseFlagInotTOD : {}, With param_name :{},param_value:{} ",tblEnvOrderObject,param_name,param_value);
	}
}
