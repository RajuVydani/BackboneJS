package com.vz.esap.translation.dao.repository;

import java.util.List;
import java.util.Map;

import com.vz.esap.translation.dao.model.TblOrderDetails;

public interface CustomTblOrderDetailsMapper extends TblOrderDetailsMapper {

	public long insertOrderDetail(TblOrderDetails tblOrderDeatilsObject);

	public long getOrdDtlIdNextVal();

	public List<TblOrderDetails> getTblOrderDetailsEntities(TblOrderDetails tblOrderDetails);

	public List<TblOrderDetails> getOrderDetailsForDefiniteActionAndParentId(TblOrderDetails tblOrderDetails);

	public List<TblOrderDetails> getOrderDetailsForDefiniteActionAndParentName(TblOrderDetails tblOrderDetails);

	public List<TblOrderDetails> getOrderDetailsForDefiniteActionAndNoParent(TblOrderDetails tblOrderDetails);

	public List<TblOrderDetails> getOrderDetailsForNoActionAndParentId(TblOrderDetails tblOrderDetails);

	public List<TblOrderDetails> getOrderDetailsForNoActionAndParentName(TblOrderDetails tblOrderDetails);

	public List<TblOrderDetails> getOrderDetailsForNoActionAndNoParent(TblOrderDetails tblOrderDetails);

	public List<TblOrderDetails> getTblOrderDetailsTNEntities(TblOrderDetails tblOrderDetails);

	public List<TblOrderDetails> getOrderDetailParam(Map<String, Object> params);
	
	public List<TblOrderDetails> getTblOrderDetailsForOrder(Map<String, Object> params);

}