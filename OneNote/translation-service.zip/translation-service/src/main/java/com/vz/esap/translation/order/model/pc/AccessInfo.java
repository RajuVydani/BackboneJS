package com.vz.esap.translation.order.model.pc;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

@XmlAccessorType(XmlAccessType.FIELD)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
public class AccessInfo {
	
	@XmlElement(name = "EBIId")
	@JsonProperty(value = "EBIId")
	private String ebiId;

	@XmlElement(name = "AccessType")
	@JsonProperty(value = "AccessType")
	private String accessType;

	@XmlElement(name = "PVCServiceInstanceId")
	@JsonProperty(value = "PVCServiceInstanceId")
	private String pvcServiceInstanceId;

	public String getEBIId() {
		return ebiId;
	}

	public void setEBIId(String EBIId) {
		this.ebiId = EBIId;
	}

	public String getAccessType() {
		return accessType;
	}

	public void setAccessType(String AccessType) {
		this.accessType = AccessType;
	}

	public String getPVCServiceInstanceId() {
		return pvcServiceInstanceId;
	}

	public void setPVCServiceInstanceId(String PVCServiceInstanceId) {
		this.pvcServiceInstanceId = PVCServiceInstanceId;
	}

	@Override
	public String toString() {
		return "ClassPojo [EBIId = " + ebiId + ", AccessType = " + accessType + ", PVCServiceInstanceId = "
				+ pvcServiceInstanceId + "]";
	}
}
