package com.vz.esap.translation.dao.repository;

import java.util.Map;

import com.vz.esap.translation.dao.model.TblEnvOrder;

public interface CustomTblEnvOrderMapper extends TblEnvOrderMapper {
	long createEnvelopOrder(TblEnvOrder tblEnvOrderObject);

	void updateTblEnvOrderStatus(Map<String, Object> params);

}