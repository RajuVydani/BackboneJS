
package com.vz.esap.translation.connector.dto;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "columnValues", "inClauseList", "queryReferenceId", "sourceService", "sqlKey" })
public class DBOperationRequest {

	@JsonProperty("columnValues")
	private List<String> columnValues = new ArrayList<String>();

	/*
	 * @JsonProperty("inClauseList") private List<InClauseList> inClauseList = new
	 * ArrayList<InClauseList>();
	 */

	@JsonProperty("queryReferenceId")
	private Long queryReferenceId;

	@JsonProperty("sourceService")
	private String sourceService;

	@JsonProperty("sqlKey")
	private String sqlKey;

	@JsonIgnore
	private Map<String, Object> additionalProperties = new HashMap<String, Object>();

	@JsonProperty("columnValues")
	public List<String> getColumnValues() {
		return columnValues;
	}

	@JsonProperty("columnValues")
	public void setColumnValues(List<String> columnValues) {
		this.columnValues = columnValues;
	}

	/*
	 * @JsonProperty("inClauseList") public List<InClauseList> getInClauseList() {
	 * return inClauseList; }
	 * 
	 * @JsonProperty("inClauseList") public void setInClauseList(List<InClauseList>
	 * inClauseList) { this.inClauseList = inClauseList; }
	 */

	@JsonProperty("queryReferenceId")
	public Long getQueryReferenceId() {
		return queryReferenceId;
	}

	@JsonProperty("queryReferenceId")
	public void setQueryReferenceId(Long queryReferenceId) {
		this.queryReferenceId = queryReferenceId;
	}

	@JsonProperty("sourceService")
	public String getSourceService() {
		return sourceService;
	}

	@JsonProperty("sourceService")
	public void setSourceService(String sourceService) {
		this.sourceService = sourceService;
	}

	@JsonProperty("sqlKey")
	public String getSqlKey() {
		return sqlKey;
	}

	@JsonProperty("sqlKey")
	public void setSqlKey(String sqlKey) {
		this.sqlKey = sqlKey;
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}

	@JsonAnyGetter
	public Map<String, Object> getAdditionalProperties() {
		return this.additionalProperties;
	}

	@JsonAnySetter
	public void setAdditionalProperty(String name, Object value) {
		this.additionalProperties.put(name, value);
	}

	/*
	 * @Override public int hashCode() { return new
	 * HashCodeBuilder().append(columnValues).append(inClauseList).append(
	 * queryReferenceId).append(sourceService).append(sqlKey).append(
	 * additionalProperties).toHashCode(); }
	 */

	/*
	 * @Override public boolean equals(Object other) { if (other == this) { return
	 * true; } if ((other instanceof DBOperationRequest) == false) { return false; }
	 * DBOperationRequest rhs = ((DBOperationRequest) other); return new
	 * EqualsBuilder().append(columnValues, rhs.columnValues).append(inClauseList,
	 * rhs.inClauseList).append(queryReferenceId,
	 * rhs.queryReferenceId).append(sourceService, rhs.sourceService).append(sqlKey,
	 * rhs.sqlKey).append(additionalProperties,
	 * rhs.additionalProperties).isEquals(); }
	 */

}
