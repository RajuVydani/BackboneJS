package com.vz.esap.translation.order.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.vz.esap.translation.dao.model.TblOrder;
import com.vz.esap.translation.entity.DeviceEntity;
import com.vz.esap.translation.enums.EsapEnum.OrderEntity;
import com.vz.esap.translation.enums.EsapEnum.RollbackReason;
import com.vz.esap.translation.order.model.Order;
import com.vz.esap.translation.order.model.RollbackOrder;
import com.vz.esap.translation.order.transformer.DeviceTransformer;

import esap.db.TblOrderServiceDbBean;

@Service
public class RollbackOrderService extends Order {
	
	@Autowired
	DeviceTransformer DeviceTransformerImpl;

	public RollbackOrder rollbackOrder(TblOrder prevOrder, RollbackReason reason) {

		RollbackOrder rollbackOrder = validate(prevOrder);

		return rollbackOrder;
	}

	public RollbackOrder validate(TblOrder prevOrder) {
		
		//TODO Implementation pending

		return null;
	}

}
