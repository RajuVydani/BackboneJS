package com.vz.esap.translation.order.model.request;

public class Location {

	private String Name;

	private PrimaryLocationContact PrimaryLocationContact;

	private String ActionCode;

	private String Type;

	private OrderManagerContact OrderManagerContact;

	private LocationAddress LocationAddress;

	private String Id;

	private SalesManagerContact SalesManagerContact;

	public String getName() {
		return Name;
	}

	public void setName(String Name) {
		this.Name = Name;
	}

	public PrimaryLocationContact getPrimaryLocationContact() {
		return PrimaryLocationContact;
	}

	public void setPrimaryLocationContact(PrimaryLocationContact PrimaryLocationContact) {
		this.PrimaryLocationContact = PrimaryLocationContact;
	}

	public String getActionCode() {
		return ActionCode;
	}

	public void setActionCode(String ActionCode) {
		this.ActionCode = ActionCode;
	}

	public String getType() {
		return Type;
	}

	public void setType(String Type) {
		this.Type = Type;
	}

	public OrderManagerContact getOrderManagerContact() {
		return OrderManagerContact;
	}

	public void setOrderManagerContact(OrderManagerContact OrderManagerContact) {
		this.OrderManagerContact = OrderManagerContact;
	}

	public LocationAddress getLocationAddress() {
		return LocationAddress;
	}

	public void setLocationAddress(LocationAddress LocationAddress) {
		this.LocationAddress = LocationAddress;
	}

	public String getId() {
		return Id;
	}

	public void setId(String Id) {
		this.Id = Id;
	}

	public SalesManagerContact getSalesManagerContact() {
		return SalesManagerContact;
	}

	public void setSalesManagerContact(SalesManagerContact SalesManagerContact) {
		this.SalesManagerContact = SalesManagerContact;
	}

	public String toString() {
		return "ClassPojo [Name = " + Name + ", PrimaryLocationContact = " + PrimaryLocationContact + ", ActionCode = "
				+ ActionCode + ", Type = " + Type + ", OrderManagerContact = " + OrderManagerContact
				+ ", LocationAddress = " + LocationAddress + ", Id = " + Id + ", SalesManagerContact = "
				+ SalesManagerContact + "]";
	}
}
