package com.vz.esap.translation.order.transformer;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.vz.esap.translation.constant.TranslationConstant;
import com.vz.esap.translation.dao.model.TblOrderDetails;
import com.vz.esap.translation.entity.AccountAuthCode;
import com.vz.esap.translation.entity.CallingPlanEntity;
import com.vz.esap.translation.entity.ECMInfo;
import com.vz.esap.translation.entity.EmergencyCodeInfo;
import com.vz.esap.translation.entity.GCMInfo;
import com.vz.esap.translation.entity.GCMPricingInfo;
import com.vz.esap.translation.entity.IncomingCallingPlan;
import com.vz.esap.translation.entity.LocationEntity;
import com.vz.esap.translation.entity.LocationEntity.TypeOfLocEnum;
import com.vz.esap.translation.entity.OutgoingCallingPlan;
import com.vz.esap.translation.entity.ParamInfo;
import com.vz.esap.translation.entity.Session;
import com.vz.esap.translation.entity.VmAccess;
import com.vz.esap.translation.enums.EsapEnum;
import com.vz.esap.translation.enums.EsapEnum.AuthFeatureType;
import com.vz.esap.translation.enums.EsapEnum.RedundancyPriorityType;
import com.vz.esap.translation.enums.EsapEnum.RedundancyType;
import com.vz.esap.translation.enums.EsapEnum.SolutionType;
import com.vz.esap.translation.exception.ApplicationInterfaceException;
import com.vz.esap.translation.exception.GenericException;
import com.vz.esap.translation.exception.TranslatorException;
import com.vz.esap.translation.exception.TranslatorException.ErrorCode;
import com.vz.esap.translation.order.dao.VOIPOrderDao;
import com.vz.esap.translation.order.model.request.CallingPlan.CallTypeEnum;
import com.vz.esap.translation.order.model.request.DigitString;
import com.vz.esap.translation.order.model.request.TsoMigrationLocReferenceData;
import com.vz.esap.translation.order.model.request.VOIPOrderRequest;
import com.vz.esap.translation.order.service.helper.OrderServiceHelper;
import com.vz.esap.translation.util.OrderUtility;

/**
 * @author chattni
 *
 */
@Component
public class LocationTransformerImpl implements LocationTransformer {

	@Autowired
	private VOIPOrderDao voipOrderDao;

	@Autowired
	private ParamInfoTransformer paramInfoTransformer;

	@Autowired
	private OrderServiceHelper orderServiceHelperImpl;

	private static final Logger LOG = LoggerFactory.getLogger(LocationTransformerImpl.class);

	private static final String LOCATION_ID = "LocationId";

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.vz.esap.translation.order.transformer.LocationTransformer#
	 * transformOrderDetailsToLocation(long, long, java.lang.String, boolean)
	 */
	// each entity to include paramActionExclusionList-->COMPLETED
	@Override
	public LocationEntity transformOrderDetailsToLocation(long orderId, long parentId, String action, boolean delta,
			List<String> paramActionExclusionList) throws TranslatorException, GenericException {
		LOG.info("Inside - transformOrderDetailsToLocation");

		return createLocationFromParamInfo(
				createLocationParamInfoFromOrderDetails(orderId, parentId, action, delta, null),
				paramActionExclusionList);
	}

	/**
	 * @param orderId
	 * @param parentId
	 * @param action
	 * @param delta
	 * @param paramName
	 * @return root
	 * @throws GenericException
	 */
	private ParamInfo createLocationParamInfoFromOrderDetails(long orderId, long parentId, String action, boolean delta,
			String paramName) throws GenericException {
		LOG.info(
				"In LocationTransformerImpl createLocationParamInfoFromOrderDetails ordId:{} parentId:{} action:{} delta:{}",
				orderId, parentId, action, delta);
		ParamInfo root = null;
		TblOrderDetails tblOrderDetails = null;
		List<TblOrderDetails> ordDetails = null;

		try {
			tblOrderDetails = new TblOrderDetails();
			tblOrderDetails.setOrderId(orderId);
			tblOrderDetails.setAction(action);
			tblOrderDetails.setParentId(parentId);
			tblOrderDetails.setParamName(paramName);

			ordDetails = voipOrderDao.getOrderDetailsWithActionAndParent(parentId, action, delta, paramName,
					tblOrderDetails);

			LOG.info("List Size:{}", ordDetails.size());

			root = new ParamInfo("LocationEntity", null, null);
			root = paramInfoTransformer.transformOrderDetailsToParamInfo(ordDetails, root, 0, null);

		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new GenericException(GenericException.GENERIC_EXCEPTION,
					"Unexpected Exception while Location Transformation");
		}
		LOG.info("Exit createLocationParamInfoFromOrderDetails");
		return root;

	}

	/**
	 * @param parent
	 * @param paramActionExclusionList
	 *            TODO
	 * @return location
	 * @throws TranslatorException
	 */
	// each-->COMPLETED
	// entity to include paramActionExclusionList
	private LocationEntity createLocationFromParamInfo(ParamInfo parent, List<String> paramActionExclusionList)
			throws TranslatorException {

		LOG.info("LocationTransformerImpl - createLocationFromParamInfo");
		LocationEntity locationEntity = new LocationEntity();

		try {
			for (ParamInfo param : parent.getChildParams()) {
				LOG.debug("Name:{}  Value:{} ChildParamCnt:{} And Param Action = {}", param.getName(), param.getValue(),
						(param.getChildParams() == null ? 0 : param.getChildParams().size()), param.getAction());

				// createXXXFromParamInfo(...)

				if (paramActionExclusionList != null && !paramActionExclusionList.isEmpty()) {
					boolean skip = false;
					for (String exclude : paramActionExclusionList) {
						exclude = paramInfoTransformer.translateTODActToPIAct(exclude);
						
						if (exclude.equalsIgnoreCase(param.getAction())) {
							LOG.info("Excluded Action : {} for Param Name = {} and Param Value = {}", exclude,
									param.getName(), param.getValue());
							skip = true;
						}
					}
					if (skip)
						continue;
				}

				if (param.getName().equals(LOCATION_ID))
					locationEntity.setLocationId(param.getValue());
				else if (param.getName().equals("CustomerId")) {
					locationEntity.setCustomerId(param.getValue());
				}

				else if (param.getName().equals("Description"))
					locationEntity.setDescription(param.getValue());
				else if (param.getName().equals("MarketType"))
					locationEntity.setMarketType(param.getValue());
				else if (param.getName().equals("Name"))
					locationEntity.setName(param.getValue());
				else if (param.getName().equals("Address"))
					locationEntity.setAddress(param.getValue());
				else if (param.getName().equals("City"))
					locationEntity.setCity(param.getValue());
				else if (param.getName().equals("State"))
					locationEntity.setState(param.getValue());
				else if (param.getName().equals("Zip"))
					locationEntity.setZip(param.getValue());
				else if (param.getName().equals("Country"))
					locationEntity.setCountry(param.getValue());
				else if (param.getName().equals("PrivateNumberLength"))
					locationEntity.setPrivateNumberLength(getBigInteger(param.getValue()));
				else if (param.getName().equals("TimeZone"))
					locationEntity.setTimeZone(param.getValue());
				else if (param.getName().equals("DaylightSavingInd"))
					locationEntity.setDaylightSavingInd(param.getValue());
				else if (param.getName().equals("WebLanguage"))
					locationEntity.setWebLanguage(param.getValue());
				else if (param.getName().equals("VmLanguage"))
					locationEntity.setVmLanguage(param.getValue());
				else if (param.getName().equals("ContactName"))
					locationEntity.setContactName(param.getValue());
				else if (param.getName().equals("ContactPhone"))
					locationEntity.setContactPhone(param.getValue());
				else if (param.getName().equals("ContactEmail"))
					locationEntity.setContactEmail(param.getValue());
				else if (param.getName().equals("AcctTeamName"))
					locationEntity.setAcctTeamName(param.getValue());
				else if (param.getName().equals("AcctTeamPhone"))
					locationEntity.setAcctTeamPhone(param.getValue());
				else if (param.getName().equals("AcctTeamEmail"))
					locationEntity.setAcctTeamEmail(param.getValue());
				else if (param.getName().equals("SipDomain"))
					locationEntity.setSipDomain(param.getValue());
				else if (param.getName().equals("ParentDomain"))
					locationEntity.setParentDomain(param.getValue());
				else if (param.getName().equals("BillingType"))
					locationEntity.setBillingType(param.getValue());
				else if (param.getName().equals("ServiceLevel"))
					locationEntity.setServiceLevel(param.getValue());
				else if (param.getName().equals("NpaNxx"))
					locationEntity.setNpaNxx(param.getValue());
				else if (param.getName().equals("AccessType"))
					locationEntity.setAccessType(param.getValue());
				else if (param.getName().equals("AccessCategory"))
					locationEntity.setAccessCategory(param.getValue());
				else if (param.getName().equals("SbcAccessType"))
					locationEntity.setSbcAccessType(param.getValue());
				else if (param.getName().equals("VpnName"))
					locationEntity.setVpnName(param.getValue());
				else if (param.getName().equals("ESBCSignalingIP"))
					locationEntity.setEsbcSignalingIP(param.getValue());
				else if (param.getName().equals("CircuitId"))
					locationEntity.setCircuitId(param.getValue());
				else if (param.getName().equals("LocationComment"))
					locationEntity.setLocationComment(param.getValue());
				else if (param.getName().equals("AdvantageClub"))
					locationEntity.setAdvantageClub(param.getValue());
				else if (param.getName().equals("NetcomSvcId"))
					locationEntity.setNetcomSvcId(param.getValue());
				else if (param.getName().equals("ManagedFlag"))
					locationEntity.setManagedFlag(param.getValue());
				else if (param.getName().equals("UunetSiteId"))
					locationEntity.setUunetSiteId(param.getValue());
				else if (param.getName().equals("CallingPartyNumber"))
					locationEntity.setCallingPartyNumber(param.getValue());
				else if (param.getName().equals("CallingPartyPrivacy"))
					locationEntity.setCallingPartyPrivacy(param.getValue());
				else if (param.getName().equals("StationLevelId"))
					locationEntity.setStationLevelId(param.getValue());
				else if (param.getName().equals("BsAppServer"))
					locationEntity.setBsAppServer(param.getValue());
				else if (param.getName().equals("AsClli"))
					locationEntity.setAsClli(param.getValue());	
				else if (param.getName().equals("Cv2Service"))
					locationEntity.setCv2Service(param.getValue());
				else if (param.getName().equals("TotalSubscribers"))
					locationEntity.setTotalSubscribers(getBigInteger(param.getValue()));
				else if (param.getName().equals("TotalVoiceMailAccts"))
					locationEntity.setTotalVoiceMailAccts(getBigInteger(param.getValue()));
				else if (param.getName().equals("TotalPublicNumbers"))
					locationEntity.setTotalPublicNumbers(getBigInteger(param.getValue()));
				else if (param.getName().equals("IxPlusID"))
					locationEntity.setIxPlusID(getBigInteger(param.getValue()));
				else if (param.getName().equals("IxPlusRegion"))
					locationEntity.setIxPlusRegion(getBigInteger(param.getValue()));
				else if (param.getName().equals("ExtensionLength"))
					locationEntity.setExtensionLength(getBigInteger(param.getValue()));
				else if (param.getName().equals("MaxConcurrentSlg"))
					locationEntity.setMaxConcurrentSlg(getBigInteger(param.getValue()));
				else if (param.getName().equals("MaxConcurrentInbound"))
					locationEntity.setMaxConcurrentInbound(getBigInteger(param.getValue()));
				// --XO Attributes
				else if (param.getName().equals("EslId"))
					locationEntity.setEslId(param.getValue());
				else if (param.getName().equals("BWLocationId"))
					locationEntity.setBwLocationId(param.getValue());
				else if (param.getName().equals("PreBuildLocId"))
					locationEntity.setPreBuildLocId(param.getValue());
				else if (param.getName().equals("Region"))
					locationEntity.setRegion(param.getValue());
				else if (param.getName().equals("AdminFirstName"))
					locationEntity.setAdminFirstName(param.getValue());
				else if (param.getName().equals("AdminLastName"))
					locationEntity.setAdminLastName(param.getValue());
				else if (param.getName().equals("AdminEmail"))
					locationEntity.setAdminEmail(param.getValue());
				else if (param.getName().equals("AdminWebLoginId"))
					locationEntity.setAdminWebLoginId(param.getValue());
				else if (param.getName().equals("AdminPassword"))
					locationEntity.setAdminPassword(param.getValue());
				else if (param.getName().equals("DomainName"))
					locationEntity.setDomainName(param.getValue());
				else if (param.getName().equals("BillingTN"))
					locationEntity.setBillingTN(Long.valueOf(param.getValue()));
				else if (param.getName().equals("GroupUserLimit"))
					locationEntity.setGroupUserLimit(param.getValue());
				else if (param.getName().equals("BroadworksPortalNumber"))
					locationEntity.setBroadworksPortalNumber(param.getValue());
				else if (param.getName().equals("Redundency")) {
					if ("PRIORITY".equalsIgnoreCase(param.getValue()))
						locationEntity.setRedundancy(EsapEnum.RedundancyType.PRIORITY);
					else if ("LOADSHARING".equalsIgnoreCase(param.getValue()))
						locationEntity.setRedundancy(EsapEnum.RedundancyType.LOADSHARING);
					else if ("NONE".equalsIgnoreCase(param.getValue()))
						locationEntity.setRedundancy(EsapEnum.RedundancyType.NONE);
				} else if (param.getName().equals("RedundencyId"))
					locationEntity.setRedundancyId(param.getValue());
				else if (param.getName().equals("RedundancyPriorityType")) {
					if ("PRIMARY".equalsIgnoreCase(param.getValue()))
						locationEntity.setRedundancyPriorityType(EsapEnum.RedundancyPriorityType.PRIMARY);
					else if ("SECONDARY".equalsIgnoreCase(param.getValue()))
						locationEntity.setRedundancyPriorityType(EsapEnum.RedundancyPriorityType.SECONDARY);
				} else if (param.getName().equals("TNQuantity"))
					locationEntity.setTnQuantity(Long.valueOf(param.getValue()));
				else if (param.getName().equals("BWEnterpriseId"))
					locationEntity.setBwEnterpriseId(param.getValue());
				else if (param.getName().equals("BsTimeZone"))
					locationEntity.setBsTimeZone(param.getValue());
				else if (param.getName().equals("SolutionType"))
					locationEntity.setSolutionType(SolutionType.valueOf(param.getValue()));
				if (param.getName().equals("AuthService") && param.getChildParams() != null) {
					String svc = null;
					Boolean authorised = null;
					for (ParamInfo par2 : param.getChildParams()) {
						if (par2.getName().equals("Name"))
							svc = par2.getValue();
						if (par2.getName().equals("Authorised") && par2.getValue() != null) {
							authorised = OrderUtility.getBooleanFromYN(par2.getValue());
						}
					}
						locationEntity.addAuthService(svc, authorised);
				}
				
				if (param.getName().equals("LocationFeature") && param.getChildParams() != null) {
					String svc = null;
					Boolean authorised = null;
					String featureQuantity = null;

					for (ParamInfo par2 : param.getChildParams()) {
						if (par2.getName().equals("Feature"))
							svc = par2.getValue();
						if (par2.getName().equals("Name") && svc==null)
							svc = par2.getValue();
						if (par2.getName().equals("FeatureQuantity") && par2.getValue() != null) {
							featureQuantity =  par2.getValue();
						}
						authorised = OrderUtility.getBooleanFromYN("Y");
					}
					if(featureQuantity!=null) {
						locationEntity.prepareAuthService(svc, featureQuantity, authorised);
					}else {
						locationEntity.addAuthService(svc, authorised);
					}
				}
				
				if (param.getName().equals("Session")) {
					if (param.getChildParams() != null) {
						Session session = new Session();

						for (ParamInfo par2 : param.getChildParams()) {
							if (par2.getName().equals("Quantity"))
								session.setQuantity(Long.valueOf(par2.getValue()));
							if (par2.getName().equals("PortSpeed"))
								session.setPortSpeed(par2.getValue());
							if (par2.getName().equals("CompressionType"))
								session.setCompressionType(par2.getValue());
							if (par2.getName().equals("MaxQuantity"))
								session.setMaxQuantity(par2.getValue());
						}
						locationEntity.setSession(session);
					}
				}
				// --XO Attributes
				else if (param.getName().equals("VoipServiceType"))
					locationEntity.setVoipServiceType(param.getValue());
				else if (param.getName().equals("LocationType"))
					locationEntity.setLocationType(Integer.parseInt(param.getValue()));
				else if (param.getName().equals("HybridServiceType"))
					locationEntity.setHybridServiceType(param.getValue());
				else if (param.getName().equals("EmergencyCallLine"))
					locationEntity.setEmergencyCallLine(param.getValue());
				else if (param.getName().equals("STN"))
					locationEntity.setsTn(param.getValue());
				else if (param.getName().equals("EnableCallPark"))
					locationEntity.setEnableCallPark(Boolean.valueOf(param.getValue()));
				else if (param.getName().equals("OverrideSubPrivate"))
					locationEntity.setOverrideSubPrivate(Boolean.valueOf(param.getValue()));
				else if (param.getName().equals("OverrideCidName"))
					locationEntity.setOverrideCidName(Boolean.valueOf(param.getValue()));
				else if (param.getName().equals("OverrideCidNum"))
					locationEntity.setOverrideCidNum(Boolean.valueOf(param.getValue()));
				else if (param.getName().equals("AuthFeatureType"))
					locationEntity.setAuthFeatureType(AuthFeatureType.valueOf(param.getValue()));
				else if (param.getName().equals("EnableAccountCode"))
					locationEntity.setEnableAccountCode(Boolean.valueOf(param.getValue()));
				else if (param.getName().equals("EnableAuthCode"))
					locationEntity.setEnableAuthCode(Boolean.valueOf(param.getValue()));
				else if (param.getName().equals("PremiseVMSMDI"))
					locationEntity.setVmSmdiAuthToggle(Boolean.valueOf(param.getValue()));
				else if (param.getName().equals("BlockAllCalls"))
					locationEntity.setBlockAllCalls(Boolean.valueOf(param.getValue()));
				else if (param.getName().equals("Expedite"))
					locationEntity.setExpedite(Boolean.valueOf(param.getValue()));
				else if (param.getName().equals("HighVolume"))
					locationEntity.setHighVolume(Boolean.valueOf(param.getValue()));
				else if (param.getName().equals("AfterHourInstallFee"))
					locationEntity.setAfterHourInstallFee(Boolean.valueOf(param.getValue()));
				else if (param.getName().equals("CallingNameInd"))
					locationEntity.setCallingNameInd(Boolean.valueOf(param.getValue()));
				else if (param.getName().equals("EnhancedANIInd"))
					locationEntity.setEnhancedANIInd(Boolean.valueOf(param.getValue()));
				else if (param.getName().equals("LocationCclIndicator"))
					locationEntity.setLocationCclIndicator(Boolean.valueOf(param.getValue()));
				else if (param.getName().equals("PubIp"))
					locationEntity.setPubIp(Boolean.valueOf(param.getValue()));
				else if (param.getName().equals("PubIpIn"))
					locationEntity.setPubIpIn(Boolean.valueOf(param.getValue()));
				else if (param.getName().equals("PubIpInStr"))
					locationEntity.setPubIpInStr(Boolean.valueOf(param.getValue()));
				else if (param.getName().equals("PubIpOut"))
					locationEntity.setPubIpOut(Boolean.valueOf(param.getValue()));
				else if (param.getName().equals("PubIpOutStr"))
					locationEntity.setPubIpOutStr(Boolean.valueOf(param.getValue()));
				else if (param.getName().equals("PubIpStr"))
					locationEntity.setPubIpStr(Boolean.valueOf(param.getValue()));
				else if (param.getName().equals("LocalDirAssistance"))
					locationEntity.setLocalDirAssistance(param.getValue());
				else if (param.getName().equals("NatDirAssistance"))
					locationEntity.setNatDirAssistance(param.getValue());
				else if (param.getName().equals("MaxNg"))
					locationEntity.setMaxNg(Integer.valueOf(param.getValue())); // New
				else if (param.getName().equals("CidTn"))
					locationEntity.setCidTn(param.getValue());
				else if (param.getName().equals("TrunkType"))
					locationEntity.setTrunkType(Integer.valueOf(param.getValue()));
				else if (param.getName().equals("SwitchClli"))
					locationEntity.setSwitchClli(param.getValue());
				else if (param.getName().equals("Trunk") && param.getValue() != null)
					locationEntity.setTrunk(param.getValue());
				else if (param.getName().equals("AbbrDialingCode"))
					locationEntity.setAbbrDialingCode(param.getValue());
				else if (param.getName().equals("SbcEnabled"))
					locationEntity.setSbcEnabled(Boolean.valueOf(param.getValue()));
				else if (param.getName().equals("VmCpeIpAddress"))
					locationEntity.setVmCpeIpAddress(param.getValue());
				else if (param.getName().equals("VmSmdiAuthToggle"))
					locationEntity.setVmSmdiAuthToggle(Boolean.valueOf(param.getValue()));
				else if (param.getName().equals("LinePortLength"))
					locationEntity.setLinePortLength(Integer.valueOf(param.getValue()));
				else if (param.getName().equals("PublicGtwyDpid"))
					locationEntity.setPublicGtwyDpid(Long.valueOf(param.getValue()));
				else if (param.getName().equals("DefaultGtwyDpid"))
					locationEntity.setDefaultGtwyDpid(Long.valueOf(param.getValue()));
				else if (param.getName().equals("SipClientEnabledFlag	"))
					locationEntity.setSipClientEnabledFlag(param.getValue());
				else if (param.getName().equals("StrSbcId"))
					locationEntity.setStrSbcId(param.getValue());
				else if (param.getName().equals("StrCustFqdn"))
					locationEntity.setStrCustFqdn(param.getValue());
				else if (param.getName().equals("StrCustIpAddr"))
					locationEntity.setStrCustIpAddr(param.getValue());
				else if (param.getName().equals("UNumber"))
					locationEntity.setuNumber(param.getValue());
				else if (param.getName().equals("SiebelOrder"))
					locationEntity.setSiebelOrder(param.getValue());
				else if (param.getName().equals("BillAcctNum"))
					locationEntity.setBillAcctNum(param.getValue());
				else if (param.getName().equals("IntCustPort"))
					locationEntity.setIntCustPort(Integer.valueOf(param.getValue()));
				else if (param.getName().equals("MaxConcurrentCalls") && param.getValue() != null)
					locationEntity.setMaxConcurrentCalls(getBigInteger(param.getValue()));
				else if (param.getName().equals("MaxConcurrentOffNet"))
					locationEntity.setMaxConcurrentOffNet(getBigInteger(param.getValue()));
				else if (param.getName().equals("FmcLocation"))
					locationEntity.setFmcLocation(param.getValue());
				else if (param.getName().equals("TypeOfLoc"))
					locationEntity.setTypeOfLoc(TypeOfLocEnum.valueOf(param.getValue()));
				else if (param.getName().equals("HubLocationId"))
					locationEntity.setHubLocationId(param.getValue());
				else if (param.getName().equals("ProductionIndicator"))
					locationEntity.setProductionIndicator(new Boolean(param.getValue()));
				else if (param.getName().equals("EmerLocationCode"))
					locationEntity.setEmerLocationCode(param.getValue());
				else if (param.getName().equals("HubGatewayDeviceId"))
					locationEntity.setHubGatewayDeviceId(Long.valueOf(param.getValue()));
				else if (param.getName().equals("LocationMask"))
					locationEntity.setLocationMask(Long.valueOf(param.getValue()));
				else if (param.getName().equals("ANumMask"))
					locationEntity.setaNumMask(new Long(param.getValue()));
				else if (param.getName().equals("BNumMask"))
					locationEntity.setbNumMask(new Long(param.getValue()));
				else if (param.getName().equals("RivCustomer") && param.getValue() != null)
					locationEntity.setRivCustomer(param.getValue());
				else if (param.getName().equals("VmType") && param.getValue() != null)
					locationEntity.setVmType(LocationEntity.VmType.valueOf(param.getValue()));
				else if (param.getName().equals("Territory"))
					locationEntity.setTerritory(param.getValue());
				else if (param.getName().equals("LocRegion"))
					locationEntity.setLocRegion(param.getValue());
				else if (param.getName().equals("TypeOfMigration"))
					locationEntity.setMigrationType(param.getValue());
				else if (param.getName().equals("PBBAN"))
					locationEntity.setPBBAN(param.getValue());
				else if (param.getName().equals("BillingSystem"))
					locationEntity.setBillingSystem(Integer.valueOf(param.getValue()));
				else if (param.getName().equals("IASAOrderId"))
					locationEntity.setIasaOrderId(param.getValue());
				else if (param.getName().equals("PrefixPlanId"))
					locationEntity.setPrefixPlanId(Integer.valueOf(param.getValue()));
				else if (param.getName().equals("EmerLocCodeId"))
					locationEntity.setEmerLocCodeId(new Long(param.getValue()));
				else if (param.getName().equals("ConfigAllowed"))
					locationEntity.setConfigAllowed(new Long(param.getValue()));
				else if (param.getName().equals("ProductId"))
					locationEntity.setProductId(param.getValue());
				else if (param.getName().equals("VARRS"))
					locationEntity.setVARRS(param.getValue());
				else if (param.getName().equals("PendingRPID"))
					locationEntity.setPendingRPID(param.getValue());
				else if (param.getName().equals("MigrationType"))
					locationEntity.setMigrationType(param.getValue());
				else if (param.getName().equals("Vce"))
					locationEntity.setVce(param.getValue());
				else if (param.getName().equals("BillingActivated"))
					locationEntity.setBillingActivated(Boolean.valueOf(param.getValue()));
				else if (param.getName().equals("PhysicalLocationId"))
					locationEntity.setPhysicalLocationId(param.getValue());
				else if (param.getName().equals("PhysicalLocationName"))
					locationEntity.setPhysicalLocationName(param.getValue());
				else if (param.getName().equals("CallForwardPlanName"))
					locationEntity.setCallForwardPlanName(param.getValue());
				else if (param.getName().equals("EnterpriseTrunkId"))
					locationEntity.setEnterpriseTrunkId(new Long(param.getValue()));
				else if (param.getName().equals("PqInstanceId"))
					locationEntity.setPqInstanceId(new Long(param.getValue()));
				else if (param.getName().equals("DesignId"))
					locationEntity.setDesignId(new Long(param.getValue()));
				else if (param.getName().equals("EmerNumber"))
					locationEntity.setEmerNumber(param.getValue());
				else if (param.getName().equals("EmerMappingCode"))
					locationEntity.setEmerMappingCode(param.getValue());
				else if (param.getName().equals("AddressID"))
					locationEntity.setAddressID(param.getValue());
				else if (param.getName().equals("EmerLocationCodeId"))
					locationEntity.setEmerLocationCodeId(param.getValue());
				else if (param.getName().equals("Clin"))
					locationEntity.setClin(param.getValue());
				else if (param.getName().equals("TransportType"))
					locationEntity.setTransportType(param.getValue());
				else if (param.getName().equals("SubAgencyHierCode"))
					locationEntity.setSubAgencyHierCode(param.getValue());
				else if (param.getName().equals("IsE2E"))
					locationEntity.setIsE2E(Boolean.valueOf(param.getValue()));
				else if (param.getName().equals("DialingCountryCode")) 
					locationEntity.setDialingCountryCode(param.getValue());
				else if (param.getName().equals("PortOutType"))
					locationEntity.setPortOutType(param.getValue());
				else if (param.getName().equals("ProvisionCategory"))
					locationEntity.setProvisionCategory(param.getValue());
				
				else if (param.getName().equals("MaxActiveCalls"))
					locationEntity.setMaxActiveCalls(Long.valueOf(param.getValue()));
				else if (param.getName().equals("MaxActiveIncomingCalls"))
					locationEntity.setMaxActiveIncomingCalls(Long.valueOf(param.getValue()));
				else if (param.getName().equals("MaxActiveOutgoingCalls"))
					locationEntity.setMaxActiveOutgoingCalls(Long.valueOf(param.getValue()));
				
				else if (param.getName().equals("TsoMigLock"))
					locationEntity.setTsoMigLock(new Short(param.getValue()));
				else if (param.getName().equals("QosIndicator") && param.getValue() != null)
					locationEntity.setQosIndicator(LocationEntity.QosIndicator.valueOf(param.getValue()));
				else if (param.getName().equals("SbcProvMethod") && param.getValue() != null)
					locationEntity.setSbcProvMethod(LocationEntity.SbcProvMethod.valueOf(param.getValue()));
				else if (param.getName().equals("TsoMigrationLocReferenceData") && param.getValue() != null) {
					TsoMigrationLocReferenceData tsoMigrationLocReferenceData = new TsoMigrationLocReferenceData();
					if (param.getChildParams() != null) {
						for (ParamInfo par2 : param.getChildParams()) {
							if (par2.getName().equals("LocationReferenceId") && par2.getValue() != null) {
								tsoMigrationLocReferenceData.setLocationReferenceId(new Long(par2.getValue()));
							} else if (par2.getName().equals("NewLocationId") && par2.getValue() != null) {
								tsoMigrationLocReferenceData.setNewLocationId(par2.getValue());
							} else if (par2.getName().equals("OldLocationId") && par2.getValue() != null) {
								tsoMigrationLocReferenceData.setOldLocationId(par2.getValue());
							}
						}
					}
				} else if (param.getName().equals("AlternativeCallerIdFlag") && param.getValue() != null) {
					locationEntity.setAltCallerIdFlag(LocationEntity.AlternativeCallerIdFlag.valueOf(param.getValue()));
				} else if (param.getName().equals("AdditionalAttribs")) {
					if (param.getChildParams() != null)
						for (ParamInfo par2 : param.getChildParams())
							locationEntity.addAttrib(par2.getName(), par2.getValue());
				} else if (param.getName().equals("HotCutIndicator")) {
					if (param.getValue() != null && param.getValue().equals("Y"))
						locationEntity.setHotCutIndicator(Boolean.TRUE);
				} else if (param.getName().equals("CDDDIndicator")) {
					if (param.getValue() != null && param.getValue().equals("Y"))
						locationEntity.setCDDDIndicator(Boolean.TRUE);
				} else if (param.getName().equals("isE2E")) {
					if (param.getValue() != null && param.getValue().equals("Y"))
						locationEntity.setIsE2E(Boolean.TRUE);
				} else if (param.getName().equals("CallingPlan") && param.getValue() != null) {
					CallingPlanEntity callingPlanEntity = new CallingPlanEntity();
					if (param.getChildParams() != null) {
						for (ParamInfo par2 : param.getChildParams()) {
							if (par2.getName().equals("DepartmentId") && par2.getValue() != null) {
								callingPlanEntity.setDepartmentId(par2.getValue());
							} else if (par2.getName().equals(LOCATION_ID) && par2.getValue() != null) {
								callingPlanEntity.setLocationId(par2.getValue());
							} else if (par2.getName().equals("CallingPlanId") && par2.getValue() != null) {
								callingPlanEntity.setCallingPlanId(par2.getValue());
							} else if (par2.getName().equals("CallingPlanName") && par2.getValue() != null) {
								callingPlanEntity.setCallingPlanName(par2.getValue());
							} else if (par2.getName().equals("Incoming") && par2.getValue() != null) {
								if (param.getChildParams() != null) {
									IncomingCallingPlan incomingCallingPlan = new IncomingCallingPlan();
									for (ParamInfo par3 : param.getChildParams()) {
										if (par3.getName().equals("IntraLocation") && par3.getValue() != null) {
											incomingCallingPlan.setIntraLocation(par3.getValue());
										} else if (par3.getName().equals("InterLocation") && par3.getValue() != null) {
											incomingCallingPlan.setInterLocation(par3.getValue());
										} else if (par3.getName().equals("CollectCalls") && par3.getValue() != null) {
											incomingCallingPlan.setCollectCalls(par3.getValue());
										}
									}
									callingPlanEntity.setIncoming(incomingCallingPlan);
								}
							} else if (par2.getName().equals("Outgoing") && par2.getValue() != null) {
								if (param.getChildParams() != null) {
									OutgoingCallingPlan outgoingCallingPlan = new OutgoingCallingPlan();
									for (ParamInfo par3 : param.getChildParams()) {
										if (par3.getName().equals("IntraLocation") && par3.getValue() != null) {
											outgoingCallingPlan.setIntraLocation(par3.getValue());
										} else if (par3.getName().equals("Local") && par3.getValue() != null) {
											outgoingCallingPlan.setLocal(par3.getValue());
										} else if (par3.getName().equals("TollFree") && par3.getValue() != null) {
											outgoingCallingPlan.setTollFree(par3.getValue());
										} else if (par3.getName().equals("Toll") && par3.getValue() != null) {
											outgoingCallingPlan.setToll(par3.getValue());
										} else if (par3.getName().equals("International") && par3.getValue() != null) {
											outgoingCallingPlan.setInternational(par3.getValue());
										} else if (par3.getName().equals("Casual") && par3.getValue() != null) {
											outgoingCallingPlan.setCasual(par3.getValue());
										} else if (par3.getName().equals("OperatorAssisted")
												&& par3.getValue() != null) {
											outgoingCallingPlan.setOperatorAssisted(par3.getValue());
										} else if (par3.getName().equals("ChargeableDirectoryAssist")
												&& par3.getValue() != null) {
											outgoingCallingPlan.setChargeableDirectoryAssist(par3.getValue());
										} else if (par3.getName().equals("SpecialServices1")
												&& par3.getValue() != null) {
											outgoingCallingPlan.setSpecialServices1(par3.getValue());
										} else if (par3.getName().equals("SpecialServices2")
												&& par3.getValue() != null) {
											outgoingCallingPlan.setSpecialServices2(par3.getValue());
										} else if (par3.getName().equals("PremiumServices1")
												&& par3.getValue() != null) {
											outgoingCallingPlan.setPremiumServices1(par3.getValue());
										} else if (par3.getName().equals("PremiumServices2")
												&& par3.getValue() != null) {
											outgoingCallingPlan.setPremiumServices2(par3.getValue());
										} else if (par3.getName().equals("URLDialing") && par3.getValue() != null) {
											outgoingCallingPlan.setURLDialing(par3.getValue());
										} else if (par3.getName().equals("Unknown") && par3.getValue() != null) {
											outgoingCallingPlan.setUnknown(par3.getValue());
										} else if (par3.getName().equals("FwdTrnsfIntraLocation")
												&& par3.getValue() != null) {
											outgoingCallingPlan.setFwdTrnsfIntraLocation(par3.getValue());
										} else if (par3.getName().equals("FwdTrnsfLocal") && par3.getValue() != null) {
											outgoingCallingPlan.setFwdTrnsfLocal(par3.getValue());
										} else if (par3.getName().equals("FwdTrnsfTollFree")
												&& par3.getValue() != null) {
											outgoingCallingPlan.setFwdTrnsfTollFree(par3.getValue());
										} else if (par3.getName().equals("FwdTrnsfToll") && par3.getValue() != null) {
											outgoingCallingPlan.setFwdTrnsfToll(par3.getValue());
										} else if (par3.getName().equals("FwdTrnsfInternational")
												&& par3.getValue() != null) {
											outgoingCallingPlan.setFwdTrnsfInternational(par3.getValue());
										} else if (par3.getName().equals("FwdTrnsfCasual") && par3.getValue() != null) {
											outgoingCallingPlan.setFwdTrnsfCasual(par3.getValue());
										} else if (par3.getName().equals("FwdTrnsfOperatorAssisted")
												&& par3.getValue() != null) {
											outgoingCallingPlan.setFwdTrnsfOperatorAssisted(par3.getValue());
										} else if (par3.getName().equals("FwdTrnsfChargeableDirectoryAssist")
												&& par3.getValue() != null) {
											outgoingCallingPlan.setFwdTrnsfChargeableDirectoryAssist(par3.getValue());
										} else if (par3.getName().equals("FwdTrnsfSpecialServices1")
												&& par3.getValue() != null) {
											outgoingCallingPlan.setFwdTrnsfSpecialServices1(par3.getValue());
										} else if (par3.getName().equals("FwdTrnsfSpecialServices2")
												&& par3.getValue() != null) {
											outgoingCallingPlan.setFwdTrnsfSpecialServices2(par3.getValue());
										} else if (par3.getName().equals("FwdTrnsfPremiumServices1")
												&& par3.getValue() != null) {
											outgoingCallingPlan.setFwdTrnsfPremiumServices1(par3.getValue());
										} else if (par3.getName().equals("FwdTrnsfPremiumServices2")
												&& par3.getValue() != null) {
											outgoingCallingPlan.setFwdTrnsfPremiumServices2(par3.getValue());
										} else if (par3.getName().equals("FwdTrnsfURLDialing")
												&& par3.getValue() != null) {
											outgoingCallingPlan.setFwdTrnsfURLDialing(par3.getValue());
										} else if (par3.getName().equals("FwdTrnsfUnknown")
												&& par3.getValue() != null) {
											outgoingCallingPlan.setFwdTrnsfUnknown(par3.getValue());
										}
										callingPlanEntity.setOutgoing(outgoingCallingPlan);
									}
								}
							} else if (par2.getName().equals("_default") && par2.getValue() != null) {
								callingPlanEntity.set_default(par2.getValue());
							} else if (par2.getName().equals("Telephone1") && par2.getValue() != null) {
								callingPlanEntity.setTelephone1(par2.getValue());
							} else if (par2.getName().equals("Telephone2") && par2.getValue() != null) {
								callingPlanEntity.setTelephone2(par2.getValue());
							} else if (par2.getName().equals("Telephone3") && par2.getValue() != null) {
								callingPlanEntity.setTelephone3(par2.getValue());
							} else if (par2.getName().equals("DigitString") && par2.getValue() != null) {
								ArrayList<DigitString> digitStrings;
								if (par2.getChildParams() != null) {
									digitStrings = new ArrayList<DigitString>();
									DigitString digitString = new DigitString();
									for (ParamInfo par3 : par2.getChildParams()) {
										if (par3.getName().equals("id") && par3.getValue() != null) {
											digitString.setId(new Long(par3.getValue()));
										} else if (par3.getName().equals("Value") && par3.getValue() != null) {
											digitString.setValue(par3.getValue());
										} else if (par3.getName().equals("Incoming") && par3.getValue() != null) {
											digitString.setIncoming(CallTypeEnum.valueOf(par3.getValue()));
										} else if (par3.getName().equals("Outgoing") && par3.getValue() != null) {
											digitString.setOutgoing(CallTypeEnum.valueOf(par3.getValue()));
										} else if (par3.getName().equals("FwdTransfer") && par3.getValue() != null) {
											digitString.setFwdTransfer(CallTypeEnum.valueOf(par3.getValue()));
										} else if (par3.getName().equals("BeingFwdTransfer")
												&& par3.getValue() != null) {
											digitString.setBeingFwdTransfer(CallTypeEnum.valueOf(par3.getValue()));
										}
										digitStrings.add(digitString);
									}
									callingPlanEntity.setDigitStrings(digitStrings);
								}
							}
						}

					}
				} else if (param.getName().equals("ECMInfo") && param.getValue() != null) {
					ArrayList<ECMInfo> ECMInfo = null;
					ECMInfo ecmTemp;
					if (param.getChildParams() != null) {
						ECMInfo = new ArrayList<ECMInfo>();
						for (ParamInfo par2 : param.getChildParams()) {
							ecmTemp = new ECMInfo();
							if (par2.getName().equals("AddressId") && par2.getValue() != null) {
								ecmTemp.setAddressId(par2.getValue());
							} else if (par2.getName().equals("emercodeInfo") && par2.getValue() != null) {
								ArrayList<EmergencyCodeInfo> emercodeInfo = null;
								if (par2.getChildParams() != null) {
									emercodeInfo = new ArrayList<EmergencyCodeInfo>();
									EmergencyCodeInfo emercodeInfoTemp = new EmergencyCodeInfo();
									for (ParamInfo par3 : par2.getChildParams()) {
										if (par3.getName().equals("EmerMappingCode") && par3.getValue() != null) {
											emercodeInfoTemp.setEmergencyCode(par3.getValue());
										} else if (par3.getName().equals("EmergencyNumber")
												&& par3.getValue() != null) {
											emercodeInfoTemp.setEmergencyNumber(par3.getValue());
										}
										emercodeInfo.add(emercodeInfoTemp);
									}
								}
								ecmTemp.setEmercodeInfo(emercodeInfo);
							}
							ECMInfo.add(ecmTemp);
						}
					}
					locationEntity.setEcmInfo(ECMInfo);

				} else if (param.getName().equals("GCMInfo") && param.getValue() != null) {
					GCMInfo gcmInfo = null;
					if (param != null && param.getChildParams() != null) {
						gcmInfo = new GCMInfo();
						for (ParamInfo par2 : param.getChildParams()) {
							if (par2.getName().equals("CustomerPriceBookId") && par2.getValue() != null) {
								gcmInfo.setCustomerPriceBookId(par2.getValue());
							} else if (par2.getName().equals("ContractId") && par2.getValue() != null) {
								gcmInfo.setContractId(par2.getValue());
							} else if (par2.getName().equals("QuoteId") && par2.getValue() != null) {
								gcmInfo.setQuoteId(par2.getValue());
							} else if (par2.getName().equals("ProductIdentifier") && par2.getValue() != null) {
								gcmInfo.setProductId(par2.getValue());
							} else if (par2.getName().equals("PricingInfo") && par2.getValue() != null) {
								ArrayList<GCMPricingInfo> pricingInfo = null;
								if (param.getChildParams() != null) {
									pricingInfo = new ArrayList<GCMPricingInfo>();
									GCMPricingInfo pricingInfoTemp = null;
									for (ParamInfo par3 : par2.getChildParams()) {
										pricingInfoTemp = new GCMPricingInfo();
										if (par3.getName().equals("FeatInstId") && par3.getValue() != null) {
											pricingInfoTemp.setFeatureInstanceId(par3.getValue());
										} else if (par3.getName().equals("FeatCode") && par3.getValue() != null) {
											pricingInfoTemp.setFeatureCode(par3.getValue());
										} else if (par3.getName().equals("ChargeType") && par3.getValue() != null) {
											pricingInfoTemp.setChargeType(par3.getValue());
										} else if (par3.getName().equals("CurrencyCode") && par3.getValue() != null) {
											pricingInfoTemp.setCurrencyCode(par3.getValue());
										} else if (par3.getName().equals("ChargeFrq") && par3.getValue() != null) {
											pricingInfoTemp.setChargeFrequency(par3.getValue());
										} else if (par3.getName().equals("Uom") && par3.getValue() != null) {
											pricingInfoTemp.setUnitOfMeasure(par3.getValue());
										} else if (par3.getName().equals("BillTime") && par3.getValue() != null) {
											pricingInfoTemp.setBillTime(par3.getValue());
										} else if (par3.getName().equals("PbLi") && par3.getValue() != null) {
											pricingInfoTemp.setPbLi(par3.getValue());
										} else if (par3.getName().equals("CatelogReferenceTime")
												&& par3.getValue() != null) {
											pricingInfoTemp.setCatelogReferenceTime(par3.getValue());
										} else if (par3.getName().equals("ServicePlan") && par3.getValue() != null) {
											pricingInfoTemp.setServicePlan(par3.getValue());
										} else if (par3.getName().equals("CclType") && par3.getValue() != null) {
											pricingInfoTemp.setCclType(par2.getValue());
										}
										pricingInfo.add(pricingInfoTemp);
									}
								}
								gcmInfo.setPricingInfo(pricingInfo);
							}
							locationEntity.setGcmInfo(gcmInfo);
						}
					}
				} else if (param.getName().equals("VmAccess") && param.getValue() != null) {
					ArrayList<VmAccess> vmaList;
					if (param.getChildParams() != null) {
						vmaList = new ArrayList<VmAccess>();
						VmAccess vMAccessTemp;
						for (ParamInfo par2 : param.getChildParams()) {
							/********************* check *********************************/
							vMAccessTemp = new VmAccess();
							if (par2.getName().equals("vmAccessId") && par2.getValue() != null) {
								vMAccessTemp.setVmAccessId(new Long(par2.getValue()));
							} else if (par2.getName().equals("PublicNumber") && par2.getValue() != null) {
								vMAccessTemp.setPublicNumber(par2.getValue());
							} else if (par2.getName().equals("PrivateNumber") && par2.getValue() != null) {
								vMAccessTemp.setPrivateNumber(par2.getValue());
							} else if (par2.getName().equals("SubscriberId") && par2.getValue() != null) {
								vMAccessTemp.setSubscriberId(par2.getValue());
							}
							vmaList.add(vMAccessTemp);
						}
						locationEntity.setVmAccessList(vmaList);
					}
				} else if (param.getName().equals("AcctAccountAuthCodes") && param.getValue() != null) {
					ArrayList<AccountAuthCode> accountAuthCodes;
					accountAuthCodes = new ArrayList<AccountAuthCode>();
					if (param.getChildParams() != null) {
						AccountAuthCode accountAuthCodeTemp;
						for (ParamInfo par2 : param.getChildParams()) {
							accountAuthCodeTemp = new AccountAuthCode();
							if (par2.getName().equals("Code") && par2.getValue() != null) {
								accountAuthCodeTemp.setCode(par2.getValue());
							} else if (par2.getName().equals("Desc") && par2.getValue() != null) {
								accountAuthCodeTemp.setDescription(par2.getValue());
							} else if (par2.getName().equals("Type") && par2.getValue() != null) {
								accountAuthCodeTemp.setCode(par2.getValue());
							}
							accountAuthCodes.add(accountAuthCodeTemp);
						}
					}
					locationEntity.setAccountAuthCodes(accountAuthCodes);
				} else if (param.getName().equals("PrefixPlanName") && param.getValue() != null) {
					if (param.getChildParams() != null)
						param.getChildParams().forEach(par2 -> locationEntity.addToprefixPlanName(par2.getValue()));
				} else if (param.getName().equals("PreselectedVpnName") && param.getValue() != null) {
					if (param.getChildParams() != null)
						param.getChildParams().forEach(par2 -> locationEntity.addTopreselectedVpnName(par2.getValue()));
				} else if (param.getName().equals("LocationFeature")) {
					HashMap<String, Integer> locationFeature;
					if (param.getChildParams() != null) {
						locationFeature = new HashMap<String, Integer>();
						String feature = null;
						Integer deltaCount = null;
						for (ParamInfo par2 : param.getChildParams()) {
							if (par2.getName().equals("Feature") && par2.getValue() != null)
								feature = par2.getValue();
							else if (par2.getName().equals("DeltaCount") && par2.getValue() != null) {
								if (par2.getValue().equalsIgnoreCase("true"))
									deltaCount = 1;
								else
									deltaCount = 0;
							}
							locationFeature.put(feature, deltaCount);
						}
						locationEntity.setLocationFeatures(locationFeature);
					}
				}
				if (param.getName().equals("FeaturePackage") && param.getValue() != null) {
					Map<String, BigInteger> featurePackageMap;
					if (param.getChildParams() != null) {
						featurePackageMap = new HashMap<>();
						String name = null;
						BigInteger vmBoxSize = null;
						if (param.getChildParams() != null) {
							for (ParamInfo par2 : param.getChildParams()) {
								if (par2.getName().equals("Name") && par2.getValue() != null)
									name = par2.getValue();
								else if (par2.getName().equals("VmBoxSize") && par2.getValue() != null)
									vmBoxSize = new BigInteger(par2.getValue());
								featurePackageMap.put(name, vmBoxSize);
							}
							locationEntity.setFeaturePackage(featurePackageMap);
						}
					}
				}
			}

		} catch (Exception e) {
			LOG.error("Exception {} ", e);
			throw new TranslatorException(ErrorCode.TRANSFORMER_FAILURE,
					"Exception occured in createLocationFromParamInfo");
		}
		LOG.info("Exit - createLocationFromParamInfo");
		return locationEntity;
	}

	public BigInteger getBigInteger(String value) {
		if(value != null) {
			return new BigInteger(value);
		}
		return null;
	}

	// XXXTransformerImpl.XXXInventoryToLocationEntityTransformer(...)
	@Override
	public LocationEntity locationInventoryToLocationEntityTransformer(Map<String, String> resultantRow) {
		LOG.info("Entered locationInventoryToLocationEntityTransformer");

		LocationEntity locationEntity = new LocationEntity();

		locationEntity.setLocationId(resultantRow.get("LOCATION_ID"));
		locationEntity.setCustomerId(resultantRow.get("ENTERPRISE_ID"));
		locationEntity.setName(resultantRow.get("LOCATION_NAME"));
		locationEntity.setAddress(resultantRow.get("LOC_ADDRESS"));
		locationEntity.setCity(resultantRow.get("LOC_CITY"));
		locationEntity.setState(resultantRow.get("LOC_STATE"));
		locationEntity.setZip(resultantRow.get("LOC_ZIP"));
		locationEntity.setCountry(resultantRow.get("LOC_COUNTRY"));
		locationEntity.setTimeZone(resultantRow.get("TIME_ZONE"));
		locationEntity.setVoipServiceType(resultantRow.get("VOIP_SERVICE_TYPE"));
		locationEntity.setCircuitId(resultantRow.get("CIRCUIT_ID"));
		locationEntity.setSipDomain(resultantRow.get("SIP_DOMAIN"));

		if (resultantRow.get("TRUNK_TYPE") != null)
			locationEntity.setTrunkType(Integer.parseInt(resultantRow.get("TRUNK_TYPE")));

		locationEntity.setServiceLevel(resultantRow.get("SERVICE_LEVEL"));

		if (resultantRow.get("MAX_CONCURRENT_CALLS") != null)
			locationEntity.setMaxConcurrentCalls(new BigInteger(resultantRow.get("MAX_CONCURRENT_CALLS")));

		locationEntity.setTrunk(resultantRow.get("TRUNK"));

		if (resultantRow.get("ENV_ORDER_ID") != null)
			locationEntity.setEnvOrderId(Long.valueOf(resultantRow.get("ENV_ORDER_ID")));

		locationEntity.setHubLocationId(resultantRow.get("HUB_LOCATION_ID"));
		locationEntity.setVpnName(resultantRow.get("VPN_NAME"));

		if (resultantRow.get("ENTERPRISE_TRUNK_ID") != null)
			locationEntity.setEnterpriseTrunkId(Long.valueOf(resultantRow.get("ENTERPRISE_TRUNK_ID")));

		if (resultantRow.get("PQ_INSTANCE_ID") != null)
			locationEntity.setPqInstanceId(Long.valueOf(resultantRow.get("PQ_INSTANCE_ID")));

		locationEntity.setEslId(resultantRow.get("ESLID"));
		
		locationEntity.setBwLocationId(resultantRow.get("LOC_GROUP_ID"));

		if (resultantRow.get("REDUNDENCY") != null) {
			if (resultantRow.get("REDUNDENCY").equalsIgnoreCase(RedundancyType.PRIORITY.toString()))
				locationEntity.setRedundancy(RedundancyType.PRIORITY);
			else if (resultantRow.get("REDUNDENCY").equalsIgnoreCase(RedundancyType.LOADSHARING.toString()))
				locationEntity.setRedundancy(RedundancyType.LOADSHARING);
			else if (resultantRow.get("REDUNDENCY").equalsIgnoreCase(RedundancyType.NONE.toString()))
				locationEntity.setRedundancy(RedundancyType.NONE);
		}

		locationEntity.setRedundancyId(resultantRow.get("REDUNDENCYID"));

		if (resultantRow.get("BILLINGTN") != null)
			locationEntity.setBillingTN(Long.valueOf(resultantRow.get("BILLINGTN")));

		locationEntity.setBroadworksPortalNumber(resultantRow.get("BROADWORKSPORTALNUMBER"));
		locationEntity.setGroupUserLimit(resultantRow.get("GROUPUSERLIMIT"));

		if (resultantRow.get("REDUNDANCY_PRIORITY_TYPE") != null) {
			if (resultantRow.get("REDUNDANCY_PRIORITY_TYPE")
					.equalsIgnoreCase(RedundancyPriorityType.PRIMARY.toString()))
				locationEntity.setRedundancyPriorityType(RedundancyPriorityType.PRIMARY);
			else if (resultantRow.get("REDUNDANCY_PRIORITY_TYPE")
					.equalsIgnoreCase(RedundancyPriorityType.SECONDARY.toString()))
				locationEntity.setRedundancyPriorityType(RedundancyPriorityType.SECONDARY);
		}

		if (resultantRow.get("XO_MAX_ACTIVE_CALLS") != null)
			locationEntity.setMaxActiveCall(Long.valueOf(resultantRow.get("XO_MAX_ACTIVE_CALLS")));

		if (resultantRow.get("XO_MAX_ACTIVE_INCOMING_CALLS") != null)
			locationEntity.setMaxIncomingCall(Long.valueOf(resultantRow.get("XO_MAX_ACTIVE_INCOMING_CALLS")));

		if (resultantRow.get("XO_MAX_ACTIVE_OUTGOING_CALLS") != null)
			locationEntity.setMaxOutgoingCall(Long.valueOf(resultantRow.get("XO_MAX_ACTIVE_OUTGOING_CALLS")));

		// Missing:
		// POLICY_SERVICE_ID
		// locationEntity.setBwEnterpriseId(bwEnterpriseId);

		LOG.info("Exit locationInventoryToLocationEntityTransformer");
		return locationEntity;
	}

	// Original Entity with the TBL_LOCATION.
	// Do same for all entities enrichXXXEntityWithInventory(...)
	// Trunk Group==TBLGROUP
	// ET == XO ENTERPRISE TRUNK
	// TN == TN POOL--
	// NBS -- NBS_CLUSTER_INFO
	// Customer -- TBL ENTERPRISE
	// TODO 10/26 : Update all etities enrichXXXEntityWithInventory(...) as per
	// this-->COMPLETED
	// method as I have fixed this
	@Override
	public LocationEntity enrichLocationEntityWithInventory(VOIPOrderRequest voipOrderRequest,
			LocationEntity locationEntity)
			throws TranslatorException, GenericException, IllegalAccessException, ApplicationInterfaceException {
		LOG.info("Entered enrichLocationEntityWithInventory");

		LOG.debug("++Level 9+++++Original Location Entity : {} ", locationEntity);

		LOG.debug("++Level 9+++++Changed Location Entity : {} ", locationEntity.getLocationEntity());

		LocationEntity locationEntityInv = orderServiceHelperImpl
				.getEntityDetailsFromInventory(locationEntity.getLocationId(), LocationEntity.class);
		
		LOG.info("locationEntityInv.getGroupUserLimit()----> {}", locationEntityInv.getGroupUserLimit());
		LOG.info("locationEntityInv.getBroadworksPortalNumber()----> {}", locationEntityInv.getBroadworksPortalNumber());
		LOG.info("locationEntity.getBroadworksPortalNumber()----> {}", locationEntity.getBroadworksPortalNumber());
		
		// Copying Location Inv Details to Original Location Entity

		LOG.debug("++Level 10+++++Original Location Entity : {} ", locationEntity);

		LOG.debug("++Level 10+++++Changed Location Entity : {} ", locationEntity.getLocationEntity());

		LOG.debug("++Level 10+++++Original Location Entity locationEntityInv : {} ", locationEntityInv);

		LOG.debug("++Level 10+++++Changed Location Entity locationEntityInv.getLocationEntity() : {} ",
				locationEntityInv.getLocationEntity());
		locationEntity = copyFields(locationEntityInv, locationEntity);

		LOG.debug("++Level 11+++++Original Location Entity : {} ", locationEntity);

		LOG.debug("++Level 11+++++Changed Location Entity : {} ", locationEntity.getLocationEntity());

		if (locationEntity.getLocationEntity() != null) {
			// LocationEntity locationEntityChanged = locationEntity.getLocationEntity();

			// Copying Location Inv Details to Changed Location Entity
			copyFields(locationEntity, locationEntity.getLocationEntity());

			LOG.debug("++Level 3+++++Original Location Entity : {} ", locationEntity);

			LOG.debug("++Level 3+++++Changed Location Entity : {} ", locationEntity.getLocationEntity());

		}

		LOG.info("Exit enrichLocationEntityWithInventory Location Enriched = {} ", locationEntity);
		return locationEntity;
	}

	/**
	 * @param currentEntity
	 * @param resultEntity
	 * @return
	 */
	private LocationEntity copyFields(LocationEntity currentLocationEntity, LocationEntity resultLocationEntity) {

		// Inventory -> original
		if (resultLocationEntity.getLocationId() == null && currentLocationEntity.getLocationId() != null) {
			resultLocationEntity.setLocationId(currentLocationEntity.getLocationId());
		}
		if (resultLocationEntity.getCustomerId() == null && currentLocationEntity.getCustomerId() != null) {
			resultLocationEntity.setCustomerId(currentLocationEntity.getCustomerId());
		}
		if (resultLocationEntity.getRegion() == null && currentLocationEntity.getRegion() != null) {
			resultLocationEntity.setRegion(currentLocationEntity.getRegion());
		}
		if (resultLocationEntity.getCity() == null && currentLocationEntity.getCity() != null) {
			resultLocationEntity.setCity(currentLocationEntity.getCity());
		}
		if (resultLocationEntity.getState() == null && currentLocationEntity.getState() != null) {
			resultLocationEntity.setState(currentLocationEntity.getState());
		}
		if (resultLocationEntity.getZip() == null && currentLocationEntity.getZip() != null) {
			resultLocationEntity.setZip(currentLocationEntity.getZip());
		}
		if (resultLocationEntity.getCountry() == null && currentLocationEntity.getCountry() != null) {
			resultLocationEntity.setCountry(currentLocationEntity.getCountry());
		}
		if (resultLocationEntity.getSipDomain() == null && currentLocationEntity.getSipDomain() != null) {
			resultLocationEntity.setSipDomain(currentLocationEntity.getSipDomain());
		}
		if (resultLocationEntity.getBroadworksPortalNumber() == null
				&& currentLocationEntity.getBroadworksPortalNumber() != null) {
			resultLocationEntity.setBroadworksPortalNumber(currentLocationEntity.getBroadworksPortalNumber());
		}
		if (resultLocationEntity.getEslId() == null && currentLocationEntity.getEslId() != null) {
			resultLocationEntity.setEslId(currentLocationEntity.getEslId());
		}
		if (resultLocationEntity.getHubLocationId() == null && currentLocationEntity.getHubLocationId() != null) {
			resultLocationEntity.setHubLocationId(currentLocationEntity.getHubLocationId());
		}
		if (resultLocationEntity.getRedundancy() == null && currentLocationEntity.getRedundancy() != null) {
			resultLocationEntity.setRedundancy(currentLocationEntity.getRedundancy());
		}
		if (resultLocationEntity.getRedundancyId() == null && currentLocationEntity.getRedundancyId() != null) {
			resultLocationEntity.setRedundancyId(currentLocationEntity.getRedundancyId());
		}
		if (resultLocationEntity.getBillingTN() == 0 && currentLocationEntity.getBillingTN() > 0) {
			resultLocationEntity.setBillingTN(Long.valueOf(currentLocationEntity.getBillingTN()));
		}				
		if (resultLocationEntity.getBroadworksPortalNumber() == null
				&& currentLocationEntity.getBroadworksPortalNumber() != null) {
			resultLocationEntity.setRedundancy(currentLocationEntity.getRedundancy());
		}
		if (resultLocationEntity.getGroupUserLimit() == null && currentLocationEntity.getGroupUserLimit() != null) {
			resultLocationEntity.setGroupUserLimit(currentLocationEntity.getGroupUserLimit());
		}
		if (resultLocationEntity.getRedundancyPriorityType() == null
				&& currentLocationEntity.getRedundancyPriorityType() != null) {
			resultLocationEntity.setRedundancyPriorityType(currentLocationEntity.getRedundancyPriorityType());
		}
		if (resultLocationEntity.getMaxActiveCall() == 0 && currentLocationEntity.getMaxActiveCall() > 0) {
			resultLocationEntity.setMaxActiveCall(currentLocationEntity.getMaxActiveCall());
		}
		if (resultLocationEntity.getMaxIncomingCall() == 0 && currentLocationEntity.getMaxIncomingCall() > 0) {
			resultLocationEntity.setMaxIncomingCall(currentLocationEntity.getMaxIncomingCall());
		}
		if (resultLocationEntity.getMaxOutgoingCall() == 0 && currentLocationEntity.getMaxOutgoingCall() > 0) {
			resultLocationEntity.setMaxOutgoingCall(currentLocationEntity.getMaxOutgoingCall());
		}
		if (resultLocationEntity.getMaxConcurrentCalls() == null
				&& currentLocationEntity.getMaxConcurrentCalls() != null) {
			resultLocationEntity.setMaxConcurrentCalls(currentLocationEntity.getMaxConcurrentCalls());
		}
		if (resultLocationEntity.getVpnName() == null && currentLocationEntity.getVpnName() != null) {
			resultLocationEntity.setVpnName(currentLocationEntity.getVpnName());
		}
		if (resultLocationEntity.getVpnPortSpeed() == null && currentLocationEntity.getVpnPortSpeed() != null) {
			resultLocationEntity.setVpnPortSpeed(currentLocationEntity.getVpnPortSpeed());
		}
		if (resultLocationEntity.getPortSpeed() == null && currentLocationEntity.getPortSpeed() != null) {
			resultLocationEntity.setPortSpeed(currentLocationEntity.getPortSpeed());
		}
		if (resultLocationEntity.getDesignId() == null && currentLocationEntity.getDesignId() != null) {
			resultLocationEntity.setDesignId(currentLocationEntity.getDesignId());
		}
		if (resultLocationEntity.getVoipServiceType() == null && currentLocationEntity.getVoipServiceType() != null) {
			resultLocationEntity.setVoipServiceType(currentLocationEntity.getVoipServiceType());
		}
		if (resultLocationEntity.getLocationType() == 0 && currentLocationEntity.getLocationType() > 0) {
			resultLocationEntity.setLocationType(currentLocationEntity.getLocationType());
		}
		if (resultLocationEntity.getName() == null && currentLocationEntity.getName() != null) {
			resultLocationEntity.setName(currentLocationEntity.getName());
		}
		if (resultLocationEntity.getAddress() == null && currentLocationEntity.getAddress() != null) {
			resultLocationEntity.setAddress(currentLocationEntity.getAddress());
		}
		if (resultLocationEntity.getPqInstanceId() == null && currentLocationEntity.getPqInstanceId() != null) {
			resultLocationEntity.setPqInstanceId(currentLocationEntity.getPqInstanceId());
		}
		if (resultLocationEntity.getWebLanguage() == null && currentLocationEntity.getWebLanguage() != null) {
			resultLocationEntity.setWebLanguage(currentLocationEntity.getWebLanguage());
		}
		if (resultLocationEntity.getVmLanguage() == null && currentLocationEntity.getVmLanguage() != null) {
			resultLocationEntity.setVmLanguage(currentLocationEntity.getVmLanguage());
		}
		if (resultLocationEntity.getMaxConcurrentOffNet() == null
				&& currentLocationEntity.getMaxConcurrentOffNet() != null) {
			resultLocationEntity.setMaxConcurrentOffNet(currentLocationEntity.getMaxConcurrentOffNet());
		}
		if (resultLocationEntity.getLocationCclIndicator() == null
				&& currentLocationEntity.getLocationCclIndicator() != null) {
			resultLocationEntity.setLocationCclIndicator(currentLocationEntity.getLocationCclIndicator());
		}
		if (resultLocationEntity.getServiceLevel() == null && currentLocationEntity.getServiceLevel() != null) {
			resultLocationEntity.setServiceLevel(currentLocationEntity.getServiceLevel());
		}
		if (resultLocationEntity.getVARRS() == null && currentLocationEntity.getVARRS() != null) {
			resultLocationEntity.setVARRS(currentLocationEntity.getVARRS());
		}
		if (resultLocationEntity.getAdvantageClub() == null && currentLocationEntity.getAdvantageClub() != null) {
			resultLocationEntity.setAdvantageClub(currentLocationEntity.getAdvantageClub());
		}
		if (resultLocationEntity.getEmergencyCallLine() == null
				&& currentLocationEntity.getEmergencyCallLine() != null) {
			resultLocationEntity.setEmergencyCallLine(currentLocationEntity.getEmergencyCallLine());
		}
		if (resultLocationEntity.getCallingPartyPrivacy() == null
				&& currentLocationEntity.getCallingPartyPrivacy() != null) {
			resultLocationEntity.setCallingPartyPrivacy(currentLocationEntity.getCallingPartyPrivacy());
		}
		if (resultLocationEntity.getLinePortLength() == null && currentLocationEntity.getLinePortLength() != null) {
			resultLocationEntity.setLinePortLength(currentLocationEntity.getLinePortLength());
		}
		if (resultLocationEntity.getExtensionLength() == null && currentLocationEntity.getExtensionLength() != null) {
			resultLocationEntity.setExtensionLength(currentLocationEntity.getExtensionLength());
		}
		if (resultLocationEntity.getEnhancedANIInd() == null && currentLocationEntity.getEnhancedANIInd() != null) {
			resultLocationEntity.setEnhancedANIInd(currentLocationEntity.getEnhancedANIInd());
		}
		if (resultLocationEntity.getTypeOfLoc() == null && currentLocationEntity.getTypeOfLoc() != null) {
			resultLocationEntity.setTypeOfLoc(currentLocationEntity.getTypeOfLoc());
		}
		if (resultLocationEntity.getAuthServices() == null && currentLocationEntity.getAuthServices() != null) {
			resultLocationEntity.setAuthServices(currentLocationEntity.getAuthServices());
		}
		if (resultLocationEntity.getBwLocationId() == null && currentLocationEntity.getBwLocationId() != null) {
			resultLocationEntity.setBwLocationId(currentLocationEntity.getBwLocationId());
		}
		if (resultLocationEntity.getEsbcSignalingIP() == null && currentLocationEntity.getEsbcSignalingIP() != null) {
			resultLocationEntity.setEsbcSignalingIP(currentLocationEntity.getEsbcSignalingIP());
		}

		// Missings
		// POLICY_SERVICE_ID

		return resultLocationEntity;
	}

}
