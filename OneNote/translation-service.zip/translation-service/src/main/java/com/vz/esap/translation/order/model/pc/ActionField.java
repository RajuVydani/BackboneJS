package com.vz.esap.translation.order.model.pc;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;

import com.fasterxml.jackson.annotation.JsonProperty;

@XmlAccessorType(XmlAccessType.FIELD)
public class ActionField {

	@XmlElement(name = "Name")
	@JsonProperty(value = "Name")
	private String name;

	@XmlElement(name = "Value")
	@JsonProperty(value = "Value")
	private String value;

	public String getName() {
		return name;
	}

	public void setName(String Name) {
		this.name = Name;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String Value) {
		this.value = Value;
	}

	@Override
	public String toString() {
		return "ClassPojo [Name = " + name + ", Value = " + value + "]";
	}
}