package com.vz.esap.translation.order.model.pc;

import com.fasterxml.jackson.annotation.JsonProperty;

public class BodData {
	
	@JsonProperty(value = "VOIPOrderRequest")
	private VOIPOrderRequest voipOrderRequest;

	public VOIPOrderRequest getVoipOrderRequest() {
		return voipOrderRequest;
	}

	public void setVoipOrderRequest(VOIPOrderRequest voipOrderRequest) {
		this.voipOrderRequest = voipOrderRequest;
	}
	
}
