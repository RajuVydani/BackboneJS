package com.vz.esap.translation.order.parser;

import static java.util.Arrays.stream;

import java.math.BigInteger;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.vz.esap.translation.connector.model.DBServiceResponse;
import com.vz.esap.translation.connector.model.TblRow;
import com.vz.esap.translation.connector.service.InventoryDomainDataServiceImpl;
import com.vz.esap.translation.entity.DeviceEntity;
import com.vz.esap.translation.entity.Entity.GroupType;
import com.vz.esap.translation.entity.PilotUser;
import com.vz.esap.translation.entity.TrunkGroupEntity;
import com.vz.esap.translation.enums.EsapEnum;
import com.vz.esap.translation.enums.EsapEnum.AuthFeatureType;
import com.vz.esap.translation.enums.EsapEnum.ChangeType;
import com.vz.esap.translation.enums.EsapEnum.SolutionType;
import com.vz.esap.translation.enums.EsapEnum.TrunkGroupType;
import com.vz.esap.translation.exception.ApplicationInterfaceException;
import com.vz.esap.translation.exception.GenericException;
import com.vz.esap.translation.exception.TranslatorException;
import com.vz.esap.translation.order.entity.identifier.util.EntityIdentifireUtil;
import com.vz.esap.translation.order.model.request.ChangeManagement;
import com.vz.esap.translation.order.model.request.ChangedElement;
import com.vz.esap.translation.order.model.request.ConvergedService;
import com.vz.esap.translation.order.model.request.Feature;
import com.vz.esap.translation.order.model.request.ParamInfo;
import com.vz.esap.translation.order.model.request.Specification;
import com.vz.esap.translation.order.model.request.VOIPOrderRequest;
import com.vz.esap.translation.order.service.helper.OrderServiceHelper;
import com.vz.esap.translation.util.InventoryUtil;

import reactor.util.CollectionUtils;

@Component
public class TrunkOrderParserImpl implements TrunkOrderParser {

	private static final Logger LOG = LoggerFactory.getLogger(TrunkOrderParserImpl.class);

	@Autowired
	private EntityIdentifireUtil entityIdentifireUtil;

	@Autowired
	private OrderServiceHelper orderServiceHelperImpl;

	@Autowired
	private InventoryDomainDataServiceImpl inventoryDomainDataServiceImpl;
	
	@Autowired
	private InventoryUtil inventoryUtil;

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.vz.esap.translation.order.parser.TrunkOrderParser#parseTrunkOrder(com.vz.
	 * esap.translation.order.model.request.VOIPOrderRequest)
	 */
	@Override
	public ArrayList<TrunkGroupEntity> parseTrunkOrder(VOIPOrderRequest voipOrderRequest)
			throws TranslatorException, ParseException {
		LOG.info("TrunkGroupEntity - parseTrunkGroup");
		ArrayList<TrunkGroupEntity> trunkGroupEntityList = null;
		TrunkGroupEntity trunkGroupEntity = null;
		ConvergedService convergedService = null;
		Feature[] features = null;
		String cityCode = null;
		String pilotTn = null;
		List<Feature> locFeat = null;
		String pqEslId = null;
		List<Feature> decFeat = null;
		long deviceMapId = -1;
		String sigDir = null;
		String entityAction = null;
		Specification[] specifications = null;
		PilotUser pilotUser = null;
		String bwEntId = null;
		Set<String> selectColumnSet = null;
		List<String[]> whereClauseList = null;
		DBServiceResponse dbServiceResponseCustomer = null;
		List<Specification> eslSpec = null;
		List<Specification> devNameSpec = null;
		String bwDeviceId = null;
		String trunkGroupId = null;
		List<Feature> nativeTrunkTypeFeatures = null;
		String nativeTrunkFeatures = null;
		boolean isLine = false;
		List<Feature> trunkFeatList = null;
		List<Feature> entFeat = null;
		List<Specification> bwEntSpec = null;
		List<Specification> trunkSessionCountSpec = null;
		int sessionCount = 0;
		Map<String, String> deviceResultMap;
		List<Feature>  trunkLinePriLineFeatures = null;
		String trunkInstanceIdChanged = null;
		List<String> trunkInstanceIdChangedList = null;

		try {

			convergedService = voipOrderRequest.getConvergedService();
			
			LOG.debug("TrunkGroupEntity - parseTrunkGroup: convergedService: {}", convergedService);
			LOG.debug("TrunkGroupEntity - parseTrunkGroup: voipOrderRequest.getOrderHeader().getOrderType():{}",
					voipOrderRequest.getOrderHeader().getOrderType());
			
			if (convergedService.getFeature() != null) {

				nativeTrunkTypeFeatures = stream(voipOrderRequest.getConvergedService().getFeature())
						.filter(trunkFeature -> "FET_PRILIN".equalsIgnoreCase(trunkFeature.getCode())
								|| "FET_XO_TRULIN".equalsIgnoreCase(trunkFeature.getCode()) 
								|| "FET_LIN".equalsIgnoreCase(trunkFeature.getCode()) 
								|| "FET_PRI".equalsIgnoreCase(trunkFeature.getCode()) 
								|| "FET_XO_TRUON".equalsIgnoreCase(trunkFeature.getCode()) 
								|| "FET_HPBX_TRU".equalsIgnoreCase(trunkFeature.getCode()) 
								|| "FET_HPBX_TRU_LOC".equalsIgnoreCase(trunkFeature.getCode()))
						.collect(Collectors.toList());
				
				//Start:PRI/LIN,TRU/LIN Fix
				
				trunkLinePriLineFeatures = stream(voipOrderRequest.getConvergedService().getFeature())
						.filter(trunkFeature -> "FET_PRILIN".equalsIgnoreCase(trunkFeature.getCode())
								|| "FET_XO_TRULIN".equalsIgnoreCase(trunkFeature.getCode()))
						.collect(Collectors.toList());
				
				//End:PRI/LIN,TRU/LIN Fix
				
				//Start: Trunk Change Fix:
				if (voipOrderRequest.getChangeManagement() != null) {
					for (ChangeManagement changeManagement : voipOrderRequest.getChangeManagement()) {
						trunkInstanceIdChangedList = new ArrayList<>();
						for (ChangedElement changedElement : changeManagement.getChangedElement()) {
							if ("ADDED".equalsIgnoreCase(changedElement.getChangeType())
									&& "FET_XO_TRU".equalsIgnoreCase(changedElement.getFeatureCode())) {
								trunkInstanceIdChanged = changedElement.getFeatureInstanceId();
								trunkInstanceIdChangedList.add(trunkInstanceIdChanged);
								LOG.info("TrunkInstanceIdChanged = {}", trunkInstanceIdChanged);
							}
						}
					}
				}
				
				//End: Trunk Change Fix:

				features = convergedService.getFeature();
				trunkGroupEntityList = new ArrayList<>();

				if (voipOrderRequest.getLocation() != null
						&& voipOrderRequest.getLocation().getLocationAddress() != null
						&& voipOrderRequest.getLocation().getLocationAddress().getCity() != null) {
					cityCode = voipOrderRequest.getLocation().getLocationAddress().getCity();
				}
				
				entFeat = stream(voipOrderRequest.getConvergedService().getFeature())
						.filter(feature -> "EFET_VOIP_ENT_LVL".equalsIgnoreCase(feature.getCode())).collect(Collectors.toList());
				
				if(!CollectionUtils.isEmpty(entFeat)) {				
					bwEntSpec = stream(entFeat.get(0).getSpecification())
							.filter(spec -> "BW_ENTERPRISE_ID".equalsIgnoreCase(spec.getCode())).collect(Collectors.toList());				
				}

				if (voipOrderRequest.getOrderHeader().getBwEnterpriseId() != null) {
					bwEntId = voipOrderRequest.getOrderHeader().getBwEnterpriseId();
				} else if (!CollectionUtils.isEmpty(bwEntSpec)) {
					bwEntId = bwEntSpec.get(0).getValue();
				} else {
					bwEntId = entityIdentifireUtil.createBwEnterpriseId(voipOrderRequest.getOrderHeader().getGCHId(),
							voipOrderRequest.getOrderHeader().getSolutionType(), null,
							voipOrderRequest.getOrderHeader().getEnterpriseId());
				}
					

				locFeat = stream(features).filter(feat -> "FET_LOC_LVL".equalsIgnoreCase(feat.getCode()))
						.collect(Collectors.toList());

				pqEslId = voipOrderRequest.getConvergedService().getID();

				decFeat = stream(features).filter(feat -> "EFET_VOIP_DEVICE_LVL".equalsIgnoreCase(feat.getCode())
						|| "FET_DE".equalsIgnoreCase(feat.getCode())
						|| "FET_DE_LOC".equalsIgnoreCase(feat.getCode())).collect(Collectors.toList());

				if (!CollectionUtils.isEmpty(decFeat)) {
					deviceMapId = Long.valueOf(decFeat.get(0).getInstanceId());

					devNameSpec = stream(decFeat.get(0).getSpecification())
							.filter(spec -> "ESP_LOGICAL_DEVICE_NAME".equalsIgnoreCase(spec.getCode()))
							.collect(Collectors.toList());
				}
				
				//Start : Session Feature Fix
				
				trunkFeatList = stream(voipOrderRequest.getConvergedService().getFeature())
						.filter(truFeat -> "FET_XO_TRU".equalsIgnoreCase(truFeat.getCode()))
						.collect(Collectors.toList());

				if (!CollectionUtils.isEmpty(trunkFeatList)) {
					for (Feature trunkFeat : trunkFeatList) {
						trunkSessionCountSpec = stream(trunkFeat.getSpecification())
								.filter(spec -> "SP_TRK".equalsIgnoreCase(spec.getCode()))
								.collect(Collectors.toList());

						if (!CollectionUtils.isEmpty(trunkSessionCountSpec)) {
							sessionCount = sessionCount
									+ Integer.parseInt(trunkSessionCountSpec.get(0).getValue());
						}
					}
					LOG.info("Session Total Count ={} ", sessionCount);					
				}
				//End : Session Feature Fix

				int index = 0;
				for (Feature feature : features) {
					if (("EFET_VOIP_TRUNK_LVL".equalsIgnoreCase(feature.getCode())
							|| "FET_XO_TRU".equalsIgnoreCase(feature.getCode())
							|| "FET_XO_TRU_CON".equalsIgnoreCase(feature.getCode())
							|| "FET_XO_TRU_CON_LINE_LOC".equalsIgnoreCase(feature.getCode())
							|| "FET_HPBX_TRU".equalsIgnoreCase(feature.getCode())
							|| "FET_HPBX_TRU_LOC".equalsIgnoreCase(feature.getCode()))
							&& ("I".equalsIgnoreCase(voipOrderRequest.getOrderHeader().getOrderType())
									|| "C".equalsIgnoreCase(voipOrderRequest.getOrderHeader().getOrderType()))) {

						trunkGroupEntity = new TrunkGroupEntity();
						
						if (!CollectionUtils.isEmpty(decFeat) && decFeat.size() > index && decFeat.get(index) != null) {
							LOG.info("Device map Id  - {}", decFeat.get(index).getInstanceId());

							deviceMapId = Long.valueOf(decFeat.get(index).getInstanceId());
						}
						index ++;
						trunkGroupEntity.setDeviceMapId(deviceMapId);

						if (voipOrderRequest.getOrderHeader().getEnterpriseId() != null)
							trunkGroupEntity.setEnterpriseId(voipOrderRequest.getOrderHeader().getEnterpriseId());
						if (voipOrderRequest.getOrderHeader().getLocationId() != null)
							trunkGroupEntity.setLocationId(voipOrderRequest.getOrderHeader().getLocationId());

						if (feature.getInstanceId() != null) {
							trunkGroupEntity.setGroupId(new Long(feature.getInstanceId()));
						}
						if (feature.getActionCode() != null) {
							entityAction = feature.getActionCode();
							if ("ADD".equalsIgnoreCase(entityAction)) {
								trunkGroupEntity.setAction(EsapEnum.OrderAction.ADD);
							} else if ("CHANGE".equalsIgnoreCase(entityAction)) {
								trunkGroupEntity.setAction(EsapEnum.OrderAction.MODIFY);
							} else if ("DELETE".equalsIgnoreCase(entityAction)) {
								trunkGroupEntity.setAction(EsapEnum.OrderAction.DELETE);
							}
						}

						specifications = feature.getSpecification();
						LOG.debug("TrunkGroupEntity - parseTrunkGroup: specifications: {}", specifications);
						
						for (Specification specification : specifications) {
							
							if ("SP_XO_BW_TRUNK_ID_LOC".equalsIgnoreCase(specification.getCode())) {
								trunkGroupEntity.setBwTrunkGroupId(specification.getValue());

							}
							
							if ("SP_XO_ASSO_LOC_INST_ID_LOC".equalsIgnoreCase(specification.getCode())) { 								
								trunkGroupEntity.setLocationId(specification.getValue());
								
							}
							
							if ("ESP_EXT_REQ_FLAG".equalsIgnoreCase(specification.getCode())) {
								boolean createExtension = "Yes".equalsIgnoreCase(specification.getValue()) ? true
										: false;
								trunkGroupEntity.setCreateExtension(createExtension);

							}
							if ("SP_VOIP_TRUNK_VM_NUM".equalsIgnoreCase(specification.getCode())) {
								trunkGroupEntity.setVMNumber(specification.getValue());
							}
							if ("SP_VOIP_TRUNK_VM_TYPE".equalsIgnoreCase(specification.getCode())) {
								trunkGroupEntity.setVMType(specification.getValue());
							}
							if ("SP_VOIP_TERM_OPT".equalsIgnoreCase(specification.getCode())) {
								trunkGroupEntity.setTerminationOption(specification.getValue());
							}
							if ("ESP_FORWARD_TO_NUMBER".equalsIgnoreCase(specification.getCode())) {
								trunkGroupEntity.setForwardToNumber(specification.getValue());
							}
							if ("ESP_TRUNK_GROUP_NAM".equalsIgnoreCase(specification.getCode())) {
								trunkGroupEntity.setName(specification.getValue());
							}
							if ("SP_XO_TRU_GRP_NM".equalsIgnoreCase(specification.getCode())) {
								trunkGroupEntity.setName(specification.getValue());
							}
							if ("SP_VOIP_INVITATION_TIMER".equalsIgnoreCase(specification.getCode())) {
								trunkGroupEntity.setInvitationTimer(new Integer(specification.getValue()));
							}
							if ("ESP_MAX_CONCURRENT_CALLS".equalsIgnoreCase(specification.getCode())) {
								trunkGroupEntity.setMaxConcurrentCallLimit(new BigInteger(specification.getValue()));
							}
							if ("SP_XO_PILNUM".equalsIgnoreCase(specification.getCode())) {

								pilotTn = specification.getValue();
								LOG.info("pilotTn 1 - parseTrunkOrder : {}", pilotTn);
								trunkGroupEntity.setCallingLineIdPhoneNumber(pilotTn);
								trunkGroupEntity.setPilotTn(pilotTn);
								trunkGroupEntity.setExtension(specification.getValue().substring(pilotTn.length() - 4));
								LOG.info("pilotTn 2 - parseTrunkOrder : {} ", pilotTn);
							}
							if ("SP_TRK".equalsIgnoreCase(specification.getCode())) {
								trunkGroupEntity.setCommittedSessionCount(specification.getValue());
								trunkGroupEntity.setTrunkCallCapacity(Long.valueOf(specification.getValue()));
								trunkGroupEntity.setMaxActiveCalls(specification.getValue()); //Added by 738577 as individual call capacity is handled individually for different TN Entity   
							}
							if ("SP_XO_INT".equalsIgnoreCase(specification.getCode())) {
								trunkGroupEntity.setInternationalLDRestriction(specification.getValue());
							}
							if ("SP_XO_SIG".equalsIgnoreCase(specification.getCode())) {

								if ("2 Way".equalsIgnoreCase(specification.getValue()))
									sigDir = EsapEnum.SignalingDirection.TWO_WAY.toString();
								if ("Inbound".equalsIgnoreCase(specification.getValue()))
									sigDir = EsapEnum.SignalingDirection.INBOUND.toString();

								trunkGroupEntity.setSignalingDirection(sigDir);
							}
						}
						
						if(trunkGroupEntity.getLocationId() == null) {
							trunkGroupEntity.setLocationId(voipOrderRequest.getOrderHeader().getLocationId());
							
						}
						
						
						LOG.debug("+++++++++++++++++ BW Enterprise Id : {} pqEslId {} sigDir {} cityCode {} ", bwEntId,
								pqEslId, sigDir, cityCode);
						if (voipOrderRequest.getOrderHeader() != null
								&& voipOrderRequest.getOrderHeader().getSolutionType() != null
								&& !(SolutionType.ESIP_EBL.equals(voipOrderRequest.getOrderHeader().getSolutionType())
										|| SolutionType.HPBX
												.equals(voipOrderRequest.getOrderHeader().getSolutionType()))) {

							trunkGroupId = entityIdentifireUtil.createBwTgId(bwEntId, pqEslId, sigDir, cityCode);
							trunkGroupEntity.setBwTrunkGroupId(trunkGroupId);

							trunkGroupEntity.setOtgDtgIdentity(
									entityIdentifireUtil.createBwTgOtgId(bwEntId, pqEslId, sigDir, cityCode));

							if (!CollectionUtils.isEmpty(decFeat)) {
								bwDeviceId = entityIdentifireUtil.createBwDeviceId(decFeat.get(0).getInstanceId(),
										sigDir);
							}
						}

						if (sigDir != null) {
							if (EsapEnum.SignalingDirection.TWO_WAY.toString().equalsIgnoreCase(sigDir))
								trunkGroupEntity.setGroupType(GroupType.TWO_WAY);
							else if (EsapEnum.SignalingDirection.INBOUND.toString().equalsIgnoreCase(sigDir))
								trunkGroupEntity.setGroupType(GroupType.INBOUND);
						}

						if (!CollectionUtils.isEmpty(nativeTrunkTypeFeatures))
							nativeTrunkFeatures = nativeTrunkTypeFeatures.get(0).getCode();
						else
							nativeTrunkFeatures = "NONE";

						isLine = "FET_XO_TRU_CON_LINE_LOC".equalsIgnoreCase(feature.getCode());

						if (!isLine && Arrays.asList("FET_PRILIN", "FET_PRI").contains(nativeTrunkFeatures)) {
							trunkGroupEntity.setGroupType(GroupType.PRI_DID);
							trunkGroupEntity.setSignalingDirection(EsapEnum.SignalingDirection.TWO_WAY.toString());
						} else if (!isLine
								&& Arrays.asList("FET_XO_TRULIN", "FET_XO_TRUON").contains(nativeTrunkFeatures)) {
							trunkGroupEntity.setGroupType(GroupType.NON_PRI_DID);
							trunkGroupEntity.setSignalingDirection(EsapEnum.SignalingDirection.TWO_WAY.toString());
						} else if (isLine) {
							trunkGroupEntity.setGroupType(GroupType.LINE);
						}

						// Start: EBL Change
						if (!locFeat.isEmpty()) {
							eslSpec = stream(locFeat.get(0).getSpecification())
									.filter(spec -> "SP_XO_ESL".equalsIgnoreCase(spec.getCode()))
									.collect(Collectors.toList());

							if (!eslSpec.isEmpty()) {

								if (voipOrderRequest.getOrderHeader().getSolutionType() != null) {
									trunkGroupEntity
											.setSolutionType(voipOrderRequest.getOrderHeader().getSolutionType());

									if (SolutionType.ESIP_ESL
											.equals(voipOrderRequest.getOrderHeader().getSolutionType()))
										trunkGroupEntity
												.setCustomerId(voipOrderRequest.getOrderHeader().getEnterpriseId());

									if (SolutionType.ESIP_EBL
											.equals(voipOrderRequest.getOrderHeader().getSolutionType()))
										trunkGroupEntity.setCustomerId(orderServiceHelperImpl
												.getEnterpriseInformationFromEsl(eslSpec.get(0).getValue()));
								}

								int groupType = 0;

								selectColumnSet = new HashSet<>();
								selectColumnSet.add("GROUP_ID");
								selectColumnSet.add("GROUP_NAME");
								selectColumnSet.add("GROUP_TYPE");
								selectColumnSet.add("LOCATION_ID");
								selectColumnSet.add("TG_ID");
								selectColumnSet.add("DEVICE_MAP_ID");

								if (trunkGroupEntity.getGroupType().equals(GroupType.TWO_WAY))
									groupType = TrunkGroupType.TWO_WAY.getIndex();
								else if (trunkGroupEntity.getGroupType().equals(GroupType.INBOUND))
									groupType = TrunkGroupType.INBOUND.getIndex();
								else if (trunkGroupEntity.getGroupType().equals(GroupType.PRI_DID))
									groupType = TrunkGroupType.PRI_DID.getIndex();
								else if (trunkGroupEntity.getGroupType().equals(GroupType.LINE))
									groupType = TrunkGroupType.LINE.getIndex();
								else if (trunkGroupEntity.getGroupType().equals(GroupType.NON_PRI_DID))
									groupType = TrunkGroupType.NON_PRI_DID.getIndex();

								whereClauseList = new ArrayList<>();
								whereClauseList.add(new String[] { "LOCATION_ID", eslSpec.get(0).getValue() });
								whereClauseList.add(new String[] { "GROUP_TYPE", String.valueOf(groupType) });

								dbServiceResponseCustomer = inventoryDomainDataServiceImpl.searchInventory("TBL_GROUP",
										selectColumnSet, whereClauseList);

								if (dbServiceResponseCustomer.getNumberOfRecords() != 0) {
									for (TblRow tblRow : dbServiceResponseCustomer.getTableRows()) {
										if (tblRow.getTblRow().containsKey("GROUP_ID")) {
											trunkGroupEntity
													.setVirtualTrunkId(tblRow.getTblRow().get("GROUP_ID").getValue());
											LOG.info("For EBL the VirtualTrunkId : {}",
													trunkGroupEntity.getVirtualTrunkId());
										}
										if (tblRow.getTblRow().containsKey("TG_ID")) {
											trunkGroupEntity
													.setBwTrunkGroupId(tblRow.getTblRow().get("TG_ID").getValue());
											trunkGroupId = tblRow.getTblRow().get("TG_ID").getValue();
											LOG.info("For EBL the BwTrunkGroupId : {}",
													trunkGroupEntity.getBwTrunkGroupId());
										}
										if (tblRow.getTblRow().containsKey("DEVICE_MAP_ID")) {
											deviceMapId = Long
													.valueOf(tblRow.getTblRow().get("DEVICE_MAP_ID").getValue());
											bwDeviceId = entityIdentifireUtil
													.createBwDeviceId(String.valueOf(deviceMapId), sigDir);
											LOG.info("For EBL the DeviceMapId : {}", deviceMapId);
											LOG.info("For EBL the BWDeviceId : {}", bwDeviceId);
										}
									}
								}
							}
						}

						trunkGroupEntity.setDeviceMapId(deviceMapId);
						
						//BUG TG-1 : Multiple Device Map Id is not getting assigned to correct TG #91000202, #8380001
						
						// trunkGroupEntity.setMaxActiveCalls(String.valueOf(sessionCount));  //commented by 738577 as now each TN Type Max Active Call is handled differently for each feature 
					
						if (trunkGroupId != null && bwEntId != null && pilotTn != null && bwDeviceId != null) {
							pilotUser = new PilotUser();
							pilotUser.setUserId(trunkGroupId + "@" + bwEntId.toLowerCase() + ".vm.xohost.com");
							pilotUser.setFirstName("Pilot-" + pilotTn.substring(pilotTn.length() - 4));
							pilotUser.setLastName(trunkGroupId.substring(trunkGroupId.indexOf('-') + 1));
							LOG.info("pilotTn 3- parseTrunkOrder : {} ", pilotTn);
							pilotUser.setPhoneNumber(Long.valueOf(pilotTn));
							pilotUser.setCallingLineIdFirstName("Pilot-" + pilotTn.substring(pilotTn.length() - 4));
							pilotUser.setCallingLineIdLastName(trunkGroupId.substring(trunkGroupId.indexOf('-') + 1));
							
							//This below section is no more required so commenting:
							//pilotUser.setLinePort(pilotTn);
							pilotUser.setDeviceLevel(null);
							pilotUser.setDeviceName(bwDeviceId);

							trunkGroupEntity.setPilotUser(pilotUser);
						}
						
						//Start: Flex Dev Name Fix
						
						DeviceEntity device = null;
						
						if(SolutionType.IPFLEX.equals(voipOrderRequest.getOrderHeader().getSolutionType())) {
							
							device = new DeviceEntity();
							device.setDeviceMapId(deviceMapId);
							device.setDeviceName(String.valueOf(deviceMapId));
							
							//Start Port Number Fix
							
							device.setLinePort(pilotTn);//TODO Fix this with actual CPE Port Number
							
							//End Port Number Fix
							
							trunkGroupEntity.setDevice(device);
							
							LOG.info("Parser Here with device.getDeviceName()--> {}" ,device.getDeviceName());
						}
						
						if (SolutionType.HPBX.equals(voipOrderRequest.getOrderHeader().getSolutionType())) {
							deviceResultMap = inventoryUtil
									.getHpbxDeviceFromEnterprise(voipOrderRequest.getOrderHeader().getEnterpriseId());

							if (deviceResultMap != null) {
								device = new DeviceEntity();
								device.setDeviceMapId(Long.valueOf(deviceResultMap.get("DEVICE_MAP_ID")));
								device.setDeviceName(String.valueOf(deviceResultMap.get("DEVICE_MAP_ID")));

								trunkGroupEntity.setDevice(device);

								trunkGroupEntity.setDeviceMapId(Long.valueOf(deviceResultMap.get("DEVICE_MAP_ID")));

								LOG.info("Parser Here with device.getDeviceName()--> {}", device.getDeviceName());

							}
						}
						
						//End: Flex Hpbx Dev Name Fix
						
						if ("C".equalsIgnoreCase(voipOrderRequest.getOrderHeader().getOrderType())) {

							if (!CollectionUtils.isEmpty(trunkInstanceIdChangedList)) {
								LOG.info("Trunk Present in Change Management");

								for (String trunkChangedId : trunkInstanceIdChangedList) {
									if (feature.getInstanceId().equalsIgnoreCase(trunkChangedId)) {
										LOG.info("Trunk Instance Id Included In ADDED Change Management = {}",
												feature.getInstanceId());
										// Do Nothing

									} else {
										LOG.info("Trunk Instance Id NOT Included In Change Management = {}",
												feature.getInstanceId());

										TrunkGroupEntity changeTrunkGroup = parseTrunkGroupChangeOrder(
												voipOrderRequest);
										trunkGroupEntity.setTrunkGroupEntity(changeTrunkGroup);
									}
								}
							} else {
								LOG.info("No Trunk in Change Management and Trunk Instance Id = {}",
										feature.getInstanceId());
								TrunkGroupEntity changeTrunkGroup = parseTrunkGroupChangeOrder(voipOrderRequest);
								trunkGroupEntity.setTrunkGroupEntity(changeTrunkGroup);
							}
						}
						
						//AuthFeatureType
						if (Arrays.asList(SolutionType.ESIP_ESL, SolutionType.ESIP_EBL)
								.contains(voipOrderRequest.getOrderHeader().getSolutionType())) {
							trunkGroupEntity.setAuthFeatureType(AuthFeatureType.FET_ESIP);
						} else if (SolutionType.IPFLEX.equals(voipOrderRequest.getOrderHeader().getSolutionType())) {
							trunkGroupEntity.setAuthFeatureType(orderServiceHelperImpl.getAuthFeatureType(voipOrderRequest));
						} else if (SolutionType.HPBX.equals(voipOrderRequest.getOrderHeader().getSolutionType())) {
							trunkGroupEntity.setAuthFeatureType(AuthFeatureType.FET_HPBX);
						}
						//
						trunkGroupEntityList.add(trunkGroupEntity);
					}
				}
			}
		} catch (Exception e) {
			LOG.error("Exception {} ", e);
			LOG.error("Exception Stack Trace {} ", e);
			throw new TranslatorException(TranslatorException.ErrorCode.ORDER_NOT_SAVABLE,
					"Unexpected Error Occured while Parsing Trunk Order");
		}
		LOG.info("trunkGroupEntityList.size() : {}", trunkGroupEntityList.size());
		return trunkGroupEntityList;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.vz.esap.translation.order.parser.TrunkOrderParser#
	 * parseTrunkGroupChangeOrder(com.vz.
	 * esap.translation.order.model.request.VOIPOrderRequest)
	 */
	// new/change TrunkGroup entities.
	public TrunkGroupEntity parseTrunkGroupChangeOrder(VOIPOrderRequest voipOrderRequest)
			throws TranslatorException, ApplicationInterfaceException, GenericException {

		LOG.info("Entered - parseTrunkGroupChangeOrder");

		ChangeManagement[] changeManagements = voipOrderRequest.getChangeManagement();

		if (changeManagements == null) {
			// TODO: Logic for the ADD
			return null;
		}

		TrunkGroupEntity changeTrunkGroup = new TrunkGroupEntity();
		changeTrunkGroup.setLocationId(voipOrderRequest.getConvergedService().getID());
		
		List<Feature> trunkFeature = stream(voipOrderRequest.getConvergedService().getFeature())
				.filter(feature -> "EFET_VOIP_TRUNK_LVL".equalsIgnoreCase(feature.getCode()))
				.collect(Collectors.toList());

		List<Feature> xoTruFeature = stream(voipOrderRequest.getConvergedService().getFeature())
				.filter(feature -> "FET_XO_TRU".equalsIgnoreCase(feature.getCode()))
				.collect(Collectors.toList());
		
		List<Feature> xoTruHbpxFeature = stream(voipOrderRequest.getConvergedService().getFeature())
				.filter(feature -> "FET_HPBX_TRU".equalsIgnoreCase(feature.getCode()))
				.collect(Collectors.toList());		

		List<Feature> xoTruConFeature = stream(voipOrderRequest.getConvergedService().getFeature())
				.filter(feature -> "FET_XO_TRU_CON".equalsIgnoreCase(feature.getCode()))
				.collect(Collectors.toList());

		List<Feature> xoTruConLineLocFeature = stream(voipOrderRequest.getConvergedService().getFeature())
				.filter(feature -> "FET_XO_TRU_CON_LINE_LOC".equalsIgnoreCase(feature.getCode()))
				.collect(Collectors.toList());

		List<Feature> locFeature = stream(voipOrderRequest.getConvergedService().getFeature())
				.filter(feature -> "FET_LOC_LVL".equalsIgnoreCase(feature.getCode()))
				.collect(Collectors.toList());

		List<Feature> devFeature = stream(voipOrderRequest.getConvergedService().getFeature())
				.filter(feature -> "EFET_VOIP_DEVICE_LVL".equalsIgnoreCase(feature.getCode())
						|| "FET_DE".equalsIgnoreCase(feature.getCode())
						|| "FET_DE_LOC".equalsIgnoreCase(feature.getCode()))
				.collect(Collectors.toList());

		List<Feature> sessionFeature = stream(voipOrderRequest.getConvergedService().getFeature())
				.filter(feature -> "FET_XO_SES".equalsIgnoreCase(feature.getCode()))
				.collect(Collectors.toList());

		for (ChangeManagement changeManagement : changeManagements) {

			ChangedElement[] changeElements = changeManagement.getChangedElement();

			if (changeElements != null && changeElements.length > 0) {
				for (ChangedElement changedElement : changeElements) {

					if (!trunkFeature.isEmpty()
							&& trunkFeature.get(0).getCode().equalsIgnoreCase(changedElement.getFeatureCode())
							&& trunkFeature.get(0).getInstanceId()
									.equalsIgnoreCase(changedElement.getFeatureInstanceId())) {

						if (changedElement.getChangeType() != null
								&& ChangeType.CHANGED.toString().equalsIgnoreCase(changedElement.getChangeType())
								&& changedElement.getSpecificationCode() != null) {

							createChangedTrunkGroupEntity(changeTrunkGroup, changedElement.getSpecificationCode(),
									changedElement.getNewValue(), voipOrderRequest);

						}

					} else if (!xoTruFeature.isEmpty()
							&& xoTruFeature.get(0).getCode().equalsIgnoreCase(changedElement.getFeatureCode())
							&& xoTruFeature.get(0).getInstanceId()
									.equalsIgnoreCase(changedElement.getFeatureInstanceId())) {
						if (changedElement.getChangeType() != null
								&& ChangeType.CHANGED.toString().equalsIgnoreCase(changedElement.getChangeType())
								&& changedElement.getSpecificationCode() != null) {

							createChangedTrunkGroupEntity(changeTrunkGroup, changedElement.getSpecificationCode(),
									changedElement.getNewValue(), voipOrderRequest);

						}
					}  else if (!xoTruHbpxFeature.isEmpty()
							&& xoTruHbpxFeature.get(0).getCode().equalsIgnoreCase(changedElement.getFeatureCode())
							&& xoTruHbpxFeature.get(0).getInstanceId()
									.equalsIgnoreCase(changedElement.getFeatureInstanceId())) {
						if (changedElement.getChangeType() != null
								&& ChangeType.CHANGED.toString().equalsIgnoreCase(changedElement.getChangeType())
								&& changedElement.getSpecificationCode() != null) {

							createChangedTrunkGroupEntity(changeTrunkGroup, changedElement.getSpecificationCode(),
									changedElement.getNewValue(), voipOrderRequest);

						}
					} else if (!xoTruConFeature.isEmpty()
							&& xoTruConFeature.get(0).getCode().equalsIgnoreCase(changedElement.getFeatureCode())
							&& xoTruConFeature.get(0).getInstanceId()
									.equalsIgnoreCase(changedElement.getFeatureInstanceId())) {
						if (changedElement.getChangeType() != null
								&& ChangeType.CHANGED.toString().equalsIgnoreCase(changedElement.getChangeType())
								&& changedElement.getSpecificationCode() != null) {

							createChangedTrunkGroupEntity(changeTrunkGroup, changedElement.getSpecificationCode(),
									changedElement.getNewValue(), voipOrderRequest);

						}
					} else if (!xoTruConLineLocFeature.isEmpty()
							&& xoTruConLineLocFeature.get(0).getCode().equalsIgnoreCase(changedElement.getFeatureCode())
							&& xoTruConLineLocFeature.get(0).getInstanceId()
									.equalsIgnoreCase(changedElement.getFeatureInstanceId())) {
						if (changedElement.getChangeType() != null
								&& ChangeType.CHANGED.toString().equalsIgnoreCase(changedElement.getChangeType())
								&& changedElement.getSpecificationCode() != null) {

							createChangedTrunkGroupEntity(changeTrunkGroup, changedElement.getSpecificationCode(),
									changedElement.getNewValue(), voipOrderRequest);

						}
					}
					// Start missed Coding
					else if (!locFeature.isEmpty()
							&& locFeature.get(0).getCode().equalsIgnoreCase(changedElement.getFeatureCode())
							&& locFeature.get(0).getInstanceId()
									.equalsIgnoreCase(changedElement.getFeatureInstanceId())) {
						if (changedElement.getChangeType() != null
								&& ChangeType.CHANGED.toString().equalsIgnoreCase(changedElement.getChangeType())
								&& changedElement.getSpecificationCode() != null) {

							createChangedTrunkGroupEntity(changeTrunkGroup, changedElement.getSpecificationCode(),
									changedElement.getNewValue(), voipOrderRequest);

						}
					} else if (!devFeature.isEmpty()
							&& devFeature.get(0).getCode().equalsIgnoreCase(changedElement.getFeatureCode())
							&& devFeature.get(0).getInstanceId()
									.equalsIgnoreCase(changedElement.getFeatureInstanceId())) {
						if (changedElement.getChangeType() != null
								&& ChangeType.CHANGED.toString().equalsIgnoreCase(changedElement.getChangeType())
								&& changedElement.getSpecificationCode() != null) {

							createChangedTrunkGroupEntity(changeTrunkGroup, changedElement.getSpecificationCode(),
									changedElement.getNewValue(), voipOrderRequest);

						}
					} else if (!sessionFeature.isEmpty()
							&& sessionFeature.get(0).getCode().equalsIgnoreCase(changedElement.getFeatureCode())
							&& sessionFeature.get(0).getInstanceId()
									.equalsIgnoreCase(changedElement.getFeatureInstanceId())) {
						if (changedElement.getChangeType() != null
								&& ChangeType.CHANGED.toString().equalsIgnoreCase(changedElement.getChangeType())
								&& changedElement.getSpecificationCode() != null) {

							createChangedTrunkGroupEntity(changeTrunkGroup, changedElement.getSpecificationCode(),
									changedElement.getNewValue(), voipOrderRequest);

						}
					}

					// End missed Coding
				}
			}
		}

		LOG.info("Exited - parseTrunkGroupChangeOrder");
		return changeTrunkGroup;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.vz.esap.translation.order.parser.TrunkOrderParser#
	 * createChangedTrunkGroupEntity(com.vz.
	 * esap.translation.order.model.request.VOIPOrderRequest)
	 */

	// change TrunkGroup entities.
	public void createChangedTrunkGroupEntity(TrunkGroupEntity changeTrunkGroup, String specCode, String specValue,
			VOIPOrderRequest voipOrderRequest) throws ApplicationInterfaceException, GenericException {
		String sigDir = null;
		String pilotTn = null;
		LOG.info("Entered - createchanceTrunkGroupEntity");

		if (changeTrunkGroup == null) {
			changeTrunkGroup = new TrunkGroupEntity();
		}

		if ("ESP_EXT_REQ_FLAG".equalsIgnoreCase(specCode)) {
			boolean createExtension = "Yes".equalsIgnoreCase(specValue) ? true : false;
			changeTrunkGroup.setCreateExtension(createExtension);
		}
		if ("SP_VOIP_TRUNK_VM_NUM".equalsIgnoreCase(specCode)) {
			changeTrunkGroup.setVMNumber(specValue);
		}
		if ("SP_VOIP_TRUNK_VM_TYPE".equalsIgnoreCase(specCode)) {
			changeTrunkGroup.setVMType(specValue);
		}
		if ("SP_VOIP_TERM_OPT".equalsIgnoreCase(specCode)) {
			changeTrunkGroup.setTerminationOption(specValue);
		}
		if ("ESP_FORWARD_TO_NUMBER".equalsIgnoreCase(specCode)) {
			changeTrunkGroup.setForwardToNumber(specValue);
		}
		if ("ESP_TRUNK_GROUP_NAM".equalsIgnoreCase(specCode)) {
			changeTrunkGroup.setName(specValue);
		}
		if ("SP_XO_TRU_GRP_NM".equalsIgnoreCase(specCode)) {
			changeTrunkGroup.setName(specValue);
		}
		if ("SP_VOIP_INVITATION_TIMER".equalsIgnoreCase(specCode)) {
			changeTrunkGroup.setInvitationTimer(new Integer(specValue));
		}
		if ("ESP_MAX_CONCURRENT_CALLS".equalsIgnoreCase(specCode)) {
			changeTrunkGroup.setMaxConcurrentCallLimit(new BigInteger(specValue));
		}
		if ("SP_XO_PILNUM".equalsIgnoreCase(specCode)) {

			pilotTn = specValue;
			LOG.info("pilotTn 1 - parseTrunkOrder : {}", pilotTn);
			changeTrunkGroup.setCallingLineIdPhoneNumber(pilotTn);
			changeTrunkGroup.setPilotTn(pilotTn);
			changeTrunkGroup.setExtension(specValue.substring(pilotTn.length() - 4));
			LOG.info("pilotTn 2 - parseTrunkOrder : {} ", pilotTn);

		}
		if ("SP_TRK".equalsIgnoreCase(specCode)) {
			LOG.info("Trunk Call Capacity is = {}", specValue);
			changeTrunkGroup.setCommittedSessionCount(specValue);
			changeTrunkGroup.setMaxActiveCalls(specValue);
			changeTrunkGroup.setTrunkCallCapacity(Long.valueOf(specValue));
		}
		if ("SP_XO_INT".equalsIgnoreCase(specCode)) {
			changeTrunkGroup.setInternationalLDRestriction(specValue);
		}
		if ("SP_XO_SIG".equalsIgnoreCase(specCode)) {
			if ("2 Way".equalsIgnoreCase(specValue))
				sigDir = EsapEnum.SignalingDirection.TWO_WAY.toString();
			if ("Inbound".equalsIgnoreCase(specValue))
				sigDir = EsapEnum.SignalingDirection.INBOUND.toString();

			changeTrunkGroup.setSignalingDirection(sigDir);
		}

		// Start missed Coding
		if ("SP_XO_ESL".equalsIgnoreCase(specCode)) {
			updateTrunkGroupEntityForChangedESL(voipOrderRequest, changeTrunkGroup, specValue);
		}

		// TODO : 10/30: Do like above for devFeature, sessionFeature

		// End missed Coding

		// not creating the createChangedSessionEntity method as "No Spec items" and
		// session attribute is not exists in TrunkGroupEntity - Need confirmation..
		LOG.info("Exited - createchanceTrunkGroupEntity");
	}

	// Start missed Coding
	public void updateTrunkGroupEntityForChangedESL(VOIPOrderRequest voipOrderRequest,
			TrunkGroupEntity changeTrunkGroup, String esl) throws ApplicationInterfaceException, GenericException {
		LOG.info("Entered - updateTrunkGroupEntityForChangedESL");

		if (changeTrunkGroup == null) {
			changeTrunkGroup = new TrunkGroupEntity();
		}

		if (voipOrderRequest.getOrderHeader().getSolutionType() != null) {
			changeTrunkGroup.setSolutionType(voipOrderRequest.getOrderHeader().getSolutionType());

			if (SolutionType.ESIP_ESL.equals(voipOrderRequest.getOrderHeader().getSolutionType()))
				changeTrunkGroup.setCustomerId(voipOrderRequest.getOrderHeader().getEnterpriseId());

			if (SolutionType.ESIP_EBL.equals(voipOrderRequest.getOrderHeader().getSolutionType()))
				changeTrunkGroup.setCustomerId(orderServiceHelperImpl.getEnterpriseInformationFromEsl(esl));
		}

		int groupType = 0;

		Set<String> selectColumnSet = new HashSet<>();
		selectColumnSet.add("GROUP_ID");
		selectColumnSet.add("GROUP_NAME");
		selectColumnSet.add("GROUP_TYPE");
		selectColumnSet.add("LOCATION_ID");
		selectColumnSet.add("TG_ID");
		selectColumnSet.add("DEVICE_MAP_ID");

		if (GroupType.TWO_WAY.toString().equals(changeTrunkGroup.getSignalingDirection()))
			groupType = TrunkGroupType.TWO_WAY.getIndex();
		else if (GroupType.INBOUND.toString().equals(changeTrunkGroup.getSignalingDirection()))
			groupType = TrunkGroupType.INBOUND.getIndex();
		/*
		 * else if (changeTrunkGroup.getGroupType().equals(GroupType.PRI_DID)) groupType
		 * = TrunkGroupType.PRI_DID.getIndex(); else if
		 * (changeTrunkGroup.getGroupType().equals(GroupType.LINE)) groupType =
		 * TrunkGroupType.LINE.getIndex(); else if
		 * (changeTrunkGroup.getGroupType().equals(GroupType.NON_PRI_DID)) groupType =
		 * TrunkGroupType.NON_PRI_DID.getIndex();
		 */

		List<String[]> whereClauseList = new ArrayList<>();
		whereClauseList.add(new String[] { "LOCATION_ID", esl });
		whereClauseList.add(new String[] { "GROUP_TYPE", String.valueOf(groupType) });

		DBServiceResponse dbServiceResponseCustomer = inventoryDomainDataServiceImpl.searchInventory("TBL_GROUP",
				selectColumnSet, whereClauseList);

		String trunkGroupId = null;
		long deviceMapId = -1L;
		String bwDeviceId = null;

		if (dbServiceResponseCustomer.getNumberOfRecords() != 0) {
			for (TblRow tblRow : dbServiceResponseCustomer.getTableRows()) {
				if (tblRow.getTblRow().containsKey("GROUP_ID")) {
					changeTrunkGroup.setVirtualTrunkId(tblRow.getTblRow().get("GROUP_ID").getValue());
					LOG.debug("For EBL the VirtualTrunkId : {}", changeTrunkGroup.getVirtualTrunkId());
				}
				if (tblRow.getTblRow().containsKey("TG_ID")) {
					changeTrunkGroup.setBwTrunkGroupId(tblRow.getTblRow().get("TG_ID").getValue());
					trunkGroupId = tblRow.getTblRow().get("TG_ID").getValue();
					LOG.debug("For EBL the BwTrunkGroupId : {}", changeTrunkGroup.getBwTrunkGroupId());
				}
				if (tblRow.getTblRow().containsKey("DEVICE_MAP_ID")) {
					deviceMapId = Long.valueOf(tblRow.getTblRow().get("DEVICE_MAP_ID").getValue());
					bwDeviceId = entityIdentifireUtil.createBwDeviceId(String.valueOf(deviceMapId),
							changeTrunkGroup.getSignalingDirection());
					LOG.debug("For EBL the DeviceMapId : {}", deviceMapId);
					LOG.debug("For EBL the BWDeviceId : {}", bwDeviceId);
				}
			}
		}

		changeTrunkGroup.setDeviceMapId(deviceMapId);

		LOG.info("Exited - updateTrunkGroupEntityForChangedESL");
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.vz.esap.translation.order.parser.TrunkOrderParser#parseTrunkOrder(com.vz.
	 * esap.translation.order.model.request.VOIPOrderRequest,
	 * com.vz.esap.translation.order.model.request.ParamInfo)
	 */
	@Override
	public ArrayList<TrunkGroupEntity> parseTrunkOrder(VOIPOrderRequest voipOrderRequest, ParamInfo headerParamInfo)
			throws TranslatorException, ParseException {
		LOG.info("TrunkGroupEntity - parseTrunkGroup");
		ArrayList<TrunkGroupEntity> trunkGroupEntityList = null;
		TrunkGroupEntity trunkGroupEntity = null;
		ConvergedService convergedService = null;
		Feature[] features = null;
		String cityCode = null;
		String pilotTn = null;
		List<Feature> locFeat = null;
		String pqEslId = null;
		List<Feature> decFeat = null;
		long deviceMapId = -1;
		String sigDir = null;
		String entityAction = null;
		Specification[] specifications = null;
		PilotUser pilotUser = null;
		String bwEntId = null;
		Set<String> selectColumnSet = null;
		List<String[]> whereClauseList = null;
		DBServiceResponse dbServiceResponseCustomer = null;
		List<Specification> eslSpec = null;
		List<Specification> devNameSpec = null;
		String bwDeviceId = null;
		String trunkGroupId = null;
		List<Feature> nativeTrunkTypeFeatures = null;
		String nativeTrunkFeatures = null;
		boolean isLine = false;
		List<Feature> trunkFeatList = null;
		List<Feature> entFeat = null;
		List<Specification> bwEntSpec = null;
		List<Specification> trunkSessionCountSpec = null;
		int sessionCount = 0;
		Map<String, String> deviceResultMap;
		List<Feature>  trunkLinePriLineFeatures = null;
		String trunkInstanceIdChanged = null;
		List<String> trunkInstanceIdChangedList = null;

		try {

			convergedService = voipOrderRequest.getConvergedService();
			
			LOG.debug("TrunkGroupEntity - parseTrunkGroup: convergedService: {}", convergedService);
			LOG.debug("TrunkGroupEntity - parseTrunkGroup: voipOrderRequest.getOrderHeader().getOrderType():{}",
					voipOrderRequest.getOrderHeader().getOrderType());
			
			if (convergedService.getFeature() != null) {

				nativeTrunkTypeFeatures = stream(voipOrderRequest.getConvergedService().getFeature())
						.filter(trunkFeature -> "FET_PRILIN".equalsIgnoreCase(trunkFeature.getCode())
								|| "FET_XO_TRULIN".equalsIgnoreCase(trunkFeature.getCode()) 
								|| "FET_LIN".equalsIgnoreCase(trunkFeature.getCode()) 
								|| "FET_PRI".equalsIgnoreCase(trunkFeature.getCode()) 
								|| "FET_XO_TRUON".equalsIgnoreCase(trunkFeature.getCode()) 
								|| "FET_HPBX_TRU".equalsIgnoreCase(trunkFeature.getCode()) 
								|| "FET_HPBX_TRU_LOC".equalsIgnoreCase(trunkFeature.getCode()))
						.collect(Collectors.toList());
				
				//Start:PRI/LIN,TRU/LIN Fix
				
				trunkLinePriLineFeatures = stream(voipOrderRequest.getConvergedService().getFeature())
						.filter(trunkFeature -> "FET_PRILIN".equalsIgnoreCase(trunkFeature.getCode())
								|| "FET_XO_TRULIN".equalsIgnoreCase(trunkFeature.getCode()))
						.collect(Collectors.toList());
				
				//End:PRI/LIN,TRU/LIN Fix
				
				//Start: Trunk Change Fix:
				if (voipOrderRequest.getChangeManagement() != null) {
					for (ChangeManagement changeManagement : voipOrderRequest.getChangeManagement()) {
						trunkInstanceIdChangedList = new ArrayList<>();
						for (ChangedElement changedElement : changeManagement.getChangedElement()) {
							if ("ADDED".equalsIgnoreCase(changedElement.getChangeType())
									&& "FET_XO_TRU".equalsIgnoreCase(changedElement.getFeatureCode())) {
								trunkInstanceIdChanged = changedElement.getFeatureInstanceId();
								trunkInstanceIdChangedList.add(trunkInstanceIdChanged);
								LOG.info("TrunkInstanceIdChanged = {}", trunkInstanceIdChanged);
							}
						}
					}
				}
				
				//End: Trunk Change Fix:

				features = convergedService.getFeature();
				trunkGroupEntityList = new ArrayList<>();

				if (voipOrderRequest.getLocation() != null
						&& voipOrderRequest.getLocation().getLocationAddress() != null
						&& voipOrderRequest.getLocation().getLocationAddress().getCity() != null) {
					cityCode = voipOrderRequest.getLocation().getLocationAddress().getCity();
				}
				
				entFeat = stream(voipOrderRequest.getConvergedService().getFeature())
						.filter(feature -> "EFET_VOIP_ENT_LVL".equalsIgnoreCase(feature.getCode())).collect(Collectors.toList());
				
				if(!CollectionUtils.isEmpty(entFeat)) {				
					bwEntSpec = stream(entFeat.get(0).getSpecification())
							.filter(spec -> "BW_ENTERPRISE_ID".equalsIgnoreCase(spec.getCode())).collect(Collectors.toList());				
				}

				if (voipOrderRequest.getOrderHeader().getBwEnterpriseId() != null) {
					bwEntId = voipOrderRequest.getOrderHeader().getBwEnterpriseId();
				} else if (!CollectionUtils.isEmpty(bwEntSpec)) {
					bwEntId = bwEntSpec.get(0).getValue();
				} else {
					bwEntId = entityIdentifireUtil.createBwEnterpriseId(voipOrderRequest.getOrderHeader().getGCHId(),
							voipOrderRequest.getOrderHeader().getSolutionType(), null,
							voipOrderRequest.getOrderHeader().getEnterpriseId());
				}
					

				locFeat = stream(features).filter(feat -> "FET_LOC_LVL".equalsIgnoreCase(feat.getCode()))
						.collect(Collectors.toList());

				pqEslId = voipOrderRequest.getConvergedService().getID();

				decFeat = stream(features).filter(feat -> "EFET_VOIP_DEVICE_LVL".equalsIgnoreCase(feat.getCode())
						|| "FET_DE".equalsIgnoreCase(feat.getCode())
						|| "FET_DE_LOC".equalsIgnoreCase(feat.getCode())).collect(Collectors.toList());

				if (!CollectionUtils.isEmpty(decFeat)) {
					deviceMapId = Long.valueOf(decFeat.get(0).getInstanceId());

					devNameSpec = stream(decFeat.get(0).getSpecification())
							.filter(spec -> "ESP_LOGICAL_DEVICE_NAME".equalsIgnoreCase(spec.getCode()))
							.collect(Collectors.toList());
				}
				
				//Start : Session Feature Fix
				
				trunkFeatList = stream(voipOrderRequest.getConvergedService().getFeature())
						.filter(truFeat -> "FET_XO_TRU".equalsIgnoreCase(truFeat.getCode()))
						.collect(Collectors.toList());

				if (!CollectionUtils.isEmpty(trunkFeatList)) {
					for (Feature trunkFeat : trunkFeatList) {
						trunkSessionCountSpec = stream(trunkFeat.getSpecification())
								.filter(spec -> "SP_TRK".equalsIgnoreCase(spec.getCode()))
								.collect(Collectors.toList());

						if (!CollectionUtils.isEmpty(trunkSessionCountSpec)) {
							sessionCount = sessionCount
									+ Integer.parseInt(trunkSessionCountSpec.get(0).getValue());
						}
					}
					LOG.info("Session Total Count ={} ", sessionCount);					
				}
				//End : Session Feature Fix

				int index = 0;
				for (Feature feature : features) {
					if (("EFET_VOIP_TRUNK_LVL".equalsIgnoreCase(feature.getCode())
							|| "FET_XO_TRU".equalsIgnoreCase(feature.getCode())
							|| "FET_XO_TRU_CON".equalsIgnoreCase(feature.getCode())
							|| "FET_XO_TRU_CON_LINE_LOC".equalsIgnoreCase(feature.getCode())
							|| "FET_HPBX_TRU".equalsIgnoreCase(feature.getCode())
							|| "FET_HPBX_TRU_LOC".equalsIgnoreCase(feature.getCode()))
							&& ("I".equalsIgnoreCase(voipOrderRequest.getOrderHeader().getOrderType())
									|| "C".equalsIgnoreCase(voipOrderRequest.getOrderHeader().getOrderType()))) {

						trunkGroupEntity = new TrunkGroupEntity();
						
						trunkGroupEntity.setAsClli(voipOrderRequest.getOrderHeader().getAsClli()); //add broadsoft clli.
						
						if (!CollectionUtils.isEmpty(decFeat) && decFeat.size() > index && decFeat.get(index) != null) {
							LOG.info("Device map Id  - {}", decFeat.get(index).getInstanceId());

							deviceMapId = Long.valueOf(decFeat.get(index).getInstanceId());
						}
						index ++;
						trunkGroupEntity.setDeviceMapId(deviceMapId);

						if (voipOrderRequest.getOrderHeader().getEnterpriseId() != null)
							trunkGroupEntity.setEnterpriseId(voipOrderRequest.getOrderHeader().getEnterpriseId());
						if (voipOrderRequest.getOrderHeader().getLocationId() != null)
							trunkGroupEntity.setLocationId(voipOrderRequest.getOrderHeader().getLocationId());

						if (feature.getInstanceId() != null) {
							trunkGroupEntity.setGroupId(new Long(feature.getInstanceId()));
						}
						if (feature.getActionCode() != null) {
							entityAction = feature.getActionCode();
							if ("ADD".equalsIgnoreCase(entityAction)) {
								trunkGroupEntity.setAction(EsapEnum.OrderAction.ADD);
							} else if ("CHANGE".equalsIgnoreCase(entityAction)) {
								trunkGroupEntity.setAction(EsapEnum.OrderAction.MODIFY);
							} else if ("DELETE".equalsIgnoreCase(entityAction)) {
								trunkGroupEntity.setAction(EsapEnum.OrderAction.DELETE);
							}
						}

						specifications = feature.getSpecification();
						LOG.debug("TrunkGroupEntity - parseTrunkGroup: specifications: {}", specifications);
						
						for (Specification specification : specifications) {
							
							if ("SP_XO_BW_TRUNK_ID_LOC".equalsIgnoreCase(specification.getCode())) {
								trunkGroupEntity.setBwTrunkGroupId(specification.getValue());

							}
							
							if ("SP_XO_ASSO_LOC_INST_ID_LOC".equalsIgnoreCase(specification.getCode())) { 								
								trunkGroupEntity.setLocationId(specification.getValue());
								
							}
							
							if ("ESP_EXT_REQ_FLAG".equalsIgnoreCase(specification.getCode())) {
								boolean createExtension = "Yes".equalsIgnoreCase(specification.getValue()) ? true
										: false;
								trunkGroupEntity.setCreateExtension(createExtension);

							}
							if ("SP_VOIP_TRUNK_VM_NUM".equalsIgnoreCase(specification.getCode())) {
								trunkGroupEntity.setVMNumber(specification.getValue());
							}
							if ("SP_VOIP_TRUNK_VM_TYPE".equalsIgnoreCase(specification.getCode())) {
								trunkGroupEntity.setVMType(specification.getValue());
							}
							if ("SP_VOIP_TERM_OPT".equalsIgnoreCase(specification.getCode())) {
								trunkGroupEntity.setTerminationOption(specification.getValue());
							}
							if ("ESP_FORWARD_TO_NUMBER".equalsIgnoreCase(specification.getCode())) {
								trunkGroupEntity.setForwardToNumber(specification.getValue());
							}
							if ("ESP_TRUNK_GROUP_NAM".equalsIgnoreCase(specification.getCode())) {
								trunkGroupEntity.setName(specification.getValue());
							}
							if ("SP_XO_TRU_GRP_NM".equalsIgnoreCase(specification.getCode())) {
								trunkGroupEntity.setName(specification.getValue());
							}
							if ("SP_VOIP_INVITATION_TIMER".equalsIgnoreCase(specification.getCode())) {
								trunkGroupEntity.setInvitationTimer(new Integer(specification.getValue()));
							}
							if ("ESP_MAX_CONCURRENT_CALLS".equalsIgnoreCase(specification.getCode())) {
								trunkGroupEntity.setMaxConcurrentCallLimit(new BigInteger(specification.getValue()));
							}
							if ("SP_XO_PILNUM".equalsIgnoreCase(specification.getCode())) {

								pilotTn = specification.getValue();
								LOG.info("pilotTn 1 - parseTrunkOrder : {}", pilotTn);
								trunkGroupEntity.setCallingLineIdPhoneNumber(pilotTn);
								trunkGroupEntity.setPilotTn(pilotTn);
								trunkGroupEntity.setExtension(specification.getValue().substring(pilotTn.length() - 4));
								LOG.info("pilotTn 2 - parseTrunkOrder : {} ", pilotTn);
							}
							if ("SP_TRK".equalsIgnoreCase(specification.getCode())) {
								trunkGroupEntity.setCommittedSessionCount(specification.getValue());
								trunkGroupEntity.setTrunkCallCapacity(Long.valueOf(specification.getValue()));
								trunkGroupEntity.setMaxActiveCalls(specification.getValue()); //Added by 738577 as individual call capacity is handled individually for Different TN Entity   
							}
							if ("SP_XO_INT".equalsIgnoreCase(specification.getCode())) {
								trunkGroupEntity.setInternationalLDRestriction(specification.getValue());
							}
							if ("SP_XO_SIG".equalsIgnoreCase(specification.getCode())) {

								if ("2 Way".equalsIgnoreCase(specification.getValue()))
									sigDir = EsapEnum.SignalingDirection.TWO_WAY.toString();
								if ("Inbound".equalsIgnoreCase(specification.getValue()))
									sigDir = EsapEnum.SignalingDirection.INBOUND.toString();

								trunkGroupEntity.setSignalingDirection(sigDir);
							}
						}
						
						if(trunkGroupEntity.getLocationId() == null) {
							trunkGroupEntity.setLocationId(voipOrderRequest.getOrderHeader().getLocationId());
							
						}
						
						
						LOG.debug("+++++++++++++++++ BW Enterprise Id : {} pqEslId {} sigDir {} cityCode {} ", bwEntId,
								pqEslId, sigDir, cityCode);
						if (voipOrderRequest.getOrderHeader() != null
								&& voipOrderRequest.getOrderHeader().getSolutionType() != null
								&& !(SolutionType.ESIP_EBL.equals(voipOrderRequest.getOrderHeader().getSolutionType())
										|| SolutionType.HPBX
												.equals(voipOrderRequest.getOrderHeader().getSolutionType()))) {

							trunkGroupId = entityIdentifireUtil.createBwTgId(bwEntId, pqEslId, sigDir, cityCode);
							trunkGroupEntity.setBwTrunkGroupId(trunkGroupId);

							trunkGroupEntity.setOtgDtgIdentity(
									entityIdentifireUtil.createBwTgOtgId(bwEntId, pqEslId, sigDir, cityCode));

							if (!CollectionUtils.isEmpty(decFeat)) {
								bwDeviceId = entityIdentifireUtil.createBwDeviceId(decFeat.get(0).getInstanceId(),
										sigDir);
							}
						}

						if (sigDir != null) {
							if (EsapEnum.SignalingDirection.TWO_WAY.toString().equalsIgnoreCase(sigDir))
								trunkGroupEntity.setGroupType(GroupType.TWO_WAY);
							else if (EsapEnum.SignalingDirection.INBOUND.toString().equalsIgnoreCase(sigDir))
								trunkGroupEntity.setGroupType(GroupType.INBOUND);
						}

						if (!CollectionUtils.isEmpty(nativeTrunkTypeFeatures))
							nativeTrunkFeatures = nativeTrunkTypeFeatures.get(0).getCode();
						else
							nativeTrunkFeatures = "NONE";

						isLine = "FET_XO_TRU_CON_LINE_LOC".equalsIgnoreCase(feature.getCode());

						if (!isLine && Arrays.asList("FET_PRILIN", "FET_PRI").contains(nativeTrunkFeatures)) {
							trunkGroupEntity.setGroupType(GroupType.PRI_DID);
							trunkGroupEntity.setSignalingDirection(EsapEnum.SignalingDirection.TWO_WAY.toString());
						} else if (!isLine
								&& Arrays.asList("FET_XO_TRULIN", "FET_XO_TRUON").contains(nativeTrunkFeatures)) {
							trunkGroupEntity.setGroupType(GroupType.NON_PRI_DID);
							trunkGroupEntity.setSignalingDirection(EsapEnum.SignalingDirection.TWO_WAY.toString());
						} else if (isLine) {
							trunkGroupEntity.setGroupType(GroupType.LINE);
						}

						// Start: EBL Change
						if (!locFeat.isEmpty()) {
							eslSpec = stream(locFeat.get(0).getSpecification())
									.filter(spec -> "SP_XO_ESL".equalsIgnoreCase(spec.getCode()))
									.collect(Collectors.toList());

							if (!eslSpec.isEmpty()) {

								if (voipOrderRequest.getOrderHeader().getSolutionType() != null) {
									trunkGroupEntity
											.setSolutionType(voipOrderRequest.getOrderHeader().getSolutionType());

									if (SolutionType.ESIP_ESL
											.equals(voipOrderRequest.getOrderHeader().getSolutionType()))
										trunkGroupEntity
												.setCustomerId(voipOrderRequest.getOrderHeader().getEnterpriseId());

									if (SolutionType.ESIP_EBL
											.equals(voipOrderRequest.getOrderHeader().getSolutionType()))
										trunkGroupEntity.setCustomerId(orderServiceHelperImpl
												.getEnterpriseInformationFromEsl(eslSpec.get(0).getValue()));
								}

								int groupType = 0;

								selectColumnSet = new HashSet<>();
								selectColumnSet.add("GROUP_ID");
								selectColumnSet.add("GROUP_NAME");
								selectColumnSet.add("GROUP_TYPE");
								selectColumnSet.add("LOCATION_ID");
								selectColumnSet.add("TG_ID");
								selectColumnSet.add("DEVICE_MAP_ID");

								if (trunkGroupEntity.getGroupType().equals(GroupType.TWO_WAY))
									groupType = TrunkGroupType.TWO_WAY.getIndex();
								else if (trunkGroupEntity.getGroupType().equals(GroupType.INBOUND))
									groupType = TrunkGroupType.INBOUND.getIndex();
								else if (trunkGroupEntity.getGroupType().equals(GroupType.PRI_DID))
									groupType = TrunkGroupType.PRI_DID.getIndex();
								else if (trunkGroupEntity.getGroupType().equals(GroupType.LINE))
									groupType = TrunkGroupType.LINE.getIndex();
								else if (trunkGroupEntity.getGroupType().equals(GroupType.NON_PRI_DID))
									groupType = TrunkGroupType.NON_PRI_DID.getIndex();

								whereClauseList = new ArrayList<>();
								whereClauseList.add(new String[] { "LOCATION_ID", eslSpec.get(0).getValue() });
								whereClauseList.add(new String[] { "GROUP_TYPE", String.valueOf(groupType) });

								dbServiceResponseCustomer = inventoryDomainDataServiceImpl.searchInventory("TBL_GROUP",
										selectColumnSet, whereClauseList);

								if (dbServiceResponseCustomer.getNumberOfRecords() != 0) {
									for (TblRow tblRow : dbServiceResponseCustomer.getTableRows()) {
										if (tblRow.getTblRow().containsKey("GROUP_ID")) {
											trunkGroupEntity
													.setVirtualTrunkId(tblRow.getTblRow().get("GROUP_ID").getValue());
											LOG.info("For EBL the VirtualTrunkId : {}",
													trunkGroupEntity.getVirtualTrunkId());
										}
										if (tblRow.getTblRow().containsKey("TG_ID")) {
											trunkGroupEntity
													.setBwTrunkGroupId(tblRow.getTblRow().get("TG_ID").getValue());
											trunkGroupId = tblRow.getTblRow().get("TG_ID").getValue();
											LOG.info("For EBL the BwTrunkGroupId : {}",
													trunkGroupEntity.getBwTrunkGroupId());
										}
										if (tblRow.getTblRow().containsKey("DEVICE_MAP_ID")) {
											deviceMapId = Long
													.valueOf(tblRow.getTblRow().get("DEVICE_MAP_ID").getValue());
											bwDeviceId = entityIdentifireUtil
													.createBwDeviceId(String.valueOf(deviceMapId), sigDir);
											LOG.info("For EBL the DeviceMapId : {}", deviceMapId);
											LOG.info("For EBL the BWDeviceId : {}", bwDeviceId);
										}
									}
								}
							}
						}
						
						trunkGroupEntity.setDeviceMapId(deviceMapId);
												
						// Start : Fix for IB Trunk device.
						
						LOG.info("ESIP ESL - TG DEV MAPPING --> Trunk Id = {}, Solution Type = {}, Trunk Type = {}",
								trunkGroupEntity.getGroupId(), voipOrderRequest.getOrderHeader().getSolutionType(),
								trunkGroupEntity.getGroupType());

						List<ParamInfo> paramInfos = null;
						boolean isComplete = false;
						if (SolutionType.ESIP_ESL.equals(voipOrderRequest.getOrderHeader().getSolutionType())
								&& GroupType.INBOUND.equals(trunkGroupEntity.getGroupType()) && headerParamInfo != null
								&& headerParamInfo.getChildParams() != null) {

							LOG.info("ESIP ESL - INBOUND DUO --> Trunk Id = {}, Solution Type = {}, Trunk Type = {}",
									trunkGroupEntity.getGroupId(), voipOrderRequest.getOrderHeader().getSolutionType(),
									trunkGroupEntity.getGroupType());


							paramInfos = headerParamInfo.getChildParams();

							List<ParamInfo> deviceParamInfos = null;
							String devMapId = null;
							long deviceIbMapId = -1;

							for (ParamInfo paramInfo : paramInfos) {

								if ("Device".equalsIgnoreCase(paramInfo.getName())) {
									LOG.info("Device Info for validation");

									deviceParamInfos = paramInfo.getChildParams();

									for (ParamInfo deviceInfo : deviceParamInfos) {

										if ("DeviceMapId".equalsIgnoreCase(deviceInfo.getName())) {

											LOG.info("Device Map Id = {}", deviceInfo.getValue());

											devMapId = deviceInfo.getValue();

										}

										if ("TrunkType".equalsIgnoreCase(deviceInfo.getName())
												&& "INBOUND".equalsIgnoreCase(deviceInfo.getValue())) {

											LOG.info("Device Info for validation for Inbound");

											deviceIbMapId = Long.valueOf(devMapId);

											isComplete = true;

											break;

										}
									}

									if (isComplete)
										break;
								}
							}
							
							trunkGroupEntity.setDeviceMapId(deviceIbMapId);
						}

						// End : Fix for IB Trunk device.

						
						
						//BUG TG-1 : Multiple Device Map Id is not getting assigned to correct TG #91000202, #8380001
						
						// trunkGroupEntity.setMaxActiveCalls(String.valueOf(sessionCount)); //commented by 738577 as now each TN Type Max Active Call is handled in the each feature type 
					
						if (trunkGroupId != null && bwEntId != null && pilotTn != null && bwDeviceId != null) {
							pilotUser = new PilotUser();
							pilotUser.setUserId(trunkGroupId + "@" + bwEntId.toLowerCase() + ".vm.xohost.com");
							pilotUser.setFirstName("Pilot-" + pilotTn.substring(pilotTn.length() - 4));
							pilotUser.setLastName(trunkGroupId.substring(trunkGroupId.indexOf('-') + 1));
							LOG.info("pilotTn 3- parseTrunkOrder : {} ", pilotTn);
							pilotUser.setPhoneNumber(Long.valueOf(pilotTn));
							pilotUser.setCallingLineIdFirstName("Pilot-" + pilotTn.substring(pilotTn.length() - 4));
							pilotUser.setCallingLineIdLastName(trunkGroupId.substring(trunkGroupId.indexOf('-') + 1));
							
							//This below section is no more required so commenting:
							//pilotUser.setLinePort(pilotTn);
							pilotUser.setDeviceLevel(null);
							pilotUser.setDeviceName(bwDeviceId);

							trunkGroupEntity.setPilotUser(pilotUser);
						}
						
						//Start: Flex Dev Name Fix
						
						DeviceEntity device = null;
						
						if(SolutionType.IPFLEX.equals(voipOrderRequest.getOrderHeader().getSolutionType())) {
							
							device = new DeviceEntity();
							device.setDeviceMapId(deviceMapId);
							device.setDeviceName(String.valueOf(deviceMapId));
							
							//Start Port Number Fix
							
							device.setLinePort(pilotTn);//TODO Fix this with actual CPE Port Number
							
							//End Port Number Fix
							
							trunkGroupEntity.setDevice(device);
							
							LOG.info("Parser Here with device.getDeviceName()--> {}" ,device.getDeviceName());
						}
						
						if (SolutionType.HPBX.equals(voipOrderRequest.getOrderHeader().getSolutionType())) {
							deviceResultMap = inventoryUtil
									.getHpbxDeviceFromEnterprise(voipOrderRequest.getOrderHeader().getEnterpriseId());

							if (deviceResultMap != null) {
								device = new DeviceEntity();
								device.setDeviceMapId(Long.valueOf(deviceResultMap.get("DEVICE_MAP_ID")));
								device.setDeviceName(String.valueOf(deviceResultMap.get("DEVICE_MAP_ID")));

								trunkGroupEntity.setDevice(device);

								trunkGroupEntity.setDeviceMapId(Long.valueOf(deviceResultMap.get("DEVICE_MAP_ID")));

								LOG.info("Parser Here with device.getDeviceName()--> {}", device.getDeviceName());

							}
						}
						
						//End: Flex Hpbx Dev Name Fix
						
						if ("C".equalsIgnoreCase(voipOrderRequest.getOrderHeader().getOrderType())) {

							if (!CollectionUtils.isEmpty(trunkInstanceIdChangedList)) {
								LOG.info("Trunk Present in Change Management");

								for (String trunkChangedId : trunkInstanceIdChangedList) {
									if (feature.getInstanceId().equalsIgnoreCase(trunkChangedId)) {
										LOG.info("Trunk Instance Id Included In ADDED Change Management = {}",
												feature.getInstanceId());
										// Do Nothing

									} else {
										LOG.info("Trunk Instance Id NOT Included In Change Management = {}",
												feature.getInstanceId());

										TrunkGroupEntity changeTrunkGroup = parseTrunkGroupChangeOrder(
												voipOrderRequest);
										trunkGroupEntity.setTrunkGroupEntity(changeTrunkGroup);
									}
								}
							} else {
								LOG.info("No Trunk in Change Management and Trunk Instance Id = {}",
										feature.getInstanceId());
								TrunkGroupEntity changeTrunkGroup = parseTrunkGroupChangeOrder(voipOrderRequest);
								trunkGroupEntity.setTrunkGroupEntity(changeTrunkGroup);
							}
						}
						
						//AuthFeatureType
						if (Arrays.asList(SolutionType.ESIP_ESL, SolutionType.ESIP_EBL)
								.contains(voipOrderRequest.getOrderHeader().getSolutionType())) {
							trunkGroupEntity.setAuthFeatureType(AuthFeatureType.FET_ESIP);
						} else if (SolutionType.IPFLEX.equals(voipOrderRequest.getOrderHeader().getSolutionType())) {
							trunkGroupEntity.setAuthFeatureType(orderServiceHelperImpl.getAuthFeatureType(voipOrderRequest));
						} else if (SolutionType.HPBX.equals(voipOrderRequest.getOrderHeader().getSolutionType())) {
							trunkGroupEntity.setAuthFeatureType(AuthFeatureType.FET_HPBX);
						}
						//
						
						trunkGroupEntityList.add(trunkGroupEntity);
					}
				}
			}
		} catch (Exception e) {			
			LOG.error("Exception {} ", e);
			LOG.error("Exception Stack Trace {} ", e);
			throw new TranslatorException(TranslatorException.ErrorCode.ORDER_NOT_SAVABLE,
					"Unexpected Error Occured while Parsing Trunk Order");
		}
		LOG.info("trunkGroupEntityList.size() : {}", trunkGroupEntityList.size());
		return trunkGroupEntityList;
	}
	
	
	
}