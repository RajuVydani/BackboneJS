package com.vz.esap.translation.order.model.pc;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;

import com.fasterxml.jackson.annotation.JsonProperty;

@XmlAccessorType(XmlAccessType.FIELD)
public class GCMInfo {
	
	@XmlElement(name = "QuoteId")
	@JsonProperty(value = "QuoteId")
	private String quoteId;

	@XmlElement(name = "PricingInfo")
	@JsonProperty(value = "PricingInfo")
	private PricingInfo[] pricingInfo;

	@XmlElement(name = "CustomerPriceBookId")
	@JsonProperty(value = "CustomerPriceBookId")
	private String customerPriceBookId;

	@XmlElement(name = "ContractId")
	@JsonProperty(value = "ContractId")
	private String contractId;

	@XmlElement(name = "ProductIdentifier")
	@JsonProperty(value = "ProductIdentifier")
	private String productIdentifier;

	public String getQuoteId() {
		return quoteId;
	}

	public void setQuoteId(String QuoteId) {
		this.quoteId = QuoteId;
	}

	public PricingInfo[] getPricingInfo() {
		return pricingInfo;
	}

	public void setPricingInfo(PricingInfo[] PricingInfo) {
		this.pricingInfo = PricingInfo;
	}

	public String getCustomerPriceBookId() {
		return customerPriceBookId;
	}

	public void setCustomerPriceBookId(String CustomerPriceBookId) {
		this.customerPriceBookId = CustomerPriceBookId;
	}

	public String getContractId() {
		return contractId;
	}

	public void setContractId(String ContractId) {
		this.contractId = ContractId;
	}

	public String getProductIdentifier() {
		return productIdentifier;
	}

	public void setProductIdentifier(String ProductIdentifier) {
		this.productIdentifier = ProductIdentifier;
	}

	@Override
	public String toString() {
		return "ClassPojo [QuoteId = " + quoteId + ", PricingInfo = " + pricingInfo + ", CustomerPriceBookId = "
				+ customerPriceBookId + ", ContractId = " + contractId + ", ProductIdentifier = " + productIdentifier
				+ "]";
	}
}
