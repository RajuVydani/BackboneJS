package com.vz.esap.translation.order.model.request;

public class CircuitInfo {

	private String EbiId;

	private String CircuitId;

	private String[] VpnName;

	private String IpAddress;

	public String getEbiId() {
		return EbiId;
	}

	public void setEbiId(String EbiId) {
		this.EbiId = EbiId;
	}

	public String getCircuitId() {
		return CircuitId;
	}

	public void setCircuitId(String CircuitId) {
		this.CircuitId = CircuitId;
	}

	public String[] getVpnName() {
		return VpnName;
	}

	public void setVpnName(String[] VpnName) {
		this.VpnName = VpnName;
	}

	public String getIpAddress() {
		return IpAddress;
	}

	public void setIpAddress(String IpAddress) {
		this.IpAddress = IpAddress;
	}

	public String toString() {
		return "ClassPojo [EbiId = " + EbiId + ", CircuitId = " + CircuitId + ", VpnName = " + VpnName
				+ ", IpAddress = " + IpAddress + "]";
	}
}
