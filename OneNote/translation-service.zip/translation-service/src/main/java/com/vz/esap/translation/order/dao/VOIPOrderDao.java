package com.vz.esap.translation.order.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.vz.esap.translation.connector.model.DBServiceResponse;
import com.vz.esap.translation.dao.model.TblConfigParams;
import com.vz.esap.translation.dao.model.TblEnvOrder;
import com.vz.esap.translation.dao.model.TblEnvOrderDetails;
import com.vz.esap.translation.dao.model.TblEnvOrderResp;
import com.vz.esap.translation.dao.model.TblEnvOrderSegment;
import com.vz.esap.translation.dao.model.TblLorTnChngDetails;
import com.vz.esap.translation.dao.model.TblOrder;
import com.vz.esap.translation.dao.model.TblOrderDetails;
import com.vz.esap.translation.dao.model.TblOrderService;
import com.vz.esap.translation.dao.model.TblRetailService;
import com.vz.esap.translation.dao.model.TblSafeStore;
import com.vz.esap.translation.enums.EsapEnum.FlowPath;
import com.vz.esap.translation.enums.EsapEnum.OrderEntity;
import com.vz.esap.translation.exception.GenericException;
import com.vz.esap.translation.exception.TranslatorException;
import com.vz.esap.translation.order.model.Order;
import com.vz.esap.translation.order.model.request.OrderHeader;
import com.vz.esap.translation.order.model.request.ParamInfo;
import com.vz.esap.translation.order.model.request.VOIPOrderRequest;

/**
 * @author chattni
 *
 */
/**
 * @author chattni
 *
 */
@Repository
public interface VOIPOrderDao {
	/**
	 * @param tblEnvOrderObject
	 * @return count
	 * @throws TranslatorException
	 */
	public long createEnvelopOrder(TblEnvOrder tblEnvOrderObject) throws TranslatorException;

	/**
	 * @param tblOrder
	 * @return count
	 * @throws TranslatorException
	 */
	public long createTblOrder(TblOrder tblOrder) throws TranslatorException;

	/**
	 * @param tblOrderObject
	 * @param childParams
	 * @param action
	 * @param parentId
	 * @param leaf
	 * @return count
	 * @throws TranslatorException
	 */
	public long populateOrderDetails(TblOrder tblOrderObject, List<ParamInfo> childParams, String action,
			long parentId, long leaf) throws TranslatorException;

	/**
	 * @param tblOrderService
	 * @return count
	 * @throws TranslatorException
	 */
	public long createTblOrderService(TblOrderService tblOrderService) throws TranslatorException;

	/**
	 * @param tblEnvOrderResp
	 */
	public void insertTblEnvOrderRespData(TblEnvOrderResp tblEnvOrderResp);

	/**
	 * @param region
	 * @return tblRetailServiceList
	 * @throws TranslatorException
	 */
	public List<TblRetailService> findServicesValidation(String region) throws TranslatorException;
	
	/**
	 * @param tblSafeStoreObject
	 */
	public void updateTblSafeStoreTranslationStartTime(TblSafeStore tblSafeStoreObject);

	/**
	 * @param tblSafeStoreObject
	 */
	public void updateTblSafeStoreTranslationEndTime(TblSafeStore tblSafeStoreObject);

	/**
	 * @param tblEnvOrderSegment
	 * @return
	 */
	public long createTableEnvOrderSegment(TblEnvOrderSegment tblEnvOrderSegment);

	/**
	 * @param tblEnvOrder
	 * @return count
	 * @throws TranslatorException
	 */
	public List<TblEnvOrder> getTableEnvOrder(TblEnvOrder tblEnvOrder) throws TranslatorException;

	/**
	 * @param tblEnvOrderDetails
	 * @return tblEnvOrderList
	 */
	public long createEnvOrderDetails(TblEnvOrderDetails tblEnvOrderDetails);

	/**
	 * @param tblEnvOrderDetails
	 * @return tblEnvOrderDetailsList
	 */
	public List<TblEnvOrderDetails> getEnvOrderDetails(TblEnvOrderDetails tblEnvOrderDetails);

	/**
	 * @param tblOrder
	 * @return tblOrderList
	 */
	public List<TblOrder> getTblOrder(TblOrder tblOrder);

	/**
	 * @param tblOrderDetails
	 * @return tblOrderDetailsList
	 */
	public List<TblOrderDetails> getOrderDetailsEntities(TblOrderDetails tblOrderDetails);

	/**
	 * @param parentId
	 * @param action
	 * @param delta
	 * @param paramName
	 * @param tblOrderDetails
	 * @return tblOrderDetailsList
	 */
	public List<TblOrderDetails> getOrderDetailsWithActionAndParent(long parentId, String action, boolean delta,
			String paramName, TblOrderDetails tblOrderDetails);
	
	/**
	 * @param tblConfigParams
	 * @return tblConfigParamsList
	 * @throws TranslatorException
	 */
	public List<TblConfigParams> getConfigParamValue(TblConfigParams tblConfigParams) throws TranslatorException;

	/**
	 * @param order
	 * @param orderPrevPass 
	 * @return tblRetailServiceList
	 * @throws TranslatorException
	 */
	public List<TblRetailService> findServices(Order order, Order orderPrevPass) throws TranslatorException;

	/**
	 * @param envOrderId
	 * @param status
	 */
	void updateTblEnvOrderStatus(Long envOrderId, int status);
	
	/**
	 * @param envOrderId
	 * @param status
	 * @param workGroup
	 */
	void updateTblEnvOrderStatusAndWorkGroup(Long envOrderId, int status, String workGroup);

	/**
	 * @param orderId
	 * @param status
	 */
	void updateTblOrderStatus(Long orderId, int status);

	/**
	 * @param tblSafeStoreObject
	 */
	void insertTblSafeStore(TblSafeStore tblSafeStoreObject);
	
	
	/**
	 * @param tblOrderDetails
	 * @return
	 */
	public List<TblOrderDetails> getTnOrderDetailsEntities(TblOrderDetails tblOrderDetails);
	
	/**
	 * @param tblEnvOrder
	 */
	public void createParentChildOrderRelationship(TblEnvOrder tblEnvOrder);

	
	
	/**
	 * @param tblOrderDetailsList
	 * @param childParams
	 * @param action
	 * @param parentId
	 * @param leaf
	 * @return count
	 */
	int upsertTblOrderDetails(List<TblOrderDetails> tblOrderDetailsList, List<ParamInfo> childParams, String action,
			long parentId, long leaf);

	/**
	 * @param envOrderId
	 * @param orderId
	 * @param wfService
	 * @param milestone
	 * @param status
	 * @param seqNo
	 */
	void insertOrderMilestone(long envOrderId, long orderId, String wfService, long milestone, long status, long seqNo);

	public List<TblOrder> getPrevTblOrder(TblOrder tblOrder, OrderEntity orderEntity);
	
	/**
	 * @param tblEnvOrder
	 * @param statusExclusion
	 * @return tblEnvOrderList
	 * @throws TranslatorException
	 */
	List<TblEnvOrder> getTableEnvOrder(TblEnvOrder tblEnvOrder, List<Long> statusExclusion) throws TranslatorException;
	
	/**
	 * @param tblEnvOrder
	 * @return tblOrderList
	 */
	public List<TblOrder> getTblOrder(TblEnvOrder tblEnvOrder);

	/**
	 * @param orderId
	 * @param prevPassOrderId
	 */
	void moveTblOrder(Long orderId, Long prevPassOrderId);

	/**
	 * @param prevOrderId
	 * @return TblOrderDetailsList
	 */
	public List<TblOrderDetails> getOrderDetailParam(Long prevOrderId, String entityType);

	/**
	 * @param prevOrder
	 * @return TblOrderServiceList
	 */
	public List<TblOrderService> getOrderServiceList(TblOrder prevOrder); 
	
	/**
	 * @param service
	 * @param region
	 * @return TblRetailServiceList
	 * @throws TranslatorException 
	 */
	List<TblRetailService> getTblRetailService(String service, String region) throws TranslatorException;

	/**
	 * @param tblOrderDetails
	 * @return
	 */
	List<TblOrderDetails> getOrderDetailsEntriesPerOrder(TblOrder tblOrder);


	/**
	 * @param orderId
	 * @param seqNumber
	 * @param serviceStatus
	 */
	void updateOrderServiceStatus(long orderId, long seqNumber, long serviceStatus);

	


	/**
	 * @param dbServiceResponse
	 * @param inventoryTable
	 * @return
	 * @throws TranslatorException
	 */
	TblEnvOrder getTblEnvOrderDetailsFromInventory(DBServiceResponse dbServiceResponse, String inventoryTable)
			throws TranslatorException;

	/**
	 * @param voipOrderRequest
	 * @return
	 * @throws TranslatorException 
	 */
	List<String> getDistinctTrunkFromTnDetails(VOIPOrderRequest voipOrderRequest) throws TranslatorException;

	/**
	 * @param voipOrderRequest
	 * @return
	 */
	public List<TblLorTnChngDetails> getChangedTnDetails(VOIPOrderRequest voipOrderRequest);

	/**
	 * @param tblEnvOrder
	 * @param flowPath
	 */
	void createParentChildOrderRelationship(TblEnvOrder tblEnvOrder, FlowPath flowPath) throws TranslatorException;

	
	/**
	 * @param orderHeader
	 * @return
	 * @throws TranslatorException
	 * @throws GenericException 
	 */
	List<TblEnvOrder> getTableEnvOrderFromOrderHeader(OrderHeader orderHeader) throws TranslatorException, GenericException;

	/**
	 * @param region
	 * @param orderType
	 * @return
	 * @throws TranslatorException
	 */
	List<TblRetailService> findServicesValidation(String region, String orderType) throws TranslatorException;

	
	/**
	 * @param orderId
	 * @param childParams
	 * @param action
	 * @param parentId
	 * @param leaf
	 * @return
	 */
	int upsertTblOrderDetails(Long orderId, List<ParamInfo> childParams, String action, long parentId, long leaf);

	/**
	 * @param tblOrder
	 */
	public void updateTblOrderDetailParamValue(TblOrderDetails tblOrderDetail);
	
	/**
	 * @param envOrderId
	 * @param errorCode
	 */
	void updateTblEnvOrderError(Long envOrderId, String errorCode);
	

	/**
	 * @param tblEnvOrder
	 * @return 
	 * @throws TranslatorException
	 */
	public List<TblEnvOrder> getPrevVersionTableEnvOrder(TblEnvOrder tblEnvOrder) throws TranslatorException;

	List<String> getSkipTasksForReverseService(String service, long aqmWorkId) throws GenericException;
	
	/**
	 * @param tblOrderService
	 * @throws GenericException
	 */
	public void updateTblOrderService(TblOrderService tblOrderService)  throws GenericException;
	
	
	/**
	 * @param orderId
	 * @throws GenericException
	 */
	public void deletePendingWOTaskByOrderID(Long orderId) throws GenericException;
/**
 * 
 * @param tblOrderDetails
 * @param param_name
 * @param param_value
 */
	public void createTblOrderDetails(TblOrderDetails tblOrderDetails, String param_name, String param_value);
	
	public String getAsClli(String bsAsId);
	
	public String getBwCluster(String bsAsId); 
	
}


