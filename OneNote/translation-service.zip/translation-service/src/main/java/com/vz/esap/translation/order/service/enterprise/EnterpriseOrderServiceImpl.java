package com.vz.esap.translation.order.service.enterprise;

import java.util.Arrays;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.vz.esap.translation.dao.model.TblEnvOrder;
import com.vz.esap.translation.dao.model.TblOrder;
import com.vz.esap.translation.dao.model.TblOrderDetails;
import com.vz.esap.translation.dao.model.TblOrderService;
import com.vz.esap.translation.entity.CustomerEntity;
import com.vz.esap.translation.entity.OrderManagerContactInfoEntity;
import com.vz.esap.translation.enums.EsapEnum;
import com.vz.esap.translation.enums.EsapEnum.FlowPath;
import com.vz.esap.translation.enums.EsapEnum.OrderEntity;
import com.vz.esap.translation.exception.GenericException;
import com.vz.esap.translation.exception.TranslatorException;
import com.vz.esap.translation.exception.TranslatorException.ErrorCode;
import com.vz.esap.translation.order.dao.VOIPOrderDao;
import com.vz.esap.translation.order.model.Order;
import com.vz.esap.translation.order.model.OrderHeader;
import com.vz.esap.translation.order.model.OrderHeader.SuppType;
import com.vz.esap.translation.order.model.request.ParamInfo;
import com.vz.esap.translation.order.model.request.VOIPOrderRequest;
import com.vz.esap.translation.order.model.response.VoipOrderResponse;
import com.vz.esap.translation.order.parser.OrderParser;
import com.vz.esap.translation.order.service.OrderServiceBase;
import com.vz.esap.translation.order.service.VOIPResponseGenerator;
import com.vz.esap.translation.order.service.helper.OrderServiceHelperImpl;
import com.vz.esap.translation.order.transformer.CustomerTransformer;
import com.vz.esap.translation.order.transformer.EnterpriseTblOrderDataTransformer;
import com.vz.esap.translation.order.transformer.EnterpriseTblOrderDetailsDataTransformer;
import com.vz.esap.translation.order.transformer.EnterpriseTblOrderServiceDataTransformer;
import com.vz.esap.translation.order.transformer.OrderManagerContactInfoTransformer;

import EsapEnumPkg.WorkOrderEnum;

@Service
public class EnterpriseOrderServiceImpl extends OrderServiceBase implements EnterpriseOrderService {

	@Autowired
	private VOIPOrderDao voipOrderDao;

	@Autowired
	private CustomerTransformer customerTransformer;

	@Autowired
	private EnterpriseTblOrderServiceDataTransformer enterpriseTblOrderServiceData;

	@Autowired
	private EnterpriseTblOrderDataTransformer enterpriseTblOrderData;

	@Autowired
	private OrderManagerContactInfoTransformer orderManagerContactInfoTransformer;

	@Autowired
	private EnterpriseTblOrderDetailsDataTransformer enterpriseTblOrderDetailsData;

	@Autowired
	private VOIPResponseGenerator voipResponseGenerator;

	@Autowired
	private OrderServiceHelperImpl orderServiceHelperImpl;

	@Autowired
	private OrderParser orderParserImpl;

	private static final Logger LOG = LoggerFactory.getLogger(EnterpriseOrderServiceImpl.class);

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.vz.esap.translation.order.service.enterprise.EnterpriseOrderService#
	 * processReleaseOrder(com.vz.esap.translation.dao.model.TblOrderDetails,
	 * com.vz.esap.translation.dao.model.TblOrder,
	 * com.vz.esap.translation.dao.model.TblEnvOrder,
	 * com.vz.esap.translation.order.model.request.VOIPOrderRequest, java.util.List)
	 */
	@Override
	public VoipOrderResponse processReleaseOrder(TblOrderDetails tblOrderDetails, TblOrder tblOrderBeanValidation,
			TblEnvOrder tblEnvOrder, VOIPOrderRequest voipOrderRequest, List<TblOrderDetails> tblOrderDetailsList)
			throws TranslatorException, GenericException {
		LOG.info("Entered - processReleaseOrder");

		VoipOrderResponse voipOrderResponse = null;
		CustomerEntity customerEntity = null;
		OrderHeader orderHeader = null;
		List<TblEnvOrder> tblEnvOrderListPrev = null;
		List<TblOrder> tblOrderListPrev = null;
		List<TblOrderDetails> tblOrderDetailsListPrev = null;
		CustomerEntity customerEntityPrev = null;

		try {
			if ("C".equalsIgnoreCase(voipOrderRequest.getOrderHeader().getOrderType())) {
				customerEntity = customerTransformer.transformOrderDetailsToCustomer(
						tblOrderBeanValidation.getOrderId(), tblOrderDetails.getOrderDetailId(), null, false,
						Arrays.asList("o"));

				customerEntityPrev = customerTransformer.transformOrderDetailsToCustomer(
						tblOrderBeanValidation.getOrderId(), tblOrderDetails.getOrderDetailId(), null, false,
						Arrays.asList("n"));

			} else {
				customerEntity = customerTransformer.transformOrderDetailsToCustomer(
						tblOrderBeanValidation.getOrderId(), tblOrderDetails.getOrderDetailId(), "n", false, null);
			}

			if (customerEntity == null) {
				throw new TranslatorException(ErrorCode.ENTERPRISE_TRANSFORMATION_FAILURE,
						"Failed To Transform Enterprise Entity");
			}
			LOG.debug("CustomerEntity  : {} ", customerEntity);
			
			int orderVersion = Integer.parseInt(voipOrderRequest.getOrderHeader().getWorkOrderVersion());
			
			LOG.info("Order version:: {}", orderVersion);
			
			if (orderVersion > 0) {
				VOIPOrderRequest voipOrderRequestPrev = orderParserImpl.getCorrectPrevPassVoipOrderRequest(voipOrderRequest);

				LOG.debug("SUPP Order version:: {}", voipOrderRequestPrev.getOrderHeader().getWorkOrderVersion());

				voipOrderRequestPrev.getOrderHeader().setWorkOrderVersion(Integer.toString(orderVersion - 1));
				tblEnvOrderListPrev = orderServiceHelperImpl.getMatchingPrevPassEnvOrder(voipOrderRequestPrev, 0,
						WorkOrderEnum.OrderClassify.RELEASE);

				LOG.debug("env table records size::{}", tblEnvOrderListPrev.size());
				LOG.info("ENV ORDER ID::{}", tblEnvOrderListPrev.get(0).getEnvOrderId());

				tblOrderListPrev = orderServiceHelperImpl.getMatchingPrevPassOrder(tblEnvOrderListPrev.get(0),
						OrderEntity.ENTERPRISE);

				LOG.info("TBL_ORDER records size::{}", tblOrderListPrev.size());
				LOG.info("TBL ORDER ID::{}", tblOrderListPrev.get(0).getOrderId());

				for (TblOrder tblOrderPrev : tblOrderListPrev) {
					if (tblOrderPrev.getAccountNumber().equalsIgnoreCase(customerEntity.getCustomerName())) {
						tblOrderDetailsListPrev = orderServiceHelperImpl.getMatchingOrderDetails(tblOrderPrev);
						LOG.info("TBL_ORDER_DETAILS records size::{}", tblOrderDetailsListPrev.size());
					}
				}

				if (tblOrderDetailsListPrev != null && !CollectionUtils.isEmpty(tblOrderDetailsListPrev)
						&& "Enterprise".equalsIgnoreCase(tblOrderDetailsListPrev.get(0).getParamName())) {

					LOG.debug("Previous Table Order Id::{}", tblOrderListPrev.get(0).getOrderId());
					LOG.debug("Previous Table Order Details Id::{}", tblOrderDetailsListPrev.get(0).getOrderDetailId());

					customerEntityPrev = customerTransformer.transformOrderDetailsToCustomer(
							tblOrderListPrev.get(0).getOrderId(), tblOrderDetailsListPrev.get(0).getOrderDetailId(),
							"n", false, null);
					customerEntityPrev.setEnvOrderId(tblEnvOrderListPrev.get(0).getEnvOrderId());
					customerEntityPrev.setInternalOrderId(tblOrderDetailsListPrev.get(0).getOrderId());

					LOG.info("CustomerEntityPrev::{}::{}", customerEntityPrev.getCustomerId(),
							customerEntityPrev.getCustomerName());
					LOG.info("CustomerEntity::{}::{}", customerEntity.getCustomerId(),
							customerEntity.getCustomerName());
				}
				if (SuppType.CANCEL.toString().equalsIgnoreCase(voipOrderRequest.getOrderHeader().getSuppType()))
					voipOrderRequest.getOrderHeader().setSuppType(SuppType.CANCEL.toString());
				else
					voipOrderRequest.getOrderHeader().setSuppType(SuppType.SUPP.toString());
			}

			orderHeader = createdOrderHeaderForEnterpriseOrder(voipOrderRequest, customerEntity);

			createReleaseOrders(orderHeader, customerEntity, customerEntityPrev, tblOrderBeanValidation,
					WorkOrderEnum.Status.WO_INIT, tblEnvOrder);

			voipOrderResponse = voipResponseGenerator.prepareSuccessOrderResponse(voipOrderRequest);

		} catch (TranslatorException ex) {
			LOG.error("Exception {} ", ex.getMessage());
			throw new TranslatorException(ex.getErrorCode(), ex.getMessage());
		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new GenericException(GenericException.GENERIC_EXCEPTION,
					"Exception in the provide input arguments-" + e);
		}
		LOG.info("Exit - processReleaseOrder");
		return voipOrderResponse;

	}

	/**
	 * @param orderHeader
	 * @param customerEntity
	 * @param tblOrderBeanValidation
	 * @param status
	 * @param tblEnvOrderObject
	 * @return isCreated
	 * @throws TranslatorException
	 * @throws GenericException
	 */
	boolean createReleaseOrders(OrderHeader orderHeader, CustomerEntity customerEntity,
			CustomerEntity customerEntityPrev, TblOrder tblOrderBeanValidation, int status,
			TblEnvOrder tblEnvOrderObject) throws TranslatorException, GenericException {
		LOG.info("Entered - createReleaseOrders");
		boolean isCreated = true;
		Order order = null;
		Order orderPrevPass = null;
		OrderManagerContactInfoEntity cnctInfo = null;
		long count = -1;
		TblOrder tblOrderObject = null;
		List<TblOrderService> tblOrderServiceList = null;
		boolean hasChange = false;
		ParamInfo headerParamInfo = null;
		ParamInfo entityParamInfo = null;

		try {
			order = new Order();
			orderHeader.setOrderStatus(status);

			if (customerEntity == null) {
				customerEntity = new CustomerEntity();
			}

			// :create order
			LOG.info("createOrders start creating customer entity orders");

			cnctInfo = orderManagerContactInfoTransformer
					.transformValEnvOrderToOrdMgrContactInfo(tblEnvOrderObject.getEnvOrderId(), null);

			if (cnctInfo != null)
				orderHeader.setOrdMgrContactInfo(cnctInfo);
			if (null != tblEnvOrderObject.getE2eiSensitivityLevel()) {
				orderHeader.setE2eiSensitivtyLevel(tblEnvOrderObject.getE2eiSensitivityLevel());
			}
			if (null != tblEnvOrderObject.getE2eiSensitivityLevel()) {
				customerEntity.setCustSensitivityLevel(tblEnvOrderObject.getE2eiSensitivityLevel());
				LOG.debug("CustomerEntity SenseLevel--> processReleaseOrder: {}",
						customerEntity.getCustSensitivityLevel());
			}
			if (null != tblEnvOrderObject.getEnvOrderId())
				orderHeader.setEnvOrderId(tblEnvOrderObject.getEnvOrderId());
			if (null != tblEnvOrderObject.getProjectId())
				orderHeader.setProjectId(tblEnvOrderObject.getProjectId());
			orderHeader.setEnvOrderId(tblEnvOrderObject.getEnvOrderId());
			orderHeader.setProjectId(tblEnvOrderObject.getProjectId());

			order.setOrderHeader(orderHeader);
			order.setCustomer(customerEntity);

			if ("I".equalsIgnoreCase(orderHeader.getEntityAction())) {
				if (customerEntityPrev != null) {
					LOG.info("customerEntityPrev is not null");

					headerParamInfo = enterpriseTblOrderDetailsData.prepareTblOrderDetailsHeaderParamData(order,
							customerEntityPrev, true);

					entityParamInfo = enterpriseTblOrderDetailsData.prepareTblOrderDetailsEntityParamDataForCustomer(
							customerEntityPrev, customerEntity, true, null);

					if (entityParamInfo != null && entityParamInfo.getAction() != null
							&& entityParamInfo.getAction().equals("C")) {
						LOG.info("entityParamInfo.getAction(): {}", entityParamInfo.getAction());
						
						hasChange = true;
						orderHeader.setEntityAction("C");

						entityParamInfo.addNotNullValChild("ENT_INV_CHANGE", "Y", "n");												
						
					} else if (entityParamInfo != null && entityParamInfo.getAction() != null
							&& entityParamInfo.getAction().equals("NC")) {
						LOG.info("entityParamInfo.getAction(): {}", entityParamInfo.getAction());
						hasChange = false;
						orderHeader.setEntityAction("NC");
					}

				} else {

					headerParamInfo = enterpriseTblOrderDetailsData.prepareTblOrderDetailsHeaderParamData(order);
					entityParamInfo = enterpriseTblOrderDetailsData
							.prepareTblOrderDetailsEntityParamDataForCustomer(order, null);
					LOG.info("entityParamInfo.getAction(): {}", entityParamInfo.getAction());

					hasChange = false;
					orderHeader.setEntityAction("I");

				}
			} else if ("C".equalsIgnoreCase(orderHeader.getEntityAction())) {
				if (customerEntityPrev != null) {
					LOG.info("locationEntityPrev is not null");

					headerParamInfo = enterpriseTblOrderDetailsData.prepareTblOrderDetailsHeaderParamData(order,
							customerEntityPrev, true);

					entityParamInfo = enterpriseTblOrderDetailsData.prepareTblOrderDetailsEntityParamDataForCustomer(
							customerEntityPrev, customerEntity, true, null);

					if (entityParamInfo != null && entityParamInfo.getAction() != null
							&& entityParamInfo.getAction().equals("C")) {
						LOG.info("entityParamInfo.getAction(): {}", entityParamInfo.getAction());
						
						hasChange = true;
						orderHeader.setEntityAction("C");

						entityParamInfo.addNotNullValChild("ENT_INV_CHANGE", "Y", "n");	
					}
				}
			}

			LOG.info("orderHeader.getEntityAction()-Enterprise : {}  ", orderHeader.getEntityAction());
			if (null != headerParamInfo && !"NC".equalsIgnoreCase(orderHeader.getEntityAction())) {
				headerParamInfo.addChildParam(entityParamInfo);

				// :create order
				tblOrderObject = enterpriseTblOrderData.prepareTblOrderDataFromOrder(order, 1L);
				count = voipOrderDao.createTblOrder(tblOrderObject);

				LOG.info("Tbl_Order Created for Enterprise , Order Id : {}", tblOrderObject.getOrderId());

				// :create order Details
				LOG.info("createOrders start creating customer entity order details");
				
				if (entityParamInfo != null && entityParamInfo.getAction() != null)
					voipOrderDao.populateOrderDetails(tblOrderObject, headerParamInfo.getChildParams(),
							entityParamInfo.getAction(), 0, 0);
				else
					voipOrderDao.populateOrderDetails(tblOrderObject, headerParamInfo.getChildParams(), "n", 0, 0);

				// :create service entry for WF

				LOG.info("createOrders start creating service for Enterprise entity");

				orderHeader.setFlowPath(FlowPath.valueOf(tblOrderObject.getFlowPath()));
				orderHeader.setTblOrderId(tblOrderObject.getOrderId());
				orderHeader.setEntityType(EsapEnum.OrderEntity.ENTERPRISE.getIndex());
				orderHeader.setProvisionCategory(customerEntity.getProvisionCategory());
				
				order.setOrderHeader(orderHeader);

				orderPrevPass = new Order();
				orderPrevPass.setOrderHeader(orderHeader);
				orderPrevPass.setCustomerEntity(customerEntityPrev);

				tblOrderServiceList = enterpriseTblOrderServiceData.prepareTblOrderServiceData(order, orderPrevPass,
						null);

				LOG.info("Retail Order Service Count : {}", tblOrderServiceList.size());

				for (TblOrderService tblOrderService : tblOrderServiceList) {
					voipOrderDao.createTblOrderService(tblOrderService);
				}

				voipOrderDao.updateTblOrderStatus(tblOrderObject.getOrderId(), WorkOrderEnum.Status.WO_INIT);
			} else if (customerEntityPrev != null && "NC".equalsIgnoreCase(orderHeader.getEntityAction())) {

				orderServiceHelperImpl.handleSuppOrderWithNoChange(tblEnvOrderObject.getEnvOrderId(),
						customerEntityPrev.getInternalOrderId(), tblEnvOrderObject);

			}

		} catch (TranslatorException ex) {
			LOG.error("Exception {} {}", ex.getMessage(), ex);
			throw new TranslatorException(ex.getErrorCode(), ex.getMessage());
		} catch (Exception e) {
			LOG.error("Exception {} {}", e.getMessage(), e);
			throw new GenericException(GenericException.GENERIC_EXCEPTION, "Exception in the provide input arguments");
		}
		LOG.info("Exit - createReleaseOrders");
		return isCreated;
	}

	/**
	 * @param order
	 * @param orderPrevPass
	 * @param tblOrderObject
	 * @return tblOrderServiceList
	 * @throws TranslatorException
	 */
	List<TblOrderService> createOrderServiceEntry(Order order, Order orderPrevPass, TblOrder tblOrderObject)
			throws TranslatorException {
		OrderHeader orderHeader = order.getOrderHeader();
		orderHeader.setFlowPath(FlowPath.valueOf(tblOrderObject.getFlowPath()));
		orderHeader.setTblOrderId(tblOrderObject.getOrderId());
		order.setOrderHeader(orderHeader);

		// refactor prepareTblOrderServiceData to pass orderPrevPass
		List<TblOrderService> tblOrderServiceList = enterpriseTblOrderServiceData.prepareTblOrderServiceData(order,
				orderPrevPass, null);

		if (tblOrderServiceList.isEmpty()) {
			throw new TranslatorException(ErrorCode.SERVICE_ORDER_CREATION_FAILURE, "Failed To Create Service Order");
		}
		LOG.info("Retail Order Service Count : {}", tblOrderServiceList.size());

		for (TblOrderService tblOrderService : tblOrderServiceList) {
			if (voipOrderDao.createTblOrderService(tblOrderService) <= 0) {
				throw new TranslatorException(ErrorCode.SERVICE_ORDER_CREATION_FAILURE,
						"Failed To Create Service Order");
			}
		}

		return tblOrderServiceList;
	}

}
