package com.vz.esap.translation.constant;

import com.vz.esap.translation.enums.EsapEnum.FunctionCode;

public class TranslationConstant {

	public static final String FUNCTION_CODE_VALIDATE = "VALIDATE";
	public static final String FUNCTION_CODE_RELEASE = "RELEASE";
	public static final long TRUNK_CALL_DEFAULT_CAPACITY = 1;
	public static final String FUNCTION_CODE_NBS_PROV_CONFIG = "NBS_PROV_CONFIG";
	public static final String FUNCTION_CODE_CIRCUIT_INFO = "CIRCUIT_INFO";
	//TODO Discon add REL_SUSPEND and REL_DEACTIVATE constants - Done
	public static final String FUNCTION_CODE_REL_SUSPEND = "REL_SUSPEND";
	public static final String FUNCTION_CODE_REL_DEACTIVATE = "REL_DEACTIVATE";
	public static final String FUNCTION_CODE_GET_LOC_INFO = FunctionCode.GET_LOC_INFO.toString();
	public static final String LNP_ACTIVATE = "LNP_ACTIVATE";
	public static final String CUSTOMER_ENTITY_CLASS = "CustomerEntity";
	public static final String LOCATION_ENTITY_CLASS = "LocationEntity";
	public static final String DEVICE_ENTITY_CLASS = "DeviceEntity";
	public static final String ENTERPRISE_TRUNK_ENTITY_CLASS = "EnterpriseTrunkEntity";
	public static final String TRUNK_GROUP_ENTITY_CLASS = "TrunkGroupEntity";
	public static final String NBS_ENTITY_CLASS = "NbsEntity";
	public static final String LOCATION_COUNTRY_CODE_US = "1";
	public static final String TBL_ENTERPRISE = "TBL_ENTERPRISE";
	public static final String LOCATION_ENTITY = "LOCATIONENTITY";
	public static final String CUSTOMER_ENTITY = "CUSTOMERENTITY";
	public static final String TRUNK_GROUP_ENTITY = "TRUNKGROUPENTITY";
	public static final String ENTERPRISE_TRUNK_ENTITY = "ENTERPRISETRUNKENTITY";
	public static final String NBS_ENTTY = "NBSENTITY";
	public static final String DEVICE_ENTITY = "DEVICEENTITY";
	public static final String GROUP_TN_ENTITY = "GROUPTNENTITY";
	public static final String TN_ENTITY = "TNENTITY";
	public static final String FUNCTION_CODE_PIT = "PIT";	
	public static final String HTTP_PROTOCOL = "HTTP";
	public static final Object FUNCTION_CODE_LOC_ACTIVATE = "LOC_ACTIVATE_COMPLETE";
	public static final String TBL_LOCATION = "TBL_LOCATION";
	public static final String NBS_PROV = "NBS_PROV";
	
	
}
