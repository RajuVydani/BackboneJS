package com.vz.esap.translation.order.model.request;

public class TnRangeInfo {

	private String tnRangeStart;
	private String tnRangeEnd;

	public String getTnRangeStart() {
		return tnRangeStart;
	}

	public void setTnRangeStart(String tnRangeStart) {
		this.tnRangeStart = tnRangeStart;
	}

	public String getTnRangeEnd() {
		return tnRangeEnd;
	}

	public void setTnRangeEnd(String tnRangeEnd) {
		this.tnRangeEnd = tnRangeEnd;
	}

}
