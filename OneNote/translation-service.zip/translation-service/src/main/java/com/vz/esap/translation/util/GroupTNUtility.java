package com.vz.esap.translation.util;

import java.util.ArrayList;
import java.util.Objects;

import org.apache.commons.lang3.BooleanUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.CollectionUtils;

import com.vz.esap.translation.entity.GroupTNEntity;
import com.vz.esap.translation.entity.TNEntity;
import com.vz.esap.translation.enums.EsapEnum;
import com.vz.esap.translation.enums.EsapEnum.OrderAction;
import com.vz.esap.translation.order.model.request.ParamInfo;

/**
 * @author baigkh
 *
 */
public class GroupTNUtility extends OrderUtility {

	private static final Logger LOG = LoggerFactory.getLogger(GroupTNUtility.class);
	private static final String TN_REMOVE = "TNRemove";

	/**
	 * @param grpTNEntityPrev
	 * @param action
	 * @return grpTnParam
	 */
	public static ParamInfo getParamInfo(GroupTNEntity grpTNEntityPrev, String action) {
		LOG.debug(" Entering GroupTNUtil.getParamInfo" + grpTNEntityPrev + "action=" + action);
		LOG.info(" Entered  getParamInfo(grpTNEntityPrev, action)");
		ParamInfo grpTnParam = new ParamInfo("GroupTN", null, action);
		grpTnParam.addNotNullValChild("GroupTNId", grpTNEntityPrev.getGroupTNId(), action, ParamInfo.Tag.ID);
		@SuppressWarnings("unused")
		boolean addTN = false;
		boolean delTN = false;
		boolean chngeTN = false;
		
		if (Objects.nonNull(grpTNEntityPrev.getTnRecord())) {
			if ("I".equalsIgnoreCase(action)) {
				addTN = true;
			} else if ("O".equalsIgnoreCase(action)) {
				delTN = true;
			} else if ("C".equalsIgnoreCase(action)) {
				chngeTN = true;
			}
			TNEntity tnRecord = grpTNEntityPrev.getTnRecord();
			ParamInfo tnParam = TNUtility.buildTNParamDataForTN(tnRecord, action);
			tnParam.addNotNullValChild("LinePort", grpTNEntityPrev.getLinePort(), action, ParamInfo.Tag.NON_ORD);
			grpTnParam.addChildParam(tnParam, ParamInfo.Tag.ID);
			if (null != tnRecord.getSTNInd() && tnRecord.getSTNInd().longValue() == 1 && delTN) {
				if (!(StringUtils.equals(grpTNEntityPrev.getAttrib(TN_REMOVE), "N")))
					grpTnParam.addChildParam(new ParamInfo(TN_REMOVE, "Y", null));
			}
		}
		if (delTN) {
			grpTnParam.addChildParam(new ParamInfo("PTN", "DEL", null));
		}

		if (grpTNEntityPrev.getTrunkGroupEntity() != null) {
			grpTnParam.addNotNullValChild("CustomerId", grpTNEntityPrev.getTrunkGroupEntity().getCustomerId(), action);
			grpTnParam.addNotNullValChild("LocationId", grpTNEntityPrev.getTrunkGroupEntity().getLocationId(), action);
			grpTnParam.addNotNullValChild("Region", grpTNEntityPrev.getTrunkGroupEntity().getRegion(), action);

		}
		grpTnParam.addNotNullValChild("AsClli", grpTNEntityPrev.getAsClli(), action); //add broadsoft clli.
		grpTnParam.addNotNullValChild("DeviceName", grpTNEntityPrev.getDeviceName(), action);
		grpTnParam.addNotNullValChild("EntityAction", grpTNEntityPrev.getEntityAction(), action);
		grpTnParam.addNotNullValChild("TnCount", grpTNEntityPrev.getTnCount(), action);
		grpTnParam.addNotNullValChild("SubscriberId", grpTNEntityPrev.getSubscriberId(), action, ParamInfo.Tag.NON_ORD);
		grpTnParam.addNotNullValChild("Extension", grpTNEntityPrev.getExtension(), action, ParamInfo.Tag.NON_ORD);
		grpTnParam.addNotNullValChild("PrivateNumber", grpTNEntityPrev.getPrivateNumber(), action, ParamInfo.Tag.NON_ORD);
		grpTnParam.addNotNullValChild("SipDomain", grpTNEntityPrev.getSipDomain(), action, ParamInfo.Tag.NON_ORD);
		grpTnParam.addNotNullValChild("GroupName", grpTNEntityPrev.getGroupName(), action, ParamInfo.Tag.NAME);
		grpTnParam.addNotNullValChild("TnCLIDFirstName", grpTNEntityPrev.getTnCLIDFirstName(), action);
		grpTnParam.addNotNullValChild("TnCLIDLastName", grpTNEntityPrev.getTnCLIDLastName(), action);
		grpTnParam.addNotNullValChild("SequenceNo", grpTNEntityPrev.getSequenceNo(), action, ParamInfo.Tag.NON_ORD);
		grpTnParam.addNotNullValChild("LinePort", grpTNEntityPrev.getLinePort(), action, ParamInfo.Tag.NON_ORD);
		grpTnParam.addNotNullValChild("VMBoxNumber", grpTNEntityPrev.getVmBoxNumber(), action, ParamInfo.Tag.NON_ORD);
		LOG.info("VmPin - [" + grpTNEntityPrev.getVmPin() + "]");
		grpTnParam.addNotNullValChild("VMPin", grpTNEntityPrev.getVmPin(), action, ParamInfo.Tag.NON_ORD);

		grpTnParam.addNotNullValChild("GroupId", grpTNEntityPrev.getGroupId(), action);

		if (grpTNEntityPrev.getVmType() != null && !"0".equalsIgnoreCase(grpTNEntityPrev.getVmType())) {
			if ("I".equalsIgnoreCase(action)) {
				grpTnParam.addChildParam(new ParamInfo("VM_ACTION", "ADD", null));
			} else if ("O".equalsIgnoreCase(action)) {
				grpTnParam.addChildParam(new ParamInfo("VM_ACTION", "DEL", null));
			} else if ("C".equalsIgnoreCase(action)) {
				grpTnParam.addChildParam(new ParamInfo("VM_ACTION", "MOD", null));
			}
		}
		if (!"0".equals(grpTNEntityPrev.getVmType())) {
			grpTnParam.addNotNullValChild("VMType", grpTNEntityPrev.getVmType(), action, ParamInfo.Tag.NON_ORD);
		}
		if (grpTNEntityPrev.getTrunkGroupEntity() != null && grpTNEntityPrev.getTrunkGroupEntity().getDisableFeatureList() == null
				&& null != grpTNEntityPrev.getDisableFeatureList()) {
			LOG.info("Assigning Disable featureList");
			grpTNEntityPrev.getTrunkGroupEntity().setDisableFeatureList(grpTNEntityPrev.getDisableFeatureList());
		}

		ArrayList<String> nonPkgFeatures = grpTNEntityPrev.getNonPkgFeatures();
		if (!CollectionUtils.isEmpty(nonPkgFeatures)) {
			if (StringUtils.equalsIgnoreCase(action, "I")) {
				grpTnParam.addChildParam(new ParamInfo("FEAT_ASSIGN", null, null));
			}
			grpTnParam.addChildParam(OrderUtility.getNonPkgParamInfo(nonPkgFeatures, action));
		}

		/*
		 * March Voip Feature Enhancement Changes
		 */
		ArrayList<String> userFeatures = grpTNEntityPrev.getUserFeatures();
		if (!CollectionUtils.isEmpty(userFeatures)) {
			if (StringUtils.equalsIgnoreCase(action, "I")) {
				grpTnParam.addChildParam(new ParamInfo("USER_ASSIGN", null, null));
			}
			grpTnParam.addChildParam(OrderUtility.getUserFeatInfo(userFeatures, action));

		}

		ArrayList<String> disableFeatureList = grpTNEntityPrev.getDisableFeatureList();
		if (!CollectionUtils.isEmpty(disableFeatureList)) {
			ParamInfo dfParam = new ParamInfo("DisableFeatureList", (String) null, action);

			for (String feature : disableFeatureList) {
				LOG.info("GroupTNUtil Adding DisableFeature:" + feature);
				dfParam.addChildParam(new ParamInfo("Feature", feature, action));
			}
			grpTnParam.addChildParam(dfParam);
		}

		grpTnParam.addChildParam(OrderUtility.getAttribParamInfo(grpTNEntityPrev.getAttribMap(), action));
		if (grpTNEntityPrev.getAction() != null) {
			LOG.info("GroupTNOrder.Action:" + grpTNEntityPrev.getAction().name());
			if (grpTNEntityPrev.getAction().equals(EsapEnum.OrderAction.ADD)) {
				grpTnParam.addChildParam(new ParamInfo("Action", "I", "n"));
			} else if (grpTNEntityPrev.getAction().equals(EsapEnum.OrderAction.MODIFY)) {
				grpTnParam.addChildParam(new ParamInfo("Action", "C", "n"));
			}  else if (grpTNEntityPrev.getAction().equals(EsapEnum.OrderAction.DELETE)) {
				grpTnParam.addChildParam(new ParamInfo("Action", "O", "n"));
			}
		}
		if (BooleanUtils.isTrue(grpTNEntityPrev.getHotCutIndicator()))
			grpTnParam.addNotNullValChild("HotCutIndicator", "Y", action);
		if (BooleanUtils.isTrue(grpTNEntityPrev.getCDDDIndicator()))
			grpTnParam.addNotNullValChild("CDDDIndicator", "Y", action);
		
		grpTnParam.addNotNullValChild("TimeZone", grpTNEntityPrev.getTimeZoneId(), action);
		grpTnParam.addNotNullValChild("DaylightSavingInd", grpTNEntityPrev.getDayLightSavingInd(), action);
		grpTnParam.addNotNullValChild("AuthFeatureType", grpTNEntityPrev.getAuthFeatureType(), action);
		
		grpTnParam.setName("TrunkTN"); // Mark them as TrunkTN

		LOG.info("Exited GroupTNUtil.getParamInfo");

		return grpTnParam;
	}

	/**
	 * @param grpTNEntityPrev
	 * @param action
	 * @return grpTnParam
	 */
	public static ParamInfo getTnSystemUpdateParamInfo(GroupTNEntity grpTNEntityPrev, String action) {

		LOG.info(" Entered getTnSystemUpdateParamInfo for TN Count is : {}", grpTNEntityPrev.getTnCount());
		ParamInfo grpTnParam = new ParamInfo("SystemUpdate", null, action);

		if (grpTNEntityPrev.getTrunkGroupEntity() != null) {
			grpTnParam.addNotNullValChild("CustomerId", grpTNEntityPrev.getTrunkGroupEntity().getCustomerId(), action);
			grpTnParam.addNotNullValChild("LocationId", grpTNEntityPrev.getTrunkGroupEntity().getLocationId(), action);
		}

		if (grpTNEntityPrev.getTnCount() >= 1) {
			grpTnParam.addNotNullValChild("TnCount", grpTNEntityPrev.getTnCount(), action);
		}

		LOG.info(" Exited getTnSystemUpdateParamInfo");

		return grpTnParam;
	}

	public static ParamInfo getParamInfo(GroupTNEntity grpTNEntityPrev, boolean change) {

		GroupTNEntity groupTnEntity = grpTNEntityPrev.getGroupTNEntity() != null ? grpTNEntityPrev.getGroupTNEntity()
				: new GroupTNEntity();

		LOG.info(" Entering GroupTNUtil.getParamInfo = {} , action= {}" ,grpTNEntityPrev, booleanToStr(change));
		
		ParamInfo grpTnParam = new ParamInfo("GroupTN", null, booleanToStr(change));
		grpTnParam.addChangeParam("GroupTNId", grpTNEntityPrev.getGroupTNId(), groupTnEntity.getGroupTNId(), change,
				ParamInfo.Tag.ID);
		
		@SuppressWarnings("unused")
		boolean addTN = false;
		boolean delTN = false;
		
		if (Objects.nonNull(grpTNEntityPrev.getTnRecord())) {
			if ("I".equalsIgnoreCase(booleanToStr(change))) {
				addTN = true;
			}
			if(OrderAction.DELETE.equals(grpTNEntityPrev.getAction())) {
				delTN = true;
			}
			TNEntity tnRecord = grpTNEntityPrev.getTnRecord();
			ParamInfo tnParam = TNUtility.buildTNParamDataForTN(tnRecord, booleanToStr(change));
			tnParam.addNotNullValChild("LinePort", grpTNEntityPrev.getLinePort(), booleanToStr(change), ParamInfo.Tag.NON_ORD);
			grpTnParam.addChildParam(tnParam, ParamInfo.Tag.ID);

			if (null != tnRecord.getSTNInd() && tnRecord.getSTNInd().longValue() == 1 && delTN) {
				if (!(StringUtils.equals(grpTNEntityPrev.getAttrib(TN_REMOVE), "N")))
					grpTnParam.addChildParam(new ParamInfo(TN_REMOVE, "Y", null));
			}
		}
		if (delTN) {
			grpTnParam.addChildParam(new ParamInfo("PTN", "DEL", null));
		}

		if (grpTNEntityPrev.getTrunkGroupEntity() != null) {
			grpTnParam.addChangeParam("CustomerId", grpTNEntityPrev.getTrunkGroupEntity().getCustomerId(),
					groupTnEntity.getTrunkGroupEntity().getCustomerId(), change);
			grpTnParam.addChangeParam("LocationId", grpTNEntityPrev.getTrunkGroupEntity().getLocationId(),
					groupTnEntity.getTrunkGroupEntity().getLocationId(), change);
			grpTnParam.addChangeParam("Region", grpTNEntityPrev.getTrunkGroupEntity().getRegion(),
					groupTnEntity.getTrunkGroupEntity().getRegion(), change);
		}
		grpTnParam.addChangeParam("AsClli", grpTNEntityPrev.getAsClli(), grpTNEntityPrev.getAsClli(), change); //add broadsoft clli.
		grpTnParam.addChangeParam("EntityAction", groupTnEntity.getEntityAction(), groupTnEntity.getEntityAction(), change);
		grpTnParam.addChangeParam("LinePort", groupTnEntity.getLinePort(), groupTnEntity.getLinePort(), change);
		grpTnParam.addChangeParam("TnCount", groupTnEntity.getTnCount(), groupTnEntity.getTnCount(), change);
		grpTnParam.addChangeParam("SubscriberId", grpTNEntityPrev.getSubscriberId(), grpTNEntityPrev.getSubscriberId(),
				change, ParamInfo.Tag.NON_ORD);
		grpTnParam.addChangeParam("Extension", grpTNEntityPrev.getExtension(), groupTnEntity.getExtension(), change,
				ParamInfo.Tag.NON_ORD);
		grpTnParam.addChangeParam("PrivateNumber", grpTNEntityPrev.getPrivateNumber(), groupTnEntity.getPrivateNumber(),
				change, ParamInfo.Tag.NON_ORD);
		grpTnParam.addChangeParam("SipDomain", grpTNEntityPrev.getSipDomain(), groupTnEntity.getSipDomain(), change,
				ParamInfo.Tag.NON_ORD);
		grpTnParam.addChangeParam("GroupName", grpTNEntityPrev.getGroupName(), groupTnEntity.getGroupName(), change,
				ParamInfo.Tag.NAME);
		grpTnParam.addChangeParam("TnCLIDFirstName", grpTNEntityPrev.getTnCLIDFirstName(),
				groupTnEntity.getTnCLIDFirstName(), change);
		grpTnParam.addChangeParam("TnCLIDLastName", grpTNEntityPrev.getTnCLIDLastName(),
				groupTnEntity.getTnCLIDLastName(), change);
		grpTnParam.addChangeParam("SequenceNo", grpTNEntityPrev.getSequenceNo(), groupTnEntity.getSequenceNo(), change,
				ParamInfo.Tag.NON_ORD);
		grpTnParam.addChangeParam("LinePort", grpTNEntityPrev.getLinePort(), groupTnEntity.getLinePort(), change,
				ParamInfo.Tag.NON_ORD);
		grpTnParam.addChangeParam("VMBoxNumber", grpTNEntityPrev.getVmBoxNumber(), groupTnEntity.getVmBoxNumber(), change,
				ParamInfo.Tag.NON_ORD);
		LOG.info("VmPin - [" + grpTNEntityPrev.getVmPin() + "]");
		grpTnParam.addChangeParam("VMPin", grpTNEntityPrev.getVmPin(), groupTnEntity.getVmPin(), change,
				ParamInfo.Tag.NON_ORD);
		grpTnParam.addChangeParam("DeviceName", grpTNEntityPrev.getDeviceName(), groupTnEntity.getDeviceName(), change);
		grpTnParam.addChangeParam("GroupId", grpTNEntityPrev.getGroupId(), groupTnEntity.getGroupId(), change);

		if (grpTNEntityPrev.getVmType() != null && !"0".equalsIgnoreCase(grpTNEntityPrev.getVmType())) {
			if ("I".equalsIgnoreCase(booleanToStr(change))) {
				grpTnParam.addChildParam(new ParamInfo("VM_ACTION", "ADD", null));
			} else if ("C".equalsIgnoreCase(booleanToStr(change))) {
				grpTnParam.addChildParam(new ParamInfo("VM_ACTION", "MOD", null));
			}
		}
		if (!"0".equals(grpTNEntityPrev.getVmType())) {
			grpTnParam.addChangeParam("VMType", grpTNEntityPrev.getVmType(), groupTnEntity.getVmType(), change,
					ParamInfo.Tag.NON_ORD);
		}
		if (grpTNEntityPrev.getTrunkGroupEntity() != null && grpTNEntityPrev.getTrunkGroupEntity().getDisableFeatureList() == null
				&& null != grpTNEntityPrev.getDisableFeatureList()) {
			LOG.info("Assigning Disable featureList");
			grpTNEntityPrev.getTrunkGroupEntity().setDisableFeatureList(grpTNEntityPrev.getDisableFeatureList());
		}

		ArrayList<String> nonPkgFeatures = grpTNEntityPrev.getNonPkgFeatures();
		if (!CollectionUtils.isEmpty(nonPkgFeatures)) {
			if (StringUtils.equalsIgnoreCase(booleanToStr(change), "I")) {
				grpTnParam.addChildParam(new ParamInfo("FEAT_ASSIGN", null, null));
			}
			grpTnParam.addChildParam(OrderUtility.getNonPkgParamInfo(nonPkgFeatures, booleanToStr(change)));
		}

		/*
		 * March Voip Feature Enhancement Changes
		 */
		ArrayList<String> userFeatures = grpTNEntityPrev.getUserFeatures();
		if (!CollectionUtils.isEmpty(userFeatures)) {
			if (StringUtils.equalsIgnoreCase(booleanToStr(change), "I")) {
				grpTnParam.addChildParam(new ParamInfo("USER_ASSIGN", null, null));
			}
			grpTnParam.addChildParam(OrderUtility.getUserFeatInfo(userFeatures, booleanToStr(change)));

		}

		ArrayList<String> disableFeatureList = grpTNEntityPrev.getDisableFeatureList();
		if (!CollectionUtils.isEmpty(disableFeatureList)) {
			ParamInfo dfParam = new ParamInfo("DisableFeatureList", (String) null, booleanToStr(change));

			for (String feature : disableFeatureList) {
				LOG.info("GroupTNUtil Adding DisableFeature:" + feature);
				dfParam.addChildParam(new ParamInfo("Feature", feature, booleanToStr(change)));
			}
			grpTnParam.addChildParam(dfParam);
		}

		grpTnParam.addChildParam(OrderUtility.getAttribParamInfo(grpTNEntityPrev.getAttribMap(), booleanToStr(change)));
		if (grpTNEntityPrev.getAction() != null) {
			LOG.info("GroupTNOrder.Action:" + grpTNEntityPrev.getAction().name());
			if (grpTNEntityPrev.getAction().equals(EsapEnum.OrderAction.ADD)) {
				grpTnParam.addChildParam(new ParamInfo("Action", "I", "n"));
			} else if (grpTNEntityPrev.getAction().equals(EsapEnum.OrderAction.MODIFY)) {
				grpTnParam.addChildParam(new ParamInfo("Action", "C", "n"));
			}
		}
		if (BooleanUtils.isTrue(grpTNEntityPrev.getHotCutIndicator()))
			grpTnParam.addNotNullValChild("HotCutIndicator", "Y", booleanToStr(change));
		if (BooleanUtils.isTrue(grpTNEntityPrev.getCDDDIndicator()))
			grpTnParam.addNotNullValChild("CDDDIndicator", "Y", booleanToStr(change));
		
		grpTnParam.addChangeParam("TimeZone", groupTnEntity.getTimeZoneId(), groupTnEntity.getTimeZoneId(), change);
		grpTnParam.addChangeParam("DaylightSavingInd", groupTnEntity.getDayLightSavingInd(),
				groupTnEntity.getDayLightSavingInd(), change);

		grpTnParam.setName("TrunkTN"); // Mark them as TrunkTN

		LOG.info("Exited GroupTNUtil.getParamInfo");

		return grpTnParam;
	}

	public static ParamInfo getTnSystemUpdateParamInfo(GroupTNEntity grpTNEntityPrev, boolean change) {

		GroupTNEntity groupTnEntity = grpTNEntityPrev.getGroupTNEntity() != null ? grpTNEntityPrev.getGroupTNEntity()
				: new GroupTNEntity();
		LOG.info(" Entered getTnSystemUpdateParamInfo for TN Count is : {}", grpTNEntityPrev.getTnCount());
		ParamInfo grpTnParam = new ParamInfo("SystemUpdate", null, booleanToStr(change));

		if (grpTNEntityPrev.getTrunkGroupEntity() != null) {
			grpTnParam.addChangeParam("CustomerId", grpTNEntityPrev.getTrunkGroupEntity().getCustomerId(),
					groupTnEntity.getTrunkGroupEntity().getCustomerId(), change);
			grpTnParam.addChangeParam("LocationId", grpTNEntityPrev.getTrunkGroupEntity().getLocationId(),
					groupTnEntity.getTrunkGroupEntity().getLocationId(), change);
		}

		if (grpTNEntityPrev.getTnCount() >= 1) {
			grpTnParam.addChangeParam("TnCount", groupTnEntity.getTnCount(), groupTnEntity.getTnCount(), change);
		}

		LOG.info(" Exited getTnSystemUpdateParamInfo");

		return grpTnParam;

	}

	/**
	 * @param bool
	 * @return boolean
	 */
	public static String booleanToStr(Boolean bool) {
		if (bool == null)
			return null;
		else
			return bool ? "C" : "I";
	}

	public static ParamInfo getParamInfo(GroupTNEntity grpTNEntityPrev, GroupTNEntity groupTnEntity, boolean change,
			String action) {
		
		LOG.info(" Entering GroupTNUtil.getParamInfo -->supp CHANGE value: {}", change);
		
		ParamInfo grpTnParam = null;
		
		
			grpTnParam = new ParamInfo("GroupTN", null, null);
			if(grpTNEntityPrev.getGroupTNId() != null) {
				grpTnParam.addChildParam(new ParamInfo("GroupTNId", grpTNEntityPrev.getGroupTNId().toString(), null));
			}
			if (Objects.nonNull(grpTNEntityPrev.getTnRecord())) {
				TNEntity tnRecordPrev = grpTNEntityPrev.getTnRecord();
				TNEntity tnRecord = groupTnEntity.getTnRecord();
				ParamInfo tnParam = TNUtility.buildTNParamDataForPrevTN(tnRecordPrev, tnRecord, change, action);
				tnParam.addNotNullValChild("LinePort", grpTNEntityPrev.getLinePort(), booleanToStr(change), ParamInfo.Tag.NON_ORD);
				grpTnParam.addChildParam(tnParam, ParamInfo.Tag.ID);
			}
			if (grpTNEntityPrev.getTrunkGroupEntity() != null) {
				grpTnParam.addChangeParam("CustomerId", grpTNEntityPrev.getTrunkGroupEntity().getCustomerId(),
						groupTnEntity.getTrunkGroupEntity().getCustomerId(), change);
				grpTnParam.addChangeParam("LocationId", grpTNEntityPrev.getTrunkGroupEntity().getLocationId(),
						groupTnEntity.getTrunkGroupEntity().getLocationId(), change);
				grpTnParam.addChangeParam("Region", grpTNEntityPrev.getTrunkGroupEntity().getRegion(),
						groupTnEntity.getTrunkGroupEntity().getRegion(), change);
			}
			grpTnParam.addChangeParam("TnCount", groupTnEntity.getTnCount(), groupTnEntity.getTnCount(), change);
			grpTnParam.addChangeParam("EntityAction", groupTnEntity.getEntityAction(), groupTnEntity.getEntityAction(), change);
			grpTnParam.addChangeParam("LinePort", groupTnEntity.getLinePort(), groupTnEntity.getLinePort(), change);
			grpTnParam.addChangeParam("SubscriberId", grpTNEntityPrev.getSubscriberId(), grpTNEntityPrev.getSubscriberId(),
					change, ParamInfo.Tag.NON_ORD);
			grpTnParam.addChangeParam("Extension", grpTNEntityPrev.getExtension(), groupTnEntity.getExtension(), change,
					ParamInfo.Tag.NON_ORD);
			grpTnParam.addChangeParam("PrivateNumber", grpTNEntityPrev.getPrivateNumber(), groupTnEntity.getPrivateNumber(),
					change, ParamInfo.Tag.NON_ORD);
			grpTnParam.addChangeParam("SipDomain", grpTNEntityPrev.getSipDomain(), groupTnEntity.getSipDomain(), change,
					ParamInfo.Tag.NON_ORD);
			grpTnParam.addChangeParam("GroupName", grpTNEntityPrev.getGroupName(), groupTnEntity.getGroupName(), change,
					ParamInfo.Tag.NAME);
			grpTnParam.addChangeParam("TnCLIDFirstName", grpTNEntityPrev.getTnCLIDFirstName(),
					groupTnEntity.getTnCLIDFirstName(), change);
			grpTnParam.addChangeParam("TnCLIDLastName", grpTNEntityPrev.getTnCLIDLastName(),
					groupTnEntity.getTnCLIDLastName(), change);
			grpTnParam.addChangeParam("SequenceNo", grpTNEntityPrev.getSequenceNo(), groupTnEntity.getSequenceNo(), change,
					ParamInfo.Tag.NON_ORD);
			grpTnParam.addChangeParam("LinePort", grpTNEntityPrev.getLinePort(), groupTnEntity.getLinePort(), change,
					ParamInfo.Tag.NON_ORD);
			grpTnParam.addChangeParam("VMBoxNumber", grpTNEntityPrev.getVmBoxNumber(), groupTnEntity.getVmBoxNumber(), change,
					ParamInfo.Tag.NON_ORD);
			LOG.info("VmPin - [" + grpTNEntityPrev.getVmPin() + "]");
			grpTnParam.addChangeParam("VMPin", grpTNEntityPrev.getVmPin(), groupTnEntity.getVmPin(), change,
					ParamInfo.Tag.NON_ORD);
			grpTnParam.addChangeParam("GroupId", grpTNEntityPrev.getGroupId(), groupTnEntity.getGroupId(), change);
			if (!"0".equals(grpTNEntityPrev.getVmType())) {
				grpTnParam.addChangeParam("VMType", grpTNEntityPrev.getVmType(), groupTnEntity.getVmType(), change,
						ParamInfo.Tag.NON_ORD);
			}
			ArrayList<String> nonPkgFeatures = grpTNEntityPrev.getNonPkgFeatures();
			if (!CollectionUtils.isEmpty(nonPkgFeatures)) {
				if (StringUtils.equalsIgnoreCase(booleanToStr(change), "I")) {
					grpTnParam.addChildParam(new ParamInfo("FEAT_ASSIGN", null, null));
				}
				grpTnParam.addChildParam(OrderUtility.getNonPkgParamInfo(nonPkgFeatures, booleanToStr(change)));
			}
			
			ArrayList<String> userFeatures = grpTNEntityPrev.getUserFeatures();
			if (!CollectionUtils.isEmpty(userFeatures)) {
				if (StringUtils.equalsIgnoreCase(booleanToStr(change), "I")) {
					grpTnParam.addChildParam(new ParamInfo("USER_ASSIGN", null, null));
				}
				grpTnParam.addChildParam(OrderUtility.getUserFeatInfo(userFeatures, booleanToStr(change)));
	
			}
			ArrayList<String> disableFeatureList = grpTNEntityPrev.getDisableFeatureList();
			if (!CollectionUtils.isEmpty(disableFeatureList)) {
				ParamInfo dfParam = new ParamInfo("DisableFeatureList", (String) null, booleanToStr(change));
	
				for (String feature : disableFeatureList) {
					LOG.info("GroupTNUtil Adding DisableFeature:" + feature);
					dfParam.addChildParam(new ParamInfo("Feature", feature, booleanToStr(change)));
				}
				grpTnParam.addChildParam(dfParam);
			}
			grpTnParam.addChildParam(OrderUtility.getAttribParamInfo(grpTNEntityPrev.getAttribMap(), booleanToStr(change)));
			if (grpTNEntityPrev.getAction() != null) {
				LOG.info("GroupTNOrder.Action: {}", grpTNEntityPrev.getAction().name());
				if (grpTNEntityPrev.getAction().equals(EsapEnum.OrderAction.ADD)) {
					grpTnParam.addChildParam(new ParamInfo("Action", "I", "n"));
				} else if (grpTNEntityPrev.getAction().equals(EsapEnum.OrderAction.MODIFY)) {
					grpTnParam.addChildParam(new ParamInfo("Action", "C", "n"));
				}
			}
			if (BooleanUtils.isTrue(grpTNEntityPrev.getHotCutIndicator()))
				grpTnParam.addNotNullValChild("HotCutIndicator", "Y", booleanToStr(change));
			if (BooleanUtils.isTrue(grpTNEntityPrev.getCDDDIndicator()))
				grpTnParam.addNotNullValChild("CDDDIndicator", "Y", booleanToStr(change));
			
			
		grpTnParam.addChangeParam("TimeZone", groupTnEntity.getTimeZoneId(), groupTnEntity.getTimeZoneId(), change);
		grpTnParam.addChangeParam("DaylightSavingInd", groupTnEntity.getDayLightSavingInd(),
				groupTnEntity.getDayLightSavingInd(), change);

			grpTnParam.addChangeParam("DeviceName", grpTNEntityPrev.getDeviceName(),
					groupTnEntity.getDeviceName(), change);
			
			grpTnParam.setName("TrunkTN"); // Mark them as TrunkTN
		

		LOG.info("Exited GroupTNUtil.getParamInfo");
		return grpTnParam;
	}
}