package com.vz.esap.translation.order.transformer;

import java.util.List;
import java.util.Map;

import com.vz.esap.translation.entity.TrunkGroupEntity;
import com.vz.esap.translation.exception.ApplicationInterfaceException;
import com.vz.esap.translation.exception.GenericException;
import com.vz.esap.translation.exception.TranslatorException;
import com.vz.esap.translation.order.model.request.VOIPOrderRequest;

/**
 * @author kalagsu
 *
 */
public interface TrunkGroupTransformer {

	/**
	 * @param orderId
	 * @param parentId
	 * @param action
	 * @param delta
	 * @return
	 * @throws TranslatorException
	 */
	TrunkGroupEntity transformOrderDetailsToTrunkGroup(long orderId, long parentId, String action, boolean delta, List<String> paramActionExclusionList)
			throws TranslatorException;

	/**
	 * 
	 * @param voipOrderRequest
	 * @param trunkEntity
	 * @return
	 * @throws IllegalAccessException
	 * @throws ApplicationInterfaceException
	 * @throws TranslatorException
	 * @throws GenericException
	 */
	TrunkGroupEntity enrichTrunkEntityWithInventory(VOIPOrderRequest voipOrderRequest, TrunkGroupEntity trunkEntity)
			throws IllegalAccessException, ApplicationInterfaceException, TranslatorException, GenericException;

	/**
	 * 
	 * @param resultantRow
	 * @return
	 */
	TrunkGroupEntity trunkGroupInventoryTotrunkGroupEntityTransformer(Map<String, String> resultantRow);

}
