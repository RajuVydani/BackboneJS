package com.vz.esap.translation.order.service.location;

import java.util.Arrays;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.vz.esap.translation.dao.model.TblEnvOrder;
import com.vz.esap.translation.dao.model.TblOrder;
import com.vz.esap.translation.dao.model.TblOrderDetails;
import com.vz.esap.translation.dao.model.TblOrderService;
import com.vz.esap.translation.entity.LocationEntity;
import com.vz.esap.translation.entity.OrderManagerContactInfoEntity;
import com.vz.esap.translation.enums.EsapEnum;
import com.vz.esap.translation.enums.EsapEnum.FlowPath;
import com.vz.esap.translation.enums.EsapEnum.OrderEntity;
import com.vz.esap.translation.exception.GenericException;
import com.vz.esap.translation.exception.TranslatorException;
import com.vz.esap.translation.exception.TranslatorException.ErrorCode;
import com.vz.esap.translation.order.dao.VOIPOrderDao;
import com.vz.esap.translation.order.model.Order;
import com.vz.esap.translation.order.model.OrderHeader;
import com.vz.esap.translation.order.model.OrderHeader.SuppType;
import com.vz.esap.translation.order.model.request.ParamInfo;
import com.vz.esap.translation.order.model.request.VOIPOrderRequest;
import com.vz.esap.translation.order.model.response.VoipOrderResponse;
import com.vz.esap.translation.order.parser.OrderParser;
import com.vz.esap.translation.order.service.CancelOrderService;
import com.vz.esap.translation.order.service.OrderServiceBase;
import com.vz.esap.translation.order.service.VOIPResponseGenerator;
import com.vz.esap.translation.order.service.helper.OrderServiceHelperImpl;
import com.vz.esap.translation.order.transformer.EnterpriseTblOrderDataTransformer;
import com.vz.esap.translation.order.transformer.EnterpriseTblOrderServiceDataTransformer;
import com.vz.esap.translation.order.transformer.LocationTblOrderDetailsDataTransformer;
import com.vz.esap.translation.order.transformer.LocationTransformer;
import com.vz.esap.translation.order.transformer.OrderManagerContactInfoTransformer;

import EsapEnumPkg.WorkOrderEnum;

/**
 * @author chattni
 *
 */
@Service
public class LocationOrderServiceImpl extends OrderServiceBase implements LocationOrderService {

	private static final Logger LOG = LoggerFactory.getLogger(LocationOrderServiceImpl.class);

	@Autowired
	private LocationTblOrderDetailsDataTransformer locationTblOrderDetailsData;

	@Autowired
	private LocationTransformer locationTransformer;

	@Autowired
	private VOIPOrderDao voipOrderDao;

	@Autowired
	private EnterpriseTblOrderServiceDataTransformer enterpriseTblOrderServiceData;

	@Autowired
	private EnterpriseTblOrderDataTransformer enterpriseTblOrderData;

	@Autowired
	private OrderManagerContactInfoTransformer orderManagerContactInfoTransformer;

	@Autowired
	private VOIPResponseGenerator voipResponseGenerator;

	@Autowired
	private OrderServiceHelperImpl orderServiceHelperImpl;

	@Autowired
	private OrderParser orderParserImpl;
	
	@Autowired
	private CancelOrderService cancelOrderServiceImpl;

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.vz.esap.translation.order.service.location.LocationOrderService#
	 * processReleaseOrder(com.vz.esap.translation.dao.model.TblOrderDetails,
	 * com.vz.esap.translation.dao.model.TblOrder,
	 * com.vz.esap.translation.dao.model.TblEnvOrder,
	 * com.vz.esap.translation.order.model.request.VOIPOrderRequest, java.util.List)
	 */
	@Override
	public VoipOrderResponse processReleaseOrder(TblOrderDetails tblOrderDetails, TblOrder tblOrderBeanValidation,
			TblEnvOrder tblEnvOrder, VOIPOrderRequest voipOrderRequest, List<TblOrderDetails> tblOrderDetailsList)
			throws TranslatorException, GenericException {
		LOG.info("Entered - processReleaseOrder");

		VoipOrderResponse voipOrderResponse = null;
		LocationEntity locationEntity = null;
		OrderHeader orderHeader = null;
		List<TblEnvOrder> tblEnvOrderListPrev = null;
		List<TblOrder> tblOrderListPrev = null;
		List<TblOrderDetails> tblOrderDetailsListPrev = null;
		LocationEntity locationEntityPrev = null;

		try {

			if ("C".equalsIgnoreCase(voipOrderRequest.getOrderHeader().getOrderType())) {
				LOG.info("Going for Changed Location Entity for r,n");
				locationEntity = locationTransformer.transformOrderDetailsToLocation(
						tblOrderBeanValidation.getOrderId(), tblOrderDetails.getOrderDetailId(), null, false,
						Arrays.asList("o"));

				LOG.info("Going for Prev Location Entity for r,o");
				locationEntityPrev = locationTransformer.transformOrderDetailsToLocation(
						tblOrderBeanValidation.getOrderId(), tblOrderDetails.getOrderDetailId(), null, false,
						Arrays.asList("n"));
				
				LOG.debug("locationEntity : {} ", locationEntity);
				LOG.debug("locationEntityPrev : {} ", locationEntityPrev);

			} else {
				locationEntity = locationTransformer.transformOrderDetailsToLocation(
						tblOrderBeanValidation.getOrderId(), tblOrderDetails.getOrderDetailId(), "n", false, null);
			}

			if (locationEntity == null) {
				throw new TranslatorException(ErrorCode.LOCATION_TRANSFORMATION_FAILURE,
						"Failed to get Trunk transformation");
			}

			LOG.debug("LocationEntity : {} ", locationEntity);

			// SUPP changes...
			int orderVersion = Integer.parseInt(voipOrderRequest.getOrderHeader().getWorkOrderVersion());
			LOG.info("Order version:: {}", orderVersion);

			if (orderVersion > 0) {

				VOIPOrderRequest voipOrderRequestPrev = orderParserImpl.getCorrectPrevPassVoipOrderRequest(voipOrderRequest);
				LOG.info("SUPP Order version:: {}", voipOrderRequestPrev.getOrderHeader().getWorkOrderVersion());
				//voipOrderRequestPrev.getOrderHeader().setWorkOrderVersion(Integer.toString(orderVersion - 1));

				tblEnvOrderListPrev = orderServiceHelperImpl.getMatchingPrevPassEnvOrder(voipOrderRequestPrev, 0,
						WorkOrderEnum.OrderClassify.RELEASE); 

				LOG.info("env table records size::{}", tblEnvOrderListPrev.size());
				LOG.info("ENV ORDER ID::{}", tblEnvOrderListPrev.get(0).getEnvOrderId());
				tblOrderListPrev = orderServiceHelperImpl.getMatchingPrevPassOrder(tblEnvOrderListPrev.get(0),
						OrderEntity.LOCATION); // returns one release pass tbl order records basing on upstream task Id.
			//	LOG.info("TBL_ORDER records size::{}", tblOrderListPrev.size());
			//	LOG.info("TBL ORDER ID::{}", tblOrderListPrev.get(0).getOrderId());

				for (TblOrder tblOrderPrev : tblOrderListPrev) {
					if (tblOrderPrev.getAccountNumber().equalsIgnoreCase(locationEntity.getLocationId())) {
						tblOrderDetailsListPrev = orderServiceHelperImpl.getMatchingOrderDetails(tblOrderPrev);
						LOG.info("TBL_ORDER_DETAILS records size::{}", tblOrderDetailsListPrev.size());
					}
				}

				if (tblOrderDetailsListPrev != null && !tblOrderDetailsListPrev.isEmpty()
						&& "Location".equalsIgnoreCase(tblOrderDetailsListPrev.get(0).getParamName())) {
					
					LOG.info("Previous Table Order Id::{}", tblOrderListPrev.get(0).getOrderId());
					LOG.info("Previous Table Order Details Id::{}", tblOrderDetailsListPrev.get(0).getOrderDetailId());
					
					locationEntityPrev = locationTransformer.transformOrderDetailsToLocation(
							tblOrderListPrev.get(0).getOrderId(), tblOrderDetailsListPrev.get(0).getOrderDetailId(),
							"n", false, null);
					locationEntityPrev.setEnvOrderId(tblEnvOrderListPrev.get(0).getEnvOrderId());
					locationEntityPrev.setInternalOrderId(tblOrderDetailsListPrev.get(0).getOrderId());
					
					LOG.info("locationEntityPrev::{} ::{}", locationEntityPrev.getLocationId(),
							locationEntityPrev.getPhysicalLocationName());
					LOG.info("locationEntity::{}::{}", locationEntity.getLocationId(),
							locationEntity.getPhysicalLocationName());
					
				}

				if (voipOrderRequest.getOrderHeader().getSuppType() != null
						&& voipOrderRequest.getOrderHeader().getSuppType().equals(SuppType.CANCEL.toString()))
					voipOrderRequest.getOrderHeader().setSuppType(SuppType.CANCEL.toString());
				else
					voipOrderRequest.getOrderHeader().setSuppType(SuppType.SUPP.toString());
			}

			orderHeader = createdOrderHeaderForLocationOrder(voipOrderRequest, locationEntity);
			
			LOG.info("Previous Location order status ===>>> {} ", !CollectionUtils.isEmpty(tblOrderListPrev) ? tblOrderListPrev.get(0).getOrderStatus() : "Not supp");
			createReleaseOrders(voipOrderRequest, tblOrderListPrev, orderHeader, locationEntity, locationEntityPrev, tblOrderDetailsList,
					tblOrderBeanValidation, WorkOrderEnum.Status.WO_INIT, tblEnvOrder);

			voipOrderResponse = voipResponseGenerator.prepareSuccessOrderResponse(voipOrderRequest);

		} catch (TranslatorException ex) {
			LOG.error("Exception {} ", ex);
			throw new TranslatorException(ex.getErrorCode(), ex.getMessage());
		} catch (Exception e) {
			LOG.error("Exception {} ", e);
			throw new GenericException(GenericException.GENERIC_EXCEPTION,
					"Exception in the provide input arguments-" + e);
		}

		LOG.info("Exit - processReleaseOrder");
		return voipOrderResponse;

	}

	/**
	 * @param orderHeader
	 * @param locationEntity
	 * @param locationEntityPrev
	 * @param tblOrderDetailsList
	 * @param tblOrderBeanValidation
	 * @param status
	 * @param tblEnvOrderObject
	 * @return isCreated
	 * @throws TranslatorException
	 * @throws GenericException
	 */
	boolean createReleaseOrders(VOIPOrderRequest voipOrderRequest, List<TblOrder> tblOrderListPrev, OrderHeader orderHeader, LocationEntity locationEntity,
			LocationEntity locationEntityPrev, List<TblOrderDetails> tblOrderDetailsList,
			TblOrder tblOrderBeanValidation, int status, TblEnvOrder tblEnvOrderObject)
			throws TranslatorException, GenericException {
		LOG.info("Entered - createReleaseOrders For Order Action = {} ", orderHeader.getEntityAction());
		boolean isCreated = true;
		Order order = null;
		Order orderPrevPass = null;
		OrderManagerContactInfoEntity cnctInfo = null;
		TblOrder tblOrderObject = null;
		List<TblOrderService> tblOrderServiceList = null;
		ParamInfo headerParamInfo = null;
		ParamInfo entityParamInfo = null;

		try {
			order = new Order();
			orderHeader.setOrderStatus(status);
			order.setOrderHeader(orderHeader);

			if (locationEntity == null) {
				locationEntity = new LocationEntity();
			}

			// :create order
			LOG.info("createOrders start creating customer entity orders");
			cnctInfo = orderManagerContactInfoTransformer
					.transformValEnvOrderToOrdMgrContactInfo(tblEnvOrderObject.getEnvOrderId(), null);

			if (cnctInfo != null)
				orderHeader.setOrdMgrContactInfo(cnctInfo);
			if (null != tblEnvOrderObject.getEnvOrderId())
				orderHeader.setEnvOrderId(tblEnvOrderObject.getEnvOrderId());
			if (null != tblEnvOrderObject.getProjectId())
				orderHeader.setProjectId(tblEnvOrderObject.getProjectId());
			orderHeader.setEnvOrderId(tblEnvOrderObject.getEnvOrderId());
			orderHeader.setProjectId(tblEnvOrderObject.getProjectId());

			order.setOrderHeader(orderHeader);
			order.setLocationEntity(locationEntity);	
			
			

			if ("I".equalsIgnoreCase(orderHeader.getEntityAction())) {

				if (locationEntityPrev != null) {
					LOG.info("locationEntityPrev is not null");

					headerParamInfo = locationTblOrderDetailsData.prepareTblOrderDetailsHeaderParamData(order,
							locationEntityPrev, true);

					entityParamInfo = locationTblOrderDetailsData.prepareTblOrderDetailsEntityParamDataForLocation(
							locationEntityPrev, locationEntity, true, null);

					if (entityParamInfo != null && entityParamInfo.getAction() != null
							&& "C".equals(entityParamInfo.getAction())) {
						LOG.info("entityParamInfo.getAction(): {}", entityParamInfo.getAction());
						
						orderHeader.setEntityAction("C");
						
						entityParamInfo.addNotNullValChild("LOC_INV_CHANGE", "Y", "n");												
												
					}else if (entityParamInfo != null && entityParamInfo.getAction() != null
							&& "NC".equals(entityParamInfo.getAction())) {
						LOG.info("entityParamInfo.getAction(): {}", entityParamInfo.getAction());
						orderHeader.setEntityAction("NC");
					}
				} else {
					headerParamInfo = locationTblOrderDetailsData.prepareTblOrderDetailsHeaderParamData(order);
					entityParamInfo = locationTblOrderDetailsData
							.prepareTblOrderDetailsEntityParamDataForLocation(order, null);
					LOG.info("entityParamInfo.getAction(): {}", entityParamInfo.getAction());
				}

			} else if ("C".equalsIgnoreCase(orderHeader.getEntityAction())) {

				if (locationEntityPrev != null) {
					LOG.info("locationEntityPrev is not null");

					headerParamInfo = locationTblOrderDetailsData.prepareTblOrderDetailsHeaderParamData(order,
							locationEntityPrev, true);

					entityParamInfo = locationTblOrderDetailsData.prepareTblOrderDetailsEntityParamDataForLocation(
							locationEntityPrev, locationEntity, true, null);

					if (entityParamInfo != null && entityParamInfo.getAction() != null
							&& "C".equals(entityParamInfo.getAction())) {
						LOG.info("entityParamInfo.getAction() For Location: {}", entityParamInfo.getAction());
						
						orderHeader.setEntityAction("C");
						
						entityParamInfo.addNotNullValChild("LOC_INV_CHANGE", "Y", "n");												
												
					} else if (entityParamInfo != null && entityParamInfo.getAction() != null
							&& "NC".equals(entityParamInfo.getAction())) {
						LOG.info("entityParamInfo.getAction(): {}", entityParamInfo.getAction());
						orderHeader.setEntityAction("NC");
					}
				}				
			}
			
			LOG.info("orderHeader.getEntityAction()-Location : {} ", orderHeader.getEntityAction());
			
			if (null != headerParamInfo && !"NC".equalsIgnoreCase(orderHeader.getEntityAction())) {
				LOG.info("null != headerParamInfo && !\"NC\".equalsIgnoreCase(orderHeader.getEntityAction())");
				
				//ESVRRS-18523 :: START :: Supp other on failed Entity fix.
				int orderVersion = Integer.parseInt(voipOrderRequest.getOrderHeader().getWorkOrderVersion());
				LOG.info("Order version:: {}", orderVersion);
				
				if (orderVersion > 0) {
					LOG.info("Previous Location order status :: {} ", tblOrderListPrev.get(0).getOrderStatus() );
					LOG.info("Location records count - {}", tblOrderListPrev.size());
					if(WorkOrderEnum.Status.WO_FAILED == tblOrderListPrev.get(0).getOrderStatus()) {
						LOG.info("Creating reverse order for location with order id {} ", tblOrderListPrev.get(0).getOrderId());
						// Reverse Order Creation..It may be EntityAction I OR C
						cancelOrderServiceImpl.createReverseOrder(voipOrderRequest, tblOrderListPrev, tblEnvOrderObject);
						LOG.info("Creating reverse order for location with order id {} COMPLETED !!!!", tblOrderListPrev.get(0).getOrderId());
						
						//Creating Forward order...
						LOG.info("Creating Forward Order..... ");
						headerParamInfo = locationTblOrderDetailsData.prepareTblOrderDetailsHeaderParamData(order);
						entityParamInfo = locationTblOrderDetailsData
								.prepareTblOrderDetailsEntityParamDataForLocation(order, null);
						orderHeader.setEntityAction("I");
						LOG.info("Creating Forward Order.....COMPLETED !!! ");
					}	
				}
				//ESVRRS-18523 :: END
				
				headerParamInfo.addChildParam(entityParamInfo);
				
				// :create order
				tblOrderObject = enterpriseTblOrderData.prepareTblOrderDataFromOrder(order, 3L);
				voipOrderDao.createTblOrder(tblOrderObject);

				LOG.info("Tbl_Order Created for Location , Order Id : {}", tblOrderObject.getOrderId());

				// :create order Details
				LOG.info("createOrders start creating location entity order details");

				if (entityParamInfo != null && entityParamInfo.getAction() != null)
					voipOrderDao.populateOrderDetails(tblOrderObject, headerParamInfo.getChildParams(),
							entityParamInfo.getAction(), 0, 0);
				else
					voipOrderDao.populateOrderDetails(tblOrderObject, headerParamInfo.getChildParams(), "n", 0, 0);
				
				// :create service entry for WF
				LOG.info("createOrders start creating service for Location entity");
				orderHeader.setFlowPath(FlowPath.valueOf(tblOrderObject.getFlowPath()));
				orderHeader.setTblOrderId(tblOrderObject.getOrderId());
				orderHeader.setEntityType(EsapEnum.OrderEntity.LOCATION.getIndex());
				orderHeader.setProvisionCategory(locationEntity.getProvisionCategory());
				
				order.setOrderHeader(orderHeader);

				// refactor prepareTblOrderServiceData to pass orderPrevPass
				orderPrevPass = new Order();
				orderPrevPass.setOrderHeader(orderHeader);// TODO add previous pass order header
				orderPrevPass.setLocationEntity(locationEntityPrev);
				tblOrderServiceList = enterpriseTblOrderServiceData.prepareTblOrderServiceData(order, orderPrevPass,
						null);

				LOG.info("Retail Order Service Count : {}", tblOrderServiceList.size());

				for (TblOrderService tblOrderService : tblOrderServiceList) {
					voipOrderDao.createTblOrderService(tblOrderService);
				}

				voipOrderDao.updateTblOrderStatus(tblOrderObject.getOrderId(), WorkOrderEnum.Status.WO_INIT);
				
			}else if (locationEntityPrev != null && "NC".equalsIgnoreCase(orderHeader.getEntityAction())) {
				LOG.info("locationEntityPrev != null && \"NC\".equalsIgnoreCase(orderHeader.getEntityAction())");
				LOG.info("Order Version ==>> {}", orderHeader.getOrderVersion());
				
				int orderVersion = Integer.parseInt(orderHeader.getOrderVersion());
				
				if(orderVersion > 0) {
					orderServiceHelperImpl.handleSuppOrderWithNoChange(tblEnvOrderObject.getEnvOrderId(),
							locationEntityPrev.getInternalOrderId(), tblEnvOrderObject);
					
				} else {
					
					LOG.info("This is MAC Location Scenario of Do Nothing");
				}
			}			
		} catch (TranslatorException ex) {
			LOG.error("Exception {} {} ", ex.getMessage(), ex);
			throw new TranslatorException(ex.getErrorCode(), ex.getMessage());
		} catch (Exception e) {
			LOG.error("Exception {} {} ", e.getMessage(), e);
			throw new GenericException(GenericException.GENERIC_EXCEPTION, "Exception in the provide input arguments");
		}
		LOG.info("Exit - createReleaseOrders");
		return isCreated;
	}

}
