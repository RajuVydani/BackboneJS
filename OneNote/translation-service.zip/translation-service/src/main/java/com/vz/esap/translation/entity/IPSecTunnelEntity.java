package com.vz.esap.translation.entity;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class IPSecTunnelEntity {

	private static final Logger LOG = LoggerFactory.getLogger(IPSecTunnelEntity.class);

	private Long ipsecTunnelId;
	private String ikeIP;
	private String sigHostSubnetIp;
	private String sigHostMask;
	private String egwType;
	private String protectedResource;
	private String preshareKey;

	public String getIKEIP() {
		return ikeIP;
	}

	public void setIKEIP(String iKEIP) {
		this.ikeIP = iKEIP;
	}

	public String getSigHostSubnet() {
		return sigHostSubnetIp;
	}

	public void setSigHostSubnet(String sigHostSubnet) {
		this.sigHostSubnetIp = sigHostSubnet;
	}

	public String getSigHostMask() {
		return sigHostMask;
	}

	public void setSigHostMask(String sigHostMask) {
		this.sigHostMask = sigHostMask;
	}

	public String getEWGType() {
		return egwType;
	}

	public void setEWGType(String eWGType) {
		egwType = eWGType;
	}

	public Long getIpsecTunnelId() {
		return ipsecTunnelId;
	}

	public void setIpsecTunnelId(Long ipsecTunnelId) {
		this.ipsecTunnelId = ipsecTunnelId;
	}

	public String getProtectedResource() {
		return protectedResource;
	}

	public void setProtectedResource(String protectedResource) {
		this.protectedResource = protectedResource;
	}

	public String getPreshareKey() {
		return preshareKey;
	}

	public void setPreshareKey(String preshareKey) {
		this.preshareKey = preshareKey;
	}

	public ParamInfo getParamInfo(String action) {

		ParamInfo ipsecParam = new ParamInfo("IpSecTunnel", null, action);

		ipsecParam.addNotNullValChild("IpSecTunnelId", getIpsecTunnelId(), action);
		ipsecParam.addNotNullValChild("IKEIP", getIKEIP(), action);
		ipsecParam.addNotNullValChild("EWGType", getEWGType(), action);
		ipsecParam.addNotNullValChild("SigHostMask", getSigHostMask(), action);
		ipsecParam.addNotNullValChild("SigHostSubnet", getSigHostSubnet(), action);

		return ipsecParam;
	}

	public ParamInfo getChangeParam(IPSecTunnelEntity oldIpSecTunnel, IPSecTunnelEntity newIpSecTunnel,
			boolean forSupp) {

		LOG.info("Enter IpsecUtil.getChangeParam Input:: oldIpSecTunnel:: {} \n newIpSecTunnel:: {}", oldIpSecTunnel,
				newIpSecTunnel);

		if (null == oldIpSecTunnel && null == newIpSecTunnel)
			return null;
		if (null == oldIpSecTunnel) {
			return newIpSecTunnel.getParamInfo("I");
		} else if (null == newIpSecTunnel) {
			return oldIpSecTunnel.getParamInfo(forSupp ? "O" : null);
		}

		ParamInfo ipsecParam = new ParamInfo("IpSecTunnel", null, null);
		ipsecParam.addChangeParam("IpSecTunnelId", oldIpSecTunnel.getIpsecTunnelId(), newIpSecTunnel.getIpsecTunnelId(),
				forSupp);
		ipsecParam.addChangeParam("IKEIP", oldIpSecTunnel.getIKEIP(), newIpSecTunnel.getIKEIP(), forSupp);
		ipsecParam.addChangeParam("EWGType", oldIpSecTunnel.getEWGType(), newIpSecTunnel.getEWGType(), forSupp);
		ipsecParam.addChangeParam("SigHostMask", oldIpSecTunnel.getSigHostMask(), newIpSecTunnel.getSigHostMask(),
				forSupp);
		ipsecParam.addChangeParam("SigHostSubnet", oldIpSecTunnel.getSigHostSubnet(), newIpSecTunnel.getSigHostSubnet(),
				forSupp);
		return ipsecParam;
	}

}
