package com.vz.esap.translation.util;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.owasp.esapi.ESAPI;
import org.owasp.esapi.codecs.Codec;
import org.owasp.esapi.codecs.OracleCodec;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.vz.esap.translation.connector.model.DBServiceResponse;
import com.vz.esap.translation.connector.model.TblRow;
import com.vz.esap.translation.connector.service.InventoryDomainDataServiceImpl;
import com.vz.esap.translation.constant.TranslationConstant;
import com.vz.esap.translation.dao.model.TblEnvOrder;
import com.vz.esap.translation.dao.repository.CustomTblEnvOrderMapper;
import com.vz.esap.translation.enums.ESAPDBQueryEnum;
import com.vz.esap.translation.enums.EsapEnum;
import com.vz.esap.translation.enums.EsapEnum.LocationType;
import com.vz.esap.translation.enums.EsapEnum.SubscriberTnType;
import com.vz.esap.translation.enums.EsapEnum.VoipServiceType;
import com.vz.esap.translation.exception.ApplicationInterfaceException;
import com.vz.esap.translation.exception.GenericException;
import com.vz.esap.translation.exception.TranslatorException;
import com.vz.esap.translation.exception.TranslatorException.ErrorCode;
import com.vz.esap.translation.order.model.request.Communication;
import com.vz.esap.translation.order.model.request.VOIPOrderRequest;
import com.vz.esap.translation.order.parser.OrderParser;
import com.vz.esap.translation.order.service.helper.OrderServiceHelper;

/**
 * @author chattni Change FOr MAC
 *
 */
@Component
public class InventoryUtil {

	private static final Logger LOG = LoggerFactory.getLogger(InventoryUtil.class);

	@Autowired
	private InventoryDomainDataServiceImpl inventoryDomainDataServiceImpl;

	@Autowired
	private OrderServiceHelper orderServiceHelperImpl;

	@Autowired
	private CustomTblEnvOrderMapper customTblEnvOrderMapper;

	@Autowired
	private OrderParser orderParserImpl;

	static final Codec ORACLE_CODEC = new OracleCodec();

	/**
	 * @return
	 */
	public static Set<String> getSelectColumnSetForLocation() {

		Set<String> selectColumnSet = new HashSet<>();

		selectColumnSet.add("LOCATION_ID");
		selectColumnSet.add("ENTERPRISE_ID");
		selectColumnSet.add("DIAL_PLAN_ID");
		selectColumnSet.add("ORDER_SOURCE");
		selectColumnSet.add("LOCATION_NAME");
		selectColumnSet.add("LOC_ADDRESS");
		selectColumnSet.add("LOC_CITY");
		selectColumnSet.add("LOC_STATE");
		selectColumnSet.add("LOC_ZIP");
		selectColumnSet.add("LOC_COUNTRY");
		selectColumnSet.add("NPANXX");
		selectColumnSet.add("TIME_ZONE");
		selectColumnSet.add("USE_DAYLIGHT_SAVINGS");
		selectColumnSet.add("DAYLIGHT_SAVINGS_REGION");
		selectColumnSet.add("WEB_LANG");
		selectColumnSet.add("IXPLUS_ID");
		selectColumnSet.add("IXPLUS_ENV_ID");
		selectColumnSet.add("BILL_TYPE");
		selectColumnSet.add("BILL_ACCT_NUM");
		selectColumnSet.add("NETCOM_SERVICE_ID");
		selectColumnSet.add("CV2_SERVICE");
		selectColumnSet.add("MANAGED_SERVICE");
		selectColumnSet.add("SERVICE_TYPE_OFFERING");
		selectColumnSet.add("VOIP_SERVICE_TYPE");
		selectColumnSet.add("HYBRID_SERVICE_TYPE");
		selectColumnSet.add("ACCESS_TYPE");
		selectColumnSet.add("PUB_IP");
		selectColumnSet.add("CIRCUIT_ID");
		selectColumnSet.add("UUNET_SITE_ID");
		selectColumnSet.add("SIP_DOMAIN");
		selectColumnSet.add("SBC_IND");
		selectColumnSet.add("SBC_ID");
		selectColumnSet.add("SIP_ENABLED");
		selectColumnSet.add("PUBLIC_GTWY_DPID");
		selectColumnSet.add("DEFAULT_GTWY_DPID");
		selectColumnSet.add("TRUNK_TYPE");
		selectColumnSet.add("VOIP_CLUB");
		selectColumnSet.add("SERVICE_LEVEL");
		selectColumnSet.add("LOC_MARKET");
		selectColumnSet.add("MAX_EXT_LENGTH");
		selectColumnSet.add("EXT_LENGTH");
		selectColumnSet.add("PRIVATE_NUM_LENGTH");
		selectColumnSet.add("LINE_PORT_LENGTH");
		selectColumnSet.add("ABBR_DIALING_CODE");
		selectColumnSet.add("ENABLE_CALL_PARK");
		selectColumnSet.add("ENABLE_ACCOUNT_CODE");
		selectColumnSet.add("ENABLE_AUTH_CODE");
		selectColumnSet.add("LOCAL_DIR_ASSISTANCE");
		selectColumnSet.add("NAT_DIR_ASSISTANCE");
		selectColumnSet.add("CONCCALL_STAT");
		selectColumnSet.add("MAX_CONCURRENT_CALLS");
		selectColumnSet.add("MAX_CONCURRENT_OFFNET");
		selectColumnSet.add("MAX_INBOUND");
		selectColumnSet.add("MAX_SLG");
		selectColumnSet.add("MAX_NG");
		selectColumnSet.add("MAX_SUBSCRIBERS");
		selectColumnSet.add("MAX_PUBLIC_TN");
		selectColumnSet.add("BLOCK_ALL_CALLS");
		selectColumnSet.add("RPID_PRIV");
		selectColumnSet.add("OVERRIDE_CID_NAME");
		selectColumnSet.add("OVERRIDE_SUB_PRIVATE");
		selectColumnSet.add("OVERRIDE_CID_NUM");
		selectColumnSet.add("RPID_POOL_ID");
		selectColumnSet.add("RPID");
		selectColumnSet.add("BTN_POOL_ID");
		selectColumnSet.add("SWITCH_CLLI");
		selectColumnSet.add("TRUNK");
		selectColumnSet.add("ACT_TEAM_NAME");
		selectColumnSet.add("ACT_TEAM_PHONE");
		selectColumnSet.add("ACT_TEAM_EMAIL");
		selectColumnSet.add("CONTACT_NAME");
		selectColumnSet.add("CONTACT_PHONE");
		selectColumnSet.add("CONTACT_EMAIL");
		selectColumnSet.add("HICR_SERVICE");
		selectColumnSet.add("VM_TYPE");
		selectColumnSet.add("VM_LANG");
		selectColumnSet.add("VM_CPE_IP_ADDRESS");
		selectColumnSet.add("MAX_VM_BOX");
		selectColumnSet.add("CALLING_PLAN_ID");
		selectColumnSet.add("ACTIVE_IND");
		selectColumnSet.add("ACTIVE_DATE");
		selectColumnSet.add("TERM_DATE");
		selectColumnSet.add("CREATED_BY");
		selectColumnSet.add("CREATION_DATE");
		selectColumnSet.add("MODIFIED_BY");
		selectColumnSet.add("LAST_MODIFIED_DATE");
		selectColumnSet.add("ENV_ORDER_ID");
		selectColumnSet.add("EMER_POOL_ID");
		selectColumnSet.add("EMER_LOCATION_CODE");
		selectColumnSet.add("LOCATION_TYPE");
		selectColumnSet.add("FMCG_LOCATION_TYPE");
		selectColumnSet.add("HUB_LOCATION_ID");
		selectColumnSet.add("HUB_GATEWAY_DEVICE_ID");
		selectColumnSet.add("LOCATION_MASK");
		selectColumnSet.add("A_NUM_MASK");
		selectColumnSet.add("B_NUM_MASK");
		selectColumnSet.add("VPN_NAME");
		selectColumnSet.add("TBL_VPN_ID_MAPPING_ID");
		selectColumnSet.add("SBC_PROV_METHOD");
		selectColumnSet.add("PRODUCTION_INDICATOR");
		selectColumnSet.add("QOS_IND");
		selectColumnSet.add("RIV_LOCATION");
		selectColumnSet.add("NOTES");
		selectColumnSet.add("SBC_MIG_IND");
		selectColumnSet.add("AFTER_HOURS_INSTALL_FLAG");
		selectColumnSet.add("HIGH_VOLUME_INSTALL_FLAG");
		selectColumnSet.add("EXPEDITE");
		selectColumnSet.add("LOC_CCL_IND");
		selectColumnSet.add("BILLING_ACTIVATED");
		selectColumnSet.add("CALLING_NAME_IND");
		selectColumnSet.add("ENHANCED_ANI_IND");
		selectColumnSet.add("STN_POOL_ID");
		selectColumnSet.add("TW_FQDN");
		selectColumnSet.add("TW_SBC_ID");
		selectColumnSet.add("IASA_ORDER_ID");
		selectColumnSet.add("LOC_TERRITORY");
		selectColumnSet.add("LOC_REGION");
		selectColumnSet.add("BILLING_SYSTEM");
		selectColumnSet.add("CONFIG_ALLOWED");
		selectColumnSet.add("PRODUCT_IDENTIFIER");
		selectColumnSet.add("E911_SERVICE");
		selectColumnSet.add("ALTERNET_CALLER_ID");
		selectColumnSet.add("VARRS_FLAG");
		selectColumnSet.add("ISR_DESIGN_ID");
		selectColumnSet.add("LOC_TRUNK_CCL_SUM");
		selectColumnSet.add("SUB_AGENCY_HIER_CODE");
		selectColumnSet.add("PHYSICAL_LOCATION_ID");
		selectColumnSet.add("PHYSICAL_LOCATION_NAME");
		selectColumnSet.add("DIALING_COUNTRY_CODE");
		selectColumnSet.add("RESTRICTED_ACCESS");
		selectColumnSet.add("LOR_ID");
		selectColumnSet.add("HYBRID_ASSIGNED");
		selectColumnSet.add("CALL_FWD_PLAN_NAME");
		selectColumnSet.add("ENTERPRISE_TRUNK_ID");
		selectColumnSet.add("PQ_INSTANCE_ID");
		selectColumnSet.add("PENDING_RPID");
		selectColumnSet.add("CNAM_UPDATE_STATUS");
		selectColumnSet.add("CNAM_UPDATE_DATE");
		selectColumnSet.add("E2EI_MIG_FLAG");
		selectColumnSet.add("TSO_MIG_LOCK");
		selectColumnSet.add("E2EI_MIG_DATE");
		selectColumnSet.add("UI_PROV_FLAG");
		selectColumnSet.add("CALNET_SUB_CONTRACT_ID");
		selectColumnSet.add("ADDRESS_ID");
		selectColumnSet.add("CLIN");
		selectColumnSet.add("VCE_ENABLED");
		selectColumnSet.add("CCL_TYPE");
		selectColumnSet.add("ESLID");
		selectColumnSet.add("REDUNDENCY");
		selectColumnSet.add("REDUNDENCYID");
		selectColumnSet.add("POLICY_SERVICE_ID");
		selectColumnSet.add("BILLINGTN");
		selectColumnSet.add("BROADWORKSPORTALNUMBER");
		selectColumnSet.add("GROUPUSERLIMIT");
		selectColumnSet.add("LOC_GROUP_ID");
		selectColumnSet.add("REDUNDANCY_PRIORITY_TYPE");
		selectColumnSet.add("HIPC_RETENTION");
		selectColumnSet.add("XO_MAX_ACTIVE_CALLS");
		selectColumnSet.add("XO_MAX_ACTIVE_INCOMING_CALLS");
		selectColumnSet.add("XO_MAX_ACTIVE_OUTGOING_CALLS");

		return selectColumnSet;
	}

	/**
	 * @param locationId
	 * @param selectColumnSet
	 * @return
	 * @throws GenericException
	 */
	public Map<String, String> getTblLocationFromLocationId(String locationId, Map<String, String> resultantRow,
			Set<String> selectColumnSet) throws GenericException {
		LOG.info("Entered getTblLocationFromLocationId for Location Id= {}", locationId);

		List<String[]> whereClauseList = null;
		DBServiceResponse dbServiceResponse = null;

		try {

			if (resultantRow == null) {
				resultantRow = new HashMap<>();
			}

			if (selectColumnSet == null) {
				selectColumnSet = getSelectColumnSetForLocation();
			}

			whereClauseList = new ArrayList<>();
			whereClauseList.add(new String[] { "LOCATION_ID", locationId });

			dbServiceResponse = inventoryDomainDataServiceImpl.searchInventory("TBL_LOCATION", selectColumnSet,
					whereClauseList);

			resultantRow = getResultantRow(dbServiceResponse, selectColumnSet, resultantRow);

		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new GenericException(GenericException.GENERIC_EXCEPTION,
					"Exception occured in getTblLocationFromLocationId");
		}

		LOG.info("Exit getTblLocationFromLocationId");
		return resultantRow;
	}

	/**
	 * @param dbServiceResponse
	 * @param selectColumnSet
	 * @return
	 */
	Map<String, String> getResultantRow(DBServiceResponse dbServiceResponse, Set<String> selectColumnSet,
			Map<String, String> resultantRow) {

		if (resultantRow == null) {
			resultantRow = new HashMap<>();
		}

		if (dbServiceResponse == null)
			return null;
		else if (dbServiceResponse.getTableRows() == null)
			return null;

		for (TblRow tblRows : dbServiceResponse.getTableRows()) {

			Iterator<String> colItr = selectColumnSet.iterator();
			String colName;

			while (colItr.hasNext()) {

				colName = colItr.next();

				if (tblRows.getTblRow().get(colName) != null && tblRows.getTblRow().get(colName).getValue() != null) {
					LOG.info("+++++Level2+++++Column Name = {} , And Col Value = {}", colName,
							tblRows.getTblRow().get(colName).getValue());
					resultantRow.put(colName, tblRows.getTblRow().get(colName).getValue());
				}
			}
		}

		return resultantRow;
	}

	public Map<String, String> getTblGroupFromGroupId(String primaryId, Map<String, String> resultantRow,
			Set<String> selectColumnSet) throws GenericException {
		LOG.info("Entered getTrunkGroupFromTrunkId");
		List<String[]> whereClauseList = null;
		DBServiceResponse dbServiceResponse = null;

		try {

			if (resultantRow == null) {
				resultantRow = new HashMap<>();
			}

			if (selectColumnSet == null) {
				selectColumnSet = getSelectColumnSetForTrunkGroup();
			}

			// Getting Data from TBL_GROUP
			whereClauseList = new ArrayList<>();
			whereClauseList.add(new String[] { "GROUP_ID", primaryId });

			dbServiceResponse = inventoryDomainDataServiceImpl.searchInventory("TBL_GROUP", selectColumnSet,
					whereClauseList);

			resultantRow = getResultantRow(dbServiceResponse, selectColumnSet, resultantRow);

			// Getting Data from TBL_LOCATION
			selectColumnSet = getSelectColumnSetForLocation();
			whereClauseList = new ArrayList<>();
			whereClauseList.add(new String[] { "LOCATION_ID", resultantRow.get("LOCATION_ID") });

			dbServiceResponse = inventoryDomainDataServiceImpl.searchInventory("TBL_LOCATION", selectColumnSet,
					whereClauseList);

			resultantRow = getResultantRow(dbServiceResponse, selectColumnSet, resultantRow);

		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new GenericException(GenericException.GENERIC_EXCEPTION,
					"Exception occured in getTrunkGroupFromTrunkId");
		}

		LOG.info("Exit getTrunkGroupFromTrunkId");
		return resultantRow;
	}

	public Set<String> getSelectColumnSetForTrunkGroup() {

		Set<String> selectColumnSet = new HashSet<>();

		selectColumnSet.add("GROUP_ID");
		selectColumnSet.add("LOCATION_ID");
		selectColumnSet.add("DEPARTMENT_ID");
		selectColumnSet.add("GROUP_NAME");
		selectColumnSet.add("GROUP_TYPE");
		selectColumnSet.add("PACKAGE_ID");
		selectColumnSet.add("DEVICE_MAP_ID");
		selectColumnSet.add("CID_FIRST_NAME");
		selectColumnSet.add("CID_LAST_NAME");
		selectColumnSet.add("PBX_PILOT_POOL_ID");
		selectColumnSet.add("EXTENSION");
		selectColumnSet.add("PRIVATE_NUMBER");
		selectColumnSet.add("LINE_PORT");
		selectColumnSet.add("PBX_CID_POOL_ID");
		selectColumnSet.add("PBX_MAX_CCL_LIMIT");
		selectColumnSet.add("KEY_TERMINATION_TYPE");
		selectColumnSet.add("KEY_FWD_TN");
		selectColumnSet.add("KEY_VM_MAXSIZE_ID");
		selectColumnSet.add("KEY_VM_BOX_NUM");
		selectColumnSet.add("CREATED_BY");
		selectColumnSet.add("CREATION_DATE");
		selectColumnSet.add("MODIFIED_BY");
		selectColumnSet.add("LAST_MODIFIED_DATE");
		selectColumnSet.add("ACTIVE_IND");
		selectColumnSet.add("PBX_REDIRECT_TN");
		selectColumnSet.add("PBX_REDIRECT_TRUNK_ID");
		selectColumnSet.add("ENV_ORDER_ID");
		selectColumnSet.add("LINE_PORT_LENGTH");
		selectColumnSet.add("INVITATION_TIMER");
		selectColumnSet.add("PQ_INSTANCE_ID");
		selectColumnSet.add("TG_ID");
		selectColumnSet.add("OTG_ID");
		selectColumnSet.add("SIGNALING_DIRECTION");
		// ChangeNila
		/*
		 * selectColumnSet.add("TRUNK_CALL_CAPACITY"); selectColumnSet.add("PILOT_TN");
		 */

		return selectColumnSet;

	}

	public Map<String, String> gettblESIPENTERPRISETRUNKFromEnterpriseTrunkId(String primaryId,
			Map<String, String> resultantRow, Set<String> selectColumnSet) throws GenericException {
		LOG.info("Entered getEnterpriseTrunkFromEnterpriseTrunkId");
		List<String[]> whereClauseList = null;
		DBServiceResponse dbServiceResponse = null;

		try {

			if (resultantRow == null) {
				resultantRow = new HashMap<>();
			}

			if (selectColumnSet == null) {
				selectColumnSet = getSelectColumnSetForEnterpriseTrunk();
			}

			whereClauseList = new ArrayList<>();
			whereClauseList.add(new String[] { "ENTERPRISE_TRUNK_ID", primaryId });

			dbServiceResponse = inventoryDomainDataServiceImpl.searchInventory("TBL_ESIP_ENTERPRISE_TRUNK",
					selectColumnSet, whereClauseList);

			resultantRow = getResultantRow(dbServiceResponse, selectColumnSet, resultantRow);

			LOG.info("resultantRow.get(\"TRUNKGROUPID\") ==>>" + resultantRow.get("TRUNKGROUPID"));

			// Getting Data from TBL_GROUP
			selectColumnSet = getSelectColumnSetForTrunkGroup();
			whereClauseList = new ArrayList<>();
			whereClauseList.add(new String[] { "TG_ID", resultantRow.get("TRUNKGROUPID") });

			dbServiceResponse = inventoryDomainDataServiceImpl.searchInventory("TBL_GROUP", selectColumnSet,
					whereClauseList);

			resultantRow = getResultantRow(dbServiceResponse, selectColumnSet, resultantRow);

			LOG.info("resultantRow.get(\"LOCATION_ID\") ==>>" + resultantRow.get("LOCATION_ID"));

			// Getting Data from TBL_LOCATION
			selectColumnSet = getSelectColumnSetForLocation();
			whereClauseList = new ArrayList<>();
			whereClauseList.add(new String[] { "LOCATION_ID", resultantRow.get("LOCATION_ID") });

			dbServiceResponse = inventoryDomainDataServiceImpl.searchInventory("TBL_LOCATION", selectColumnSet,
					whereClauseList);

			resultantRow = getResultantRow(dbServiceResponse, selectColumnSet, resultantRow);

		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new GenericException(GenericException.GENERIC_EXCEPTION,
					"Exception occured in getEnterpriseTrunkFromEnterpriseTrunkId");
		}

		LOG.info("Exit getEnterpriseTrunkFromEnterpriseTrunkId");
		return resultantRow;

	}

	public Set<String> getSelectColumnSetForEnterpriseTrunk() {
		Set<String> selectColumnSet = new HashSet<>();

		selectColumnSet.add("ENTERPRISE_TRUNK_ID");
		selectColumnSet.add("ENTERPRISE_TRUNK_NAME");
		selectColumnSet.add("CUSTOMER_ID");
		selectColumnSet.add("BWENTERPRISETRUNKID");
		selectColumnSet.add("BWENTERPRISEID");
		selectColumnSet.add("ENTERPRISETRUNKTYPE");
		selectColumnSet.add("MAXREROUTEATTEMPTS");
		selectColumnSet.add("ROUTEEXHAUSTIONACTION");
		selectColumnSet.add("ORDERINGALGORITHM");
		selectColumnSet.add("TRUNKGROUPID");
		selectColumnSet.add("TRUNKGROUPNAME");
		selectColumnSet.add("CREATED_BY");
		selectColumnSet.add("CREATION_DATE");
		selectColumnSet.add("MODIFIED_BY");
		selectColumnSet.add("LAST_MODIFIED_DATE");

		return selectColumnSet;
	}

	public Map<String, String> gettblNbsInfofromClusterId(String primaryId, Map<String, String> resultantRow,
			Set<String> selectColumnSet) throws GenericException {
		LOG.info("Entered getNbsFromNbsClusterId");
		List<String[]> whereClauseList = null;
		DBServiceResponse dbServiceResponse = null;

		try {

			if (resultantRow == null) {
				resultantRow = new HashMap<>();
			}

			if (selectColumnSet == null) {
				selectColumnSet = getSelectColumnSetForNbsEntity();
			}

			whereClauseList = new ArrayList<>();
			whereClauseList.add(new String[] { "NBS_CLUSTER_INFO_ID", primaryId });

			dbServiceResponse = inventoryDomainDataServiceImpl.searchInventory("TBL_NBS_CLUSTER_INFO", selectColumnSet,
					whereClauseList);

			resultantRow = getResultantRow(dbServiceResponse, selectColumnSet, resultantRow);

		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new GenericException(GenericException.GENERIC_EXCEPTION,
					"Exception occured in getNbsFromNbsClusterId");
		}

		LOG.info("Exit getNbsFromNbsClusterId");
		return resultantRow;
	}

	public Set<String> getSelectColumnSetForNbsEntity() {
		Set<String> selectColumnSet = new HashSet<>();

		selectColumnSet.add("NBS_CLUSTER_INFO_ID");
		selectColumnSet.add("NBS_POOL_ID");
		selectColumnSet.add("NBS_TYPE");
		selectColumnSet.add("BS_AS_MAPPING_ID");
		selectColumnSet.add("INTERNAL_PORT");
		selectColumnSet.add("INTERNAL_32_IP");
		selectColumnSet.add("EXTERNAL_PORT");
		selectColumnSet.add("EXTERNAL_28_IP_BLOCK");
		selectColumnSet.add("EXTERNAL_IP_2W");
		selectColumnSet.add("EXTERNAL_IP_IB");
		selectColumnSet.add("WT_INTERNAL_PORT");
		selectColumnSet.add("WT_EXTERNAL_PORT");
		selectColumnSet.add("CPE_EXTERNAL_PORT");
		selectColumnSet.add("CPE_EXTERNAL_IP");
		selectColumnSet.add("NIF_IP_1");
		selectColumnSet.add("NIF_IP_2");
		selectColumnSet.add("NIF_IP_3");
		selectColumnSet.add("NIF_IP_4");
		selectColumnSet.add("VPN_ID");
		selectColumnSet.add("VPN_NAME");
		selectColumnSet.add("LOCATION_ID");
		selectColumnSet.add("GROUP_ID");
		selectColumnSet.add("STATUS");
		selectColumnSet.add("CREATED_BY");
		selectColumnSet.add("CREATION_DATE");
		selectColumnSet.add("MODIFIED_BY");
		selectColumnSet.add("LAST_MODIFIED_DATE");

		return selectColumnSet;
	}

	public Map<String, String> getTblEnterpriseFromEnterpriseId(String primaryId, Map<String, String> resultantRow,
			Set<String> selectColumnSet) throws GenericException {
		LOG.info("Entered getTblEnterpriseFromEnterpriseId");
		List<String[]> whereClauseList = null;
		DBServiceResponse dbServiceResponse = null;

		try {

			if (resultantRow == null) {
				resultantRow = new HashMap<>();
			}

			if (selectColumnSet == null) {
				selectColumnSet = getSelectColumnSetForCustomerEntity();
			}

			whereClauseList = new ArrayList<>();
			whereClauseList.add(new String[] { "ENTERPRISE_ID", primaryId });

			dbServiceResponse = inventoryDomainDataServiceImpl.searchInventory("TBL_ENTERPRISE", selectColumnSet,
					whereClauseList);

			resultantRow = getResultantRow(dbServiceResponse, selectColumnSet, resultantRow);

		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new GenericException(GenericException.GENERIC_EXCEPTION,
					"Exception occured in getTblEnterpriseFromEnterpriseId");
		}

		LOG.info("Exit getTblEnterpriseFromEnterpriseId");
		return resultantRow;
	}

	Set<String> getSelectColumnSetForCustomerEntity() {
		Set<String> selectColumnSet = new HashSet<>();

		selectColumnSet.add("ENTERPRISE_ID");
		selectColumnSet.add("CUST_TYPE");
		selectColumnSet.add("CUST_MARKET");
		selectColumnSet.add("PLATFORM_INDICATOR");
		selectColumnSet.add("VM_PARTITION_ID");
		selectColumnSet.add("PUBIP");
		selectColumnSet.add("ON_NET_INTERCO");
		selectColumnSet.add("SIP_DOMAIN");
		selectColumnSet.add("AS_ID");
		selectColumnSet.add("ENTCCL_IND");
		selectColumnSet.add("IEAN_LENGTH");
		selectColumnSet.add("QOS_IND");
		selectColumnSet.add("VNET_CORP_ID");
		selectColumnSet.add("CONTRACT_IND");
		selectColumnSet.add("AGENCY_HIER_CODE");
		selectColumnSet.add("XREF_CUSTOMER_ID");
		selectColumnSet.add("CALLING_PLAN_ID");
		selectColumnSet.add("AUTH_SERVICES_ID");
		selectColumnSet.add("ACTIVE_IND");
		selectColumnSet.add("CREATED_BY");
		selectColumnSet.add("CREATION_DATE");
		selectColumnSet.add("MODIFIED_BY");
		selectColumnSet.add("LAST_MODIFIED_DATE");
		selectColumnSet.add("BS_BLOCK_IND");
		selectColumnSet.add("ENV_ORDER_ID");
		selectColumnSet.add("SBC_ACTIVATION_SYSTEM");
		selectColumnSet.add("SLA_TYPE");
		selectColumnSet.add("RIV_CUSTOMER");
		selectColumnSet.add("SBC_MIG_IND");
		selectColumnSet.add("IPAC_FLAG");
		selectColumnSet.add("LOR_FLAG");
		selectColumnSet.add("ENT_TRUNK_CCL_SUM");
		selectColumnSet.add("LOAD_SHARING");
		selectColumnSet.add("SO_ENABLED");
		selectColumnSet.add("US_LD_AND_LOCAL_BEST_POOL");
		selectColumnSet.add("US_LD_ONLY_BEST_POOL");
		selectColumnSet.add("EMEA_APAC_BEST_POOL");
		selectColumnSet.add("LOR_ID");
		selectColumnSet.add("ADDRESS");
		selectColumnSet.add("CITY");
		selectColumnSet.add("STATE");
		selectColumnSet.add("ZIP");
		selectColumnSet.add("COUNTRY");
		selectColumnSet.add("HYBRID_IND");
		selectColumnSet.add("CUST_PRICE_BOOK_ID");
		selectColumnSet.add("CONTRACT_ID");
		selectColumnSet.add("QUOTE_ID");
		selectColumnSet.add("APPROVED_CCL");
		selectColumnSet.add("DESIGN_ID");
		selectColumnSet.add("US_LD_AND_LOCAL_BEST_PLUS_POOL");
		selectColumnSet.add("US_LD_ONLY_BEST_PLUS_POOL");
		selectColumnSet.add("EMEA_APAC_BEST_PLUS_POOL");
		selectColumnSet.add("CATALOGUE_REFERENCE_TIME");
		selectColumnSet.add("DEF_SUBNET");
		selectColumnSet.add("ENT_CUM_CCL");
		selectColumnSet.add("USAGE_PLAN");
		selectColumnSet.add("BMT");
		selectColumnSet.add("E164");
		selectColumnSet.add("BW_ENTERPRISE_ID");
		selectColumnSet.add("POLICY_SERVICE_ID");
		selectColumnSet.add("SERVICEPACK_SERVICE_ID");

		return selectColumnSet;
	}

	/**
	 * @param locationId
	 * @param resultantRow
	 * @param selectColumnSet
	 * @return
	 * @throws GenericException
	 */
	// other entities by creating getTblXXXFromXXXId(...)
	// Set<String> selectColumnSet
	public Map<String, String> getTblDeviceFromDeviceId(String deviceId, Map<String, String> resultantRow,
			Set<String> selectColumnSet) throws GenericException {
		LOG.info("Entered getTblDeviceFromDeviceId");

		List<String[]> whereClauseList = null;
		DBServiceResponse dbServiceResponse = null;

		try {

			if (resultantRow == null) {
				resultantRow = new HashMap<>();
			}

			// TBL_DEVICE_MAP
			if (selectColumnSet == null) {
				selectColumnSet = getSelectColumnSetForDeviceMap();
			}

			whereClauseList = new ArrayList<>();
			whereClauseList.add(new String[] { "DEVICE_MAP_ID", deviceId });

			dbServiceResponse = inventoryDomainDataServiceImpl.searchInventory("TBL_DEVICE_MAP", selectColumnSet,
					whereClauseList);

			resultantRow = getResultantRow(dbServiceResponse, selectColumnSet, resultantRow);

			if (resultantRow.get("SIP_DEVICE_ID") != null && Long.valueOf(resultantRow.get("SIP_DEVICE_ID")) > 0) {
				// TBL_SIP_DEVICE_INFO
				selectColumnSet = getSelectColumnSetForSipDeviceInfo();
				whereClauseList.clear();
				whereClauseList.add(new String[] { "SIP_DEVICE_ID", resultantRow.get("SIP_DEVICE_ID") });
				dbServiceResponse = inventoryDomainDataServiceImpl.searchInventory("TBL_SIP_DEVICE_INFO",
						selectColumnSet, whereClauseList);
				resultantRow = getResultantRow(dbServiceResponse, selectColumnSet, resultantRow);
			} else if (resultantRow.get("GATEWAY_DEVICE_ID") != null
					&& Long.valueOf(resultantRow.get("GATEWAY_DEVICE_ID")) > 0) {
				// TBL_GATEWAY_DEVICE_INFO
				selectColumnSet = getSelectColumnSetForGatewayDeviceInfo();
				whereClauseList.clear();
				whereClauseList.add(new String[] { "GATEWAY_DEVICE_ID", resultantRow.get("GATEWAY_DEVICE_ID") });
				dbServiceResponse = inventoryDomainDataServiceImpl.searchInventory("TBL_GATEWAY_DEVICE_INFO",
						selectColumnSet, whereClauseList);
				resultantRow = getResultantRow(dbServiceResponse, selectColumnSet, resultantRow);
			}

			// TBL_DEVICE_TYPES
			selectColumnSet = getSelectColumnSetForTblDeviceType();
			whereClauseList.clear();
			whereClauseList.add(new String[] { "DEVICE_TYPE_ID", resultantRow.get("DEVICE_TYPE_ID") });
			dbServiceResponse = inventoryDomainDataServiceImpl.searchInventory("TBL_DEVICE_TYPES", selectColumnSet,
					whereClauseList);
			resultantRow = getResultantRow(dbServiceResponse, selectColumnSet, resultantRow);

			LOG.info("resultantRow.get(\"DEVICE_REALTYPE_ID\") -->" + resultantRow.get("DEVICE_REALTYPE_ID"));

			LOG.info("Device resultantRow count {}", resultantRow.size());
		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new GenericException(GenericException.GENERIC_EXCEPTION,
					"Exception occured in getTblDeviceFromDeviceId");
		}

		LOG.info("Exit getTblDeviceFromDeviceId");
		return resultantRow;
	}

	public Set<String> getSelectColumnSetForSipDeviceInfo() {
		Set<String> selectColumnSet = new HashSet<>();

		selectColumnSet.add("SIP_DEVICE_ID");
		selectColumnSet.add("DEVICE_NAME");
		selectColumnSet.add("DEVICE_TYPE_ID");
		selectColumnSet.add("MAC_ADDRESS");
		selectColumnSet.add("SERIAL_NUMBER");
		selectColumnSet.add("PORTS_AVAILABLE");
		selectColumnSet.add("CPE_USERNAME");
		selectColumnSet.add("CPE_PASSWORD");
		selectColumnSet.add("CODEC_ID");
		selectColumnSet.add("BUSINESS_LOCATION");
		selectColumnSet.add("STATION_LOCATION");
		selectColumnSet.add("DEVICE_LOCATION");
		selectColumnSet.add("FIRMWARE_VERSION_ID");
		selectColumnSet.add("IS_MANAGED");
		selectColumnSet.add("CREATED_BY");
		selectColumnSet.add("CREATION_DATE");
		selectColumnSet.add("MODIFIED_BY");
		selectColumnSet.add("LAST_MODIFIED_DATE");
		selectColumnSet.add("IP_ADDRESS");
		selectColumnSet.add("IP_SEC_ADDRESS");
		selectColumnSet.add("ENV_ORDER_ID");
		selectColumnSet.add("BRIX_IND");
		selectColumnSet.add("PORTS_ASSIGNED");
		selectColumnSet.add("BS_DEVICE_ID");
		selectColumnSet.add("CPE_NETWORK_FEATURES");
		selectColumnSet.add("INTERNAL_ADMIN");

		return selectColumnSet;
	}

	public Set<String> getSelectColumnSetForGatewayDeviceInfo() {
		Set<String> selectColumnSet = new HashSet<>();

		selectColumnSet.add("GATEWAY_DEVICE_ID");
		selectColumnSet.add("DEVICE_NAME");
		selectColumnSet.add("DEVICE_TYPE_ID");
		selectColumnSet.add("GATEWAY_ADDRESS");
		selectColumnSet.add("GATEWAY_SEC_ADDRESS");
		selectColumnSet.add("CALLING_PARTY_FORMAT");
		selectColumnSet.add("TERM_CALLING_IND");
		selectColumnSet.add("SBC_ID");
		selectColumnSet.add("CREATED_BY");
		selectColumnSet.add("CREATION_DATE");
		selectColumnSet.add("MODIFIED_BY");
		selectColumnSet.add("LAST_MODIFIED_DATE");
		selectColumnSet.add("ENV_ORDER_ID");
		selectColumnSet.add("DEVICE_CHAR_ID");
		selectColumnSet.add("TRANSPORT");
		selectColumnSet.add("PORTS_AVAILABLE");
		selectColumnSet.add("PORTS_ASSIGNED");
		selectColumnSet.add("GATEWAY_FQDN");
		selectColumnSet.add("GATEWAY_HUNT");
		selectColumnSet.add("SBC_PROV_METHOD");
		selectColumnSet.add("SBC_MIG_IND");
		selectColumnSet.add("IASA_CPE_LOCAL_GWYID");
		selectColumnSet.add("STN_POOL_ID");
		selectColumnSet.add("STN_LINE_PORT");
		selectColumnSet.add("SEC_SBC_ID");
		selectColumnSet.add("INTERNAL_ADMIN");
		selectColumnSet.add("AGGREGATE_OFFNET_CCL");
		selectColumnSet.add("SIGNALING_TIER_LOOKUP_VALUE");
		selectColumnSet.add("TIER_OVERRIDE_FLAG");
		selectColumnSet.add("IP_VERSION");
		selectColumnSet.add("PQ_INSTANCE_ID");
		selectColumnSet.add("TSO_MIG_LOCK");
		selectColumnSet.add("IPSEC_TUNNEL_ID");
		selectColumnSet.add("CUST_SIG_CONSTRAINT");
		selectColumnSet.add("UPDATE_COMMENT");

		return selectColumnSet;
	}

	public Set<String> getSelectColumnSetForDeviceMap() {

		Set<String> selectColumnSet = new HashSet<>();

		selectColumnSet.add("DEVICE_MAP_ID");
		selectColumnSet.add("ENTERPRISE_ID");
		selectColumnSet.add("LOCATION_ID");
		selectColumnSet.add("DEPARTMENT_ID");
		selectColumnSet.add("GATEWAY_DEVICE_ID");
		selectColumnSet.add("SIP_DEVICE_ID");
		selectColumnSet.add("CREATED_BY");
		selectColumnSet.add("CREATION_DATE");
		selectColumnSet.add("MODIFIED_BY");
		selectColumnSet.add("LAST_MODIFIED_DATE");
		selectColumnSet.add("ACTIVE_IND");
		selectColumnSet.add("ENV_ORDER_ID");
		selectColumnSet.add("DEVICE_NAME_ID");

		return selectColumnSet;
	}

	public Map<String, String> getEnterpriseTrunkFromTrunkId(String trunkId, Map<String, String> resultantRow,
			Set<String> selectColumnSet) throws GenericException {
		LOG.info("Entered getEnterpriseTrunkFromTrunkId");

		List<String[]> whereClauseList = null;
		DBServiceResponse dbServiceResponse = null;

		try {

			if (resultantRow == null) {
				resultantRow = new HashMap<>();
			}

			if (selectColumnSet == null) {
				selectColumnSet = getSelectColumnSetForTrunkGroup();
			}

			whereClauseList = new ArrayList<>();
			whereClauseList.add(new String[] { "GROUP_ID", trunkId });

			dbServiceResponse = inventoryDomainDataServiceImpl.searchInventory("TBL_GROUP", selectColumnSet,
					whereClauseList);

			resultantRow = getResultantRow(dbServiceResponse, selectColumnSet, resultantRow);

			if (resultantRow != null && resultantRow.get("TG_ID") != null) {
				selectColumnSet.clear();
				selectColumnSet = getSelectColumnSetForEnterpriseTrunk();

				whereClauseList = new ArrayList<>();
				whereClauseList.add(new String[] { "TRUNKGROUPID", resultantRow.get("TG_ID") });

				dbServiceResponse = inventoryDomainDataServiceImpl.searchInventory("TBL_ESIP_ENTERPRISE_TRUNK",
						selectColumnSet, whereClauseList);

				resultantRow = getResultantRow(dbServiceResponse, selectColumnSet, resultantRow);

			}

		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new GenericException(GenericException.GENERIC_EXCEPTION,
					"Exception occured in getTblDeviceFromDeviceId");
		}

		LOG.info("Exit getEnterpriseTrunkFromTrunkId");
		return resultantRow;
	}

	public Map<String, String> getTblTnFromTnPoolId(String tn, Map<String, String> resultantRow,
			Set<String> selectColumnSet) throws GenericException {

		LOG.info("Entered getTblTnFromTnPoolId");

		List<String[]> whereClauseList = null;
		DBServiceResponse dbServiceResponse = null;

		try {

			if (resultantRow == null) {
				resultantRow = new HashMap<>();
			}

			if (selectColumnSet == null) {
				selectColumnSet = getSelectColumnSetForTnEntity();
			}

			whereClauseList = new ArrayList<>();
			whereClauseList.add(new String[] { "TN", tn });

			dbServiceResponse = inventoryDomainDataServiceImpl.searchInventory("TBL_PUBLIC_TN_POOL", selectColumnSet,
					whereClauseList);

			resultantRow = getResultantRow(dbServiceResponse, selectColumnSet, resultantRow);

		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new GenericException(GenericException.GENERIC_EXCEPTION,
					"Exception occured in getTblDeviceFromDeviceId");
		}

		LOG.info("Exit getTblTnFromTnPoolId");
		return resultantRow;
	}

	public Set<String> getSelectColumnSetForTnEntity() {

		Set<String> selectColumnSet = new HashSet<>();

		selectColumnSet.add("TN_POOL_ID");
		selectColumnSet.add("LOCATION_ID");
		selectColumnSet.add("DEPARTMENT_ID");
		selectColumnSet.add("TN");
		selectColumnSet.add("TN_STATUS");
		selectColumnSet.add("PORTED_STATUS");
		selectColumnSet.add("NPA_SPLIT_STATUS");
		selectColumnSet.add("CREATED_BY");
		selectColumnSet.add("CREATION_DATE");
		selectColumnSet.add("MODIFIED_BY");
		selectColumnSet.add("LAST_MODIFIED_DATE");
		selectColumnSet.add("SWITCH_CLLI");
		selectColumnSet.add("TRUNK");
		selectColumnSet.add("ENV_ORDER_ID");
		selectColumnSet.add("ACTIVE_IND");
		selectColumnSet.add("TN_TYPE");
		selectColumnSet.add("TN_ON_OFF");
		selectColumnSet.add("STN_IND");
		selectColumnSet.add("ACT_DEACT");
		selectColumnSet.add("LI_IND");
		selectColumnSet.add("PUBIP");
		selectColumnSet.add("PORTIN_TYPE");
		selectColumnSet.add("TSP_CODE");
		selectColumnSet.add("REPLACEMENT_CLI");
		selectColumnSet.add("TRANSITION_TYPE");
		selectColumnSet.add("PS_ALI");
		selectColumnSet.add("CNAM_UPDATE_STATUS");
		selectColumnSet.add("CNAM_UPDATE_DATE");
		selectColumnSet.add("VERIZON_BTN");
		selectColumnSet.add("PUBIP_IN");
		selectColumnSet.add("PUBIP_OUT");

		return selectColumnSet;
	}

	/**
	 * @param primaryId
	 * @param resultantRow
	 * @param selectColumnSet
	 * @throws GenericException
	 */
	public Map<String, String> getTblGroupTnFromGroupTnId(String tnPoolId, Map<String, String> resultantRow,
			Set<String> selectColumnSet) throws GenericException {

		LOG.info("Entered getTblGroupTnFromGroupTnId");

		List<String[]> whereClauseList = null;
		DBServiceResponse dbServiceResponse = null;

		try {

			if (resultantRow == null) {
				resultantRow = new HashMap<>();
			}

			if (selectColumnSet == null) {
				selectColumnSet = getSelectColumnSetForGroupTnEntity();
			}

			whereClauseList = new ArrayList<>();
			whereClauseList.add(new String[] { "TN_POOL_ID", tnPoolId });

			dbServiceResponse = inventoryDomainDataServiceImpl.searchInventory("TBL_GROUP_TN", selectColumnSet,
					whereClauseList);

			resultantRow = getResultantRow(dbServiceResponse, selectColumnSet, resultantRow);

		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new GenericException(GenericException.GENERIC_EXCEPTION,
					"Exception occured in getTblGroupTnFromGroupTnId");
		}

		LOG.info("Exit getTblGroupTnFromGroupTnId");
		return resultantRow;
	}

	/**
	 * @return
	 */
	public Set<String> getSelectColumnSetForGroupTnEntity() {

		Set<String> selectColumnSet = new HashSet<>();

		selectColumnSet.add("GROUP_TN_ID");
		selectColumnSet.add("GROUP_ID");
		selectColumnSet.add("TN_POOL_ID");
		selectColumnSet.add("SEQUENCE_NO");
		selectColumnSet.add("EXTENSION");
		selectColumnSet.add("PRIVATE_NUMBER");
		selectColumnSet.add("LINE_PORT");
		selectColumnSet.add("CID_FIRST_NAME");
		selectColumnSet.add("CID_LAST_NAME");
		selectColumnSet.add("VM_MAXSIZE_ID");
		selectColumnSet.add("VM_BOX_NUM");
		selectColumnSet.add("CREATED_BY");
		selectColumnSet.add("CREATION_DATE");
		selectColumnSet.add("MODIFIED_BY");
		selectColumnSet.add("LAST_MODIFIED_DATE");
		selectColumnSet.add("ACTIVE_IND");
		selectColumnSet.add("ENV_ORDER_ID");
		selectColumnSet.add("SUB_ID");
		selectColumnSet.add("ICP_SUB_ID");
		selectColumnSet.add("PIT_SIP_TRX_ID");

		return selectColumnSet;
	}

	// HPBX Start
	public List<Map<String, String>> getCurrentHpbxNniDetails() throws GenericException {
		LOG.info("Entered getCurrentHpbxNniDetails");

		List<String[]> whereClauseList = null;
		DBServiceResponse dbServiceResponse = null;
		Set<String> selectColumnSet = null;
		List<Map<String, String>> resultantRows = new ArrayList<>();

		try {

			whereClauseList = new ArrayList<>();
			whereClauseList.add(new String[] { "STATUS", "1" });

			selectColumnSet = getSelectColumnSetForHpbxNniConfig();

			dbServiceResponse = inventoryDomainDataServiceImpl.searchInventory("TBL_HPBX_NNI_CONFIG", selectColumnSet,
					whereClauseList);

			resultantRows = getResultantRows(dbServiceResponse, selectColumnSet);

			if (resultantRows != null && !resultantRows.isEmpty())
				;
			else {
				throw new TranslatorException(ErrorCode.HPBX_NNI_MISSING, "HPBX NNI Missing");
			}

		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new GenericException(GenericException.GENERIC_EXCEPTION,
					"Exception occured in getTblLocationFromLocationId");
		}

		LOG.info("Exit getCurrentHpbxNniDetails");
		return resultantRows;
	}

	/**
	 * @return
	 */
	public Set<String> getSelectColumnSetForHpbxNniConfig() {
		LOG.info("Entered getSelectColumnSetForHpbxNniConfig");

		Set<String> selectColumnSet = new HashSet<>();

		selectColumnSet.add("HPBX_NNI");
		selectColumnSet.add("HPBX_PREBUILD_LOC_ID");
		selectColumnSet.add("HPBX_PREBUILD_ENT_ID");
		selectColumnSet.add("HPBX_PREBUILD_ENT_TRUNK_ID");
		selectColumnSet.add("HPBX_PREBUILD_ENT_TRUNK_NAME");
		selectColumnSet.add("HPBX_PREBUILD_TRUNK_ID");
		selectColumnSet.add("HPBX_PREBUILD_TRUNK_NAME");
		selectColumnSet.add("ECH_ID");
		selectColumnSet.add("REDUNCANCY_TYPE");
		selectColumnSet.add("FAILOVER_ID");
		selectColumnSet.add("BW_CLUSTER");
		selectColumnSet.add("NBS_CLUSTER");
		selectColumnSet.add("HPBX_PREBUILD_DEVICE_ID");
		selectColumnSet.add("ADDRESS");
		selectColumnSet.add("CITY");
		selectColumnSet.add("STATE");
		selectColumnSet.add("ZIP");
		selectColumnSet.add("COUNTRY");
		selectColumnSet.add("STATUS");

		LOG.info("Exit getSelectColumnSetForHpbxNniConfig");

		return selectColumnSet;
	}

	/**
	 * @param dbServiceResponse
	 * @param selectColumnSet
	 * @return
	 */
	List<Map<String, String>> getResultantRows(DBServiceResponse dbServiceResponse, Set<String> selectColumnSet) {
		LOG.info("Entered getResultantRows");

		Map<String, String> resultantRow = null;
		List<Map<String, String>> resultantRows = new ArrayList<>();

		if (dbServiceResponse == null)
			return null;
		else if (dbServiceResponse.getTableRows() == null)
			return null;

		for (TblRow tblRows : dbServiceResponse.getTableRows()) {

			resultantRow = new HashMap<>();
			Iterator<String> colItr = selectColumnSet.iterator();
			String colName;

			while (colItr.hasNext()) {

				colName = colItr.next();

				if (tblRows.getTblRow().get(colName) != null && tblRows.getTblRow().get(colName).getValue() != null) {
					LOG.info("+++++Level2+++++Column Name = {} , And Col Value = {}", colName,
							tblRows.getTblRow().get(colName).getValue());
					resultantRow.put(colName, tblRows.getTblRow().get(colName).getValue());
				}
			}

			resultantRows.add(resultantRow);
		}

		LOG.info("Exit getResultantRows");
		return resultantRows;
	}

	/**
	 * @param voipOrderRequest
	 * @return
	 * @throws ApplicationInterfaceException
	 * @throws TranslatorException
	 * @throws GenericException
	 */
	public String getBSAppServer(VOIPOrderRequest voipOrderRequest)
			throws ApplicationInterfaceException, TranslatorException, GenericException {
		LOG.info("Inside getBSAppServer(voipOrderRequest)");

		String state = null;
		VoipServiceType voipServiceType = null;

		String labBsAsId = getLabBsAsId();
		if (labBsAsId != null) {
			return labBsAsId;
		} else {

			DBServiceResponse dbServiceResponse = orderServiceHelperImpl
					.getEnterpriseInformationFromGchId(voipOrderRequest.getOrderHeader().getGCHId());

			boolean isNewEsipEnterprise = orderServiceHelperImpl.isNewEsipEnterprise(voipOrderRequest,
					dbServiceResponse);

			if (isNewEsipEnterprise) {

				if (voipOrderRequest.getLocation() != null
						&& voipOrderRequest.getLocation().getLocationAddress() != null
						&& voipOrderRequest.getLocation().getLocationAddress().getState() != null) {
					state = voipOrderRequest.getLocation().getLocationAddress().getState();
				} // TODO Implement Else Part

				switch (voipOrderRequest.getOrderHeader().getSolutionType()) {
				case ESIP_ESL:
				case ESIP_EBL:
					voipServiceType = VoipServiceType.ENTERPRISE_SIP;
					break;
				case IPFLEX:
					voipServiceType = VoipServiceType.IP_FLEX;
					break;
				case HPBX:
					voipServiceType = VoipServiceType.HOSTED_PBX;
					break;
				default:
					break;
				}

				return getBSAppServer(voipServiceType, state);

			} else {
				String entId = null;
				for (TblRow tblRows : dbServiceResponse.getTableRows()) {
					if (tblRows.getTblRow() != null && tblRows.getTblRow().get("ENTERPRISE_ID") != null
							&& tblRows.getTblRow().get("ENTERPRISE_ID").getValue() != null) {

						entId = tblRows.getTblRow().get("ENTERPRISE_ID").getValue();
						LOG.info("The ENTERPRISE_ID = {}", entId);
					}
				}
				return getExistingBSAppServer(entId);
			}
		}
	}

	/**
	 * @return labBsAppId
	 * @throws ApplicationInterfaceException
	 */
	String getLabBsAsId() throws ApplicationInterfaceException {

		String labBsAppId = null;

		Set<String> selectColumnSet = new HashSet<>();
		selectColumnSet.add("PARAM_NAME");
		selectColumnSet.add("PARAM_VALUE");

		List<String[]> whereClauseList = new ArrayList<>();
		whereClauseList.add(new String[] { "PARAM_NAME", "BS_SELECTION" });
		whereClauseList.add(new String[] { "PROCESS_NAME", "ORDER_MANAGER" });

		DBServiceResponse dbServiceResponse = inventoryDomainDataServiceImpl.searchInventory("TBL_CONFIG_PARAMS",
				selectColumnSet, whereClauseList);

		for (TblRow tblRows : dbServiceResponse.getTableRows()) {
			if (tblRows.getTblRow() != null && tblRows.getTblRow().get("PARAM_VALUE") != null
					&& tblRows.getTblRow().get("PARAM_VALUE").getValue() != null) {
				labBsAppId = tblRows.getTblRow().get("PARAM_VALUE").getValue();
				LOG.info(labBsAppId);
			}
		}
		return labBsAppId;
	}

	/**
	 * @param voipServiceType
	 * @param state
	 * @return
	 * @throws ApplicationInterfaceException
	 * @throws TranslatorException
	 */
	public String getBSAppServer(VoipServiceType voipServiceType, String state)
			throws ApplicationInterfaceException, TranslatorException {
		LOG.info("Entered getBSAppServer(voipServiceType, state) For voipServiceType = {}  And State = {}",
				voipServiceType, state);

		String bsAsId = null;
		Set<String> selectColumnSet = new HashSet<>();
		selectColumnSet.add("BS_AS_ID");

		List<String[]> whereClauseList = new ArrayList<>();
		whereClauseList.add(new String[] { "STATE", state });
		whereClauseList.add(new String[] { "VOIP_SERVICE_TYPE", String.valueOf(voipServiceType.getIndex()) });

		DBServiceResponse dbServiceResponse = inventoryDomainDataServiceImpl.searchInventory("TBL_BS_AS_MAPPING_FXO",
				selectColumnSet, whereClauseList);

		for (TblRow tblRows : dbServiceResponse.getTableRows()) {
			if (tblRows.getTblRow() != null && tblRows.getTblRow().get("BS_AS_ID") != null
					&& tblRows.getTblRow().get("BS_AS_ID").getValue() != null) {
				bsAsId = tblRows.getTblRow().get("BS_AS_ID").getValue();
				LOG.info("BS_AS_ID : {}", bsAsId);
			} else {
				throw new TranslatorException(ErrorCode.BS_AS_ID_MISSING, "BS_AS_ID missing");
			}
		}

		LOG.info("Exit getBSAppServer");
		return bsAsId;
	}

	/**
	 * @param enterpriseId
	 * @return
	 * @throws ApplicationInterfaceException
	 * @throws TranslatorException
	 */
	public String getExistingBSAppServer(String enterpriseId) throws ApplicationInterfaceException {
		LOG.info("Entered getExistingBSAppServer for EnterpriseId = {}", enterpriseId);

		String bsAsId = null;

		Set<String> selectColumnSet = new HashSet<>();
		selectColumnSet.add("AS_ID");

		List<String[]> whereClauseList = new ArrayList<>();
		whereClauseList.add(new String[] { "ENTERPRISE_ID", enterpriseId });

		DBServiceResponse dbServiceResponse = inventoryDomainDataServiceImpl.searchInventory("TBL_ENTERPRISE",
				selectColumnSet, whereClauseList);

		for (TblRow tblRows : dbServiceResponse.getTableRows()) {
			if (tblRows.getTblRow() != null && tblRows.getTblRow().get("AS_ID") != null
					&& tblRows.getTblRow().get("AS_ID").getValue() != null) {
				bsAsId = tblRows.getTblRow().get("AS_ID").getValue();
				LOG.info("AS_ID : {}", bsAsId);
			}
		}

		LOG.info("Exit getExistingBSAppServer");
		return bsAsId;
	}

	/**
	 * @param deviceUeId
	 * @return
	 * @throws GenericException
	 * @throws ApplicationInterfaceException
	 * @throws TranslatorException
	 */
	public List<String> getTNsFromLocationId(String voipLocationId) throws ApplicationInterfaceException {
		LOG.info("Entered getTNsFromLocationId");

		List<String> tns = new ArrayList<>();

		Set<String> selectColumnSet = new HashSet<>();
		selectColumnSet.add("TN");

		List<String[]> whereClauseList = new ArrayList<>();
		whereClauseList.add(new String[] { "LOCATION_ID", voipLocationId });

		DBServiceResponse dbServiceResponse = inventoryDomainDataServiceImpl.searchInventory("TBL_PUBLIC_TN_POOL",
				selectColumnSet, whereClauseList);

		for (TblRow tblRows : dbServiceResponse.getTableRows()) {
			if (tblRows.getTblRow() != null && tblRows.getTblRow().get("TN") != null
					&& tblRows.getTblRow().get("TN").getValue() != null) {
				LOG.info("TN::{}", tblRows.getTblRow().get("TN").getValue());
				tns.add(tblRows.getTblRow().get("TN").getValue());

			}
		}
		LOG.info("Exiting getTNsFromLocationId");
		return tns;
	}

	/**
	 * @param enterpriseId
	 * @return
	 * @throws ApplicationInterfaceException
	 * @throws TranslatorException
	 */
	public String getHpbxBwLocationIdFromEnterpriseId(String enterpriseId)
			throws ApplicationInterfaceException, TranslatorException {
		LOG.info("Entered getHpbxBwLocationId For Entrprise Id = {}", enterpriseId);

		String bwLocationId = null;

		Set<String> selectColumnSet = new HashSet<>();
		selectColumnSet.add("ENTERPRISE_ID");
		selectColumnSet.add("LOCATION_ID");
		selectColumnSet.add("LOC_GROUP_ID");
		selectColumnSet.add("LOCATION_TYPE");

		List<String[]> whereClauseList = new ArrayList<>();
		whereClauseList.add(new String[] { "ENTERPRISE_ID", enterpriseId });
		whereClauseList.add(new String[] { "LOCATION_TYPE", String.valueOf(LocationType.HPBX_ECH.getIndex()) });

		DBServiceResponse dbServiceResponse = inventoryDomainDataServiceImpl.searchInventory("TBL_LOCATION",
				selectColumnSet, whereClauseList);

		for (TblRow tblRows : dbServiceResponse.getTableRows()) {
			if (tblRows.getTblRow() != null && tblRows.getTblRow().get("LOC_GROUP_ID") != null
					&& tblRows.getTblRow().get("LOC_GROUP_ID").getValue() != null) {
				bwLocationId = tblRows.getTblRow().get("LOC_GROUP_ID").getValue();
				LOG.info("LOC_GROUP_ID : {}", bwLocationId);
				break;
			}
		}

		if (bwLocationId == null) {
			throw new TranslatorException(ErrorCode.LOCATION_MISSING, "Location Id Not Found");
		}

		LOG.info("Exit getHpbxBwLocationId");
		return bwLocationId;
	}

	/**
	 * @param enterpriseId
	 * @return
	 * @throws ApplicationInterfaceException
	 * @throws TranslatorException
	 * @throws GenericException
	 */
	public Map<String, String> getHpbxDeviceFromEnterprise(String enterpriseId)
			throws ApplicationInterfaceException, TranslatorException, GenericException {
		LOG.info("Entered getHpbxDeviceFromEnterprise For Enterprise Id = {}", enterpriseId);

		String locationId = null;
		Map<String, String> deviceResultMap = null;

		Set<String> selectColumnSet = new HashSet<>();
		selectColumnSet.add("ENTERPRISE_ID");
		selectColumnSet.add("LOCATION_ID");
		selectColumnSet.add("LOCATION_TYPE");

		List<String[]> whereClauseList = new ArrayList<>();
		whereClauseList.add(new String[] { "ENTERPRISE_ID", enterpriseId });
		whereClauseList.add(new String[] { "LOCATION_TYPE", String.valueOf(LocationType.HPBX_ECH.getIndex()) });

		LOG.info("LocationType.HPBX_ECH.getIndex() -->" + LocationType.HPBX_ECH.getIndex());

		DBServiceResponse dbServiceResponse = inventoryDomainDataServiceImpl.searchInventory("TBL_LOCATION",
				selectColumnSet, whereClauseList);

		for (TblRow tblRows : dbServiceResponse.getTableRows()) {
			if (tblRows.getTblRow() != null && tblRows.getTblRow().get("LOCATION_ID") != null
					&& tblRows.getTblRow().get("LOCATION_ID").getValue() != null) {
				locationId = tblRows.getTblRow().get("LOCATION_ID").getValue();
				LOG.info("LOCATION_ID : {}", locationId);
				break;
			}
		}

		if (locationId != null) {

			String deviceMapId = null;

			selectColumnSet = new HashSet<>();
			selectColumnSet.add("DEVICE_MAP_ID");

			whereClauseList = new ArrayList<>();
			whereClauseList.add(new String[] { "LOCATION_ID", locationId });

			dbServiceResponse = inventoryDomainDataServiceImpl.searchInventory("TBL_GROUP", selectColumnSet,
					whereClauseList);

			for (TblRow tblRows : dbServiceResponse.getTableRows()) {
				if (tblRows.getTblRow() != null && tblRows.getTblRow().get("DEVICE_MAP_ID") != null
						&& tblRows.getTblRow().get("DEVICE_MAP_ID").getValue() != null) {
					deviceMapId = tblRows.getTblRow().get("DEVICE_MAP_ID").getValue();
					LOG.info("DEVICE_MAP_ID : {}", deviceMapId);
					break;
				}
			}

			if (deviceMapId != null) {
				deviceResultMap = getTblDeviceFromDeviceId(deviceMapId, null, null);

			}
		}

		LOG.info("Exit getHpbxDeviceFromEnterprise");
		return deviceResultMap;
	}

	/**
	 * @param vpnName
	 * @return
	 * @throws ApplicationInterfaceException
	 */
	public DBServiceResponse getLocationFromVpnName(String vpnName) throws ApplicationInterfaceException {
		LOG.info("Entered getLocationFromVpnName");

		Set<String> selectColumnSet = new HashSet<>();
		selectColumnSet.add("LOCATION_ID");
		selectColumnSet.add("ENTERPRISE_ID");

		List<String[]> whereClauseList = new ArrayList<>();
		whereClauseList.add(new String[] { "VPN_NAME", vpnName });

		DBServiceResponse dbServiceResponse = inventoryDomainDataServiceImpl.searchInventory("TBL_LOCATION",
				selectColumnSet, whereClauseList);

		LOG.info("Exiting getLocationFromVpnName");
		return dbServiceResponse;
	}

	public LocationType getLocationTypeFromEnterpriseId(String enterpriseId) throws ApplicationInterfaceException {
		LOG.info("Entered getLocationTypeFromEnterpriseId");

		LocationType locationType = null;
		String locationTypeNumber = null;

		Set<String> selectColumnSet = new HashSet<>();
		selectColumnSet.add("LOCATION_ID");
		selectColumnSet.add("ENTERPRISE_ID");
		selectColumnSet.add("LOCATION_TYPE");

		List<String[]> whereClauseList = new ArrayList<>();
		whereClauseList.add(new String[] { "ENTERPRISE_ID", enterpriseId });

		DBServiceResponse dbServiceResponse = inventoryDomainDataServiceImpl.searchInventory("TBL_LOCATION",
				selectColumnSet, whereClauseList);

		if (dbServiceResponse != null && dbServiceResponse.getTableRows() != null) {
			for (TblRow tblRows : dbServiceResponse.getTableRows()) {
				locationTypeNumber = tblRows.getTblRow().get("LOCATION_TYPE").getValue();
				LOG.info("LOCATION_TYPE from TBL_LOCATION : {}", locationTypeNumber);

			}

			if (locationTypeNumber != null) {
				locationType = LocationType.values()[Integer.valueOf(locationTypeNumber) - 1];
				LOG.info("LOCATIONTYPE Enum value: {}", locationType);

			}
		}

		LOG.info("Exiting getLocationTypeFromEnterpriseId");
		return locationType;
	}

	/**
	 * @param paramName
	 * @param processName
	 * @param paramGroup
	 * @param status
	 * @return
	 * @throws ApplicationInterfaceException
	 */
	public List<String> getParamValue(String paramName, String processName, String paramGroup, String status)
			throws ApplicationInterfaceException {
		LOG.info("Entered getParamValue");

		Set<String> selectColumnSet = new HashSet<>();
		selectColumnSet.add("PARAM_NAME");
		selectColumnSet.add("PARAM_VALUE");
		List<String> paramValueList = new ArrayList<>();

		List<String[]> whereClauseList = new ArrayList<>();
		if (paramName != null) {
			whereClauseList.add(new String[] { "PARAM_NAME", paramName });
		}
		if (processName != null) {
			whereClauseList.add(new String[] { "PROCESS_NAME", processName });
		}
		if (paramGroup != null) {
			whereClauseList.add(new String[] { "PARAM_GROUP", paramGroup });
		}
		if (status != null) {
			whereClauseList.add(new String[] { "STATUS", status });
		}

		DBServiceResponse dbServiceResponse = inventoryDomainDataServiceImpl.searchInventory("TBL_CONFIG_PARAMS",
				selectColumnSet, whereClauseList);

		for (TblRow tblRows : dbServiceResponse.getTableRows()) {
			if (tblRows.getTblRow() != null && tblRows.getTblRow().get("PARAM_VALUE") != null
					&& tblRows.getTblRow().get("PARAM_VALUE").getValue() != null) {

				paramValueList.add(tblRows.getTblRow().get("PARAM_VALUE").getValue());
			}
		}

		LOG.info("Exiting getParamValue");
		return paramValueList;
	}

	/**
	 * @param deviceUeId
	 * @param devProtocol
	 * @return
	 * @throws GenericException
	 */
	public Map<String, String> getDeviceDetails(String deviceUeId, String devProtocol) throws GenericException {
		LOG.info("Entered getDeviceDetails");

		Map<String, String> deviceDetailsMap = new HashMap<>();

		Map<String, String> tblDeviceTypeResultantRowMap = getTblDeviceTypeFromUeId(deviceUeId, devProtocol);

		deviceDetailsMap.put("DEVICE_TYPE_ID", tblDeviceTypeResultantRowMap.get("DEVICE_TYPE_ID"));
		deviceDetailsMap.put("DEVICE_TYPE_NAME", tblDeviceTypeResultantRowMap.get("DEVICE_TYPE_NAME"));
		deviceDetailsMap.put("DEVICE_VENDOR", tblDeviceTypeResultantRowMap.get("DEVICE_VENDOR"));
		deviceDetailsMap.put("DEVICE_MODEL", tblDeviceTypeResultantRowMap.get("DEVICE_MODEL"));
		deviceDetailsMap.put("UEID", tblDeviceTypeResultantRowMap.get("UEID"));
		deviceDetailsMap.put("PROTOCOL", tblDeviceTypeResultantRowMap.get("PROTOCOL"));

		Map<String, String> tblDeviceBSTypeResultantRowMap = getTblDeviceBSType(
				tblDeviceTypeResultantRowMap.get("DEVICE_BSTYPE_ID"));

		deviceDetailsMap.put("DEVICE_BSTYPE_ID", tblDeviceBSTypeResultantRowMap.get("DEVICE_BSTYPE_ID"));
		deviceDetailsMap.put("DEVICE_BSNAME", tblDeviceBSTypeResultantRowMap.get("DEVICE_BSNAME"));
		deviceDetailsMap.put("DEVICE_BSTYPE", tblDeviceBSTypeResultantRowMap.get("DEVICE_BSTYPE"));
		deviceDetailsMap.put("MAX_NUM_PORTS", tblDeviceBSTypeResultantRowMap.get("MAX_NUM_PORTS"));

		Map<String, String> tblDeviceRealTypeResultantRowMap = getTblDeviceRealType(
				tblDeviceTypeResultantRowMap.get("DEVICE_REALTYPE_ID"));

		deviceDetailsMap.put("DEVICE_REALTYPE_ID", tblDeviceRealTypeResultantRowMap.get("DEVICE_REALTYPE_ID"));
		deviceDetailsMap.put("DEVICE_REALTYPE_NAME", tblDeviceRealTypeResultantRowMap.get("DEVICE_REALTYPE_NAME"));

		LOG.info("Exit getDeviceDetails");
		return deviceDetailsMap;
	}

	/**
	 * @param ueId
	 * @param devProtocol
	 * @return
	 * @throws GenericException
	 */
	public Map<String, String> getTblDeviceTypeFromUeId(String ueId, String devProtocol) throws GenericException {
		LOG.info("Entered getTblDeviceTypeFromUeId");

		List<String[]> whereClauseList = null;
		DBServiceResponse dbServiceResponse = null;
		Map<String, String> resultantRow = null;
		Set<String> selectColumnSet = null;

		try {

			selectColumnSet = getSelectColumnSetForTblDeviceType();

			whereClauseList = new ArrayList<>();
			whereClauseList.add(new String[] { "UEID", ueId });
			whereClauseList.add(new String[] { "PROTOCOL", devProtocol });

			dbServiceResponse = inventoryDomainDataServiceImpl.searchInventory("TBL_DEVICE_TYPES", selectColumnSet,
					whereClauseList);

			resultantRow = getResultantRow(dbServiceResponse, selectColumnSet, resultantRow);

		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new GenericException(GenericException.GENERIC_EXCEPTION,
					"Exception occured in getTblDeviceTypeFromUeId");
		}

		LOG.info("Exit getTblDeviceTypeFromUeId");
		return resultantRow;
	}

	public static Set<String> getSelectColumnSetForTblDeviceType() {

		Set<String> selectColumnSet = new HashSet<>();

		selectColumnSet.add("DEVICE_TYPE_ID");
		selectColumnSet.add("DEVICE_TYPE_NAME");
		selectColumnSet.add("DEVICE_REALTYPE_ID");
		selectColumnSet.add("DEVICE_BSTYPE_ID");
		selectColumnSet.add("MODIFIED_BY");
		selectColumnSet.add("LAST_MODIFIED_DATE");
		selectColumnSet.add("DISPLAY_INDICATOR");
		selectColumnSet.add("IS_SHARED_CALL_ENABLED");
		selectColumnSet.add("DEVICE_VENDOR");
		selectColumnSet.add("DEVICE_MODEL");
		selectColumnSet.add("IS_CPE_DEVICE");
		selectColumnSet.add("IS_BLF_DEVICE");
		selectColumnSet.add("MAX_LINE_KEYS");
		selectColumnSet.add("PROTOCOL");
		selectColumnSet.add("ENV_ORDER_ID");
		selectColumnSet.add("UEID");
		selectColumnSet.add("DEVICE_CHAR_ID");

		return selectColumnSet;
	}

	/**
	 * @param bsTypeId
	 * @return
	 * @throws GenericException
	 */
	public Map<String, String> getTblDeviceBSType(String bsTypeId) throws GenericException {
		LOG.info("Entered getTblDeviceBSType");

		List<String[]> whereClauseList = null;
		DBServiceResponse dbServiceResponse = null;
		Map<String, String> resultantRow = null;
		Set<String> selectColumnSet = null;

		try {

			selectColumnSet = getSelectColumnSetForTblDeviceBSType();

			whereClauseList = new ArrayList<>();
			whereClauseList.add(new String[] { "DEVICE_BSTYPE_ID", bsTypeId });

			dbServiceResponse = inventoryDomainDataServiceImpl.searchInventory("TBL_DEVICE_BSTYPE", selectColumnSet,
					whereClauseList);

			resultantRow = getResultantRow(dbServiceResponse, selectColumnSet, resultantRow);

		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new GenericException(GenericException.GENERIC_EXCEPTION, "Exception occured in getTblDeviceBSType");
		}

		LOG.info("Exit getTblDeviceBSType");
		return resultantRow;
	}

	public static Set<String> getSelectColumnSetForTblDeviceBSType() {

		Set<String> selectColumnSet = new HashSet<>();

		selectColumnSet.add("DEVICE_BSTYPE_ID");
		selectColumnSet.add("DEVICE_BSNAME");
		selectColumnSet.add("DEVICE_BSTYPE");
		selectColumnSet.add("MAX_NUM_PORTS");
		selectColumnSet.add("MODIFIED_BY");
		selectColumnSet.add("LAST_MODIFIED_DATE");
		selectColumnSet.add("IP_REQUIRED");
		selectColumnSet.add("PORT_ALLOWED");

		return selectColumnSet;
	}

	/**
	 * @param deviceRealTypeId
	 * @return
	 * @throws GenericException
	 */
	public Map<String, String> getTblDeviceRealType(String deviceRealTypeId) throws GenericException {
		LOG.info("Entered getTblDeviceRealType");

		List<String[]> whereClauseList = null;
		DBServiceResponse dbServiceResponse = null;
		Map<String, String> resultantRow = null;
		Set<String> selectColumnSet = null;

		try {

			selectColumnSet = getSelectColumnSetForTblDeviceRealType();

			whereClauseList = new ArrayList<>();
			whereClauseList.add(new String[] { "DEVICE_REALTYPE_ID", deviceRealTypeId });

			dbServiceResponse = inventoryDomainDataServiceImpl.searchInventory("TBL_DEVICE_REALTYPE", selectColumnSet,
					whereClauseList);

			resultantRow = getResultantRow(dbServiceResponse, selectColumnSet, resultantRow);

		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new GenericException(GenericException.GENERIC_EXCEPTION, "Exception occured in getTblDeviceRealType");
		}

		LOG.info("Exit getTblDeviceRealType");
		return resultantRow;
	}

	public static Set<String> getSelectColumnSetForTblDeviceRealType() {

		Set<String> selectColumnSet = new HashSet<>();

		selectColumnSet.add("DEVICE_REALTYPE_ID");
		selectColumnSet.add("DEVICE_REALTYPE_NAME");
		selectColumnSet.add("SHARED_IND");
		selectColumnSet.add("MODIFIED_BY");
		selectColumnSet.add("LAST_MODIFIED_DATE");

		return selectColumnSet;
	}

	public String getNbsClusterInfoIdFromTrunkId(String trunkId) throws ApplicationInterfaceException {
		LOG.info("Entered getNbsClusterInfoIdFromTrunkId");

		Set<String> selectColumnSet = getSelectColumnSetForNbsEntity();

		List<String[]> whereClauseList = new ArrayList<>();
		whereClauseList.add(new String[] { "GROUP_ID", trunkId });

		DBServiceResponse dbServiceResponse = inventoryDomainDataServiceImpl.searchInventory("TBL_NBS_CLUSTER_INFO",
				selectColumnSet, whereClauseList);

		Map<String, String> resultantRow = getResultantRow(dbServiceResponse, selectColumnSet, null);

		LOG.info("Exit getNbsClusterInfoIdFromTrunkId");
		return resultantRow.get("NBS_CLUSTER_INFO_ID");
	}

	/*
	 * Get Devices list by Location Id from inventory
	 */

	public List<Map<String, String>> getDevicesFromLocationId(String locationId) throws ApplicationInterfaceException {
		LOG.info("Entered getDevicesFromLocationId - {}", locationId);
		List<String> devicesList = new ArrayList<>();
		List<Map<String, String>> resultantRows = new ArrayList<>();

		List<String[]> whereClauseList = new ArrayList<>();
		whereClauseList.add(new String[] { "LOCATION_ID", locationId });

		Set<String> selectColumnSet = getSelectColumnSetForDeviceMap();

		DBServiceResponse dbServiceResponse = inventoryDomainDataServiceImpl.searchInventory("TBL_DEVICE_MAP",
				selectColumnSet, whereClauseList);

		resultantRows = getResultantRows(dbServiceResponse, selectColumnSet);

		LOG.info("Leaving getDevicesFromLocationId");

		return resultantRows;
	}

	// loc id for prev order
	/**
	 * Prasad
	 * 
	 * @return
	 */
	public List<Long> getHpbxInstalledLocalEchid(String workOrderNumber, String eblId)
			throws ApplicationInterfaceException {

		LOG.info("Entered getHpbxInstalledLocalEchid");

		LocationType locationType = null;
		String locationGroupId = null;
		List<Map<String, String>> resultantRows = new ArrayList<>();
		List<Long> locationIds = null;

		Set<String> selectColumnSet = new HashSet<>();
		selectColumnSet.add("LOC_GROUP_ID");

		List<String[]> whereClauseList = new ArrayList<>();
		whereClauseList.add(new String[] { "LOCATION_ID", eblId });

		DBServiceResponse dbServiceResponse = inventoryDomainDataServiceImpl.searchInventory("TBL_LOCATION",
				selectColumnSet, whereClauseList);

		Map<String, String> resultantRow = getResultantRow(dbServiceResponse, selectColumnSet, null);

		LOG.info("resultantRow- {}", resultantRow);

		locationGroupId = resultantRow.get("LOC_GROUP_ID");
		LOG.info("locationGroupId- {}", locationGroupId);
		if (null != locationGroupId) {
			selectColumnSet = new HashSet<>();
			selectColumnSet.add("LOCATION_ID");
			selectColumnSet.add("LOCATION_TYPE");

			LOG.info("String.valueOf(LocationType.HPBX_ECH.getIndex())- {}",
					String.valueOf(LocationType.HPBX_ECH.getIndex()));

			whereClauseList = new ArrayList<>();
			whereClauseList.add(new String[] { "LOCATION_TYPE", String.valueOf(LocationType.HPBX_ECH.getIndex()) }); // HPBX
																														// TYPE
																														// 7
			whereClauseList.add(new String[] { "LOC_GROUP_ID", locationGroupId });

			dbServiceResponse = inventoryDomainDataServiceImpl.searchInventory("TBL_LOCATION", selectColumnSet,
					whereClauseList);

			resultantRows = getResultantRows(dbServiceResponse, selectColumnSet);
		}

		locationIds = new ArrayList<>();
		for (Map<String, String> results : resultantRows) {
			locationIds.add(Long.valueOf(results.get("LOCATION_ID")));
		}

		LOG.info("Exiting getHpbxInstalledLocalEchid");

		return locationIds;
	}

	/**
	 * @param enterpriseId
	 * @param locationType
	 * @return
	 * @throws ApplicationInterfaceException
	 * @throws TranslatorException
	 */
	public String getLocationIdFromEnterpriseId(String enterpriseId, int locationType)
			throws ApplicationInterfaceException, TranslatorException {
		LOG.info("Entered getLocationIdFromEnterpriseId For Entrprise Id = {} and LocationType = {}", enterpriseId,
				locationType);

		String locationId = null;

		Set<String> selectColumnSet = new HashSet<>();
		selectColumnSet.add("LOCATION_ID");

		List<String[]> whereClauseList = new ArrayList<>();
		whereClauseList.add(new String[] { "ENTERPRISE_ID", enterpriseId });
		whereClauseList.add(new String[] { "LOCATION_TYPE", String.valueOf(locationType) });

		DBServiceResponse dbServiceResponse = inventoryDomainDataServiceImpl.searchInventory("TBL_LOCATION",
				selectColumnSet, whereClauseList);

		for (TblRow tblRows : dbServiceResponse.getTableRows()) {
			if (tblRows.getTblRow() != null && tblRows.getTblRow().get("LOCATION_ID") != null
					&& tblRows.getTblRow().get("LOCATION_ID").getValue() != null) {
				locationId = tblRows.getTblRow().get("LOCATION_ID").getValue();
				LOG.info("LOCATION_ID : {}", locationId);
				break;
			}
		}

		LOG.info("Exit getLocationIdFromEnterpriseId with Location Id = {}", locationId);
		return locationId;
	}

	/**
	 * @param groupId
	 * @return deviceId
	 * @throws ApplicationInterfaceException
	 */
	public Long getDeviceMapIdFromTrunkId(String groupId) throws ApplicationInterfaceException {
		LOG.info("Entered getDeviceIdFromTrunkId For groupId= {}", groupId);
		long deviceId = 0;

		Set<String> selectColumnSet = new HashSet<>();
		selectColumnSet.add("DEVICE_MAP_ID");

		List<String[]> whereClauseList = new ArrayList<>();
		whereClauseList.add(new String[] { "GROUP_ID", groupId });

		DBServiceResponse dbServiceResponse = inventoryDomainDataServiceImpl.searchInventory("TBL_GROUP",
				selectColumnSet, whereClauseList);

		for (TblRow tblRows : dbServiceResponse.getTableRows()) {
			if (tblRows.getTblRow() != null && tblRows.getTblRow().get("DEVICE_MAP_ID") != null
					&& tblRows.getTblRow().get("DEVICE_MAP_ID").getValue() != null) {
				deviceId = Long.valueOf(tblRows.getTblRow().get("DEVICE_MAP_ID").getValue());
				LOG.info("DEVICE_MAP_ID : {}", deviceId);
				break;
			}
		}

		LOG.info("Exit getDeviceIdFromTrunkId For groupId= {}", groupId);
		return deviceId;
	}

	/**
	 * @param LocationId
	 * @return TrunkGroupId
	 * @throws ApplicationInterfaceException
	 */
	public Long getTrunkGroupIdFromLocationId(String locationId) throws ApplicationInterfaceException {
		LOG.info("Entered getTrunkGroupIdFromLocationId For Location Id = {}", locationId);
		long trunkGroupId = 0;

		Set<String> selectColumnSet = new HashSet<>();
		selectColumnSet.add("GROUP_ID");

		List<String[]> whereClauseList = new ArrayList<>();
		whereClauseList.add(new String[] { "LOCATION_ID", locationId });

		DBServiceResponse dbServiceResponse = inventoryDomainDataServiceImpl.searchInventory("TBL_GROUP",
				selectColumnSet, whereClauseList);

		for (TblRow tblRows : dbServiceResponse.getTableRows()) {
			if (tblRows.getTblRow() != null && tblRows.getTblRow().get("GROUP_ID") != null
					&& tblRows.getTblRow().get("GROUP_ID").getValue() != null) {
				trunkGroupId = Long.valueOf(tblRows.getTblRow().get("GROUP_ID").getValue());
				LOG.info("GROUP_ID : {}", trunkGroupId);
				break;
			}
		}

		LOG.info("Exit getDeviceIdFromTrunkId For groupId= {}", trunkGroupId);
		return trunkGroupId;
	}

	/**
	 * @param timeZoneNrmTzCode
	 * @return
	 * @throws ApplicationInterfaceException
	 */
	public String getTimeZoneId(String timeZoneNrmTzCode) throws ApplicationInterfaceException {
		LOG.info("Entered getTimeZoneId with input Timezone = {}", timeZoneNrmTzCode);
		String timeZoneId = null;

		String nrmTimeZone = null;
		try {
			nrmTimeZone = ESAPI.encoder().encodeForSQL(ORACLE_CODEC, timeZoneNrmTzCode);

		} catch (Exception e) {
			LOG.info("Error While decoding Time zone so defaulting to EST");
			nrmTimeZone = "EST";
		}

		LOG.info("NRM_TZ_CODE --> {}", nrmTimeZone);

		List<String> values = Arrays.asList(nrmTimeZone);
		DBServiceResponse response = inventoryDomainDataServiceImpl
				.executePreconfiguredQuery(ESAPDBQueryEnum.GET_TIMEZONE_ID, "ORDER_MANAGER", values);

		for (TblRow tblRow : response.getTableRows()) {
			if (tblRow.getTblRow().containsKey("TIME_ZONE_ID")) {
				timeZoneId = tblRow.getTblRow().get("TIME_ZONE_ID").getValue();
				LOG.info("TIME_ZONE_ID : {}", tblRow.getTblRow().get("TIME_ZONE_ID").getValue());
			}
		}

		LOG.info("Exit getTimeZoneId = {}", timeZoneId);
		return timeZoneId;
	}

	public TblEnvOrder getTblEnvOrderDetailsFromInventory(String primaryKey, String inventoryTable)
			throws TranslatorException, ApplicationInterfaceException {
		LOG.info("Entered getTblEnvOrderDetailsFromInventory for Inventory Table = {}", inventoryTable);

		HashSet<String> supportedType = new HashSet<>();
		supportedType.add(TranslationConstant.TBL_LOCATION);

		if (!supportedType.contains(inventoryTable))
			throw new TranslatorException(ErrorCode.UNSUPPORTED_TABLE_TYPE, "Unsupported Table Type");

		long tblEnvOrderId = -1;
		TblEnvOrder tblEnvOrder = null;
		DBServiceResponse dbServiceResponse = null;

		if (TranslationConstant.TBL_LOCATION.equalsIgnoreCase(inventoryTable)) {
			Set<String> selectColumnSet = new HashSet<>();
			selectColumnSet.add("ENV_ORDER_ID");

			List<String[]> whereClauseList = new ArrayList<>();
			whereClauseList.add(new String[] { "LOCATION_ID", primaryKey });

			dbServiceResponse = inventoryDomainDataServiceImpl.searchInventory("TBL_LOCATION", selectColumnSet,
					whereClauseList);
		}

		if (dbServiceResponse != null) {
			LOG.info("Got Rows for dbServiceResponse");
			for (TblRow tblRows : dbServiceResponse.getTableRows()) {
				tblEnvOrderId = Long.valueOf(tblRows.getTblRow().get("ENV_ORDER_ID").getValue());

			}
		}

		LOG.info("TblEnvOrder Id : {}", tblEnvOrderId);

		if (tblEnvOrderId != -1)
			tblEnvOrder = customTblEnvOrderMapper.selectByPrimaryKey(tblEnvOrderId);

		LOG.info("Exit getTblEnvOrderDetailsFromInventory");

		return tblEnvOrder;
	}

	public Long getTrunkGroupIdFromLocationId(String locationId, int trunkGroupType)
			throws ApplicationInterfaceException {
		LOG.info("Entered getTrunkGroupIdFromLocationId For Location Id = {} and Trunk Group Type = {}", locationId,
				trunkGroupType);
		long trunkGroupId = 0;

		Set<String> selectColumnSet = new HashSet<>();
		selectColumnSet.add("GROUP_ID");

		List<String[]> whereClauseList = new ArrayList<>();
		whereClauseList.add(new String[] { "LOCATION_ID", locationId });
		whereClauseList.add(new String[] { "GROUP_TYPE", String.valueOf(trunkGroupType) });

		DBServiceResponse dbServiceResponse = inventoryDomainDataServiceImpl.searchInventory("TBL_GROUP",
				selectColumnSet, whereClauseList);

		for (TblRow tblRows : dbServiceResponse.getTableRows()) {
			if (tblRows.getTblRow() != null && tblRows.getTblRow().get("GROUP_ID") != null
					&& tblRows.getTblRow().get("GROUP_ID").getValue() != null) {
				trunkGroupId = Long.valueOf(tblRows.getTblRow().get("GROUP_ID").getValue());
				LOG.info("GROUP_ID : {}", trunkGroupId);
				break;
			}
		}

		LOG.info("Exit getDeviceIdFromTrunkId For groupId= {}", trunkGroupId);
		return trunkGroupId;
	}

	public Map<String, String> getTnAssignmentFromTn(String tn, Map<String, String> resultantRow)
			throws GenericException {

		LOG.info("Entered getTnAssignmentFromTn");
		String subscriberType = null;

		try {

			if (resultantRow == null) {
				resultantRow = new HashMap<>();
			}

			List<String> values = Arrays.asList(tn);
			DBServiceResponse response = inventoryDomainDataServiceImpl
					.executePreconfiguredQuery(ESAPDBQueryEnum.GET_SUBSCRIBER_TYPE_BY_TN, "ORDER_MANAGER", values);

			for (TblRow tblRow : response.getTableRows()) {
				if (tblRow.getTblRow().containsKey("SUBSCRIBER_TYPE")
						&& tblRow.getTblRow().get("SUBSCRIBER_TYPE").getValue() != null) {
					subscriberType = tblRow.getTblRow().get("SUBSCRIBER_TYPE").getValue();
					LOG.info("SUBSCRIBER_TYPE : {}", tblRow.getTblRow().get("SUBSCRIBER_TYPE").getValue());
				}
			}

			if (subscriberType != null) {
				for (SubscriberTnType subTnType : EsapEnum.SubscriberTnType.values()) {
					if (subTnType.getIndex() == Integer.valueOf(subscriberType)) {
						LOG.info("TnAssignment : {}", subTnType.getValue());
						resultantRow.put("TnAssignment", subTnType.getValue());
					}
				}
			}
		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new GenericException(GenericException.GENERIC_EXCEPTION,
					"Exception occured in getTnAssignmentFromTn");
		}

		LOG.info("Exit getTnAssignmentFromTn");
		return resultantRow;
	}

	public Map<String, String> getEslDisconnectMileStoneData(VOIPOrderRequest voipOrderRequest)
			throws GenericException {

		Map<String, String> resultantRow = null;
		LOG.info("Entered getEslDisconnectMileStoneData");

		try {

			resultantRow = new HashMap<>();

			List<String> values = Arrays.asList(voipOrderRequest.getOrderHeader().getVoipLocationId());
			DBServiceResponse response = inventoryDomainDataServiceImpl
					.executePreconfiguredQuery(ESAPDBQueryEnum.GET_CLUSTER_VPN_BY_LOC_ID, "ORDER_MANAGER", values);

			for (TblRow tblRow : response.getTableRows()) {
				if (tblRow.getTblRow().containsKey("NBS_CLUSTER_NAME")
						&& tblRow.getTblRow().get("NBS_CLUSTER_NAME").getValue() != null) {
					resultantRow.put("NBSCluster", tblRow.getTblRow().get("NBS_CLUSTER_NAME").getValue());
					LOG.info("NBSCluster : {}", tblRow.getTblRow().get("NBS_CLUSTER_NAME").getValue());
				}
				if (tblRow.getTblRow().containsKey("VPN_NAME")
						&& tblRow.getTblRow().get("VPN_NAME").getValue() != null) {
					resultantRow.put("VPNName", tblRow.getTblRow().get("VPN_NAME").getValue());
					LOG.info("VPNName : {}", tblRow.getTblRow().get("VPN_NAME").getValue());
				}
			}

			DBServiceResponse srResponse = inventoryDomainDataServiceImpl
					.executePreconfiguredQuery(ESAPDBQueryEnum.GET_SRS_BY_LOC_ID, "ORDER_MANAGER", values);
			int srindex = 1;
			for (TblRow tblRow : srResponse.getTableRows()) {
				if (tblRow.getTblRow().containsKey("SR") && tblRow.getTblRow().get("SR").getValue() != null) {
					resultantRow.put("SR" + String.valueOf(srindex), tblRow.getTblRow().get("SR").getValue());
					LOG.info("SR : {}", tblRow.getTblRow().get("SR").getValue());
					srindex++;
				}
			}

		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new GenericException(GenericException.GENERIC_EXCEPTION,
					"Exception occured in getEslDisconnectMileStoneData");
		}

		LOG.info("Exit getEslDisconnectMileStoneData");
		return resultantRow;
	}

	public String getDialingCountryCode(String locationId, VOIPOrderRequest voipOrderRequest) {
		LOG.info("Entered getDialingCountryCode For Location Id = {}", locationId);
		String countryCode = null;

		Set<String> selectColumnSet = new HashSet<>();
		selectColumnSet.add("DIALING_COUNTRY_CODE");

		List<String[]> whereClauseList = new ArrayList<>();
		whereClauseList.add(new String[] { "LOCATION_ID", locationId });

		try {
			if (locationId != null) {
				DBServiceResponse dbServiceResponse = inventoryDomainDataServiceImpl.searchInventory("TBL_LOCATION",
						selectColumnSet, whereClauseList);
				if (dbServiceResponse != null && dbServiceResponse.getTableRows() != null) {
					for (TblRow tblRows : dbServiceResponse.getTableRows()) {
						if (tblRows.getTblRow() != null && tblRows.getTblRow().get("DIALING_COUNTRY_CODE") != null
								&& tblRows.getTblRow().get("DIALING_COUNTRY_CODE").getValue() != null) {
							countryCode = tblRows.getTblRow().get("DIALING_COUNTRY_CODE").getValue();
							LOG.info("LOCATION_ID : {}", locationId);
							break;
						} // Getting from Request
					}
				}
			}
			if (countryCode == null && voipOrderRequest.getLocation() != null
					&& voipOrderRequest.getLocation().getPrimaryLocationContact() != null) {
				Communication[] communication = voipOrderRequest.getLocation().getPrimaryLocationContact()
						.getCommunication();
				if (communication.length > 0) {
					for (Communication comm : communication) {
						if ("Phone".equalsIgnoreCase(comm.getChannel())) {
							countryCode = comm.getCountryDialing();
							break;
						} // Getting from Request

					}
				}

			}

			if (countryCode == null) {
				countryCode = "1";// Added as default country code after suggested by Lakshmi
			}

		} catch (Exception e) {
			LOG.error("Exception in getDialingCountryCode {} ", e.getMessage());
		}

		LOG.info("Exit getDialingCountryCode For locationId= {}", locationId);
		return countryCode;
	}

}