package com.vz.esap.translation.order.model.request;

public class NBSConfig {

	private String region;

	private String routerStatus;

	private String vpnName;

	private String circuitID;

	private String nbscluster;

	private String ipversion;

	private String ipext28;

	private String ipint32;

	private String sr1;

	private String sr2;

	private String sr3;

	private String sr4;

	private String vlan;

	@Override
	public String toString() {
		return "NBSConfig [Region=" + region + ", NBSCluster=" + nbscluster + ", RouterStatus=" + routerStatus
				+ ", VpnName=" + vpnName + ", IPVersion=" + ipversion + ", IPExt28=" + ipext28 + ", IPInt32=" + ipint32
				+ ", SR1=" + sr1 + ", SR2=" + sr2 + ", SR3=" + sr3 + ", SR4=" + sr4 + ", VLan=" + vlan + ", CircuitID="
				+ circuitID + "]";
	}

	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		region = region;
	}

	public String getNBSCluster() {
		return nbscluster;
	}

	public void setNBSCluster(String nBSCluster) {
		nbscluster = nBSCluster;
	}

	public String getRouterStatus() {
		return routerStatus;
	}

	public void setRouterStatus(String routerStatus) {
		routerStatus = routerStatus;
	}

	public String getVpnName() {
		return vpnName;
	}

	public void setVpnName(String vpnName) {
		vpnName = vpnName;
	}

	public String getIPVersion() {
		return ipversion;
	}

	public void setIPVersion(String iPVersion) {
		ipversion = iPVersion;
	}

	public String getIPExt28() {
		return ipext28;
	}

	public void setIPExt28(String iPExt28) {
		ipext28 = iPExt28;
	}

	public String getIPInt32() {
		return ipint32;
	}

	public void setIPInt32(String iPInt32) {
		ipint32 = iPInt32;
	}

	public String getSR1() {
		return sr1;
	}

	public void setSR1(String sR1) {
		sr1 = sR1;
	}

	public String getSR2() {
		return sr2;
	}

	public void setSR2(String sR2) {
		sr2 = sR2;
	}

	public String getSR3() {
		return sr3;
	}

	public void setSR3(String sR3) {
		sr3 = sR3;
	}

	public String getSR4() {
		return sr4;
	}

	public void setSR4(String sR4) {
		sr4 = sR4;
	}

	public String getVLan() {
		return vlan;
	}

	public void setVLan(String vLan) {
		vlan = vLan;
	}

	public String getCircuitID() {
		return circuitID;
	}

	public void setCircuitID(String circuitID) {
		circuitID = circuitID;
	}

}
