package com.vz.esap.translation.order.service.trunk;

import java.util.List;

import com.vz.esap.translation.dao.model.TblEnvOrder;
import com.vz.esap.translation.dao.model.TblOrder;
import com.vz.esap.translation.dao.model.TblOrderDetails;
import com.vz.esap.translation.exception.GenericException;
import com.vz.esap.translation.order.model.request.VOIPOrderRequest;
import com.vz.esap.translation.order.model.response.VoipOrderResponse;

/**
 * @author kalagsu
 *
 */
public interface TrunkOrderService {
	/**
	 * @param tblOrderDetails
	 * @param tblOrderBeanValidation
	 * @param tblEnvOrder
	 * @param voipOrderRequest
	 * @param tblOrderDetailsList
	 * @return voipOrderResponse
	 * @throws GenericException
	 */
	VoipOrderResponse processReleaseOrder(TblOrderDetails tblOrderDetails, TblOrder tblOrderBeanValidation,
			TblEnvOrder tblEnvOrder, VOIPOrderRequest voipOrderRequest, List<TblOrderDetails> tblOrderDetailsList) throws GenericException;

}
