package com.vz.esap.translation.entity;

import java.util.ArrayList;
import java.util.List;



/**
 * This class forms the new Data Structure ( since July'11 ) for  
 * Gateway DeviceEntity SBC Provisioning related details transfer.
 * This class will closely match the TOD structure of SBC Order.
 * Note: Details persistent to the Gateway DeviceEntity itself such as 
 * CPE_IP may not be represented here.  
 */
public class GatewayDeviceSBCDetail {
    private Integer sbcIndex = Integer.valueOf( 1 ); 
    private String sbcCLLI;
    private String sbcShortName;
    private String primarySbcShortName; //Use this to populate oldSBCNodeName in DNS records
    private SbcSigTier sbcSigTier;
    private List<SBCSignalingInterfaceDetail> sbcSignalingInterfaceDetailList;
	public Integer getSbcIndex() {
		return sbcIndex;
	}
	public void setSbcIndex(Integer sbcIndex) {
		this.sbcIndex = sbcIndex;
	}
	public String getSbcCLLI() {
		return sbcCLLI;
	}
	public void setSbcCLLI(String sbcCLLI) {
		this.sbcCLLI = sbcCLLI;
	}
	public String getSbcShortName() {
		return sbcShortName;
	}
	public void setSbcShortName(String sbcShortName) {
		this.sbcShortName = sbcShortName;
	}
	public String getPrimarySbcShortName() {
		return primarySbcShortName;
	}
	public void setPrimarySbcShortName(String primarySbcShortName) {
		this.primarySbcShortName = primarySbcShortName;
	}
	public SbcSigTier getSbcSigTier() {
		return sbcSigTier;
	}
	public void setSbcSigTier(SbcSigTier sbcSigTier) {
		this.sbcSigTier = sbcSigTier;
	}
	public List<SBCSignalingInterfaceDetail> getSbcSignalingInterfaceDetailList() {
		return sbcSignalingInterfaceDetailList;
	}
	public void setSbcSignalingInterfaceDetailList(List<SBCSignalingInterfaceDetail> sbcSignalingInterfaceDetailList) {
		this.sbcSignalingInterfaceDetailList = sbcSignalingInterfaceDetailList;
	}
    
    public void addToSbcSignalingInterfaceDetailList( SBCSignalingInterfaceDetail sbcSignalingInterfaceDetail ) {
        if( sbcSignalingInterfaceDetailList == null)
        	sbcSignalingInterfaceDetailList = new ArrayList<SBCSignalingInterfaceDetail>();
        
        sbcSignalingInterfaceDetailList.add(sbcSignalingInterfaceDetail);
    }
    
}
