package com.vz.esap.translation.order.service.device;

import java.util.Arrays;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.vz.esap.translation.dao.model.TblEnvOrder;
import com.vz.esap.translation.dao.model.TblOrder;
import com.vz.esap.translation.dao.model.TblOrderDetails;
import com.vz.esap.translation.dao.model.TblOrderService;
import com.vz.esap.translation.entity.DeviceEntity;
import com.vz.esap.translation.entity.OrderManagerContactInfoEntity;
import com.vz.esap.translation.enums.EsapEnum;
import com.vz.esap.translation.enums.EsapEnum.FlowPath;
import com.vz.esap.translation.enums.EsapEnum.OrderEntity;
import com.vz.esap.translation.exception.GenericException;
import com.vz.esap.translation.exception.TranslatorException;
import com.vz.esap.translation.order.dao.VOIPOrderDao;
import com.vz.esap.translation.order.model.Order;
import com.vz.esap.translation.order.model.OrderHeader;
import com.vz.esap.translation.order.model.OrderHeader.SuppType;
import com.vz.esap.translation.order.model.request.ParamInfo;
import com.vz.esap.translation.order.model.request.VOIPOrderRequest;
import com.vz.esap.translation.order.model.response.VoipOrderResponse;
import com.vz.esap.translation.order.parser.OrderParser;
import com.vz.esap.translation.order.service.OrderServiceBase;
import com.vz.esap.translation.order.service.VOIPResponseGenerator;
import com.vz.esap.translation.order.service.helper.OrderServiceHelperImpl;
import com.vz.esap.translation.order.transformer.DeviceTblOrderDetailsDataTransformer;
import com.vz.esap.translation.order.transformer.DeviceTransformer;
import com.vz.esap.translation.order.transformer.EnterpriseTblOrderDataTransformer;
import com.vz.esap.translation.order.transformer.EnterpriseTblOrderServiceDataTransformer;
import com.vz.esap.translation.order.transformer.OrderManagerContactInfoTransformer;

import EsapEnumPkg.WorkOrderEnum;

import org.springframework.util.CollectionUtils;

/**
 * @author kalagsu
 *
 */
@Service
public class DeviceOrderServiceImpl extends OrderServiceBase implements DeviceOrderService {

	private static final Logger LOG = LoggerFactory.getLogger(DeviceOrderServiceImpl.class);

	@Autowired
	private DeviceTransformer deviceTransformer;

	@Autowired
	private VOIPOrderDao voipOrderDao;

	@Autowired
	private EnterpriseTblOrderServiceDataTransformer enterpriseTblOrderServiceData;

	@Autowired
	private EnterpriseTblOrderDataTransformer enterpriseTblOrderData;

	@Autowired
	private OrderManagerContactInfoTransformer orderManagerContactInfoTransformer;

	@Autowired
	private VOIPResponseGenerator voipResponseGenerator;

	@Autowired
	private DeviceTblOrderDetailsDataTransformer deviceTblOrderDetailsDataTransformerImpl;

	@Autowired
	private OrderServiceHelperImpl orderServiceHelperImpl;

	@Autowired
	private OrderParser orderParserImpl;

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.vz.esap.translation.order.service.device.DeviceOrderService#
	 * processReleaseOrder(com.vz.esap.translation.dao.model.TblOrderDetails,
	 * com.vz.esap.translation.dao.model.TblOrder,
	 * com.vz.esap.translation.dao.model.TblEnvOrder,
	 * com.vz.esap.translation.order.model.request.VOIPOrderRequest, java.util.List)
	 */
	@Override
	public VoipOrderResponse processReleaseOrder(TblOrderDetails tblOrderDetails, TblOrder tblOrderBeanValidation,
			TblEnvOrder tblEnvOrder, VOIPOrderRequest voipOrderRequest, List<TblOrderDetails> tblOrderDetailsList)
			throws TranslatorException, GenericException {
		LOG.info("Entered - processReleaseOrder");

		VoipOrderResponse voipOrderResponse = null;
		DeviceEntity deviceEntity = null;
		OrderHeader orderHeader = null;
		List<TblEnvOrder> tblEnvOrderListPrev = null;
		List<TblOrder> tblOrderListPrev = null;
		List<TblOrderDetails> tblOrderDetailsListPrev = null;
		DeviceEntity deviceEntityPrev = null;
		boolean isNewDevice;

		try {
			if ("C".equalsIgnoreCase(voipOrderRequest.getOrderHeader().getOrderType())) {
				LOG.info("Inside Device Change");
				//This will fetch n,r
				deviceEntity = deviceTransformer.transformOrderDetailsToDevice(tblOrderBeanValidation.getOrderId(),
						tblOrderDetails.getOrderDetailId(), null, false, Arrays.asList("o"));

				//This will fetch o,r
				deviceEntityPrev = deviceTransformer.transformOrderDetailsToDevice(tblOrderBeanValidation.getOrderId(),
						tblOrderDetails.getOrderDetailId(), null, false, Arrays.asList("n"));
				
				//This will fetch if there is any TOD with n
				isNewDevice = orderServiceHelperImpl.isNewEntityChangeOrder(tblOrderBeanValidation.getOrderId(),
						tblOrderDetails.getOrderDetailId());
				
				LOG.info("Device Id = {} Is New Device Entity = {}", deviceEntity.getDeviceMapId(), isNewDevice);
				
				deviceEntity.setNewDevice(isNewDevice);

			} else {
				deviceEntity = deviceTransformer.transformOrderDetailsToDevice(tblOrderBeanValidation.getOrderId(),
						tblOrderDetails.getOrderDetailId(), "n", false, null);
			}

			if (deviceEntity == null) {
				deviceEntity = new DeviceEntity();
			}
			LOG.info("DeviceEntity : {} ", deviceEntity);
			// SUPP changes...
			int orderVersion = Integer.parseInt(voipOrderRequest.getOrderHeader().getWorkOrderVersion());
			LOG.info("Order version:: {}", orderVersion);
			
			if (orderVersion > 0) {

				VOIPOrderRequest voipOrderRequestPrev = orderParserImpl.getCorrectPrevPassVoipOrderRequest(voipOrderRequest);
				
				LOG.info("SUPP Order version:: {}", voipOrderRequestPrev.getOrderHeader().getWorkOrderVersion());
				
				//voipOrderRequestPrev.getOrderHeader().setWorkOrderVersion(Integer.toString(orderVersion - 1));
				tblEnvOrderListPrev = orderServiceHelperImpl.getMatchingPrevPassEnvOrder(voipOrderRequestPrev, 0,
						WorkOrderEnum.OrderClassify.RELEASE);
				
				LOG.info("Env table records size::{}", tblEnvOrderListPrev.size());
				LOG.info("ENV ORDER ID PREV::{}", tblEnvOrderListPrev.get(0).getEnvOrderId());
				
				tblOrderListPrev = orderServiceHelperImpl.getMatchingPrevPassOrder(tblEnvOrderListPrev.get(0),
						OrderEntity.DEVICE, deviceEntity.getDeviceId()); 

				
				if(!CollectionUtils.isEmpty(tblOrderListPrev)) {
					LOG.info("TBL_ORDER records size::{}", tblOrderListPrev.size());
					LOG.info("TBL ORDER ID::{}", tblOrderListPrev.get(0).getOrderId());


					for (TblOrder tblOrderPrev : tblOrderListPrev) {
						if (tblOrderPrev.getAccountNumber().equalsIgnoreCase(deviceEntity.getBwDeviceId())) {
							tblOrderDetailsListPrev = orderServiceHelperImpl.getMatchingOrderDetails(tblOrderPrev);
							LOG.info("TBL_ORDER_DETAILS records size::{}", tblOrderDetailsListPrev.size());
						}
					}					
				}
				

				if (tblOrderDetailsListPrev!=null && !CollectionUtils.isEmpty(tblOrderDetailsListPrev)
						&& "Device".equalsIgnoreCase(tblOrderDetailsListPrev.get(0).getParamName())) {
					
					LOG.info("Previous Table Order Id::{}", tblOrderListPrev.get(0).getOrderId());
					LOG.info("Previous Table Order Details Id::{}", tblOrderDetailsListPrev.get(0).getOrderDetailId());
					
					deviceEntityPrev = deviceTransformer.transformOrderDetailsToDevice(
							tblOrderDetailsListPrev.get(0).getOrderId(), tblOrderDetailsListPrev.get(0).getOrderDetailId(),
							"n", false, null);
					
					//Fix for Supp dueDate Scenario which is missing IB Trunk Data - Start
					deviceEntity.setDeviceMapId(deviceEntityPrev.getDeviceMapId());
					deviceEntity.setDeviceSeqId(deviceEntityPrev.getDeviceMapId());
					
					//Fix for Supp dueDate Scenario which is missing IB Trunk Data - End
					
					deviceEntityPrev.setEnvOrderId(tblEnvOrderListPrev.get(0).getEnvOrderId());
					deviceEntityPrev.setInteralOrderId(tblOrderDetailsListPrev.get(0).getOrderId());
					
					LOG.info("deviceEntityPrev::{}::{}", deviceEntityPrev.getDeviceId(),
							deviceEntityPrev.getDeviceName());
					LOG.info("deviceEntity::{}::{}", deviceEntity.getDeviceId(), deviceEntity.getDeviceName());
				}

				if (voipOrderRequest.getOrderHeader().getSuppType().equals(SuppType.CANCEL.toString()))
					voipOrderRequest.getOrderHeader().setSuppType(SuppType.CANCEL.toString());
				else
					voipOrderRequest.getOrderHeader().setSuppType(SuppType.SUPP.toString());
			}

			orderHeader = createdOrderHeaderForDeviceOrder(voipOrderRequest, deviceEntity);
			createReleaseOrders(orderHeader, deviceEntity, deviceEntityPrev, tblOrderDetailsList,
					tblOrderBeanValidation, WorkOrderEnum.Status.WO_INIT, tblEnvOrder);

			voipOrderResponse = voipResponseGenerator.prepareSuccessOrderResponse(voipOrderRequest);

		} catch (TranslatorException ex) {
			LOG.error("Exception {} ", ex);
			throw new TranslatorException(ex.getErrorCode(), ex.getMessage());
		} catch (Exception e) {
			LOG.error("Exception {} ", e);
			throw new GenericException(GenericException.GENERIC_EXCEPTION, "Exception in the provide input arguments");
		}

		LOG.info("Exit - processReleaseOrder");
		return voipOrderResponse;

	}

	/**
	 * @param orderHeader
	 * @param deviceEntity
	 * @param deviceEntityPrev
	 * @param tblOrderDetailsList
	 * @param tblOrderBeanValidation
	 * @param status
	 * @param tblEnvOrderObject
	 * @return isCreated
	 * @throws TranslatorException
	 * @throws GenericException
	 */
	boolean createReleaseOrders(OrderHeader orderHeader, DeviceEntity deviceEntity, DeviceEntity deviceEntityPrev,
			List<TblOrderDetails> tblOrderDetailsList, TblOrder tblOrderBeanValidation, int status,
			TblEnvOrder tblEnvOrderObject) throws TranslatorException, GenericException {
		LOG.info("Entered - createReleaseOrders");
		boolean isCreated = true;
		Order order = null;
		Order orderPrevPass = null;
		OrderManagerContactInfoEntity cnctInfo = null;
		TblOrder tblOrderObject = null;
		List<TblOrderService> tblOrderServiceList = null;
		boolean hasChange = false;
		ParamInfo headerParamInfo = null;
		ParamInfo entityParamInfo = null;

		try {
			order = new Order();

			orderHeader.setOrderStatus(status);
			order.setOrderHeader(orderHeader);

			if (deviceEntity == null) {
				deviceEntity = new DeviceEntity();
			}

			// :create order
			LOG.info("createOrders start creating Device entity orders");
			cnctInfo = orderManagerContactInfoTransformer
					.transformValEnvOrderToOrdMgrContactInfo(tblEnvOrderObject.getEnvOrderId(), null);

			if (cnctInfo != null)
				orderHeader.setOrdMgrContactInfo(cnctInfo);
			if (null != tblEnvOrderObject.getEnvOrderId())
				orderHeader.setEnvOrderId(tblEnvOrderObject.getEnvOrderId());
			if (null != tblEnvOrderObject.getProjectId())
				orderHeader.setProjectId(tblEnvOrderObject.getProjectId());
			orderHeader.setEnvOrderId(tblEnvOrderObject.getEnvOrderId());
			orderHeader.setProjectId(tblEnvOrderObject.getProjectId());
			orderHeader.setCustomerId(tblEnvOrderObject.getEnterpriseId());
			orderHeader.setEnterpriseId(tblEnvOrderObject.getEnterpriseId());
			orderHeader.setLocationId(tblEnvOrderObject.getLocationId());

			order.setOrderHeader(orderHeader);
			
			deviceEntity.setCustomerId(tblEnvOrderObject.getEnterpriseId());
			order.setDeviceEntity(deviceEntity);
			
			
			LOG.info("Device orderHeader.getEntityAction() = {}", orderHeader.getEntityAction());
			
			if ("I".equalsIgnoreCase(orderHeader.getEntityAction())) {
				if (deviceEntityPrev != null) {
					LOG.info("deviceEntityPrev is not null");

					deviceEntityPrev.setCustomerId(tblEnvOrderObject.getEnterpriseId());
					
					headerParamInfo = deviceTblOrderDetailsDataTransformerImpl
							.prepareTblOrderDetailsHeaderParamData(order, deviceEntityPrev, true);
					entityParamInfo = deviceTblOrderDetailsDataTransformerImpl
							.prepareTblOrderDetailsEntityParamDataForDevice(deviceEntityPrev, deviceEntity, true, null);

					if (entityParamInfo != null && entityParamInfo.getAction() != null
							&& "C".equals(entityParamInfo.getAction())) {
						hasChange = true;
						orderHeader.setEntityAction("C"); 
						
						entityParamInfo.addNotNullValChild("DEV_LOGICAL_CHANGE", "N", "n");
						entityParamInfo.addNotNullValChild("DEV_INV_CHANGE", "Y", "n");
						
					} else if (entityParamInfo != null && entityParamInfo.getAction() != null
							&& entityParamInfo.getAction().equals("NC")) {
						LOG.info("entityParamInfo.getAction(): {}", entityParamInfo.getAction());
						hasChange = false;
						orderHeader.setEntityAction("NC");
					}
				} else {

					headerParamInfo = deviceTblOrderDetailsDataTransformerImpl
							.prepareTblOrderDetailsHeaderParamData(order);
					entityParamInfo = deviceTblOrderDetailsDataTransformerImpl
							.prepareTblOrderDetailsEntityParamDataForDevice(order, null);
					headerParamInfo = orderServiceHelperImpl.updateParamInfoForLocationid(tblEnvOrderObject.getEnvOrderId(),headerParamInfo,orderHeader);
					
					LOG.info("entityParamInfo.getAction(): {}", entityParamInfo.getAction());
				}
			} else if ("C".equalsIgnoreCase(orderHeader.getEntityAction())) {
				LOG.info("Inside createReleaseOrders For Device Change");
				if (deviceEntityPrev != null) {
					LOG.info("deviceEntityPrev is not null");

					headerParamInfo = deviceTblOrderDetailsDataTransformerImpl
							.prepareTblOrderDetailsHeaderParamData(order, deviceEntityPrev, true);
					entityParamInfo = deviceTblOrderDetailsDataTransformerImpl
							.prepareTblOrderDetailsEntityParamDataForDevice(deviceEntityPrev, deviceEntity, true, null);

					LOG.info("entityParamInfo.getAction() For Device: {}", entityParamInfo.getAction());
					
					
					if(deviceEntity.isNewDevice()) {
						LOG.info("Device is New Install For MAC Order Device Id = {}", deviceEntity.getDeviceMapId());
						orderHeader.setEntityAction("I");
						entityParamInfo.setAction("n");
						
					} else {
						if (entityParamInfo != null && entityParamInfo.getAction() != null
								&& "C".equals(entityParamInfo.getAction())) {
							hasChange = true;
							orderHeader.setEntityAction("C"); 
							
							entityParamInfo.addNotNullValChild("DEV_LOGICAL_CHANGE", "N", "n");
							entityParamInfo.addNotNullValChild("DEV_INV_CHANGE", "Y", "n");
							
						} else if (entityParamInfo != null && entityParamInfo.getAction() != null
								&& entityParamInfo.getAction().equals("NC")) {
							LOG.info("entityParamInfo.getAction(): {}", entityParamInfo.getAction());
							hasChange = false;
							orderHeader.setEntityAction("NC");
							
						}
					}
				}				
			}
			LOG.info("orderHeader.getEntityAction()-Device :{} For Device Id = {} ", orderHeader.getEntityAction(),
					deviceEntity.getDeviceMapId());
			if (headerParamInfo != null && !"NC".equalsIgnoreCase(orderHeader.getEntityAction())) {
				headerParamInfo.addChildParam(entityParamInfo);
				
				// :create order
				tblOrderObject = enterpriseTblOrderData.prepareTblOrderDataFromOrder(order, 4L);
				voipOrderDao.createTblOrder(tblOrderObject);

				LOG.info("Tbl_Order Created for Device , Order Id : {}", tblOrderObject.getOrderId());

				// :create order Details
				LOG.info("createOrders start creating device entity order details");
				
				LOG.info("hasChange {}", hasChange);

				if (entityParamInfo != null && entityParamInfo.getAction() != null)
					voipOrderDao.populateOrderDetails(tblOrderObject, headerParamInfo.getChildParams(),
							entityParamInfo.getAction(), 0, 0);
				else
					voipOrderDao.populateOrderDetails(tblOrderObject, headerParamInfo.getChildParams(), "n", 0, 0);
				
				// :create service entry for WF
				LOG.info("createOrders start creating service for device entity");
				orderHeader.setFlowPath(FlowPath.valueOf(tblOrderObject.getFlowPath()));
				orderHeader.setTblOrderId(tblOrderObject.getOrderId());
				orderHeader.setEntityType(EsapEnum.OrderEntity.DEVICE.getIndex());
				orderHeader.setProvisionCategory(deviceEntity.getProvisionCategory());
				
				order.setOrderHeader(orderHeader);

				// refactor prepareTblOrderServiceData to pass orderPrevPass
				orderPrevPass = new Order();
				orderPrevPass.setOrderHeader(orderHeader);// TODO add previous pass order header
				orderPrevPass.setDeviceEntity(deviceEntityPrev);
				tblOrderServiceList = enterpriseTblOrderServiceData.prepareTblOrderServiceData(order, orderPrevPass,
						null);

				LOG.info("Retail Order Service Count : {}", tblOrderServiceList.size());

				for (TblOrderService tblOrderService : tblOrderServiceList) {
					voipOrderDao.createTblOrderService(tblOrderService);
				}

				voipOrderDao.updateTblOrderStatus(tblOrderObject.getOrderId(), WorkOrderEnum.Status.WO_INIT);
				
			} else if (deviceEntityPrev != null && "NC".equalsIgnoreCase(orderHeader.getEntityAction())) {

				LOG.info("deviceEntityPrev != null && \"NC\".equalsIgnoreCase(orderHeader.getEntityAction())");
				LOG.info("Order Version ==>> {}", orderHeader.getOrderVersion());
				
				int orderVersion = Integer.parseInt(orderHeader.getOrderVersion());
				
				if(orderVersion > 0) {
				orderServiceHelperImpl.handleSuppOrderWithNoChange(tblEnvOrderObject.getEnvOrderId(),
						deviceEntityPrev.getInteralOrderId(), tblEnvOrderObject);
				
				} else {
					
					LOG.info("This is MAC Device Scenario of Do Nothing");
				}
			}
				
		} catch (TranslatorException ex) {
			LOG.error("Exception {} ", ex);
			throw new TranslatorException(ex.getErrorCode(), ex.getMessage());
		} catch (Exception e) {
			LOG.error("Exception {} ", e);
			throw new GenericException(GenericException.GENERIC_EXCEPTION, "Exception in the provide input arguments");
		}
		LOG.info("Exit - createReleaseOrders");
		return isCreated;
	}

}
