package com.vz.esap.translation.order.parser;

import static java.util.Arrays.stream;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.vz.esap.translation.entity.EnterpriseTrunkEntity;
import com.vz.esap.translation.enums.EsapEnum;
import com.vz.esap.translation.enums.EsapEnum.ChangeType;
import com.vz.esap.translation.exception.TranslatorException;
import com.vz.esap.translation.order.model.request.ChangeManagement;
import com.vz.esap.translation.order.model.request.ChangedElement;
import com.vz.esap.translation.order.model.request.Feature;
import com.vz.esap.translation.order.model.request.Specification;
import com.vz.esap.translation.order.model.request.VOIPOrderRequest;

/**
 * @author chattni
 *
 */
@Component
public class EnterpriseTrunkOrderParserImpl implements EnterpriseTrunkOrderParser {
	private static final Logger LOG = LoggerFactory.getLogger(EnterpriseTrunkOrderParserImpl.class);

	private ObjectMapper mapper = new ObjectMapper();

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.vz.esap.translation.order.parser.EnterpriseTrunkOrderParser#
	 * parseEnterpriseTrunkOrder(com.vz.esap.translation.order.model.request.
	 * VOIPOrderRequest)
	 */
	@Override
	public List<EnterpriseTrunkEntity> parseEnterpriseTrunkOrder(VOIPOrderRequest voipOrderRequest)
			throws TranslatorException, ParseException, JsonProcessingException {

		LOG.info("Entered - parseEnterpriseTrunkOrder");
		EnterpriseTrunkEntity enterpriseTrunk = null;
		List<EnterpriseTrunkEntity> enterpriseTrunkList = null;
		List<Feature> features = null;
		String signalingDirection = null;

		try {

			features = stream(voipOrderRequest.getConvergedService().getFeature())
					.filter(feature -> "EFET_VOIP_ENT_TRUNK".equalsIgnoreCase(feature.getCode()))
					.collect(Collectors.toList());
			if (features.isEmpty()) {
				throw new TranslatorException(TranslatorException.ErrorCode.INVALID_XML,
						"No Feature Found in XML");
			}

			LOG.debug("ET FEATURE : {}", mapper.writerWithDefaultPrettyPrinter().writeValueAsString(features));

			enterpriseTrunkList = new ArrayList<>();

			for (Feature etFeature : features) {
				
				LOG.debug("ET SPECIFICATION : ",
						mapper.writerWithDefaultPrettyPrinter().writeValueAsString(etFeature.getSpecification()));

				enterpriseTrunk = new EnterpriseTrunkEntity();
				enterpriseTrunk.setAsClli(voipOrderRequest.getOrderHeader().getAsClli()); //add broadsoft clli.
				enterpriseTrunk.setCustomerId(voipOrderRequest.getOrderHeader().getEnterpriseId());
				enterpriseTrunk.setEnterpriseTrunkId(Long.valueOf(etFeature.getInstanceId()));
				
				if (voipOrderRequest.getOrderHeader().getSolutionType() != null)
					enterpriseTrunk.setSolutionType(voipOrderRequest.getOrderHeader().getSolutionType());

				for (Specification spec : etFeature.getSpecification()) {
					if ("ESP_ENT_TRUNK_NAME".equalsIgnoreCase(spec.getCode()))
						enterpriseTrunk.setEnterpriseTrunkName(spec.getValue());
					if ("ESP_MAX_REROUTE_ATMPT_PRTY".equalsIgnoreCase(spec.getCode()))
						enterpriseTrunk.setMaxRerouteAttemptsPriority(Integer.parseInt(spec.getValue()));
					if ("ESP_MAX_REROUTE_ATMPT_ET".equalsIgnoreCase(spec.getCode()))
						enterpriseTrunk.setMaxRerouteAttempts(Integer.parseInt(spec.getValue()));
					
					if ("SP_XO_SIG".equalsIgnoreCase(spec.getCode())) {
						if (EsapEnum.SignalingDirection.TWO_WAY.toString().equalsIgnoreCase(spec.getValue()))
							signalingDirection = EsapEnum.SignalingDirection.TWO_WAY.toString();
						if (EsapEnum.SignalingDirection.INBOUND.toString().equalsIgnoreCase(spec.getValue()))
							signalingDirection = EsapEnum.SignalingDirection.INBOUND.toString();
						enterpriseTrunk.setSignalDirection(signalingDirection);
					}
					if ("BW_ET_ID".equalsIgnoreCase(spec.getCode()))
						enterpriseTrunk.setBwEtId(spec.getValue());
					if ("BW_ENTERPRISE_ID".equalsIgnoreCase(spec.getCode()))
						enterpriseTrunk.setBwEntId(spec.getValue());
					if ("ENTERPRISE_ID".equalsIgnoreCase(spec.getCode()))
						enterpriseTrunk.setEnterpriseId(spec.getValue());
					if ("ENTERPRISE_SERVICE_LOCATION_ID".equalsIgnoreCase(spec.getCode()))
						enterpriseTrunk.setLocationId(spec.getValue());
					if ("BW_TG_ID".equalsIgnoreCase(spec.getCode()))
						enterpriseTrunk.setBwTrunkGroupId(spec.getValue());
					if ("ESL_REDUNDANCY".equalsIgnoreCase(spec.getCode()))
						enterpriseTrunk.setRedundancy(spec.getValue());
					if ("ESL_REDUNDANCY_PRIORITY_TYPE".equalsIgnoreCase(spec.getCode())) {						
						enterpriseTrunk.setRedundancyPriorityType(spec.getValue());
					}						
				}
				
				if (voipOrderRequest.getLocation() != null && voipOrderRequest.getLocation().getLocationAddress() != null
						&& voipOrderRequest.getLocation().getLocationAddress().getCountryCode() != null)
					enterpriseTrunk.setRegion(voipOrderRequest.getLocation().getLocationAddress().getCountryCode());
				
				if ("C".equalsIgnoreCase(voipOrderRequest.getOrderHeader().getOrderType())) {
					LOG.info("etFeature.getActionCode() --> {}", etFeature.getActionCode());
					if ("ADD".equalsIgnoreCase(etFeature.getActionCode())) {
						LOG.info("Enterprise Trunk Instance Id Included In ADDED Trunk Change Management = {}",
								etFeature.getInstanceId());
						// Do Nothing						
					} else {
						LOG.info("Enterprise Trunk Instance Id NOT Included In Trunk Change Management = {}",
								etFeature.getInstanceId());

						EnterpriseTrunkEntity changeEnterpriseTrunk = parseEnterpriseTrunkChangeOrder(voipOrderRequest);
						enterpriseTrunk.setEnterpriseTrunkEntity(changeEnterpriseTrunk);
					}
				}
				
				enterpriseTrunkList.add(enterpriseTrunk);
			}
		} catch (TranslatorException ex) {
			LOG.error("Exception {} ", ex.getMessage());
			throw new TranslatorException(ex.getErrorCode(), ex.getMessage());
		}

		LOG.info("Exit - parseEnterpriseTrunkOrder");
		return enterpriseTrunkList;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.vz.esap.translation.order.parser.TrunkOrderParser#parseEnterpriseTrunkChangeOrder(com.vz.
	 * esap.translation.order.model.request.VOIPOrderRequest)
	 */
	public EnterpriseTrunkEntity parseEnterpriseTrunkChangeOrder(VOIPOrderRequest voipOrderRequest) throws TranslatorException{

		LOG.info("Entered - parseEnterpriseTrunkChangeOrder");
		
		ChangeManagement[] changeManagements = voipOrderRequest.getChangeManagement();

		if (changeManagements == null) {
			// TODO: Logic for the ADD
			return null;
		}

		EnterpriseTrunkEntity chanceEnterpriseTrunk = new EnterpriseTrunkEntity();
		chanceEnterpriseTrunk.setLocationId(voipOrderRequest.getConvergedService().getID());

		for (ChangeManagement changeManagement : changeManagements) {

			ChangedElement[] changeElements = changeManagement.getChangedElement();

			if (changeElements != null && changeElements.length > 0) {
				for (ChangedElement changedElement : changeElements) {
					
					List<Feature> entTrunkFeature = stream(voipOrderRequest.getConvergedService().getFeature())
							.filter(feature -> "EFET_VOIP_ENT_TRUNK".equalsIgnoreCase(feature.getCode()))
							.collect(Collectors.toList());


					if (!entTrunkFeature.isEmpty() && entTrunkFeature.get(0).getCode().equalsIgnoreCase(changedElement.getFeatureCode()) && entTrunkFeature
							.get(0).getInstanceId().equalsIgnoreCase(changedElement.getFeatureInstanceId())) {

						if (changedElement.getChangeType() != null
								&& ChangeType.CHANGED.toString().equalsIgnoreCase(changedElement.getChangeType())
								&& changedElement.getSpecificationCode() != null) {

							createChangedEnterpriseTrunkEntity(chanceEnterpriseTrunk, changedElement.getSpecificationCode(),
									changedElement.getNewValue());

						}

					} 
				}
			}
		}

		LOG.info("Exited - parseEnterpriseTrunkChangeOrder");
		return chanceEnterpriseTrunk;
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.vz.esap.translation.order.parser.TrunkOrderParser#createChangedEnterpriseTrunkEntity(com.vz.
	 * esap.translation.order.model.request.VOIPOrderRequest)
	 */

	public void createChangedEnterpriseTrunkEntity(EnterpriseTrunkEntity chanceEnterpriseTrunk, String specCode, String specValue) throws TranslatorException{
		String signalingDirection = null;
		LOG.info("Entered - createchanceEnterpriseTrunkEntity");

		if (chanceEnterpriseTrunk == null) {
			chanceEnterpriseTrunk = new EnterpriseTrunkEntity();
		}

		if ("ESP_ENT_TRUNK_NAME".equalsIgnoreCase(specCode)) {
			chanceEnterpriseTrunk.setEnterpriseTrunkName(specValue);
		}
		if ("ESP_MAX_REROUTE_ATMPT_PRTY".equalsIgnoreCase(specCode)) {
			chanceEnterpriseTrunk.setMaxRerouteAttemptsPriority(Integer.parseInt(specValue));
		}
		if ("ESP_MAX_REROUTE_ATMPT_ET".equalsIgnoreCase(specCode)) {
			chanceEnterpriseTrunk.setMaxRerouteAttempts(Integer.parseInt(specValue));
		}
		if ("SP_XO_SIG".equalsIgnoreCase(specCode)) {
			if (EsapEnum.SignalingDirection.TWO_WAY.toString().equalsIgnoreCase(specValue))
				signalingDirection = EsapEnum.SignalingDirection.TWO_WAY.toString();
			if (EsapEnum.SignalingDirection.INBOUND.toString().equalsIgnoreCase(specValue))
				signalingDirection = EsapEnum.SignalingDirection.INBOUND.toString();
			chanceEnterpriseTrunk.setSignalDirection(signalingDirection);
		}
		if ("BW_ET_ID".equalsIgnoreCase(specCode)) {
			chanceEnterpriseTrunk.setBwEtId(specValue);
		}
		if ("BW_ENTERPRISE_ID".equalsIgnoreCase(specCode)) { 
			chanceEnterpriseTrunk.setBwEntId(specValue);
		}
		if ("ENTERPRISE_ID".equalsIgnoreCase(specCode)) {
			chanceEnterpriseTrunk.setEnterpriseId(specValue);
		}
		if ("ENTERPRISE_SERVICE_LOCATION_ID".equalsIgnoreCase(specCode)) {
			chanceEnterpriseTrunk.setLocationId(specValue);
		}
		if ("BW_TG_ID".equalsIgnoreCase(specCode)) {
			chanceEnterpriseTrunk.setBwTrunkGroupId(specValue);
		}
		if ("ESL_REDUNDANCY".equalsIgnoreCase(specCode)) {
			chanceEnterpriseTrunk.setRedundancy(specValue);
		}
		if ("ESL_REDUNDANCY_PRIORITY_TYPE".equalsIgnoreCase(specCode)) {
			chanceEnterpriseTrunk.setRedundancyPriorityType(specValue);
		}
		
		//not creating the createChangedSessionEntity method as "No Spec items" and session attribute is not exists in TrunkGroupEntity - Need confirmation..
		LOG.info("Exited - createchanceTrunkGroupEntity");
	}
}
