package com.vz.esap.translation.order.model.pc;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;

import com.fasterxml.jackson.annotation.JsonProperty;

@XmlAccessorType(XmlAccessType.FIELD)
public class ChangeManagement {
	
	@XmlElement(name = "ChangedElement")
	@JsonProperty(value = "ChangedElement")
	private ChangedElement[] changedElement;

	@XmlElement(name = "ChangeSummaryVersion")
	@JsonProperty(value = "ChangeSummaryVersion")
	private String changeSummaryVersion;

	public ChangedElement[] getChangedElement() {
		return changedElement;
	}

	public void setChangedElement(ChangedElement[] ChangedElement) {
		this.changedElement = ChangedElement;
	}

	public String getChangeSummaryVersion() {
		return changeSummaryVersion;
	}

	public void setChangeSummaryVersion(String ChangeSummaryVersion) {
		this.changeSummaryVersion = ChangeSummaryVersion;
	}

	@Override
	public String toString() {
		return "ClassPojo [ChangedElement = " + changedElement + ", ChangeSummaryVersion = " + changeSummaryVersion
				+ "]";
	}
}
