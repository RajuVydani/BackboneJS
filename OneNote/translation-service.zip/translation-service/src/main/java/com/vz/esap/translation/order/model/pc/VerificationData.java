package com.vz.esap.translation.order.model.pc;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;

import com.fasterxml.jackson.annotation.JsonProperty;

@XmlAccessorType(XmlAccessType.FIELD)
public class VerificationData {

	@XmlElement(name = "ActionCode")
	@JsonProperty(value = "ActionCode")
	private String actionCode;

	@XmlElement(name = "ActionField")
	@JsonProperty(value = "ActionField")
	private ActionField[] actionField;

	public String getActionCode() {
		return actionCode;
	}

	public void setActionCode(String actionCode) {
		this.actionCode = actionCode;
	}

	public ActionField[] getActionField() {
		return actionField;
	}

	public void setActionField(ActionField[] actionField) {
		this.actionField = actionField;
	}

	@Override
	public String toString() {
		return "ClassPojo [ActionCode = " + actionCode + ", ActionField = " + actionField + "]";
	}
}