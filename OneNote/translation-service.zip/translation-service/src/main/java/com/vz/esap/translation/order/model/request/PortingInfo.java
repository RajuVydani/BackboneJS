package com.vz.esap.translation.order.model.request;

public class PortingInfo {

	private String PortingFlag;

	private String GainingCarrierPrefix;

	private String SubStatus;

	private String PortingIndicator;

	private String LosingCarrierPrefix;

	private String TN;

	private String OriginalCarrierPrefix;

	private String GatewayNumber;

	public String getPortingFlag() {
		return PortingFlag;
	}

	public void setPortingFlag(String PortingFlag) {
		this.PortingFlag = PortingFlag;
	}

	public String getGainingCarrierPrefix() {
		return GainingCarrierPrefix;
	}

	public void setGainingCarrierPrefix(String GainingCarrierPrefix) {
		this.GainingCarrierPrefix = GainingCarrierPrefix;
	}

	public String getSubStatus() {
		return SubStatus;
	}

	public void setSubStatus(String SubStatus) {
		this.SubStatus = SubStatus;
	}

	public String getPortingIndicator() {
		return PortingIndicator;
	}

	public void setPortingIndicator(String PortingIndicator) {
		this.PortingIndicator = PortingIndicator;
	}

	public String getLosingCarrierPrefix() {
		return LosingCarrierPrefix;
	}

	public void setLosingCarrierPrefix(String LosingCarrierPrefix) {
		this.LosingCarrierPrefix = LosingCarrierPrefix;
	}

	public String getTN() {
		return TN;
	}

	public void setTN(String TN) {
		this.TN = TN;
	}

	public String getOriginalCarrierPrefix() {
		return OriginalCarrierPrefix;
	}

	public void setOriginalCarrierPrefix(String OriginalCarrierPrefix) {
		this.OriginalCarrierPrefix = OriginalCarrierPrefix;
	}

	public String getGatewayNumber() {
		return GatewayNumber;
	}

	public void setGatewayNumber(String GatewayNumber) {
		this.GatewayNumber = GatewayNumber;
	}

	public String toString() {
		return "ClassPojo [PortingFlag = " + PortingFlag + ", GainingCarrierPrefix = " + GainingCarrierPrefix
				+ ", SubStatus = " + SubStatus + ", PortingIndicator = " + PortingIndicator + ", LosingCarrierPrefix = "
				+ LosingCarrierPrefix + ", TN = " + TN + ", OriginalCarrierPrefix = " + OriginalCarrierPrefix
				+ ", GatewayNumber = " + GatewayNumber + "]";
	}
}
