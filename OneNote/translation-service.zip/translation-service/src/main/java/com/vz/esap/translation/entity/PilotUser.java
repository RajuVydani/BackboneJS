package com.vz.esap.translation.entity;

public class PilotUser {

	private String userId;
    private String firstName;
    private String lastName;
	private String callingLineIdFirstName;
	private String callingLineIdLastName;
	private String linePort;
	private long phoneNumber;
	private String deviceLevel;
	private String deviceName;

	
	
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getCallingLineIdFirstName() {
		return callingLineIdFirstName;
	}
	public void setCallingLineIdFirstName(String callingLineIdFirstName) {
		this.callingLineIdFirstName = callingLineIdFirstName;
	}
	public String getCallingLineIdLastName() {
		return callingLineIdLastName;
	}
	public void setCallingLineIdLastName(String callingLineIdLastName) {
		this.callingLineIdLastName = callingLineIdLastName;
	}
	public String getLinePort() {
		return linePort;
	}
	public void setLinePort(String linePort) {
		this.linePort = linePort;
	}
	public long getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(long phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public String getDeviceLevel() {
		return deviceLevel;
	}
	public void setDeviceLevel(String deviceLevel) {
		this.deviceLevel = deviceLevel;
	}
	public String getDeviceName() {
		return deviceName;
	}
	public void setDeviceName(String deviceName) {
		this.deviceName = deviceName;
	}
	
	

	
	
}
