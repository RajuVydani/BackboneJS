package com.vz.esap.translation.order.transformer;

import static java.util.Arrays.stream;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.vz.esap.translation.dao.model.TblOrder;
import com.vz.esap.translation.dao.model.TblOrderDetails;
import com.vz.esap.translation.entity.DeviceEntity;
import com.vz.esap.translation.enums.EsapEnum;
import com.vz.esap.translation.enums.EsapEnum.DeviceType;
import com.vz.esap.translation.enums.EsapEnum.OrderEntity;
import com.vz.esap.translation.enums.EsapEnum.SolutionType;
import com.vz.esap.translation.exception.TranslatorException;
import com.vz.esap.translation.exception.TranslatorException.ErrorCode;
import com.vz.esap.translation.order.dao.VOIPOrderDao;
import com.vz.esap.translation.order.model.Order;
import com.vz.esap.translation.order.model.request.Feature;
import com.vz.esap.translation.order.model.request.ParamInfo;
import com.vz.esap.translation.order.model.request.Specification;
import com.vz.esap.translation.order.model.request.VOIPOrderRequest;
import com.vz.esap.translation.util.OrderUtility;

/**
 * @author kalagsu
 *
 */
@Component
public class DeviceTblOrderDetailsDataTransformerImpl implements DeviceTblOrderDetailsDataTransformer {
	private static final Logger LOG = LoggerFactory.getLogger(DeviceTblOrderDetailsDataTransformerImpl.class);

	private static final String LOCATION_ID = "LocationId";
	private static final String CUSTOMER_ID = "CustomerId";
	private static final String REGION = "Region";
	//private static final String BS_APP_SERVER = "BsAppServer";
	private static final String HOT_CUT_IND = "HotCutIndicator";
	private static final String CDD_IND = "CDDDIndicator";
	
	@Autowired
	private VOIPOrderDao voipOrderDao;
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.vz.esap.translation.order.transformer.
	 * DeviceTblOrderDetailsDataTransformer#
	 * prepareTblOrderDetailsEntityParamDataForDevice(com.vz.esap.translation.order.
	 * model.request.VOIPOrderRequest, com.vz.esap.translation.dao.model.TblOrder,
	 * java.util.ArrayList)
	 */
	public ArrayList<ParamInfo> prepareTblOrderDetailsEntityParamDataForDevice(VOIPOrderRequest voipOrderRequest,
			TblOrder tblOrderObject, ArrayList<DeviceEntity> deviceList) throws TranslatorException {

		LOG.info("Entered - prepareTblOrderDetailsEntityParamDataForDevice");
		ParamInfo paramInfo = null;
		ArrayList<ParamInfo> paramInfoList = null;
		try {
			String action = voipOrderRequest.getOrderHeader().getOrderType();
			paramInfoList = new ArrayList<>();
			for (DeviceEntity device : deviceList) {
				
				paramInfo = new ParamInfo("Device", null, action);
				paramInfo.addNotNullValChild("DeviceMapId", device.getDeviceMapId(), action, ParamInfo.Tag.ID);
				paramInfo.addNotNullValChild("DeviceTypeId", device.getDeviceTypeId(), action);
				paramInfo.addNotNullValChild("DeviceId", device.getDeviceId(), action);							
				paramInfo.addNotNullValChild("DeviceName", device.getDeviceName(), action, ParamInfo.Tag.NAME);
				switch (device.getDeviceType()) {
				case 0:
					paramInfo.addNotNullValChild("DeviceType", "SIP_DEVICE", action);
					break;
				case 1:
					paramInfo.addNotNullValChild("DeviceType", "ENTPRISE_GTWY", action);
					break;
				case 2:
					paramInfo.addNotNullValChild("DeviceType", "EST_STATIC_DEVGW_01", action);
					break;
				case 3:
					paramInfo.addNotNullValChild("DeviceType", "CPE_LOCAL_GTWY", action);
					break;
				case 4:
					paramInfo.addNotNullValChild("DeviceType", "CPE_ENTPRISE_GTWY_SHARED", action);
					break;
				default:
					break;
				}
				
				if (device.getAuthFeatureType() != null)
					paramInfo.addNotNullValChild("AuthFeatureType", device.getAuthFeatureType().toString(), action);
				
				paramInfo.addNotNullValChild("Address", device.getAddress(), action);
				paramInfo.addNotNullValChild("DeviceCharId", device.getDeviceCharId(), action);
				paramInfo.addNotNullValChild("DeviceNameId", device.getDeviceNameId(), action);
				paramInfo.addNotNullValChild("Address2", device.getCPEUIId(), action);
				paramInfo.addNotNullValChild("DeviceCharId", device.getSecAddress(), action);
				paramInfo.addNotNullValChild("IpVersion", device.getIpVersion(), action);
				paramInfo.addNotNullValChild("GwyFqdn", device.getGwyFqdn(), action);
				paramInfo.addNotNullValChild("GwyHunt", device.getGwyHunt(), action);
				paramInfo.addNotNullValChild("STN", device.getSTN(), action);
				paramInfo.addNotNullValChild("Codec", device.getCodec(), action);
				paramInfo.addNotNullValChild("TermCallingInd", device.getTermCallingInd(), action);
				paramInfo.addNotNullValChild("StripCcInd", device.getStripCcInd(), action);
				// XOOO
				paramInfo.addNotNullValChild("DeviceSeqId", device.getDeviceMapId(), action);
				paramInfo.addNotNullValChild("InternalAdmin", device.getInternalAdmin(), action);
				paramInfo.addNotNullValChild("EndPointType", device.getEndPointType(), action);
				paramInfo.addNotNullValChild("TrunkGroupId", device.getTrunkId(), action);
				paramInfo.addNotNullValChild("Description", device.getDeviceName(), action);
				//paramInfo.addNotNullValChild("Protocol", device.getProtocol(), action);

				paramInfo.addNotNullValChild("AccessDevice", device.getAccessDevice(), action);
				paramInfo.addNotNullValChild("DeviceLevel", device.getDeviceLevel(), action);
				paramInfo.addNotNullValChild("LinePort", device.getLinePort(), action);
				if(device.getSigDir() != null) {
					paramInfo.addNotNullValChild("SignalingDirection", device.getSigDir(), action);
				}
				
				paramInfo.addNotNullValChild("TrunkType", device.getTrunkType(), action);

				paramInfo.addNotNullValChild("MacAddress", device.getMac(), action);
				paramInfo.addNotNullValChild("SerialNumber", device.getSerialNumber(), action);
				paramInfo.addNotNullValChild("BWDeviceId", device.getBwDeviceId(), action);
				paramInfo.addNotNullValChild("BsDeviceId", device.getBwDeviceId(), action);
				// XOOO
				//Start-Device Change
				//paramInfo.addNotNullValChild("IpAddress", device.getIpAddress(), action);
				paramInfo.addNotNullValChild("IpAddress", device.getAddress(), action);
				paramInfo.addNotNullValChild("TransportProtocol", device.getTransportProtocol(), action);
				paramInfo.addNotNullValChild("Protocol", device.getProtocol(), action);
				paramInfo.addNotNullValChild("Port", device.getPort(), action);
				paramInfo.addNotNullValChild("CpeIpAddress", device.getCpeIpAddress(), action);
				paramInfo.addNotNullValChild("ESBCSignalingIP", device.getCpeIpAddress(), action);
				
				if(voipOrderRequest.getLocation().getLocationAddress() != null 
						&& voipOrderRequest.getLocation().getLocationAddress().getCountryCode() != null)
					paramInfo.addNotNullValChild("Region", 
							voipOrderRequest.getLocation().getLocationAddress().getCountryCode(), action);
				//End-Device Change
				paramInfo.addNotNullValChild("CustomerId", voipOrderRequest.getOrderHeader().getEnterpriseId(), action);
				
				if(SolutionType.HPBX.equals(voipOrderRequest.getOrderHeader().getSolutionType())) {
					paramInfo.addNotNullValChild("ProvisionCategory", "INV_ONLY", action);
				}
				
				paramInfo.addNotNullValChild("AsClli", voipOrderRequest.getOrderHeader().getAsClli(), action); //adding bs clli.
				
				paramInfoList.add(paramInfo);
			}
			

			LOG.info("Exit prepareTblOrderDetailsEntityParamDataForDevice");
		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new TranslatorException(ErrorCode.TRANSFORMER_FAILURE,
					"Exception occured in prepareTblOrderDetailsEntityParamDataForDevice");
		}
		return paramInfoList;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.vz.esap.translation.order.transformer.
	 * DeviceTblOrderDetailsDataTransformer#
	 * prepareTblOrderDetailsEntityParamDataForDevice(com.vz.esap.translation.order.
	 * model.Order)
	 */
	@Override
	public ParamInfo prepareTblOrderDetailsEntityParamDataForDevice(Order order, String action) throws TranslatorException {

		LOG.info("Entered - prepareTblOrderDetailsEntityParamDataForDevice");
		if (action == null)
			action = order.getOrderHeader().getOrderType();
		
		ParamInfo deviceParams = null;
		try {
			deviceParams = new ParamInfo("Device", null, action);

			// deviceParams.addNotNullValChild("EnterpriseId", customer.getCustomerId(),
			// action);
			deviceParams.addNotNullValChild("DeviceMapId", order.getDeviceEntity().getDeviceMapId(), action, ParamInfo.Tag.ID);
			deviceParams.addNotNullValChild("DeviceTypeId", order.getDeviceEntity().getDeviceTypeId(), action);
			deviceParams.addNotNullValChild("DeviceId", order.getDeviceEntity().getDeviceId(), action);
			deviceParams.addNotNullValChild("DeviceName", order.getDeviceEntity().getDeviceName(), action,
					ParamInfo.Tag.NAME);
			
		
			switch (order.getDeviceEntity().getDeviceType()) {
			case 0:
				deviceParams.addNotNullValChild("DeviceType", "SIP_DEVICE", action);
				break;
			case 1:
				deviceParams.addNotNullValChild("DeviceType", "ENTPRISE_GTWY", action);
				break;
			case 2:
				deviceParams.addNotNullValChild("DeviceType", "EST-STATIC-DEVGW-01", action);
				break;
			case 3:
				deviceParams.addNotNullValChild("DeviceType", "CPE_LOCAL_GTWY", action);
				break;
			case 4:
				deviceParams.addNotNullValChild("DeviceType", "CPE_ENTPRISE_GTWY_SHARED", action);
				break;
			default:
				break;
			}
			
			if (order.getDeviceEntity().getAuthFeatureType() != null)
				deviceParams.addNotNullValChild("AuthFeatureType",
						order.getDeviceEntity().getAuthFeatureType().toString(), action);

			deviceParams.addNotNullValChild("Address", order.getDeviceEntity().getAddress(), action);
			deviceParams.addNotNullValChild("DeviceCharId", order.getDeviceEntity().getDeviceCharId(), action);
			deviceParams.addNotNullValChild("DeviceNameId", order.getDeviceEntity().getDeviceNameId(), action);

			deviceParams.addNotNullValChild("Address2", order.getDeviceEntity().getCPEUIId(), action);
			deviceParams.addNotNullValChild("DeviceCharId", order.getDeviceEntity().getSecAddress(), action);
			deviceParams.addNotNullValChild("IpVersion", order.getDeviceEntity().getIpVersion(), action);

			deviceParams.addNotNullValChild("GwyFqdn", order.getDeviceEntity().getGwyFqdn(), action);
			deviceParams.addNotNullValChild("GwyHunt", order.getDeviceEntity().getGwyHunt(), action);
			deviceParams.addNotNullValChild("IpVersion", order.getDeviceEntity().getIpVersion(), action);

			deviceParams.addNotNullValChild("STN", order.getDeviceEntity().getSTN(), action);
			deviceParams.addNotNullValChild("Codec", order.getDeviceEntity().getCodec(), action);
			deviceParams.addNotNullValChild("TermCallingInd", order.getDeviceEntity().getTermCallingInd(), action);

			deviceParams.addNotNullValChild("StripCcInd", order.getDeviceEntity().getStripCcInd(), action);

			// XOOO
			deviceParams.addNotNullValChild("DeviceSeqId", order.getDeviceEntity().getDeviceMapId(), action);
			deviceParams.addNotNullValChild("InternalAdmin", order.getDeviceEntity().getInternalAdmin(), action);
			deviceParams.addNotNullValChild("EndPointType", order.getDeviceEntity().getEndPointType(), action);
			deviceParams.addNotNullValChild("TrunkGroupId", order.getDeviceEntity().getTrunkId(), action);
			deviceParams.addNotNullValChild("Description", order.getDeviceEntity().getDeviceName(), action);
			//deviceParams.addNotNullValChild("Protocol", order.getDeviceEntity().getProtocol(), action);
			deviceParams.addNotNullValChild("AccessDevice", order.getDeviceEntity().getAccessDevice(), action);
			deviceParams.addNotNullValChild("DeviceLevel", order.getDeviceEntity().getDeviceLevel(), action);
			deviceParams.addNotNullValChild("LinePort", order.getDeviceEntity().getLinePort(), action);
			if(null != order.getDeviceEntity().getSigDir()) {
				deviceParams.addNotNullValChild("SignalingDirection", String.valueOf(order.getDeviceEntity().getSigDir()), action);
			}
			deviceParams.addNotNullValChild("TrunkType", order.getDeviceEntity().getTrunkType(), action);
			deviceParams.addNotNullValChild("MacAddress", order.getDeviceEntity().getMac(), action);
			deviceParams.addNotNullValChild("SerialNumber", order.getDeviceEntity().getSerialNumber(), action);
			deviceParams.addNotNullValChild("BWDeviceId", order.getDeviceEntity().getBwDeviceId(), action);
			deviceParams.addNotNullValChild("BsDeviceId", order.getDeviceEntity().getBwDeviceId(), action);
			// XOOO
			//Start-Device Change
			//deviceParams.addNotNullValChild("IpAddress", order.getDeviceEntity().getIpAddress(), action);
			deviceParams.addNotNullValChild("IpAddress", order.getDeviceEntity().getAddress(), action);
			deviceParams.addNotNullValChild("TransportProtocol", order.getDeviceEntity().getTransportProtocol(), action);
			deviceParams.addNotNullValChild("Protocol", order.getDeviceEntity().getProtocol(), action);
			deviceParams.addNotNullValChild("Port", order.getDeviceEntity().getPort(), action);
			deviceParams.addNotNullValChild("Region", order.getDeviceEntity().getRegion(), action);
			deviceParams.addNotNullValChild("CpeIpAddress", order.getDeviceEntity().getCpeIpAddress(), action);
			//End-Device Change

			
		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new TranslatorException(ErrorCode.TRANSFORMER_FAILURE,
					"Exception occured in prepareTblOrderDetailsEntityParamDataForDevice");
		}
		LOG.info("Exit prepareTblOrderDetailsEntityParamDataForDevice");
		return deviceParams;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.vz.esap.translation.order.transformer.
	 * DeviceTblOrderDetailsDataTransformer#prepareTblOrderDetailsHeaderParamData(
	 * com.vz.esap.translation.order.model.Order)
	 */
	@Override
	public ParamInfo prepareTblOrderDetailsHeaderParamData(Order order) throws ParseException, TranslatorException {

		LOG.info("Entered - prepareTblOrderDetailsHeaderParamData");
		ParamInfo headerParams = null;
		String action = null;
		try {

			action = order.getOrderHeader().getOrderType();

			headerParams = new ParamInfo("Header", null, action);
			headerParams.addNotNullValChild("OrderNumber", order.getOrderHeader().getOrderNumber(), action);
			headerParams.addNotNullValChild("EnvOrderId", order.getOrderHeader().getEnvOrderId(), action);
			headerParams.addNotNullValChild("MasterOrderNumber", order.getOrderHeader().getMasterOrderNumber(), action);
			headerParams.addNotNullValChild("OrderVersion", order.getOrderHeader().getOrderVersion(), action);
			headerParams.addNotNullValChild("TransactionId", order.getOrderHeader().getTransactionId(), action);
			headerParams.addNotNullValChild("Region", order.getOrderHeader().getRegion(), action);
			headerParams.addNotNullValChild("MinorOrderType", order.getOrderHeader().getMinorOrderType(), action);
			headerParams.addNotNullValChild("CentrexType", order.getOrderHeader().getCentrexType(), action);
			headerParams.addNotNullValChild("ServiceType", order.getOrderHeader().getServiceType(), action);
			headerParams.addNotNullValChild("OriginatingSystem", order.getOrderHeader().getOriginatingSystem(), action);
			headerParams.addNotNullValChild("InterfaceSystem", order.getOrderHeader().getInterfaceSystem(), action);
			headerParams.addNotNullValChild("OrderType",
					EsapEnum.OrderType.getValue(order.getOrderHeader().getOrderType().charAt(0)), action);
			headerParams.addNotNullValChild("SuppType", order.getOrderHeader().getSuppType(), action);
			headerParams.addNotNullValChild("OrderClassify", order.getOrderHeader().getFunctionCode(), action);

			if (order.getOrderHeader().getDueDate() != null) {
				SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
				Date date = format.parse(order.getOrderHeader().getDueDate().toString());
				Calendar calendar = GregorianCalendar.getInstance();
				calendar.setTime(date);
				Object dueDate = calendar.getTime();
				headerParams.addNotNullValChild("DueDate", dueDate, action);
			}
			headerParams.addNotNullValChild("CustomerId", order.getOrderHeader().getCustomerId(), action);
			headerParams.addNotNullValChild("LocationId", order.getOrderHeader().getLocationId(), action);
			// headerParams.addNotNullValChild("BsAppServer",
			// order.getCustomer().getBsAppServer(), action); Fix This
			headerParams.addNotNullValChild("OrderProTIN", order.getOrderHeader().getOrderProTIN(), action);
			headerParams.addNotNullValChild("IOrderTIN", order.getOrderHeader().getiOrderTIN(), action);
			headerParams.addNotNullValChild("TINVersion", order.getOrderHeader().getTinVersion(), action);
			headerParams.addNotNullValChild("TransitionFlag", order.getOrderHeader().isTransitionFlag() ? "Y" : "N",
					action);
			headerParams.addNotNullValChild("Priority", order.getOrderHeader().getPriority(), action);
			if (order.getOrderHeader().getAttribMap() != null) {
				headerParams
						.addChildParam(OrderUtility.getAttribParamInfo(order.getOrderHeader().getAttribMap(), action));
			}
			if (order.getOrderHeader().getOrderCreatedBy() != null)
				headerParams.addNotNullValChild("OrderCreatedBy", order.getOrderHeader().getOrderCreatedBy(), action);
			if (order.getOrderHeader().isHasBulkOrder()) {
				headerParams.addNotNullValChild("BULK", "Y", action);
			}
			if (order.getOrderHeader().getHotCutIndicator() != null) {
				headerParams.addNotNullValChild("HotCutIndicator", "Y", action);
			}
			if (order.getOrderHeader().getCDDDIndicator() != null) {
				headerParams.addNotNullValChild("CDDDIndicator", "Y", action);
			}
			if (order.getOrderHeader().getSolutionType() != null) {
				headerParams.addNotNullValChild("SolutionType", order.getOrderHeader().getSolutionType().toString(),
						action);
			}
		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new TranslatorException(ErrorCode.TRANSFORMER_FAILURE,
					"Exception occured in prepareTblOrderDetailsHeaderParamData");
		}

		LOG.info("Exit prepareTblOrderDetailsHeaderParamData");

		return headerParams;
	}

	@Override
	public ParamInfo prepareTblOrderDetailsEntityParamDataForDevice(DeviceEntity oldDevice, DeviceEntity newDevice,
			boolean supp, String action) throws ParseException, TranslatorException {
		LOG.info("Entered - prepareTblOrderDetailsEntityParamDataForDevice");
		
		List<TblOrderDetails> ordDetails = null;
		ParamInfo deviceParam = new ParamInfo("Device", null, null);

		if (oldDevice.getDeviceId() != null)
			deviceParam.addChildParam(new ParamInfo("DeviceId", oldDevice
					.getDeviceId(), null));
		
		try {

			deviceParam.addChangeParam("DeviceMapId", oldDevice.getDeviceMapId(), 
					newDevice.getDeviceMapId(), supp, ParamInfo.Tag.ID);
			deviceParam.addChangeParam("DeviceTypeId", oldDevice.getDeviceTypeId(), oldDevice.getDeviceTypeId(), supp);
			deviceParam.addChangeParam("DeviceName", oldDevice.getDeviceName(), 
					newDevice.getDeviceName(), supp, ParamInfo.Tag.NAME);
			
			switch (oldDevice.getDeviceType()) {
			case 0:
				deviceParam.addNotNullValChild("DeviceType", "SIP_DEVICE", null);
				break;
			case 1:
				deviceParam.addNotNullValChild("DeviceType", "ENTPRISE_GTWY", null);
				break;
			case 2:
				deviceParam.addNotNullValChild("DeviceType", "EST-STATIC-DEVGW-01", null);
				break;
			case 3:
				deviceParam.addNotNullValChild("DeviceType", "CPE_LOCAL_GTWY", null);
				break;
			case 4:
				deviceParam.addNotNullValChild("DeviceType", "CPE_ENTPRISE_GTWY_SHARED", null);
				break;
			default:
				break;
			}
			
			if (oldDevice.getAuthFeatureType() != null)
				deviceParam.addChangeParam("AuthFeatureType", oldDevice.getAuthFeatureType().toString(),
						oldDevice.getAuthFeatureType().toString(), supp);

			deviceParam.addChangeParam("CustomerId", oldDevice.getCustomerId(), oldDevice.getCustomerId(), supp);
			deviceParam.addChangeParam("Address", oldDevice.getAddress(), oldDevice.getAddress(), supp);
			deviceParam.addChangeParam("DeviceCharId", oldDevice.getDeviceCharId(), newDevice.getDeviceCharId(), supp);
			deviceParam.addChangeParam("DeviceNameId", oldDevice.getDeviceNameId(), newDevice.getDeviceNameId(), supp);

			deviceParam.addChangeParam("Address2", oldDevice.getCPEUIId(), newDevice.getCPEUIId(), supp);
			deviceParam.addChangeParam("DeviceCharId", oldDevice.getSecAddress(), newDevice.getSecAddress(), supp);
			deviceParam.addChangeParam("IpVersion", oldDevice.getIpVersion(), oldDevice.getIpVersion(), supp);

			deviceParam.addChangeParam("GwyFqdn", oldDevice.getGwyFqdn(), newDevice.getGwyFqdn(), supp);
			deviceParam.addChangeParam("GwyHunt", oldDevice.getGwyHunt(), newDevice.getGwyHunt(), supp);

			deviceParam.addChangeParam("STN", oldDevice.getSTN(), newDevice.getSTN(), supp);
			deviceParam.addChangeParam("Codec", oldDevice.getCodec(), newDevice.getCodec(), supp);
			deviceParam.addChangeParam("TermCallingInd", oldDevice.getTermCallingInd(), newDevice.getTermCallingInd(), supp);

			deviceParam.addChangeParam("StripCcInd", oldDevice.getStripCcInd(), newDevice.getStripCcInd(), supp);

			// XOOO
			deviceParam.addChangeParam("DeviceSeqId", oldDevice.getDeviceMapId(), newDevice.getDeviceMapId(), supp);
			deviceParam.addChangeParam("InternalAdmin", oldDevice.getInternalAdmin(), newDevice.getInternalAdmin(), supp);
			deviceParam.addChangeParam("EndPointType", oldDevice.getEndPointType(), newDevice.getEndPointType(), supp);
			deviceParam.addChangeParam("TrunkGroupId", oldDevice.getTrunkId(), oldDevice.getTrunkId(), supp);
			deviceParam.addChangeParam("Description", oldDevice.getDeviceName(), newDevice.getDeviceName(), supp);
			//deviceParam.addChangeParam("Protocol", oldDevice.getProtocol(), newDevice.getDeviceCharId(), supp);
			deviceParam.addChangeParam("AccessDevice", oldDevice.getAccessDevice(), newDevice.getAccessDevice(), supp);
			deviceParam.addChangeParam("DeviceLevel", oldDevice.getDeviceLevel(), newDevice.getDeviceLevel(), supp);
			deviceParam.addChangeParam("LinePort", oldDevice.getLinePort(), newDevice.getLinePort(), supp);
			deviceParam.addChangeParam("SignalingDirection", String.valueOf(oldDevice.getSigDir()), String.valueOf(oldDevice.getSigDir()), supp);
			deviceParam.addChangeParam("TrunkType", oldDevice.getTrunkType(), oldDevice.getTrunkType(), supp);
			deviceParam.addChangeParam("MacAddress", oldDevice.getMac(), newDevice.getMac(), supp);
			deviceParam.addChangeParam("SerialNumber", oldDevice.getSerialNumber(), newDevice.getSerialNumber(), supp);
			deviceParam.addChangeParam("BWDeviceId", oldDevice.getBwDeviceId(), oldDevice.getBwDeviceId(), supp);
			deviceParam.addChangeParam("BsDeviceId", oldDevice.getBsDeviceId(), oldDevice.getBsDeviceId(), supp);
			// XOOO
			//Start-Device Change
			//deviceParam.addChangeParam("IpAddress", oldDevice.getIpAddress(), newDevice.getDeviceCharId(), supp);
			deviceParam.addChangeParam("IpAddress", oldDevice.getAddress(), oldDevice.getAddress(), supp);
			deviceParam.addChangeParam("TransportProtocol", oldDevice.getTransportProtocol(), oldDevice.getTransportProtocol(), supp);
			deviceParam.addChangeParam("Protocol", oldDevice.getProtocol(), oldDevice.getProtocol(), supp);
			deviceParam.addChangeParam("Port", oldDevice.getPort(), oldDevice.getPort(), supp);
			deviceParam.addChangeParam("Region", oldDevice.getRegion(), oldDevice.getRegion(), supp);
			//End-Device Change
			
			if((oldDevice.getSigDir() != null && !oldDevice.getSigDir().equals(newDevice.getSigDir()))
					|| (oldDevice.getBwDeviceId() != null && !oldDevice.getBwDeviceId().equals(newDevice.getBwDeviceId()))
					|| (oldDevice.getDeviceName() != null && !oldDevice.getDeviceName().equals(newDevice.getDeviceName()))) {
				LOG.info("DEV_BS_CHANGE = Y");				
				deviceParam.addNotNullValChild("DEV_BS_CHANGE", "Y", "n");
			} else if(oldDevice.getSigDir() == null && newDevice.getSigDir() != null) {
				LOG.info("DEV_BS_CHANGE = Y");
				deviceParam.addNotNullValChild("DEV_BS_CHANGE", "Y", "n");
			} else if(oldDevice.getSigDir() != null && newDevice.getSigDir() == null) {
				LOG.info("DEV_BS_CHANGE = Y");
				deviceParam.addNotNullValChild("DEV_BS_CHANGE", "Y", "n");
			} else {
				LOG.info("DEV_BS_CHANGE = N");
				deviceParam.addNotNullValChild("DEV_BS_CHANGE", "N", "n");
			}

			LOG.info("Exit prepareTblOrderDetailsEntityParamDataForDevice");
		} catch (Exception e) {
			LOG.error("Exception {} ", e);
			throw new TranslatorException(ErrorCode.TRANSFORMER_FAILURE,
					"Exception occured in prepareTblOrderDetailsEntityParamDataForDevice");
		}
		return deviceParam;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.vz.esap.translation.order.transformer.
	 * DeviceTblOrderDetailsDataTransformer#prepareTblOrderDetailsHeaderParamData(
	 * com.vz.esap.translation.order.model.Order,
	 * com.vz.esap.translation.entity.DeviceEntity, boolean)
	 */
	@Override
	public ParamInfo prepareTblOrderDetailsHeaderParamData(Order order, DeviceEntity oldDeviceEntity, boolean supp)
			throws ParseException, TranslatorException {
		LOG.info("Entered - prepareTblOrderDetailsHeaderParamData");
		
		ParamInfo root = null;
		String action = null;
		try {

			int oldVersion = Integer.parseInt(order.getOrderHeader().getOrderVersion()) + 1;
			
			action = order.getOrderHeader().getOrderType();

			root = new ParamInfo("Header", null, action);
			root.addChangeParam("OrderNumber", order.getOrderHeader().getOrderNumber(),
					order.getOrderHeader().getOrderNumber(), supp);
			root.addChangeParam("EnvOrderId", order.getOrderHeader().getEnvOrderId(), order.getOrderHeader().getEnvOrderId(), supp);
			root.addChangeParam("MasterOrderNumber",order.getOrderHeader().getMasterOrderNumber(),
					order.getOrderHeader().getMasterOrderNumber(), supp);
			root.addChangeParam("OrderVersion", order.getOrderHeader().getOrderVersion(), order.getOrderHeader().getOrderVersion(), supp);
			root.addChangeParam("TransactionId", order.getOrderHeader().getTransactionId(),
					order.getOrderHeader().getTransactionId(), supp);
			root.addChangeParam(REGION, order.getOrderHeader().getRegion(), order.getOrderHeader().getRegion(), supp);
			root.addChangeParam("MinorOrderType", order.getOrderHeader().getMinorOrderType(),
					order.getOrderHeader().getMinorOrderType(), supp);
			root.addChangeParam("CentrexType",  order.getOrderHeader().getCentrexType(),
					order.getOrderHeader().getCentrexType(), supp);
			root.addChangeParam("ServiceType", order.getOrderHeader().getServiceType(),
					order.getOrderHeader().getServiceType(), supp);
			root.addChangeParam("OriginatingSystem",  order.getOrderHeader().getOriginatingSystem(),
					order.getOrderHeader().getOriginatingSystem(), supp);
			root.addChangeParam("InterfaceSystem", order.getOrderHeader().getInterfaceSystem(),
					order.getOrderHeader().getInterfaceSystem(), supp);
			root.addChangeParam("OrderType",
					EsapEnum.OrderType.getValue(order.getOrderHeader().getOrderType().charAt(0)),
					EsapEnum.OrderType.getValue(order.getOrderHeader().getOrderType().charAt(0)), supp);
			root.addChangeParam("SuppType", order.getOrderHeader().getSuppType(), order.getOrderHeader().getSuppType(), supp);
			root.addChangeParam("OrderClassify",  order.getOrderHeader().getFunctionCode(),
					order.getOrderHeader().getFunctionCode(), supp);

			if (order.getOrderHeader().getDueDate() != null) {
				SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
				Date date = format.parse(order.getOrderHeader().getDueDate().toString());
				Calendar calendar = GregorianCalendar.getInstance();
				calendar.setTime(date);
				Object dueDate = calendar.getTime();
				root.addNotNullValChild("DueDate", dueDate, action);
			}

			if (order.getLocation() != null && order.getLocation().getCustomerId() != null) {
				LOG.info("Customer Id = {}", order.getLocation().getCustomerId());
				root.addChangeParam(CUSTOMER_ID, order.getLocation().getCustomerId(),
						order.getLocation().getCustomerId(), supp);
				
			} else if (order.getOrderHeader().getCustomerId() != null) {
				LOG.info("Customer Id = {}", order.getOrderHeader().getCustomerId());
				root.addChangeParam(CUSTOMER_ID, order.getOrderHeader().getCustomerId(),
						order.getOrderHeader().getCustomerId(), supp);
				
			} else if (oldDeviceEntity.getCustomerId() != null) {
				LOG.info("Customer Id = {}", oldDeviceEntity.getCustomerId());
				root.addChangeParam(CUSTOMER_ID, oldDeviceEntity.getCustomerId(),
						oldDeviceEntity.getCustomerId(), supp);
			}
				
			
			root.addChangeParam(LOCATION_ID, order.getOrderHeader().getLocationId(),
					order.getOrderHeader().getLocationId(), supp);
			// root.addNotNullValChild(BS_APP_SERVER, order.getLocation().getBsAppServer(), action); Fix This
			root.addChangeParam("OrderProTIN", order.getOrderHeader().getOrderProTIN(),
					order.getOrderHeader().getOrderProTIN(), supp);
			root.addChangeParam("IOrderTIN", order.getOrderHeader().getiOrderTIN(),
					order.getOrderHeader().getiOrderTIN(), supp);
			root.addChangeParam("TINVersion", order.getOrderHeader().getTinVersion(),
					order.getOrderHeader().getTinVersion(), supp);
			root.addChangeParam("TransitionFlag", order.getOrderHeader().isTransitionFlag() ? "Y" : "N",
					order.getOrderHeader().isTransitionFlag() ? "Y" : "N", supp);
			root.addChangeParam("Priority", order.getOrderHeader().getPriority(), order.getOrderHeader().getPriority(),
					supp);
			if (order.getOrderHeader().getAttribMap() != null) {
				root.addChildParam(OrderUtility.getAttribParamInfo(order.getOrderHeader().getAttribMap(), action));
			}
			if (order.getOrderHeader().getOrderCreatedBy() != null)
				root.addChangeParam("OrderCreatedBy", order.getOrderHeader().getOrderCreatedBy(),
						order.getOrderHeader().getOrderCreatedBy(), supp);
			if (order.getOrderHeader().isHasBulkOrder()) {
				root.addChangeParam("BULK", "Y", "Y", supp);
			}
			if (order.getOrderHeader().getHotCutIndicator() != null) {
				root.addChangeParam(HOT_CUT_IND, "Y", "Y", supp);
			}
			if (order.getOrderHeader().getCDDDIndicator() != null) {
				root.addChangeParam(CDD_IND, "Y", "Y", supp);
			}
			if (order.getOrderHeader().getSolutionType() != null) {
				root.addChangeParam("SolutionType", order.getOrderHeader().getSolutionType().toString(),
						order.getOrderHeader().getSolutionType().toString(), supp);
			}
		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new TranslatorException(ErrorCode.TRANSFORMER_FAILURE,
					"Exception occured in prepareTblOrderDetailsHeaderParamData");
		}

		LOG.info("Exit prepareTblOrderDetailsHeaderParamData");

		return root;
	}
/**
 * @author Abhiram varma
 * @param  deviceList, change ,object
 * @return ArrayList<ParamInfo> 
 * @throws  TranslatorException
 */
	@Override
	public ArrayList<ParamInfo> prepareTblOrderDetailsEntityParamDataForDevice(ArrayList<DeviceEntity> deviceList,
			boolean change, Object  object) throws TranslatorException {

		LOG.info("Entered - prepareTblOrderDetailsEntityParamDataForDevice");
		ParamInfo paramInfo = null;
		ArrayList<ParamInfo> paramInfoList = null;
		DeviceEntity  changedEntity=null;
		try {
	//		String action = voipOrderRequest.getOrderHeader().getOrderType();
			paramInfoList = new ArrayList<>();
			for (DeviceEntity device : deviceList) {
				changedEntity=device.getDeviceEntity()!=null?device.getDeviceEntity():new DeviceEntity();
				
				paramInfo = new ParamInfo("Device", null, null);
				paramInfo.addChangeParam("DeviceMapId", device.getDeviceMapId(),changedEntity.getDeviceMapId(), change, ParamInfo.Tag.ID);
				paramInfo.addChangeParam("DeviceTypeId", device.getDeviceTypeId(),changedEntity.getDeviceTypeId(), change);
				paramInfo.addChangeParam("DeviceId", device.getDeviceId(),changedEntity.getDeviceId(), change);
				paramInfo.addChangeParam("DeviceName", device.getDeviceName(),changedEntity.getDeviceName(), change, ParamInfo.Tag.NAME);
				
				if(device.getDeviceType() != null) {
					DeviceType deviceType = DeviceType.values()[device.getDeviceType().intValue()];
					String deviceTypeStr = deviceType.getValue();
					LOG.info("Device Type is = {}", deviceTypeStr);
					
					paramInfo.addChangeParam("DeviceType", deviceTypeStr, deviceTypeStr, change);
				}
				
				/*if(device.getDeviceType() != null) {
					switch (device.getDeviceType()) {
					case 0:
						paramInfo.addChangeParam("DeviceType", "SIP_DEVICE","SIP_DEVICE", change);
						break;
					case 1:
						paramInfo.addChangeParam("DeviceType", "ENTPRISE_GTWY","ENTPRISE_GTWY", change);
						break;
					case 2:
						paramInfo.addChangeParam("DeviceType", "CPE_LOCAL_GTWY","EST-STATIC-DEVGW-01", change);
						break;
					case 3:
						paramInfo.addChangeParam("DeviceType", "CPE_ENTPRISE_GTWY_SHARED", "CPE_LOCAL_GTWY",change);
						break;
					case 4:
						paramInfo.addChangeParam("DeviceType", "EST-STATIC-DEVGW-01","CPE_ENTPRISE_GTWY_SHARED", change);
						break;
					default:
						break;
					}
				}	*/			
				
				if (device.getAuthFeatureType() != null)
					paramInfo.addChangeParam("AuthFeatureType", device.getAuthFeatureType().toString(),
							device.getAuthFeatureType().toString(), change);

				paramInfo.addChangeParam("Address", device.getAddress(),changedEntity.getAddress(), change);
				paramInfo.addChangeParam("DeviceCharId", device.getDeviceCharId(), changedEntity.getDeviceCharId(), change);
				paramInfo.addChangeParam("DeviceNameId", device.getDeviceNameId(), changedEntity.getDeviceNameId(), change);
				paramInfo.addChangeParam("Address2", device.getCPEUIId(),changedEntity.getCPEUIId(), change);
				paramInfo.addChangeParam("DeviceCharId", device.getSecAddress(),changedEntity.getSecAddress(), change);
				paramInfo.addChangeParam("IpVersion", device.getIpVersion(),device.getIpVersion(), change);
				paramInfo.addChangeParam("GwyFqdn", device.getGwyFqdn(),changedEntity.getGwyFqdn(), change);
				paramInfo.addChangeParam("GwyHunt", device.getGwyHunt(),changedEntity.getGwyHunt(), change);
				paramInfo.addChangeParam("STN", device.getSTN(),changedEntity.getSTN(), change);
				paramInfo.addChangeParam("Codec", device.getCodec(),changedEntity.getCodec(), change);
				paramInfo.addChangeParam("TermCallingInd", device.getTermCallingInd(),changedEntity.getTermCallingInd(), change);
				paramInfo.addChangeParam("StripCcInd", device.getStripCcInd(),changedEntity.getStripCcInd(), change);
				// XOOO
				paramInfo.addChangeParam("DeviceSeqId", device.getDeviceMapId(),changedEntity.getDeviceMapId(), change);
				paramInfo.addChangeParam("InternalAdmin", device.getInternalAdmin(),changedEntity.getInternalAdmin(), change);
				paramInfo.addChangeParam("EndPointType", device.getEndPointType(), changedEntity.getEndPointType(),  change);
				paramInfo.addChangeParam("TrunkGroupId", device.getTrunkId(),changedEntity.getTrunkId(),  change);
				paramInfo.addChangeParam("Description", device.getDeviceName(),changedEntity.getDeviceName(), change);
				//paramInfo.addNotNullValChild("Protocol", device.getProtocol(), action);

				paramInfo.addChangeParam("AccessDevice", device.getAccessDevice(),changedEntity.getAccessDevice(),  change);
				paramInfo.addChangeParam("DeviceLevel", device.getDeviceLevel(),changedEntity.getDeviceLevel(), change);
				paramInfo.addChangeParam("LinePort", device.getLinePort(),changedEntity.getLinePort(), change);
				paramInfo.addChangeParam("SignalingDirection", device.getSigDir(),changedEntity.getSigDir(),  change);
				paramInfo.addChangeParam("TrunkType", device.getTrunkType(),changedEntity.getTrunkType(), change);

				paramInfo.addChangeParam("MacAddress", device.getMac(),changedEntity.getMac(), change);
				paramInfo.addChangeParam("SerialNumber", device.getSerialNumber(),changedEntity.getSerialNumber(), change);
				paramInfo.addChangeParam("BWDeviceId", device.getBwDeviceId(),changedEntity.getBwDeviceId(), change);
				paramInfo.addChangeParam("BsDeviceId", device.getBwDeviceId(),changedEntity.getBwDeviceId(), change);
				// XOOO
				//Start-Device Change
				//paramInfo.addNotNullValChild("IpAddress", device.getIpAddress(), action);
				paramInfo.addChangeParam("IpAddress", device.getAddress(),changedEntity.getAddress(), change);
				paramInfo.addChangeParam("TransportProtocol", device.getTransportProtocol(), changedEntity.getTransportProtocol(), change);
				paramInfo.addChangeParam("Protocol", device.getProtocol(),changedEntity.getProtocol(), change);
				paramInfo.addChangeParam("Port", device.getPort(), changedEntity.getPort(), change);
				paramInfo.addChangeParam("AsClli", device.getAsClli(), device.getAsClli(), change); //add broadsoft clli.
				
				//if(voipOrderRequest.getLocation().getLocationAddress() != null 
				//		&& voipOrderRequest.getLocation().getLocationAddress().getCountryCode() != null)
				//	paramInfo.addNotNullValChild("Region", 
				//			voipOrderRequest.getLocation().getLocationAddress().getCountryCode(), change);
				//End-Device Change
				paramInfoList.add(paramInfo);
			}

			LOG.info("Exit prepareTblOrderDetailsEntityParamDataForDevice");
		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new TranslatorException(ErrorCode.TRANSFORMER_FAILURE,
					"Exception occured in prepareTblOrderDetailsEntityParamDataForDevice");
		}
		return paramInfoList;
	}
	/**
	 * @param bool
	 * @return boolean
	 */
	public static String booleanToStr(Boolean bool) {
		if (bool == null)
			return null;
		else
			return bool ? "C" : "N";
	}

}