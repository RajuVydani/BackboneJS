package com.vz.esap.translation.entity;

/* */
import java.sql.Connection;
import java.sql.SQLException;
//import esap.db.DBTblOrderDetails;
import java.util.ArrayList;

public class VmAccess 
{
    private Long vmAccessId;
    private String publicNumber;
    private String privateNumber;
    private String subscriberId;

    public Long getVmAccessId() {
		return vmAccessId;
	}

	public void setVmAccessId(Long vmAccessId) {
		this.vmAccessId = vmAccessId;
	}

	public String getPublicNumber() {
		return publicNumber;
	}

	public void setPublicNumber(String publicNumber) {
		if(publicNumber != null){
			publicNumber = publicNumber.trim();
		}
		this.publicNumber = publicNumber;
	}

	public String getPrivateNumber() {
		return privateNumber;
	}

	public void setPrivateNumber(String privateNumber) {
		this.privateNumber = privateNumber;
	}

	public String getSubscriberId() {
		return subscriberId;
	}

	public void setSubscriberId(String subscriberId) {
		this.subscriberId = subscriberId;
	}

	
}
