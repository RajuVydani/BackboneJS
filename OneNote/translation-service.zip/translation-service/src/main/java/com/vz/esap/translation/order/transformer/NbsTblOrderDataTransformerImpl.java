package com.vz.esap.translation.order.transformer;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.vz.esap.translation.dao.model.TblOrder;
import com.vz.esap.translation.dao.model.TblOrderPrioritySettings;
import com.vz.esap.translation.dao.repository.CustomCustomerMapper;
import com.vz.esap.translation.dao.repository.CustomTblOrderPrioritySettingsMapper;
import com.vz.esap.translation.enums.EsapEnum.FlowPath;
import com.vz.esap.translation.enums.EsapEnum.OrderPass;
import com.vz.esap.translation.exception.GenericException;
import com.vz.esap.translation.order.model.Order;
import com.vz.esap.translation.util.OrderUtility;

import EsapEnumPkg.WorkOrderEnum;

@Component
public class NbsTblOrderDataTransformerImpl implements NbsTblOrderDataTransformer {

	private static final Logger LOG = LoggerFactory.getLogger(NbsTblOrderDataTransformerImpl.class);

	@Autowired
	private CustomCustomerMapper customCustomerMapper;

	@Autowired
	private CustomTblOrderPrioritySettingsMapper customTblOrderPrioritySettingsMapper;
	
	@Value("${source.address}")
	private String sourceAddress;

	/**
	 * @param ordPrioCols
	 * @return tblOrderPrioritySettingsList
	 */
	List<TblOrderPrioritySettings> getOrderPrioritySettings(HashMap<String, String> ordPrioCols) {
		LOG.info("Entered getOrderPrioritySettings apii");
		List<TblOrderPrioritySettings> tblOrderPrioritySettingsList = new ArrayList<TblOrderPrioritySettings>();
		tblOrderPrioritySettingsList = customTblOrderPrioritySettingsMapper.getOrderPrioritySettings(ordPrioCols);
		LOG.info("Exit getOrderPrioritySettings apii");
		return tblOrderPrioritySettingsList;
	}

	/**
	 * @return customCustomerMapper
	 */
	public CustomCustomerMapper getCustomCustomerMapper() {
		return customCustomerMapper;
	}

	/**
	 * @param customCustomerMapper
	 */
	public void setCustomCustomerMapper(CustomCustomerMapper customCustomerMapper) {
		this.customCustomerMapper = customCustomerMapper;
	}

	/**
	 * @return customTblOrderPrioritySettingsMapper
	 */
	public CustomTblOrderPrioritySettingsMapper getCustomTblOrderPrioritySettingsMapper() {
		return customTblOrderPrioritySettingsMapper;
	}

	/**
	 * @param customTblOrderPrioritySettingsMapper
	 */
	public void setCustomTblOrderPrioritySettingsMapper(
			CustomTblOrderPrioritySettingsMapper customTblOrderPrioritySettingsMapper) {
		this.customTblOrderPrioritySettingsMapper = customTblOrderPrioritySettingsMapper;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.vz.esap.translation.order.transformer.NbsTblOrderDataTransformer#
	 * prepareTblOrderDataFromOrder(com.vz.esap.translation.order.model.Order,
	 * java.lang.Long)
	 */
	@Override
	public TblOrder prepareTblOrderDataFromOrder(Order order, Long orderEntity) throws GenericException {
		LOG.info("Entered - prepareTblOrderDataFromOrder");
		//EsapEnumPkg.VzbVoipEnum.OrderEntity.ENTERPRISE
		TblOrder tblOrder = null;
		long orderId = 0L;
		long priority =  0L;

		try {
			tblOrder = new TblOrder();
			orderId = customCustomerMapper.getOrderIdSeqNextVal();

			tblOrder.setOrderId(orderId);
			tblOrder.setEnvOrderId(order.getOrderHeader().getEnvOrderId());
			tblOrder.setPrevPassOrderId(null); //  : TODO Get Prev Pass
			if ("GUI".equals(order.getOrderHeader().getInterfaceSystem())) {
				tblOrder.setDestSystem("WEB");
			} else {
				// tblOrder.setDestSystem(order.getOrderHeader().getInterfaceSystem());
				// // : TODO Make this dynamic
				tblOrder.setDestSystem("PC");
			}

			priority = getOrderPriorityForOrder(order);

			tblOrder.setPriority(priority);

			tblOrder.setApptypeId(priority);
			tblOrder.setOrderStatus(Long.valueOf(order.getOrderHeader().getOrderStatus()));
			tblOrder.setPrevOrderStatus(null);
			tblOrder.setWorkGroup(null);

			LOG.info("sourceAddress : {}", sourceAddress);
			tblOrder.setSourceSystem(sourceAddress);
			tblOrder.setSourceService(null);
			tblOrder.setManualOrder("N");
			tblOrder.setCompletedDate("");
			tblOrder.setFailedDate("");
			tblOrder.setVzId("");
			tblOrder.setResponseReqd(null);
			tblOrder.setStartDate("");
			tblOrder.setUpdatedDate(null);
			tblOrder.setUpstreamWoId(order.getOrderHeader().getOrderNumber());
			//tblOrder.setUpstreamFlowId(order.getCustomer().getCustomerId());
			tblOrder.setUpstreamTaskId(orderEntity); //  : TODO 13 for Validation fix this for all
			tblOrder.setTdn(null);//  :TODO Fix this BaseOrder.persist()
			tblOrder.setNpa("");
			tblOrder.setClli("CLLI");
			tblOrder.setTimezoneOffset("0");
			tblOrder.setCatalog(order.getOrderHeader().getOriginatingSystem());
			tblOrder.setWireCenter(null);
			tblOrder.setParentOrder(0L);
			tblOrder.setTranslatorId("");
			tblOrder.setLockedFromStatus(null);
			tblOrder.setLockedByVzId(null);
			tblOrder.setReturnStatus(null);
			tblOrder.setCos(""); //  : TODO Need change
			if(order.getOrderHeader().getFunctionCode().equals(OrderPass.VALIDATE))
				tblOrder.setAccountNumber("Validation");
			else if(order.getOrderHeader().getFunctionCode().equals(OrderPass.RELEASE.toString())) {	
					LOG.info("+++2+++order.getNbsEntity().getNbsType().toString() ::: {}"
							, order.getNbsEntity().getNbsType().toString());
					tblOrder.setAccountNumber(order.getNbsEntity().getNbsType().toString());
			}
			tblOrder.setTransactionNumber(order.getOrderHeader().getTransactionId().toString());
			tblOrder.setVersionNo(order.getOrderHeader().getOrderVersion());
			tblOrder.setFlowPath(FlowPath.F.toString()); // : TODO Need Change
			tblOrder.setOrderType(order.getOrderHeader().getOrderType().substring(0, 1));

			if (order.getOrderHeader().getMinorOrderType() != null) {
				tblOrder.setMinorOrderType(order.getOrderHeader().getMinorOrderType().substring(0, 1));
			}else {
				tblOrder.setMinorOrderType(order.getOrderHeader().getOrderType());
			}
			tblOrder.setSoacsCode(null); // :TODO Need Change
			tblOrder.setAction("");
			tblOrder.setApsState(0L); // :TODO Need Change
			tblOrder.setExk("");

			if (null != order.getOrderHeader().getCentrexType()
					&& OrderUtility.isOneOf(order.getOrderHeader().getCentrexType(), true, "IPAC", "IPAC1", "IPAC2")) {
				tblOrder.setProjectId("RA");
			} else {
				tblOrder.setProjectId("R");
			}
			tblOrder.setErrorCode("");
		}catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new GenericException(GenericException.GENERIC_EXCEPTION,
					"Exception occured in prepareTblOrderDataFromOrder");
		}
		LOG.info("Exit - prepareTblOrderDataFromOrder");
		return tblOrder;
	}

	/**
	 * @param order
	 * @return priority
	 */
	private Long getOrderPriorityForOrder(Order order) {
		long priority = 20;
		HashMap<String, String> ordPrioCols = null;
		
		ordPrioCols = new HashMap<String, String>();
		ordPrioCols.put("ProjectId", order.getOrderHeader().getProjectId());
		ordPrioCols.put("ORDER_SOURCE", order.getOrderHeader().getOriginatingSystem());
		ordPrioCols.put("ORDER_TYPE", OrderUtility.getOrderTypeChar(order.getOrderHeader().getEnvOrderType()));
		if (order.getOrderHeader().getMinorOrderType() != null)
			ordPrioCols.put("MINOR_ORDER_TYPE", order.getOrderHeader().getMinorOrderType().substring(0, 1));
		ordPrioCols.put("FUNCTION_CODE",
				WorkOrderEnum.OrderClassify.acronym(order.getOrderHeader().getOrderClassify()));
		ordPrioCols.put("BULK_ORDER", order.getOrderHeader().getBulkOrder());
		ordPrioCols.put("EXPEDITE", order.getOrderHeader().isExpedite() == true ? "1" : "0");

		List<TblOrderPrioritySettings> tblOrderPrioritySettingsList = getOrderPrioritySettings(ordPrioCols);

		if (tblOrderPrioritySettingsList.size() > 0) {
			for (TblOrderPrioritySettings tblOrderPrioritySettings : tblOrderPrioritySettingsList) {
				priority = tblOrderPrioritySettings.getPriority();
				break;
			}
		}

		return priority;
	}
}
