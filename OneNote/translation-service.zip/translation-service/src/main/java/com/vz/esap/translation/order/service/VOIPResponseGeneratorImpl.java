package com.vz.esap.translation.order.service;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.vz.esap.translation.enums.EsapEnum;
import com.vz.esap.translation.enums.EsapEnum.PcMilestone;
import com.vz.esap.translation.enums.EsapEnum.StatusCode;
import com.vz.esap.translation.exception.GenericException;
import com.vz.esap.translation.order.model.request.OrderHeader;
import com.vz.esap.translation.order.model.request.VOIPOrderRequest;
import com.vz.esap.translation.order.model.response.Entity;
import com.vz.esap.translation.order.model.response.OrderStatus;
import com.vz.esap.translation.order.model.response.VoipOrderResponse;

/**
 * @author chattni
 *
 */
@Component
public class VOIPResponseGeneratorImpl implements VOIPResponseGenerator {
	private static final Logger LOG = LoggerFactory.getLogger(VOIPResponseGeneratorImpl.class);

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.vz.esap.translation.order.service.VOIPResponseGenerator#
	 * prepareFailureOrderResponse(java.lang.String,
	 * com.vz.esap.translation.order.model.request.VOIPOrderRequest)
	 */
	@Override
	public VoipOrderResponse prepareFailureOrderResponse(String errorString, VOIPOrderRequest voipOrderRequest)
			throws GenericException {
		LOG.info("Entered prepareFailureOrderResponse");
		OrderStatus orderStatus = new OrderStatus();
		orderStatus.setStatusDescription(errorString);
		orderStatus.setMilestone(EsapEnum.MileStone.ESAP_DATA_ALREADY_EXISTS.getValue());
		VoipOrderResponse response = prepareCommonFailureOrderResponse(orderStatus, voipOrderRequest);
		LOG.info("Exit prepareFailureOrderResponse");
		return response;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.vz.esap.translation.order.service.VOIPResponseGenerator#
	 * prepareFailureOrderResponse(java.util.List, java.lang.String,
	 * com.vz.esap.translation.order.model.request.VOIPOrderRequest)
	 */
	@Override
	public VoipOrderResponse prepareFailureOrderResponse(Set<String> errors, String entityName,
			VOIPOrderRequest voipOrderRequest) throws GenericException {
		LOG.info("Entered prepareFailureOrderResponse");
		StringBuilder missingFiledsBuffer = new StringBuilder("");
		OrderStatus orderStatus = new OrderStatus();
		int iteration = 1;
		for (String missingfield : errors) {
			missingFiledsBuffer.append(missingfield);
			if (iteration != errors.size()) {
				missingFiledsBuffer.append("/");
			}
			iteration++;
		}
		String statusMessage = " is missing in the " + entityName + " order";
		if (errors.size() > 1) {
			statusMessage = " are missing in the " + entityName + " order";
		}
		orderStatus.setStatusDescription(missingFiledsBuffer + statusMessage);
		orderStatus.setMilestone(EsapEnum.MileStone.ESAP_MISSING_REQUIRED_DATA.getValue());
		VoipOrderResponse response = prepareCommonFailureOrderResponse(orderStatus, voipOrderRequest);
		LOG.info("Exit prepareFailureOrderResponse");
		return response;
	}

	/**
	 * @param orderStatus
	 * @param voipOrderRequest
	 * @return voipOrderResponse
	 * @throws GenericException
	 */
	VoipOrderResponse prepareCommonFailureOrderResponse(OrderStatus orderStatus, VOIPOrderRequest voipOrderRequest)
			throws GenericException {
		LOG.info("Entered prepareCommonFailureOrderResponse");

		OrderHeader orderHeader = null;
		Timestamp rcvTime = null;
		VoipOrderResponse voipOrderResponse = new VoipOrderResponse();
		try {
			orderHeader = new OrderHeader();
			orderStatus.setSystem("ESAP");
			orderStatus.setStatusCode(EsapEnum.StatusCode.ESP_FAILURE.getValue());
			rcvTime = new Timestamp(System.currentTimeMillis());
			orderStatus.setTimeStamp(rcvTime);

			orderHeader.setUNOServiceId(voipOrderRequest.getOrderHeader().getUNOServiceId());
			orderHeader.setWorkOrderNumber(voipOrderRequest.getOrderHeader().getWorkOrderNumber());
			orderHeader.setWorkOrderVersion(voipOrderRequest.getOrderHeader().getWorkOrderVersion());
			orderHeader.setTransactionID(voipOrderRequest.getOrderHeader().getTransactionID());
			orderHeader.setFunctionCode(voipOrderRequest.getOrderHeader().getFunctionCode());
			orderHeader.setOrderType(voipOrderRequest.getOrderHeader().getOrderType());
			orderHeader.setResponseType("ORDER");
		} catch (Exception e) {
			throw new GenericException(GenericException.GENERIC_EXCEPTION, "Unexpected Error while Preparing Response");
		} finally {
			voipOrderResponse.setOrderHeader(voipOrderRequest.getOrderHeader());
			voipOrderResponse.setOrderStatus(orderStatus);
		}
		LOG.info("Exit prepareCommonFailureOrderResponse");
		return voipOrderResponse;
	}

	// :Added for Successfull Response.
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.vz.esap.translation.order.service.VOIPResponseGenerator#
	 * prepareSuccessOrderResponse(com.vz.esap.translation.order.model.request.
	 * VOIPOrderRequest)
	 */
	@Override
	public VoipOrderResponse prepareSuccessOrderResponse(VOIPOrderRequest voipOrderRequest) throws GenericException {
		OrderHeader orderHeader = new OrderHeader();
		VoipOrderResponse voipOrderResponse = new VoipOrderResponse();
		Timestamp rcvTime = null;
		OrderStatus orderStatus = null;

		try {
			orderStatus = new OrderStatus();
			orderStatus.setSystem("ESAP");
			orderStatus.setStatusCode(EsapEnum.StatusCode.ESP_SUCCESS.getValue());

			rcvTime = new Timestamp(System.currentTimeMillis());
			orderStatus.setTimeStamp(rcvTime);
			orderStatus.setStatusDescription("Success");// :Get this from Enum
			orderStatus.setMilestone(EsapEnum.MileStone.WO_COMPLETE.getValue());

			orderHeader.setUNOServiceId(voipOrderRequest.getOrderHeader().getUNOServiceId());
			orderHeader.setWorkOrderNumber(voipOrderRequest.getOrderHeader().getWorkOrderNumber());
			orderHeader.setWorkOrderVersion(voipOrderRequest.getOrderHeader().getWorkOrderVersion());
			orderHeader.setTransactionID(voipOrderRequest.getOrderHeader().getTransactionID());
			orderHeader.setFunctionCode(voipOrderRequest.getOrderHeader().getFunctionCode());
			orderHeader.setOrderType(voipOrderRequest.getOrderHeader().getOrderType());
			orderHeader.setResponseType("ORDER");
		} catch (Exception e) {
			throw new GenericException(GenericException.GENERIC_EXCEPTION, "Unexpected Error while Preparing Response");
		} finally {
			voipOrderResponse.setOrderHeader(voipOrderRequest.getOrderHeader());
			voipOrderResponse.setOrderStatus(orderStatus);
		}
		return voipOrderResponse;

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.vz.esap.translation.order.service.VOIPResponseGenerator#
	 * preparePCMilestone(com.vz.esap.translation.order.model.request.
	 * VOIPOrderRequest, java.lang.String,
	 * com.vz.esap.translation.enums.EsapEnum.StatusCode, java.lang.String)
	 */
	@Override
	public VoipOrderResponse preparePCMilestone(VOIPOrderRequest voipOrderRequest, String milestone,
			StatusCode statusCode, String responseType) throws GenericException {
		LOG.info("Entered preparePCMilestone");

		VoipOrderResponse voipOrderResponse = new VoipOrderResponse();
		Timestamp rcvTime = null;
		OrderStatus orderStatus = null;
		OrderHeader orderHeader = null;

		try {
			orderHeader = new OrderHeader();
			orderHeader.setWorkOrderNumber(voipOrderRequest.getOrderHeader().getWorkOrderNumber());
			orderHeader.setUNOServiceId(voipOrderRequest.getOrderHeader().getUNOServiceId());
			orderHeader.setFunctionCode(voipOrderRequest.getOrderHeader().getFunctionCode());
			orderHeader.setTransactionID(voipOrderRequest.getOrderHeader().getTransactionID());
			orderHeader.setWorkOrderVersion(voipOrderRequest.getOrderHeader().getWorkOrderVersion());
			orderHeader.setOrderType(voipOrderRequest.getOrderHeader().getOrderType());
			orderHeader.setOriginatingSystem("ESAP");
			orderHeader.setResponseType(responseType);

			voipOrderResponse.setOrderHeader(orderHeader);

			orderStatus = new OrderStatus();
			orderStatus.setStatusCode(statusCode.getValue());
			orderStatus.setStatusDescription(statusCode.toString());
			
			//Error descripton added for ESL Location suspend.
			if(PcMilestone.REL_SUSPEND.getValue().equalsIgnoreCase(milestone)) {
				orderStatus.setStatusDescription("ESL Can not be Deleted as EBL Exists");
			}
			
			orderStatus.setMilestone(milestone);
			orderStatus.setSystem("ESAP");

			voipOrderResponse.setOrderStatus(orderStatus);

		} catch (Exception e) {
			throw new GenericException(GenericException.GENERIC_EXCEPTION,
					"Unexpected Error while Preparing PCMilestone");
		} finally {
			voipOrderRequest.getOrderHeader().setResponseType(responseType);
			voipOrderResponse.setOrderHeader(voipOrderRequest.getOrderHeader());
			voipOrderResponse.setOrderStatus(orderStatus);
		}
		LOG.info("Exited preparePCMilestone");

		return voipOrderResponse;

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.vz.esap.translation.order.service.VOIPResponseGenerator#
	 * preparePCMilestone(com.vz.esap.translation.order.model.request.
	 * VOIPOrderRequest, java.lang.String,
	 * com.vz.esap.translation.enums.EsapEnum.StatusCode, java.lang.String,
	 * java.util.Map)
	 */
	@Override
	public VoipOrderResponse preparePCMilestone(VOIPOrderRequest voipOrderRequest, String milestone,
			StatusCode statusCode, String responseType, Map<String, String> paramNameValue) throws GenericException {
		LOG.info("Entered preparePCMilestone");

		VoipOrderResponse voipOrderResponse = new VoipOrderResponse();
		ObjectMapper mapper = null;
		OrderStatus orderStatus = null;
		OrderHeader orderHeader = null;

		try {
			mapper = new ObjectMapper();

			orderHeader = new OrderHeader();
			orderHeader.setWorkOrderNumber(voipOrderRequest.getOrderHeader().getWorkOrderNumber());
			orderHeader.setUNOServiceId(voipOrderRequest.getOrderHeader().getUNOServiceId());
			orderHeader.setFunctionCode(voipOrderRequest.getOrderHeader().getFunctionCode());
			orderHeader.setTransactionID(voipOrderRequest.getOrderHeader().getTransactionID());
			orderHeader.setWorkOrderVersion(voipOrderRequest.getOrderHeader().getWorkOrderVersion());
			orderHeader.setOrderType(voipOrderRequest.getOrderHeader().getOrderType());
			orderHeader.setOriginatingSystem("ESAP");
			orderHeader.setResponseType(responseType);

			voipOrderResponse.setOrderHeader(orderHeader);

			orderStatus = new OrderStatus();
			orderStatus.setStatusCode(statusCode.getValue());
			orderStatus.setStatusDescription(statusCode.toString());
			orderStatus.setMilestone(milestone);
			orderStatus.setSystem("ESAP");

			List<Entity> entities = new ArrayList<>();

			for (Map.Entry<String, String> entry : paramNameValue.entrySet()) {

				addEntityToList(entry.getKey(), entry.getValue(), entities);
			}

			orderStatus.setEntities(entities);

			voipOrderResponse.setOrderStatus(orderStatus);

			LOG.info("Inside preparePCMilestone : voipOrderResponse:{}",
					mapper.writerWithDefaultPrettyPrinter().writeValueAsString(voipOrderResponse));

		} catch (Exception e) {
			throw new GenericException(GenericException.GENERIC_EXCEPTION,
					"Unexpected Error while Preparing PCMilestone");
		} finally {
			voipOrderRequest.getOrderHeader().setResponseType(responseType);
			voipOrderResponse.setOrderHeader(voipOrderRequest.getOrderHeader());
			voipOrderResponse.setOrderStatus(orderStatus);
		}
		LOG.info("Exited preparePCMilestone");

		return voipOrderResponse;

	}

	/**
	 * @param key
	 * @param value
	 * @param entityList
	 * @return
	 */
	public List<Entity> addEntityToList(String key, String value, List<Entity> entityList) {
		Entity entity = new Entity();
		entity.setType(key);
		entity.setValue(value);
		entityList.add(entity);
		return entityList;
	}

}