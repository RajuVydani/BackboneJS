package com.vz.esap.translation.order.model.request;

public class AdditionalInfo {

	private String BillingAccountNumber;

	private AccessInfo[] AccessInfo;

	private String ProductCode;

	private Ecm[] Ecm;

	private String DayLightSavingsInd;

	private CNAMInfo[] CNAMInfo;

	private GCMInfo GCMInfo;

	private String TimeZone;

	private String LocationReferenceId;

	private String TransitionType;

	public String getBillingAccountNumber() {
		return BillingAccountNumber;
	}

	public void setBillingAccountNumber(String BillingAccountNumber) {
		this.BillingAccountNumber = BillingAccountNumber;
	}

	public AccessInfo[] getAccessInfo() {
		return AccessInfo;
	}

	public void setAccessInfo(AccessInfo[] AccessInfo) {
		this.AccessInfo = AccessInfo;
	}

	public String getProductCode() {
		return ProductCode;
	}

	public void setProductCode(String ProductCode) {
		this.ProductCode = ProductCode;
	}

	public Ecm[] getEcm() {
		return Ecm;
	}

	public void setEcm(Ecm[] Ecm) {
		this.Ecm = Ecm;
	}

	public String getDayLightSavingsInd() {
		return DayLightSavingsInd;
	}

	public void setDayLightSavingsInd(String DayLightSavingsInd) {
		this.DayLightSavingsInd = DayLightSavingsInd;
	}

	public CNAMInfo[] getCNAMInfo() {
		return CNAMInfo;
	}

	public void setCNAMInfo(CNAMInfo[] CNAMInfo) {
		this.CNAMInfo = CNAMInfo;
	}

	public GCMInfo getGCMInfo() {
		return GCMInfo;
	}

	public void setGCMInfo(GCMInfo GCMInfo) {
		this.GCMInfo = GCMInfo;
	}

	public String getTimeZone() {
		return TimeZone;
	}

	public void setTimeZone(String TimeZone) {
		this.TimeZone = TimeZone;
	}

	public String getLocationReferenceId() {
		return LocationReferenceId;
	}

	public void setLocationReferenceId(String LocationReferenceId) {
		this.LocationReferenceId = LocationReferenceId;
	}

	public String getTransitionType() {
		return TransitionType;
	}

	public void setTransitionType(String TransitionType) {
		this.TransitionType = TransitionType;
	}

	public String toString() {
		return "ClassPojo [BillingAccountNumber = " + BillingAccountNumber + ", AccessInfo = " + AccessInfo
				+ ", ProductCode = " + ProductCode + ", Ecm = " + Ecm + ", DayLightSavingsInd = " + DayLightSavingsInd
				+ ", CNAMInfo = " + CNAMInfo + ", GCMInfo = " + GCMInfo + ", TimeZone = " + TimeZone
				+ ", LocationReferenceId = " + LocationReferenceId + ", TransitionType = " + TransitionType + "]";
	}
}
