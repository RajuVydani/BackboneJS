package com.vz.esap.translation.exception;

/*
 * TranslatorException.java
 *
 */

@SuppressWarnings("serial")

public class TranslatorException extends java.lang.Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private ErrorCode errorCode = null;
	private String errorDesc = null;

	public static enum ErrorCode {
		RETRY_APP_ERROR(true), RETRY_SCENARIO(true), ORDER_NOT_SAVABLE, INVALID_XML,
		INTERNAL_ERROR, VOIP_ORDER_NOT_FOUND, MISSING_ORDER_SEGMENT, INVALID_DATE,  
		INVALID_SEGMENT_NUMBER, GROUP_NOT_FOUND, HALTED_FOR_MANUAL_INPUT,
		VALIDATION_ORDER_NOT_FOUND, VALIDATION_NOT_COMPLETE, ORD_VER_OUTOF_SYNC, 
		LOCAL_ORDER_NOT_SUPPORTED, ESAP_MISSING_REQUIRED_DATA, ESAP_DATA_ALREADY_EXISTS, 
		DUPLICATE_EBI_IP_ADDRESS_NOT_ALLOWED, ORDER_DETAILS_CREATION_FAILURE, ORDER_CREATION_FAILURE, 
		ENV_ORDER_CREATION_FAILURE, ENV_ORDER_MGR_CREATION_FAILURE, SERVICE_ORDER_CREATION_FAILURE,
		PARSER_EXCEPTION, ET_TRANSFORMATION_FAILURE, ENTERPRISE_TRANSFORMATION_FAILURE, 
        ET_INFORMATION_FAILURE, ORDER_VALIDATION_FAILURE, CT_TRANSFORMATION_FAILURE,
        VOIP_RESPONSE_NOT_FOUND, TRUNK_TRANSFORMATION_FAILURE, DATA_NOT_FOUND, 
        ENV_ORDER_DETAILS_CREATION_FAILURE, ESIP_ESL_ORDER_NOT_FOUND, LOCATION_TRANSFORMATION_FAILURE,
        TRANSFORMER_FAILURE, COLUMN_METADATA_MISSING, MANDATORY_FIELDS_MISSING,CLLI_MISSING, PC_TN_FETCH_FAILURE, 
        STRING_INTEGER_CONVERSION_FAILURE, STRING_LONG_CONVERSION_FAILURE, RELEASE_ORDER_NOT_FOUND, 
        ORDER_DETAILS_UPSERT_ERROR, ENV_ORDER_NOT_FOUND, TBL_ORDER_RECORD_NOT_FOUND, TBL_ORDER_DETAILS_RECORD_NOT_FOUND,
        UNSUPPORTED_TABLE_TYPE, HPBX_NNI_MISSING, EBL_EXISTS_FOR_THE_ESL, INVENTORY_RECORD_MISSING, BS_AS_ID_MISSING,
        ETERPRISE_MISSING, LOCATION_MISSING, BW_LOC_ID_NOT_FOUND
        ;

		boolean retryError;

		ErrorCode() {
			retryError = false;
		}

		ErrorCode(boolean retry) {
			retryError = retry;
		}

		public boolean isRetryError() {
			return retryError;
		}

	};

	public TranslatorException(ErrorCode eCode, String eDesc) {
		super(eDesc);
		this.errorCode = eCode;
		this.errorDesc = eDesc;
	}

	public ErrorCode getErrorCode() {
		return this.errorCode;
	}

	public void setErrorCode(ErrorCode errorCode) {
		this.errorCode = errorCode;
	}

	public String getErrorDesc() {
		return this.errorDesc;
	}

	public void setErrorDesc(String errorDesc) {
		this.errorDesc = errorDesc;
	}

	public String toString() {
		return String.valueOf(errorCode)+ ":" + errorDesc;
	}
}
