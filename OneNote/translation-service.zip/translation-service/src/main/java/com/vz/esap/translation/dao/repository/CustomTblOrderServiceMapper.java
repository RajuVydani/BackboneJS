package com.vz.esap.translation.dao.repository;

import java.util.List;
import java.util.Map;

import com.vz.esap.translation.dao.model.TblOrderService;

public interface CustomTblOrderServiceMapper extends TblOrderServiceMapper {

	long createTblOrderService(TblOrderService tblOrderService);

	List<TblOrderService> getOrderServiceList(Long prevOrderId);
	
	void updateOrderServiceStatusByOrderIdOptionalSeqNum(long orderId, long seqNumber, long serviceStatus);
	
	List<String> getSkipTasksForReverseService(Map<String, Object> params);
	
	String getAsClli(String bsAsId);

	String getBwCluster(String bsAsId);
	
}
