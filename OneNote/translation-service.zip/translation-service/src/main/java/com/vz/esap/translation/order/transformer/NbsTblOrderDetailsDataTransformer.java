package com.vz.esap.translation.order.transformer;

import java.text.ParseException;
import java.util.ArrayList;

import com.vz.esap.translation.dao.model.TblOrder;
import com.vz.esap.translation.entity.NbsEntity;
import com.vz.esap.translation.exception.TranslatorException;
import com.vz.esap.translation.order.model.Order;
import com.vz.esap.translation.order.model.request.ParamInfo;
import com.vz.esap.translation.order.model.request.VOIPOrderRequest;

/**
 * @author kalagsu
 *
 */
public interface NbsTblOrderDetailsDataTransformer {

	/**
	 * @param voipOrderRequest
	 * @param tblOrderObject
	 * @param nbsEntityList
	 * @param paramRoot
	 *            TODO
	 * @return paramInfoList
	 */
	ArrayList<ParamInfo> prepareTblOrderDetailsEntityParamDataForNbs(VOIPOrderRequest voipOrderRequest,
			TblOrder tblOrderObject, ArrayList<NbsEntity> nbsEntityList, ParamInfo paramRoot);

	/**
	 * @param order
	 * @return root
	 * @throws ParseException
	 * @throws TranslatorException
	 */
	ParamInfo prepareTblOrderDetailsHeaderParamData(Order order) throws ParseException, TranslatorException;

	/**
	 * @param order
	 * @return root
	 * @throws TranslatorException
	 */
	ParamInfo prepareTblOrderDetailsEntityParamDataForNbs(Order order) throws TranslatorException;

	/**
	 * @param nbsEntityPrev
	 * @param nbsEntity
	 * @param supp
	 * @param paramRoot
	 * @return paramInfo
	 * @throws TranslatorException
	 */
	ParamInfo prepareTblOrderDetailsEntityParamDataForNbs(NbsEntity nbsEntityPrev, NbsEntity nbsEntity, boolean supp,
			String paramRoot) throws TranslatorException;

	/**
	 * @param order
	 * @param nbsEntityPrev
	 * @param supp
	 * @return paramInfo
	 * @throws TranslatorException
	 */
	ParamInfo prepareTblOrderDetailsHeaderParamData(Order order, NbsEntity nbsEntityPrev, boolean supp)
			throws TranslatorException;

	/**
	 * 
	 * @param enrichedNbsEntityList
	 * @param b
	 * @param object
	 * @return
	 */
	ArrayList<ParamInfo> prepareTblOrderDetailsEntityParamDataForNbs(ArrayList<NbsEntity> enrichedNbsEntityList,
			boolean b, Object object);
}
