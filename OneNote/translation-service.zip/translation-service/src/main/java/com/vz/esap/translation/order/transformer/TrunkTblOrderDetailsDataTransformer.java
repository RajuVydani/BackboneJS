package com.vz.esap.translation.order.transformer;

import java.text.ParseException;
import java.util.ArrayList;

import com.vz.esap.translation.dao.model.TblOrder;
import com.vz.esap.translation.entity.TrunkGroupEntity;
import com.vz.esap.translation.exception.TranslatorException;
import com.vz.esap.translation.order.model.Order;
import com.vz.esap.translation.order.model.request.ParamInfo;
import com.vz.esap.translation.order.model.request.VOIPOrderRequest;

/**
 * @author kalagsu
 *
 */
public interface TrunkTblOrderDetailsDataTransformer {

	/**
	 * @param order
	 * @return root
	 * @throws TranslatorException
	 */
	ParamInfo prepareTblOrderDetailsEntityParamDataForTrunk(Order order, String action) throws TranslatorException;// release
																													// pass

	/**
	 * @param voipOrderRequest
	 * @param tblOrderObject
	 * @param trunkGroup
	 * @return paramInfoList
	 */
	ArrayList<ParamInfo> prepareTblOrderDetailsEntityParamDataForTrunk(VOIPOrderRequest voipOrderRequest,
			TblOrder tblOrderObject, ArrayList<TrunkGroupEntity> trunkGroup);// val pass

	/**
	 * @param order
	 * @return root
	 * @throws ParseException
	 * @throws TranslatorException
	 */
	ParamInfo prepareTblOrderDetailsHeaderParamData(Order order) throws ParseException, TranslatorException;

	/**
	 * @param oldTrunkEntity
	 * @param trunkEntity
	 * @param supp
	 * @param action
	 * @return paramInfo
	 * @throws TranslatorException
	 */
	ParamInfo prepareTblOrderDetailsEntityParamDataForTrunk(TrunkGroupEntity oldTrunkEntity,
			TrunkGroupEntity trunkEntity, boolean supp, String action) throws TranslatorException;

	/**
	 * @param order
	 * @param trunkEntityPrev
	 * @param supp
	 * @return paramInfo
	 * @throws TranslatorException
	 */
	ParamInfo prepareTblOrderDetailsHeaderParamData(Order order, TrunkGroupEntity trunkEntityPrev, boolean supp)
			throws TranslatorException;

	/**
	 * 
	 * @param enrichedTrunkGrp
	 * @param b
	 * @param trunkGroup
	 * @return
	 */
	ArrayList<ParamInfo> prepareTblOrderDetailsEntityParamDataForTrunk(ArrayList<TrunkGroupEntity> enrichedTrunkGrp,
			boolean b, Object trunkGroup);
}