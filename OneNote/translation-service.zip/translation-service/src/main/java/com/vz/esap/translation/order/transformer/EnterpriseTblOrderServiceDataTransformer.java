package com.vz.esap.translation.order.transformer;

import java.util.List;

import org.springframework.stereotype.Component;

import com.vz.esap.translation.dao.model.TblOrder;
import com.vz.esap.translation.dao.model.TblOrderService;
import com.vz.esap.translation.exception.GenericException;
import com.vz.esap.translation.exception.TranslatorException;
import com.vz.esap.translation.order.model.Order;
import com.vz.esap.translation.order.model.request.ParamInfo;

@Component
public interface EnterpriseTblOrderServiceDataTransformer {

	/**
	 * @param region
	 * @param tblOrderObject
	 * @return tblOrderServiceList
	 * @throws TranslatorException
	 * @throws GenericException 
	 */
	List<TblOrderService> prepareTblOrderServiceDataValidate(String region, TblOrder tblOrderObject) throws TranslatorException, GenericException;

	/**
	 * @param order
	 * @param orderPrevPass
	 * @param entityParamInfo
	 * @return tblOrderServiceList
	 * @throws TranslatorException
	 */
	List<TblOrderService> prepareTblOrderServiceData(Order order, Order orderPrevPass, ParamInfo entityParamInfo)
			throws TranslatorException;

	
	/**
	 * @param tblOrderObjectOrig
	 * @param tblOrderObjectCurrent
	 * @return tblOrderServiceList
	 * @throws TranslatorException
	 * @throws GenericException
	 */
	List<TblOrderService> prepareTblOrderServiceForReverseOrder(TblOrder tblOrderObjectOrig,
			TblOrder tblOrderObjectCurrent) throws TranslatorException, GenericException;

}
