package com.vz.esap.translation.util;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.vz.esap.translation.dao.model.TblOrder;
import com.vz.esap.translation.dao.model.TblOrderDetails;
import com.vz.esap.translation.exception.GenericException;
import com.vz.esap.translation.exception.TranslatorException;
import com.vz.esap.translation.exception.TranslatorException.ErrorCode;
import com.vz.esap.translation.order.dao.VOIPOrderDao;
import com.vz.esap.translation.order.model.request.ParamInfo;
import com.vz.esap.translation.order.model.request.VOIPOrderRequest;
import com.vz.esap.translation.order.service.helper.OrderServiceHelper;

@Component
public class TranslationUtility {

	private static final Logger LOG = LoggerFactory.getLogger(TranslationUtility.class);

	@Autowired
	private OrderServiceHelper orderServiceHelperImpl;
	
	@Autowired
	private VOIPOrderDao voipOrderDao;
	
	@Autowired
	private InventoryUtil inventoryUtil;
	
	public void populateEntityFlag(TblOrder tblOrderObject) throws GenericException{
		List<TblOrderDetails> tblOrderDetailsList;
		LOG.info("Entered EntityCheck");
		try {
			tblOrderDetailsList = orderServiceHelperImpl.getMatchingOrderDetails(tblOrderObject);
			if (tblOrderDetailsList.isEmpty()) {

				ArrayList<ParamInfo> headerParamInfo = new ArrayList<>();
				ParamInfo root = new ParamInfo("EntityFlag", "N", null);
				headerParamInfo.add(root);

				voipOrderDao.populateOrderDetails(tblOrderObject, headerParamInfo, "c", 0, 0);
				LOG.info("populating EntityFlag in TOD");
			}
		}catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new GenericException(GenericException.GENERIC_EXCEPTION,
					"Exception occured in EntityCheck");
		}
		LOG.info("Exit EntityCheck");
	}
	
	public Boolean isEntityFlagExists(TblOrder tblOrder) throws GenericException {
		LOG.info("Entered isEntityFlagExists");
		Boolean entityFlag = false;
		List<TblOrderDetails> tblOrderDetailsList;
		try {
		tblOrderDetailsList = voipOrderDao.getOrderDetailsEntriesPerOrder(tblOrder);
			if(tblOrderDetailsList!= null && !tblOrderDetailsList.isEmpty()) {
				for(TblOrderDetails tblOrderDetails : tblOrderDetailsList) {
					if ("EntityFlag".equalsIgnoreCase(tblOrderDetails.getParamName())) {
						entityFlag = true;
						break;
					}
				}
			}
		}catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new GenericException(GenericException.GENERIC_EXCEPTION,
					"Exception occured in isEntityFlagExists");
		}
		LOG.info("Exit isEntityFlagExists");
		return entityFlag;
	}
	
	public VOIPOrderRequest setAsClli(VOIPOrderRequest voipOrderRequest) throws TranslatorException {
		LOG.info("Entered - setAsClli()");
		try {
			String bsAppServer = inventoryUtil.getBSAppServer(voipOrderRequest);
			voipOrderRequest.getOrderHeader().setBsAppServer(bsAppServer);
			voipOrderRequest.getOrderHeader().setAsClli(voipOrderDao.getAsClli(bsAppServer)); //Getting AsClli from bsAppServerId
			voipOrderRequest.getOrderHeader().setBwCluster(voipOrderDao.getBwCluster(bsAppServer)); //Getting BwCluster from bsAppServerId

		} catch (Exception e) {
			LOG.error("Exception {} ", e);
			throw new TranslatorException(ErrorCode.TRANSFORMER_FAILURE, "Exception occured in setAsClli");
		}
		LOG.info("Exit - setAsClli()");
		return voipOrderRequest;
	}

}
