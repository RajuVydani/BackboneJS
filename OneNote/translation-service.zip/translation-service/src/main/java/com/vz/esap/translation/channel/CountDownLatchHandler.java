package com.vz.esap.translation.channel;

import java.util.concurrent.CountDownLatch;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageHandler;
import org.springframework.messaging.MessagingException;

import com.google.gson.Gson;
import com.vz.esap.translation.order.model.request.VOIPOrderRequest;
import com.vz.esap.translation.service.TranslationService;

import org.springframework.stereotype.Component;

@Component
public class CountDownLatchHandler implements MessageHandler {

	private static final Logger LOG = LoggerFactory.getLogger(CountDownLatchHandler.class);

	@Autowired
	private TranslationService translationService;

	@Value("${server.port}")
	String port;

	@Value("${kafka.topic.vrd-order-topic}")
	private String vrdOrderTopic;

	private CountDownLatch latch = new CountDownLatch(10);

	private Message<?> message = null;

	public CountDownLatch getLatch() {
		return latch;
	}

	public Message<?> getMessage() {
		return message;
	}

	@Override
	public void handleMessage(Message<?> message) throws MessagingException {
		this.message = message;
		LOG.info("received message='{}'", message);

		consumeMessage(message.getPayload().toString());
		latch.countDown();
	}

	public VOIPOrderRequest consumeMessage(String payload) {
		VOIPOrderRequest voipOrderRequest = null;
		try {
			LOG.debug("Received Message from TOPIC :{} is {}", vrdOrderTopic, payload);

			Gson gson = new Gson();
			voipOrderRequest = gson.fromJson(payload, VOIPOrderRequest.class);
			LOG.info("voipOrderRequest: {} , translationService: {} ", voipOrderRequest, translationService);
			translationService.translateOrder(voipOrderRequest);
		} catch (Exception e) {
			LOG.error("Exception while translating the order:", e.getMessage(), e);
		}
		return voipOrderRequest;
	}
}
