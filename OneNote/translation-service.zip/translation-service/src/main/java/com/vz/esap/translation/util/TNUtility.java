package com.vz.esap.translation.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.vz.esap.translation.entity.TNEntity;
import com.vz.esap.translation.entity.TNEntity.DeleteType;
import com.vz.esap.translation.entity.TNEntity.PortInType;
import com.vz.esap.translation.entity.TNEntity.PortOutType;
import com.vz.esap.translation.entity.TNEntity.PortStatus;
import com.vz.esap.translation.exception.TranslatorException;
import com.vz.esap.translation.order.model.request.ParamInfo;

import EsapEnumPkg.TNEnum;
import EsapEnumPkg.VzbVoipEnum;

/**
 * @author baigkh
 *
 */
public class TNUtility extends OrderUtility {

	private static final Logger LOG = LoggerFactory.getLogger(TNUtility.class);

	public static TNEntity createInstanceFromParamInfo(ParamInfo parent) throws TranslatorException {
		return createInstanceFromParamInfo(parent, null);
	}

	public static TNEntity createInstanceFromParamInfo(ParamInfo parent, TNEntity tn) throws TranslatorException {
		
		if (parent == null)
			return null;

		if (tn == null)
			tn = new TNEntity();

		if (parent.getChildParams() == null)
			return tn;

		for (ParamInfo param : parent.getChildParams()) {

			if (("TN").equals(param.getName()))
				tn.setTn(param.getValue());
			else if (("TnPoolId").equals(param.getName()) && (param.getValue() != null))
				tn.setTNPoolId(new Long(param.getValue()));
			else if (("CustomerId").equals(param.getName()))
				tn.setCustomerId(param.getValue());
			else if (("LocationId").equals(param.getName()))
				tn.setLocationId(param.getValue());
			else if (("PortingFlag").equals(param.getName()))
				tn.setPortingFlag(param.getValue());
			else if (("Territory").equals(param.getName()))
				tn.setTerritory(param.getValue());
			else if (("PortStatus").equals(param.getName()) && param.getValue() != null)
				tn.setPortStatus(TNEntity.PortStatus.valueOf(param.getValue()));
			else if (("RealTrunkGroupNumber").equals(param.getName()))
				tn.setTrunkId(param.getValue());
			else if (("SwitchCLLI").equals(param.getName()))
				tn.setSwitchClli(param.getValue());
			else if (("ReplacementCLLI").equals(param.getName()))
				tn.setReplacementCLLI(param.getValue());
			else if (("TnActivation").equals(param.getName()) && param.getValue() != null)
				tn.setOnOffStatus(TNEntity.OnOffStatus.valueOf(param.getValue()));
			else if (("TSPCode").equals(param.getName()) && param.getValue() != null)
				tn.setTspCode(param.getValue());
			else if (("Lidb").equals(param.getName()))
				tn.setLidb(param.getValue());
			else if (("TnDisposition").equals(param.getName()))
				tn.setTnDisposition(param.getValue());
			else if (("EmergencyFirstName").equals(param.getName()))
				tn.setEmergencyFirstName(param.getValue());
			else if (("EmergencyMiddleName").equals(param.getName()) && param.getValue() != null)
				tn.setEmergencyMiddleName(param.getValue());
			else if (("EmergencyLastName").equals(param.getName()) && param.getValue() != null)
				tn.setEmergencyLastName(param.getValue());			
			else if (("EmergencyBldngDesignator").equals(param.getName()))
				tn.setEmergencyBldngDesignator(param.getValue());
			else if (("EmergencyBldngValue").equals(param.getName()))
				tn.setEmergencyBldngValue(param.getValue());
			else if (("EmergencyFloorValue").equals(param.getName()))
				tn.setEmergencyFloorValue(param.getValue());
			else if (("EmergencyFloorDesignator").equals(param.getName()) && param.getValue() != null)
				tn.setEmergencyFloorDesignator(param.getValue());
			else if (("EmergencyRoomValue").equals(param.getName()) && param.getValue() != null)
				tn.setEmergencyRoomValue(param.getValue());			
			else if (("EmergencyRoomDesignator").equals(param.getName()))
				tn.setEmergencyRoomDesignator(param.getValue());
			else if (("CnamOutBoundFirstName").equals(param.getName()))
				tn.setCnamOutBoundFirstName(param.getValue());
			else if (("CnamOutBoundLastName").equals(param.getName()))
				tn.setCnamOutBoundLastName(param.getValue());
			else if (("NewVerizonBTN").equals(param.getName()) && param.getValue() != null)
				tn.setNewVerizonBTN(param.getValue());
			else if (("TnTypeOrdering").equals(param.getName()) && param.getValue() != null)
				tn.setTnTypeOrdering(param.getValue());			
			else if (("IndustryPortability").equals(param.getName()))
				tn.setIndustryPortability(param.getValue());
			else if (("PortingServiceAddress").equals(param.getName()))
				tn.setPortingServiceAddress(param.getValue());
			else if (("IldRestriction").equals(param.getName()))
				tn.setIldRestriction(param.getValue());
			else if (("CurrentLecBtn").equals(param.getName()) && param.getValue() != null)
				tn.setCurrentLecBtn(param.getValue());
			else if (("Nomadic911").equals(param.getName()) && param.getValue() != null)
				tn.setNomadic911(param.getValue());			
			else if (("TnAssignment").equals(param.getName()))
				tn.setTnAssignment(param.getValue());
			else if (("PointToNumber").equals(param.getName()))
				tn.setPointToNumber(param.getValue());
			else if (("Provider").equals(param.getName()) && param.getValue() != null)
				tn.setProvider(param.getValue());
			else if (("HuntGroupSequence").equals(param.getName()) && param.getValue() != null)
				tn.setHuntGroupSequence(param.getValue());
			
			
			else if (("PubIp").equals(param.getName()) && param.getValue() != null) {
				Integer pubip = null;
				try {
					pubip = Integer.decode(param.getValue());
				} catch (Exception e) {
					LOG.error("Exception {} ", e.getMessage());
					throw new TranslatorException(TranslatorException.ErrorCode.STRING_INTEGER_CONVERSION_FAILURE,
							"Unexpected Error Occured while decode PubIp value to Integer \"") ;
				}
				tn.setPubIp(pubip);
			} else if (("PubIpIn").equals(param.getName()) && param.getValue() != null)// VOV
			{
				Integer pubipin = null;
				try {
					pubipin = Integer.decode(param.getValue());
				} catch (Exception e) {
					LOG.error("Exception {} ", e.getMessage());
					throw new TranslatorException(TranslatorException.ErrorCode.STRING_INTEGER_CONVERSION_FAILURE,
							"Unexpected Error Occured while decode PubIpIn value to Integer \"") ;
				}
				tn.setPubIpIn(pubipin);
			} else if (("PubIpOut").equals(param.getName()) && param.getValue() != null) {
				Integer pubipout = null;
				try {
					pubipout = Integer.decode(param.getValue());
				} catch (Exception e) {
					LOG.error("Exception {} ", e.getMessage());
					throw new TranslatorException(TranslatorException.ErrorCode.STRING_INTEGER_CONVERSION_FAILURE,
							"Unexpected Error Occured while decode PubIpOut value to Integer \"") ;
				}
				tn.setPubIpOut(pubipout);
			} else if (("ExistingTN").equals(param.getName()) && param.getValue() != null)
				tn.setExistingTN(getBooleanFromYN(param.getValue()));
			else if (("Available").equals(param.getName()) && param.getValue() != null)
				tn.setAvailable(getBooleanFromYN(param.getValue()));
			else if (("STNInd").equals(param.getName()) && param.getValue() != null)
				tn.setSTNInd(Long.decode(param.getValue()));
			else if (("SubscriberId").equals(param.getName()) && param.getValue() != null)
				tn.setSubscriberId(getLongFromString(param.getValue()));
			else if (("GroupTNId").equals(param.getName()) && param.getValue() != null)
				tn.setGroupTNId(getLongFromString(param.getValue()));
			/*else if (("TnType").equals(param.getName()) && param.getValue() != null)
				tn.setTnTypeEnum(param.getValue());*/
			else if (("DeviceName").equals(param.getName()) && param.getValue() != null)
					tn.setDeviceName(param.getValue());
			else if (("EntityAction").equals(param.getName()) && param.getValue() != null)
				tn.setEntityAction(param.getValue());
			else if (("LinePort").equals(param.getName()) && param.getValue() != null)
				tn.setLinePort(param.getValue());
			else if (("PortInType").equals(param.getName()) && param.getValue() != null)
				tn.setPortInType(PortInType.valueOf(param.getValue()));
			else if (("TNDeleteType").equals(param.getName()) && param.getValue() != null)
				tn.setDeleteType(DeleteType.valueOf(param.getValue()));
			else if (("PortOutType").equals(param.getName()) && param.getValue() != null)
				tn.setPortOutType(PortOutType.valueOf(param.getValue()));
			else if (("PortingIndicator").equals(param.getName()) && param.getValue() != null)
				tn.setPortingIndicator(param.getValue());
			else if (("SubStatus").equals(param.getName()) && param.getValue() != null)
				tn.setSubStatus(param.getValue());
			else if (("OriginalCarrierPrefix").equals(param.getName()) && param.getValue() != null)
				tn.setOriginalCarrierPrefix(param.getValue());
			else if (("GainingCarrierPrefix").equals(param.getName()) && param.getValue() != null)
				tn.setGainingCarrierPrefix(param.getValue());
			else if (("LosingCarrierPrefix").equals(param.getName()) && param.getValue() != null)
				tn.setLosingCarrierPrefix(param.getValue());
			else if (("GatewayNumber").equals(param.getName()) && param.getValue() != null)
				tn.setGatewayNumber(param.getValue());
			else if (("ActDeact").equals(param.getName()) && param.getValue() != null) {
				try {
					tn.setActDeact(Integer.parseInt(param.getValue()));
				} catch (NumberFormatException e) {
					LOG.error("Exception {} ", e.getMessage());
					throw new TranslatorException(TranslatorException.ErrorCode.PARSER_EXCEPTION,
							"Unexpected Error Occured while parsing ActDeact value to Integer \"") ;
				}
			} else if (("TransitionType").equals(param.getName()) && param.getValue() != null)
				tn.setTransitionType(TNEnum.TransitionType.valueByAcronym(param.getValue()));
			else if (("OldLocationId").equals(param.getName()) && param.getValue() != null)
				tn.setOldLocationId(param.getValue());
			else if (("OldLocationEmptyFlag").equals(param.getName()) && param.getValue() != null) {
				if (param.getValue() == "Y")
					tn.setOldLocationEmptyFlag(Boolean.TRUE);
			}
			// This is done.. since for res TN orders, unline any other entity
			// orders,
			// the entity params are being persisted under root "TNRecord" tag
			// in TOD
			// Also, we want to populate locId and custId from header into
			// TNRecord obj
			// to continue how it was done before this change( root param in
			// TOD).
			else if (("TNRecord").equals(param.getName()))
				createInstanceFromParamInfo(param, tn);
			else if (("AdditionalAttribs").equals(param.getName())) {
				if (param.getChildParams() != null)
					for (ParamInfo par2 : param.getChildParams())
						tn.addAttrib(par2.getName(), par2.getValue());
			} else if (("HotCutIndicator").equals(param.getName())) {
				if (param.getValue() != null && param.getValue().equals("Y"))
					tn.setHotCutIndicator(Boolean.TRUE);
			} else if (("CDDDIndicator").equals(param.getName())) {
				if (param.getValue() != null && param.getValue().equals("Y"))
					tn.setCDDDIndicator(Boolean.TRUE);
			} else if (("PSALI").equals(param.getName()) && param.getValue() != null) {
				tn.setPSALI(param.getValue());
			} else if (("VerizonBTN").equals(param.getName()) && param.getValue() != null) {
				LOG.info("in TNUTIL ->VerizonBTN->" + param.getValue());

				tn.setVerizonBTN(param.getValue());
			}

		}

		return tn;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.vz.esap.translation.order.transformer.
	 * TNTblOrderDetailsDataTransformer#buildTNParamDataForTN
	 * (com.vz.esap.translation.entity.TNEntity, java.lang.String)
	 */
	public static ParamInfo buildTNParamDataForTN(TNEntity tnRecord, String action) {

		LOG.info("Entered  buildTNParamDataForTN");
		
		ParamInfo root = null;

		root = new ParamInfo("TNRecord", null, action);
		if ("I".equals(action)) {
			root.addChildParam(new ParamInfo("PTN", "ADD", action));
		} else if ("O".equals(action)) {
			root.addChildParam(new ParamInfo("PTN", "DEL", action));
		} else if ("C".equals(action)) {
			root.addChildParam(new ParamInfo("PTN", "MOD", action));
		}
		
		root.addNotNullValChild("TN", tnRecord.getTn(), action, ParamInfo.Tag.NAME);
		root.addNotNullValChild("TnPoolId", tnRecord.getTnPoolId(), action, null);
		root.addNotNullValChild("TNPoolId", tnRecord.getTnPoolId(), action, null);

		if (null == tnRecord.getPortingFlag()) {
			tnRecord.setPortingFlag("N");
			if (tnRecord.getPortStatus() != null && tnRecord.getPortStatus() == PortStatus.PORT_PENDING) {
				tnRecord.setPortingFlag("Y");
			}
		}
		root.addNotNullValChild("Region", tnRecord.getRegion(), action);
		root.addNotNullValChild("PortingFlag", tnRecord.getPortingFlag(), action);
		root.addNotNullValChild("Territory", tnRecord.getTerritory(), action);
		root.addNotNullValChild("TrunkId", tnRecord.getTrunkId(), action);
		root.addNotNullValChild("GroupId", tnRecord.getTrunkId(), action);
		root.addNotNullValChild("SwitchClli", tnRecord.getSwitchClli(), action);
		root.addNotNullValChild("RealTrunkGroupNumber", tnRecord.getTrunkId(), action);
		root.addNotNullValChild("SwitchCLLI", tnRecord.getSwitchClli(), action);
		root.addNotNullValChild("ReplacementCLLI", tnRecord.getReplacementCLLI(), action);
		root.addNotNullValChild("PortPending", tnRecord.getPortingFlag(), action);
		root.addNotNullValChild("PortStatus", tnRecord.getPortStatus(), action);
		root.addNotNullValChild("ExistingTN", OrderUtility.booleanToStr(tnRecord.isExistingTN()), action);
		root.addNotNullValChild("Available", OrderUtility.booleanToStr(tnRecord.getAvailable()), action);
		root.addNotNullValChild("STNInd", tnRecord.getSTNInd(), action);
		root.addNotNullValChild("SubscriberId", tnRecord.getSubscriberId(), action);
		root.addNotNullValChild("GroupTNId", OrderUtility.longToString(tnRecord.getGroupTNId()), action);
		root.addNotNullValChild("EntityAction", tnRecord.getEntityAction(), action);
		root.addNotNullValChild("LinePort", tnRecord.getLinePort(), action);
		root.addNotNullValChild("TnActivation", tnRecord.getOnOffStatus(), action);
		root.addNotNullValChild("PubIp", tnRecord.getPubIp(), action);
		root.addNotNullValChild("PubIpIn", tnRecord.getPubIpIn(), action); // VOV
		root.addNotNullValChild("PubIpOut", tnRecord.getPubIpOut(), action);
		root.addNotNullValChild("TnType", tnRecord.getTnType(), action);
		root.addNotNullValChild("DeviceName", tnRecord.getDeviceName(), action);
		root.addNotNullValChild("PortInType", tnRecord.getPortInType(), action);
		root.addNotNullValChild("TNDeleteType", tnRecord.getDeleteType(), action);
		root.addNotNullValChild("PortOutType", tnRecord.getPortOutType(), action);
		root.addNotNullValChild("PortingIndicator", tnRecord.getPortingIndicator(), action);
		root.addNotNullValChild("SubStatus", tnRecord.getSubStatus(), action);
		root.addNotNullValChild("OriginalCarrierPrefix", tnRecord.getOriginalCarrierPrefix(), action);
		root.addNotNullValChild("GainingCarrierPrefix", tnRecord.getGainingCarrierPrefix(), action);
		root.addNotNullValChild("LosingCarrierPrefix", tnRecord.getLosingCarrierPrefix(), action);
		root.addNotNullValChild("GatewayNumber", tnRecord.getGatewayNumber(), action);
		root.addNotNullValChild("TSPCode", tnRecord.getTspCode(), action);
		
		if(tnRecord.getTransitionType() > 0) {
			root.addNotNullValChild("TransitionType", TNEnum.TransitionType.acronym(tnRecord.getTransitionType()), action);
			
		}
		
		root.addNotNullValChild("OldLocationId", tnRecord.getOldLocationId(), action);		
		root.addNotNullValChild("Lidb", tnRecord.getLidb(), action, null);
		root.addNotNullValChild("TnDisposition", tnRecord.getTnDisposition(), action, null);
		root.addNotNullValChild("EmergencyFirstName", tnRecord.getEmergencyFirstName(), action, null);
		root.addNotNullValChild("EmergencyMiddleName", tnRecord.getEmergencyMiddleName(), action, null);
		root.addNotNullValChild("EmergencyLastName", tnRecord.getEmergencyLastName(), action, null);
		root.addNotNullValChild("EmergencyBldngDesignator", tnRecord.getEmergencyBldngDesignator(), action, null);
		root.addNotNullValChild("EmergencyBldngValue", tnRecord.getEmergencyBldngValue(), action, null);		
		root.addNotNullValChild("EmergencyFloorValue", tnRecord.getEmergencyFloorValue(), action, null);
		root.addNotNullValChild("EmergencyFloorDesignator", tnRecord.getEmergencyFloorDesignator(), action, null);
		root.addNotNullValChild("EmergencyRoomValue", tnRecord.getEmergencyRoomValue(), action, null);
		root.addNotNullValChild("EmergencyRoomDesignator", tnRecord.getEmergencyRoomDesignator(), action, null);
		root.addNotNullValChild("CnamOutBoundFirstName", tnRecord.getCnamOutBoundFirstName(), action, null);
		root.addNotNullValChild("CnamOutBoundLastName", tnRecord.getCnamOutBoundLastName(), action, null);
		root.addNotNullValChild("NewVerizonBTN", tnRecord.getNewVerizonBTN(), action, null);		
		root.addNotNullValChild("TnTypeOrdering", tnRecord.getTnTypeOrdering(), action, null);
		root.addNotNullValChild("IndustryPortability", tnRecord.getIndustryPortability(), action, null);
		root.addNotNullValChild("PortingServiceAddress", tnRecord.getPortingServiceAddress(), action, null);
		root.addNotNullValChild("IldRestriction", tnRecord.getIldRestriction(), action, null);
		root.addNotNullValChild("CurrentLecBtn", tnRecord.getCurrentLecBtn(), action, null);
		root.addNotNullValChild("Nomadic911", tnRecord.getNomadic911(), action, null);
		root.addNotNullValChild("TnAssignment", tnRecord.getTnAssignment(), action, null);		
		root.addNotNullValChild("PointToNumber", tnRecord.getPointToNumber(), action, null);
		root.addNotNullValChild("Provider", tnRecord.getProvider(), action, null);
		root.addNotNullValChild("HuntGroupSequence", tnRecord.getHuntGroupSequence(), action, null);
		
		
		if (null != tnRecord.getOldLocatinEmptyFlag() && tnRecord.getOldLocatinEmptyFlag())
			root.addNotNullValChild("OldLocationEmptyFlag", "Y", action);
		// PS/ALI Changes
		root.addNotNullValChild("PSALI", tnRecord.getPSALI(), action);

		LOG.info("tnRecord.isBroadsoftTNActivationEnabled()->" + tnRecord.isBroadsoftTNActivationEnabled());

		LOG.info("tnRecord.getPortStatus()->" + tnRecord.getPortStatus());
		LOG.info("getParamInfo(" + action + ")->" + tnRecord);
		LOG.info("tnRecord.isActivation()->" + tnRecord.isActivation());
		LOG.info("tnRecord.isDeactivation()->" + tnRecord.isDeactivation());

		//Start : TN This needs to be fixed righnt now we have temporary fix
		if (tnRecord.isBroadsoftTNActivationEnabled()) {
			if (true) {
				if (action != null && action.equalsIgnoreCase("O")) {
					LOG.info("tnRecord action is O setting to deactivate");
					tnRecord.setActDeact(VzbVoipEnum.ActDeact.DEACTIVATED);
				} else {
					if (null != tnRecord.getPortStatus()) {
						if (tnRecord.getPortStatus() == PortStatus.PORT_PENDING) {
							tnRecord.setActDeact(VzbVoipEnum.ActDeact.DEACTIVATED);
						} else if (tnRecord.getPortStatus() == PortStatus.NATIVE
								|| tnRecord.getPortStatus() == PortStatus.PORTED) {
							tnRecord.setActDeact(VzbVoipEnum.ActDeact.ACTIVATED);
						}
					}
					if (null == tnRecord.getActDeact()) {
						if (null != tnRecord.getPortingFlag() && tnRecord.getPortingFlag().equalsIgnoreCase("N")) {
							tnRecord.setActDeact(VzbVoipEnum.ActDeact.ACTIVATED);
						}
					}
				}
			}
			if (tnRecord.isActivation()) {
				LOG.info("tnRecord.isActivation() is enabled");
				tnRecord.setActDeact(VzbVoipEnum.ActDeact.ACTIVATED);
			}
			if (tnRecord.isDeactivation()) {
				LOG.info("tnRecord.isDeactivation() is enabled");
				tnRecord.setActDeact(VzbVoipEnum.ActDeact.DEACTIVATED);
			}
			if (null != tnRecord.getActDeact() && tnRecord.getActDeact() >= 1) {
				root.addNotNullValChild("ActDeact", tnRecord.getActDeact(), action);
			}
		}
		
		if (action != null && action.equalsIgnoreCase("O")) {
			LOG.info("tnRecord action is O setting to deactivate");
			tnRecord.setActDeact(VzbVoipEnum.ActDeact.DEACTIVATED);
			
		} else {
			tnRecord.setActDeact(VzbVoipEnum.ActDeact.ACTIVATED);
			
		}
		
		if (null != tnRecord.getActDeact() && tnRecord.getActDeact() >= 1) {
			root.addNotNullValChild("ActDeact", tnRecord.getActDeact(), action);
		}
		
		//End : TN This needs to be fixed righnt now we have temporary fix.
		
		root.addChildParam(OrderUtility.getAttribParamInfo(tnRecord.getAttribMap(), action));
		if (tnRecord.getHotCutIndicator() != null && tnRecord.getHotCutIndicator() == Boolean.TRUE)
			root.addNotNullValChild("HotCutIndicator", "Y", action);
		if (tnRecord.getCDDDIndicator() != null && tnRecord.getCDDDIndicator() == Boolean.TRUE)
			root.addNotNullValChild("CDDDIndicator", "Y", action);

		root.addNotNullValChild("VerizonBTN", tnRecord.getVerizonBTN(), action);

		LOG.info("Exit buildTNParamDataForTN");

		return root;
	}
	
	public static ParamInfo buildTNParamDataForPrevTN(TNEntity tnRecordPrev, TNEntity tnRecord, boolean change, String action) {

		LOG.info("Entered  buildTNParamDataForPrevTN");
		
		ParamInfo tnParam = new ParamInfo("TNRecord", null, null);
		
		tnParam.addChangeParam("TN", tnRecordPrev.getTn(), tnRecord.getTn(), change, ParamInfo.Tag.NAME);
		tnParam.addChangeParam("TnPoolId", tnRecordPrev.getTnPoolId(), tnRecord.getTnPoolId(), change);

		if (null == tnRecord.getPortingFlag()) {
			tnRecord.setPortingFlag("N");
		} else if (tnRecord.getPortStatus() != null && tnRecord.getPortStatus() == PortStatus.PORT_PENDING) {
			tnRecord.setPortingFlag("Y");
		}
		
		tnParam.addChangeParam("Region", tnRecordPrev.getRegion(), tnRecord.getRegion(), change);
		tnParam.addChangeParam("PortingFlag", tnRecordPrev.getPortingFlag(), tnRecord.getPortingFlag(), change);
		tnParam.addChangeParam("Territory", tnRecordPrev.getTerritory(), tnRecord.getTerritory(), change);
		tnParam.addChangeParam("TrunkId", tnRecordPrev.getTrunkId(), tnRecord.getTrunkId(), change);
		tnParam.addChangeParam("GroupId", tnRecordPrev.getTrunkId(), tnRecord.getTrunkId(), change);
		tnParam.addChangeParam("SwitchClli", tnRecordPrev.getSwitchClli(), tnRecord.getSwitchClli(), change);
		tnParam.addChangeParam("RealTrunkGroupNumber", tnRecordPrev.getTrunkId(), tnRecord.getTrunkId(), change);
		tnParam.addChangeParam("SwitchCLLI", tnRecordPrev.getSwitchClli(), tnRecord.getSwitchClli(), change);
		tnParam.addChangeParam("ReplacementCLLI", tnRecordPrev.getReplacementCLLI(), tnRecord.getReplacementCLLI(), change);
		tnParam.addChangeParam("PortPending", tnRecordPrev.getPortingFlag(), tnRecord.getPortingFlag(), change);
		tnParam.addChangeParam("PortStatus", tnRecordPrev.getPortStatus(), tnRecord.getPortStatus(), change);
		tnParam.addChangeParam("ExistingTN", OrderUtility.booleanToStr(tnRecordPrev.isExistingTN()), OrderUtility.booleanToStr(tnRecord.isExistingTN()), change);
		tnParam.addChangeParam("Available", OrderUtility.booleanToStr(tnRecordPrev.getAvailable()), OrderUtility.booleanToStr(tnRecord.getAvailable()), change);
		tnParam.addChangeParam("STNInd", tnRecordPrev.getSTNInd(), tnRecord.getSTNInd(), change);
		tnParam.addChangeParam("SubscriberId", tnRecordPrev.getSubscriberId(), tnRecordPrev.getSubscriberId(), change);
		tnParam.addChangeParam("GroupTNId", OrderUtility.longToString(tnRecordPrev.getGroupTNId()), OrderUtility.longToString(tnRecord.getGroupTNId()), change);
		tnParam.addChangeParam("TnActivation", tnRecordPrev.getOnOffStatus(), tnRecord.getOnOffStatus(), change);
		tnParam.addChangeParam("EntityAction", tnRecordPrev.getEntityAction(), tnRecord.getEntityAction(), change);
		tnParam.addChangeParam("LinePort", tnRecordPrev.getLinePort(), tnRecord.getLinePort(), change);
		tnParam.addChangeParam("PubIp", tnRecordPrev.getPubIp(), tnRecord.getPubIp(), change);
		tnParam.addChangeParam("PubIpIn", tnRecordPrev.getPubIpIn(), tnRecord.getPubIpIn(), change); // VOV 
		tnParam.addChangeParam("PubIpOut", tnRecordPrev.getPubIpOut(), tnRecord.getPubIpOut(), change);
		tnParam.addChangeParam("TnType", tnRecordPrev.getTnType(), tnRecord.getTnType(), change);
		tnParam.addChangeParam("DeviceName", tnRecordPrev.getDeviceName(), tnRecord.getDeviceName(), change);
		tnParam.addChangeParam("PortInType", tnRecordPrev.getPortInType(), tnRecord.getPortInType(), change);
		tnParam.addChangeParam("TNDeleteType", tnRecordPrev.getDeleteType(), tnRecord.getDeleteType(), change);
		tnParam.addChangeParam("PortOutType", tnRecordPrev.getPortOutType(), tnRecord.getPortOutType(), change);
		tnParam.addChangeParam("PortingIndicator", tnRecordPrev.getPortingIndicator(), tnRecord.getPortingIndicator(), change);
		tnParam.addChangeParam("SubStatus", tnRecordPrev.getSubStatus(), tnRecord.getSubStatus(), change);
		tnParam.addChangeParam("OriginalCarrierPrefix", tnRecordPrev.getOriginalCarrierPrefix(), tnRecord.getOriginalCarrierPrefix(), change);
		tnParam.addChangeParam("GainingCarrierPrefix", tnRecordPrev.getGainingCarrierPrefix(), tnRecord.getGainingCarrierPrefix(), change);
		tnParam.addChangeParam("LosingCarrierPrefix", tnRecordPrev.getLosingCarrierPrefix(), tnRecord.getLosingCarrierPrefix(), change);
		tnParam.addChangeParam("GatewayNumber", tnRecordPrev.getGatewayNumber(), tnRecord.getGatewayNumber(), change);
		tnParam.addChangeParam("TSPCode", tnRecordPrev.getTspCode(), tnRecord.getTspCode(), change);
		tnParam.addChangeParam("TransitionType", TNEnum.TransitionType.acronym(tnRecordPrev.getTransitionType()), TNEnum.TransitionType.acronym(tnRecord.getTransitionType()), change);
		tnParam.addChangeParam("OldLocationId", tnRecordPrev.getOldLocationId(), tnRecord.getOldLocationId(), change);		
		tnParam.addChangeParam("Lidb", tnRecordPrev.getLidb(), tnRecord.getLidb(), change);
		tnParam.addChangeParam("TnDisposition", tnRecordPrev.getTnDisposition(), tnRecord.getTnDisposition(), change);
		tnParam.addChangeParam("EmergencyFirstName", tnRecordPrev.getEmergencyFirstName(), tnRecord.getEmergencyFirstName(), change);
		tnParam.addChangeParam("EmergencyMiddleName", tnRecordPrev.getEmergencyMiddleName(), tnRecord.getEmergencyMiddleName(), change);
		tnParam.addChangeParam("EmergencyLastName", tnRecordPrev.getEmergencyLastName(), tnRecord.getEmergencyLastName(), change);
		tnParam.addChangeParam("EmergencyBldngDesignator", tnRecordPrev.getEmergencyBldngDesignator(), tnRecord.getEmergencyBldngDesignator(), change);
		tnParam.addChangeParam("EmergencyBldngValue", tnRecordPrev.getEmergencyBldngValue(), tnRecord.getEmergencyBldngValue(), change);		
		tnParam.addChangeParam("EmergencyFloorValue", tnRecordPrev.getEmergencyFloorValue(), tnRecord.getEmergencyFloorValue(), change);
		tnParam.addChangeParam("EmergencyFloorDesignator", tnRecordPrev.getEmergencyFloorDesignator(), tnRecord.getEmergencyFloorDesignator(), change);
		tnParam.addChangeParam("EmergencyRoomValue", tnRecordPrev.getEmergencyRoomValue(), tnRecord.getEmergencyRoomValue(), change);
		tnParam.addChangeParam("EmergencyRoomDesignator", tnRecordPrev.getEmergencyRoomDesignator(), tnRecord.getEmergencyRoomDesignator(), change);
		tnParam.addChangeParam("CnamOutBoundFirstName", tnRecordPrev.getCnamOutBoundFirstName(), tnRecord.getCnamOutBoundFirstName(), change);
		tnParam.addChangeParam("CnamOutBoundLastName", tnRecordPrev.getCnamOutBoundLastName(), tnRecord.getCnamOutBoundLastName(), change);
		tnParam.addChangeParam("NewVerizonBTN", tnRecordPrev.getNewVerizonBTN(), tnRecord.getNewVerizonBTN(), change);		
		tnParam.addChangeParam("TnTypeOrdering", tnRecordPrev.getTnTypeOrdering(), tnRecord.getTnTypeOrdering(), change);
		tnParam.addChangeParam("IndustryPortability", tnRecordPrev.getIndustryPortability(), tnRecord.getIndustryPortability(), change);
		tnParam.addChangeParam("PortingServiceAddress", tnRecordPrev.getPortingServiceAddress(), tnRecord.getPortingServiceAddress(), change);
		tnParam.addChangeParam("IldRestriction", tnRecordPrev.getIldRestriction(), tnRecord.getIldRestriction(), change);
		tnParam.addChangeParam("CurrentLecBtn", tnRecordPrev.getCurrentLecBtn(), tnRecord.getCurrentLecBtn(), change);
		tnParam.addChangeParam("Nomadic911", tnRecordPrev.getNomadic911(), tnRecord.getNomadic911(), change);
		tnParam.addChangeParam("TnAssignment", tnRecordPrev.getTnAssignment(), tnRecord.getTnAssignment(), change);		
		tnParam.addChangeParam("PointToNumber", tnRecordPrev.getPointToNumber(), tnRecord.getPointToNumber(), change);
		tnParam.addChangeParam("Provider", tnRecordPrev.getProvider(), tnRecord.getProvider(), change);
		tnParam.addChangeParam("HuntGroupSequence", tnRecordPrev.getHuntGroupSequence(), tnRecord.getHuntGroupSequence(), change);
		
		
		if (null != tnRecordPrev.getOldLocatinEmptyFlag() && tnRecord.getOldLocatinEmptyFlag())
			tnParam.addChangeParam("OldLocationEmptyFlag", "Y", "Y", change);
		// PS/ALI Changes
		tnParam.addChangeParam("PSALI", tnRecordPrev.getPSALI(), tnRecord.getPSALI(), change);

		LOG.info("tnRecord.isBroadsoftTNActivationEnabled()->" + tnRecord.isBroadsoftTNActivationEnabled());

		LOG.info("tnRecord.getPortStatus()->" + tnRecord.getPortStatus());
		LOG.info("getParamInfo(" + change + ")->" + tnRecord);
		LOG.info("tnRecord.isActivation()->" + tnRecord.isActivation());
		LOG.info("tnRecord.isDeactivation()->" + tnRecord.isDeactivation());

		/*if (tnRecord.isBroadsoftTNActivationEnabled()) {
			if (true) {
				if (action != null && action.equalsIgnoreCase("O")) {
					LOG.info("tnRecord action is O setting to deactivate");
					tnRecord.setActDeact(VzbVoipEnum.ActDeact.DEACTIVATED);
				} else {
					if (null != tnRecord.getPortStatus()) {
						if (tnRecord.getPortStatus() == PortStatus.PORT_PENDING) {
							tnRecord.setActDeact(VzbVoipEnum.ActDeact.DEACTIVATED);
						} else if (tnRecord.getPortStatus() == PortStatus.NATIVE
								|| tnRecord.getPortStatus() == PortStatus.PORTED) {
							tnRecord.setActDeact(VzbVoipEnum.ActDeact.ACTIVATED);
						}
					}
					if (null == tnRecord.getActDeact()) {
						if (null != tnRecord.getPortingFlag() && tnRecord.getPortingFlag().equalsIgnoreCase("N")) {
							tnRecord.setActDeact(VzbVoipEnum.ActDeact.ACTIVATED);
						}
					}
				}
			}
			if (tnRecord.isActivation()) {
				LOG.info("tnRecord.isActivation() is enabled");
				tnRecord.setActDeact(VzbVoipEnum.ActDeact.ACTIVATED);
			}
			if (tnRecord.isDeactivation()) {
				LOG.info("tnRecord.isDeactivation() is enabled");
				tnRecord.setActDeact(VzbVoipEnum.ActDeact.DEACTIVATED);
			}
			if (null != tnRecord.getActDeact() && tnRecord.getActDeact() >= 1) {
				tnParam.addChangeParam("ActDeact", tnRecord.getActDeact(), action);
			}
		}
		root.addChildParam(OrderUtility.getAttribParamInfo(tnRecord.getAttribMap(), action));
		if (tnRecord.getHotCutIndicator() != null && tnRecord.getHotCutIndicator() == Boolean.TRUE)
			tnParam.addChangeParam("HotCutIndicator", "Y", action);
		if (tnRecord.getCDDDIndicator() != null && tnRecord.getCDDDIndicator() == Boolean.TRUE)
			tnParam.addChangeParam("CDDDIndicator", "Y", action);*/

		tnParam.addChangeParam("VerizonBTN", tnRecordPrev.getVerizonBTN(), tnRecord.getVerizonBTN(), change);

		LOG.info("Exit buildTNParamDataForTN");

		return tnParam;
	}

}
