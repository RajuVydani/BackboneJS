package com.vz.esap.translation.order.service.enterprisetrunk;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.vz.esap.translation.dao.model.TblEnvOrder;
import com.vz.esap.translation.dao.model.TblOrder;
import com.vz.esap.translation.dao.model.TblOrderDetails;
import com.vz.esap.translation.dao.model.TblOrderService;
import com.vz.esap.translation.entity.EnterpriseTrunkEntity;
import com.vz.esap.translation.enums.EsapEnum;
import com.vz.esap.translation.enums.EsapEnum.FlowPath;
import com.vz.esap.translation.enums.EsapEnum.OrderEntity;
import com.vz.esap.translation.exception.GenericException;
import com.vz.esap.translation.exception.TranslatorException;
import com.vz.esap.translation.exception.TranslatorException.ErrorCode;
import com.vz.esap.translation.order.dao.VOIPOrderDao;
import com.vz.esap.translation.order.model.Order;
import com.vz.esap.translation.order.model.OrderHeader;
import com.vz.esap.translation.order.model.OrderHeader.SuppType;
import com.vz.esap.translation.order.model.request.ParamInfo;
import com.vz.esap.translation.order.model.request.VOIPOrderRequest;
import com.vz.esap.translation.order.model.response.VoipOrderResponse;
import com.vz.esap.translation.order.parser.OrderParser;
import com.vz.esap.translation.order.service.CancelOrderService;
import com.vz.esap.translation.order.service.OrderServiceBase;
import com.vz.esap.translation.order.service.VOIPResponseGenerator;
import com.vz.esap.translation.order.service.helper.OrderServiceHelperImpl;
import com.vz.esap.translation.order.transformer.EnterpriseTblOrderDataTransformer;
import com.vz.esap.translation.order.transformer.EnterpriseTblOrderDetailsDataTransformer;
import com.vz.esap.translation.order.transformer.EnterpriseTblOrderServiceDataTransformer;
import com.vz.esap.translation.order.transformer.EnterpriseTrunkTblOrderDetailsDataTransformerImpl;
import com.vz.esap.translation.order.transformer.EnterpriseTrunkTransformer;

import EsapEnumPkg.WorkOrderEnum;

/**
 * @author chattni
 *
 */
@Service
public class EnterpriseTrunkOrderServiceImpl extends OrderServiceBase implements EnterpriseTrunkOrderService {

	@Autowired
	private EnterpriseTrunkTransformer enterpriseTrunkTransformer;

	@Autowired
	private EnterpriseTblOrderDataTransformer enterpriseTblOrderData;

	@Autowired
	private EnterpriseTblOrderServiceDataTransformer enterpriseTblOrderServiceData;

	@Autowired
	private EnterpriseTblOrderDetailsDataTransformer enterpriseTblOrderDetailsData;

	@Autowired
	private EnterpriseTrunkTblOrderDetailsDataTransformerImpl enterpriseTrunkTblOrderDetailsDataTransformerImpl;

	@Autowired
	private VOIPOrderDao voipOrderDao;

	@Autowired
	private VOIPResponseGenerator voipResponseGenerator;

	@Autowired
	private OrderServiceHelperImpl orderServiceHelperImpl;

	@Autowired
	private OrderParser orderParserImpl;
	
	@Autowired
	private CancelOrderService cancelOrderServiceImpl;

	private static final Logger LOG = LoggerFactory.getLogger(EnterpriseTrunkOrderServiceImpl.class);

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.vz.esap.translation.order.service.enterprisetrunk.
	 * EnterpriseTrunkOrderService#processReleaseOrder(com.vz.esap.translation.dao.
	 * model.TblOrder, com.vz.esap.translation.dao.model.TblOrderDetails,
	 * com.vz.esap.translation.dao.model.TblEnvOrder,
	 * com.vz.esap.translation.order.model.request.VOIPOrderRequest, java.util.List)
	 */
	@Override
	public VoipOrderResponse processReleaseOrder(TblOrder tblOrderBeanValidation, TblOrderDetails tblOrderDetails,
			TblEnvOrder tblEnvOrder, VOIPOrderRequest voipOrderRequest, List<TblOrderDetails> tblOrderDetailsList)
			throws GenericException, TranslatorException {
		LOG.info("Entered - processReleaseOrder");

		VoipOrderResponse voipOrderResponse = null;
		EnterpriseTrunkEntity enterpriseTrunkEntity = null;
		List<EnterpriseTrunkEntity> enterpriseTrunkEntityList = null;
		List<EnterpriseTrunkEntity> enterpriseTrunkEntityPrevList = null;
		Order order = null;
		Order orderPrevPass = null;
		OrderHeader orderHeader = null;
		List<TblEnvOrder> tblEnvOrderListPrev = null;
		List<TblOrder> tblOrderListPrev = null;
		List<TblOrderDetails> tblOrderDetailsListPrev = null;
		EnterpriseTrunkEntity enterpriseTrunkEntityPrev = null;
		boolean isNewEt;

		try {

			LOG.info("Creating ET Objects from order details id:{}", tblOrderDetails.getOrderDetailId());

			if ("C".equalsIgnoreCase(voipOrderRequest.getOrderHeader().getOrderType())) {
				LOG.info("Inside ET Change");
				
				//This will fetch n,r
				enterpriseTrunkEntity = enterpriseTrunkTransformer.transformOrderDetailsToEnterpriseTrunk(
						tblOrderBeanValidation.getOrderId(), tblOrderDetails.getOrderDetailId(), null, false,
						Arrays.asList("o"));				
				
				//This will fetch o,r
				
				enterpriseTrunkEntityPrev = enterpriseTrunkTransformer.transformOrderDetailsToEnterpriseTrunk(
						tblOrderBeanValidation.getOrderId(), tblOrderDetails.getOrderDetailId(), null, false,
						Arrays.asList("n"));
				
				if(enterpriseTrunkEntityPrev != null) {
					enterpriseTrunkEntityPrevList = new ArrayList<>();
					enterpriseTrunkEntityPrevList.add(enterpriseTrunkEntityPrev);
				}
				
				//This will fetch if there is any TOD with n
				isNewEt = orderServiceHelperImpl.isNewEntityChangeOrder(tblOrderBeanValidation.getOrderId(),
						tblOrderDetails.getOrderDetailId());
				
				LOG.info("ET Id = {} Is New ET Entity = {}", enterpriseTrunkEntity.getEnterpriseTrunkId(), isNewEt);
				
				enterpriseTrunkEntity.setNewEt(isNewEt);

			} else {
				enterpriseTrunkEntity = enterpriseTrunkTransformer.transformOrderDetailsToEnterpriseTrunk(
						tblOrderBeanValidation.getOrderId(), tblOrderDetails.getOrderDetailId(), "n", false, null);
			}

			if (enterpriseTrunkEntity == null) {
				throw new TranslatorException(ErrorCode.ET_TRANSFORMATION_FAILURE,
						"Enterprise Trunk transformation Failure");
			}

			enterpriseTrunkEntityList = new ArrayList<>();
			enterpriseTrunkEntityList.add(enterpriseTrunkEntity);
			int orderVersion = Integer.parseInt(voipOrderRequest.getOrderHeader().getWorkOrderVersion());
			LOG.info("Order version:: {}", orderVersion);

			if (orderVersion > 0) {
				VOIPOrderRequest voipOrderRequestPrev = orderParserImpl.getCorrectPrevPassVoipOrderRequest(voipOrderRequest);
				LOG.info("SUPP Order version:: {}", voipOrderRequestPrev.getOrderHeader().getWorkOrderVersion());
				//voipOrderRequestPrev.getOrderHeader().setWorkOrderVersion(Integer.toString(orderVersion - 1));
				tblEnvOrderListPrev = orderServiceHelperImpl.getMatchingPrevPassEnvOrder(voipOrderRequestPrev, 0,
						WorkOrderEnum.OrderClassify.RELEASE); // returns 1 release pass record
				
				LOG.info("env table records size::{}", tblEnvOrderListPrev.size());
				LOG.info("ENV ORDER ID::{}", tblEnvOrderListPrev.get(0).getEnvOrderId());
				
				tblOrderListPrev = orderServiceHelperImpl.getMatchingPrevPassOrder(tblEnvOrderListPrev.get(0),
						OrderEntity.ENTERPRISE_TRUNK, enterpriseTrunkEntity.getEnterpriseId()); 

				if(!CollectionUtils.isEmpty(tblOrderListPrev)) {
					
					LOG.info("TBL_ORDER records size::{}", tblOrderListPrev.size());
					LOG.info("TBL ORDER ID::{}", tblOrderListPrev.get(0).getOrderId());
					

					for (TblOrder tblOrderPrev : tblOrderListPrev) {

						LOG.info("TBL ORDER ID Account Number is::{} and BW ET Id is::{}",
								tblOrderPrev.getAccountNumber(), enterpriseTrunkEntity.getBwEtId());
						
						if (tblOrderPrev.getAccountNumber().equalsIgnoreCase(enterpriseTrunkEntity.getBwEtId())) {
							tblOrderDetailsListPrev = orderServiceHelperImpl.getMatchingOrderDetails(tblOrderPrev);
							LOG.info("TBL_ORDER_DETAILS records size for Matching previous pass record::{}",
									tblOrderDetailsListPrev.size());
						}
					}
					
					/*tblOrderDetailsListPrev = orderServiceHelperImpl.getMatchingOrderDetails(tblOrderListPrev.get(0));
					LOG.info("TBL_ORDER_DETAILS records size::{}", tblOrderDetailsListPrev.size());*/


					if (tblOrderDetailsListPrev != null && !tblOrderDetailsListPrev.isEmpty()
							&& "EnterpriseTrunk".equalsIgnoreCase(tblOrderDetailsListPrev.get(0).getParamName())) {
						
						LOG.info("Previous Table Order Id::{}", tblOrderListPrev.get(0).getOrderId());
						LOG.info("Previous Table Order Details Id::{}", tblOrderDetailsListPrev.get(0).getOrderDetailId());
						
						enterpriseTrunkEntityPrev = enterpriseTrunkTransformer.transformOrderDetailsToEnterpriseTrunk(
								tblOrderListPrev.get(0).getOrderId(), tblOrderDetailsListPrev.get(0).getOrderDetailId(),
								"n", false, null);
						
						enterpriseTrunkEntityPrev.setEnvOrderId(tblEnvOrderListPrev.get(0).getEnvOrderId());
						enterpriseTrunkEntityPrev.setInternalOrderId(tblOrderDetailsListPrev.get(0).getOrderId());
						
						LOG.info("enterpriseTrunkEntityPrev::{}::{}", enterpriseTrunkEntityPrev.getEnterpriseTrunkName(),
								enterpriseTrunkEntityPrev.getBwEtId());
						LOG.info("enterpriseTrunkEntity::{}::{}", enterpriseTrunkEntity.getEnterpriseTrunkName(),
								enterpriseTrunkEntity.getBwEtId());

						enterpriseTrunkEntityPrevList = new ArrayList<>();
						enterpriseTrunkEntityPrevList.add(enterpriseTrunkEntityPrev);
					}					
				}

				if (voipOrderRequest.getOrderHeader().getSuppType().equals(SuppType.CANCEL.toString()))
					voipOrderRequest.getOrderHeader().setSuppType(SuppType.CANCEL.toString());
				else
					voipOrderRequest.getOrderHeader().setSuppType(SuppType.SUPP.toString());
			}

			orderHeader = createdOrderHeaderForEtOrder(voipOrderRequest, enterpriseTrunkEntity);

			order = new Order();
			order.setEnterpriseTrunks(enterpriseTrunkEntityList);

			orderHeader.setEnvOrderId(tblEnvOrder.getEnvOrderId());
			order.setOrderHeader(orderHeader);

			orderPrevPass = new Order();
			orderPrevPass.setOrderHeader(orderHeader);
			orderPrevPass.setEnterpriseTrunks(enterpriseTrunkEntityPrevList);
			
			LOG.info("Previous Enterprise Trunk order status ===>>> {} ", !CollectionUtils.isEmpty(tblOrderListPrev) ? tblOrderListPrev.get(0).getOrderStatus() : "Not supp");
			createReleaseOrders(voipOrderRequest, tblOrderListPrev, order, orderPrevPass, tblOrderBeanValidation, tblOrderDetails, tblOrderDetailsList,
					WorkOrderEnum.Status.WO_INIT, tblEnvOrder);

			voipOrderResponse = voipResponseGenerator.prepareSuccessOrderResponse(voipOrderRequest);

		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new GenericException(GenericException.GENERIC_EXCEPTION,
					"Exception occured while providing input arguments-" + e);
		}
		LOG.info("Exit - processReleaseOrder");
		return voipOrderResponse;
	}

	/**
	 * @param order
	 * @param orderPrevPass
	 * @param tblOrderBeanValidation
	 * @param tblOrderDetails
	 * @param tblOrderDetailsList
	 * @param status
	 * @param tblEnvOrder
	 * @return boolean
	 * @throws GenericException
	 * @throws TranslatorException
	 */
	boolean createReleaseOrders(VOIPOrderRequest voipOrderRequest, List<TblOrder> tblOrderListPrev, Order order, Order orderPrevPass, TblOrder tblOrderBeanValidation,
			TblOrderDetails tblOrderDetails, List<TblOrderDetails> tblOrderDetailsList, int status,
			TblEnvOrder tblEnvOrder) throws GenericException, TranslatorException {
		LOG.info("Entered - createReleaseOrders");

		List<EnterpriseTrunkEntity> enterpriseTrunkEntities = null;
		OrderHeader orderHeader = null;
		boolean isCreated = true;
		TblOrder tblOrderObject = null;
		List<TblOrderService> tblOrderServiceList = null;
		EnterpriseTrunkEntity enterpriseTrunkEntityPrev = null;
		EnterpriseTrunkEntity enterpriseTrunkEntity = null;
		ParamInfo headerParamInfo = null;
		ParamInfo entityParamInfo = null;

		try {
			enterpriseTrunkEntities = order.getEnterpriseTrunks();
			order.getOrderHeader().setOrderStatus(status);
			orderHeader = order.getOrderHeader();

			for (EnterpriseTrunkEntity entTrunkEntity : enterpriseTrunkEntities) {
				orderHeader.setEntityType(entTrunkEntity.getEntityType());
				order.setOrderHeader(orderHeader);
				// :create order object
				tblOrderObject = enterpriseTblOrderData.prepareTblOrderDataFromOrder(order, 43L);
				
				orderHeader.setTblOrderId(tblOrderObject.getOrderId());
				order.setOrderHeader(orderHeader);
				
				if (order != null && order.getEnterpriseTrunkEntities() != null
						&& !order.getEnterpriseTrunkEntities().isEmpty()) {
				enterpriseTrunkEntity = order.getEnterpriseTrunkEntities().get(0);
				}
				
				if (orderPrevPass != null && orderPrevPass.getEnterpriseTrunkEntities() != null
						&& !orderPrevPass.getEnterpriseTrunkEntities().isEmpty()) {
							
					enterpriseTrunkEntityPrev = orderPrevPass.getEnterpriseTrunkEntities().get(0);
				}
				
				if ("I".equalsIgnoreCase(orderHeader.getEntityAction())) {

					if (enterpriseTrunkEntityPrev != null) {
						LOG.info("enterpriseTrunkEntityPrev is not null");

						headerParamInfo = enterpriseTrunkTblOrderDetailsDataTransformerImpl
								.prepareTblOrderDetailsHeaderParamData(order, enterpriseTrunkEntityPrev, true);
						entityParamInfo = enterpriseTrunkTblOrderDetailsDataTransformerImpl
								.prepareTblOrderDetailsEntityParamDataForET(enterpriseTrunkEntityPrev,
										enterpriseTrunkEntity, true, null);

						if (entityParamInfo != null && entityParamInfo.getAction() != null
								&& "C".equals(entityParamInfo.getAction())) {
							LOG.info("entityParamInfo.getAction(): {}", entityParamInfo.getAction());
							orderHeader.setEntityAction("C");
							
							entityParamInfo.addNotNullValChild("ET_INV_CHANGE", "Y", "n");
							
						} else if (entityParamInfo != null && entityParamInfo.getAction() != null
								&& entityParamInfo.getAction().equals("NC")) {
							LOG.info("entityParamInfo.getAction(): {}", entityParamInfo.getAction());
							orderHeader.setEntityAction("NC");
						}
						
					} else {

						headerParamInfo = enterpriseTblOrderDetailsData.prepareTblOrderDetailsHeaderParamData(order);
						entityParamInfo = enterpriseTrunkTblOrderDetailsDataTransformerImpl
								.prepareTblOrderDetailsEntityParamDataForET(entTrunkEntity,
										order.getOrderHeader().getOrderType());

						LOG.info("entityParamInfo.getAction(): {}", entityParamInfo.getAction());
						orderHeader.setEntityAction("I");
					}
				} else if ("C".equalsIgnoreCase(orderHeader.getEntityAction())) {
					LOG.info("Inside createReleaseOrders For ET Change");
					if (enterpriseTrunkEntityPrev != null) {
						LOG.info("enterpriseTrunkEntityPrev is not null");

						headerParamInfo = enterpriseTrunkTblOrderDetailsDataTransformerImpl
								.prepareTblOrderDetailsHeaderParamData(order, enterpriseTrunkEntityPrev, true);
						entityParamInfo = enterpriseTrunkTblOrderDetailsDataTransformerImpl
								.prepareTblOrderDetailsEntityParamDataForET(enterpriseTrunkEntityPrev,
										enterpriseTrunkEntity, true, null);
						
							//LOG.info("entityParamInfo.getAction() For NBS: {}", entityParamInfo.getAction());

						/*if (entityParamInfo != null && entityParamInfo.getAction() != null
								&& "C".equals(entityParamInfo.getAction())) {
							LOG.info("entityParamInfo.getAction(): {}", entityParamInfo.getAction());
							orderHeader.setEntityAction("C");
							
							entityParamInfo.addNotNullValChild("ET_INV_CHANGE", "Y", "n");
							
						}
						*/
						
						if(entTrunkEntity.isNewEt()) {
							LOG.info("ET is New Install For MAC Order Device Id = {}", entTrunkEntity.getEnterpriseTrunkId());
							orderHeader.setEntityAction("I");
							entityParamInfo.setAction("n");
							
						} else {
							if (entityParamInfo != null && entityParamInfo.getAction() != null
									&& "C".equals(entityParamInfo.getAction())) {
								LOG.info("entityParamInfo.getAction(): {}", entityParamInfo.getAction());
								orderHeader.setEntityAction("C");
								
								entityParamInfo.addNotNullValChild("ET_INV_CHANGE", "Y", "n");
								
							} else if (entityParamInfo != null && entityParamInfo.getAction() != null
									&& entityParamInfo.getAction().equals("NC")) {
								LOG.info("ET entityParamInfo.getAction(): {}", entityParamInfo.getAction());
								orderHeader.setEntityAction("NC");
								
							}
						}
						
					}
				}
				LOG.info("orderHeader.getEntityAction()-ET : {} ", orderHeader.getEntityAction());
				if (null != headerParamInfo && !"NC".equalsIgnoreCase(orderHeader.getEntityAction())) {
					
					//ESVRRS-18523 :: START :: Supp other on failed Entity fix.
					int orderVersion = Integer.parseInt(voipOrderRequest.getOrderHeader().getWorkOrderVersion());
					LOG.info("Order version:: {}", orderVersion);
					
					if (orderVersion > 0) {
						if(!CollectionUtils.isEmpty(tblOrderListPrev)) {
							LOG.info("Previous Enterprise Trunk order status :: {} ", tblOrderListPrev.get(0).getOrderStatus() );
							LOG.info("Enterprise Trunk records count - {}", tblOrderListPrev.size());
							if(WorkOrderEnum.Status.WO_FAILED == tblOrderListPrev.get(0).getOrderStatus()) {
								LOG.info("Creating reverse order for Enterprise Trunk with order id {} ", tblOrderListPrev.get(0).getOrderId());
								// Reverse Order Creation..It may be EntityAction I OR C
								cancelOrderServiceImpl.createReverseOrder(voipOrderRequest, tblOrderListPrev, tblEnvOrder);
								LOG.info("Creating reverse order for Enterprise Trunk with order id {} COMPLETED !!!!", tblOrderListPrev.get(0).getOrderId());
								
								//Creating Forward order...
								LOG.info("Creating Forward Order..... ");
								headerParamInfo = enterpriseTblOrderDetailsData.prepareTblOrderDetailsHeaderParamData(order);
								entityParamInfo = enterpriseTrunkTblOrderDetailsDataTransformerImpl
										.prepareTblOrderDetailsEntityParamDataForET(entTrunkEntity,
												order.getOrderHeader().getOrderType());
								orderHeader.setEntityAction("I");
								LOG.info("Creating Forward Order.....COMPLETED !!! ");
							}
						}
					}
					//ESVRRS-18523 :: END
					
					headerParamInfo.addChildParam(entityParamInfo);
					
					//create order
					voipOrderDao.createTblOrder(tblOrderObject);
					
					// :create order Details
					LOG.info("createOrders start creating entperprise trunk entity order details");

					if (entityParamInfo != null && entityParamInfo.getAction() != null)
						voipOrderDao.populateOrderDetails(tblOrderObject, headerParamInfo.getChildParams(),
								entityParamInfo.getAction(), 0, 0);
					else
						voipOrderDao.populateOrderDetails(tblOrderObject, headerParamInfo.getChildParams(), "n", 0, 0);

					// :create service entry for WF
					LOG.info("create Orders Service start creating service for ET entity");
					orderHeader.setFlowPath(FlowPath.valueOf(tblOrderObject.getFlowPath()));
					orderHeader.setTblOrderId(tblOrderObject.getOrderId());
					orderHeader.setEntityType(EsapEnum.OrderEntity.ENTERPRISE_TRUNK.getIndex());					
					orderHeader.setProvisionCategory(entTrunkEntity.getProvisionCategory());
					order.setOrderHeader(orderHeader);
					
					orderPrevPass = new Order();
					orderPrevPass.setOrderHeader(orderHeader);

					tblOrderServiceList = enterpriseTblOrderServiceData.prepareTblOrderServiceData(order, orderPrevPass,
							null);

					for (TblOrderService tblOrderService : tblOrderServiceList) {
						voipOrderDao.createTblOrderService(tblOrderService);
					}

					voipOrderDao.updateTblOrderStatus(tblOrderObject.getOrderId(), WorkOrderEnum.Status.WO_INIT);
					
				} else if (enterpriseTrunkEntityPrev != null && "NC".equalsIgnoreCase(orderHeader.getEntityAction())) {
					
					LOG.info("deviceEntienterpriseTrunkEntityPrevtyPrev != null && \"NC\".equalsIgnoreCase(orderHeader.getEntityAction())");
					LOG.info("Order Version ==>> {}", orderHeader.getOrderVersion());
					
					int orderVersion = Integer.parseInt(orderHeader.getOrderVersion());
					
					if(orderVersion > 0) {
						orderServiceHelperImpl.handleSuppOrderWithNoChange(order.getOrderHeader().getEnvOrderId(),
								enterpriseTrunkEntityPrev.getInternalOrderId(), tblEnvOrder);
					
					} else {
						
						LOG.info("This is MAC ET Scenario of Do Nothing");
					}
				}					
			}
			
		} catch (TranslatorException ex) {

			LOG.error("Exception {} {} ", ex.getMessage(), ex);
			throw new TranslatorException(ex.getErrorCode(), ex.getMessage());
		} catch (Exception e) {
			LOG.error("Exception {} {} ", e.getMessage(), e);
			throw new GenericException(GenericException.GENERIC_EXCEPTION,
					"Exception occured while providing input arguments");
		}
		LOG.info("Exit - createReleaseOrders");
		return isCreated;
	}

}
