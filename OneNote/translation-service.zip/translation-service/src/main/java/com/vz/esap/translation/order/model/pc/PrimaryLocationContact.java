package com.vz.esap.translation.order.model.pc;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;

import com.fasterxml.jackson.annotation.JsonProperty;

@XmlAccessorType(XmlAccessType.FIELD)
public class PrimaryLocationContact {

	@XmlElement(name = "ContactLastName")
	@JsonProperty(value = "ContactLastName")
	private String contactLastName;

	@XmlElement(name = "ContactFirstName")
	@JsonProperty(value = "ContactFirstName")
	private String contactFirstName;

	@XmlElement(name = "Communication")
	@JsonProperty(value = "Communication")
	private Communication[] communication;

	@XmlElement(name = "ContactComments")
	@JsonProperty(value = "ContactComments")
	private String contactComments;

	public String getContactLastName() {
		return contactLastName;
	}

	public void setContactLastName(String contactLastName) {
		this.contactLastName = contactLastName;
	}

	public String getContactFirstName() {
		return contactFirstName;
	}

	public void setContactFirstName(String contactFirstName) {
		this.contactFirstName = contactFirstName;
	}

	public Communication[] getCommunication() {
		return communication;
	}

	public void setCommunication(Communication[] communication) {
		this.communication = communication;
	}

	public String getContactComments() {
		return contactComments;
	}

	public void setContactComments(String contactComments) {
		this.contactComments = contactComments;
	}

	@Override
	public String toString() {
		return "ClassPojo [ContactLastName = " + contactLastName + ", ContactFirstName = " + contactFirstName
				+ ", Communication = " + communication + ", ContactComments = " + contactComments + "]";
	}
}
