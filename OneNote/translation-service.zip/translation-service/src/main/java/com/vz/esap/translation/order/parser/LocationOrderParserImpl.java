package com.vz.esap.translation.order.parser;

import static java.util.Arrays.stream;

import java.math.BigInteger;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.vz.esap.translation.entity.AuthService;
import com.vz.esap.translation.entity.LocationEntity;
import com.vz.esap.translation.entity.LocationEntity.TypeOfLocEnum;
import com.vz.esap.translation.entity.Session;
import com.vz.esap.translation.enums.EsapEnum;
import com.vz.esap.translation.enums.EsapEnum.AuthFeatureType;
import com.vz.esap.translation.enums.EsapEnum.ChangeType;
import com.vz.esap.translation.enums.EsapEnum.LocationType;
import com.vz.esap.translation.enums.EsapEnum.RedundancyPriorityType;
import com.vz.esap.translation.enums.EsapEnum.RedundancyType;
import com.vz.esap.translation.enums.EsapEnum.SolutionType;
import com.vz.esap.translation.enums.EsapEnum.VoipServiceType;
import com.vz.esap.translation.exception.TranslatorException;
import com.vz.esap.translation.order.entity.identifier.util.EntityIdentifireUtil;
import com.vz.esap.translation.order.model.request.ChangeManagement;
import com.vz.esap.translation.order.model.request.ChangedElement;
import com.vz.esap.translation.order.model.request.Communication;
import com.vz.esap.translation.order.model.request.ConvergedService;
import com.vz.esap.translation.order.model.request.Feature;
import com.vz.esap.translation.order.model.request.Specification;
import com.vz.esap.translation.order.model.request.VOIPOrderRequest;
import com.vz.esap.translation.order.service.helper.OrderServiceHelper;
import com.vz.esap.translation.util.InventoryUtil;

import reactor.util.CollectionUtils;

/**
 * @author chattni
 *
 */
@Component
public class LocationOrderParserImpl implements LocationOrderParser {
	private static final Logger LOG = LoggerFactory.getLogger(LocationOrderParserImpl.class);

	@Autowired
	private OrderServiceHelper orderServiceHelperImpl;

	@Autowired
	private EntityIdentifireUtil entityIdentifireUtil;
	
	@Autowired
	private InventoryUtil inventoryUtil;

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.vz.esap.translation.order.parser.LocationOrderParser#parseLocationOrder(
	 * com.vz.esap.translation.order.model.request.VOIPOrderRequest)
	 */
	@Override
	public LocationEntity parseLocationOrder(VOIPOrderRequest voipOrderRequest)
			throws TranslatorException, ParseException {
		LOG.info("Entered - parseLocationOrder");
		LocationEntity location = null;
		ConvergedService convergedService = null;
		Session session = null;
		List<Feature> vpnFeature = null;
		List<Feature> vpnPortFeature = null;
		String bwEnterpriseId = null;
		List<Feature> lsrFeature = null;
		List<Specification> btnSpec = null;
		List<Feature> trunkConFeature = null;
		List<Feature> trunkFeatList = null;
		List<Specification> trunkSessionCountSpec = null;
		int sessionCount = 0;
		String sipDomain = null;
		
		try {

			location = new LocationEntity();
			
			convergedService = voipOrderRequest.getConvergedService();
			
			if (convergedService != null && convergedService.getID() != null) {
				location.setLocationId(convergedService.getID());
			}
			if (voipOrderRequest.getOrderHeader().getEnterpriseId() != null)
				location.setCustomerId(voipOrderRequest.getOrderHeader().getEnterpriseId());
			
			location.setAsClli(voipOrderRequest.getOrderHeader().getAsClli()); //add broadsoft clli.
				
			if (voipOrderRequest.getCircuitInfo() != null && voipOrderRequest.getCircuitInfo()[0] != null) {
				location.setCircuitId(voipOrderRequest.getCircuitInfo()[0].getCircuitId());
				location.setVpnName(voipOrderRequest.getCircuitInfo()[0].getVpnName()[0]);
			}

			if (voipOrderRequest.getOrderHeader().getBwEnterpriseId() != null)
				bwEnterpriseId = voipOrderRequest.getOrderHeader().getBwEnterpriseId();
			else
				bwEnterpriseId = entityIdentifireUtil.createBwEnterpriseId(voipOrderRequest.getOrderHeader().getGCHId(),
						voipOrderRequest.getOrderHeader().getSolutionType(), null,
						voipOrderRequest.getOrderHeader().getEnterpriseId());
			
			if(SolutionType.HPBX.equals(voipOrderRequest.getOrderHeader().getSolutionType())) {
				sipDomain = entityIdentifireUtil.getHpbxDomainName();
						
			}else {
				sipDomain = bwEnterpriseId.toLowerCase() + ".vm.xohost.com";
						
			}
				
			location.setSipDomain(sipDomain);
			LOG.debug("SIP Domain of Location is :{}", location.getSipDomain());

			if (voipOrderRequest.getLocation() != null && voipOrderRequest.getLocation().getLocationAddress() != null
					&& voipOrderRequest.getLocation().getLocationAddress().getCountryCode() != null) {
				location.setRegion(voipOrderRequest.getLocation().getLocationAddress().getCountryCode());
				location.setAddress(voipOrderRequest.getLocation().getLocationAddress().getAddressLine());
				location.setCity(voipOrderRequest.getLocation().getLocationAddress().getCity());
				location.setState(voipOrderRequest.getLocation().getLocationAddress().getState());
				location.setZip(voipOrderRequest.getLocation().getLocationAddress().getZip());
				location.setCountry(voipOrderRequest.getLocation().getLocationAddress().getCountryCode());
			} else {
				location.setRegion("US");
			}
			
			if (voipOrderRequest.getLocation() != null && voipOrderRequest.getLocation().getName() != null) {				
				location.setName(voipOrderRequest.getLocation().getName());				
			} else {
				location.setName(convergedService.getID());
			}
			
			
			if (voipOrderRequest.getOrderHeader().getSolutionType() != null)
				location.setSolutionType(voipOrderRequest.getOrderHeader().getSolutionType());

			if (Arrays.asList(SolutionType.ESIP_ESL, SolutionType.ESIP_EBL)
					.contains(voipOrderRequest.getOrderHeader().getSolutionType())) {
				location.setAuthFeatureType(AuthFeatureType.FET_ESIP);
				
			} else if (SolutionType.IPFLEX.equals(voipOrderRequest.getOrderHeader().getSolutionType())) {
				location.setAuthFeatureType(orderServiceHelperImpl.getAuthFeatureType(voipOrderRequest));
				location.setTypeOfLoc(TypeOfLocEnum.FLEX);
				
			}

			lsrFeature = stream(voipOrderRequest.getConvergedService().getFeature())
					.filter(feature -> "FET_XO_LSR".equalsIgnoreCase(feature.getCode())
							|| "FET_HPBX_LSR".equalsIgnoreCase(feature.getCode())).collect(Collectors.toList());
			
			if(!CollectionUtils.isEmpty(lsrFeature)) {				
				btnSpec = stream(lsrFeature.get(0).getSpecification())
						.filter(spec -> "SP_XO_NEW".equalsIgnoreCase(spec.getCode())).collect(Collectors.toList());				
			}
			
			List<AuthService> authServicesList = new ArrayList<>();	
			for (Feature feature : convergedService.getFeature()) {
				
				if (("EFET_VOIP_LOC_LVL".equalsIgnoreCase(feature.getCode())
						|| "FET_LOC_LVL".equalsIgnoreCase(feature.getCode()))
						&& ("I".equalsIgnoreCase(voipOrderRequest.getOrderHeader().getOrderType())
								|| "C".equalsIgnoreCase(voipOrderRequest.getOrderHeader().getOrderType())))
				{

					location.setLocationId(convergedService.getID());
					if (feature.getInstanceId() != null) {
						location.setPqInstanceId(Long.valueOf(feature.getInstanceId()));
					}
					if (feature.getActionCode() != null) {
						String entityAction = feature.getActionCode();
						if ("ADD".equalsIgnoreCase(entityAction)) {
							location.setAction(EsapEnum.OrderAction.ADD);
						} else if ("CHANGE".equalsIgnoreCase(entityAction)) {
							location.setAction(EsapEnum.OrderAction.MODIFY);
						} else if ("DELETE".equalsIgnoreCase(entityAction)) {
							location.setAction(EsapEnum.OrderAction.DELETE);
						}
					}
					for (Specification specification : feature.getSpecification()) {
						if ("SP_VOIP_CALLER_ID_CONFIG".equalsIgnoreCase(specification.getCode())) {
							boolean overrideCidNum = "Yes".equalsIgnoreCase(specification.getValue()) ? true : false;
							location.setOverrideCidNum(overrideCidNum);
						}
						if ("SP_VOIP_BURSTABLE_EST".equalsIgnoreCase(specification.getCode())) {
							boolean locationCclIndicator = "Yes".equalsIgnoreCase(specification.getValue()) ? true
									: false;
							location.setLocationCclIndicator(locationCclIndicator);
						}
						if ("ESP_ENT_TRUNK_INST_ID".equalsIgnoreCase(specification.getCode())) {
							location.setEnterpriseTrunkId(new Long(specification.getValue()));
						}
						if ("ESP_DESIGN_ID".equalsIgnoreCase(specification.getCode())) {
							location.setDesignId(new Long(specification.getValue()));
						}
						if ("ESP_PORT_OUT_TYPE".equalsIgnoreCase(specification.getCode())) {
							location.setPortOutType(specification.getValue());
						}
						if ("SP_VOIP_LOC_LEVEL_CAC".equalsIgnoreCase(specification.getCode())) { // confirm
							location.setMaxConcurrentCalls(
									BigInteger.valueOf(Integer.parseInt(specification.getValue())));
						}
						if ("SP_EIS_CLIN_DESC".equalsIgnoreCase(specification.getCode())) {
							location.setClin(specification.getCode());
						}

						if ("ESP_DIALING_COUNTRY_CODE".equalsIgnoreCase(specification.getCode())) {
							location.setDialingCountryCode(specification.getValue());
						}
						if ("SP_VOIP_NUM_ENTER_LOC_CD".equalsIgnoreCase(specification.getCode())) {
							location.setAbbrDialingCode(specification.getValue());
						}
						if ("SP_VOIP_DO_YOU_WANT_VARRS".equalsIgnoreCase(specification.getCode())) {
							location.setVARRS(specification.getValueCode());
						}
						if ("SP_VOIP_TYPE_OF_EXPEDITE".equalsIgnoreCase(specification.getCode())) {
							boolean expedite = "Yes".equalsIgnoreCase(specification.getValue()) ? true : false;
							location.setExpedite(expedite);
						}

						if ("SP_VOIP_WEB_LANGUAGE".equalsIgnoreCase(specification.getCode())) {
							location.setWebLanguage(specification.getValue());
						}
						if ("SP_VOIP_VOICE_MAIL_LANG".equalsIgnoreCase(specification.getCode())) {
							location.setVmLanguage(specification.getValue());
						}
						if ("SP_VOIP_USG_PLAN".equalsIgnoreCase(specification.getCode())) {
							location.setBillingType(specification.getValue());
						}
						if ("SP_VOIP_MAX_CONC_OFF_LOC_CALL".equalsIgnoreCase(specification.getCode())) {// confirm
							location.setMaxConcurrentCalls(new BigInteger(specification.getValue()));
						}
						if ("SP_VOIP_NUM_CONC_CALL".equalsIgnoreCase(specification.getCode())) {
							location.setMaxConcurrentOffNet(new BigInteger(specification.getValue()));
						}
						if ("SP_VOIP_SERVICE_PLAN".equalsIgnoreCase(specification.getCode())) {
							location.setServiceLevel(specification.getValue());
						}
						if ("SP_VOIP_VIPER".equalsIgnoreCase(specification.getCode())) {
							location.setAdvantageClub(specification.getValue());
						}
						if ("SP_VOIP_TOT_QTY_TEL_QUOTED".equalsIgnoreCase(specification.getCode())) {
							location.setTotalPublicNumbers(new BigInteger(specification.getValue()));
						}
						if ("ESP_CALLER_ID_NUMBER".equalsIgnoreCase(specification.getCode())) {
							location.setCallingPartyNumber(specification.getValue());
						}
						if ("SP_VOIP_NUM_HOST_EXT_DIAL_DGT".equalsIgnoreCase(specification.getCode())) {
							location.setExtensionLength(new BigInteger(specification.getValue()));
						}
						if ("SP_VOIP_LINE_PORT_LENGTH".equalsIgnoreCase(specification.getCode())) {
							location.setLinePortLength(new Integer(specification.getValue()));
						}

						if ("SP_VOIP_SERVICE_TYPE".equalsIgnoreCase(specification.getCode())) {
							location.setVoipServiceType(specification.getValue());
						}else {							
							if(voipOrderRequest.getOrderHeader().getSolutionType() != null) {								
								if(SolutionType.ESIP_ESL.equals(voipOrderRequest.getOrderHeader().getSolutionType())) {
									location.setVoipServiceType(VoipServiceType.ENTERPRISE_SIP.getValue());
									location.setLocationType(LocationType.ESIP_ESL.getIndex());
									location.setTypeOfLoc(TypeOfLocEnum.ESIP_ESL);
								}									
								else if(SolutionType.ESIP_EBL.equals(voipOrderRequest.getOrderHeader().getSolutionType())) {
									location.setVoipServiceType(VoipServiceType.ENTERPRISE_SIP.getValue());
									location.setLocationType(LocationType.ESIP_EBL.getIndex());
									location.setTypeOfLoc(TypeOfLocEnum.ESIP_EBL);
								}
								else if(SolutionType.IPFLEX.equals(voipOrderRequest.getOrderHeader().getSolutionType())) {
									location.setVoipServiceType(VoipServiceType.IP_FLEX.getValue());
									location.setLocationType(LocationType.IPFLEX.getIndex());
									location.setTypeOfLoc(TypeOfLocEnum.FLEX);
								}
							}
						}
						if ("ESP_EMERGENCY_CALLING_LINE".equalsIgnoreCase(specification.getCode())) {
							location.setEmergencyCallLine(specification.getValue());
						}

						if ("ESP_HUB_SVC_INSTANCE_ID".equalsIgnoreCase(specification.getCode())) {
							location.setHubLocationId(specification.getValue());
						} else if ("SP_XO_ESL".equalsIgnoreCase(specification.getCode())) {
							location.setHubLocationId(specification.getValue());
							
							Map<String, String> entMap = orderServiceHelperImpl.getEnterpriseFromEsl(specification.getValue());
							location.setSipDomain(entMap.get("SIP_DOMAIN"));
							LOG.info("SIP Domain of ESL was :{}", location.getSipDomain());
						}
						if ("ESP_LOCATION_SCREENED_TN".equalsIgnoreCase(specification.getCode())) {
							location.setsTn(specification.getValue());
						}
						if ("SP_VOIP_ALTERNATE_CALLER_ID".equalsIgnoreCase(specification.getCode())) {
							boolean enhancedANIInd = "Yes".equalsIgnoreCase(specification.getValue()) ? true : false;
							location.setEnhancedANIInd(enhancedANIInd);
						}
						if ("SP_VOIP_CALLER_ID_NAME_INBND".equalsIgnoreCase(specification.getCode())) {
							boolean callingNameInd = "Yes".equalsIgnoreCase(specification.getValue()) ? true : false;
							location.setCallingNameInd(callingNameInd);
						}
						
						if ("SP_VOIP_CALLER_ID_CONFIG".equalsIgnoreCase(specification.getCode())) {
							location.setCallingPartyPrivacy(specification.getValue());
						}
						if ("SP_XO_TNQ".equalsIgnoreCase(specification.getCode())) {
							location.setTnQuantity(Long.valueOf(specification.getValue()));
						}
						if ("SP_XO_RED".equalsIgnoreCase(specification.getCode())) {

							RedundancyType redundancy = null;
							if ("PRIORITY".equalsIgnoreCase(specification.getValue()))
								redundancy = RedundancyType.PRIORITY;
							if ("Load Sharing".equalsIgnoreCase(specification.getValue()))
								redundancy = RedundancyType.LOADSHARING;
							if ("NONE".equalsIgnoreCase(specification.getValue()))
								redundancy = RedundancyType.NONE;

							location.setRedundancy(redundancy);
						}
						if ("SP_XO_REDID".equalsIgnoreCase(specification.getCode())) {
							location.setRedundancyId(specification.getValue());
						}
						if ("SP_XO_REDPT".equalsIgnoreCase(specification.getCode())) {

							RedundancyPriorityType redundancyPriority = null;
							if ("PRIMARY".equalsIgnoreCase(specification.getValue()))
								redundancyPriority = RedundancyPriorityType.PRIMARY;
							if ("SECONDARY".equalsIgnoreCase(specification.getValue()))
								redundancyPriority = RedundancyPriorityType.SECONDARY;

							location.setRedundancyPriorityType(redundancyPriority);
						}
						if ("SP_XO_RED".equalsIgnoreCase(specification.getCode())) {
							location.setEslId(convergedService.getID());
							location.setTypeOfLoc(TypeOfLocEnum.ESIP_ESL);

						}
						if ("SP_XO_ESL".equalsIgnoreCase(specification.getCode())) {
							location.setTypeOfLoc(TypeOfLocEnum.ESIP_EBL);
							location.setEslId(specification.getValue());
							location.setCustomerId(orderServiceHelperImpl
									.getEnterpriseInformationFromEsl(specification.getValue()));
						}
						if ("SP_XO_BW_PORT_NUM".equalsIgnoreCase(specification.getCode())) {
							location.setBroadworksPortalNumber(specification.getValue());
						}
						if ("SP_XO_GRO".equalsIgnoreCase(specification.getCode())) {
							location.setBillingTN(Long.valueOf(specification.getValue()));
						}else if(!CollectionUtils.isEmpty(btnSpec)) {
							location.setBillingTN(Long.valueOf(btnSpec.get(0).getValue()));
						}
						if ("SP_XO_BW_LOC_ID".equalsIgnoreCase(specification.getCode())) {
							location.setBwLocationId(specification.getValue());
						}
						//Start VPN Change for ESIP
						if ("ESP_XO_ASSOCIATED_VPN_NAME".equalsIgnoreCase(specification.getCode())) {
							location.setVpnName(specification.getValue());
						}
						if ("SP_XO_ESBC_IP".equalsIgnoreCase(specification.getCode())) { //ESBC Signaling IP
							location.setEsbcSignalingIP(specification.getValue());
						}
					}
					
					//Add here
				}
				if ("FET_XO_AUT".equalsIgnoreCase(feature.getCode()))
					location.addAuthService("Call Forwarding Not Reachable", true);
				if ("FET_XO_TFD".equalsIgnoreCase(feature.getCode()))
					location.addAuthService("Worktime Feature", true);
				if ("FET_AUT".equalsIgnoreCase(feature.getCode()))
					location.addAuthService("Auto Attendant", true);
				if ("FET_CAL".equalsIgnoreCase(feature.getCode()))
					location.addAuthService("Call Center", true);				
				//Feature Quantity changes
				if ("FET_XO_WOR".equalsIgnoreCase(feature.getCode()) || "FET_IPA".equalsIgnoreCase(feature.getCode())) {
					
					String packageType = null;
					String featureQuantity = null;
					AuthService authService = new AuthService();
		
					for (Specification specification : feature.getSpecification()) {
						if ("SP_XO_PAC".equalsIgnoreCase(specification.getCode())) {
							packageType = specification.getValue();
						}
						if ("SP_QUA_XO".equalsIgnoreCase(specification.getCode())) {
							featureQuantity = specification.getValue();
						}
					}
						if(packageType != null) {
							authService.setName(feature.getName() + "-" + packageType);
							authService.setFeatureQuantity(featureQuantity);
							authService.setAuthorise(true);
						} else {
							authService.setName(feature.getName());
							authService.setFeatureQuantity(featureQuantity);
							authService.setAuthorise(true);
						}
					authServicesList.add(authService);	
				}
			}

			if(!authServicesList.isEmpty()) {
				location.setAuthService(authServicesList);
			}
			
			//Start :Session Fix 
			trunkFeatList = stream(voipOrderRequest.getConvergedService().getFeature())
					.filter(feature -> "FET_XO_TRU".equalsIgnoreCase(feature.getCode())).collect(Collectors.toList());

			
			if (!CollectionUtils.isEmpty(trunkFeatList)) {
				session = new Session();
				
				for (Feature trunkFeat : trunkFeatList) {
					
					if ("C".equalsIgnoreCase(voipOrderRequest.getOrderHeader().getOrderType())
							&& ("NONE".equalsIgnoreCase(trunkFeat.getActionCode())
									|| "ADD".equalsIgnoreCase(trunkFeat.getActionCode()))) {						
						
						trunkSessionCountSpec = stream(trunkFeat.getSpecification())
								.filter(spec -> "SP_TRK".equalsIgnoreCase(spec.getCode())).collect(Collectors.toList());
						LOG.info("Session Count Before = {}", sessionCount);
						
						if (!CollectionUtils.isEmpty(trunkSessionCountSpec)) {
							sessionCount = sessionCount + Integer.parseInt(trunkSessionCountSpec.get(0).getValue());
						}	
						LOG.info("Session Count After = {}", sessionCount);						
						
					} else {

						trunkSessionCountSpec = stream(trunkFeat.getSpecification())
								.filter(spec -> "SP_TRK".equalsIgnoreCase(spec.getCode())).collect(Collectors.toList());
						
						if (!CollectionUtils.isEmpty(trunkSessionCountSpec)) {
							sessionCount = sessionCount + Integer.parseInt(trunkSessionCountSpec.get(0).getValue());
						}	
					}
				}
				
				LOG.info("Session Total Count ={} ", sessionCount);

				if ("I".equalsIgnoreCase(voipOrderRequest.getOrderHeader().getOrderType())){
					location.setGroupUserLimit(String.valueOf(sessionCount));
					session.setQuantity(sessionCount);
					location.setSession(session);
					
				}				
			}
			//End :Session Fix 
			
			vpnFeature = stream(voipOrderRequest.getConvergedService().getFeature())
					.filter(feature -> "FET_IPFVPN".equalsIgnoreCase(feature.getCode())
							|| "EXT_FET_VPN".equalsIgnoreCase(feature.getCode())).collect(Collectors.toList());

			if (!CollectionUtils.isEmpty(vpnFeature)) {

				for (Specification spec : vpnFeature.get(0).getSpecification()) {
					if ("SP_XO_IPF".equalsIgnoreCase(spec.getCode()))
						location.setVpnPortSpeed(spec.getValue());
					if ("SP_VPN_NAME".equalsIgnoreCase(spec.getCode()))
						location.setVpnName(spec.getValue());
				}
			}

			vpnPortFeature = stream(voipOrderRequest.getConvergedService().getFeature())
					.filter(feature -> "FET_IPF_VPNPRT".equalsIgnoreCase(feature.getCode()))
					.collect(Collectors.toList());

			if (!CollectionUtils.isEmpty(vpnPortFeature)) {

				for (Specification spec : vpnPortFeature.get(0).getSpecification()) {
					if ("SP_XO_IPFPS".equalsIgnoreCase(spec.getCode()))
						location.setPortSpeed(spec.getValue());
					else if ("SP_XO_PORT".equalsIgnoreCase(spec.getCode()))
						location.setVpnPortType(spec.getValue());
					else if ("SP_XO_VGE".equalsIgnoreCase(spec.getCode()))
						location.setVgeCont(spec.getValue());
				}
			}

			if ("C".equalsIgnoreCase(voipOrderRequest.getOrderHeader().getOrderType())) {

				session = new Session();
				LocationEntity changeLocation = parseLocationChangeOrder(voipOrderRequest);

				if (sessionCount == 0) {
					changeLocation.setGroupUserLimit(null);

				} else {
					changeLocation.setGroupUserLimit(String.valueOf(sessionCount));

				}
				session.setQuantity(sessionCount);
				changeLocation.setSession(session);

				location.setLocationEntity(changeLocation);
				LOG.info("In Loc Parser location.getGroupUserLimit() -->>{}", location.getGroupUserLimit());
				LOG.info("In Loc Parser changeLocation.getGroupUserLimit() -->>{}", changeLocation.getGroupUserLimit());
				LOG.info("In Loc Parser changeLocation.getMaxActiveCall() -->>{}", changeLocation.getMaxActiveCall());
				LOG.info("In Loc Parser changeLocation.getMaxActiveIncomingCalls() -->>{}",
						changeLocation.getMaxActiveIncomingCalls());
				LOG.info("In Loc Parser changeLocation.getMaxActiveIncomingCalls() -->>{}",
						changeLocation.getMaxActiveIncomingCalls());
			}

			trunkConFeature = stream(voipOrderRequest.getConvergedService().getFeature())
					.filter(feature -> "FET_XO_TRU_CON".equalsIgnoreCase(feature.getCode())).collect(Collectors.toList());
			
			if (!CollectionUtils.isEmpty(trunkConFeature)) {
				
				LOG.info("FET_XO_TRU_CON is present and getting the Max connection for Flex");
				
				long twoWayChannelCount = 0;
				long didChannelCount = 0;
				long dodChannelCount = 0;
				
				for (Specification spec : trunkConFeature.get(0).getSpecification()) {
					if ("SP_XO_NUM".equalsIgnoreCase(spec.getCode()))
						twoWayChannelCount = Long.valueOf(spec.getValue());
					else if ("SP_XO_NUM_DID".equalsIgnoreCase(spec.getCode()))
						didChannelCount = Long.valueOf(spec.getValue());
					else if ("SP_XO_NUM_DOD".equalsIgnoreCase(spec.getCode()))
						dodChannelCount = Long.valueOf(spec.getValue());
				}
				
				location.setMaxActiveCalls(twoWayChannelCount + didChannelCount + dodChannelCount);
				location.setMaxActiveIncomingCalls(twoWayChannelCount + didChannelCount);
				location.setMaxActiveOutgoingCalls(twoWayChannelCount + dodChannelCount);	
				
				LOG.info("In Loc Parser location.getMaxActiveCall() -->>{}", location.getMaxActiveCalls());
				LOG.info("In Loc Parser location.getMaxActiveIncomingCalls() -->>{}",
						location.getMaxActiveIncomingCalls());
				LOG.info("In Loc Parser location.getMaxActiveIncomingCalls() -->>{}",
						location.getMaxActiveIncomingCalls());				
				
			}
			
			
			//Start: Time Zone Fix
			
			//Time Zone :
			if (voipOrderRequest.getAdditionalInfo() != null
					&& voipOrderRequest.getAdditionalInfo().getTimeZone() != null) {
				String timeZone = inventoryUtil.getTimeZoneId(voipOrderRequest.getAdditionalInfo().getTimeZone());					
				
				location.setTimeZone(timeZone != null? timeZone : "26");
				
			}else {
				location.setTimeZone("26");
			}
			
			LOG.info("Time Zone is {}", location.getTimeZone());
			
			
			//Day Light Saving :
			
			if (voipOrderRequest.getAdditionalInfo() != null
					&& voipOrderRequest.getAdditionalInfo().getDayLightSavingsInd() != null) {
				
				location.setDaylightSavingInd(voipOrderRequest.getAdditionalInfo().getDayLightSavingsInd());
				
			}else {
				location.setDaylightSavingInd("N");
			}
			
			LOG.info("Day Light Saving Indicator is {}", location.getDaylightSavingInd());
			
			if (voipOrderRequest.getLocation() != null
					&& voipOrderRequest.getLocation().getPrimaryLocationContact() != null
					&& voipOrderRequest.getLocation().getPrimaryLocationContact().getCommunication() != null) {

				if (voipOrderRequest.getLocation().getPrimaryLocationContact().getCommunication().length > 0) {
					Communication[] communication = voipOrderRequest.getLocation().getPrimaryLocationContact()
							.getCommunication();
					for (Communication comm : communication) {
						if ("Phone".equalsIgnoreCase(comm.getChannel())) {
							location.setDialingCountryCode(comm.getCountryDialing());
							break;
						}
					}
				}
			}
			
			//End: Time Zone Fix
			
		} catch (Exception e) {
			LOG.error("Exception {}", e);
			throw new TranslatorException(TranslatorException.ErrorCode.ORDER_NOT_SAVABLE,
					"Unexpected Error Occur while Parsing Location Order");
		}
		//location is old and changeLocation is new
		LOG.info("Exited - parseLocation");
		return location;
	}

	// new/change Location entities.
	// Do same for all other entities like parseXXXChangeOrder(...)
	public LocationEntity parseLocationChangeOrder(VOIPOrderRequest voipOrderRequest) {

		LOG.info("Entered - parseLocationChangeOrder");

		ChangeManagement[] changeManagements = voipOrderRequest.getChangeManagement();

		if (changeManagements == null) {
			// TODO: Logic for the ADD
			return null;
		}

		LocationEntity changeLocation = new LocationEntity();		
		
		changeLocation.setLocationId(voipOrderRequest.getConvergedService().getID());
		
		List<Feature> locFeature = stream(voipOrderRequest.getConvergedService().getFeature())
				.filter(feature -> "FET_LOC_LVL".equalsIgnoreCase(feature.getCode()))
				.collect(Collectors.toList());

		List<Feature> callForwardFeature = stream(voipOrderRequest.getConvergedService().getFeature())
				.filter(feature -> "FET_XO_AUT".equalsIgnoreCase(feature.getCode()))
				.collect(Collectors.toList());

		List<Feature> wtFeature = stream(voipOrderRequest.getConvergedService().getFeature())
				.filter(feature -> "FET_XO_TFD".equalsIgnoreCase(feature.getCode()))
				.collect(Collectors.toList());
		
		//3/25 : TO DO for similar to xoAutFeature(FET_XO_AUT) do for FET_AUT, FET_CAL

		List<Feature> sessionFeature = stream(voipOrderRequest.getConvergedService().getFeature())
				.filter(feature -> "FET_XO_SES".equalsIgnoreCase(feature.getCode()))
				.collect(Collectors.toList());
		
		List<Feature> trunkFeature = stream(voipOrderRequest.getConvergedService().getFeature())
				.filter(feature -> "SP_TRK".equalsIgnoreCase(feature.getCode()))
				.collect(Collectors.toList());
		
		//TODO: Here Need to do fix for Session Feature

		List<Feature> vpnFeature = stream(voipOrderRequest.getConvergedService().getFeature())
				.filter(feature -> feature.getCode().equalsIgnoreCase("FET_IPFVPN"))
				.collect(Collectors.toList());

		List<Feature> vpnPortFeature = stream(voipOrderRequest.getConvergedService().getFeature())
				.filter(feature -> feature.getCode().equalsIgnoreCase("FET_IPF_VPNPRT"))
				.collect(Collectors.toList());

		for (ChangeManagement changeManagement : changeManagements) {

			ChangedElement[] changeElements = changeManagement.getChangedElement();

			if (changeElements != null && changeElements.length > 0) {
				for (ChangedElement changedElement : changeElements) {

					

					if (!locFeature.isEmpty() && locFeature.get(0).getCode().equalsIgnoreCase(changedElement.getFeatureCode()) && locFeature
							.get(0).getInstanceId().equalsIgnoreCase(changedElement.getFeatureInstanceId())) {

						if (changedElement.getChangeType() != null
								&& ChangeType.CHANGED.toString().equalsIgnoreCase(changedElement.getChangeType())
								&& changedElement.getSpecificationCode() != null) {

							createChangedLocationEntity(changeLocation, changedElement.getSpecificationCode(),
									changedElement.getNewValue());

						}

					} else if (!callForwardFeature.isEmpty() && callForwardFeature.get(0).getCode().equalsIgnoreCase(changedElement.getFeatureCode())
							&& callForwardFeature.get(0).getInstanceId()
									.equalsIgnoreCase(changedElement.getFeatureInstanceId())) {
						if (changedElement.getChangeType() != null
								&& ChangeType.CHANGED.toString().equalsIgnoreCase(changedElement.getChangeType())
								&& changedElement.getSpecificationCode() != null) {

							createChangedLocationEntity(changeLocation, changedElement.getSpecificationCode(),
									changedElement.getNewValue());

						}
					} else if (!wtFeature.isEmpty() && wtFeature.get(0).getCode().equalsIgnoreCase(changedElement.getFeatureCode()) && wtFeature
							.get(0).getInstanceId().equalsIgnoreCase(changedElement.getFeatureInstanceId())) {
						if (changedElement.getChangeType() != null
								&& ChangeType.CHANGED.toString().equalsIgnoreCase(changedElement.getChangeType())
								&& changedElement.getSpecificationCode() != null) {

							createChangedLocationEntity(changeLocation, changedElement.getSpecificationCode(),
									changedElement.getNewValue());

						}
					} else if (!sessionFeature.isEmpty() && sessionFeature.get(0).getCode().equalsIgnoreCase(changedElement.getFeatureCode())
							&& sessionFeature.get(0).getInstanceId()
									.equalsIgnoreCase(changedElement.getFeatureInstanceId())) {
						if (changedElement.getChangeType() != null
								&& ChangeType.CHANGED.toString().equalsIgnoreCase(changedElement.getChangeType())
								&& changedElement.getSpecificationCode() != null) {

							createChangedLocationEntity(changeLocation, changedElement.getSpecificationCode(),
									changedElement.getNewValue());

						}
					} else if (!vpnFeature.isEmpty() && vpnFeature.get(0).getCode().equalsIgnoreCase(changedElement.getFeatureCode())
							&& vpnFeature.get(0).getInstanceId()
									.equalsIgnoreCase(changedElement.getFeatureInstanceId())) {
						if (changedElement.getChangeType() != null
								&& ChangeType.CHANGED.toString().equalsIgnoreCase(changedElement.getChangeType())
								&& changedElement.getSpecificationCode() != null) {

							createChangedLocationEntity(changeLocation, changedElement.getSpecificationCode(),
									changedElement.getNewValue());

						}
					} else if (!vpnPortFeature.isEmpty() && vpnPortFeature.get(0).getCode().equalsIgnoreCase(changedElement.getFeatureCode())
							&& vpnPortFeature.get(0).getInstanceId()
									.equalsIgnoreCase(changedElement.getFeatureInstanceId())) {
						if (changedElement.getChangeType() != null
								&& ChangeType.CHANGED.toString().equalsIgnoreCase(changedElement.getChangeType())
								&& changedElement.getSpecificationCode() != null) {

							createChangedLocationEntity(changeLocation, changedElement.getSpecificationCode(),
									changedElement.getNewValue());

						}
					} else if (!trunkFeature.isEmpty()) {
						
						for (Feature tgfeat : trunkFeature) {
							if (tgfeat.getCode().equalsIgnoreCase(changedElement.getFeatureCode())
							&& tgfeat.getInstanceId()
									.equalsIgnoreCase(changedElement.getFeatureInstanceId())
									&& changedElement.getChangeType() != null
									&& ChangeType.CHANGED.toString().equalsIgnoreCase(changedElement.getChangeType())
									&& changedElement.getSpecificationCode() != null) {
								
									createChangedLocationEntity(changeLocation, changedElement.getSpecificationCode(),
											changedElement.getNewValue());

								}								
							}
						}
					}
				}
			}
		LOG.info("Exited - parseLocationChangeOrder");
		return changeLocation;
	}

	// new/change Location entities.
	// Do same for all other entities like createChangedXXXEntity(...)
	public void createChangedLocationEntity(LocationEntity changedLocation, String specCode, String specValue) {

		LOG.info("Entered - createChangedLocationEntity for specCode = {} and specValue = {}", specCode, specValue);

		if (changedLocation == null) {
			changedLocation = new LocationEntity();
		}

		if ("SP_VOIP_CALLER_ID_CONFIG".equalsIgnoreCase(specCode)) {
			boolean overrideCidNum = "Yes".equalsIgnoreCase(specValue) ? true : false;
			changedLocation.setOverrideCidNum(overrideCidNum);
		}
		if ("SP_VOIP_BURSTABLE_EST".equalsIgnoreCase(specCode)) {
			boolean invLocationCclIndicator = "Yes".equalsIgnoreCase(specValue) ? true : false;
			changedLocation.setLocationCclIndicator(invLocationCclIndicator);
		}
		if ("ESP_ENT_TRUNK_INST_ID".equalsIgnoreCase(specCode)) {
			changedLocation.setEnterpriseTrunkId(new Long(specValue));
		}
		if ("ESP_DESIGN_ID".equalsIgnoreCase(specCode)) {
			changedLocation.setDesignId(new Long(specValue));
		}
		if ("ESP_PORT_OUT_TYPE".equalsIgnoreCase(specCode)) {
			changedLocation.setPortOutType(specValue);
		}
		if ("SP_VOIP_LOC_LEVEL_CAC".equalsIgnoreCase(specCode)) { // confirm
			changedLocation.setMaxConcurrentCalls(BigInteger.valueOf(Integer.parseInt(specValue)));
		}
		if ("SP_EIS_CLIN_DESC".equalsIgnoreCase(specCode)) {
			changedLocation.setClin(specCode);
		}
		if ("ESP_DIALING_COUNTRY_CODE".equalsIgnoreCase(specCode)) {
			changedLocation.setDialingCountryCode(specValue);
		}
		if ("SP_VOIP_NUM_ENTER_LOC_CD".equalsIgnoreCase(specCode)) {
			changedLocation.setAbbrDialingCode(specValue);
		}
		if ("SP_VOIP_DO_YOU_WANT_VARRS".equalsIgnoreCase(specCode)) {
			changedLocation.setVARRS(specValue);
		}
		if ("SP_VOIP_TYPE_OF_EXPEDITE".equalsIgnoreCase(specCode)) {
			boolean expedite = "Yes".equalsIgnoreCase(specValue) ? true : false;
			changedLocation.setExpedite(expedite);
		}
		if ("SP_VOIP_WEB_LANGUAGE".equalsIgnoreCase(specCode)) {
			changedLocation.setWebLanguage(specValue);
		}
		if ("SP_VOIP_VOICE_MAIL_LANG".equalsIgnoreCase(specCode)) {
			changedLocation.setVmLanguage(specValue);
		}
		if ("SP_VOIP_USG_PLAN".equalsIgnoreCase(specCode)) {
			changedLocation.setBillingType(specValue);
		}
		if ("SP_VOIP_MAX_CONC_OFF_LOC_CALL".equalsIgnoreCase(specCode)) {// confirm
			changedLocation.setMaxConcurrentCalls(new BigInteger(specValue));
		}
		if ("SP_VOIP_NUM_CONC_CALL".equalsIgnoreCase(specCode)) {
			changedLocation.setMaxConcurrentOffNet(new BigInteger(specValue));
		}
		if ("SP_VOIP_SERVICE_PLAN".equalsIgnoreCase(specCode)) {
			changedLocation.setServiceLevel(specValue);
		}
		if ("SP_VOIP_VIPER".equalsIgnoreCase(specCode)) {
			changedLocation.setAdvantageClub(specValue);
		}
		if ("SP_VOIP_TOT_QTY_TEL_QUOTED".equalsIgnoreCase(specCode)) {
			changedLocation.setTotalPublicNumbers(new BigInteger(specValue));
		}
		if ("ESP_CALLER_ID_NUMBER".equalsIgnoreCase(specCode)) {
			changedLocation.setCallingPartyNumber(specValue);
		}
		if ("SP_VOIP_NUM_HOST_EXT_DIAL_DGT".equalsIgnoreCase(specCode)) {
			changedLocation.setExtensionLength(new BigInteger(specValue));
		}
		if ("SP_VOIP_LINE_PORT_LENGTH".equalsIgnoreCase(specCode)) {
			changedLocation.setLinePortLength(new Integer(specValue));
		}
		if ("SP_VOIP_SERVICE_TYPE".equalsIgnoreCase(specCode)) {
			changedLocation.setVoipServiceType(specValue);
		}
		if ("ESP_EMERGENCY_CALLING_LINE".equalsIgnoreCase(specCode)) {
			changedLocation.setEmergencyCallLine(specValue);
		}
		/*if ("SP_VOIP_LOC_TYPE".equalsIgnoreCase(specCode)) {
			changedLocation.setTypeOfLoc(TypeOfLocEnum.valueOf(specValue));
		}*/
		if ("ESP_HUB_SVC_INSTANCE_ID".equalsIgnoreCase(specCode)) {
			changedLocation.setHubLocationId(specValue);
		}
		if ("SP_XO_ESL".equalsIgnoreCase(specCode)) {
			changedLocation.setHubLocationId(specValue);
		}
		if ("SP_SIP_DOMAIN".equalsIgnoreCase(specCode)) {
			changedLocation.setSipDomain(specValue);
		}
		if ("ESP_invLocation_SCREENED_TN".equalsIgnoreCase(specCode)) {
			changedLocation.setsTn(specValue);
		}
		if ("SP_VOIP_ALTERNATE_CALLER_ID".equalsIgnoreCase(specCode)) {
			boolean enhancedANIInd = "Yes".equalsIgnoreCase(specValue) ? true : false;
			changedLocation.setEnhancedANIInd(enhancedANIInd);
		}
		if ("SP_VOIP_CALLER_ID_NAME_INBND".equalsIgnoreCase(specCode)) {
			boolean callingNameInd = "Yes".equalsIgnoreCase(specValue) ? true : false;
			changedLocation.setCallingNameInd(callingNameInd);
		}
		if ("ESP_VOIP_invLocation_NAME".equalsIgnoreCase(specCode)) {
			changedLocation.setName(specValue);
		} /*else {
			changedLocation.setName(changedLocation.getLocationId());
		}*/
		if ("SP_VOIP_CALLER_ID_CONFIG".equalsIgnoreCase(specCode)) {
			changedLocation.setCallingPartyPrivacy(specValue);
		}
		if ("SP_XO_TNQ".equalsIgnoreCase(specCode)) {
			changedLocation.setTnQuantity(Long.valueOf(specValue));
		}
		if ("SP_XO_RED".equalsIgnoreCase(specCode)) {

			RedundancyType redundancy = null;
			if ("PRIORITY".equalsIgnoreCase(specValue))
				redundancy = RedundancyType.PRIORITY;
			if ("Load Sharing".equalsIgnoreCase(specValue))
				redundancy = RedundancyType.LOADSHARING;
			if ("NONE".equalsIgnoreCase(specValue))
				redundancy = RedundancyType.NONE;

			changedLocation.setRedundancy(redundancy);
		}
		if ("SP_XO_REDID".equalsIgnoreCase(specCode)) {
			changedLocation.setRedundancyId(specValue);
		}
		if ("SP_XO_REDPT".equalsIgnoreCase(specCode)) {

			RedundancyPriorityType redundancyPriority = null;
			if ("PRIMARY".equalsIgnoreCase(specValue))
				redundancyPriority = RedundancyPriorityType.PRIMARY;
			if ("SECONDARY".equalsIgnoreCase(specValue))
				redundancyPriority = RedundancyPriorityType.SECONDARY;

			changedLocation.setRedundancyPriorityType(redundancyPriority);
		}
		if ("SP_XO_RED".equalsIgnoreCase(specCode)) {
			changedLocation.setEslId(changedLocation.getLocationId());
			changedLocation.setTypeOfLoc(TypeOfLocEnum.ESIP_ESL);

		}
		if ("SP_XO_ESL".equalsIgnoreCase(specCode)) {
			changedLocation.setTypeOfLoc(TypeOfLocEnum.ESIP_EBL);
			changedLocation.setEslId(specValue);
		}
		if ("SP_XO_BW_PORT_NUM".equalsIgnoreCase(specCode)) {
			changedLocation.setBroadworksPortalNumber(specValue);
		}
		if ("SP_XO_GRO".equalsIgnoreCase(specCode)) {
			changedLocation.setBillingTN(Long.valueOf(specValue));
		}

		Session changedSession;
		if (changedLocation.getSession() == null) {
			changedSession = new Session();
			changedLocation.setSession(changedSession);
		} else {
			changedSession = changedLocation.getSession();
		}

		if (Arrays.asList("SP_QUA_XO", "SP_XO_PORTSPD", "SP_XO_COM", "SP_XO_MAX").contains(specCode)) {

			createChangedSessionEntity(changedSession, specCode, specValue);

		}
		
		long currentGroupUserLimit = 0;
		long existingGroupUserLimit = 0;
		long groupUserLimit;
		if (Arrays.asList("SP_TRK").contains(specCode)) {
			LOG.info("Inside Spec SP_TRK");
			
			if (changedLocation.getGroupUserLimit() != null) {
				existingGroupUserLimit = Long.valueOf(changedLocation.getGroupUserLimit());
			}
			if (specValue != null) {
				currentGroupUserLimit = Long.valueOf(specValue);
			}
			
			groupUserLimit = getChangedGroupUserLimitEntity(existingGroupUserLimit, currentGroupUserLimit);

			changedLocation.setGroupUserLimit(String.valueOf(groupUserLimit));
		}

		LOG.info("Exited - createChangedLocationEntity");
	}

	// new/change and object property of Location entities.
	// Do same for all other entities like createChangedXXXEntity(...)
	public void createChangedSessionEntity(Session changedSession, String specCode, String specValue) {
		LOG.info("Entered - createChangedSessionEntity");

		if (changedSession == null) {
			changedSession = new Session();
		}

		if ("SP_QUA_XO".equalsIgnoreCase(specCode))
			changedSession.setQuantity(Long.valueOf(specValue));
		if ("SP_XO_PORTSPD".equalsIgnoreCase(specCode))
			changedSession.setPortSpeed(specValue);
		if ("SP_XO_COM".equalsIgnoreCase(specCode))
			changedSession.setCompressionType(specValue);
		if ("SP_XO_MAX".equalsIgnoreCase(specCode))
			changedSession.setMaxQuantity(specValue);

		LOG.info("Exited - createChangedSessionEntity");
	}
	
	
	/**
	 * @param specCode
	 * @param specValue
	 * @return
	 */
	public long getChangedGroupUserLimitEntity(long existingGroupUserLimit, long currentGroupUserLimit) {
		LOG.info(
				"Entered - getChangedGroupUserLimitEntity for existingGroupUserLimit = {} and currentGroupUserLimit = {}",
				existingGroupUserLimit, currentGroupUserLimit);
		long resultantGroupUserLimit;
		
		resultantGroupUserLimit = existingGroupUserLimit + currentGroupUserLimit; 
		

		LOG.info("Exited - getChangedGroupUserLimitEntity with resultantGroupUserLimit = {}", resultantGroupUserLimit);
		return resultantGroupUserLimit;
	}
	
	//HPBX Start:
	
	@Override
	public List<LocationEntity> parseLocationOrders(VOIPOrderRequest voipOrderRequest)
			throws TranslatorException, ParseException {
		LOG.info("Entered - parseLocationOrders");
		LocationEntity location = null;
		ConvergedService convergedService = null;
		List<Feature> sessionFeature = null;
		Session session = null;
		List<Feature> vpnFeature = null;
		List<Feature> vpnPortFeature = null;
		String bwEnterpriseId = null;
		List<Feature> lsrFeature = null;
		List<Specification> btnSpec = null;
		List<Feature> trunkConFeature = null;
		List<LocationEntity> locations = null;
		List<Feature> entFeature = null;
		List<Specification> bwEntSpec = null;
		List<String> authFeatList = null;
		List<Feature> authFeature = null;
		String groupUserLimit = null;
		String vpnPortSpeed = null;
		String portSpeed = null;
		String vpnPortType = null;
		String vgeCont = null;
		long twoWayChannelCount = 0;
		long didChannelCount = 0;
		long dodChannelCount = 0;
		List<Feature> trunkFeatList = null;
		List<Specification> trunkSessionCountSpec = null;
		int sessionCount = 0; 
		String sipDomain = null;
		List<Feature> bwLocFeature = null;
		String bwLocId = null;
		String locationName = null;
		
		try {

			locations = new ArrayList<>();
			
			convergedService = voipOrderRequest.getConvergedService();
			
			entFeature = stream(voipOrderRequest.getConvergedService().getFeature())
					.filter(feature -> "EFET_VOIP_ENT_LVL".equalsIgnoreCase(feature.getCode())).collect(Collectors.toList());
			
			if(!CollectionUtils.isEmpty(entFeature)) {				
				bwEntSpec = stream(entFeature.get(0).getSpecification())
						.filter(spec -> "BW_ENTERPRISE_ID".equalsIgnoreCase(spec.getCode())).collect(Collectors.toList());				
			}

			if (voipOrderRequest.getOrderHeader().getBwEnterpriseId() != null) {
				bwEnterpriseId = voipOrderRequest.getOrderHeader().getBwEnterpriseId();
			} else if(!CollectionUtils.isEmpty(bwEntSpec)){
				bwEnterpriseId = bwEntSpec.get(0).getValue();
			} else {
				bwEnterpriseId = entityIdentifireUtil.createBwEnterpriseId(voipOrderRequest.getOrderHeader().getGCHId(),
						voipOrderRequest.getOrderHeader().getSolutionType(), null,
						voipOrderRequest.getOrderHeader().getEnterpriseId());
			}
			
			lsrFeature = stream(voipOrderRequest.getConvergedService().getFeature())
					.filter(feature -> "FET_XO_LSR".equalsIgnoreCase(feature.getCode())
							|| "FET_HPBX_LSR".equalsIgnoreCase(feature.getCode())).collect(Collectors.toList());
			
			if(!CollectionUtils.isEmpty(lsrFeature)) {				
				btnSpec = stream(lsrFeature.get(0).getSpecification())
						.filter(spec -> "SP_XO_NEW".equalsIgnoreCase(spec.getCode())).collect(Collectors.toList());				
			}
			
			authFeature = stream(voipOrderRequest.getConvergedService().getFeature())
					.filter(feature -> "FET_XO_AUT".equalsIgnoreCase(feature.getCode())
							|| "FET_XO_TFD".equalsIgnoreCase(feature.getCode())
							|| "FET_AUT".equalsIgnoreCase(feature.getCode())
							|| "FET_CAL".equalsIgnoreCase(feature.getCode()))
					.collect(Collectors.toList());
			
			if(!CollectionUtils.isEmpty(authFeature)) {
				authFeatList = new ArrayList<>();
				
				for (Feature authFeat : authFeature) {
					if ("FET_AUT".equalsIgnoreCase(authFeat.getCode()))
						authFeatList.add("Auto Attendant");
					if ("FET_XO_TFD".equalsIgnoreCase(authFeat.getCode()))
						authFeatList.add("Worktime Feature");
					if ("FET_XO_AUT".equalsIgnoreCase(authFeat.getCode()))
						authFeatList.add("Call Forwarding Not Reachable");
					if ("FET_CAL".equalsIgnoreCase(authFeat.getCode()))
						authFeatList.add("Call Center");
					}
				}
			
				

			vpnFeature = stream(voipOrderRequest.getConvergedService().getFeature())
					.filter(feature -> "FET_IPFVPN".equalsIgnoreCase(feature.getCode())).collect(Collectors.toList());

			if (!CollectionUtils.isEmpty(vpnFeature)) {

				for (Specification spec : vpnFeature.get(0).getSpecification()) {
					if ("SP_XO_IPF".equalsIgnoreCase(spec.getCode()))
						vpnPortSpeed = spec.getCode();						
				}
			}

			vpnPortFeature = stream(voipOrderRequest.getConvergedService().getFeature())
					.filter(feature -> "FET_IPF_VPNPRT".equalsIgnoreCase(feature.getCode()))
					.collect(Collectors.toList());

			if (!CollectionUtils.isEmpty(vpnPortFeature)) {

				for (Specification spec : vpnPortFeature.get(0).getSpecification()) {
					if ("SP_XO_IPFPS".equalsIgnoreCase(spec.getCode()))
						portSpeed = spec.getCode();						
					else if ("SP_XO_PORT".equalsIgnoreCase(spec.getCode()))
						vpnPortType = spec.getCode();						
					else if ("SP_XO_VGE".equalsIgnoreCase(spec.getCode()))
						vgeCont = spec.getCode();						
				}
			}
			
			trunkConFeature = stream(voipOrderRequest.getConvergedService().getFeature())
					.filter(feature -> feature.getCode().equalsIgnoreCase("FET_XO_TRU_CON")).collect(Collectors.toList());
			
			if (!CollectionUtils.isEmpty(trunkConFeature)) {
				
				for (Specification spec : trunkConFeature.get(0).getSpecification()) {
					if ("SP_XO_NUM".equalsIgnoreCase(spec.getCode()))
						twoWayChannelCount = Long.valueOf(spec.getValue());
					else if ("SP_XO_NUM_DID".equalsIgnoreCase(spec.getCode()))
						didChannelCount = Long.valueOf(spec.getValue());
					else if ("SP_XO_NUM_DOD".equalsIgnoreCase(spec.getCode()))
						dodChannelCount = Long.valueOf(spec.getValue());
				}				
			}
			
			
			bwLocFeature = stream(voipOrderRequest.getConvergedService().getFeature())
					.filter(feature -> "FET_HPBX_LOC_LVL_LOC".equalsIgnoreCase(feature.getCode()))
					.collect(Collectors.toList());

			if (!CollectionUtils.isEmpty(bwLocFeature)) {

				for (Specification spec : bwLocFeature.get(0).getSpecification()) {
					if ("SP_XO_BW_LOC_ID".equalsIgnoreCase(spec.getCode()))
						bwLocId = spec.getValue();
				}
			} else if (CollectionUtils.isEmpty(bwLocFeature)
					&& SolutionType.HPBX.equals(voipOrderRequest.getOrderHeader().getSolutionType())) {
				bwLocId = inventoryUtil
						.getHpbxBwLocationIdFromEnterpriseId(voipOrderRequest.getOrderHeader().getEnterpriseId());
				
			}

			LOG.info("BW Location Id = {}", bwLocId);
			
			//Loc Name Fix:
			if (voipOrderRequest.getLocation() != null && voipOrderRequest.getLocation().getName() != null) {				
				locationName = voipOrderRequest.getLocation().getName();				
			}
			
			
			for (Feature feature : convergedService.getFeature()) {
				
				if (("EFET_VOIP_LOC_LVL".equalsIgnoreCase(feature.getCode())
						|| "FET_LOC_LVL".equalsIgnoreCase(feature.getCode())
						|| "FET_HPBX_LOC_LVL".equalsIgnoreCase(feature.getCode())
						|| "FET_HPBX_LOC_LVL_LOC".equalsIgnoreCase(feature.getCode()))
						&& ("I".equalsIgnoreCase(voipOrderRequest.getOrderHeader().getOrderType())
								|| "C".equalsIgnoreCase(voipOrderRequest.getOrderHeader().getOrderType())))
				{

					location = new LocationEntity();
					
					location.setAsClli(voipOrderRequest.getOrderHeader().getAsClli()); //add broadsoft clli.
					
					location.setBwLocationId(bwLocId);
					
					if("FET_HPBX_LOC_LVL_LOC".equalsIgnoreCase(feature.getCode())) {
						location.setLocationId(feature.getInstanceId());
					}else if("FET_HPBX_LOC_LVL".equalsIgnoreCase(feature.getCode())) {
						location.setLocationId(convergedService.getID());
					} 
					
					
					if (voipOrderRequest.getOrderHeader().getEnterpriseId() != null) {
						location.setCustomerId(voipOrderRequest.getOrderHeader().getEnterpriseId());
					}
					if (voipOrderRequest.getCircuitInfo() != null && voipOrderRequest.getCircuitInfo()[0] != null) {
						location.setCircuitId(voipOrderRequest.getCircuitInfo()[0].getCircuitId());
						location.setVpnName(voipOrderRequest.getCircuitInfo()[0].getVpnName()[0]);
					}
					if (voipOrderRequest.getLocation() != null && voipOrderRequest.getLocation().getLocationAddress() != null
							&& voipOrderRequest.getLocation().getLocationAddress().getCountryCode() != null) {
						location.setRegion(voipOrderRequest.getLocation().getLocationAddress().getCountryCode());
						location.setAddress(voipOrderRequest.getLocation().getLocationAddress().getAddressLine());
						location.setCity(voipOrderRequest.getLocation().getLocationAddress().getCity());
						location.setState(voipOrderRequest.getLocation().getLocationAddress().getState());
						location.setZip(voipOrderRequest.getLocation().getLocationAddress().getZip());
						location.setCountry(voipOrderRequest.getLocation().getLocationAddress().getCountryCode());
					} else {
						location.setRegion("US");
					}
					if (voipOrderRequest.getOrderHeader().getSolutionType() != null) {
						location.setSolutionType(voipOrderRequest.getOrderHeader().getSolutionType());
					}
					if (Arrays.asList(SolutionType.ESIP_ESL, SolutionType.ESIP_EBL)
							.contains(voipOrderRequest.getOrderHeader().getSolutionType())) {
						location.setAuthFeatureType(AuthFeatureType.FET_ESIP);
					} else if (SolutionType.IPFLEX.equals(voipOrderRequest.getOrderHeader().getSolutionType())) {
						location.setAuthFeatureType(orderServiceHelperImpl.getAuthFeatureType(voipOrderRequest));
						location.setTypeOfLoc(TypeOfLocEnum.FLEX);
					} else if (SolutionType.HPBX.equals(voipOrderRequest.getOrderHeader().getSolutionType())) {
						location.setAuthFeatureType(AuthFeatureType.FET_HPBX);
						
						if("FET_HPBX_LOC_LVL_LOC".equalsIgnoreCase(feature.getCode())) {
							location.setTypeOfLoc(TypeOfLocEnum.HPBX_ECH);
						}else if("FET_HPBX_LOC_LVL".equalsIgnoreCase(feature.getCode())) {
							location.setTypeOfLoc(TypeOfLocEnum.HPBX_EBL);
						} 
					}
					if(!CollectionUtils.isEmpty(authFeatList)) {
						for (String intAuthFeature : authFeatList) {
							location.addAuthService(intAuthFeature, true);
						}
					}
					
					if(SolutionType.HPBX.equals(voipOrderRequest.getOrderHeader().getSolutionType())) {
						sipDomain = entityIdentifireUtil.getHpbxDomainName();
								
					}else {
						sipDomain = bwEnterpriseId.toLowerCase() + ".vm.xohost.com";
								
					}
					
					location.setSipDomain(sipDomain);
					LOG.debug("SIP Domain of Location is :{}", location.getSipDomain());
					
					location.setSession(session);
					location.setGroupUserLimit(groupUserLimit);
					location.setVpnPortSpeed(vpnPortSpeed);
					location.setPortSpeed(portSpeed);
					location.setVpnPortType(vpnPortType);
					location.setVgeCont(vgeCont);
					location.setMaxActiveCalls(twoWayChannelCount + didChannelCount + dodChannelCount);
					location.setMaxActiveIncomingCalls(twoWayChannelCount + didChannelCount);
					location.setMaxActiveOutgoingCalls(twoWayChannelCount + dodChannelCount);
					
					if (feature.getInstanceId() != null) {
						location.setPqInstanceId(Long.valueOf(feature.getInstanceId()));
					}
					if (feature.getActionCode() != null) {
						String entityAction = feature.getActionCode();
						if ("ADD".equalsIgnoreCase(entityAction)) {
							location.setAction(EsapEnum.OrderAction.ADD);
						} else if ("CHANGE".equalsIgnoreCase(entityAction)) {
							location.setAction(EsapEnum.OrderAction.MODIFY);
						} else if ("DELETE".equalsIgnoreCase(entityAction)) {
							location.setAction(EsapEnum.OrderAction.DELETE);
						}
					}
					for (Specification specification : feature.getSpecification()) {
						if ("SP_VOIP_CALLER_ID_CONFIG".equalsIgnoreCase(specification.getCode())) {
							boolean overrideCidNum = "Yes".equalsIgnoreCase(specification.getValue()) ? true : false;
							location.setOverrideCidNum(overrideCidNum);
						}
						if ("SP_VOIP_BURSTABLE_EST".equalsIgnoreCase(specification.getCode())) {
							boolean locationCclIndicator = "Yes".equalsIgnoreCase(specification.getValue()) ? true
									: false;
							location.setLocationCclIndicator(locationCclIndicator);
						}
						if ("ESP_ENT_TRUNK_INST_ID".equalsIgnoreCase(specification.getCode())) {
							location.setEnterpriseTrunkId(new Long(specification.getValue()));
						}
						if ("ESP_DESIGN_ID".equalsIgnoreCase(specification.getCode())) {
							location.setDesignId(new Long(specification.getValue()));
						}
						if ("ESP_PORT_OUT_TYPE".equalsIgnoreCase(specification.getCode())) {
							location.setPortOutType(specification.getValue());
						}
						if ("SP_VOIP_LOC_LEVEL_CAC".equalsIgnoreCase(specification.getCode())) { // confirm
							location.setMaxConcurrentCalls(
									BigInteger.valueOf(Integer.parseInt(specification.getValue())));
						}
						if ("SP_EIS_CLIN_DESC".equalsIgnoreCase(specification.getCode())) {
							location.setClin(specification.getCode());
						}

						if ("ESP_DIALING_COUNTRY_CODE".equalsIgnoreCase(specification.getCode())) {
							location.setDialingCountryCode(specification.getValue());
						}
						if ("SP_VOIP_NUM_ENTER_LOC_CD".equalsIgnoreCase(specification.getCode())) {
							location.setAbbrDialingCode(specification.getValue());
						}
						if ("SP_VOIP_DO_YOU_WANT_VARRS".equalsIgnoreCase(specification.getCode())) {
							location.setVARRS(specification.getValueCode());
						}
						if ("SP_VOIP_TYPE_OF_EXPEDITE".equalsIgnoreCase(specification.getCode())) {
							boolean expedite = "Yes".equalsIgnoreCase(specification.getValue()) ? true : false;
							location.setExpedite(expedite);
						}

						if ("SP_VOIP_WEB_LANGUAGE".equalsIgnoreCase(specification.getCode())) {
							location.setWebLanguage(specification.getValue());
						}
						if ("SP_VOIP_VOICE_MAIL_LANG".equalsIgnoreCase(specification.getCode())) {
							location.setVmLanguage(specification.getValue());
						}
						if ("SP_VOIP_USG_PLAN".equalsIgnoreCase(specification.getCode())) {
							location.setBillingType(specification.getValue());
						}
						if ("SP_VOIP_MAX_CONC_OFF_LOC_CALL".equalsIgnoreCase(specification.getCode())) {// confirm
							location.setMaxConcurrentCalls(new BigInteger(specification.getValue()));
						}
						if ("SP_VOIP_NUM_CONC_CALL".equalsIgnoreCase(specification.getCode())) {
							location.setMaxConcurrentOffNet(new BigInteger(specification.getValue()));
						}
						if ("SP_VOIP_SERVICE_PLAN".equalsIgnoreCase(specification.getCode())) {
							location.setServiceLevel(specification.getValue());
						}
						if ("SP_VOIP_VIPER".equalsIgnoreCase(specification.getCode())) {
							location.setAdvantageClub(specification.getValue());
						}
						if ("SP_VOIP_TOT_QTY_TEL_QUOTED".equalsIgnoreCase(specification.getCode())) {
							location.setTotalPublicNumbers(new BigInteger(specification.getValue()));
						}
						if ("ESP_CALLER_ID_NUMBER".equalsIgnoreCase(specification.getCode())) {
							location.setCallingPartyNumber(specification.getValue());
						}
						if ("SP_VOIP_NUM_HOST_EXT_DIAL_DGT".equalsIgnoreCase(specification.getCode())) {
							location.setExtensionLength(new BigInteger(specification.getValue()));
						}
						if ("SP_VOIP_LINE_PORT_LENGTH".equalsIgnoreCase(specification.getCode())) {
							location.setLinePortLength(new Integer(specification.getValue()));
						}

						if ("SP_VOIP_SERVICE_TYPE".equalsIgnoreCase(specification.getCode())) {
							location.setVoipServiceType(specification.getValue());
						}else {							
							if(voipOrderRequest.getOrderHeader().getSolutionType() != null) {								
								if(SolutionType.ESIP_ESL.equals(voipOrderRequest.getOrderHeader().getSolutionType())) {
									location.setVoipServiceType(VoipServiceType.ENTERPRISE_SIP.getValue());
									location.setLocationType(LocationType.ESIP_ESL.getIndex());
									location.setTypeOfLoc(TypeOfLocEnum.ESIP_ESL);
								}									
								else if(SolutionType.ESIP_EBL.equals(voipOrderRequest.getOrderHeader().getSolutionType())) {
									location.setVoipServiceType(VoipServiceType.ENTERPRISE_SIP.getValue());
									location.setLocationType(LocationType.ESIP_EBL.getIndex());
									location.setTypeOfLoc(TypeOfLocEnum.ESIP_EBL);
								}
								else if(SolutionType.IPFLEX.equals(voipOrderRequest.getOrderHeader().getSolutionType())) {
									location.setVoipServiceType(VoipServiceType.IP_FLEX.getValue());
									location.setLocationType(LocationType.IPFLEX.getIndex());
									location.setTypeOfLoc(TypeOfLocEnum.FLEX);
								}else if(SolutionType.HPBX.equals(voipOrderRequest.getOrderHeader().getSolutionType())) {
									location.setVoipServiceType(VoipServiceType.HOSTED_PBX.getValue());
									
									if("FET_HPBX_LOC_LVL_LOC".equalsIgnoreCase(feature.getCode())) {
										location.setTypeOfLoc(TypeOfLocEnum.HPBX_ECH);
										location.setLocationType(LocationType.HPBX_ECH.getIndex());
										
									}else if("FET_HPBX_LOC_LVL".equalsIgnoreCase(feature.getCode())) {
										location.setTypeOfLoc(TypeOfLocEnum.HPBX_EBL);
										location.setLocationType(LocationType.HPBX_EBL.getIndex());
										
									}
								}									
							}
						}
						if ("ESP_EMERGENCY_CALLING_LINE".equalsIgnoreCase(specification.getCode())) {
							location.setEmergencyCallLine(specification.getValue());
						}

						if ("ESP_HUB_SVC_INSTANCE_ID".equalsIgnoreCase(specification.getCode())) {
							location.setHubLocationId(specification.getValue());
						} else if ("SP_XO_ESL".equalsIgnoreCase(specification.getCode())) {
							location.setHubLocationId(specification.getValue());
							
							Map<String, String> entMap = orderServiceHelperImpl.getEnterpriseFromEsl(specification.getValue());
							location.setSipDomain(entMap.get("SIP_DOMAIN"));
							LOG.info("SIP Domain of ESL was :{}", location.getSipDomain());
						}
						if ("ESP_LOCATION_SCREENED_TN".equalsIgnoreCase(specification.getCode())) {
							location.setsTn(specification.getValue());
						}
						if ("SP_VOIP_ALTERNATE_CALLER_ID".equalsIgnoreCase(specification.getCode())) {
							boolean enhancedANIInd = "Yes".equalsIgnoreCase(specification.getValue()) ? true : false;
							location.setEnhancedANIInd(enhancedANIInd);
						}
						if ("SP_VOIP_CALLER_ID_NAME_INBND".equalsIgnoreCase(specification.getCode())) {
							boolean callingNameInd = "Yes".equalsIgnoreCase(specification.getValue()) ? true : false;
							location.setCallingNameInd(callingNameInd);
						}
						/*if ("ESP_VOIP_LOCATION_NAME".equalsIgnoreCase(specification.getCode())) {
							location.setName(specification.getValue());
						} else {
							location.setName(feature.getInstanceId());
						}*/
						if(locationName != null) {
							location.setName(locationName);
						} else {
							location.setName(feature.getInstanceId());
						}
						
						if ("SP_VOIP_CALLER_ID_CONFIG".equalsIgnoreCase(specification.getCode())) {
							location.setCallingPartyPrivacy(specification.getValue());
						}
						if ("SP_XO_TNQ".equalsIgnoreCase(specification.getCode())) {
							location.setTnQuantity(Long.valueOf(specification.getValue()));
						}
						if ("SP_XO_RED".equalsIgnoreCase(specification.getCode())) {

							RedundancyType redundancy = null;
							if ("PRIORITY".equalsIgnoreCase(specification.getValue()))
								redundancy = RedundancyType.PRIORITY;
							if ("Load Sharing".equalsIgnoreCase(specification.getValue()))
								redundancy = RedundancyType.LOADSHARING;
							if ("NONE".equalsIgnoreCase(specification.getValue()))
								redundancy = RedundancyType.NONE;

							location.setRedundancy(redundancy);
						}
						if ("SP_XO_REDID".equalsIgnoreCase(specification.getCode())) {
							location.setRedundancyId(specification.getValue());
						}
						if ("SP_XO_REDPT".equalsIgnoreCase(specification.getCode())) {

							RedundancyPriorityType redundancyPriority = null;
							if ("PRIMARY".equalsIgnoreCase(specification.getValue()))
								redundancyPriority = RedundancyPriorityType.PRIMARY;
							if ("SECONDARY".equalsIgnoreCase(specification.getValue()))
								redundancyPriority = RedundancyPriorityType.SECONDARY;

							location.setRedundancyPriorityType(redundancyPriority);
						}
						if ("SP_XO_RED".equalsIgnoreCase(specification.getCode())) {
							location.setEslId(convergedService.getID());
							location.setTypeOfLoc(TypeOfLocEnum.ESIP_ESL);

						}
						if ("SP_XO_ESL".equalsIgnoreCase(specification.getCode())) {
							location.setTypeOfLoc(TypeOfLocEnum.ESIP_EBL);
							location.setEslId(specification.getValue());
							location.setCustomerId(orderServiceHelperImpl
									.getEnterpriseInformationFromEsl(specification.getValue()));
						}
						if ("SP_XO_BW_PORT_NUM".equalsIgnoreCase(specification.getCode())) {
							location.setBroadworksPortalNumber(specification.getValue());
						}
						if ("SP_XO_GRO".equalsIgnoreCase(specification.getCode())) {
							location.setBillingTN(Long.valueOf(specification.getValue()));
						}else if(!CollectionUtils.isEmpty(btnSpec)) {
							location.setBillingTN(Long.valueOf(btnSpec.get(0).getValue()));
						}
						/*if ("SP_XO_BW_LOC_ID".equalsIgnoreCase(specification.getCode())) {
							location.setBwLocationId(specification.getValue());
						}*/
						if ("SP_HPBX_PREBUILD_LOC_ID".equalsIgnoreCase(specification.getCode())
								&& TypeOfLocEnum.HPBX_ECH.equals(location.getTypeOfLoc())) {
							location.setPreBuildLocId(specification.getValue());

							LOG.info("HPBX Prebuild Location Id = {}", specification.getValue());
						}							
					}
					

					//Start :Session Fix 
					trunkFeatList = stream(voipOrderRequest.getConvergedService().getFeature())
							.filter(truFeat -> "FET_XO_TRU".equalsIgnoreCase(truFeat.getCode())).collect(Collectors.toList());

					
					if (!CollectionUtils.isEmpty(trunkFeatList)) {
						session = new Session();
						
						for (Feature trunkFeat : trunkFeatList) {
							
							trunkSessionCountSpec = stream(trunkFeat.getSpecification())
									.filter(spec -> "SP_TRK".equalsIgnoreCase(spec.getCode())).collect(Collectors.toList());
							
							if (!CollectionUtils.isEmpty(trunkSessionCountSpec)) {
								sessionCount = sessionCount + Integer.parseInt(trunkSessionCountSpec.get(0).getValue());
							}
							
						}
						
						LOG.info("Session Total Count ={} ", sessionCount);

						location.setGroupUserLimit(String.valueOf(sessionCount));
						session.setQuantity(sessionCount);
						
						location.setSession(session);
						
						//Start: Time Zone Fix
						
						//Time Zone :
						if (voipOrderRequest.getAdditionalInfo() != null
								&& voipOrderRequest.getAdditionalInfo().getTimeZone() != null) {
							String timeZone = inventoryUtil.getTimeZoneId(voipOrderRequest.getAdditionalInfo().getTimeZone());					
							
							location.setTimeZone(timeZone != null? timeZone : "26");
							
						}else {
							location.setTimeZone("26");
						}
						
						LOG.info("Time Zone is {}", location.getTimeZone());
						
						
						//Day Light Saving :
						
						if (voipOrderRequest.getAdditionalInfo() != null
								&& voipOrderRequest.getAdditionalInfo().getDayLightSavingsInd() != null) {
							
							location.setDaylightSavingInd(voipOrderRequest.getAdditionalInfo().getDayLightSavingsInd());
							
						}else {
							location.setDaylightSavingInd("N");
						}
						
						LOG.info("Day Light Saving Indicator is {}", location.getDaylightSavingInd());
						
						//End: Time Zone Fix
					}
					//End :Session Fix 
					
					if (voipOrderRequest.getLocation() != null
							&& voipOrderRequest.getLocation().getPrimaryLocationContact() != null
							&& voipOrderRequest.getLocation().getPrimaryLocationContact().getCommunication() != null) {

						if (voipOrderRequest.getLocation().getPrimaryLocationContact().getCommunication().length > 0) {
							Communication[] communication = voipOrderRequest.getLocation().getPrimaryLocationContact()
									.getCommunication();
							for (Communication comm : communication) {
								if ("Phone".equalsIgnoreCase(comm.getChannel())) {
									location.setDialingCountryCode(comm.getCountryDialing());
									break;
								}
							}
						}
					}
					
					
					locations.add(location);
				}
			}
			

			//TODO : Implement for MAC HPBX
			if ("C".equalsIgnoreCase(voipOrderRequest.getOrderHeader().getOrderType())) {

				LocationEntity changeLocation = parseLocationChangeOrder(voipOrderRequest);
				location.setLocationEntity(changeLocation);
			}
			
		} catch (Exception e) {
			LOG.error("Exception {}", e.getMessage());
			throw new TranslatorException(TranslatorException.ErrorCode.ORDER_NOT_SAVABLE,
					"Unexpected Error Occur while parseLocationOrders");
		}
		LOG.info("Exited - parseLocationOrders");
		return locations;
	}

}
