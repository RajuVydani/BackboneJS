package com.vz.esap.translation.app;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author Niladri Chattaraj
 *
 */

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.context.annotation.ComponentScan;

//@EnableDiscoveryClient
@SpringBootApplication
@ComponentScan({ "com.vz.esap", "com.vz.esap.translation" })
public class TranslationServiceApplication {

	private static final Logger LOG = LoggerFactory.getLogger(TranslationServiceApplication.class);

	public static void main(String[] args) {
		SpringApplication.run(TranslationServiceApplication.class, args);
		System.out.println("Boot Complete !!!");
	}

}