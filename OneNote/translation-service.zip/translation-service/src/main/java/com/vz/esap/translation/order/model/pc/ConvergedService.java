package com.vz.esap.translation.order.model.pc;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;

import com.fasterxml.jackson.annotation.JsonProperty;

@XmlAccessorType(XmlAccessType.FIELD)
public class ConvergedService {
	
	@XmlElement(name = "Name")
	@JsonProperty(value = "Name")
	private String name;

	@XmlElement(name = "CatalogVersionTime")
	@JsonProperty(value = "CatalogVersionTime")
	private String catalogVersionTime;

	@XmlElement(name = "Type")
	@JsonProperty(value = "Type")
	private String type;

	@XmlElement(name = "ID")
	@JsonProperty(value = "ID")
	private String id;

	@XmlElement(name = "Specification")
	@JsonProperty(value = "Specification")
	private Specification[] specification;

	@XmlElement(name = "Feature")
	@JsonProperty(value = "Feature")
	private Feature[] feature;

	public String getName() {
		return name;
	}

	public void setName(String Name) {
		this.name = Name;
	}

	public String getCatalogVersionTime() {
		return catalogVersionTime;
	}

	public void setCatalogVersionTime(String CatalogVersionTime) {
		this.catalogVersionTime = CatalogVersionTime;
	}

	public String getType() {
		return type;
	}

	public void setType(String Type) {
		this.type = Type;
	}

	public String getID() {
		return id;
	}

	public void setID(String ID) {
		this.id = ID;
	}

	public Specification[] getSpecification() {
		return specification;
	}

	public void setSpecification(Specification[] Specification) {
		this.specification = Specification;
	}

	public Feature[] getFeature() {
		return feature;
	}

	public void setFeature(Feature[] Feature) {
		this.feature = Feature;
	}

	@Override
	public String toString() {
		return "ClassPojo [Name = " + name + ", CatalogVersionTime = " + catalogVersionTime + ", Type = " + type
				+ ", ID = " + id + ", Specification = " + specification + ", Feature = " + feature + "]";
	}
}
