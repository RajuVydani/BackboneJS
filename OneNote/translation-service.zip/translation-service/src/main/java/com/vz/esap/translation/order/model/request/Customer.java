package com.vz.esap.translation.order.model.request;

public class Customer {

	private String Name;

	public String getName() {
		return Name;
	}

	public void setName(String Name) {
		this.Name = Name;
	}

}