package com.vz.esap.translation.order.log;

import java.io.IOException;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpRequest;
import org.springframework.http.client.ClientHttpRequestExecution;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.ClientHttpResponse;

import com.vz.esap.translation.enums.RequestHeaders;

public class LoggingRestTemplateInterceptor implements ClientHttpRequestInterceptor {

	private static final Logger LOG = LoggerFactory.getLogger(LoggingRestTemplateInterceptor.class);

	@Override
	public ClientHttpResponse intercept(final HttpRequest request, final byte[] body,
			final ClientHttpRequestExecution execution) throws IOException {
		logRequest(request, body);
		ClientHttpResponse response = execution.execute(request, body);

		logResponse(response);

		return response;
	}

	/**
	 * Log request attributes of rest template
	 * 
	 * @param request
	 * @param body
	 */
	private void logRequest(final HttpRequest request, final byte[] body) {
		LOG.debug("Method: " + request.getMethod().toString());
		LOG.info("External System URI: " + request.getURI().toString());
		LOG.debug("Request Body: " + new String(body));
		logHeader(request.getHeaders());

	}

	private void logResponse(final ClientHttpResponse response) {
		try {
			LOG.debug("StatusCode :" + response.getRawStatusCode());
			LOG.debug("Status Text :" + response.getStatusText());
			HttpHeaders responseHeaders = response.getHeaders();
			LOG.debug("Headers :" + responseHeaders);
			LOG.debug("Response Body :" + response.getBody());
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}

	/**
	 * @param request
	 */
	private void logHeader(HttpHeaders headers) {
		StringBuilder headerLog = new StringBuilder();
		List<String> headerParams;
		for (String reqHeaderName : RequestHeaders.headerNames()) {
			headerParams = headers.get(reqHeaderName);
			headerLog.append("#").append(RequestHeaders.getHeaderDescription(reqHeaderName)).append(": ")
					.append(headerParams == null ? " " : headerParams.get(0)).append(" ");
		}
		LOG.debug("Header details sent to external system: " + headerLog.toString());
	}
}