package com.vz.esap.translation.service;

import com.vz.esap.translation.exception.GenericException;
import com.vz.esap.translation.exception.TranslatorException;
import com.vz.esap.translation.order.model.request.VOIPOrderRequest;
import com.vz.esap.translation.order.model.response.VoipOrderResponse;

public interface OrderRouter {

	/**
	 * @param voipOrderRequest
	 * @return voipOrderResponse
	 * @throws TranslatorException 
	 * @throws GenericException 
	 * @throws Exception
	 */
	VoipOrderResponse routeOrder(VOIPOrderRequest voipOrderRequest) throws TranslatorException, GenericException;

}
