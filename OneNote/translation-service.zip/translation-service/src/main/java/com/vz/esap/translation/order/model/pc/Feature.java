package com.vz.esap.translation.order.model.pc;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;

import com.fasterxml.jackson.annotation.JsonProperty;

@XmlAccessorType(XmlAccessType.FIELD)
public class Feature {
	
	@XmlElement(name = "Name")
	@JsonProperty(value = "Name")
	private String name;

	@XmlElement(name = "ActionCode")
	@JsonProperty(value = "ActionCode")
	private String actionCode;

	@XmlElement(name = "InstanceId")
	@JsonProperty(value = "InstanceId")
	private String instanceId;

	@XmlElement(name = "Specification")
	@JsonProperty(value = "Specification")
	private Specification[] specification;

	@XmlElement(name = "Code")
	@JsonProperty(value = "Code")
	private String code;

	public String getName() {
		return name;
	}

	public void setName(String Name) {
		this.name = Name;
	}

	public String getActionCode() {
		return actionCode;
	}

	public void setActionCode(String ActionCode) {
		this.actionCode = ActionCode;
	}

	public String getInstanceId() {
		return instanceId;
	}

	public void setInstanceId(String InstanceId) {
		this.instanceId = InstanceId;
	}

	public Specification[] getSpecification() {
		return specification;
	}

	public void setSpecification(Specification[] Specification) {
		this.specification = Specification;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String Code) {
		this.code = Code;
	}

	@Override
	public String toString() {
		return "ClassPojo [Name = " + name + ", ActionCode = " + actionCode + ", InstanceId = " + instanceId
				+ ", Specification = " + specification + ", Code = " + code + "]";
	}
}
