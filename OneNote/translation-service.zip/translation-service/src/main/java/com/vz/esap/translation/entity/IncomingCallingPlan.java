package com.vz.esap.translation.entity;

public class IncomingCallingPlan {
    private String intraLocation;
    private String interLocation;
    private String collectCalls;
    public String getIntraLocation() {
        return intraLocation;
    }
    public void setIntraLocation(String intraLocation) {
        this.intraLocation = intraLocation;
    }
    public String getInterLocation() {
        return interLocation;
    }
    public void setInterLocation(String interLocation) {
        this.interLocation = interLocation;
    }
    public String getCollectCalls() {
        return collectCalls;
    }
    public void setCollectCalls(String collectCalls) {
        this.collectCalls = collectCalls;
    }
    
}
