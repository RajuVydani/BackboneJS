package com.vz.esap.translation.order.service;

import java.util.Map;
import java.util.Set;

import com.vz.esap.translation.enums.EsapEnum.StatusCode;
import com.vz.esap.translation.exception.GenericException;
import com.vz.esap.translation.order.model.request.VOIPOrderRequest;
import com.vz.esap.translation.order.model.response.VoipOrderResponse;

public interface VOIPResponseGenerator {

	/**
	 * @param errorString
	 * @param voipOrderRequest
	 * @return response
	 * @throws GenericException 
	 */
	VoipOrderResponse prepareFailureOrderResponse(String errorString, VOIPOrderRequest voipOrderRequest) throws GenericException;

	/**
	 * @param errorMessage
	 * @param entityType
	 * @param voipOrderRequest
	 * @return response
	 * @throws GenericException 
	 */
	VoipOrderResponse prepareFailureOrderResponse(Set<String> errorMessage, String entityType,
			VOIPOrderRequest voipOrderRequest) throws GenericException;

	/**
	 * @param voipOrderRequest
	 * @return voipOrderResponse
	 * @throws GenericException 
	 */
	VoipOrderResponse prepareSuccessOrderResponse(VOIPOrderRequest voipOrderRequest) throws GenericException;



	/**
	 * @param voipOrderRequest
	 * @param milestone
	 * @param statusCode
	 * @param responseType TODO
	 * @return VoipOrderResponse
	 * @throws GenericException
	 */
	VoipOrderResponse preparePCMilestone(VOIPOrderRequest voipOrderRequest, String milestone,
			StatusCode statusCode, String responseType) throws GenericException;

	/**
	 * @param voipOrderRequest
	 * @param milestone
	 * @param statusCode
	 * @param responseType
	 * @param paramNameValue
	 * @return
	 * @throws GenericException
	 */
	VoipOrderResponse preparePCMilestone(VOIPOrderRequest voipOrderRequest, String milestone, StatusCode statusCode,
			String responseType, Map<String, String> paramNameValue) throws GenericException;

}
