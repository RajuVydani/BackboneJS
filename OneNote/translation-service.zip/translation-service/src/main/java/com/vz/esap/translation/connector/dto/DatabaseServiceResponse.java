
package com.vz.esap.translation.connector.dto;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "queryId", "tableName", "dbOperation", "status", "statusDesc", "rows", "columnMetaData",
		"rowDataList", "numberOfRecords" })
public class DatabaseServiceResponse {

	@JsonProperty("queryId")
	private Object queryId;

	@JsonProperty("tableName")
	private String tableName;

	@JsonProperty("dbOperation")
	private String dbOperation;

	@JsonProperty("status")
	private String status;

	@JsonProperty("statusDesc")
	private String statusDesc;

	@JsonProperty("rows")
	private Object rows;

	@JsonProperty("columnMetaData")
	private ColumnMetaData columnMetaData;

	@JsonProperty("rowDataList")
	private List<RowDataList> rowDataList = new ArrayList<RowDataList>();

	@JsonProperty("numberOfRecords")
	private Long numberOfRecords;

	@JsonIgnore
	private Map<String, Object> additionalProperties = new HashMap<String, Object>();

	@JsonProperty("queryId")
	public Object getQueryId() {
		return queryId;
	}

	@JsonProperty("queryId")
	public void setQueryId(Object queryId) {
		this.queryId = queryId;
	}

	@JsonProperty("tableName")
	public String getTableName() {
		return tableName;
	}

	@JsonProperty("tableName")
	public void setTableName(String tableName) {
		this.tableName = tableName;
	}

	@JsonProperty("dbOperation")
	public String getDbOperation() {
		return dbOperation;
	}

	@JsonProperty("dbOperation")
	public void setDbOperation(String dbOperation) {
		this.dbOperation = dbOperation;
	}

	@JsonProperty("status")
	public String getStatus() {
		return status;
	}

	@JsonProperty("status")
	public void setStatus(String status) {
		this.status = status;
	}

	@JsonProperty("statusDesc")
	public String getStatusDesc() {
		return statusDesc;
	}

	@JsonProperty("statusDesc")
	public void setStatusDesc(String statusDesc) {
		this.statusDesc = statusDesc;
	}

	@JsonProperty("rows")
	public Object getRows() {
		return rows;
	}

	@JsonProperty("rows")
	public void setRows(Object rows) {
		this.rows = rows;
	}

	@JsonProperty("columnMetaData")
	public ColumnMetaData getColumnMetaData() {
		return columnMetaData;
	}

	@JsonProperty("columnMetaData")
	public void setColumnMetaData(ColumnMetaData columnMetaData) {
		this.columnMetaData = columnMetaData;
	}

	@JsonProperty("rowDataList")
	public List<RowDataList> getRowDataList() {
		return rowDataList;
	}

	@JsonProperty("rowDataList")
	public void setRowDataList(List<RowDataList> rowDataList) {
		this.rowDataList = rowDataList;
	}

	@JsonProperty("numberOfRecords")
	public Long getNumberOfRecords() {
		return numberOfRecords;
	}

	@JsonProperty("numberOfRecords")
	public void setNumberOfRecords(Long numberOfRecords) {
		this.numberOfRecords = numberOfRecords;
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}

	@JsonAnyGetter
	public Map<String, Object> getAdditionalProperties() {
		return this.additionalProperties;
	}

	@JsonAnySetter
	public void setAdditionalProperty(String name, Object value) {
		this.additionalProperties.put(name, value);
	}

	@Override
	public int hashCode() {
		return new HashCodeBuilder().append(queryId).append(tableName).append(dbOperation).append(status)
				.append(statusDesc).append(rows).append(columnMetaData).append(rowDataList).append(numberOfRecords)
				.append(additionalProperties).toHashCode();
	}

	@Override
	public boolean equals(Object other) {
		if (other == this) {
			return true;
		}
		if ((other instanceof DatabaseServiceResponse) == false) {
			return false;
		}
		DatabaseServiceResponse rhs = ((DatabaseServiceResponse) other);
		return new EqualsBuilder().append(queryId, rhs.queryId).append(tableName, rhs.tableName)
				.append(dbOperation, rhs.dbOperation).append(status, rhs.status).append(statusDesc, rhs.statusDesc)
				.append(rows, rhs.rows).append(columnMetaData, rhs.columnMetaData).append(rowDataList, rhs.rowDataList)
				.append(numberOfRecords, rhs.numberOfRecords).append(additionalProperties, rhs.additionalProperties)
				.isEquals();
	}

}
