package com.vz.esap.translation.connector.util;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.vz.esap.translation.connector.dto.ColumnMetaData;
import com.vz.esap.translation.connector.dto.ColumnMetaData_;
import com.vz.esap.translation.connector.dto.DBOperationResponse;
import com.vz.esap.translation.connector.dto.DatabaseServiceResponse;
import com.vz.esap.translation.connector.dto.RowDataList;
import com.vz.esap.translation.connector.dto.RowDataList_;
import com.vz.esap.translation.connector.model.DBServiceResponse;
import com.vz.esap.translation.connector.model.TblCell;
import com.vz.esap.translation.connector.model.TblRow;
import com.vz.esap.translation.exception.TranslatorException;
import com.vz.esap.translation.exception.TranslatorException.ErrorCode;

import ma.glasnost.orika.MapperFactory;
import ma.glasnost.orika.impl.DefaultMapperFactory;

@Component
public class DomainInterfaceUtil {
	private static final Logger LOG = LoggerFactory.getLogger(DomainInterfaceUtil.class);
	static final MapperFactory MAPPER_FACTORY = new DefaultMapperFactory.Builder().build();

	/**
	 * @param dbServiceResponse
	 * @return responseData
	 * @throws TranslatorException
	 */
	public DBServiceResponse convertDBResponseToTblData(DatabaseServiceResponse dbServiceResponse)
			throws TranslatorException {

		DBServiceResponse responseData = new DBServiceResponse();
		ColumnMetaData columnMetaDataResponse = dbServiceResponse.getColumnMetaData();

		LOG.debug("columnMetaDataResponse{} ", columnMetaDataResponse);

		if (columnMetaDataResponse == null) {
			throw new TranslatorException(ErrorCode.COLUMN_METADATA_MISSING, "Column Metadata Missing");
		}

		List<String> columnNameList = columnMetaDataResponse.getColumnName();
		List<String> columnTypeList = columnMetaDataResponse.getDataType();

		List<RowDataList> rowDataListResponse = dbServiceResponse.getRowDataList();
		LOG.info("rowDataListResponse Size: {} ", rowDataListResponse.size());

		List<TblRow> tblRowList = new ArrayList<>();
		TblRow tblRow = null;
		Map<String, TblCell> rowData = null;

		for (RowDataList rowDataList : rowDataListResponse) {
			rowData = new TreeMap<>(String.CASE_INSENSITIVE_ORDER);
			tblRow = new TblRow();
			
			List<String> columnValuesResponse = rowDataList.getColumnValues();
			
			for (int i = 0; i < columnValuesResponse.size(); i++) {
				String columnValue = columnValuesResponse.get(i);
				TblCell tblCellData = new TblCell();
				tblCellData.setName(columnNameList.get(i));
				tblCellData.setValue(columnValue);
				tblCellData.setDataType(columnTypeList.get(i));
				rowData.put(columnNameList.get(i).toUpperCase(), tblCellData);
			}
			tblRow.setTblRow(rowData);
			tblRowList.add(tblRow);
		}
		LOG.info("Row Size: {} ", tblRowList.size());
		responseData.setTableRows(tblRowList);
		responseData.setNumberOfRecords(dbServiceResponse.getNumberOfRecords());
		responseData.setTableName(dbServiceResponse.getTableName());
		LOG.info("Number of record: {} ", dbServiceResponse.getNumberOfRecords());
		return responseData;

	}
	
	
	/**
	 * @param dbOperationResponse
	 * @return
	 */
	public DBServiceResponse convertDBResponseToTblData(DBOperationResponse dbOperationResponse) {

		DBServiceResponse responseData = new DBServiceResponse();
		responseData.setNumberOfRecords(dbOperationResponse.getNumberOfRecords());
		responseData.setQueryReferenceId(dbOperationResponse.getQueryReferenceId());
		responseData.setDbOperation(dbOperationResponse.getDbOperation());
		responseData.setTableName(dbOperationResponse.getTableName());

		ColumnMetaData_ columnMetaDataResponse = dbOperationResponse.getColumnMetaData();

		LOG.info("columnMetaDataResponse {}", columnMetaDataResponse);

		if (columnMetaDataResponse != null) {
			List<String> columnNameList = columnMetaDataResponse.getColumnName();
			List<String> columnTypeList = columnMetaDataResponse.getDataType();

			List<RowDataList_> rowDataListResponse = dbOperationResponse.getRowDataList();
			LOG.info("rowDataListResponse Size: {}", rowDataListResponse.size());

			List<TblRow> tblRowList = new ArrayList<>();
			for (RowDataList_ rowDataList : rowDataListResponse) {
				TblRow tblRow = new TblRow();
				Map<String, TblCell> rowData = new TreeMap<>(String.CASE_INSENSITIVE_ORDER);
				List<String> columnValuesResponse = rowDataList.getColumnValues();
				for (int i = 0; i < columnValuesResponse.size(); i++) {
					String columnValue = columnValuesResponse.get(i);
					TblCell tblCellData = new TblCell();
					tblCellData.setName(columnNameList.get(i));
					tblCellData.setValue(columnValue);
					tblCellData.setDataType(columnTypeList.get(i));
					rowData.put(columnNameList.get(i), tblCellData);
				}
				tblRow.setTblRow(rowData);
				tblRowList.add(tblRow);
			}
			LOG.info("Row Size: {}", tblRowList.size());
			responseData.setTableRows(tblRowList);
		} else {
			List<TblRow> tblRowList = new ArrayList<>();
			responseData.setTableRows(tblRowList);
		}
		return responseData;

	}

}
