/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.vz.esap.translation.entity;

import EsapEnumPkg.VzbVoipEnum.AcctAuthCodeType;

public class AccountAuthCode {

	public AccountAuthCode() {

	}

	public static enum CodeType {
		ACCT_CODE(AcctAuthCodeType.ACCT_CODE), AUTH_CODE(AcctAuthCodeType.AUTH_CODE);

		private int cType;

		CodeType(int cType) {
			this.cType = cType;
		}

		public int getEsapEnum() {

			return cType;

		}

		public static CodeType valueOf(int codeType) {

			CodeType cType = null;
			for (CodeType c : CodeType.values()) {

				if (c.getEsapEnum() == codeType) {
					cType = c;
				}
			}
			return cType;
		}

	};

	private String code;
	private String description;
	private CodeType codeType;

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;

	}

	public CodeType getCodeType() {
		return codeType;
	}

	public void setCodeType(CodeType codeType) {
		this.codeType = codeType;
	}

}
