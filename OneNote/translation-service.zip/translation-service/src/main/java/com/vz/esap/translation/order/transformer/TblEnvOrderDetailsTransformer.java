package com.vz.esap.translation.order.transformer;

import com.vz.esap.translation.dao.model.TblEnvOrderDetails;

//@Component
public interface TblEnvOrderDetailsTransformer {

	/**
	 * @param envOrderId
	 * @param dataType
	 * @param seqNo
	 * @param paramType
	 * @param action
	 * @param paramName
	 * @param paramValue
	 * @param parentId
	 * @param flowStatus
	 * @param leaf
	 * @return tblEnvOrderDetails
	 */
	TblEnvOrderDetails prepareTblEnvOrderDetails(long envOrderId, String dataType, long seqNo, String paramType,
			String action, String paramName, String paramValue, long parentId, long flowStatus, long leaf);

}
