package com.vz.esap.translation.order.model.request;

public class AccessInfo {

	private String EBIId;

	private String AccessType;

	private String PVCServiceInstanceId;

	public String getEBIId() {
		return EBIId;
	}

	public void setEBIId(String EBIId) {
		this.EBIId = EBIId;
	}

	public String getAccessType() {
		return AccessType;
	}

	public void setAccessType(String AccessType) {
		this.AccessType = AccessType;
	}

	public String getPVCServiceInstanceId() {
		return PVCServiceInstanceId;
	}

	public void setPVCServiceInstanceId(String PVCServiceInstanceId) {
		this.PVCServiceInstanceId = PVCServiceInstanceId;
	}

	public String toString() {
		return "ClassPojo [EBIId = " + EBIId + ", AccessType = " + AccessType + ", PVCServiceInstanceId = "
				+ PVCServiceInstanceId + "]";
	}
}
