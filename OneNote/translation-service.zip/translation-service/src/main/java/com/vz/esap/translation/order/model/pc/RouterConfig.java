package com.vz.esap.translation.order.model.pc;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;

import com.fasterxml.jackson.annotation.JsonProperty;

@XmlAccessorType(XmlAccessType.FIELD)
public class RouterConfig {

	@XmlElement(name = "M4VRRPPriority")
	@JsonProperty(value = "M4VRRPPriority")
	private String m4VRRPPriority;

	@XmlElement(name = "LogicalRouterName")
	@JsonProperty(value = "LogicalRouterName")
	private String logicalRouterName;

	@XmlElement(name = "CustSigGatewayIp")
	@JsonProperty(value = "CustSigGatewayIp")
	private String custSigGatewayIp;

	@XmlElement(name = "NniCircuitIdM4")
	@JsonProperty(value = "NniCircuitIdM4")
	private String nniCircuitIdM4;

	@XmlElement(name = "NniCircuitIdM3")
	@JsonProperty(value = "NniCircuitIdM3")
	private String nniCircuitIdM3;

	@XmlElement(name = "MicroNodeIdentifier")
	@JsonProperty(value = "MicroNodeIdentifier")
	private String microNodeIdentifier;

	@XmlElement(name = "PvcVlanM3")
	@JsonProperty(value = "PvcVlanM3")
	private String pvcVlanM3;

	@XmlElement(name = "PvcVlanM4")
	@JsonProperty(value = "PvcVlanM4")
	private String pvcVlanM4;

	@XmlElement(name = "VpnName")
	@JsonProperty(value = "VpnName")
	private String vpnName;

	@XmlElement(name = "M3PhysicalCircuitID")
	@JsonProperty(value = "M3PhysicalCircuitID")
	private String m3PhysicalCircuitID;

	@XmlElement(name = "IpVersion")
	@JsonProperty(value = "IpVersion")
	private String ipVersion;

	@XmlElement(name = "M4InterfaceToNetwork")
	@JsonProperty(value = "M4InterfaceToNetwork")
	private String m4InterfaceToNetwork;

	@XmlElement(name = "PeerASnumber")
	@JsonProperty(value = "PeerASnumber")
	private String peerASnumber;

	@XmlElement(name = "M3InterfaceToSBC")
	@JsonProperty(value = "M3InterfaceToSBC")
	private String m3InterfaceToSBC;

	@XmlElement(name = "M4PhysicalCircuitID")
	@JsonProperty(value = "M4PhysicalCircuitID")
	private String m4PhysicalCircuitID;

	@XmlElement(name = "CustSigIrb")
	@JsonProperty(value = "CustSigIrb")
	private String custSigIrb;

	@XmlElement(name = "M3InterfaceToNetwork")
	@JsonProperty(value = "M3InterfaceToNetwork")
	private String m3InterfaceToNetwork;

	@XmlElement(name = "PvcCircuitM4")
	@JsonProperty(value = "PvcCircuitM4")
	private String pvcCircuitM4;

	@XmlElement(name = "PvcCircuitM3")
	@JsonProperty(value = "PvcCircuitM3")
	private String pvcCircuitM3;

	@XmlElement(name = "eBGPNumber")
	@JsonProperty(value = "eBGPNumber")
	private String eBGPNumber;

	@XmlElement(name = "CircuitType")
	@JsonProperty(value = "CircuitType")
	private String circuitType;

	@XmlElement(name = "M3VRRPPriority")
	@JsonProperty(value = "M3VRRPPriority")
	private String m3VRRPPriority;

	@XmlElement(name = "PeIpAddressM4")
	@JsonProperty(value = "PeIpAddressM4")
	private String peIpAddressM4;

	@XmlElement(name = "PeIpAddressM3")
	@JsonProperty(value = "PeIpAddressM3")
	private String peIpAddressM3;

	@XmlElement(name = "CeIpAddressM3")
	@JsonProperty(value = "CeIpAddressM3")
	private String ceIpAddressM3;

	@XmlElement(name = "VrrpGroup")
	@JsonProperty(value = "VrrpGroup")
	private String vrrpGroup;

	@XmlElement(name = "CeIpAddressM4")
	@JsonProperty(value = "CeIpAddressM4")
	private String ceIpAddressM4;

	@XmlElement(name = "M4InterfaceToSBC")
	@JsonProperty(value = "M4InterfaceToSBC")
	private String m4InterfaceToSBC;

	@XmlElement(name = "CustMedIrb")
	@JsonProperty(value = "CustMedIrb")
	private String custMedIrb;

	@XmlElement(name = "PvcDlciM3")
	@JsonProperty(value = "PvcDlciM3")
	private String pvcDlciM3;

	@XmlElement(name = "CustMedGatewayIp")
	@JsonProperty(value = "CustMedGatewayIp")
	private String custMedGatewayIp;

	@XmlElement(name = "PvcDlciM4")
	@JsonProperty(value = "PvcDlciM4")
	private String pvcDlciM4;

	public String getM4VRRPPriority() {
		return m4VRRPPriority;
	}

	public void setM4VRRPPriority(String m4vrrpPriority) {
		m4VRRPPriority = m4vrrpPriority;
	}

	public String getLogicalRouterName() {
		return logicalRouterName;
	}

	public void setLogicalRouterName(String logicalRouterName) {
		this.logicalRouterName = logicalRouterName;
	}

	public String getCustSigGatewayIp() {
		return custSigGatewayIp;
	}

	public void setCustSigGatewayIp(String custSigGatewayIp) {
		this.custSigGatewayIp = custSigGatewayIp;
	}

	public String getNniCircuitIdM4() {
		return nniCircuitIdM4;
	}

	public void setNniCircuitIdM4(String nniCircuitIdM4) {
		this.nniCircuitIdM4 = nniCircuitIdM4;
	}

	public String getNniCircuitIdM3() {
		return nniCircuitIdM3;
	}

	public void setNniCircuitIdM3(String nniCircuitIdM3) {
		this.nniCircuitIdM3 = nniCircuitIdM3;
	}

	public String getMicroNodeIdentifier() {
		return microNodeIdentifier;
	}

	public void setMicroNodeIdentifier(String microNodeIdentifier) {
		this.microNodeIdentifier = microNodeIdentifier;
	}

	public String getPvcVlanM3() {
		return pvcVlanM3;
	}

	public void setPvcVlanM3(String pvcVlanM3) {
		this.pvcVlanM3 = pvcVlanM3;
	}

	public String getPvcVlanM4() {
		return pvcVlanM4;
	}

	public void setPvcVlanM4(String pvcVlanM4) {
		this.pvcVlanM4 = pvcVlanM4;
	}

	public String getVpnName() {
		return vpnName;
	}

	public void setVpnName(String vpnName) {
		this.vpnName = vpnName;
	}

	public String getM3PhysicalCircuitID() {
		return m3PhysicalCircuitID;
	}

	public void setM3PhysicalCircuitID(String m3PhysicalCircuitID) {
		this.m3PhysicalCircuitID = m3PhysicalCircuitID;
	}

	public String getIpVersion() {
		return ipVersion;
	}

	public void setIpVersion(String ipVersion) {
		this.ipVersion = ipVersion;
	}

	public String getM4InterfaceToNetwork() {
		return m4InterfaceToNetwork;
	}

	public void setM4InterfaceToNetwork(String m4InterfaceToNetwork) {
		this.m4InterfaceToNetwork = m4InterfaceToNetwork;
	}

	public String getPeerASnumber() {
		return peerASnumber;
	}

	public void setPeerASnumber(String peerASnumber) {
		this.peerASnumber = peerASnumber;
	}

	public String getM3InterfaceToSBC() {
		return m3InterfaceToSBC;
	}

	public void setM3InterfaceToSBC(String m3InterfaceToSBC) {
		this.m3InterfaceToSBC = m3InterfaceToSBC;
	}

	public String getM4PhysicalCircuitID() {
		return m4PhysicalCircuitID;
	}

	public void setM4PhysicalCircuitID(String m4PhysicalCircuitID) {
		this.m4PhysicalCircuitID = m4PhysicalCircuitID;
	}

	public String getCustSigIrb() {
		return custSigIrb;
	}

	public void setCustSigIrb(String custSigIrb) {
		this.custSigIrb = custSigIrb;
	}

	public String getM3InterfaceToNetwork() {
		return m3InterfaceToNetwork;
	}

	public void setM3InterfaceToNetwork(String m3InterfaceToNetwork) {
		this.m3InterfaceToNetwork = m3InterfaceToNetwork;
	}

	public String getPvcCircuitM4() {
		return pvcCircuitM4;
	}

	public void setPvcCircuitM4(String pvcCircuitM4) {
		this.pvcCircuitM4 = pvcCircuitM4;
	}

	public String getPvcCircuitM3() {
		return pvcCircuitM3;
	}

	public void setPvcCircuitM3(String pvcCircuitM3) {
		this.pvcCircuitM3 = pvcCircuitM3;
	}

	public String geteBGPNumber() {
		return eBGPNumber;
	}

	public void seteBGPNumber(String eBGPNumber) {
		this.eBGPNumber = eBGPNumber;
	}

	public String getCircuitType() {
		return circuitType;
	}

	public void setCircuitType(String circuitType) {
		this.circuitType = circuitType;
	}

	public String getM3VRRPPriority() {
		return m3VRRPPriority;
	}

	public void setM3VRRPPriority(String m3vrrpPriority) {
		m3VRRPPriority = m3vrrpPriority;
	}

	public String getPeIpAddressM4() {
		return peIpAddressM4;
	}

	public void setPeIpAddressM4(String peIpAddressM4) {
		this.peIpAddressM4 = peIpAddressM4;
	}

	public String getPeIpAddressM3() {
		return peIpAddressM3;
	}

	public void setPeIpAddressM3(String peIpAddressM3) {
		this.peIpAddressM3 = peIpAddressM3;
	}

	public String getCeIpAddressM3() {
		return ceIpAddressM3;
	}

	public void setCeIpAddressM3(String ceIpAddressM3) {
		this.ceIpAddressM3 = ceIpAddressM3;
	}

	public String getVrrpGroup() {
		return vrrpGroup;
	}

	public void setVrrpGroup(String vrrpGroup) {
		this.vrrpGroup = vrrpGroup;
	}

	public String getCeIpAddressM4() {
		return ceIpAddressM4;
	}

	public void setCeIpAddressM4(String ceIpAddressM4) {
		this.ceIpAddressM4 = ceIpAddressM4;
	}

	public String getM4InterfaceToSBC() {
		return m4InterfaceToSBC;
	}

	public void setM4InterfaceToSBC(String m4InterfaceToSBC) {
		this.m4InterfaceToSBC = m4InterfaceToSBC;
	}

	public String getCustMedIrb() {
		return custMedIrb;
	}

	public void setCustMedIrb(String custMedIrb) {
		this.custMedIrb = custMedIrb;
	}

	public String getPvcDlciM3() {
		return pvcDlciM3;
	}

	public void setPvcDlciM3(String pvcDlciM3) {
		this.pvcDlciM3 = pvcDlciM3;
	}

	public String getCustMedGatewayIp() {
		return custMedGatewayIp;
	}

	public void setCustMedGatewayIp(String custMedGatewayIp) {
		this.custMedGatewayIp = custMedGatewayIp;
	}

	public String getPvcDlciM4() {
		return pvcDlciM4;
	}

	public void setPvcDlciM4(String pvcDlciM4) {
		this.pvcDlciM4 = pvcDlciM4;
	}

	/*
	 * @Override public String toString() { return "ClassPojo [m4VRRPPriority = " +
	 * m4VRRPPriority + ", logicalRouterName = " + logicalRouterName +
	 * ", CustSigGatewayIp = " + CustSigGatewayIp + ", NniCircuitIdM4 = " +
	 * NniCircuitIdM4 + ", NniCircuitIdM3 = " + NniCircuitIdM3 +
	 * ", MicroNodeIdentifier = " + MicroNodeIdentifier + ", PvcVlanM3 = " +
	 * PvcVlanM3 + ", PvcVlanM4 = " + PvcVlanM4 + ", VpnName = " + VpnName +
	 * ", M3PhysicalCircuitID = " + M3PhysicalCircuitID + ", IpVersion = " +
	 * IpVersion + ", M4InterfaceToNetwork = " + M4InterfaceToNetwork +
	 * ", PeerASnumber = " + PeerASnumber + ", M3InterfaceToSBC = " +
	 * M3InterfaceToSBC + ", M4PhysicalCircuitID = " + M4PhysicalCircuitID +
	 * ", CustSigIrb = " + CustSigIrb + ", M3InterfaceToNetwork = " +
	 * M3InterfaceToNetwork + ", PvcCircuitM4 = " + PvcCircuitM4 +
	 * ", PvcCircuitM3 = " + PvcCircuitM3 + ", eBGPNumber = " + eBGPNumber +
	 * ", CircuitType = " + CircuitType + ", M3VRRPPriority = " + M3VRRPPriority +
	 * ", PeIpAddressM4 = " + PeIpAddressM4 + ", PeIpAddressM3 = " + PeIpAddressM3 +
	 * ", CeIpAddressM3 = " + CeIpAddressM3 + ", VrrpGroup = " + VrrpGroup +
	 * ", CeIpAddressM4 = " + CeIpAddressM4 + ", M4InterfaceToSBC = " +
	 * M4InterfaceToSBC + ", CustMedIrb = " + CustMedIrb + ", pvcDlciM3 = " +
	 * pvcDlciM3 + ", custMedGatewayIp = " + custMedGatewayIp + ", pvcDlciM4 = " +
	 * pvcDlciM4 + "]"; }
	 */
}
