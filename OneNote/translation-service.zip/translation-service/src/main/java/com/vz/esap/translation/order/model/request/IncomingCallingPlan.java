package com.vz.esap.translation.order.model.request;

public class IncomingCallingPlan {

	private String intraLocation;
	private String interLocation;
	private String collectCalls;

	public String getIntraLocation() {
		return intraLocation;
	}

	public void setIntraLocation(String intraLocation) {
		this.intraLocation = intraLocation;
	}

	public String getInterLocation() {
		return interLocation;
	}

	public void setInterLocation(String interLocation) {
		this.interLocation = interLocation;
	}

	public String getCollectCalls() {
		return collectCalls;
	}

	public void setCollectCalls(String collectCalls) {
		this.collectCalls = collectCalls;
	}

	public String toString() {
		StringBuilder retValue = new StringBuilder();
		retValue.append("<IncomingCallingPlan>\n");
		retValue.append("<intraLocation>").append(this.intraLocation).append("</intraLocation>\n");
		retValue.append("<interLocation>").append(this.interLocation).append("</interLocation>\n");
		retValue.append("</IncomingCallingPlan>\n");

		return retValue.toString();
	}
}
