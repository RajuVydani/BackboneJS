package com.vz.esap.translation.entity;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.vz.esap.translation.enums.EsapEnum.AuthFeatureType;
import com.vz.esap.translation.enums.EsapEnum.OrderEntity;
import com.vz.esap.translation.enums.EsapEnum.RedundancyPriorityType;
import com.vz.esap.translation.enums.EsapEnum.RedundancyType;
import com.vz.esap.translation.enums.EsapEnum.SolutionType;
import com.vz.esap.translation.order.model.request.DigitString;
import com.vz.esap.translation.order.model.request.TsoMigrationLocReferenceData;

import EsapEnumPkg.VzbVoipEnum;
import EsapEnumPkg.VzbVoipEnums;

public class LocationEntity extends Entity {

	private static final Logger LOG = LoggerFactory.getLogger(LocationEntity.class);

	@Override
	public int getEntityType() {
		return OrderEntity.ENTERPRISE.getIndex();
	}

	@Override
	public String getEntityName() {
		return name;
	}

	@Override
	public String getEntityId() {
		return locationId;
	}

	public static enum QosIndicator {
		NONE, STANDARD, PREMIUM;
	}

	private String locationId;
	private String customerId;
	private String description;
	private String marketType;
	private String name;
	private String address;
	private String city;
	private String state;
	private String zip;
	private String country;
	private String timeZone;
	private String daylightSavingInd;
	private String webLanguage;
	private String vmLanguage;
	private String contactName;
	private String contactPhone;
	private String contactEmail;
	private String acctTeamName;
	private String acctTeamPhone;
	private String acctTeamEmail;
	private String sipDomain;
	private String parentDomain;
	private String billingType;
	private BigInteger maxConcurrentCalls;
	private BigInteger maxConcurrentOffNet;
	private String serviceLevel;
	private BigInteger privateNumberLength;
	private String npaNxx;
	private String accessType;
	private String accessCategory;
	private String sbcAccessType;
	private String vpnName;
	private String circuitId;
	private String locationComment;
	private String advantageClub;
	private String netcomSvcId;
	private String managedFlag;
	private String uunetSiteId;
	private BigInteger totalSubscribers;
	private BigInteger totalVoiceMailAccts;
	private BigInteger totalPublicNumbers;
	private BigInteger ixPlusID;
	private BigInteger ixPlusRegion;
	private String callingPartyNumber;
	private String callingPartyPrivacy;
	private String stationLevelId;
	private String bsAppServer;
	private String asClli;
	private BigInteger extensionLength;
	private String cv2Service;
	private String voipServiceType;
	private BigInteger maxConcurrentSlg;
	private BigInteger maxConcurrentInbound;
	private String hybridServiceType;
	private String emergencyCallLine;
	private Boolean enableCallPark; // enums??
	private Boolean overrideSubPrivate;
	private Boolean overrideCidName;
	private Boolean overrideCidNum;
	private Boolean enableAccountCode;
	private Boolean enableAuthCode;
	private Boolean blockAllCalls;
	private Boolean expedite;
	private Boolean highVolume;
	private Boolean afterHourInstallFee;
	private Boolean callingNameInd;
	private Boolean enhancedANIInd;
	private Boolean locationCclIndicator;
	private String sTn;
	private Boolean pubIp;
	private Boolean pubIpIn;
	private Boolean pubIpInStr;
	private Boolean pubIpOut;
	private Boolean pubIpOutStr;
	private Boolean pubIpStr;
	private String localDirAssistance; // enums??
	private String natDirAssistance;// enums??
	private Integer maxNg;
	private String cidTn;
	private Integer trunkType;
	private String switchClli;
	private String trunk;
	private Long publicGtwyDpid;
	private Long defaultGtwyDpid;
	private String abbrDialingCode;
	private Boolean sbcEnabled;
	private VmType vmType;
	private String vmCpeIpAddress;
	private Boolean vmSmdiAuthToggle;
	// private Long vmSmdiAuthToggle;
	private Integer linePortLength;
	private Map<String, BigInteger> featurePackage; // Name,VmBoxSize
	private ArrayList<VmAccess> vmAccessList;
	private ArrayList<String> prefixPlanName;
	private ArrayList<DeviceEntity> devices;
	private String sipClientEnabledFlag;
	private String strSbcId;
	private String strCustFqdn;
	private String strCustIpAddr;
	private String uNumber;
	private String siebelOrder;
	private String billAcctNum;
	private int intCustPort;
	private HashMap<String, Integer> locationFeatures;
	private CallingPlanEntity callingPlan;
	private QosIndicator qosIndicator;
	// private String fmcLocation = "NONE";
	private String fmcLocation;
	private TypeOfLocEnum typeOfLoc;
	private String hubLocationId;
	private Boolean productionIndicator;
	private ArrayList<AccountAuthCode> accountAuthCodes;
	private String emerLocationCode;
	private long hubGatewayDeviceId;
	private Long locationMask;
	private Long aNumMask;
	private Long bNumMask;
	private ArrayList<DigitString> digitStrings;
	// protected Boolean sbcAutomation;
	protected SbcProvMethod sbcProvMethod;
	protected AlternativeCallerIdFlag altCallerIdFlag;
	private String rivCustomer;
	private ArrayList<String> preselectedVpnName;
	/* APAC Attributes */
	private String territory;
	private String locRegion;
	private String PBBAN;
	private Integer billingSystem;
	private String iasaOrderId;
	protected Integer prefixPlanId;
	private Long emerLocCodeId;
	private Long configAllowed;
	/* End - APAC */
	private String productId;
	private String VARRS;
	private Boolean billingActivated;
	private String physicalLocationId;
	private String physicalLocationName;
	private String callForwardPlanName; // VOIP feature enhancement
	private Long enterpriseTrunkId;
	private Long pqInstanceId;
	private Long designId;
	private String pendingRPID;
	private String migrationType;
	private String provisionCategory;
	// VCE changes
	private String vce;

	// R10 ECM changes
	private String emerNumber;
	private String emerMappingCode;
	private String addressID;
	private String emerLocationCodeId;
	// Clin change - one field
	private String clin;
	private List<ECMInfo> ecmInfo;
	private List<String> TrunkIds;
	private String transportType;
	private TsoMigrationLocReferenceData tsoMigrationLocReferenceData;
	// added for CalNet contract Ind
	
	//list of trunkgroupIDs string
	private String subAgencyHierCode;
	private Boolean isE2E;
	private String dialingCountryCode;
	private GCMInfo gcmInfo;
	private String portOutType;
	private short tsoMigLock;
	//----XOOO
	private long tnQuantity;
	private RedundancyType redundancy;
	private String redundancyId;
	private RedundancyPriorityType redundancyPriorityType;
	private String eslId;
	private String eblId;
	private HashMap<String, Boolean> authServices;
	private List<AuthService> authService;
	private Session session;	
	private String adminFirstName;
	private String adminLastName;
	private String adminEmail;
	private String domainName;
	private String adminPassword;
	private String adminWebLoginId;
	private long billingTN;
	private String broadworksPortalNumber;
	private String groupUserLimit;
	private String bwEnterpriseId;
	private String bsTimeZone;
	private String region;
	private SolutionType solutionType;
	private AuthFeatureType authFeatureType;
	private String vpnPortSpeed;
	private String portSpeed;
	private String vpnPortType;
	private long envOrderId;
	private long internalOrderId;;
	private String bwLocationId;
	private long maxActiveCall;
	private long maxIncomingCall;
	private long maxOutgoingCall;
	private String preBuildLocId;
	private int locationType;
	
	
	private LocationEntity locationEntity;
	private long maxActiveCalls;
	private long maxActiveIncomingCalls;
	private long maxActiveOutgoingCalls;
	private String esbcSignalingIP;
	
	public String getPortSpeed() {
		return portSpeed;
	}

	public void setPortSpeed(String portSpeed) {
		this.portSpeed = portSpeed;
	}

	public String getVpnPortType() {
		return vpnPortType;
	}

	public void setVpnPortType(String vpnPortType) {
		this.vpnPortType = vpnPortType;
	}

	public String getVgeCont() {
		return vgeCont;
	}

	public void setVgeCont(String vgeCont) {
		this.vgeCont = vgeCont;
	}

	private String vgeCont;

	public String getVpnPortSpeed() {
		return vpnPortSpeed;
	}

	public void setVpnPortSpeed(String vpnPortSpeed) {
		this.vpnPortSpeed = vpnPortSpeed;
	}

	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	public static enum VmType {

		HOSTED(VzbVoipEnum.LocationVmType.HOSTED), PREMISE(VzbVoipEnum.LocationVmType.PREMISE);
		int esapEnum;

		private VmType(int esapEnum) {
			this.esapEnum = esapEnum;
		}

		public int getEsapEnum() {
			return esapEnum;
		}

		public static VmType valueOf(int esapEnum) {
			for (VmType vmType : VmType.values()) {
				if (vmType.getEsapEnum() == esapEnum) {
					return vmType;
				}
			}

			return null;
		}
	}

	public static enum ServiceType {

		IP_FLEXIBLE_T1(VzbVoipEnum.VoipServiceType.IP_FLEXIBLE_T1, "KEY"), IP_INTEGRATED_ACCESS_PBX(
				VzbVoipEnum.VoipServiceType.IP_INTEGRATED_ACCESS_PBX,
				"PBX"), IP_INTEGRATED_ACCESS_KEY(VzbVoipEnum.VoipServiceType.IP_INTEGRATED_ACCESS_KEY,
						"KEY"), IP_TRUNKING(VzbVoipEnum.VoipServiceType.IP_TRUNKING, "PBX"), IP_INTEGRATED_ACCESS_ET(
								VzbVoipEnum.VoipServiceType.IP_INTEGRATED_ACCESS_ET,
								"Enterprise Trunk"), IP_TRUNKING_ET(VzbVoipEnum.VoipServiceType.IP_TRUNKING_ET,
										"Enterprise Trunk"), HIPC(VzbVoipEnum.VoipServiceType.HIPC, "HIPC");
		int esapEnum;
		String commonName;

		private ServiceType(int esapEnum, String commonName) {
			this.esapEnum = esapEnum;
			this.commonName = commonName;
		}

		public int getEsapEnum() {
			return esapEnum;
		}

		public String getCommonName() {
			return commonName;
		}

		public static ServiceType valueOf(int esapEnum) {
			for (ServiceType locType : ServiceType.values()) {
				if (locType.getEsapEnum() == esapEnum) {
					return locType;
				}
			}

			return null;
		}
	}

	public static enum SbcProvMethod {

		ESAP(VzbVoipEnum.SbcProvMethodType.ESAP), IASA(VzbVoipEnum.SbcProvMethodType.IASA);
		int esapEnum;

		private SbcProvMethod(int esapEnum) {
			this.esapEnum = esapEnum;
		}

		public int getEsapEnum() {
			return esapEnum;
		}

		public static SbcProvMethod valueOf(int esapEnum) {
			for (SbcProvMethod ps : SbcProvMethod.values()) {
				if (ps.getEsapEnum() == esapEnum) {
					return ps;
				}
			}

			return null;
		}
	}
	
	public static enum TypeOfLocEnum {

	      STANDARD(VzbVoipEnum.LocationType.STANDARD),
	      HUB(VzbVoipEnum.LocationType.HUB),
	      REMOTE(VzbVoipEnum.LocationType.REMOTE),
	      HUB_AND_STANDARD(4),
	      ESIP_ESL(5),
	      ESIP_EBL(6),
	      HPBX_ECH(7),
	      HPBX_EBL(8),
	      FLEX(9);
		
		
	      int esapEnum;

	      private TypeOfLocEnum(int esapEnum) {
	         this.esapEnum = esapEnum;
	      }

	      public int getEsapEnum() {
	         return esapEnum;
	      }

	      public static TypeOfLocEnum valueOf(int esapEnum) {
	         for (TypeOfLocEnum locType : TypeOfLocEnum.values()) {
	            if (locType.getEsapEnum() == esapEnum) {
	               return locType;
	            }
	         }

	         return null;
	      }
	   }

	public static enum AlternativeCallerIdFlag {

		NOTIMPLEMENTED(VzbVoipEnum.AlternativeCallerId.NOTIMPLEMENTED), OFF(VzbVoipEnum.AlternativeCallerId.OFF), ON(
				VzbVoipEnum.AlternativeCallerId.ON);
		int esapEnum;

		private AlternativeCallerIdFlag(int esapEnum) {
			this.esapEnum = esapEnum;
		}

		public int getEsapEnum() {
			return esapEnum;
		}

		public static AlternativeCallerIdFlag valueOf(int esapEnum) {
			for (AlternativeCallerIdFlag ps : AlternativeCallerIdFlag.values()) {
				if (ps.getEsapEnum() == esapEnum) {
					return ps;
				}
			}

			return null;
		}
	}

	/*public boolean modifyLocationUnassignTn(String tn) {

		boolean mod = false;

		if (callingPartyNumber != null && callingPartyNumber.equals(tn)) {
			callingPartyNumber = "";
			// LogUtil.log(3, "Location.modifyLocationunassignTn matched RPID:" + tn);

			setCallingPartyNumber("");
			setOverrideCidName(false);
			setOverrideCidNum(false);
			setOverrideSubPrivate(true);

			mod = true;
		}

		if (emergencyCallLine != null && emergencyCallLine.equals(tn)) {
			emergencyCallLine = "";
			// LogUtil.log(3, "Location.modifyLocationunassignTn matched ETN:" + tn);
			mod = true;
		}

		if (vmAccessList != null) {
			for (Iterator<VmAccess> vmaItr = vmAccessList.iterator(); vmaItr.hasNext();) {

				VmAccess vma = vmaItr.next();
				if (vma.getPublicNumber() != null && vma.getPublicNumber().equals(tn)) {
					// LogUtil.log(3, "Location.modifyLocationunassignTn matched VPA TN:" + tn);
					vmaItr.remove();
					mod = true;
				}

			}
		}

		return mod;
	}*/

	public String getLocationId() {
		return locationId;
	}

	public void setLocationId(String locationId) {
		this.locationId = locationId;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getMarketType() {
		return marketType;
	}

	public void setMarketType(String marketType) {
		this.marketType = marketType;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getZip() {
		return zip;
	}

	public void setZip(String zip) {
		this.zip = zip;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getTimeZone() {
		return timeZone;
	}

	public void setTimeZone(String timeZone) {
		this.timeZone = timeZone;
	}

	public String getDaylightSavingInd() {
		return daylightSavingInd;
	}

	public void setDaylightSavingInd(String daylightSavingInd) {
		this.daylightSavingInd = daylightSavingInd;
	}

	public String getWebLanguage() {
		return webLanguage;
	}

	public void setWebLanguage(String webLanguage) {
		this.webLanguage = webLanguage;
	}

	public String getVmLanguage() {
		return vmLanguage;
	}

	public void setVmLanguage(String vmLanguage) {
		this.vmLanguage = vmLanguage;
	}

	public String getContactName() {
		return contactName;
	}

	public void setContactName(String contactName) {
		this.contactName = contactName;
	}

	public String getContactPhone() {
		return contactPhone;
	}

	public void setContactPhone(String contactPhone) {
		this.contactPhone = contactPhone;
	}

	public String getContactEmail() {
		return contactEmail;
	}

	public void setContactEmail(String contactEmail) {
		this.contactEmail = contactEmail;
	}

	public String getAcctTeamName() {
		return acctTeamName;
	}

	public void setAcctTeamName(String acctTeamName) {
		this.acctTeamName = acctTeamName;
	}

	public String getAcctTeamPhone() {
		return acctTeamPhone;
	}

	public void setAcctTeamPhone(String acctTeamPhone) {
		this.acctTeamPhone = acctTeamPhone;
	}

	public String getAcctTeamEmail() {
		return acctTeamEmail;
	}

	public void setAcctTeamEmail(String acctTeamEmail) {
		this.acctTeamEmail = acctTeamEmail;
	}

	public String getSipDomain() {
		return sipDomain;
	}

	public void setSipDomain(String sipDomain) {
		this.sipDomain = sipDomain;
	}

	public String getParentDomain() {
		return parentDomain;
	}

	public void setParentDomain(String parentDomain) {
		this.parentDomain = parentDomain;
	}

	public String getBillingType() {
		return billingType;
	}

	public void setBillingType(String billingType) {
		this.billingType = billingType;
	}

	public BigInteger getMaxConcurrentCalls() {
		return maxConcurrentCalls;
	}

	public void setMaxConcurrentCalls(BigInteger maxConcurrentCalls) {
		this.maxConcurrentCalls = maxConcurrentCalls;
	}

	public BigInteger getMaxConcurrentOffNet() {
		return maxConcurrentOffNet;
	}

	public void setMaxConcurrentOffNet(BigInteger maxConcurrentOffNet) {
		this.maxConcurrentOffNet = maxConcurrentOffNet;
	}

	public String getServiceLevel() {
		return serviceLevel;
	}

	public void setServiceLevel(String serviceLevel) {
		this.serviceLevel = serviceLevel;
	}

	public BigInteger getPrivateNumberLength() {
		return privateNumberLength;
	}

	public void setPrivateNumberLength(BigInteger privateNumberLength) {
		this.privateNumberLength = privateNumberLength;
	}

	public String getNpaNxx() {
		return npaNxx;
	}

	public void setNpaNxx(String npaNxx) {
		this.npaNxx = npaNxx;
	}

	public String getAccessType() {
		return accessType;
	}

	public void setAccessType(String accessType) {
		this.accessType = accessType;
	}

	public String getAccessCategory() {
		return accessCategory;
	}

	public void setAccessCategory(String accessCategory) {
		this.accessCategory = accessCategory;
	}

	public String getSbcAccessType() {
		return sbcAccessType;
	}

	public void setSbcAccessType(String sbcAccessType) {
		this.sbcAccessType = sbcAccessType;
	}

	public String getVpnName() {
		return vpnName;
	}

	public void setVpnName(String vpnName) {
		this.vpnName = vpnName;
	}

	public String getCircuitId() {
		return circuitId;
	}

	public void setCircuitId(String circuitId) {
		this.circuitId = circuitId;
	}

	public String getLocationComment() {
		return locationComment;
	}

	public void setLocationComment(String locationComment) {
		this.locationComment = locationComment;
	}

	public String getAdvantageClub() {
		return advantageClub;
	}

	public void setAdvantageClub(String advantageClub) {
		this.advantageClub = advantageClub;
	}

	public String getNetcomSvcId() {
		return netcomSvcId;
	}

	public void setNetcomSvcId(String netcomSvcId) {
		this.netcomSvcId = netcomSvcId;
	}

	public String getManagedFlag() {
		return managedFlag;
	}

	public void setManagedFlag(String managedFlag) {
		this.managedFlag = managedFlag;
	}

	public String getUunetSiteId() {
		return uunetSiteId;
	}

	public void setUunetSiteId(String uunetSiteId) {
		this.uunetSiteId = uunetSiteId;
	}

	public BigInteger getTotalSubscribers() {
		return totalSubscribers;
	}

	public void setTotalSubscribers(BigInteger totalSubscribers) {
		this.totalSubscribers = totalSubscribers;
	}

	public BigInteger getTotalVoiceMailAccts() {
		return totalVoiceMailAccts;
	}

	public void setTotalVoiceMailAccts(BigInteger totalVoiceMailAccts) {
		this.totalVoiceMailAccts = totalVoiceMailAccts;
	}

	public BigInteger getTotalPublicNumbers() {
		return totalPublicNumbers;
	}

	public void setTotalPublicNumbers(BigInteger totalPublicNumbers) {
		this.totalPublicNumbers = totalPublicNumbers;
	}

	public BigInteger getIxPlusID() {
		return ixPlusID;
	}

	public void setIxPlusID(BigInteger ixPlusID) {
		this.ixPlusID = ixPlusID;
	}

	public BigInteger getIxPlusRegion() {
		return ixPlusRegion;
	}

	public void setIxPlusRegion(BigInteger ixPlusRegion) {
		this.ixPlusRegion = ixPlusRegion;
	}

	public String getCallingPartyNumber() {
		return callingPartyNumber;
	}

	public void setCallingPartyNumber(String callingPartyNumber) {
		this.callingPartyNumber = callingPartyNumber;
	}

	public String getCallingPartyPrivacy() {
		return callingPartyPrivacy;
	}

	public void setCallingPartyPrivacy(String callingPartyPrivacy) {
		this.callingPartyPrivacy = callingPartyPrivacy;
	}

	public String getStationLevelId() {
		return stationLevelId;
	}

	public void setStationLevelId(String stationLevelId) {
		this.stationLevelId = stationLevelId;
	}

	public String getBsAppServer() {
		return bsAppServer;
	}

	public void setBsAppServer(String bsAppServer) {
		this.bsAppServer = bsAppServer;
	}

	public BigInteger getExtensionLength() {
		return extensionLength;
	}

	public void setExtensionLength(BigInteger extensionLength) {
		this.extensionLength = extensionLength;
	}

	public String getCv2Service() {
		return cv2Service;
	}

	public void setCv2Service(String cv2Service) {
		this.cv2Service = cv2Service;
	}

	public String getVoipServiceType() {
		return voipServiceType;
	}

	public void setVoipServiceType(String voipServiceType) {
		this.voipServiceType = voipServiceType;
	}

	public BigInteger getMaxConcurrentSlg() {
		return maxConcurrentSlg;
	}

	public void setMaxConcurrentSlg(BigInteger maxConcurrentSlg) {
		this.maxConcurrentSlg = maxConcurrentSlg;
	}

	public BigInteger getMaxConcurrentInbound() {
		return maxConcurrentInbound;
	}

	public void setMaxConcurrentInbound(BigInteger maxConcurrentInbound) {
		this.maxConcurrentInbound = maxConcurrentInbound;
	}

	public String getHybridServiceType() {
		return hybridServiceType;
	}

	public void setHybridServiceType(String hybridServiceType) {
		this.hybridServiceType = hybridServiceType;
	}

	public String getEmergencyCallLine() {
		return emergencyCallLine;
	}

	public void setEmergencyCallLine(String emergencyCallLine) {
		this.emergencyCallLine = emergencyCallLine;
	}

	public Boolean getEnableCallPark() {
		return enableCallPark;
	}

	public void setEnableCallPark(Boolean enableCallPark) {
		this.enableCallPark = enableCallPark;
	}

	public Boolean getOverrideSubPrivate() {
		return overrideSubPrivate;
	}

	public void setOverrideSubPrivate(Boolean overrideSubPrivate) {
		this.overrideSubPrivate = overrideSubPrivate;
	}

	public Boolean getOverrideCidName() {
		return overrideCidName;
	}

	public void setOverrideCidName(Boolean overrideCidName) {
		this.overrideCidName = overrideCidName;
	}

	public Boolean getOverrideCidNum() {
		return overrideCidNum;
	}

	public void setOverrideCidNum(Boolean overrideCidNum) {
		this.overrideCidNum = overrideCidNum;
	}

	public Boolean getEnableAccountCode() {
		return enableAccountCode;
	}

	public void setEnableAccountCode(Boolean enableAccountCode) {
		this.enableAccountCode = enableAccountCode;
	}

	public Boolean getEnableAuthCode() {
		return enableAuthCode;
	}

	public void setEnableAuthCode(Boolean enableAuthCode) {
		this.enableAuthCode = enableAuthCode;
	}

	public Boolean getBlockAllCalls() {
		return blockAllCalls;
	}

	public void setBlockAllCalls(Boolean blockAllCalls) {
		this.blockAllCalls = blockAllCalls;
	}

	public Boolean getExpedite() {
		return expedite;
	}

	public void setExpedite(Boolean expedite) {
		this.expedite = expedite;
	}

	public Boolean getHighVolume() {
		return highVolume;
	}

	public void setHighVolume(Boolean highVolume) {
		this.highVolume = highVolume;
	}

	public Boolean getAfterHourInstallFee() {
		return afterHourInstallFee;
	}

	public void setAfterHourInstallFee(Boolean afterHourInstallFee) {
		this.afterHourInstallFee = afterHourInstallFee;
	}

	public Boolean getCallingNameInd() {
		return callingNameInd;
	}

	public void setCallingNameInd(Boolean callingNameInd) {
		this.callingNameInd = callingNameInd;
	}

	public Boolean getEnhancedANIInd() {
		return enhancedANIInd;
	}

	public void setEnhancedANIInd(Boolean enhancedANIInd) {
		this.enhancedANIInd = enhancedANIInd;
	}

	public Boolean getLocationCclIndicator() {
		return locationCclIndicator;
	}

	public void setLocationCclIndicator(Boolean locationCclIndicator) {
		this.locationCclIndicator = locationCclIndicator;
	}

	public String getsTn() {
		return sTn;
	}

	public void setsTn(String sTn) {
		this.sTn = sTn;
	}

	public Boolean getPubIp() {
		return pubIp;
	}

	public void setPubIp(Boolean pubIp) {
		this.pubIp = pubIp;
	}

	public Boolean getPubIpIn() {
		return pubIpIn;
	}

	public void setPubIpIn(Boolean pubIpIn) {
		this.pubIpIn = pubIpIn;
	}

	public Boolean getPubIpInStr() {
		return pubIpInStr;
	}

	public void setPubIpInStr(Boolean pubIpInStr) {
		this.pubIpInStr = pubIpInStr;
	}

	public Boolean getPubIpOut() {
		return pubIpOut;
	}

	public void setPubIpOut(Boolean pubIpOut) {
		this.pubIpOut = pubIpOut;
	}

	public Boolean getPubIpOutStr() {
		return pubIpOutStr;
	}

	public void setPubIpOutStr(Boolean pubIpOutStr) {
		this.pubIpOutStr = pubIpOutStr;
	}

	public Boolean getPubIpStr() {
		return pubIpStr;
	}

	public void setPubIpStr(Boolean pubIpStr) {
		this.pubIpStr = pubIpStr;
	}

	public String getLocalDirAssistance() {
		return localDirAssistance;
	}

	public void setLocalDirAssistance(String localDirAssistance) {
		this.localDirAssistance = localDirAssistance;
	}

	public String getNatDirAssistance() {
		return natDirAssistance;
	}

	public void setNatDirAssistance(String natDirAssistance) {
		this.natDirAssistance = natDirAssistance;
	}

	public Integer getMaxNg() {
		return maxNg;
	}

	public void setMaxNg(Integer maxNg) {
		this.maxNg = maxNg;
	}

	public String getCidTn() {
		return cidTn;
	}

	public void setCidTn(String cidTn) {
		this.cidTn = cidTn;
	}

	public Integer getTrunkType() {
		return trunkType;
	}

	public void setTrunkType(Integer trunkType) {
		this.trunkType = trunkType;
	}

	public String getSwitchClli() {
		return switchClli;
	}

	public void setSwitchClli(String switchClli) {
		this.switchClli = switchClli;
	}

	public String getTrunk() {
		return trunk;
	}

	public void setTrunk(String trunk) {
		this.trunk = trunk;
	}

	public Long getPublicGtwyDpid() {
		return publicGtwyDpid;
	}

	public void setPublicGtwyDpid(Long publicGtwyDpid) {
		this.publicGtwyDpid = publicGtwyDpid;
	}

	public Long getDefaultGtwyDpid() {
		return defaultGtwyDpid;
	}

	public void setDefaultGtwyDpid(Long defaultGtwyDpid) {
		this.defaultGtwyDpid = defaultGtwyDpid;
	}

	public String getAbbrDialingCode() {
		return abbrDialingCode;
	}

	public void setAbbrDialingCode(String abbrDialingCode) {
		this.abbrDialingCode = abbrDialingCode;
	}

	public Boolean getSbcEnabled() {
		return sbcEnabled;
	}

	public void setSbcEnabled(Boolean sbcEnabled) {
		this.sbcEnabled = sbcEnabled;
	}

	public VmType getVmType() {
		return vmType;
	}

	public void setVmType(VmType vmType) {
		this.vmType = vmType;
	}

	public String getVmCpeIpAddress() {
		return vmCpeIpAddress;
	}

	public void setVmCpeIpAddress(String vmCpeIpAddress) {
		this.vmCpeIpAddress = vmCpeIpAddress;
	}

	public Boolean getVmSmdiAuthToggle() {
		return vmSmdiAuthToggle;
	}

	public void setVmSmdiAuthToggle(Boolean vmSmdiAuthToggle) {
		this.vmSmdiAuthToggle = vmSmdiAuthToggle;
	}

	public Integer getLinePortLength() {
		return linePortLength;
	}

	public void setLinePortLength(Integer linePortLength) {
		this.linePortLength = linePortLength;
	}

	public Map<String, BigInteger> getFeaturePackage() {
		return featurePackage;
	}

	public void setFeaturePackage(Map<String, BigInteger> featurePackage) {
		this.featurePackage = featurePackage;
	}

	public ArrayList<VmAccess> getVmAccessList() {
		return vmAccessList;
	}

	public void setVmAccessList(ArrayList<VmAccess> vmAccessList) {
		this.vmAccessList = vmAccessList;
	}

	public ArrayList<String> getPrefixPlanName() {
		return prefixPlanName;
	}

	public void setPrefixPlanName(ArrayList<String> prefixPlanName) {
		this.prefixPlanName = prefixPlanName;
	}

	public ArrayList<DeviceEntity> getDevices() {
		return devices;
	}

	public void setDevices(ArrayList<DeviceEntity> devices) {
		this.devices = devices;
	}

	public String getSipClientEnabledFlag() {
		return sipClientEnabledFlag;
	}

	public void setSipClientEnabledFlag(String sipClientEnabledFlag) {
		this.sipClientEnabledFlag = sipClientEnabledFlag;
	}

	public String getStrSbcId() {
		return strSbcId;
	}

	public void setStrSbcId(String strSbcId) {
		this.strSbcId = strSbcId;
	}

	public String getStrCustFqdn() {
		return strCustFqdn;
	}

	public void setStrCustFqdn(String strCustFqdn) {
		this.strCustFqdn = strCustFqdn;
	}

	public String getStrCustIpAddr() {
		return strCustIpAddr;
	}

	public void setStrCustIpAddr(String strCustIpAddr) {
		this.strCustIpAddr = strCustIpAddr;
	}

	public String getuNumber() {
		return uNumber;
	}

	public void setuNumber(String uNumber) {
		this.uNumber = uNumber;
	}

	public String getSiebelOrder() {
		return siebelOrder;
	}

	public void setSiebelOrder(String siebelOrder) {
		this.siebelOrder = siebelOrder;
	}

	public String getBillAcctNum() {
		return billAcctNum;
	}

	public void setBillAcctNum(String billAcctNum) {
		this.billAcctNum = billAcctNum;
	}

	public int getIntCustPort() {
		return intCustPort;
	}

	public void setIntCustPort(int intCustPort) {
		this.intCustPort = intCustPort;
	}

	public HashMap<String, Integer> getLocationFeatures() {
		return locationFeatures;
	}

	public void setLocationFeatures(HashMap<String, Integer> locationFeatures) {
		this.locationFeatures = locationFeatures;
	}

	public CallingPlanEntity getCallingPlan() {
		return callingPlan;
	}

	public void setCallingPlan(CallingPlanEntity callingPlan) {
		this.callingPlan = callingPlan;
	}

	public QosIndicator getQosIndicator() {
		return qosIndicator;
	}

	public void setQosIndicator(QosIndicator qosIndicator) {
		this.qosIndicator = qosIndicator;
	}

	public String getFmcLocation() {
		return fmcLocation;
	}

	public void setFmcLocation(String fmcLocation) {
		this.fmcLocation = fmcLocation;
	}

	public TypeOfLocEnum getTypeOfLoc() {
		return typeOfLoc;
	}

	public void setTypeOfLoc(TypeOfLocEnum typeOfLoc) {
		this.typeOfLoc = typeOfLoc;
	}

	public String getHubLocationId() {
		return hubLocationId;
	}

	public void setHubLocationId(String hubLocationId) {
		this.hubLocationId = hubLocationId;
	}

	public Boolean getProductionIndicator() {
		return productionIndicator;
	}

	public void setProductionIndicator(Boolean productionIndicator) {
		this.productionIndicator = productionIndicator;
	}

	public ArrayList<AccountAuthCode> getAccountAuthCodes() {
		return accountAuthCodes;
	}

	public void setAccountAuthCodes(ArrayList<AccountAuthCode> accountAuthCodes) {
		this.accountAuthCodes = accountAuthCodes;
	}

	public String getEmerLocationCode() {
		return emerLocationCode;
	}

	public void setEmerLocationCode(String emerLocationCode) {
		this.emerLocationCode = emerLocationCode;
	}

	public long getHubGatewayDeviceId() {
		return hubGatewayDeviceId;
	}

	public void setHubGatewayDeviceId(long hubGatewayDeviceId) {
		this.hubGatewayDeviceId = hubGatewayDeviceId;
	}

	public Long getLocationMask() {
		return locationMask;
	}

	public void setLocationMask(Long locationMask) {
		this.locationMask = locationMask;
	}

	public Long getaNumMask() {
		return aNumMask;
	}

	public void setaNumMask(Long aNumMask) {
		this.aNumMask = aNumMask;
	}

	public Long getbNumMask() {
		return bNumMask;
	}

	public void setbNumMask(Long bNumMask) {
		this.bNumMask = bNumMask;
	}

	public ArrayList<DigitString> getDigitStrings() {
		return digitStrings;
	}

	public void setDigitStrings(ArrayList<DigitString> digitStrings) {
		this.digitStrings = digitStrings;
	}

	public SbcProvMethod getSbcProvMethod() {
		return sbcProvMethod;
	}

	public void setSbcProvMethod(SbcProvMethod sbcProvMethod) {
		this.sbcProvMethod = sbcProvMethod;
	}

	public AlternativeCallerIdFlag getAltCallerIdFlag() {
		return altCallerIdFlag;
	}

	public void setAltCallerIdFlag(AlternativeCallerIdFlag altCallerIdFlag) {
		this.altCallerIdFlag = altCallerIdFlag;
	}

	public String getRivCustomer() {
		return rivCustomer;
	}

	public void setRivCustomer(String rivCustomer) {
		this.rivCustomer = rivCustomer;
	}

	public ArrayList<String> getPreselectedVpnName() {
		return preselectedVpnName;
	}

	public void setPreselectedVpnName(ArrayList<String> preselectedVpnName) {
		this.preselectedVpnName = preselectedVpnName;
	}

	public String getTerritory() {
		return territory;
	}

	public void setTerritory(String territory) {
		this.territory = territory;
	}

	public String getLocRegion() {
		return locRegion;
	}

	public void setLocRegion(String locRegion) {
		this.locRegion = locRegion;
	}

	public String getPBBAN() {
		return PBBAN;
	}

	public void setPBBAN(String pBBAN) {
		PBBAN = pBBAN;
	}

	public Integer getBillingSystem() {
		return billingSystem;
	}

	public void setBillingSystem(Integer billingSystem) {
		this.billingSystem = billingSystem;
	}

	public String getIasaOrderId() {
		return iasaOrderId;
	}

	public void setIasaOrderId(String iasaOrderId) {
		this.iasaOrderId = iasaOrderId;
	}

	public Integer getPrefixPlanId() {
		return prefixPlanId;
	}

	public void setPrefixPlanId(Integer prefixPlanId) {
		this.prefixPlanId = prefixPlanId;
	}

	public Long getEmerLocCodeId() {
		return emerLocCodeId;
	}

	public void setEmerLocCodeId(Long emerLocCodeId) {
		this.emerLocCodeId = emerLocCodeId;
	}

	public Long getConfigAllowed() {
		return configAllowed;
	}

	public void setConfigAllowed(Long configAllowed) {
		this.configAllowed = configAllowed;
	}

	public String getProductId() {
		return productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}

	public String getVARRS() {
		return VARRS;
	}

	public void setVARRS(String vARRS) {
		VARRS = vARRS;
	}

	public Boolean getBillingActivated() {
		return billingActivated;
	}

	public void setBillingActivated(Boolean billingActivated) {
		this.billingActivated = billingActivated;
	}

	public String getPhysicalLocationId() {
		return physicalLocationId;
	}

	public void setPhysicalLocationId(String physicalLocationId) {
		this.physicalLocationId = physicalLocationId;
	}

	public String getPhysicalLocationName() {
		return physicalLocationName;
	}

	public void setPhysicalLocationName(String physicalLocationName) {
		this.physicalLocationName = physicalLocationName;
	}

	public String getCallForwardPlanName() {
		return callForwardPlanName;
	}

	public void setCallForwardPlanName(String callForwardPlanName) {
		this.callForwardPlanName = callForwardPlanName;
	}

	public Long getEnterpriseTrunkId() {
		return enterpriseTrunkId;
	}

	public void setEnterpriseTrunkId(Long enterpriseTrunkId) {
		this.enterpriseTrunkId = enterpriseTrunkId;
	}

	public Long getPqInstanceId() {
		return pqInstanceId;
	}

	public void setPqInstanceId(Long pqInstanceId) {
		this.pqInstanceId = pqInstanceId;
	}

	public Long getDesignId() {
		return designId;
	}

	public void setDesignId(Long designId) {
		this.designId = designId;
	}

	public String getPendingRPID() {
		return pendingRPID;
	}

	public void setPendingRPID(String pendingRPID) {
		this.pendingRPID = pendingRPID;
	}

	public String getMigrationType() {
		return migrationType;
	}

	public void setMigrationType(String migrationType) {
		this.migrationType = migrationType;
	}

	public String getVce() {
		return vce;
	}

	public void setVce(String vce) {
		this.vce = vce;
	}

	public String getEmerNumber() {
		return emerNumber;
	}

	public void setEmerNumber(String emerNumber) {
		this.emerNumber = emerNumber;
	}

	public String getEmerMappingCode() {
		return emerMappingCode;
	}

	public void setEmerMappingCode(String emerMappingCode) {
		this.emerMappingCode = emerMappingCode;
	}

	public String getAddressID() {
		return addressID;
	}

	public void setAddressID(String addressID) {
		this.addressID = addressID;
	}

	public String getEmerLocationCodeId() {
		return emerLocationCodeId;
	}

	public void setEmerLocationCodeId(String emerLocationCodeId) {
		this.emerLocationCodeId = emerLocationCodeId;
	}

	public String getClin() {
		return clin;
	}

	public void setClin(String clin) {
		this.clin = clin;
	}

	
	public List<ECMInfo> getEcmInfo() {
		return ecmInfo;
	}

	public void setEcmInfo(List<ECMInfo> ecmInfo) {
		this.ecmInfo = ecmInfo;
	}

	public String getTransportType() {
		return transportType;
	}

	public void setTransportType(String transportType) {
		this.transportType = transportType;
	}

	public TsoMigrationLocReferenceData getTsoMigrationLocReferenceData() {
		return tsoMigrationLocReferenceData;
	}

	public void setTsoMigrationLocReferenceData(TsoMigrationLocReferenceData tsoMigrationLocReferenceData) {
		this.tsoMigrationLocReferenceData = tsoMigrationLocReferenceData;
	}

	public String getSubAgencyHierCode() {
		return subAgencyHierCode;
	}

	public void setSubAgencyHierCode(String subAgencyHierCode) {
		this.subAgencyHierCode = subAgencyHierCode;
	}

	public Boolean getIsE2E() {
		return isE2E;
	}

	public void setIsE2E(Boolean isE2E) {
		this.isE2E = isE2E;
	}

	public String getDialingCountryCode() {
		return dialingCountryCode;
	}

	public void setDialingCountryCode(String dialingCountryCode) {
		this.dialingCountryCode = dialingCountryCode;
	}

	public GCMInfo getGcmInfo() {
		return gcmInfo;
	}

	public void setGcmInfo(GCMInfo gcmInfo) {
		this.gcmInfo = gcmInfo;
	}

	public String getPortOutType() {
		return portOutType;
	}

	public void setPortOutType(String portOutType) {
		this.portOutType = portOutType;
	}

	public short getTsoMigLock() {
		return tsoMigLock;
	}

	public void setTsoMigLock(short tsoMigLock) {
		this.tsoMigLock = tsoMigLock;
	}
	
	public void addToprefixPlanName(String prefixPlanNametemp) {
		if (prefixPlanName == null)
			prefixPlanName = new ArrayList<String>();

		if (!prefixPlanName.contains(prefixPlanNametemp))
			this.prefixPlanName.add(prefixPlanNametemp);
	}
	
	public void addTopreselectedVpnName(String preselectedVpnNametemp) {
		if (preselectedVpnName == null)
			preselectedVpnName = new ArrayList<String>();

		if (!preselectedVpnName.contains(preselectedVpnNametemp))
			this.preselectedVpnName.add(preselectedVpnNametemp);
	}

	public boolean isPureHipcLocation() {
	      if (VzbVoipEnums.VoipServiceTypeEnum.HIPC.getAcronym().equals(voipServiceType)
	              && (hybridServiceType == null || hybridServiceType.equals(""))) {
	         return true;
	      } else {
	         return false;
	      }

	   }

	public List<String> getTrunkIds() {
		return TrunkIds;
	}

	public void setTrunkIds(List<String> trunkIds) {
		TrunkIds = trunkIds;
	}

	public long getTnQuantity() {
		return tnQuantity;
	}

	public void setTnQuantity(long tnQuantity) {
		this.tnQuantity = tnQuantity;
	}

	public RedundancyType getRedundancy() {
		return redundancy;
	}

	public void setRedundancy(RedundancyType redundancy) {
		this.redundancy = redundancy;
	}

	
	public RedundancyPriorityType getRedundancyPriorityType() {
		return redundancyPriorityType;
	}

	public void setRedundancyPriorityType(RedundancyPriorityType redundancyPriorityType) {
		this.redundancyPriorityType = redundancyPriorityType;
	}

	public String getEslId() {
		return eslId;
	}

	public void setEslId(String eslId) {
		this.eslId = eslId;
	}

	public String getEblId() {
		return eblId;
	}

	public void setEblId(String eblId) {
		this.eblId = eblId;
	}
	
	public void setRedundancyId(String redundancyId) {
		this.redundancyId = redundancyId;
	}

	public String getRedundancyId() {
		return redundancyId;
	}

	public HashMap<String, Boolean> getAuthServices() {
		return authServices;
	}

	public void setAuthServices(HashMap<String, Boolean> authServices) {
		this.authServices = authServices;
	}
	
	public void addAuthService(String service, Boolean authorised) {
		if (authServices == null)
			authServices = new HashMap<String, Boolean>();

		authServices.put(service, authorised);
	}

	public Session getSession() {
		return session;
	}

	public void setSession(Session session) {
		this.session = session;
	}

	public String getAdminFirstName() {
		return adminFirstName;
	}

	public void setAdminFirstName(String adminFirstName) {
		this.adminFirstName = adminFirstName;
	}

	public String getAdminLastName() {
		return adminLastName;
	}

	public void setAdminLastName(String adminLastName) {
		this.adminLastName = adminLastName;
	}

	public String getAdminEmail() {
		return adminEmail;
	}

	public void setAdminEmail(String adminEmail) {
		this.adminEmail = adminEmail;
	}

	public String getDomainName() {
		return domainName;
	}

	public void setDomainName(String domainName) {
		this.domainName = domainName;
	}

	public String getAdminPassword() {
		return adminPassword;
	}

	public void setAdminPassword(String adminPassword) {
		this.adminPassword = adminPassword;
	}

	public String getAdminWebLoginId() {
		return adminWebLoginId;
	}

	public void setAdminWebLoginId(String adminWebLoginId) {
		this.adminWebLoginId = adminWebLoginId;
	}

	public long getBillingTN() {
		return billingTN;
	}

	public void setBillingTN(long billingTN) {
		this.billingTN = billingTN;
	}

	public String getBroadworksPortalNumber() {
		return broadworksPortalNumber;
	}

	public void setBroadworksPortalNumber(String broadworksPortalNumber) {
		this.broadworksPortalNumber = broadworksPortalNumber;
	}

	public String getGroupUserLimit() {
		return groupUserLimit;
	}

	public void setGroupUserLimit(String groupUserLimit) {
		this.groupUserLimit = groupUserLimit;
	}

	public String getBwEnterpriseId() {
		return bwEnterpriseId;
	}

	public void setBwEnterpriseId(String bwEnterpriseId) {
		this.bwEnterpriseId = bwEnterpriseId;
	}

	public String getBsTimeZone() {
		return bsTimeZone;
	}

	public void setBsTimeZone(String bsTimeZone) {
		this.bsTimeZone = bsTimeZone;
	}

	public SolutionType getSolutionType() {
		return solutionType;
	}

	public void setSolutionType(SolutionType solutionType) {
		this.solutionType = solutionType;
	}

	public AuthFeatureType getAuthFeatureType() {
		return authFeatureType;
	}

	public void setAuthFeatureType(AuthFeatureType authFeatureType) {
		this.authFeatureType = authFeatureType;
	}

	public long getEnvOrderId() {
		return envOrderId;
	}

	public void setEnvOrderId(long envOrderId) {
		this.envOrderId = envOrderId;
	}

	public LocationEntity getLocationEntity() {
		return locationEntity;
	}

	public void setLocationEntity(LocationEntity locationEntity) {
		this.locationEntity = locationEntity;
	}

	public long getMaxActiveCall() {
		return maxActiveCall;
	}

	public void setMaxActiveCall(long maxActiveCall) {
		this.maxActiveCall = maxActiveCall;
	}

	public long getMaxIncomingCall() {
		return maxIncomingCall;
	}

	public void setMaxIncomingCall(long maxIncomingCall) {
		this.maxIncomingCall = maxIncomingCall;
	}

	public long getMaxOutgoingCall() {
		return maxOutgoingCall;
	}

	public void setMaxOutgoingCall(long maxOutgoingCall) {
		this.maxOutgoingCall = maxOutgoingCall;
	}

	@Override
	public String toString() {
		return "LocationEntity [locationId=" + locationId + ", customerId=" + customerId + ", description="
				+ description + ", marketType=" + marketType + ", name=" + name + ", address=" + address + ", city="
				+ city + ", state=" + state + ", zip=" + zip + ", country=" + country + ", timeZone=" + timeZone
				+ ", daylightSavingInd=" + daylightSavingInd + ", webLanguage=" + webLanguage + ", vmLanguage="
				+ vmLanguage + ", contactName=" + contactName + ", contactPhone=" + contactPhone + ", contactEmail="
				+ contactEmail + ", acctTeamName=" + acctTeamName + ", acctTeamPhone=" + acctTeamPhone
				+ ", acctTeamEmail=" + acctTeamEmail + ", sipDomain=" + sipDomain + ", parentDomain=" + parentDomain
				+ ", billingType=" + billingType + ", maxConcurrentCalls=" + maxConcurrentCalls
				+ ", maxConcurrentOffNet=" + maxConcurrentOffNet + ", serviceLevel=" + serviceLevel
				+ ", privateNumberLength=" + privateNumberLength + ", npaNxx=" + npaNxx + ", accessType=" + accessType
				+ ", accessCategory=" + accessCategory + ", sbcAccessType=" + sbcAccessType + ", vpnName=" + vpnName
				+ ", circuitId=" + circuitId + ", locationComment=" + locationComment + ", advantageClub="
				+ advantageClub + ", netcomSvcId=" + netcomSvcId + ", managedFlag=" + managedFlag + ", uunetSiteId="
				+ uunetSiteId + ", totalSubscribers=" + totalSubscribers + ", totalVoiceMailAccts="
				+ totalVoiceMailAccts + ", totalPublicNumbers=" + totalPublicNumbers + ", ixPlusID=" + ixPlusID
				+ ", ixPlusRegion=" + ixPlusRegion + ", callingPartyNumber=" + callingPartyNumber
				+ ", callingPartyPrivacy=" + callingPartyPrivacy + ", stationLevelId=" + stationLevelId
				+ ", bsAppServer=" + bsAppServer + ", extensionLength=" + extensionLength + ", cv2Service=" + cv2Service
				+ ", voipServiceType=" + voipServiceType + ", maxConcurrentSlg=" + maxConcurrentSlg
				+ ", maxConcurrentInbound=" + maxConcurrentInbound + ", hybridServiceType=" + hybridServiceType
				+ ", emergencyCallLine=" + emergencyCallLine + ", enableCallPark=" + enableCallPark
				+ ", overrideSubPrivate=" + overrideSubPrivate + ", overrideCidName=" + overrideCidName
				+ ", overrideCidNum=" + overrideCidNum + ", enableAccountCode=" + enableAccountCode
				+ ", enableAuthCode=" + enableAuthCode + ", blockAllCalls=" + blockAllCalls + ", expedite=" + expedite
				+ ", highVolume=" + highVolume + ", afterHourInstallFee=" + afterHourInstallFee + ", callingNameInd="
				+ callingNameInd + ", enhancedANIInd=" + enhancedANIInd + ", locationCclIndicator="
				+ locationCclIndicator + ", sTn=" + sTn + ", pubIp=" + pubIp + ", pubIpIn=" + pubIpIn + ", pubIpInStr="
				+ pubIpInStr + ", pubIpOut=" + pubIpOut + ", pubIpOutStr=" + pubIpOutStr + ", pubIpStr=" + pubIpStr
				+ ", localDirAssistance=" + localDirAssistance + ", natDirAssistance=" + natDirAssistance + ", maxNg="
				+ maxNg + ", cidTn=" + cidTn + ", trunkType=" + trunkType + ", switchClli=" + switchClli + ", trunk="
				+ trunk + ", publicGtwyDpid=" + publicGtwyDpid + ", defaultGtwyDpid=" + defaultGtwyDpid
				+ ", abbrDialingCode=" + abbrDialingCode + ", sbcEnabled=" + sbcEnabled + ", vmType=" + vmType
				+ ", vmCpeIpAddress=" + vmCpeIpAddress + ", vmSmdiAuthToggle=" + vmSmdiAuthToggle + ", linePortLength="
				+ linePortLength + ", featurePackage=" + featurePackage + ", vmAccessList=" + vmAccessList
				+ ", prefixPlanName=" + prefixPlanName + ", devices=" + devices + ", sipClientEnabledFlag="
				+ sipClientEnabledFlag + ", strSbcId=" + strSbcId + ", strCustFqdn=" + strCustFqdn + ", strCustIpAddr="
				+ strCustIpAddr + ", uNumber=" + uNumber + ", siebelOrder=" + siebelOrder + ", billAcctNum="
				+ billAcctNum + ", intCustPort=" + intCustPort + ", locationFeatures=" + locationFeatures
				+ ", callingPlan=" + callingPlan + ", qosIndicator=" + qosIndicator + ", fmcLocation=" + fmcLocation
				+ ", typeOfLoc=" + typeOfLoc + ", hubLocationId=" + hubLocationId + ", productionIndicator="
				+ productionIndicator + ", accountAuthCodes=" + accountAuthCodes + ", emerLocationCode="
				+ emerLocationCode + ", hubGatewayDeviceId=" + hubGatewayDeviceId + ", locationMask=" + locationMask
				+ ", aNumMask=" + aNumMask + ", bNumMask=" + bNumMask + ", digitStrings=" + digitStrings
				+ ", sbcProvMethod=" + sbcProvMethod + ", altCallerIdFlag=" + altCallerIdFlag + ", rivCustomer="
				+ rivCustomer + ", preselectedVpnName=" + preselectedVpnName + ", territory=" + territory
				+ ", locRegion=" + locRegion + ", PBBAN=" + PBBAN + ", billingSystem=" + billingSystem
				+ ", iasaOrderId=" + iasaOrderId + ", prefixPlanId=" + prefixPlanId + ", emerLocCodeId=" + emerLocCodeId
				+ ", configAllowed=" + configAllowed + ", productId=" + productId + ", VARRS=" + VARRS
				+ ", billingActivated=" + billingActivated + ", physicalLocationId=" + physicalLocationId
				+ ", physicalLocationName=" + physicalLocationName + ", callForwardPlanName=" + callForwardPlanName
				+ ", enterpriseTrunkId=" + enterpriseTrunkId + ", pqInstanceId=" + pqInstanceId + ", designId="
				+ designId + ", pendingRPID=" + pendingRPID + ", migrationType=" + migrationType + ", vce=" + vce
				+ ", emerNumber=" + emerNumber + ", emerMappingCode=" + emerMappingCode + ", addressID=" + addressID
				+ ", emerLocationCodeId=" + emerLocationCodeId + ", clin=" + clin + ", ecmInfo=" + ecmInfo
				+ ", TrunkIds=" + TrunkIds + ", transportType=" + transportType + ", tsoMigrationLocReferenceData="
				+ tsoMigrationLocReferenceData + ", subAgencyHierCode=" + subAgencyHierCode + ", isE2E=" + isE2E
				+ ", dialingCountryCode=" + dialingCountryCode + ", gcmInfo=" + gcmInfo + ", portOutType=" + portOutType
				+ ", tsoMigLock=" + tsoMigLock + ", tnQuantity=" + tnQuantity + ", redundancy=" + redundancy
				+ ", redundancyId=" + redundancyId + ", redundancyPriorityType=" + redundancyPriorityType + ", eslId="
				+ eslId + ", eblId=" + eblId + ", authServices=" + authServices + ", session=" + session
				+ ", adminFirstName=" + adminFirstName + ", adminLastName=" + adminLastName + ", adminEmail="
				+ adminEmail + ", domainName=" + domainName + ", adminPassword=" + adminPassword + ", adminWebLoginId="
				+ adminWebLoginId + ", billingTN=" + billingTN + ", broadworksPortalNumber=" + broadworksPortalNumber
				+ ", groupUserLimit=" + groupUserLimit + ", bwEnterpriseId=" + bwEnterpriseId + ", bsTimeZone="
				+ bsTimeZone + ", region=" + region + ", solutionType=" + solutionType + ", authFeatureType="
				+ authFeatureType + ", vpnPortSpeed=" + vpnPortSpeed + ", portSpeed=" + portSpeed + ", vpnPortType="
				+ vpnPortType + ", envOrderId=" + envOrderId + ", maxActiveCall=" + maxActiveCall + ", maxIncomingCall="
				+ maxIncomingCall + ", maxOutgoingCall=" + maxOutgoingCall + ", vgeCont=" + vgeCont + "]";
	}

	public int getLocationType() {
		return locationType;
	}

	public void setLocationType(int locationType) {
		this.locationType = locationType;
	}

	public long getMaxActiveCalls() {
		return maxActiveCalls;
	}

	public void setMaxActiveCalls(long maxActiveCalls) {
		this.maxActiveCalls = maxActiveCalls;
	}

	public long getMaxActiveIncomingCalls() {
		return maxActiveIncomingCalls;
	}

	public void setMaxActiveIncomingCalls(long maxActiveIncomingCalls) {
		this.maxActiveIncomingCalls = maxActiveIncomingCalls;
	}

	public long getMaxActiveOutgoingCalls() {
		return maxActiveOutgoingCalls;
	}

	public void setMaxActiveOutgoingCalls(long maxActiveOutgoingCalls) {
		this.maxActiveOutgoingCalls = maxActiveOutgoingCalls;
	}

	public long getInternalOrderId() {
		return internalOrderId;
	}

	public void setInternalOrderId(long internalOrderId) {
		this.internalOrderId = internalOrderId;
	}

	public String getBwLocationId() {
		return bwLocationId;
	}

	public void setBwLocationId(String bwLocationId) {
		this.bwLocationId = bwLocationId;
	}

	public String getProvisionCategory() {
		return provisionCategory;
	}

	public void setProvisionCategory(String provisionCategory) {
		this.provisionCategory = provisionCategory;
	}

	public String getPreBuildLocId() {
		return preBuildLocId;
	}

	public void setPreBuildLocId(String preBuildLocId) {
		this.preBuildLocId = preBuildLocId;
	}

	public String getEsbcSignalingIP() {
		return esbcSignalingIP;
	}

	public void setEsbcSignalingIP(String esbcSignalingIP) {
		this.esbcSignalingIP = esbcSignalingIP;
	}

	public List<AuthService> getAuthService() {
		return authService;
	}

	public void setAuthService(List<AuthService> authService) {
		this.authService = authService;
	}
	
	public void prepareAuthService(String name, String featureQuantity, Boolean authorise) {
		if(authService == null)
			authService = new ArrayList<>();
		
		AuthService authService1= new AuthService();
		authService1.setName(name);
		authService1.setFeatureQuantity(featureQuantity);
		authService1.setAuthorise(authorise);
		
		authService.add(authService1);
	}
	
	public String getAsClli() {
		return asClli;
	}

	public void setAsClli(String asClli) {
		this.asClli = asClli;
	}
}
