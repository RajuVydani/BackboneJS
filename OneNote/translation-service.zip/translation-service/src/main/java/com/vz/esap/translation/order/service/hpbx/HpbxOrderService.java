package com.vz.esap.translation.order.service.hpbx;

import java.util.Map;

import com.vz.esap.translation.exception.GenericException;
import com.vz.esap.translation.exception.TranslatorException;
import com.vz.esap.translation.order.model.request.VOIPOrderRequest;
import com.vz.esap.translation.order.model.response.VoipOrderResponse;

public interface HpbxOrderService {

	/**
	 * @param voipOrderRequest
	 * @param productDetails
	 * @return
	 * @throws GenericException
	 * @throws TranslatorException
	 */
	VoipOrderResponse createHpbxValidateOrder(VOIPOrderRequest voipOrderRequest, Map<String, String> productDetails)
			throws GenericException, TranslatorException;

	/**
	 * @param voipOrderRequest
	 * @param productDetails
	 * @return
	 * @throws TranslatorException
	 * @throws GenericException
	 */
	VoipOrderResponse createHpbxReleaseOrder(VOIPOrderRequest voipOrderRequest, Map<String, String> productDetails)
			throws TranslatorException, GenericException;
	
	/**
	 * @param voipOrderRequest
	 * @param productDetails
	 * @return
	 * @throws TranslatorException
	 * @throws GenericException
	 */
	VoipOrderResponse createHpbxLocSuspendOrder(VOIPOrderRequest voipOrderRequest, Map<String, String> productDetails)
			throws TranslatorException, GenericException;

	/**
	 * @param voipOrderRequest
	 * @param productDetails
	 * @return
	 * @throws TranslatorException
	 * @throws GenericException
	 */
	VoipOrderResponse createHpbxLocDeactivateOrder(VOIPOrderRequest voipOrderRequest,
			Map<String, String> productDetails) throws TranslatorException, GenericException;
}
