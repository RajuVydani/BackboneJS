package com.vz.esap.translation.order.transformer;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Component;

import com.vz.esap.translation.entity.CustomerEntity;
import com.vz.esap.translation.exception.ApplicationInterfaceException;
import com.vz.esap.translation.exception.GenericException;
import com.vz.esap.translation.exception.TranslatorException;
import com.vz.esap.translation.order.model.request.VOIPOrderRequest;

@Component
public interface CustomerTransformer {

	/**
	 * @param orderId
	 * @param parentId
	 * @param action
	 * @param delta
	 * @return customerEntity
	 * @throws TranslatorException
	 */
	CustomerEntity transformOrderDetailsToCustomer(long orderId, long parentId, String action, boolean delta, List<String> paramActionExclusionList)
			throws TranslatorException;

	/**
	 * 
	 * @param voipOrderRequest
	 * @param customerEntity
	 * @return
	 * @throws IllegalAccessException
	 * @throws ApplicationInterfaceException
	 * @throws TranslatorException
	 * @throws GenericException
	 */
	CustomerEntity enrichCustomerEntityWithInventory(VOIPOrderRequest voipOrderRequest, CustomerEntity customerEntity)
			throws IllegalAccessException, ApplicationInterfaceException, TranslatorException, GenericException;

	/**
	 * 
	 * 
	 * @param resultantRow
	 * @return
	 */
	CustomerEntity customerEntityInventoryTocustomerEntityTransformer(Map<String, String> resultantRow);

}
