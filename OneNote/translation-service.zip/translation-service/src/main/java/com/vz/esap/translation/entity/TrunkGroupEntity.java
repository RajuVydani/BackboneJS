package com.vz.esap.translation.entity;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.TreeMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.vz.esap.translation.enums.EsapEnum.AuthFeatureType;
import com.vz.esap.translation.enums.EsapEnum.OrderEntity;
import com.vz.esap.translation.enums.EsapEnum.SolutionType;
import com.vz.esap.translation.order.service.esl.EslOrderServiceImpl;

import EsapEnumPkg.TNEnum;
import EsapEnumPkg.VzbVoipEnum;

public class TrunkGroupEntity extends Entity {

	private static final Logger LOG = LoggerFactory.getLogger(EslOrderServiceImpl.class);

	protected Long groupId;
	protected GroupType groupType;
	protected String locationId;
	protected String customerId;
	protected String departmentId;
	protected String name;
	protected String clidFirstName;
	protected String clidLastName;
	protected String tnCLIDFirstName;
	protected String tnCLIDLastName;
	protected String simpleFeaturePackage;
	protected ArrayList<String> disableFeatureList;
	private String linePort;
	protected DeviceEntity device;

	protected Long forwardToGroupId;
	protected String forwardToGroupName;
	protected Integer invitationTimer;
	protected ArrayList<String> nonPkgFeatures;
	private boolean isNewTrunk; 
	protected BigInteger maxConcurrentCallLimit;
	protected String terminationOption;
	protected String forwardToNumber;
	protected String vmNumber;
	protected String vmType;
	protected String vmPin;
	protected String extension;
	protected String privateNumber;
	protected String pilotTN;
	protected TreeMap<Integer, TNEntity> keyTNs;
	private Integer linePortLength;
	private String region;
	private AuthFeatureType authFeatureType;
	protected TrunkGroupEntity trunkGroupEntity;
	private String asClli;
	
	public TrunkGroupEntity getTrunkGroupEntity() {
		return trunkGroupEntity;
	}

	public void setTrunkGroupEntity(TrunkGroupEntity trunkGroupEntity) {
		this.trunkGroupEntity = trunkGroupEntity;
	}

	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	/*
	 * IEAN- intra Enterprise Alias Number - is a new feature for Enhanced IP
	 * centrex customers (new and existing)
	 */
	private Boolean autoflag;
	private Integer ieanLength;

	private String lastActiveTN;
	private String firstActiveTN;
	private Boolean createExtension;
	private Long pqInstanceId;
	private String provisionCategory;
	private String enterpriseId;
	private String maxActiveCalls;
	private String maxIncomingCalls;
	private String maxOutgoingCalls;
	private String enableBursting;
	private String burstingMaxActiveCalls;
	private String burstingMaxIncomingCalls;
	private String burstingMaxOutgoingCalls;
	private String allowedUnscreenedCalls;
	private String requireAuthentication;
	private String otgDtgIdentity;
	private String sipAuthenticationUserName;
	private String sipAuthenticationPassword;
	private String continuousOptionsSendingIntervalSeconds;
	private String failureOptionsSendingIntervalSeconds;
	private String failureThresholdCounter;
	private String successThresholdCounter;
	private String inviteFailureThresholdWindowSeconds;
	private String useSystemCallingLineIdentityPolicy;
	private String useSystemCLIDForScreenedCallsPolicy;
	private String useSystemUserLookupPolicy;
	private String callingLineIdPhoneNumber;
	private long trunkCallCapacity;
	private String timeZone;
//xoo
	private String committedSessionCount;
	private String internationalLDRestriction;
	private String pilotTn;
	private String signalingDirection;
	private PilotUser pilotUser;
	private String bwTrunkGroupId;
	private String burstingMaxActiveCallsUnlimited;
	private SolutionType solutionType;
	private String virtualTrunkId;
	private Long envOrderId;
	private Long internalOrderId;;

	public Long getGroupId() {
		return groupId;
	}

	public void setGroupId(Long groupId) {
		this.groupId = groupId;
	}

	public GroupType getGroupType() {
		return groupType;
	}

	public void setGroupType(GroupType groupType) {
		this.groupType = groupType;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getLocationId() {
		return locationId;
	}

	public void setLocationId(String locationId) {
		this.locationId = locationId;
	}

	public String getDepartmentId() {
		return departmentId;
	}

	public void setDepartmentId(String departmentId) {
		this.departmentId = departmentId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Long getGatewayDeviceId() {
		if (device == null)
			return null;
		else
			return device.getDeviceSeqId();
	}

	public void setGatewayDeviceId(Long gatewayDeviceId) {
		if (device == null)
			device = new DeviceEntity();

		this.device.setDeviceSeqId(gatewayDeviceId);
	}

	public Long getDeviceMapId() {
		if (device == null)
			return null;
		else
			return device.getDeviceMapId();
	}

	public void setDeviceMapId(Long deviceMapId) {
		if (device == null)
			device = new DeviceEntity();

		this.device.setDeviceMapId(deviceMapId);
	}

	public String getGatewayDeviceName() {
		if (device == null)
			return null;
		else
			return device.getDeviceName();
	}

	public void setGatewayDeviceName(String gatewayDeviceName) {
		if (device == null)
			device = new DeviceEntity();

		this.device.setDeviceName(gatewayDeviceName);
	}

	public void setDeviceNameId(String deviceNameId) {
		if (device == null)
			device = new DeviceEntity();

		this.device.setDeviceNameId(deviceNameId);
	}

	public String getDeviceNameId() {
		if (device == null)
			return null;
		else
			return device.getDeviceNameId();
	}

	public DeviceEntity getDevice() {
		return device;
	}

	public void setDevice(DeviceEntity device) {
		this.device = device;
	}

	public String getLinePort() {
		return linePort;
	}

	public void setLinePort(String linePort) {
		this.linePort = linePort;
	}

	public String getCLIDFirstName() {
		return clidFirstName;
	}

	public void setCLIDFirstName(String clidFirstName) {
		this.clidFirstName = clidFirstName;
	}

	public String getCLIDLastName() {
		return clidLastName;
	}

	public void setCLIDLastName(String clidLastName) {
		this.clidLastName = clidLastName;
	}

	public String getTnCLIDFirstName() {
		return tnCLIDFirstName;
	}

	public void setTnCLIDFirstName(String tnCLIDFirstName) {
		this.tnCLIDFirstName = tnCLIDFirstName;
	}

	public String getTnCLIDLastName() {
		return tnCLIDLastName;
	}

	public void setTnCLIDLastName(String tnCLIDLastName) {
		this.tnCLIDLastName = tnCLIDLastName;
	}

	public String getSimpleFeaturePackage() {
		if (null != getGroupType()) {
			if (getGroupType().equals(Entity.GroupType.PBX)) {
				simpleFeaturePackage = "ICP_SIMPLE_PBX";
			} else if (getGroupType().equals(Entity.GroupType.KEY))
				simpleFeaturePackage = "ICP_SIMPLE_KEY";
		}
		return simpleFeaturePackage;
	}

	public void setSimpleFeaturePackage(String simpleFeaturePackage) {
		this.simpleFeaturePackage = simpleFeaturePackage;
	}

	public ArrayList<String> getDisableFeatureList() {
		return disableFeatureList;
	}

	public void setDisableFeatureList(ArrayList<String> disableFeatureList) {
		this.disableFeatureList = disableFeatureList;
	}

	public void addDisableFeature(String disableFeature) {
		if (disableFeatureList == null)
			disableFeatureList = new ArrayList<String>();

		disableFeatureList.add(disableFeature);
	}

	public BigInteger getMaxConcurrentCallLimit() {
		return maxConcurrentCallLimit;
	}

	public void setMaxConcurrentCallLimit(BigInteger maxConcurrentCallLimit) {
		this.maxConcurrentCallLimit = maxConcurrentCallLimit;
	}

	public String getTerminationOption() {
		return terminationOption;
	}

	public void setTerminationOption(String terminationOption) {
		this.terminationOption = terminationOption;
	}

	public String getForwardToNumber() {
		return forwardToNumber;
	}

	public void setForwardToNumber(String forwardToNumber) {
		this.forwardToNumber = forwardToNumber;
	}

	public String getVMNumber() {
		return vmNumber;
	}

	public void setVMNumber(String vmNumber) {
		this.vmNumber = vmNumber;
	}

	public String getVmPin() {
		return vmPin;
	}

	public void setVmPin(String vmPin) {
		this.vmPin = vmPin;
	}

	public String getVMType() {
		return vmType;
	}

	public void setVMType(String vmType) {
		if ("20".equals(vmType) || "50".equals(vmType) || "0".equals(vmType))
			this.vmType = vmType;
		else
			this.vmType = null;
	}

	public String getExtension() {
		return extension;
	}

	public void setExtension(String extension) {
		this.extension = extension;
	}

	public String getPrivateNumber() {
		return privateNumber;
	}

	public void setPrivateNumber(String privateNumber) {
		this.privateNumber = privateNumber;
	}

	public void setFirstActiveTN(String firstActiveTN) {
		this.firstActiveTN = firstActiveTN;
	}

	public String getFirstActiveTN() {
		if (null == this.firstActiveTN) {
			this.firstActiveTN = getFirstActiveTN(keyTNs);
		}
		return this.firstActiveTN;
	}

	public String getFirstActiveTN(TreeMap<Integer, TNEntity> keyTNs) {

		if (keyTNs != null)
			for (Map.Entry<Integer, TNEntity> entry : keyTNs.entrySet())
				if (!"Y".equals(entry.getValue().getPortingFlag())
						&& !(entry.getValue().getTransitionType() == TNEnum.TransitionType.R2R
								|| entry.getValue().getTransitionType() == TNEnum.TransitionType.W2R
								|| entry.getValue().getTransitionType() == TNEnum.TransitionType.V2R))

					return entry.getValue().getTn();

		return null;
	}

	public void setLastActiveTN(String lastActiveTN) {
		this.lastActiveTN = lastActiveTN;
	}

	public String getLastActiveTN() {
		if (null == lastActiveTN) {
			if (keyTNs != null)
				for (Map.Entry<Integer, TNEntity> entry : keyTNs.entrySet())
					if (!"Y".equals(entry.getValue().getPortingFlag())
							&& !(entry.getValue().getTransitionType() == TNEnum.TransitionType.R2R
									|| entry.getValue().getTransitionType() == TNEnum.TransitionType.W2R
									|| entry.getValue().getTransitionType() == TNEnum.TransitionType.V2R))

						lastActiveTN = entry.getValue().getTn();
		}
		return lastActiveTN;
	}

	public String getLastPortPendingTN() {
		String lastPortPendingTN = null;
		if (keyTNs != null)
			for (Map.Entry<Integer, TNEntity> entry : keyTNs.entrySet())
				lastPortPendingTN = entry.getValue().getTn();

		return lastPortPendingTN;
	}

	public String getPilotTN() {
		return pilotTN;
	}

	public void setPilotTN(String pilotTN) {
		this.pilotTN = pilotTN;
	}

	public Integer getLinePortLength() {
		return linePortLength;
	}

	public void setLinePortLength(Integer linePortLength) {
		this.linePortLength = linePortLength;
	}

	public TreeMap<Integer, TNEntity> getKeyTNs() {
		return keyTNs;
	}

	public void setKeyTNs(TreeMap<Integer, TNEntity> keyTNs) {
		this.keyTNs = keyTNs;
	}

	public void addToKeyTNs(Integer seqNo, TNEntity tnRecord) {
		if (keyTNs == null)
			keyTNs = new TreeMap<Integer, TNEntity>();

		this.keyTNs.put(seqNo, tnRecord);
	}

	public int getEntityType() {
		LOG.info("Group Type ++++1111 : {}", groupType);
		if (groupType.equals(GroupType.PBX))
			return OrderEntity.PBX.getIndex();
		else if (groupType.equals(GroupType.TWO_WAY))
			return OrderEntity.TWO_WAY.getIndex();
		else if (groupType.equals(GroupType.INBOUND))
			return OrderEntity.INBOUND.getIndex();
		else if (groupType.equals(GroupType.PRI_DID))
			return OrderEntity.PRI_DID.getIndex();
		else if (groupType.equals(GroupType.NON_PRI_DID))
			return OrderEntity.NON_PRI_DID.getIndex();
		else if (groupType.equals(GroupType.LINE))
			return OrderEntity.LINE.getIndex();
		else if (groupType.equals(GroupType.KEY))
			return OrderEntity.KEY.getIndex();
		else
			return 0;
	}

	public String getEntityId() {
		if (groupId != null)
			return groupId.toString();
		else
			return null;
	}

	public String getEntityName() {
		return name;
	}

	public HashSet<ParentEntity> getParentList() {
		addParentToList(new ParentEntity(VzbVoipEnum.OrderEntity.ENTERPRISE, null, customerId));
		addParentToList(new ParentEntity(VzbVoipEnum.OrderEntity.LOCATION, null, locationId));
		if (device != null)
			addParentToList(new ParentEntity(VzbVoipEnum.OrderEntity.DEVICE, device.getDeviceName(),
					device.getDeviceMapId() == null ? null : device.getDeviceMapId().toString()));

		return super.getParentList();
	}

	public Long getForwardToGroupId() {
		return forwardToGroupId;
	}

	public void setForwardToGroupId(Long forwardToGroupId) {
		this.forwardToGroupId = forwardToGroupId;
	}

	public String getForwardToGroupName() {
		return forwardToGroupName;
	}

	public void setForwardToGroupName(String forwardToGroupName) {
		this.forwardToGroupName = forwardToGroupName;
	}

	public ArrayList<String> getNonPkgFeatures() {
		return nonPkgFeatures;
	}

	public boolean hasNonPkgFeature(String nonPkgFeat) {
		if (nonPkgFeatures == null)
			return false;
		else
			return nonPkgFeatures.contains(nonPkgFeat);
	}

	public void removeNonPkgFeature(String nonPkgFeat) {
		if (nonPkgFeatures != null)
			nonPkgFeatures.remove(nonPkgFeat);
	}

	public void setNonPkgFeatures(ArrayList<String> nonPkgFeatures) {
		this.nonPkgFeatures = nonPkgFeatures;
	}

	public void addNonPkgFeature(String nonPkgFeature) {
		if (this.nonPkgFeatures == null)
			this.nonPkgFeatures = new ArrayList<String>();

		this.nonPkgFeatures.add(nonPkgFeature);
	}

	public String getAutoflagString() {
		if (null != autoflag) {
			if (autoflag == true) {
				return "Y";
			} else {
				return "N";
			}
		}
		return null;
	}

	public Boolean getAutoflag() {
		return autoflag;
	}

	public void setAutoflag(Boolean autoflag) {
		this.autoflag = autoflag;
	}

	public Integer getIeanLength() {
		return ieanLength;
	}

	// public void setIeanLength(Integer ieanLength)throws OrderManagerException {
	// if(null != ieanLength) {
	// if(ieanLength < 5 || ieanLength > 11) {
	// throw new OrderManagerException(ErrorCode.INVALID_IEAN_LENGTH, "Invalid IEAN
	// Length, length should be between 5 and 11");
	// }
	// }
	// this.ieanLength = ieanLength;
	// }

	public boolean isIEANLengthChange() {
		if (null != autoflag && autoflag == true) {
			if (null != ieanLength && ieanLength > 0) {
				return true;
			}
		}
		return false;
	}

	@Override
	public boolean isContainer() {
		return true;
	}

	@Override
	public boolean isDeleteCascade() {
		return true;
	}

	public Integer getInvitationTimer() {
		return invitationTimer;
	}

	public void setInvitationTimer(Integer invitationTimer) {
		this.invitationTimer = invitationTimer;
	}

	public Boolean getCreateExtension() {
		return createExtension;
	}

	public void setCreateExtension(Boolean createExtension) {
		this.createExtension = createExtension;
	}

	public void removeKeyTn(String delTn) {

		TNEntity tnRec = new TNEntity();
		tnRec.setTn(delTn);

		if (keyTNs != null) {
			TreeMap<Integer, TNEntity> tmpKeyTns = new TreeMap<Integer, TNEntity>();
			int found = 0;
			for (Map.Entry<Integer, TNEntity> entry : keyTNs.entrySet()) {
				if (entry.getValue().equals(tnRec)) {
					found = 1;
					continue;
				}
				tmpKeyTns.put(entry.getKey() - found, entry.getValue());
			}
			keyTNs = tmpKeyTns;
		}

	}

	public void addKeyTn(TNEntity tnRecord) {
		if (keyTNs == null)
			keyTNs = new TreeMap<Integer, TNEntity>();

		if (keyTNs.size() == 0) {
			keyTNs.put(1, tnRecord);
		} else {
			// Add at second from end
			int lastIdx = keyTNs.size();
			TNEntity currentLastTn = keyTNs.get(lastIdx);
			keyTNs.put(lastIdx, tnRecord);
			keyTNs.put(lastIdx + 1, currentLastTn);
		}
	}

	/*
	 * @deprecated
	 */
	public ArrayList<String> getTnList() {
		if (keyTNs == null)
			return null;
		ArrayList<String> ret = new ArrayList<String>();
		if (keyTNs.size() <= 0)
			return ret;
		Iterator<Map.Entry<Integer, TNEntity>> itr = keyTNs.entrySet().iterator();
		while (itr.hasNext())
			ret.add(itr.next().getValue().getTn());
		return ret;
	}

	/*
	 * @deprecated
	 */
	public void setTnList(ArrayList<String> tnList) {
		// How to convert from String to TN?
		return;
	}

	public void update(TrunkGroupEntity trunkGrp) {

		if (trunkGrp.getName() != null)
			name = trunkGrp.getName();

		if (trunkGrp.getCLIDFirstName() != null)
			clidFirstName = trunkGrp.getCLIDFirstName();

		if (trunkGrp.getCLIDLastName() != null)
			clidLastName = trunkGrp.getCLIDLastName();

		if (trunkGrp.getTnCLIDFirstName() != null)
			tnCLIDFirstName = trunkGrp.getTnCLIDFirstName();

		if (trunkGrp.getTnCLIDLastName() != null)
			tnCLIDLastName = trunkGrp.getTnCLIDLastName();

		if (trunkGrp.getDisableFeatureList() != null) {
			disableFeatureList = trunkGrp.getDisableFeatureList();
		}

		if (trunkGrp.getLinePort() != null) {
			linePort = trunkGrp.getLinePort();
		}

		if (trunkGrp.getDevice() != null) {
			device = trunkGrp.getDevice();
		}

		if (trunkGrp.getForwardToGroupId() != null) {
			forwardToGroupId = trunkGrp.getForwardToGroupId();
		}

		if (trunkGrp.getForwardToNumber() != null)
			forwardToGroupName = trunkGrp.getForwardToGroupName();

		if (trunkGrp.getInvitationTimer() != null)
			invitationTimer = trunkGrp.getInvitationTimer();

		if (trunkGrp.getNonPkgFeatures() != null)
			nonPkgFeatures = trunkGrp.getNonPkgFeatures();

		if (trunkGrp.getMaxConcurrentCallLimit() != null)
			maxConcurrentCallLimit = trunkGrp.getMaxConcurrentCallLimit();

		if (trunkGrp.getTerminationOption() != null)
			terminationOption = trunkGrp.getTerminationOption();

		if (trunkGrp.getForwardToNumber() != null)
			forwardToNumber = trunkGrp.getForwardToNumber();

		if (trunkGrp.getVMNumber() != null)
			vmNumber = trunkGrp.getVMNumber();

		if (trunkGrp.getVMType() != null)
			vmType = trunkGrp.getVMType();

		if (trunkGrp.getVmPin() != null)
			vmPin = trunkGrp.getVmPin();

		if (trunkGrp.getExtension() != null)
			extension = trunkGrp.getExtension();

		if (trunkGrp.getPrivateNumber() != null)
			privateNumber = trunkGrp.getPrivateNumber();

		if (trunkGrp.getPilotTN() != null)
			pilotTN = trunkGrp.getPilotTN();

		if (trunkGrp.getKeyTNs() != null)
			keyTNs = trunkGrp.getKeyTNs();

		if (trunkGrp.getLinePortLength() != null)
			linePortLength = trunkGrp.getLinePortLength();

		if (trunkGrp.getAutoflag() != null)
			autoflag = trunkGrp.getAutoflag();

		if (trunkGrp.getIeanLength() != null)
			ieanLength = trunkGrp.getIeanLength();

		if (trunkGrp.getLastActiveTN() != null)
			lastActiveTN = trunkGrp.getLastActiveTN();

		if (trunkGrp.getFirstActiveTN() != null)
			firstActiveTN = trunkGrp.getFirstActiveTN();

		if (trunkGrp.getCreateExtension() != null)
			createExtension = trunkGrp.getCreateExtension();

		if (trunkGrp.getPqInstanceId() != null)
			pqInstanceId = trunkGrp.getPqInstanceId();

	}

	public Long getPqInstanceId() {
		return pqInstanceId;
	}

	public void setPqInstanceId(Long instanceId) {
		this.pqInstanceId = instanceId;
	}

	public void addToNonPkgFeatures(String nonPkgFeaturestemp) {
		if (nonPkgFeatures == null)
			nonPkgFeatures = new ArrayList<String>();

		if (!nonPkgFeatures.contains(nonPkgFeaturestemp))
			this.nonPkgFeatures.add(nonPkgFeaturestemp);
	}

	public void addToDisableFeatureList(String disableFeature) {
		if (disableFeatureList == null)
			disableFeatureList = new ArrayList<String>();

		if (!disableFeatureList.contains(disableFeature))
			this.disableFeatureList.add(disableFeature);
	}

	public String getClidFirstName() {
		return clidFirstName;
	}

	public void setClidFirstName(String clidFirstName) {
		this.clidFirstName = clidFirstName;
	}

	public String getClidLastName() {
		return clidLastName;
	}

	public void setClidLastName(String clidLastName) {
		this.clidLastName = clidLastName;
	}

	public String getVmNumber() {
		return vmNumber;
	}

	public void setVmNumber(String vmNumber) {
		this.vmNumber = vmNumber;
	}

	public String getVmType() {
		return vmType;
	}

	public void setVmType(String vmType) {
		this.vmType = vmType;
	}

	public String getEnterpriseId() {
		return enterpriseId;
	}

	public void setEnterpriseId(String enterpriseId) {
		this.enterpriseId = enterpriseId;
	}

	public String getMaxActiveCalls() {
		return maxActiveCalls;
	}

	public void setMaxActiveCalls(String maxActiveCalls) {
		this.maxActiveCalls = maxActiveCalls;
	}

	public String getMaxIncomingCalls() {
		return maxIncomingCalls;
	}

	public void setMaxIncomingCalls(String maxIncomingCalls) {
		this.maxIncomingCalls = maxIncomingCalls;
	}

	public String getMaxOutgoingCalls() {
		return maxOutgoingCalls;
	}

	public void setMaxOutgoingCalls(String maxOutgoingCalls) {
		this.maxOutgoingCalls = maxOutgoingCalls;
	}

	public String getEnableBursting() {
		return enableBursting;
	}

	public void setEnableBursting(String enableBursting) {
		this.enableBursting = enableBursting;
	}

	public String getBurstingMaxActiveCalls() {
		return burstingMaxActiveCalls;
	}

	public void setBurstingMaxActiveCalls(String burstingMaxActiveCalls) {
		this.burstingMaxActiveCalls = burstingMaxActiveCalls;
	}

	public String getBurstingMaxIncomingCalls() {
		return burstingMaxIncomingCalls;
	}

	public void setBurstingMaxIncomingCalls(String burstingMaxIncomingCalls) {
		this.burstingMaxIncomingCalls = burstingMaxIncomingCalls;
	}

	public String getBurstingMaxOutgoingCalls() {
		return burstingMaxOutgoingCalls;
	}

	public void setBurstingMaxOutgoingCalls(String burstingMaxOutgoingCalls) {
		this.burstingMaxOutgoingCalls = burstingMaxOutgoingCalls;
	}

	public String getAllowedUnscreenedCalls() {
		return allowedUnscreenedCalls;
	}

	public void setAllowedUnscreenedCalls(String allowedUnscreenedCalls) {
		this.allowedUnscreenedCalls = allowedUnscreenedCalls;
	}

	public String getRequireAuthentication() {
		return requireAuthentication;
	}

	public void setRequireAuthentication(String requireAuthentication) {
		this.requireAuthentication = requireAuthentication;
	}

	public String getOtgDtgIdentity() {
		return otgDtgIdentity;
	}

	public void setOtgDtgIdentity(String otgDtgIdentity) {
		this.otgDtgIdentity = otgDtgIdentity;
	}

	public String getSipAuthenticationUserName() {
		return sipAuthenticationUserName;
	}

	public void setSipAuthenticationUserName(String sipAuthenticationUserName) {
		this.sipAuthenticationUserName = sipAuthenticationUserName;
	}

	public String getSipAuthenticationPassword() {
		return sipAuthenticationPassword;
	}

	public void setSipAuthenticationPassword(String sipAuthenticationPassword) {
		this.sipAuthenticationPassword = sipAuthenticationPassword;
	}

	public String getContinuousOptionsSendingIntervalSeconds() {
		return continuousOptionsSendingIntervalSeconds;
	}

	public void setContinuousOptionsSendingIntervalSeconds(String continuousOptionsSendingIntervalSeconds) {
		this.continuousOptionsSendingIntervalSeconds = continuousOptionsSendingIntervalSeconds;
	}

	public String getFailureOptionsSendingIntervalSeconds() {
		return failureOptionsSendingIntervalSeconds;
	}

	public void setFailureOptionsSendingIntervalSeconds(String failureOptionsSendingIntervalSeconds) {
		this.failureOptionsSendingIntervalSeconds = failureOptionsSendingIntervalSeconds;
	}

	public String getFailureThresholdCounter() {
		return failureThresholdCounter;
	}

	public void setFailureThresholdCounter(String failureThresholdCounter) {
		this.failureThresholdCounter = failureThresholdCounter;
	}

	public String getSuccessThresholdCounter() {
		return successThresholdCounter;
	}

	public void setSuccessThresholdCounter(String successThresholdCounter) {
		this.successThresholdCounter = successThresholdCounter;
	}

	public String getInviteFailureThresholdWindowSeconds() {
		return inviteFailureThresholdWindowSeconds;
	}

	public void setInviteFailureThresholdWindowSeconds(String inviteFailureThresholdWindowSeconds) {
		this.inviteFailureThresholdWindowSeconds = inviteFailureThresholdWindowSeconds;
	}

	public String getUseSystemCallingLineIdentityPolicy() {
		return useSystemCallingLineIdentityPolicy;
	}

	public void setUseSystemCallingLineIdentityPolicy(String useSystemCallingLineIdentityPolicy) {
		this.useSystemCallingLineIdentityPolicy = useSystemCallingLineIdentityPolicy;
	}

	public String getUseSystemCLIDForScreenedCallsPolicy() {
		return useSystemCLIDForScreenedCallsPolicy;
	}

	public void setUseSystemCLIDForScreenedCallsPolicy(String useSystemCLIDForScreenedCallsPolicy) {
		this.useSystemCLIDForScreenedCallsPolicy = useSystemCLIDForScreenedCallsPolicy;
	}

	public String getUseSystemUserLookupPolicy() {
		return useSystemUserLookupPolicy;
	}

	public void setUseSystemUserLookupPolicy(String useSystemUserLookupPolicy) {
		this.useSystemUserLookupPolicy = useSystemUserLookupPolicy;
	}

	public String getCallingLineIdPhoneNumber() {
		return callingLineIdPhoneNumber;
	}

	public void setCallingLineIdPhoneNumber(String callingLineIdPhoneNumber) {
		this.callingLineIdPhoneNumber = callingLineIdPhoneNumber;
	}

	public long getTrunkCallCapacity() {
		return trunkCallCapacity;
	}

	public void setTrunkCallCapacity(long trunkCallCapacity) {
		this.trunkCallCapacity = trunkCallCapacity;
	}

	public String getTimeZone() {
		return timeZone;
	}

	public void setTimeZone(String timeZone) {
		this.timeZone = timeZone;
	}

	public String getCommittedSessionCount() {
		return committedSessionCount;
	}

	public void setCommittedSessionCount(String committedSessionCount) {
		this.committedSessionCount = committedSessionCount;
	}

	public String getInternationalLDRestriction() {
		return internationalLDRestriction;
	}

	public void setInternationalLDRestriction(String internationalLDRestriction) {
		this.internationalLDRestriction = internationalLDRestriction;
	}

	public String getPilotTn() {
		return pilotTn;
	}

	public void setPilotTn(String pilotTn) {
		this.pilotTn = pilotTn;
	}

	public String getSignalingDirection() {
		return signalingDirection;
	}

	public void setSignalingDirection(String signalingDirection) {
		this.signalingDirection = signalingDirection;
	}

	public PilotUser getPilotUser() {
		return pilotUser;
	}

	public void setPilotUser(PilotUser pilotUser) {
		this.pilotUser = pilotUser;
	}

	public void setIeanLength(Integer ieanLength) {
		this.ieanLength = ieanLength;
	}

	public String getBwTrunkGroupId() {
		return bwTrunkGroupId;
	}

	public void setBwTrunkGroupId(String bwTrunkGroupId) {
		this.bwTrunkGroupId = bwTrunkGroupId;
	}

	public String getBurstingMaxActiveCallsUnlimited() {
		return burstingMaxActiveCallsUnlimited;
	}

	public void setBurstingMaxActiveCallsUnlimited(String burstingMaxActiveCallsUnlimited) {
		this.burstingMaxActiveCallsUnlimited = burstingMaxActiveCallsUnlimited;
	}

	public SolutionType getSolutionType() {
		return solutionType;
	}

	public void setSolutionType(SolutionType solutionType) {
		this.solutionType = solutionType;
	}

	public String getVirtualTrunkId() {
		return virtualTrunkId;
	}

	public void setVirtualTrunkId(String virtualTrunkId) {
		this.virtualTrunkId = virtualTrunkId;
	}

	public Long getEnvOrderId() {
		return envOrderId;
	}

	public void setEnvOrderId(Long envOrderId) {
		this.envOrderId = envOrderId;
	}

	@Override
	public String toString() {
		return "TrunkGroupEntity [groupId=" + groupId + ", groupType=" + groupType + ", locationId=" + locationId
				+ ", customerId=" + customerId + ", departmentId=" + departmentId + ", name=" + name
				+ ", clidFirstName=" + clidFirstName + ", clidLastName=" + clidLastName + ", tnCLIDFirstName="
				+ tnCLIDFirstName + ", tnCLIDLastName=" + tnCLIDLastName + ", simpleFeaturePackage="
				+ simpleFeaturePackage + ", disableFeatureList=" + disableFeatureList + ", linePort=" + linePort
				+ ", device=" + device + ", forwardToGroupId=" + forwardToGroupId + ", forwardToGroupName="
				+ forwardToGroupName + ", invitationTimer=" + invitationTimer + ", nonPkgFeatures=" + nonPkgFeatures
				+ ", maxConcurrentCallLimit=" + maxConcurrentCallLimit + ", terminationOption=" + terminationOption
				+ ", forwardToNumber=" + forwardToNumber + ", vmNumber=" + vmNumber + ", vmType=" + vmType + ", vmPin="
				+ vmPin + ", extension=" + extension + ", privateNumber=" + privateNumber + ", pilotTN=" + pilotTN
				+ ", keyTNs=" + keyTNs + ", linePortLength=" + linePortLength + ", region=" + region
				+ ", trunkGroupEntity=" + trunkGroupEntity + ", autoflag=" + autoflag + ", ieanLength=" + ieanLength
				+ ", lastActiveTN=" + lastActiveTN + ", firstActiveTN=" + firstActiveTN + ", createExtension="
				+ createExtension + ", pqInstanceId=" + pqInstanceId + ", enterpriseId=" + enterpriseId
				+ ", maxActiveCalls=" + maxActiveCalls + ", maxIncomingCalls=" + maxIncomingCalls
				+ ", maxOutgoingCalls=" + maxOutgoingCalls + ", enableBursting=" + enableBursting
				+ ", burstingMaxActiveCalls=" + burstingMaxActiveCalls + ", burstingMaxIncomingCalls="
				+ burstingMaxIncomingCalls + ", burstingMaxOutgoingCalls=" + burstingMaxOutgoingCalls
				+ ", allowedUnscreenedCalls=" + allowedUnscreenedCalls + ", requireAuthentication="
				+ requireAuthentication + ", otgDtgIdentity=" + otgDtgIdentity + ", sipAuthenticationUserName="
				+ sipAuthenticationUserName + ", sipAuthenticationPassword=" + sipAuthenticationPassword
				+ ", continuousOptionsSendingIntervalSeconds=" + continuousOptionsSendingIntervalSeconds
				+ ", failureOptionsSendingIntervalSeconds=" + failureOptionsSendingIntervalSeconds
				+ ", failureThresholdCounter=" + failureThresholdCounter + ", successThresholdCounter="
				+ successThresholdCounter + ", inviteFailureThresholdWindowSeconds="
				+ inviteFailureThresholdWindowSeconds + ", useSystemCallingLineIdentityPolicy="
				+ useSystemCallingLineIdentityPolicy + ", useSystemCLIDForScreenedCallsPolicy="
				+ useSystemCLIDForScreenedCallsPolicy + ", useSystemUserLookupPolicy=" + useSystemUserLookupPolicy
				+ ", callingLineIdPhoneNumber=" + callingLineIdPhoneNumber + ", trunkCallCapacity=" + trunkCallCapacity
				+ ", timeZone=" + timeZone + ", committedSessionCount=" + committedSessionCount
				+ ", internationalLDRestriction=" + internationalLDRestriction + ", pilotTn=" + pilotTn
				+ ", signalingDirection=" + signalingDirection + ", pilotUser=" + pilotUser + ", bwTrunkGroupId="
				+ bwTrunkGroupId + ", burstingMaxActiveCallsUnlimited=" + burstingMaxActiveCallsUnlimited
				+ ", solutionType=" + solutionType + ", virtualTrunkId=" + virtualTrunkId + ", envOrderId=" + envOrderId
				+ ", authFeatureType=" + authFeatureType + "]";
	}

	public Long getInternalOrderId() {
		return internalOrderId;
	}

	public void setInternalOrderId(Long internalOrderId) {
		this.internalOrderId = internalOrderId;
	}

	public String getProvisionCategory() {
		return provisionCategory;
	}

	public void setProvisionCategory(String provisionCategory) {
		this.provisionCategory = provisionCategory;
	}

	public boolean isNewTrunk() {
		return isNewTrunk;
	}

	public void setNewTrunk(boolean isNewTrunk) {
		this.isNewTrunk = isNewTrunk;
	}
	
	public AuthFeatureType getAuthFeatureType() {
		return authFeatureType;
	}

	public void setAuthFeatureType(AuthFeatureType authFeatureType) {
		this.authFeatureType = authFeatureType;
	}
	
	public String getAsClli() {
		return asClli;
	}

	public void setAsClli(String asClli) {
		this.asClli = asClli;
	}
}
