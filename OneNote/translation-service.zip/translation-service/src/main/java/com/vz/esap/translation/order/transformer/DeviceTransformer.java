package com.vz.esap.translation.order.transformer;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Component;

import com.vz.esap.translation.entity.DeviceEntity;
import com.vz.esap.translation.exception.ApplicationInterfaceException;
import com.vz.esap.translation.exception.GenericException;
import com.vz.esap.translation.exception.TranslatorException;
import com.vz.esap.translation.order.model.request.VOIPOrderRequest;

/**
 * @author kalagsu
 *
 */
@Component
public interface DeviceTransformer {
	/**
	 * @param orderId
	 * @param parentId
	 * @param action
	 * @param delta
	 * @return deviceEntity
	 * @throws TranslatorException
	 */
	DeviceEntity transformOrderDetailsToDevice(long orderId, long parentId, String action, boolean delta, List<String> paramActionExclusionList)
			throws TranslatorException;

	DeviceEntity enrichDeviceEntityWithInventory(VOIPOrderRequest voipOrderRequest, DeviceEntity deviceEntity)
			throws TranslatorException, GenericException, IllegalAccessException, ApplicationInterfaceException;

	DeviceEntity deviceInventoryToDeviceEntityTransformer(Map<String, String> resultantRow);

}
