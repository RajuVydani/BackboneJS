package com.vz.esap.translation.order.transformer;

import java.util.Map;

import com.vz.esap.translation.dao.model.TblOrder;
import com.vz.esap.translation.exception.GenericException;

/**
 * @author chattni
 *
 */
public interface CommonTblOrderTransformer {

	/**
	 * @param tblOrder
	 * @param mapForUpdate
	 * @return TblOrder
	 * @throws GenericException 
	 */
	TblOrder prepareTblOrderDataFromExistingTblOrder(TblOrder tblOrder, Map<String, String> mapForUpdate) throws GenericException;

}
