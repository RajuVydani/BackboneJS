
package com.vz.esap.translation.connector.dto;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "columnMetaData", "dbOperation", "numberOfRecords", "queryId", "queryReferenceId", "rowDataList",
		"rows", "sourceService", "sqlKey", "status", "statusDesc", "tableName" })
public class DBOperationResponse {

	@JsonProperty("columnMetaData")
	private ColumnMetaData_ columnMetaData;

	@JsonProperty("dbOperation")
	private String dbOperation;

	@JsonProperty("numberOfRecords")
	private Long numberOfRecords;

	@JsonProperty("queryId")
	private String queryId;

	@JsonProperty("queryReferenceId")
	private Long queryReferenceId;

	@JsonProperty("rowDataList")
	private List<RowDataList_> rowDataList = new ArrayList<RowDataList_>();

	@JsonProperty("rows")
	private List<Row> rows = new ArrayList<Row>();

	@JsonProperty("sourceService")
	private String sourceService;

	@JsonProperty("sqlKey")
	private String sqlKey;

	@JsonProperty("status")
	private String status;

	@JsonProperty("statusDesc")
	private String statusDesc;

	@JsonProperty("tableName")
	private String tableName;

	@JsonIgnore
	private Map<String, Object> additionalProperties = new HashMap<String, Object>();

	@JsonProperty("columnMetaData")
	public ColumnMetaData_ getColumnMetaData() {
		return columnMetaData;
	}

	@JsonProperty("columnMetaData")
	public void setColumnMetaData(ColumnMetaData_ columnMetaData) {
		this.columnMetaData = columnMetaData;
	}

	@JsonProperty("dbOperation")
	public String getDbOperation() {
		return dbOperation;
	}

	@JsonProperty("dbOperation")
	public void setDbOperation(String dbOperation) {
		this.dbOperation = dbOperation;
	}

	@JsonProperty("numberOfRecords")
	public Long getNumberOfRecords() {
		return numberOfRecords;
	}

	@JsonProperty("numberOfRecords")
	public void setNumberOfRecords(Long numberOfRecords) {
		this.numberOfRecords = numberOfRecords;
	}

	@JsonProperty("queryId")
	public String getQueryId() {
		return queryId;
	}

	@JsonProperty("queryId")
	public void setQueryId(String queryId) {
		this.queryId = queryId;
	}

	@JsonProperty("queryReferenceId")
	public Long getQueryReferenceId() {
		return queryReferenceId;
	}

	@JsonProperty("queryReferenceId")
	public void setQueryReferenceId(Long queryReferenceId) {
		this.queryReferenceId = queryReferenceId;
	}

	@JsonProperty("rowDataList")
	public List<RowDataList_> getRowDataList() {
		return rowDataList;
	}

	@JsonProperty("rowDataList")
	public void setRowDataList(List<RowDataList_> rowDataList) {
		this.rowDataList = rowDataList;
	}

	@JsonProperty("rows")
	public List<Row> getRows() {
		return rows;
	}

	@JsonProperty("rows")
	public void setRows(List<Row> rows) {
		this.rows = rows;
	}

	@JsonProperty("sourceService")
	public String getSourceService() {
		return sourceService;
	}

	@JsonProperty("sourceService")
	public void setSourceService(String sourceService) {
		this.sourceService = sourceService;
	}

	@JsonProperty("sqlKey")
	public String getSqlKey() {
		return sqlKey;
	}

	@JsonProperty("sqlKey")
	public void setSqlKey(String sqlKey) {
		this.sqlKey = sqlKey;
	}

	@JsonProperty("status")
	public String getStatus() {
		return status;
	}

	@JsonProperty("status")
	public void setStatus(String status) {
		this.status = status;
	}

	@JsonProperty("statusDesc")
	public String getStatusDesc() {
		return statusDesc;
	}

	@JsonProperty("statusDesc")
	public void setStatusDesc(String statusDesc) {
		this.statusDesc = statusDesc;
	}

	@JsonProperty("tableName")
	public String getTableName() {
		return tableName;
	}

	@JsonProperty("tableName")
	public void setTableName(String tableName) {
		this.tableName = tableName;
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}

	@JsonAnyGetter
	public Map<String, Object> getAdditionalProperties() {
		return this.additionalProperties;
	}

	@JsonAnySetter
	public void setAdditionalProperty(String name, Object value) {
		this.additionalProperties.put(name, value);
	}

	@Override
	public int hashCode() {
		return new HashCodeBuilder().append(columnMetaData).append(dbOperation).append(numberOfRecords).append(queryId)
				.append(queryReferenceId).append(rowDataList).append(rows).append(sourceService).append(sqlKey)
				.append(status).append(statusDesc).append(tableName).append(additionalProperties).toHashCode();
	}

	@Override
	public boolean equals(Object other) {
		if (other == this) {
			return true;
		}
		if ((other instanceof DBOperationResponse) == false) {
			return false;
		}
		DBOperationResponse rhs = ((DBOperationResponse) other);
		return new EqualsBuilder().append(columnMetaData, rhs.columnMetaData).append(dbOperation, rhs.dbOperation)
				.append(numberOfRecords, rhs.numberOfRecords).append(queryId, rhs.queryId)
				.append(queryReferenceId, rhs.queryReferenceId).append(rowDataList, rhs.rowDataList)
				.append(rows, rhs.rows).append(sourceService, rhs.sourceService).append(sqlKey, rhs.sqlKey)
				.append(status, rhs.status).append(statusDesc, rhs.statusDesc).append(tableName, rhs.tableName)
				.append(additionalProperties, rhs.additionalProperties).isEquals();
	}

}
