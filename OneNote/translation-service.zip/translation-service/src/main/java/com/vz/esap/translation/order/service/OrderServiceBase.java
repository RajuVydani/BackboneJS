package com.vz.esap.translation.order.service;

import static java.util.Arrays.stream;

import java.math.BigInteger;
import java.text.ParseException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.FieldError;

import com.vz.esap.translation.dao.model.TblEnvOrder;
import com.vz.esap.translation.dao.model.TblEnvOrderDetails;
import com.vz.esap.translation.dao.model.TblOrder;
import com.vz.esap.translation.dao.model.TblOrderDetails;
import com.vz.esap.translation.dao.repository.CustomCustomerMapper;
import com.vz.esap.translation.entity.CustomerEntity;
import com.vz.esap.translation.entity.DeviceEntity;
import com.vz.esap.translation.entity.EnterpriseTrunkEntity;
import com.vz.esap.translation.entity.GroupTNEntity;
import com.vz.esap.translation.entity.LocationEntity;
import com.vz.esap.translation.entity.NbsEntity;
import com.vz.esap.translation.entity.TrunkGroupEntity;
import com.vz.esap.translation.enums.EsapEnum.OrderType;
import com.vz.esap.translation.enums.EsapEnum.SolutionType;
import com.vz.esap.translation.exception.BadRequestException;
import com.vz.esap.translation.exception.GenericException;
import com.vz.esap.translation.exception.TranslatorException;
import com.vz.esap.translation.exception.TranslatorException.ErrorCode;
import com.vz.esap.translation.order.dao.VOIPOrderDao;
import com.vz.esap.translation.order.model.Order;
import com.vz.esap.translation.order.model.OrderHeader;
import com.vz.esap.translation.order.model.OrderHeader.SuppType;
import com.vz.esap.translation.order.model.request.Communication;
import com.vz.esap.translation.order.model.request.ParamInfo;
import com.vz.esap.translation.order.model.request.TsoMigrationEntReferenceData;
import com.vz.esap.translation.order.model.request.VOIPOrderRequest;
import com.vz.esap.translation.order.parser.LocationOrderParser;
import com.vz.esap.translation.order.parser.NbsOrderParser;
import com.vz.esap.translation.order.transformer.CustomerTransformer;
import com.vz.esap.translation.order.transformer.EnterpriseEnvelopOrderTransformer;
import com.vz.esap.translation.order.transformer.LocationTblOrderDetailsDataTransformerImpl;
import com.vz.esap.translation.order.transformer.NbsTblOrderDetailsDataTransformerImpl;
import com.vz.esap.translation.order.transformer.TblEnvOrderDetailsTransformer;

import EsapEnumPkg.VzbVoipEnum;

/**
 * @author chattni
 *
 */
public class OrderServiceBase {

	@Autowired
	private TblEnvOrderDetailsTransformer tblEnvOrderDetailsTransformer;

	@Autowired
	public VOIPOrderDao voipOrderDaoImpl;

	@Autowired
	private CustomCustomerMapper customCustomerMapper;

	@Autowired
	private EnterpriseEnvelopOrderTransformer enterpriseEnvelopOrderData;

	@Autowired
	private CustomerTransformer customerTransformer;

	@Autowired
	public LocationOrderParser locationOrderParser;

	@Autowired
	public NbsOrderParser nbsOrderParserImpl;

	@Autowired
	public VOIPResponseGenerator voipResponseGeneratorImpl;

	@Autowired
	public NbsTblOrderDetailsDataTransformerImpl nbsTblOrderDetailsDataTransformerImpl;

	@Autowired
	public LocationTblOrderDetailsDataTransformerImpl locationTblOrderDetailsDataTransformerImpl;

	public static final Logger LOG = LoggerFactory.getLogger(OrderServiceBase.class);

	/**
	 * @param tblOrderDetails
	 * @param tblOrderBeanValidation
	 * @param voipOrderRequest
	 * @param status
	 * @return tblEnvOrder
	 * @throws GenericException
	 */
	public TblEnvOrder createTblEnvOrder(TblOrderDetails tblOrderDetails, TblOrder tblOrderBeanValidation,
			VOIPOrderRequest voipOrderRequest, int status) throws GenericException {

		LOG.info("Entered - createTblEnvOrder");

		TblEnvOrder tblEnvOrder = null;
		Order order = null;
		OrderHeader orderHeader = null;
		CustomerEntity customerEntity = null;
		long count = -1;
		try {
			if (!"C".equalsIgnoreCase(voipOrderRequest.getOrderHeader().getOrderType())) {
				customerEntity = customerTransformer.transformOrderDetailsToCustomer(
						tblOrderBeanValidation.getOrderId(), tblOrderDetails.getOrderDetailId(), "n", false, null);

				if (customerEntity == null) {
					throw new TranslatorException(ErrorCode.CT_TRANSFORMATION_FAILURE,
							"Failed to Retrieve the Customer Entity");
				}
				LOG.info("CustomerEntity  : {} ", customerEntity);
			}

			orderHeader = createdOrderHeaderForEnterpriseOrder(voipOrderRequest, customerEntity);
			order = new Order();
			orderHeader.setOrderStatus(status);
			order.setOrderHeader(orderHeader);

			tblEnvOrder = enterpriseEnvelopOrderData.createTblEnvOrderFromOrder(order, null);
			count = voipOrderDaoImpl.createEnvelopOrder(tblEnvOrder);
			if (count <= 0) {
				throw new TranslatorException(ErrorCode.ORDER_CREATION_FAILURE, "Failed To Create Order");
			}
		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new GenericException(GenericException.GENERIC_EXCEPTION, "Exception occured - createTblEnvOrder");
		}
		LOG.info("Exit - createTblEnvOrder");
		return tblEnvOrder;

	}

	/**
	 * @param envOrderId
	 * @param voipOrderRequest
	 * @return count
	 * @throws GenericException
	 */
	public long createEnvOrderDetailsOrderManagerInfo(long envOrderId, VOIPOrderRequest voipOrderRequest)
			throws GenericException {

		LOG.info("Entered - createEnvOrderDetailsOrderManagerInfo");
		String paramName = null;
		String paramValue = null;
		long count = -1;
		TblEnvOrderDetails tblEnvOrderDetails = null;
		Communication[] communicationList = null;
		try {

			if (voipOrderRequest.getLocation() != null
					&& voipOrderRequest.getLocation().getOrderManagerContact() != null) {

				if (voipOrderRequest.getLocation().getOrderManagerContact().getContactFirstName() != null) {
					paramName = "OrderManagerFirstName";
					paramValue = voipOrderRequest.getLocation().getOrderManagerContact().getContactFirstName();

					tblEnvOrderDetails = tblEnvOrderDetailsTransformer.prepareTblEnvOrderDetails(envOrderId, null, 0L,
							"P", null, paramName, paramValue, 0L, 0L, 1L);
					count = voipOrderDaoImpl.createEnvOrderDetails(tblEnvOrderDetails);
				}
				if (voipOrderRequest.getLocation().getOrderManagerContact().getContactLastName() != null) {
					paramName = "OrderManagerLastName";
					paramValue = voipOrderRequest.getLocation().getOrderManagerContact().getContactLastName();

					tblEnvOrderDetails = tblEnvOrderDetailsTransformer.prepareTblEnvOrderDetails(envOrderId, null, 0L,
							"P", null, paramName, paramValue, 0L, 0L, 1L);
					count = voipOrderDaoImpl.createEnvOrderDetails(tblEnvOrderDetails);
				}
				if (voipOrderRequest.getLocation().getOrderManagerContact().getCommunication() != null) {
					communicationList = voipOrderRequest.getLocation().getOrderManagerContact().getCommunication();
					stream(communicationList).forEach(communication -> {
						if (communication.getChannel() != null
								&& "PHONE".equalsIgnoreCase(communication.getChannel())) {
							TblEnvOrderDetails tblEnvOrderDetailsLoc = tblEnvOrderDetailsTransformer
									.prepareTblEnvOrderDetails(envOrderId, null, 0L, "P", null, "OrderManagerPhone",
											communication.getCountryDialing().concat(communication.getAreaDialing())
													.concat(communication.getDialNumber()),
											0L, 0L, 1L);
							voipOrderDaoImpl.createEnvOrderDetails(tblEnvOrderDetailsLoc);
						}
						if (communication.getChannel() != null
								&& "EMAIL".equalsIgnoreCase(communication.getChannel())) {
							TblEnvOrderDetails tblEnvOrderDetailsLoc = tblEnvOrderDetailsTransformer
									.prepareTblEnvOrderDetails(envOrderId, null, 0L, "P", null, "OrderManagerEmail",
											communication.getURI(), 0L, 0L, 1L);
							voipOrderDaoImpl.createEnvOrderDetails(tblEnvOrderDetailsLoc);
						}
					});

				}
			}

		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new GenericException(GenericException.GENERIC_EXCEPTION,
					"Exception occured - createEnvOrderDetailsOrderManagerInfo");
		}
		LOG.info("Exit - createEnvOrderDetailsOrderManagerInfo");

		return count;
	}

	/**
	 * @param voipOrderRequest
	 * @param customer
	 */
	protected void populateCustomerRegion(VOIPOrderRequest voipOrderRequest, CustomerEntity customer) {
		LOG.info("Entered - populateCustomerRegion");
		if (customer != null && customer.getVirtualAddrCountry() != null
				&& !"US".equalsIgnoreCase(customer.getVirtualAddrCountry())) {
			// get region from tbl_country_province based on CountryCode
			String region = getCustomerRegionBasedOnCountry(customer.getVirtualAddrCountry());
			if (region != null) {
				voipOrderRequest.getOrderHeader().setRegion(region);
				customer.setRegionType(
						VzbVoipEnum.RegionType.valueByAcronym(voipOrderRequest.getOrderHeader().getRegion()));
			}
		}
		LOG.info("Exited - populateCustomerRegion");
	}

	/**
	 * @param tsoMigrationRefData
	 */
	protected void populateOldCustomerId(TsoMigrationEntReferenceData tsoMigrationRefData) {
		LOG.info("Entered - OrderServiceImpl - populateOldCustomerId");
		String oldEnterpriseId = null;
		if (null != tsoMigrationRefData && null != tsoMigrationRefData.getEnterpriseReferenceId()) {
			oldEnterpriseId = getOldEnterpriseIdForTSOMgration(tsoMigrationRefData.getEnterpriseReferenceId());
			if (null != oldEnterpriseId)
				tsoMigrationRefData.setOldEnterpriseId(oldEnterpriseId);
		}
		LOG.info("Exit - populateOldCustomerId");
	}

	/**
	 * @param customer
	 * @return dataCheck
	 */
	protected String checkDataIntegrity(CustomerEntity customer) {
		LOG.info("Entered - checkDataIntegratity");
		String dataCheck = null;
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("CustomerId", customer.getCustomerId());

		long customerDataCount = customCustomerMapper.getCustomerCount(params);
		if (customerDataCount > 0) {
			dataCheck = "CustomerEntity already exists for :" + customer.getCustomerId();
		}
		LOG.info("Exit - checkDataIntegratity");
		return dataCheck;
	}

	/**
	 * @param voipOrderRequest
	 * @param customerEntity
	 * @return orderHeader
	 * @throws GenericException
	 */
	public OrderHeader createdOrderHeaderForEnterpriseOrder(VOIPOrderRequest voipOrderRequest,
			CustomerEntity customerEntity) throws GenericException {
		LOG.info("Entered - createdOrderHeaderForEnterpriseOrder");
		OrderHeader orderHeader = null;
		try {
			orderHeader = new OrderHeader();

			if ("I".equalsIgnoreCase(voipOrderRequest.getOrderHeader().getOrderType()))
				voipOrderRequest.getOrderHeader().setMinorOrderType("INSTALL");
			if (voipOrderRequest.getOrderHeader().getWorkOrderNumber() != null)
				orderHeader.setOrderNumber(voipOrderRequest.getOrderHeader().getWorkOrderNumber());
			if (voipOrderRequest.getOrderHeader().getOriginatingSystem() != null)
				orderHeader.setOriginatingSystem(voipOrderRequest.getOrderHeader().getOriginatingSystem());
			if (voipOrderRequest.getOrderHeader().getWorkOrderVersion() != null)
				orderHeader.setOrderVersion(voipOrderRequest.getOrderHeader().getWorkOrderVersion());
			if (voipOrderRequest.getOrderHeader().getOrderType() != null)
				orderHeader.setOrderType(voipOrderRequest.getOrderHeader().getOrderType());
			if (voipOrderRequest.getOrderHeader().getFunctionCode() != null)
				orderHeader.setFunctionCode(voipOrderRequest.getOrderHeader().getFunctionCode());
			if (voipOrderRequest.getOrderHeader().getSuppType() != null)
				orderHeader.setSuppType(voipOrderRequest.getOrderHeader().getSuppType());
			if (voipOrderRequest.getOrderHeader().getInterfaceSystem() != null)
				orderHeader.setInterfaceSystem(voipOrderRequest.getOrderHeader().getInterfaceSystem());
			if (voipOrderRequest.getSequenceNumber() > 0)
				orderHeader.setSequenceNumber(voipOrderRequest.getSequenceNumber());
			if (null != voipOrderRequest.getOrderHeader().getTransactionID())
				orderHeader.setTransactionId(new BigInteger(voipOrderRequest.getOrderHeader().getTransactionID()));

			if (customerEntity != null && customerEntity.getRegionType() != null) {
				orderHeader.setRegion(VzbVoipEnum.RegionType.acronym(customerEntity.getRegionType()));
			} else {
				orderHeader.setRegion(voipOrderRequest.getOrderHeader().getRegion());
			}
			if (customerEntity != null && customerEntity.getCentrexType() != null)
				orderHeader.setCentrexType(VzbVoipEnum.CentrexType.acronym(customerEntity.getCentrexType()));
			else
				orderHeader
						.setCentrexType(VzbVoipEnum.CentrexType.acronym(VzbVoipEnum.CentrexType.ENHANCED_IP_CENTREX));
			if (customerEntity != null && customerEntity.getEntityType() > 0)
				orderHeader.setEntityType(customerEntity.getEntityType());

			if ("I".equalsIgnoreCase(voipOrderRequest.getOrderHeader().getOrderType())) {
				orderHeader.setEntityAction("I");
			} else if ("C".equalsIgnoreCase(voipOrderRequest.getOrderHeader().getOrderType())) {
				orderHeader.setEntityAction("C");
			} else if ("D".equalsIgnoreCase(voipOrderRequest.getOrderHeader().getOrderType())) {
				orderHeader.setEntityAction("O");
			}

			orderHeader.setLocationId(voipOrderRequest.getOrderHeader().getVoipLocationId());
			if (voipOrderRequest.getOrderHeader().getUNOServiceId() != null) {
				orderHeader.setMasterOrderNumber(voipOrderRequest.getOrderHeader().getUNOServiceId());
			} else {
				orderHeader.setMasterOrderNumber(voipOrderRequest.getOrderHeader().getWorkOrderNumber());
			}
			// XOO
			if (customerEntity != null) {
				orderHeader.setCustomerId(customerEntity.getCustomerId());
				orderHeader.setEnterpriseId(customerEntity.getCustomerId());
				orderHeader.setAuthFeatureType(customerEntity.getAuthFeatureType());
				orderHeader.setBsAppServer(customerEntity.getBsAppServer());
				orderHeader.setAsClli(customerEntity.getAsClli());
			} else {
				orderHeader.setCustomerId(voipOrderRequest.getOrderHeader().getEnterpriseId());
				orderHeader.setEnterpriseId(voipOrderRequest.getOrderHeader().getEnterpriseId());
				orderHeader.setBsAppServer(voipOrderRequest.getOrderHeader().getBsAppServer());
			}

			orderHeader.setLocationId(voipOrderRequest.getOrderHeader().getVoipLocationId());

			orderHeader.setPriority(voipOrderRequest.getOrderHeader().getPriority());

			if (customerEntity != null && customerEntity.getSolutionType() != null) {
				orderHeader.setSolutionType(customerEntity.getSolutionType());
			} else if (voipOrderRequest.getOrderHeader().getSolutionType() != null) {
				orderHeader.setSolutionType(voipOrderRequest.getOrderHeader().getSolutionType());
			}

			if (voipOrderRequest.getOrderHeader().getGCHId() != null)
				orderHeader.setGchId(voipOrderRequest.getOrderHeader().getGCHId());
			else if (customerEntity != null && customerEntity.getGchId() != null)
				orderHeader.setGchId(customerEntity.getGchId());

		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new GenericException(GenericException.GENERIC_EXCEPTION,
					"Exception occured - createdOrderHeaderForEnterpriseOrder");
		}
		LOG.info("Exit - createdOrderHeaderForEnterpriseOrder");
		return orderHeader;

	}

	/**
	 * @param virtualAddrCountry
	 * @return customerRegion
	 */
	String getCustomerRegionBasedOnCountry(String virtualAddrCountry) {
		LOG.info("Entered - getCustomerRegionBasedOnCountry");
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("VirtualAddrCountry", virtualAddrCountry);
		String customerRegion = customCustomerMapper.getCustomerRegionBasedOnCountry(params);
		LOG.info("Exit - getCustomerRegionBasedOnCountry");
		return customerRegion;
	}

	/**
	 * @param enterpriseReferenceId
	 * @return oldEnterpriseId
	 */
	String getOldEnterpriseIdForTSOMgration(Long enterpriseReferenceId) {
		LOG.info("Entered - getOldEnterpriseIdForTSOMgration");
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("NewEnterpriseId", enterpriseReferenceId);
		String oldEnterpriseId = customCustomerMapper.getOldEnterpriseIdForTSOMgration(params);
		LOG.info("Exit - getOldEnterpriseIdForTSOMgration");
		return oldEnterpriseId;
	}

	/**
	 * @param voipOrderRequest
	 * @param locationEntity
	 * @return orderHeader
	 * @throws GenericException
	 */
	public OrderHeader createdOrderHeaderForLocationOrder(VOIPOrderRequest voipOrderRequest,
			LocationEntity locationEntity) throws GenericException {
		LOG.info("Entered - createdOrderHeaderForLocationOrder");
		OrderHeader orderHeader = null;
		try {

			orderHeader = mapVoipRequestToOrderHeader(voipOrderRequest);

			if (locationEntity.getRegion() != null) {
				// locfix
				// orderHeader.setRegion(VzbVoipEnum.RegionType.acronym(1));// Fix for release
				orderHeader.setRegion(locationEntity.getRegion());
			} else {
				orderHeader.setRegion("US");
			}
			if (voipOrderRequest.getOrderHeader().getVoipLocationId() != null) {
				orderHeader.setLocationId(voipOrderRequest.getOrderHeader().getVoipLocationId());
			} else if (locationEntity.getLocationId() != null) {
				orderHeader.setLocationId(locationEntity.getLocationId());
			}
			if (locationEntity.getEntityType() > 0)
				orderHeader.setEntityType(locationEntity.getEntityType());

			if ("I".equalsIgnoreCase(voipOrderRequest.getOrderHeader().getOrderType())) {
				orderHeader.setEntityAction("I");
			} else if ("C".equalsIgnoreCase(voipOrderRequest.getOrderHeader().getOrderType())) {
				orderHeader.setEntityAction("C");
			} else if ("D".equalsIgnoreCase(voipOrderRequest.getOrderHeader().getOrderType())) {
				orderHeader.setEntityAction("O");
			}

			if (locationEntity.getLocationId() != null) {
				orderHeader.setLocationId(locationEntity.getLocationId());
			} else {
				orderHeader.setLocationId(voipOrderRequest.getOrderHeader().getVoipLocationId());
			}

			orderHeader.setCustomerId(locationEntity.getCustomerId());

			if (locationEntity.getSolutionType() != null) {
				orderHeader.setSolutionType(locationEntity.getSolutionType());
			} else if (voipOrderRequest.getOrderHeader().getSolutionType() != null) {
				orderHeader.setSolutionType(voipOrderRequest.getOrderHeader().getSolutionType());
			}

			if (voipOrderRequest.getOrderHeader().getSuppType() != null) {
				orderHeader.setSuppType(voipOrderRequest.getOrderHeader().getSuppType());
				orderHeader.setSupp(true);

				LOG.info("SUPP Type is : {}", voipOrderRequest.getOrderHeader().getSuppType());
			}
			
				orderHeader.setAsClli(locationEntity.getAsClli());

		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new GenericException(GenericException.GENERIC_EXCEPTION,
					"Exception occured - createdOrderHeaderForLocationOrder");
		}
		LOG.info("Exit - createdOrderHeaderForLocationOrder");
		return orderHeader;
	}

	/**
	 * @param voipOrderRequest
	 * @param enterpriseTrunkEntity
	 * @return orderHeader
	 * @throws GenericException
	 */
	public OrderHeader createdOrderHeaderForEtOrder(VOIPOrderRequest voipOrderRequest,
			EnterpriseTrunkEntity enterpriseTrunkEntity) throws GenericException {
		LOG.info("Entered - createdOrderHeaderForEtOrder");
		OrderHeader orderHeader = null;
		try {

			orderHeader = mapVoipRequestToOrderHeader(voipOrderRequest);

			if (voipOrderRequest.getLocation() != null && voipOrderRequest.getLocation().getLocationAddress() != null
					&& voipOrderRequest.getLocation().getLocationAddress().getCountryCode() != null)
				orderHeader.setRegion(voipOrderRequest.getLocation().getLocationAddress().getCountryCode());

			orderHeader.setCustomerId(enterpriseTrunkEntity.getCustomerId());

			if (enterpriseTrunkEntity.getEntityType() > 0)
				orderHeader.setEntityType(enterpriseTrunkEntity.getEntityType());

			if ("I".equalsIgnoreCase(voipOrderRequest.getOrderHeader().getOrderType())) {
				orderHeader.setEntityAction("I");
			} else if ("C".equalsIgnoreCase(voipOrderRequest.getOrderHeader().getOrderType())) {
				orderHeader.setEntityAction("C");
			}

			orderHeader.setLocationId(voipOrderRequest.getOrderHeader().getVoipLocationId());
			orderHeader.setRegion(enterpriseTrunkEntity.getRegion());

			if (enterpriseTrunkEntity.getSolutionType() != null) {
				orderHeader.setSolutionType(enterpriseTrunkEntity.getSolutionType());
			} else if (voipOrderRequest.getOrderHeader().getSolutionType() != null) {
				orderHeader.setSolutionType(voipOrderRequest.getOrderHeader().getSolutionType());
			}

			if (voipOrderRequest.getOrderHeader().getSuppType() != null) {
				orderHeader.setSuppType(voipOrderRequest.getOrderHeader().getSuppType());
				orderHeader.setSupp(true);

				LOG.info("SUPP Type is : {}", voipOrderRequest.getOrderHeader().getSuppType());
			}
			
				orderHeader.setAsClli(enterpriseTrunkEntity.getAsClli());

		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new GenericException(GenericException.GENERIC_EXCEPTION,
					"Exception occured - CreatedOrderHeaderForEtOrder");
		}
		LOG.info("Exit - createdOrderHeaderForEtOrder");
		return orderHeader;
	}

	/**
	 * @param voipOrderRequest
	 * @param deviceEntity
	 * @return orderHeader
	 * @throws GenericException
	 */
	public OrderHeader createdOrderHeaderForDeviceOrder(VOIPOrderRequest voipOrderRequest, DeviceEntity deviceEntity)
			throws GenericException {
		LOG.info("Entered - createdOrderHeaderForDeviceOrder");
		OrderHeader orderHeader = null;

		try {

			orderHeader = mapVoipRequestToOrderHeader(voipOrderRequest);

			if ("I".equalsIgnoreCase(voipOrderRequest.getOrderHeader().getOrderType())) {
				orderHeader.setEntityAction("I");
			} else if ("C".equalsIgnoreCase(voipOrderRequest.getOrderHeader().getOrderType())) {
				orderHeader.setEntityAction("C");
			}

			if (deviceEntity.getEntityType() > 0)
				orderHeader.setEntityType(deviceEntity.getEntityType());

			orderHeader.setLocationId(voipOrderRequest.getOrderHeader().getVoipLocationId());

			orderHeader.setCustomerId(deviceEntity.getCustomerId());

			if (deviceEntity.getSolutionType() != null) {
				orderHeader.setSolutionType(deviceEntity.getSolutionType());
			} else if (voipOrderRequest.getOrderHeader().getSolutionType() != null) {
				orderHeader.setSolutionType(voipOrderRequest.getOrderHeader().getSolutionType());
			}

			if (deviceEntity.getRegion() != null)
				orderHeader.setRegion(deviceEntity.getRegion());

			if (voipOrderRequest.getOrderHeader().getSuppType() != null) {
				orderHeader.setSuppType(voipOrderRequest.getOrderHeader().getSuppType());
				orderHeader.setSupp(true);

				LOG.info("SUPP Type is : {}", voipOrderRequest.getOrderHeader().getSuppType());
			}
			
				orderHeader.setAsClli(deviceEntity.getAsClli());

		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new GenericException(GenericException.GENERIC_EXCEPTION,
					"Exception occured - createdOrderHeaderForDeviceOrder");
		}

		LOG.info("Exit - createdOrderHeaderForDeviceOrder");
		return orderHeader;
	}

	/**
	 * @param voipOrderRequest
	 * @param groupTnEntity
	 * @return orderHeader
	 * @throws GenericException
	 */
	public OrderHeader createOrderHeaderForGroupTnOrder(VOIPOrderRequest voipOrderRequest, GroupTNEntity groupTnEntity)
			throws GenericException {
		LOG.info("Entered - createOrderHeaderForGroupTnOrder");
		OrderHeader orderHeader = null;

		try {

			orderHeader = mapVoipRequestToOrderHeader(voipOrderRequest);

			if (groupTnEntity.getEntityType() > 0)
				orderHeader.setEntityType(groupTnEntity.getEntityType());

			if (OrderType.getValueReverse("IN").equalsIgnoreCase(voipOrderRequest.getOrderHeader().getOrderType())) {
				orderHeader.setEntityAction("I");

			} else if (OrderType.getValueReverse("CHANGE")
					.equalsIgnoreCase(voipOrderRequest.getOrderHeader().getOrderType())) {
				orderHeader.setEntityAction("C");

			} else if (OrderType.getValueReverse("DISCONNECT")
					.equalsIgnoreCase(voipOrderRequest.getOrderHeader().getOrderType())) {
				orderHeader.setEntityAction("O");

			} else {
				orderHeader.setEntityAction("I");

			}

			orderHeader.setLocationId(voipOrderRequest.getOrderHeader().getVoipLocationId());
			orderHeader.setCustomerId(groupTnEntity.getCustomerId());
			orderHeader.setRegion(groupTnEntity.getRegion());

			if (voipOrderRequest.getOrderHeader().getSolutionType() != null) {
				orderHeader.setSolutionType(voipOrderRequest.getOrderHeader().getSolutionType());
			}

			if (voipOrderRequest.getOrderHeader().getSuppType() != null) {
				orderHeader.setSuppType(voipOrderRequest.getOrderHeader().getSuppType());
				orderHeader.setSupp(true);

				LOG.info("SUPP Type is : {}", voipOrderRequest.getOrderHeader().getSuppType());
			}
			
				orderHeader.setAsClli(groupTnEntity.getAsClli());
			
		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new GenericException(GenericException.GENERIC_EXCEPTION,
					"Exception occured - createOrderHeaderForGroupTnOrder");
		}

		LOG.info("Exit - createOrderHeaderForGroupTnOrder");
		return orderHeader;
	}

	/**
	 * @param voipOrderRequest
	 * @param trunkGroupEntity
	 * @return orderHeader
	 * @throws GenericException
	 */
	public OrderHeader createdOrderHeaderForTrunkOrder(VOIPOrderRequest voipOrderRequest,
			TrunkGroupEntity trunkGroupEntity) throws GenericException {
		LOG.info("Entered - createdOrderHeaderForTrunkOrder");
		OrderHeader orderHeader = null;
		try {

			orderHeader = mapVoipRequestToOrderHeader(voipOrderRequest);

			if (trunkGroupEntity.getEntityType() > 0)
				orderHeader.setEntityType(trunkGroupEntity.getEntityType());

			LOG.info(" +++++++1111++++++++++ trunkGroupEntity.getEntityType() {}", trunkGroupEntity.getEntityType());
			// orderHeader.setEntityAction("I");// : TODO Make this dynamic
			if ("I".equalsIgnoreCase(voipOrderRequest.getOrderHeader().getOrderType())) {
				orderHeader.setEntityAction("I");
			} else if ("C".equalsIgnoreCase(voipOrderRequest.getOrderHeader().getOrderType())) {
				orderHeader.setEntityAction("C");
			}

			if (trunkGroupEntity.getLocationId() != null) {
				orderHeader.setLocationId(trunkGroupEntity.getLocationId());
			} else {
				orderHeader.setLocationId(voipOrderRequest.getOrderHeader().getVoipLocationId());
			}

			if (trunkGroupEntity.getCustomerId() != null) {
				orderHeader.setCustomerId(trunkGroupEntity.getCustomerId());

			} else {
				orderHeader.setCustomerId(trunkGroupEntity.getEnterpriseId());

			}

			if (trunkGroupEntity.getSolutionType() != null) {
				orderHeader.setSolutionType(trunkGroupEntity.getSolutionType());
			} else if (voipOrderRequest.getOrderHeader().getSolutionType() != null) {
				orderHeader.setSolutionType(voipOrderRequest.getOrderHeader().getSolutionType());
			}

			if (voipOrderRequest.getOrderHeader().getSuppType() != null) {
				orderHeader.setSuppType(voipOrderRequest.getOrderHeader().getSuppType());
				orderHeader.setSupp(true);

				LOG.info("SUPP Type is : {}", voipOrderRequest.getOrderHeader().getSuppType());
			}

			if (trunkGroupEntity.getRegion() != null) {
				orderHeader.setRegion(trunkGroupEntity.getRegion());
			} else {
				orderHeader.setRegion("US");
			}
			
				orderHeader.setAsClli(trunkGroupEntity.getAsClli());

		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new GenericException(GenericException.GENERIC_EXCEPTION,
					"Exception occured - createdOrderHeaderForTrunkOrder");
		}
		LOG.info("Exit - createdOrderHeaderForTrunkOrder");
		return orderHeader;
	}

	/**
	 * @param voipOrderRequest
	 * @param nbsEntity
	 * @return orderHeader
	 * @throws GenericException
	 */
	public OrderHeader createdOrderHeaderForNbsOrder(VOIPOrderRequest voipOrderRequest, NbsEntity nbsEntity)
			throws GenericException {
		LOG.info("Entered - createdOrderHeaderForDeviceOrder");
		OrderHeader orderHeader = null;
		try {

			orderHeader = mapVoipRequestToOrderHeader(voipOrderRequest);

			if (nbsEntity.getEntityType() > 0)
				orderHeader.setEntityType(nbsEntity.getEntityType());
			// orderHeader.setEntityAction("I");// : TODO Make this dynamic

			if ("I".equalsIgnoreCase(voipOrderRequest.getOrderHeader().getOrderType())) {
				orderHeader.setEntityAction("I");
			} else if ("C".equalsIgnoreCase(voipOrderRequest.getOrderHeader().getOrderType())) {
				orderHeader.setEntityAction("C");
			}

			orderHeader.setLocationId(voipOrderRequest.getOrderHeader().getLocationId());
			orderHeader.setCustomerId(nbsEntity.getCustomerId());

			if (nbsEntity.getSolutionType() != null) {
				orderHeader.setSolutionType(nbsEntity.getSolutionType());
			} else if (voipOrderRequest.getOrderHeader().getSolutionType() != null) {
				orderHeader.setSolutionType(voipOrderRequest.getOrderHeader().getSolutionType());
			}

			if (voipOrderRequest.getOrderHeader().getSuppType() != null) {
				orderHeader.setSuppType(voipOrderRequest.getOrderHeader().getSuppType());
				orderHeader.setSupp(true);

				LOG.info("SUPP Type is : {}", voipOrderRequest.getOrderHeader().getSuppType());
			}
			
				orderHeader.setAsClli(nbsEntity.getAsClli());

		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new GenericException(GenericException.GENERIC_EXCEPTION,
					"Exception occured - createdOrderHeaderForNbsOrder");
		}
		LOG.info("Exit - createdOrderHeaderForDeviceOrder");
		return orderHeader;
	}

	/**
	 * @param voipOrderRequest
	 * @return orderHeader
	 */
	private OrderHeader mapVoipRequestToOrderHeader(VOIPOrderRequest voipOrderRequest) {

		LOG.info("Entered - mapVoipRequestToOrderHeader");
		OrderHeader orderHeader = new OrderHeader();

		if ("I".equalsIgnoreCase(voipOrderRequest.getOrderHeader().getOrderType()))
			voipOrderRequest.getOrderHeader().setMinorOrderType("INSTALL");
		if (voipOrderRequest.getOrderHeader().getWorkOrderNumber() != null)
			orderHeader.setOrderNumber(voipOrderRequest.getOrderHeader().getWorkOrderNumber());
		if (voipOrderRequest.getOrderHeader().getOriginatingSystem() != null)
			orderHeader.setOriginatingSystem(voipOrderRequest.getOrderHeader().getOriginatingSystem());
		if (voipOrderRequest.getOrderHeader().getWorkOrderVersion() != null)
			orderHeader.setOrderVersion(voipOrderRequest.getOrderHeader().getWorkOrderVersion());
		if (voipOrderRequest.getOrderHeader().getOrderType() != null)
			orderHeader.setOrderType(voipOrderRequest.getOrderHeader().getOrderType());
		if (voipOrderRequest.getOrderHeader().getFunctionCode() != null)
			orderHeader.setFunctionCode(voipOrderRequest.getOrderHeader().getFunctionCode());
		if (voipOrderRequest.getOrderHeader().getSuppType() != null)
			orderHeader.setSuppType(voipOrderRequest.getOrderHeader().getSuppType());
		if (voipOrderRequest.getOrderHeader().getInterfaceSystem() != null)
			orderHeader.setInterfaceSystem(voipOrderRequest.getOrderHeader().getInterfaceSystem());
		if (voipOrderRequest.getSequenceNumber() >= 0)
			orderHeader.setSequenceNumber(voipOrderRequest.getSequenceNumber());
		if (null != voipOrderRequest.getOrderHeader().getTransactionID())
			orderHeader.setTransactionId(new BigInteger(voipOrderRequest.getOrderHeader().getTransactionID()));
		orderHeader.setCentrexType(VzbVoipEnum.CentrexType.acronym(VzbVoipEnum.CentrexType.ENHANCED_IP_CENTREX));

		orderHeader.setOrderVersion(voipOrderRequest.getOrderHeader().getWorkOrderVersion());

		LOG.info("Exited - mapVoipRequestToOrderHeader");
		return orderHeader;
	}

	public VOIPOrderRequest setSolutionTypeInOrderHeader(VOIPOrderRequest voipOrderRequest, String solutionType) {

		LOG.info("Entered - setSolutionTypeInOrderHeader");

		if (voipOrderRequest.getOrderHeader() == null) {
			FieldError fieldError = new FieldError("OrderHeader", "OrderHeader", "OrderHeader is missing");
			throw new BadRequestException(fieldError);
		}
		if (solutionType.equalsIgnoreCase(SolutionType.ESIP_ESL.toString()))
			voipOrderRequest.getOrderHeader().setSolutionType(SolutionType.ESIP_ESL);
		else if (solutionType.equalsIgnoreCase(SolutionType.ESIP_EBL.toString()))
			voipOrderRequest.getOrderHeader().setSolutionType(SolutionType.ESIP_EBL);
		else if (solutionType.equalsIgnoreCase(SolutionType.IPFLEX.toString()))
			voipOrderRequest.getOrderHeader().setSolutionType(SolutionType.IPFLEX);
		else if (solutionType.equalsIgnoreCase(SolutionType.HPBX.toString()))
			voipOrderRequest.getOrderHeader().setSolutionType(SolutionType.HPBX);

		LOG.info("Exited - setSolutionTypeInOrderHeader with Solution Type : {}",
				voipOrderRequest.getOrderHeader().getSolutionType());
		return voipOrderRequest;
	}

	public ParamInfo prepareTblOrdDetHeaderParamDataFromExistingTblOrdDet(List<TblOrderDetails> tblOrderDetailsListOrig,
			String suppType, String action, TblEnvOrder tblEnvOrderCurrent) throws ParseException, TranslatorException {

		LOG.info("Entered - prepareTblOrdDetHeaderParamDataFromExistingTblOrdDet");
		ParamInfo root = null;
		List<String> entities = Arrays.asList("Enterprise", "Location", "Device", "SonusNbs", "EnterpriseTrunk",
				"Group", "TrunkTN", "PREV_ERROR_CODE", "OrderVersion", "EnvOrderId", "TransactionId");
		try {

			if (action == null) {
				if (suppType != null && SuppType.CANCEL.toString().equalsIgnoreCase(suppType))
					action = "c";
			}

			root = new ParamInfo("Header", null, action);

			if (tblEnvOrderCurrent != null) {
				root.addNotNullValChild("EnvOrderId", tblEnvOrderCurrent.getEnvOrderId(), action);
				root.addNotNullValChild("OrderVersion", tblEnvOrderCurrent.getVersionNumber(), action);
				root.addNotNullValChild("TransactionId", tblEnvOrderCurrent.getTransactionId(), action);

			}

			for (TblOrderDetails tblOrderDetailsOrig : tblOrderDetailsListOrig) {

				if ((tblOrderDetailsOrig.getParentId() == null || tblOrderDetailsOrig.getParentId() == 0)
						&& !entities.stream().anyMatch(tblOrderDetailsOrig.getParamName()::equalsIgnoreCase)) {
					root.addNotNullValChild(tblOrderDetailsOrig.getParamName(), tblOrderDetailsOrig.getParamValue(),
							action);

					LOG.info(
							"Copying from Tbl_Order_details for root.getName() = {} and root.getValue() = {} root.getAction() = {} ",
							root.getName(), root.getValue(), root.getAction());
				}
			}

		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new TranslatorException(ErrorCode.TRANSFORMER_FAILURE,
					"Exception occured in prepareTblOrdDetHeaderParamDataFromExistingTblOrdDet");
		}
		LOG.info("Exit - prepareTblOrdDetHeaderParamDataFromExistingTblOrdDet");
		return root;
	}

	public ParamInfo prepareTblOrdDetEntityParamDataFromExistingTblOrdDet(List<TblOrderDetails> tblOrderDetailsListOrig,
			String suppType, String action) {
		LOG.info("Entered - prepareTblOrdDetEntityParamDataFromExistingTblOrdDet For Entity = {} ",
				tblOrderDetailsListOrig.get(0).getParamName());

		if (action == null) {
			if (suppType != null && SuppType.CANCEL.toString().equalsIgnoreCase(suppType))
				action = "o";
		}

		long parentId = -1;

		ParamInfo root = null;

		for (TblOrderDetails tblOrderDetailsOrig : tblOrderDetailsListOrig) {

			LOG.info("Param Name = {}", tblOrderDetailsOrig.getParamName());

			if (parentId == -1) {
				switch (tblOrderDetailsOrig.getParamName()) {
				case "Enterprise":
					root = new ParamInfo("Enterprise", null, action);
					parentId = tblOrderDetailsOrig.getOrderDetailId();
					continue;
				case "Location":
					root = new ParamInfo("Location", null, action);
					parentId = tblOrderDetailsOrig.getOrderDetailId();
					continue;
				case "Device":
					root = new ParamInfo("Device", null, action);
					parentId = tblOrderDetailsOrig.getOrderDetailId();
					continue;
				case "SonusNbs":
					root = new ParamInfo("SonusNbs", null, action);
					parentId = tblOrderDetailsOrig.getOrderDetailId();
					continue;
				case "EnterpriseTrunk":
					root = new ParamInfo("EnterpriseTrunk", null, action);
					parentId = tblOrderDetailsOrig.getOrderDetailId();
					continue;
				case "Group":
					root = new ParamInfo("Group", null, action);
					parentId = tblOrderDetailsOrig.getOrderDetailId();
					continue;
				case "TrunkTN":
					root = new ParamInfo("TrunkTN", null, action);
					parentId = tblOrderDetailsOrig.getOrderDetailId();
					continue;
				default:
					root = new ParamInfo("Enterprise", null, action); // default param Info added as root was not
																		// initialized
					break;
				}
			}

			if (parentId != -1) {
				root.addNotNullValChild(tblOrderDetailsOrig.getParamName(), tblOrderDetailsOrig.getParamValue(),
						action);

				LOG.info(
						"Copying from Tbl_Order_details for root.getName() = {} and root.getValue() = {} root.getAction() = {} ",
						root.getName(), root.getValue(), root.getAction());
			}
		}

		LOG.info("Exit - prepareTblOrdDetEntityParamDataFromExistingTblOrdDet");
		return root;
	}

	/**
	 * @param orderHeader
	 * @param groupTnEntity
	 * @param grpTNEntityPrev
	 * @param status
	 * @param tblEnvOrderObject
	 * @return
	 * @throws TranslatorException
	 * @throws GenericException
	 */
	public long createSystemUpdateReleaseOrders(OrderHeader orderHeader, GroupTNEntity groupTnEntity,
			GroupTNEntity grpTNEntityPrev, int status, TblEnvOrder tblEnvOrderObject)
			throws TranslatorException, GenericException {
		// TODO Auto-generated method stub
		return 0;
	}

}
