package com.vz.esap.translation.entity;

public class ParentEntity extends Entity
{

    private int entityType;
    private String entityName;
    private String entityId;
    private boolean self;
    private boolean dependForMod;

    public ParentEntity(int entityType, String entityName, String entityId, boolean self)
    {
        initialize(entityType, entityName, entityId, self, true);
    }

    public ParentEntity(int entityType, String entityName, String entityId)
    {
        initialize(entityType, entityName, entityId, false, true);
    }

    public void initialize(int entityType, String entityName, String entityId, boolean self, boolean dependForMod)
    {
        this.entityType = entityType;
        this.entityName = entityName;
        this.entityId = entityId;
        this.self = self;
        this.dependForMod = dependForMod;
    }
    
   
    public boolean isDependForMod() {
		return dependForMod;
	}

	public void setDependForMod(boolean dependForMod) {
		this.dependForMod = dependForMod;
	}

	public void setEntityId(String entityId) {
		this.entityId = entityId;
	}

	public void setEntityName(String entityName) {
		this.entityName = entityName;
	}

	public void setEntityType(int entityType) {
		this.entityType = entityType;
	}

	public void setSelf(boolean self) {
		this.self = self;
	}

	public int getEntityType()
    {
        return entityType;
    }
    public String getEntityName()
    {
        return entityName;
    }
    public String getEntityId()
    {
        return entityId;
    }
    public boolean isSelf()
    {
        return self;
    }

    public boolean equals(Object obj) {
        if (!(obj instanceof ParentEntity)) {
            return false;
        }
        ParentEntity comp = (ParentEntity) obj;
        return (entityType == comp.getEntityType() && self == comp.isSelf() && equals(entityName, comp.getEntityName()) && equals(entityId, comp.getEntityId()));
    }

    public static boolean equals( Object obj1, Object obj2 )
    {
        if( obj1 != null ) return obj1.equals(obj2);
        else if( obj2 != null ) return obj2.equals(obj1);
        else return true;
    }

}
