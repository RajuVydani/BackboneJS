package com.vz.esap.translation.controller;

/**
 * @author Niladri Chattaraj
 *
 */

import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeoutException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.validation.BindException;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.vz.esap.translation.enums.EsapEnum.ResourceVerb;
import com.vz.esap.translation.enums.EsapEnum.StatusCode;
import com.vz.esap.translation.exception.BadRequestException;
import com.vz.esap.translation.exception.GenericException;
import com.vz.esap.translation.exception.TranslatorException;
import com.vz.esap.translation.order.model.request.VOIPOrderRequest;
import com.vz.esap.translation.order.model.response.OrderStatus;
import com.vz.esap.translation.order.model.response.VoipOrderResponse;
import com.vz.esap.translation.order.transformer.VoipRequestTransformer;
import com.vz.esap.translation.service.TranslationService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RefreshScope
@RequestMapping("/translation")
@Api(value = "translation", description = "Translation Operations Service API")
public class TranslationServiceController {

	@Autowired
	private TranslationService translationService;

	@Autowired
	private VoipRequestTransformer voipRequestTransformerImpl;

	private static final Logger LOG = LoggerFactory.getLogger(TranslationServiceController.class);

	/**
	 * @return object
	 * @throws InterruptedException
	 * @throws ExecutionException
	 * @throws TimeoutException
	 * @throws BindException
	 * @throws JsonProcessingException
	 * @throws TranslatorException
	 */
	@RequestMapping(value = "/consume", method = RequestMethod.POST, produces = "application/json", consumes = "application/json")
	@ApiResponses(value = { @ApiResponse(code = 0, message = "Successful"),
			@ApiResponse(code = 1, message = "Internal Server Error"), })
	public Object consume() throws InterruptedException, ExecutionException, TimeoutException, BindException,
			JsonProcessingException, TranslatorException, GenericException, BadRequestException {
		return null;
	}

	/**
	 * @param voipOrderRequest
	 * @return voipOrderResponse
	 * @throws JsonProcessingException
	 * @throws TranslatorException
	 * @throws GenericException
	 */
	@RequestMapping(value = "/process", method = RequestMethod.POST, produces = "application/json", consumes = "application/json")
	@ApiResponses(value = { @ApiResponse(code = 0, message = "Successful"),
			@ApiResponse(code = 1, message = "Internal Server Error"), })
	public VoipOrderResponse process(@RequestBody VOIPOrderRequest voipOrderRequest)
			throws JsonProcessingException, TranslatorException, GenericException {
		LOG.info("Entered process");
		ObjectMapper mapper;

		VoipOrderResponse voipOrderResponse;
		if (voipOrderRequest != null) {

			if (voipOrderRequest.getOrderHeader() != null) {
				mapper = new ObjectMapper();
				LOG.info("Order data ready for translation :{}",
						mapper.writerWithDefaultPrettyPrinter().writeValueAsString(voipOrderRequest));
				voipOrderResponse = translationService.translateOrder(voipOrderRequest);
			} else {
				LOG.info("voipOrderRequest.getOrderHeader() is null");
				mapper = new ObjectMapper();
				LOG.debug("Order data ready for translation :{}",
						mapper.writerWithDefaultPrettyPrinter().writeValueAsString(voipOrderRequest));
				OrderStatus orderStatus = new OrderStatus();
				orderStatus.setStatusCode(StatusCode.ESP_FAILURE.getValue());
				voipOrderResponse = new VoipOrderResponse();
				voipOrderResponse.setOrderStatus(orderStatus);
			}
		} else {
			LOG.info("voipOrderRequest is null");
			OrderStatus orderStatus = new OrderStatus();
			orderStatus.setStatusCode(StatusCode.ESP_FAILURE.getValue());
			voipOrderResponse = new VoipOrderResponse();
			voipOrderResponse.setOrderStatus(orderStatus);
		}
		LOG.info("Exit process");
		return voipOrderResponse;

	}

	/**
	 * @param locationId
	 * @param workOrderNumber
	 * @param workOrderVersion
	 * @param unoServiceId
	 * @param transactionID
	 * @param msgSegmentNo
	 * @param orderType
	 * @param gchId
	 * @param solutionType
	 * @return voipOrderResponse
	 * @throws GenericException
	 * @throws TranslatorException
	 * @throws JsonProcessingException
	 */
	@RequestMapping(value = "/location/{locationId}/status", method = RequestMethod.GET, produces = "application/json")
	@ApiResponses(value = { @ApiResponse(code = 0, message = "Successful"),
			@ApiResponse(code = 1, message = "Internal Server Error"), })
	public VoipOrderResponse getLocationInformation(@PathVariable(value = "locationId") String locationId,
			@RequestParam(value = "workOrderNumber", required = false) String workOrderNumber,
			@RequestParam(value = "workOrderVersion", required = false) String workOrderVersion,
			@RequestParam(value = "unoServiceId", required = false) String unoServiceId,
			@RequestParam(value = "transactionID", required = false) String transactionID,
			@RequestParam(value = "msgSegmentNo", required = false) String msgSegmentNo,
			@RequestParam(value = "orderType", required = false) String orderType,
			@RequestParam(value = "gchId", required = false) String gchId,
			@RequestParam(value = "solutionType", required = false) String solutionType)
			throws JsonProcessingException, TranslatorException, GenericException {

		LOG.info("Entered getLocationInformation");

		VoipOrderResponse voipOrderResponse = translationService.retrieveLocationInformation(voipRequestTransformerImpl
				.createVoipOrderRequestFromRequestUri(ResourceVerb.GET_LOC_INFO, locationId, workOrderNumber,
						workOrderVersion, unoServiceId, transactionID, msgSegmentNo, orderType, gchId, solutionType));

		LOG.info("Exit getLocationInformation");
		return voipOrderResponse;

	}

	@RequestMapping(value = "/order/tn", method = RequestMethod.PUT, produces = "application/json", consumes = "application/json")
	@ApiResponses(value = { @ApiResponse(code = 0, message = "Successful"),
			@ApiResponse(code = 1, message = "Internal Server Error"), })
	public VoipOrderResponse activateTn(@RequestBody VOIPOrderRequest voipOrderRequest)
			throws JsonProcessingException, TranslatorException, GenericException {
		LOG.info("Entered activateTn");
		ObjectMapper mapper;

		VoipOrderResponse voipOrderResponse;
		if (voipOrderRequest != null) {

			if (voipOrderRequest.getOrderHeader() != null) {
				mapper = new ObjectMapper();
				LOG.info("Order data ready for translation :{}",
						mapper.writerWithDefaultPrettyPrinter().writeValueAsString(voipOrderRequest));
				voipOrderResponse = translationService.translateOrder(voipOrderRequest);
			} else {
				LOG.info("voipOrderRequest.getOrderHeader() is null");
				mapper = new ObjectMapper();
				LOG.debug("Order data ready for translation :{}",
						mapper.writerWithDefaultPrettyPrinter().writeValueAsString(voipOrderRequest));
				OrderStatus orderStatus = new OrderStatus();
				orderStatus.setStatusCode(StatusCode.ESP_FAILURE.getValue());
				voipOrderResponse = new VoipOrderResponse();
				voipOrderResponse.setOrderStatus(orderStatus);
			}
		} else {
			LOG.info("voipOrderRequest is null");
			OrderStatus orderStatus = new OrderStatus();
			orderStatus.setStatusCode(StatusCode.ESP_FAILURE.getValue());
			voipOrderResponse = new VoipOrderResponse();
			voipOrderResponse.setOrderStatus(orderStatus);
		}
		LOG.info("Exit activateTn");
		return voipOrderResponse;

	}

	public TranslationService getTranslationService() {
		return translationService;
	}

	public void setTranslationService(TranslationService translationService) {
		this.translationService = translationService;
	}

}