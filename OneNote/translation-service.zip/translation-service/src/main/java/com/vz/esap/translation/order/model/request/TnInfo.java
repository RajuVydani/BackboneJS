package com.vz.esap.translation.order.model.request;

public class TnInfo {

	private String tn;

	public String getTn() {
		return tn;
	}

	public void setTn(String tn) {
		this.tn = tn;
	}

}
