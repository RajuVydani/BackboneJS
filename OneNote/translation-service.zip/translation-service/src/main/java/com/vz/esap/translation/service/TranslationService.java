package com.vz.esap.translation.service;

/**
 * @author Niladri Chattaraj
 *
 */
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.vz.esap.translation.enums.EsapEnum.FunctionCode;
import com.vz.esap.translation.enums.EsapEnum.MileStone;
import com.vz.esap.translation.enums.EsapEnum.PcResponseType;
import com.vz.esap.translation.enums.EsapEnum.StatusCode;
import com.vz.esap.translation.exception.BadRequestException;
import com.vz.esap.translation.exception.GenericException;
import com.vz.esap.translation.exception.TranslatorException;
import com.vz.esap.translation.exception.TranslatorException.ErrorCode;
import com.vz.esap.translation.order.model.request.VOIPOrderRequest;
import com.vz.esap.translation.order.model.response.VoipOrderResponse;
import com.vz.esap.translation.order.service.VOIPResponseGenerator;
import com.vz.esap.translation.order.service.helper.OrderServiceHelper;

@Service
public class TranslationService {

	private static final Logger LOG = LoggerFactory.getLogger(TranslationService.class);

	boolean isReversal = false;
	String transaction = "";
	String jurisdiction = "E2EI_BULK";

	@Autowired
	private OrderRouter orderRouter;

	@Autowired
	private OrderServiceHelper orderServiceHelperImpl;

	@Autowired
	private VOIPResponseGenerator voipResponseGenerator;

	public void setOrderRouter(OrderRouter orderRouter) {
		this.orderRouter = orderRouter;
	}

	// @Async Future<String>
	/**
	 * @param voipOrderRequest
	 * @return voipOrderResponse
	 * @throws TranslatorException
	 * @throws GenericException
	 * @throws JsonProcessingException
	 * @throws Exception
	 */
	public VoipOrderResponse translateOrder(VOIPOrderRequest voipOrderRequest)
			throws TranslatorException, GenericException, JsonProcessingException {

		VoipOrderResponse voipOrderResponse = null;
		ObjectMapper mapper = null;
		String processInfo = null;
		String milestone = null;

		try {

			if (voipOrderRequest.getOrderHeader() != null
					&& voipOrderRequest.getOrderHeader().getFunctionCode() != null) {
				if (FunctionCode.VALIDATE.toString()
						.equalsIgnoreCase(voipOrderRequest.getOrderHeader().getFunctionCode()))
					milestone = MileStone.VALIDATE_ORDER_WITH_ESAP.getValue();
				else if (FunctionCode.RELEASE.toString()
						.equalsIgnoreCase(voipOrderRequest.getOrderHeader().getFunctionCode()))
					milestone = MileStone.RELEASE_ORDER_WITH_ESAP.getValue();
				else if (FunctionCode.NBS_PROV_CONFIG.toString()
						.equalsIgnoreCase(voipOrderRequest.getOrderHeader().getFunctionCode()))
					milestone = MileStone.IP_VLAN_INFO_WITH_LOGICAL.getValue();
			} // 1. Discon - Decide the disconnect milestone

			mapper = new ObjectMapper();
			LOG.info("VOIP REQUEST ::::: {}",
					mapper.writerWithDefaultPrettyPrinter().writeValueAsString(voipOrderRequest));
			LOG.info(
					"Order Header Information - Work Order Number:{},Work Order Version:{}, Order Type:{},Function Code:{}",
					voipOrderRequest.getOrderHeader().getWorkOrderNumber(),
					voipOrderRequest.getOrderHeader().getWorkOrderVersion(),
					voipOrderRequest.getOrderHeader().getOrderType(),
					voipOrderRequest.getOrderHeader().getFunctionCode());

			voipOrderResponse = orderRouter.routeOrder(voipOrderRequest);

			if (voipOrderResponse == null) {
				throw new TranslatorException(ErrorCode.VOIP_RESPONSE_NOT_FOUND, "Failed to find voipOrderResponse");
			}

			voipOrderResponse = voipResponseGenerator.preparePCMilestone(voipOrderRequest, milestone,
					StatusCode.ESP_SUCCESS, voipOrderRequest.getOrderHeader().getResponseType());

			processInfo = String.format("Processing is Done with Thread id= %d ", Thread.currentThread().getId());
			LOG.info(processInfo);

			LOG.info("Order Response :{} ",
					mapper.writerWithDefaultPrettyPrinter().writeValueAsString(voipOrderResponse));

		} catch (TranslatorException ex) {
			LOG.error("Exception {} ", ex.getMessage());
			milestone = milestone != null ? milestone : MileStone.UNKNOWN.getValue();
			voipOrderResponse = orderServiceHelperImpl.handleTranslationException(voipOrderRequest, milestone,
					StatusCode.ESP_FAILURE, ex.getErrorDesc());

			throw new TranslatorException(ex.getErrorCode(), ex.getMessage());

		} catch (BadRequestException be) {
			LOG.error("Exception {} ", be.getMessage());
			milestone = milestone != null ? milestone : MileStone.UNKNOWN.getValue();
			voipOrderResponse = orderServiceHelperImpl.handleTranslationException(voipOrderRequest, milestone,
					StatusCode.ESP_FAILURE, be.getMessage());

			throw new BadRequestException(be.getError());
		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			milestone = milestone != null ? milestone : MileStone.UNKNOWN.getValue();
			voipOrderResponse = orderServiceHelperImpl.handleTranslationException(voipOrderRequest, milestone,
					StatusCode.ESP_FAILURE, e.getMessage());

			throw new GenericException(GenericException.GENERIC_EXCEPTION,
					"Exception occured while providing input arguments");
		}

		LOG.info("Exit - translateOrder");
		return voipOrderResponse;
	}

	/**
	 * @param voipOrderRequest
	 * @return voipOrderResponse
	 * @throws TranslatorException
	 * @throws GenericException
	 * @throws JsonProcessingException
	 */
	public VoipOrderResponse retrieveLocationInformation(VOIPOrderRequest voipOrderRequest)
			throws TranslatorException, GenericException, JsonProcessingException {

		LOG.info("Entered retrieveLocationInformation");

		VoipOrderResponse voipOrderResponse = null;
		ObjectMapper mapper = new ObjectMapper();
		String processInfo = null;

		try {
			LOG.info("GET LOCATION INFO REQUEST ::::: {}",
					mapper.writerWithDefaultPrettyPrinter().writeValueAsString(voipOrderRequest));

			voipOrderResponse = orderRouter.routeOrder(voipOrderRequest);
			if (voipOrderResponse == null) {
				throw new TranslatorException(ErrorCode.VOIP_RESPONSE_NOT_FOUND, "Failed to find voipOrderResponse");
			}

			processInfo = String.format("Processing is Done with Thread id= %d ", Thread.currentThread().getId());
			LOG.info(processInfo);

		} catch (TranslatorException ex) {
			LOG.error("Exception {} ", ex.getMessage());
			voipOrderResponse = voipResponseGenerator.preparePCMilestone(voipOrderRequest, null, StatusCode.ESP_FAILURE,
					PcResponseType.ORDER.getValue());

		} catch (BadRequestException be) {
			LOG.error("Exception {} ", be.getMessage());
			voipOrderResponse = voipResponseGenerator.preparePCMilestone(voipOrderRequest, null, StatusCode.ESP_FAILURE,
					PcResponseType.ORDER.getValue());

		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			voipOrderResponse = voipResponseGenerator.preparePCMilestone(voipOrderRequest, null, StatusCode.ESP_FAILURE,
					PcResponseType.ORDER.getValue());
		}

		LOG.info("Order Response :{} ", mapper.writerWithDefaultPrettyPrinter().writeValueAsString(voipOrderResponse));
		LOG.info("Exit - retrieveLocationInformation");
		return voipOrderResponse;
	}

}
