package com.vz.esap.translation.order.dao;

import static java.util.Arrays.stream;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

/**
 * @author V864498
 * 
 *         Generic Order Utility class to do Order related DB activities for all
 *         kinds of entities
 */

import org.springframework.stereotype.Component;

import com.vz.esap.translation.connector.model.DBServiceResponse;
import com.vz.esap.translation.connector.model.TblRow;
import com.vz.esap.translation.constant.TranslationConstant;
import com.vz.esap.translation.dao.model.TblConfigParams;
import com.vz.esap.translation.dao.model.TblConfigParamsExample;
import com.vz.esap.translation.dao.model.TblEnvOrder;
import com.vz.esap.translation.dao.model.TblEnvOrderDetails;
import com.vz.esap.translation.dao.model.TblEnvOrderExample;
import com.vz.esap.translation.dao.model.TblEnvOrderResp;
import com.vz.esap.translation.dao.model.TblEnvOrderSegment;
import com.vz.esap.translation.dao.model.TblLorTnChngDetails;
import com.vz.esap.translation.dao.model.TblLorTnChngDetailsExample;
import com.vz.esap.translation.dao.model.TblLorTnDetails;
import com.vz.esap.translation.dao.model.TblLorTnDetailsExample;
import com.vz.esap.translation.dao.model.TblMilestoneOrders;
import com.vz.esap.translation.dao.model.TblOrder;
import com.vz.esap.translation.dao.model.TblOrderDetails;
import com.vz.esap.translation.dao.model.TblOrderExample;
import com.vz.esap.translation.dao.model.TblOrderService;
import com.vz.esap.translation.dao.model.TblParentOrders;
import com.vz.esap.translation.dao.model.TblParentOrdersExample;
import com.vz.esap.translation.dao.model.TblRetailService;
import com.vz.esap.translation.dao.model.TblRetailServiceExample;
import com.vz.esap.translation.dao.model.TblRetailServiceExample.Criteria;
import com.vz.esap.translation.dao.model.TblSafeStore;
import com.vz.esap.translation.dao.repository.CustomTblConfigParamsMapper;
import com.vz.esap.translation.dao.repository.CustomTblEnvOrderDetailsMapper;
import com.vz.esap.translation.dao.repository.CustomTblEnvOrderMapper;
import com.vz.esap.translation.dao.repository.CustomTblEnvOrderRespMapper;
import com.vz.esap.translation.dao.repository.CustomTblOrderDetailsMapper;
import com.vz.esap.translation.dao.repository.CustomTblOrderMapper;
import com.vz.esap.translation.dao.repository.CustomTblOrderServiceMapper;
import com.vz.esap.translation.dao.repository.CustomTblRetailServiceMapper;
import com.vz.esap.translation.dao.repository.CustomTblSafeStoreMapper;
import com.vz.esap.translation.dao.repository.TblEnvOrderSegmentMapper;
import com.vz.esap.translation.dao.repository.TblLorTnChngDetailsMapper;
import com.vz.esap.translation.dao.repository.TblLorTnDetailsMapper;
import com.vz.esap.translation.dao.repository.TblMilestoneOrdersMapper;
import com.vz.esap.translation.dao.repository.TblParentOrdersMapper;
import com.vz.esap.translation.dao.repository.TblPendingWoTaskDbBeanMapper;
import com.vz.esap.translation.entity.Entity.GroupType;
import com.vz.esap.translation.enums.EsapEnum.FlowPath;
import com.vz.esap.translation.enums.EsapEnum.FunctionCode;
import com.vz.esap.translation.enums.EsapEnum.OrderAction;
import com.vz.esap.translation.enums.EsapEnum.OrderEntity;
import com.vz.esap.translation.enums.EsapEnum.OrderType;
import com.vz.esap.translation.enums.EsapEnum.Service;
import com.vz.esap.translation.enums.EsapEnum.ServiceType;
import com.vz.esap.translation.enums.EsapEnum.SolutionType;
import com.vz.esap.translation.enums.EsapEnum.TnType;
import com.vz.esap.translation.exception.GenericException;
import com.vz.esap.translation.exception.TranslatorException;
import com.vz.esap.translation.exception.TranslatorException.ErrorCode;
import com.vz.esap.translation.order.model.Order;
import com.vz.esap.translation.order.model.request.OrderHeader;
import com.vz.esap.translation.order.model.request.ParamInfo;
import com.vz.esap.translation.order.model.request.VOIPOrderRequest;

import EsapEnumPkg.WorkOrderEnum;
import reactor.util.CollectionUtils;

@Component
public class VOIPOrderDaoImpl implements VOIPOrderDao {

	@Autowired
	private CustomTblEnvOrderMapper customTblEnvOrderMapper;

	@Autowired
	private CustomTblOrderMapper customTblOrderMapper;

	@Autowired
	private CustomTblOrderDetailsMapper customTblOrderDetailsMapper;

	@Autowired
	private CustomTblOrderServiceMapper customTblOrderServiceMapper;

	@Autowired
	private CustomTblEnvOrderRespMapper customTblEnvOrderRespMapper;

	@Autowired
	private CustomTblRetailServiceMapper customTblRetailServiceMapper;

	@Autowired
	private CustomTblSafeStoreMapper customTblSafeStoreMapper;

	@Autowired
	private TblEnvOrderSegmentMapper tblEnvOrderSegmentMapper;

	@Autowired
	private CustomTblEnvOrderDetailsMapper customTblEnvOrderDetailsMapper;

	@Autowired
	private CustomTblConfigParamsMapper customTblConfigParamsMapper;

	@Autowired
	private TblParentOrdersMapper tblParentOrdersMapper;

	@Autowired
	private TblMilestoneOrdersMapper tblMilestoneOrdersMapper;

	@Autowired
	private TblLorTnChngDetailsMapper tblLorTnChngDetailsMapper;

	@Autowired
	private TblLorTnDetailsMapper tblLorTnDetailsMapper;
	
	@Autowired
	private TblPendingWoTaskDbBeanMapper tblPendingWoTaskDbBeanMapper;

	private static final Logger LOG = LoggerFactory.getLogger(VOIPOrderDaoImpl.class);

	private static final String FXO_INBOUND = "FXO_INBOUND";

	private static final String FXO_TWO_WAY = "FXO_TWO_WAY";

	private static final String INBOUND = "INBOUND";

	private static final String TWO_WAY = "TWO_WAY";

	private static final String FXO = "FXO";

	private static final String BULK_SYSTEM_UPDATE = "BULK_SYSTEM_UPDATE";

	private static final String FXO_LINE = "FXO_LINE";

	private static final String FXO_DID = "FXO_DID";

	private static final String LINE = "LINE";

	private static final String DID = "DID";

	private static final String ALL = "ALL";

	private static final String RELEASE = "RELEASE";

	protected ArrayList<Service> skipServices = new ArrayList<>();

	@Autowired
	@Qualifier("getdataserviceDS")
	private DataSource dataSource;

	private long forwardSuperParent = -1;

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.vz.esap.translation.order.dao.VOIPOrderDao#createEnvelopOrder(com.vz.esap
	 * .translation.dao.model.TblEnvOrder)
	 */
	@Override
	public long createEnvelopOrder(TblEnvOrder tblEnvOrderObject) throws TranslatorException {
		LOG.info("Entered - createEnvelopOrder");

		long count = 0;

		count = customTblEnvOrderMapper.createEnvelopOrder(tblEnvOrderObject);
		if (count <= 0) {
			throw new TranslatorException(ErrorCode.DATA_NOT_FOUND, "Failed to retrieve data in createEnvelopOrder ");
		}

		LOG.info("Exit - createEnvelopOrder ,Number of rows inserted :{} , Env Order Id :{} ", count,
				tblEnvOrderObject.getEnvOrderId());
		return count;

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.vz.esap.translation.order.dao.VOIPOrderDao#createTblOrder(com.vz.esap.
	 * translation.dao.model.TblOrder)
	 */
	@Override
	public long createTblOrder(TblOrder tblOrderObject) throws TranslatorException {
		LOG.info("VOIPOrderDaoImpl - createTblOrder");

		long count = 0;
		count = customTblOrderMapper.createTblOrder(tblOrderObject);

		if (count <= 0) {
			throw new TranslatorException(ErrorCode.DATA_NOT_FOUND, "Failed to retrieve data in createTblOrder");
		}

		LOG.info("TblOrder Order_id : {}", tblOrderObject.getOrderId());
		return count;

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.vz.esap.translation.order.dao.VOIPOrderDao#createTblOrderService(com.vz.
	 * esap.translation.dao.model.TblOrderService)
	 */
	@Override
	public long createTblOrderService(TblOrderService tblOrderService) throws TranslatorException {
		LOG.info("Entered - createTblOrderService for Service : {} , Order id : {} , Sequence Number : {}",
				tblOrderService.getService(), tblOrderService.getOrderId(), tblOrderService.getSeqNo());
		long count = 0;
		count = customTblOrderServiceMapper.createTblOrderService(tblOrderService);
		if (count <= 0) {
			throw new TranslatorException(ErrorCode.DATA_NOT_FOUND, "Failed to retrieve data in createTblOrderService");
		}
		LOG.info("Exit - createTblOrderService");
		return count;

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.vz.esap.translation.order.dao.VOIPOrderDao#updateTblEnvOrderStatus(java.
	 * lang.Long, int)
	 */
	@Override
	public void updateTblEnvOrderStatus(Long envOrderId, int status) {
		LOG.info("Entered - updateTblEnvOrderStatus for EnvOrderId = {}, Status = {}", envOrderId, status);

		TblEnvOrder tblEnvOrder = new TblEnvOrder();
		tblEnvOrder.setEnvOrderId(envOrderId);
		tblEnvOrder.setOrderStatus(Long.valueOf(status));

		int count = customTblEnvOrderMapper.updateByPrimaryKeySelective(tblEnvOrder);

		LOG.info("Exit - updateTblEnvOrderStatus Row Updated = {} ...", count);
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.vz.esap.translation.order.dao.VOIPOrderDao#updateTblEnvOrderStatusAndWorkGroup(java.
	 * lang.Long, int, java.lang.String)
	 */
	@Override
	public void updateTblEnvOrderStatusAndWorkGroup(Long envOrderId, int status, String workGroup) {
		LOG.info("Entered - updateTblEnvOrderStatusAndWorkGroup for EnvOrderId = {}, Status = {}, WorkGroup = {}", envOrderId, status, workGroup);

		TblEnvOrder tblEnvOrder = new TblEnvOrder();
		tblEnvOrder.setEnvOrderId(envOrderId);
		tblEnvOrder.setOrderStatus(Long.valueOf(status));
		tblEnvOrder.setWorkGroup(workGroup);
		int count = customTblEnvOrderMapper.updateByPrimaryKeySelective(tblEnvOrder);

		LOG.info("Exit - updateTblEnvOrderStatusAndWorkGroup Row Updated = {} ...", count);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.vz.esap.translation.order.dao.VOIPOrderDao#updateTblOrderStatus(java.lang
	 * .Long, int)
	 */
	@Override
	public void updateTblOrderStatus(Long orderId, int status) {
		LOG.info("Updating Order Id : {}, With Status :{} ", orderId, status);
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("OrderId", orderId);
		params.put("Status", status);
		customTblOrderMapper.updateTblOrderStatus(params);

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.vz.esap.translation.order.dao.VOIPOrderDao#updateTblOrderStatus(java.lang
	 * .Long, int)
	 */
	@Override
	public void moveTblOrder(Long envOrderId, Long prevPassOrderId) {
		LOG.info("Inside moveTblOrder Updating EnvOrder Id : {}, for Order Id : {} ", envOrderId, prevPassOrderId);
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("envOrderId", envOrderId);
		params.put("prevPassOrderId", prevPassOrderId);
		customTblOrderMapper.updateOrderId(params);
	}

	@Override
	public List<TblOrderDetails> getOrderDetailParam(Long prevOrderId, String entityType) {
		LOG.info("Fetch Order details for previous order Id : {}", prevOrderId);
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("prevOrderId", prevOrderId);
		params.put("param_name", entityType);
		List<TblOrderDetails> tblOrderDetailsList = customTblOrderDetailsMapper.getOrderDetailParam(params);
		LOG.info("tblOrderDetailsList size: {}", tblOrderDetailsList.size());
		return tblOrderDetailsList;
	}

	public List<TblOrderService> getOrderServiceList(TblOrder prevOrder) {
		LOG.info("Fetch Order service list for previous order Id : {}", prevOrder.getOrderId());
		List<TblOrderService> tblOrderServiceList = customTblOrderServiceMapper
				.getOrderServiceList(prevOrder.getOrderId());
		LOG.info("tblOrderServiceList size: {}", tblOrderServiceList.size());
		return tblOrderServiceList;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.vz.esap.translation.order.dao.VOIPOrderDao#insertTblEnvOrderRespData(com.
	 * vz.esap.translation.dao.model.TblEnvOrderResp)
	 */
	@Override
	public void insertTblEnvOrderRespData(TblEnvOrderResp tblEnvOrderResp) {
		customTblEnvOrderRespMapper.insertTblEnvOrderRespData(tblEnvOrderResp);

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.vz.esap.translation.order.dao.VOIPOrderDao#populateOrderDetails(com.vz.
	 * esap.translation.dao.model.TblOrder, java.util.List, java.lang.String, long,
	 * long)
	 */
	@Override
	public long populateOrderDetails(TblOrder tblOrderObject, List<ParamInfo> childParams, String action, long parentId,
			long leaf) throws TranslatorException {
		LOG.info("Entered - populateOrderDetails With action in the Input Arg :::: {}", action);
		long count = 0;

		if (childParams != null) {

			for (ParamInfo param : childParams) {
				LOG.debug(
						"+++++++Level 1++++++++ Inside For Loop of ParamInfo with param.getName() = {} , param.getAction() = {} ",
						param.getName(), param.getAction());

				populateOrderDetails(tblOrderObject.getOrderId(), param, action, parentId, leaf);
				count++;
			}
		}

		if (count <= 0) {
			throw new TranslatorException(ErrorCode.DATA_NOT_FOUND, "Failed to retrieve data in populateOrderDetails");
		}
		LOG.info("Exit - populateOrderDetails");
		return count;
	}

	/**
	 * @param orderId
	 * @param param
	 * @param action
	 * @param parentId
	 * @param leaf
	 */
	private void populateOrderDetails(Long orderId, ParamInfo param, String action, long parentId, long leaf) {

		LOG.debug(
				"Inside populateOrderDetails +++++++Level 2++++++++ For Param Name = {} with Sent Action = {} with Param Action = {} ",
				param.getName(), action, param.getAction());

		String finalAction = null;
		HashSet<ParamInfo.Tag> tags = param.getTagSet();
		String paramType = null;
		if (tags != null) {
			paramType = new String(",");
			for (ParamInfo.Tag tag : tags)
				paramType += tag.ordinal() + ",";
		}

		if ("n".equalsIgnoreCase(action)) {
			finalAction = "n";
		} else if ("I".equalsIgnoreCase(action)) {
			finalAction = "n";
		} else if ("C".equalsIgnoreCase(action) && param.getAction() != null) {

			if ("C".equalsIgnoreCase(param.getAction()))
				finalAction = "c";
			else if ("I".equalsIgnoreCase(param.getAction()))
				finalAction = "n";
			else if ("O".equalsIgnoreCase(param.getAction()))
				finalAction = "o";

		} else if ("C".equalsIgnoreCase(action) && param.getAction() == null) {
			finalAction = "r";
		} else if ("o".equalsIgnoreCase(action)) {
			finalAction = "o";
		}

		LOG.debug("Final Action is = {}", finalAction);

		TblOrderDetails tblOrderDeatilsObject = prepareOrderDetail(orderId, param.getName(), param.getValue(), parentId,
				param.getSeqNo(), finalAction, leaf, paramType);

		long newParentId = tblOrderDeatilsObject.getOrderDetailId();
		insertOrderDetails(tblOrderDeatilsObject);

		if (param.getChildParams() != null)
			param.getChildParams()
					.forEach(childParam -> populateOrderDetails(orderId, childParam, action, newParentId, leaf + 1));

	}

	/**
	 * @param tblOrderDeatilsObject
	 * @return count
	 */
	public long insertOrderDetails(TblOrderDetails tblOrderDeatilsObject) {
		long count = customTblOrderDetailsMapper.insertOrderDetail(tblOrderDeatilsObject);
		return count;
	}

	/**
	 * @param orderId
	 * @param paramName
	 * @param paramValue
	 * @param parentId
	 * @param seqNo
	 * @param action
	 * @param leaf
	 * @param paramType
	 * @return tblOrderDeatilsObject
	 */
	public TblOrderDetails prepareOrderDetail(Long orderId, String paramName, String paramValue, Long parentId,
			Long seqNo, String action, Long leaf, String paramType) {

		if (paramType == null || "".equals(paramType)) {
			paramType = "P";
		}
		/*
		 * if (paramType == null || paramType.trim().equals("")) { paramType = ","; }
		 */
		if (parentId < 0)
			parentId = 0L;

		TblOrderDetails tblOrderDeatilsObject = new TblOrderDetails();
		long orderDetailId = customTblOrderDetailsMapper.getOrdDtlIdNextVal();
		tblOrderDeatilsObject.setOrderDetailId(orderDetailId);
		tblOrderDeatilsObject.setOrderId(orderId);
		tblOrderDeatilsObject.setParamName(paramName);
		tblOrderDeatilsObject.setParamValue(paramValue);
		tblOrderDeatilsObject.setParentId(parentId);
		tblOrderDeatilsObject.setSeqNo(seqNo);
		tblOrderDeatilsObject.setAction(action);
		tblOrderDeatilsObject.setLeaf(leaf);
		tblOrderDeatilsObject.setFlowStatus(0L);
		tblOrderDeatilsObject.setParamType(paramType);

		return tblOrderDeatilsObject;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.vz.esap.translation.order.dao.VOIPOrderDao#findServicesValidation(java.
	 * lang.String)
	 */
	@Override
	public List<TblRetailService> findServicesValidation(String region) throws TranslatorException {
		LOG.info("VOIPOrderDaoImpl - findServicesValidation");
		TblRetailServiceExample tblRetailServiceExample = new TblRetailServiceExample();
		List<String> regionList = new ArrayList<String>();
		regionList.add(region);
		regionList.add("ALL");
		Criteria criteria = tblRetailServiceExample.createCriteria();
		criteria.andProductEqualTo("RE").andOrderTypeEqualTo("I").andFunctionCodeEqualTo("VALIDATE")
				.andEntityTypeEqualTo("VALIDATION").andEntityActionEqualTo("V").andRegionIn(regionList);

		tblRetailServiceExample.setOrderByClause("PARAM_NAME, SEQ_NO");

		List<TblRetailService> tblRetailServiceList = findE2EIRetailServices(tblRetailServiceExample);

		return tblRetailServiceList;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.vz.esap.translation.order.dao.VOIPOrderDao#findServices(com.vz.esap.
	 * translation.order.model.Order)
	 */
	@Override
	public List<TblRetailService> findServices(Order order, Order orderPrevPass) throws TranslatorException {
		LOG.info("Entered findServices for Entity : {} and SolutionType : {} , Entity Action : {} ",
				order.getOrderHeader().getEntityType(), order.getOrderHeader().getSolutionType(),
				order.getOrderHeader().getEntityAction());

		List<TblRetailService> tblRetailServiceList = null;
		TblRetailServiceExample tblRetailServiceExample = null;
		List<String> regionList = null;
		OrderAction serviceAction = null;
		String entityType = null;
		String paramName = null;
		List<String> orderTypeList = null;
		List<String> functionCodeList = null;
		List<String> paramNameList = null;
		try {
			paramNameList = new ArrayList<>();
			tblRetailServiceExample = new TblRetailServiceExample();
			regionList = new ArrayList<>();

			if (order.getOrderHeader().getRegion() != null) {
				regionList.add(order.getOrderHeader().getRegion());
			} else {
				regionList.add("US");
			}
			regionList.add("ALL");

			if (order != null && order.getOrderHeader() != null && order.getOrderHeader().getOrderClassify() <= 0)
				order.getOrderHeader().setOrderClassify(WorkOrderEnum.OrderClassify.INITIAL);

			serviceAction = order.getOrderHeader().getAction();
			if (order.getOrderHeader().getFlowPath().equals(FlowPath.D))
				serviceAction = OrderAction.ADD; // forward order of delta is always ADD
			else if (order.getOrderHeader().getFlowPath().equals(FlowPath.R))
				serviceAction = OrderAction.reverse(OrderAction.ADD); // Use action of the forward
			// order to find services

			if (order.getOrderHeader().getEntityType() == OrderEntity.ENTERPRISE.getIndex()) {
				entityType = OrderEntity.ENTERPRISE.toString();
			}
			if (order.getOrderHeader().getEntityType() == OrderEntity.LOCATION.getIndex()) {
				entityType = OrderEntity.LOCATION.toString();
			}
			if (order.getOrderHeader().getSolutionType().equals(SolutionType.ESIP_EBL)
					|| order.getOrderHeader().getSolutionType().equals(SolutionType.ESIP_ESL)
					|| order.getOrderHeader().getSolutionType().equals(SolutionType.IPFLEX)
					|| order.getOrderHeader().getSolutionType().equals(SolutionType.HPBX)) {
				
				paramName = FXO;
			}
			if (order.getOrderHeader().getEntityType() == OrderEntity.ENTERPRISE_TRUNK.getIndex()) {
				entityType = OrderEntity.ENTERPRISE_TRUNK.toString();

				LOG.debug("order.getEnterpriseTrunkEntities() : {} ", order.getEnterpriseTrunkEntities());
				LOG.debug("order.getEnterpriseTrunkEntities().get(0) : {} ", order.getEnterpriseTrunkEntities().get(0));
				LOG.debug("order.getEnterpriseTrunkEntities().get(0).getEtType() : {} ",
						order.getEnterpriseTrunkEntities().get(0).getEtType());

				if (order.getEnterpriseTrunkEntities().get(0).getEtType().equalsIgnoreCase(INBOUND))
					paramName = FXO_INBOUND;
				if (order.getEnterpriseTrunkEntities().get(0).getEtType().equalsIgnoreCase(TWO_WAY))
					paramName = FXO_TWO_WAY;
			}
			if (order.getOrderHeader().getEntityType() == OrderEntity.DEVICE.getIndex()) {
				entityType = OrderEntity.DEVICE.toString();

				if (order.getDeviceEntity().getSigDir() != null) {
					if (order.getDeviceEntity().getSigDir().toString().equalsIgnoreCase(INBOUND))
						paramName = FXO_INBOUND;
					if (order.getDeviceEntity().getSigDir().toString().equalsIgnoreCase(TWO_WAY))
						paramName = FXO_TWO_WAY;
				}

				if (order.getDeviceEntity().getTrunkType() != null) {
					if (GroupType.PRI_DID.equals(order.getDeviceEntity().getTrunkType())
							|| GroupType.NON_PRI_DID.equals(order.getDeviceEntity().getTrunkType()))
						paramName = FXO_DID;
					if (GroupType.LINE.equals(order.getDeviceEntity().getTrunkType()))
						paramName = FXO_LINE;
				}
			}

			if (order.getOrderHeader().getEntityType() == OrderEntity.PBX.getIndex()) {
				entityType = OrderEntity.PBX.toString();
			}
			if (order.getOrderHeader().getEntityType() == OrderEntity.KEY.getIndex()) {
				entityType = OrderEntity.KEY.toString();
			}
			if (order.getOrderHeader().getEntityType() == OrderEntity.TWO_WAY.getIndex()) {
				entityType = TWO_WAY;
				paramName = FXO;
			}
			if (order.getOrderHeader().getEntityType() == OrderEntity.INBOUND.getIndex()) {
				entityType = INBOUND;
				paramName = FXO;
			}
			if (order.getOrderHeader().getEntityType() == OrderEntity.LINE.getIndex()) {
				entityType = LINE;
				paramName = FXO;
			}
			if (order.getOrderHeader().getEntityType() == OrderEntity.PRI_DID.getIndex()
					|| order.getOrderHeader().getEntityType() == OrderEntity.NON_PRI_DID.getIndex()) {
				entityType = DID;
				paramName = FXO;
			}

			if (order.getOrderHeader().getEntityType() == OrderEntity.SONUS_NBS.getIndex()) {
				entityType = OrderEntity.SONUS_NBS.toString();
				if (order.getNbsEntity().getNbsType().toString().equalsIgnoreCase(INBOUND))
					paramName = FXO_INBOUND;
				if (order.getNbsEntity().getNbsType().toString().equalsIgnoreCase(TWO_WAY))
					paramName = FXO_TWO_WAY;
			}
			if (order.getOrderHeader().getEntityType() == OrderEntity.SYSTEM_UPDATE.getIndex()) {
				entityType = BULK_SYSTEM_UPDATE;
				paramName = FXO;
				if (order.getGroupTnEntity() != null && order.getGroupTnEntity().getTnRecord() != null
						&& order.getGroupTnEntity().getTnRecord().getTnType() != null
						&& order.getGroupTnEntity().getTnRecord().getTnType().equals(TnType.TWO_WAY_TN)) {
					paramNameList.add(FXO_TWO_WAY);
				} else if (order.getGroupTnEntity() != null && order.getGroupTnEntity().getTnRecord() != null
						&& order.getGroupTnEntity().getTnRecord().getTnType() != null
						&& order.getGroupTnEntity().getTnRecord().getTnType().equals(TnType.INBOUND_TN)) {
					paramNameList.add(FXO_INBOUND);
				} else if (order.getGroupTnEntity() != null && order.getGroupTnEntity().getTnRecord() != null
						&& order.getGroupTnEntity().getTnRecord().getTnType() != null
						&& order.getGroupTnEntity().getTnRecord().getTnType().equals(TnType.LINE_TN)) {
					paramNameList.add(FXO_LINE);
				} else if (order.getGroupTnEntity() != null && order.getGroupTnEntity().getTnRecord() != null
						&& order.getGroupTnEntity().getTnRecord().getTnType() != null
						&& order.getGroupTnEntity().getTnRecord().getTnType().equals(TnType.DID_TN)) {
					paramNameList.add(FXO_DID);
				}

				//LOG.debug("PARAM NAME LIST for SYSTEM_UPDATE: {}", paramNameList.get(0));
			}
			if (order.getOrderHeader().getEntityType() == OrderEntity.TWO_WAY_TN.getIndex()) {
				entityType = OrderEntity.TWO_WAY_TN.toString();
				paramName = FXO;
				order.getOrderHeader().setEntityAction("I");
			}
			if (order.getOrderHeader().getEntityType() == OrderEntity.INBOUND_TN.getIndex()) {
				entityType = OrderEntity.INBOUND_TN.toString();
				paramName = FXO;
				order.getOrderHeader().setEntityAction("I");
			}
			if (order.getOrderHeader().getEntityType() == OrderEntity.LINE_TN.getIndex()) {
				entityType = OrderEntity.LINE_TN.toString();
				paramName = FXO;
				order.getOrderHeader().setEntityAction("I");
			}
			if (order.getOrderHeader().getEntityType() == OrderEntity.DID_TN.getIndex()) {
				entityType = OrderEntity.DID_TN.toString();
				paramName = FXO;
				order.getOrderHeader().setEntityAction("I");
			}

			paramNameList.add(paramName);

			orderTypeList = new ArrayList<>();
			orderTypeList.add("O".equalsIgnoreCase(order.getOrderHeader().getOrderType()) ? "D"
					: order.getOrderHeader().getOrderType());
			orderTypeList.add("*");

			functionCodeList = new ArrayList<>();
			functionCodeList.add(order.getOrderHeader().getFunctionCode());

			/** Fix for Function code : LNP_ACTIVATE && SYSTEM_UPDATE*/


			if("LNP_ACTIVATE".equalsIgnoreCase(order.getOrderHeader().getFunctionCode())) {
				if(!"BULK_SYSTEM_UPDATE".equalsIgnoreCase(entityType))
					functionCodeList.add("ALL");	
			} else {
				functionCodeList.add("ALL");
			}

			LOG.info(
					"Entered findServices Input Region : {} Entity Action: {} Entity Type: {} Function Code: {} orderTypeList: {} Param Name : {} ",
					regionList, order.getOrderHeader().getEntityAction(), entityType, functionCodeList, orderTypeList,
					paramNameList);

			// This will look for the param of order .For now its null.

			if (!CollectionUtils.isEmpty(paramNameList))
				tblRetailServiceExample.createCriteria().andProductEqualTo("RE").andOrderTypeIn(orderTypeList)
						.andFunctionCodeIn(functionCodeList).andEntityTypeEqualTo(entityType)
						.andEntityActionEqualTo(order.getOrderHeader().getEntityAction()).andRegionIn(regionList)
						.andParamNameIn(paramNameList);

			tblRetailServiceExample.setOrderByClause("PARAM_NAME, SEQ_NO");

			tblRetailServiceList = findE2EIRetailServices(tblRetailServiceExample);

		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new TranslatorException(ErrorCode.DATA_NOT_FOUND, "Failed to retrieve data for findServices");
		}
		LOG.info("Exit findServices");
		return tblRetailServiceList;
	}

	/**
	 * @param tblRetailServiceExample
	 * @return tblRetailServiceList
	 * @throws TranslatorException
	 */
	public List<TblRetailService> findE2EIRetailServices(TblRetailServiceExample tblRetailServiceExample)
			throws TranslatorException {
		LOG.info("Entered - findE2EIRetailServices");

		List<TblRetailService> tblRetailServiceList = null;

		tblRetailServiceList = customTblRetailServiceMapper.findRetailServices(tblRetailServiceExample);

		if (tblRetailServiceList.size() <= 0) {
			throw new TranslatorException(ErrorCode.DATA_NOT_FOUND,
					"Failed to retrieve data for findE2EIRetailServices");
		}
		LOG.info("Exit - findE2EIRetailServices");
		return tblRetailServiceList;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.vz.esap.translation.order.dao.VOIPOrderDao#
	 * updateTblSafeStoreTranslationStartTime(com.vz.esap.translation.dao.model.
	 * TblSafeStore)
	 */
	@Override
	public void updateTblSafeStoreTranslationStartTime(TblSafeStore tblSafeStoreObject) {
		LOG.info("Entered updateTblSafeStoreTranslationStartTime");
		customTblSafeStoreMapper.updateTblSafeStoreWithTranslationStartTime(tblSafeStoreObject);
		LOG.info("Exit updateTblSafeStoreTranslationStartTime");

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.vz.esap.translation.order.dao.VOIPOrderDao#
	 * updateTblSafeStoreTranslationEndTime(com.vz.esap.translation.dao.model.
	 * TblSafeStore)
	 */
	@Override
	public void updateTblSafeStoreTranslationEndTime(TblSafeStore tblSafeStoreObject) {
		LOG.info("Entered updateTblSafeStoreTranslationEndTime api");
		customTblSafeStoreMapper.updateTblSafeStoreWithTranslationEndTime(tblSafeStoreObject);
		LOG.info("Exit updateTblSafeStoreTranslationEndTime api");

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.vz.esap.translation.order.dao.VOIPOrderDao#insertTblSafeStore(com.vz.esap
	 * .translation.dao.model.TblSafeStore)
	 */
	@Override
	public void insertTblSafeStore(TblSafeStore tblSafeStoreObject) {
		LOG.info("Entered insertTblSafeStore api");
		customTblSafeStoreMapper.insert(tblSafeStoreObject);
		LOG.info("Exit insertTblSafeStore api");

	}

	// :Added for inserting order segment

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.vz.esap.translation.order.dao.VOIPOrderDao#createTableEnvOrderSegment(com
	 * .vz.esap.translation.dao.model.TblEnvOrderSegment)
	 */
	@Override
	public long createTableEnvOrderSegment(TblEnvOrderSegment tblEnvOrderSegment) {
		long count = tblEnvOrderSegmentMapper.insert(tblEnvOrderSegment);
		return count;
	}

	// :Added for quering env order

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.vz.esap.translation.order.dao.VOIPOrderDao#getTableEnvOrder(com.vz.esap.
	 * translation.dao.model.TblEnvOrder)
	 */
	@Override
	public List<TblEnvOrder> getTableEnvOrder(TblEnvOrder tblEnvOrder) throws TranslatorException {
		LOG.info("Entered - getTableEnvOrder");

		LOG.info(
				"OrderNumber:{} ,MasterOrderNumber:{} ,VersionNumber:{} ,Region:{} ,OrderStatus{} ,OrderClassify:{} ,ProjectId:{} ",
				tblEnvOrder.getOrderNumber(), tblEnvOrder.getMasterOrderNumber(), tblEnvOrder.getVersionNumber(),
				tblEnvOrder.getRegion(), tblEnvOrder.getOrderStatus(), tblEnvOrder.getOrderClassify(),
				tblEnvOrder.getProjectId());
		TblEnvOrderExample tblEnvOrderExMapper = null;
		List<TblEnvOrder> tblEnvOrderList = null;
		try {
			tblEnvOrderExMapper = new TblEnvOrderExample();

			if (tblEnvOrder.getMasterOrderNumber() != null) {
				if (tblEnvOrder.getOrderStatus() != null)
					tblEnvOrderExMapper.createCriteria().andOrderNumberEqualTo(tblEnvOrder.getOrderNumber())
							.andMasterOrderNumberEqualTo(tblEnvOrder.getMasterOrderNumber())
							.andVersionNumberEqualTo(tblEnvOrder.getVersionNumber())
							.andRegionEqualTo(tblEnvOrder.getRegion())
							.andOrderStatusEqualTo(tblEnvOrder.getOrderStatus())
							.andOrderClassifyEqualTo(tblEnvOrder.getOrderClassify())
							.andProjectIdEqualTo(tblEnvOrder.getProjectId());
				else
					tblEnvOrderExMapper.createCriteria().andOrderNumberEqualTo(tblEnvOrder.getOrderNumber())
							.andMasterOrderNumberEqualTo(tblEnvOrder.getMasterOrderNumber())
							.andVersionNumberEqualTo(tblEnvOrder.getVersionNumber())
							.andRegionEqualTo(tblEnvOrder.getRegion())
							.andOrderClassifyEqualTo(tblEnvOrder.getOrderClassify())
							.andProjectIdEqualTo(tblEnvOrder.getProjectId());

				LOG.debug("Test 22 - getTableEnvOrder");
			} else {
				LOG.debug("Test 33 - getTableEnvOrder");
				if (tblEnvOrder.getOrderStatus() != null)
					tblEnvOrderExMapper.createCriteria().andOrderNumberEqualTo(tblEnvOrder.getOrderNumber())
							.andVersionNumberEqualTo(tblEnvOrder.getVersionNumber())
							.andRegionEqualTo(tblEnvOrder.getRegion())
							.andOrderStatusEqualTo(tblEnvOrder.getOrderStatus())
							.andOrderClassifyEqualTo(tblEnvOrder.getOrderClassify())
							.andProjectIdEqualTo(tblEnvOrder.getProjectId());
				else
					tblEnvOrderExMapper.createCriteria().andOrderNumberEqualTo(tblEnvOrder.getOrderNumber())
							.andVersionNumberEqualTo(tblEnvOrder.getVersionNumber())
							.andRegionEqualTo(tblEnvOrder.getRegion())
							.andOrderClassifyEqualTo(tblEnvOrder.getOrderClassify())
							.andProjectIdEqualTo(tblEnvOrder.getProjectId());

			}

			tblEnvOrderExMapper.setOrderByClause("receive_date desc");

			tblEnvOrderList = customTblEnvOrderMapper.selectByExample(tblEnvOrderExMapper);
			LOG.debug("Fetched values - getTableEnvOrder");

		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new TranslatorException(ErrorCode.DATA_NOT_FOUND, "Failed to retrieve data for getTableEnvOrder");
		}
		LOG.info("Exit - getTableEnvOrder");

		LOG.debug("Test 11 tblEnvOrderList {} ", tblEnvOrderList);

		return tblEnvOrderList;
	}

	// :Added for inserting env order details
	@Override
	public long createEnvOrderDetails(TblEnvOrderDetails tblEnvOrderDetails) {
		long count = customTblEnvOrderDetailsMapper.insertSelective(tblEnvOrderDetails);
		return count;
	}

	// :Added for quering env order details

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.vz.esap.translation.order.dao.VOIPOrderDao#getEnvOrderDetails(com.vz.esap
	 * .translation.dao.model.TblEnvOrderDetails)
	 */
	@Override
	public List<TblEnvOrderDetails> getEnvOrderDetails(TblEnvOrderDetails tblEnvOrderDetails) {
		List<TblEnvOrderDetails> tblEnvOrderDetailsList = null;

		tblEnvOrderDetailsList = customTblEnvOrderDetailsMapper.getCustomTblEnvOrderDetails(tblEnvOrderDetails);

		return tblEnvOrderDetailsList;
	}

	// :Added for quering order tbl
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.vz.esap.translation.order.dao.VOIPOrderDao#getTblOrder(com.vz.esap.
	 * translation.dao.model.TblOrder)
	 */
	@Override
	public List<TblOrder> getTblOrder(TblOrder tblOrder) {
		LOG.info("VOIPOrderDaoImpl - getTblOrder");
		TblOrderExample tblOrderExampleMapper = new TblOrderExample();
		tblOrderExampleMapper.createCriteria().andEnvOrderIdEqualTo(tblOrder.getEnvOrderId());// :include all

		return customTblOrderMapper.selectByExample(tblOrderExampleMapper);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.vz.esap.translation.order.dao.VOIPOrderDao#getTblOrder(com.vz.esap.
	 * translation.dao.model.TblOrder)
	 */
	@Override
	public List<TblOrder> getPrevTblOrder(TblOrder tblOrder, OrderEntity orderEntity) {
		LOG.info("VOIPOrderDaoImpl - getPrevTblOrder");
		TblOrderExample tblOrderExampleMapper = new TblOrderExample();

		LOG.debug("EnvOrderId::{}", tblOrder.getEnvOrderId());

		if (orderEntity != null) {
			LOG.debug("Upstream Task Id::{}", orderEntity.ordinal());
			tblOrderExampleMapper.createCriteria().andEnvOrderIdEqualTo(tblOrder.getEnvOrderId())
					.andUpstreamTaskIdEqualTo(Long.valueOf(orderEntity.ordinal()));
		} else {
			tblOrderExampleMapper.createCriteria().andEnvOrderIdEqualTo(tblOrder.getEnvOrderId());
		}

		customTblOrderMapper.selectByExample(tblOrderExampleMapper);

		return customTblOrderMapper.selectByExample(tblOrderExampleMapper);
	}

	// :Added to get order details
	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.vz.esap.translation.order.dao.VOIPOrderDao#getOrderDetailsEntities(com.vz
	 * .esap.translation.dao.model.TblOrderDetails)
	 */
	@Override
	public List<TblOrderDetails> getOrderDetailsEntities(TblOrderDetails tblOrderDetails) {
		LOG.info("VOIPOrderDaoImpl - getOrderDetailsEntities {}", tblOrderDetails.getOrderId());
		List<TblOrderDetails> tblOrderDetailsList = customTblOrderDetailsMapper
				.getTblOrderDetailsEntities(tblOrderDetails);
		LOG.info("Order Detail Id : {}",
				(tblOrderDetailsList != null && !tblOrderDetailsList.isEmpty() && tblOrderDetailsList.get(0) != null
						&& tblOrderDetailsList.get(0).getOrderDetailId() != null)
								? tblOrderDetailsList.get(0).getOrderDetailId()
								: "Entities(Order Detail Id) doesn't exists"); // null check


		return tblOrderDetailsList;
	}

	// :Added to get order details based on action and parent
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.vz.esap.translation.order.dao.VOIPOrderDao#
	 * getOrderDetailsWithActionAndParent(long, java.lang.String, boolean,
	 * java.lang.String, com.vz.esap.translation.dao.model.TblOrderDetails)
	 */
	@Override
	public List<TblOrderDetails> getOrderDetailsWithActionAndParent(long parentId, String action, boolean delta,
			String paramName, TblOrderDetails tblOrderDetails) {
		LOG.info("Entered - getOrderDetailsWithActionAndParent");
		LOG.info(
				"In - getOrderDetailsWithActionAndParent parentId = {} "
						+ ",action = {} ,delta = {} , paramName = {} , OrderId = {}",
				tblOrderDetails.getParentId(), tblOrderDetails.getAction(), delta, tblOrderDetails.getParamName(),
				tblOrderDetails.getOrderId());
		List<TblOrderDetails> tblOrderDetailsList = null;
		if (action == null && parentId <= 0 && paramName == null)
			tblOrderDetailsList = customTblOrderDetailsMapper.getOrderDetailsForNoActionAndNoParent(tblOrderDetails);
		if (action != null && parentId <= 0 && paramName == null)
			tblOrderDetailsList = customTblOrderDetailsMapper
					.getOrderDetailsForDefiniteActionAndNoParent(tblOrderDetails);
		if (action != null && parentId > 0 && paramName == null)
			tblOrderDetailsList = customTblOrderDetailsMapper
					.getOrderDetailsForDefiniteActionAndParentId(tblOrderDetails);
		if (action == null && parentId > 0 && paramName == null)
			tblOrderDetailsList = customTblOrderDetailsMapper.getOrderDetailsForNoActionAndParentId(tblOrderDetails);
		if (action == null && parentId <= 0 && paramName != null)
			tblOrderDetailsList = customTblOrderDetailsMapper
					.getOrderDetailsForDefiniteActionAndParentName(tblOrderDetails);
		if (action == null && parentId <= 0 && paramName != null)
			tblOrderDetailsList = customTblOrderDetailsMapper.getOrderDetailsForNoActionAndParentName(tblOrderDetails);
		LOG.info("Exit - getOrderDetailsWithActionAndParent");
		return tblOrderDetailsList;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.vz.esap.translation.order.dao.VOIPOrderDao#getConfigParamValue(com.vz.
	 * esap.translation.dao.model.TblConfigParams)
	 */
	@Override
	public List<TblConfigParams> getConfigParamValue(TblConfigParams tblConfigParams) throws TranslatorException {
		LOG.info("VOIPOrderDaoImpl - getConfigParamValue");

		List<TblConfigParams> tblConfigParamsList = null;
		TblConfigParamsExample tblConfigParamsExData = null;
		try {
			tblConfigParamsExData = new TblConfigParamsExample();

			LOG.debug("Process Name :{} , Param Name :{} , Param Group :{} , Status :{}",
					tblConfigParams.getProcessName(), tblConfigParams.getParamName(), tblConfigParams.getParamGroup(),
					tblConfigParams.getStatus());

			if (tblConfigParams.getParamGroup() != null) {
				tblConfigParamsExData.createCriteria().andProcessNameEqualTo(tblConfigParams.getProcessName())
						.andParamNameEqualTo(tblConfigParams.getParamName())
						.andParamGroupEqualTo(tblConfigParams.getParamGroup())
						.andStatusEqualTo(tblConfigParams.getStatus());
			} else {
				tblConfigParamsExData.createCriteria().andProcessNameEqualTo(tblConfigParams.getProcessName())
						.andParamNameEqualTo(tblConfigParams.getParamName())
						.andStatusEqualTo(tblConfigParams.getStatus());
			}

			tblConfigParamsList = customTblConfigParamsMapper.selectByExample(tblConfigParamsExData);

			LOG.debug("List : {} Param : {}", tblConfigParamsList, tblConfigParamsList.get(0));

		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new TranslatorException(ErrorCode.DATA_NOT_FOUND, "Failed to retrieve data for getConfigParamValue");
		}

		return tblConfigParamsList;
	}

	@Override
	public List<TblOrderDetails> getTnOrderDetailsEntities(TblOrderDetails tblOrderDetails) {
		LOG.info("VOIPOrderDaoImpl - getTnOrderDetailsEntities {}", tblOrderDetails.getOrderId());
		List<TblOrderDetails> tblOrderDetailsList = null;
		try {
			tblOrderDetailsList = customTblOrderDetailsMapper
					.getTblOrderDetailsTNEntities(tblOrderDetails);
			LOG.info("Order Detail Id : {}",  !tblOrderDetailsList.isEmpty() ? tblOrderDetailsList.get(0).getOrderDetailId() : "No Records found");
		} catch (Exception e) {
			LOG.error("Exception {} ", e);
		}

		return tblOrderDetailsList;
	}

	/**
	 * @return customTblOrderServiceMapper
	 */
	public CustomTblOrderServiceMapper getCustomTblOrderServiceMapper() {
		return customTblOrderServiceMapper;
	}

	/**
	 * @param customTblOrderServiceMapper
	 */
	public void setCustomTblOrderServiceMapper(CustomTblOrderServiceMapper customTblOrderServiceMapper) {
		this.customTblOrderServiceMapper = customTblOrderServiceMapper;
	}

	/**
	 * @return customTblEnvOrderMapper
	 */
	public CustomTblEnvOrderMapper getCustomTblEnvOrderMapper() {
		return customTblEnvOrderMapper;
	}

	/**
	 * @param customTblEnvOrderMapper
	 */
	public void setCustomTblEnvOrderMapper(CustomTblEnvOrderMapper customTblEnvOrderMapper) {
		this.customTblEnvOrderMapper = customTblEnvOrderMapper;
	}

	/**
	 * @return customTblOrderMapper
	 */
	public CustomTblOrderMapper getCustomTblOrderMapper() {
		return customTblOrderMapper;
	}

	/**
	 * @param customTblOrderMapper
	 */
	public void setCustomTblOrderMapper(CustomTblOrderMapper customTblOrderMapper) {
		this.customTblOrderMapper = customTblOrderMapper;
	}

	/**
	 * @return customTblOrderDetailsMapper
	 */
	public CustomTblOrderDetailsMapper getCustomTblOrderDetailsMapper() {
		return customTblOrderDetailsMapper;
	}

	/**
	 * @param customTblOrderDetailsMapper
	 */
	public void setCustomTblOrderDetailsMapper(CustomTblOrderDetailsMapper customTblOrderDetailsMapper) {
		this.customTblOrderDetailsMapper = customTblOrderDetailsMapper;
	}

	/**
	 * @return customTblEnvOrderRespMapper
	 */
	public CustomTblEnvOrderRespMapper getCustomTblEnvOrderRespMapper() {
		return customTblEnvOrderRespMapper;
	}

	/**
	 * @param customTblEnvOrderRespMapper
	 */
	public void setCustomTblEnvOrderRespMapper(CustomTblEnvOrderRespMapper customTblEnvOrderRespMapper) {
		this.customTblEnvOrderRespMapper = customTblEnvOrderRespMapper;
	}

	/**
	 * @return customTblRetailServiceMapper
	 */
	public CustomTblRetailServiceMapper getCustomTblRetailServiceMapper() {
		return customTblRetailServiceMapper;
	}

	/**
	 * @param customTblRetailServiceMapper
	 */
	public void setCustomTblRetailServiceMapper(CustomTblRetailServiceMapper customTblRetailServiceMapper) {
		this.customTblRetailServiceMapper = customTblRetailServiceMapper;
	}

	/**
	 * @return customTblSafeStoreMapper
	 */
	public CustomTblSafeStoreMapper getCustomTblSafeStoreMapper() {
		return customTblSafeStoreMapper;
	}

	/**
	 * @param customTblSafeStoreMapper
	 */
	public void setCustomTblSafeStoreMapper(CustomTblSafeStoreMapper customTblSafeStoreMapper) {
		this.customTblSafeStoreMapper = customTblSafeStoreMapper;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.vz.esap.translation.order.dao.VOIPOrderDao#
	 * createParentChildOrderRelationship(com.vz.esap.translation.dao.model.
	 * TblEnvOrder)
	 */
	@Override
	public void createParentChildOrderRelationship(TblEnvOrder tblEnvOrder) {
		LOG.info(
				"Entered createParentChildOrderRelationship For tblEnvOrder.getEnvOrderId() = {} and tblEnvOrder.getVersionNumber() = {} ",
				tblEnvOrder.getEnvOrderId(), tblEnvOrder.getVersionNumber());
		
		TblOrderExample tblOrderExampleMapper = new TblOrderExample();
		tblOrderExampleMapper.createCriteria().andEnvOrderIdEqualTo(tblEnvOrder.getEnvOrderId())
				.andVersionNoEqualTo(tblEnvOrder.getVersionNumber().toString())
				.andOrderStatusNotEqualTo(104L).andFlowPathIn(Arrays.asList(FlowPath.F.toString()))
				.andOrderTypeIn(Arrays.asList(OrderType.getValueReverse("IN"), OrderType.getValueReverse("CHANGE")));

		List<TblOrder> tblOrderListForward = customTblOrderMapper.selectByExample(tblOrderExampleMapper);
		
		tblOrderExampleMapper = new TblOrderExample();
		tblOrderExampleMapper.createCriteria().andEnvOrderIdEqualTo(tblEnvOrder.getEnvOrderId())
				.andVersionNoEqualTo(tblEnvOrder.getVersionNumber().toString())
				.andFlowPathIn(Arrays.asList(FlowPath.R.toString()));

		List<TblOrder> tblOrderListReverse = customTblOrderMapper.selectByExample(tblOrderExampleMapper);
		
		
		tblOrderExampleMapper = new TblOrderExample();
		tblOrderExampleMapper.createCriteria().andEnvOrderIdEqualTo(tblEnvOrder.getEnvOrderId())
				.andVersionNoEqualTo(tblEnvOrder.getVersionNumber().toString()).andOrderTypeIn(
						Arrays.asList(OrderType.getValueReverse("DISCONNECT"), OrderType.getValueReverse("OUT")));

		List<TblOrder> tblOrderListCancel = customTblOrderMapper.selectByExample(tblOrderExampleMapper);
		
		if(!CollectionUtils.isEmpty(tblOrderListForward)) {
			LOG.info("Going to createParentChildOrderRelationshipForward for Forward Pass");
			createParentChildOrderRelationshipForward(tblOrderListForward, tblEnvOrder);
			
		} 
		if(!CollectionUtils.isEmpty(tblOrderListReverse)) {
			LOG.info("Going to createParentChildOrderRelationshipReverse for Reverse Pass");
			createParentChildOrderRelationshipCancelOrReverse(tblOrderListReverse);
			createReverseForwardRelationship(tblOrderListReverse, tblOrderListForward);
			
		} 
		if(!CollectionUtils.isEmpty(tblOrderListCancel)) {
			LOG.info("Going to createParentChildOrderRelationshipReverse for Disconnect");
			createParentChildOrderRelationshipCancelOrReverse(tblOrderListCancel);
			
		}
		
		LOG.info("Exited createParentChildOrderRelationship");
	}
	
	public void createReverseForwardRelationship(List<TblOrder> tblOrderListReverse,
			List<TblOrder> tblOrderListForward) {
		LOG.info("Entered createReverseForwardRelationship");
		TblParentOrders tblParentOrders = null;
		
		//Last reverse order id should be assigned as parent to
		//First forward order 12345(F) - 54321(R)
		//Initially first forward order will not have parent.
		tblOrderListReverse.sort(Comparator.comparing(TblOrder :: getOrderId));
		long reverseParentId = tblOrderListReverse.get(tblOrderListReverse.size()-1).getOrderId();
		
//		tblOrderListForward.sort(Comparator.comparing(TblOrder :: getOrderId));
//		long forwardchildId = tblOrderListForward.get(0).getOrderId();
		
		//forwardSuperParent - first forward order which is not having parentId.
		
		LOG.info("reverseParentId :: {} :: forwardchildId {}", reverseParentId, forwardSuperParent);
		
		if(forwardSuperParent != -1 && !orderParentExist(reverseParentId, forwardSuperParent)) {
			LOG.info("Inserting Parent-Child records :: Reverse - Forward");
			tblParentOrders = new TblParentOrders();
			tblParentOrders.setOrderId(forwardSuperParent);
			tblParentOrders.setParentOrderId(reverseParentId);
			tblParentOrders.setParentPending('Y');
			tblParentOrdersMapper.insert(tblParentOrders);
		} else {
			LOG.error("Already parentId record present");
		}
		
		LOG.info("Exit createReverseForwardRelationship");
	}

	private void createParentChildOrderRelationshipCancelOrReverse(List<TblOrder> tblOrderListReverse) {
		LOG.info("Exited createParentChildOrderRelationshipCancelOrReverse");

		boolean superParentAllocated = false;
		long parentOrderId = -1;
		TblParentOrders tblParentOrders = null;

		for (TblOrder tblOrder : tblOrderListReverse) {
			LOG.info("TblOrder Id = {} ", tblOrder.getOrderId());

			if (isSuperParentCancelOrReverse(tblOrder, tblOrderListReverse) && !superParentAllocated) {
				LOG.info("Super Parent TblOrder Id = {} , Upstream Task id = {} ", tblOrder.getOrderId(),
						tblOrder.getUpstreamTaskId());
				superParentAllocated = true;
				continue;

			} else if (23L != tblOrder.getUpstreamTaskId()) {

				parentOrderId = getParentOrderIdCancelOrReverse(tblOrder, tblOrderListReverse);

				if (parentOrderId != -1) {
					tblParentOrders = new TblParentOrders();
					tblParentOrders.setOrderId(tblOrder.getOrderId());
					tblParentOrders.setParentOrderId(parentOrderId);
					tblParentOrders.setParentPending('Y');
					tblParentOrdersMapper.insert(tblParentOrders);
				}
			} else if (23L == tblOrder.getUpstreamTaskId()) {

				for (TblOrder tblOrderLoc : tblOrderListReverse) {

					if (67L == tblOrderLoc.getUpstreamTaskId() || 68L == tblOrderLoc.getUpstreamTaskId()
							|| 71L == tblOrderLoc.getUpstreamTaskId() || 72L == tblOrderLoc.getUpstreamTaskId()) {

						OrderEntity orderEntity = OrderEntity.values()[tblOrderLoc.getUpstreamTaskId().intValue()];
											
						if (orderEntity.toString().equalsIgnoreCase(tblOrder.getAccountNumber())) {
							tblParentOrders = new TblParentOrders();
							tblParentOrders.setOrderId(tblOrder.getOrderId());
							tblParentOrders.setParentOrderId(tblOrderLoc.getOrderId());
							
							if(tblOrderLoc.getOrderStatus() == WorkOrderEnum.Status.WO_CANCELLED) {
								tblParentOrders.setParentPending('N');
							}else {
								tblParentOrders.setParentPending('Y');
							}
							
							tblParentOrdersMapper.insert(tblParentOrders);
							
						}

					}
				}
			}
		}
		LOG.info("Exited createParentChildOrderRelationshipCancelOrReverse");
	}

	/**
	 * @param tblOrderListForward
	 */
	@Deprecated
	private void createParentChildOrderRelationshipForward(List<TblOrder> tblOrderListForward) {
		LOG.info("Exited createParentChildOrderRelationshipForward");

		boolean superParentAllocated = false;
		long parentOrderId = -1;
		TblParentOrders tblParentOrders = null;

		for (TblOrder tblOrder : tblOrderListForward) {
			LOG.info("TblOrder Id = {} ", tblOrder.getOrderId());

			if (isSuperParent(tblOrder, tblOrderListForward) && !superParentAllocated) {
				LOG.info("Super Parent TblOrder Id = {} , Upstream Task id = {} ", tblOrder.getOrderId(),
						tblOrder.getUpstreamTaskId());
				superParentAllocated = true;
				continue;

			} else if (23L != tblOrder.getUpstreamTaskId()) {

				parentOrderId = getParentOrderId(tblOrder, tblOrderListForward);

				if (parentOrderId != -1) {
					tblParentOrders = new TblParentOrders();
					tblParentOrders.setOrderId(tblOrder.getOrderId());
					tblParentOrders.setParentOrderId(parentOrderId);
					tblParentOrders.setParentPending('Y');
					tblParentOrdersMapper.insert(tblParentOrders);
				}
			} else if (23L == tblOrder.getUpstreamTaskId()) {

				for (TblOrder tblOrderLoc : tblOrderListForward) {

					if (67L == tblOrderLoc.getUpstreamTaskId() || 68L == tblOrderLoc.getUpstreamTaskId()
							|| 71L == tblOrderLoc.getUpstreamTaskId() || 72L == tblOrderLoc.getUpstreamTaskId()) {

						tblParentOrders = new TblParentOrders();
						tblParentOrders.setOrderId(tblOrder.getOrderId());
						tblParentOrders.setParentOrderId(tblOrderLoc.getOrderId());
						tblParentOrders.setParentPending('Y');
						tblParentOrdersMapper.insert(tblParentOrders);

					}
				}
			}
		}
		LOG.info("Exited createParentChildOrderRelationshipForward");
	}
	
	
	
	/**
	 * @param tblOrderListForward
	 * @param TblEnvOrder
	 */
	void createParentChildOrderRelationshipForward(List<TblOrder> tblOrderListForward,
			TblEnvOrder tblEnvOrder) {
		LOG.info("Entered createParentChildOrderRelationshipForward for Env Order Service Type = {}",
				tblEnvOrder.getServiceType());

		boolean superParentAllocated = false;
		long parentOrderId = -1;
		TblParentOrders tblParentOrders = null;

		for (TblOrder tblOrder : tblOrderListForward) {
			LOG.info("TblOrder Id = {} , Upstream Task Id = {} , Env Order Service Type = {}", tblOrder.getOrderId(),
					tblOrder.getUpstreamTaskId(), tblEnvOrder.getServiceType());
			
			
			if (isSuperParent(tblOrder, tblOrderListForward) && !superParentAllocated) {
				LOG.info("Super Parent TblOrder Id = {} , Upstream Task id = {} ", tblOrder.getOrderId(),
						tblOrder.getUpstreamTaskId());
				superParentAllocated = true;
				forwardSuperParent = tblOrder.getOrderId();
				continue;

			} else if (23L != tblOrder.getUpstreamTaskId()
					&& !(ServiceType.HPBX_INSTAL.getValue().equalsIgnoreCase(tblEnvOrder.getServiceType())
							&& (4L == tblOrder.getUpstreamTaskId() || 43L == tblOrder.getUpstreamTaskId()))) {
				parentOrderId = getParentOrderId(tblOrder, tblOrderListForward);
				if (parentOrderId != -1) {
					if(!orderParentExist(parentOrderId, tblOrder.getOrderId())) {
						LOG.info("Inserting Parent-Child records :: 4L/43L Device/Etrunk");
						tblParentOrders = new TblParentOrders();
						tblParentOrders.setOrderId(tblOrder.getOrderId());
						tblParentOrders.setParentOrderId(parentOrderId);
						tblParentOrders.setParentPending('Y');
						tblParentOrdersMapper.insert(tblParentOrders);
					}
				}
			} else if (23L == tblOrder.getUpstreamTaskId()) {				
			
				for (TblOrder tblOrderLoc : tblOrderListForward) {
					LOG.info("tblOrderLoc.getUpstreamTaskId() = {}, tblOrder.getAccountNumber() = {}",
							tblOrderLoc.getUpstreamTaskId(), tblOrder.getAccountNumber());
							
					if (67L == tblOrderLoc.getUpstreamTaskId() || 68L == tblOrderLoc.getUpstreamTaskId()
							|| 71L == tblOrderLoc.getUpstreamTaskId() || 72L == tblOrderLoc.getUpstreamTaskId()) {

						OrderEntity orderEntity = OrderEntity.values()[tblOrderLoc.getUpstreamTaskId().intValue()];
						
						LOG.info("orderEntity Value = {}", orderEntity);

						if (orderEntity.toString().equalsIgnoreCase(tblOrder.getAccountNumber())) {
							if(!orderParentExist(tblOrderLoc.getOrderId(), tblOrder.getOrderId())) {
								LOG.info("Inserting Parent-Child records :: 23L - System Update");
								tblParentOrders = new TblParentOrders();
								tblParentOrders.setOrderId(tblOrder.getOrderId());
								tblParentOrders.setParentOrderId(tblOrderLoc.getOrderId());
								
								if(tblOrderLoc.getOrderStatus() == WorkOrderEnum.Status.WO_CANCELLED) {
									tblParentOrders.setParentPending('N');
								}else {
									tblParentOrders.setParentPending('Y');
								}
								
								tblParentOrdersMapper.insert(tblParentOrders);
							}
							
							
						}
					}
				}
			} else if (4L == tblOrder.getUpstreamTaskId()
					&& ServiceType.HPBX_INSTAL.getValue().equalsIgnoreCase(tblEnvOrder.getServiceType())) {

				for (TblOrder tblOrderLoc : tblOrderListForward) {

					if (3L == tblOrderLoc.getUpstreamTaskId()) {
						if(!orderParentExist(tblOrderLoc.getOrderId(), tblOrder.getOrderId())) {
							LOG.info("Inserting Parent-Child records :: 3L - Location");
							tblParentOrders = new TblParentOrders();
							tblParentOrders.setOrderId(tblOrder.getOrderId());
							tblParentOrders.setParentOrderId(tblOrderLoc.getOrderId());
							tblParentOrders.setParentPending('Y');
							tblParentOrdersMapper.insert(tblParentOrders);
						}

					}
				}
			} else if (43L == tblOrder.getUpstreamTaskId()
					&& ServiceType.HPBX_INSTAL.getValue().equalsIgnoreCase(tblEnvOrder.getServiceType())) {

				for (TblOrder tblOrderLoc : tblOrderListForward) {

					if (64L == tblOrderLoc.getUpstreamTaskId()) {
						if(!orderParentExist(tblOrderLoc.getOrderId(), tblOrder.getOrderId())) {
							LOG.info("Inserting Parent-Child records :: 64L - Two Way");
							tblParentOrders = new TblParentOrders();
							tblParentOrders.setOrderId(tblOrder.getOrderId());
							tblParentOrders.setParentOrderId(tblOrderLoc.getOrderId());
							tblParentOrders.setParentPending('Y');
							tblParentOrdersMapper.insert(tblParentOrders);
						}

					}
				}
			}
		}
		LOG.info("Exited createParentChildOrderRelationshipForward");
	}

	/**
	 * @param parentOrderId
	 * @param orderId
	 */
	private boolean orderParentExist(long parentOrderId, long orderId) {
		//Check orderId and ParentOrderId already exists or not.
		LOG.info("Order Id = {} and Parent Order Id = {} ", orderId, parentOrderId);
		TblParentOrdersExample tblParentOrdersExample = new TblParentOrdersExample();
		tblParentOrdersExample.createCriteria().andOrderIdEqualTo(orderId).andParentOrderIdEqualTo(parentOrderId);
		
		List<TblParentOrders> tblParentOrdersList = tblParentOrdersMapper.selectByExample(tblParentOrdersExample);
		LOG.info("tblParentOrdersList size :: {}", tblParentOrdersList.size());
		
		return tblParentOrdersList.size() > 0 ? true : false;
	}

	/**
	 * @param tblOrder
	 * @param tblOrderList
	 * @return parentOrderId
	 */
	private long getParentOrderId(TblOrder tblOrder, List<TblOrder> tblOrderList) {
		LOG.info("Entered getParentOrderId for Order Id  = {} ", tblOrder.getOrderId());
		
		long parentOrderId = -1;
		
		List<TblOrder> entOrder = stream((TblOrder[]) tblOrderList.toArray(new TblOrder[0]))
				.filter(tblOrd -> 1L == tblOrd.getUpstreamTaskId()).collect(Collectors.toList());
		
		List<TblOrder> locOrder = stream((TblOrder[]) tblOrderList.toArray(new TblOrder[0]))
				.filter(tblOrd -> 3L == tblOrd.getUpstreamTaskId()).collect(Collectors.toList());
		
		List<TblOrder> devTwoWayOrder = stream((TblOrder[]) tblOrderList.toArray(new TblOrder[0]))
				.filter(tblOrd -> 4L == tblOrd.getUpstreamTaskId() && tblOrd.getAccountNumber().contains("2W"))
				.collect(Collectors.toList());
		
		List<TblOrder> devOrder = stream((TblOrder[]) tblOrderList.toArray(new TblOrder[0]))
				.filter(tblOrd -> 4L == tblOrd.getUpstreamTaskId()).collect(Collectors.toList());
		
		List<TblOrder> twWayTgOrder = stream((TblOrder[]) tblOrderList.toArray(new TblOrder[0]))
				.filter(tblOrd -> 64L == tblOrd.getUpstreamTaskId()).collect(Collectors.toList());
		
		List<TblOrder> ibTgOrder = stream((TblOrder[]) tblOrderList.toArray(new TblOrder[0]))
				.filter(tblOrd -> 65L == tblOrd.getUpstreamTaskId()).collect(Collectors.toList());
		
		List<TblOrder> etTwoWayOrder = stream((TblOrder[]) tblOrderList.toArray(new TblOrder[0]))
				.filter(tblOrd -> 43L == tblOrd.getUpstreamTaskId() && tblOrd.getAccountNumber().contains("2W"))
				.collect(Collectors.toList());

		List<TblOrder> nbsTwoWayOrder = stream((TblOrder[]) tblOrderList.toArray(new TblOrder[0]))
				.filter(tblOrd -> 66L == tblOrd.getUpstreamTaskId() && tblOrd.getAccountNumber().contains("TWO_WAY"))
				.collect(Collectors.toList());
		
		List<TblOrder> etOrder = stream((TblOrder[]) tblOrderList.toArray(new TblOrder[0]))
				.filter(tblOrd -> 43L == tblOrd.getUpstreamTaskId()).collect(Collectors.toList());
		
		List<TblOrder> lineOrder = stream((TblOrder[]) tblOrderList.toArray(new TblOrder[0]))
				.filter(tblOrd -> 69L == tblOrd.getUpstreamTaskId()).collect(Collectors.toList());

		List<TblOrder> priDidOrder = stream((TblOrder[]) tblOrderList.toArray(new TblOrder[0]))
				.filter(tblOrd -> 70L == tblOrd.getUpstreamTaskId()).collect(Collectors.toList());
		
		List<TblOrder> nonPriDidOrder = stream((TblOrder[]) tblOrderList.toArray(new TblOrder[0]))
				.filter(tblOrd -> 73L == tblOrd.getUpstreamTaskId()).collect(Collectors.toList());
		
						
		if(1L == tblOrder.getUpstreamTaskId()) { 
			//No Parent for this Order But Do not Uncomment This is Required Later.
			
		} else if(3L == tblOrder.getUpstreamTaskId()) {
			
			if(!CollectionUtils.isEmpty(entOrder)) {
				parentOrderId = entOrder.get(entOrder.size() - 1).getOrderId();//For HPBX 3 Location will start as soon as Ent completes
				
			}
		} else if(4L == tblOrder.getUpstreamTaskId()) {
			
			if(!CollectionUtils.isEmpty(devTwoWayOrder) && tblOrder.getAccountNumber().contains("IB")) {
				parentOrderId = devTwoWayOrder.get(devTwoWayOrder.size() - 1).getOrderId();
				
			}else {
				if(!CollectionUtils.isEmpty(locOrder)) {
					parentOrderId = locOrder.get(locOrder.size() - 1).getOrderId();
					
				}else if(!CollectionUtils.isEmpty(entOrder)) {
					parentOrderId = entOrder.get(entOrder.size() - 1).getOrderId();
					
				}
			}
		} else if(64L == tblOrder.getUpstreamTaskId()) {					
		
			if(!CollectionUtils.isEmpty(devOrder)) {
				parentOrderId = devOrder.get(devOrder.size() - 1).getOrderId();
				
			} else if(!CollectionUtils.isEmpty(locOrder)) {							
				parentOrderId = locOrder.get(locOrder.size() - 1).getOrderId();
				
			}else if(!CollectionUtils.isEmpty(entOrder)) {
				parentOrderId = entOrder.get(entOrder.size() - 1).getOrderId();
				
			}
		} else if(65L == tblOrder.getUpstreamTaskId()) {			
		
			if(!CollectionUtils.isEmpty(twWayTgOrder)) {
				parentOrderId = twWayTgOrder.get(twWayTgOrder.size() - 1).getOrderId();
				
			} else if(!CollectionUtils.isEmpty(devOrder)) {
				parentOrderId = devOrder.get(devOrder.size() - 1).getOrderId();
				
			} else if(!CollectionUtils.isEmpty(locOrder)) {
				parentOrderId = locOrder.get(locOrder.size() - 1).getOrderId();
				
			}else if(!CollectionUtils.isEmpty(entOrder)) {
				parentOrderId = entOrder.get(entOrder.size() - 1).getOrderId();
				
			}
		} else if(43L == tblOrder.getUpstreamTaskId()) {
			//This Logic is Correct . Donot Change
			if(!CollectionUtils.isEmpty(etTwoWayOrder) && tblOrder.getAccountNumber().contains("IB")) {
				parentOrderId = etTwoWayOrder.get(etTwoWayOrder.size() - 1).getOrderId();
				
			}else {
				
				if(!CollectionUtils.isEmpty(ibTgOrder)) {
					parentOrderId = ibTgOrder.get(ibTgOrder.size() - 1).getOrderId();
					
				} else if(!CollectionUtils.isEmpty(twWayTgOrder)) {
					parentOrderId = twWayTgOrder.get(twWayTgOrder.size() - 1).getOrderId();
					
				} else if(!CollectionUtils.isEmpty(devOrder)) {
					parentOrderId = devOrder.get(devOrder.size() - 1).getOrderId();
					
				} else if(!CollectionUtils.isEmpty(locOrder)) {
					parentOrderId = locOrder.get(locOrder.size() - 1).getOrderId();
					
				}else if(!CollectionUtils.isEmpty(entOrder)) {
					parentOrderId = entOrder.get(0).getOrderId();
					
				}				
			}	
		} else if(66L == tblOrder.getUpstreamTaskId()) {
			//This Logic is Correct . Donot Change
			if(!CollectionUtils.isEmpty(nbsTwoWayOrder) && tblOrder.getAccountNumber().contains("INBOUND")) {
				parentOrderId = nbsTwoWayOrder.get(nbsTwoWayOrder.size() - 1).getOrderId();
				
			}else {
				
				if(!CollectionUtils.isEmpty(etOrder)) {
					parentOrderId = etOrder.get(etOrder.size() - 1).getOrderId();
					
				} else if(!CollectionUtils.isEmpty(ibTgOrder)) {
					parentOrderId = ibTgOrder.get(ibTgOrder.size() - 1).getOrderId();
					
				} else if(!CollectionUtils.isEmpty(twWayTgOrder)) {
					parentOrderId = twWayTgOrder.get(twWayTgOrder.size() - 1).getOrderId();
					
				} else if(!CollectionUtils.isEmpty(devOrder)) {
					parentOrderId = devOrder.get(devOrder.size() - 1).getOrderId();
					
				} else if(!CollectionUtils.isEmpty(locOrder)) {
					parentOrderId = locOrder.get(locOrder.size() - 1).getOrderId();
					
				}else if(!CollectionUtils.isEmpty(entOrder)) {
					parentOrderId = entOrder.get(0).getOrderId();
					
				}				
			}
			
		} else if(67L == tblOrder.getUpstreamTaskId()) {
			
			if(!CollectionUtils.isEmpty(ibTgOrder)) {
				parentOrderId = ibTgOrder.get(ibTgOrder.size() - 1).getOrderId();
				
			} else if(!CollectionUtils.isEmpty(twWayTgOrder)) {
				parentOrderId = twWayTgOrder.get(twWayTgOrder.size() - 1).getOrderId();
				
			} else if(!CollectionUtils.isEmpty(devOrder)) {
				parentOrderId = devOrder.get(devOrder.size() - 1).getOrderId();
				
			} else if(!CollectionUtils.isEmpty(locOrder)) {
				parentOrderId = locOrder.get(locOrder.size() - 1).getOrderId();
				
			}else if(!CollectionUtils.isEmpty(entOrder)) {
				parentOrderId = entOrder.get(0).getOrderId();
				
			}
		} else if(68L == tblOrder.getUpstreamTaskId()) {
			
			if(!CollectionUtils.isEmpty(ibTgOrder)) {
				parentOrderId = ibTgOrder.get(ibTgOrder.size() - 1).getOrderId();
				
			} else if(!CollectionUtils.isEmpty(twWayTgOrder)) {
				parentOrderId = twWayTgOrder.get(twWayTgOrder.size() - 1).getOrderId();
				
			} else if(!CollectionUtils.isEmpty(devOrder)) {
				parentOrderId = devOrder.get(devOrder.size() - 1).getOrderId();
				
			} else if(!CollectionUtils.isEmpty(locOrder)) {
				parentOrderId = locOrder.get(locOrder.size() - 1).getOrderId();
				
			}else if(!CollectionUtils.isEmpty(entOrder)) {
				parentOrderId = entOrder.get(0).getOrderId();
				
			}
		} else if (69L == tblOrder.getUpstreamTaskId()) {

			if (!CollectionUtils.isEmpty(devOrder)) {
				parentOrderId = devOrder.get(devOrder.size() - 1).getOrderId();

			} else if (!CollectionUtils.isEmpty(locOrder)) {
				parentOrderId = locOrder.get(locOrder.size() - 1).getOrderId();

			} else if (!CollectionUtils.isEmpty(entOrder)) {
				parentOrderId = entOrder.get(entOrder.size() - 1).getOrderId();

			}
			
		} else if(70L == tblOrder.getUpstreamTaskId()) {
			
			if (!CollectionUtils.isEmpty(lineOrder)) {
				parentOrderId = lineOrder.get(lineOrder.size() - 1).getOrderId();

			} else if (!CollectionUtils.isEmpty(devOrder)) {
				parentOrderId = devOrder.get(devOrder.size() - 1).getOrderId();

			} else if (!CollectionUtils.isEmpty(locOrder)) {
				parentOrderId = locOrder.get(locOrder.size() - 1).getOrderId();

			} else if (!CollectionUtils.isEmpty(entOrder)) {
				parentOrderId = entOrder.get(entOrder.size() - 1).getOrderId();

			}
		} else if(73L == tblOrder.getUpstreamTaskId()) {			

			if (!CollectionUtils.isEmpty(priDidOrder)) {
				parentOrderId = priDidOrder.get(priDidOrder.size() - 1).getOrderId();

			} else if (!CollectionUtils.isEmpty(lineOrder)) {
				parentOrderId = lineOrder.get(lineOrder.size() - 1).getOrderId();

			} else if (!CollectionUtils.isEmpty(devOrder)) {
				parentOrderId = devOrder.get(devOrder.size() - 1).getOrderId();

			} else if (!CollectionUtils.isEmpty(locOrder)) {
				parentOrderId = locOrder.get(locOrder.size() - 1).getOrderId();

			} else if (!CollectionUtils.isEmpty(entOrder)) {
				parentOrderId = entOrder.get(entOrder.size() - 1).getOrderId();

			}
		} else if(71L == tblOrder.getUpstreamTaskId()) {
			
			if (!CollectionUtils.isEmpty(lineOrder)) {
				parentOrderId = lineOrder.get(lineOrder.size() - 1).getOrderId();

			} else if (!CollectionUtils.isEmpty(devOrder)) {
				parentOrderId = devOrder.get(devOrder.size() - 1).getOrderId();

			} else if (!CollectionUtils.isEmpty(locOrder)) {
				parentOrderId = locOrder.get(locOrder.size() - 1).getOrderId();

			} else if (!CollectionUtils.isEmpty(entOrder)) {
				parentOrderId = entOrder.get(entOrder.size() - 1).getOrderId();

			}
		} else if(72L == tblOrder.getUpstreamTaskId()) {		
			
			if (!CollectionUtils.isEmpty(nonPriDidOrder)) {
				parentOrderId = nonPriDidOrder.get(nonPriDidOrder.size() - 1).getOrderId();

			} else if (!CollectionUtils.isEmpty(priDidOrder)) {
				parentOrderId = priDidOrder.get(priDidOrder.size() - 1).getOrderId();

			} else if (!CollectionUtils.isEmpty(lineOrder)) {
				parentOrderId = lineOrder.get(lineOrder.size() - 1).getOrderId();

			} else if (!CollectionUtils.isEmpty(devOrder)) {
				parentOrderId = devOrder.get(devOrder.size() - 1).getOrderId();

			} else if (!CollectionUtils.isEmpty(locOrder)) {
				parentOrderId = locOrder.get(locOrder.size() - 1).getOrderId();

			} else if (!CollectionUtils.isEmpty(entOrder)) {
				parentOrderId = entOrder.get(entOrder.size() - 1).getOrderId();

			}
		}

		LOG.info("Exited getParentOrderId for Order Id = {} and Parent Order Id = {} ", tblOrder.getOrderId(),
				parentOrderId);
		return parentOrderId;
	}
	
	

	/**
	 * @param tblOrder
	 * @param tblOrderList
	 * @return boolean
	 */
	boolean isSuperParent(TblOrder tblOrder, List<TblOrder> tblOrderList) {
		LOG.info("Entered isSuperParent for Upstream Task Id  = {} and Order Id = {} ", 
				tblOrder.getUpstreamTaskId(), tblOrder.getOrderId());

		if(1L == tblOrder.getUpstreamTaskId()) {
			//No Parent for this Order
			return true;
		} else if(3L == tblOrder.getUpstreamTaskId()) {					
			boolean hasParent = stream((TblOrder[]) tblOrderList.toArray(new TblOrder[0]))
					.anyMatch(tblOrd -> 1L == tblOrd.getUpstreamTaskId());			
			if(hasParent) {
				return false; //Parent Present for this Order
			}
			
		} else if(4L == tblOrder.getUpstreamTaskId()) {					
			boolean hasParent = stream((TblOrder[]) tblOrderList.toArray(new TblOrder[0]))
					.anyMatch(tblOrd -> 1L == tblOrd.getUpstreamTaskId() || 3L == tblOrd.getUpstreamTaskId());
			if(hasParent) {
				return false; //Parent Present for this Order
			}
		} else if(64L == tblOrder.getUpstreamTaskId()) {					
			boolean hasParent = stream((TblOrder[]) tblOrderList.toArray(new TblOrder[0]))
					.anyMatch(tblOrd -> 1L == tblOrd.getUpstreamTaskId() || 3L == tblOrd.getUpstreamTaskId()
							|| 4L == tblOrd.getUpstreamTaskId());
			if(hasParent) {
				return false;  //Parent Present for this Order
			}
		} else if(65L == tblOrder.getUpstreamTaskId()) {					
			boolean hasParent = stream((TblOrder[]) tblOrderList.toArray(new TblOrder[0]))
					.anyMatch(tblOrd -> 1L == tblOrd.getUpstreamTaskId() || 3L == tblOrd.getUpstreamTaskId()
							|| 4L == tblOrd.getUpstreamTaskId() || 64L == tblOrd.getUpstreamTaskId());
			if(hasParent) {
				return false;  //Parent Present for this Order
			}
		} else if(43L == tblOrder.getUpstreamTaskId()) {					
			boolean hasParent = stream((TblOrder[]) tblOrderList.toArray(new TblOrder[0]))
					.anyMatch(tblOrd -> 1L == tblOrd.getUpstreamTaskId() || 3L == tblOrd.getUpstreamTaskId()
							|| 4L == tblOrd.getUpstreamTaskId() || 64L == tblOrd.getUpstreamTaskId()
							|| 65L == tblOrd.getUpstreamTaskId());
			if(hasParent) {
				return false;  //Parent Present for this Order
			}
		} else if(66L == tblOrder.getUpstreamTaskId()) {					
			boolean hasParent = stream((TblOrder[]) tblOrderList.toArray(new TblOrder[0]))
					.anyMatch(tblOrd -> 1L == tblOrd.getUpstreamTaskId() || 3L == tblOrd.getUpstreamTaskId()
							|| 4L == tblOrd.getUpstreamTaskId() || 64L == tblOrd.getUpstreamTaskId()
							|| 65L == tblOrd.getUpstreamTaskId() || 43L == tblOrd.getUpstreamTaskId());
			if(hasParent) {
				return false;  //Parent Present for this Order
			}
		} else if(67L == tblOrder.getUpstreamTaskId()) {					
			boolean hasParent = stream((TblOrder[]) tblOrderList.toArray(new TblOrder[0]))
					.anyMatch(tblOrd -> 1L == tblOrd.getUpstreamTaskId() || 3L == tblOrd.getUpstreamTaskId()
							|| 4L == tblOrd.getUpstreamTaskId() || 64L == tblOrd.getUpstreamTaskId()
							|| 65L == tblOrd.getUpstreamTaskId() || 43L == tblOrd.getUpstreamTaskId()
							|| 66L == tblOrd.getUpstreamTaskId());
			if(hasParent) {
				return false;  //Parent Present for this Order
			}
		} else if(68L == tblOrder.getUpstreamTaskId()) {					
			boolean hasParent = stream((TblOrder[]) tblOrderList.toArray(new TblOrder[0]))
					.anyMatch(tblOrd -> 1L == tblOrd.getUpstreamTaskId() || 3L == tblOrd.getUpstreamTaskId()
							|| 4L == tblOrd.getUpstreamTaskId() || 64L == tblOrd.getUpstreamTaskId()
							|| 65L == tblOrd.getUpstreamTaskId() || 43L == tblOrd.getUpstreamTaskId()
							|| 66L == tblOrd.getUpstreamTaskId() || 67L == tblOrd.getUpstreamTaskId());
			
			if(hasParent) {
				return false;  //Parent Present for this Order
			}
		} else if(69L == tblOrder.getUpstreamTaskId()) {					
			boolean hasParent = stream((TblOrder[]) tblOrderList.toArray(new TblOrder[0]))
					.anyMatch(tblOrd -> 1L == tblOrd.getUpstreamTaskId() || 3L == tblOrd.getUpstreamTaskId()
							|| 4L == tblOrd.getUpstreamTaskId());
			if(hasParent) {
				return false;  //Parent Present for this Order
			}
		} else if(70L == tblOrder.getUpstreamTaskId()) {					
			boolean hasParent = stream((TblOrder[]) tblOrderList.toArray(new TblOrder[0]))
					.anyMatch(tblOrd -> 1L == tblOrd.getUpstreamTaskId() || 3L == tblOrd.getUpstreamTaskId()
							|| 4L == tblOrd.getUpstreamTaskId() || 69L == tblOrd.getUpstreamTaskId());
			if(hasParent) {
				return false;  //Parent Present for this Order
			}
		} else if(73L == tblOrder.getUpstreamTaskId()) {					
			boolean hasParent = stream((TblOrder[]) tblOrderList.toArray(new TblOrder[0]))
					.anyMatch(tblOrd -> 1L == tblOrd.getUpstreamTaskId() || 3L == tblOrd.getUpstreamTaskId()
							|| 4L == tblOrd.getUpstreamTaskId() || 69L == tblOrd.getUpstreamTaskId()
							|| 70L == tblOrd.getUpstreamTaskId());
			if(hasParent) {
				return false;  //Parent Present for this Order
			}
		} else if(71L == tblOrder.getUpstreamTaskId()) {					
			boolean hasParent = stream((TblOrder[]) tblOrderList.toArray(new TblOrder[0]))
					.anyMatch(tblOrd -> 1L == tblOrd.getUpstreamTaskId() || 3L == tblOrd.getUpstreamTaskId()
							|| 4L == tblOrd.getUpstreamTaskId() || 69L == tblOrd.getUpstreamTaskId()
							|| 70L == tblOrd.getUpstreamTaskId() || 73L == tblOrd.getUpstreamTaskId());
			if(hasParent) {
				return false;  //Parent Present for this Order
			}
		} else if(72L == tblOrder.getUpstreamTaskId()) {					
			boolean hasParent = stream((TblOrder[]) tblOrderList.toArray(new TblOrder[0]))
					.anyMatch(tblOrd -> 1L == tblOrd.getUpstreamTaskId() || 3L == tblOrd.getUpstreamTaskId()
							|| 4L == tblOrd.getUpstreamTaskId() || 69L == tblOrd.getUpstreamTaskId()
							|| 70L == tblOrd.getUpstreamTaskId() || 73L == tblOrd.getUpstreamTaskId()
							|| 71L == tblOrd.getUpstreamTaskId());
			if(hasParent) {
				return false;  //Parent Present for this Order
			}
		} else if(23L == tblOrder.getUpstreamTaskId()) {					
				return false;  //System Update Can never be Super Parent
		}else {
			return true;
		}

		LOG.info("Exited isSuperParent with Super Parent = {}", tblOrder.getOrderId());
		return true;
	}


	@Override
	public int upsertTblOrderDetails(Long orderId, List<ParamInfo> childParams, String action, long parentId, long leaf) {
		LOG.info("Entered upsertTblOrderDetails(orderId, childParams, action, parentId, leaf) parent Detail Id = {}, OrderId  = {}",
				parentId, orderId);
		try {
		List<TblOrderDetails> existingTblOrderDetailsList;
		Map<String, Object> todParams = null;
		TblOrderDetails tblOrderDetails = null;

		if (childParams != null && !childParams.isEmpty()) {

			for (ParamInfo param : childParams) {
				LOG.debug("TOD Parameter is ={}", param);
				
				//Below will insert complete param
				populateOrderDetails(orderId, param, action, parentId, leaf);
				
				//Below will update param name existing from above value
				for (ParamInfo paramChild : param.getChildParams()) {
					
					LOG.info("Incoming TOD Parameter Name is ={}", paramChild.getName());
					LOG.info("Incoming TOD Parameter Value is ={}", paramChild.getValue());
					
					todParams = new HashMap<>();
					todParams.put("prevOrderId", orderId);
					todParams.put("param_name", paramChild.getName().toUpperCase());
					existingTblOrderDetailsList = customTblOrderDetailsMapper.getOrderDetailParam(todParams);
					
				
					if (existingTblOrderDetailsList != null && !CollectionUtils.isEmpty(existingTblOrderDetailsList)
							&& paramChild.getValue() != null) {					
						
						for (TblOrderDetails tblOrderDetailsLoc : existingTblOrderDetailsList) {
							LOG.info("Param is present and Current value = {}", tblOrderDetailsLoc.getParamValue());
							
							tblOrderDetails = new TblOrderDetails();
							tblOrderDetails.setOrderDetailId(tblOrderDetailsLoc.getOrderDetailId());
							tblOrderDetails.setParamValue(paramChild.getValue());
							
							customTblOrderDetailsMapper.updateByPrimaryKeySelective(tblOrderDetails);
							
						}
					} 
					
				}
			}
		}
		
		}catch(Exception e) {
			LOG.error("Exception {} ", e);
		}
		
		LOG.info("Exited upsertTblOrderDetails(orderId, childParams, action, parentId, leaf)");
		return 0;
	}
	
	@Override
	public int upsertTblOrderDetails(List<TblOrderDetails> tblOrderDetailsList, List<ParamInfo> childParams,
			String action, long parentId, long leaf) {
		LOG.info("Entered upsertTblOrderDetails parent Detail Id = {}", parentId);

		if (childParams != null && !childParams.isEmpty()) {

			for (ParamInfo param : childParams) {
				LOG.debug("TOD Parameter is ={}", param);
				populateOrderDetails(tblOrderDetailsList.get(0).getOrderId(), param, action, parentId, leaf);
			}
		}
		LOG.info("Exited upsertTblOrderDetails");
		return 0;
	}

	@Override
	public void insertOrderMilestone(long envOrderId, long orderId, String wfService, long milestone, long status,
			long seqNo) {
		LOG.info("Entered insertOrderMilestone");

		TblMilestoneOrders tblMilestoneOrders = new TblMilestoneOrders();
		tblMilestoneOrders.setEnvOrderId(envOrderId);
		tblMilestoneOrders.setMilestone(milestone);
		tblMilestoneOrders.setOrderId(orderId);
		tblMilestoneOrders.setSeqNo(seqNo);
		tblMilestoneOrders.setStatus(status);
		tblMilestoneOrders.setTransactionId(null);
		tblMilestoneOrders.setWfService(wfService);

		tblMilestoneOrdersMapper.insert(tblMilestoneOrders);

		LOG.info("Exited insertOrderMilestone");
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.vz.esap.translation.order.dao.VOIPOrderDao#getTableEnvOrder(com.vz.esap.
	 * translation.dao.model.TblEnvOrder)
	 */
	@Override
	public List<TblEnvOrder> getTableEnvOrder(TblEnvOrder tblEnvOrder, List<Long> statusExclusion)
			throws TranslatorException {
		LOG.info("Entered - getTableEnvOrder(TblEnvOrder tblEnvOrder, List<Long> statusExclusion)");

		LOG.debug(
				"OrderNumber:{} ,MasterOrderNumber:{} ,VersionNumber:{} ,Region:{} ,OrderStatus{} ,OrderClassify:{} ,ProjectId:{} ",
				tblEnvOrder.getOrderNumber(), tblEnvOrder.getMasterOrderNumber(), tblEnvOrder.getVersionNumber(),
				tblEnvOrder.getRegion(), tblEnvOrder.getOrderStatus(), tblEnvOrder.getOrderClassify(),
				tblEnvOrder.getProjectId());
		TblEnvOrderExample tblEnvOrderExMapper = null;
		List<TblEnvOrder> tblEnvOrderList = null;
		try {
			tblEnvOrderExMapper = new TblEnvOrderExample();

			if (tblEnvOrder.getMasterOrderNumber() != null && statusExclusion != null) {
				tblEnvOrderExMapper.createCriteria().andOrderNumberEqualTo(tblEnvOrder.getOrderNumber())
						.andMasterOrderNumberEqualTo(tblEnvOrder.getMasterOrderNumber())
						.andVersionNumberEqualTo(tblEnvOrder.getVersionNumber())
						.andRegionEqualTo(tblEnvOrder.getRegion())
						.andOrderClassifyEqualTo(tblEnvOrder.getOrderClassify())
						.andProjectIdEqualTo(tblEnvOrder.getProjectId()).andOrderStatusNotIn(statusExclusion);
			} else if (tblEnvOrder.getMasterOrderNumber() == null && statusExclusion != null) {
				tblEnvOrderExMapper.createCriteria().andOrderNumberEqualTo(tblEnvOrder.getOrderNumber())
						.andVersionNumberEqualTo(tblEnvOrder.getVersionNumber())
						.andRegionEqualTo(tblEnvOrder.getRegion())
						.andOrderClassifyEqualTo(tblEnvOrder.getOrderClassify())
						.andProjectIdEqualTo(tblEnvOrder.getProjectId()).andOrderStatusNotIn(statusExclusion);
			} else {
				tblEnvOrderExMapper.createCriteria().andOrderNumberEqualTo(tblEnvOrder.getOrderNumber())
						.andVersionNumberEqualTo(tblEnvOrder.getVersionNumber())
						.andRegionEqualTo(tblEnvOrder.getRegion())
						.andOrderClassifyEqualTo(tblEnvOrder.getOrderClassify())
						.andProjectIdEqualTo(tblEnvOrder.getProjectId());
			}

			tblEnvOrderExMapper.setOrderByClause("receive_date desc");

			tblEnvOrderList = customTblEnvOrderMapper.selectByExample(tblEnvOrderExMapper);
			LOG.debug("Fetched values - getTableEnvOrder");

		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new TranslatorException(ErrorCode.DATA_NOT_FOUND, "Failed to retrieve data for getTableEnvOrder");
		}

		LOG.debug("tblEnvOrderList {} ", tblEnvOrderList);

		LOG.info("Exit - getTableEnvOrder(TblEnvOrder tblEnvOrder, List<String> statusExclusion)");
		return tblEnvOrderList;
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.vz.esap.translation.order.dao.VOIPOrderDao#getPrevVersionTableEnvOrder(com.vz.esap.
	 * translation.dao.model.TblEnvOrder)
	 */
	@Override
	public List<TblEnvOrder> getPrevVersionTableEnvOrder(TblEnvOrder tblEnvOrder)
			throws TranslatorException {
		LOG.info("Entered - getPrevVersionTableEnvOrder(TblEnvOrder tblEnvOrder)");

		LOG.debug(
				"OrderNumber:{} ,MasterOrderNumber:{} ,VersionNumber:{} ,Region:{} ,OrderStatus{} ,OrderClassify:{} ,ProjectId:{} ",
				tblEnvOrder.getOrderNumber(), tblEnvOrder.getMasterOrderNumber(), tblEnvOrder.getVersionNumber(),
				tblEnvOrder.getRegion(), tblEnvOrder.getOrderStatus(), tblEnvOrder.getOrderClassify(),
				tblEnvOrder.getProjectId());
		TblEnvOrderExample tblEnvOrderExMapper = null;
		List<TblEnvOrder> tblEnvOrderList = null;
		List<Long> statusExclusion = null;
		
			tblEnvOrderExMapper = new TblEnvOrderExample();
			statusExclusion = Arrays.asList(Long.parseLong(String.valueOf(WorkOrderEnum.Status.WO_ABORT)),
					Long.parseLong(String.valueOf(WorkOrderEnum.Status.WO_DUPLICATE)),
					Long.parseLong(String.valueOf(WorkOrderEnum.Status.WO_PREVPASS)),
					Long.parseLong(String.valueOf(WorkOrderEnum.Status.WO_TRANSLATION_FAIL)));
						
				tblEnvOrderExMapper.createCriteria()
						.andOrderNumberEqualTo(tblEnvOrder.getOrderNumber())
						.andVersionNumberLessThan(tblEnvOrder.getVersionNumber())
						.andRegionEqualTo(tblEnvOrder.getRegion())
						.andOrderClassifyNotEqualTo(Long.parseLong(String.valueOf(WorkOrderEnum.OrderClassify.PIT)))
						.andOrderClassifyEqualTo(tblEnvOrder.getOrderClassify())
						.andProjectIdEqualTo(tblEnvOrder.getProjectId())
						.andOrderStatusNotIn(statusExclusion);

			tblEnvOrderExMapper.setOrderByClause("receive_date desc");

			tblEnvOrderList = customTblEnvOrderMapper.selectByExample(tblEnvOrderExMapper);
			LOG.debug("Fetched values - getTableEnvOrder");

		LOG.debug("tblEnvOrderList {} ", tblEnvOrderList);

		LOG.info("Exit - getPrevVersionTableEnvOrder(TblEnvOrder tblEnvOrder)");
		return tblEnvOrderList;
	}

	@Override
	public List<TblOrder> getTblOrder(TblEnvOrder tblEnvOrder) {
		LOG.info("VOIPOrderDaoImpl - getTblOrder");
		TblOrderExample tblOrderExampleMapper = new TblOrderExample();

		LOG.info("EnvOrderId::{}", tblEnvOrder.getEnvOrderId());

		tblOrderExampleMapper.createCriteria().andEnvOrderIdEqualTo(tblEnvOrder.getEnvOrderId());

		customTblOrderMapper.selectByExample(tblOrderExampleMapper);

		return customTblOrderMapper.selectByExample(tblOrderExampleMapper);
	}

	@Override
	public List<TblRetailService> getTblRetailService(String service, String region) throws TranslatorException {
		LOG.info("Inside getTblRetailService");

		List<String> paramNameList = Arrays.asList(FXO_INBOUND, FXO_TWO_WAY, FXO, FXO_LINE, FXO_DID);

		List<String> functionCodeList = Arrays.asList(RELEASE, ALL);

		TblRetailServiceExample tblRetailServiceExample = new TblRetailServiceExample();

		if (!CollectionUtils.isEmpty(paramNameList))
			tblRetailServiceExample.createCriteria().andProductEqualTo("RE").andFunctionCodeIn(functionCodeList)
					.andParamNameIn(paramNameList).andWfServiceEqualTo(service.toUpperCase());

		tblRetailServiceExample.setOrderByClause("PARAM_NAME, SEQ_NO");

		return findE2EIRetailServices(tblRetailServiceExample);
	}

	@Override
	public List<TblOrderDetails> getOrderDetailsEntriesPerOrder(TblOrder tblOrder) {
		LOG.info("VOIPOrderDaoImpl - getOrderDetailsEntriesPerOrder for Order Id = {}", tblOrder.getOrderId());

		Map<String, Object> params = new HashMap<String, Object>();
		params.put("orderId", tblOrder.getOrderId());

		List<TblOrderDetails> tblOrderDetailsList = customTblOrderDetailsMapper.getTblOrderDetailsForOrder(params);
		if (tblOrderDetailsList != null && !tblOrderDetailsList.isEmpty())
			LOG.debug("Order Detail Id : {} and Size ={}", tblOrderDetailsList.get(0).getOrderDetailId(),
					tblOrderDetailsList.size());

		return tblOrderDetailsList;
	}

	@Override
	public void updateOrderServiceStatus(long orderId, long seqNumber, long serviceStatus) {
		LOG.info("Inside updateOrderService");

		customTblOrderServiceMapper.updateOrderServiceStatusByOrderIdOptionalSeqNum(orderId, seqNumber, serviceStatus);
	}

	@Override
	public TblEnvOrder getTblEnvOrderDetailsFromInventory(DBServiceResponse dbServiceResponse, String inventoryTable)
			throws TranslatorException {
		LOG.info("Entered getTblEnvOrderDetailsFromInventory for Inventory Table = {}", inventoryTable);

		HashSet<String> supportedType = new HashSet<>();
		supportedType.add(TranslationConstant.TBL_ENTERPRISE);

		if (!supportedType.contains(inventoryTable))
			throw new TranslatorException(ErrorCode.UNSUPPORTED_TABLE_TYPE, "Unsupported Table Type");

		long tblEnvOrderId = -1;
		TblEnvOrder tblEnvOrder = null;

		for (TblRow tblRows : dbServiceResponse.getTableRows()) {
			tblEnvOrderId = Long.valueOf(tblRows.getTblRow().get("ENV_ORDER_ID").getValue());
			LOG.info("TblEnvOrder Id : {}", tblEnvOrderId);
		}

		if (tblEnvOrderId != -1)
			tblEnvOrder = customTblEnvOrderMapper.selectByPrimaryKey(tblEnvOrderId);

		LOG.info("Exit getTblEnvOrderDetailsFromInventory");

		return tblEnvOrder;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.vz.esap.translation.order.dao.VOIPOrderDao#getDistinctTrunkFromTnDetails(
	 * com.vz.esap.translation.order.model.request.VOIPOrderRequest)
	 */
	@Override
	public List<String> getDistinctTrunkFromTnDetails(VOIPOrderRequest voipOrderRequest) throws TranslatorException {
		LOG.info("Entered getDistinctTrunkFromTnDetails");

		List<String> distinctTrunkList = null;

		TblLorTnDetailsExample tblLorTnDetailsExample = new TblLorTnDetailsExample();
		tblLorTnDetailsExample.createCriteria()
				.andOrderNumberEqualTo(voipOrderRequest.getOrderHeader().getWorkOrderNumber())
				.andOrderVersionEqualTo(voipOrderRequest.getOrderHeader().getWorkOrderVersion())
				.andSpecCodeIn(Arrays.asList("SP_XO_TRU","SP_XO_TRU_CON_LINE_LOC","SP_XO_TRUID"));

		List<TblLorTnDetails> tblLorTnDetailsList = tblLorTnDetailsMapper.selectByExample(tblLorTnDetailsExample);

		if (tblLorTnDetailsList != null && !tblLorTnDetailsList.isEmpty()) {

			LOG.info("TN row size total = {}", tblLorTnDetailsList.size());
			distinctTrunkList = new ArrayList<>();

			for (TblLorTnDetails tblLorTnDetails : tblLorTnDetailsList) {
				distinctTrunkList.add(tblLorTnDetails.getSpecValue());
			}
			
			LOG.info("distinctTrunkList = {}", distinctTrunkList.size());
			LOG.info("Unique distinctTrunkList = {}",
					distinctTrunkList.stream().distinct().collect(Collectors.toList()));

		} else {
			throw new TranslatorException(ErrorCode.PC_TN_FETCH_FAILURE, "Exception while fetching TNs");
		}

		LOG.info("Exit getDistinctTrunkFromTnDetails");
		return distinctTrunkList.stream().distinct().collect(Collectors.toList());
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.vz.esap.translation.order.dao.VOIPOrderDao#getChangedTnDetails(com.vz.
	 * esap.translation.order.model.request.VOIPOrderRequest)
	 */
	@Override
	public List<TblLorTnChngDetails> getChangedTnDetails(VOIPOrderRequest voipOrderRequest) {
		LOG.info("Entered getChangedTnDetails");

		List<TblLorTnChngDetails> tblLorTnChngDetailsList = null;

		TblLorTnChngDetailsExample tblLorTnChngDetailsExample = new TblLorTnChngDetailsExample();
		tblLorTnChngDetailsExample.createCriteria()
				.andOrderNumberEqualTo(voipOrderRequest.getOrderHeader().getWorkOrderNumber())
				.andOrderVersionEqualTo(voipOrderRequest.getOrderHeader().getWorkOrderVersion());

		tblLorTnChngDetailsList = tblLorTnChngDetailsMapper.selectByExample(tblLorTnChngDetailsExample);

		LOG.info("Exit getChangedTnDetails");
		return tblLorTnChngDetailsList;
	}
	
	
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.vz.esap.translation.order.dao.VOIPOrderDao#
	 * createParentChildOrderRelationship(com.vz.esap.translation.dao.model.
	 * TblEnvOrder, com.vz.esap.translation.enums.EsapEnum.FlowPath)
	 */
	@Deprecated
	@Override
	public void createParentChildOrderRelationship(TblEnvOrder tblEnvOrder, FlowPath flowPath) throws TranslatorException {
		LOG.info(
				"Entered createParentChildOrderRelationship For tblEnvOrder.getEnvOrderId() = {} "
				+ "and tblEnvOrder.getVersionNumber() = {} and Flow Path = {} ",
				tblEnvOrder.getEnvOrderId(), tblEnvOrder.getVersionNumber(), flowPath);

		TblOrderExample tblOrderExampleMapper = new TblOrderExample();
		tblOrderExampleMapper.createCriteria().andEnvOrderIdEqualTo(tblEnvOrder.getEnvOrderId())
				.andVersionNoEqualTo(tblEnvOrder.getVersionNumber().toString()).andOrderStatusNotEqualTo(104L)
				.andFlowPathEqualTo(flowPath.toString());

		List<TblOrder> tblOrderList = customTblOrderMapper.selectByExample(tblOrderExampleMapper);

		if (tblOrderList.isEmpty()) {
			LOG.info("Fetched Order List Not Available");
			//throw new TranslatorException(ErrorCode.TBL_ORDER_RECORD_NOT_FOUND, "Fetched Order List Not Available");
			return;
		}
		
		List<TblOrder> sysUpdOrder = stream((TblOrder[]) tblOrderList.toArray(new TblOrder[0]))
				.filter(tblOrd -> 23L == tblOrd.getUpstreamTaskId()).collect(Collectors.toList());
		
		List<Long> tblOrderIdList = null;
		TblParentOrders tblParentOrders = null;
		long parentOrderId = -1;
		List<Long> tblOrderIdListSorted = null;

		if (FlowPath.R.equals(flowPath)) {
			
			if (!CollectionUtils.isEmpty(sysUpdOrder)) {
				parentOrderId = sysUpdOrder.get(0).getOrderId();
				
				for (TblOrder tblOrderLoc : tblOrderList) {
					if (67L == tblOrderLoc.getUpstreamTaskId() || 68L == tblOrderLoc.getUpstreamTaskId()
							|| 71L == tblOrderLoc.getUpstreamTaskId() || 72L == tblOrderLoc.getUpstreamTaskId()) {

						tblParentOrders = new TblParentOrders();
						tblParentOrders.setOrderId(sysUpdOrder.get(0).getOrderId());
						tblParentOrders.setParentOrderId(tblOrderLoc.getOrderId());
						tblParentOrders.setParentPending('Y');
						tblParentOrdersMapper.insert(tblParentOrders);
					}
				}
			}
			
			tblOrderIdList = new ArrayList<>();
			for (TblOrder tblOrder : tblOrderList) {
				
				if (67L == tblOrder.getUpstreamTaskId() || 68L == tblOrder.getUpstreamTaskId()
						|| 71L == tblOrder.getUpstreamTaskId() || 72L == tblOrder.getUpstreamTaskId()) {
					
					continue;
				}
				tblOrderIdList.add(tblOrder.getOrderId());
			}
			Collections.sort(tblOrderIdList);
			
			long parentId = -1;
			for (Long orderId : tblOrderIdList) {
				LOG.debug("Order Id : {} , Parent Order Id : {} ", orderId, parentId);

				if (parentId == -1) {
					parentId = orderId;
					LOG.info("First Parent Id {} ", parentId);
					continue;
				}

				tblParentOrders = new TblParentOrders();
				tblParentOrders.setOrderId(orderId);
				tblParentOrders.setParentOrderId(parentId);
				tblParentOrders.setParentPending('Y');
				tblParentOrdersMapper.insert(tblParentOrders);
				
				parentId = orderId;
				LOG.debug("New Parent Id {} ", parentId);
			}

		}
		LOG.info("Exited createParentChildOrderRelationship");
	}
	
	
	/**
	 * @param tblOrder
	 * @param tblOrderList
	 * @return boolean
	 */
	boolean isSuperParentCancelOrReverse(TblOrder tblOrder, List<TblOrder> tblOrderList) {
		LOG.info("Entered isSuperParentCancelOrReverse for Upstream Task Id  = {} and Order Id = {} ", 
				tblOrder.getUpstreamTaskId(), tblOrder.getOrderId());

		if(23L == tblOrder.getUpstreamTaskId()) {					
				return false;  //System Update Can never be Super Parent
				
		} else if (72L == tblOrder.getUpstreamTaskId() || 71L == tblOrder.getUpstreamTaskId()
				|| 68L == tblOrder.getUpstreamTaskId() || 67L == tblOrder.getUpstreamTaskId()) {					
			//No Parent for this Order
			return true;
			
		} else if(73L == tblOrder.getUpstreamTaskId() || 70L == tblOrder.getUpstreamTaskId()) {					
			boolean hasParent = stream((TblOrder[]) tblOrderList.toArray(new TblOrder[0]))
					.anyMatch(tblOrd -> 72L == tblOrd.getUpstreamTaskId());
			if(hasParent) {
				return false;  //Parent Present for this Order
			}
		} else if(69L == tblOrder.getUpstreamTaskId()) {					
			boolean hasParent = stream((TblOrder[]) tblOrderList.toArray(new TblOrder[0]))
					.anyMatch(tblOrd -> 71L == tblOrd.getUpstreamTaskId());
			if(hasParent) {
				return false;  //Parent Present for this Order
			}
		} else if(66L == tblOrder.getUpstreamTaskId()) {					
			boolean hasParent = stream((TblOrder[]) tblOrderList.toArray(new TblOrder[0]))
					.anyMatch(tblOrd -> 72L == tblOrd.getUpstreamTaskId() || 71L == tblOrd.getUpstreamTaskId()
							|| 68L == tblOrd.getUpstreamTaskId() || 67L == tblOrd.getUpstreamTaskId()
							|| 73L == tblOrd.getUpstreamTaskId() || 70L == tblOrd.getUpstreamTaskId()
							|| 69L == tblOrd.getUpstreamTaskId());
			if(hasParent) {
				return false;  //Parent Present for this Order
			}
		} else if(43L == tblOrder.getUpstreamTaskId()) {					
			boolean hasParent = stream((TblOrder[]) tblOrderList.toArray(new TblOrder[0]))
					.anyMatch(tblOrd -> 72L == tblOrd.getUpstreamTaskId() || 71L == tblOrd.getUpstreamTaskId()
							|| 68L == tblOrd.getUpstreamTaskId() || 67L == tblOrd.getUpstreamTaskId()
							|| 73L == tblOrd.getUpstreamTaskId() || 70L == tblOrd.getUpstreamTaskId()
							|| 69L == tblOrd.getUpstreamTaskId() || 66L == tblOrd.getUpstreamTaskId());
			if(hasParent) {
				return false;  //Parent Present for this Order
			}
		} else if(65L == tblOrder.getUpstreamTaskId()) {					
			boolean hasParent = stream((TblOrder[]) tblOrderList.toArray(new TblOrder[0]))
					.anyMatch(tblOrd -> 72L == tblOrd.getUpstreamTaskId() || 71L == tblOrd.getUpstreamTaskId()
							|| 68L == tblOrd.getUpstreamTaskId() || 67L == tblOrd.getUpstreamTaskId()
							|| 73L == tblOrd.getUpstreamTaskId() || 70L == tblOrd.getUpstreamTaskId()
							|| 69L == tblOrd.getUpstreamTaskId() || 66L == tblOrd.getUpstreamTaskId()
							|| 43L == tblOrd.getUpstreamTaskId());
			if(hasParent) {
				return false;  //Parent Present for this Order
			}
		} else if(64L == tblOrder.getUpstreamTaskId()) {					
			boolean hasParent = stream((TblOrder[]) tblOrderList.toArray(new TblOrder[0]))
					.anyMatch(tblOrd -> 72L == tblOrd.getUpstreamTaskId() || 71L == tblOrd.getUpstreamTaskId()
							|| 68L == tblOrd.getUpstreamTaskId() || 67L == tblOrd.getUpstreamTaskId()
							|| 73L == tblOrd.getUpstreamTaskId() || 70L == tblOrd.getUpstreamTaskId()
							|| 69L == tblOrd.getUpstreamTaskId() || 66L == tblOrd.getUpstreamTaskId()
							|| 43L == tblOrd.getUpstreamTaskId() || 65L == tblOrd.getUpstreamTaskId());
			if(hasParent) {
				return false;  //Parent Present for this Order
			}
		} else if(4L == tblOrder.getUpstreamTaskId()) {					
			boolean hasParent = stream((TblOrder[]) tblOrderList.toArray(new TblOrder[0]))
					.anyMatch(tblOrd -> 72L == tblOrd.getUpstreamTaskId() || 71L == tblOrd.getUpstreamTaskId()
							|| 68L == tblOrd.getUpstreamTaskId() || 67L == tblOrd.getUpstreamTaskId()
							|| 73L == tblOrd.getUpstreamTaskId() || 70L == tblOrd.getUpstreamTaskId()
							|| 69L == tblOrd.getUpstreamTaskId() || 66L == tblOrd.getUpstreamTaskId()
							|| 43L == tblOrd.getUpstreamTaskId() || 65L == tblOrd.getUpstreamTaskId()
							|| 64L == tblOrd.getUpstreamTaskId());
			if(hasParent) {
				return false;  //Parent Present for this Order
			}
		} else if(3L == tblOrder.getUpstreamTaskId()) {					
			boolean hasParent = stream((TblOrder[]) tblOrderList.toArray(new TblOrder[0]))
					.anyMatch(tblOrd -> 72L == tblOrd.getUpstreamTaskId() || 71L == tblOrd.getUpstreamTaskId()
							|| 68L == tblOrd.getUpstreamTaskId() || 67L == tblOrd.getUpstreamTaskId()
							|| 73L == tblOrd.getUpstreamTaskId() || 70L == tblOrd.getUpstreamTaskId()
							|| 69L == tblOrd.getUpstreamTaskId() || 66L == tblOrd.getUpstreamTaskId()
							|| 43L == tblOrd.getUpstreamTaskId() || 65L == tblOrd.getUpstreamTaskId()
							|| 64L == tblOrd.getUpstreamTaskId() || 4L == tblOrd.getUpstreamTaskId());
			if(hasParent) {
				return false;  //Parent Present for this Order
			}
		} else if(1L == tblOrder.getUpstreamTaskId()) {					
			boolean hasParent = stream((TblOrder[]) tblOrderList.toArray(new TblOrder[0]))
					.anyMatch(tblOrd -> 72L == tblOrd.getUpstreamTaskId() || 71L == tblOrd.getUpstreamTaskId()
							|| 68L == tblOrd.getUpstreamTaskId() || 67L == tblOrd.getUpstreamTaskId()
							|| 73L == tblOrd.getUpstreamTaskId() || 70L == tblOrd.getUpstreamTaskId()
							|| 69L == tblOrd.getUpstreamTaskId() || 66L == tblOrd.getUpstreamTaskId()
							|| 43L == tblOrd.getUpstreamTaskId() || 65L == tblOrd.getUpstreamTaskId()
							|| 64L == tblOrd.getUpstreamTaskId() || 4L == tblOrd.getUpstreamTaskId()
							|| 3L == tblOrd.getUpstreamTaskId());
			if(hasParent) {
				return false;  //Parent Present for this Order
			}
		} else {
			return true;
		}

		LOG.info("Exited isSuperParentCancelOrReverse with Super Parent = {}", tblOrder.getOrderId());
		return true;
	}
	
	
	/**
	 * @param tblOrder
	 * @param tblOrderList
	 * @return parentOrderId
	 */
	private long getParentOrderIdCancelOrReverse(TblOrder tblOrder, List<TblOrder> tblOrderList) {
		LOG.info("Entered getParentOrderIdCancelOrReverse for Order Id  = {} ", tblOrder.getOrderId());
		
		long parentOrderId = -1;

		List<TblOrder> locOrder = stream((TblOrder[]) tblOrderList.toArray(new TblOrder[0]))
				.filter(tblOrd -> 3L == tblOrd.getUpstreamTaskId()).collect(Collectors.toList());
			
		List<TblOrder> devOrder = stream((TblOrder[]) tblOrderList.toArray(new TblOrder[0]))
				.filter(tblOrd -> 4L == tblOrd.getUpstreamTaskId()).collect(Collectors.toList());
		
		List<TblOrder> twWayTgOrder = stream((TblOrder[]) tblOrderList.toArray(new TblOrder[0]))
				.filter(tblOrd -> 64L == tblOrd.getUpstreamTaskId()).collect(Collectors.toList());
		
		List<TblOrder> ibTgOrder = stream((TblOrder[]) tblOrderList.toArray(new TblOrder[0]))
				.filter(tblOrd -> 65L == tblOrd.getUpstreamTaskId()).collect(Collectors.toList());
	
		List<TblOrder> etOrder = stream((TblOrder[]) tblOrderList.toArray(new TblOrder[0]))
				.filter(tblOrd -> 43L == tblOrd.getUpstreamTaskId()).collect(Collectors.toList());
				
		List<TblOrder> sysUpdOrder = stream((TblOrder[]) tblOrderList.toArray(new TblOrder[0]))
				.filter(tblOrd -> 23L == tblOrd.getUpstreamTaskId()).collect(Collectors.toList());
		
		List<TblOrder> nbsOrder = stream((TblOrder[]) tblOrderList.toArray(new TblOrder[0]))
				.filter(tblOrd -> 66L == tblOrd.getUpstreamTaskId()).collect(Collectors.toList());
		
		if (72L == tblOrder.getUpstreamTaskId() || 71L == tblOrder.getUpstreamTaskId()
				|| 68L == tblOrder.getUpstreamTaskId() || 67L == tblOrder.getUpstreamTaskId()
				|| 66L == tblOrder.getUpstreamTaskId()) {					
			//No Parent for this Order But Do not Uncomment This is Required Later.			
		} else if(73L == tblOrder.getUpstreamTaskId() || 70L == tblOrder.getUpstreamTaskId()
				|| 69L == tblOrder.getUpstreamTaskId()) {					
			
			if (!CollectionUtils.isEmpty(sysUpdOrder)) {
				parentOrderId = sysUpdOrder.get(sysUpdOrder.size() - 1).getOrderId();

			}
		} else if(43L == tblOrder.getUpstreamTaskId()) {					
			
			if (!CollectionUtils.isEmpty(nbsOrder)) {
				parentOrderId = nbsOrder.get(nbsOrder.size() - 1).getOrderId();

			}else if (!CollectionUtils.isEmpty(sysUpdOrder)) {
				parentOrderId = sysUpdOrder.get(sysUpdOrder.size() - 1).getOrderId();

			}
		} else if (65L == tblOrder.getUpstreamTaskId()) {

			if (!CollectionUtils.isEmpty(etOrder)) {
				parentOrderId = etOrder.get(etOrder.size() - 1).getOrderId();

			} else if (!CollectionUtils.isEmpty(nbsOrder)) {
				parentOrderId = nbsOrder.get(nbsOrder.size() - 1).getOrderId();

			} else if (!CollectionUtils.isEmpty(sysUpdOrder)) {
				parentOrderId = sysUpdOrder.get(sysUpdOrder.size() - 1).getOrderId();

			}
		} else if(64L == tblOrder.getUpstreamTaskId()) {					
			
			if (!CollectionUtils.isEmpty(ibTgOrder)) {
				parentOrderId = ibTgOrder.get(ibTgOrder.size() - 1).getOrderId();

			} else if (!CollectionUtils.isEmpty(etOrder)) {
				parentOrderId = etOrder.get(etOrder.size() - 1).getOrderId();

			} else if (!CollectionUtils.isEmpty(nbsOrder)) {
				parentOrderId = nbsOrder.get(nbsOrder.size() - 1).getOrderId();

			} else if (!CollectionUtils.isEmpty(sysUpdOrder)) {
				parentOrderId = sysUpdOrder.get(sysUpdOrder.size() - 1).getOrderId();

			}
		} else if(4L == tblOrder.getUpstreamTaskId()) {					
			
			if (!CollectionUtils.isEmpty(twWayTgOrder)) {
				parentOrderId = twWayTgOrder.get(twWayTgOrder.size() - 1).getOrderId();

			} else if (!CollectionUtils.isEmpty(ibTgOrder)) {
				parentOrderId = ibTgOrder.get(ibTgOrder.size() - 1).getOrderId();

			} else if (!CollectionUtils.isEmpty(etOrder)) {
				parentOrderId = etOrder.get(etOrder.size() - 1).getOrderId();

			} else if (!CollectionUtils.isEmpty(nbsOrder)) {
				parentOrderId = nbsOrder.get(nbsOrder.size() - 1).getOrderId();

			} else if (!CollectionUtils.isEmpty(sysUpdOrder)) {
				parentOrderId = sysUpdOrder.get(sysUpdOrder.size() - 1).getOrderId();

			}
		} else if(3L == tblOrder.getUpstreamTaskId()) {					
			
			if (!CollectionUtils.isEmpty(devOrder)) {
				parentOrderId = devOrder.get(devOrder.size() - 1).getOrderId();

			} else if (!CollectionUtils.isEmpty(twWayTgOrder)) {
				parentOrderId = twWayTgOrder.get(twWayTgOrder.size() - 1).getOrderId();

			} else if (!CollectionUtils.isEmpty(ibTgOrder)) {
				parentOrderId = ibTgOrder.get(ibTgOrder.size() - 1).getOrderId();

			} else if (!CollectionUtils.isEmpty(etOrder)) {
				parentOrderId = etOrder.get(etOrder.size() - 1).getOrderId();

			} else if (!CollectionUtils.isEmpty(nbsOrder)) {
				parentOrderId = nbsOrder.get(nbsOrder.size() - 1).getOrderId();

			} else if (!CollectionUtils.isEmpty(sysUpdOrder)) {
				parentOrderId = sysUpdOrder.get(sysUpdOrder.size() - 1).getOrderId();

			}
			
		}  else if(1L == tblOrder.getUpstreamTaskId()) {					
			
			if (!CollectionUtils.isEmpty(locOrder)) {
				parentOrderId = locOrder.get(locOrder.size() - 1).getOrderId();

			}else if (!CollectionUtils.isEmpty(devOrder)) {
				parentOrderId = devOrder.get(devOrder.size() - 1).getOrderId();

			} else if (!CollectionUtils.isEmpty(twWayTgOrder)) {
				parentOrderId = twWayTgOrder.get(twWayTgOrder.size() - 1).getOrderId();

			} else if (!CollectionUtils.isEmpty(ibTgOrder)) {
				parentOrderId = ibTgOrder.get(ibTgOrder.size() - 1).getOrderId();

			} else if (!CollectionUtils.isEmpty(etOrder)) {
				parentOrderId = etOrder.get(etOrder.size() - 1).getOrderId();

			} else if (!CollectionUtils.isEmpty(nbsOrder)) {
				parentOrderId = nbsOrder.get(nbsOrder.size() - 1).getOrderId();

			} else if (!CollectionUtils.isEmpty(sysUpdOrder)) {
				parentOrderId = sysUpdOrder.get(sysUpdOrder.size() - 1).getOrderId();

			}
		}
		
		LOG.info("Exited getParentOrderIdCancelOrReverse for Order Id = {} and Parent Order Id = {} ", tblOrder.getOrderId(),
				parentOrderId);
		return parentOrderId;
	}

	
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.vz.esap.translation.order.dao.VOIPOrderDao#
	 * getTableEnvOrderFromOrderHeader(com.vz.esap.translation.order.model.request.
	 * OrderHeader)
	 */
	@Override
	public List<TblEnvOrder> getTableEnvOrderFromOrderHeader(OrderHeader orderHeader)
			throws TranslatorException, GenericException {
		LOG.info("Entered - getTableEnvOrderFromOrderHeader");

		LOG.info("OrderNumber:{} ,VersionNumber:{} , FunctionCode:{} ", orderHeader.getWorkOrderNumber(),
				orderHeader.getWorkOrderVersion(), orderHeader.getFunctionCode());
		
		TblEnvOrderExample tblEnvOrderExMapper = null;
		List<TblEnvOrder> tblEnvOrderList = null;
		int orderClassify = 0;
		
		try {
			tblEnvOrderExMapper = new TblEnvOrderExample();
			
			if(FunctionCode.VALIDATE.toString().equals(orderHeader.getFunctionCode())) {
				orderClassify = WorkOrderEnum.OrderClassify.VALIDATE;
			} else if(FunctionCode.RELEASE.toString().equals(orderHeader.getFunctionCode())) {
				orderClassify = WorkOrderEnum.OrderClassify.RELEASE;
			} else if(FunctionCode.CIRCUIT_INFO.toString().equals(orderHeader.getFunctionCode())) {
				orderClassify = WorkOrderEnum.OrderClassify.CIRCUIT_INFO;
			} else if(FunctionCode.REL_DEACTIVATE.toString().equals(orderHeader.getFunctionCode())) {
				orderClassify = WorkOrderEnum.OrderClassify.REL_DEACTIVATE;
			} else if(FunctionCode.REL_SUSPEND.toString().equals(orderHeader.getFunctionCode())) {
				orderClassify = WorkOrderEnum.OrderClassify.REL_SUSPEND;
			} else if(FunctionCode.NBS_PROV_CONFIG.toString().equals(orderHeader.getFunctionCode())) {
				orderClassify = WorkOrderEnum.OrderClassify.RELEASE;
			}

			tblEnvOrderExMapper.createCriteria().andOrderNumberEqualTo(orderHeader.getWorkOrderNumber())
			.andVersionNumberEqualTo(Long.valueOf(orderHeader.getWorkOrderVersion()))
			.andOrderClassifyEqualTo(Long.valueOf(orderClassify));

			tblEnvOrderExMapper.setOrderByClause("receive_date desc");

			tblEnvOrderList = customTblEnvOrderMapper.selectByExample(tblEnvOrderExMapper);

		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new GenericException("Error While Retreiving Data", "Error While Retreiving Data from tblEnvOrder");
		}
		LOG.info("Exit - getTableEnvOrderFromOrderHeader");

		return tblEnvOrderList;
	}
	
	
	@Override
	public List<TblRetailService> findServicesValidation(String region, String orderType) throws TranslatorException {
		LOG.info("Entered - findServicesValidation(region, orderType) with Order Action = {}", orderType);
		TblRetailServiceExample tblRetailServiceExample = new TblRetailServiceExample();
		List<String> regionList = new ArrayList<String>();
		regionList.add(region);
		regionList.add("ALL");
		String orderTypeLoc = "I";
		
		if (orderType != null) {
			orderTypeLoc = orderType;
		}
		
		Criteria criteria = tblRetailServiceExample.createCriteria();
		criteria.andProductEqualTo("RE").andOrderTypeEqualTo(orderTypeLoc).andFunctionCodeEqualTo("VALIDATE")
				.andEntityTypeEqualTo("VALIDATION").andEntityActionEqualTo("V").andRegionIn(regionList);

		tblRetailServiceExample.setOrderByClause("PARAM_NAME, SEQ_NO");

		List<TblRetailService> tblRetailServiceList = findE2EIRetailServices(tblRetailServiceExample);

		LOG.info("Exit - findServicesValidation(region, orderType)");
		
		return tblRetailServiceList;
	}
	
	@Override
	public void updateTblOrderDetailParamValue(TblOrderDetails tblOrderDetail) {
		LOG.info("updateTblOrderDetailParamValue : {}, With Status :{} ",tblOrderDetail);
		customTblOrderDetailsMapper.updateByPrimaryKey(tblOrderDetail);

	}
	
	@Override
	public void updateTblEnvOrderError(Long envOrderId, String errorCode) {
		LOG.info("Entered - updateTblEnvOrderError for EnvOrderId = {}, errorCode = {}", envOrderId, errorCode);

		TblEnvOrder tblEnvOrder = new TblEnvOrder();
		tblEnvOrder.setEnvOrderId(envOrderId);
		tblEnvOrder.setErrorCode(errorCode);

		int count = customTblEnvOrderMapper.updateByPrimaryKeySelective(tblEnvOrder);

		LOG.info("Exit - updateTblEnvOrderError Row Updated = {} ...", count);
	}
	
	@Override
	public List<String> getSkipTasksForReverseService(String service, long aqmWorkId) throws GenericException {
		List<String> skipTasks = null;
		
		try {
			skipTasks = new ArrayList<String>();
			Map<String, Object> params = new HashMap<String, Object>();
			params.put("wfService", service);
			params.put("aqmWorkId", aqmWorkId);
			skipTasks = customTblOrderServiceMapper.getSkipTasksForReverseService(params);
			LOG.info("skipTasks Count :: {}", skipTasks);
		} catch (Exception e) {
			LOG.error("Exception {} {}", e.getMessage(), e);
			throw new GenericException("Error While Retreiving skip tasks", "Error While Retreiving skip tasks");
		}
		return skipTasks;
	}

	@Override
	public void updateTblOrderService(TblOrderService tblOrderService) throws GenericException {
		LOG.info("updateTblOrderDetailParamValue : {}, With Status :{} ",tblOrderService);
		customTblOrderServiceMapper.updateByPrimaryKey(tblOrderService);
		
	}

	@Override
	public void deletePendingWOTaskByOrderID(Long orderId) throws GenericException {
		LOG.info("deletePendingWOTaskByOrderID : {}, With orderId :{} ",orderId);
		tblPendingWoTaskDbBeanMapper.deleteByPrimaryKey(orderId);
	}
	
	@Override
	public void createTblOrderDetails(TblOrderDetails tblOrderDetails, String param_name, String param_value) {
		LOG.info("Enterted createTblOrderDetails : {}, With param_name :{},param_value:{} ",tblOrderDetails,param_name,param_value);
		TblOrderDetails tblOrderDeatilsObject = prepareOrderDetail(tblOrderDetails.getOrderId(), param_name,param_value, 0L,
				tblOrderDetails.getSeqNo(), tblOrderDetails.getAction(), tblOrderDetails.getLeaf(), tblOrderDetails.getParamType());
		insertOrderDetails(tblOrderDeatilsObject);
		
		LOG.info("Exited createTblOrderDetails : {}, With param_name :{},param_value:{} ",tblOrderDetails,param_name,param_value);
		
	}
	
	@Override
	public String getAsClli(String bsAsId) {
		return customTblOrderServiceMapper.getAsClli(bsAsId);
	}
	
	@Override
	public String getBwCluster(String bsAsId) {
		return customTblOrderServiceMapper.getBwCluster(bsAsId);
	}
}
