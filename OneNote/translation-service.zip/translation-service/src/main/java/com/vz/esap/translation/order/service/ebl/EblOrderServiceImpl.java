package com.vz.esap.translation.order.service.ebl;

import static java.util.Arrays.stream;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.google.common.collect.Lists;
import com.vz.esap.translation.connector.model.DBServiceResponse;
import com.vz.esap.translation.constant.GenericConstant;
import com.vz.esap.translation.dao.model.TblEnvOrder;
import com.vz.esap.translation.dao.model.TblOrder;
import com.vz.esap.translation.dao.model.TblOrderDetails;
import com.vz.esap.translation.dao.model.TblSafeStore;
import com.vz.esap.translation.entity.LocationEntity;
import com.vz.esap.translation.enums.EsapEnum.LocationType;
import com.vz.esap.translation.enums.EsapEnum.PcMilestone;
import com.vz.esap.translation.enums.EsapEnum.PcResponseType;
import com.vz.esap.translation.enums.EsapEnum.StatusCode;
import com.vz.esap.translation.exception.GenericException;
import com.vz.esap.translation.exception.TranslatorException;
import com.vz.esap.translation.exception.TranslatorException.ErrorCode;
import com.vz.esap.translation.order.dao.VOIPOrderDao;
import com.vz.esap.translation.order.model.request.Specification;
import com.vz.esap.translation.order.model.request.VOIPOrderRequest;
import com.vz.esap.translation.order.model.response.VoipOrderResponse;
import com.vz.esap.translation.order.service.NotificationService;
import com.vz.esap.translation.order.service.OrderServiceBase;
import com.vz.esap.translation.order.service.VOIPResponseGenerator;
import com.vz.esap.translation.order.service.device.DeviceOrderServiceImpl;
import com.vz.esap.translation.order.service.helper.OrderServiceHelper;
import com.vz.esap.translation.order.service.location.LocationOrderService;
import com.vz.esap.translation.order.service.tn.GroupTnOrderServiceImpl;
import com.vz.esap.translation.order.service.trunk.TrunkOrderServiceImpl;
import com.vz.esap.translation.order.transformer.TblSafeStoreTransformer;
import com.vz.esap.translation.order.transformer.VoipRequestTransformer;
import com.vz.esap.translation.util.InventoryUtil;
import com.vz.esap.translation.util.TranslationUtility;

import EsapEnumPkg.WorkOrderEnum;

/**
 * @author chattni
 *
 */
@Service
public class EblOrderServiceImpl extends OrderServiceBase implements EblOrderService {

	private static final Logger LOG = LoggerFactory.getLogger(EblOrderServiceImpl.class);

	@Autowired
	private VOIPOrderDao voipOrderDao;

	@Autowired
	private TblSafeStoreTransformer tblSafeStoreTransformer;

	@Autowired
	private OrderServiceHelper orderServiceHelperImpl;

	@Autowired
	private VOIPResponseGenerator voipResponseGenerator;

	@Autowired
	private LocationOrderService locationOrderService;

	@Autowired
	private TrunkOrderServiceImpl trunkOrderServiceImpl;

	@Autowired
	private DeviceOrderServiceImpl deviceOrderServiceImpl;

	@Autowired
	private GroupTnOrderServiceImpl groupTnOrderServiceImpl;
	
	@Autowired
	private NotificationService notificationServiceImpl;
	
	@Autowired
	private InventoryUtil inventoryUtil;
	
	@Autowired
	private VoipRequestTransformer voipRequestTransformerImpl;
	
	@Autowired
	private TranslationUtility translationUtility;

	// Start EBL
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.vz.esap.translation.order.service.ebl.EblOrderService#
	 * createEblEsipValidateOrder(com.vz.esap.translation.order.model.request.
	 * VOIPOrderRequest, java.util.Map)
	 */
	@Override
	public VoipOrderResponse createEblEsipValidateOrder(VOIPOrderRequest voipOrderRequest,
			Map<String, String> productDetails) throws GenericException {
		LOG.info("Entered createEblEsipValidateOrder");
		VoipOrderResponse voipOrderResponse = null;
		List<Specification> eslSpec = null;

		try {
			
			int orderVersion = Integer.parseInt(voipOrderRequest.getOrderHeader().getWorkOrderVersion());
			if (orderVersion > 0) {
				LOG.info("Handling supp orders whose previous orders in \"InProgress\" status.");
				orderServiceHelperImpl.handleOrdersInProgress(voipOrderRequest);
			}
			
			eslSpec = stream(stream(voipOrderRequest.getConvergedService().getFeature())
					.filter(feat -> "FET_LOC_LVL".equalsIgnoreCase(feat.getCode())).collect(Collectors.toList()).get(0)
					.getSpecification()).filter(spec -> "SP_XO_ESL".equalsIgnoreCase(spec.getCode()))
							.collect(Collectors.toList());
			
			voipOrderRequest.getOrderHeader()
					.setEnterpriseId(orderServiceHelperImpl.getEnterpriseInformationFromEsl(eslSpec.get(0).getValue()));

			//AsClli			
			String bsAppServer = inventoryUtil.getExistingBSAppServer(voipOrderRequest.getOrderHeader().getEnterpriseId());
			voipOrderRequest.getOrderHeader().setBsAppServer(bsAppServer);
			voipOrderRequest.getOrderHeader().setAsClli(voipOrderDao.getAsClli(bsAppServer)); //Getting AsClli from bsAppServerId
			LOG.info("AsClli :: {}", voipOrderRequest.getOrderHeader().getAsClli());
			
			voipOrderResponse = createEblEsipValidatePassOrder(voipOrderRequest);

		} catch (Exception e) {
			
			notificationServiceImpl.notifyFailures(voipResponseGenerator.preparePCMilestone(voipOrderRequest,
					PcMilestone.ACTIVATION_COMPLETE.getValue(), StatusCode.ESP_FAILURE, PcResponseType.ORDER.getValue()));
			
			LOG.error("Exception Occured-" + e);
			throw new GenericException(GenericConstant.GENERIC_EXCEPTION, "Generic Exception has occured");
		}

		LOG.info("Exited createEblEsipValidateOrder");
		return voipOrderResponse;
	}
	// End EBL

	// Start EBL
	/**
	 * @param voipOrderRequest
	 * @return voipOrderResponse
	 * @throws GenericException
	 * @throws TranslatorException
	 */
	public VoipOrderResponse createEblEsipValidatePassOrder(VOIPOrderRequest voipOrderRequest)
			throws GenericException, TranslatorException {
		LOG.info("Entered createEblEsipValidatePassOrder");

		VoipOrderResponse voipOrderResponse = null;
		boolean isOrderCreated = false;
		long sequenceNumber = -1;
		TblSafeStore tblSafeStoreObject = null;
		TblEnvOrder tblEnvOrderObject = null;
		TblOrder tblOrderObject = null;
		long detailCounts = -1;
		String virtualAddrCountry = null;
		long serviceCounts = -1;

		try {
			sequenceNumber = voipOrderRequest.getSequenceNumber();
			LOG.info("TblSafeOrder  SequenceNo : {}", sequenceNumber);

			// Update TblSafeStore
			tblSafeStoreObject = tblSafeStoreTransformer.prepareTblSafeStoreData(sequenceNumber);
			voipOrderDao.updateTblSafeStoreTranslationStartTime(tblSafeStoreObject);

			tblEnvOrderObject = orderServiceHelperImpl.createEsipEblEnvOrder(voipOrderRequest,
					WorkOrderEnum.Status.WO_RECV_SEGMENT);

			tblOrderObject = orderServiceHelperImpl.createEsipEblOrderHeader(voipOrderRequest,
					WorkOrderEnum.Status.WO_RECV_SEGMENT, tblEnvOrderObject);

			detailCounts = orderServiceHelperImpl.createEsipEblOrderDetails(voipOrderRequest, tblOrderObject);

			//ESVRRS-19513
			if ("C".equalsIgnoreCase(voipOrderRequest.getOrderHeader().getOrderType())) {
				translationUtility.populateEntityFlag(tblOrderObject);
			}
			//ESVRRS-19513

			virtualAddrCountry = voipOrderRequest.getLocation().getLocationAddress().getCountryCode();

			serviceCounts = orderServiceHelperImpl.createValidateOrderServices(tblOrderObject, virtualAddrCountry);

			voipOrderDao.updateTblEnvOrderStatus(tblEnvOrderObject.getEnvOrderId(), WorkOrderEnum.Status.WO_INIT);
			voipOrderDao.updateTblOrderStatus(tblOrderObject.getOrderId(), WorkOrderEnum.Status.WO_INIT);

			isOrderCreated = true;
			LOG.info("Count Infos {}-{}-{}", isOrderCreated, detailCounts, serviceCounts);

			voipOrderResponse = voipResponseGenerator.prepareSuccessOrderResponse(voipOrderRequest);

		} catch (TranslatorException te) {
			LOG.error("Exception {} ", te.getMessage());
			throw new TranslatorException(te.getErrorCode(), te.getMessage());
		} catch (Exception e) {
			if(tblEnvOrderObject != null && tblEnvOrderObject.getEnvOrderId() != null)
				voipOrderDao.updateTblEnvOrderStatus(tblEnvOrderObject.getEnvOrderId(), WorkOrderEnum.Status.WO_TRANSLATION_FAIL);
			LOG.error("Exception {} ", e.getMessage());
			throw new GenericException(GenericConstant.GENERIC_EXCEPTION, "Generic Exception has occured");
		}

		LOG.info("Exited createEblEsipValidatePassOrder");
		return voipOrderResponse;
	}
	// End EBL

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.vz.esap.translation.order.service.ebl.EblOrderService#
	 * createEblEsipReleaseOrder(com.vz.esap.translation.order.model.request.
	 * VOIPOrderRequest, java.util.Map)
	 */
	@Override
	public VoipOrderResponse createEblEsipReleaseOrder(VOIPOrderRequest voipOrderRequest,
			Map<String, String> productDetails) throws TranslatorException, GenericException {
		LOG.info("Entered createEblEsipReleaseOrder");

		List<TblEnvOrder> tblEnvOrderList = null;
		List<TblOrder> tblOrderList = null;
		List<TblOrderDetails> tblOrderDetailsList = null;
		List<TblOrderDetails> tnTblOrderDetailsList = null;
		TblEnvOrder tblEnvOrder = null;
		VoipOrderResponse voipOrderResponse = null;
		Boolean entityFlag = false;

		try {
			// Find Validation Env Order
			tblEnvOrderList = orderServiceHelperImpl.getMatchingValidationEnvOrder(voipOrderRequest);
			
			if (tblEnvOrderList.get(0) != null && tblEnvOrderList.get(0).getEnterpriseId() != null) {
				voipOrderRequest.getOrderHeader().setEnterpriseId(tblEnvOrderList.get(0).getEnterpriseId());

			}

			// Find Validation Order
			tblOrderList = orderServiceHelperImpl.getMatchingPassOrder(tblEnvOrderList.get(0));

			//ESVRRS-19513
			entityFlag = translationUtility.isEntityFlagExists(tblOrderList.get(0));
			//ESVRRS-19513
			if("C".equalsIgnoreCase(voipOrderRequest.getOrderHeader().getOrderType()) && entityFlag) {
				// soft success has to return as entities doesn't exists..
				LOG.info("#Entities doesn't exists for order##");
				tblEnvOrder = createTblEnvOrder(null, tblOrderList.get(0), voipOrderRequest,
						WorkOrderEnum.Status.WO_COMPLETE);

				voipOrderResponse = voipResponseGenerator.prepareSuccessOrderResponse(voipOrderRequest);

				notificationServiceImpl.notifySuccess(voipResponseGenerator.preparePCMilestone(voipOrderRequest,
						PcMilestone.ORDER_ACCEPTANCE.getValue(), StatusCode.ESP_SUCCESS,
						PcResponseType.ORDER.getValue()));
			}else {
			// Find matching Order details
			for (TblOrder tblOrderBean : tblOrderList) {
				LOG.info("ValidationOrderId: {}", tblOrderBean.getOrderId());
				tblOrderDetailsList = orderServiceHelperImpl.getMatchingOrderDetails(tblOrderBean);
				LOG.info("Order Details Size: {}", tblOrderDetailsList.size());

				if (voipOrderRequest.getOrderHeader().getMinorOrderType() != null)
					voipOrderRequest.getOrderHeader().setMinorOrderType(tblEnvOrderList.get(0).getMinorOrderType());

				tblEnvOrder = createTblEnvOrder(tblOrderDetailsList.get(0), tblOrderBean, voipOrderRequest,
						WorkOrderEnum.Status.WO_RECV_SEGMENT);

				// Find Entities and route
				for (TblOrderDetails tblOrderDetails : tblOrderDetailsList) {
					LOG.info("TblOrderDetails Param Detail Id : {} , Param Name : {} ",
							tblOrderDetails.getOrderDetailId(), tblOrderDetails.getParamName());
					if (("Location").equalsIgnoreCase(tblOrderDetails.getParamName()))
						voipOrderResponse = locationOrderService.processReleaseOrder(tblOrderDetails, tblOrderBean,
								tblEnvOrder, voipOrderRequest, tblOrderDetailsList);
					if ("Group".equalsIgnoreCase(tblOrderDetails.getParamName()))
						voipOrderResponse = trunkOrderServiceImpl.processReleaseOrder(tblOrderDetails, tblOrderBean,
								tblEnvOrder, voipOrderRequest, tblOrderDetailsList);
					if ("Device".equalsIgnoreCase(tblOrderDetails.getParamName()))
						voipOrderResponse = deviceOrderServiceImpl.processReleaseOrder(tblOrderDetails, tblOrderBean,
								tblEnvOrder, voipOrderRequest, tblOrderDetailsList);
				}				

				// TN Processing Code Here
				tnTblOrderDetailsList = orderServiceHelperImpl.getMatchingTnOrderDetails(tblOrderBean);
				int batchSize = 500; // To do need to pull in batches.
				
				if (!tnTblOrderDetailsList.isEmpty()) {

					for (List<TblOrderDetails> batchTNOrderDetails : Lists.partition(tnTblOrderDetailsList,
							batchSize)) {
						LOG.info("Start Process Release Order For TN");
						// Here we need to implement batching as in BAU
						groupTnOrderServiceImpl.processReleaseOrder(batchTNOrderDetails, tblOrderBean, tblEnvOrder,
								voipOrderRequest, tnTblOrderDetailsList);
						// Process Individual TN's here
						LOG.info("End Process Release Order For TN");
					}					
				}
			}
			
			// Update Env and other generate response post processing all TN's

			int orderVersion = Integer.parseInt(voipOrderRequest.getOrderHeader().getWorkOrderVersion());
			LOG.info("Order version:: {}", orderVersion);
			
			if(orderVersion > 0 && tnTblOrderDetailsList.isEmpty()) {
				orderServiceHelperImpl.handlePreviousOrder(voipOrderRequest, null, tblEnvOrder.getEnvOrderId());							
			}
			
			voipOrderDao.createParentChildOrderRelationship(tblEnvOrder);
			
			if(orderVersion == 0) {
				voipOrderDao.updateTblEnvOrderStatus(tblEnvOrder.getEnvOrderId(), WorkOrderEnum.Status.WO_INIT);
			} else {
				orderServiceHelperImpl.updateTblEnvOrderStatusWithCurrOrdFlow(voipOrderRequest, tblEnvOrder.getEnvOrderId());
			}
			voipOrderResponse = voipResponseGenerator.prepareSuccessOrderResponse(voipOrderRequest);
		
			notificationServiceImpl.notifySuccess(voipResponseGenerator.preparePCMilestone(voipOrderRequest,
					PcMilestone.ORDER_ACCEPTANCE.getValue(), StatusCode.ESP_SUCCESS, PcResponseType.ORDER.getValue()));
		
			}
			
		} catch (TranslatorException ex) {
			LOG.error("Exception {} ", ex.getMessage());
			LOG.error("Exception Info -" + ex);
			throw new TranslatorException(ex.getErrorCode(), ex.getMessage());
		} catch (Exception e) {
			if(tblEnvOrder != null && tblEnvOrder.getEnvOrderId() != null)
				voipOrderDao.updateTblEnvOrderStatus(tblEnvOrder.getEnvOrderId(), WorkOrderEnum.Status.WO_TRANSLATION_FAIL);
			
			notificationServiceImpl.notifyFailures(voipResponseGenerator.preparePCMilestone(voipOrderRequest,
					PcMilestone.ORDER_ACCEPTANCE.getValue(), StatusCode.ESP_FAILURE, PcResponseType.ORDER.getValue()));
			
			LOG.error("Exception {} ", e.getMessage());
			
			throw new GenericException(GenericException.GENERIC_EXCEPTION, "Exception in the provide input arguments");
		}

		LOG.info("Exited createEblEsipReleaseOrder");
		return voipOrderResponse;
	}
	
	/**
	 * TODO - Disconn
	 * 
	 * @param voipOrderRequest
	 * @return voipOrderResponse
	 * @throws GenericException
	 * @throws TranslatorException
	 */
	@Override
	public VoipOrderResponse createEblEsipLocSuspOrder(VOIPOrderRequest voipOrderRequest,
			Map<String, String> productDetails) throws TranslatorException, GenericException {
		LOG.info("Entered createEblEsipLocSuspOrder");

		VoipOrderResponse voipOrderResponse = null;
		String voipLocation = null;
		String enterpriseID = null;
		String customerId = null;
		long sequenceNumber = -1;
		TblSafeStore tblSafeStoreObject = null;
		TblEnvOrder tblEnvOrderObject = null;
		String virtualAddrCountry = null;
		LocationEntity locationEntityInv = null;
		Map<String, String> locRows = null;
		DBServiceResponse dbServiceResponse = null;

		try {
			if (voipOrderRequest.getOrderHeader().getVoipLocationId() == null
					|| voipOrderRequest.getOrderHeader().getVoipLocationId().isEmpty()) {
				throw new TranslatorException(ErrorCode.INVALID_XML, "Voip Location ID is Missing");
			}
			voipLocation = voipOrderRequest.getOrderHeader().getVoipLocationId();

			if (voipOrderRequest.getOrderHeader().getGCHId() == null)
				throw new TranslatorException(ErrorCode.ESAP_MISSING_REQUIRED_DATA,
						"GCHID is not present in the request BOD");
			dbServiceResponse = orderServiceHelperImpl
					.getEnterpriseInformationFromGchId(voipOrderRequest.getOrderHeader().getGCHId());

			voipOrderRequest = voipRequestTransformerImpl.modifyOrderHeader(voipOrderRequest, dbServiceResponse, false,
					productDetails);

			locRows = inventoryUtil.getTblLocationFromLocationId(voipLocation, null, null);

			if (locRows != null && locRows.get("LOCATION_TYPE") != null
					&& LocationType.ESIP_EBL.getIndex() == Integer.valueOf(locRows.get("LOCATION_TYPE"))) {
				enterpriseID = locRows.get("ENTERPRISE_ID");

				if (enterpriseID == null) {
					throw new TranslatorException(ErrorCode.INVENTORY_RECORD_MISSING,
							"Enterprise record is not available for the location");
				}
			}
			
			//AsClli
			String bsAppServer = inventoryUtil.getExistingBSAppServer(enterpriseID);
			voipOrderRequest.getOrderHeader().setBsAppServer(bsAppServer);
			voipOrderRequest.getOrderHeader().setAsClli(voipOrderDao.getAsClli(bsAppServer)); //Getting AsClli from bsAppServerId
			LOG.info("EBL :: AsClli :: {}", voipOrderRequest.getOrderHeader().getAsClli());		

			locationEntityInv = orderServiceHelperImpl.getEntityDetailsFromInventory(voipLocation,
					LocationEntity.class);

			if (locationEntityInv != null && locationEntityInv.getLocRegion() != null)
				virtualAddrCountry = locationEntityInv.getLocRegion();
			else
				virtualAddrCountry = "US";

			LOG.info("EblOrderServiceImpl:: virtualAddrCountry {}", virtualAddrCountry);
			voipOrderRequest.getOrderHeader().setRegion(virtualAddrCountry);

			if (locationEntityInv != null && locationEntityInv.getCustomerId() != null) {
				customerId = locationEntityInv.getCustomerId();
				LOG.info("Customer Id : {}", customerId);
				voipOrderRequest.getOrderHeader().setEnterpriseId(customerId);
			}

			sequenceNumber = voipOrderRequest.getSequenceNumber();
			LOG.info("TblSafeOrder  SequenceNo : {}", sequenceNumber);

			// Update TblSafeStore
			tblSafeStoreObject = tblSafeStoreTransformer.prepareTblSafeStoreData(sequenceNumber);
			voipOrderDao.updateTblSafeStoreTranslationStartTime(tblSafeStoreObject);

			// Create Env Order
			tblEnvOrderObject = orderServiceHelperImpl.createEsipEblEnvOrder(voipOrderRequest,
					WorkOrderEnum.Status.WO_RECV_SEGMENT);

			orderServiceHelperImpl.createLocationOrderFromInventoryDetails(voipOrderRequest, tblEnvOrderObject);
			LOG.info("Location order is placed");

			// TODO: 1/17. Please propagate below to Flex
			voipOrderResponse = voipResponseGenerator.prepareSuccessOrderResponse(voipOrderRequest);

			voipOrderDao.createParentChildOrderRelationship(tblEnvOrderObject);

			voipOrderDao.updateTblEnvOrderStatus(tblEnvOrderObject.getEnvOrderId(), WorkOrderEnum.Status.WO_INIT);

			//Commentting below as PC do not need this milestone
			/*notificationServiceImpl.notifySuccess(voipResponseGenerator.preparePCMilestone(voipOrderRequest,
					PcMilestone.ORDER_ACCEPTANCE.getValue(), StatusCode.ESP_SUCCESS, PcResponseType.ORDER.getValue()));*/

		} catch (TranslatorException ex) {
			LOG.error("Exception {} ", ex);
			throw new TranslatorException(ex.getErrorCode(), ex.getMessage());
		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new GenericException(GenericException.GENERIC_EXCEPTION, "Exception in the provide input arguments");
		}
		return voipOrderResponse;
	}
	
	/**
	 * TODO - Disconn
	 * 
	 * @param voipOrderRequest
	 * @return voipOrderResponse
	 * @throws GenericException
	 * @throws TranslatorException
	 */
	@Override
	public VoipOrderResponse createEblEsipLocDeactOrder(VOIPOrderRequest voipOrderRequest,
			Map<String, String> productDetails) throws TranslatorException, GenericException {
		LOG.info("Entered createEblEsipLocDeactOrder");

		VoipOrderResponse voipOrderResponse = null;
		List<TblEnvOrder> suspenedTblEnvOrderObjects = null;
		long sequenceNumber = -1;
		TblSafeStore tblSafeStoreObject = null;
		TblEnvOrder tblEnvOrderObject = null;
		String virtualAddrCountry = null;
		String customerId = null;
		int relSuspendOrderClassify = 33;
		DBServiceResponse dbServiceResponse = null;

		try {
			suspenedTblEnvOrderObjects = orderServiceHelperImpl.getMatchingPrevPassEnvOrder(voipOrderRequest,
					WorkOrderEnum.Status.WO_COMPLETE, relSuspendOrderClassify);

			if (suspenedTblEnvOrderObjects == null || suspenedTblEnvOrderObjects.isEmpty()
					|| suspenedTblEnvOrderObjects.get(0) == null
					|| suspenedTblEnvOrderObjects.get(0).getEnvOrderId() == null)
				throw new TranslatorException(TranslatorException.ErrorCode.VALIDATION_NOT_COMPLETE,
						"Suspend is not completed for Order:" + voipOrderRequest.getOrderHeader().getWorkOrderNumber());

			LOG.info("createEblEsipLocDeactOrder::REL_SUSPEND order is succesfully completed for order - {}",
					voipOrderRequest.getOrderHeader().getWorkOrderNumber());

			if (voipOrderRequest.getOrderHeader().getGCHId() == null)
				throw new TranslatorException(ErrorCode.ESAP_MISSING_REQUIRED_DATA,
						"GCHID is not present in the request BOD");
			dbServiceResponse = orderServiceHelperImpl
					.getEnterpriseInformationFromGchId(voipOrderRequest.getOrderHeader().getGCHId());

			voipOrderRequest = voipRequestTransformerImpl.modifyOrderHeader(voipOrderRequest, dbServiceResponse, false,
					productDetails);

			LocationEntity locationEntityInv = orderServiceHelperImpl.getEntityDetailsFromInventory(
					voipOrderRequest.getOrderHeader().getVoipLocationId(), LocationEntity.class);
			if (locationEntityInv != null && locationEntityInv.getLocRegion() != null)
				virtualAddrCountry = locationEntityInv.getLocRegion();
			else
				virtualAddrCountry = "US";

			LOG.info("EblOrderServiceImpl:: virtualAddrCountry - {}", virtualAddrCountry);
			voipOrderRequest.getOrderHeader().setRegion(virtualAddrCountry);

			if (locationEntityInv != null && locationEntityInv.getCustomerId() != null) {
				customerId = locationEntityInv.getCustomerId();
				LOG.info("Customer Id : {}", customerId);
				voipOrderRequest.getOrderHeader().setEnterpriseId(customerId);
				//AsClli
				String bsAppServer = inventoryUtil.getExistingBSAppServer(customerId);
				voipOrderRequest.getOrderHeader().setBsAppServer(bsAppServer);
				voipOrderRequest.getOrderHeader().setAsClli(voipOrderDao.getAsClli(bsAppServer)); //Getting AsClli from bsAppServerId
			}

			sequenceNumber = voipOrderRequest.getSequenceNumber();
			LOG.info("TblSafeOrder  SequenceNo : {}", sequenceNumber);

			// Update TblSafeStore
			tblSafeStoreObject = tblSafeStoreTransformer.prepareTblSafeStoreData(sequenceNumber);
			voipOrderDao.updateTblSafeStoreTranslationStartTime(tblSafeStoreObject);

			// Create Env Order
			tblEnvOrderObject = orderServiceHelperImpl.createEsipEblEnvOrder(voipOrderRequest,
					WorkOrderEnum.Status.WO_RECV_SEGMENT);

			orderServiceHelperImpl.createLocationOrderFromInventoryDetails(voipOrderRequest, tblEnvOrderObject);
			LOG.info("Location order is placed");

			orderServiceHelperImpl.createTNOrderFromInventoryDetails(voipOrderRequest, tblEnvOrderObject);
			LOG.info("TN order is placed");

			voipOrderResponse = voipResponseGenerator.prepareSuccessOrderResponse(voipOrderRequest);

			voipOrderDao.createParentChildOrderRelationship(tblEnvOrderObject);

			voipOrderDao.updateTblEnvOrderStatus(tblEnvOrderObject.getEnvOrderId(), WorkOrderEnum.Status.WO_INIT);

			//Commentting below as PC do not need this milestone
			/*notificationServiceImpl.notifySuccess(voipResponseGenerator.preparePCMilestone(voipOrderRequest,
					PcMilestone.ORDER_ACCEPTANCE.getValue(), StatusCode.ESP_SUCCESS, PcResponseType.ORDER.getValue()));*/
			
			//Adding new Milestone VALIDATE_DEACT
			notificationServiceImpl.notifySuccess(voipResponseGenerator.preparePCMilestone(voipOrderRequest,
					PcMilestone.VALIDATE_DEACT.getValue(), StatusCode.ESP_SUCCESS, PcResponseType.VALIDATION.getValue()));
			

		} catch (TranslatorException ex) {
			LOG.error("Exception {} ", ex.getMessage());
			throw new TranslatorException(ex.getErrorCode(), ex.getMessage());
		
		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new GenericException(GenericException.GENERIC_EXCEPTION, "Exception in the provide input arguments");
		
		}
		LOG.info("Exiting createEblEsipLocDeactOrder");
		return voipOrderResponse;
	}
	
	
	@Deprecated
	@Override
	public VoipOrderResponse createTnPortActivationOrder(VOIPOrderRequest voipOrderRequest,
			Map<String, String> productDetails) throws TranslatorException, GenericException {
		LOG.info("Entered createTnPortActivationOrder");

		VoipOrderResponse voipOrderResponse = null;
		long sequenceNumber = -1;
		TblSafeStore tblSafeStoreObject = null;
		TblEnvOrder tblEnvOrderObject = null;
		String virtualAddrCountry = null;
		String customerId = null;
		DBServiceResponse dbServiceResponse = null;

		try {
			
			if (voipOrderRequest.getOrderHeader().getGCHId() == null)
				throw new TranslatorException(ErrorCode.ESAP_MISSING_REQUIRED_DATA,
						"GCHID is not present in the request BOD");
			dbServiceResponse = orderServiceHelperImpl
					.getEnterpriseInformationFromGchId(voipOrderRequest.getOrderHeader().getGCHId());

			voipOrderRequest = voipRequestTransformerImpl.modifyOrderHeader(voipOrderRequest, dbServiceResponse, false,
					productDetails);

			LocationEntity locationEntityInv = orderServiceHelperImpl.getEntityDetailsFromInventory(
					voipOrderRequest.getOrderHeader().getVoipLocationId(), LocationEntity.class);
			
			if (locationEntityInv != null && locationEntityInv.getLocRegion() != null)
				virtualAddrCountry = locationEntityInv.getLocRegion();
			else
				virtualAddrCountry = "US";
			
			LOG.info("EblOrderServiceImpl:: virtualAddrCountry - {}", virtualAddrCountry);
			voipOrderRequest.getOrderHeader().setRegion(virtualAddrCountry);

			if (locationEntityInv != null && locationEntityInv.getCustomerId() != null) {
				customerId = locationEntityInv.getCustomerId();
				LOG.info("Customer Id : {}", customerId);
				voipOrderRequest.getOrderHeader().setEnterpriseId(customerId);
			}

			sequenceNumber = voipOrderRequest.getSequenceNumber();
			LOG.info("TblSafeOrder  SequenceNo : {}", sequenceNumber);

			// Update TblSafeStore
			tblSafeStoreObject = tblSafeStoreTransformer.prepareTblSafeStoreData(sequenceNumber);
			voipOrderDao.updateTblSafeStoreTranslationStartTime(tblSafeStoreObject);

			// Create Env Order
			tblEnvOrderObject = orderServiceHelperImpl.createEsipEblEnvOrder(voipOrderRequest,
					WorkOrderEnum.Status.WO_RECV_SEGMENT);

			orderServiceHelperImpl.createTNOrderFromInventoryDetails(voipOrderRequest, tblEnvOrderObject);
			LOG.info("TN order is placed");


			voipOrderResponse = voipResponseGenerator.prepareSuccessOrderResponse(voipOrderRequest);

			voipOrderDao.createParentChildOrderRelationship(tblEnvOrderObject);

			voipOrderDao.updateTblEnvOrderStatus(tblEnvOrderObject.getEnvOrderId(), WorkOrderEnum.Status.WO_INIT);

			notificationServiceImpl.notifySuccess(voipResponseGenerator.preparePCMilestone(voipOrderRequest,
					PcMilestone.ORDER_ACCEPTANCE.getValue(), StatusCode.ESP_SUCCESS, PcResponseType.ORDER.getValue()));

		} catch (TranslatorException ex) {
			LOG.error("Exception {} ", ex.getMessage());
			throw new TranslatorException(ex.getErrorCode(), ex.getMessage());
		
		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new GenericException(GenericException.GENERIC_EXCEPTION, "Generic Exception in createTnPortActivationOrder");
		
		}
		LOG.info("Exiting createEblEsipLocDeactOrder");
		return voipOrderResponse;
	}
	
}
