package com.vz.esap.translation.entity;

import java.util.ArrayList;
import java.util.HashSet;

import com.vz.esap.translation.enums.EsapEnum.AuthFeatureType;

import EsapEnumPkg.VzbVoipEnum;

public class GroupTNEntity extends Entity {

	private Long groupTNId;
	private TNEntity tnRecord;
	private String extension;
	private String privateNumber;
	private String sipDomain;
	private String tnCLIDFirstName;
	private String tnCLIDLastName;
	private Integer sequenceNo;
	private String linePort;
	private String vmBoxNumber;
	private String vmPin;
	private TrunkGroupEntity trunkGroupEntity;
	private String vmType;
	private ArrayList<String> nonPkgFeatures;
	protected ArrayList<String> disableFeatureList;
	// private GroupTNFMCG groupTNFMCG; TODO: check if this is needed for XO
	private String subscriberId;
	private boolean isFmcgDelete;
	private ArrayList<String> pkgDiffFeatures;
	private ArrayList<String> userFeatures;
	private String region;
	private String customerId;
	private String locationId;
	private long tnCount;
	private long envOrderId;
	private long internalOrderId;
	private GroupTNEntity groupTNEntity;
	private String deviceName;
	private String entityAction;
	private String timeZoneId;
	private String dayLightSavingInd;
	private AuthFeatureType authFeatureType;
	private String asClli;

	public long getTnCount() {
		return tnCount;
	}

	public void setTnCount(long tnCount) {
		this.tnCount = tnCount;
	}

	/*
	 * public GroupTNEntity(GroupTNEntity groupTNEntity) { trunkGroupEntity =
	 * new TrunkGroupEntity(); groupTNId = groupTNEntity.getGroupTNId(); if
	 * (tnRecord != null) tnRecord = new TNEntity(groupTNEntity.getTnRecord());
	 * sipDomain = groupTNEntity.getSipDomain(); extension =
	 * groupTNEntity.getExtension(); privateNumber =
	 * groupTNEntity.getPrivateNumber(); tnCLIDFirstName =
	 * groupTNEntity.getTnCLIDFirstName(); tnCLIDLastName =
	 * groupTNEntity.getTnCLIDLastName(); sequenceNo =
	 * groupTNEntity.getSequenceNo(); linePort = groupTNEntity.getLinePort();
	 * vmBoxNumber = groupTNEntity.getVmBoxNumber(); vmPin =
	 * groupTNEntity.getVmPin(); if (groupTNEntity.getTrunkGroupEntity() !=
	 * null) trunkGroupEntity = new
	 * TrunkGroupEntity(groupTNEntity.getTrunkGroupEntity()); if
	 * (groupTNEntity.getDisableFeatureList() != null) disableFeatureList = new
	 * ArrayList<String>(groupTNEntity.getDisableFeatureList()); if
	 * (groupTNEntity.getNonPkgFeatures() != null) nonPkgFeatures = new
	 * ArrayList<String>(groupTNEntity.getNonPkgFeatures()); if
	 * (groupTNEntity.getUserFeatures() != null) userFeatures = new
	 * ArrayList<String>(groupTNEntity.getUserFeatures()); vmType =
	 * groupTNEntity.getVmType(); if (groupTNEntity.getPkgDiffFeatures() !=
	 * null) { pkgDiffFeatures = new ArrayList<String>();
	 * pkgDiffFeatures.addAll(groupTNEntity.getPkgDiffFeatures()); }
	 * 
	 * }
	 */
	public GroupTNEntity() {
		trunkGroupEntity = new TrunkGroupEntity();
	}

	public boolean isFmcgDelete() {
		return isFmcgDelete;
	}

	public void setFmcgDelete(boolean isFmcgDelete) {
		this.isFmcgDelete = isFmcgDelete;
	}

	public Long getGroupTNId() {
		return groupTNId;
	}

	public void setGroupTNId(Long groupTNId) {
		this.groupTNId = groupTNId;
	}

	public String getVmPin() {
		return vmPin;
	}

	public void setVmPin(String vmPin) {
		this.vmPin = vmPin;
	}

	public Long getGroupId() {
		if (trunkGroupEntity == null)
			trunkGroupEntity = new TrunkGroupEntity();

		return trunkGroupEntity.getGroupId();
	}

	public void setGroupId(Long groupId) {
		if (trunkGroupEntity == null)
			trunkGroupEntity = new TrunkGroupEntity();

		trunkGroupEntity.setGroupId(groupId);
	}

	public String getGroupName() {
		if (trunkGroupEntity == null)
			trunkGroupEntity = new TrunkGroupEntity();

		return trunkGroupEntity.getName();
	}

	public void setGroupName(String groupName) {
		if (trunkGroupEntity == null)
			trunkGroupEntity = new TrunkGroupEntity();

		trunkGroupEntity.setName(groupName);
	}

	public String getSipDomain() {
		return sipDomain;
	}

	public void setSipDomain(String sipDomain) {
		this.sipDomain = sipDomain;
	}

	public GroupType getGroupType() {
		if (trunkGroupEntity == null)
			return null;
		else
			return trunkGroupEntity.getGroupType();
	}

	public void setGroupType(GroupType groupType) {
		if (trunkGroupEntity == null)
			trunkGroupEntity = new TrunkGroupEntity();

		trunkGroupEntity.setGroupType(groupType);
	}

	public String getTnCLIDFirstName() {
		return tnCLIDFirstName;
	}

	public void setTnCLIDFirstName(String tnCLIDFirstName) {
		this.tnCLIDFirstName = tnCLIDFirstName;
	}

	public String getTnCLIDLastName() {
		return tnCLIDLastName;
	}

	public void setTnCLIDLastName(String tnCLIDLastName) {
		this.tnCLIDLastName = tnCLIDLastName;
	}

	public String getPrivateNumber() {
		return privateNumber;
	}

	public void setPrivateNumber(String privateNumber) {
		this.privateNumber = privateNumber;
	}

	public String getExtension() {
		return extension;
	}

	public void setExtension(String extension) {
		this.extension = extension;
	}

	public TNEntity getTnRecord() {
		return tnRecord;
	}

	public String getTN() {
		if (null != tnRecord) {
			return tnRecord.getTn();
		}
		return null;
	}

	public void setTnRecord(TNEntity tnRecord) {
		this.tnRecord = tnRecord;
	}

	public Integer getSequenceNo() {
		return sequenceNo;
	}

	public void setSequenceNo(Integer sequenceNo) {
		this.sequenceNo = sequenceNo;
	}

	public String getFeaturePackage() {
		if (trunkGroupEntity == null)
			trunkGroupEntity = new TrunkGroupEntity();

		return trunkGroupEntity.getSimpleFeaturePackage();
	}

	public void setFeaturePackage(String featurePackage) {
		if (trunkGroupEntity == null)
			trunkGroupEntity = new TrunkGroupEntity();

		this.trunkGroupEntity.setSimpleFeaturePackage(featurePackage);
	}

	public String getLinePort() {
		return linePort;
	}

	public void setLinePort(String linePort) {
		this.linePort = linePort;
	}

	public String getVmBoxNumber() {
		return vmBoxNumber;
	}

	public void setVmBoxNumber(String vmBoxNumber) {
		this.vmBoxNumber = vmBoxNumber;
	}

	public TrunkGroupEntity getTrunkGroupEntity() {
		return trunkGroupEntity;
	}

	public void setTrunkGroupEntity(TrunkGroupEntity trunkGroupEntity) {
		this.trunkGroupEntity = trunkGroupEntity;
	}

	public void addDisableFeature(String disableFeature) {
		if (this.disableFeatureList == null)
			this.disableFeatureList = new ArrayList<String>();

		this.disableFeatureList.add(disableFeature);
	}

	public void setDisableFeatureList(ArrayList<String> disableFeatureList) {
		this.disableFeatureList = disableFeatureList;
	}

	public ArrayList<String> getDisableFeatureList() {
		return disableFeatureList;
	}

	public void addNonPkgFeature(String nonPkgFeature) {
		if (this.nonPkgFeatures == null)
			this.nonPkgFeatures = new ArrayList<String>();

		this.nonPkgFeatures.add(nonPkgFeature);
	}

	public void addNonPkgFeatures(ArrayList<String> nonPkgFeats) {
		if (null != nonPkgFeats && nonPkgFeats.size() > 0) {
			if (this.nonPkgFeatures == null) {
				this.nonPkgFeatures = new ArrayList<String>();
				this.nonPkgFeatures.addAll(nonPkgFeats);
			} else if (null != nonPkgFeatures && nonPkgFeatures.size() > 0) {
				for (String feature : nonPkgFeats) {
					nonPkgFeatures.add(feature);
				}
			}
		}
	}

	public void setNonPkgFeatures(ArrayList<String> nonPkgFeatures) {
		this.nonPkgFeatures = nonPkgFeatures;
	}

	public ArrayList<String> getNonPkgFeatures() {
		return nonPkgFeatures;
	}

	public String getVmType() {
		return vmType;
	}

	public void setVmType(String vmType) {
		if ("20".equals(vmType) || "50".equals(vmType) || "0".equals(vmType))
			this.vmType = vmType;
		else
			this.vmType = null;
	}

	public int getEntityType() {
		int entType = -1;
		if (GroupTNEntity.GroupType.PBX.equals(getGroupType()))
			entType = VzbVoipEnum.OrderEntity.PBX_TN;
		else
			entType = VzbVoipEnum.OrderEntity.KEY_TN;

		return entType;
	}

	public String getEntityId() {
		if (groupTNId != null)
			return groupTNId.toString();
		else
			return null;
	}

	public String getEntityName() {
		if (tnRecord != null)
			return tnRecord.getTn();
		else
			return extension;
	}

	public HashSet<ParentEntity> getParentList() {
		if (trunkGroupEntity != null) {
			addParentToList(
					new ParentEntity(VzbVoipEnum.OrderEntity.ENTERPRISE, null, trunkGroupEntity.getCustomerId()));
			addParentToList(new ParentEntity(VzbVoipEnum.OrderEntity.LOCATION, null, trunkGroupEntity.getLocationId()));
			if (trunkGroupEntity.getGroupType().equals(GroupType.PBX))
				addParentToList(new ParentEntity(VzbVoipEnum.OrderEntity.PBX, null,
						trunkGroupEntity.getGroupId() == null ? null : trunkGroupEntity.getGroupId().toString()));
			else
				addParentToList(new ParentEntity(VzbVoipEnum.OrderEntity.KEY, null,
						trunkGroupEntity.getGroupId() == null ? null : trunkGroupEntity.getGroupId().toString()));

			/*
			 * if (trunkGroupEntity.getDevice() != null) addParentToList(new
			 * ParentEntity(VzbVoipEnum.OrderEntity.DEVICE,
			 * trunkGroupEntity.getDevice().getDeviceName(),
			 * trunkGroupEntity.getDevice().getDeviceMapId() == null ? null :
			 * trunkGroupEntity.getDevice() .getDeviceMapId().toString()));
			 */

			/*
			 * TODO : Will check if this is needed as on commenting it 7/16 if
			 * (groupTNFMCG != null && null != groupTNFMCG.getDeviceEntity()) {
			 * addParentToList( new ParentEntity(VzbVoipEnum.OrderEntity.DEVICE,
			 * groupTNFMCG.getDeviceEntity().getDeviceName(),
			 * groupTNFMCG.getDeviceEntity().getDeviceMapId() == null ? null :
			 * groupTNFMCG.getDeviceEntity().getDeviceMapId().toString())); } if
			 * (groupTNFMCG != null && null != groupTNFMCG.getDeviceEntity()) {
			 * addParentToList( new ParentEntity(VzbVoipEnum.OrderEntity.DEVICE,
			 * groupTNFMCG.getDeviceEntity().getDeviceName(),
			 * groupTNFMCG.getDeviceEntity().getDeviceMapId() == null ? null :
			 * groupTNFMCG.getDeviceEntity().getDeviceMapId().toString())); }
			 */
		}

		if (getTN() != null && getTN().length() > 0) {
			addParentToList(new ParentEntity(VzbVoipEnum.OrderEntity.TN, getTN(), null));
		}

		return super.getParentList();
	}

	public Integer getSubscriberOrTnType() {
		if (tnRecord != null)
			return tnRecord.getSubscriberOrTnType();
		else if (extension != null)
			return VzbVoipEnum.SubscriberOrTnStatus.EXTENSION_ONLY;

		else
			return null;
	}

	/*
	 * TODO: check if this is needed for XO, as on commenting it 07/16 public
	 * GroupTNFMCG getGroupTNFMCG() { return groupTNFMCG; }
	 * 
	 * public void setGroupTNFMCG(GroupTNFMCG groupTNFMCG) { this.groupTNFMCG =
	 * groupTNFMCG; }
	 */

	public String getSubscriberId() {
		return subscriberId;
	}

	public void setSubscriberId(String subscriberId) {
		this.subscriberId = subscriberId;
	}

	public String getLocationId() {
		if (trunkGroupEntity == null)
			return null;
		else
			return trunkGroupEntity.getLocationId();
	}

	public String getCustomerId() {
		if (trunkGroupEntity == null)
			return null;
		else
			return trunkGroupEntity.getCustomerId();
	}

	public ArrayList<String> getPkgDiffFeatures() {
		return pkgDiffFeatures;
	}

	public void setPkgDiffFeatures(ArrayList<String> pkgDiffFeatures) {
		this.pkgDiffFeatures = pkgDiffFeatures;
	}

	public void addPkgDiffFeature(String feat) {
		if (pkgDiffFeatures == null)
			pkgDiffFeatures = new ArrayList<String>();

		pkgDiffFeatures.add(feat);
	}

	/*
	 * public void copyDelta(GroupTNEntity groupTNEntity) {
	 * 
	 * if (groupTNEntity.getGroupTNId() != null) groupTNId =
	 * groupTNEntity.getGroupTNId(); if (tnRecord != null)
	 * tnRecord.copyDelta(groupTNEntity.getTnRecord()); else tnRecord =
	 * groupTNEntity.getTnRecord(); if (groupTNEntity.getSipDomain() != null)
	 * sipDomain = groupTNEntity.getSipDomain(); if
	 * (groupTNEntity.getExtension() != null) extension =
	 * groupTNEntity.getExtension(); if (groupTNEntity.getPrivateNumber() !=
	 * null) privateNumber = groupTNEntity.getPrivateNumber(); if
	 * (groupTNEntity.getTnCLIDFirstName() != null) tnCLIDFirstName =
	 * groupTNEntity.getTnCLIDFirstName(); if (groupTNEntity.getTnCLIDLastName()
	 * != null) tnCLIDLastName = groupTNEntity.getTnCLIDLastName(); if
	 * (groupTNEntity.getSequenceNo() != null) sequenceNo =
	 * groupTNEntity.getSequenceNo(); if (groupTNEntity.getLinePort() != null)
	 * linePort = groupTNEntity.getLinePort(); if
	 * (groupTNEntity.getVmBoxNumber() != null) vmBoxNumber =
	 * groupTNEntity.getVmBoxNumber(); if (groupTNEntity.getVmPin() != null)
	 * vmPin = groupTNEntity.getVmPin(); if (trunkGroupEntity != null)
	 * trunkGroupEntity.copyDelta(groupTNEntity.getTrunkGroupEntity()); if
	 * (groupTNEntity.getDisableFeatureList() != null) disableFeatureList = new
	 * ArrayList<String>(groupTNEntity.getDisableFeatureList()); if
	 * (groupTNEntity.getNonPkgFeatures() != null) nonPkgFeatures = new
	 * ArrayList<String>(groupTNEntity.getNonPkgFeatures()); if
	 * (groupTNEntity.getUserFeatures() != null) userFeatures = new
	 * ArrayList<String>(groupTNEntity.getUserFeatures());
	 * 
	 * if (groupTNEntity.getVmType() != null) vmType =
	 * groupTNEntity.getVmType();
	 * 
	 * if (groupTNEntity.getPkgDiffFeatures() != null) { pkgDiffFeatures = new
	 * ArrayList<String>();
	 * pkgDiffFeatures.addAll(groupTNEntity.getPkgDiffFeatures()); }
	 * 
	 * }
	 */

	public ArrayList<String> getUserFeatures() {
		return userFeatures;
	}

	public void setUserFeatures(ArrayList<String> userFeatures) {
		this.userFeatures = userFeatures;
	}

	public void addUserFeatures(String userFeature) {
		if (this.userFeatures == null)
			this.userFeatures = new ArrayList<String>();

		this.userFeatures.add(userFeature);
	}

	public void addUserFeatures(ArrayList<String> userFeaturesFeats) {
		if (null != userFeaturesFeats && userFeaturesFeats.size() > 0) {
			if (this.userFeatures == null) {
				this.userFeatures = new ArrayList<String>();
				this.userFeatures.addAll(userFeaturesFeats);
			} else if (null != userFeatures && userFeatures.size() > 0) {
				for (String feature : userFeaturesFeats) {
					userFeatures.add(feature);
				}
			}
		}
	}

	public String toString() {
		StringBuffer buffer = new StringBuffer();
		buffer.append("<GroupTN>\n");
		buffer.append("<GroupTNId>").append(groupTNId).append("</GroupTNId>\n");
		buffer.append("<SipDomain>").append(sipDomain).append("</SipDomain>\n");
		buffer.append("<TNCLIDFirstName>").append(tnCLIDFirstName).append("</TNCLIDFirstName>\n");
		buffer.append("<TNCLIDLastName>").append(tnCLIDLastName).append("</TNCLIDLastName>\n");
		buffer.append("<sequenceNo>").append(sequenceNo).append("</sequenceNo>\n");
		buffer.append("<tnRecord>").append(tnRecord).append("</tnRecord>\n");
		buffer.append("<extension>").append(extension).append("</extension>\n");
		buffer.append("<privateNumber>").append(extension).append("</privateNumber>\n");
		buffer.append("<linePort>").append(linePort).append("</linePort>\n");
		buffer.append("<vmBoxNumber>").append(vmBoxNumber).append("</vmBoxNumber>\n");
		buffer.append("<isFmcgDelete>").append(isFmcgDelete).append("</isFmcgDelete>\n");
		buffer.append("<PkgDiffFeatures>").append(pkgDiffFeatures).append("</PkgDiffFeatures>\n");

		if (nonPkgFeatures == null) {
			buffer.append("<NonPkgFeatures>null</NonPkgFeatures>\n");
		} else {
			buffer.append("<NonPkgFeatures>\n");
			for (String nonPkgFeature : nonPkgFeatures) {
				buffer.append("<NonPkgFeature>").append(nonPkgFeature).append("</NonPkgFeature>\n");
			}
			buffer.append("</NonPkgFeatures>\n");
		}
		/*
		 * March Voip Feature Enhancement Changes
		 */
		if (userFeatures == null) {
			buffer.append("<UserFeatures>null</UserFeatures>\n");
		} else {
			buffer.append("<UserFeatures>\n");
			for (String usrFeatures : userFeatures) {
				buffer.append("<UserFeature>").append(usrFeatures).append("</UserFeature>\n");
			}
			buffer.append("</UserFeatures>\n");
		}
		if (disableFeatureList == null) {
			buffer.append("<disableFeatureList>null</disableFeatureList>\n");
		} else {
			buffer.append("<disableFeatureList>\n");
			for (String disableFeature : disableFeatureList) {
				buffer.append("<disableFeature>").append(disableFeature).append("</disableFeature>\n");
			}
			buffer.append("</disableFeatureList>\n");
		}

		if (trunkGroupEntity == null) {
			buffer.append("<TrunkGroupEntity>null</TrunkGroupEntity>\n");
		} else {
			buffer.append(trunkGroupEntity.toString());
		}
		buffer.append("<vmType>").append(vmType).append("</vmType>\n");
		// buffer.append("<GroupTNFMCG>").append(groupTNFMCG).append("</GroupTNFMCG>\n");
		// TODO : check if this is needed
		buffer.append("<subscriberId>").append(subscriberId).append("</subscriberId>\n");
		buffer.append("<AuthFeatureType>").append(authFeatureType).append("</AuthFeatureType>\n");
		buffer.append("</GroupTN>\n");
		return buffer.toString();
	}

	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public void setLocationId(String locationId) {
		this.locationId = locationId;
	}
	
	public long getEnvOrderId() {
		return envOrderId;
	}

	public void setEnvOrderId(long envOrderId) {
		this.envOrderId = envOrderId;
	}

	public GroupTNEntity getGroupTNEntity() {
		return groupTNEntity;
	}

	public void setGroupTNEntity(GroupTNEntity groupTNEntity) {
		this.groupTNEntity = groupTNEntity;
	}

	public long getInternalOrderId() {
		return internalOrderId;
	}

	public void setInternalOrderId(long internalOrderId) {
		this.internalOrderId = internalOrderId;
	}

	public String getDeviceName() {
		return deviceName;
	}

	public void setDeviceName(String deviceName) {
		this.deviceName = deviceName;
	}

	public String getEntityAction() {
		return entityAction;
	}

	public void setEntityAction(String entityAction) {
		this.entityAction = entityAction;
	}

	public String getTimeZoneId() {
		return timeZoneId;
	}

	public void setTimeZoneId(String timeZoneId) {
		this.timeZoneId = timeZoneId;
	}

	public String getDayLightSavingInd() {
		return dayLightSavingInd;
	}

	public void setDayLightSavingInd(String dayLightSavingInd) {
		this.dayLightSavingInd = dayLightSavingInd;
	}
	
	public AuthFeatureType getAuthFeatureType() {
		return authFeatureType;
	}

	public void setAuthFeatureType(AuthFeatureType authFeatureType) {
		this.authFeatureType = authFeatureType;
	}
	
	public String getAsClli() {
		return asClli;
	}

	public void setAsClli(String asClli) {
		this.asClli = asClli;
	}
}
