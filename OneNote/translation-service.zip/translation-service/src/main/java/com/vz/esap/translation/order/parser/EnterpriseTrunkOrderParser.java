package com.vz.esap.translation.order.parser;

import java.text.ParseException;
import java.util.List;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.vz.esap.translation.entity.EnterpriseTrunkEntity;
import com.vz.esap.translation.exception.GenericException;
import com.vz.esap.translation.exception.TranslatorException;
import com.vz.esap.translation.order.model.request.VOIPOrderRequest;

public interface EnterpriseTrunkOrderParser {
	

	/**
	 * @param voipOrderRequest
	 * @return enterpriseTrunkList
	 * @throws TranslatorException
	 * @throws ParseException
	 * @throws GenericException
	 * @throws JsonProcessingException 
	 */
	List<EnterpriseTrunkEntity> parseEnterpriseTrunkOrder(VOIPOrderRequest voipOrderRequest)
			throws TranslatorException, ParseException, JsonProcessingException;


}
