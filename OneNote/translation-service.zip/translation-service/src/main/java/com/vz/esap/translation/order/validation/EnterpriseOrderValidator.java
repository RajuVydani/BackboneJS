package com.vz.esap.translation.order.validation;

import java.util.Set;

import com.vz.esap.translation.order.model.request.VOIPOrderRequest;

public interface EnterpriseOrderValidator {
	
	/**
	 * @param voipOrderRequest
	 * @return missingFields
	 */
	Set<String> validate(VOIPOrderRequest voipOrderRequest);

}
