package com.vz.esap.translation.order.service;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.vz.esap.translation.dao.model.TblEnvOrder;
import com.vz.esap.translation.dao.model.TblOrder;
import com.vz.esap.translation.dao.model.TblOrderDetails;
import com.vz.esap.translation.dao.model.TblOrderService;
import com.vz.esap.translation.dao.repository.CustomTblOrderServiceMapper;
import com.vz.esap.translation.enums.EsapEnum.FlowPath;
import com.vz.esap.translation.enums.EsapEnum.PcMilestone;
import com.vz.esap.translation.enums.EsapEnum.PcResponseType;
import com.vz.esap.translation.enums.EsapEnum.StatusCode;
import com.vz.esap.translation.exception.GenericException;
import com.vz.esap.translation.exception.TranslatorException;
import com.vz.esap.translation.order.dao.VOIPOrderDao;
import com.vz.esap.translation.order.model.Order;
import com.vz.esap.translation.order.model.OrderHeader;
import com.vz.esap.translation.order.model.request.ParamInfo;
import com.vz.esap.translation.order.model.request.VOIPOrderRequest;
import com.vz.esap.translation.order.model.response.VoipOrderResponse;
import com.vz.esap.translation.order.parser.OrderParser;
import com.vz.esap.translation.order.service.helper.OrderServiceHelper;
import com.vz.esap.translation.order.transformer.CommonTblOrderTransformer;
import com.vz.esap.translation.order.transformer.EnterpriseEnvelopOrderTransformer;
import com.vz.esap.translation.order.transformer.EnterpriseTblOrderServiceDataTransformer;

import EsapEnumPkg.WorkOrderEnum;

/**
 * @author chattni
 *
 */

@Service
public class CancelOrderServiceImpl extends OrderServiceBase implements CancelOrderService {

	private static final Logger LOG = LoggerFactory.getLogger(CancelOrderServiceImpl.class);

	@Autowired
	private VOIPOrderDao voipOrderDao;

	@Autowired
	private OrderServiceHelper orderServiceHelperImpl;

	@Autowired
	private VOIPResponseGenerator voipResponseGenerator;

	@Autowired
	private EnterpriseEnvelopOrderTransformer enterpriseEnvelopOrderData;

	@Autowired
	private CommonTblOrderTransformer commonTblOrderTransformerImpl;

	@Autowired
	private EnterpriseTblOrderServiceDataTransformer enterpriseTblOrderServiceData;

	@Autowired
	private OrderParser orderParserImpl;
	
	@Autowired
	private CustomTblOrderServiceMapper customTblOrderServiceMapper;
	
	@Autowired
	private NotificationService notificationServiceImpl;

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.vz.esap.translation.order.service.CancelOrderService#
	 * createCancelWorkOrder(com.vz.esap.translation.order.model.request.
	 * VOIPOrderRequest)
	 */
	@Override
	public VoipOrderResponse createCancelWorkOrder(VOIPOrderRequest voipOrderRequest)
			throws TranslatorException, GenericException {
		LOG.info("Entered createCancelWorkOrder");

		OrderHeader orderHeader = null;
		List<TblEnvOrder> tblEnvOrderListPrev = null;
		List<TblOrder> tblOrderListPrev = null;
		VOIPOrderRequest voipOrderRequestPrev = null;
		int orderVersion = -1;
		TblEnvOrder tblEnvOrderPrev = null;
		Order order = null;
		TblEnvOrder tblEnvOrderCurrent = null;
		long envOrderCount = -1;
		VoipOrderResponse voipOrderResponse = null;

		try {

			orderVersion = Integer.parseInt(voipOrderRequest.getOrderHeader().getWorkOrderVersion());

			LOG.info("Start Cancel Order for Order Version = {}", orderVersion);

			if (orderVersion == 0) {
				// TODO Implementation of Cancel Order is Due
			} else if (orderVersion > 0) {
				voipOrderRequestPrev = orderParserImpl.getCorrectPrevPassVoipOrderRequest(voipOrderRequest);
				//voipOrderRequestPrev.getOrderHeader().setWorkOrderVersion(Integer.toString(orderVersion - 1));

				tblEnvOrderListPrev = orderServiceHelperImpl.getMatchingPrevPassEnvOrder(voipOrderRequestPrev, 0,
						WorkOrderEnum.OrderClassify.RELEASE);

				if (tblEnvOrderListPrev.isEmpty()) {
					throw new TranslatorException(TranslatorException.ErrorCode.ENV_ORDER_NOT_FOUND,
							"Env Order Not Found for Order Number=:"
									+ voipOrderRequest.getOrderHeader().getWorkOrderNumber());
				}

				LOG.info("Env Order Id Prev Pass - {}", tblEnvOrderListPrev.get(0).getEnvOrderId());

				tblEnvOrderPrev = new TblEnvOrder();
				tblEnvOrderPrev.setEnvOrderId(tblEnvOrderListPrev.get(0).getEnvOrderId());
				tblOrderListPrev = voipOrderDao.getTblOrder(tblEnvOrderPrev);

				if (tblOrderListPrev.isEmpty()) {
					throw new TranslatorException(TranslatorException.ErrorCode.TBL_ORDER_RECORD_NOT_FOUND,
							"Tbl Order Not Found for Order Number=:"
									+ voipOrderRequest.getOrderHeader().getWorkOrderNumber());
				}

				LOG.info("Tbl Order List Size Prev Pass - {}", tblOrderListPrev.size());

				voipOrderRequest.getOrderHeader().setRegion(tblEnvOrderListPrev.get(0).getRegion());
				voipOrderRequest.getOrderHeader().setEnterpriseId(tblEnvOrderListPrev.get(0).getEnterpriseId());

				orderHeader = createdOrderHeaderForEnterpriseOrder(voipOrderRequest, null);

				order = new Order();
				orderHeader.setOrderStatus(WorkOrderEnum.Status.WO_RECV_SEGMENT);
				order.setOrderHeader(orderHeader);

				tblEnvOrderCurrent = enterpriseEnvelopOrderData.createTblEnvOrderFromOrder(order, voipOrderRequest);
				envOrderCount = voipOrderDao.createEnvelopOrder(tblEnvOrderCurrent);
				
				voipOrderDao.updateTblEnvOrderStatus(tblEnvOrderListPrev.get(0).getEnvOrderId(),
						WorkOrderEnum.Status.WO_CANCELLED);

				createReverseOrder(voipOrderRequest, tblOrderListPrev, tblEnvOrderCurrent);

			}

			voipOrderResponse = voipResponseGenerator.prepareSuccessOrderResponse(voipOrderRequest);
			
			if(tblEnvOrderCurrent!=null) {
				//voipOrderDao.createParentChildOrderRelationship(tblEnvOrderCurrent, FlowPath.R);
				voipOrderDao.createParentChildOrderRelationship(tblEnvOrderCurrent);
				voipOrderDao.updateTblEnvOrderStatus(tblEnvOrderCurrent.getEnvOrderId(), WorkOrderEnum.Status.WO_INIT);
			}
			
			notificationServiceImpl.notifySuccess(voipResponseGenerator.preparePCMilestone(voipOrderRequest,
					PcMilestone.ORDER_ACCEPTANCE.getValue(), StatusCode.ESP_SUCCESS, PcResponseType.ORDER.getValue()));
			
		} catch (TranslatorException ex) {
			LOG.error("Exception {} ", ex.getMessage());
			throw new TranslatorException(ex.getErrorCode(), ex.getMessage());
		} catch (Exception e) {

			if (tblEnvOrderCurrent != null && envOrderCount > 0)
				voipOrderDao.updateTblEnvOrderStatus(tblEnvOrderCurrent.getEnvOrderId(),
						WorkOrderEnum.Status.WO_TRANSLATION_FAIL);

			notificationServiceImpl.notifyFailures(voipResponseGenerator.preparePCMilestone(voipOrderRequest,
					PcMilestone.ORDER_ACCEPTANCE.getValue(), StatusCode.ESP_FAILURE, PcResponseType.ORDER.getValue()));
			
			LOG.error("Exception {} ", e.getMessage());
			throw new GenericException(GenericException.GENERIC_EXCEPTION, "Exception in createCancelWorkOrder");
		}

		LOG.info("Exit createCancelWorkOrder");
		return voipOrderResponse;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.vz.esap.translation.order.service.CancelOrderService#createReverseOrder(
	 * com.vz.esap.translation.order.model.request.VOIPOrderRequest, java.util.List,
	 * java.util.List, com.vz.esap.translation.dao.model.TblEnvOrder)
	 */
	@Override
	public void createReverseOrder(VOIPOrderRequest voipOrderRequest,
			List<TblOrder> tblOrderListOrig, TblEnvOrder tblEnvOrderCurrent)
			throws TranslatorException, GenericException {
		LOG.info("Entered createReverseOrder");

		List<TblOrderDetails> tblOrderDetailsListPrev = null;
		ParamInfo headerParamInfo = null;
		ParamInfo entityParamInfo = null;
		TblOrder tblOrderCurrent = null;
		List<TblOrderService> tblOrderServiceListCurrent = null;
		boolean isOtherActiveLocationPresent = true;

		try {
			
				
			Collections.sort(tblOrderListOrig, Collections
					.reverseOrder((TblOrder ord1, TblOrder ord2) -> (int) (ord1.getOrderId() - ord2.getOrderId())));

			for (TblOrder tblOrderOrig : tblOrderListOrig) {

				LOG.info("Tbl Order Id Prev Pass - {} and Upstream Task Id - {} ", tblOrderOrig.getOrderId(),
						tblOrderOrig.getUpstreamTaskId());
				
				//NBS disconnect is done manually
				if ("I".equalsIgnoreCase(voipOrderRequest.getOrderHeader().getOrderType())
						&& tblOrderOrig.getUpstreamTaskId() == 66) {
					continue;
				}
				
				if ("I".equalsIgnoreCase(voipOrderRequest.getOrderHeader().getOrderType())
						&& tblOrderOrig.getUpstreamTaskId() == 1) {
					LOG.info("Searching BW for Enterprise Id = {}", voipOrderRequest.getOrderHeader().getEnterpriseId());
					
					isOtherActiveLocationPresent = orderServiceHelperImpl.isOtherActiveLocationPresentUnderEnterpriseInBw(
							voipOrderRequest.getOrderHeader().getEnterpriseId(),
							Arrays.asList(voipOrderRequest.getOrderHeader().getVoipLocationId()));
							
					LOG.info("isOtherActiveLocationPresent --> {}", isOtherActiveLocationPresent);
					
					if (isOtherActiveLocationPresent) {
						break;
					}
				}

				tblOrderDetailsListPrev = voipOrderDao.getOrderDetailsEntriesPerOrder(tblOrderOrig);

				if (tblOrderDetailsListPrev.isEmpty()) {
					throw new TranslatorException(TranslatorException.ErrorCode.TBL_ORDER_DETAILS_RECORD_NOT_FOUND,
							"Tbl Order Details Not Found for Order Number=:"
									+ voipOrderRequest.getOrderHeader().getWorkOrderNumber());
				}

				LOG.info("Tbl Order Detail List Size Prev Pass - {} And Param_Name = {}", tblOrderDetailsListPrev.size(),
						tblOrderDetailsListPrev.get(0).getParamName());	
				
				// :create order
				tblOrderCurrent = createReverseTblOrder(tblOrderOrig, tblEnvOrderCurrent);
				
				// :Cancelling Previous order
				voipOrderDao.updateTblOrderStatus(tblOrderOrig.getOrderId(), WorkOrderEnum.Status.WO_CANCELLED);

				LOG.info("New Tbl_Order_Id = {} And Old Tbl_Order_Id = {} ", tblOrderCurrent.getOrderId(),
						tblOrderOrig.getOrderId());

				headerParamInfo = prepareTblOrdDetHeaderParamDataFromExistingTblOrdDet(tblOrderDetailsListPrev,
						voipOrderRequest.getOrderHeader().getSuppType(), null, tblEnvOrderCurrent);

				entityParamInfo = prepareTblOrdDetEntityParamDataFromExistingTblOrdDet(tblOrderDetailsListPrev,
						voipOrderRequest.getOrderHeader().getSuppType(), null);

				headerParamInfo.addChildParam(entityParamInfo);

				voipOrderDao.populateOrderDetails(tblOrderCurrent, headerParamInfo.getChildParams(), "o", 0, 0);

				tblOrderServiceListCurrent = enterpriseTblOrderServiceData
						.prepareTblOrderServiceForReverseOrder(tblOrderOrig, tblOrderCurrent);
				
				// :Cancelling Previous order Service
				//Fix this for Drop Scenario
				//voipOrderDao.updateOrderServiceStatus(tblOrderOrig.getOrderId(), 0, WorkOrderEnum.Status.WO_CANCELLED);

				LOG.info("Retail Order Service Count : {}", tblOrderServiceListCurrent.size());

				for (TblOrderService tblOrderService : tblOrderServiceListCurrent) {
					voipOrderDao.createTblOrderService(tblOrderService);
				}

			}

		} catch (TranslatorException ex) {
			LOG.error("Exception {} ", ex.getMessage());
			throw new TranslatorException(ex.getErrorCode(), ex.getMessage());
		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new GenericException(GenericException.GENERIC_EXCEPTION, "Exception in createReverseOrder");
		}

		LOG.info("Exit createReverseOrder");
	}
	
	/**
	 * @param tblOrderOrig
	 * @param tblEnvOrderCurrent
	 * @return TblOrder
	 * @throws GenericException
	 * @throws TranslatorException
	 */
	TblOrder createReverseTblOrder(TblOrder tblOrderOrig, TblEnvOrder tblEnvOrderCurrent)
			throws GenericException, TranslatorException {

		LOG.info("Entered createReverseTblOrder");

		Map<String, String> mapForUpdate = new HashMap<>();
		mapForUpdate.put("EnvOrderId", tblEnvOrderCurrent.getEnvOrderId().toString());
		mapForUpdate.put("TransactionNumber", tblEnvOrderCurrent.getTransactionId().toString());
		mapForUpdate.put("OrderStatus", String.valueOf(WorkOrderEnum.Status.WO_INIT));
		mapForUpdate.put("VersionNo", tblEnvOrderCurrent.getVersionNumber().toString());
		mapForUpdate.put("FlowPath", FlowPath.R.toString());

		TblOrder tblOrderCurr = commonTblOrderTransformerImpl.prepareTblOrderDataFromExistingTblOrder(tblOrderOrig,
				mapForUpdate);

		voipOrderDao.createTblOrder(tblOrderCurr);

		LOG.info("Exited createReverseTblOrder");
		return tblOrderCurr;
	}

}
