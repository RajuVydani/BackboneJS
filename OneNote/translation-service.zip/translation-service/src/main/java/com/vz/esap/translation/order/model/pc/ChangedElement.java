package com.vz.esap.translation.order.model.pc;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;

import com.fasterxml.jackson.annotation.JsonProperty;

@XmlAccessorType(XmlAccessType.FIELD)
public class ChangedElement {
	
	@XmlElement(name = "ValueIdentifier")
	@JsonProperty(value = "ValueIdentifier")
	private String valueIdentifier;

	@XmlElement(name = "ChangeIdentifier")
	@JsonProperty(value = "ChangeIdentifier")
	private String changeIdentifier;

	@XmlElement(name = "NewValue")
	@JsonProperty(value = "NewValue")
	private String newValue;

	@XmlElement(name = "FeatureInstanceId")
	@JsonProperty(value = "FeatureInstanceId")
	private String featureInstanceId;

	@XmlElement(name = "OriginalValue")
	@JsonProperty(value = "OriginalValue")
	private String originalValue;

	@XmlElement(name = "FeatureCode")
	@JsonProperty(value = "FeatureCode")
	private String featureCode;

	@XmlElement(name = "SpecificationCode")
	@JsonProperty(value = "SpecificationCode")
	private String specificationCode;

	@XmlElement(name = "ChangeType")
	@JsonProperty(value = "ChangeType")
	private String changeType;

	public String getValueIdentifier() {
		return valueIdentifier;
	}

	public void setValueIdentifier(String ValueIdentifier) {
		this.valueIdentifier = ValueIdentifier;
	}

	public String getChangeIdentifier() {
		return changeIdentifier;
	}

	public void setChangeIdentifier(String ChangeIdentifier) {
		this.changeIdentifier = ChangeIdentifier;
	}

	public String getNewValue() {
		return newValue;
	}

	public void setNewValue(String NewValue) {
		this.newValue = NewValue;
	}

	public String getFeatureInstanceId() {
		return featureInstanceId;
	}

	public void setFeatureInstanceId(String FeatureInstanceId) {
		this.featureInstanceId = FeatureInstanceId;
	}

	public String getOriginalValue() {
		return originalValue;
	}

	public void setOriginalValue(String OriginalValue) {
		this.originalValue = OriginalValue;
	}

	public String getFeatureCode() {
		return featureCode;
	}

	public void setFeatureCode(String FeatureCode) {
		this.featureCode = FeatureCode;
	}

	public String getSpecificationCode() {
		return specificationCode;
	}

	public void setSpecificationCode(String SpecificationCode) {
		this.specificationCode = SpecificationCode;
	}

	public String getChangeType() {
		return changeType;
	}

	public void setChangeType(String ChangeType) {
		this.changeType = ChangeType;
	}

	@Override
	public String toString() {
		return "ClassPojo [ValueIdentifier = " + valueIdentifier + ", ChangeIdentifier = " + changeIdentifier
				+ ", NewValue = " + newValue + ", FeatureInstanceId = " + featureInstanceId + ", OriginalValue = "
				+ originalValue + ", FeatureCode = " + featureCode + ", SpecificationCode = " + specificationCode
				+ ", ChangeType = " + changeType + "]";
	}
}
