package com.vz.esap.translation.order.transformer;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Component;

import com.vz.esap.translation.entity.GroupTNEntity;
import com.vz.esap.translation.entity.TNEntity;
import com.vz.esap.translation.exception.GenericException;
import com.vz.esap.translation.exception.TranslatorException;
import com.vz.esap.translation.order.model.request.VOIPOrderRequest;

/**
 * @author baigkh
 *
 */
@Component
public interface GroupTnTransformer {
	/**
	 * @param orderId
	 * @param parentId
	 * @param action
	 * @param delta
	 * @return deviceEntity
	 * @throws TranslatorException
	 */
	GroupTNEntity transformOrderDetailsToGroupTn(long orderId, long parentId, String action, boolean delta, List<String> paramActionExclusionList) throws TranslatorException;

	GroupTNEntity enrichGroupTNEntityWithInventory(VOIPOrderRequest voipOrderRequest, GroupTNEntity groupTNEntity) throws TranslatorException, GenericException;

	GroupTNEntity groupTnEntityInventoryTogroupTnEntityTransformer(Map<String, String> resultantRow);

	TNEntity tnEntityInventoryToTnEntityTransformer(Map<String, String> resultantRow);
	
}

