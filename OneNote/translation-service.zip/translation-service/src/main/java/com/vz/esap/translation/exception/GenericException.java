package com.vz.esap.translation.exception;

public class GenericException extends Exception {

	private static final long serialVersionUID = -7894284007591953781L;

	public static final String GENERIC_EXCEPTION = "GENERIC_EXCEPTION";

	public GenericException(String errorCode, String errorMessage) {
		super(errorMessage);
	}

}
