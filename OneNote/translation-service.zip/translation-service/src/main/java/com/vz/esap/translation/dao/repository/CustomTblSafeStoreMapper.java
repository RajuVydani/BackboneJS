package com.vz.esap.translation.dao.repository;

import com.vz.esap.translation.dao.model.TblSafeStore;

public interface CustomTblSafeStoreMapper {

	void updateTblSafeStoreWithTranslationStartTime(
			TblSafeStore tblSafeStoreObject);

	void updateTblSafeStoreWithTranslationEndTime(
			TblSafeStore tblSafeStoreObject);
	
	void insert(
			TblSafeStore tblSafeStoreObject);
	
	long getTblSafeStoreSeqNextVal();

}