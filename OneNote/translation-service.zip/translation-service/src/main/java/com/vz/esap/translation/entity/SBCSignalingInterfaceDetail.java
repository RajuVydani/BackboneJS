package com.vz.esap.translation.entity;

import java.util.Map;

import org.springframework.stereotype.Component;

import EsapEnumPkg.VzbVoipEnums.TransportEnum;

/**
 * This class forms the new Data Structure ( since July'11 ) for Signaling
 * Interface related details transfer. This class will closely match the TOD
 * structure of SBC Order. This structure will be used by DNS prov. tasks and
 * Broadsoft
 */
@Component
public class SBCSignalingInterfaceDetail {

	public static enum InterfaceNetworkType {
		CUSTOMER, CARRIER
	};

	public static enum SignalingTrafficType {
		REGISTERING, NON_REGISTERING
	};

	private Boolean interfaceStateEnabled = Boolean.TRUE;
	private InterfaceNetworkType interfaceNetworkType;
	private SignalingTrafficType signalingTrafficType;
	private String signalingInterfaceIP;
	private Integer signalingInterfacePort;
	private TransportEnum transportProtocol; // E.g: UDP
	private String signalingFQDN;
	private String dnsAccessType;
	private String dnsDeviceSeqNum;
	private String dnsOldDeviceSeqNum;
	private Integer dnsPriority;
	private String oldSbcNode;
	private String mediaInterfaceSubnet;

	/*
	 * To Maintain IPSM DB session, for retires, later these attributes will be
	 * moved to entity
	 */
	private long parent_order_id;
	private int flowStatus;

	/**
	 * This generic Map structure is defined to accommodate transient and quick fix
	 * Please do not abuse. If any value need to defined in the Order Entity for
	 * order processing across all modules define a aptly named property rather than
	 * using this structure.
	 */
	private Map<Object, Object> addonObjectMap;

	public Boolean getInterfaceStateEnabled() {
		return interfaceStateEnabled;
	}

	public void setInterfaceStateEnabled(Boolean interfaceStateEnabled) {
		this.interfaceStateEnabled = interfaceStateEnabled;
	}

	public InterfaceNetworkType getInterfaceNetworkType() {
		return interfaceNetworkType;
	}

	public void setInterfaceNetworkType(InterfaceNetworkType interfaceNetworkType) {
		this.interfaceNetworkType = interfaceNetworkType;
	}

	public SignalingTrafficType getSignalingTrafficType() {
		return signalingTrafficType;
	}

	public void setSignalingTrafficType(SignalingTrafficType signalingTrafficType) {
		this.signalingTrafficType = signalingTrafficType;
	}

	public String getSignalingInterfaceIP() {
		return signalingInterfaceIP;
	}

	public void setSignalingInterfaceIP(String signalingInterfaceIP) {
		this.signalingInterfaceIP = signalingInterfaceIP;
	}

	public Integer getSignalingInterfacePort() {
		return signalingInterfacePort;
	}

	public void setSignalingInterfacePort(Integer signalingInterfacePort) {
		this.signalingInterfacePort = signalingInterfacePort;
	}

	public TransportEnum getTransportProtocol() {
		return transportProtocol;
	}

	public void setTransportProtocol(TransportEnum transportProtocol) {
		this.transportProtocol = transportProtocol;
	}

	public String getSignalingFQDN() {
		return signalingFQDN;
	}

	public void setSignalingFQDN(String signalingFQDN) {
		this.signalingFQDN = signalingFQDN;
	}

	public String getDnsAccessType() {
		return dnsAccessType;
	}

	public void setDnsAccessType(String dnsAccessType) {
		this.dnsAccessType = dnsAccessType;
	}

	public String getDnsDeviceSeqNum() {
		return dnsDeviceSeqNum;
	}

	public void setDnsDeviceSeqNum(String dnsDeviceSeqNum) {
		this.dnsDeviceSeqNum = dnsDeviceSeqNum;
	}

	public String getDnsOldDeviceSeqNum() {
		return dnsOldDeviceSeqNum;
	}

	public void setDnsOldDeviceSeqNum(String dnsOldDeviceSeqNum) {
		this.dnsOldDeviceSeqNum = dnsOldDeviceSeqNum;
	}

	public Integer getDnsPriority() {
		return dnsPriority;
	}

	public void setDnsPriority(Integer dnsPriority) {
		this.dnsPriority = dnsPriority;
	}

	public String getOldSbcNode() {
		return oldSbcNode;
	}

	public void setOldSbcNode(String oldSbcNode) {
		this.oldSbcNode = oldSbcNode;
	}

	public String getMediaInterfaceSubnet() {
		return mediaInterfaceSubnet;
	}

	public void setMediaInterfaceSubnet(String mediaInterfaceSubnet) {
		this.mediaInterfaceSubnet = mediaInterfaceSubnet;
	}

	public long getParent_order_id() {
		return parent_order_id;
	}

	public void setParent_order_id(long parent_order_id) {
		this.parent_order_id = parent_order_id;
	}

	public int getFlowStatus() {
		return flowStatus;
	}

	public void setFlowStatus(int flowStatus) {
		this.flowStatus = flowStatus;
	}

	public Map<Object, Object> getAddonObjectMap() {
		return addonObjectMap;
	}

	public void setAddonObjectMap(Map<Object, Object> addonObjectMap) {
		this.addonObjectMap = addonObjectMap;
	}

}