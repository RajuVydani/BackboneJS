package com.vz.esap.translation.order.model.response;

import com.fasterxml.jackson.annotation.JsonProperty;

public class DNSInfo {

	@JsonProperty(value = "Priority")
	private String priority;

	@JsonProperty(value = "DeviceName")
	private String deviceName;

	@JsonProperty(value = "Identifier")
	private String identifier;

	@JsonProperty(value = "DNSNodeName")
	private String dnsNodeName;

	@JsonProperty(value = "AccessType")
	private String accessType;

	@JsonProperty(value = "SBCNode")
	private String sbcNode;

	@JsonProperty(value = "DeviceSeqNo")
	private String deviceSeqNo;

	@JsonProperty(value = "SubDomainName")
	private String subDomainName;

	@JsonProperty(value = "DomainName")
	private String domainName;

	@JsonProperty(value = "Port")
	private String port;

	@JsonProperty(value = "Protocol")
	private String protocol;

	@JsonProperty(value = "HostAddress")
	private String hostAddress;

	public String getPriority() {
		return priority;
	}

	public void setPriority(String priority) {
		this.priority = priority;
	}

	public String getDeviceName() {
		return deviceName;
	}

	public void setDeviceName(String deviceName) {
		this.deviceName = deviceName;
	}

	public String getIdentifier() {
		return identifier;
	}

	public void setIdentifier(String identifier) {
		this.identifier = identifier;
	}

	public String getDnsNodeName() {
		return dnsNodeName;
	}

	public void setDnsNodeName(String dnsNodeName) {
		this.dnsNodeName = dnsNodeName;
	}

	public String getAccessType() {
		return accessType;
	}

	public void setAccessType(String accessType) {
		this.accessType = accessType;
	}

	public String getSbcNode() {
		return sbcNode;
	}

	public void setSbcNode(String sbcNode) {
		this.sbcNode = sbcNode;
	}

	public String getDeviceSeqNo() {
		return deviceSeqNo;
	}

	public void setDeviceSeqNo(String deviceSeqNo) {
		this.deviceSeqNo = deviceSeqNo;
	}

	public String getSubDomainName() {
		return subDomainName;
	}

	public void setSubDomainName(String subDomainName) {
		this.subDomainName = subDomainName;
	}

	public String getDomainName() {
		return domainName;
	}

	public void setDomainName(String domainName) {
		this.domainName = domainName;
	}

	public String getPort() {
		return port;
	}

	public void setPort(String port) {
		this.port = port;
	}

	public String getProtocol() {
		return protocol;
	}

	public void setProtocol(String protocol) {
		this.protocol = protocol;
	}

	public String getHostAddress() {
		return hostAddress;
	}

	public void setHostAddress(String hostAddress) {
		this.hostAddress = hostAddress;
	}

}
