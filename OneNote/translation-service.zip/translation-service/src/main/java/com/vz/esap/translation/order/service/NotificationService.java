package com.vz.esap.translation.order.service;

import com.vz.esap.translation.exception.GenericException;
import com.vz.esap.translation.order.model.response.ResponseObject;
import com.vz.esap.translation.order.model.response.VoipOrderResponse;

public interface NotificationService {
	
	/**
	 * @param voipOrderResponse
	 * @return responseObject
	 * @throws GenericException 
	 */
	public ResponseObject notifyFailures(VoipOrderResponse voipOrderResponse) throws GenericException;
	

	/**
	 * @param voipOrderResponse
	 * @return responseObject
	 * @throws GenericException 
	 */
	public ResponseObject notifySuccess(VoipOrderResponse voipOrderResponse) throws GenericException;



}
