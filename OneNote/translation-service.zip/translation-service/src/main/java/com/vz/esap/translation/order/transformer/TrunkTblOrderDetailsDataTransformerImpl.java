package com.vz.esap.translation.order.transformer;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.vz.esap.translation.dao.model.TblOrder;
import com.vz.esap.translation.entity.Entity;
import com.vz.esap.translation.entity.TrunkGroupEntity;
import com.vz.esap.translation.enums.EsapEnum;
import com.vz.esap.translation.exception.TranslatorException;
import com.vz.esap.translation.exception.TranslatorException.ErrorCode;
import com.vz.esap.translation.order.model.Order;
import com.vz.esap.translation.order.model.request.Feature;
import com.vz.esap.translation.order.model.request.ParamInfo;
import com.vz.esap.translation.order.model.request.VOIPOrderRequest;
import com.vz.esap.translation.util.OrderUtility;

import static java.util.Arrays.stream;

/**
 * @author kalagsu
 *
 */
@Component
public class TrunkTblOrderDetailsDataTransformerImpl implements TrunkTblOrderDetailsDataTransformer {

	private static final Logger LOG = LoggerFactory.getLogger(TrunkTblOrderDetailsDataTransformerImpl.class);

	private static final String LOCATION_ID = "LocationId";
	private static final String CUSTOMER_ID = "CustomerId";
	private static final String REGION = "Region";
	// private static final String BS_APP_SERVER = "BsAppServer";
	private static final String HOT_CUT_IND = "HotCutIndicator";
	private static final String CDD_IND = "CDDDIndicator";

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.vz.esap.translation.order.transformer.TrunkTblOrderDetailsDataTransformer
	 * #prepareTblOrderDetailsEntityParamDataForTrunk(com.vz.esap.translation.order.
	 * model.Order)
	 */
	@Override
	public ParamInfo prepareTblOrderDetailsEntityParamDataForTrunk(Order order, String action)
			throws TranslatorException {
		LOG.info("Entered - prepareTblOrderDetailsEntityParamDataForTrunk(order, action)");

		if (order.getTrunkGroupEntity() == null)
			return null;

		if (action == null)
			action = order.getOrderHeader().getOrderType();

		ParamInfo root = null;
		ParamInfo pilotUser = null;
		boolean forwardFeature = false;
		try {
			root = new ParamInfo("Group", null, action);
			if (order.getTrunkGroupEntity().getGroupId() != null) {
				root.addChildParam(new ParamInfo("GroupId", order.getTrunkGroupEntity().getGroupId().toString(), action,
						ParamInfo.Tag.ID));
				if (order.getTrunkGroupEntity().getGroupType() != null) {
					if (order.getTrunkGroupEntity().getGroupType().equals(Entity.GroupType.PBX))
						root.addChildParam(new ParamInfo("PBXGroupId",
								order.getTrunkGroupEntity().getGroupId().toString(), action, ParamInfo.Tag.ID));
					else if (order.getTrunkGroupEntity().getGroupType().equals(Entity.GroupType.KEY))
						root.addChildParam(new ParamInfo("KeyGroupId",
								order.getTrunkGroupEntity().getGroupId().toString(), action, ParamInfo.Tag.ID));
				}
			}

			if (order.getTrunkGroupEntity().getGroupType() != null) {
				root.addChildParam(
						new ParamInfo("GroupType", order.getTrunkGroupEntity().getGroupType().toString(), action));
				root.addChildParam(new ParamInfo("SimpleFeaturePackage",
						order.getTrunkGroupEntity().getSimpleFeaturePackage(), action));

			}

			root.addNotNullValChild("CustomerId", order.getTrunkGroupEntity().getCustomerId(), action,
					ParamInfo.Tag.ID);
			root.addNotNullValChild("LocationId", order.getTrunkGroupEntity().getLocationId(), action,
					ParamInfo.Tag.ID);
			root.addNotNullValChild("DepartmentId", order.getTrunkGroupEntity().getDepartmentId(), action);
			root.addNotNullValChild("Name", order.getTrunkGroupEntity().getName(), action, ParamInfo.Tag.NAME);

			root.addNotNullValChild("MaxConcurrentCallLimit", order.getTrunkGroupEntity().getMaxConcurrentCallLimit(),
					action);
			if (order.getTrunkGroupEntity().hasNonPkgFeature("Trunk Group Unreachable")) {
				forwardFeature = true;
				if ("O".equals(action))
					root.addNotNullValChild("TRUNK_REDIRECT", "DEL", action, ParamInfo.Tag.WF);
				else if ("I".equals(action))
					root.addNotNullValChild("TRUNK_REDIRECT", "ADD", action, ParamInfo.Tag.WF);
				else
					root.addNotNullValChild("TRUNK_REDIRECT", null, action, ParamInfo.Tag.WF);
			}

			root.addNotNullValChild("InvitationTimer", order.getTrunkGroupEntity().getInvitationTimer(), action);
			if (forwardFeature) {
				root.addNotNullValChild("ForwardToGroupId", order.getTrunkGroupEntity().getForwardToGroupId(), action);
				root.addNotNullValChild("ForwardToGroupName", order.getTrunkGroupEntity().getForwardToGroupName(),
						action);
			}
			ArrayList<String> disableFeatureList = order.getTrunkGroupEntity().getDisableFeatureList();
			if (disableFeatureList != null) {
				ParamInfo dfParam = new ParamInfo("DisableFeatureList", (String) null, action);

				for (String feature : disableFeatureList) {
					LOG.info("GroupUtil Adding DisableFeature:" + feature);
					dfParam.addChildParam(new ParamInfo("Feature", feature, action));
				}
				root.addChildParam(dfParam);
			}

			if (order.getTrunkGroupEntity().getHotCutIndicator() != null
					&& order.getTrunkGroupEntity().getHotCutIndicator() == Boolean.TRUE)
				root.addNotNullValChild("HotCutIndicator", "Y", action);
			if (order.getTrunkGroupEntity().getCDDDIndicator() != null
					&& order.getTrunkGroupEntity().getCDDDIndicator() == Boolean.TRUE)
				root.addNotNullValChild("CDDDIndicator", "Y", action);

			root.addNotNullValChild("PQInstanceId", order.getTrunkGroupEntity().getPqInstanceId(), action);

			// XOO
			root.addNotNullValChild("EnterpriseId", order.getOrderHeader().getEnterpriseId(), action);
			root.addNotNullValChild("LocationId", order.getTrunkGroupEntity().getLocationId(), action);
			root.addNotNullValChild("MaxActiveCalls", order.getTrunkGroupEntity().getMaxActiveCalls(), action);
			root.addNotNullValChild("MaxIncomingCalls", order.getTrunkGroupEntity().getMaxIncomingCalls(), action);
			root.addNotNullValChild("EnableBursting", "false", action);
			root.addNotNullValChild("BurstingMaxActiveCalls", "1", action);
			root.addNotNullValChild("BurstingMaxActiveCallsUnlimited", "true", action);
			root.addNotNullValChild("BurstingMaxIncomingCalls",
					order.getTrunkGroupEntity().getBurstingMaxIncomingCalls(), action);
			root.addNotNullValChild("BurstingMaxOutgoingCalls",
					order.getTrunkGroupEntity().getBurstingMaxOutgoingCalls(), action);
			root.addNotNullValChild("AllowedUnscreenedCalls", order.getTrunkGroupEntity().getAllowedUnscreenedCalls(),
					action);
			root.addNotNullValChild("RequireAuthentication", order.getTrunkGroupEntity().getRequireAuthentication(),
					action);
			root.addNotNullValChild("OtgDtgIdentity", order.getTrunkGroupEntity().getOtgDtgIdentity(), action);
			root.addNotNullValChild("SipAuthenticationUserName",
					order.getTrunkGroupEntity().getSipAuthenticationUserName(), action);
			root.addNotNullValChild("SipAuthenticationPassword",
					order.getTrunkGroupEntity().getSipAuthenticationPassword(), action);
			root.addNotNullValChild("ContinuousOptionsSendingIntervalSeconds", "30", action);
			root.addNotNullValChild("FailureOptionsSendingIntervalSeconds", "10", action);
			root.addNotNullValChild("FailureThresholdCounter", "1", action);
			root.addNotNullValChild("SuccessThresholdCounter", "1", action);
			root.addNotNullValChild("InviteFailureThresholdWindowSeconds", "30", action);
			root.addNotNullValChild("UseSystemCallingLineIdentityPolicy", "true", action);
			root.addNotNullValChild("UseSystemCLIDForScreenedCallsPolicy", "true", action);
			root.addNotNullValChild("UseSystemUserLookupPolicy",
					order.getTrunkGroupEntity().getUseSystemUserLookupPolicy(), action);
			root.addNotNullValChild("CallingLineIdPhoneNumber",
					order.getTrunkGroupEntity().getCallingLineIdPhoneNumber(), action);

			root.addNotNullValChild("Extension", order.getTrunkGroupEntity().getExtension(), action);
			root.addNotNullValChild("TimeZone", order.getTrunkGroupEntity().getTimeZone(), action);
			root.addNotNullValChild("TrunkCallCapacity", order.getTrunkGroupEntity().getTrunkCallCapacity(), action);
			root.addNotNullValChild("CommittedSessionCount", order.getTrunkGroupEntity().getCommittedSessionCount(),
					action);
			root.addNotNullValChild("InternationalLDRestriction",
					order.getTrunkGroupEntity().getInternationalLDRestriction(), action);
			root.addNotNullValChild("PilotTn", order.getTrunkGroupEntity().getPilotTn(), action);
			root.addNotNullValChild("DeviceMapId", order.getTrunkGroupEntity().getDeviceMapId(), action);
			root.addNotNullValChild("DeviceSeqId", order.getTrunkGroupEntity().getDeviceMapId(), action);
			root.addNotNullValChild("SignalingDirection", order.getTrunkGroupEntity().getSignalingDirection(), action);

			if (order.getTrunkGroupEntity().getPilotUser() != null) {
				pilotUser = new ParamInfo("PilotUser", null, action);
				pilotUser.addChildParam(
						new ParamInfo("UserId", order.getTrunkGroupEntity().getPilotUser().getUserId(), action));
				pilotUser.addChildParam(
						new ParamInfo("FirstName", order.getTrunkGroupEntity().getPilotUser().getFirstName(), action));
				pilotUser.addChildParam(
						new ParamInfo("LastName", order.getTrunkGroupEntity().getPilotUser().getLastName(), action));
				pilotUser.addChildParam(new ParamInfo("CallingLineIdFirstName",
						order.getTrunkGroupEntity().getPilotUser().getCallingLineIdFirstName(), action));
				pilotUser.addChildParam(new ParamInfo("CallingLineIdLastName",
						order.getTrunkGroupEntity().getPilotUser().getCallingLineIdLastName(), action));
				pilotUser.addChildParam(new ParamInfo("PhoneNumber",
						String.valueOf(order.getTrunkGroupEntity().getPilotUser().getPhoneNumber()), action));
				/*pilotUser.addChildParam(
						new ParamInfo("LinePort", order.getTrunkGroupEntity().getPilotUser().getLinePort(), action));*/
				pilotUser.addChildParam(new ParamInfo("DeviceLevel",
						order.getTrunkGroupEntity().getPilotUser().getDeviceLevel(), action));
				pilotUser.addChildParam(new ParamInfo("DeviceName",
						order.getTrunkGroupEntity().getPilotUser().getDeviceName(), action));
				root.addChildParam(pilotUser, ParamInfo.Tag.NON_ORD);
			}

			// XOO
			root.addNotNullValChild("BWTrunkGroupId", order.getTrunkGroupEntity().getBwTrunkGroupId(), action);
			// Start:EBL Change
			if (order.getTrunkGroupEntity().getVirtualTrunkId() != null)
				root.addNotNullValChild("VirtualTrunkGroupId", order.getTrunkGroupEntity().getVirtualTrunkId(), action);
			// End:EBL Change
			root.addNotNullValChild("Region", order.getTrunkGroupEntity().getRegion(), action);

			LOG.info("Exit TrunkGroupTblOrderDetailsDataTransformerImpl");

		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new TranslatorException(TranslatorException.ErrorCode.ORDER_NOT_SAVABLE,
					"Unexpected Error Occured while Parsing Trunk Order\"");
		}
		LOG.info("Exit - prepareTblOrderDetailsEntityParamDataForTrunk(order, action)");
		return root;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.vz.esap.translation.order.transformer.TrunkTblOrderDetailsDataTransformer
	 * #prepareTblOrderDetailsEntityParamDataForTrunk(com.vz.esap.translation.order.
	 * model.request.VOIPOrderRequest, com.vz.esap.translation.dao.model.TblOrder,
	 * java.util.ArrayList)
	 */
	@Override
	public ArrayList<ParamInfo> prepareTblOrderDetailsEntityParamDataForTrunk(VOIPOrderRequest voipOrderRequest,
			TblOrder tblOrderObject, ArrayList<TrunkGroupEntity> trunkGroupEntityList) {

		LOG.info(
				"Entered - prepareTblOrderDetailsEntityParamDataForTrunk(voipOrderRequest, tblOrderObject, trunkGroupEntityList)");

		if (trunkGroupEntityList == null)
			return null;
		ArrayList<ParamInfo> paramInfoList = new ArrayList<ParamInfo>();

		String action = voipOrderRequest.getOrderHeader().getOrderType();
		ParamInfo root = null;
		ParamInfo dfParam = null;
		boolean forwardFeature = false;
		ParamInfo pilotUser = null;

		for (TrunkGroupEntity trunkGroupEntity : trunkGroupEntityList) {
			root = new ParamInfo("Group", null, action);
			if (trunkGroupEntity.getGroupId() != null) {
				root.addChildParam(
						new ParamInfo("GroupId", trunkGroupEntity.getGroupId().toString(), action, ParamInfo.Tag.ID));
				if (trunkGroupEntity.getGroupType() != null) {
					if (trunkGroupEntity.getGroupType().equals(Entity.GroupType.PBX))
						root.addChildParam(new ParamInfo("PBXGroupId", trunkGroupEntity.getGroupId().toString(), action,
								ParamInfo.Tag.ID));
					else if (trunkGroupEntity.getGroupType().equals(Entity.GroupType.KEY))
						root.addChildParam(new ParamInfo("KeyGroupId", trunkGroupEntity.getGroupId().toString(), action,
								ParamInfo.Tag.ID));
				}
			}

			if (trunkGroupEntity.getGroupType() != null) {
				root.addChildParam(new ParamInfo("GroupType", trunkGroupEntity.getGroupType().toString(), action));

				root.addChildParam(
						new ParamInfo("SimpleFeaturePackage", trunkGroupEntity.getSimpleFeaturePackage(), action));

			}

			if (trunkGroupEntity.getCustomerId() != null) {
				root.addNotNullValChild("CustomerId", trunkGroupEntity.getCustomerId(), action, ParamInfo.Tag.ID);

			} else {
				root.addNotNullValChild("CustomerId", voipOrderRequest.getOrderHeader().getEnterpriseId(), action,
						ParamInfo.Tag.ID);

			}
			
			root.addNotNullValChild("LocationId", trunkGroupEntity.getLocationId(), action, ParamInfo.Tag.ID);
			root.addNotNullValChild("DepartmentId", trunkGroupEntity.getDepartmentId(), action);
			root.addNotNullValChild("Name", trunkGroupEntity.getName(), action, ParamInfo.Tag.NAME);

			root.addNotNullValChild("MaxConcurrentCallLimit", trunkGroupEntity.getMaxConcurrentCallLimit(), action);
			if (trunkGroupEntity.getCreateExtension() != null)
				root.addNotNullValChild("CreateExtension", Boolean.valueOf(trunkGroupEntity.getCreateExtension()),
						action);
			root.addNotNullValChild("CLIDFirstName", trunkGroupEntity.getCLIDFirstName(), action);
			root.addNotNullValChild("CLIDLastName", trunkGroupEntity.getCLIDLastName(), action);
			root.addNotNullValChild("TnCLIDFirstName", trunkGroupEntity.getTnCLIDFirstName(), action);
			root.addNotNullValChild("TnCLIDLastName", trunkGroupEntity.getTnCLIDLastName(), action);
			root.addNotNullValChild("TerminationOption", trunkGroupEntity.getTerminationOption(), action);
			root.addNotNullValChild("ForwardToNumber", trunkGroupEntity.getForwardToNumber(), action);
			root.addNotNullValChild("VMBoxNumber", trunkGroupEntity.getVMNumber(), action);
			LOG.info("VmPin - [" + trunkGroupEntity.getVmPin() + "]");
			root.addNotNullValChild("VMPin", trunkGroupEntity.getVmPin(), action);
			root.addNotNullValChild("Extension", trunkGroupEntity.getExtension(), action);
			root.addNotNullValChild("PrivateNumber", trunkGroupEntity.getPrivateNumber(), action);
			root.addNotNullValChild("PilotTN", trunkGroupEntity.getPilotTN(), action);
			root.addNotNullValChild("LinePortLength", trunkGroupEntity.getLinePortLength(), action);
			if (!"0".equals(trunkGroupEntity.getVMType()))
				root.addNotNullValChild("VMType", trunkGroupEntity.getVMType(), action);
			root.addNotNullValChild("LinePort", trunkGroupEntity.getLinePort(), action, ParamInfo.Tag.NON_ORD);
			root.addNotNullValChild("LastActiveTN", trunkGroupEntity.getLastActiveTN(), action, ParamInfo.Tag.NON_ORD);
			root.addNotNullValChild("FirstActiveTN", trunkGroupEntity.getFirstActiveTN(), action,
					ParamInfo.Tag.NON_ORD);
			root.addNotNullValChild("Autoflag", trunkGroupEntity.getAutoflagString(), action, ParamInfo.Tag.NON_ORD);
			root.addNotNullValChild("IEANLength", trunkGroupEntity.getIeanLength(), action, ParamInfo.Tag.NON_ORD);

			if (trunkGroupEntity.hasNonPkgFeature("Trunk Group Unreachable")) {
				forwardFeature = true;
				if ("O".equals(action))
					root.addNotNullValChild("TRUNK_REDIRECT", "DEL", action, ParamInfo.Tag.WF);
				else if ("I".equals(action))
					root.addNotNullValChild("TRUNK_REDIRECT", "ADD", action, ParamInfo.Tag.WF);
				else
					root.addNotNullValChild("TRUNK_REDIRECT", null, action, ParamInfo.Tag.WF);
			}

			root.addNotNullValChild("InvitationTimer", trunkGroupEntity.getInvitationTimer(), action);
			if (forwardFeature) {
				root.addNotNullValChild("ForwardToGroupId", trunkGroupEntity.getForwardToGroupId(), action);
				root.addNotNullValChild("ForwardToGroupName", trunkGroupEntity.getForwardToGroupName(), action);
			}
			ArrayList<String> disableFeatureList = trunkGroupEntity.getDisableFeatureList();
			if (disableFeatureList != null) {
				dfParam = new ParamInfo("DisableFeatureList", (String) null, action);

				for (String feature : disableFeatureList) {
					LOG.info("GroupUtil Adding DisableFeature:" + feature);
					dfParam.addChildParam(new ParamInfo("Feature", feature, action));
				}
				root.addChildParam(dfParam);
			}

			if (trunkGroupEntity.getHotCutIndicator() != null && trunkGroupEntity.getHotCutIndicator() == Boolean.TRUE)
				root.addNotNullValChild("HotCutIndicator", "Y", action);
			if (trunkGroupEntity.getCDDDIndicator() != null && trunkGroupEntity.getCDDDIndicator() == Boolean.TRUE)
				root.addNotNullValChild("CDDDIndicator", "Y", action);

			root.addNotNullValChild("PQInstanceId", trunkGroupEntity.getPqInstanceId(), action);

			// XOO
			root.addNotNullValChild("EnterpriseId", trunkGroupEntity.getEnterpriseId(), action);
			root.addNotNullValChild("LocationId", trunkGroupEntity.getLocationId(), action);
			root.addNotNullValChild("MaxActiveCalls", trunkGroupEntity.getMaxActiveCalls(), action);
			root.addNotNullValChild("MaxIncomingCalls", trunkGroupEntity.getMaxIncomingCalls(), action);
			root.addNotNullValChild("EnableBursting", "false", action);
			root.addNotNullValChild("BurstingMaxActiveCalls", "1", action);
			root.addNotNullValChild("BurstingMaxActiveCallsUnlimited", "true", action);
			root.addNotNullValChild("BurstingMaxIncomingCalls", trunkGroupEntity.getBurstingMaxIncomingCalls(), action);
			root.addNotNullValChild("BurstingMaxOutgoingCalls", trunkGroupEntity.getBurstingMaxOutgoingCalls(), action);
			root.addNotNullValChild("AllowedUnscreenedCalls", trunkGroupEntity.getAllowedUnscreenedCalls(), action);
			root.addNotNullValChild("RequireAuthentication", trunkGroupEntity.getRequireAuthentication(), action);
			root.addNotNullValChild("OtgDtgIdentity", trunkGroupEntity.getOtgDtgIdentity(), action);
			root.addNotNullValChild("SipAuthenticationUserName", trunkGroupEntity.getSipAuthenticationUserName(),
					action);
			root.addNotNullValChild("SipAuthenticationPassword", trunkGroupEntity.getSipAuthenticationPassword(),
					action);
			root.addNotNullValChild("ContinuousOptionsSendingIntervalSeconds", "30", action);
			root.addNotNullValChild("FailureOptionsSendingIntervalSeconds", "10", action);
			root.addNotNullValChild("FailureThresholdCounter", "1", action);
			root.addNotNullValChild("SuccessThresholdCounter", "1", action);
			root.addNotNullValChild("InviteFailureThresholdWindowSeconds", "30", action);
			root.addNotNullValChild("UseSystemCallingLineIdentityPolicy", "true", action);
			root.addNotNullValChild("UseSystemCLIDForScreenedCallsPolicy", "true", action);
			root.addNotNullValChild("UseSystemUserLookupPolicy", trunkGroupEntity.getUseSystemUserLookupPolicy(),
					action);
			root.addNotNullValChild("CallingLineIdPhoneNumber", trunkGroupEntity.getCallingLineIdPhoneNumber(), action);

			root.addNotNullValChild("Extension", trunkGroupEntity.getExtension(), action);
			root.addNotNullValChild("TimeZone", trunkGroupEntity.getTimeZone(), action);
			root.addNotNullValChild("TrunkCallCapacity", trunkGroupEntity.getTrunkCallCapacity(), action);
			root.addNotNullValChild("CommittedSessionCount", trunkGroupEntity.getCommittedSessionCount(), action);
			root.addNotNullValChild("InternationalLDRestriction", trunkGroupEntity.getInternationalLDRestriction(),
					action);
			root.addNotNullValChild("PilotTn", trunkGroupEntity.getPilotTn(), action);
			root.addNotNullValChild("DeviceMapId", trunkGroupEntity.getDeviceMapId(), action);
			root.addNotNullValChild("DeviceSeqId", trunkGroupEntity.getDeviceMapId(), action);
			root.addNotNullValChild("SignalingDirection", trunkGroupEntity.getSignalingDirection(), action);

			if (trunkGroupEntity.getPilotUser() != null) {
				pilotUser = new ParamInfo("PilotUser", null, action);
				pilotUser.addChildParam(new ParamInfo("UserId", trunkGroupEntity.getPilotUser().getUserId(), action));
				pilotUser.addChildParam(
						new ParamInfo("FirstName", trunkGroupEntity.getPilotUser().getFirstName(), action));
				pilotUser.addChildParam(
						new ParamInfo("LastName", trunkGroupEntity.getPilotUser().getLastName(), action));
				pilotUser.addChildParam(new ParamInfo("CallingLineIdFirstName",
						trunkGroupEntity.getPilotUser().getCallingLineIdFirstName(), action));
				pilotUser.addChildParam(new ParamInfo("CallingLineIdLastName",
						trunkGroupEntity.getPilotUser().getCallingLineIdLastName(), action));
				pilotUser.addChildParam(new ParamInfo("PhoneNumber",
						String.valueOf(trunkGroupEntity.getPilotUser().getPhoneNumber()), action));
				pilotUser.addChildParam(
						new ParamInfo("LinePort", trunkGroupEntity.getPilotUser().getLinePort(), action));
				pilotUser.addChildParam(
						new ParamInfo("DeviceLevel", trunkGroupEntity.getPilotUser().getDeviceLevel(), action));
				pilotUser.addChildParam(
						new ParamInfo("DeviceName", trunkGroupEntity.getPilotUser().getDeviceName(), action));
				root.addChildParam(pilotUser, ParamInfo.Tag.NON_ORD);

			}

			// XOO
			root.addNotNullValChild("BWTrunkGroupId", trunkGroupEntity.getBwTrunkGroupId(), action);
			// Start:EBL Change
			if (trunkGroupEntity.getVirtualTrunkId() != null)
				root.addNotNullValChild("VirtualTrunkGroupId", trunkGroupEntity.getVirtualTrunkId(), action);

			// End:EBL Change
			if (voipOrderRequest.getLocation().getLocationAddress() != null
					&& voipOrderRequest.getLocation().getLocationAddress().getCountryCode() != null)
				root.addNotNullValChild("Region", voipOrderRequest.getLocation().getLocationAddress().getCountryCode(),
						action);
			
			if (voipOrderRequest.getConvergedService() != null
					&& voipOrderRequest.getConvergedService().getFeature() != null) {

				List<Feature> hpbxPreBuiltTgFeat = stream(voipOrderRequest.getConvergedService().getFeature())
						.filter(feature -> feature.getCode().equalsIgnoreCase("FET_HPBX_TRU")
								|| feature.getCode().equalsIgnoreCase("FET_HPBX_TRU_LOC"))
						.collect(Collectors.toList());

				if (!CollectionUtils.isEmpty(hpbxPreBuiltTgFeat)) {

					root.addNotNullValChild("ProvisionCategory", "INV_ONLY", action);
				}
			}

			if (trunkGroupEntity.getAuthFeatureType() != null)
				root.addNotNullValChild("AuthFeatureType", trunkGroupEntity.getAuthFeatureType().toString(), action);
			
			root.addNotNullValChild("AsClli", voipOrderRequest.getOrderHeader().getAsClli(), action); //adding bs clli.
			
			paramInfoList.add(root);
		}
		LOG.info(
				"Exit - prepareTblOrderDetailsEntityParamDataForTrunk(voipOrderRequest, tblOrderObject, trunkGroupEntityList)");

		return paramInfoList;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.vz.esap.translation.order.transformer.TrunkTblOrderDetailsDataTransformer
	 * #prepareTblOrderDetailsHeaderParamData(com.vz.esap.translation.order.model.
	 * Order)
	 */
	@Override
	public ParamInfo prepareTblOrderDetailsHeaderParamData(Order order) throws ParseException, TranslatorException {

		LOG.info("Entered - prepareTblOrderDetailsHeaderParamData");
		ParamInfo root = null;
		String action = null;
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		Date date = null;
		Calendar calendar = GregorianCalendar.getInstance();
		Object dueDate = null;

		try {

			action = order.getOrderHeader().getOrderType();
			root = new ParamInfo("Header", null, action);

			root.addNotNullValChild("OrderNumber", order.getOrderHeader().getOrderNumber(), action);
			root.addNotNullValChild("EnvOrderId", order.getOrderHeader().getEnvOrderId(), action);
			root.addNotNullValChild("MasterOrderNumber", order.getOrderHeader().getMasterOrderNumber(), action);
			root.addNotNullValChild("OrderVersion", order.getOrderHeader().getOrderVersion(), action);
			root.addNotNullValChild("TransactionId", order.getOrderHeader().getTransactionId(), action);
			root.addNotNullValChild("Region", order.getTrunkGroupEntity().getRegion(), action);
			root.addNotNullValChild("MinorOrderType", order.getOrderHeader().getMinorOrderType(), action);
			root.addNotNullValChild("CentrexType", order.getOrderHeader().getCentrexType(), action);
			root.addNotNullValChild("ServiceType", order.getOrderHeader().getServiceType(), action);
			root.addNotNullValChild("OriginatingSystem", order.getOrderHeader().getOriginatingSystem(), action);
			root.addNotNullValChild("InterfaceSystem", order.getOrderHeader().getInterfaceSystem(), action);
			root.addNotNullValChild("OrderType",
					EsapEnum.OrderType.getValue(order.getOrderHeader().getOrderType().charAt(0)), action);
			root.addNotNullValChild("SuppType", order.getOrderHeader().getSuppType(), action);
			root.addNotNullValChild("OrderClassify", order.getOrderHeader().getFunctionCode(), action);

			if (order.getOrderHeader().getDueDate() != null) {
				date = format.parse(order.getOrderHeader().getDueDate().toString());
				calendar.setTime(date);
				dueDate = calendar.getTime();
				root.addNotNullValChild("DueDate", dueDate, action);
			}
			if (order.getOrderHeader().getCustomerId() != null)
				root.addNotNullValChild("CustomerId", order.getOrderHeader().getCustomerId(), action);
			else
				root.addNotNullValChild("CustomerId", order.getTrunkGroupEntity().getCustomerId(), action);
			root.addNotNullValChild("LocationId", order.getOrderHeader().getLocationId(), action);
			root.addNotNullValChild("OrderProTIN", order.getOrderHeader().getOrderProTIN(), action);
			root.addNotNullValChild("IOrderTIN", order.getOrderHeader().getiOrderTIN(), action);
			root.addNotNullValChild("TINVersion", order.getOrderHeader().getTinVersion(), action);
			root.addNotNullValChild("TransitionFlag", order.getOrderHeader().isTransitionFlag() ? "Y" : "N", action);
			root.addNotNullValChild("Priority", order.getOrderHeader().getPriority(), action);
			if (order.getOrderHeader().getAttribMap() != null) {
				root.addChildParam(OrderUtility.getAttribParamInfo(order.getOrderHeader().getAttribMap(), action));
			}
			if (order.getOrderHeader().getOrderCreatedBy() != null)
				root.addNotNullValChild("OrderCreatedBy", order.getOrderHeader().getOrderCreatedBy(), action);
			if (order.getOrderHeader().isHasBulkOrder()) {
				root.addNotNullValChild("BULK", "Y", action);
			}
			if (order.getOrderHeader().getHotCutIndicator() != null) {
				root.addNotNullValChild("HotCutIndicator", "Y", action);
			}
			if (order.getOrderHeader().getCDDDIndicator() != null) {
				root.addNotNullValChild("CDDDIndicator", "Y", action);
			}
			if (order.getOrderHeader().getSolutionType() != null) {
				root.addNotNullValChild("SolutionType", order.getOrderHeader().getSolutionType().toString(), action);
			}
			if (order.getTrunkGroupEntity().getAuthFeatureType() != null) {
				root.addNotNullValChild("AuthFeatureType", order.getTrunkGroupEntity().getAuthFeatureType().toString(), action);
			}
		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new TranslatorException(ErrorCode.TRANSFORMER_FAILURE,
					"Exception occured in prepareTblOrderDetailsHeaderParamData");
		}

		LOG.info("Exit prepareTblOrderDetailsHeaderParamData");

		return root;
	}

	@Override
	public ParamInfo prepareTblOrderDetailsEntityParamDataForTrunk(TrunkGroupEntity oldTrunkEntity,
			TrunkGroupEntity newTrunkEntity, boolean supp, String action) throws TranslatorException {
		LOG.info(
				"Entered - prepareTblOrderDetailsEntityParamDataForTrunk(oldTrunkEntity, newTrunkEntity, supp, action)");
		ParamInfo trunkParam = new ParamInfo("Group", null, null);

		ParamInfo pilotUser = null;
		boolean forwardFeature = false;
		ArrayList<String> disableFeatureList = null;

		try {

			if (oldTrunkEntity.getGroupId() != null) {
				trunkParam.addChildParam(
						new ParamInfo("GroupId", oldTrunkEntity.getGroupId().toString(), null, ParamInfo.Tag.ID));

				if (oldTrunkEntity.getGroupType() != null) {
					if (oldTrunkEntity.getGroupType().equals(Entity.GroupType.PBX))
						trunkParam.addChildParam(new ParamInfo("PBXGroupId", oldTrunkEntity.getGroupId().toString(),
								null, ParamInfo.Tag.ID));
					else if (oldTrunkEntity.getGroupType().equals(Entity.GroupType.KEY))
						trunkParam.addChildParam(new ParamInfo("KeyGroupId", oldTrunkEntity.getGroupId().toString(),
								null, ParamInfo.Tag.ID));
				}
			}

			if (oldTrunkEntity.getGroupType() != null) {
				trunkParam.addChildParam(new ParamInfo("GroupType", oldTrunkEntity.getGroupType().toString(), null));
				trunkParam.addChildParam(
						new ParamInfo("SimpleFeaturePackage", oldTrunkEntity.getSimpleFeaturePackage(), null));

			}

			if (oldTrunkEntity.getCustomerId() != null) {
				trunkParam.addChangeParam("CustomerId", oldTrunkEntity.getCustomerId(), oldTrunkEntity.getCustomerId(),
						supp, ParamInfo.Tag.ID);
				
			} else {
				trunkParam.addChangeParam("CustomerId", oldTrunkEntity.getEnterpriseId(),
						newTrunkEntity.getEnterpriseId(), supp, ParamInfo.Tag.ID);
				
			}
			
			trunkParam.addChangeParam("LocationId", oldTrunkEntity.getLocationId(), newTrunkEntity.getLocationId(),
					supp, ParamInfo.Tag.ID);
			trunkParam.addChangeParam("DepartmentId", oldTrunkEntity.getDepartmentId(),
					newTrunkEntity.getDepartmentId(), supp);
			trunkParam.addChangeParam("Name", oldTrunkEntity.getName(), newTrunkEntity.getName(), supp,
					ParamInfo.Tag.NAME);

			trunkParam.addChangeParam("MaxConcurrentCallLimit", oldTrunkEntity.getMaxConcurrentCallLimit(),
					newTrunkEntity.getMaxConcurrentCallLimit(), supp);
			// Need clarification- Niladri
			if (oldTrunkEntity.hasNonPkgFeature("Trunk Group Unreachable")) {
				forwardFeature = true;
				if ("O".equals(action))
					trunkParam.addChangeParam("TRUNK_REDIRECT", "DEL", newTrunkEntity.getCustomerId(), supp,
							ParamInfo.Tag.WF);
				else if ("I".equals(action))
					trunkParam.addChangeParam("TRUNK_REDIRECT", "ADD", newTrunkEntity.getCustomerId(), supp,
							ParamInfo.Tag.WF);
				else
					trunkParam.addChangeParam("TRUNK_REDIRECT", null, newTrunkEntity.getCustomerId(), supp,
							ParamInfo.Tag.WF);
			}

			trunkParam.addChangeParam("InvitationTimer", oldTrunkEntity.getInvitationTimer(),
					newTrunkEntity.getInvitationTimer(), supp);
			if (forwardFeature) {
				trunkParam.addChangeParam("ForwardToGroupId", oldTrunkEntity.getForwardToGroupId(),
						newTrunkEntity.getForwardToGroupId(), supp);
				trunkParam.addChangeParam("ForwardToGroupName", oldTrunkEntity.getForwardToGroupName(),
						newTrunkEntity.getForwardToGroupName(), supp);
			}

			disableFeatureList = oldTrunkEntity.getDisableFeatureList();
			if (disableFeatureList != null) {
				ParamInfo dfParam = new ParamInfo("DisableFeatureList", null, action);

				for (String feature : disableFeatureList) {
					LOG.debug("GroupUtil Adding DisableFeature: {}", feature);
					dfParam.addChildParam(new ParamInfo("Feature", feature, null));
				}
				trunkParam.addChildParam(dfParam);
			}

			if (oldTrunkEntity.getHotCutIndicator() != null && oldTrunkEntity.getHotCutIndicator() == Boolean.TRUE)
				trunkParam.addChangeParam("HotCutIndicator", "Y", newTrunkEntity.getHotCutIndicator(), supp);
			if (oldTrunkEntity.getCDDDIndicator() != null && oldTrunkEntity.getCDDDIndicator() == Boolean.TRUE)
				trunkParam.addChangeParam("CDDDIndicator", "Y", newTrunkEntity.getCDDDIndicator(), supp);

			trunkParam.addChangeParam("PQInstanceId", oldTrunkEntity.getPqInstanceId(),
					newTrunkEntity.getPqInstanceId(), supp);

			// XOO
			trunkParam.addChangeParam("EnterpriseId", oldTrunkEntity.getEnterpriseId(),
					newTrunkEntity.getEnterpriseId(), supp);
			trunkParam.addChangeParam("LocationId", oldTrunkEntity.getLocationId(), newTrunkEntity.getLocationId(),
					supp);
			trunkParam.addChangeParam("MaxActiveCalls", oldTrunkEntity.getMaxActiveCalls(),
					newTrunkEntity.getMaxActiveCalls(), supp);
			trunkParam.addChangeParam("MaxIncomingCalls", oldTrunkEntity.getMaxIncomingCalls(),
					newTrunkEntity.getMaxIncomingCalls(), supp);
			
			LOG.info("Trunk Id = {}", newTrunkEntity.getGroupId());
			LOG.info("oldTrunkEntity.getEnableBursting()--> {}", newTrunkEntity.getEnableBursting());
			LOG.info("oldTrunkEntity.getEnableBursting()--> {}", oldTrunkEntity.getEnableBursting());
			trunkParam.addChangeParam("EnableBursting", oldTrunkEntity.getEnableBursting(),
					newTrunkEntity.getEnableBursting(), supp);

			LOG.info("oldTrunkEntity.getBurstingMaxActiveCalls()--> {}", newTrunkEntity.getBurstingMaxActiveCalls());
			LOG.info("oldTrunkEntity.getBurstingMaxActiveCalls()--> {}", oldTrunkEntity.getBurstingMaxActiveCalls());			
			trunkParam.addChangeParam("BurstingMaxActiveCalls", oldTrunkEntity.getBurstingMaxActiveCalls(),
					newTrunkEntity.getBurstingMaxActiveCalls(), supp);
			

			LOG.info("oldTrunkEntity.getBurstingMaxActiveCallsUnlimited()--> {}", newTrunkEntity.getBurstingMaxActiveCallsUnlimited());
			LOG.info("oldTrunkEntity.getBurstingMaxActiveCallsUnlimited()--> {}", oldTrunkEntity.getBurstingMaxActiveCallsUnlimited());
			trunkParam.addChangeParam("BurstingMaxActiveCallsUnlimited",
					oldTrunkEntity.getBurstingMaxActiveCallsUnlimited(),
					newTrunkEntity.getBurstingMaxActiveCallsUnlimited(), supp);
			
			
			trunkParam.addChangeParam("BurstingMaxIncomingCalls", oldTrunkEntity.getBurstingMaxIncomingCalls(),
					newTrunkEntity.getBurstingMaxIncomingCalls(), supp);
			trunkParam.addChangeParam("BurstingMaxOutgoingCalls", oldTrunkEntity.getBurstingMaxOutgoingCalls(),
					newTrunkEntity.getBurstingMaxOutgoingCalls(), supp);
			trunkParam.addChangeParam("AllowedUnscreenedCalls", oldTrunkEntity.getAllowedUnscreenedCalls(),
					newTrunkEntity.getAllowedUnscreenedCalls(), supp);
			trunkParam.addChangeParam("RequireAuthentication", oldTrunkEntity.getRequireAuthentication(),
					newTrunkEntity.getRequireAuthentication(), supp);
			trunkParam.addChangeParam("OtgDtgIdentity", oldTrunkEntity.getOtgDtgIdentity(),
					newTrunkEntity.getOtgDtgIdentity(), supp);
			trunkParam.addChangeParam("SipAuthenticationUserName", oldTrunkEntity.getSipAuthenticationUserName(),
					newTrunkEntity.getSipAuthenticationUserName(), supp);
			trunkParam.addChangeParam("SipAuthenticationPassword", oldTrunkEntity.getSipAuthenticationPassword(),
					newTrunkEntity.getSipAuthenticationPassword(), supp);
			/*trunkParam.addChangeParam("ContinuousOptionsSendingIntervalSeconds", "30", null, supp);
			trunkParam.addChangeParam("FailureOptionsSendingIntervalSeconds", "10", null, supp);
			trunkParam.addChangeParam("FailureThresholdCounter", "1", null, supp);
			trunkParam.addChangeParam("SuccessThresholdCounter", "1", null, supp);
			trunkParam.addChangeParam("InviteFailureThresholdWindowSeconds", "30", null, supp);
			trunkParam.addChangeParam("UseSystemCallingLineIdentityPolicy", "true", null, supp);
			trunkParam.addChangeParam("UseSystemCLIDForScreenedCallsPolicy", "true", null, supp);*/
			trunkParam.addChangeParam("UseSystemUserLookupPolicy", oldTrunkEntity.getUseSystemUserLookupPolicy(),
					newTrunkEntity.getUseSystemUserLookupPolicy(), supp);
			trunkParam.addChangeParam("CallingLineIdPhoneNumber", oldTrunkEntity.getCallingLineIdPhoneNumber(),
					newTrunkEntity.getCallingLineIdPhoneNumber(), supp);
			trunkParam.addChangeParam("Extension", oldTrunkEntity.getExtension(), newTrunkEntity.getExtension(), supp);
			trunkParam.addChangeParam("TimeZone", oldTrunkEntity.getTimeZone(), newTrunkEntity.getTimeZone(), supp);
			trunkParam.addChangeParam("TrunkCallCapacity", oldTrunkEntity.getTrunkCallCapacity(),
					newTrunkEntity.getTrunkCallCapacity(), supp);			
			trunkParam.addChangeParam("CommittedSessionCount", oldTrunkEntity.getCommittedSessionCount(),
					newTrunkEntity.getCommittedSessionCount(), supp);						
			trunkParam.addChangeParam("InternationalLDRestriction", oldTrunkEntity.getInternationalLDRestriction(),
					newTrunkEntity.getInternationalLDRestriction(), supp);

			trunkParam.addChangeParam("PilotTn", oldTrunkEntity.getPilotTn(), newTrunkEntity.getPilotTn(), supp);
			trunkParam.addChangeParam("DeviceMapId", oldTrunkEntity.getDeviceMapId(), newTrunkEntity.getDeviceMapId(),
					supp);
			trunkParam.addChangeParam("DeviceSeqId", oldTrunkEntity.getDeviceMapId(), newTrunkEntity.getDeviceMapId(),
					supp);
			trunkParam.addChangeParam("SignalingDirection", oldTrunkEntity.getSignalingDirection(),
					newTrunkEntity.getSignalingDirection(), supp);

			if (oldTrunkEntity.getPilotUser() != null) {
				pilotUser = new ParamInfo("PilotUser", null, null);
				pilotUser.addChildParam(new ParamInfo("UserId", oldTrunkEntity.getPilotUser().getUserId(), null));
				pilotUser.addChildParam(new ParamInfo("FirstName", oldTrunkEntity.getPilotUser().getFirstName(), null));
				pilotUser.addChildParam(new ParamInfo("LastName", oldTrunkEntity.getPilotUser().getLastName(), null));
				pilotUser.addChildParam(new ParamInfo("CallingLineIdFirstName",
						oldTrunkEntity.getPilotUser().getCallingLineIdFirstName(), null));
				pilotUser.addChildParam(new ParamInfo("CallingLineIdLastName",
						oldTrunkEntity.getPilotUser().getCallingLineIdLastName(), null));
				pilotUser.addChildParam(new ParamInfo("PhoneNumber",
						String.valueOf(oldTrunkEntity.getPilotUser().getPhoneNumber()), null));
				pilotUser.addChildParam(new ParamInfo("LinePort", oldTrunkEntity.getPilotUser().getLinePort(), null));
				pilotUser.addChildParam(
						new ParamInfo("DeviceLevel", oldTrunkEntity.getPilotUser().getDeviceLevel(), null));
				pilotUser.addChildParam(
						new ParamInfo("DeviceName", oldTrunkEntity.getPilotUser().getDeviceName(), null));
				trunkParam.addChildParam(pilotUser, ParamInfo.Tag.NON_ORD);
			}

			// XOO
			trunkParam.addChangeParam("BWTrunkGroupId", oldTrunkEntity.getBwTrunkGroupId(),
					newTrunkEntity.getBwTrunkGroupId(), supp);
			// Start:EBL Change
			if (oldTrunkEntity.getVirtualTrunkId() != null)
				trunkParam.addChangeParam("VirtualTrunkGroupId", oldTrunkEntity.getVirtualTrunkId(),
						newTrunkEntity.getVirtualTrunkId(), supp);
			// End:EBL Change
			trunkParam.addChangeParam("Region", oldTrunkEntity.getRegion(), newTrunkEntity.getRegion(), supp);
			
			if( (oldTrunkEntity.getMaxActiveCalls() != null && !oldTrunkEntity.getMaxActiveCalls().equalsIgnoreCase(newTrunkEntity.getMaxActiveCalls()))
					|| (oldTrunkEntity.getCommittedSessionCount() != null && !oldTrunkEntity.getCommittedSessionCount().equalsIgnoreCase(newTrunkEntity.getCommittedSessionCount()))
					|| oldTrunkEntity.getTrunkCallCapacity() != newTrunkEntity.getTrunkCallCapacity() ) {
				trunkParam.addNotNullValChild("CALL_CAP_BS_CHANGE", "Y", "n");
			}else {
				trunkParam.addNotNullValChild("CALL_CAP_BS_CHANGE", "N", "n");
			}
			
			if( (oldTrunkEntity.getCallingLineIdPhoneNumber() != null && !oldTrunkEntity.getCallingLineIdPhoneNumber().equalsIgnoreCase(newTrunkEntity.getCallingLineIdPhoneNumber()))
					||  (oldTrunkEntity.getPilotTn() != null && !oldTrunkEntity.getPilotTn().equalsIgnoreCase(newTrunkEntity.getPilotTn()))
					|| 	(oldTrunkEntity.getExtension() != null && !oldTrunkEntity.getExtension().equalsIgnoreCase(newTrunkEntity.getExtension()))
					||	(oldTrunkEntity.getSignalingDirection() != null && !oldTrunkEntity.getSignalingDirection().equalsIgnoreCase(newTrunkEntity.getSignalingDirection()))
					||  (oldTrunkEntity.getBwTrunkGroupId() != null && !oldTrunkEntity.getBwTrunkGroupId().equalsIgnoreCase(newTrunkEntity.getBwTrunkGroupId()))
					||	(oldTrunkEntity.getOtgDtgIdentity() != null && !oldTrunkEntity.getOtgDtgIdentity().equalsIgnoreCase(newTrunkEntity.getOtgDtgIdentity()))
					||	(oldTrunkEntity.getGroupType() != null && !oldTrunkEntity.getGroupType().equals(newTrunkEntity.getGroupType())) ) {
				trunkParam.addNotNullValChild("TG_LOC_BS_CHANGE", "Y", "n");				
			}else {
				trunkParam.addNotNullValChild("TG_LOC_BS_CHANGE", "N", "n");				
			}

			LOG.info("Exit TrunkGroupTbloldTrunkEntityDetailsDataTransformerImpl");

		} catch (Exception e) {
			LOG.error("Exception Occured while Parsing Trunk Order {} ", e);
			throw new TranslatorException(TranslatorException.ErrorCode.ORDER_NOT_SAVABLE,
					"Unexpected Error Occured while Parsing Trunk Order\"");
		}
		LOG.info("Exit - prepareTblOrderDetailsEntityParamDataForTrunk(oldTrunkEntity, newTrunkEntity, supp, action)");
		return trunkParam;
	}

	@Override
	public ParamInfo prepareTblOrderDetailsHeaderParamData(Order order, TrunkGroupEntity oldTrunkEntity, boolean supp)
			throws TranslatorException {
		LOG.info("Entered - prepareTblOrderDetailsHeaderParamData");
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		Date date = null;
		Calendar calendar = GregorianCalendar.getInstance();
		Object dueDate = null;

		ParamInfo root = null;
		String action = null;

		try {

			int oldVersion = Integer.parseInt(order.getOrderHeader().getOrderVersion()) + 1;
			action = order.getOrderHeader().getOrderType();

			root = new ParamInfo("Header", null, action);

			root.addChangeParam("OrderNumber", order.getOrderHeader().getOrderNumber(),
					order.getOrderHeader().getOrderNumber(), supp);
			root.addChangeParam("EnvOrderId", order.getOrderHeader().getEnvOrderId(), order.getOrderHeader().getEnvOrderId(),
					supp);
			root.addChangeParam("MasterOrderNumber", order.getOrderHeader().getMasterOrderNumber(),
					order.getOrderHeader().getMasterOrderNumber(), supp);
			root.addChangeParam("OrderVersion", order.getOrderHeader().getOrderVersion(), order.getOrderHeader().getOrderVersion(), supp);
			root.addChangeParam("TransactionId", order.getOrderHeader().getTransactionId(),
					order.getOrderHeader().getTransactionId(), supp);
			root.addChangeParam(REGION, order.getOrderHeader().getRegion(), order.getOrderHeader().getRegion(), supp);
			root.addChangeParam("MinorOrderType", order.getOrderHeader().getMinorOrderType(),
					order.getOrderHeader().getMinorOrderType(), supp);
			root.addChangeParam("CentrexType", order.getOrderHeader().getCentrexType(),
					order.getOrderHeader().getCentrexType(), supp);
			root.addChangeParam("ServiceType", order.getOrderHeader().getServiceType(),
					order.getOrderHeader().getServiceType(), supp);
			root.addChangeParam("OriginatingSystem", order.getOrderHeader().getOriginatingSystem(),
					order.getOrderHeader().getOriginatingSystem(), supp);
			root.addChangeParam("InterfaceSystem", order.getOrderHeader().getInterfaceSystem(),
					order.getOrderHeader().getInterfaceSystem(), supp);
			root.addChangeParam("OrderType",
					EsapEnum.OrderType.getValue(order.getOrderHeader().getOrderType().charAt(0)),
					EsapEnum.OrderType.getValue(order.getOrderHeader().getOrderType().charAt(0)), supp);
			root.addChangeParam("SuppType", order.getOrderHeader().getSuppType(), order.getOrderHeader().getSuppType(), supp);
			root.addChangeParam("OrderClassify", order.getOrderHeader().getFunctionCode(),
					order.getOrderHeader().getFunctionCode(), supp);

			if (order.getOrderHeader().getDueDate() != null) {
				date = format.parse(order.getOrderHeader().getDueDate().toString());
				calendar.setTime(date);
				dueDate = calendar.getTime();
				root.addNotNullValChild("DueDate", dueDate, action);
			}

			if (order.getLocation() != null && order.getLocation().getCustomerId() != null) {
				LOG.info("Customer Id = {}", order.getLocation().getCustomerId());
				root.addChangeParam(CUSTOMER_ID, order.getLocation().getCustomerId(),
						order.getLocation().getCustomerId(), supp);
				
			} else if (order.getOrderHeader().getCustomerId() != null) {
				LOG.info("Customer Id = {}", order.getOrderHeader().getCustomerId());
				root.addChangeParam(CUSTOMER_ID, order.getOrderHeader().getCustomerId(),
						order.getOrderHeader().getCustomerId(), supp);
				
			}  else if (oldTrunkEntity.getEnterpriseId() != null) {
				LOG.info("Customer Id = {}", oldTrunkEntity.getEnterpriseId());
				root.addChangeParam(CUSTOMER_ID, oldTrunkEntity.getEnterpriseId(),
						oldTrunkEntity.getEnterpriseId(), supp);
			}

			root.addChangeParam(LOCATION_ID, order.getOrderHeader().getLocationId(),
					order.getOrderHeader().getLocationId(), supp);

			// root.addNotNullValChild(BS_APP_SERVER, order.getLocation().getBsAppServer(),
			// action); Fix This
			root.addChangeParam("OrderProTIN", order.getOrderHeader().getOrderProTIN(),
					order.getOrderHeader().getOrderProTIN(), supp);
			root.addChangeParam("IOrderTIN", order.getOrderHeader().getiOrderTIN(),
					order.getOrderHeader().getiOrderTIN(), supp);
			root.addChangeParam("TINVersion", order.getOrderHeader().getTinVersion(),
					order.getOrderHeader().getTinVersion(), supp);
			root.addChangeParam("TransitionFlag", order.getOrderHeader().isTransitionFlag() ? "Y" : "N",
					order.getOrderHeader().isTransitionFlag() ? "Y" : "N", supp);
			root.addChangeParam("Priority", order.getOrderHeader().getPriority(), order.getOrderHeader().getPriority(),
					supp);
			if (order.getOrderHeader().getAttribMap() != null) {
				root.addChildParam(OrderUtility.getAttribParamInfo(order.getOrderHeader().getAttribMap(), action));
			}
			if (order.getOrderHeader().getOrderCreatedBy() != null)
				root.addChangeParam("OrderCreatedBy", order.getOrderHeader().getOrderCreatedBy(),
						order.getOrderHeader().getOrderCreatedBy(), supp);
			if (order.getOrderHeader().isHasBulkOrder()) {
				root.addChangeParam("BULK", "Y", "Y", supp);
			}
			if (order.getOrderHeader().getHotCutIndicator() != null) {
				root.addChangeParam(HOT_CUT_IND, "Y", "Y", supp);
			}
			if (order.getOrderHeader().getCDDDIndicator() != null) {
				root.addChangeParam(CDD_IND, "Y", "Y", supp);
			}
			if (order.getOrderHeader().getSolutionType() != null) {
				root.addChangeParam("SolutionType", order.getOrderHeader().getSolutionType().toString(),
						order.getOrderHeader().getSolutionType().toString(), supp);
			}
			if (order.getTrunkGroupEntity().getAuthFeatureType() != null) {
				root.addChangeParam("AuthFeatureType", order.getTrunkGroupEntity().getAuthFeatureType().toString(),
						order.getTrunkGroupEntity().getAuthFeatureType().toString(), supp);	
			}
		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new TranslatorException(ErrorCode.TRANSFORMER_FAILURE,
					"Exception occured in prepareTblOrderDetailsHeaderParamData");
		}

		LOG.info("Exit prepareTblOrderDetailsHeaderParamData");

		return root;
	}

	/**
	 *
	 * @param enrichedTrunkGrp,change
	 * @return ArrayList<ParamInfo> @throws
	 */
	@Override
	public ArrayList<ParamInfo> prepareTblOrderDetailsEntityParamDataForTrunk(
			ArrayList<TrunkGroupEntity> enrichedTrunkGrp, boolean change, Object trunkGroup) {

		LOG.info("Entered - prepareTblOrderDetailsEntityParamDataForTrunk(enrichedTrunkGrp, change, trunkGroup)");

		ArrayList<ParamInfo> paramInfoList = new ArrayList<>();
		// String action = voipOrderRequest.getOrderHeader().getOrderType();
		ParamInfo trunkGroupParam = null;
		ParamInfo dfParam = null;
		boolean forwardFeature = false;
		ParamInfo pilotUser = null;
		TrunkGroupEntity changedTrunkGroup = null;
		try {
			for (TrunkGroupEntity trunkGroupEntity : enrichedTrunkGrp) {
				changedTrunkGroup = trunkGroupEntity.getTrunkGroupEntity() != null ? trunkGroupEntity.getTrunkGroupEntity()
						: new TrunkGroupEntity();

				trunkGroupParam = new ParamInfo("Group", null, null);
				if (trunkGroupEntity.getGroupId() != null) {

					if(null != trunkGroupEntity.getGroupId()) {
						trunkGroupParam.addChangeParam("GroupId", trunkGroupEntity.getGroupId().toString(),
								trunkGroupEntity.getGroupId().toString(), true);
					}

					if (trunkGroupEntity.getGroupType() != null) {
						if (trunkGroupEntity.getGroupType().equals(Entity.GroupType.PBX))
							trunkGroupParam.addChildParam(new ParamInfo("PBXGroupId",
									trunkGroupEntity.getGroupId().toString(), booleanToStr(change), ParamInfo.Tag.ID));
						else if (trunkGroupEntity.getGroupType().equals(Entity.GroupType.KEY))
							trunkGroupParam.addChildParam(new ParamInfo("KeyGroupId",
									trunkGroupEntity.getGroupId().toString(), booleanToStr(change), ParamInfo.Tag.ID));
					}
				}

				if (trunkGroupEntity.getGroupType() != null) {				
					trunkGroupParam.addChangeParam("GroupType", trunkGroupEntity.getGroupType().toString(),
							trunkGroupEntity.getGroupType().toString(), true);
					trunkGroupParam.addChangeParam("SimpleFeaturePackage", trunkGroupEntity.getSimpleFeaturePackage(),
							trunkGroupEntity.getSimpleFeaturePackage(), true);
				}

				trunkGroupParam.addChangeParam("CustomerId", trunkGroupEntity.getCustomerId(),
						changedTrunkGroup.getCustomerId(), change, ParamInfo.Tag.ID);
				trunkGroupParam.addChangeParam("LocationId", trunkGroupEntity.getLocationId(),
						changedTrunkGroup.getLocationId(), change, ParamInfo.Tag.ID);
				trunkGroupParam.addChangeParam("DepartmentId", trunkGroupEntity.getDepartmentId(),
						changedTrunkGroup.getDepartmentId(), change);
				trunkGroupParam.addChangeParam("Name", trunkGroupEntity.getName(), changedTrunkGroup.getName(), change,
						ParamInfo.Tag.NAME);

				trunkGroupParam.addChangeParam("MaxConcurrentCallLimit", trunkGroupEntity.getMaxConcurrentCallLimit(),
						changedTrunkGroup.getMaxConcurrentCallLimit(), change);
				if (trunkGroupEntity.getCreateExtension() != null)
					trunkGroupParam.addChangeParam("CreateExtension", trunkGroupEntity.getCreateExtension(),
							changedTrunkGroup.getCreateExtension(), change);
				trunkGroupParam.addChangeParam("CLIDFirstName", trunkGroupEntity.getCLIDFirstName(),
						changedTrunkGroup.getCLIDFirstName(), change);
				trunkGroupParam.addChangeParam("CLIDLastName", trunkGroupEntity.getCLIDLastName(),
						changedTrunkGroup.getCLIDLastName(), change);
				trunkGroupParam.addChangeParam("TnCLIDFirstName", trunkGroupEntity.getTnCLIDFirstName(),
						changedTrunkGroup.getTnCLIDFirstName(), change);
				trunkGroupParam.addChangeParam("TnCLIDLastName", trunkGroupEntity.getTnCLIDLastName(),
						changedTrunkGroup.getTnCLIDLastName(), change);
				trunkGroupParam.addChangeParam("TerminationOption", trunkGroupEntity.getTerminationOption(),
						changedTrunkGroup.getTerminationOption(), change);
				trunkGroupParam.addChangeParam("ForwardToNumber", trunkGroupEntity.getForwardToNumber(),
						changedTrunkGroup.getForwardToNumber(), change);
				trunkGroupParam.addChangeParam("VMBoxNumber", trunkGroupEntity.getVMNumber(),
						changedTrunkGroup.getVMNumber(), change);
				LOG.info("VmPin - [{}]", trunkGroupEntity.getVmPin());
				trunkGroupParam.addChangeParam("VMPin", trunkGroupEntity.getVmPin(), changedTrunkGroup.getVmPin(), change);
				trunkGroupParam.addChangeParam("Extension", trunkGroupEntity.getExtension(),
						changedTrunkGroup.getExtension(), change);
				trunkGroupParam.addChangeParam("PrivateNumber", trunkGroupEntity.getPrivateNumber(),
						changedTrunkGroup.getPrivateNumber(), change);
				trunkGroupParam.addChangeParam("PilotTN", trunkGroupEntity.getPilotTN(), changedTrunkGroup.getPilotTN(),
						change);
				trunkGroupParam.addChangeParam("LinePortLength", trunkGroupEntity.getLinePortLength(),
						changedTrunkGroup.getLinePortLength(), change);
				if (!"0".equals(trunkGroupEntity.getVMType()))
					trunkGroupParam.addChangeParam("VMType", trunkGroupEntity.getVMType(), changedTrunkGroup.getVMType(),
							change);
				trunkGroupParam.addChangeParam("LinePort", trunkGroupEntity.getLinePort(), changedTrunkGroup.getLinePort(),
						change, ParamInfo.Tag.NON_ORD);
				trunkGroupParam.addChangeParam("LastActiveTN", trunkGroupEntity.getLastActiveTN(),
						changedTrunkGroup.getLastActiveTN(), change, ParamInfo.Tag.NON_ORD);
				trunkGroupParam.addChangeParam("FirstActiveTN", trunkGroupEntity.getFirstActiveTN(),
						changedTrunkGroup.getLastActiveTN(), change, ParamInfo.Tag.NON_ORD);
				trunkGroupParam.addChangeParam("Autoflag", trunkGroupEntity.getAutoflagString(),
						changedTrunkGroup.getAutoflagString(), change, ParamInfo.Tag.NON_ORD);
				trunkGroupParam.addChangeParam("IEANLength", trunkGroupEntity.getIeanLength(),
						changedTrunkGroup.getIeanLength(), change, ParamInfo.Tag.NON_ORD);

				if (trunkGroupEntity.hasNonPkgFeature("Trunk Group Unreachable")) {
					forwardFeature = true;
					if ("O".equals(change))
						trunkGroupParam.addChangeParam("TRUNK_REDIRECT", "DEL", "DEL", change, ParamInfo.Tag.WF);
					else if ("I".equals(change))
						trunkGroupParam.addChangeParam("TRUNK_REDIRECT", "ADD", "ADD", change, ParamInfo.Tag.WF);
					else
						trunkGroupParam.addChangeParam("TRUNK_REDIRECT", null, null, change, ParamInfo.Tag.WF);
				}

				trunkGroupParam.addChangeParam("InvitationTimer", trunkGroupEntity.getInvitationTimer(),
						changedTrunkGroup.getInvitationTimer(), change);
				if (forwardFeature) {
					trunkGroupParam.addChangeParam("ForwardToGroupId", trunkGroupEntity.getForwardToGroupId(),
							changedTrunkGroup.getForwardToGroupId(), change);
					trunkGroupParam.addChangeParam("ForwardToGroupName", trunkGroupEntity.getForwardToGroupName(),
							changedTrunkGroup.getForwardToGroupName(), change);
				}
				ArrayList<String> disableFeatureList = trunkGroupEntity.getDisableFeatureList();
				if (disableFeatureList != null) {
					dfParam = new ParamInfo("DisableFeatureList", (String) null, booleanToStr(change));

					for (String feature : disableFeatureList) {
						LOG.info("GroupUtil Adding DisableFeature:{}", feature);
						dfParam.addChildParam(new ParamInfo("Feature", feature, booleanToStr(change)));
					}
					trunkGroupParam.addChildParam(dfParam);
				}

				if (trunkGroupEntity.getHotCutIndicator() != null && trunkGroupEntity.getHotCutIndicator() == Boolean.TRUE)
					trunkGroupParam.addChangeParam("HotCutIndicator", "Y", "Y", change);
				if (trunkGroupEntity.getCDDDIndicator() != null && trunkGroupEntity.getCDDDIndicator() == Boolean.TRUE)
					trunkGroupParam.addChangeParam("CDDDIndicator", "Y", "Y", change);

				trunkGroupParam.addChangeParam("PQInstanceId", trunkGroupEntity.getPqInstanceId(),
						changedTrunkGroup.getPqInstanceId(), change);

				// XOO
				trunkGroupParam.addChangeParam("EnterpriseId", trunkGroupEntity.getEnterpriseId(),
						trunkGroupEntity.getEnterpriseId(), change);
				trunkGroupParam.addChangeParam("LocationId", changedTrunkGroup.getLocationId(),
						changedTrunkGroup.getLocationId(), change);
				trunkGroupParam.addChangeParam("MaxActiveCalls", changedTrunkGroup.getMaxActiveCalls(),
						changedTrunkGroup.getMaxActiveCalls(), change);
				
				trunkGroupParam.addChangeParam("MaxIncomingCalls", trunkGroupEntity.getMaxIncomingCalls(),
						changedTrunkGroup.getMaxIncomingCalls(), change);
				trunkGroupParam.addChangeParam("EnableBursting", "false", "false", change);
				trunkGroupParam.addChangeParam("BurstingMaxActiveCalls", "1", "1", change);
				trunkGroupParam.addChangeParam("BurstingMaxActiveCallsUnlimited", "true", "true", change);
				trunkGroupParam.addChangeParam("BurstingMaxIncomingCalls", trunkGroupEntity.getBurstingMaxIncomingCalls(),
						changedTrunkGroup.getBurstingMaxIncomingCalls(), change);
				trunkGroupParam.addChangeParam("BurstingMaxOutgoingCalls", trunkGroupEntity.getBurstingMaxOutgoingCalls(),
						changedTrunkGroup.getBurstingMaxOutgoingCalls(), change);
				trunkGroupParam.addChangeParam("AllowedUnscreenedCalls", trunkGroupEntity.getAllowedUnscreenedCalls(),
						changedTrunkGroup.getAllowedUnscreenedCalls(), change);
				trunkGroupParam.addChangeParam("RequireAuthentication", trunkGroupEntity.getRequireAuthentication(),
						changedTrunkGroup.getRequireAuthentication(), change);
				trunkGroupParam.addChangeParam("OtgDtgIdentity", trunkGroupEntity.getOtgDtgIdentity(),
						changedTrunkGroup.getOtgDtgIdentity(), change);
				trunkGroupParam.addChangeParam("SipAuthenticationUserName", trunkGroupEntity.getSipAuthenticationUserName(),
						changedTrunkGroup.getSipAuthenticationUserName(), change);
				trunkGroupParam.addChangeParam("SipAuthenticationPassword", trunkGroupEntity.getSipAuthenticationPassword(),
						changedTrunkGroup.getSipAuthenticationPassword(), change);
				trunkGroupParam.addChangeParam("ContinuousOptionsSendingIntervalSeconds", "30", "30", change);
				trunkGroupParam.addChangeParam("FailureOptionsSendingIntervalSeconds", "10", "10", change);
				trunkGroupParam.addChangeParam("FailureThresholdCounter", "1", "1", change);
				trunkGroupParam.addChangeParam("SuccessThresholdCounter", "1", "1", change);
				trunkGroupParam.addChangeParam("InviteFailureThresholdWindowSeconds", "30", "30", change);
				trunkGroupParam.addChangeParam("UseSystemCallingLineIdentityPolicy", "true", "true", change);
				trunkGroupParam.addChangeParam("UseSystemCLIDForScreenedCallsPolicy", "true", "true", change);
				trunkGroupParam.addChangeParam("UseSystemUserLookupPolicy", trunkGroupEntity.getUseSystemUserLookupPolicy(),
						changedTrunkGroup.getUseSystemUserLookupPolicy(), change);
				trunkGroupParam.addChangeParam("CallingLineIdPhoneNumber", trunkGroupEntity.getCallingLineIdPhoneNumber(),
						changedTrunkGroup.getCallingLineIdPhoneNumber(), change);

				trunkGroupParam.addChangeParam("Extension", trunkGroupEntity.getExtension(),
						changedTrunkGroup.getExtension(), change);
				trunkGroupParam.addChangeParam("TimeZone", trunkGroupEntity.getTimeZone(), changedTrunkGroup.getTimeZone(),
						change);
				trunkGroupParam.addChangeParam("TrunkCallCapacity", trunkGroupEntity.getTrunkCallCapacity(),
						changedTrunkGroup.getTrunkCallCapacity(), change);
				trunkGroupParam.addChangeParam("CommittedSessionCount", trunkGroupEntity.getCommittedSessionCount(),
						changedTrunkGroup.getCommittedSessionCount(), change);
				trunkGroupParam.addChangeParam("InternationalLDRestriction",
						changedTrunkGroup.getInternationalLDRestriction(), changedTrunkGroup.getInternationalLDRestriction(),
						change);
				trunkGroupParam.addChangeParam("PilotTn", trunkGroupEntity.getPilotTn(), changedTrunkGroup.getPilotTn(),
						change);
				trunkGroupParam.addChangeParam("DeviceMapId", trunkGroupEntity.getDeviceMapId(),
						changedTrunkGroup.getDeviceMapId(), change);
				trunkGroupParam.addChangeParam("DeviceSeqId", trunkGroupEntity.getDeviceMapId(),
						changedTrunkGroup.getDeviceMapId(), change);
				trunkGroupParam.addChangeParam("SignalingDirection", trunkGroupEntity.getSignalingDirection(),
						changedTrunkGroup.getSignalingDirection(), change);
				trunkGroupParam.addChangeParam("AsClli", trunkGroupEntity.getAsClli(), trunkGroupEntity.getAsClli(), change); //add broadsoft clli.

				if (trunkGroupEntity.getPilotUser() != null) {
					pilotUser = new ParamInfo("PilotUser", null, booleanToStr(change));
					pilotUser.addChildParam(
							new ParamInfo("UserId", trunkGroupEntity.getPilotUser().getUserId(), booleanToStr(change)));
					pilotUser.addChildParam(new ParamInfo("FirstName", trunkGroupEntity.getPilotUser().getFirstName(),
							booleanToStr(change)));
					pilotUser.addChildParam(
							new ParamInfo("LastName", trunkGroupEntity.getPilotUser().getLastName(), booleanToStr(change)));
					pilotUser.addChildParam(new ParamInfo("CallingLineIdFirstName",
							trunkGroupEntity.getPilotUser().getCallingLineIdFirstName(), booleanToStr(change)));
					pilotUser.addChildParam(new ParamInfo("CallingLineIdLastName",
							trunkGroupEntity.getPilotUser().getCallingLineIdLastName(), booleanToStr(change)));
					pilotUser.addChildParam(new ParamInfo("PhoneNumber",
							String.valueOf(trunkGroupEntity.getPilotUser().getPhoneNumber()), booleanToStr(change)));
					pilotUser.addChildParam(
							new ParamInfo("LinePort", trunkGroupEntity.getPilotUser().getLinePort(), booleanToStr(change)));
					pilotUser.addChildParam(new ParamInfo("DeviceLevel", trunkGroupEntity.getPilotUser().getDeviceLevel(),
							booleanToStr(change)));
					pilotUser.addChildParam(new ParamInfo("DeviceName", trunkGroupEntity.getPilotUser().getDeviceName(),
							booleanToStr(change)));
					trunkGroupParam.addChildParam(pilotUser, ParamInfo.Tag.NON_ORD);

				}

				// XOO
				trunkGroupParam.addChangeParam("BWTrunkGroupId", trunkGroupEntity.getBwTrunkGroupId(),
						changedTrunkGroup.getBwTrunkGroupId(), change);
				// Start:EBL Change
				if (trunkGroupEntity.getVirtualTrunkId() != null)
					trunkGroupParam.addChangeParam("VirtualTrunkGroupId", trunkGroupEntity.getVirtualTrunkId(),
							trunkGroupEntity.getVirtualTrunkId(), change);

				paramInfoList.add(trunkGroupParam);
			}
		} catch (Exception e) {
			LOG.error("Exception Occured::", e);
		}
		LOG.info("Exit - prepareTblOrderDetailsEntityParamDataForTrunk(enrichedTrunkGrp, change, trunkGroup)");

		return paramInfoList;
	}

	/**
	 * @param bool
	 * @return boolean
	 */
	public static String booleanToStr(Boolean bool) {
		if (bool == null)
			return null;
		else
			return bool ? "C" : "N";
	}
}
