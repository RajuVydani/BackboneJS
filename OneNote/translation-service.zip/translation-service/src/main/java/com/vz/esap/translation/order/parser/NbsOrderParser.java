package com.vz.esap.translation.order.parser;

import java.text.ParseException;
import java.util.ArrayList;

import com.vz.esap.translation.entity.NbsEntity;
import com.vz.esap.translation.exception.TranslatorException;
import com.vz.esap.translation.order.model.request.VOIPOrderRequest;

public interface NbsOrderParser {

	/**
	 * @param voipOrderRequest
	 * @return nbsEntityList
	 * @throws TranslatorException
	 * @throws ParseException
	 */
	ArrayList<NbsEntity> parseNbsOrder(VOIPOrderRequest voipOrderRequest) throws TranslatorException, ParseException;

}
