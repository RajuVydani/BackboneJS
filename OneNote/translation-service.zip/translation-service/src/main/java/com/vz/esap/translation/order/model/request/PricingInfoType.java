package com.vz.esap.translation.order.model.request;

public interface PricingInfoType {


    /**
     * Gets the value of the chargeType property.
     *
     * @return
     *     possible object is
     *     {@link java.lang.String}
     */
    java.lang.String getChargeType();

    /**
     * Sets the value of the chargeType property.
     *
     * @param value
     *     allowed object is
     *     {@link java.lang.String}
     */
    void setChargeType(java.lang.String value);

    /**
     * Gets the value of the catalogVersionTime property.
     *
     * @return
     *     possible object is
     *     {@link java.util.Calendar}
     */
    java.util.Calendar getCatalogVersionTime();

    /**
     * Sets the value of the catalogVersionTime property.
     *
     * @param value
     *     allowed object is
     *     {@link java.util.Calendar}
     */
    void setCatalogVersionTime(java.util.Calendar value);

    /**
     * Gets the value of the unitOfMeasure property.
     *
     * @return
     *     possible object is
     *     {@link java.lang.String}
     */
    java.lang.String getUnitOfMeasure();

    /**
     * Sets the value of the unitOfMeasure property.
     *
     * @param value
     *     allowed object is
     *     {@link java.lang.String}
     */
    void setUnitOfMeasure(java.lang.String value);

    /**
     * Gets the value of the billTime property.
     *
     * @return
     *     possible object is
     *     {@link java.lang.String}
     */
    java.lang.String getBillTime();

    /**
     * Sets the value of the billTime property.
     *
     * @param value
     *     allowed object is
     *     {@link java.lang.String}
     */
    void setBillTime(java.lang.String value);

    /**
     * Gets the value of the featureInstanceId property.
     *
     * @return
     *     possible object is
     *     {@link java.lang.String}
     */
    java.lang.String getFeatureInstanceId();

    /**
     * Sets the value of the featureInstanceId property.
     *
     * @param value
     *     allowed object is
     *     {@link java.lang.String}
     */
    void setFeatureInstanceId(java.lang.String value);

    /**
     * Gets the value of the chargeFrequency property.
     *
     * @return
     *     possible object is
     *     {@link java.lang.String}
     */
    java.lang.String getChargeFrequency();

    /**
     * Sets the value of the chargeFrequency property.
     *
     * @param value
     *     allowed object is
     *     {@link java.lang.String}
     */
    void setChargeFrequency(java.lang.String value);

    /**
     * Gets the value of the featureCode property.
     *
     * @return
     *     possible object is
     *     {@link java.lang.String}
     */
    java.lang.String getFeatureCode();

    /**
     * Sets the value of the featureCode property.
     *
     * @param value
     *     allowed object is
     *     {@link java.lang.String}
     */
    void setFeatureCode(java.lang.String value);

    /**
     * Gets the value of the currencyCode property.
     *
     * @return
     *     possible object is
     *     {@link java.lang.String}
     */
    java.lang.String getCurrencyCode();

    /**
     * Sets the value of the currencyCode property.
     *
     * @param value
     *     allowed object is
     *     {@link java.lang.String}
     */
    void setCurrencyCode(java.lang.String value);

}