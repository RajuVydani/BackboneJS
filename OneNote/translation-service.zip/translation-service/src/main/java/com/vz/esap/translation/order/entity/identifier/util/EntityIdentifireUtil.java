package com.vz.esap.translation.order.entity.identifier.util;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.vz.esap.translation.connector.model.DBServiceResponse;
import com.vz.esap.translation.connector.model.TblRow;
import com.vz.esap.translation.connector.service.InventoryDomainDataServiceImpl;
import com.vz.esap.translation.dao.model.TblEnvOrder;
import com.vz.esap.translation.dao.model.TblOrder;
import com.vz.esap.translation.dao.model.TblOrderDetails;
import com.vz.esap.translation.dao.repository.CustomCustomerMapper;
import com.vz.esap.translation.enums.EsapEnum;
import com.vz.esap.translation.enums.EsapEnum.OrderEntity;
import com.vz.esap.translation.enums.EsapEnum.SolutionType;
import com.vz.esap.translation.exception.GenericException;
import com.vz.esap.translation.exception.TranslatorException;
import com.vz.esap.translation.exception.TranslatorException.ErrorCode;
import com.vz.esap.translation.order.dao.VOIPOrderDao;
import com.vz.esap.translation.order.model.request.VOIPOrderRequest;
import com.vz.esap.translation.order.parser.OrderParser;
import com.vz.esap.translation.order.service.helper.OrderServiceHelperImpl;

import EsapEnumPkg.WorkOrderEnum;

@Component
public class EntityIdentifireUtil {

	private static final Logger LOG = LoggerFactory.getLogger(EntityIdentifireUtil.class);

	@Autowired
	private CustomCustomerMapper customCustomerMapper;	

	@Autowired
	private InventoryDomainDataServiceImpl inventoryDomainDataServiceImpl;	

	@Autowired
	private OrderParser orderParserImpl;
	
	@Autowired
	private OrderServiceHelperImpl orderServiceHelperImpl;	

	@Autowired
	private VOIPOrderDao voipOrderDaoImpl;
	
	/**
	 * @return pqEnterpriseId
	 * @throws GenericException
	 */
	
	public String createPqInstanceEnterpriseId() throws GenericException {
		LOG.info("Entered createPqInstanceEnterpriseId");
		String pqEnterpriseId = null;

		try {
			pqEnterpriseId = String.valueOf(customCustomerMapper.getEnterpriseIdSeqNextVal());
			LOG.debug("Generate Enterprise id : {}", pqEnterpriseId);

		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new GenericException(GenericException.GENERIC_EXCEPTION, "Exception in the provide input arguments");
		}
		LOG.info("Exited createPqInstanceEnterpriseId");
		return pqEnterpriseId;
	}

	
	/**
	 * @param gchId
	 * @param solutionType
	 * @param vpnName TODO
	 * @param internalEnterpriseId TODO
	 * @return enterpriseId
	 * @throws GenericException
	 */
	public String createBwEnterpriseId(String gchId, SolutionType solutionType, String vpnName,
			String internalEnterpriseId) throws GenericException {
		LOG.info("Entered createBwEnterpriseId With internalEnterpriseId = {}", internalEnterpriseId);
		String enterpriseId = null;

		try {
			if(solutionType.equals(SolutionType.ESIP_ESL) || solutionType.equals(SolutionType.ESIP_EBL)) {
				if(internalEnterpriseId != null)
					enterpriseId = "E".concat(internalEnterpriseId);
				else
					enterpriseId = "E".concat(gchId);
				
			} else if(solutionType.equals(SolutionType.IPFLEX)) {
				if(internalEnterpriseId != null)
					enterpriseId = "AID-".concat(internalEnterpriseId);
				else
					enterpriseId = "AID-".concat(gchId);
				
			} else if(solutionType.equals(SolutionType.HPBX)) {
				if(internalEnterpriseId != null)
					enterpriseId = "C-".concat(internalEnterpriseId);
				else
					enterpriseId = "C-".concat(vpnName);
				
			}
				
			
		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new GenericException(GenericException.GENERIC_EXCEPTION, "Exception in the provide input arguments");
		}

		LOG.info("Exited createBwEnterpriseId With enterpriseId - {}", enterpriseId);
		return enterpriseId;
	}

	/**
	 * @return pqEtId
	 * @throws GenericException
	 */
	public String createPqInstanceEtId() throws GenericException {
		LOG.info("Entered createPqInstanceEtId");
		String pqEtId = null;

		try {
			pqEtId = String.valueOf(customCustomerMapper.getEnterpriseTrunkIdSeqNextVal());
			LOG.debug("Generate Enterprise Trunk id : {}", pqEtId);

		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new GenericException(GenericException.GENERIC_EXCEPTION, "Exception in the provide input arguments");
		}

		LOG.info("Exited createPqInstanceEtId");
		return pqEtId;
	}

	/**
	 * @param pqEslId
	 * @param signalingDirection
	 * @return pqEtId
	 * @throws GenericException
	 */
	public String createBwEtId(String pqEslId, String signalingDirection) throws GenericException {
		LOG.info("Entered createBwEtId");
		String pqEtId = null;

		try {
			if (EsapEnum.SignalingDirection.TWO_WAY.toString().equalsIgnoreCase(signalingDirection))
				signalingDirection = EsapEnum.SignalingDirection.TWO_WAY.getValue();
			if (EsapEnum.SignalingDirection.INBOUND.toString().equalsIgnoreCase(signalingDirection))
				signalingDirection = EsapEnum.SignalingDirection.INBOUND.getValue();
			pqEtId = "ET-".concat(signalingDirection).concat("-").concat(pqEslId);
		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new GenericException(GenericException.GENERIC_EXCEPTION, "Exception in the provide input arguments");
		}
		LOG.info("Exited createBwEtId");
		return pqEtId;
	}

	/**
	 * @param bwEntId
	 * @param pqEslId
	 * @param signalingDirection
	 * @param cityCode
	 * @return bwTgId
	 * @throws GenericException
	 */
	public String createBwTgId(String bwEntId, String pqEslId, String signalingDirection, String cityCode)
			throws GenericException {
		LOG.info("Entered createBwTgId");
		String bwTgId = null;

		try {
			if(cityCode != null && cityCode.length() > 3) {
				cityCode = cityCode.substring(0, 2);
			}
			
			if(signalingDirection != null) {
				if (EsapEnum.SignalingDirection.TWO_WAY.toString().equalsIgnoreCase(signalingDirection))
					signalingDirection = EsapEnum.SignalingDirection.TWO_WAY.getValue();
				if (EsapEnum.SignalingDirection.INBOUND.toString().equalsIgnoreCase(signalingDirection))
					signalingDirection = EsapEnum.SignalingDirection.INBOUND.getValue();
				bwTgId = bwEntId.concat(cityCode).concat(pqEslId).concat("-").concat(signalingDirection);
			}else {
				bwTgId = bwEntId.concat(cityCode).concat(pqEslId);
			}
			
		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new GenericException(GenericException.GENERIC_EXCEPTION, "Exception in the provide input arguments");
		}

		LOG.info("Exited createBwTgId");
		return bwTgId;
	}

	/**
	 * @param instanceId
	 * @param signalingDirection
	 * @return bwDevId
	 * @throws GenericException
	 */
	public String createBwDeviceId(String instanceId, String signalingDirection) throws GenericException {
		LOG.info("Entered createBwDeviceId");
		String bwDevId = null;

		try {
			if(signalingDirection != null) {
				if (EsapEnum.SignalingDirection.TWO_WAY.toString().equalsIgnoreCase(signalingDirection))
					signalingDirection = EsapEnum.SignalingDirection.TWO_WAY.getValue();
				if (EsapEnum.SignalingDirection.INBOUND.toString().equalsIgnoreCase(signalingDirection))
					signalingDirection = EsapEnum.SignalingDirection.INBOUND.getValue();
				bwDevId = instanceId.concat("-").concat(signalingDirection);
			}else {
				bwDevId = instanceId;
			}
			
		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new GenericException(GenericException.GENERIC_EXCEPTION, "Exception in the provide input arguments");
		}

		LOG.info("Exited createBwDeviceId");
		return bwDevId;
	}

	public String createBwTgOtgId(String bwEntId, String pqEslId, String signalingDirection, String cityCode)
			throws GenericException {
		LOG.info("Entered createBwTgOtgId");
		String bwOtgTgId = null;
		// Group ID-cluster'E'Direction
		try {
			if(signalingDirection != null) {
			if (EsapEnum.SignalingDirection.TWO_WAY.toString().equalsIgnoreCase(signalingDirection))
				signalingDirection = EsapEnum.SignalingDirection.TWO_WAY.getValue();
			if (EsapEnum.SignalingDirection.INBOUND.toString().equalsIgnoreCase(signalingDirection))
				signalingDirection = EsapEnum.SignalingDirection.INBOUND.getValue();
			// Temporary Fix for Cluster
			bwOtgTgId = bwEntId.concat(cityCode).concat(pqEslId).concat("-").concat("01").concat("E")
					.concat(signalingDirection);
			}else {
				bwOtgTgId = bwEntId.concat(cityCode).concat(pqEslId).concat("-").concat("01").concat("E");
			}
		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new GenericException(GenericException.GENERIC_EXCEPTION, "Exception in the provide input arguments");
		}

		LOG.info("Exited createBwTgOtgId");
		return bwOtgTgId;
	}
	
	/**
	 * @param gchId
	 * @return enterpriseId
	 * @throws GenericException
	 */
	@Deprecated
	public String createBwFlexEnterpriseId(String gchId) throws GenericException {
		LOG.info("Entered createBwFlexEnterpriseId");
		String enterpriseId = null;

		try {
			enterpriseId = "F".concat(gchId);
		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new GenericException(GenericException.GENERIC_EXCEPTION, "Exception in the provide input arguments");
		}

		LOG.info("Exited createBwFlexEnterpriseId");
		return enterpriseId;
	}
	
	
	public String getHpbxDomainName() throws GenericException {
		LOG.info("Entered getHpbxDomainName");
		String domainName = null;
		DBServiceResponse dbServiceResponse = null;
		Set<String> selectColumnSet = null;
		List<String[]> whereClauseList = null;

		try {
			selectColumnSet = new HashSet<>();
			selectColumnSet.add("PARAM_NAME");
			selectColumnSet.add("PARAM_VALUE");

			whereClauseList = new ArrayList<>();
			whereClauseList.add(new String[] { "PARAM_NAME", "LOC_BS_DOMAIN_NAME" });
			whereClauseList.add(new String[] { "PROCESS_NAME", "ORDER_MANAGER" });

			dbServiceResponse = inventoryDomainDataServiceImpl.searchInventory("TBL_CONFIG_PARAMS", selectColumnSet,
					whereClauseList);

			for (TblRow tblRows : dbServiceResponse.getTableRows()) {
				if (tblRows.getTblRow() != null && tblRows.getTblRow().get("PARAM_VALUE") != null
						&& tblRows.getTblRow().get("PARAM_VALUE").getValue() != null) {
					domainName = tblRows.getTblRow().get("PARAM_VALUE").getValue();
					LOG.info("domainName : {}", domainName);
				}
			}
		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new GenericException(GenericException.GENERIC_EXCEPTION, "Exception in the getHpbxDomainName");
		}

		LOG.info("Exited getHpbxDomainName");
		return domainName;
	}


	public long createLineTrunkGroupId(VOIPOrderRequest voipOrderRequest) throws GenericException, TranslatorException {
		LOG.info("Entered createLineTrunkGroupId");
		long tgId = -1;
		// Added for SUPP
		int orderVersion = Integer.parseInt(voipOrderRequest.getOrderHeader().getWorkOrderVersion());
		LOG.info("Order version:: {}", orderVersion);

		List<TblEnvOrder> tblEnvOrderListPrev = null;
		List<TblOrder> tblOrderListPrev = null;
		List<TblOrderDetails> tblOrderDetailsListPrev = null;
		VOIPOrderRequest voipOrderRequestPrev = null;

		if (orderVersion > 0) {

			voipOrderRequestPrev = orderParserImpl.getCorrectPrevPassVoipOrderRequest(voipOrderRequest);

			tblEnvOrderListPrev = orderServiceHelperImpl.getMatchingPrevPassEnvOrder(voipOrderRequestPrev, 0,
					WorkOrderEnum.OrderClassify.RELEASE);
			
			if (CollectionUtils.isEmpty(tblEnvOrderListPrev)) {
				throw new TranslatorException(ErrorCode.ENV_ORDER_NOT_FOUND,
						"No Tbl_Env_Order Record Found");
			}

			LOG.info("Release env table records size::{}", tblEnvOrderListPrev.size());
			LOG.info("REL OLDER VERSION ENV ORDER ID::{}", tblEnvOrderListPrev.get(0).getEnvOrderId());

			tblOrderListPrev = orderServiceHelperImpl.getMatchingPrevPassOrder(tblEnvOrderListPrev.get(0),
					OrderEntity.LINE); // returns one release pass tbl order records basing on upstream task Id.
			
			if(CollectionUtils.isEmpty(tblOrderListPrev)) {
				tblOrderListPrev = orderServiceHelperImpl.getMatchingPrevPassOrder(tblEnvOrderListPrev.get(0),
						OrderEntity.TWO_WAY);
			} 
			
			if(CollectionUtils.isEmpty(tblOrderListPrev)) {
				tblOrderListPrev = orderServiceHelperImpl.getMatchingPrevPassOrder(tblEnvOrderListPrev.get(0),
						OrderEntity.INBOUND);
			}
			
			if (CollectionUtils.isEmpty(tblOrderListPrev)) {
				throw new TranslatorException(ErrorCode.TBL_ORDER_RECORD_NOT_FOUND,
						"No Tbl_Order Record Found");
			}

			LOG.info("REL OLDER VERSION TBL_ORDER records size::{}", tblOrderListPrev.size());
			LOG.info("REL OLDER VERSION TBL ORDER ID::{}", tblOrderListPrev.get(0).getOrderId());

			for (TblOrder tblOrderPrev : tblOrderListPrev) {
				tblOrderDetailsListPrev = voipOrderDaoImpl.getOrderDetailsEntriesPerOrder(tblOrderPrev);
				
			}
			
			if (CollectionUtils.isEmpty(tblOrderDetailsListPrev)) {
				throw new TranslatorException(ErrorCode.TBL_ORDER_DETAILS_RECORD_NOT_FOUND,
						"No Tbl_Order_Details Record Found");
			}
			LOG.info("VAL OLDER VERSION TBL_ORDER_DETAILS records size::{}", tblOrderDetailsListPrev.size());
			
			for (TblOrderDetails tblOrderDetails : tblOrderDetailsListPrev) {				
				if ("GroupId".equalsIgnoreCase(tblOrderDetails.getParamName())){
					tgId = Long.valueOf(tblOrderDetails.getParamValue());
					
					break;
				}
			}

		} else {
			tgId = customCustomerMapper.getGroupIdSeqNextVal();
		}

		LOG.info("Exited createLineTrunkGroupId With Trunk Group Id = {}", tgId);
		return tgId;
	}

}
