package com.vz.esap.translation.order.transformer;

import java.text.ParseException;
import java.util.ArrayList;

import com.vz.esap.translation.entity.GroupTNEntity;
import com.vz.esap.translation.exception.TranslatorException;
import com.vz.esap.translation.order.model.Order;
import com.vz.esap.translation.order.model.request.ParamInfo;

/**
 * @author baigkh
 *
 */
public interface TNTblOrderDetailsDataTransformer {

	/**
	 * @param groupTNList
	 * @param action
	 * @return paramInfos
	 */
	ArrayList<ParamInfo> prepareTODEtityDataForGroups(ArrayList<GroupTNEntity> groupTNList, String action);
	
	
	/**
	 * @param order
	 * @return paramInfo
	 * @throws ParseException
	 * @throws TranslatorException
	 */
	ParamInfo prepareTblOrderDetailsHeaderParamData(Order order) throws ParseException, TranslatorException ;
	
	
	/**
	 * @param order
	 * @return paramInfo
	 * @throws TranslatorException
	 */
	ParamInfo prepareTblOrderDetailsEntityParamDataForGroupTn(Order order) throws TranslatorException;
	

	/**
	 * @param order
	 * @return paramInfo
	 * @throws TranslatorException
	 */
	ParamInfo prepareTblOrderDetailsEntityParamDataForSystemUpdate(Order order, String action) throws TranslatorException;


	/**
	 * @param order
	 * @param grpTNEntityPrev
	 * @param supp
	 * @return paramInfo
	 * @throws ParseException
	 * @throws TranslatorException
	 */
	ParamInfo prepareTblOrderDetailsHeaderParamData(Order order, GroupTNEntity grpTNEntityPrev, boolean supp)
			throws ParseException, TranslatorException;


	/**
	 * @param grpTNEntityPrev
	 * @param groupTnEntity
	 * @param supp
	 * @param action
	 * @return paramInfo
	 */
	ParamInfo prepareTblOrderDetailsEntityParamDataForSystemUpdate(GroupTNEntity grpTNEntityPrev,
			GroupTNEntity groupTnEntity, boolean supp, String action);


	/**
	 * @param grpTNEntityPrev
	 * @param groupTnEntity
	 * @param supp
	 * @param action
	 * @return
	 */
	ParamInfo prepareTblOrderDetailsEntityParamDataForGroupTn(GroupTNEntity grpTNEntityPrev,
			GroupTNEntity groupTnEntity, boolean supp, String action);


	/**
	 * @param order
	 * @param action
	 * @return
	 * @throws ParseException
	 * @throws TranslatorException
	 */
	ParamInfo prepareTblOrderDetailsHeaderParamData(Order order, String action)
			throws ParseException, TranslatorException;


	/**
	 * @param order
	 * @param action
	 * @return
	 * @throws TranslatorException
	 */
	ParamInfo prepareTblOrderDetailsEntityParamDataForGroupTn(Order order, String action) throws TranslatorException;

}