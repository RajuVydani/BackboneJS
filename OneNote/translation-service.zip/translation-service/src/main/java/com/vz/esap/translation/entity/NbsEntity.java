package com.vz.esap.translation.entity;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.vz.esap.translation.enums.EsapEnum.NbsType;
import com.vz.esap.translation.enums.EsapEnum.OrderEntity;
import com.vz.esap.translation.enums.EsapEnum.RedundancyPriorityType;
import com.vz.esap.translation.enums.EsapEnum.RedundancyType;
import com.vz.esap.translation.enums.EsapEnum.SolutionType;

public class NbsEntity extends Entity {

	private static final Logger LOG = LoggerFactory.getLogger(NbsEntity.class);

	private static final long serialVersionUID = 1L;
	private String customerId;
	private String locationId;
	private String nbsClusterName;
	private String nbsClusterId;
	private String vpnId;
	private String vpnName;
	private String vlanId;
	private String nbsCircuitId;
	private String state;
	private String country;
	private String city;
	private String region;
	private String stateCode;
	private String bwCluster;
	private String eslId;
	private String pbxIpRedundancy1;
	private String pbxIpRedundancy2;
	private String internalSigZonePort;
	private String internalSigZoneIp;
	private String externalSigZonePort;
	private String externalSigZoneIp;
	private SolutionType solutionType;
	private String ip28;
	private String ip32;
	private String ip0;
	private String ip1;
	private String ip2;
	private String ip3;
	private String trunkGroupTwoWay;
	private String trunkGroupInbound;
	private String trunkGroupId;
	private NbsType nbsType;
	private RedundancyType redundancy;
	private RedundancyPriorityType redundancyPriorityType;
	// Start-NBS Change
	private String cpeIpAddress;
	private String ipAddress;
	private String address;
	private String cpeServerFqdnPort;
	private String cpeServerFqdn;
	private String cpePort;
	private String ipVersion;
	// End-NBS Change
	private String SR1;
	private String SR2;
	private String SR3;
	private String SR4;
	private long envOrderId;
	private long internalOrderId;
	private NbsEntity nbsEntity;
	private boolean isNewNbsTrunk;
	private String groupUserLimit;
	private String compressionType; 
	private String asClli;

	public NbsEntity getNbsEntity() {
		return nbsEntity;
	}

	public void setNbsEntity(NbsEntity nbsEntity) {
		this.nbsEntity = nbsEntity;
	}

	@Override
	public int getEntityType() {
		return OrderEntity.SONUS_NBS.getIndex();
	}

	@Override
	public String getEntityName() {
		return nbsClusterName;
	}

	@Override
	public String getEntityId() {
		return nbsClusterId;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getLocationId() {
		return locationId;
	}

	public void setLocationId(String locationId) {
		this.locationId = locationId;
	}

	public String getNbsClusterName() {
		return nbsClusterName;
	}

	public void setNbsClusterName(String nbsClusterName) {
		this.nbsClusterName = nbsClusterName;
	}

	public String getNbsClusterId() {
		return nbsClusterId;
	}

	public void setNbsClusterId(String nbsClusterId) {
		this.nbsClusterId = nbsClusterId;
	}

	public String getVpnId() {
		return vpnId;
	}

	public void setVpnId(String vpnId) {
		this.vpnId = vpnId;
	}

	public String getVpnName() {
		return vpnName;
	}

	public void setVpnName(String vpnName) {
		this.vpnName = vpnName;
	}

	public String getVlanId() {
		return vlanId;
	}

	public void setVlanId(String vlanId) {
		this.vlanId = vlanId;
	}

	public String getNbsCircuitId() {
		return nbsCircuitId;
	}

	public void setNbsCircuitId(String nbsCircuitId) {
		this.nbsCircuitId = nbsCircuitId;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	public String getStateCode() {
		return stateCode;
	}

	public void setStateCode(String stateCode) {
		this.stateCode = stateCode;
	}

	public String getBwCluster() {
		return bwCluster;
	}

	public void setBwCluster(String bwCluster) {
		this.bwCluster = bwCluster;
	}

	public String getEslId() {
		return eslId;
	}

	public void setEslId(String eslId) {
		this.eslId = eslId;
	}

	public String getPbxIpRedundancy1() {
		return pbxIpRedundancy1;
	}

	public void setPbxIpRedundancy1(String pbxIpRedundancy1) {
		this.pbxIpRedundancy1 = pbxIpRedundancy1;
	}

	public String getPbxIpRedundancy2() {
		return pbxIpRedundancy2;
	}

	public void setPbxIpRedundancy2(String pbxIpRedundancy2) {
		this.pbxIpRedundancy2 = pbxIpRedundancy2;
	}

	public String getInternalSigZonePort() {
		return internalSigZonePort;
	}

	public void setInternalSigZonePort(String internalSigZonePort) {
		this.internalSigZonePort = internalSigZonePort;
	}

	public String getInternalSigZoneIp() {
		return internalSigZoneIp;
	}

	public void setInternalSigZoneIp(String internalSigZoneIp) {
		this.internalSigZoneIp = internalSigZoneIp;
	}

	public String getExternalSigZonePort() {
		return externalSigZonePort;
	}

	public void setExternalSigZonePort(String externalSigZonePort) {
		this.externalSigZonePort = externalSigZonePort;
	}

	public String getExternalSigZoneIp() {
		return externalSigZoneIp;
	}

	public void setExternalSigZoneIp(String externalSigZoneIp) {
		this.externalSigZoneIp = externalSigZoneIp;
	}

	public SolutionType getSolutionType() {
		return solutionType;
	}

	public void setSolutionType(SolutionType solutionType) {
		this.solutionType = solutionType;
	}

	public String getIp28() {
		return ip28;
	}

	public void setIp28(String ip28) {
		this.ip28 = ip28;
	}

	public String getIp0() {
		return ip0;
	}

	public void setIp0(String ip0) {
		this.ip0 = ip0;
	}

	public String getIp1() {
		return ip1;
	}

	public void setIp1(String ip1) {
		this.ip1 = ip1;
	}

	public String getIp2() {
		return ip2;
	}

	public void setIp2(String ip2) {
		this.ip2 = ip2;
	}

	public String getIp3() {
		return ip3;
	}

	public void setIp3(String ip3) {
		this.ip3 = ip3;
	}

	public String getTrunkGroupTwoWay() {
		return trunkGroupTwoWay;
	}

	public void setTrunkGroupTwoWay(String trunkGroupTwoWay) {
		this.trunkGroupTwoWay = trunkGroupTwoWay;
	}

	public String getTrunkGroupInbound() {
		return trunkGroupInbound;
	}

	public void setTrunkGroupInbound(String trunkGroupInbound) {
		this.trunkGroupInbound = trunkGroupInbound;
	}

	public NbsType getNbsType() {
		return nbsType;
	}

	public void setNbsType(NbsType nbsType) {
		this.nbsType = nbsType;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public String getTrunkGroupId() {
		return trunkGroupId;
	}

	public void setTrunkGroupId(String trunkGroupId) {
		this.trunkGroupId = trunkGroupId;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getCpeIpAddress() {
		return cpeIpAddress;
	}

	public void setCpeIpAddress(String cpeIpAddress) {
		this.cpeIpAddress = cpeIpAddress;
	}

	public String getCpeServerFqdnPort() {
		return cpeServerFqdnPort;
	}

	public void setCpeServerFqdnPort(String cpeServerFqdnPort) {
		this.cpeServerFqdnPort = cpeServerFqdnPort;
	}

	public String getCpeServerFqdn() {
		return cpeServerFqdn;
	}

	public void setCpeServerFqdn(String cpeServerFqdn) {
		this.cpeServerFqdn = cpeServerFqdn;
	}

	public String getCpePort() {
		return cpePort;
	}

	public void setCpePort(String cpePort) {
		this.cpePort = cpePort;
	}

	public RedundancyType getRedundancy() {
		return redundancy;
	}

	public void setRedundancy(RedundancyType redundancy) {
		this.redundancy = redundancy;
	}

	public RedundancyPriorityType getRedundancyPriorityType() {
		return redundancyPriorityType;
	}

	public void setRedundancyPriorityType(RedundancyPriorityType redundancyPriorityType) {
		this.redundancyPriorityType = redundancyPriorityType;
	}

	public String getIpVersion() {
		return ipVersion;
	}

	public void setIpVersion(String ipVersion) {
		this.ipVersion = ipVersion;
	}

	public String getIp32() {
		return ip32;
	}

	public void setIp32(String ip32) {
		this.ip32 = ip32;
	}

	public String getSR1() {
		return SR1;
	}

	public void setSR1(String sR1) {
		SR1 = sR1;
	}

	public String getSR2() {
		return SR2;
	}

	public void setSR2(String sR2) {
		SR2 = sR2;
	}

	public String getSR3() {
		return SR3;
	}

	public void setSR3(String sR3) {
		SR3 = sR3;
	}

	public String getSR4() {
		return SR4;
	}

	public void setSR4(String sR4) {
		SR4 = sR4;
	}

	@Override
	public String toString() {
		return "NbsEntity [customerId=" + customerId + ", locationId=" + locationId
				+ ", nbsClusterName=" + nbsClusterName + ", nbsClusterId=" + nbsClusterId + ", vpnId=" + vpnId
				+ ", vpnName=" + vpnName + ", vlanId=" + vlanId + ", nbsCircuitId=" + nbsCircuitId + ", state=" + state
				+ ", country=" + country + ", city=" + city + ", region=" + region + ", stateCode=" + stateCode
				+ ", bwCluster=" + bwCluster + ", eslId=" + eslId + ", pbxIpRedundancy1=" + pbxIpRedundancy1
				+ ", pbxIpRedundancy2=" + pbxIpRedundancy2 + ", internalSigZonePort=" + internalSigZonePort
				+ ", internalSigZoneIp=" + internalSigZoneIp + ", externalSigZonePort=" + externalSigZonePort
				+ ", externalSigZoneIp=" + externalSigZoneIp + ", solutionType=" + solutionType + ", ip28=" + ip28
				+ ", ip32=" + ip32 + ", ip0=" + ip0 + ", ip1=" + ip1 + ", ip2=" + ip2 + ", ip3=" + ip3
				+ ", trunkGroupTwoWay=" + trunkGroupTwoWay + ", trunkGroupInbound=" + trunkGroupInbound
				+ ", trunkGroupId=" + trunkGroupId + ", nbsType=" + nbsType + ", redundancy=" + redundancy
				+ ", redundancyPriorityType=" + redundancyPriorityType + ", cpeIpAddress=" + cpeIpAddress
				+ ", ipAddress=" + ipAddress + ", address=" + address + ", cpeServerFqdnPort=" + cpeServerFqdnPort
				+ ", cpeServerFqdn=" + cpeServerFqdn + ", cpePort=" + cpePort + ", ipVersion=" + ipVersion + ", SR1="
				+ SR1 + ", SR2=" + SR2 + ", SR3=" + SR3 + ", SR4=" + SR4 + "]";
	}

	public long getEnvOrderId() {
		return envOrderId;
	}

	public void setEnvOrderId(long envOrderId) {
		this.envOrderId = envOrderId;
	}

	public long getInternalOrderId() {
		return internalOrderId;
	}

	public void setInternalOrderId(long internalOrderId) {
		this.internalOrderId = internalOrderId;
	}

	public boolean isNewNbsTrunk() {
		return isNewNbsTrunk;
	}

	public void setNewNbsTrunk(boolean isNewNbsTrunk) {
		this.isNewNbsTrunk = isNewNbsTrunk;
	}

	public String getGroupUserLimit() {
		return groupUserLimit;
	}

	public void setGroupUserLimit(String groupUserLimit) {
		this.groupUserLimit = groupUserLimit;
	}

	public String getIpAddress() {
		return ipAddress;
	}

	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getCompressionType() {
		return compressionType;
	}

	public void setCompressionType(String compressionType) {
		this.compressionType = compressionType;
	}

	public String getAsClli() {
		return asClli;
	}

	public void setAsClli(String asClli) {
		this.asClli = asClli;
	}
}
