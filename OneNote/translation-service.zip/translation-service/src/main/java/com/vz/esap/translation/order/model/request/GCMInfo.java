package com.vz.esap.translation.order.model.request;

public class GCMInfo {

	private PricingInfo[] PricingInfo;

	private String QuoteId;

	private String CustomerPriceBookId;

	private String ContractId;

	private String ProductIdentifier;

	public PricingInfo[] getPricingInfo() {
		return PricingInfo;
	}

	public void setPricingInfo(PricingInfo[] PricingInfo) {
		this.PricingInfo = PricingInfo;
	}

	public String getQuoteId() {
		return QuoteId;
	}

	public void setQuoteId(String QuoteId) {
		this.QuoteId = QuoteId;
	}

	public String getCustomerPriceBookId() {
		return CustomerPriceBookId;
	}

	public void setCustomerPriceBookId(String CustomerPriceBookId) {
		this.CustomerPriceBookId = CustomerPriceBookId;
	}

	public String getContractId() {
		return ContractId;
	}

	public void setContractId(String ContractId) {
		this.ContractId = ContractId;
	}

	public String getProductIdentifier() {
		return ProductIdentifier;
	}

	public void setProductIdentifier(String ProductIdentifier) {
		this.ProductIdentifier = ProductIdentifier;
	}

	@Override
	public String toString() {
		return "ClassPojo [PricingInfo = " + PricingInfo + ", QuoteId = " + QuoteId + ", CustomerPriceBookId = "
				+ CustomerPriceBookId + ", ContractId = " + ContractId + ", ProductIdentifier = " + ProductIdentifier
				+ "]";
	}

	public ParamInfo getParamInfo(String action) {
		ParamInfo gcmParam = new ParamInfo("BillableFeatureInfo", null, action);
		gcmParam.addNotNullValChild("CustomerPriceBookId", CustomerPriceBookId, action);
		gcmParam.addNotNullValChild("ContractId", ContractId, action);
		gcmParam.addNotNullValChild("QuoteId", QuoteId, action);
		gcmParam.addNotNullValChild("ProductIdentifier", ProductIdentifier, action);
		if (PricingInfo != null && PricingInfo.length > 0) {
			for (PricingInfo priceInfo : PricingInfo) {
				gcmParam.addChildParam(priceInfo.getParamInfo(action));
			}
		}
		return gcmParam;
	}
}