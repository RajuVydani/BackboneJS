package com.vz.esap.translation.order.service.nbs;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.vz.esap.translation.dao.model.TblEnvOrder;
import com.vz.esap.translation.dao.model.TblOrder;
import com.vz.esap.translation.dao.model.TblOrderDetails;
import com.vz.esap.translation.dao.model.TblOrderExample;
import com.vz.esap.translation.dao.model.TblOrderService;
import com.vz.esap.translation.dao.repository.CustomTblOrderMapper;
import com.vz.esap.translation.entity.NbsEntity;
import com.vz.esap.translation.enums.EsapEnum;
import com.vz.esap.translation.enums.EsapEnum.FlowPath;
import com.vz.esap.translation.enums.EsapEnum.OrderEntity;
import com.vz.esap.translation.enums.EsapEnum.OrderType;
import com.vz.esap.translation.exception.GenericException;
import com.vz.esap.translation.exception.TranslatorException;
import com.vz.esap.translation.order.dao.VOIPOrderDao;
import com.vz.esap.translation.order.model.Order;
import com.vz.esap.translation.order.model.OrderHeader;
import com.vz.esap.translation.order.model.OrderHeader.SuppType;
import com.vz.esap.translation.order.model.request.ParamInfo;
import com.vz.esap.translation.order.model.request.VOIPOrderRequest;
import com.vz.esap.translation.order.model.response.VoipOrderResponse;
import com.vz.esap.translation.order.parser.OrderParser;
import com.vz.esap.translation.order.service.OrderServiceBase;
import com.vz.esap.translation.order.service.VOIPResponseGenerator;
import com.vz.esap.translation.order.service.helper.OrderServiceHelperImpl;
import com.vz.esap.translation.order.transformer.EnterpriseTblOrderServiceDataTransformer;
import com.vz.esap.translation.order.transformer.NbsTblOrderDataTransformerImpl;
import com.vz.esap.translation.order.transformer.NbsTblOrderDetailsDataTransformer;
import com.vz.esap.translation.order.transformer.NbsTransformer;
import com.vz.esap.translation.util.InventoryUtil;

import EsapEnumPkg.WorkOrderEnum;

@Service
public class NbsOrderServiceImpl extends OrderServiceBase implements NbsOrderService {

	private static final Logger LOG = LoggerFactory.getLogger(NbsOrderServiceImpl.class);

	@Autowired
	private NbsTransformer nbsTransformerImpl;

	@Autowired
	private NbsTblOrderDataTransformerImpl nbsTblOrderDataTransformerImpl;

	@Autowired
	private VOIPOrderDao voipOrderDao;

	@Autowired
	private NbsTblOrderDetailsDataTransformer nbsTblOrderDetailsDataTransformerImpl;

	@Autowired
	private EnterpriseTblOrderServiceDataTransformer enterpriseTblOrderServiceData;

	@Autowired
	private VOIPResponseGenerator voipResponseGenerator;

	@Autowired
	private OrderServiceHelperImpl orderServiceHelperImpl;

	@Autowired
	private OrderParser orderParserImpl;
	
	@Autowired
	private CustomTblOrderMapper customTblOrderMapper;

	@Autowired
	private InventoryUtil inventoryUtil;
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.vz.esap.translation.order.service.nbs.NbsOrderService#processReleaseOrder
	 * (com.vz.esap.translation.dao.model.TblOrderDetails,
	 * com.vz.esap.translation.dao.model.TblOrder,
	 * com.vz.esap.translation.dao.model.TblEnvOrder,
	 * com.vz.esap.translation.order.model.request.VOIPOrderRequest, java.util.List)
	 */
	@Override
	public VoipOrderResponse processReleaseOrder(TblOrderDetails tblOrderDetails, TblOrder tblOrderBeanValidation,
			TblEnvOrder tblEnvOrder, VOIPOrderRequest voipOrderRequest, List<TblOrderDetails> tblOrderDetailsList)
			throws GenericException, TranslatorException {

		LOG.info("Entered - processReleaseOrder");

		VoipOrderResponse voipOrderResponse = null;
		NbsEntity nbsEntity = null;
		OrderHeader orderHeader = null;
		List<TblEnvOrder> tblEnvOrderListPrev = null;
		List<TblOrder> tblOrderListPrev = null;
		List<TblOrderDetails> tblOrderDetailsListPrev = null;
		NbsEntity nbsEntityPrev = null;
		boolean isNewNbsTrunk;

		try {
			if ("C".equalsIgnoreCase(voipOrderRequest.getOrderHeader().getOrderType())) {
				LOG.info("Inside Device Change");
				//This will fetch n,r
				nbsEntity = nbsTransformerImpl.transformOrderDetailsToNbs(tblOrderBeanValidation.getOrderId(),
						tblOrderDetails.getOrderDetailId(), null, false, Arrays.asList("o"));

				//This will fetch o,r
				nbsEntityPrev = nbsTransformerImpl.transformOrderDetailsToNbs(tblOrderBeanValidation.getOrderId(),
						tblOrderDetails.getOrderDetailId(), null, false, Arrays.asList("n"));
				
				//This will fetch if there is any TOD with n
				isNewNbsTrunk = orderServiceHelperImpl.isNewEntityChangeOrder(tblOrderBeanValidation.getOrderId(),
						tblOrderDetails.getOrderDetailId());
				
				LOG.info("Device Id = {} Is New Device Entity = {}", nbsEntity.getTrunkGroupId(), isNewNbsTrunk);
				
				nbsEntity.setNewNbsTrunk(isNewNbsTrunk);

			} else {
				nbsEntity = nbsTransformerImpl.transformOrderDetailsToNbs(tblOrderBeanValidation.getOrderId(),
						tblOrderDetails.getOrderDetailId(), "n", false, null);
			}

			if (nbsEntity == null) {
				nbsEntity = new NbsEntity();
			}

			LOG.info("NBSEntity : {} ", nbsEntity);

			int orderVersion = Integer.parseInt(voipOrderRequest.getOrderHeader().getWorkOrderVersion());
			LOG.info("Order version:: {}", orderVersion);

			if (orderVersion > 0) {
				LOG.info("SUPP Order version:: {}", voipOrderRequest.getOrderHeader().getWorkOrderVersion());
				
				VOIPOrderRequest voipOrderRequestPrev = orderParserImpl.getCorrectPrevPassVoipOrderRequest(voipOrderRequest);
				//voipOrderRequestPrev.getOrderHeader().setWorkOrderVersion(Integer.toString(orderVersion - 1));
				tblEnvOrderListPrev = orderServiceHelperImpl.getMatchingPrevPassEnvOrder(voipOrderRequestPrev, 0,
						WorkOrderEnum.OrderClassify.RELEASE); // returns 1 release pass record
				
				LOG.info("env table records size::{}", tblEnvOrderListPrev.size());
				LOG.info("ENV ORDER ID::{}", tblEnvOrderListPrev.get(0).getEnvOrderId());
				
				tblOrderListPrev = orderServiceHelperImpl.getMatchingPrevPassOrder(tblEnvOrderListPrev.get(0),
						OrderEntity.SONUS_NBS, nbsEntity.getNbsType().toString());
				
				LOG.info("TBL_ORDER table records size::{}", tblOrderListPrev.size());
				
				//ESVRRS-18523 :: START :: Supp other on failed Entity fix.
				if(!CollectionUtils.isEmpty(tblOrderListPrev) && WorkOrderEnum.Status.WO_INIT != tblOrderListPrev.get(0).getOrderStatus()) {
					
					if (!CollectionUtils.isEmpty(tblOrderListPrev)) {
						LOG.info("TBL_ORDER records size::{}", tblOrderListPrev.size());
						LOG.info("TBL ORDER ID::{}", tblOrderListPrev.get(0).getOrderId());
	
						for (TblOrder tblOrderPrev : tblOrderListPrev) {
							if (tblOrderPrev.getAccountNumber().equalsIgnoreCase(nbsEntity.getNbsType().toString())) {
								tblOrderDetailsListPrev = orderServiceHelperImpl.getMatchingOrderDetails(tblOrderPrev);
								if(tblOrderDetailsListPrev!=null)//Changed For Sonar Coverage
								LOG.info("TBL_ORDER_DETAILS records size::{}", tblOrderDetailsListPrev.size());
							}
						}
					}
					
					if (tblOrderDetailsListPrev!=null && !CollectionUtils.isEmpty(tblOrderDetailsListPrev)) {//Changed For Sonar Coverage
						LOG.info("TBL_ORDER_DETAILS records size::{}",tblOrderDetailsListPrev.size());
						LOG.info("Previous Table Order Id::{}", tblOrderListPrev.get(0).getOrderId());
						LOG.info("Previous Table Order Details Id::{}", tblOrderDetailsListPrev.get(0).getOrderDetailId());
						
						nbsEntityPrev = nbsTransformerImpl.transformOrderDetailsToNbs(tblOrderListPrev.get(0).getOrderId(),
								tblOrderDetailsListPrev.get(0).getOrderDetailId(), "n", false, null);
	
						nbsEntityPrev.setEnvOrderId(tblEnvOrderListPrev.get(0).getEnvOrderId());
						nbsEntityPrev.setInternalOrderId(tblOrderDetailsListPrev.get(0).getOrderId());
						
						LOG.info("nbsEntityPrev::{}::{}", nbsEntityPrev.getCustomerId(), nbsEntityPrev.getCpeIpAddress());
						LOG.info("nbsEntity::{}::{}", nbsEntity.getCustomerId(), nbsEntity.getCpeIpAddress());
					}
	
					if (voipOrderRequest.getOrderHeader().getSuppType().equals(SuppType.CANCEL.toString()))
						voipOrderRequest.getOrderHeader().setSuppType(SuppType.CANCEL.toString());
					else
						voipOrderRequest.getOrderHeader().setSuppType(SuppType.SUPP.toString());
				}
			}

			orderHeader = createdOrderHeaderForNbsOrder(voipOrderRequest, nbsEntity);

			createReleaseOrders(orderHeader, nbsEntity, nbsEntityPrev, tblOrderDetailsList, tblOrderBeanValidation,
					WorkOrderEnum.Status.WO_INIT, tblEnvOrder);

			voipOrderResponse = voipResponseGenerator.prepareSuccessOrderResponse(voipOrderRequest);

		} catch (TranslatorException ex) {
			LOG.error("Exception {} {} ", ex.getMessage(), ex);
			throw new TranslatorException(ex.getErrorCode(), ex.getMessage());
		} catch (Exception e) {
			LOG.error("Exception {} {} ", e.getMessage(), e);
			throw new GenericException(GenericException.GENERIC_EXCEPTION,
					"Exception in the provide input arguments-" + e);
		}

		LOG.info("Exit - processReleaseOrder");
		return voipOrderResponse;
	}

	/**
	 * @param orderHeader
	 * @param nbsEntity
	 * @param nbsEntityPrev
	 * @param tblOrderDetailsList
	 * @param tblOrderBeanValidation
	 * @param status
	 * @param tblEnvOrderObject
	 * @return isCreated
	 * @throws TranslatorException
	 * @throws GenericException
	 */
	boolean createReleaseOrders(OrderHeader orderHeader, NbsEntity nbsEntity, NbsEntity nbsEntityPrev,
			List<TblOrderDetails> tblOrderDetailsList, TblOrder tblOrderBeanValidation, int status,
			TblEnvOrder tblEnvOrderObject) throws TranslatorException, GenericException {
		LOG.info("Entered - createReleaseOrders");

		boolean isCreated = true;
		Order order = null;
		Order orderPrevPass = null;
		TblOrder tblOrderObject = null;
		List<TblOrderService> tblOrderServiceList = null;
		boolean hasChange = false;
		ParamInfo headerParamInfo = null;
		ParamInfo entityParamInfo = null;

		try {

			order = new Order();
			orderHeader.setOrderStatus(status);
			order.setOrderHeader(orderHeader);

			if (nbsEntity == null) {
				nbsEntity = new NbsEntity();
			}

			if (null != tblEnvOrderObject.getEnvOrderId())
				orderHeader.setEnvOrderId(tblEnvOrderObject.getEnvOrderId());
			if (null != tblEnvOrderObject.getProjectId())
				orderHeader.setProjectId(tblEnvOrderObject.getProjectId());
			orderHeader.setEnvOrderId(tblEnvOrderObject.getEnvOrderId());
			orderHeader.setProjectId(tblEnvOrderObject.getProjectId());
			orderHeader.setCustomerId(tblEnvOrderObject.getEnterpriseId());
			orderHeader.setEnterpriseId(tblEnvOrderObject.getEnterpriseId());
			orderHeader.setLocationId(tblEnvOrderObject.getLocationId());

			order.setOrderHeader(orderHeader);
			order.setNbsEntity(nbsEntity);
			
			LOG.info("Nbs orderHeader.getEntityAction() = {}", orderHeader.getEntityAction());
			if ("I".equalsIgnoreCase(orderHeader.getEntityAction())) {
				if (nbsEntityPrev != null) {
					LOG.info("nbsEntityPrev is not null");

					headerParamInfo = nbsTblOrderDetailsDataTransformerImpl.prepareTblOrderDetailsHeaderParamData(order,
							nbsEntityPrev, true);

					entityParamInfo = nbsTblOrderDetailsDataTransformerImpl
							.prepareTblOrderDetailsEntityParamDataForNbs(nbsEntityPrev, nbsEntity, true, null);

					if (entityParamInfo != null && entityParamInfo.getAction() != null
							&& "C".equals(entityParamInfo.getAction())) {
						LOG.info("entityParamInfo.getAction(): {}", entityParamInfo.getAction());
						hasChange = true;
						orderHeader.setEntityAction("C");
						
						entityParamInfo.addNotNullValChild("NBS_INV_CHANGE", "Y", "n");
						entityParamInfo.addNotNullValChild("NBS_GSX_CHANGE", "Y", "n");
						entityParamInfo.addNotNullValChild("NBS_PSX_CHANGE", "Y", "n");
						
					} else if (entityParamInfo != null && entityParamInfo.getAction() != null
							&& entityParamInfo.getAction().equals("NC")) {
						LOG.info("entityParamInfo.getAction(): {}", entityParamInfo.getAction());
						hasChange = false;
						orderHeader.setEntityAction("NC");
					}
					
				} else {

					headerParamInfo = nbsTblOrderDetailsDataTransformerImpl
							.prepareTblOrderDetailsHeaderParamData(order);

					entityParamInfo = nbsTblOrderDetailsDataTransformerImpl
							.prepareTblOrderDetailsEntityParamDataForNbs(order);
					LOG.info("entityParamInfo.getAction(): {}", entityParamInfo.getAction());

					hasChange = false;
					orderHeader.setEntityAction("I");
				}
			} else if ("C".equalsIgnoreCase(orderHeader.getEntityAction())) {
				LOG.info("Inside createReleaseOrders For Nbs Change");
				if (nbsEntityPrev != null) {
					LOG.info("nbsEntityPrev is not null");

					headerParamInfo = nbsTblOrderDetailsDataTransformerImpl.prepareTblOrderDetailsHeaderParamData(order,
							nbsEntityPrev, true);

					entityParamInfo = nbsTblOrderDetailsDataTransformerImpl
							.prepareTblOrderDetailsEntityParamDataForNbs(nbsEntityPrev, nbsEntity, true, null);
					
					//LOG.info("entityParamInfo.getAction() For NBS: {}", entityParamInfo.getAction());

					if (nbsEntity.isNewNbsTrunk()) {
						LOG.info("NBS is New Install For MAC Order Device Id = {}", nbsEntity.getTrunkGroupId());
						orderHeader.setEntityAction("I");
						entityParamInfo.setAction("n");

					} else {
						if (entityParamInfo != null && entityParamInfo.getAction() != null
								&& "C".equals(entityParamInfo.getAction())) {

							LOG.info("NBS entityParamInfo.getAction(): {}", entityParamInfo.getAction());
							hasChange = true;
							orderHeader.setEntityAction("C");

							entityParamInfo.addNotNullValChild("NBS_INV_CHANGE", "Y", "n");
							entityParamInfo.addNotNullValChild("NBS_GSX_CHANGE", "Y", "n");
							entityParamInfo.addNotNullValChild("NBS_PSX_CHANGE", "Y", "n");

						} else if (entityParamInfo != null && entityParamInfo.getAction() != null
								&& entityParamInfo.getAction().equals("NC")) {
							LOG.info("NBS entityParamInfo.getAction(): {}", entityParamInfo.getAction());
							hasChange = false;
							orderHeader.setEntityAction("NC");

						}
					}
				}				
			}
			LOG.info("orderHeader.getEntityAction()-Nbs : {} ", orderHeader.getEntityAction());
			if (null != headerParamInfo && !"NC".equalsIgnoreCase(orderHeader.getEntityAction())) {
				headerParamInfo.addChildParam(entityParamInfo);
				
				// Create Order :
				tblOrderObject = nbsTblOrderDataTransformerImpl.prepareTblOrderDataFromOrder(order,
						Long.valueOf(OrderEntity.SONUS_NBS.ordinal()));
				voipOrderDao.createTblOrder(tblOrderObject);
				LOG.info("Tbl_Order Created for Nbs , Order Id : {}", tblOrderObject.getOrderId());

				// :create order Details
				LOG.info("createOrders start creating Nbs entity order details");

				LOG.info("hasChange {}", hasChange);

				if (entityParamInfo != null && entityParamInfo.getAction() != null)
					voipOrderDao.populateOrderDetails(tblOrderObject, headerParamInfo.getChildParams(),
							entityParamInfo.getAction(), 0, 0);
				else
					voipOrderDao.populateOrderDetails(tblOrderObject, headerParamInfo.getChildParams(), "n", 0, 0);
				
				// :create service entry for WF
				LOG.info("createOrders start creating service for Nbs entity");
				orderHeader.setFlowPath(FlowPath.valueOf(tblOrderObject.getFlowPath()));
				orderHeader.setTblOrderId(tblOrderObject.getOrderId());
				orderHeader.setEntityType(EsapEnum.OrderEntity.SONUS_NBS.getIndex());
				order.setOrderHeader(orderHeader);

				// refactor prepareTblOrderServiceData to pass orderPrevPass
				orderPrevPass = new Order();
				orderPrevPass.setOrderHeader(orderHeader);// TODO add previous pass order header
				orderPrevPass.setNbsEntity(nbsEntityPrev);

				tblOrderServiceList = enterpriseTblOrderServiceData.prepareTblOrderServiceData(order, orderPrevPass,
						null);

				LOG.info("Retail Order Service Count : {}", tblOrderServiceList.size());

				for (TblOrderService tblOrderService : tblOrderServiceList) {
					LOG.info("TblOrderService:"+tblOrderService.toString());
					voipOrderDao.createTblOrderService(tblOrderService);
				}

				voipOrderDao.updateTblOrderStatus(tblOrderObject.getOrderId(), WorkOrderEnum.Status.WO_INIT);
				
			} else if (nbsEntityPrev != null && "NC".equalsIgnoreCase(orderHeader.getEntityAction())) {
				
				LOG.info("nbsEntityPrev != null && \"NC\".equalsIgnoreCase(orderHeader.getEntityAction())");
				LOG.info("Order Version ==>> {}", orderHeader.getOrderVersion());
				
				int orderVersion = Integer.parseInt(orderHeader.getOrderVersion());
				
				if(orderVersion > 0) {
					orderServiceHelperImpl.handleSuppOrderWithNoChange(tblEnvOrderObject.getEnvOrderId(),
							nbsEntityPrev.getInternalOrderId(), tblEnvOrderObject);
					//Check if TWO way is stil NBS pending
					TblOrder ordertemp = new TblOrder();
					ordertemp.setOrderId(nbsEntityPrev.getInternalOrderId());
					
					tblOrderServiceList = voipOrderDao.getOrderServiceList(ordertemp);
					
					if( null != tblOrderServiceList) {
						for(TblOrderService tblOrderService : tblOrderServiceList) {
							if(tblOrderService.getService().equalsIgnoreCase("VZB_ESAP_INPUT_NBS_DATA") && tblOrderService.getServiceStatus() == 253L && tblOrderService.getServiceStatus() != 102L) {
								tblOrderService.setServiceStatus(102L);
								voipOrderDao.updateTblOrderService(tblOrderService);
								voipOrderDao.updateTblOrderStatus(nbsEntityPrev.getInternalOrderId(), WorkOrderEnum.Status.WO_INIT);
								voipOrderDao.deletePendingWOTaskByOrderID(nbsEntityPrev.getInternalOrderId());
							}else if(tblOrderService.getService().equalsIgnoreCase("VZB_INV_ADD_SONUS_NBS_2W_FXO") && tblOrderService.getServiceStatus() != 104L) {
								tblOrderService.setServiceStatus(102L);
								voipOrderDao.updateTblOrderService(tblOrderService);
								voipOrderDao.updateTblOrderStatus(nbsEntityPrev.getInternalOrderId(), WorkOrderEnum.Status.WO_INIT);
								voipOrderDao.deletePendingWOTaskByOrderID(nbsEntityPrev.getInternalOrderId());
							}
							
						}
					}			
					
				} else {
					
					LOG.info("This is MAC NBS Scenario of Do Nothing");
				}
			}
		} catch (TranslatorException ex) {
			LOG.error("Exception {} {}", ex.getMessage(), ex);
			throw new TranslatorException(ex.getErrorCode(), ex.getMessage());
		} catch (Exception e) {
			LOG.error("Exception {} {}", e.getMessage(), e);
			throw new GenericException(GenericException.GENERIC_EXCEPTION, "Exception in the provide input arguments");
		}

		LOG.info("Exit - createReleaseOrders");
		return isCreated;
	}
	
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.vz.esap.translation.order.service.nbs.NbsOrderService#
	 * isNbsProvisioningRequired(com.vz.esap.translation.dao.model.TblEnvOrder)
	 */
	@Override
	public String isNbsProvisioningRequired(TblEnvOrder tblEnvOrder) throws TranslatorException, GenericException {
		LOG.info("Entered - isNbsProvisioningRequired");

		boolean isNbsProvReqBool = false;

		if (WorkOrderEnum.OrderType.IN == tblEnvOrder.getOrderType() || WorkOrderEnum.OrderType.CHANGE == tblEnvOrder.getOrderType()) {
			isNbsProvReqBool = isNbsProvisioningReqInstall(tblEnvOrder);

		}

		LOG.info("Exit - isNbsProvisioningRequired = {} ", isNbsProvReqBool);
		return isNbsProvReqBool ? "Y" : "N";
	}

	/**
	 * @param tblEnvOrder
	 * @return
	 * @throws GenericException
	 * @throws TranslatorException
	 */
	boolean isNbsProvisioningReqInstall(TblEnvOrder tblEnvOrder) throws TranslatorException, GenericException {
		LOG.info("Entered - isNbsProvisioningReqInstall");

		boolean isNbsProvReqBool = false;
		List<TblOrder> tblOrderListNbs = null;

		tblOrderListNbs = getNbsOrders(tblEnvOrder);

		if (tblEnvOrder.getVersionNumber() == 0) {
			LOG.info("ESL Install Order V0 2W + IB --> NBS_PROV = Y || ESL Install Order V0 2W --> NBS_PROV = Y");

			if (!CollectionUtils.isEmpty(tblOrderListNbs)) {
				LOG.info("ESL Install V0 Scenario and NBS Order is present so NBS Provisioning is required");
				isNbsProvReqBool = true;

			}

		} else { 
			LOG.info("ESL Install Supp scenario");
			
			if (!CollectionUtils.isEmpty(tblOrderListNbs)) {
				LOG.info("ESL Install Order Supp Add IB --> NBS_PROV = Y || ESL Install Order Supp Add 2W --> NBS_PROV = Y");
				LOG.info("ESL Install V1 Scenario and NBS Order is present so NBS Provisioning is required");
				isNbsProvReqBool = true;
				
				//populateNbsConfigFromPreviousOrder(tblOrderListNbs);

			} else {
				LOG.info("ESL Install Order Supp No NBS Impact --> NBS_PROV = N");

			}
		}

		LOG.info("Exit - isNbsProvisioningReqInstall");
		return isNbsProvReqBool;
	}

	/**
	 * @param tblOrderListNbs
	 * @throws GenericException
	 * @throws TranslatorException
	 */
	 void populateNbsConfigFromPreviousOrder(List<TblOrder> tblOrderListNbs)
			throws TranslatorException, GenericException {
		LOG.info("Entered - populateNbsConfigFromPreviousOrder");

		List<TblOrderDetails> nbsConfigTblOrderDetails = null;

		nbsConfigTblOrderDetails = getNbsConfigParentDetails(tblOrderListNbs);

		if (!CollectionUtils.isEmpty(nbsConfigTblOrderDetails)) {
			LOG.info("NBS Config is present and NBS Config TblOrderDetails size = {}", nbsConfigTblOrderDetails.size());
			
		}

		LOG.info("Exit - populateNbsConfigFromPreviousOrder");
	}

	/**
	 * @param tblOrderListNbs
	 * @return
	 * @throws GenericException
	 * @throws TranslatorException
	 */
	 List<TblOrderDetails> getNbsConfigParentDetails(List<TblOrder> tblOrderListNbs)
			throws TranslatorException, GenericException {
		LOG.info("Entered - getNbsConfigParentDetails");
		
		List<TblOrderDetails> tblOrderDetailsList;
		List<TblOrderDetails> parentTblOrderDetails = null;
		List<TblOrderDetails> nbsConfigTblOrderDetails = null;
		for (TblOrder tblOrder : tblOrderListNbs) {

			tblOrderDetailsList = voipOrderDaoImpl.getOrderDetailsEntriesPerOrder(tblOrder);
			LOG.info("Order Details Size: {}", tblOrderDetailsList.size());

			parentTblOrderDetails = tblOrderDetailsList.stream()
					.filter(tblOrderDetails -> "NbsConfig".equalsIgnoreCase(tblOrderDetails.getParamName()))
					.collect(Collectors.toList());
			
		
			if (parentTblOrderDetails != null && !CollectionUtils.isEmpty(parentTblOrderDetails)) {
				LOG.info("NBS Config Detail Id: {}", parentTblOrderDetails.get(0).getOrderDetailId());
				
				TblOrderDetails tblOrderDetails = new TblOrderDetails();
				tblOrderDetails.setOrderId(tblOrder.getOrderId());
				tblOrderDetails.setParentId(parentTblOrderDetails.get(0).getOrderDetailId());
				nbsConfigTblOrderDetails = voipOrderDao.getOrderDetailsWithActionAndParent(
						parentTblOrderDetails.get(0).getOrderDetailId(), null, false, null, tblOrderDetails);				
							
			}			
		}
		LOG.info("Exit - getNbsConfigParentDetails");
		return nbsConfigTblOrderDetails;
	}
	
	/**
	 * @param tblEnvOrder
	 * @return
	 */
	   List<TblOrder> getNbsOrders(TblEnvOrder tblEnvOrder) {
		LOG.info("Entered - getNbsOrders");

		TblOrderExample tblOrderExampleMapper = new TblOrderExample();
		List<String> orderTypeList=new ArrayList<String>();
		orderTypeList.add(OrderType.getValueReverse("IN"));
		orderTypeList.add(OrderType.getValueReverse("CHANGE"));
		tblOrderExampleMapper.createCriteria().andEnvOrderIdEqualTo(tblEnvOrder.getEnvOrderId())
				.andVersionNoEqualTo(tblEnvOrder.getVersionNumber().toString())
				.andFlowPathIn(Arrays.asList(FlowPath.F.toString()))
				.andOrderTypeIn(orderTypeList); 

		List<TblOrder> tblOrderListComplete = customTblOrderMapper.selectByExample(tblOrderExampleMapper);

		List<TblOrder> tblOrderListNbs = tblOrderListComplete.stream()
				.filter(tblOrder -> tblOrder.getUpstreamTaskId() == 66).collect(Collectors.toList());

		LOG.info("Exit - getNbsOrders Size = {}", tblOrderListNbs.size());
		return tblOrderListNbs;
	}

	/*
	 * ESL Install Order V0 2W + IB --> NBS_PROV = Y ESL Install Order V0 2W -->
	 * NBS_PROV = Y ESL Install Order Supp Add IB --> NBS_PROV = Y ESL Install Order
	 * Supp Remove IB --> NBS_PROV = Y ESL Install Order Supp No NBS Impact -->
	 * NBS_PROV = N ESL Change Order Add IB --> NBS_PROV = Y ESL Change Order No NBS
	 * Impact --> NBS_PROV = N ESL Change Order Remove IB --> NBS_PROV = Y ESL
	 * Install Order V0 NBS is in progress status --> NBS_PROV = Y
	 */

}
