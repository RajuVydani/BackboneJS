package com.vz.esap.translation.order.transformer;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.vz.esap.translation.entity.EnterpriseTrunkEntity;
import com.vz.esap.translation.exception.TranslatorException;
import com.vz.esap.translation.order.model.Order;
import com.vz.esap.translation.order.model.request.ParamInfo;
import com.vz.esap.translation.order.model.request.VOIPOrderRequest;

@Component
public interface EnterpriseTrunkTblOrderDetailsDataTransformer {

	/**
	 * @param ets
	 * @param action
	 * @return paramInfoList
	 */
	ArrayList<ParamInfo> prepareTblOrderDetailsEntityParamDataForET(List<EnterpriseTrunkEntity> ets, VOIPOrderRequest voipOrderRequest);

	/**
	 * @param et
	 * @param action
	 * @return paramInfo
	 */
	ParamInfo prepareTblOrderDetailsEntityParamDataForET(EnterpriseTrunkEntity et, String action);


	/**
	 * @param enterpriseTrunkEntityPrev
	 * @param enterpriseTrunkEntity
	 * @param supp
	 * @param action
	 * @return paramInfo
	 */
	ParamInfo prepareTblOrderDetailsEntityParamDataForET(EnterpriseTrunkEntity enterpriseTrunkEntityPrev,
			EnterpriseTrunkEntity enterpriseTrunkEntity, boolean supp, String action);

	/**
	 * @param order
	 * @param oldETEntity
	 * @param supp
	 * @return paramInfo
	 * @throws TranslatorException 
	 */
	ParamInfo prepareTblOrderDetailsHeaderParamData(Order order, EnterpriseTrunkEntity oldETEntity,
			boolean supp) throws TranslatorException;

}
