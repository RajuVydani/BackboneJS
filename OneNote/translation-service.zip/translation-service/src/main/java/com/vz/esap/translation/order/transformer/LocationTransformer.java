package com.vz.esap.translation.order.transformer;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Component;

import com.vz.esap.translation.entity.LocationEntity;
import com.vz.esap.translation.entity.ParamInfo;
import com.vz.esap.translation.exception.ApplicationInterfaceException;
import com.vz.esap.translation.exception.GenericException;
import com.vz.esap.translation.exception.TranslatorException;
import com.vz.esap.translation.order.model.request.VOIPOrderRequest;

@Component
public interface LocationTransformer {

	/**
	 * @param orderId
	 * @param parentId
	 * @param action
	 * @param delta
	 * @param paramActionExclusionList
	 *            TODO
	 * @return location
	 * @throws TranslatorException
	 * @throws GenericException
	 */
	LocationEntity transformOrderDetailsToLocation(long orderId, long parentId, String action, boolean delta,
			List<String> paramActionExclusionList) throws TranslatorException, GenericException;

	/**
	 * @param resultantRow
	 * @return
	 */
	LocationEntity locationInventoryToLocationEntityTransformer(Map<String, String> resultantRow);

	/**
	 * @param voipOrderRequest
	 * @param locationEntity
	 * @return
	 * @throws GenericException
	 * @throws TranslatorException
	 * @throws ApplicationInterfaceException
	 * @throws IllegalAccessException
	 */
	LocationEntity enrichLocationEntityWithInventory(VOIPOrderRequest voipOrderRequest, LocationEntity locationEntity)
			throws TranslatorException, GenericException, IllegalAccessException, ApplicationInterfaceException;

}
