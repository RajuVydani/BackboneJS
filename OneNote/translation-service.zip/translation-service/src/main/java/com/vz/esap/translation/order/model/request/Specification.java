package com.vz.esap.translation.order.model.request;

public class Specification {

	private String Name;

	private String Value;

	private String Code;

	private String ValueCode;

	public String getName() {
		return Name;
	}

	public void setName(String Name) {
		this.Name = Name;
	}

	public String getValue() {
		return Value;
	}

	public void setValue(String Value) {
		this.Value = Value;
	}

	public String getCode() {
		return Code;
	}

	public void setCode(String Code) {
		this.Code = Code;
	}

	public String getValueCode() {
		return ValueCode;
	}

	public void setValueCode(String ValueCode) {
		this.ValueCode = ValueCode;
	}

	public String toString() {
		return "ClassPojo [Specificationm Name = " + Name + ", Value = " + Value + ", Code = " + Code + ", ValueCode = "
				+ ValueCode + "]";
	}
}
