package com.vz.esap.translation.connector.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.vz.esap.translation.connector.dto.DBOperationRequest;
import com.vz.esap.translation.connector.dto.DBOperationResponse;
import com.vz.esap.translation.connector.dto.DatabaseServiceRequest;
import com.vz.esap.translation.connector.dto.DatabaseServiceResponse;
import com.vz.esap.translation.connector.dto.WhereClause;
import com.vz.esap.translation.connector.model.DBServiceResponse;
import com.vz.esap.translation.connector.util.DomainInterfaceUtil;
import com.vz.esap.translation.enums.ESAPDBQueryEnum;
import com.vz.esap.translation.exception.ApplicationInterfaceException;

/**
 * @author Aricent
 * 
 */
@Service
public class InventoryDomainDataServiceImpl {

	private static final Logger LOG = LoggerFactory.getLogger(InventoryDomainDataServiceImpl.class);
	
	private static final String INVENTORY_DOMAIN_SERVICE = "InventoryDomainService:";
	private ObjectMapper mapper = new ObjectMapper();

	@Autowired
	private DomainInterfaceUtil domainInterfaceUtil;

	@Autowired
	private RestTemplate restTemplate;

	@Value("${inventoryDomain.databaseService}")
	private String inventoryDatabaseServiceBaseURL;

	@Value("${inventory.dbOperationsUrl}")
	private String inventoryDatabasePreConfiguredQueryServiceURL;

	public DBServiceResponse searchInventory(String tableName, Set<String> selectColumnSet,
			List<String[]> whereClauseList) throws ApplicationInterfaceException {
		DBServiceResponse responseData = null;

		LOG.info("Entering searchInventory(): {} ", tableName);

		final String inventoryDatabaseServiceURL = inventoryDatabaseServiceBaseURL.concat("/databaseService");
		try {

			DatabaseServiceRequest request = new DatabaseServiceRequest();
			request.setDbOperation("SELECT");
			request.setTableName(tableName);
			List<String> selectColumnList = new ArrayList<>(selectColumnSet);
			LOG.info("searchInventory(): Table: {} SelectColumn: {} WhereCondition: {}", tableName, selectColumnList,
					whereClauseList);
			request.setColumnNames(selectColumnList);
			WhereClause whereClauseRequest = new WhereClause();

			List<String> whereClauseColumnName = new ArrayList<>();
			List<String> whereClauseColumnValue = new ArrayList<>();
			for (String[] whereClauseArray : whereClauseList) {
				whereClauseColumnName.add(whereClauseArray[0]);
				whereClauseColumnValue.add(whereClauseArray[1]);
			}
			whereClauseRequest.setColumnNames(whereClauseColumnName);
			whereClauseRequest.setColumnValues(whereClauseColumnValue);
			request.setWhereClause(Collections.singletonList(whereClauseRequest));

			long startTime = System.currentTimeMillis();
			LOG.info("searchInventory(): Making HTTP POST Request for tableName:{} at time:{}", tableName,
					startTime);
			LOG.info("searchInventory(): Service URL: {}", inventoryDatabaseServiceURL);

			LOG.info("searchInventory(): Service request: {}",
					mapper.writerWithDefaultPrettyPrinter().writeValueAsString(request));

			DatabaseServiceResponse inventoryDBServiceResponse = restTemplate.postForObject(inventoryDatabaseServiceURL,
					request, DatabaseServiceResponse.class);

			if (inventoryDBServiceResponse == null)
				throw new ApplicationInterfaceException("No response received from Inventory DB service");

			long endTime = System.currentTimeMillis();

			LOG.info("searchInventory(): HTTP Response: {} ",
					mapper.writerWithDefaultPrettyPrinter().writeValueAsString(inventoryDBServiceResponse));

			responseData = domainInterfaceUtil.convertDBResponseToTblData(inventoryDBServiceResponse);

			LOG.debug(
					"searchInventory(): Number of record: {}, Received HTTP POST Response for tableName:{} at time:{} and Response{} : ",
					inventoryDBServiceResponse.getNumberOfRecords(), tableName, endTime, responseData.toString());
			LOG.debug("searchInventory(): Time taken for Response for tableName:{} is:{} ms",
					inventoryDBServiceResponse.getNumberOfRecords(), endTime - startTime);

			LOG.info("Exiting searchInventory() at {}", endTime);

		} catch (HttpStatusCodeException e) {

			LOG.error("Exception received from InventoryDBService Service: {} ", e);
			LOG.error("Execption during searchInventory execution code:{} , text:{}", e.getStatusCode(),
					e.getResponseBodyAsString());
			throw new ApplicationInterfaceException(INVENTORY_DOMAIN_SERVICE + e.getMessage());
		} catch (Exception e) {

			LOG.error("Exception received from InventoryDBService Service: {} ", e);
			throw new ApplicationInterfaceException(INVENTORY_DOMAIN_SERVICE + e.getMessage());
		}

		return responseData;
	}

	/**
	 * @param sqlKey
	 * @param sourceService
	 * @param values
	 * @return
	 * @throws ApplicationInterfaceException
	 */
	public DBServiceResponse executePreconfiguredQuery(ESAPDBQueryEnum sqlKey, String sourceService,
			List<String> values) throws ApplicationInterfaceException {

		DBServiceResponse responseData = null;

		LOG.info("executePreconfiguredQuery(): sqlKey:{} , sourceService:{} , values:{}", sqlKey, sourceService,
				values);

		try {
			List<DBOperationRequest> requestList = new ArrayList<DBOperationRequest>();
			DBOperationRequest request = new DBOperationRequest();
			request.setSqlKey(sqlKey.name());
			request.setSourceService(sourceService);
			request.setQueryReferenceId(0L);
			request.setColumnValues(values);

			requestList.add(request);

			long startTime = System.currentTimeMillis();
			LOG.info("executePreconfiguredQuery(): Making HTTP POST Request for sql:{} at time:{}", sqlKey,
					startTime);
			LOG.info("executePreconfiguredQuery(): Service URL: {}", inventoryDatabasePreConfiguredQueryServiceURL);
			LOG.info("executePreconfiguredQuery(): Service restTemplate: {}", restTemplate);

			DBOperationResponse[] dbOperationResponse = restTemplate.postForObject(
					inventoryDatabasePreConfiguredQueryServiceURL, requestList, DBOperationResponse[].class);

			if (dbOperationResponse == null || dbOperationResponse.length == 0)
				throw new ApplicationInterfaceException(INVENTORY_DOMAIN_SERVICE + "No Response from Service");

			long endTime = System.currentTimeMillis();

			LOG.info("executePreconfiguredQuery(): Received HTTP POST Response at time:{}", endTime);
			LOG.info("executePreconfiguredQuery(): Time taken for Response for {} ms", (endTime - startTime));

			LOG.info("executePreconfiguredQuery(): HTTP Response: {} " + dbOperationResponse[0]);

			responseData = domainInterfaceUtil.convertDBResponseToTblData(dbOperationResponse[0]);

			LOG.info("Exiting executePreconfiguredQuery() ");

		} catch (HttpStatusCodeException e) {
			LOG.error("Exception received from InventoryDBService Service URL: {} ",
					inventoryDatabasePreConfiguredQueryServiceURL);
			LOG.error("Exception received from InventoryDBService Service: {} ", e);
			LOG.error("Execption during executePreconfiguredQuery execution code:{} , text:{}", e.getStatusCode(),
					e.getResponseBodyAsString());
			throw new ApplicationInterfaceException(INVENTORY_DOMAIN_SERVICE + e.getMessage());
		} catch (RestClientException e) {
			LOG.error("Exception received from InventoryDBService Service URL: {} ",
					inventoryDatabasePreConfiguredQueryServiceURL);
			LOG.error("Exception received from InventoryDBService Service: {} ", e);
			throw new ApplicationInterfaceException(INVENTORY_DOMAIN_SERVICE + e.getMessage());
		}
		return responseData;

	}

}