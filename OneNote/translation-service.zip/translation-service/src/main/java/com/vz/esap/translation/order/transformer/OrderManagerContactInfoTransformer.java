package com.vz.esap.translation.order.transformer;

import org.springframework.stereotype.Component;

import com.vz.esap.translation.entity.OrderManagerContactInfoEntity;
import com.vz.esap.translation.exception.GenericException;

@Component
public interface OrderManagerContactInfoTransformer {

	/**
	 * @param envOrderId
	 * @param action
	 * @return orderManagerContact
	 * @throws GenericException
	 */
	OrderManagerContactInfoEntity transformValEnvOrderToOrdMgrContactInfo(long envOrderId, String action)
			throws GenericException;

}
