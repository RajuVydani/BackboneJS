package com.vz.esap.translation.order.model.request;

public class RouterConfig {

	private String M4VRRPPriority;

	private String LogicalRouterName;

	private String CustSigGatewayIp;

	private String NniCircuitIdM4;

	private String NniCircuitIdM3;

	private String MicroNodeIdentifier;

	private String PvcVlanM3;

	private String PvcVlanM4;

	private String VpnName;

	private String M3PhysicalCircuitID;

	private String IpVersion;

	private String M4InterfaceToNetwork;

	private String PeerASnumber;

	private String M3InterfaceToSBC;

	private String M4PhysicalCircuitID;

	private String CustSigIrb;

	private String M3InterfaceToNetwork;

	private String PvcCircuitM4;

	private String PvcCircuitM3;

	private String EBGPNumber;

	private String CircuitType;

	private String M3VRRPPriority;

	private String PeIpAddressM4;

	private String PeIpAddressM3;

	private String CeIpAddressM3;

	private String VrrpGroup;

	private String CeIpAddressM4;

	private String M4InterfaceToSBC;

	private String CustMedIrb;

	private String PvcDlciM3;

	private String CustMedGatewayIp;

	private String PvcDlciM4;

	public String getM4VRRPPriority() {
		return M4VRRPPriority;
	}

	public void setM4VRRPPriority(String M4VRRPPriority) {
		this.M4VRRPPriority = M4VRRPPriority;
	}

	public String getLogicalRouterName() {
		return LogicalRouterName;
	}

	public void setLogicalRouterName(String LogicalRouterName) {
		this.LogicalRouterName = LogicalRouterName;
	}

	public String getCustSigGatewayIp() {
		return CustSigGatewayIp;
	}

	public void setCustSigGatewayIp(String CustSigGatewayIp) {
		this.CustSigGatewayIp = CustSigGatewayIp;
	}

	public String getNniCircuitIdM4() {
		return NniCircuitIdM4;
	}

	public void setNniCircuitIdM4(String NniCircuitIdM4) {
		this.NniCircuitIdM4 = NniCircuitIdM4;
	}

	public String getNniCircuitIdM3() {
		return NniCircuitIdM3;
	}

	public void setNniCircuitIdM3(String NniCircuitIdM3) {
		this.NniCircuitIdM3 = NniCircuitIdM3;
	}

	public String getMicroNodeIdentifier() {
		return MicroNodeIdentifier;
	}

	public void setMicroNodeIdentifier(String MicroNodeIdentifier) {
		this.MicroNodeIdentifier = MicroNodeIdentifier;
	}

	public String getPvcVlanM3() {
		return PvcVlanM3;
	}

	public void setPvcVlanM3(String PvcVlanM3) {
		this.PvcVlanM3 = PvcVlanM3;
	}

	public String getPvcVlanM4() {
		return PvcVlanM4;
	}

	public void setPvcVlanM4(String PvcVlanM4) {
		this.PvcVlanM4 = PvcVlanM4;
	}

	public String getVpnName() {
		return VpnName;
	}

	public void setVpnName(String VpnName) {
		this.VpnName = VpnName;
	}

	public String getM3PhysicalCircuitID() {
		return M3PhysicalCircuitID;
	}

	public void setM3PhysicalCircuitID(String M3PhysicalCircuitID) {
		this.M3PhysicalCircuitID = M3PhysicalCircuitID;
	}

	public String getIpVersion() {
		return IpVersion;
	}

	public void setIpVersion(String IpVersion) {
		this.IpVersion = IpVersion;
	}

	public String getM4InterfaceToNetwork() {
		return M4InterfaceToNetwork;
	}

	public void setM4InterfaceToNetwork(String M4InterfaceToNetwork) {
		this.M4InterfaceToNetwork = M4InterfaceToNetwork;
	}

	public String getPeerASnumber() {
		return PeerASnumber;
	}

	public void setPeerASnumber(String PeerASnumber) {
		this.PeerASnumber = PeerASnumber;
	}

	public String getM3InterfaceToSBC() {
		return M3InterfaceToSBC;
	}

	public void setM3InterfaceToSBC(String M3InterfaceToSBC) {
		this.M3InterfaceToSBC = M3InterfaceToSBC;
	}

	public String getM4PhysicalCircuitID() {
		return M4PhysicalCircuitID;
	}

	public void setM4PhysicalCircuitID(String M4PhysicalCircuitID) {
		this.M4PhysicalCircuitID = M4PhysicalCircuitID;
	}

	public String getCustSigIrb() {
		return CustSigIrb;
	}

	public void setCustSigIrb(String CustSigIrb) {
		this.CustSigIrb = CustSigIrb;
	}

	public String getM3InterfaceToNetwork() {
		return M3InterfaceToNetwork;
	}

	public void setM3InterfaceToNetwork(String M3InterfaceToNetwork) {
		this.M3InterfaceToNetwork = M3InterfaceToNetwork;
	}

	public String getPvcCircuitM4() {
		return PvcCircuitM4;
	}

	public void setPvcCircuitM4(String PvcCircuitM4) {
		this.PvcCircuitM4 = PvcCircuitM4;
	}

	public String getPvcCircuitM3() {
		return PvcCircuitM3;
	}

	public void setPvcCircuitM3(String PvcCircuitM3) {
		this.PvcCircuitM3 = PvcCircuitM3;
	}

	public String getEBGPNumber() {
		return EBGPNumber;
	}

	public void setEBGPNumber(String EBGPNumber) {
		this.EBGPNumber = EBGPNumber;
	}

	public String getCircuitType() {
		return CircuitType;
	}

	public void setCircuitType(String CircuitType) {
		this.CircuitType = CircuitType;
	}

	public String getM3VRRPPriority() {
		return M3VRRPPriority;
	}

	public void setM3VRRPPriority(String M3VRRPPriority) {
		this.M3VRRPPriority = M3VRRPPriority;
	}

	public String getPeIpAddressM4() {
		return PeIpAddressM4;
	}

	public void setPeIpAddressM4(String PeIpAddressM4) {
		this.PeIpAddressM4 = PeIpAddressM4;
	}

	public String getPeIpAddressM3() {
		return PeIpAddressM3;
	}

	public void setPeIpAddressM3(String PeIpAddressM3) {
		this.PeIpAddressM3 = PeIpAddressM3;
	}

	public String getCeIpAddressM3() {
		return CeIpAddressM3;
	}

	public void setCeIpAddressM3(String CeIpAddressM3) {
		this.CeIpAddressM3 = CeIpAddressM3;
	}

	public String getVrrpGroup() {
		return VrrpGroup;
	}

	public void setVrrpGroup(String VrrpGroup) {
		this.VrrpGroup = VrrpGroup;
	}

	public String getCeIpAddressM4() {
		return CeIpAddressM4;
	}

	public void setCeIpAddressM4(String CeIpAddressM4) {
		this.CeIpAddressM4 = CeIpAddressM4;
	}

	public String getM4InterfaceToSBC() {
		return M4InterfaceToSBC;
	}

	public void setM4InterfaceToSBC(String M4InterfaceToSBC) {
		this.M4InterfaceToSBC = M4InterfaceToSBC;
	}

	public String getCustMedIrb() {
		return CustMedIrb;
	}

	public void setCustMedIrb(String CustMedIrb) {
		this.CustMedIrb = CustMedIrb;
	}

	public String getPvcDlciM3() {
		return PvcDlciM3;
	}

	public void setPvcDlciM3(String PvcDlciM3) {
		this.PvcDlciM3 = PvcDlciM3;
	}

	public String getCustMedGatewayIp() {
		return CustMedGatewayIp;
	}

	public void setCustMedGatewayIp(String CustMedGatewayIp) {
		this.CustMedGatewayIp = CustMedGatewayIp;
	}

	public String getPvcDlciM4() {
		return PvcDlciM4;
	}

	public void setPvcDlciM4(String PvcDlciM4) {
		this.PvcDlciM4 = PvcDlciM4;
	}

}
