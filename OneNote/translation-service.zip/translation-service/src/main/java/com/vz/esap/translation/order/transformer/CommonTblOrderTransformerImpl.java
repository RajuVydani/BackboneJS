package com.vz.esap.translation.order.transformer;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.vz.esap.translation.dao.model.TblOrder;
import com.vz.esap.translation.dao.repository.CustomCustomerMapper;
import com.vz.esap.translation.dao.repository.CustomTblOrderPrioritySettingsMapper;
import com.vz.esap.translation.exception.GenericException;

@Component
public class CommonTblOrderTransformerImpl implements CommonTblOrderTransformer {

	private static final Logger LOG = LoggerFactory.getLogger(CommonTblOrderTransformerImpl.class);

	@Autowired
	private CustomCustomerMapper customCustomerMapper;

	@Autowired
	private CustomTblOrderPrioritySettingsMapper customTblOrderPrioritySettingsMapper;

	@Value("${source.address}")
	private String sourceAddress;

	@Override
	public TblOrder prepareTblOrderDataFromExistingTblOrder(TblOrder tblOrderOrig, Map<String, String> mapForUpdate) throws GenericException {
		LOG.info("Entered - prepareTblOrderDataFromOrder");
		
		TblOrder tblOrderNew = null;
		long orderId = -1;
		long priority = -1;

		try {
			tblOrderNew = new TblOrder();
			orderId = customCustomerMapper.getOrderIdSeqNextVal();

			tblOrderNew.setOrderId(orderId);
			tblOrderNew.setEnvOrderId(Long.valueOf(mapForUpdate.get("EnvOrderId")));
			tblOrderNew.setPrevPassOrderId(tblOrderOrig.getOrderId());			
			tblOrderNew.setOrderStatus(Long.valueOf(mapForUpdate.get("OrderStatus")));
			tblOrderNew.setPrevOrderStatus(tblOrderOrig.getOrderStatus());
			tblOrderNew.setWorkGroup(null);			
			tblOrderNew.setCompletedDate("");
			tblOrderNew.setStartDate("");
			tblOrderNew.setUpdatedDate(null);
			tblOrderNew.setTransactionNumber(mapForUpdate.get("TransactionNumber"));
			tblOrderNew.setVersionNo(mapForUpdate.get("VersionNo"));
			tblOrderNew.setFlowPath(mapForUpdate.get("FlowPath"));
			tblOrderNew.setErrorCode("");			
			tblOrderNew.setDestSystem(tblOrderOrig.getDestSystem());
			tblOrderNew.setApptypeId(tblOrderOrig.getApptypeId());
			tblOrderNew.setDueDate(tblOrderOrig.getDueDate());
			tblOrderNew.setPriority(tblOrderOrig.getPriority());
			tblOrderNew.setSourceService(tblOrderOrig.getSourceService());
			tblOrderNew.setSourceSystem(tblOrderOrig.getSourceSystem());
			tblOrderNew.setManualOrder(tblOrderOrig.getManualOrder());
			tblOrderNew.setVzId(tblOrderOrig.getVzId());
			tblOrderNew.setUpstreamFlowId(tblOrderOrig.getUpstreamFlowId());
			tblOrderNew.setUpstreamTaskId(tblOrderOrig.getUpstreamTaskId());
			tblOrderNew.setUpstreamWoId(tblOrderOrig.getUpstreamWoId());
			tblOrderNew.setTdn(tblOrderOrig.getTdn());
			tblOrderNew.setNpa(tblOrderOrig.getNpa());
			tblOrderNew.setClli(tblOrderOrig.getClli());
			tblOrderNew.setParentOrder(tblOrderOrig.getParentOrder());
			tblOrderNew.setAccountNumber(tblOrderOrig.getAccountNumber());
			tblOrderNew.setOrderType(tblOrderOrig.getOrderType());
			tblOrderNew.setMinorOrderType(tblOrderOrig.getMinorOrderType());
			tblOrderNew.setAction(tblOrderOrig.getAction());
			tblOrderNew.setProjectId(tblOrderOrig.getProjectId());
			if(tblOrderOrig.getApsState() != null) {
			tblOrderNew.setApsState(tblOrderOrig.getApsState());
			} else {
				tblOrderNew.setApsState(0L);
			}
		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new GenericException(GenericException.GENERIC_EXCEPTION,
					"Exception occured in getEnterpriseInformationFromGchId");
		}
		LOG.info("Exit - prepareTblOrderDataFromOrder");
		return tblOrderNew;
	}

}
