package com.vz.esap.translation.order.transformer;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import com.vz.esap.translation.dao.model.TblEnvOrder;
import com.vz.esap.translation.dao.model.TblOrder;
import com.vz.esap.translation.dao.model.TblOrderPrioritySettings;
import com.vz.esap.translation.dao.repository.CustomCustomerMapper;
import com.vz.esap.translation.dao.repository.CustomTblOrderPrioritySettingsMapper;
import com.vz.esap.translation.enums.EsapEnum.FlowPath;
import com.vz.esap.translation.enums.EsapEnum.OrderEntity;
import com.vz.esap.translation.enums.EsapEnum.OrderPass;
import com.vz.esap.translation.exception.GenericException;
import com.vz.esap.translation.order.model.Order;
import com.vz.esap.translation.order.model.request.VOIPOrderRequest;
import com.vz.esap.translation.order.service.helper.OrderServiceHelper;
import com.vz.esap.translation.util.OrderUtility;

import EsapEnumPkg.WorkOrderEnum;
import org.springframework.stereotype.Component;

@Component
public class EnterpriseTblOrderDataTransformerImpl implements EnterpriseTblOrderDataTransformer {

	private static final Logger LOG = LoggerFactory.getLogger(EnterpriseTblOrderDataTransformerImpl.class);

	@Autowired
	private CustomCustomerMapper customCustomerMapper;

	@Autowired
	private CustomTblOrderPrioritySettingsMapper customTblOrderPrioritySettingsMapper;
	
	@Autowired
	private OrderServiceHelper orderServiceHelperImpl;
	
	@Value("${source.address}")
	private String sourceAddress;

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.vz.esap.translation.order.transformer.EnterpriseTblOrderDataTransformer#
	 * prepareTblOrderData(com.vz.esap.translation.order.model.request.
	 * VOIPOrderRequest, com.vz.esap.translation.dao.model.TblEnvOrder)
	 */
	@SuppressWarnings("static-access")
	@Override
	public TblOrder prepareTblOrderData(VOIPOrderRequest voipOrderRequest, TblEnvOrder tblEnvOrder) {
		LOG.error("EnterpriseTblOrderDataTransformerImpl - prepareTblOrderData");
		TblOrder tblOrder = new TblOrder();

		long orderId = customCustomerMapper.getOrderIdSeqNextVal();

		tblOrder.setOrderId(orderId);
		tblOrder.setEnvOrderId(tblEnvOrder.getEnvOrderId());
		tblOrder.setPrevPassOrderId(0L);
		if (voipOrderRequest.getOrderHeader().getOriginatingSystem() == null) {
			tblOrder.setDestSystem("PC");
		} else {
			tblOrder.setDestSystem(voipOrderRequest.getOrderHeader().getOriginatingSystem());
		}
		tblOrder.setApptypeId(42L);
		tblOrder.setOrderStatus(102L);
		tblOrder.setPrevOrderStatus(null);
		tblOrder.setWorkGroup(null);
		// tblOrder.setPriority(42L);// created based on duedate,...
		tblOrder.setPriority(getOrderPriority(tblEnvOrder.getEnvOrderId(), voipOrderRequest, tblEnvOrder.getProjectId(),
				tblEnvOrder.getOrderType()));
		
		LOG.info("sourceAddress : {}", sourceAddress);
		tblOrder.setSourceSystem(sourceAddress);
		
		tblOrder.setSourceService(null);
		tblOrder.setManualOrder("N");
		tblOrder.setCompletedDate("");
		tblOrder.setFailedDate("");
		tblOrder.setVzId("");
		tblOrder.setResponseReqd(null);
		tblOrder.setStartDate("");
		tblOrder.setUpdatedDate(null);
		tblOrder.setUpstreamWoId(voipOrderRequest.getOrderHeader().getWorkOrderNumber());
		tblOrder.setUpstreamFlowId(voipOrderRequest.getOrderHeader().getEnterpriseId());
		tblOrder.setUpstreamTaskId(orderServiceHelperImpl
				.getUpstreamTaskIdFromFunctionCode(voipOrderRequest.getOrderHeader().getFunctionCode()));
		tblOrder.setTdn(null);
		tblOrder.setNpa("");
		tblOrder.setClli("CLLI");
		tblOrder.setTimezoneOffset("0");
		tblOrder.setCatalog(voipOrderRequest.getOrderHeader().getOriginatingSystem());
		tblOrder.setWireCenter(null);
		tblOrder.setParentOrder(0L);
		tblOrder.setTranslatorId("");
		tblOrder.setLockedFromStatus(null);
		tblOrder.setLockedByVzId(null);
		tblOrder.setReturnStatus(null);
		tblOrder.setCos("");
		tblOrder.setAccountNumber("Validation");
		tblOrder.setTransactionNumber(voipOrderRequest.getOrderHeader().getTransactionID());
		tblOrder.setVersionNo(voipOrderRequest.getOrderHeader().getWorkOrderVersion());
		tblOrder.setFlowPath("F");
		tblOrder.setOrderType(voipOrderRequest.getOrderHeader().getOrderType().substring(0, 1));

		if (voipOrderRequest.getOrderHeader().getMinorOrderType() != null) {
			tblOrder.setMinorOrderType(voipOrderRequest.getOrderHeader().getMinorOrderType().substring(0, 1));
		} else {
			tblOrder.setMinorOrderType(voipOrderRequest.getOrderHeader().getOrderType());
		}
		tblOrder.setSoacsCode(null);
		tblOrder.setAction("");
		tblOrder.setApsState(0L);
		tblOrder.setExk("");

		if (null != voipOrderRequest.getOrderHeader().getCentrexType() && OrderUtility
				.isOneOf(voipOrderRequest.getOrderHeader().getCentrexType(), true, "IPAC", "IPAC1", "IPAC2")) {
			tblOrder.setProjectId("RA");
		} else {
			tblOrder.setProjectId("R");
		}
		tblOrder.setErrorCode("");
		return tblOrder;
	}

	/**
	 * @param envOrderId
	 * @param voipOrderRequest
	 * @param projectId
	 * @param orderType
	 * @return priority
	 */
	private Long getOrderPriority(Long envOrderId, VOIPOrderRequest voipOrderRequest, String projectId,
			long orderType) {
		long priority = 20;
		HashMap<String, String> ordPrioCols = new HashMap<String, String>();
		ordPrioCols.put("ProjectId", projectId);
		ordPrioCols.put("ORDER_SOURCE", voipOrderRequest.getOrderHeader().getOriginatingSystem());
		ordPrioCols.put("ORDER_TYPE", OrderUtility.getOrderTypeChar((int) orderType));
		if (voipOrderRequest.getOrderHeader().getMinorOrderType() != null)
			ordPrioCols.put("MINOR_ORDER_TYPE", voipOrderRequest.getOrderHeader().getMinorOrderType().substring(0, 1));
		ordPrioCols.put("FUNCTION_CODE",
				WorkOrderEnum.OrderClassify.acronym(voipOrderRequest.getOrderHeader().getOrderClassify()));
		ordPrioCols.put("BULK_ORDER", voipOrderRequest.getOrderHeader().getBulkOrder());
		ordPrioCols.put("EXPEDITE", voipOrderRequest.getOrderHeader().getExpedite() == true ? "1" : "0");

		List<TblOrderPrioritySettings> tblOrderPrioritySettingsList = getOrderPrioritySettings(ordPrioCols);

		if (tblOrderPrioritySettingsList.size() > 0) {
			for (TblOrderPrioritySettings tblOrderPrioritySettings : tblOrderPrioritySettingsList) {
				priority = tblOrderPrioritySettings.getPriority();
				break;
			}
		}

		return priority;
	}

	/**
	 * @param ordPrioCols
	 * @return tblOrderPrioritySettingsList
	 */
	public List<TblOrderPrioritySettings> getOrderPrioritySettings(HashMap<String, String> ordPrioCols) {
		LOG.info("Entered getOrderPrioritySettings apii");
		List<TblOrderPrioritySettings> tblOrderPrioritySettingsList = new ArrayList<TblOrderPrioritySettings>();
		tblOrderPrioritySettingsList = customTblOrderPrioritySettingsMapper.getOrderPrioritySettings(ordPrioCols);
		LOG.info("Exit getOrderPrioritySettings apii");
		return tblOrderPrioritySettingsList;
	}

	public CustomCustomerMapper getCustomCustomerMapper() {
		return customCustomerMapper;
	}

	public void setCustomCustomerMapper(CustomCustomerMapper customCustomerMapper) {
		this.customCustomerMapper = customCustomerMapper;
	}

	public CustomTblOrderPrioritySettingsMapper getCustomTblOrderPrioritySettingsMapper() {
		return customTblOrderPrioritySettingsMapper;
	}

	public void setCustomTblOrderPrioritySettingsMapper(
			CustomTblOrderPrioritySettingsMapper customTblOrderPrioritySettingsMapper) {
		this.customTblOrderPrioritySettingsMapper = customTblOrderPrioritySettingsMapper;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.vz.esap.translation.order.transformer.EnterpriseTblOrderDataTransformer#
	 * prepareTblOrderDataFromOrder(com.vz.esap.translation.order.model.Order,
	 * java.lang.Long)
	 */
	@Override
	public TblOrder prepareTblOrderDataFromOrder(Order order, Long orderEntity) throws GenericException {
		LOG.info("Entered - prepareTblOrderDataFromOrder");
		// EsapEnumPkg.VzbVoipEnum.OrderEntity.ENTERPRISE
		TblOrder tblOrder = null;
		long orderId = -1;
		long priority = -1;
		String tblOrderType = null;

		try {
			tblOrder = new TblOrder();
			orderId = customCustomerMapper.getOrderIdSeqNextVal();

			tblOrder.setOrderId(orderId);
			tblOrder.setEnvOrderId(order.getOrderHeader().getEnvOrderId());
			tblOrder.setPrevPassOrderId(null); // : TODO Get Prev Pass
			
			if ("GUI".equals(order.getOrderHeader().getInterfaceSystem())) {
				tblOrder.setDestSystem("WEB");
			} else {
				// tblOrder.setDestSystem(order.getOrderHeader().getInterfaceSystem());
				// TODO Make this dynamic
				tblOrder.setDestSystem("PC");
			}
			
			priority = getOrderPriorityForOrder(order);

			tblOrder.setPriority(priority);
			tblOrder.setApptypeId(priority);
			tblOrder.setOrderStatus(Long.valueOf(order.getOrderHeader().getOrderStatus()));
			tblOrder.setPrevOrderStatus(null);
			tblOrder.setWorkGroup(null);
			LOG.info("sourceAddress : {}", sourceAddress);
			tblOrder.setSourceSystem(sourceAddress);
			tblOrder.setSourceService(null);
			tblOrder.setManualOrder("N");
			tblOrder.setCompletedDate("");
			tblOrder.setFailedDate("");
			tblOrder.setVzId("");
			tblOrder.setResponseReqd(null);
			tblOrder.setStartDate("");
			tblOrder.setUpdatedDate(null);
			tblOrder.setUpstreamWoId(order.getOrderHeader().getOrderNumber());
			// tblOrder.setUpstreamFlowId(order.getCustomer().getCustomerId());
			tblOrder.setUpstreamTaskId(orderEntity);
			tblOrder.setTdn(null);// :TODO Fix this BaseOrder.persist()
			tblOrder.setNpa("");
			tblOrder.setClli("CLLI");
			tblOrder.setTimezoneOffset("0");
			tblOrder.setCatalog(order.getOrderHeader().getOriginatingSystem());
			tblOrder.setWireCenter(null);
			tblOrder.setParentOrder(0L);
			tblOrder.setTranslatorId("");
			tblOrder.setLockedFromStatus(null);
			tblOrder.setLockedByVzId(null);
			tblOrder.setReturnStatus(null);
			tblOrder.setCos(""); // : TODO Need change
			
			if(order.getOrderHeader().getFunctionCode().equals(OrderPass.VALIDATE)) {
				tblOrder.setAccountNumber("Validation");
			} else if (Arrays
					.asList(OrderPass.RELEASE.toString(), OrderPass.REL_SUSPEND.toString(),
							OrderPass.REL_DEACTIVATE.toString(), OrderPass.LNP_ACTIVATE.toString())
					.contains(order.getOrderHeader().getFunctionCode())) {

				if(orderEntity == OrderEntity.ENTERPRISE.ordinal())
					tblOrder.setAccountNumber(order.getCustomerEntity().getCustomerName());
				if(orderEntity == OrderEntity.LOCATION.ordinal())
					tblOrder.setAccountNumber(order.getLocationEntity().getLocationId());
				if(orderEntity == OrderEntity.ENTERPRISE_TRUNK.ordinal())
					tblOrder.setAccountNumber(order.getEnterpriseTrunkEntities().get(0).getEnterpriseTrunkName());
				if(orderEntity == OrderEntity.TWO_WAY.ordinal())
					tblOrder.setAccountNumber(order.getTrunkGroupEntity().getName());
				if(orderEntity == OrderEntity.INBOUND.ordinal())
					tblOrder.setAccountNumber(order.getTrunkGroupEntity().getName());
				if(orderEntity == OrderEntity.DEVICE.ordinal())
					tblOrder.setAccountNumber(order.getDeviceEntity().getBwDeviceId());	
				if(orderEntity == OrderEntity.SONUS_NBS.ordinal()) {
					tblOrder.setAccountNumber(order.getNbsEntity().getNbsType().toString());
					}
				if(orderEntity == OrderEntity.SYSTEM_UPDATE.ordinal()) {					
					
					if (order.getGroupTnEntity() != null && order.getGroupTnEntity().getTnRecord() != null
							&& order.getGroupTnEntity().getTnRecord().getTn() != null) {
						
						LOG.info("System Update TN Type = {}", order.getGroupTnEntity().getTnRecord().getTnType());
						
						tblOrder.setAccountNumber(order.getGroupTnEntity().getTnRecord().getTnType().toString());
						
					} else {
						tblOrder.setAccountNumber(order.getOrderHeader().getVoipLocationId());
					}
				}					
				if(orderEntity == OrderEntity.TWO_WAY_TN.ordinal() 
						|| orderEntity == OrderEntity.INBOUND_TN.ordinal()
						|| orderEntity == OrderEntity.DID_TN.ordinal() 
						|| orderEntity == OrderEntity.LINE_TN.ordinal())
					tblOrder.setAccountNumber(order.getGroupTnEntity().getTnRecord().getTn());
				if(orderEntity == OrderEntity.LINE.ordinal())
					tblOrder.setAccountNumber(order.getTrunkGroupEntity().getName());
				if(orderEntity == OrderEntity.PRI_DID.ordinal())
					tblOrder.setAccountNumber(order.getTrunkGroupEntity().getName());
				if(orderEntity == OrderEntity.NON_PRI_DID.ordinal())
					tblOrder.setAccountNumber(order.getTrunkGroupEntity().getName());
				
			}
				
			
			tblOrder.setTransactionNumber(order.getOrderHeader().getTransactionId().toString());
			tblOrder.setVersionNo(order.getOrderHeader().getOrderVersion());
			tblOrder.setFlowPath(FlowPath.F.toString()); // : TODO Need Change
			//tblOrder.setOrderType(order.getOrderHeader().getOrderType().substring(0, 1));
			
			if (order.getGroupTnEntity() != null
					&& "ADD".equalsIgnoreCase(order.getGroupTnEntity().getEntityAction())) {
				tblOrderType = "I";

			} else if (order.getGroupTnEntity() != null
					&& ("REMOVE".equalsIgnoreCase(order.getGroupTnEntity().getEntityAction())
							||"CANCEL".equalsIgnoreCase(order.getGroupTnEntity().getEntityAction()))) {
				tblOrderType = "O";

			} else {
				tblOrderType = orderServiceHelperImpl.getVoipOrderType(order.getOrderHeader().getOrderType());

			}
			
			
			tblOrder.setOrderType(tblOrderType);

			if (order.getOrderHeader().getMinorOrderType() != null) {
				tblOrder.setMinorOrderType(order.getOrderHeader().getMinorOrderType().substring(0, 1));
			} else {
				tblOrder.setMinorOrderType(order.getOrderHeader().getOrderType());
			}
			
			tblOrder.setSoacsCode(null); // :TODO Need Change
			tblOrder.setAction("");
			tblOrder.setApsState(0L); // :TODO Need Change
			tblOrder.setExk("");

			if (null != order.getOrderHeader().getCentrexType()
					&& OrderUtility.isOneOf(order.getOrderHeader().getCentrexType(), true, "IPAC", "IPAC1", "IPAC2")) {
				tblOrder.setProjectId("RA");
			} else {
				tblOrder.setProjectId("R");
			}
			
			tblOrder.setErrorCode("");
			
		}catch (Exception e) {
			LOG.error("Exception {} ", e);
			throw new GenericException(GenericException.GENERIC_EXCEPTION,
					"Exception occured in getEnterpriseInformationFromGchId");
		}
		LOG.info("Exit - prepareTblOrderDataFromOrder");
		return tblOrder;
	}

	/**
	 * @param order
	 * @return priority
	 */
	private Long getOrderPriorityForOrder(Order order) {
		long priority = 20;
		HashMap<String, String> ordPrioCols = new HashMap<String, String>();
		ordPrioCols.put("ProjectId", order.getOrderHeader().getProjectId());
		ordPrioCols.put("ORDER_SOURCE", order.getOrderHeader().getOriginatingSystem());
		ordPrioCols.put("ORDER_TYPE", OrderUtility.getOrderTypeChar(order.getOrderHeader().getEnvOrderType()));
		if (order.getOrderHeader().getMinorOrderType() != null)
			ordPrioCols.put("MINOR_ORDER_TYPE", order.getOrderHeader().getMinorOrderType().substring(0, 1));
		ordPrioCols.put("FUNCTION_CODE",
				WorkOrderEnum.OrderClassify.acronym(order.getOrderHeader().getOrderClassify()));
		ordPrioCols.put("BULK_ORDER", order.getOrderHeader().getBulkOrder());
		ordPrioCols.put("EXPEDITE", order.getOrderHeader().isExpedite() == true ? "1" : "0");

		List<TblOrderPrioritySettings> tblOrderPrioritySettingsList = getOrderPrioritySettings(ordPrioCols);

		if (tblOrderPrioritySettingsList.size() > 0) {
			for (TblOrderPrioritySettings tblOrderPrioritySettings : tblOrderPrioritySettingsList) {
				priority = tblOrderPrioritySettings.getPriority();
				break;
			}
		}

		return priority;
	}

}
