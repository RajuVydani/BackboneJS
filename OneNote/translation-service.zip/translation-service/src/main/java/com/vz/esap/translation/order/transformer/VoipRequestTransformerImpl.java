package com.vz.esap.translation.order.transformer;

import static java.util.Arrays.stream;

import java.math.BigInteger;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.validation.FieldError;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.vz.esap.translation.connector.model.DBServiceResponse;
import com.vz.esap.translation.connector.model.TblRow;
import com.vz.esap.translation.dao.model.TblEnvOrder;
import com.vz.esap.translation.dao.model.TblOrder;
import com.vz.esap.translation.dao.model.TblOrderDetails;
import com.vz.esap.translation.dao.repository.CustomCustomerMapper;
import com.vz.esap.translation.enums.EsapEnum;
import com.vz.esap.translation.enums.EsapEnum.FunctionCode;
import com.vz.esap.translation.enums.EsapEnum.OrderEntity;
import com.vz.esap.translation.enums.EsapEnum.ResourceVerb;
import com.vz.esap.translation.enums.EsapEnum.SolutionType;
import com.vz.esap.translation.enums.EsapEnum.TrunkGroupType;
import com.vz.esap.translation.exception.BadRequestException;
import com.vz.esap.translation.exception.TranslatorException;
import com.vz.esap.translation.exception.TranslatorException.ErrorCode;
import com.vz.esap.translation.order.dao.VOIPOrderDao;
import com.vz.esap.translation.order.entity.identifier.util.EntityIdentifireUtil;
import com.vz.esap.translation.order.model.Order;
import com.vz.esap.translation.order.model.OrderHeader;
import com.vz.esap.translation.order.model.request.Feature;
import com.vz.esap.translation.order.model.request.Specification;
import com.vz.esap.translation.order.model.request.VOIPOrderRequest;
import com.vz.esap.translation.order.parser.OrderParser;
import com.vz.esap.translation.order.service.VOIPResponseGenerator;
import com.vz.esap.translation.order.service.helper.OrderServiceHelper;
import com.vz.esap.translation.util.InventoryUtil;

import EsapEnumPkg.WorkOrderEnum;

@Component
public class VoipRequestTransformerImpl implements VoipRequestTransformer {

	@Autowired
	private EntityIdentifireUtil entityIdentifireUtil;

	@Autowired
	private CustomCustomerMapper customCustomerMapper;

	@Autowired
	private InventoryUtil inventoryUtil;
	
	@Autowired
	private OrderServiceHelper orderServiceHelperImpl;

	@Autowired
	private VOIPResponseGenerator voipResponseGenerator;

	@Autowired
	private OrderParser orderParserImpl;
	
	@Autowired
	private VOIPOrderDao voipOrderDaoImpl;
	
	private static final Logger LOG = LoggerFactory.getLogger(VoipRequestTransformerImpl.class);

	private ObjectMapper mapper = new ObjectMapper();

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.vz.esap.translation.order.transformer.VoipRequestTransformer#
	 * transformVoipOrderRequestToOrder(com.vz.esap.translation.order.model.request.
	 * VOIPOrderRequest)
	 */
	@Override
	public Order transformVoipOrderRequestToOrder(VOIPOrderRequest voipOrderRequest) throws TranslatorException {
		LOG.info("Entered transformVoipOrderRequestToOrder");
		Order order = null;
		OrderHeader orderHeader = null;
		Date dueDate = null;

		try {

			order = new Order();

			orderHeader = new OrderHeader();
			orderHeader.setOriginatingSystem(voipOrderRequest.getOrderHeader().getOriginatingSystem());
			orderHeader.setOrderType(voipOrderRequest.getOrderHeader().getOrderType());
			orderHeader.setFunctionCode(voipOrderRequest.getOrderHeader().getFunctionCode());
			orderHeader.setGchId(voipOrderRequest.getOrderHeader().getGCHId());
			orderHeader.setNASPId(voipOrderRequest.getOrderHeader().getNASPId());
			orderHeader.setEnterpriseId(voipOrderRequest.getOrderHeader().getEnterpriseId());
			orderHeader.setTransactionId(new BigInteger(voipOrderRequest.getOrderHeader().getTransactionID()));
			orderHeader.setLastSegment(voipOrderRequest.getOrderHeader().getLastSegment());

			dueDate = new SimpleDateFormat("dd-MMM-yy").parse(voipOrderRequest.getOrderHeader().getDueDate());
			orderHeader.setDueDate(dueDate);

			orderHeader.setMsgSegmentNo(voipOrderRequest.getOrderHeader().getMsgSegmentNo());
			orderHeader.setVoipLocationId(voipOrderRequest.getOrderHeader().getVoipLocationId());
			orderHeader.setMinorOrderType(voipOrderRequest.getOrderHeader().getMinorOrderType());
			orderHeader.setWorkOrderNumber(voipOrderRequest.getOrderHeader().getWorkOrderNumber());
			orderHeader.setWorkOrderVersion(voipOrderRequest.getOrderHeader().getWorkOrderVersion());

		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new TranslatorException(ErrorCode.TRANSFORMER_FAILURE,
					"Exception occured in transformVoipOrderRequestToOrder");
		}
		LOG.info("Exit transformVoipOrderRequestToOrder");
		return order;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.vz.esap.translation.order.transformer.VoipRequestTransformer#
	 * enrichVoipRequestWithEnterprise(com.vz.esap.translation.order.model.request.
	 * VOIPOrderRequest, java.util.Map,
	 * com.vz.esap.translation.connector.model.DBServiceResponse, boolean)
	 */

	@Override
	public VOIPOrderRequest enrichVoipRequestWithEnterprise(VOIPOrderRequest voipOrderRequest,
			Map<String, String> productDetails, DBServiceResponse dbServiceResponse, boolean isNewCustomer)
			throws TranslatorException {
		LOG.info("Entered enrichVoipRequestWithEnterprise");
		Feature[] newFeatures = null;

		try {
			voipOrderRequest = modifyOrderHeader(voipOrderRequest, dbServiceResponse, isNewCustomer, productDetails);

			newFeatures = createAndAddEnterpriseFeature(voipOrderRequest, dbServiceResponse, isNewCustomer);
			voipOrderRequest.getConvergedService().setFeature(newFeatures);

			LOG.info("Voip Order Request Enriched with Enterprise: {}",
					mapper.writerWithDefaultPrettyPrinter().writeValueAsString(voipOrderRequest));

		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new TranslatorException(ErrorCode.TRANSFORMER_FAILURE,
					"Exception occured in enrichVoipRequestWithEnterprise");
		}

		LOG.info("Exited enrichVoipRequestWithEnterprise");
		return voipOrderRequest;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.vz.esap.translation.order.transformer.VoipRequestTransformer#
	 * modifyOrderHeader(com.vz.esap.translation.order.model.request.
	 * VOIPOrderRequest, com.vz.esap.translation.connector.model.DBServiceResponse,
	 * boolean, java.util.Map)
	 */
	@Override
	public VOIPOrderRequest modifyOrderHeader(VOIPOrderRequest voipOrderRequest, DBServiceResponse dbServiceResponse,
			boolean isNewCustomer, Map<String, String> productDetails) throws TranslatorException {
		LOG.info("Entered modifyOrderHeader");

		String enterpriseId = null;
		String bwEnterpriseId = null;
		String bsAppServer = null;

		try {

			if (isNewCustomer) {
				enterpriseId = entityIdentifireUtil.createPqInstanceEnterpriseId();
			} else {
				for (TblRow tblRows : dbServiceResponse.getTableRows()) {
					enterpriseId = tblRows.getTblRow().get("ENTERPRISE_ID").getValue();
					bwEnterpriseId = tblRows.getTblRow().get("BW_ENTERPRISE_ID").getValue();

					LOG.info("Enterprise Id : {}", enterpriseId);
					LOG.info("BW Enterprise Id : {}", bwEnterpriseId);
				}
			}

			if (productDetails.get("SolutionType").equalsIgnoreCase(SolutionType.ESIP_ESL.toString()))
				voipOrderRequest.getOrderHeader().setSolutionType(SolutionType.ESIP_ESL);
			else if (productDetails.get("SolutionType").equalsIgnoreCase(SolutionType.ESIP_EBL.toString()))
				voipOrderRequest.getOrderHeader().setSolutionType(SolutionType.ESIP_EBL);
			else if (productDetails.get("SolutionType").equalsIgnoreCase(SolutionType.IPFLEX.toString()))
				voipOrderRequest.getOrderHeader().setSolutionType(SolutionType.IPFLEX);
			else if (productDetails.get("SolutionType").equalsIgnoreCase(SolutionType.HPBX.toString()))
				voipOrderRequest.getOrderHeader().setSolutionType(SolutionType.HPBX);

			voipOrderRequest.getOrderHeader().setEnterpriseId(enterpriseId);
			voipOrderRequest.getOrderHeader().setLocationId(voipOrderRequest.getOrderHeader().getVoipLocationId());			
			voipOrderRequest.getOrderHeader().setBwEnterpriseId(bwEnterpriseId);

		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new TranslatorException(ErrorCode.TRANSFORMER_FAILURE, "Exception occured in modifyOrderHeader");
		}
		LOG.info("Exited modifyOrderHeader");
		return voipOrderRequest;
	}

	/**
	 * @param voipOrderRequest
	 * @param dbServiceResponse
	 * @param isNewCustomer
	 * @return newFeatureArray
	 * @throws TranslatorException
	 */
	private Feature[] createAndAddEnterpriseFeature(VOIPOrderRequest voipOrderRequest,
			DBServiceResponse dbServiceResponse, boolean isNewCustomer) throws TranslatorException {
		LOG.info("Entered createAndAddEnterpriseFeature");
		Feature[] newFeatureArray = null;
		Feature[] oldFeatureArray = null;
		Feature featureEnterprise = null;
		try {
			oldFeatureArray = voipOrderRequest.getConvergedService().getFeature();

			featureEnterprise = new Feature();
			featureEnterprise.setInstanceId(voipOrderRequest.getOrderHeader().getEnterpriseId());
			featureEnterprise.setCode("EFET_VOIP_ENT_LVL");
			featureEnterprise.setName("Enterprise level");

			for (Feature feature : oldFeatureArray) {
				if ("FET_LOC_LVL".equalsIgnoreCase(feature.getCode())
						|| "FET_HPBX_LOC_LVL".equalsIgnoreCase(feature.getCode()))
					featureEnterprise.setActionCode(feature.getActionCode());
			}

			Specification[] specifications = createEnterpriseSpecification(voipOrderRequest, dbServiceResponse,
					isNewCustomer);
			featureEnterprise.setSpecification(specifications);

			newFeatureArray = Arrays.copyOf(oldFeatureArray, oldFeatureArray.length + 1);
			newFeatureArray[oldFeatureArray.length] = featureEnterprise;

		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new TranslatorException(ErrorCode.TRANSFORMER_FAILURE,
					"Exception occured in transformVoipOrderRequestToOrder");
		}

		LOG.info("Exited createAndAddEnterpriseFeature");
		return newFeatureArray;
	}

	/**
	 * @param voipOrderRequest
	 * @param dbServiceResponse
	 * @param isNewCustomer
	 * @return
	 * @throws TranslatorException
	 */
	private Specification[] createEnterpriseSpecification(VOIPOrderRequest voipOrderRequest,
			DBServiceResponse dbServiceResponse, boolean isNewCustomer) throws TranslatorException {
		LOG.info("Entered createEnterpriseSpecification");
		Specification[] specifications = null;
		List<Specification> specList = null;
		Specification admBwEntId = null;
		Specification tsoSpec = null;
		Specification sipSpec = null;
		Specification featTypeSpec = null;
		Specification admEmailSpec = null;
		Specification admFnSpec = null;
		Specification admLogInSpec = null;
		Specification admLnSpec = null;
		Specification admPwdSpec = null;
		Specification admEntName = null;
		Specification admEntCountry = null;
		Specification admEntState = null;
		Specification admEntRegion = null;
		List<Map<String, String>> resultantInvRows = null;
		String sipDomain = null;

		try {
			specList = new ArrayList<>();

			String bwEnterpriseId = null;
			if (isNewCustomer && !SolutionType.HPBX.equals(voipOrderRequest.getOrderHeader().getSolutionType())) {
				bwEnterpriseId = entityIdentifireUtil.createBwEnterpriseId(voipOrderRequest.getOrderHeader().getGCHId(),
						voipOrderRequest.getOrderHeader().getSolutionType(), null,
						voipOrderRequest.getOrderHeader().getEnterpriseId());

			} else if (isNewCustomer && SolutionType.HPBX.equals(voipOrderRequest.getOrderHeader().getSolutionType())) {
				resultantInvRows = inventoryUtil.getCurrentHpbxNniDetails();
				
				if(resultantInvRows != null && !resultantInvRows.isEmpty() && resultantInvRows.get(0).get("HPBX_NNI") != null)
					bwEnterpriseId = resultantInvRows.get(0).get("HPBX_NNI");
				else
					throw new TranslatorException(ErrorCode.DATA_NOT_FOUND, "HPBX Active NNI Not Found");
			} else {
				for (TblRow tblRows : dbServiceResponse.getTableRows()) {
					bwEnterpriseId = tblRows.getTblRow().get("BW_ENTERPRISE_ID").getValue();
					LOG.info("BW Enterprise Id : {}", bwEnterpriseId);
				}
			}
			
			if(SolutionType.HPBX.equals(voipOrderRequest.getOrderHeader().getSolutionType())) {
				sipDomain = entityIdentifireUtil.getHpbxDomainName();
						
			}else {
				sipDomain = bwEnterpriseId.toLowerCase() + ".vm.xohost.com";
						
			}

			admBwEntId = new Specification();
			admBwEntId.setCode("BW_ENTERPRISE_ID");
			admBwEntId.setName("Enterprise State");
			admBwEntId.setValue(bwEnterpriseId);
			specList.add(admBwEntId);

			tsoSpec = new Specification();
			tsoSpec.setCode("SP_VOIP_SERVICE_OPT");
			tsoSpec.setName("Service Optimization");
			tsoSpec.setValue("No");
			specList.add(tsoSpec);

			sipSpec = new Specification();
			sipSpec.setCode("ESP_SIP_DOMAIN");
			sipSpec.setName("SIP Domain");
			sipSpec.setValue(sipDomain);
			specList.add(sipSpec);

			featTypeSpec = new Specification();
			featTypeSpec.setCode("SP_TYPE_OF_FEATURE");
			featTypeSpec.setName("Type of Feature");
			featTypeSpec.setValue("Base Feature");
			specList.add(featTypeSpec);

			admEmailSpec = new Specification();
			admEmailSpec.setCode("ESP_ADM_EMAIL");
			admEmailSpec.setName("Admin EMail");
			admEmailSpec.setValue(bwEnterpriseId.toLowerCase());
			specList.add(admEmailSpec);

			admFnSpec = new Specification();
			admFnSpec.setCode("ESP_ADM_FST_NAME");
			admFnSpec.setName("Admin First Name");
			admFnSpec.setValue(bwEnterpriseId);
			specList.add(admFnSpec);

			admLogInSpec = new Specification();
			admLogInSpec.setCode("ESP_ADM_LOGIN_ID");
			admLogInSpec.setName("Admin Web Login ID");
			admLogInSpec.setValue(bwEnterpriseId.toLowerCase());
			specList.add(admLogInSpec);

			admLnSpec = new Specification();
			admLnSpec.setCode("ESP_ADM_LST_NAME");
			admLnSpec.setName("Admin Last Name");
			admLnSpec.setValue(bwEnterpriseId);
			specList.add(admLnSpec);

			admPwdSpec = new Specification();
			admPwdSpec.setCode("ESP_ADM_PW");
			admPwdSpec.setName("Admin Password");
			admPwdSpec.setValue(bwEnterpriseId);
			specList.add(admPwdSpec);

			admEntName = new Specification();
			admEntName.setCode("ESP_ENTERPRISE_NAME");
			admEntName.setName("Enterprise Name");
			admEntName.setValue(bwEnterpriseId);
			specList.add(admEntName);

			admEntCountry = new Specification();
			admEntCountry.setCode("ESP_ENT_COUNTRY");
			admEntCountry.setName("Enterprise Country");
			admEntCountry.setValue(voipOrderRequest.getLocation().getLocationAddress().getCountryName());
			specList.add(admEntCountry);

			admEntState = new Specification();
			admEntState.setCode("ESP_ENT_STATE");
			admEntState.setName("Enterprise State");
			admEntState.setValue(voipOrderRequest.getLocation().getLocationAddress().getState());
			specList.add(admEntState);

			admEntRegion = new Specification();
			admEntRegion.setCode("ESP_REGION");
			admEntRegion.setName("Region");
			admEntRegion.setValue(voipOrderRequest.getLocation().getLocationAddress().getCountryCode());
			specList.add(admEntRegion);

			specifications = specList.toArray(new Specification[specList.size()]);

		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new TranslatorException(ErrorCode.TRANSFORMER_FAILURE,
					"Exception occured in transformVoipOrderRequestToOrder");
		}

		LOG.info("Exited createEnterpriseSpecification");
		return specifications;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.vz.esap.translation.order.transformer.VoipRequestTransformer#
	 * enrichVoipRequestWithEt(com.vz.esap.translation.order.model.request.
	 * VOIPOrderRequest, java.util.Map,
	 * com.vz.esap.translation.connector.model.DBServiceResponse, boolean)
	 */
	@Override
	public VOIPOrderRequest enrichVoipRequestWithEt(VOIPOrderRequest voipOrderRequest,
			Map<String, String> productDetails, DBServiceResponse dbServiceResponse, boolean isNewCustomer)
			throws TranslatorException {
		LOG.info("Entered enrichVoipRequestWithEt");
		Feature[] newFeatures = null;

		try {

			newFeatures = createAndAddEtFeature(voipOrderRequest, dbServiceResponse, isNewCustomer);
			voipOrderRequest.getConvergedService().setFeature(newFeatures);
			LOG.info("Voip Order Request Enriched with ET : {}",
					mapper.writerWithDefaultPrettyPrinter().writeValueAsString(voipOrderRequest));

		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new TranslatorException(ErrorCode.TRANSFORMER_FAILURE,
					"Exception occured in enrichVoipRequestWithEt");
		}
		LOG.info("Exited enrichVoipRequestWithEt");
		return voipOrderRequest;
	}

	/**
	 * @param voipOrderRequest
	 * @param dbServiceResponse
	 * @param isNewCustomer
	 * @return newFeatureArray
	 * @throws TranslatorException
	 */
	private Feature[] createAndAddEtFeature(VOIPOrderRequest voipOrderRequest, DBServiceResponse dbServiceResponse,
			boolean isNewCustomer) throws TranslatorException {
		LOG.info("Entered createAndAddEtFeature");
		Feature[] newFeatureArray = null;
		String pqEslId = null;
		String bwEntId = null;
		String pqEntId = null;
		String redundncy = null;
		String cityCode = null;
		Feature[] oldFeatureArray = null;
		String actionCode = null;
		List<Feature> featureList = null;
		List<Feature> entFeat = null;
		List<Specification> bwEntIdSpec = null;
		int count = 0;
		Map<String, String> resultantRow = null;
		String bwTgId = null;
		List<Specification> bwTgSpec = null;
		String redundncyPriority = null;

		try {
			oldFeatureArray = voipOrderRequest.getConvergedService().getFeature();
			featureList = new ArrayList<>();

			if (voipOrderRequest.getLocation() != null && voipOrderRequest.getLocation().getLocationAddress() != null
					&& voipOrderRequest.getLocation().getLocationAddress().getCity() != null) {
				cityCode = voipOrderRequest.getLocation().getLocationAddress().getCity();
			}

			entFeat = stream(oldFeatureArray).filter(feat -> "EFET_VOIP_ENT_LVL".equalsIgnoreCase(feat.getCode()))
					.collect(Collectors.toList());

			if (!entFeat.isEmpty() && entFeat.get(0) != null) {
				pqEntId = entFeat.get(0).getInstanceId();

				bwEntIdSpec = stream(entFeat.get(0).getSpecification())
						.filter(spec -> "BW_ENTERPRISE_ID".equalsIgnoreCase(spec.getCode()))
						.collect(Collectors.toList());
				bwEntId = bwEntIdSpec.get(0).getValue();
			} else {
				pqEntId = voipOrderRequest.getOrderHeader().getEnterpriseId();
				bwEntId = voipOrderRequest.getOrderHeader().getBwEnterpriseId();
			}

			if(SolutionType.ESIP_ESL.equals(voipOrderRequest.getOrderHeader().getSolutionType()))
				pqEslId = voipOrderRequest.getConvergedService().getID();
			else if(SolutionType.HPBX.equals(voipOrderRequest.getOrderHeader().getSolutionType()))
				pqEslId = voipOrderRequest.getConvergedService().getID();

			for (Feature feature : oldFeatureArray) {
				if ("FET_LOC_LVL".equalsIgnoreCase(feature.getCode())) {

					List<Specification> redundancySpec = stream(feature.getSpecification())
							.filter(spec -> spec.getCode().equalsIgnoreCase("SP_XO_RED")).collect(Collectors.toList());

					if(!redundancySpec.isEmpty()) {
						redundncy = redundancySpec.get(0).getValue();
					} 
					
					List<Specification> redundancyPrioritySpec = stream(feature.getSpecification())
							.filter(spec -> spec.getCode().equalsIgnoreCase("SP_XO_REDPT")).collect(Collectors.toList());

					if(!redundancyPrioritySpec.isEmpty()) {
						redundncyPriority = redundancyPrioritySpec.get(0).getValue();
					} 
				}

				if ("FET_XO_TRU".equalsIgnoreCase(feature.getCode())
						|| "FET_HPBX_TRU_LOC".equalsIgnoreCase(feature.getCode())) {
					actionCode = feature.getActionCode();

					Feature featureEt = new Feature();

					if ("C".equalsIgnoreCase(voipOrderRequest.getOrderHeader().getOrderType())
							&& Arrays.asList("CHANGE", "NONE").contains(actionCode)) {
						resultantRow = inventoryUtil.getEnterpriseTrunkFromTrunkId(feature.getInstanceId(), null, null);

						if (resultantRow != null && resultantRow.get("ENTERPRISE_TRUNK_ID") != null) {
							featureEt.setInstanceId(resultantRow.get("ENTERPRISE_TRUNK_ID"));

						} else {
							featureEt.setInstanceId(entityIdentifireUtil.createPqInstanceEtId());

						}
					} else {
						featureEt.setInstanceId(entityIdentifireUtil.createPqInstanceEtId());
					}

					featureEt.setCode("EFET_VOIP_ENT_TRUNK");
					featureEt.setName("Enterprise Trunk");
					featureEt.setActionCode(actionCode);
					
					bwTgSpec = stream(feature.getSpecification())
							.filter(spec -> spec.getCode().equalsIgnoreCase("SP_XO_BW_TRUNK_ID_LOC"))
							.collect(Collectors.toList());
					
					if(!bwTgSpec.isEmpty()) {
						bwTgId = bwTgSpec.get(0).getValue();					
						
					}

					Specification[] specifications = createEtSpecification(feature, dbServiceResponse, isNewCustomer,
							pqEslId, bwEntId, pqEntId, cityCode, redundncy, actionCode, resultantRow, bwTgId, redundncyPriority);
					featureEt.setSpecification(specifications);

					featureList.add(featureEt);
					
					LOG.info("ET Feature  : {} , Size : {}",
							mapper.writerWithDefaultPrettyPrinter().writeValueAsString(featureEt), featureList.size());
				}
			}
			count = oldFeatureArray.length;
			newFeatureArray = Arrays.copyOf(oldFeatureArray, oldFeatureArray.length + featureList.size());
			for (Feature feature : featureList) {
				newFeatureArray[count] = feature;
				count++;
			}

			LOG.info("Complete Feature  List with ET Featues: {} ",
					mapper.writerWithDefaultPrettyPrinter().writeValueAsString(newFeatureArray));

		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new TranslatorException(ErrorCode.TRANSFORMER_FAILURE, "Exception occured in createAndAddEtFeature");
		}
		LOG.info("Exited createAndAddEtFeature");
		return newFeatureArray;
	}

	/**
	 * @param trunkGroupFeature
	 * @param dbServiceResponse
	 * @param isNewCustomer
	 * @param pqEslId
	 * @param bwEntId
	 * @param pqEntId
	 * @param cityCode
	 * @param redundancy
	 * @param action
	 * @param resultantRow
	 * @param bwTgId
	 * @param redundancyPriority TODO
	 * @return specifications
	 * @throws TranslatorException
	 */
	private Specification[] createEtSpecification(Feature trunkGroupFeature, DBServiceResponse dbServiceResponse,
			boolean isNewCustomer, String pqEslId, String bwEntId, String pqEntId, String cityCode, String redundancy,
			String action, Map<String, String> resultantRow, String bwTgId, String redundancyPriority) throws TranslatorException {
		LOG.info("Entered createEtSpecification");
		
		Specification[] specifications = null;
		List<Specification> specList = null;
		String signalingDirection = null;
		Specification etSpec = null;
		List<Map<String, String>> resultantInvRows = null;
		String bwEtId = null;

		try {
			specList = new ArrayList<>();

			for (Specification specs : trunkGroupFeature.getSpecification()) {
				if ("SP_XO_TRU_GRP_NM".equalsIgnoreCase(specs.getCode())) {
					Specification specification = new Specification();
					specification.setCode("ESP_ENT_TRUNK_NAME");
					specification.setName("Enterprise Trunk Name");
					specification.setValue(specs.getValue());
					specification.setValueCode(specs.getValueCode());
					specList.add(specification);
				}
				if ("SP_XO_SIG".equalsIgnoreCase(specs.getCode())) {

					if ("2 Way".equalsIgnoreCase(specs.getValue()))
						signalingDirection = EsapEnum.SignalingDirection.TWO_WAY.toString();
					if ("Inbound".equalsIgnoreCase(specs.getValue()))
						signalingDirection = EsapEnum.SignalingDirection.INBOUND.toString();

					Specification specification = new Specification();
					specification.setCode("SP_XO_SIG");
					specification.setName("Enterprise Trunk Signaling Direction");
					specification.setValue(signalingDirection);
					specification.setValueCode(specs.getValueCode());
					specList.add(specification);
				}
			}
			
			LOG.info("bwTgId = {}", bwTgId);
			
			if (bwTgId != null) {
				resultantInvRows = inventoryUtil.getCurrentHpbxNniDetails();

				for (Map<String, String> nniMap : resultantInvRows) {

					if (bwTgId.equalsIgnoreCase(nniMap.get("HPBX_PREBUILD_TRUNK_ID"))) {
						bwEtId = nniMap.get("HPBX_PREBUILD_ENT_TRUNK_NAME");
						redundancy = nniMap.get("REDUNCANCY_TYPE");
					}
				}
			}
			
			LOG.info("bwEtId = {}", bwEtId);
			
			etSpec = new Specification();
			etSpec.setCode("BW_ET_ID");
			etSpec.setName("Enterprise Trunk BW Id");
			
			if(bwEtId != null) {
				etSpec.setValue(bwEtId);
			} else if (action == null || "ADD".equalsIgnoreCase(action)) {
				etSpec.setValue(entityIdentifireUtil.createBwEtId(pqEslId, signalingDirection));
			} else if (action == null || "CHANGE".equalsIgnoreCase(action)) {
				etSpec.setValue(resultantRow.get("BWENTERPRISEID"));
			}				
			specList.add(etSpec);

			etSpec = new Specification();
			etSpec.setCode("BW_ENTERPRISE_ID");
			etSpec.setName("Enterprise BW Id");
			etSpec.setValue(bwEntId);
			specList.add(etSpec);

			etSpec = new Specification();
			etSpec.setCode("ENTERPRISE_ID");
			etSpec.setName("Enterprise BW Id");
			etSpec.setValue(pqEntId);
			specList.add(etSpec);

			etSpec = new Specification();
			etSpec.setCode("ENTERPRISE_SERVICE_LOCATION_ID");
			etSpec.setName("ESL BW Id");
			etSpec.setValue(pqEslId);
			specList.add(etSpec);

			etSpec = new Specification();
			etSpec.setCode("BW_TG_ID");
			etSpec.setName("TG BW Id");
			if(bwTgId != null)
				etSpec.setValue(bwTgId);
			else if (action == null || "ADD".equalsIgnoreCase(action))
				etSpec.setValue(entityIdentifireUtil.createBwTgId(bwEntId, pqEslId, signalingDirection, cityCode));
			else if (action == null || "CHANGE".equalsIgnoreCase(action))
				etSpec.setValue(resultantRow.get("TRUNKGROUPID"));
			
			specList.add(etSpec);

			etSpec = new Specification();
			etSpec.setCode("ESL_REDUNDANCY");
			etSpec.setName("ESL Redundancy");
			etSpec.setValue(redundancy);
			specList.add(etSpec);

			etSpec = new Specification();
			etSpec.setCode("ESL_REDUNDANCY_PRIORITY_TYPE");
			etSpec.setName("ESL Redundancy Priority");
			etSpec.setValue(redundancyPriority);
			specList.add(etSpec);

			specifications = specList.toArray(new Specification[specList.size()]);

		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new TranslatorException(ErrorCode.TRANSFORMER_FAILURE, "Exception occured in createEtSpecification");
		}

		LOG.info("Exited createEtSpecification");
		return specifications;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.vz.esap.translation.order.transformer.VoipRequestTransformer#
	 * enrichVoipRequestWithTrunkGroup(com.vz.esap.translation.order.model.request.
	 * VOIPOrderRequest, java.util.Map,
	 * com.vz.esap.translation.connector.model.DBServiceResponse, boolean)
	 */
	@Override
	public VOIPOrderRequest enrichVoipRequestWithTrunkGroup(VOIPOrderRequest voipOrderRequest)
			throws TranslatorException {
		LOG.info("Entered enrichVoipRequestWithTrunkGroup");
		Feature[] newFeatures = null;

		try {
			newFeatures = createAndAddTrunkGroupFeature(voipOrderRequest);
			voipOrderRequest.getConvergedService().setFeature(newFeatures);

			LOG.info("Voip Order Request Enriched with Trunk Group: {}",
					mapper.writerWithDefaultPrettyPrinter().writeValueAsString(voipOrderRequest));

		} catch (Exception e) {
			LOG.error("Exception {} ", e);
			throw new TranslatorException(ErrorCode.TRANSFORMER_FAILURE,
					"Exception occured in enrichVoipRequestWithTrunkGroup");
		}

		LOG.info("Exited enrichVoipRequestWithTrunkGroup");
		return voipOrderRequest;
	}

	/**
	 * @param voipOrderRequest
	 * @return newFeatureArray
	 * @throws TranslatorException
	 */
	private Feature[] createAndAddTrunkGroupFeature(VOIPOrderRequest voipOrderRequest) throws TranslatorException {
		LOG.info("Entered createAndAddTrunkGroupFeature");
		Feature[] newFeatureArray = null;
		Feature[] oldFeatureArray = null;
		Feature featureTg = null;
		long tgId = -1;
		List<Feature> tgFeaturesMod = null;
		String locInstanceId = null;
		String bwLocId = null;
		List<Specification> bwLocSpec = null;
		String preBuildLocId = null;
		List<Specification> preBuildLocSpec = null;
		int orderVersion = 0;

		try {
			tgFeaturesMod = new ArrayList<>();
			//HPBX Supp fix :: Govardhan
			orderVersion = Integer.parseInt(voipOrderRequest.getOrderHeader().getWorkOrderVersion());
			oldFeatureArray = voipOrderRequest.getConvergedService().getFeature();

			for (Feature origFeature : oldFeatureArray) {
				
				if ("FET_LOC_LVL".equalsIgnoreCase(origFeature.getCode())
						|| "FET_HPBX_LOC_LVL_LOC".equalsIgnoreCase(origFeature.getCode())) {
					
					if ("FET_LOC_LVL".equalsIgnoreCase(origFeature.getCode())) {
						//tgId = entityIdentifireUtil.createLineTrunkGroupId(voipOrderRequest);
						//Start : Flex Change Order Line TG fix
						
						if (orderVersion == 0 && voipOrderRequest.getOrderHeader() != null
								&& "C".equalsIgnoreCase(voipOrderRequest.getOrderHeader().getOrderType())) {
							
							LOG.info("wo# {} - LocInstanceId as Voip LocationId - {}",
									voipOrderRequest.getOrderHeader().getWorkOrderNumber(),
									voipOrderRequest.getOrderHeader().getVoipLocationId());
							
							tgId = inventoryUtil.getTrunkGroupIdFromLocationId(
									voipOrderRequest.getOrderHeader().getVoipLocationId(), TrunkGroupType.LINE.getIndex());
							
							LOG.info("tgId: {} from LocInstanceId: {}", tgId,
									voipOrderRequest.getOrderHeader().getVoipLocationId());

						} else {
							tgId = entityIdentifireUtil.createLineTrunkGroupId(voipOrderRequest);

						}
						
						//End : Flex Change Order Line TG fix						
						
					} else if ("FET_HPBX_LOC_LVL_LOC".equalsIgnoreCase(origFeature.getCode())) {
						
						if (orderVersion > 0) {
							LOG.info("wo# {} - LocInstanceId as LocationId - {}",
									voipOrderRequest.getOrderHeader().getWorkOrderNumber(),
									origFeature.getInstanceId());
							tgId = inventoryUtil.getTrunkGroupIdFromLocationId(origFeature.getInstanceId());
							LOG.info("tgId from LocInstanceId: {}", tgId);
							if (tgId == 0) {
								tgId = customCustomerMapper.getGroupIdSeqNextVal();
							}
						} else {
							tgId = customCustomerMapper.getGroupIdSeqNextVal();
						}
					}
					
					//tgId = customCustomerMapper.getGroupIdSeqNextVal();
					
					//locInstanceId = origFeature.getInstanceId();
					
					//locInstanceId = voipOrderRequest.getOrderHeader().getVoipLocationId();

					featureTg = new Feature();
					featureTg.setInstanceId(String.valueOf(tgId));
					featureTg.setActionCode(origFeature.getActionCode());
					featureTg.setName("TrunkGroup level");
					
					if(SolutionType.HPBX.equals(voipOrderRequest.getOrderHeader().getSolutionType())) {
						featureTg.setCode("FET_HPBX_TRU_LOC");
						locInstanceId = origFeature.getInstanceId();
						
					}else if(SolutionType.IPFLEX.equals(voipOrderRequest.getOrderHeader().getSolutionType())) {
						featureTg.setCode("FET_XO_TRU_CON_LINE_LOC");
						locInstanceId = voipOrderRequest.getOrderHeader().getVoipLocationId();
						
					}
					
					bwLocSpec = stream(origFeature.getSpecification())
							.filter(spec -> spec.getCode().equalsIgnoreCase("SP_XO_BW_LOC_ID"))
							.collect(Collectors.toList());	
					
					if(!bwLocSpec.isEmpty()) {
						bwLocId = bwLocSpec.get(0).getValue();
								
					}
					
					
					preBuildLocSpec = stream(origFeature.getSpecification())
							.filter(spec -> spec.getCode().equalsIgnoreCase("SP_HPBX_PREBUILD_LOC_ID"))
							.collect(Collectors.toList());	
					
					if(!preBuildLocSpec.isEmpty()) {
						preBuildLocId = preBuildLocSpec.get(0).getValue();
								
					}
					
					Specification[] specifications = createTrunkGroupSpecification(voipOrderRequest, tgId,
							locInstanceId, bwLocId, preBuildLocId);
					featureTg.setSpecification(specifications);
					
					tgFeaturesMod.add(featureTg);
					
				}
			}
			
			newFeatureArray = ArrayUtils.addAll(oldFeatureArray,
					tgFeaturesMod.toArray(new Feature[tgFeaturesMod.size()]));
			
			LOG.info("Complete Feature  List with Trunk Group Featues: {} ",
					mapper.writerWithDefaultPrettyPrinter().writeValueAsString(newFeatureArray));
			
		} catch (Exception e) {
			LOG.error("Exception {} ", e);
			throw new TranslatorException(ErrorCode.TRANSFORMER_FAILURE,
					"Exception occured in createAndAddTrunkGroupFeature");
		}

		LOG.info("Exited createAndAddTrunkGroupFeature");
		return newFeatureArray;
	}

	/**
	 * @param voipOrderRequest
	 * @param tgId
	 * @param locInstanceId
	 * @param bwLocId
	 * @param preBuildLocId TODO
	 * @return specifications
	 * @throws TranslatorException
	 */
	private Specification[] createTrunkGroupSpecification(VOIPOrderRequest voipOrderRequest, long tgId,
			String locInstanceId, String bwLocId, String preBuildLocId)			
					throws TranslatorException {
		LOG.info("Entered createTrunkGroupSpecification");
		Specification[] specifications = null;
		List<Specification> specList = null;
		Specification trunkNameSpec = null;
		Specification trunkTypeSpec = null;
		List<Feature> features = null;
		List<Map<String, String>> resultantInvRows = null;

		try {
			
			specList = new ArrayList<>();
			
			if(SolutionType.IPFLEX.equals(voipOrderRequest.getOrderHeader().getSolutionType())) {
				
				trunkNameSpec = new Specification();
				trunkNameSpec.setCode("SP_XO_TRU_GRP_NM");
				trunkNameSpec.setName("Enterprise State");
				trunkNameSpec.setValue(String.valueOf(tgId));
				specList.add(trunkNameSpec);

				trunkTypeSpec = new Specification();
				trunkTypeSpec.setCode("SP_XO_TRU_GRP_TYPE_LOC");
				trunkTypeSpec.setName("Trunk Group Type");
				trunkTypeSpec.setValue("LINE");
				specList.add(trunkTypeSpec);				
				
			} else if(SolutionType.HPBX.equals(voipOrderRequest.getOrderHeader().getSolutionType())) {
				
				resultantInvRows = inventoryUtil.getCurrentHpbxNniDetails();
				
				for (Map<String, String> map : resultantInvRows) {
					if(preBuildLocId != null && preBuildLocId.equalsIgnoreCase(map.get("HPBX_PREBUILD_LOC_ID"))) {
						
						trunkTypeSpec = new Specification();
						trunkTypeSpec.setCode("SP_XO_BW_TRUNK_ID_LOC");
						trunkTypeSpec.setName("BW Trunk Group Id");
						trunkTypeSpec.setValue(map.get("HPBX_PREBUILD_TRUNK_ID"));
						specList.add(trunkTypeSpec);
						
						trunkTypeSpec = new Specification();
						trunkTypeSpec.setCode("BW_TG_ID");
						trunkTypeSpec.setName("BW Trunk Group Id");
						trunkTypeSpec.setValue(map.get("HPBX_PREBUILD_TRUNK_ID"));
						specList.add(trunkTypeSpec);
						
					}
				}
				
				trunkTypeSpec = new Specification();
				trunkTypeSpec.setCode("SP_XO_TRU_GRP_TYPE_LOC");
				trunkTypeSpec.setName("Trunk Group Type");
				trunkTypeSpec.setValue("HPBX_ECH");
				specList.add(trunkTypeSpec);
			}
			
			trunkTypeSpec = new Specification();
			trunkTypeSpec.setCode("SP_XO_ASSO_LOC_INST_ID_LOC");
			trunkTypeSpec.setName("Associated Location In");
			trunkTypeSpec.setValue(locInstanceId);
			specList.add(trunkTypeSpec);
			
			features = stream(voipOrderRequest.getConvergedService().getFeature())
					.filter(feature -> feature.getCode().equalsIgnoreCase("FET_HPBX_TRU"))
					.collect(Collectors.toList());			
			
			if(features != null && !features.isEmpty()) {
				
				Specification locSpecs = null;
				for (Specification spec : features.get(0).getSpecification()) {
					locSpecs = new Specification();
					
					if(!"SP_XO_TRU_GRP_NM".equalsIgnoreCase(spec.getCode())) {						
						locSpecs.setCode(spec.getCode());
						locSpecs.setValue(spec.getValue());
						
					}else {
						locSpecs.setCode(spec.getCode());
						locSpecs.setValue(String.valueOf(tgId));
					}
					
					specList.add(locSpecs);
				}
			}

			specifications = specList.toArray(new Specification[specList.size()]);

		} catch (Exception e) {
			LOG.error("Exception {} ", e);
			throw new TranslatorException(ErrorCode.TRANSFORMER_FAILURE,
					"Exception occured in createTrunkGroupSpecification");
		}

		LOG.info("Exited createTrunkGroupSpecification");
		return specifications;
	}
	
	//HPBX Changes::
	
	@Override
	public VOIPOrderRequest enrichVoipRequestWithLocation(VOIPOrderRequest voipOrderRequest,
			Map<String, String> productDetails, DBServiceResponse dbServiceResponse, boolean isNewCustomer)
			throws TranslatorException {
		LOG.info("Entered enrichVoipRequestWithLocation");
		Feature[] newFeatures = null;

		try {
			newFeatures = createAndAddLocationFeature(voipOrderRequest, dbServiceResponse, isNewCustomer);
			voipOrderRequest.getConvergedService().setFeature(newFeatures);

			LOG.info("Voip Order Request Enriched with Location: {}",
					mapper.writerWithDefaultPrettyPrinter().writeValueAsString(voipOrderRequest));

		} catch (Exception e) {
			LOG.error("Exception {} ", e);
			throw new TranslatorException(ErrorCode.TRANSFORMER_FAILURE,
					"Exception occured in enrichVoipRequestWithEnterprise");
		}

		LOG.info("Exited enrichVoipRequestWithLocation");
		return voipOrderRequest;
	}
	
	
	/**
	 * @param voipOrderRequest
	 * @param dbServiceResponse
	 * @param isNewCustomer
	 * @return newFeatureArray
	 * @throws TranslatorException
	 */
	private Feature[] createAndAddLocationFeature(VOIPOrderRequest voipOrderRequest,
			DBServiceResponse dbServiceResponse, boolean isNewCustomer) throws TranslatorException {
		LOG.info("Entered createAndAddLocationFeature");
		Feature[] newFeatureArray = null;
		Feature[] oldFeatureArray = null;
		Feature featureLocation = null;
		List<Feature> locFeaturesOld = null;
		List<Feature> locFeaturesMod = null;
		String actionCode = null;
		List<Map<String, String>> resultantInvRows = null;
		long locId;
		long bwLocationId = -1;
		Specification locSpecs;
		List<Long> locationIds = null;
		int version = 0;
				
		try {
			locFeaturesMod = new ArrayList<>();
			
			oldFeatureArray = voipOrderRequest.getConvergedService().getFeature();
			
			locFeaturesOld = stream(oldFeatureArray)
					.filter(feature -> feature.getCode().equalsIgnoreCase("FET_HPBX_LOC_LVL"))
					.collect(Collectors.toList());
			
			if(locFeaturesOld != null && !locFeaturesOld.isEmpty()) {
				actionCode = locFeaturesOld.get(0).getActionCode();
			}else {
				throw new BadRequestException(
						new FieldError("FET_HPBX_LOC", "FET_HPBX_LOC", "Missing Feature FET_HPBX_LOC"));
			}
			
			resultantInvRows = inventoryUtil.getCurrentHpbxNniDetails();
			
			//HPBX Supp fix :: Prasad
			version = Integer.parseInt(voipOrderRequest.getOrderHeader().getWorkOrderVersion());
			
			if(version>0) {
				LOG.info("wo# {} - locId - {}", voipOrderRequest.getOrderHeader().getWorkOrderNumber(), voipOrderRequest.getOrderHeader().getVoipLocationId());
		    	locationIds = inventoryUtil.getHpbxInstalledLocalEchid(voipOrderRequest.getOrderHeader().getWorkOrderNumber(), voipOrderRequest.getOrderHeader().getVoipLocationId());
		    	Collections.sort(locationIds);
				}
			   
			int index = 0;
			for (Map<String, String> map : resultantInvRows) {
				
				if(version > 0 && !CollectionUtils.isEmpty(locationIds) && index < locationIds.size()) {
					LOG.info("locationId:"+locationIds.get(index));
					locId = locationIds.get(index);
				} else {
					locId = customCustomerMapper.getLocationIdSeqNextVal();
				}
				
				index++;
				
				if(bwLocationId == -1) {
					bwLocationId = locId;
				}
				
				featureLocation = new Feature();
				featureLocation.setInstanceId(String.valueOf(locId));
				featureLocation.setCode("FET_HPBX_LOC_LVL_LOC");
				featureLocation.setName("Local Location level");
				
				LOG.info("HPBX_PREBUILD_LOC_ID = {}", map.get("HPBX_PREBUILD_LOC_ID"));
		
				Specification[] specifications = createLocationSpecification(voipOrderRequest, dbServiceResponse,
						isNewCustomer, String.valueOf(bwLocationId), map.get("HPBX_PREBUILD_LOC_ID"));
				featureLocation.setSpecification(specifications);
				featureLocation.setActionCode(actionCode);
				
				locFeaturesMod.add(featureLocation);
				
			}
			
			newFeatureArray = ArrayUtils.addAll(oldFeatureArray,
					locFeaturesMod.toArray(new Feature[locFeaturesMod.size()]));

			LOG.info("Complete Feature  List with Location Featues: {} ",
					mapper.writerWithDefaultPrettyPrinter().writeValueAsString(newFeatureArray));
			
		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new TranslatorException(ErrorCode.TRANSFORMER_FAILURE,
					"Exception occured in createAndAddLocationFeature");
		}

		LOG.info("Exited createAndAddLocationFeature");
		return newFeatureArray;
	}
	
	/**
	 * @param voipOrderRequest
	 * @param dbServiceResponse
	 * @param isNewCustomer
	 * @param bwLocId TODO
	 * @param preBuildLocId TODO
	 * @return
	 * @throws TranslatorException
	 */
	private Specification[] createLocationSpecification(VOIPOrderRequest voipOrderRequest,
			DBServiceResponse dbServiceResponse, boolean isNewCustomer, String bwLocId, String preBuildLocId)
			throws TranslatorException {
		LOG.info("Entered createLocationSpecification");
		Specification[] specifications = null;
		List<Specification> specList = null;
		List<Feature> features = null;
		List<Feature> etFeatures = null;
		Specification locSpecs;
		
		LOG.info("bwLocId = {}", bwLocId);

		try {
			specList = new ArrayList<>();
			
			features = stream(voipOrderRequest.getConvergedService().getFeature())
					.filter(feature -> feature.getCode().equalsIgnoreCase("FET_HPBX_LOC_LVL"))
					.collect(Collectors.toList());			
			
			if(features != null && !features.isEmpty()) {				
				
				for (Specification spec : features.get(0).getSpecification()) {
					
					locSpecs = new Specification();
					locSpecs.setCode(spec.getCode());
					locSpecs.setValue(spec.getValue());
					
					specList.add(locSpecs);
				}
			}			
			
			locSpecs = new Specification();
			locSpecs.setCode("SP_XO_BW_LOC_ID");
			locSpecs.setValue(bwLocId);
			
			specList.add(locSpecs);
			
			locSpecs = new Specification();
			locSpecs.setCode("SP_HPBX_PREBUILD_LOC_ID");
			locSpecs.setValue(preBuildLocId);
			
			specList.add(locSpecs);

			specifications = specList.toArray(new Specification[specList.size()]);

		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new TranslatorException(ErrorCode.TRANSFORMER_FAILURE,
					"Exception occured in createLocationSpecification");
		}

		LOG.info("Exited createLocationSpecification");
		return specifications;
	}
	
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.vz.esap.translation.order.transformer.VoipRequestTransformer#
	 * enrichVoipRequestWithDevice(com.vz.esap.translation.order.model.request.
	 * VOIPOrderRequest)
	 */
	@Override
	public VOIPOrderRequest enrichVoipRequestWithDevice(VOIPOrderRequest voipOrderRequest)
			throws TranslatorException {
		LOG.info("Entered enrichVoipRequestWithDevice");
		Feature[] newFeatures = null;

		try {
			newFeatures = createAndAddDeviceFeature(voipOrderRequest);
			voipOrderRequest.getConvergedService().setFeature(newFeatures);

			LOG.info("Voip Order Request Enriched with Device: {}",
					mapper.writerWithDefaultPrettyPrinter().writeValueAsString(voipOrderRequest));

		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new TranslatorException(ErrorCode.TRANSFORMER_FAILURE,
					"Exception occured in enrichVoipRequestWithDevice");
		}

		LOG.info("Exited enrichVoipRequestWithDevice");
		return voipOrderRequest;
	}
	

	/**
	 * @param voipOrderRequest
	 * @return newFeatureArray
	 * @throws TranslatorException
	 */
	private Feature[] createAndAddDeviceFeature(VOIPOrderRequest voipOrderRequest) throws TranslatorException {
		LOG.info("Entered createAndAddDeviceFeature");
		Feature[] newFeatureArray = null;
		Feature[] oldFeatureArray = null;
		Feature featureDev = null;
		long deviceId = -1;
		List<Feature> devFeaturesMod = null;
		Specification[] specifications = null;
		List<Feature>  trunkLinePriLineFeatures = null;
		int orderVersion = 0;
		List<TblEnvOrder> tblEnvOrderListPrev = null;
		List<TblOrder> tblOrderListPrev = null;
		List<TblOrderDetails> tblOrderDetailsListPrev = null;
		
		try {
			devFeaturesMod = new ArrayList<>();
			//HPBX Supp fix :: Govardhan
			orderVersion = Integer.parseInt(voipOrderRequest.getOrderHeader().getWorkOrderVersion());
			oldFeatureArray = voipOrderRequest.getConvergedService().getFeature();

			for (Feature origFeature : oldFeatureArray) {
				
				if ("FET_HPBX_TRU".equalsIgnoreCase(origFeature.getCode())) {
					
					//TODO : Done
					
					if (orderVersion > 0) {
						//TODO : if version> 0 then search entire TOD for device order and get deviceMapID from there
						//if nothing comes go with inventory and again nothing comes go with sequence..
						VOIPOrderRequest voipOrderRequestPrev = orderParserImpl.getCorrectPrevPassVoipOrderRequest(voipOrderRequest);
						
						LOG.info("SUPP Order version:: {}", voipOrderRequestPrev.getOrderHeader().getWorkOrderVersion());
						
						//voipOrderRequestPrev.getOrderHeader().setWorkOrderVersion(Integer.toString(orderVersion - 1));
						tblEnvOrderListPrev = orderServiceHelperImpl.getMatchingPrevPassEnvOrder(voipOrderRequestPrev, 0,
								WorkOrderEnum.OrderClassify.RELEASE);
						
						LOG.info("Env table records size::{}", tblEnvOrderListPrev.size());
						
						tblOrderListPrev = orderServiceHelperImpl.getMatchingPrevPassOrder(tblEnvOrderListPrev.get(0),
								OrderEntity.DEVICE); 

						if(!CollectionUtils.isEmpty(tblOrderListPrev)) {
							LOG.info("TBL_ORDER records size::{}", tblOrderListPrev.size());
							LOG.info("TBL ORDER ID::{}", tblOrderListPrev.get(0).getOrderId());

							for (TblOrder tblOrderPrev : tblOrderListPrev) {
//									tblOrderDetailsListPrev = orderServiceHelperImpl.getMatchingOrderDetails(tblOrderPrev);
									tblOrderDetailsListPrev = voipOrderDaoImpl.getOrderDetailsEntriesPerOrder(tblOrderPrev);
									LOG.info("TBL_ORDER_DETAILS records size::{}", tblOrderDetailsListPrev.size());
							}					
						}
						
						if (tblOrderDetailsListPrev!=null && !CollectionUtils.isEmpty(tblOrderDetailsListPrev)) {
							for(TblOrderDetails tblOrderDetails : tblOrderDetailsListPrev) {
								LOG.info("ParamName:"+tblOrderDetails.getParamName()+"::PramValue:"+tblOrderDetails.getParamValue());
								if("DeviceMapId".equalsIgnoreCase(tblOrderDetails.getParamName())) {
									deviceId = tblOrderDetails.getParamValue()!=null ? Long.valueOf(tblOrderDetails.getParamValue()) : 0;
								}
							}
						}
						LOG.info("deviceMapId from TOD:" + deviceId);
						//
						if(deviceId == 0) {
							LOG.info("wo# {} - TrunkInstanceId as GroupId - {}",
									voipOrderRequest.getOrderHeader().getWorkOrderNumber(), origFeature.getInstanceId());
							deviceId = inventoryUtil.getDeviceMapIdFromTrunkId(origFeature.getInstanceId());
							LOG.info("deviceId from Group:" + deviceId);
							if (deviceId == 0) {
								deviceId = customCustomerMapper.getDeviceMapIdSeqNextVal();
							}
						}
						
					} else {
						deviceId = customCustomerMapper.getDeviceMapIdSeqNextVal();
					}
					
					featureDev = new Feature();
					featureDev.setInstanceId(String.valueOf(deviceId));
					featureDev.setActionCode(origFeature.getActionCode());
					featureDev.setName("Device level");					
					featureDev.setCode("FET_DE_LOC");					
										
					specifications = createDeviceSpecification(deviceId);
					featureDev.setSpecification(specifications);
					
					devFeaturesMod.add(featureDev);
					
				}
				
				//Enriching Device for IPFLEX
				if ("FET_XO_TRU_CON_LINE_LOC".equalsIgnoreCase(origFeature.getCode())) {
					
					//TODO : Done
					LOG.info("Enriching Device::FET_XO_TRU_CON_LINE_LOC ");
					if (orderVersion > 0) {
						LOG.info("Enriching Device::FET_XO_TRU_CON_LINE_LOC for Supp Version");
						//TODO : if version> 0 then search entire TOD for device order and get deviceMapID from there
						//if nothing comes go with inventory and again nothing comes go with sequence..
						VOIPOrderRequest voipOrderRequestPrev = orderParserImpl.getCorrectPrevPassVoipOrderRequest(voipOrderRequest);
						
						LOG.info("SUPP Order version:: {}", voipOrderRequestPrev.getOrderHeader().getWorkOrderVersion());
						
						//voipOrderRequestPrev.getOrderHeader().setWorkOrderVersion(Integer.toString(orderVersion - 1));
						tblEnvOrderListPrev = orderServiceHelperImpl.getMatchingPrevPassEnvOrder(voipOrderRequestPrev, 0,
								WorkOrderEnum.OrderClassify.RELEASE);
						
						LOG.info("Env table records size::{}", tblEnvOrderListPrev.size());
						
						tblOrderListPrev = orderServiceHelperImpl.getMatchingPrevPassOrder(tblEnvOrderListPrev.get(0),
								OrderEntity.DEVICE);
						
						//getting instance id
						List<Feature> features = null;
						features = stream(voipOrderRequest.getConvergedService().getFeature())
								.filter(feature -> feature.getCode().equalsIgnoreCase("FET_DE")).collect(Collectors.toList());
						String currentInstanceId = features.get(0).getInstanceId();

						if(!CollectionUtils.isEmpty(tblOrderListPrev)) {
							LOG.info("TBL_ORDER records size::{}", tblOrderListPrev.size());
							LOG.info("TBL ORDER ID::{}", tblOrderListPrev.get(0).getOrderId());

							for (TblOrder tblOrderPrev : tblOrderListPrev) {
								LOG.info("Device Order Id :: {}", tblOrderPrev.getOrderId());
								tblOrderDetailsListPrev = voipOrderDaoImpl.getOrderDetailsEntriesPerOrder(tblOrderPrev);
								LOG.info("TBL_ORDER_DETAILS records size::{}", tblOrderDetailsListPrev.size());
								if (tblOrderDetailsListPrev!=null && !CollectionUtils.isEmpty(tblOrderDetailsListPrev)) {
									for(TblOrderDetails tblOrderDetails : tblOrderDetailsListPrev) {
										LOG.info("ParamName:"+tblOrderDetails.getParamName()+"::PramValue:"+tblOrderDetails.getParamValue());
										if("DeviceMapId".equalsIgnoreCase(tblOrderDetails.getParamName())) {
											LOG.info("CurrentInstanceId::{} :: DeviceMapId:: {}", currentInstanceId, tblOrderDetails.getParamValue());
											if(!currentInstanceId.equalsIgnoreCase(tblOrderDetails.getParamValue())) {
												LOG.info("Found Enriched Device");
												deviceId = Long.valueOf(tblOrderDetails.getParamValue());
												break;
											}
										}
									}
								}
							}					
						}
						
						LOG.info("deviceMapId from TOD:" + deviceId);
						if (deviceId == -1) {
							LOG.info("Enriching Device::FET_XO_TRU_CON_LINE_LOC for SUPP with sequence unique id.");
							deviceId = customCustomerMapper.getDeviceMapIdSeqNextVal();
						}
						/*
						if(deviceId == 0) {
							LOG.info("wo# {} - TrunkInstanceId as GroupId - {}",
									voipOrderRequest.getOrderHeader().getWorkOrderNumber(), origFeature.getInstanceId());
							deviceId = inventoryUtil.getDeviceMapIdFromTrunkId(origFeature.getInstanceId());
							LOG.info("deviceId from Group:" + deviceId);
							if (deviceId == 0) {
								deviceId = customCustomerMapper.getDeviceMapIdSeqNextVal();
							}
						}*/
						
					} else {
						LOG.info("Enriching Device::FET_XO_TRU_CON_LINE_LOC for Install with sequence unique id.");
						deviceId = customCustomerMapper.getDeviceMapIdSeqNextVal();
					}
					
					featureDev = new Feature();
					featureDev.setInstanceId(String.valueOf(deviceId));
					featureDev.setActionCode(origFeature.getActionCode());
					featureDev.setName("Device level");					
					featureDev.setCode("FET_DE_LOC");					
										
					specifications = createDeviceSpecification(deviceId);
					featureDev.setSpecification(specifications);
					
					devFeaturesMod.add(featureDev);
				}
				
				/*trunkLinePriLineFeatures = stream(voipOrderRequest.getConvergedService().getFeature())
						.filter(trunkFeature -> "FET_PRILIN".equalsIgnoreCase(trunkFeature.getCode())
								|| "FET_XO_TRULIN".equalsIgnoreCase(trunkFeature.getCode()))
						.collect(Collectors.toList());
				
				// Start:PRI/LIN,TRU/LIN Fix

				if (!CollectionUtils.isEmpty(trunkLinePriLineFeatures)) {
					LOG.info("The Type of Flex is = {}", trunkLinePriLineFeatures.get(0).getCode());

					if ("FET_XO_TRU_CON_LINE_LOC".equalsIgnoreCase(origFeature.getCode())) {
						LOG.info("Creating Device Map for Line part of TRU/PRI/LINE");

						deviceId = customCustomerMapper.getDeviceMapIdSeqNextVal();

						featureDev = new Feature();
						featureDev.setInstanceId(String.valueOf(deviceId));
						featureDev.setActionCode(origFeature.getActionCode());
						featureDev.setName("Device level");
						featureDev.setCode("FET_DE_LOC");

						specifications = createDeviceSpecification(deviceId);
						featureDev.setSpecification(specifications);

						devFeaturesMod.add(featureDev);
					}
				}*/

				// End:PRI/LIN,TRU/LIN Fix				
			}
			
			newFeatureArray = ArrayUtils.addAll(oldFeatureArray,
					devFeaturesMod.toArray(new Feature[devFeaturesMod.size()]));
			
			LOG.info("Complete Feature  List with Device Features: {} ",
					mapper.writerWithDefaultPrettyPrinter().writeValueAsString(newFeatureArray));
			
		} catch (Exception e) {
			LOG.error("Exception {} ", e);
			throw new TranslatorException(ErrorCode.TRANSFORMER_FAILURE,
					"Exception occured in createAndAddDeviceFeature");
		}

		LOG.info("Exited createAndAddDeviceFeature");
		return newFeatureArray;
	}
	
	/**
	 * @param deviceId
	 * @return
	 * @throws TranslatorException
	 */
	private Specification[] createDeviceSpecification(long deviceId)			
					throws TranslatorException {
		LOG.info("Entered createDeviceSpecification");
		
		Specification[] specifications = null;
		List<Specification> specList = null;
		Specification deviceTypeSpec = null;

		try {
			specList = new ArrayList<>();
			
			deviceTypeSpec = new Specification();
			deviceTypeSpec.setCode("ESP_CPE_DEVICE_ID");
			deviceTypeSpec.setName("Device Id");
			deviceTypeSpec.setValue(String.valueOf(deviceId));
			specList.add(deviceTypeSpec);
			
			deviceTypeSpec = new Specification();
			deviceTypeSpec.setCode("ESP_LOGICAL_DEVICE_NAME");
			deviceTypeSpec.setName("Device Name");
			deviceTypeSpec.setValue(String.valueOf(deviceId));
			specList.add(deviceTypeSpec);
			
			deviceTypeSpec = new Specification();
			deviceTypeSpec.setCode("ESP_CPE_UEID");
			deviceTypeSpec.setName("Device Ueid");
			deviceTypeSpec.setValue(String.valueOf(deviceId));
			specList.add(deviceTypeSpec);

			specifications = specList.toArray(new Specification[specList.size()]);

		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new TranslatorException(ErrorCode.TRANSFORMER_FAILURE,
					"Exception occured in createDeviceSpecification");
		}

		LOG.info("Exited createDeviceSpecification");
		return specifications;
	}
	
	
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.vz.esap.translation.order.transformer.VoipRequestTransformer#
	 * createVoipOrderRequestFromRequestUri(com.vz.esap.translation.enums.EsapEnum.
	 * ResourceVerb, java.lang.String, java.lang.String, java.lang.String,
	 * java.lang.String, java.lang.String, java.lang.String, java.lang.String,
	 * java.lang.String, java.lang.String)
	 */
	@Override
	public VOIPOrderRequest createVoipOrderRequestFromRequestUri(ResourceVerb verb, String locationId, String workOrderNumber,
			String workOrderVersion, String unoServiceId, String transactionID, String msgSegmentNo, String orderType,
			String gchId, String solutionType) throws TranslatorException {
		LOG.info("Entered createVoipOrderRequestFromRequestUri");

		VOIPOrderRequest voipOrderRequest = null;
		com.vz.esap.translation.order.model.request.OrderHeader orderHeader = null;

		orderHeader = new com.vz.esap.translation.order.model.request.OrderHeader();
		orderHeader.setVoipLocationId(locationId);
		orderHeader.setWorkOrderNumber(workOrderNumber);
		orderHeader.setWorkOrderVersion(workOrderVersion);
		orderHeader.setUNOServiceId(unoServiceId);
		orderHeader.setTransactionID(transactionID);
		orderHeader.setMsgSegmentNo(msgSegmentNo);
		orderHeader.setGCHId(gchId);
		if(solutionType!= null){
			orderHeader.setSolutionType(orderServiceHelperImpl.getSolutionTypeFromBodReuest(solutionType));
		}else {
			orderHeader.setSolutionType(SolutionType.SL_ESIP);
		}
		
		if(ResourceVerb.GET_LOC_INFO.equals(verb)) {
			orderHeader.setFunctionCode(FunctionCode.GET_LOC_INFO.toString());
		}

		voipOrderRequest = new VOIPOrderRequest();
		voipOrderRequest.setOrderHeader(orderHeader);

		LOG.info("Exited createVoipOrderRequestFromRequestUri with FunctionCode = {}", orderHeader.getFunctionCode());
		return voipOrderRequest;
	}
	
	
}
