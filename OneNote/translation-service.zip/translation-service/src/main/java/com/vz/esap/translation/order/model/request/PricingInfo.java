package com.vz.esap.translation.order.model.request;

public class PricingInfo {

	private String ChargeType;

	private String CatalogVersionTime;

	private String UnitOfMeasure;

	private String BillTime;

	private String FeatureInstanceId;

	private String ChargeFrequency;

	private String FeatureCode;

	private String CurrencyCode;

	private String pbLi;

	private String servicePlan;

	public String getChargeType() {
		return ChargeType;
	}

	public void setChargeType(String ChargeType) {
		this.ChargeType = ChargeType;
	}

	public String getCatalogVersionTime() {
		return CatalogVersionTime;
	}

	public void setCatalogVersionTime(String CatalogVersionTime) {
		this.CatalogVersionTime = CatalogVersionTime;
	}

	public String getUnitOfMeasure() {
		return UnitOfMeasure;
	}

	public void setUnitOfMeasure(String UnitOfMeasure) {
		this.UnitOfMeasure = UnitOfMeasure;
	}

	public String getBillTime() {
		return BillTime;
	}

	public void setBillTime(String BillTime) {
		this.BillTime = BillTime;
	}

	public String getFeatureInstanceId() {
		return FeatureInstanceId;
	}

	public void setFeatureInstanceId(String FeatureInstanceId) {
		this.FeatureInstanceId = FeatureInstanceId;
	}

	public String getChargeFrequency() {
		return ChargeFrequency;
	}

	public void setChargeFrequency(String ChargeFrequency) {
		this.ChargeFrequency = ChargeFrequency;
	}

	public String getFeatureCode() {
		return FeatureCode;
	}

	public void setFeatureCode(String FeatureCode) {
		this.FeatureCode = FeatureCode;
	}

	public String getCurrencyCode() {
		return CurrencyCode;
	}

	public void setCurrencyCode(String CurrencyCode) {
		this.CurrencyCode = CurrencyCode;
	}

	public String toString() {
		return "ClassPojo [ChargeType = " + ChargeType + ", CatalogVersionTime = " + CatalogVersionTime
				+ ", UnitOfMeasure = " + UnitOfMeasure + ", BillTime = " + BillTime + ", FeatureInstanceId = "
				+ FeatureInstanceId + ", ChargeFrequency = " + ChargeFrequency + ", FeatureCode = " + FeatureCode
				+ ", CurrencyCode = " + CurrencyCode + "]";
	}

	public String getPbLi() {
		return pbLi;
	}

	public void setPbLi(String pbLi) {
		this.pbLi = pbLi;
	}

	public String getServicePlan() {
		return servicePlan;
	}

	public void setServicePlan(String servicePlan) {
		this.servicePlan = servicePlan;
	}

	public ParamInfo getParamInfo(String action) {
		ParamInfo priceInfoParam = new ParamInfo("PricingInfo", null, action);

		priceInfoParam.addNotNullValChild("PBLI", pbLi, action);
		priceInfoParam.addNotNullValChild("FeatureInstanceId", FeatureInstanceId, action);
		priceInfoParam.addNotNullValChild("FeatureCode", FeatureCode, action);
		priceInfoParam.addNotNullValChild("ChargeType", ChargeType, action);
		priceInfoParam.addNotNullValChild("CurrencyCode", CurrencyCode, action);
		priceInfoParam.addNotNullValChild("ChargeFrequency", ChargeFrequency, action);
		priceInfoParam.addNotNullValChild("UnitOfMeasure", UnitOfMeasure, action);
		priceInfoParam.addNotNullValChild("BillTime", BillTime, action);
		priceInfoParam.addNotNullValChild("CatalogVersionTime", CatalogVersionTime, action);
		priceInfoParam.addNotNullValChild("ServicePlan", servicePlan, action);
		return priceInfoParam;
	}
}
