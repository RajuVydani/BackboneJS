package com.vz.esap.translation.order.service.ebl;

import java.util.Map;

import com.vz.esap.translation.exception.GenericException;
import com.vz.esap.translation.exception.TranslatorException;
import com.vz.esap.translation.order.model.request.VOIPOrderRequest;
import com.vz.esap.translation.order.model.response.VoipOrderResponse;

public interface EblOrderService {

	/**
	 * @param voipOrderRequest
	 * @param productDetails
	 * @return voipOrderResponse
	 * @throws GenericException
	 */
	VoipOrderResponse createEblEsipValidateOrder(VOIPOrderRequest voipOrderRequest, Map<String, String> productDetails)
			throws GenericException;

	/**
	 * @param voipOrderRequest
	 * @param productDetails
	 * @return voipOrderResponse
	 * @throws GenericException 
	 * @throws TranslatorException 
	 */
	VoipOrderResponse createEblEsipReleaseOrder(VOIPOrderRequest voipOrderRequest, Map<String, String> productDetails) throws TranslatorException, GenericException;
	
	/** Disconn
	 * @param voipOrderRequest
	 * @param productDetails TODO
	 * @return VoipOrderResponse
	 * @throws TranslatorException
	 * @throws GenericException
	 */
	VoipOrderResponse createEblEsipLocSuspOrder(VOIPOrderRequest voipOrderRequest, Map<String, String> productDetails)
			throws TranslatorException, GenericException;

	/**
	 * Disconn
	 * 
	 * @param voipOrderRequest
	 * @param productDetails TODO
	 * @return VoipOrderResponse
	 * @throws TranslatorException
	 * @throws GenericException
	 */
	VoipOrderResponse createEblEsipLocDeactOrder(VOIPOrderRequest voipOrderRequest, Map<String, String> productDetails)
			throws TranslatorException, GenericException;

	/**
	 * @param voipOrderRequest
	 * @param productDetails
	 * @return VoipOrderResponse
	 * @throws TranslatorException
	 * @throws GenericException
	 */
	VoipOrderResponse createTnPortActivationOrder(VOIPOrderRequest voipOrderRequest, Map<String, String> productDetails)
			throws TranslatorException, GenericException;	
}
