package com.vz.esap.translation.order.model.pc;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

@XmlAccessorType(XmlAccessType.FIELD)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
public class AdditionalInfo {
	
	@XmlElement(name = "BillingAccountNumber")
	@JsonProperty(value = "BillingAccountNumber")
	private String billingAccountNumber;

	@XmlElement(name = "AccessInfo")
	@JsonProperty(value = "AccessInfo")
	private AccessInfo[] accessInfo;

	@XmlElement(name = "ProductCode")
	@JsonProperty(value = "ProductCode")
	private String productCode;

	@XmlElement(name = "Ecm")
	@JsonProperty(value = "Ecm")
	private Ecm[] ecm;

	@XmlElement(name = "DayLightSavingsInd")
	@JsonProperty(value = "DayLightSavingsInd")
	private String dayLightSavingsInd;

	@XmlElement(name = "CNAMInfo")
	@JsonProperty(value = "CNAMInfo")
	private CNAMInfo[] cnamInfo;

	@XmlElement(name = "GCMInfo")
	@JsonProperty(value = "GCMInfo")
	private GCMInfo gcmInfo;

	@XmlElement(name = "TimeZone")
	@JsonProperty(value = "TimeZone")
	private String timeZone;

	@XmlElement(name = "LocationReferenceId")
	@JsonProperty(value = "LocationReferenceId")
	private String locationReferenceId;

	@XmlElement(name = "TransitionType")
	@JsonProperty(value = "TransitionType")
	private String transitionType;

	public String getBillingAccountNumber() {
		return billingAccountNumber;
	}

	public void setBillingAccountNumber(String BillingAccountNumber) {
		this.billingAccountNumber = BillingAccountNumber;
	}

	public AccessInfo[] getAccessInfo() {
		return accessInfo;
	}

	public void setAccessInfo(AccessInfo[] AccessInfo) {
		this.accessInfo = AccessInfo;
	}

	public String getProductCode() {
		return productCode;
	}

	public void setProductCode(String ProductCode) {
		this.productCode = ProductCode;
	}

	public Ecm[] getEcm() {
		return ecm;
	}

	public void setEcm(Ecm[] Ecm) {
		this.ecm = Ecm;
	}

	public String getDayLightSavingsInd() {
		return dayLightSavingsInd;
	}

	public void setDayLightSavingsInd(String DayLightSavingsInd) {
		this.dayLightSavingsInd = DayLightSavingsInd;
	}

	public CNAMInfo[] getCNAMInfo() {
		return cnamInfo;
	}

	public void setCNAMInfo(CNAMInfo[] CNAMInfo) {
		this.cnamInfo = CNAMInfo;
	}

	public GCMInfo getGCMInfo() {
		return gcmInfo;
	}

	public void setGCMInfo(GCMInfo GCMInfo) {
		this.gcmInfo = GCMInfo;
	}

	public String getTimeZone() {
		return timeZone;
	}

	public void setTimeZone(String TimeZone) {
		this.timeZone = TimeZone;
	}

	public String getLocationReferenceId() {
		return locationReferenceId;
	}

	public void setLocationReferenceId(String LocationReferenceId) {
		this.locationReferenceId = LocationReferenceId;
	}

	public String getTransitionType() {
		return transitionType;
	}

	public void setTransitionType(String TransitionType) {
		this.transitionType = TransitionType;
	}

	@Override
	public String toString() {
		return "ClassPojo [BillingAccountNumber = " + billingAccountNumber + ", AccessInfo = " + accessInfo
				+ ", ProductCode = " + productCode + ", Ecm = " + ecm + ", DayLightSavingsInd = " + dayLightSavingsInd
				+ ", CNAMInfo = " + cnamInfo + ", GCMInfo = " + gcmInfo + ", TimeZone = " + timeZone
				+ ", LocationReferenceId = " + locationReferenceId + ", TransitionType = " + transitionType + "]";
	}
}
