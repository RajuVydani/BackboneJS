package com.vz.esap.translation.order.transformer;

import java.text.ParseException;
import java.util.ArrayList;

import org.springframework.stereotype.Component;

import com.vz.esap.translation.dao.model.TblOrder;
import com.vz.esap.translation.entity.CustomerEntity;
import com.vz.esap.translation.entity.DeviceEntity;
import com.vz.esap.translation.entity.LocationEntity;
import com.vz.esap.translation.exception.GenericException;
import com.vz.esap.translation.exception.TranslatorException;
import com.vz.esap.translation.order.model.Order;
import com.vz.esap.translation.order.model.request.ParamInfo;
import com.vz.esap.translation.order.model.request.VOIPOrderRequest;

@Component
public interface LocationTblOrderDetailsDataTransformer {

	/**
	 * @param order
	 * @param action
	 *            TODO
	 * @return paramInfo
	 */
	ParamInfo prepareTblOrderDetailsEntityParamDataForLocation(Order order, String action);// release pass

	/**
	 * @param voipOrderRequest
	 * @param tblOrderObject
	 * @param location
	 * @param action
	 *            TODO
	 * @return paramInfo
	 * @throws GenericException
	 */
	ParamInfo prepareTblOrderDetailsEntityParamDataForLocation(VOIPOrderRequest voipOrderRequest,
			TblOrder tblOrderObject, LocationEntity location, String action) throws GenericException;// val pass

	/**
	 * @param order
	 * @return paramInfo
	 * @throws ParseException
	 * @throws TranslatorException
	 */
	ParamInfo prepareTblOrderDetailsHeaderParamData(Order order) throws ParseException, TranslatorException;

	/**
	 * @param oldLoc
	 * @param newLoc
	 * @param supp
	 * @param action
	 * @return paramInfo
	 */
	ParamInfo prepareTblOrderDetailsEntityParamDataForLocation(LocationEntity oldLoc, LocationEntity newLoc,
			boolean supp, String action);

	/**
	 * @param order
	 * @param oldLoc
	 * @param supp
	 * @return paramInfo
	 * @throws ParseException
	 * @throws TranslatorException
	 */
	ParamInfo prepareTblOrderDetailsHeaderParamData(Order order, LocationEntity oldLoc, boolean supp)
			throws ParseException, TranslatorException;

	

}
