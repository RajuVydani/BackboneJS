package com.vz.esap.translation.order.transformer;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.vz.esap.translation.entity.GroupTNEntity;
import com.vz.esap.translation.enums.EsapEnum;
import com.vz.esap.translation.exception.TranslatorException;
import com.vz.esap.translation.exception.TranslatorException.ErrorCode;
import com.vz.esap.translation.order.model.Order;
import com.vz.esap.translation.order.model.request.ParamInfo;
import com.vz.esap.translation.util.GroupTNUtility;
import com.vz.esap.translation.util.OrderUtility;

/**
 * @author baigkh
 *
 */
@Component
public class TNTblOrderDetailsDataTransformerImpl implements TNTblOrderDetailsDataTransformer {

	private static final Logger LOG = LoggerFactory.getLogger(TNTblOrderDetailsDataTransformerImpl.class);

	private static final String LOCATION_ID = "LocationId";
	private static final String CUSTOMER_ID = "CustomerId";
	private static final String REGION = "Region";
	//private static final String BS_APP_SERVER = "BsAppServer";
	private static final String HOT_CUT_IND = "HotCutIndicator";
	private static final String CDD_IND = "CDDDIndicator";

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.vz.esap.translation.order.transformer.
	 * TNTblOrderDetailsDataTransformer#
	 * prepareTODEtityDataForGroups(java.util.ArrayList, java.lang.String)
	 */
	@Override
	public ArrayList<ParamInfo> prepareTODEtityDataForGroups(ArrayList<GroupTNEntity> groupTNList, String action) {

		LOG.info("Entered - prepareTODEtityDataForGroups");

		ArrayList<ParamInfo> grpTnRecordsList = null;
		String locAction = null;
		try {
			grpTnRecordsList = new ArrayList<>();
			for (GroupTNEntity grpTn : groupTNList) {
				LOG.info("TN Type {} ", grpTn.getTnRecord().getTnType());
				LOG.info("TN Type Ordering{} ", grpTn.getTnRecord().getTnTypeOrdering());
				
				if("C".equalsIgnoreCase(action) || EsapEnum.OrderAction.MODIFY.equals(grpTn.getAction())) {
					locAction = "C";
					grpTnRecordsList.add(GroupTNUtility.getParamInfo(grpTn, true));
					
				} else if("I".equalsIgnoreCase(action)){
					locAction = "I";
					grpTnRecordsList.add(GroupTNUtility.getParamInfo(grpTn, action));
					
				} else if("O".equalsIgnoreCase(action) || EsapEnum.OrderAction.DELETE.equals(grpTn.getAction())){
					locAction = "O";
					grpTnRecordsList.add(GroupTNUtility.getParamInfo(grpTn, locAction));
					
				}
			}
			
			if(groupTNList != null && !groupTNList.isEmpty()) {
				if("C".equalsIgnoreCase(locAction)) {
					grpTnRecordsList.add(GroupTNUtility.getTnSystemUpdateParamInfo(groupTNList.get(0), true));
					
				} else {
					grpTnRecordsList.add(GroupTNUtility.getTnSystemUpdateParamInfo(groupTNList.get(0), action));
					
				}
			}
		} catch (Exception e) {
			LOG.error("Exception Occured in prepareTODEtityDataForGroups() {}", e.getMessage());
		}

		return grpTnRecordsList;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.vz.esap.translation.order.transformer.
	 * TNTblOrderDetailsDataTransformer#
	 * prepareTblOrderDetailsEntityParamDataForGroupTn(com.vz.esap.translation.
	 * order.model.Order)
	 * 
	 */
	@Override
	public ParamInfo prepareTblOrderDetailsEntityParamDataForGroupTn(Order order) throws TranslatorException {

		LOG.info("Inside - prepareTblOrderDetailsEntityParamDataForGroupTn");
		return GroupTNUtility.getParamInfo(order.getGroupTnEntity(), order.getOrderHeader().getOrderType());

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.vz.esap.translation.order.transformer.TNTblOrderDetailsDataTransformer#
	 * prepareTblOrderDetailsEntityParamDataForSystemUpdate(com.vz.esap.translation.
	 * order.model.Order, java.lang.String)
	 */
	@Override
	public ParamInfo prepareTblOrderDetailsEntityParamDataForSystemUpdate(Order order, String action)
			throws TranslatorException {

		LOG.info("Inside - prepareTblOrderDetailsEntityParamDataForSystemUpdate");
		if (action == null) {
			action = order.getOrderHeader().getOrderType();
		}
		return GroupTNUtility.getTnSystemUpdateParamInfo(order.getGroupTnEntity(), action);

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.vz.esap.translation.order.transformer.
	 * DeviceTblOrderDetailsDataTransformer# prepareTblOrderDetailsHeaderParamData(
	 * com.vz.esap.translation.order.model.Order)
	 */
	@Override
	public ParamInfo prepareTblOrderDetailsHeaderParamData(Order order) throws ParseException, TranslatorException {

		LOG.info("Entered - prepareTblOrderDetailsHeaderParamData");
		ParamInfo headerParams = null;
		String action = null;
		try {

			action = order.getOrderHeader().getOrderType();

			headerParams = new ParamInfo("Header", null, action);
			headerParams.addNotNullValChild("OrderNumber", order.getOrderHeader().getOrderNumber(), action);
			headerParams.addNotNullValChild("EnvOrderId", order.getOrderHeader().getEnvOrderId(), action);
			headerParams.addNotNullValChild("MasterOrderNumber", order.getOrderHeader().getMasterOrderNumber(), action);
			headerParams.addNotNullValChild("OrderVersion", order.getOrderHeader().getOrderVersion(), action);
			headerParams.addNotNullValChild("TransactionId", order.getOrderHeader().getTransactionId(), action);
			headerParams.addNotNullValChild("Region", order.getOrderHeader().getRegion(), action);
			headerParams.addNotNullValChild("MinorOrderType", order.getOrderHeader().getMinorOrderType(), action);
			headerParams.addNotNullValChild("CentrexType", order.getOrderHeader().getCentrexType(), action);
			headerParams.addNotNullValChild("ServiceType", order.getOrderHeader().getServiceType(), action);
			headerParams.addNotNullValChild("OriginatingSystem", order.getOrderHeader().getOriginatingSystem(), action);
			headerParams.addNotNullValChild("InterfaceSystem", order.getOrderHeader().getInterfaceSystem(), action);
			headerParams.addNotNullValChild("OrderType",
					EsapEnum.OrderType.getValue(order.getOrderHeader().getOrderType().charAt(0)), action);
			headerParams.addNotNullValChild("SuppType", order.getOrderHeader().getSuppType(), action);
			headerParams.addNotNullValChild("OrderClassify", order.getOrderHeader().getFunctionCode(), action);

			if (order.getOrderHeader().getDueDate() != null) {
				SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
				Date date = format.parse(order.getOrderHeader().getDueDate().toString());
				Calendar calendar = GregorianCalendar.getInstance();
				calendar.setTime(date);
				Object dueDate = calendar.getTime();
				headerParams.addNotNullValChild("DueDate", dueDate, action);
			}
			headerParams.addNotNullValChild("CustomerId", order.getOrderHeader().getCustomerId(), action);
			headerParams.addNotNullValChild("LocationId", order.getOrderHeader().getLocationId(), action);
			// headerParams.addNotNullValChild("BsAppServer",
			// order.getCustomer().getBsAppServer(), action); Fix This
			headerParams.addNotNullValChild("OrderProTIN", order.getOrderHeader().getOrderProTIN(), action);
			headerParams.addNotNullValChild("IOrderTIN", order.getOrderHeader().getiOrderTIN(), action);
			headerParams.addNotNullValChild("TINVersion", order.getOrderHeader().getTinVersion(), action);
			headerParams.addNotNullValChild("TransitionFlag", order.getOrderHeader().isTransitionFlag() ? "Y" : "N",
					action);
			headerParams.addNotNullValChild("Priority", order.getOrderHeader().getPriority(), action);
			if (order.getOrderHeader().getAttribMap() != null) {
				headerParams
						.addChildParam(OrderUtility.getAttribParamInfo(order.getOrderHeader().getAttribMap(), action));
			}
			if (order.getOrderHeader().getOrderCreatedBy() != null)
				headerParams.addNotNullValChild("OrderCreatedBy", order.getOrderHeader().getOrderCreatedBy(), action);
			if (order.getOrderHeader().isHasBulkOrder()) {
				headerParams.addNotNullValChild("BULK", "Y", action);
			}
			if (order.getOrderHeader().getHotCutIndicator() != null) {
				headerParams.addNotNullValChild("HotCutIndicator", "Y", action);
			}
			if (order.getOrderHeader().getCDDDIndicator() != null) {
				headerParams.addNotNullValChild("CDDDIndicator", "Y", action);
			}
			if (order.getOrderHeader().getSolutionType() != null) {
				headerParams.addNotNullValChild("SolutionType", order.getOrderHeader().getSolutionType().toString(),
						action);
			}
			if (order.getGroupTnEntity().getAuthFeatureType() != null) {
				headerParams.addNotNullValChild("AuthFeatureType", order.getGroupTnEntity().getAuthFeatureType().toString(),
						action);
			}
		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new TranslatorException(ErrorCode.TRANSFORMER_FAILURE,
					"Exception occured in prepareTblOrderDetailsHeaderParamData");
		}

		LOG.info("Exit prepareTblOrderDetailsHeaderParamData");

		return headerParams;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.vz.esap.translation.order.transformer.
	 * DeviceTblOrderDetailsDataTransformer# prepareTblOrderDetailsHeaderParamData(
	 * com.vz.esap.translation.order.model.Order)
	 */
	@Override
	public ParamInfo prepareTblOrderDetailsHeaderParamData(Order order, GroupTNEntity oldGrpTNEntity, boolean supp)
			throws ParseException, TranslatorException {

		LOG.info(
				"Entered - prepareTblOrderDetailsHeaderParamData(Order order, GroupTNEntity oldGrpTNEntity, boolean supp)");
		ParamInfo tnParams = null;
		String action = null;
		try {

//			int oldVersion = Integer.parseInt(order.getOrderHeader().getOrderVersion()) + 1;
			if(order.getOrderHeader() != null) {
				action = order.getOrderHeader().getOrderType();

				tnParams = new ParamInfo("Header", null, action);
				tnParams.addChangeParam("OrderNumber", order.getOrderHeader().getOrderNumber(),
						order.getOrderHeader().getOrderNumber(), supp);
				tnParams.addChangeParam("EnvOrderId", order.getOrderHeader().getEnvOrderId(),
						order.getOrderHeader().getEnvOrderId(), supp);
				tnParams.addChangeParam("MasterOrderNumber", order.getOrderHeader().getMasterOrderNumber(),
						order.getOrderHeader().getMasterOrderNumber(), supp);
				tnParams.addChangeParam("OrderVersion", order.getOrderHeader().getOrderVersion(), order.getOrderHeader().getOrderVersion(), supp);
				tnParams.addChangeParam("TransactionId", order.getOrderHeader().getTransactionId(),
						order.getOrderHeader().getTransactionId(), supp);
				tnParams.addChangeParam(REGION, order.getOrderHeader().getRegion(), order.getOrderHeader().getRegion(),
						supp);
				tnParams.addChangeParam("MinorOrderType", order.getOrderHeader().getMinorOrderType(),
						order.getOrderHeader().getMinorOrderType(), supp);
				tnParams.addChangeParam("CentrexType", order.getOrderHeader().getCentrexType(),
						order.getOrderHeader().getCentrexType(), supp);
				tnParams.addChangeParam("ServiceType", order.getOrderHeader().getServiceType(),
						order.getOrderHeader().getServiceType(), supp);
				tnParams.addChangeParam("OriginatingSystem", order.getOrderHeader().getOriginatingSystem(),
						order.getOrderHeader().getOriginatingSystem(), supp);
				tnParams.addChangeParam("InterfaceSystem", order.getOrderHeader().getInterfaceSystem(),
						order.getOrderHeader().getInterfaceSystem(), supp);
				if(order.getOrderHeader().getOrderType() != null) {
					tnParams.addChangeParam("OrderType",
							EsapEnum.OrderType.getValue(order.getOrderHeader().getOrderType().charAt(0)),
							EsapEnum.OrderType.getValue(order.getOrderHeader().getOrderType().charAt(0)), supp);
				}
				tnParams.addChangeParam("SuppType", order.getOrderHeader().getSuppType(), order.getOrderHeader().getSuppType(), supp);
				tnParams.addChangeParam("OrderClassify", order.getOrderHeader().getFunctionCode(),
						order.getOrderHeader().getFunctionCode(), supp);

				if (order.getOrderHeader().getDueDate() != null) {
					SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
					Date date = format.parse(order.getOrderHeader().getDueDate().toString());
					Calendar calendar = GregorianCalendar.getInstance();
					calendar.setTime(date);
					Object dueDate = calendar.getTime();
					tnParams.addNotNullValChild("DueDate", dueDate, action);
				}
				
				tnParams.addChangeParam("OrderProTIN", order.getOrderHeader().getOrderProTIN(), order.getOrderHeader().getOrderProTIN(), supp);
				tnParams.addChangeParam("IOrderTIN", order.getOrderHeader().getiOrderTIN(), order.getOrderHeader().getiOrderTIN(), supp);
				tnParams.addChangeParam("TINVersion", order.getOrderHeader().getTinVersion(), order.getOrderHeader().getTinVersion(), supp);
				tnParams.addChangeParam("TransitionFlag", order.getOrderHeader().isTransitionFlag() ? "Y" : "N",
						order.getOrderHeader().isTransitionFlag() ? "Y" : "N", supp);
				
				tnParams.addChangeParam("Priority", order.getOrderHeader().getPriority(), order.getOrderHeader().getPriority(), supp);
				
				if (order.getOrderHeader().getOrderCreatedBy() != null)
					tnParams.addChangeParam("OrderCreatedBy", order.getOrderHeader().getOrderCreatedBy(),
							order.getOrderHeader().getOrderCreatedBy(), supp);
				if (order.getOrderHeader().isHasBulkOrder()) {
					tnParams.addChangeParam("BULK", "Y", "Y", supp);
				}
				if (order.getOrderHeader().getHotCutIndicator() != null) {
					tnParams.addChangeParam("HotCutIndicator", "Y", "Y", supp);
				}
				if (order.getOrderHeader().getCDDDIndicator() != null) {
					tnParams.addChangeParam("CDDDIndicator", "Y", "Y", supp);
				}
				if (order.getOrderHeader().getSolutionType() != null) {
					tnParams.addChangeParam("SolutionType", order.getOrderHeader().getSolutionType().toString(),
							order.getOrderHeader().getSolutionType().toString(), supp);
				}

				if (order.getOrderHeader().getDueDate() != null) {
					SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
					Date date = format.parse(order.getOrderHeader().getDueDate().toString());
					Calendar calendar = GregorianCalendar.getInstance();
					calendar.setTime(date);
					Object dueDate = calendar.getTime();
					tnParams.addChangeParam("DueDate", dueDate, dueDate, supp);
				}
				if (order.getLocation() != null && order.getLocation().getCustomerId() != null)
					tnParams.addChangeParam("CustomerId", order.getLocation().getCustomerId(), order.getLocation().getCustomerId(), supp);
				else if (order.getOrderHeader().getCustomerId() != null)
					tnParams.addChangeParam("CustomerId", order.getOrderHeader().getCustomerId(), order.getOrderHeader().getCustomerId(), supp);

				tnParams.addChangeParam("LocationId", order.getOrderHeader().getLocationId(), order.getOrderHeader().getLocationId(), supp);
				// tnParams.addNotNullValChild(BS_APP_SERVER, order.getLocation().getBsAppServer(), action); Fix This
				tnParams.addChangeParam("OrderProTIN", order.getOrderHeader().getOrderProTIN(),
						order.getOrderHeader().getOrderProTIN(), supp);
				tnParams.addChangeParam("IOrderTIN", order.getOrderHeader().getiOrderTIN(),
						order.getOrderHeader().getiOrderTIN(), supp);
				tnParams.addChangeParam("TINVersion", order.getOrderHeader().getTinVersion(),
						order.getOrderHeader().getTinVersion(), supp);
				tnParams.addChangeParam("TransitionFlag", order.getOrderHeader().isTransitionFlag() ? "Y" : "N",
						order.getOrderHeader().isTransitionFlag() ? "Y" : "N", supp);
				tnParams.addChangeParam("Priority", order.getOrderHeader().getPriority(), 
						order.getOrderHeader().getPriority(), supp);
				
				if (order.getOrderHeader().getOrderCreatedBy() != null)
					tnParams.addChangeParam("OrderCreatedBy", order.getOrderHeader().getOrderCreatedBy(),
							order.getOrderHeader().getOrderCreatedBy(), supp);
				if (order.getOrderHeader().isHasBulkOrder()) {
					tnParams.addChangeParam("BULK", "Y", "Y", supp);
				}
				if (order.getOrderHeader().getHotCutIndicator() != null) {
					tnParams.addChangeParam(HOT_CUT_IND, "Y", "Y", supp);
				}
				if (order.getOrderHeader().getCDDDIndicator() != null) {
					tnParams.addChangeParam(CDD_IND, "Y", "Y", supp);
				}
				if (order.getOrderHeader().getSolutionType() != null) {
					tnParams.addChangeParam("SolutionType", order.getOrderHeader().getSolutionType().toString(),
							order.getOrderHeader().getSolutionType().toString(), supp);
				}
				if (order.getGroupTnEntity().getAuthFeatureType() != null) {
					tnParams.addChangeParam("AuthFeatureType", order.getGroupTnEntity().getAuthFeatureType().toString(),
							order.getGroupTnEntity().getAuthFeatureType().toString(), supp);
				}
			}
			
		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new TranslatorException(ErrorCode.TRANSFORMER_FAILURE,
					"Exception occured in prepareTblOrderDetailsHeaderParamData(Order order, GroupTNEntity grpTNEntityPrev, boolean supp)");
		}

		LOG.info(
				"Exit prepareTblOrderDetailsHeaderParamData(Order order, GroupTNEntity grpTNEntityPrev, boolean supp)");

		return tnParams;
	}

	
	/**
	 * @param oldGrpTNEntity
	 * @param newGrpTNEntity
	 * @param supp
	 * @param action
	 * @return paramInfo
	 */
	public ParamInfo prepareTblOrderDetailsEntityParamDataForSystemUpdate(GroupTNEntity oldGrpTNEntity,
			GroupTNEntity newGrpTNEntity, boolean supp, String action) {

		LOG.info(" Entered prepareTblOrderDetailsEntityParamDataForSystemUpdate");
		ParamInfo grpTnParam = new ParamInfo("SystemUpdate", null, null);

		if (oldGrpTNEntity.getTrunkGroupEntity() != null & newGrpTNEntity.getTrunkGroupEntity() != null) {
			grpTnParam.addChangeParam("CustomerId", oldGrpTNEntity.getTrunkGroupEntity().getCustomerId(),
					newGrpTNEntity.getTrunkGroupEntity().getCustomerId(), supp);
			grpTnParam.addChangeParam("LocationId", oldGrpTNEntity.getTrunkGroupEntity().getLocationId(),
					newGrpTNEntity.getTrunkGroupEntity().getLocationId(), supp);
		}

		if (oldGrpTNEntity.getTnCount() >= 1 && newGrpTNEntity.getTnCount() >= 1) {
			grpTnParam.addChangeParam("TnCount", newGrpTNEntity.getTnCount(), newGrpTNEntity.getTnCount(), supp);
		}

		LOG.info(" Exited getTnSystemUpdateParamInfo::SUPP");

		return grpTnParam;
	}
	
	@Override
	public ParamInfo prepareTblOrderDetailsEntityParamDataForGroupTn(GroupTNEntity grpTNEntityPrev,
			GroupTNEntity groupTnEntity, boolean supp, String action) {
		LOG.info("Inside - prepareTblOrderDetailsEntityParamDataForGroupTn Supp");
		return GroupTNUtility.getParamInfo(grpTNEntityPrev, groupTnEntity, supp, action);
	}
	
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.vz.esap.translation.order.transformer.TNTblOrderDetailsDataTransformer#
	 * prepareTblOrderDetailsHeaderParamData(com.vz.esap.translation.order.model.
	 * Order, java.lang.String)
	 */
	@Override
	public ParamInfo prepareTblOrderDetailsHeaderParamData(Order order, String action)
			throws ParseException, TranslatorException {

		LOG.info("Entered - prepareTblOrderDetailsHeaderParamData(Order order, String action)");
		ParamInfo headerParams = null;
		
		try {

			action = order.getOrderHeader().getOrderType();

			headerParams = new ParamInfo("Header", null, action);
			headerParams.addNotNullValChild("OrderNumber", order.getOrderHeader().getOrderNumber(), action);
			headerParams.addNotNullValChild("EnvOrderId", order.getOrderHeader().getEnvOrderId(), action);
			headerParams.addNotNullValChild("MasterOrderNumber", order.getOrderHeader().getMasterOrderNumber(), action);
			headerParams.addNotNullValChild("OrderVersion", order.getOrderHeader().getOrderVersion(), action);
			headerParams.addNotNullValChild("TransactionId", order.getOrderHeader().getTransactionId(), action);
			headerParams.addNotNullValChild("Region", order.getOrderHeader().getRegion(), action);
			headerParams.addNotNullValChild("MinorOrderType", order.getOrderHeader().getMinorOrderType(), action);
			headerParams.addNotNullValChild("CentrexType", order.getOrderHeader().getCentrexType(), action);
			headerParams.addNotNullValChild("ServiceType", order.getOrderHeader().getServiceType(), action);
			headerParams.addNotNullValChild("OriginatingSystem", order.getOrderHeader().getOriginatingSystem(), action);
			headerParams.addNotNullValChild("InterfaceSystem", order.getOrderHeader().getInterfaceSystem(), action);
			headerParams.addNotNullValChild("OrderType",
					EsapEnum.OrderType.getValue(order.getOrderHeader().getOrderType().charAt(0)), action);
			headerParams.addNotNullValChild("SuppType", order.getOrderHeader().getSuppType(), action);
			headerParams.addNotNullValChild("OrderClassify", order.getOrderHeader().getFunctionCode(), action);

			if (order.getOrderHeader().getDueDate() != null) {
				SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
				Date date = format.parse(order.getOrderHeader().getDueDate().toString());
				Calendar calendar = GregorianCalendar.getInstance();
				calendar.setTime(date);
				Object dueDate = calendar.getTime();
				headerParams.addNotNullValChild("DueDate", dueDate, action);
			}
			headerParams.addNotNullValChild("CustomerId", order.getOrderHeader().getCustomerId(), action);
			headerParams.addNotNullValChild("LocationId", order.getOrderHeader().getLocationId(), action);
			headerParams.addNotNullValChild("OrderProTIN", order.getOrderHeader().getOrderProTIN(), action);
			headerParams.addNotNullValChild("IOrderTIN", order.getOrderHeader().getiOrderTIN(), action);
			headerParams.addNotNullValChild("TINVersion", order.getOrderHeader().getTinVersion(), action);
			headerParams.addNotNullValChild("TransitionFlag", order.getOrderHeader().isTransitionFlag() ? "Y" : "N",
					action);
			headerParams.addNotNullValChild("Priority", order.getOrderHeader().getPriority(), action);
			if (order.getOrderHeader().getAttribMap() != null) {
				headerParams
						.addChildParam(OrderUtility.getAttribParamInfo(order.getOrderHeader().getAttribMap(), action));
			}
			if (order.getOrderHeader().getOrderCreatedBy() != null)
				headerParams.addNotNullValChild("OrderCreatedBy", order.getOrderHeader().getOrderCreatedBy(), action);
			if (order.getOrderHeader().isHasBulkOrder()) {
				headerParams.addNotNullValChild("BULK", "Y", action);
			}
			if (order.getOrderHeader().getHotCutIndicator() != null) {
				headerParams.addNotNullValChild("HotCutIndicator", "Y", action);
			}
			if (order.getOrderHeader().getCDDDIndicator() != null) {
				headerParams.addNotNullValChild("CDDDIndicator", "Y", action);
			}
			if (order.getOrderHeader().getSolutionType() != null) {
				headerParams.addNotNullValChild("SolutionType", order.getOrderHeader().getSolutionType().toString(),
						action);
			}
		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new TranslatorException(ErrorCode.TRANSFORMER_FAILURE,
					"Exception occured in prepareTblOrderDetailsHeaderParamData");
		}

		LOG.info("Exit prepareTblOrderDetailsHeaderParamData(Order order, String action)");

		return headerParams;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.vz.esap.translation.order.transformer.TNTblOrderDetailsDataTransformer#
	 * prepareTblOrderDetailsEntityParamDataForGroupTn(com.vz.esap.translation.order
	 * .model.Order, java.lang.String)
	 */
	@Override
	public ParamInfo prepareTblOrderDetailsEntityParamDataForGroupTn(Order order, String action)
			throws TranslatorException {

		LOG.info("Inside - prepareTblOrderDetailsEntityParamDataForGroupTn(Order order, String action)");
		return GroupTNUtility.getParamInfo(order.getGroupTnEntity(), action);

	}
	
}