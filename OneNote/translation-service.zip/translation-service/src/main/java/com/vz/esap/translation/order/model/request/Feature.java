package com.vz.esap.translation.order.model.request;

public class Feature {

	private String Name;

	private String ActionCode;

	private String InstanceId;

	private Specification[] Specification;

	private String Code;

	public String getName() {
		return Name;
	}

	public void setName(String Name) {
		this.Name = Name;
	}

	public String getActionCode() {
		return ActionCode;
	}

	public void setActionCode(String ActionCode) {
		this.ActionCode = ActionCode;
	}

	public String getInstanceId() {
		return InstanceId;
	}

	public void setInstanceId(String InstanceId) {
		this.InstanceId = InstanceId;
	}

	public Specification[] getSpecification() {
		return Specification;
	}

	public void setSpecification(Specification[] Specification) {
		this.Specification = Specification;
	}

	public String getCode() {
		return Code;
	}

	public void setCode(String Code) {
		this.Code = Code;
	}

	public String toString() {
		return "ClassPojo [Feature Name = " + Name + ", ActionCode = " + ActionCode + ", InstanceId = " + InstanceId
				+ ", Specification = " + Specification + ", Code = " + Code + "]";
	}
}
