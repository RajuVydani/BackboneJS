package com.vz.esap.translation.entity;

import java.util.ArrayList;
import java.util.List;

public class ECMInfo {
	private String addressId;
	private List<EmergencyCodeInfo> emercodeInfo;

	public List<EmergencyCodeInfo> getEmercodeInfo() {
		return emercodeInfo;
	}

	public void setEmercodeInfo(List<EmergencyCodeInfo> emercodeInfo) {
		this.emercodeInfo = emercodeInfo;
	}

	public String getAddressId() {
		return addressId;
	}

	public void setAddressId(String addressId) {
		this.addressId = addressId;
	}

	public ParamInfo getParamInfo(String action) {
		ParamInfo ecmparam = new ParamInfo("ECMInfo", null, action);
		ecmparam.addNotNullValChild("AddressId", addressId, action);
		if (null != emercodeInfo && emercodeInfo.size() > 0) {
			for (EmergencyCodeInfo emerInfo : emercodeInfo) {
				ecmparam.addChildParam(emerInfo.getParamInfo(action));
			}
		}
		return ecmparam;
	}

	public ParamInfo getChangeParam(ECMInfo oldEcmInfo, boolean supp) {
		ParamInfo ecmparam = new ParamInfo("ECMInfo", null, null);
		ecmparam.addChangeParam("AddressId", oldEcmInfo.getAddressId(),
				addressId, supp);
		List<EmergencyCodeInfo> oldEmerInfoList = oldEcmInfo.getEmercodeInfo();
		if (null != emercodeInfo && emercodeInfo.size() > 0) {
			if (oldEmerInfoList == null) {
				for (EmergencyCodeInfo emergencyCodeInfo : emercodeInfo) {
					ecmparam.addChildParam(emergencyCodeInfo.getParamInfo("I"));
				}
			} else {
				for (EmergencyCodeInfo emergencyCodeInfo : emercodeInfo) {
					for (EmergencyCodeInfo oldemergencyCodeInfo : oldEmerInfoList) {
						ecmparam.addChildParam(emergencyCodeInfo
								.getChangeParam(oldemergencyCodeInfo, supp));
					}
				}
			}
		} else if (null != oldEmerInfoList) {
			for (EmergencyCodeInfo oldEmergencyCodeInfo : emercodeInfo) {
				ecmparam.addChildParam(oldEmergencyCodeInfo.getParamInfo("O"));
			}
		}
		return ecmparam;
	}

	public static ECMInfo createInstanceFromParamInfo(ParamInfo param) {
		ECMInfo ecmInfo = null;
		if (param != null && param.getChildParams() != null) {
			ecmInfo = new ECMInfo();
			for (ParamInfo childParam : param.getChildParams()) {
				if (childParam.getName().equals("AddressId")) {
					ecmInfo.setAddressId(childParam.getValue());
				} else if (childParam.getName().equals("EmergencyCodeInfo")) {
					ecmInfo.addEmergencyInfo(EmergencyCodeInfo
							.createInstanceFromParamInfo(childParam));
				}
			}
		}
		return ecmInfo;
	}

	private void addEmergencyInfo(EmergencyCodeInfo emercodeInfo) {
		if (this.emercodeInfo == null)
			this.emercodeInfo = new ArrayList<EmergencyCodeInfo>();
		this.emercodeInfo.add(emercodeInfo);
	}

} // EOF
