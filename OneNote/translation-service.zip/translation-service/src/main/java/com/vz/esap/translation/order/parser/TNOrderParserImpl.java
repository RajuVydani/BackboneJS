package com.vz.esap.translation.order.parser;

import static java.util.Arrays.stream;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.vz.esap.translation.dao.model.TblLorTnDetails;
import com.vz.esap.translation.dao.repository.CustomCustomerMapper;
import com.vz.esap.translation.dao.repository.ProcLorUsNonTsoMapper;
import com.vz.esap.translation.dao.repository.TblLorTnDetailsMapper;
import com.vz.esap.translation.entity.Entity.GroupType;
import com.vz.esap.translation.entity.GroupTNEntity;
import com.vz.esap.translation.entity.TNEntity;
import com.vz.esap.translation.entity.TNEntity.PortStatus;
import com.vz.esap.translation.entity.TrunkGroupEntity;
import com.vz.esap.translation.enums.EsapEnum.AuthFeatureType;
import com.vz.esap.translation.enums.EsapEnum.SolutionType;
import com.vz.esap.translation.enums.EsapEnum.TnType;
import com.vz.esap.translation.exception.TranslatorException;
import com.vz.esap.translation.order.model.request.Feature;
import com.vz.esap.translation.order.model.request.OrderParam;
import com.vz.esap.translation.order.model.request.Specification;
import com.vz.esap.translation.order.model.request.VOIPOrderRequest;
import com.vz.esap.translation.order.service.helper.OrderServiceHelper;
import com.vz.esap.translation.util.InventoryUtil;
import com.vz.esap.translation.util.TNUtility;

import EsapEnumPkg.TNEnum;

/**
 * @author baigkh
 *
 */
@Component
public class TNOrderParserImpl implements TNOrderParser {
	private static final Logger LOG = LoggerFactory.getLogger(TNOrderParserImpl.class);

	@Autowired
	private TblLorTnDetailsMapper tblLorTnDetailsMapper;

	@Autowired
	private ProcLorUsNonTsoMapper procLorUsNonTsoMapper;

	@Autowired
	private CustomCustomerMapper customCustomerMapper;
	
	@Autowired
	private InventoryUtil inventoryUtil;
	
	@Autowired
	private OrderServiceHelper orderServiceHelperImpl;
	


	/*
	 * (non-Javadoc)
	 * 
	 * @see com.vz.esap.translation.order.parser.TNOrderParser#fetchTNDetailsFromPC
	 * (com.vz.esap.translation.order.model.request.VOIPOrderRequest) *
	 */
	@Override
	public int fetchTNDetailsFromPC(VOIPOrderRequest voipOrderRequest) throws TranslatorException {

		LOG.info("Entered - fetchTNDetailsFromPC");
		OrderParam params = null;
		int tnCount = 0;//TODO need to fix this as this is Temporary
		List<Feature> lineTrunkFeatures = null;
		List<Feature> locFeatures = null;
		
		try {
			
			params = new OrderParam();
			params.setIn_order_number(voipOrderRequest.getOrderHeader().getWorkOrderNumber());
			params.setIn_order_version(voipOrderRequest.getOrderHeader().getWorkOrderVersion());
			
			if(SolutionType.IPFLEX.equals(voipOrderRequest.getOrderHeader().getSolutionType())) {
				lineTrunkFeatures = stream(voipOrderRequest.getConvergedService().getFeature())
						.filter(trunkFeature -> trunkFeature.getCode().equalsIgnoreCase("FET_XO_TRU_CON_LINE_LOC"))
						.collect(Collectors.toList());
				
				if(!CollectionUtils.isEmpty(lineTrunkFeatures))
					params.setIn_sp_xo_tru_con_line_loc(lineTrunkFeatures.get(0).getInstanceId());			
			}
			
			if (SolutionType.HPBX.equals(voipOrderRequest.getOrderHeader().getSolutionType())) {
				locFeatures = stream(voipOrderRequest.getConvergedService().getFeature())
						.filter(trunkFeature -> trunkFeature.getCode().equalsIgnoreCase("FET_HPBX_LOC_LVL"))
						.collect(Collectors.toList());
				
				if(!CollectionUtils.isEmpty(locFeatures)) {
					List<Specification> tnqSpec = stream(locFeatures.get(0).getSpecification())
					.filter(spec -> spec.getCode().equalsIgnoreCase("SP_XO_TNQ")).collect(Collectors.toList());
					
					if(!tnqSpec.isEmpty()) {
						tnCount = Integer.parseInt(tnqSpec.get(0).getValue());
					} 
				}
				
			}else if (SolutionType.ESIP_EBL.equals(voipOrderRequest.getOrderHeader().getSolutionType()) || SolutionType.IPFLEX.equals(voipOrderRequest.getOrderHeader().getSolutionType())) {
				locFeatures = stream(voipOrderRequest.getConvergedService().getFeature())
						.filter(trunkFeature -> trunkFeature.getCode().equalsIgnoreCase("FET_LOC_LVL"))
						.collect(Collectors.toList());
				
				if(!CollectionUtils.isEmpty(locFeatures)) {
					List<Specification> tnqSpec = stream(locFeatures.get(0).getSpecification())
					.filter(spec -> spec.getCode().equalsIgnoreCase("SP_XO_TNQ")).collect(Collectors.toList());
					
					if(!tnqSpec.isEmpty()) {
						tnCount = Integer.parseInt(tnqSpec.get(0).getValue());
					} 
				}
			}
			
			LOG.info("params.getIn_order_number()-->{}", params.getIn_order_number());
			LOG.info("params.getIn_order_version()-->{}", params.getIn_order_version());
			LOG.info("params.getIn_sp_xo_tru_con_line_loc()-->{}", params.getIn_sp_xo_tru_con_line_loc());
			
			procLorUsNonTsoMapper.getServiceCapIdCount(params);
			LOG.info("TN Count 1: {}", tnCount);
			LOG.info("TN Count 2: {}", params.getT_cnt());//TODO: This needs to be fied

		} catch (Exception e) {
			LOG.error("Exception {}", e);
			throw new TranslatorException(TranslatorException.ErrorCode.PC_TN_FETCH_FAILURE,
			 "Unexpected Error Occur while fetching TN details from PC Database");
		}

		LOG.info("Exited - fetchTNDetailsFromPC");
		return tnCount;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.vz.esap.translation.order.parser.TNOrderParser#processGroupTNS
	 * (com.vz.esap.translation.order.model.request.VOIPOrderRequest,
	 * java.util.ArrayList, int, int)
	 */
	public ArrayList<GroupTNEntity> processGroupTNS(VOIPOrderRequest voipOrderRequest,
			ArrayList<TrunkGroupEntity> trunkGrpList, int stRange, int endRange, long tnCount)
			throws TranslatorException {

		LOG.info("Entered processGroupTNS");
		String locationCountryCode = null;
		GroupTNEntity groupTN = null;
		TNEntity tn = null;
		String entityAction = null;
		String instanceId = null;
		String tnType = null;
		Boolean assignPortingFlag = false;
		Map<String, Object> params = null;
		List<TblLorTnDetails> tnList = null;
		ArrayList<GroupTNEntity> trunkTNs = new ArrayList<>();
		int lowerLimit = 1;
		int upperLimit = 100;
		String region = null;
		Map<Object, List<TblLorTnDetails>> tblLorDetailsGrouped = null;
		boolean grpFound = false;
		locationCountryCode=inventoryUtil.getDialingCountryCode(voipOrderRequest!=null?voipOrderRequest.getOrderHeader()!=null?voipOrderRequest.getOrderHeader().getVoipLocationId():null:null,voipOrderRequest);
		try {
			if (voipOrderRequest.getLocation() != null && voipOrderRequest.getLocation().getLocationAddress() != null
					&& voipOrderRequest.getLocation().getLocationAddress().getCountryCode() != null)
				region = voipOrderRequest.getLocation().getLocationAddress().getCountryCode();

			params = new HashMap<>();
			params.put("in_order_number", voipOrderRequest.getOrderHeader().getWorkOrderNumber());
			params.put("in_order_version", voipOrderRequest.getOrderHeader().getWorkOrderVersion());
			params.put("rn_higher_limit", upperLimit);
			params.put("rn_low_limit", lowerLimit);

			tnList = tblLorTnDetailsMapper.getGroupTNForOrder(params);

			LOG.info("TN List From LorTnDetails Size : {}", tnList.size());

			tblLorDetailsGrouped = tnList.stream()
					.collect(Collectors.groupingBy(lorTn -> lorTn.getBodSvcCapabilityId()));
			
			for (Map.Entry<Object, List<TblLorTnDetails>> tblLorTnDetailsEntry : tblLorDetailsGrouped.entrySet()) {

				groupTN = new GroupTNEntity();
				tn = new TNEntity();

				groupTN.setTnCount(tnCount);

				for (TblLorTnDetails tblLorTnDetails : tblLorTnDetailsEntry.getValue()) {
					
					groupTN.setAsClli(voipOrderRequest.getOrderHeader().getAsClli()); //add broadsoft clli.

					instanceId = tblLorTnDetails.getSvcCapId();
					entityAction = tblLorTnDetails.getCapActionCode();
					tnType = tblLorTnDetails.getTnType();

					LOG.debug("SvcCapId = {} , CapActionCode = {}", instanceId, entityAction);

					if (tnType != null && "trunktn".equalsIgnoreCase(tnType)) {

						LOG.info("TNOrderParserImpl::processGroupTNS Spec Code : {}", tblLorTnDetails.getSpecCode());

						if ("SP_XO_TRU".equalsIgnoreCase(tblLorTnDetails.getSpecCode())
								|| "FET_XO_TRU_CON".equalsIgnoreCase(tblLorTnDetails.getSpecCode())
								|| "SP_XO_TRU_CON_LINE_LOC".equalsIgnoreCase(tblLorTnDetails.getSpecCode())
								|| "SP_XO_TRUID".equalsIgnoreCase(tblLorTnDetails.getSpecCode())
								|| "FET_HPBX_TRU".equalsIgnoreCase(tblLorTnDetails.getSpecCode())) {
							String trnkInstanceId = tblLorTnDetails.getSpecValue();
							LOG.info("TNOrderParserImpl::TrunkGroup InstanceId: {}", trnkInstanceId);
							if (trunkGrpList != null) {
								for (TrunkGroupEntity groupEntity : trunkGrpList) {
									if (groupEntity.getGroupId() != null
											&& groupEntity.getGroupId().toString().equals(trnkInstanceId)) {
										groupTN.setTrunkGroupEntity(groupEntity);
										grpFound = true;
										break;
									}
								}
							}
						}
						if ("ESP_CALLER_ID_FIRST_NAME".equalsIgnoreCase(tblLorTnDetails.getSpecCode())) {
							groupTN.setTnCLIDFirstName(tblLorTnDetails.getSpecValue());
						}
						if ("ESP_CALLER_ID_LAST_NAME".equalsIgnoreCase(tblLorTnDetails.getSpecCode())) {
							groupTN.setTnCLIDLastName(tblLorTnDetails.getSpecValue());
						}
						if ("SP_VOIP_TRUNK_VM_TYPE".equalsIgnoreCase(tblLorTnDetails.getSpecCode())) {
							groupTN.setVmType(tblLorTnDetails.getSpecValue());
						}
						if ("SP_VOIP_TELE_NUM".equalsIgnoreCase(tblLorTnDetails.getSpecCode())
								|| "SP_XO_TEL".equalsIgnoreCase(tblLorTnDetails.getSpecCode())) {
							LOG.info("Telephone Number = {} For SvcCapId = {}", tblLorTnDetails.getSpecValue(),
									instanceId);
							
							if (locationCountryCode != null) {
								tn.setTn(locationCountryCode + tblLorTnDetails.getSpecValue());
							}else
								tn.setTn(tblLorTnDetails.getSpecValue());
						}
						if ("SP_XO_TRU".equalsIgnoreCase(tblLorTnDetails.getSpecCode())
								|| "FET_XO_TRU_CON".equalsIgnoreCase(tblLorTnDetails.getSpecCode())
								|| "SP_XO_TRU_CON_LINE_LOC".equalsIgnoreCase(tblLorTnDetails.getSpecCode())
								|| "SP_XO_TRUID".equalsIgnoreCase(tblLorTnDetails.getSpecCode())
								|| "FET_HPBX_TRU".equalsIgnoreCase(tblLorTnDetails.getSpecCode())) {
							tn.setTrunkId(tblLorTnDetails.getSpecValue());
						}
						
						if(region != null)
							tn.setRegion(region);
						else
							tn.setRegion("US");
						
						if ("ESP_SWITCH_CLLI".equalsIgnoreCase(tblLorTnDetails.getSpecCode())) {
							tn.setSwitchClli(tblLorTnDetails.getSpecValue());
						}
						if ("ESP_VERIZON_BTN".equalsIgnoreCase(tblLorTnDetails.getSpecCode())) {
							if (locationCountryCode != null) {
								tn.setVerizonBTN(locationCountryCode + tblLorTnDetails.getSpecValue());
							}
						}
						if ("ESP_TSP_APPROVAL_CODE".equalsIgnoreCase(tblLorTnDetails.getSpecCode())) {
							tn.setTspCode(tblLorTnDetails.getSpecValue());
						}
						if ("ESP_TRANSITION_TYPE".equalsIgnoreCase(tblLorTnDetails.getSpecCode())) {
							tn.setTransitionType(TNEnum.TransitionType.valueByAcronym(tblLorTnDetails.getSpecValue()));
						}
						if ("SP_VOIP_PORTED_INDICATOR".equalsIgnoreCase(tblLorTnDetails.getSpecCode())
								|| "SP_XO_POR_IND".equalsIgnoreCase(tblLorTnDetails.getSpecCode())) {
							tn.setPortingFlag("N");
							String ported_indicator = tblLorTnDetails.getSpecValue();
							if (!assignPortingFlag) {
								if (ported_indicator != null && ("Yes".equalsIgnoreCase(ported_indicator)
										|| "Y".equalsIgnoreCase(ported_indicator))) {
									tn.setPortingFlag("Y");
								}
							}
							if (null != tn.getPortingFlag() && "N".equalsIgnoreCase(tn.getPortingFlag())) {
								tn.setPortStatus(PortStatus.NATIVE);
							}

							LOG.info(" Porting Type Issue {} :: assignPortingFlag:: {}", ported_indicator,
									assignPortingFlag);
						}
						if ("ESP_LOCATION_EMPTY".equalsIgnoreCase(tblLorTnDetails.getSpecCode())) {
							String locEmpty = tblLorTnDetails.getSpecValue();
							if (locEmpty != null
									&& ("Y".equalsIgnoreCase(locEmpty) || "YES".equalsIgnoreCase(locEmpty))) {
								tn.setOldLocationEmptyFlag(Boolean.TRUE);
							}
						}
						if ("ESP_VOIP_PS_ALI_FLAG".equalsIgnoreCase(tblLorTnDetails.getSpecCode())) {
							String PSALI = tblLorTnDetails.getSpecValue();
							if (PSALI.equalsIgnoreCase("Yes")) {
								tn.setPSALI("Y");
							} else if (PSALI.equalsIgnoreCase("No")) {
								tn.setPSALI("N");
							} else {
								tn.setPSALI(PSALI);
							}
						}
						if ("ESP_DISPLAYED_TN".equalsIgnoreCase(tblLorTnDetails.getSpecCode())) {
							tn.setReplacementCLLI(tblLorTnDetails.getSpecValue());
						}
						if ("ESP_FROM_LOCATION_ID".equalsIgnoreCase(tblLorTnDetails.getSpecCode())) {
							tn.setOldLocationId(tblLorTnDetails.getSpecValue());
						}
						if ("SP_VOIP_TN_DISPOSITION".equalsIgnoreCase(tblLorTnDetails.getSpecCode())) {
							tn.setTnDisposition(tblLorTnDetails.getSpecValue());
						}
						
						//
						
						if ("SP_XO_LID".equalsIgnoreCase(tblLorTnDetails.getSpecCode())) {
							tn.setLidb(tblLorTnDetails.getSpecValue());
						}
						if ("SP_XO_TND".equalsIgnoreCase(tblLorTnDetails.getSpecCode())) {
							tn.setTnDisposition(tblLorTnDetails.getSpecValue());
						}
						if ("SP_XO_EMEFN".equalsIgnoreCase(tblLorTnDetails.getSpecCode())) {
							tn.setEmergencyFirstName(tblLorTnDetails.getSpecValue());
						}
						if ("SP_XO_EMEMN".equalsIgnoreCase(tblLorTnDetails.getSpecCode())) {
							tn.setEmergencyMiddleName(tblLorTnDetails.getSpecValue());
						}
						if ("SP_XO_EMELN".equalsIgnoreCase(tblLorTnDetails.getSpecCode())) {
							tn.setEmergencyLastName(tblLorTnDetails.getSpecValue());
						}
						if ("SP_XO_EMEBD".equalsIgnoreCase(tblLorTnDetails.getSpecCode())) {
							tn.setEmergencyBldngDesignator(tblLorTnDetails.getSpecValue());
						}
						if ("SP_XO_EMEBV".equalsIgnoreCase(tblLorTnDetails.getSpecCode())) {
							tn.setEmergencyBldngValue(tblLorTnDetails.getSpecValue());
						}
						if ("SP_XO_EMEFV".equalsIgnoreCase(tblLorTnDetails.getSpecCode())) {
							tn.setEmergencyFloorValue(tblLorTnDetails.getSpecValue());
						}						
						if ("SP_XO_EMEFD".equalsIgnoreCase(tblLorTnDetails.getSpecCode())) {
							tn.setEmergencyFloorDesignator(tblLorTnDetails.getSpecValue());
						}
						if ("SP_XO_EMERV".equalsIgnoreCase(tblLorTnDetails.getSpecCode())) {
							tn.setEmergencyRoomValue(tblLorTnDetails.getSpecValue());
						}
						if ("SP_XO_EMERD".equalsIgnoreCase(tblLorTnDetails.getSpecCode())) {
							tn.setEmergencyRoomDesignator(tblLorTnDetails.getSpecValue());
						}
						if ("SP_XO_CNA_OFN".equalsIgnoreCase(tblLorTnDetails.getSpecCode())) {
							tn.setCnamOutBoundFirstName(tblLorTnDetails.getSpecValue());
						}
						if ("SP_XO_CNA_OLN".equalsIgnoreCase(tblLorTnDetails.getSpecCode())) {
							tn.setCnamOutBoundLastName(tblLorTnDetails.getSpecValue());
						}
						if ("SP_XO_NEW".equalsIgnoreCase(tblLorTnDetails.getSpecCode())) {
							tn.setNewVerizonBTN(tblLorTnDetails.getSpecValue());
						}
						if ("SP_XO_NEWBTN".equalsIgnoreCase(tblLorTnDetails.getSpecCode())) {
							tn.setNewVerizonBTN(tblLorTnDetails.getSpecValue());
						}
						if ("SP_XO_TNT".equalsIgnoreCase(tblLorTnDetails.getSpecCode())) {
							tn.setTnTypeOrdering(tblLorTnDetails.getSpecValue());
						}
						if ("SP_XO_INDPOR".equalsIgnoreCase(tblLorTnDetails.getSpecCode())) {
							tn.setIndustryPortability(tblLorTnDetails.getSpecValue());
						}
						if ("SP_XO_PORSA".equalsIgnoreCase(tblLorTnDetails.getSpecCode())) {
							tn.setPortingServiceAddress(tblLorTnDetails.getSpecValue());
						}
						if ("SP_XO_INT".equalsIgnoreCase(tblLorTnDetails.getSpecCode())) {
							tn.setIldRestriction(tblLorTnDetails.getSpecValue());
						}
						if ("SP_XO_CUR".equalsIgnoreCase(tblLorTnDetails.getSpecCode())) {
							tn.setCurrentLecBtn(tblLorTnDetails.getSpecValue());
						}						
						if ("SP_NOM".equalsIgnoreCase(tblLorTnDetails.getSpecCode())) {
							tn.setNomadic911(tblLorTnDetails.getSpecValue());
						}
						if ("SP_XO_TNA".equalsIgnoreCase(tblLorTnDetails.getSpecCode())) {
							tn.setTnAssignment(tblLorTnDetails.getSpecValue());
							if (tblLorTnDetails.getSpecValue() != null
									&& (tblLorTnDetails.getSpecValue().contains("Auto Attendant")
											|| tblLorTnDetails.getSpecValue().contains("Hunt Group")
											|| tblLorTnDetails.getSpecValue().contains("Call Center")
											|| tblLorTnDetails.getSpecValue().contains("Voice Portal"))) {
								
								LOG.info("tblLorTnDetails.getSpecValue() for SP_XO_TNA:: {}", tblLorTnDetails.getSpecValue());
								
								tn.setSubscriberId(customCustomerMapper.getSubscriberIdSeqNextVal());
								
								LOG.info("SubscriberId:: {}", tn.getSubscriberId());
							}
						}
						if ("SP_XO_POI".equalsIgnoreCase(tblLorTnDetails.getSpecCode())) {
							tn.setPointToNumber(tblLorTnDetails.getSpecValue());
						}
						if ("SP_XO_PRO".equalsIgnoreCase(tblLorTnDetails.getSpecCode())) {
							tn.setProvider(tblLorTnDetails.getSpecValue());
						}
						if ("SP_XO_HUN".equalsIgnoreCase(tblLorTnDetails.getSpecCode())) {
							tn.setHuntGroupSequence(tblLorTnDetails.getSpecValue());
						}
						
						//

						if ("SP_XO_TRU".equalsIgnoreCase(tblLorTnDetails.getSpecCode())
								|| "FET_XO_TRU_CON".equalsIgnoreCase(tblLorTnDetails.getSpecCode())
								|| "SP_XO_TRU_CON_LINE_LOC".equalsIgnoreCase(tblLorTnDetails.getSpecCode())
								|| "SP_XO_TRUID".equalsIgnoreCase(tblLorTnDetails.getSpecCode())
								|| "FET_HPBX_TRU".equalsIgnoreCase(tblLorTnDetails.getSpecCode())) {
							tn.setTrunkId(tblLorTnDetails.getSpecValue());
							for (TrunkGroupEntity tgEntity : trunkGrpList) {
								LOG.info("tgEntity.getGroupId() :  {}", tgEntity.getGroupId());
								LOG.info("tgEntity.getGroupType() :  {}", tgEntity.getGroupType());

								if (Long.valueOf(tblLorTnDetails.getSpecValue()).equals(tgEntity.getGroupId())) {

									if (tgEntity.getGroupType().equals(GroupType.TWO_WAY)) {
										LOG.info("TWO_WAY_TN : {} ", tgEntity.getGroupId());
										tn.setTnTypeEnum(TnType.TWO_WAY_TN);
									} else if (tgEntity.getGroupType().equals(GroupType.INBOUND)) {
										LOG.info("INBOUND_TN : {} ", tgEntity.getGroupId());
										tn.setTnTypeEnum(TnType.INBOUND_TN);
									} else if (tgEntity.getGroupType().equals(GroupType.PRI_DID)
											|| tgEntity.getGroupType().equals(GroupType.NON_PRI_DID)) {
										LOG.info("DID_TN : {} ", tgEntity.getGroupId());
										tn.setTnTypeEnum(TnType.DID_TN);
									} else if (tgEntity.getGroupType().equals(GroupType.LINE)) {
										LOG.info("LINE_TN : {} ", tgEntity.getGroupId());
										tn.setTnTypeEnum(TnType.LINE_TN);
									}
									groupTN.setGroupId(tgEntity.getGroupId());
									
									if (tgEntity.getDevice() != null) {
										
										LOG.info("1Here with tgEntity.getDevice()--> {} ", tgEntity.getDevice());
										LOG.info("1Here with tgEntity.getDevice().getDeviceName()--> {} "
												, tgEntity.getDevice().getDeviceName());
										
										if (tgEntity.getDevice().getDeviceName() != null) {
											groupTN.setDeviceName(tgEntity.getDevice().getDeviceName());
											tn.setDeviceName(tgEntity.getDevice().getDeviceName());

										}
										if (tgEntity.getDevice().getLinePort() != null) {
											groupTN.setLinePort(tgEntity.getDevice().getLinePort());

										}
									}									
									/*if(tgEntity.getPilotUser() != null && tgEntity.getPilotUser().getLinePort() != null) {
										groupTN.setLinePort(tgEntity.getPilotUser().getLinePort());
									}*/
								}
							}
						}
						groupTN.setRegion(region);
						groupTN.setGroupTNId(customCustomerMapper.getGroupTnIdSeqNextVal());
						groupTN.setEntityAction(entityAction);

						
						//Start: Time Zone Fix
						
						//Time Zone :
						if (voipOrderRequest.getAdditionalInfo() != null
								&& voipOrderRequest.getAdditionalInfo().getTimeZone() != null) {
							String timeZone = inventoryUtil.getTimeZoneId(voipOrderRequest.getAdditionalInfo().getTimeZone());					
							
							groupTN.setTimeZoneId(timeZone != null? timeZone : "26");
							
						}else {
							groupTN.setTimeZoneId("26");
						}
						
						LOG.info("Time Zone is {}", groupTN.getTimeZoneId());
						
						
						//Day Light Saving :
						
						if (voipOrderRequest.getAdditionalInfo() != null
								&& voipOrderRequest.getAdditionalInfo().getDayLightSavingsInd() != null) {
							
							groupTN.setDayLightSavingInd(voipOrderRequest.getAdditionalInfo().getDayLightSavingsInd());
							
						}else {
							groupTN.setDayLightSavingInd("N");
						}
						
						LOG.info("Day Light Saving Indicator is {}", groupTN.getDayLightSavingInd());
						
						//End: Time Zone Fix
						
						if (Arrays.asList(SolutionType.ESIP_ESL, SolutionType.ESIP_EBL)
								.contains(voipOrderRequest.getOrderHeader().getSolutionType())) {
							groupTN.setAuthFeatureType(AuthFeatureType.FET_ESIP);
						} else if (SolutionType.IPFLEX.equals(voipOrderRequest.getOrderHeader().getSolutionType())) {
							groupTN.setAuthFeatureType(orderServiceHelperImpl.getAuthFeatureType(voipOrderRequest));
						} else if (SolutionType.HPBX.equals(voipOrderRequest.getOrderHeader().getSolutionType())) {
							groupTN.setAuthFeatureType(AuthFeatureType.FET_HPBX);
						}

					} // End of if - TrunkTN
				} // End of For - TblLorTnDetails

				groupTN.setTnRecord(tn);
				trunkTNs.add(groupTN);
			}

		} catch (Exception e) {
			LOG.error("Exception {}", e);
			throw new TranslatorException(TranslatorException.ErrorCode.PARSER_EXCEPTION,
					"Unexpected Error Occur while processing Group TNs from TBL_LOR_TN_DETAILS ");

		}

		LOG.info("Exited processGroupTNS");

		return trunkTNs;

	}
	
	/* (non-Javadoc)
	 * @see com.vz.esap.translation.order.parser.TNOrderParser#fetchChangeTNDetailsFromPC(com.vz.esap.translation.order.model.request.VOIPOrderRequest)
	 */
	@Override
	public int fetchChangeTNDetailsFromPC(VOIPOrderRequest voipOrderRequest) throws TranslatorException {

		LOG.info("Entered - fetchChangeTNDetailsFromPC");
		OrderParam params = null;
		int tnCount = 0;
		
		try {
			params = new OrderParam();
			params.setIn_order_number(voipOrderRequest.getOrderHeader().getWorkOrderNumber());
			params.setIn_order_version(voipOrderRequest.getOrderHeader().getWorkOrderVersion());
			procLorUsNonTsoMapper.getChangedTnDetails(params);
			tnCount = 1;

		} catch (Exception e) {
			LOG.error("Exception {}", e);
			LOG.error("Exception Message {}", e.getMessage());
			throw new TranslatorException(TranslatorException.ErrorCode.PC_TN_FETCH_FAILURE,
			 "Unexpected Error Occur while fetching CHANGED TN details from PC Database");
		}

		LOG.info("Exited - fetchChangeTNDetailsFromPC");
		
		return tnCount;
	}
}
