package com.vz.esap.translation.order.transformer;

import static java.util.Arrays.stream;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.vz.esap.translation.dao.model.TblConfigParams;
import com.vz.esap.translation.dao.model.TblEnvOrder;
import com.vz.esap.translation.dao.model.TblOrderPrioritySettings;
import com.vz.esap.translation.dao.repository.CustomCustomerMapper;
import com.vz.esap.translation.dao.repository.CustomTblOrderPrioritySettingsMapper;
import com.vz.esap.translation.enums.EsapEnum.OrderAction;
import com.vz.esap.translation.enums.EsapEnum.OrderCategory;
import com.vz.esap.translation.enums.EsapEnum.ServiceType;
import com.vz.esap.translation.enums.EsapEnum.SolutionType;
import com.vz.esap.translation.exception.TranslatorException;
import com.vz.esap.translation.exception.TranslatorException.ErrorCode;
import com.vz.esap.translation.order.dao.VOIPOrderDao;
import com.vz.esap.translation.order.model.Order;
import com.vz.esap.translation.order.model.request.Feature;
import com.vz.esap.translation.order.model.request.Specification;
import com.vz.esap.translation.order.model.request.VOIPOrderRequest;
import com.vz.esap.translation.order.parser.OrderParser;
import com.vz.esap.translation.order.service.helper.OrderServiceHelperImpl;
import com.vz.esap.translation.util.OrderUtility;

import EsapEnumPkg.WorkOrderEnum;
import EsapEnumPkg.WorkOrderEnum.OrderClassify;
import reactor.util.CollectionUtils;

/**
 * @author chattni
 *
 */
@Component
public class EnterpriseEnvelopOrderTransformerImpl implements EnterpriseEnvelopOrderTransformer {

	private static final Logger LOG = LoggerFactory.getLogger(EnterpriseEnvelopOrderTransformerImpl.class);

	@Autowired
	private CustomCustomerMapper customCustomerMapper;

	@Autowired
	private VOIPOrderDao voipOrderDao;

	@Autowired
	private CustomTblOrderPrioritySettingsMapper customTblOrderPrioritySettingsMapper;

	@Autowired
	private OrderServiceHelperImpl orderServiceHelperImpl;

	@Autowired
	private OrderParser orderParserImpl;

	@Value("${source.address}")
	private String sourceAddress;

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.vz.esap.translation.order.transformer.EnterpriseEnvelopOrderTransformer#
	 * createTblEnvOrderFromVOIPOrderRequest(com.vz.esap.translation.order.model.
	 * request.VOIPOrderRequest, int)
	 */
	@Override
	public TblEnvOrder createTblEnvOrderFromVOIPOrderRequest(VOIPOrderRequest voipOrderRequest, int status) {

		LOG.info("EnterpriseEnvelopOrderTransformerImpl - createTblEnvOrderFromVOIPOrderRequest");

		long envOrderId = customCustomerMapper.getEnvOrderIdSeqNextVal();

		TblEnvOrder tblEnvOrderObject = new TblEnvOrder();
		tblEnvOrderObject.setEnvOrderId(envOrderId);
		tblEnvOrderObject.setSequenceNo(voipOrderRequest.getSequenceNumber());
		tblEnvOrderObject.setTransactionId(Long.valueOf(voipOrderRequest.getOrderHeader().getTransactionID()));
		// tblEnvOrderObject.setPrevPassEnvOrderId(-1L); // Fix this for Supp

		if (voipOrderRequest.getOrderHeader().getOriginatingSystem() == null) {
			tblEnvOrderObject.setSystem("PC");
		} else {
			tblEnvOrderObject.setSystem(voipOrderRequest.getOrderHeader().getOriginatingSystem());
		}
		tblEnvOrderObject.setOrderNumber(voipOrderRequest.getOrderHeader().getWorkOrderNumber());
		tblEnvOrderObject.setVersionNumber(Long.valueOf(voipOrderRequest.getOrderHeader().getWorkOrderVersion()));

		tblEnvOrderObject.setOrigin(voipOrderRequest.getOrderHeader().getOriginatingSystem());
		if (voipOrderRequest.getOrderHeader().getUNOServiceId() != null) {
			tblEnvOrderObject.setMasterOrderNumber(voipOrderRequest.getOrderHeader().getUNOServiceId());
		} else {
			tblEnvOrderObject.setMasterOrderNumber(voipOrderRequest.getOrderHeader().getWorkOrderNumber());
		}

		tblEnvOrderObject.setClli("CLLI");

		if (voipOrderRequest.getLocation() != null && voipOrderRequest.getLocation().getLocationAddress() != null
				&& voipOrderRequest.getLocation().getLocationAddress().getCountryCode() != null) {
			tblEnvOrderObject.setRegion(voipOrderRequest.getLocation().getLocationAddress().getCountryCode());
		} else if (voipOrderRequest.getOrderHeader().getRegion() == null) {
			tblEnvOrderObject.setRegion("US");
		} else {
			tblEnvOrderObject.setRegion(voipOrderRequest.getOrderHeader().getRegion());
		}
		if (voipOrderRequest.getOrderHeader().getCentrexType() == null) {
			tblEnvOrderObject.setJurisdiction("ESAP");
		} else {
			tblEnvOrderObject.setJurisdiction("ESAP");
		}
		LOG.info("sourceAddress : {}", sourceAddress);
		tblEnvOrderObject.setSourceAddr(sourceAddress);
		tblEnvOrderObject.setErrorCode(null);

		tblEnvOrderObject.setReceiveDate(null);
		Date date = new Date();
		String dueDate = new SimpleDateFormat("dd-MMM-yy").format(date);
		LOG.info("date - createTblEnvOrderFromVOIPOrderRequest:: {}", dueDate);
		if (voipOrderRequest.getOrderHeader().getDueDate() == null) {
			tblEnvOrderObject.setDueDate(dueDate);
		} else {
			tblEnvOrderObject.setDueDate(voipOrderRequest.getOrderHeader().getDueDate());
		}
		LOG.info("date after - createTblEnvOrderFromVOIPOrderRequest :: {}", dueDate);
		tblEnvOrderObject.setOrderType(
				OrderUtility.getOrderTypeEnum(voipOrderRequest.getOrderHeader().getOrderType().charAt(0)));
		tblEnvOrderObject.setOrderStatus(Long.valueOf(status));

		if (null != voipOrderRequest.getOrderHeader().getCentrexType() && OrderUtility
				.isOneOf(voipOrderRequest.getOrderHeader().getCentrexType(), true, "IPAC", "IPAC1", "IPAC2")) {
			tblEnvOrderObject.setProjectId("RA");
		} else {
			tblEnvOrderObject.setProjectId("R");
		}
		tblEnvOrderObject.setOrderPriority(getOrderPriority(tblEnvOrderObject.getEnvOrderId(), voipOrderRequest,
				tblEnvOrderObject.getProjectId(), tblEnvOrderObject.getOrderType()));
		if (voipOrderRequest.getOrderHeader().getSolutionType().equals(SolutionType.ESIP_ESL))
			tblEnvOrderObject.setOrderCategory(OrderCategory.ESIP_ESL.getValue());
		else if (voipOrderRequest.getOrderHeader().getSolutionType().equals(SolutionType.ESIP_EBL))
			tblEnvOrderObject.setOrderCategory(OrderCategory.ESIP_EBL.getValue());
		else if (voipOrderRequest.getOrderHeader().getSolutionType().equals(SolutionType.IPFLEX))
			tblEnvOrderObject.setOrderCategory(OrderCategory.IPFLEX.getValue());
		else if (voipOrderRequest.getOrderHeader().getSolutionType().equals(SolutionType.HPBX))
			tblEnvOrderObject.setOrderCategory(OrderCategory.HPBX.getValue());
		else
			tblEnvOrderObject.setOrderCategory(voipOrderRequest.getOrderHeader().getCentrexType());

		List<Feature> vpnFeat = new ArrayList<Feature>();
		if (voipOrderRequest.getConvergedService() != null
				&& voipOrderRequest.getConvergedService().getFeature() != null) {
			vpnFeat = stream(voipOrderRequest.getConvergedService().getFeature())
					.filter(feature -> feature.getCode().equalsIgnoreCase("FET_IPFVPN")).collect(Collectors.toList());
		}

		if (voipOrderRequest.getOrderHeader().getOrderClassify() == WorkOrderEnum.OrderClassify.PIT) {
			voipOrderRequest.getOrderHeader().setServiceType("PIT");
			tblEnvOrderObject.setServiceType(voipOrderRequest.getOrderHeader().getServiceType());

		} else if ((OrderAction.ADD.getValue().equalsIgnoreCase(voipOrderRequest.getOrderHeader().getOrderType())
				|| OrderAction.MODIFY.getValue().equalsIgnoreCase(voipOrderRequest.getOrderHeader().getOrderType()))
				&& SolutionType.ESIP_ESL.toString()
						.equalsIgnoreCase(voipOrderRequest.getOrderHeader().getSolutionType().toString())) {

			tblEnvOrderObject.setServiceType(ServiceType.ESIP_ESL_INSTAL.getValue());

		} else if ((OrderAction.ADD.getValue().equalsIgnoreCase(voipOrderRequest.getOrderHeader().getOrderType())
				|| OrderAction.MODIFY.getValue().equalsIgnoreCase(voipOrderRequest.getOrderHeader().getOrderType()))
				&& SolutionType.ESIP_EBL.toString()
						.equalsIgnoreCase(voipOrderRequest.getOrderHeader().getSolutionType().toString())) {

			tblEnvOrderObject.setServiceType(ServiceType.ESIP_EBL_INSTAL.getValue());

		} else if ((OrderAction.ADD.getValue().equalsIgnoreCase(voipOrderRequest.getOrderHeader().getOrderType())
				|| OrderAction.MODIFY.getValue().equalsIgnoreCase(voipOrderRequest.getOrderHeader().getOrderType()))
				&& SolutionType.IPFLEX.toString().equalsIgnoreCase(
						voipOrderRequest.getOrderHeader().getSolutionType().toString())
				&& !vpnFeat.isEmpty()) {

			tblEnvOrderObject.setServiceType(ServiceType.IPFLEX_BUNDLE_INSTAL.getValue());

		} else if ((OrderAction.ADD.getValue().equalsIgnoreCase(voipOrderRequest.getOrderHeader().getOrderType())
				|| OrderAction.MODIFY.getValue().equalsIgnoreCase(voipOrderRequest.getOrderHeader().getOrderType()))
				&& SolutionType.IPFLEX.toString().equalsIgnoreCase(
						voipOrderRequest.getOrderHeader().getSolutionType().toString())
				&& vpnFeat.isEmpty()) {

			tblEnvOrderObject.setServiceType(ServiceType.IPFLEX_STANDALONE_INSTAL.getValue());

		} else if ((OrderAction.ADD.getValue().equalsIgnoreCase(voipOrderRequest.getOrderHeader().getOrderType())
				|| OrderAction.MODIFY.getValue().equalsIgnoreCase(voipOrderRequest.getOrderHeader().getOrderType()))
				&& SolutionType.HPBX.toString().equalsIgnoreCase(
						voipOrderRequest.getOrderHeader().getSolutionType().toString())
				&& vpnFeat.isEmpty()) {

			tblEnvOrderObject.setServiceType(ServiceType.HPBX_INSTAL.getValue());

		} else if (OrderAction.DISCONNECT.getValue().equalsIgnoreCase(voipOrderRequest.getOrderHeader().getOrderType())
				&& SolutionType.ESIP_ESL.toString()
						.equalsIgnoreCase(voipOrderRequest.getOrderHeader().getSolutionType().toString())) {

			tblEnvOrderObject.setServiceType(ServiceType.ESIP_ESL_DISC.getValue());

		} else if (OrderAction.DISCONNECT.getValue().equalsIgnoreCase(voipOrderRequest.getOrderHeader().getOrderType())
				&& SolutionType.ESIP_EBL.toString()
						.equalsIgnoreCase(voipOrderRequest.getOrderHeader().getSolutionType().toString())) {

			tblEnvOrderObject.setServiceType(ServiceType.ESIP_EBL_DISC.getValue());

		} else if (OrderAction.DISCONNECT.getValue().equalsIgnoreCase(voipOrderRequest.getOrderHeader().getOrderType())
				&& SolutionType.IPFLEX.toString().equalsIgnoreCase(
						voipOrderRequest.getOrderHeader().getSolutionType().toString())
				&& !vpnFeat.isEmpty()) {

			tblEnvOrderObject.setServiceType(ServiceType.IPFLEX_BUNDLE_DISC.getValue());

		} else if (OrderAction.DISCONNECT.getValue().equalsIgnoreCase(voipOrderRequest.getOrderHeader().getOrderType())
				&& SolutionType.IPFLEX.toString().equalsIgnoreCase(
						voipOrderRequest.getOrderHeader().getSolutionType().toString())
				&& vpnFeat.isEmpty()) {

			tblEnvOrderObject.setServiceType(ServiceType.IPFLEX_STANDALONE_DISC.getValue());

		} else if (OrderAction.DISCONNECT.getValue().equalsIgnoreCase(voipOrderRequest.getOrderHeader().getOrderType())
				&& SolutionType.HPBX.toString().equalsIgnoreCase(
						voipOrderRequest.getOrderHeader().getSolutionType().toString())
				&& vpnFeat.isEmpty()) {

			tblEnvOrderObject.setServiceType(ServiceType.HPBX_DISC.getValue());

		}

		if (voipOrderRequest.getOrderHeader().getFunctionCode().equalsIgnoreCase("VALIDATE")) {
			tblEnvOrderObject.setOrderClassify(Long.valueOf(WorkOrderEnum.OrderClassify.VALIDATE));

		} else if (voipOrderRequest.getOrderHeader().getFunctionCode().equalsIgnoreCase("REL_SUSPEND")) {
			tblEnvOrderObject.setOrderClassify(Long.valueOf(WorkOrderEnum.OrderClassify.REL_SUSPEND));

		} else if (voipOrderRequest.getOrderHeader().getFunctionCode().equalsIgnoreCase("REL_DEACTIVATE")) {
			tblEnvOrderObject.setOrderClassify(Long.valueOf(WorkOrderEnum.OrderClassify.REL_DEACTIVATE));

		} else if (voipOrderRequest.getOrderHeader().getFunctionCode().equalsIgnoreCase("LNP_ACTIVATE")) {
			tblEnvOrderObject.setOrderClassify(Long.valueOf(WorkOrderEnum.OrderClassify.LNP_ACTIVATE));

		} else if (voipOrderRequest.getOrderHeader().getFunctionCode().equalsIgnoreCase("RELEASE")) {
			tblEnvOrderObject.setOrderClassify(Long.valueOf(WorkOrderEnum.OrderClassify.RELEASE));

		}
		
		tblEnvOrderObject.setMainTn("-1");
		tblEnvOrderObject.setNewPassWaiting("N");
		tblEnvOrderObject.setEnterpriseId(voipOrderRequest.getOrderHeader().getEnterpriseId());
		if (voipOrderRequest.getOrderHeader().getLocationId() != null) {
			tblEnvOrderObject.setLocationId(voipOrderRequest.getOrderHeader().getLocationId());
		} else {
			tblEnvOrderObject.setLocationId(voipOrderRequest.getOrderHeader().getVoipLocationId());
		}

		if (voipOrderRequest.getOrderHeader().getMinorOrderType() != null) {
			tblEnvOrderObject.setMinorOrderType(voipOrderRequest.getOrderHeader().getMinorOrderType());
		} else {
			tblEnvOrderObject.setMinorOrderType(orderServiceHelperImpl.getMinorOrderType(voipOrderRequest));
		}

		if (voipOrderRequest.getOrderHeader().getExpedite() == true) {
			tblEnvOrderObject.setExpedite("Y");
		} else {
			tblEnvOrderObject.setExpedite("N");
		}
		if (voipOrderRequest.getOrderHeader().getBulkOrder() != null) {
			tblEnvOrderObject.setBulkOrder(voipOrderRequest.getOrderHeader().getBulkOrder());
		} else {
			tblEnvOrderObject.setBulkOrder("N");
		}
		if (voipOrderRequest.getOrderHeader().getVzId() != null) {
			tblEnvOrderObject.setVzId(voipOrderRequest.getOrderHeader().getVzId());
		} else {
			tblEnvOrderObject.setVzId("DUMMYVZID");
		}

		// TODO Disconn Niladri - converged service & Features will be null for
		// Disconnect requests DONE
		if (voipOrderRequest.getConvergedService() != null
				&& voipOrderRequest.getConvergedService().getFeature() != null) {
			Feature[] convergedServiceFeatures = voipOrderRequest.getConvergedService().getFeature();
			for (Feature feature : convergedServiceFeatures) {
				if ("EFET_VOIP_ENT_LVL".equalsIgnoreCase(feature.getCode())) {
					Specification[] specificationList = feature.getSpecification();
					for (Specification specification : specificationList) {
						if (specification.getCode().equalsIgnoreCase("ESP_ENTERPRISE_NAME")) {
							tblEnvOrderObject.setCustomerName(specification.getValue());
						}
					}
				}
				tblEnvOrderObject.setLocationId(voipOrderRequest.getOrderHeader().getVoipLocationId());
			}
		}
		return tblEnvOrderObject;
	}

	/**
	 * @param envOrderId
	 * @param voipOrderRequest
	 * @param projectId
	 * @param orderType
	 * @return priority
	 */
	private Long getOrderPriority(Long envOrderId, VOIPOrderRequest voipOrderRequest, String projectId,
			long orderType) {
		long priority = 20;
		HashMap<String, String> ordPrioCols = new HashMap<String, String>();
		ordPrioCols.put("ProjectId", projectId);
		ordPrioCols.put("ORDER_SOURCE", voipOrderRequest.getOrderHeader().getOriginatingSystem());
		ordPrioCols.put("ORDER_TYPE", OrderUtility.getOrderTypeChar((int) orderType));
		if (voipOrderRequest.getOrderHeader().getMinorOrderType() != null)
			ordPrioCols.put("MINOR_ORDER_TYPE", voipOrderRequest.getOrderHeader().getMinorOrderType().substring(0, 1));
		ordPrioCols.put("FUNCTION_CODE",
				WorkOrderEnum.OrderClassify.acronym(voipOrderRequest.getOrderHeader().getOrderClassify()));
		ordPrioCols.put("BULK_ORDER", voipOrderRequest.getOrderHeader().getBulkOrder());
		ordPrioCols.put("EXPEDITE", voipOrderRequest.getOrderHeader().getExpedite() == true ? "1" : "0");

		List<TblOrderPrioritySettings> tblOrderPrioritySettingsList = getOrderPrioritySettings(ordPrioCols);

		if (tblOrderPrioritySettingsList.size() > 0) {
			for (TblOrderPrioritySettings tblOrderPrioritySettings : tblOrderPrioritySettingsList) {
				priority = tblOrderPrioritySettings.getPriority();
				break;
			}
		}

		return priority;
	}

	/**
	 * @param ordPrioCols
	 * @return tblOrderPrioritySettingsList
	 */
	public List<TblOrderPrioritySettings> getOrderPrioritySettings(HashMap<String, String> ordPrioCols) {
		LOG.info("Entered getOrderPrioritySettings apii");
		List<TblOrderPrioritySettings> tblOrderPrioritySettingsList = new ArrayList<TblOrderPrioritySettings>();
		tblOrderPrioritySettingsList = customTblOrderPrioritySettingsMapper.getOrderPrioritySettings(ordPrioCols);
		LOG.info("Exit getOrderPrioritySettings apii");
		return tblOrderPrioritySettingsList;
	}

	/**
	 * @return customCustomerMapper
	 */
	public CustomCustomerMapper getCustomCustomerMapper() {
		return customCustomerMapper;
	}

	/**
	 * @param customCustomerMapper
	 */
	public void setCustomCustomerMapper(CustomCustomerMapper customCustomerMapper) {
		this.customCustomerMapper = customCustomerMapper;
	}

	/**
	 * @return customTblOrderPrioritySettingsMapper
	 */
	public CustomTblOrderPrioritySettingsMapper getCustomTblOrderPrioritySettingsMapper() {
		return customTblOrderPrioritySettingsMapper;
	}

	/**
	 * @param customTblOrderPrioritySettingsMapper
	 */
	public void setCustomTblOrderPrioritySettingsMapper(
			CustomTblOrderPrioritySettingsMapper customTblOrderPrioritySettingsMapper) {
		this.customTblOrderPrioritySettingsMapper = customTblOrderPrioritySettingsMapper;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.vz.esap.translation.order.transformer.EnterpriseEnvelopOrderTransformer#
	 * createTblEnvOrderFromOrder(com.vz.esap.translation.order.model.Order,
	 * com.vz.esap.translation.order.model.request.VOIPOrderRequest)
	 */
	public TblEnvOrder createTblEnvOrderFromOrder(Order order, VOIPOrderRequest voipOrderRequest)
			throws TranslatorException {
		LOG.info("Entered - createTblEnvOrderFromOrder");

		TblEnvOrder tblEnvOrderObject = null;
		TblConfigParams tblConfigParams = null;
		long envOrderId = -1;
		List<TblConfigParams> vzIdTblConfigParams = null;
		List<TblEnvOrder> tblEnvOrderListPrev = null;
		VOIPOrderRequest voipOrderRequestPrev = null;

		try {

			tblEnvOrderObject = new TblEnvOrder();

			envOrderId = customCustomerMapper.getEnvOrderIdSeqNextVal();

			LOG.info("createTblEnvOrderFromOrder : envOrderId {}", envOrderId);

			tblEnvOrderObject.setEnvOrderId(envOrderId);
			tblEnvOrderObject.setSequenceNo(order.getOrderHeader().getSequenceNumber());

			if (order.getOrderHeader().getTransactionId() != null)
				tblEnvOrderObject.setTransactionId(Long.valueOf(order.getOrderHeader().getTransactionId().toString()));

			if (voipOrderRequest != null) {
				if (voipOrderRequest.getOrderHeader().getWorkOrderVersion() != "0") {

					voipOrderRequestPrev = orderParserImpl.getCorrectPrevPassVoipOrderRequest(voipOrderRequest);

					tblEnvOrderListPrev = orderServiceHelperImpl.getMatchingPrevPassEnvOrder(voipOrderRequestPrev, 0,
							0);
					if (!CollectionUtils.isEmpty(tblEnvOrderListPrev))
						tblEnvOrderObject.setPrevPassEnvOrderId(tblEnvOrderListPrev.get(0).getEnvOrderId());
				}
			}

			if (order.getOrderHeader().getOriginatingSystem() == null) {
				tblEnvOrderObject.setSystem("PC");
			} else {
				tblEnvOrderObject.setSystem(order.getOrderHeader().getOriginatingSystem());
			}
			tblEnvOrderObject.setOrderNumber(order.getOrderHeader().getOrderNumber());
			tblEnvOrderObject.setVersionNumber(Long.parseLong(order.getOrderHeader().getOrderVersion()));
			tblEnvOrderObject.setOrigin(order.getOrderHeader().getOriginatingSystem());
			if (order.getOrderHeader().getMasterOrderNumber() != null) {
				tblEnvOrderObject.setMasterOrderNumber(order.getOrderHeader().getMasterOrderNumber());
			} else {
				tblEnvOrderObject.setMasterOrderNumber(order.getOrderHeader().getWorkOrderNumber());
			}

			tblEnvOrderObject.setClli("CLLI");
			if (order.getOrderHeader().getRegion() == null) {
				tblEnvOrderObject.setRegion("US");
			} else {
				tblEnvOrderObject.setRegion(order.getOrderHeader().getRegion());
			}
			if (order.getOrderHeader().getCentrexType() == null) {
				tblEnvOrderObject.setJurisdiction("ESAP");
			} else {
				tblEnvOrderObject.setJurisdiction("ESAP");
			}
			LOG.info("sourceAddress : {}", sourceAddress);
			tblEnvOrderObject.setSourceAddr(sourceAddress);
			tblEnvOrderObject.setErrorCode(null);

			Date date = new Date();
			String orderTimeStamp = new SimpleDateFormat("dd-MMM-yy").format(date);
			if (order.getOrderHeader().getOrderReceiveTimeStamp() != null) {
				tblEnvOrderObject.setReceiveDate(orderTimeStamp);
			} else {
				tblEnvOrderObject.setReceiveDate(orderTimeStamp);
			}

			if (order.getOrderHeader().getDueDate() == null) {
				tblEnvOrderObject.setDueDate(orderTimeStamp);
			} else {
				tblEnvOrderObject.setDueDate(order.getOrderHeader().getDueDate().toString());
			}

			tblEnvOrderObject
					.setOrderType(OrderUtility.getOrderTypeEnum(order.getOrderHeader().getOrderType().charAt(0)));
			tblEnvOrderObject.setOrderStatus(Long.valueOf(order.getOrderHeader().getOrderStatus()));
			if (null != order.getOrderHeader().getCentrexType()
					&& OrderUtility.isOneOf(order.getOrderHeader().getCentrexType(), true, "IPAC", "IPAC1", "IPAC2")) {
				tblEnvOrderObject.setProjectId("RA");
			} else {
				tblEnvOrderObject.setProjectId("R");
			}
			tblEnvOrderObject.setOrderPriority(getOrderPriorityForOrder(order));

			if (order.getOrderHeader().getSolutionType().equals(SolutionType.ESIP_ESL))
				tblEnvOrderObject.setOrderCategory(OrderCategory.ESIP_ESL.getValue());
			else if (order.getOrderHeader().getSolutionType().equals(SolutionType.ESIP_EBL))
				tblEnvOrderObject.setOrderCategory(OrderCategory.ESIP_EBL.getValue());
			else if (order.getOrderHeader().getSolutionType().equals(SolutionType.IPFLEX))
				tblEnvOrderObject.setOrderCategory(OrderCategory.IPFLEX.getValue());
			else if (order.getOrderHeader().getSolutionType().equals(SolutionType.HPBX))
				tblEnvOrderObject.setOrderCategory(OrderCategory.HPBX.getValue());
			else
				tblEnvOrderObject.setOrderCategory(order.getOrderHeader().getCentrexType());

			if (order.getOrderHeader().getOrderClassify() == WorkOrderEnum.OrderClassify.PIT) {
				order.getOrderHeader().setServiceType("PIT");
				tblEnvOrderObject.setServiceType(order.getOrderHeader().getServiceType());
			} else if ((OrderAction.ADD.getValue().equalsIgnoreCase(order.getOrderHeader().getOrderType())
					|| OrderAction.MODIFY.getValue().equalsIgnoreCase(order.getOrderHeader().getOrderType()))
					&& SolutionType.ESIP_ESL.toString()
							.equalsIgnoreCase(order.getOrderHeader().getSolutionType().toString())) {
				tblEnvOrderObject.setServiceType(ServiceType.ESIP_ESL_INSTAL.getValue());
			} else if ((OrderAction.ADD.getValue().equalsIgnoreCase(order.getOrderHeader().getOrderType())
					|| OrderAction.MODIFY.getValue().equalsIgnoreCase(order.getOrderHeader().getOrderType()))
					&& SolutionType.ESIP_EBL.toString()
							.equalsIgnoreCase(order.getOrderHeader().getSolutionType().toString())) {
				tblEnvOrderObject.setServiceType(ServiceType.ESIP_EBL_INSTAL.getValue());
			} else if ((OrderAction.ADD.getValue().equalsIgnoreCase(order.getOrderHeader().getOrderType())
					|| OrderAction.MODIFY.getValue().equalsIgnoreCase(order.getOrderHeader().getOrderType()))
					&& SolutionType.IPFLEX.toString()
							.equalsIgnoreCase(order.getOrderHeader().getSolutionType().toString())) {
				tblEnvOrderObject.setServiceType(ServiceType.IPFLEX_INSTAL.getValue());
			} else if ((OrderAction.ADD.getValue().equalsIgnoreCase(order.getOrderHeader().getOrderType())
					|| OrderAction.MODIFY.getValue().equalsIgnoreCase(order.getOrderHeader().getOrderType()))
					&& SolutionType.HPBX.toString()
							.equalsIgnoreCase(order.getOrderHeader().getSolutionType().toString())) {
				tblEnvOrderObject.setServiceType(ServiceType.HPBX_INSTAL.getValue());

			} else if ((OrderAction.DISCONNECT.getValue().equalsIgnoreCase(order.getOrderHeader().getOrderType()))
					&& SolutionType.ESIP_ESL.toString()
							.equalsIgnoreCase(order.getOrderHeader().getSolutionType().toString())) {
				tblEnvOrderObject.setServiceType(ServiceType.ESIP_ESL_DISC.getValue());

			} else if ((OrderAction.DISCONNECT.getValue().equalsIgnoreCase(order.getOrderHeader().getOrderType()))
					&& SolutionType.ESIP_EBL.toString()
							.equalsIgnoreCase(order.getOrderHeader().getSolutionType().toString())) {
				tblEnvOrderObject.setServiceType(ServiceType.ESIP_EBL_DISC.getValue());

			} else if ((OrderAction.DISCONNECT.getValue().equalsIgnoreCase(order.getOrderHeader().getOrderType()))
					&& SolutionType.IPFLEX.toString()
							.equalsIgnoreCase(order.getOrderHeader().getSolutionType().toString())) {
				tblEnvOrderObject.setServiceType(ServiceType.IPFLEX_DISC.getValue());

			} else if ((OrderAction.DISCONNECT.getValue().equalsIgnoreCase(order.getOrderHeader().getOrderType()))
					&& SolutionType.HPBX.toString()
							.equalsIgnoreCase(order.getOrderHeader().getSolutionType().toString())) {
				tblEnvOrderObject.setServiceType(ServiceType.HPBX_DISC.getValue());

			}

			if (order.getOrderHeader().getFunctionCode() != null) {
				if (order.getOrderHeader().getOrderClassify() != 0)
					tblEnvOrderObject.setOrderClassify(Long.valueOf(order.getOrderHeader().getOrderClassify()));
				else if (order.getOrderHeader().getFunctionCode().equalsIgnoreCase("VALIDATE"))
					tblEnvOrderObject.setOrderClassify(Long.valueOf(OrderClassify.VALIDATE));
				else if (order.getOrderHeader().getFunctionCode().equalsIgnoreCase("RELEASE"))
					tblEnvOrderObject.setOrderClassify(18L);
			}
			LOG.info("Function Code = {}", order.getOrderHeader().getFunctionCode());
			LOG.info("Order Classify = {}", tblEnvOrderObject.getOrderClassify());

			tblEnvOrderObject.setMainTn("-1");
			tblEnvOrderObject.setNewPassWaiting("N");// : TODO Implement
			if (order.getCustomer() != null && order.getCustomer().getCustomerId() != null) {
				tblEnvOrderObject.setEnterpriseId(order.getCustomer().getCustomerId());
			} else if (order.getOrderHeader().getEnterpriseId() != null) {
				tblEnvOrderObject.setEnterpriseId(order.getOrderHeader().getEnterpriseId());
			}

			tblEnvOrderObject.setLocationId(order.getOrderHeader().getLocationId());
			if (order.getOrderHeader().getMinorOrderType() != null) {
				tblEnvOrderObject.setMinorOrderType(order.getOrderHeader().getMinorOrderType());
			}else if (order.getOrderHeader().getOrderType().equalsIgnoreCase("I")){
				tblEnvOrderObject.setMinorOrderType("INSTALL");
			}

			if (order.getOrderHeader().isExpedite() == true) {
				tblEnvOrderObject.setExpedite("Y");
			} else {
				tblEnvOrderObject.setExpedite("N");
			}
			if (order.getOrderHeader().getBulkOrder() != null) {
				tblEnvOrderObject.setBulkOrder(order.getOrderHeader().getBulkOrder());
			} else {
				tblEnvOrderObject.setBulkOrder("N");
			}
			if (order.getOrderHeader().getVzId() != null) {
				tblEnvOrderObject.setVzId(order.getOrderHeader().getVzId());
			} else {
				tblConfigParams = new TblConfigParams();
				tblConfigParams.setParamName("ORDER_CREATED_BY_VZ_ID");
				tblConfigParams.setProcessName("OrderManager");
				tblConfigParams.setParamGroup(null);
				tblConfigParams.setStatus("A");

				vzIdTblConfigParams = voipOrderDao.getConfigParamValue(tblConfigParams);
				tblEnvOrderObject.setVzId(vzIdTblConfigParams.get(0).getParamValue());
			}

			if (order.getCustomer() != null && order.getCustomer().getCustomerName() != null)
				tblEnvOrderObject.setCustomerName(order.getCustomer().getCustomerName());
		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new TranslatorException(ErrorCode.TRANSFORMER_FAILURE,
					"Exception occured in createTblEnvOrderFromOrder");
		}
		LOG.info("Exit - createTblEnvOrderFromOrder");
		return tblEnvOrderObject;

	}

	/**
	 * @param order
	 * @return priority
	 */
	private Long getOrderPriorityForOrder(Order order) {
		LOG.info("Entered - getOrderPriorityForOrder");

		long priority = 20;

		HashMap<String, String> ordPrioCols = new HashMap<String, String>();
		ordPrioCols.put("ProjectId", order.getOrderHeader().getProjectId());
		ordPrioCols.put("ORDER_SOURCE", order.getOrderHeader().getOriginatingSystem());
		ordPrioCols.put("ORDER_TYPE", OrderUtility.getOrderTypeChar(order.getOrderHeader().getEnvOrderType()));

		if (order.getOrderHeader().getMinorOrderType() != null)
			ordPrioCols.put("MINOR_ORDER_TYPE", order.getOrderHeader().getMinorOrderType().substring(0, 1));

		ordPrioCols.put("FUNCTION_CODE",
				WorkOrderEnum.OrderClassify.acronym(order.getOrderHeader().getOrderClassify()));
		ordPrioCols.put("BULK_ORDER", order.getOrderHeader().getBulkOrder());
		ordPrioCols.put("EXPEDITE", order.getOrderHeader().isExpedite() == true ? "1" : "0");

		List<TblOrderPrioritySettings> tblOrderPrioritySettingsList = getOrderPrioritySettings(ordPrioCols);

		if (tblOrderPrioritySettingsList.size() > 0) {
			for (TblOrderPrioritySettings tblOrderPrioritySettings : tblOrderPrioritySettingsList) {
				priority = tblOrderPrioritySettings.getPriority();
				break;
			}
		}
		LOG.info("Exit - getOrderPriorityForOrder");
		return priority;
	}

}
