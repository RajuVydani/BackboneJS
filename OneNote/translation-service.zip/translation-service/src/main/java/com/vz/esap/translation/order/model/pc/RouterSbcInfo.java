package com.vz.esap.translation.order.model.pc;

import javax.xml.bind.annotation.XmlElement;

import com.fasterxml.jackson.annotation.JsonProperty;

public class RouterSbcInfo {

	@XmlElement(name = "RouterAction")
	@JsonProperty(value = "RouterAction")
	private String routerAction;

	@XmlElement(name = "VpnName")
	@JsonProperty(value = "VpnName")
	private String vpnName;

	@XmlElement(name = "IpVersion")
	@JsonProperty(value = "IpVersion")
	private String ipVersion;

	@XmlElement(name = "MicroNodeIdentifier")
	@JsonProperty(value = "MicroNodeIdentifier")
	private String microNodeIdentifier;

	@XmlElement(name = "PvcCircuitM3")
	@JsonProperty(value = "PvcCircuitM3")
	private String pvcCircuitM3;

	@XmlElement(name = "PvcCircuitM4")
	@JsonProperty(value = "PvcCircuitM4")
	private String pvcCircuitM4;

	@XmlElement(name = "PeerAs")
	@JsonProperty(value = "PeerAs")
	private String peerAs;

	@XmlElement(name = "CustomerSigSubnet")
	@JsonProperty(value = "CustomerSigSubnet")
	private String customerSigSubnet;

	@XmlElement(name = "CustomerMedSubnet")
	@JsonProperty(value = "CustomerMedSubnet")
	private String customerMedSubnet;

	@XmlElement(name = "M10Router1")
	@JsonProperty(value = "M10Router1")
	private String m10Router1;

	@XmlElement(name = "VSNName1")
	@JsonProperty(value = "VSNName1")
	private String vSNName1;

	@XmlElement(name = "M10Router2")
	@JsonProperty(value = "M10Router2")
	private String m10Router2;

	@XmlElement(name = "VSNName2")
	@JsonProperty(value = "VSNName2")
	private String vSNName2;

	@JsonProperty(value = "CustSigVlan")
	private String custSigVlan;

	@JsonProperty(value = "CustMedVlan")
	private String custMedVlan;

	public String getRouterAction() {
		return routerAction;
	}

	public void setRouterAction(String routerAction) {
		this.routerAction = routerAction;
	}

	public String getVpnName() {
		return vpnName;
	}

	public void setVpnName(String vpnName) {
		this.vpnName = vpnName;
	}

	public String getIpVersion() {
		return ipVersion;
	}

	public void setIpVersion(String ipVersion) {
		this.ipVersion = ipVersion;
	}

	public String getMicroNodeIdentifier() {
		return microNodeIdentifier;
	}

	public void setMicroNodeIdentifier(String microNodeIdentifier) {
		this.microNodeIdentifier = microNodeIdentifier;
	}

	public String getPvcCircuitM3() {
		return pvcCircuitM3;
	}

	public void setPvcCircuitM3(String pvcCircuitM3) {
		this.pvcCircuitM3 = pvcCircuitM3;
	}

	public String getPvcCircuitM4() {
		return pvcCircuitM4;
	}

	public void setPvcCircuitM4(String pvcCircuitM4) {
		this.pvcCircuitM4 = pvcCircuitM4;
	}

	public String getPeerAs() {
		return peerAs;
	}

	public void setPeerAs(String peerAs) {
		this.peerAs = peerAs;
	}

	public String getCustomerSigSubnet() {
		return customerSigSubnet;
	}

	public void setCustomerSigSubnet(String customerSigSubnet) {
		this.customerSigSubnet = customerSigSubnet;
	}

	public String getCustomerMedSubnet() {
		return customerMedSubnet;
	}

	public void setCustomerMedSubnet(String customerMedSubnet) {
		this.customerMedSubnet = customerMedSubnet;
	}

	public String getM10Router1() {
		return m10Router1;
	}

	public void setM10Router1(String m10Router1) {
		this.m10Router1 = m10Router1;
	}

	public String getvSNName1() {
		return vSNName1;
	}

	public void setvSNName1(String vSNName1) {
		this.vSNName1 = vSNName1;
	}

	public String getM10Router2() {
		return m10Router2;
	}

	public void setM10Router2(String m10Router2) {
		this.m10Router2 = m10Router2;
	}

	public String getvSNName2() {
		return vSNName2;
	}

	public void setvSNName2(String vSNName2) {
		this.vSNName2 = vSNName2;
	}

	public String getCustSigVlan() {
		return custSigVlan;
	}

	public void setCustSigVlan(String custSigVlan) {
		this.custSigVlan = custSigVlan;
	}

	public String getCustMedVlan() {
		return custMedVlan;
	}

	public void setCustMedVlan(String custMedVlan) {
		this.custMedVlan = custMedVlan;
	}

}
