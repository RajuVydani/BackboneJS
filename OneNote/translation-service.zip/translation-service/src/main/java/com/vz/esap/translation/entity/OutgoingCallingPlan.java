package com.vz.esap.translation.entity;
import java.util.HashMap;

public class OutgoingCallingPlan {
    private String intraLocation;
    private String local;
    private String tollFree;
    private String toll;
    private String international;
    private String casual;
    private String operatorAssisted;
    private String chargeableDirectoryAssist;
    private String specialServices1;
    private String specialServices2;
    private String premiumServices1;
    private String premiumServices2;
    private String uRLDialing;
    private String unknown;

    private String fwdTrnsfIntraLocation;
    private String fwdTrnsfLocal;
    private String fwdTrnsfTollFree;
    private String fwdTrnsfToll;
    private String fwdTrnsfInternational;
    private String fwdTrnsfCasual;
    private String fwdTrnsfOperatorAssisted;
    private String fwdTrnsfChargeableDirectoryAssist;
    private String fwdTrnsfSpecialServices1;
    private String fwdTrnsfSpecialServices2;
    private String fwdTrnsfPremiumServices1;
    private String fwdTrnsfPremiumServices2;
    private String fwdTrnsfURLDialing;
    private String fwdTrnsfUnknown;
    private String beingFwdTrnsfInterLocation;

    public String getIntraLocation() {
        return intraLocation;
    }

    public void setIntraLocation(String intraLocation) {
        this.intraLocation = intraLocation;
    }

    public String getLocal() {
        return local;
    }

    public void setLocal(String local) {
        this.local = local;
    }

    public String getTollFree() {
        return tollFree;
    }

    public void setTollFree(String tollFree) {
        this.tollFree = tollFree;
    }

    public String getToll() {
        return toll;
    }

    public void setToll(String toll) {
        this.toll = toll;
    }

    public String getInternational() {
        return international;
    }

    public void setInternational(String international) {
        this.international = international;
    }

    public String getCasual() {
        return casual;
    }

    public void setCasual(String casual) {
        this.casual = casual;
    }

    public String getOperatorAssisted() {
        return operatorAssisted;
    }

    public void setOperatorAssisted(String operatorAssisted) {
        this.operatorAssisted = operatorAssisted;
    }

    public String getChargeableDirectoryAssist() {
        return chargeableDirectoryAssist;
    }

    public void setChargeableDirectoryAssist(String chargeableDirectoryAssist) {
        this.chargeableDirectoryAssist = chargeableDirectoryAssist;
    }

    public String getSpecialServices1() {
        return specialServices1;
    }

    public void setSpecialServices1(String specialServices1) {
        this.specialServices1 = specialServices1;
    }

    public String getSpecialServices2() {
        return specialServices2;
    }

    public void setSpecialServices2(String specialServices2) {
        this.specialServices2 = specialServices2;
    }

    public String getPremiumServices1() {
        return premiumServices1;
    }

    public void setPremiumServices1(String premiumServices1) {
        this.premiumServices1 = premiumServices1;
    }

    public String getPremiumServices2() {
        return premiumServices2;
    }

    public void setPremiumServices2(String premiumServices2) {
        this.premiumServices2 = premiumServices2;
    }

    public String getURLDialing() {
        return uRLDialing;
    }

    public void setURLDialing(String dialing) {
        uRLDialing = dialing;
    }

    public String getUnknown() {
        return unknown;
    }

    public void setUnknown(String unknown) {
        this.unknown = unknown;
    }

    public String getFwdTrnsfIntraLocation() {
        return fwdTrnsfIntraLocation;
    }

    public void setFwdTrnsfIntraLocation(String fwdTrnsfIntraLocation) {
        this.fwdTrnsfIntraLocation = fwdTrnsfIntraLocation;
    }

    public String getFwdTrnsfLocal() {
        return fwdTrnsfLocal;
    }

    public void setFwdTrnsfLocal(String fwdTrnsfLocal) {
        this.fwdTrnsfLocal = fwdTrnsfLocal;
    }

    public String getFwdTrnsfTollFree() {
        return fwdTrnsfTollFree;
    }

    public void setFwdTrnsfTollFree(String fwdTrnsfTollFree) {
        this.fwdTrnsfTollFree = fwdTrnsfTollFree;
    }

    public String getFwdTrnsfToll() {
        return fwdTrnsfToll;
    }

    public void setFwdTrnsfToll(String fwdTrnsfToll) {
        this.fwdTrnsfToll = fwdTrnsfToll;
    }

    public String getFwdTrnsfInternational() {
        return fwdTrnsfInternational;
    }

    public void setFwdTrnsfInternational(String fwdTrnsfInternational) {
        this.fwdTrnsfInternational = fwdTrnsfInternational;
    }

    public String getFwdTrnsfCasual() {
        return fwdTrnsfCasual;
    }

    public void setFwdTrnsfCasual(String fwdTrnsfCasual) {
        this.fwdTrnsfCasual = fwdTrnsfCasual;
    }

    public String getFwdTrnsfOperatorAssisted() {
        return fwdTrnsfOperatorAssisted;
    }

    public void setFwdTrnsfOperatorAssisted(String fwdTrnsfOperatorAssisted) {
        this.fwdTrnsfOperatorAssisted = fwdTrnsfOperatorAssisted;
    }

    public String getFwdTrnsfChargeableDirectoryAssist() {
        return fwdTrnsfChargeableDirectoryAssist;
    }

    public void setFwdTrnsfChargeableDirectoryAssist(String fwdTrnsfChargeableDirectoryAssist) {
        this.fwdTrnsfChargeableDirectoryAssist = fwdTrnsfChargeableDirectoryAssist;
    }

    public String getFwdTrnsfSpecialServices1() {
        return fwdTrnsfSpecialServices1;
    }

    public void setFwdTrnsfSpecialServices1(String fwdTrnsfSpecialServices1) {
        this.fwdTrnsfSpecialServices1 = fwdTrnsfSpecialServices1;
    }

    public String getFwdTrnsfSpecialServices2() {
        return fwdTrnsfSpecialServices2;
    }

    public void setFwdTrnsfSpecialServices2(String fwdTrnsfSpecialServices2) {
        this.fwdTrnsfSpecialServices2 = fwdTrnsfSpecialServices2;
    }

    public String getFwdTrnsfPremiumServices1() {
        return fwdTrnsfPremiumServices1;
    }

    public void setFwdTrnsfPremiumServices1(String fwdTrnsfPremiumServices1) {
        this.fwdTrnsfPremiumServices1 = fwdTrnsfPremiumServices1;
    }

    public String getFwdTrnsfPremiumServices2() {
        return fwdTrnsfPremiumServices2;
    }

    public void setFwdTrnsfPremiumServices2(String fwdTrnsfPremiumServices2) {
        this.fwdTrnsfPremiumServices2 = fwdTrnsfPremiumServices2;
    }

    public String getFwdTrnsfURLDialing() {
        return fwdTrnsfURLDialing;
    }

    public void setFwdTrnsfURLDialing(String fwdTrnsfURLDialing) {
        this.fwdTrnsfURLDialing = fwdTrnsfURLDialing;
    }

    public String getFwdTrnsfUnknown() {
        return fwdTrnsfUnknown;
    }

    public void setFwdTrnsfUnknown(String fwdTrnsfUnknown) {
        this.fwdTrnsfUnknown = fwdTrnsfUnknown;
    }

    public String getBeingFwdTrnsfInterLocation() {
        return beingFwdTrnsfInterLocation;
    }

    public void setBeingFwdTrnsfInterLocation(String beingFwdTrnsfInterLocation) {
        this.beingFwdTrnsfInterLocation = beingFwdTrnsfInterLocation;
    }
    
   
}
