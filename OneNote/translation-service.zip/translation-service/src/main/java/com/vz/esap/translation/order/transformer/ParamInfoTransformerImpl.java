package com.vz.esap.translation.order.transformer;

/**
 * @author Niladri Chattaraj
 *
 */
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.vz.esap.translation.dao.model.TblOrderDetails;
import com.vz.esap.translation.entity.ParamInfo;
import com.vz.esap.translation.exception.GenericException;

@Component
public class ParamInfoTransformerImpl implements ParamInfoTransformer {

	private static final Logger LOG = LoggerFactory.getLogger(ParamInfoTransformerImpl.class);

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.vz.esap.translation.order.transformer.ParamInfoTransformer#
	 * getAttribParamInfo(java.util.LinkedHashMap, java.lang.String)
	 */
	@Override
	public ParamInfo getAttribParamInfo(LinkedHashMap<String, String> attribMap, String action) {
		if (attribMap == null)
			return null;
		ParamInfo root = new ParamInfo("AdditionalAttribs", null, action);
		for (Map.Entry<String, String> attrib : attribMap.entrySet()) {
			root.addChildParam(new ParamInfo(attrib.getKey(), attrib.getValue(), action));
		}
		return root;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.vz.esap.translation.order.transformer.ParamInfoTransformer#
	 * getAttribParamInfo(java.util.LinkedHashMap, java.util.LinkedHashMap)
	 */
	@Override
	public ParamInfo getAttribParamInfo(LinkedHashMap<String, String> oldAttribs,
			LinkedHashMap<String, String> newAttribs) {
		if (oldAttribs == null && newAttribs == null)
			return null;

		LinkedHashMap<String, String> mergedAttribs = new LinkedHashMap<String, String>();

		if (oldAttribs != null)
			mergedAttribs.putAll(oldAttribs);

		if (newAttribs != null)
			mergedAttribs.putAll(newAttribs);

		return getAttribParamInfo(mergedAttribs, (String) null);

	}

	// : need to fix this return
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.vz.esap.translation.order.transformer.ParamInfoTransformer#
	 * transformOrderDetailsToParamInfo(java.util.List,
	 * com.vz.esap.translation.entity.ParamInfo, int,
	 * com.vz.esap.translation.dao.model.TblOrderDetails)
	 */
	@Override
	public ParamInfo transformOrderDetailsToParamInfo(List<TblOrderDetails> ordDetails, ParamInfo parentParam,
			int startIdx, TblOrderDetails parentTOD) throws GenericException {
		int i = startIdx;
		LOG.debug("Entered - transformOrderDetailsToParamInfo");
		ParamInfo prevParam = null;
		TblOrderDetails prevTOD = null;
		TblOrderDetails tblOrderDetails = null;
		long parentId = -1;
		ParamInfo param = null;
		try {
			if (parentTOD != null) {
				parentId = parentTOD.getOrderDetailId();
			}

			for (; i < ordDetails.size(); i++) {
				LOG.debug("Order Details : {}", ordDetails.get(i).getOrderDetailId());

				tblOrderDetails = ordDetails.get(i);
				LOG.debug("Order Details Parent Id: {}", tblOrderDetails.getParentId());

				if (parentId == -1 || parentId == tblOrderDetails.getParentId()) {

					param = new ParamInfo(tblOrderDetails.getOrderDetailId(), tblOrderDetails.getParentId(),
							tblOrderDetails.getFlowStatus(), tblOrderDetails.getParamName(),
							tblOrderDetails.getParamValue(), translateTODActToPIAct(tblOrderDetails.getAction()),
							ParamInfo.stringToTagSet(tblOrderDetails.getParamType()));

					parentParam.addChildParam(param);
					prevParam = param;
					parentId = tblOrderDetails.getParentId();
					prevTOD = tblOrderDetails;
				}
				// child
				else if (prevTOD.getOrderDetailId().equals(tblOrderDetails.getParentId())) {
					transformOrderDetailsToParamInfo(ordDetails, prevParam, i, prevTOD);
				}
				/*
				 * else { --i; }
				 */
			}
		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new GenericException(GenericException.GENERIC_EXCEPTION,
					"Exception occured in getEnterpriseInformationFromGchId");
		}
		LOG.debug("Total Count : {} And Param Count: {}", i, parentParam);
		LOG.debug("Exit - transformOrderDetailsToParamInfo");
		return parentParam;
	}

	@Override
	public String translateTODActToPIAct(String todAct) {
		if (todAct == null)
			return null;
		else if (todAct.equals("r"))
			return null;
		else if (todAct.equals("n"))
			return "I";
		else if (todAct.equals("o"))
			return "O";
		else if (todAct.equals("c"))
			return "C";
		else
			return todAct;
	}

}