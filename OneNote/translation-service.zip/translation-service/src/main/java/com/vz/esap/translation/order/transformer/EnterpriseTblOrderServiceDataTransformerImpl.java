package com.vz.esap.translation.order.transformer;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.vz.esap.translation.dao.model.TblOrder;
import com.vz.esap.translation.dao.model.TblOrderDetails;
import com.vz.esap.translation.dao.model.TblOrderService;
import com.vz.esap.translation.dao.model.TblRetailService;
import com.vz.esap.translation.dao.repository.CustomTblOrderDetailsMapper;
import com.vz.esap.translation.dao.repository.CustomTblOrderServiceMapper;
import com.vz.esap.translation.enums.EsapEnum;
import com.vz.esap.translation.enums.EsapEnum.FlowPath;
import com.vz.esap.translation.enums.EsapEnum.MilestoneSkip;
import com.vz.esap.translation.enums.EsapEnum.OrderAction;
import com.vz.esap.translation.enums.EsapEnum.OrderEntity;
import com.vz.esap.translation.enums.EsapEnum.OrderMilestone;
import com.vz.esap.translation.enums.EsapEnum.Service;
import com.vz.esap.translation.exception.GenericException;
import com.vz.esap.translation.exception.TranslatorException;
import com.vz.esap.translation.exception.TranslatorException.ErrorCode;
import com.vz.esap.translation.order.dao.VOIPOrderDao;
import com.vz.esap.translation.order.model.Order;
import com.vz.esap.translation.order.model.request.ParamInfo;
import com.vz.esap.translation.order.service.helper.OrderServiceHelper;

import EsapEnumPkg.VzbVoipEnum;
import EsapEnumPkg.WorkOrderEnum;

@Component
public class EnterpriseTblOrderServiceDataTransformerImpl implements EnterpriseTblOrderServiceDataTransformer {

	private static final Logger LOG = LoggerFactory.getLogger(EnterpriseTblOrderServiceDataTransformerImpl.class);

	@Autowired
	private VOIPOrderDao voipOrderDao;

	@Autowired
	private OrderServiceHelper orderServiceHelperImpl;
	
	@Autowired
	private CustomTblOrderServiceMapper customTblOrderServiceMapper;
	
	@Autowired
	private CustomTblOrderDetailsMapper customTblOrderDetailsMapper;
	
	private static final String REV_SKIP = "REV_SKIP";

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.vz.esap.translation.order.transformer.
	 * EnterpriseTblOrderServiceDataTransformer#prepareTblOrderServiceData(com.vz.
	 * esap.translation.order.model.Order)
	 */
	@Override
	public List<TblOrderService> prepareTblOrderServiceData(Order order, Order orderPrevPass, ParamInfo entityParamInfo)
			throws TranslatorException {
		LOG.info("Entered - prepareTblOrderServiceData  for Entity : {} , Env Order id : {}",
				order.getOrderHeader().getEntityType(), order.getOrderHeader().getEnvOrderId());

		List<TblOrderService> tblOrderServiceListOut = null;
		long serviceStatus = -1;
		List<TblRetailService> tblRetailServiceList = null;
		List<Service> skipServices = null;
		TblOrderService tblOrderService = null;
		boolean isSystemBulkUpdateEligible = false;
		boolean skipMilestone = false;

		try {

			serviceStatus = WorkOrderEnum.Status.WO_INIT;

			tblRetailServiceList = voipOrderDao.findServices(order, orderPrevPass);

			if (tblRetailServiceList == null || tblRetailServiceList.size() <= 0) {
				LOG.info("TblRetailService is Null");
				throw new TranslatorException(ErrorCode.SERVICE_ORDER_CREATION_FAILURE, "TblRetailService is Null");
			}

			LOG.info("TblRetailService Count : {}", tblRetailServiceList.size());

			skipServices = new ArrayList<>();

			if (order != null && order.getOrderHeader() != null && order.getCustomer() != null) {
				if (order.getCustomer().getSoEnabled() != null && order.getCustomer().getSoEnabled().equals("1")
						&& order.getCustomer().getEntityType() == VzbVoipEnum.OrderEntity.ENTERPRISE
						&& order.getOrderHeader().getAction() == OrderAction.DELETE) {
					LOG.info(" TSO Enterprise out order.. Hence skipping SBC services ");
					skipServices = addToSkipServices(skipServices, Service.SBC);
				}

				if (null != order.getCustomer().getSoEnabled() && order.getCustomer().getSoEnabled().equals("1")) {
					LOG.info(" TSO order, skip ICP task");
					skipServices = addToSkipServices(skipServices, Service.ICP);
				}

			}

			if (skipServices != null && skipServices.size() > 0)
				LOG.info("Skip services: {}", skipServices);

			String orderNum = order.getOrderHeader().getTblOrderId().toString();

			tblOrderServiceListOut = new ArrayList<TblOrderService>();

			// TODO 10/15 : Need to figure a way to find which Mod WF to execute based on
			// Difference in pass orders

			for (TblRetailService tblRetailService : tblRetailServiceList) {

				LOG.info("Order Service : {} , Order Id : {} , Forward Pass : {}", tblRetailService.getWfService(),
						orderNum, tblRetailService.getForwardSkip());

				String wfService = null;
				if (order.getOrderHeader().getFlowPath().equals(FlowPath.F))
					wfService = tblRetailService.getWfService();
				else if (order.getOrderHeader().getFlowPath().equals(FlowPath.D))
					wfService = tblRetailService.getDeltaWfService();
				else if (order.getOrderHeader().getFlowPath().equals(FlowPath.R))
					wfService = tblRetailService.getReverseWfService();

				if (wfService == null)
					continue; // TODO: Is it valid???

				long skipFlag = 0;
				long seqNo = 0;
				if (order.getOrderHeader().getFlowPath().equals(FlowPath.R)) {
					seqNo = tblRetailService.getReverseSeqNo();
					skipFlag = tblRetailService.getReverseSkip();
				} else {

					seqNo = tblRetailService.getSeqNo();
					if (tblRetailService.getForwardSkip() != null)
						skipFlag = tblRetailService.getForwardSkip();
				}

				if (order.getOrderHeader().getSolutionType() != null
						&& EsapEnum.SolutionType.ESIP_EBL.equals(order.getOrderHeader().getSolutionType())
						&& "EBL_SKIP".equalsIgnoreCase(EsapEnum.SkipEblWf.getValue(wfService)))
					skipFlag = 1;

				else if (order.getOrderHeader().getSolutionType() != null
						&& EsapEnum.SolutionType.IPFLEX.equals(order.getOrderHeader().getSolutionType())
						&& "FLEX_DID_SKIP".equalsIgnoreCase(EsapEnum.SkipFlexDidWf.getValue(wfService)))
					skipFlag = 1;

				else if (order.getOrderHeader().getSolutionType() != null
						&& EsapEnum.SolutionType.ESIP_ESL.equals(order.getOrderHeader().getSolutionType())
						&& "ESL_SKIP".equalsIgnoreCase(EsapEnum.SkipEslWf.getValue(wfService)))
					skipFlag = 1;
				
				else if (order.getOrderHeader().getSolutionType() != null
						&& EsapEnum.SolutionType.HPBX.equals(order.getOrderHeader().getSolutionType())){
					if("INV_ONLY".equalsIgnoreCase(order.getOrderHeader().getProvisionCategory())
							&& "HPBX_PRE_CONFIG_SKIP"
							.equalsIgnoreCase(EsapEnum.SkipHpbxPreConfigEntitiesWf.getValue(wfService))) {
						skipFlag = 1;
						
					}
					
					if (order.getOrderHeader().getSolutionType() != null
							&& EsapEnum.SolutionType.HPBX.equals(order.getOrderHeader().getSolutionType())
							&& "HPBX_SKIP".equalsIgnoreCase(EsapEnum.SkipHpbxWf.getValue(wfService)))
						skipFlag = 1;
				}
				
				else if (order.getOrderHeader().getSolutionType() != null
						&& EsapEnum.SolutionType.IPFLEX.equals(order.getOrderHeader().getSolutionType())
						&& "FLEX_SKIP".equalsIgnoreCase(EsapEnum.SkipFlexWf.getValue(wfService))) {
					skipFlag = 1;
					
				}
					
				
				/*else if (order.getOrderHeader().getSolutionType() != null
						&& EsapEnum.SolutionType.HPBX.equals(order.getOrderHeader().getSolutionType())
						&& "HPBX_SKIP".equalsIgnoreCase(EsapEnum.SkipHpbxWf.getValue(wfService)))
					skipFlag = 1;*/
				
				if (order.getGroupTnEntity() != null)
					isSystemBulkUpdateEligible = orderServiceHelperImpl
							.isSystemBulkUpdateEligible(order.getGroupTnEntity().getTnCount());

				LOG.info("System Update Flag : {}", isSystemBulkUpdateEligible);

				if (isSystemBulkUpdateEligible
						&& "SYSTEM_CHAIN_UPDATE_SKIP".equalsIgnoreCase(EsapEnum.SkipEslWf.getValue(wfService)))
					skipFlag = 1;
				else if (!isSystemBulkUpdateEligible
						&& "SYSTEM_BULK_UPDATE_SKIP".equalsIgnoreCase(EsapEnum.SkipEslWf.getValue(wfService)))
					skipFlag = 1;

				tblOrderService = new TblOrderService();
				tblOrderService.setOrderId(Long.valueOf(orderNum));
				tblOrderService.setSeqNo(seqNo);
				tblOrderService.setService(wfService);
				tblOrderService.setServiceStatus(serviceStatus);

				Map<String, String> paramMap = new HashMap<>();
				paramMap.put("PROCESS_NAME", "OrderManager");

				tblOrderService.setClli(orderServiceHelperImpl.getClli(wfService, paramMap));
				
				//BS CLLI
				LOG.info("Assigning Asclli for broadsoft services..... {}", order.getOrderHeader().getAsClli());
				String clliType = EsapEnum.ClliType.getValue(wfService);
				if(clliType != null && "BS_CLLI".equalsIgnoreCase(clliType) && null != order.getOrderHeader().getAsClli()) {
					LOG.info("AsClli for broadsoft service :: {} is :: {}", wfService, order.getOrderHeader().getAsClli());						
					tblOrderService.setClli(order.getOrderHeader().getAsClli());
				}

				if (skipFlag > 0) {
					tblOrderService.setSkipFlag(skipFlag);
				} else {
					tblOrderService.setSkipFlag(null);
				}

				tblOrderServiceListOut.add(tblOrderService);

				LOG.info("Order Service : {} , Order Id : {} , Sequence Numer : {}, skipFlag : {}", wfService, orderNum, seqNo, skipFlag);
				
				if (order.getOrderHeader().getSolutionType() != null
						&& EsapEnum.SolutionType.HPBX.equals(order.getOrderHeader().getSolutionType())
						&& MilestoneSkip.getValue(EsapEnum.SolutionType.HPBX.toString()).equalsIgnoreCase(wfService)) {

					LOG.info("Milestone {} skipped for {} for Solution {}", tblRetailService.getMilestone(), wfService,
							EsapEnum.SolutionType.HPBX);

					skipMilestone = true;
				}

				if (tblRetailService.getMilestone() != null && !skipMilestone) {

					long milestoneId = OrderMilestone.valueOf(tblRetailService.getMilestone()).getIndex();

					LOG.info("WF Milestone = {} with Milestone Index = {}", tblRetailService.getMilestone(),
							milestoneId);

					voipOrderDao.insertOrderMilestone(order.getOrderHeader().getEnvOrderId(), Long.valueOf(orderNum),
							wfService, milestoneId, 0, seqNo);
				}

			}
		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new TranslatorException(ErrorCode.TRANSFORMER_FAILURE,
					"Exception occured in prepareTblOrderServiceData");
		}
		LOG.info("Exit prepareAndPopulateTblOrderServiceData");

		return tblOrderServiceListOut;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.vz.esap.translation.order.transformer.
	 * EnterpriseTblOrderServiceDataTransformer#prepareTblOrderServiceDataValidate(
	 * java.lang.String, com.vz.esap.translation.dao.model.TblOrder)
	 */
	@Override
	public List<TblOrderService> prepareTblOrderServiceDataValidate(String region, TblOrder tblOrderObject)
			throws TranslatorException, GenericException {
		LOG.info("Entered - prepareTblOrderServiceDataValidate");

		long serviceStatus = WorkOrderEnum.Status.WO_INIT;
		List<TblRetailService> tblRetailServiceList = null;
		
		if(tblOrderObject != null && tblOrderObject.getOrderType() != null) {
			tblRetailServiceList = voipOrderDao.findServicesValidation(region, tblOrderObject.getOrderType());
			
		} else {
			tblRetailServiceList = voipOrderDao.findServicesValidation(region);			
		}
		

		List<TblOrderService> tblOrderServiceList = new ArrayList<TblOrderService>();
		for (TblRetailService tblRetailService : tblRetailServiceList) {
			TblOrderService tblOrderService = new TblOrderService();
			tblOrderService.setOrderId(tblOrderObject.getOrderId());
			tblOrderService.setSeqNo(tblRetailService.getSeqNo());
			tblOrderService.setService(tblRetailService.getWfService());
			tblOrderService.setServiceStatus(serviceStatus);
			// tblOrderService.setClli(EsapEnum.ClliType.getValue(tblRetailService.getWfService()));//
			// TODO: get clli based
			// on
			Map<String, String> paramMap = new HashMap<>();
			paramMap.put("PROCESS_NAME", "OrderManager");

			tblOrderService.setClli(orderServiceHelperImpl.getClli(tblRetailService.getWfService(), paramMap));

			// wf servce
			tblOrderService.setInitialFlag(null);
			tblOrderService.setAqmWorkId(null);
			tblOrderService.setSkipFlag(tblRetailService.getForwardSkip());

			long skipFlag = 0;

			if ("VAL_SKIP".equalsIgnoreCase(EsapEnum.SkipEslWf.getValue(tblRetailService.getWfService())))
				skipFlag = 1;

			if (skipFlag > 0) {
				tblOrderService.setSkipFlag(skipFlag);
			}

			tblOrderServiceList.add(tblOrderService);

			LOG.info("Order Service Added : {} And Sequence Number {}", tblRetailService.getWfService(),
					tblRetailService.getSeqNo());
		}
		LOG.info("Exited - prepareTblOrderServiceDataValidate");
		return tblOrderServiceList;
	}

	public VOIPOrderDao getVoipOrderDao() {
		return voipOrderDao;
	}

	public void setVoipOrderDao(VOIPOrderDao voipOrderDao) {
		this.voipOrderDao = voipOrderDao;
	}

	/**
	 * @param skipServices
	 * @param skipService
	 * @return skipServices
	 */
	public List<Service> addToSkipServices(List<Service> skipServices, Service skipService) {
		if (skipServices == null)
			skipServices = new ArrayList<Service>();

		skipServices.add(skipService);
		return skipServices;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.vz.esap.translation.order.transformer.
	 * EnterpriseTblOrderServiceDataTransformer#
	 * prepareTblOrderServiceForReverseOrder(com.vz.esap.translation.dao.model.
	 * TblOrder, com.vz.esap.translation.dao.model.TblOrder)
	 */
	@Override
	public List<TblOrderService> prepareTblOrderServiceForReverseOrder(TblOrder tblOrderObjectOrig,
			TblOrder tblOrderObjectCurrent) throws TranslatorException, GenericException {
		LOG.info("Entered - prepareTblOrderServiceForReverseOrder for New Tbl_Order_Id = {} And Old Tbl_Order_Id = {} "
				, tblOrderObjectCurrent.getOrderId(), tblOrderObjectOrig.getOrderId());

		long serviceStatus = WorkOrderEnum.Status.WO_INIT;
		List<TblOrderService> tblOrderServiceListOrig = voipOrderDao.getOrderServiceList(tblOrderObjectOrig);

		List<TblOrderService> tblOrderServiceListCurr = new ArrayList<>();
		TblOrderService tblOrderServiceLoc;
		List<TblRetailService> tblRetailServiceNew;
		TblOrderService tblOrderServiceCurr;

		for (TblOrderService tblOrderServiceOrig : tblOrderServiceListOrig) {
			
			tblRetailServiceNew = voipOrderDao.getTblRetailService(tblOrderServiceOrig.getService(), "US");
			
			LOG.info("For Retail Service = {} The Reverse Service = {}", tblRetailServiceNew.get(0).getWfService(),
					tblRetailServiceNew.get(0).getReverseWfService());
			
			if(tblRetailServiceNew.get(0).getReverseWfService() == null)
				continue;

			tblOrderServiceCurr = new TblOrderService();

			tblOrderServiceCurr.setOrderId(tblOrderObjectCurrent.getOrderId());
			tblOrderServiceCurr.setSeqNo(tblRetailServiceNew.get(0).getReverseSeqNo());
			tblOrderServiceCurr.setService(tblRetailServiceNew.get(0).getReverseWfService());
			tblOrderServiceCurr.setServiceStatus(serviceStatus);

			Map<String, String> paramMap = new HashMap<>();
			paramMap.put("PROCESS_NAME", "OrderManager");

			tblOrderServiceCurr.setClli(
					orderServiceHelperImpl.getClli(tblRetailServiceNew.get(0).getReverseWfService(), paramMap));

			// wf servce
			tblOrderServiceCurr.setInitialFlag(null);
			tblOrderServiceCurr.setAqmWorkId(null);
			tblOrderServiceCurr.setSkipFlag(tblRetailServiceNew.get(0).getReverseSkip());

			long skipFlag = 0;
			
			if(tblOrderServiceOrig.getServiceStatus() != WorkOrderEnum.Status.WO_COMPLETE
					&& tblOrderServiceOrig.getServiceStatus() != WorkOrderEnum.Status.WO_FAILED) { //creating reverse for failed service as well.
				skipFlag = 1;
			} else if(tblOrderServiceOrig.getServiceStatus() == WorkOrderEnum.Status.WO_FAILED) {
				LOG.info("For failed services :: {} -> {}, adding tasks in the TOD to skip.", tblOrderServiceOrig.getOrderId(), tblOrderServiceOrig.getService());
				//Get order detail Id by passing upstream taskId
				String entityType = null;
				List<String> skipTasks = null;
				long parentOrderDetailId = -1;
				
				LOG.info("{} - {} - {}", tblOrderObjectCurrent.getUpstreamTaskId(), OrderEntity.LOCATION.getIndex()-1, OrderEntity.LOCATION.toString());
				
				if(OrderEntity.ENTERPRISE.getIndex()-1 == tblOrderObjectCurrent.getUpstreamTaskId()) {
					entityType = OrderEntity.ENTERPRISE.toString();
				} else if (OrderEntity.LOCATION.getIndex()-1 == tblOrderObjectCurrent.getUpstreamTaskId()) {
					entityType = OrderEntity.LOCATION.toString();
				} else if (OrderEntity.DEVICE.getIndex()-1 == tblOrderObjectCurrent.getUpstreamTaskId()) {
					entityType = OrderEntity.DEVICE.toString();
				} else if (OrderEntity.TWO_WAY.getIndex()-1 == tblOrderObjectCurrent.getUpstreamTaskId()) {
					entityType = OrderEntity.TWO_WAY.toString();
				} else if (OrderEntity.INBOUND.getIndex()-1 == tblOrderObjectCurrent.getUpstreamTaskId()) {
					entityType = OrderEntity.INBOUND.toString();
				} else if (OrderEntity.LINE.getIndex()-1 == tblOrderObjectCurrent.getUpstreamTaskId()) {
					entityType = OrderEntity.LINE.toString();
				} else if (OrderEntity.NON_PRI_DID.getIndex()-1 == tblOrderObjectCurrent.getUpstreamTaskId()) {
					entityType = OrderEntity.NON_PRI_DID.toString();
				} else if (OrderEntity.PRI_DID.getIndex()-1 == tblOrderObjectCurrent.getUpstreamTaskId()) {
					entityType = OrderEntity.PRI_DID.toString();
				} else if (OrderEntity.TWO_WAY_TN.getIndex()-1 == tblOrderObjectCurrent.getUpstreamTaskId()) {
					entityType = OrderEntity.TWO_WAY_TN.toString();
				}  else if (OrderEntity.INBOUND_TN.getIndex()-1 == tblOrderObjectCurrent.getUpstreamTaskId()) {
					entityType = OrderEntity.INBOUND_TN.toString();
				}else if (OrderEntity.DID_TN.getIndex()-1 == tblOrderObjectCurrent.getUpstreamTaskId()) {
					entityType = OrderEntity.DID_TN.toString();
				}  else if (OrderEntity.LINE_TN.getIndex()-1 == tblOrderObjectCurrent.getUpstreamTaskId()) {
					entityType = OrderEntity.LINE_TN.toString();
				}else if (OrderEntity.ENTERPRISE_TRUNK.getIndex()-1 == tblOrderObjectCurrent.getUpstreamTaskId()) {
					entityType = OrderEntity.ENTERPRISE_TRUNK.toString();
				} else if (OrderEntity.SYSTEM_UPDATE.getIndex()-1 == tblOrderObjectCurrent.getUpstreamTaskId()) {
					entityType = OrderEntity.SYSTEM_UPDATE.toString();
				}
				
				LOG.info("Getting order details for entity :: {} :: Current OrderId :: {}", entityType, tblOrderObjectCurrent.getOrderId());
				List<TblOrderDetails> tblOrderDetailsList = voipOrderDao.getOrderDetailParam(tblOrderObjectCurrent.getOrderId(), entityType);
				if(!CollectionUtils.isEmpty(tblOrderDetailsList)) {
					parentOrderDetailId = tblOrderDetailsList.get(0).getOrderDetailId();
				}
				LOG.info("parentOrderDetailId :: {}", parentOrderDetailId);
				//If service is in failed status,
				//Get the tasks which are not executed --pass aqm_work_id & service
				skipTasks = voipOrderDao.getSkipTasksForReverseService(tblOrderServiceOrig.getService(), tblOrderServiceOrig.getAqmWorkId());
				//Add entry in tbl_order_details for these tasks as skipped.
				if(!CollectionUtils.isEmpty(skipTasks) && parentOrderDetailId != -1) {
					for (String skipTask : skipTasks) {
						//--pass tblOrderObjectCurrent.getOrderId() / skipTask  / tblorderdetailId
						TblOrderDetails tblOrderDetailsObject = new TblOrderDetails();
						long orderDetailId = customTblOrderDetailsMapper.getOrdDtlIdNextVal();
						tblOrderDetailsObject.setOrderDetailId(orderDetailId);
						tblOrderDetailsObject.setOrderId(tblOrderObjectCurrent.getOrderId());
						tblOrderDetailsObject.setParamName(skipTask);
						tblOrderDetailsObject.setParamValue(null);
						tblOrderDetailsObject.setParentId(parentOrderDetailId);
						tblOrderDetailsObject.setSeqNo(0L);
						tblOrderDetailsObject.setAction("S");
						tblOrderDetailsObject.setLeaf(1L);
						tblOrderDetailsObject.setFlowStatus(0L);
						tblOrderDetailsObject.setParamType(",");
						long count = customTblOrderDetailsMapper.insertOrderDetail(tblOrderDetailsObject);
						LOG.info("Inserted no of skip tasks in TOD :: {}", count);
					}
				}
			}

			if (tblRetailServiceNew.get(0).getReverseSkip() != null && (REV_SKIP.equalsIgnoreCase(
					EsapEnum.SkipEslWf.getValue(tblRetailServiceNew.get(0).getReverseSkip().toString()))
					|| REV_SKIP.equalsIgnoreCase(
							EsapEnum.SkipEblWf.getValue(tblRetailServiceNew.get(0).getReverseSkip().toString()))
					|| REV_SKIP.equalsIgnoreCase(
							EsapEnum.SkipFlexDidWf.getValue(tblRetailServiceNew.get(0).getReverseSkip().toString()))
					|| REV_SKIP.equalsIgnoreCase(EsapEnum.SkipSystemUpdateTnWf
							.getValue(tblRetailServiceNew.get(0).getReverseSkip().toString()))))
				skipFlag = 1;

			if (skipFlag > 0) {
				tblOrderServiceCurr.setSkipFlag(skipFlag);
			}
			
			
			tblOrderServiceListCurr.add(tblOrderServiceCurr);
			
			LOG.info("Order Service Added : {} And Sequence Number : {} And Skip Flag : {} ",
					tblOrderServiceCurr.getService(), tblOrderServiceCurr.getSeqNo(),
					tblOrderServiceCurr.getSkipFlag());
		}
		LOG.info("Exited - prepareTblOrderServiceForReverseOrder");
		return tblOrderServiceListCurr;
	}

}
