package com.vz.esap.translation.order.transformer;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.vz.esap.translation.dao.model.TblOrderDetails;
import com.vz.esap.translation.entity.DeviceEntity;
import com.vz.esap.translation.entity.LocationEntity;
import com.vz.esap.translation.entity.Entity.GroupType;
import com.vz.esap.translation.entity.ParamInfo;
import com.vz.esap.translation.enums.EsapEnum.AuthFeatureType;
import com.vz.esap.translation.enums.EsapEnum.SignalingDirection;
import com.vz.esap.translation.enums.EsapEnum.SolutionType;
import com.vz.esap.translation.enums.EsapEnum.TransportProtocol;
import com.vz.esap.translation.exception.ApplicationInterfaceException;
import com.vz.esap.translation.exception.GenericException;
import com.vz.esap.translation.exception.TranslatorException;
import com.vz.esap.translation.order.dao.VOIPOrderDao;
import com.vz.esap.translation.order.model.request.VOIPOrderRequest;
import com.vz.esap.translation.order.service.helper.OrderServiceHelper;
import com.vz.esap.translation.order.service.helper.OrderServiceHelperImpl;

import EsapEnumPkg.VzbVoipEnums;

/**
 * @author kalagsu
 *
 */
@Component
public class DeviceTransformerImpl implements DeviceTransformer {

	private static final Logger LOG = LoggerFactory.getLogger(DeviceTransformerImpl.class);

	@Autowired
	private VOIPOrderDao voipOrderDao;

	@Autowired
	private ParamInfoTransformer paramInfoTransformer;

	@Autowired
	private OrderServiceHelper orderServiceHelperImpl;

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.vz.esap.translation.order.transformer.DeviceTransformer#
	 * transformOrderDetailsToDevice(long, long, java.lang.String, boolean)
	 */
	@Override
	public DeviceEntity transformOrderDetailsToDevice(long orderId, long parentId, String action, boolean delta, List<String> paramActionExclusionList)
			throws TranslatorException {

		return createDeviceFromParamInfo(createDeviceParamInfoFromOrderDetails(orderId, parentId, action, delta, null), paramActionExclusionList);

	}

	/**
	 * @param parent
	 * @return deviceEntity
	 * @throws TranslatorException
	 */
	private DeviceEntity createDeviceFromParamInfo(ParamInfo parent, List<String> paramActionExclusionList) throws TranslatorException {

		LOG.info("Entered - createDeviceFromParamInfo");
		DeviceEntity deviceEntity = new DeviceEntity();

		for (ParamInfo param : parent.getChildParams()) {
			LOG.debug("Name:{}  Value:{} ChildParamCnt:{} And Param Action = {}", param.getName(), param.getValue(),
					(param.getChildParams() == null ? 0 : param.getChildParams().size()), param.getAction());
			
			// TODO: 10/26: MAC Change : Do this for all entity in
			// createXXXFromParamInfo(...)
			if (paramActionExclusionList != null && !paramActionExclusionList.isEmpty()) {
				boolean skip = false;
				for (String exclude : paramActionExclusionList) {
					exclude = paramInfoTransformer.translateTODActToPIAct(exclude);
					
					if (exclude.equalsIgnoreCase(param.getAction())) {
						LOG.info("Param Excluded = {} For Actual Action = {} , The Excluding Action = {}",
								param.getName(), param.getAction(), exclude);
						skip = true;
					}
				}
				if (skip)
					continue;
			}
			
			if (param.getName().equals("CustomerId"))
				deviceEntity.setCustomerId(param.getValue());
			else if (param.getName().equals("DeviceMapId"))
				deviceEntity.setDeviceMapId(new Long(param.getValue()));
			else if (param.getName().equals("DeviceNameId"))
				deviceEntity.setDeviceNameId(param.getValue());
			else if (param.getName().equals("LocationId") && param.getValue() != null)
				deviceEntity.setLocationId(param.getValue());
			else if (param.getName().equals("Codec"))
				deviceEntity.setCodec(param.getValue());
			else if (param.getName().equals("STN"))
				deviceEntity.setSTN(param.getValue());
			else if (param.getName().equals("gwyFqdn"))
				deviceEntity.setGwyFqdn(param.getValue());
			// else if (param.getName().equals("IpVersion"))
			// //deviceEntity.setIpVersion(VzbVoipEnums.IPVersionEnum(new String()));
			else if (param.getName().equals("gwyHunt"))
				deviceEntity.setGwyHunt(param.getValue());
			else if (param.getName().equals("CpeUEid"))
				deviceEntity.setCPEUEId(param.getValue());
			else if (param.getName().equals("sbcEnabledFlag"))
				deviceEntity.setSbcEnabledFlag(param.getValue());
			else if (param.getName().equals("DeviceType")) {
				switch (param.getValue()) {
				case "SIP_DEVICE":
					deviceEntity.setDeviceType(0);
					break;
				case "ENTPRISE_GTWY":
					deviceEntity.setDeviceType(1);
					break;
				case "EST_STATIC_DEVGW_01":
					deviceEntity.setDeviceType(2);
					break;
				case "CPE_LOCAL_GTWY":
					deviceEntity.setDeviceType(3);
					break;
				case "CPE_ENTPRISE_GTWY_SHARED":
					deviceEntity.setDeviceType(4);
					break;
				default:
					break;
				}
			} else if (param.getName().equals("DeviceTypeId"))
				deviceEntity.setDeviceTypeId(param.getValue());
			else if (param.getName().equals("DeviceId"))
				deviceEntity.setDeviceId(param.getValue());
			else if (param.getName().equals("CpeUsername"))
				deviceEntity.setCpeUsername(param.getValue());
			else if (param.getName().equals("CpePassword"))
				deviceEntity.setCpePassword(param.getValue());

			// XOO
			else if (param.getName().equals("DeviceSeqId"))
				deviceEntity.setDeviceSeqId(Long.valueOf(param.getValue()));
			else if (param.getName().equals("InternalAdmin"))
				deviceEntity.setInternalAdmin(Long.valueOf(param.getValue()));
			else if (param.getName().equals("EndPointType")) {
				if ("PRIMARY".equalsIgnoreCase(param.getValue()))
					deviceEntity.setEndPointType(VzbVoipEnums.EndPointTypeEnum.PRIMARY);
				if ("SCA".equalsIgnoreCase(param.getValue()))
					deviceEntity.setEndPointType(VzbVoipEnums.EndPointTypeEnum.SCA);
			} else if (param.getName().equals("TrunkGroupId"))
				deviceEntity.setTrunkId(param.getValue());
			else if (param.getName().equals("Description"))
				deviceEntity.setDescription(param.getValue());
			else if (param.getName().equals("Protocol"))
				deviceEntity.setProtocol(param.getValue());
			else if (param.getName().equals("AccessDevice"))
				deviceEntity.setAccessDevice(param.getValue());
			else if (param.getName().equals("DeviceLevel"))
				deviceEntity.setDeviceLevel(param.getValue());
			else if (param.getName().equals("Protocol"))
				deviceEntity.setProtocol(param.getValue());
			else if (param.getName().equals("AccessDevice"))
				deviceEntity.setAccessDevice(param.getValue());
			else if (param.getName().equals("DeviceLevel"))
				deviceEntity.setDeviceLevel(param.getValue());			
			else if (param.getName().equals("SignalingDirection")) {
					LOG.info("SignalingDirection Value = {}", param.getValue());
					deviceEntity.setSigDir(SignalingDirection.valueOf(param.getValue()));
				}
			else if (param.getName().equals("SolutionType"))
				deviceEntity.setSolutionType(SolutionType.valueOf(param.getValue()));
			// Start-Device Change
			else if (param.getName().equals("IpAddress"))
				deviceEntity.setIpAddress(param.getValue());
			else if (param.getName().equals("BWDeviceId"))
				deviceEntity.setBwDeviceId(param.getValue());
			else if (param.getName().equals("TransportProtocol"))
				deviceEntity.setTransportProtocol(TransportProtocol.valueOf(param.getValue()));
			else if (param.getName().equals("Port"))
				deviceEntity.setPort(param.getValue());
			else if (param.getName().equals("DeviceName"))
				deviceEntity.setDeviceName(param.getValue());
			else if (param.getName().equals("AuthFeatureType"))
				deviceEntity.setAuthFeatureType(AuthFeatureType.valueOf(param.getValue()));
			else if (param.getName().equals("Address"))
				deviceEntity.setAddress(param.getValue());
			else if (param.getName().equals("Region"))
				deviceEntity.setRegion(param.getValue());
			else if (param.getName().equals("TrunkType")) {
				if (GroupType.TWO_WAY.toString().equals(param.getValue()))
					deviceEntity.setTrunkType(GroupType.TWO_WAY);
				else if (GroupType.INBOUND.toString().equals(param.getValue()))
					deviceEntity.setTrunkType(GroupType.INBOUND);
				else if (GroupType.PRI_DID.toString().equals(param.getValue()))
					deviceEntity.setTrunkType(GroupType.PRI_DID);
				else if (GroupType.NON_PRI_DID.toString().equals(param.getValue()))
					deviceEntity.setTrunkType(GroupType.NON_PRI_DID);
				else if (GroupType.LINE.toString().equals(param.getValue()))
					deviceEntity.setTrunkType(GroupType.LINE);
			}else if (param.getName().equals("ProvisionCategory")) {
				deviceEntity.setProvisionCategory(param.getValue());
			}else if (param.getName().equalsIgnoreCase("ESBCSignalingIP")) {
				deviceEntity.setCpeIpAddress(param.getValue());
				deviceEntity.setIpAddress(param.getValue());
				deviceEntity.setAddress(param.getValue());
			}else if (param.getName().equals("AsClli")) {
				deviceEntity.setAsClli(param.getValue());
			}
			// End-Device Change
		}
		LOG.info("Exit - createDeviceFromParamInfo");
		return deviceEntity;
	}

	/**
	 * @param orderId
	 * @param parentId
	 * @param action
	 * @param delta
	 * @param paramName
	 * @return paramInfo
	 * @throws TranslatorException
	 */
	private ParamInfo createDeviceParamInfoFromOrderDetails(long orderId, long parentId, String action, boolean delta,
			String paramName) throws TranslatorException {
		LOG.info(
				"In DeviceTransformerImpl createDeviceParamInfoFromOrderDetails ordId:{} parentId:{} action:{} delta:{}",
				orderId, parentId, action, delta);
		ParamInfo paramInfo = null;

		try {
			TblOrderDetails tblOrderDetails = new TblOrderDetails();
			tblOrderDetails.setOrderId(orderId);
			tblOrderDetails.setAction(action);
			tblOrderDetails.setParentId(parentId);
			tblOrderDetails.setParamName(paramName);
			List<TblOrderDetails> ordDetails = voipOrderDao.getOrderDetailsWithActionAndParent(parentId, action, delta,
					paramName, tblOrderDetails);

			LOG.info("List Size:{}", ordDetails.size());
			
			paramInfo = new ParamInfo("CPEGATEWAYDEVICE", null, null);
			paramInfo = paramInfoTransformer.transformOrderDetailsToParamInfo(ordDetails, paramInfo, 0, null);

			// return createInstanceFromOrderDetails(ordDetails);
		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new TranslatorException(TranslatorException.ErrorCode.ORDER_NOT_SAVABLE,
					"Unexpected Error Occured while Parsing Trunk Order\"");
		}

		return paramInfo;

	}

	@Override
	public DeviceEntity enrichDeviceEntityWithInventory(VOIPOrderRequest voipOrderRequest, DeviceEntity deviceEntity)
			throws TranslatorException, GenericException, IllegalAccessException, ApplicationInterfaceException {
		LOG.info("Entered enrichDeviceEntityWithInventory For Device Map Id = {}", deviceEntity.getDeviceMapId());

		DeviceEntity deviceEntityInv = orderServiceHelperImpl
				.getEntityDetailsFromInventory(Long.toString(deviceEntity.getDeviceMapId()), DeviceEntity.class);

		// Copying Location Inv Details to Original Location Entity

		LOG.debug("++Level 10+++++Original Device Entity : {} ", deviceEntity);

		LOG.debug("++Level 10+++++Changed Device Entity : {} ", deviceEntity.getDeviceEntity());

		LOG.debug("++Level 10+++++Original Device Entity deviceEntityInv : {} ", deviceEntityInv);

		LOG.debug("++Level 10+++++Changed Device Entity deviceEntityInv.getdeviceEntity() : {} ",
				deviceEntityInv.getDeviceEntity());

		deviceEntity = copyFields(deviceEntityInv, deviceEntity);

		LOG.debug("++Level 11+++++Original Device Entity : {} ", deviceEntity);

		LOG.debug("++Level 11+++++Changed Device Entity : {} ", deviceEntity.getDeviceEntity());

		if (deviceEntity.getDeviceEntity() != null) {
			DeviceEntity deviceEntityChanged = deviceEntity.getDeviceEntity();

			// Copying Device Inv Details to Changed Device Entity
			copyFields(deviceEntity, deviceEntityChanged);

			LOG.debug("++Level 3+++++Original Device Entity : {} ", deviceEntity);

			LOG.debug("++Level 3+++++Changed Device Entity : {} ", deviceEntity.getDeviceEntity());

		}

		LOG.info("Exit enrichDeviceEntityWithInventory Device Enriched = {} ", deviceEntity);
		return deviceEntity;
	}
	
	private DeviceEntity copyFields(DeviceEntity currentDeviceEntity, DeviceEntity resultDeviceEntity) {
		
		// Inventory -> original
		if (resultDeviceEntity.getLocationId() == null && currentDeviceEntity.getLocationId() != null) {
			resultDeviceEntity.setLocationId(currentDeviceEntity.getLocationId());
		}
		if (resultDeviceEntity.getDeviceMapId() == null && currentDeviceEntity.getDeviceMapId() != null) {
			resultDeviceEntity.setDeviceMapId(currentDeviceEntity.getDeviceMapId());
		}
		if (resultDeviceEntity.getDeviceNameId() == null && currentDeviceEntity.getDeviceNameId() != null) {
			resultDeviceEntity.setDeviceNameId(currentDeviceEntity.getDeviceNameId());
		}
		if (resultDeviceEntity.getCustomerId() == null && currentDeviceEntity.getCustomerId() != null) {
			resultDeviceEntity.setCustomerId(currentDeviceEntity.getCustomerId());
		}
		if (resultDeviceEntity.getDepartmentId() == null && currentDeviceEntity.getDepartmentId() != null) {
			resultDeviceEntity.setDepartmentId(currentDeviceEntity.getDepartmentId());
		}
		if (resultDeviceEntity.getBsDeviceId() == null && currentDeviceEntity.getBsDeviceId() != null) {
			resultDeviceEntity.setBsDeviceId(currentDeviceEntity.getBsDeviceId());
		}
		if (resultDeviceEntity.getDeviceName() == null && currentDeviceEntity.getDeviceName() != null) {
			resultDeviceEntity.setDeviceName(currentDeviceEntity.getDeviceName());
		}
		if (resultDeviceEntity.getDeviceType() == null && currentDeviceEntity.getDeviceType() != null) {
			resultDeviceEntity.setDeviceType(currentDeviceEntity.getDeviceType());
		}
		if (resultDeviceEntity.getCodec() == null && currentDeviceEntity.getCodec() != null) {
			resultDeviceEntity.setCodec(currentDeviceEntity.getCodec());
		}
		if (resultDeviceEntity.getSTN() == null && currentDeviceEntity.getSTN() != null) {
			resultDeviceEntity.setSTN(currentDeviceEntity.getSTN());
		}
		if (resultDeviceEntity.getGwyFqdn() == null && currentDeviceEntity.getGwyFqdn() != null) {
			resultDeviceEntity.setGwyFqdn(currentDeviceEntity.getGwyFqdn());
		}
		if (resultDeviceEntity.getGwyHunt() == null && currentDeviceEntity.getGwyHunt() != null) {
			resultDeviceEntity.setGwyHunt(currentDeviceEntity.getGwyHunt());
		}
		if (resultDeviceEntity.getSbcEnabledFlag() == null && currentDeviceEntity.getSbcEnabledFlag() != null) {
			resultDeviceEntity.setSbcEnabledFlag(currentDeviceEntity.getSbcEnabledFlag());
		}
		if (resultDeviceEntity.getDeviceTypeId() == null && currentDeviceEntity.getDeviceTypeId() != null) {
			resultDeviceEntity.setDeviceTypeId(currentDeviceEntity.getDeviceTypeId());
		}
		if (resultDeviceEntity.getCpeUsername() == null && currentDeviceEntity.getCpeUsername() != null) {
			resultDeviceEntity.setCpeUsername(currentDeviceEntity.getCpeUsername());
		}
		if (resultDeviceEntity.getCpePassword() == null && currentDeviceEntity.getCpePassword() != null) {
			resultDeviceEntity.setCpePassword(currentDeviceEntity.getCpePassword());
		}
		if (resultDeviceEntity.getDeviceSeqId() == null && currentDeviceEntity.getDeviceSeqId() != null) {
			resultDeviceEntity.setDeviceSeqId(currentDeviceEntity.getDeviceSeqId());
		}
		if (resultDeviceEntity.getEndPointType() == null && currentDeviceEntity.getEndPointType() != null) {
			resultDeviceEntity.setEndPointType(currentDeviceEntity.getEndPointType());
		}
		if (resultDeviceEntity.getTrunkId() == null && currentDeviceEntity.getTrunkId() != null) {
			resultDeviceEntity.setTrunkId(currentDeviceEntity.getTrunkId());
		}
		if (resultDeviceEntity.getDescription() == null && currentDeviceEntity.getDescription() != null) {
			resultDeviceEntity.setDescription(currentDeviceEntity.getDescription());
		}
		if (resultDeviceEntity.getProtocol() == null && currentDeviceEntity.getProtocol() != null) {
			resultDeviceEntity.setProtocol(currentDeviceEntity.getProtocol());
		}
		if (resultDeviceEntity.getAccessDevice() == null && currentDeviceEntity.getAccessDevice() != null) {
			resultDeviceEntity.setAccessDevice(currentDeviceEntity.getAccessDevice());
		}
		if (resultDeviceEntity.getDeviceLevel() == null && currentDeviceEntity.getDeviceLevel() != null) {
			resultDeviceEntity.setDeviceLevel(currentDeviceEntity.getDeviceLevel());
		}
		if (resultDeviceEntity.getSigDir() == null && currentDeviceEntity.getSigDir() != null) {
			resultDeviceEntity.setSigDir(currentDeviceEntity.getSigDir());
		}
		if (resultDeviceEntity.getSolutionType() == null && currentDeviceEntity.getSolutionType() != null) {
			resultDeviceEntity.setSolutionType(currentDeviceEntity.getSolutionType());
		}
		if (resultDeviceEntity.getIpAddress() == null && currentDeviceEntity.getIpAddress() != null) {
			resultDeviceEntity.setIpAddress(currentDeviceEntity.getIpAddress());
		}
		if (resultDeviceEntity.getBwDeviceId() == null && currentDeviceEntity.getBwDeviceId() != null) {
			resultDeviceEntity.setBwDeviceId(currentDeviceEntity.getBwDeviceId());
		}
		if (resultDeviceEntity.getTransportProtocol() == null && currentDeviceEntity.getTransportProtocol() != null) {
			resultDeviceEntity.setTransportProtocol(currentDeviceEntity.getTransportProtocol());
		}
		if (resultDeviceEntity.getPort() == null && currentDeviceEntity.getPort() != null) {
			resultDeviceEntity.setPort(currentDeviceEntity.getPort());
		}
		if (resultDeviceEntity.getDeviceName() == null && currentDeviceEntity.getDeviceName() != null) {
			resultDeviceEntity.setDeviceName(currentDeviceEntity.getDeviceName());
		}
		if (resultDeviceEntity.getAddress() == null && currentDeviceEntity.getAddress() != null) {
			resultDeviceEntity.setAddress(currentDeviceEntity.getAddress());
		}
		if (resultDeviceEntity.getRegion() == null && currentDeviceEntity.getRegion() != null) {
			resultDeviceEntity.setRegion(currentDeviceEntity.getRegion());
		}
		if (resultDeviceEntity.getTrunkType() == null && currentDeviceEntity.getTrunkType() != null) {
			resultDeviceEntity.setTrunkType(currentDeviceEntity.getTrunkType());
		}
		return resultDeviceEntity;
	}
	
	@Override
	public DeviceEntity deviceInventoryToDeviceEntityTransformer(Map<String, String> resultantRow) {
		LOG.info("Entered deviceInventoryToDeviceEntityTransformer");
		DeviceEntity deviceEntity = new DeviceEntity();
		
		deviceEntity.setDeviceMapId(Long.valueOf(resultantRow.get("DEVICE_MAP_ID")));
		if(resultantRow.get("DEVICE_MAP_ID") != null) {
			deviceEntity.setDeviceMapId(Long.valueOf(resultantRow.get("DEVICE_MAP_ID")));
		}
		deviceEntity.setCustomerId(resultantRow.get("ENTERPRISE_ID"));
		deviceEntity.setLocationId(resultantRow.get("LOCATION_ID"));
		deviceEntity.setDepartmentId(resultantRow.get("DEPARTMENT_ID"));
		deviceEntity.setSipDomain(resultantRow.get("SIP_DEVICE_ID"));
		if(resultantRow.get("ENV_ORDER_ID") != null) {
			deviceEntity.setEnvOrderId(Long.valueOf(resultantRow.get("ENV_ORDER_ID")));
		}
		deviceEntity.setDeviceNameId(resultantRow.get("DEVICE_NAME_ID"));
		
		deviceEntity.setDeviceName(resultantRow.get("DEVICE_NAME"));
		deviceEntity.setDeviceTypeId(resultantRow.get("DEVICE_TYPE_ID"));
		deviceEntity.setMac(resultantRow.get("MAC_ADDRESS"));
		deviceEntity.setSerialNumber(resultantRow.get("SERIAL_NUMBER"));
		if(resultantRow.get("PORTS_AVAILABLE") != null) {
			deviceEntity.setPortsAvailable(Integer.parseInt(resultantRow.get("PORTS_AVAILABLE")));
		}
		deviceEntity.setCpeUsername(resultantRow.get("CPE_USERNAME"));
		deviceEntity.setCpePassword(resultantRow.get("CPE_PASSWORD"));
		deviceEntity.setCodec(resultantRow.get("CODEC_ID"));
		deviceEntity.setBizLocation(resultantRow.get("BUSINESS_LOCATION"));
		deviceEntity.setStationLocation(resultantRow.get("STATION_LOCATION"));
		deviceEntity.setPolycomFirmwareVersion(resultantRow.get("FIRMWARE_VERSION_ID"));
		deviceEntity.setIpAddress(resultantRow.get("IP_ADDRESS"));	
		if(resultantRow.get("PORTS_AVAILABLE") != null) {
			deviceEntity.setPortsAvailable(Integer.parseInt(resultantRow.get("PORTS_AVAILABLE")));
		}
		if (resultantRow.get("BRIX_IND") != null) {
			deviceEntity.setBrixInd(resultantRow.get("BRIX_IND").equals("1") ? true : false);
		}
		deviceEntity.setPort(resultantRow.get("PORTS_ASSIGNED"));
		deviceEntity.setBsDeviceId(resultantRow.get("BS_DEVICE_ID"));
		deviceEntity.setNetworkFeatures(resultantRow.get("CPE_NETWORK_FEATURES"));
		if(resultantRow.get("INTERNAL_ADMIN") != null) {
			deviceEntity.setInternalAdmin(Long.valueOf(resultantRow.get("INTERNAL_ADMIN")));
		}
		
		deviceEntity.setTermCallingInd(resultantRow.get("TERM_CALLING_IND"));
		deviceEntity.setsubId(resultantRow.get("SBC_ID"));
		deviceEntity.setTransport(resultantRow.get("TRANSPORT"));
		deviceEntity.setGwyFqdn(resultantRow.get("GATEWAY_FQDN"));
		deviceEntity.setGwyHunt(resultantRow.get("GATEWAY_HUNT"));
		deviceEntity.setSTNLinePort(resultantRow.get("STN_LINE_PORT"));
		if(resultantRow.get("AGGREGATE_OFFNET_CCL") != null) {
			deviceEntity.setAggregateOffnetCcl(Integer.valueOf(resultantRow.get("AGGREGATE_OFFNET_CCL")));
		}
		if (resultantRow.get("SIGNALING_TIER_LOOKUP_VALUE") != null) {
			deviceEntity.setSignalingRateLookupValue(
					BigDecimal.valueOf(Long.valueOf(resultantRow.get("SIGNALING_TIER_LOOKUP_VALUE"))));
		}
		if (resultantRow.get("TIER_OVERRIDE_FLAG") != null) {
			deviceEntity.setSigTierOverrideFlag(resultantRow.get("TIER_OVERRIDE_FLAG").equals("1") ? true : false);
		}
		if (resultantRow.get("IP_VERSION") != null) {
			deviceEntity
					.setIpVersion(VzbVoipEnums.IPVersionEnum.IPv4.getAcronym().equals(resultantRow.get("IP_VERSION"))
							? VzbVoipEnums.IPVersionEnum.IPv4
							: VzbVoipEnums.IPVersionEnum.IPv6);
		}
		if(resultantRow.get("PQ_INSTANCE_ID") != null) {
			deviceEntity.setPqInstanceId(Long.valueOf(resultantRow.get("PQ_INSTANCE_ID")));
		}
		if(resultantRow.get("TSO_MIG_LOCK") != null) {
			deviceEntity.setTsoMigLock(Short.valueOf(resultantRow.get("TSO_MIG_LOCK")));
		}
		deviceEntity.setCustSigConstraint(resultantRow.get("CUST_SIG_CONSTRAINT"));
		deviceEntity.setUpdateComment(resultantRow.get("UPDATE_COMMENT"));
		deviceEntity.setDeviceType(Integer.valueOf(resultantRow.get("DEVICE_REALTYPE_ID")));
		
		LOG.info("Exit deviceInventoryToDeviceEntityTransformer");
		return deviceEntity;
	}

}
