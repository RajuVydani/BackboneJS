package com.vz.esap.translation.order.service.hpbx;

import static java.util.Arrays.stream;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.Lists;
import com.vz.esap.translation.connector.model.DBServiceResponse;
import com.vz.esap.translation.constant.GenericConstant;
import com.vz.esap.translation.constant.TranslationConstant;
import com.vz.esap.translation.dao.model.TblEnvOrder;
import com.vz.esap.translation.dao.model.TblOrder;
import com.vz.esap.translation.dao.model.TblOrderDetails;
import com.vz.esap.translation.dao.model.TblSafeStore;
import com.vz.esap.translation.entity.LocationEntity;
import com.vz.esap.translation.enums.EsapEnum.LocationType;
import com.vz.esap.translation.enums.EsapEnum.PcMilestone;
import com.vz.esap.translation.enums.EsapEnum.PcResponseType;
import com.vz.esap.translation.enums.EsapEnum.StatusCode;
import com.vz.esap.translation.exception.GenericException;
import com.vz.esap.translation.exception.TranslatorException;
import com.vz.esap.translation.exception.TranslatorException.ErrorCode;
import com.vz.esap.translation.order.dao.VOIPOrderDao;
import com.vz.esap.translation.order.model.request.Feature;
import com.vz.esap.translation.order.model.request.VOIPOrderRequest;
import com.vz.esap.translation.order.model.response.VoipOrderResponse;
import com.vz.esap.translation.order.service.NotificationService;
import com.vz.esap.translation.order.service.OrderServiceBase;
import com.vz.esap.translation.order.service.VOIPResponseGenerator;
import com.vz.esap.translation.order.service.device.DeviceOrderService;
import com.vz.esap.translation.order.service.enterprise.EnterpriseOrderService;
import com.vz.esap.translation.order.service.enterprisetrunk.EnterpriseTrunkOrderService;
import com.vz.esap.translation.order.service.helper.OrderServiceHelper;
import com.vz.esap.translation.order.service.location.LocationOrderService;
import com.vz.esap.translation.order.service.nbs.NbsOrderServiceImpl;
import com.vz.esap.translation.order.service.tn.GroupTnOrderServiceImpl;
import com.vz.esap.translation.order.service.trunk.TrunkOrderServiceImpl;
import com.vz.esap.translation.order.transformer.TblSafeStoreTransformer;
import com.vz.esap.translation.order.transformer.VoipRequestTransformer;
import com.vz.esap.translation.util.InventoryUtil;
import com.vz.esap.translation.util.TranslationUtility;

import EsapEnumPkg.WorkOrderEnum;

/**
 * @author chattni
 *
 */
@Service
public class HpbxOrderServiceImpl extends OrderServiceBase implements HpbxOrderService {

	private static final Logger LOG = LoggerFactory.getLogger(HpbxOrderServiceImpl.class);

	@Autowired
	private VOIPOrderDao voipOrderDao;

	@Autowired
	private TblSafeStoreTransformer tblSafeStoreTransformer;

	@Autowired
	private OrderServiceHelper orderServiceHelperImpl;

	@Autowired
	private VOIPResponseGenerator voipResponseGenerator;

	@Autowired
	private VoipRequestTransformer voipRequestTransformerImpl;

	@Autowired
	private EnterpriseOrderService enterpriseOrderService;

	@Autowired
	private LocationOrderService locationOrderService;

	@Autowired
	private DeviceOrderService deviceOrderService;

	@Autowired
	private EnterpriseTrunkOrderService enterpriseTrunkOrderServiceImpl;

	@Autowired
	private TrunkOrderServiceImpl trunkOrderServiceImpl;

	@Autowired
	private NbsOrderServiceImpl nbsOrderServiceImpl;

	@Autowired
	private GroupTnOrderServiceImpl groupTnOrderServiceImpl;

	@Autowired
	private NotificationService notificationServiceImpl;
	
	@Autowired
	private InventoryUtil inventoryUtil;

	@Autowired
	private TranslationUtility translationUtility;
	
	private ObjectMapper mapper = new ObjectMapper();

	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.vz.esap.translation.order.service.hpbx.HpbxOrderService#
	 * createHpbxValidateOrder(com.vz.esap.translation.order.model.request.
	 * VOIPOrderRequest, java.util.Map)
	 */
	@Override
	public VoipOrderResponse createHpbxValidateOrder(VOIPOrderRequest voipOrderRequest,
			Map<String, String> productDetails) throws GenericException, TranslatorException
	{
		LOG.info("Entered createHpbxValidateOrder");
		VoipOrderResponse voipOrderResponse = null;
		DBServiceResponse dbServiceResponse = null;
		VOIPOrderRequest voipOrderGeneratedRequest = null;
		int version;
		List<Feature> features = null;
		boolean isNewEsipEnterprise = false;

		try {
			
			int orderVersion = Integer.parseInt(voipOrderRequest.getOrderHeader().getWorkOrderVersion());
			if (orderVersion > 0) {
				LOG.info("Handling supp orders whose previous orders in \"InProgress\" status.");
				orderServiceHelperImpl.handleOrdersInProgress(voipOrderRequest);
			}
			
			voipOrderRequest = translationUtility.setAsClli(voipOrderRequest);

			if (voipOrderRequest.getOrderHeader().getGCHId() == null)
				throw new TranslatorException(ErrorCode.ESAP_MISSING_REQUIRED_DATA,
						"GCHID is not present in the request BOD");
			dbServiceResponse = orderServiceHelperImpl
					.getEnterpriseInformationFromGchId(voipOrderRequest, LocationType.HPBX_ECH);

			version = Integer.parseInt(voipOrderRequest.getOrderHeader().getWorkOrderVersion());
			
			isNewEsipEnterprise = orderServiceHelperImpl.isNewEsipEnterprise(voipOrderRequest, dbServiceResponse);

			// Install Not Supp
			if (dbServiceResponse != null && "I".equalsIgnoreCase(voipOrderRequest.getOrderHeader().getOrderType())) 
			{

				// Install Brand New Customer Supp + V0
				if (version == 0 && isNewEsipEnterprise) //DO NOT Delete dbServiceResponse.getNumberOfRecords() == 0
				{
					LOG.info("New Customer");
					// Enrich voipOrderRequest for install new Enterprise
					voipOrderGeneratedRequest = voipRequestTransformerImpl
							.enrichVoipRequestWithEnterprise(voipOrderRequest, productDetails, dbServiceResponse, true);
					
					voipOrderGeneratedRequest = voipRequestTransformerImpl.enrichVoipRequestWithLocation(
							voipOrderGeneratedRequest, productDetails, dbServiceResponse, true);
					
					voipOrderGeneratedRequest = voipRequestTransformerImpl.enrichVoipRequestWithTrunkGroup(
							voipOrderGeneratedRequest);
					
					voipOrderGeneratedRequest = voipRequestTransformerImpl.enrichVoipRequestWithEt(
							voipOrderGeneratedRequest, productDetails, dbServiceResponse, true);
					
					voipOrderGeneratedRequest = voipRequestTransformerImpl
							.enrichVoipRequestWithDevice(voipOrderGeneratedRequest);

					LOG.info("Voip Order Request Enriched Completely : {}",
							mapper.writerWithDefaultPrettyPrinter().writeValueAsString(voipOrderGeneratedRequest));

					voipOrderResponse = createHpbxValidatePassOrder(voipOrderGeneratedRequest, true);
					
				} 
				else if (version == 0) //DO NOT Delete dbServiceResponse.getNumberOfRecords() > 0 && version == 0				
				{
					LOG.info("Existing Customer");
					voipOrderGeneratedRequest = voipRequestTransformerImpl.modifyOrderHeader(voipOrderRequest,
							dbServiceResponse, false, productDetails);

					/*voipOrderGeneratedRequest = voipRequestTransformerImpl.enrichVoipRequestWithLocation(
							voipOrderGeneratedRequest, productDetails, dbServiceResponse, true);*/
					
					/*voipOrderGeneratedRequest = voipRequestTransformerImpl.enrichVoipRequestWithTrunkGroup(
							voipOrderGeneratedRequest);*/
					
					/*voipOrderGeneratedRequest = voipRequestTransformerImpl.enrichVoipRequestWithEt(
							voipOrderGeneratedRequest, productDetails, dbServiceResponse, true);*/
					
					/*voipOrderGeneratedRequest = voipRequestTransformerImpl
							.enrichVoipRequestWithDevice(voipOrderGeneratedRequest);*/
					
					LOG.info("Voip Order Request Enriched Completely : {}",
							mapper.writerWithDefaultPrettyPrinter().writeValueAsString(voipOrderGeneratedRequest));

					voipOrderResponse = createHpbxValidatePassOrder(voipOrderGeneratedRequest, false);
					
				}
				else if (version > 0) //DO NOT Delete dbServiceResponse.getNumberOfRecords() > 0 && version > 0
				{
					LOG.info("Existing Customer For Supp");

					TblEnvOrder tblEnvOrder = voipOrderDao.getTblEnvOrderDetailsFromInventory(dbServiceResponse,
							TranslationConstant.TBL_ENTERPRISE);
					
					/*TblEnvOrder tblEnvOrder = inventoryUtil.getTblEnvOrderDetailsFromInventory(
							voipOrderRequest.getOrderHeader().getVoipLocationId(), TranslationConstant.TBL_LOCATION);*/

					if (tblEnvOrder != null && tblEnvOrder.getOrderNumber()
							.equalsIgnoreCase(voipOrderRequest.getOrderHeader().getWorkOrderNumber())) {
						LOG.info("This Customer was created as the previous Version of Order");
						// Enrich voipOrderRequest for install new Enterprise


						voipOrderGeneratedRequest = voipRequestTransformerImpl
								.enrichVoipRequestWithEnterprise(voipOrderRequest, productDetails, dbServiceResponse, false);
						
						voipOrderGeneratedRequest = voipRequestTransformerImpl.enrichVoipRequestWithLocation(
								voipOrderGeneratedRequest, productDetails, dbServiceResponse, false);
						
						voipOrderGeneratedRequest = voipRequestTransformerImpl.enrichVoipRequestWithTrunkGroup(
								voipOrderGeneratedRequest);
						
						voipOrderGeneratedRequest = voipRequestTransformerImpl.enrichVoipRequestWithEt(
								voipOrderGeneratedRequest, productDetails, dbServiceResponse, false);
						
						voipOrderGeneratedRequest = voipRequestTransformerImpl
								.enrichVoipRequestWithDevice(voipOrderGeneratedRequest);					

						
					} else {
						LOG.info("This Customer was created as the previous ECH order");
						voipOrderGeneratedRequest = voipRequestTransformerImpl.modifyOrderHeader(voipOrderRequest,
								dbServiceResponse, false, productDetails);
						
						
					}

					LOG.info("Voip Order Request Enriched Completely : {}",
							mapper.writerWithDefaultPrettyPrinter().writeValueAsString(voipOrderGeneratedRequest));
					
					voipOrderResponse = createHpbxValidatePassOrder(voipOrderGeneratedRequest, false);
				}
			} 
			else if ("C".equalsIgnoreCase(voipOrderRequest.getOrderHeader().getOrderType())) {

				LOG.info("MAC Order");

				voipOrderGeneratedRequest = voipRequestTransformerImpl.modifyOrderHeader(voipOrderRequest,
						dbServiceResponse, false, productDetails);

				features = stream(voipOrderGeneratedRequest.getConvergedService().getFeature())
						.filter(feature -> feature.getCode().equalsIgnoreCase("FET_XO_TRU"))
						.collect(Collectors.toList());

				if (!features.isEmpty()) {
					voipOrderGeneratedRequest = voipRequestTransformerImpl.enrichVoipRequestWithEt(
							voipOrderGeneratedRequest, productDetails, dbServiceResponse, false);
				}

				voipOrderResponse = createHpbxValidatePassOrder(voipOrderGeneratedRequest, false);

			}

		} 
		catch (TranslatorException ex)
		{
			LOG.error("Exception {} ", ex);
			throw new TranslatorException(ex.getErrorCode(), ex.getMessage());
		}
		catch (Exception e) {

			notificationServiceImpl.notifyFailures(voipResponseGenerator.preparePCMilestone(voipOrderRequest,
					PcMilestone.ACTIVATION_COMPLETE.getValue(), StatusCode.ESP_FAILURE,
					PcResponseType.ORDER.getValue()));

			LOG.error("Exception {} ", e);
			throw new GenericException(GenericException.GENERIC_EXCEPTION, "Exception in the provide input arguments");
		}

		LOG.info("Exited createEslEsipValidateOrder");
		return voipOrderResponse;
	}

	/**
	 * @param voipOrderRequest
	 * @param isNewCustomer
	 * @return voipOrderResponse
	 * @throws GenericException
	 * @throws TranslatorException
	 */
	VoipOrderResponse createHpbxValidatePassOrder(VOIPOrderRequest voipOrderRequest, boolean isNewCustomer)
			throws GenericException, TranslatorException {
		LOG.info("Entered createHpbxValidatePassOrder");

		VoipOrderResponse voipOrderResponse = null;
		long sequenceNumber = -1;
		TblSafeStore tblSafeStoreObject = null;
		TblEnvOrder tblEnvOrderObject = null;
		TblOrder tblOrderObject = null;
		long detailCounts = -1;
		long serviceCounts = -1;
		String virtualAddrCountry = null;

		try {
			sequenceNumber = voipOrderRequest.getSequenceNumber();
			LOG.info("TblSafeOrder  SequenceNo : {}", sequenceNumber);

			// Update TblSafeStore
			tblSafeStoreObject = tblSafeStoreTransformer.prepareTblSafeStoreData(sequenceNumber);
			voipOrderDao.updateTblSafeStoreTranslationStartTime(tblSafeStoreObject);

			tblEnvOrderObject = orderServiceHelperImpl.createHpbxEnvOrder(voipOrderRequest,
					WorkOrderEnum.Status.WO_RECV_SEGMENT);

			tblOrderObject = orderServiceHelperImpl.createHpbxOrderHeader(voipOrderRequest,
					WorkOrderEnum.Status.WO_RECV_SEGMENT, tblEnvOrderObject);

			detailCounts = orderServiceHelperImpl.createHpbxOrderDetails(voipOrderRequest, tblOrderObject,
					isNewCustomer);

			//ESVRRS-19513 
			if ("C".equalsIgnoreCase(voipOrderRequest.getOrderHeader().getOrderType())) {
				translationUtility.populateEntityFlag(tblOrderObject);
			}
			//ESVRRS-19513
			
			if (voipOrderRequest.getLocation() != null && voipOrderRequest.getLocation().getLocationAddress() != null)
				virtualAddrCountry = voipOrderRequest.getLocation().getLocationAddress().getCountryCode();

			serviceCounts = orderServiceHelperImpl.createValidateOrderServices(tblOrderObject, virtualAddrCountry);

			voipOrderDao.updateTblEnvOrderStatus(tblEnvOrderObject.getEnvOrderId(), WorkOrderEnum.Status.WO_INIT);
			voipOrderDao.updateTblOrderStatus(tblOrderObject.getOrderId(), WorkOrderEnum.Status.WO_INIT);

			LOG.info("Info {}-{}", detailCounts, serviceCounts);

			voipOrderResponse = voipResponseGenerator.prepareSuccessOrderResponse(voipOrderRequest);
			
			LOG.info("Status For createHpbxValidatePassOrder {}", voipOrderResponse.getOrderStatus());

		} catch (Exception te) {
			LOG.error("Exception {}", te);
			if (tblEnvOrderObject != null) {
				voipOrderDao.updateTblEnvOrderStatus(tblEnvOrderObject.getEnvOrderId(),
						WorkOrderEnum.Status.WO_TRANSLATION_FAIL);
				throw new TranslatorException(ErrorCode.ORDER_CREATION_FAILURE, "Failed to create Order");
			} else {
				throw new GenericException(GenericConstant.GENERIC_EXCEPTION, "Generic Exception has occured");
			}
		}

		LOG.info("Exited createHpbxValidatePassOrder");
		return voipOrderResponse;

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.vz.esap.translation.order.service.esl.EslOrderService#
	 * createEslEsipReleaseOrder(com.vz.esap.translation.order.model.request.
	 * VOIPOrderRequest, java.util.Map)
	 */
	@Override
	public VoipOrderResponse createHpbxReleaseOrder(VOIPOrderRequest voipOrderRequest,
			Map<String, String> productDetails) throws TranslatorException, GenericException {
		
		LOG.info("Entered createHpbxReleaseOrder");
		
		List<TblEnvOrder> tblEnvOrderList = null;
		List<TblOrder> tblOrderList = null;
		List<TblOrderDetails> tblOrderDetailsList;
		TblEnvOrder tblEnvOrder = null;
		VoipOrderResponse voipOrderResponse = null;
		List<TblOrderDetails> tnTblOrderDetailsList = null;
		Boolean entityFlag = false;
		try {

			// Find Validation Env Order
			tblEnvOrderList = orderServiceHelperImpl.getMatchingValidationEnvOrder(voipOrderRequest);
			
			if (tblEnvOrderList.get(0) != null && tblEnvOrderList.get(0).getEnterpriseId() != null) {
				voipOrderRequest.getOrderHeader().setEnterpriseId(tblEnvOrderList.get(0).getEnterpriseId());

			}

			LOG.info("Env Order Id of Validation Pass = {}", tblEnvOrderList.get(0).getEnvOrderId());

			// Find Validation Order
			tblOrderList = orderServiceHelperImpl.getMatchingPassOrder(tblEnvOrderList.get(0));

			//ESVRRS-19513
			entityFlag = translationUtility.isEntityFlagExists(tblOrderList.get(0));
			//ESVRRS-19513
			if ("C".equalsIgnoreCase(voipOrderRequest.getOrderHeader().getOrderType()) && entityFlag) {
				// soft success has to return as entities doesn't exists..
				LOG.info("#Entities doesn't exists for order##");
				tblEnvOrder = createTblEnvOrder(null, tblOrderList.get(0), voipOrderRequest,
						WorkOrderEnum.Status.WO_COMPLETE);

				voipOrderResponse = voipResponseGenerator.prepareSuccessOrderResponse(voipOrderRequest);

				notificationServiceImpl.notifySuccess(voipResponseGenerator.preparePCMilestone(voipOrderRequest,
						PcMilestone.ORDER_ACCEPTANCE.getValue(), StatusCode.ESP_SUCCESS,
						PcResponseType.ORDER.getValue()));
			}else {
			// Find matching Order details
			for (TblOrder tblOrderBean : tblOrderList) {
				LOG.info("ValidationOrderId: {}", tblOrderBean.getOrderId());
				
				tblOrderDetailsList = orderServiceHelperImpl.getMatchingOrderDetails(tblOrderBean);
				
				if(tblOrderDetailsList!= null && !tblOrderDetailsList.isEmpty()) {
				LOG.info("Order Details Size: {}", tblOrderDetailsList.size());

				if (voipOrderRequest.getOrderHeader().getMinorOrderType() != null)
					voipOrderRequest.getOrderHeader().setMinorOrderType(tblEnvOrderList.get(0).getMinorOrderType());

				tblEnvOrder = createTblEnvOrder(tblOrderDetailsList.get(0), tblOrderBean, voipOrderRequest,
						WorkOrderEnum.Status.WO_RECV_SEGMENT);

				// Find Entities and route
				for (TblOrderDetails tblOrderDetails : tblOrderDetailsList) {
					LOG.info("TblOrderDetails Param Detail Id : {} , Param Name : {} ",
							tblOrderDetails.getOrderDetailId(), tblOrderDetails.getParamName());
					if ("Enterprise".equalsIgnoreCase(tblOrderDetails.getParamName()))
						voipOrderResponse = enterpriseOrderService.processReleaseOrder(tblOrderDetails, tblOrderBean,
								tblEnvOrder, voipOrderRequest, tblOrderDetailsList);
					if ("Location".equalsIgnoreCase(tblOrderDetails.getParamName()))
						voipOrderResponse = locationOrderService.processReleaseOrder(tblOrderDetails, tblOrderBean,
								tblEnvOrder, voipOrderRequest, tblOrderDetailsList);
					if ("Device".equalsIgnoreCase(tblOrderDetails.getParamName()))
						voipOrderResponse = deviceOrderService.processReleaseOrder(tblOrderDetails, tblOrderBean,
								tblEnvOrder, voipOrderRequest, tblOrderDetailsList);
					if ("Group".equalsIgnoreCase(tblOrderDetails.getParamName()))
						voipOrderResponse = trunkOrderServiceImpl.processReleaseOrder(tblOrderDetails, tblOrderBean,
								tblEnvOrder, voipOrderRequest, tblOrderDetailsList);
					if ("EnterpriseTrunk".equalsIgnoreCase(tblOrderDetails.getParamName()))
						voipOrderResponse = enterpriseTrunkOrderServiceImpl.processReleaseOrder(tblOrderBean,
								tblOrderDetails, tblEnvOrder, voipOrderRequest, tblOrderDetailsList);					
				}
				
				// TN Processing Code Here
				tnTblOrderDetailsList = orderServiceHelperImpl.getMatchingTnOrderDetails(tblOrderBean);
				int batchSize = 500; // To do need to pull in batches.
				
				if (!tnTblOrderDetailsList.isEmpty()) {

					for (List<TblOrderDetails> batchTNOrderDetails : Lists.partition(tnTblOrderDetailsList,
							batchSize)) {

						// Here we need to implement batching as in BAU
						groupTnOrderServiceImpl.processReleaseOrder(batchTNOrderDetails, tblOrderBean, tblEnvOrder,
								voipOrderRequest, tnTblOrderDetailsList);
						// Process Individual TN's here
					}					
				}
			  }

			//Added for SUPP
			int orderVersion = Integer.parseInt(voipOrderRequest.getOrderHeader().getWorkOrderVersion());
			LOG.info("Order version:: {}", orderVersion);

			if (orderVersion > 0) {
				orderServiceHelperImpl.handlePreviousOrder(voipOrderRequest, null, tblEnvOrder.getEnvOrderId());
			}			
			voipOrderDao.createParentChildOrderRelationship(tblEnvOrder);

			if(tblEnvOrder != null) {
				if(orderVersion == 0) {
					voipOrderDao.updateTblEnvOrderStatus(tblEnvOrder.getEnvOrderId(), WorkOrderEnum.Status.WO_INIT);
				} else {
					orderServiceHelperImpl.updateTblEnvOrderStatusWithCurrOrdFlow(voipOrderRequest, tblEnvOrder.getEnvOrderId());
				}
			}			
			voipOrderResponse = voipResponseGenerator.prepareSuccessOrderResponse(voipOrderRequest);

			notificationServiceImpl.notifySuccess(voipResponseGenerator.preparePCMilestone(voipOrderRequest,
					PcMilestone.ORDER_ACCEPTANCE.getValue(), StatusCode.ESP_SUCCESS,
					PcResponseType.ORDER.getValue()));
			 }
			}
		} catch (TranslatorException ex) {
			LOG.error("Exception {} ", ex);
			throw new TranslatorException(ex.getErrorCode(), ex.getMessage());
		} catch (Exception e) {
			if (tblEnvOrder != null && tblEnvOrder.getEnvOrderId() != null)
				voipOrderDao.updateTblEnvOrderStatus(tblEnvOrder.getEnvOrderId(),
						WorkOrderEnum.Status.WO_TRANSLATION_FAIL);

			LOG.error("Exception {} ", e);

			notificationServiceImpl.notifyFailures(voipResponseGenerator.preparePCMilestone(voipOrderRequest,
					PcMilestone.ORDER_ACCEPTANCE.getValue(), StatusCode.ESP_FAILURE, PcResponseType.ORDER.getValue()));

			throw new GenericException(GenericException.GENERIC_EXCEPTION, "Exception in createHpbxReleaseOrder");
		}
		LOG.info("Exit createHpbxReleaseOrder");
		return voipOrderResponse;
	}
	
	/** HPBX Disconnect
	 * @param voipOrderRequest
	 * @return voipOrderResponse
	 * @throws GenericException
	 * @throws TranslatorException
	 */
	@Override
	public VoipOrderResponse createHpbxLocSuspendOrder(VOIPOrderRequest voipOrderRequest,
			Map<String, String> productDetails) throws TranslatorException, GenericException {
		LOG.info("Entered createHpbxLocSuspendOrder");

		VoipOrderResponse voipOrderResponse = null;
		String voipLocation = null;
		String customerId = null;
		long sequenceNumber = -1;
		TblSafeStore tblSafeStoreObject = null;
		TblEnvOrder tblEnvOrderObject = null;
		String virtualAddrCountry = null;
		LocationEntity locationEntityInv = null;
		Map<String, String> locRows = null;
		DBServiceResponse dbServiceResponse = null;
		String remoteLocationEnterpriseID = null;

		try {
			if (voipOrderRequest.getOrderHeader().getVoipLocationId() == null
					|| voipOrderRequest.getOrderHeader().getVoipLocationId().isEmpty())
				throw new TranslatorException(ErrorCode.INVALID_XML, "Voip Location ID is Missing");

			voipLocation = voipOrderRequest.getOrderHeader().getVoipLocationId();

			if (voipOrderRequest.getOrderHeader().getGCHId() == null)
				throw new TranslatorException(ErrorCode.ESAP_MISSING_REQUIRED_DATA,
						"GCHID is not present in the request BOD");

			dbServiceResponse = orderServiceHelperImpl
					.getEnterpriseInformationFromGchId(voipOrderRequest.getOrderHeader().getGCHId());

			voipOrderRequest = translationUtility.setAsClli(voipOrderRequest);//add broadsoft clli.
			
			voipOrderRequest = voipRequestTransformerImpl.modifyOrderHeader(voipOrderRequest, dbServiceResponse, false,
					productDetails);

			locRows = inventoryUtil.getTblLocationFromLocationId(voipLocation, null, null);

			if (locRows != null && locRows.get("LOCATION_TYPE") != null) {

				if (LocationType.HPBX_ECH.getIndex() == Integer.valueOf(locRows.get("LOCATION_TYPE"))) {
					remoteLocationEnterpriseID = orderServiceHelperImpl.findRemoteLocationEnterpriseId(voipLocation);
					if (remoteLocationEnterpriseID != null) {
						LOG.info("HPBX_ECH - Remote Location Exist");
						throw new TranslatorException(ErrorCode.EBL_EXISTS_FOR_THE_ESL,
								"ESL Can not be Deleted as EBL Exists");
					}
					LOG.info("HPBX_ECH - Remote Location Do not Exist");
				}

				if (LocationType.HPBX_ECH.getIndex() == Integer.valueOf(locRows.get("LOCATION_TYPE"))
						|| LocationType.HPBX_EBL.getIndex() == Integer.valueOf(locRows.get("LOCATION_TYPE"))) {

					locationEntityInv = orderServiceHelperImpl.getEntityDetailsFromInventory(voipLocation,
							LocationEntity.class);

					if (locationEntityInv != null && locationEntityInv.getLocRegion() != null)
						virtualAddrCountry = locationEntityInv.getLocRegion();
					else
						virtualAddrCountry = "US";
					voipOrderRequest.getOrderHeader().setRegion(virtualAddrCountry);

					LOG.info("EslOrderServiceImpl:: virtualAddrCountry - {}", virtualAddrCountry);

					if (locationEntityInv != null && locationEntityInv.getCustomerId() != null) {
						customerId = locationEntityInv.getCustomerId();
						LOG.info("Customer Id : {}", customerId);
						voipOrderRequest.getOrderHeader().setEnterpriseId(customerId);
					}
					sequenceNumber = voipOrderRequest.getSequenceNumber();
					LOG.info("TblSafeOrder  SequenceNo : {}", sequenceNumber);

					// Updating Tbl safe store
					tblSafeStoreObject = tblSafeStoreTransformer.prepareTblSafeStoreData(sequenceNumber);
					voipOrderDao.updateTblSafeStoreTranslationStartTime(tblSafeStoreObject);

					if (LocationType.HPBX_ECH.getIndex() == Integer.valueOf(locRows.get("LOCATION_TYPE"))) {
						// Create Env Order
						tblEnvOrderObject = orderServiceHelperImpl.createEsipEslEnvOrder(voipOrderRequest,
								WorkOrderEnum.Status.WO_RECV_SEGMENT);
					}

					if (LocationType.HPBX_EBL.getIndex() == Integer.valueOf(locRows.get("LOCATION_TYPE"))) {
						// Create Env Order
						tblEnvOrderObject = orderServiceHelperImpl.createEsipEblEnvOrder(voipOrderRequest,
								WorkOrderEnum.Status.WO_RECV_SEGMENT);
					}

					orderServiceHelperImpl.createLocationOrderFromInventoryDetails(voipOrderRequest, tblEnvOrderObject);
					LOG.info("HPBX Disconnect(REL_SUSPEND) :: Location order is placed");

					voipOrderResponse = voipResponseGenerator.prepareSuccessOrderResponse(voipOrderRequest);

					voipOrderDao.createParentChildOrderRelationship(tblEnvOrderObject);
   
					if(tblEnvOrderObject != null && tblEnvOrderObject.getEnvOrderId()!=null) {
						voipOrderDao.updateTblEnvOrderStatus(tblEnvOrderObject.getEnvOrderId(),
								WorkOrderEnum.Status.WO_INIT);
					}

					//Commentting below as PC do not need this milestone
					/*notificationServiceImpl.notifySuccess(voipResponseGenerator.preparePCMilestone(voipOrderRequest,
							PcMilestone.ORDER_ACCEPTANCE.getValue(), StatusCode.ESP_SUCCESS,
							PcResponseType.ORDER.getValue()));*/
				}
			}
		} catch (TranslatorException ex) {
			LOG.error("Exception {} ", ex.getMessage());
			throw new TranslatorException(ex.getErrorCode(), ex.getMessage());
		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new GenericException(GenericException.GENERIC_EXCEPTION, "Exception in the provide input arguments");
		}

		LOG.info("Leaving createHpbxLocSuspendOrder");
		return voipOrderResponse;
	}

	/** HPBX Disconnect
	 * @param voipOrderRequest
	 * @return voipOrderResponse
	 * @throws GenericException
	 * @throws TranslatorException
	 */
	@Override
	public VoipOrderResponse createHpbxLocDeactivateOrder(VOIPOrderRequest voipOrderRequest,
			Map<String, String> productDetails) throws TranslatorException, GenericException {
		LOG.info("Entered createHpbxLocDeactivateOrder");

		VoipOrderResponse voipOrderResponse = null;
		List<TblEnvOrder> suspenedTblEnvOrderObjects = null;
		long sequenceNumber = -1;
		TblSafeStore tblSafeStoreObject = null;
		TblEnvOrder tblEnvOrderObject = null;
		DBServiceResponse dbServiceResponse = null;
		int relSuspendOrderClassify = 33;
		Map<String, String> locRows = null;
		String voipLocation = null;
		String remoteLocationEnterpriseID = null;
		String virtualAddrCountry = null;
		String customerId = null;
		LocationEntity locationEntityInv = null;
		boolean isOtherActiveLocationPresent = true;

		try {
			suspenedTblEnvOrderObjects = orderServiceHelperImpl.getMatchingPrevPassEnvOrder(voipOrderRequest,
					WorkOrderEnum.Status.WO_COMPLETE, relSuspendOrderClassify);

			if (suspenedTblEnvOrderObjects == null || suspenedTblEnvOrderObjects.isEmpty()
					|| suspenedTblEnvOrderObjects.get(0) == null
					|| suspenedTblEnvOrderObjects.get(0).getEnvOrderId() == null)
				throw new TranslatorException(TranslatorException.ErrorCode.VALIDATION_NOT_COMPLETE,
						"Suspend is not completed for Order:" + voipOrderRequest.getOrderHeader().getWorkOrderNumber());

			LOG.info("createEblEsipLocDeactOrder::REL_SUSPEND order is succesfully completed for order - {}",
					voipOrderRequest.getOrderHeader().getWorkOrderNumber());

			if (voipOrderRequest.getOrderHeader().getGCHId() == null)
				throw new TranslatorException(ErrorCode.ESAP_MISSING_REQUIRED_DATA,
						"GCHID is not present in the request BOD");

			voipLocation = voipOrderRequest.getOrderHeader().getVoipLocationId();

			dbServiceResponse = orderServiceHelperImpl
					.getEnterpriseInformationFromGchId(voipOrderRequest.getOrderHeader().getGCHId());

			voipOrderRequest = translationUtility.setAsClli(voipOrderRequest);//add broadsoft clli.
			
			voipOrderRequest = voipRequestTransformerImpl.modifyOrderHeader(voipOrderRequest, dbServiceResponse, false,
					productDetails);

			locRows = inventoryUtil.getTblLocationFromLocationId(voipLocation, null, null);

			if (locRows != null && locRows.get("LOCATION_TYPE") != null) {
				if (LocationType.HPBX_ECH.getIndex() == Integer.valueOf(locRows.get("LOCATION_TYPE"))
						|| LocationType.HPBX_EBL.getIndex() == Integer.valueOf(locRows.get("LOCATION_TYPE"))) {
					locationEntityInv = orderServiceHelperImpl.getEntityDetailsFromInventory(
							voipOrderRequest.getOrderHeader().getVoipLocationId(), LocationEntity.class);

					if (locationEntityInv != null && locationEntityInv.getLocRegion() != null)
						virtualAddrCountry = locationEntityInv.getLocRegion();
					else
						virtualAddrCountry = "US";

					LOG.info("createHpbxLocDeactivateOrder():: virtualAddrCountry - {}", virtualAddrCountry);
					voipOrderRequest.getOrderHeader().setRegion(virtualAddrCountry);

					if (locationEntityInv != null && locationEntityInv.getCustomerId() != null) {
						customerId = locationEntityInv.getCustomerId();
						LOG.info("Customer Id : {}", customerId);
						voipOrderRequest.getOrderHeader().setEnterpriseId(customerId);
					}
					// LocationType = 7 and REL_DEACTIVATE is similar to ESL
					if (LocationType.HPBX_ECH.getIndex() == Integer.valueOf(locRows.get("LOCATION_TYPE"))) {
						remoteLocationEnterpriseID = orderServiceHelperImpl
								.findRemoteLocationEnterpriseId(voipLocation);

						if (remoteLocationEnterpriseID != null) {
							LOG.info("Remote Location Exist");
							throw new TranslatorException(ErrorCode.EBL_EXISTS_FOR_THE_ESL,
									"ESL Can not be Deleted as EBL Exists");
						}
						LOG.info("Remote Location Do not Exist");

						sequenceNumber = voipOrderRequest.getSequenceNumber();
						LOG.info("TblSafeOrder  SequenceNo : {}", sequenceNumber);

						// Update TblSafeStore
						tblSafeStoreObject = tblSafeStoreTransformer.prepareTblSafeStoreData(sequenceNumber);
						voipOrderDao.updateTblSafeStoreTranslationStartTime(tblSafeStoreObject);

						// Create Env Order
						tblEnvOrderObject = orderServiceHelperImpl.createEsipEslEnvOrder(voipOrderRequest,
								WorkOrderEnum.Status.WO_RECV_SEGMENT);

						orderServiceHelperImpl.createLocationOrderFromInventoryDetails(voipOrderRequest,
								tblEnvOrderObject);
						LOG.info("HPBX REL_DEACTIVATE :: Location order is placed");

						isOtherActiveLocationPresent = orderServiceHelperImpl
								.isOtherActiveLocationPresentUnderEnterpriseInBw(
										voipOrderRequest.getOrderHeader().getEnterpriseId(),
										Arrays.asList(voipOrderRequest.getOrderHeader().getVoipLocationId()));

						LOG.info("HPBX REL_DISCONNECT :: isOtherActiveLocationPresent --> {}",
								isOtherActiveLocationPresent);

						if (!isOtherActiveLocationPresent) {
							orderServiceHelperImpl.createEnterpriseOrderFromInventoryDetails(voipOrderRequest,
									tblEnvOrderObject);
						}
					}
					// LocationType = 8 and REL_DEACTIVATE is similar to EBL
					if (LocationType.HPBX_EBL.getIndex() == Integer.valueOf(locRows.get("LOCATION_TYPE"))) {

						sequenceNumber = voipOrderRequest.getSequenceNumber();
						LOG.info("TblSafeOrder  SequenceNo : {}", sequenceNumber);

						// Update TblSafeStore
						tblSafeStoreObject = tblSafeStoreTransformer.prepareTblSafeStoreData(sequenceNumber);
						voipOrderDao.updateTblSafeStoreTranslationStartTime(tblSafeStoreObject);

						// Create Env Order
						tblEnvOrderObject = orderServiceHelperImpl.createEsipEblEnvOrder(voipOrderRequest,
								WorkOrderEnum.Status.WO_RECV_SEGMENT);

						orderServiceHelperImpl.createLocationOrderFromInventoryDetails(voipOrderRequest,
								tblEnvOrderObject);
						LOG.info("HPBX REL_DEACTIVATE :: Location order is placed");

						orderServiceHelperImpl.createTNOrderFromInventoryDetails(voipOrderRequest, tblEnvOrderObject);
						LOG.info("HPBX REL_DEACTIVATE :: TN order is placed");
					}

					voipOrderResponse = voipResponseGenerator.prepareSuccessOrderResponse(voipOrderRequest);

					if(tblEnvOrderObject != null   && tblEnvOrderObject.getEnvOrderId()!=null) {
						voipOrderDao.createParentChildOrderRelationship(tblEnvOrderObject);
					}

					if(tblEnvOrderObject != null) {
						voipOrderDao.updateTblEnvOrderStatus(tblEnvOrderObject.getEnvOrderId(),
								WorkOrderEnum.Status.WO_INIT);
					}

					//Commentting below as PC do not need this milestone
					/*notificationServiceImpl.notifySuccess(voipResponseGenerator.preparePCMilestone(voipOrderRequest,
							PcMilestone.ORDER_ACCEPTANCE.getValue(), StatusCode.ESP_SUCCESS,
							PcResponseType.ORDER.getValue()));*/
					
					//Adding new Milestone VALIDATE_DEACT
					notificationServiceImpl.notifySuccess(voipResponseGenerator.preparePCMilestone(voipOrderRequest,
							PcMilestone.VALIDATE_DEACT.getValue(), StatusCode.ESP_SUCCESS,
							PcResponseType.VALIDATION.getValue()));
					
				}
			}
		} catch (TranslatorException ex) {
			LOG.error("Exception {} ", ex.getMessage());
			throw new TranslatorException(ex.getErrorCode(), ex.getMessage());
		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new GenericException(GenericException.GENERIC_EXCEPTION, "Exception in the provide input arguments");
		}
		LOG.info("Leaving createHpbxLocDeactivateOrder");
		return voipOrderResponse;
	}
}
