package com.vz.esap.translation.order.model.request;

public class VerificationData {

	private String ActionCode;

	private ActionField[] ActionField;

	public String getActionCode() {
		return ActionCode;
	}

	public void setActionCode(String ActionCode) {
		this.ActionCode = ActionCode;
	}

	public ActionField[] getActionField() {
		return ActionField;
	}

	public void setActionField(ActionField[] ActionField) {
		this.ActionField = ActionField;
	}

	public String toString() {
		return "ClassPojo [ActionCode = " + ActionCode + ", ActionField = " + ActionField + "]";
	}
}
