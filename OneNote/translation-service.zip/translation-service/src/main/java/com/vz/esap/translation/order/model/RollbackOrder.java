package com.vz.esap.translation.order.model;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import esap.db.TblOrderServiceDbBean;

public class RollbackOrder extends Order {

	private RollbackReason rollbackReason = null;
	private Order forwardOrder;
	ArrayList<String> skipTasks = new ArrayList<>();
	ArrayList<TblOrderServiceDbBean> prevOrdSvcs = null;

	public static final String[] taskParamsForReverseAction = new String[] { "ALTTN_SUB", "ALT_TN", "AUTHORIZE",
			"DOMAIN", "FMCG_USER", "PTN", "VEC_USER", "VMA", "VM_ACTION" };
	public static final List<String> taskParamList = Arrays.asList(taskParamsForReverseAction);

	public static enum RollbackReason {
		FAILED, ENTITY_DROPPED, TN_PORTING_OFF, AUTO_ROLLBACK, NO_CHANGE;
	}

	public RollbackReason getRollbackReason() {
		return rollbackReason;
	}

	public void setRollbackReason(RollbackReason rollbackReason) {
		this.rollbackReason = rollbackReason;
	}

	public Order getForwardOrder() {
		return forwardOrder;
	}

	public void setForwardOrder(Order forwardOrder) {
		this.forwardOrder = forwardOrder;
	}

	public ArrayList<String> getSkipTasks() {
		return skipTasks;
	}

	public void setSkipTasks(ArrayList<String> skipTasks) {
		this.skipTasks = skipTasks;
	}

	public ArrayList<TblOrderServiceDbBean> getPrevOrdSvcs() {
		return prevOrdSvcs;
	}

	public void setPrevOrdSvcs(ArrayList<TblOrderServiceDbBean> prevOrdSvcs) {
		this.prevOrdSvcs = prevOrdSvcs;
	}

}
