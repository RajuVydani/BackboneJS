package com.vz.esap.translation.order.service.tn;

import java.util.List;

import com.vz.esap.translation.dao.model.TblEnvOrder;
import com.vz.esap.translation.dao.model.TblOrder;
import com.vz.esap.translation.dao.model.TblOrderDetails;
import com.vz.esap.translation.exception.GenericException;
import com.vz.esap.translation.exception.TranslatorException;
import com.vz.esap.translation.order.model.request.VOIPOrderRequest;
import com.vz.esap.translation.order.model.response.VoipOrderResponse;

/**
 * @author baigkh
 *
 */

public interface GroupTnOrderService {
	

	/**
	 * @param batchTNOrderDetails
	 * @param tblOrderBeanValidation
	 * @param tblEnvOrder
	 * @param voipOrderRequest
	 * @param tblOrderDetailsList
	 * @return
	 * @throws TranslatorException
	 * @throws GenericException
	 */
	VoipOrderResponse processReleaseOrder(List<TblOrderDetails> batchTNOrderDetails, TblOrder tblOrderBeanValidation,
			TblEnvOrder tblEnvOrder, VOIPOrderRequest voipOrderRequest, List<TblOrderDetails> tblOrderDetailsList) throws TranslatorException, GenericException;


}
