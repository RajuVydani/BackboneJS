package com.vz.esap.translation.entity;

import java.math.BigDecimal;
import java.util.HashSet;

import com.vz.esap.translation.enums.EsapEnum;
import com.vz.esap.translation.enums.EsapEnum.AuthFeatureType;
import com.vz.esap.translation.enums.EsapEnum.OrderEntity;
import com.vz.esap.translation.enums.EsapEnum.SolutionType;
import com.vz.esap.translation.enums.EsapEnum.TransportProtocol;

import EsapEnumPkg.VzbVoipEnum;
import EsapEnumPkg.VzbVoipEnums.CallingPartyFormatEnum;
import EsapEnumPkg.VzbVoipEnums.DeviceCharIdTypeEnum;
import EsapEnumPkg.VzbVoipEnums.EndPointTypeEnum;
import EsapEnumPkg.VzbVoipEnums.IPVersionEnum;

public class DeviceEntity extends Entity {

	private static final long serialVersionUID = 1L;
	private Long deviceMapId;
	private String deviceNameId;
	private String locationId;
	private String customerId;
	private String departmentId;
	private String bsDeviceId;
	private String deviceName;
	private Integer deviceType;
	private Integer deviceBsType;
	private DeviceCharIdTypeEnum deviceCharId;
	private String transport;
	// private String deviceTypeStr;
	private String deviceTypeId;
	private String codec;
	private String polycomFirmwareVersion;
	private String deviceLoginID;
	private String linePort;
	private String mac;
	private String serialNumber;
	private Integer portsAvailable;
	private String cpeUsername;
	private String cpePassword;
	private String bizLocation;
	private String stationLocation;
	private String equipmentProvidedBy;
	private String proxyCluster;
	private String address;
	private String secAddress;
	private String stripCcInd; // CALLING_PARTY_FORMAT
	private CallingPartyFormatEnum callingPartyFormat;
	private String termCallingInd;
	private Integer attendantRegLine;
	private String blfURL;
	private Boolean brixInd;
//	private MultilineAppearance multilineAppearance;
	//private SharedCallAppearance sca;
	private EndPointTypeEnum endPointType;
	private AuthFeatureType authFeatureType;
	private String sTn;
    private String STNLinePort;
	private String gwyFqdn;
	private String sbcEnabledFlag;

	private String sipDomain;
	private String parentDomain;
	private String gwyHunt;
//    private ArrayList<GatewayDeviceSBCDetail> gatewaySbcs;
    private long internalAdmin;
    private String provisionCategory;   
    private String subId;

    /*APAC Attributes*/
    private String networkFeatures;
    private String hubLocationId; /*Only for IASA Order's.*/
    /*End - APAC*/
    
    
    private Integer aggregateOffnetCcl;
    private Boolean sigTierOverrideFlag;
    private BigDecimal signalingRateLookupValue;
    
    private IPVersionEnum ipVersion;
	private String cpeUEid;
    private Long pqInstanceId;
	private short tsoMigLock;
//	private IPSecTunnel ipSecTunnel;
	private String custSigConstraint;
	private String updateComment; 
	private String zeroSupp;
	private String featureType;
	private String billFlag;
	private EsapEnum.SignalingDirection sigDir;
	private String deviceLevel;
	private String trunkId;
	private String protocol;
	private String accessDevice;
	private String bwDeviceId;
	private String description;
	
	//xoo
	private SolutionType solutionType;
	private String ipAddress;
	private TransportProtocol transportProtocol;
	private String port;
	private String region;
	
	private GroupType trunkType;
	private long envOrderId;
	
	private long interalOrderId;
	private DeviceEntity deviceEntity;
	private boolean isNewDevice; 
	private String cpeIpAddress;
	private String asClli;
	/*private String updateComment;
	private String custSigConstraint;
	private String updateComment;
	private String custSigConstraint;
	private String updateComment;*/

	/*public String toString() {
		StringBuilder buffer = new StringBuilder();
		buffer.append("<Device>").append("\n");
		OrderUtil.appendXmlNode(buffer, "deviceMapId", deviceMapId);
		OrderUtil.appendXmlNode(buffer, "deviceNameId", deviceNameId);
		OrderUtil.appendXmlNode(buffer, "bsDeviceId", bsDeviceId);
		OrderUtil.appendXmlNode(buffer, "departmentId", departmentId);
		OrderUtil.appendXmlNode(buffer, "locationId", locationId);
		OrderUtil.appendXmlNode(buffer, "customerId", customerId);
		OrderUtil.appendXmlNode(buffer, "deviceName", deviceName);
		OrderUtil.appendXmlNode(buffer, "deviceType", deviceType);
		OrderUtil.appendXmlNode(buffer, "deviceCharId", deviceCharId);
		OrderUtil.appendXmlNode(buffer, "transport", transport);
		OrderUtil.appendXmlNode(buffer, "deviceTypeId", deviceTypeId);
		OrderUtil.appendXmlNode(buffer, "codec", codec);
		OrderUtil.appendXmlNode(buffer, "polycomFirmwareVersion",
				polycomFirmwareVersion);
		OrderUtil.appendXmlNode(buffer, "deviceLoginID", deviceLoginID);
		OrderUtil.appendXmlNode(buffer, "linePort", linePort);
		OrderUtil.appendXmlNode(buffer, "mac", mac);
        OrderUtil.appendXmlNode(buffer, "sTn", sTn);
		OrderUtil.appendXmlNode(buffer, "serialNumber", serialNumber);
		OrderUtil.appendXmlNode(buffer, "portsAvailable", portsAvailable);
		OrderUtil.appendXmlNode(buffer, "cpeUsername", cpeUsername);
		OrderUtil.appendXmlNode(buffer, "cpePassword", cpePassword);
		OrderUtil.appendXmlNode(buffer, "bizLocation", bizLocation);
		OrderUtil.appendXmlNode(buffer, "sipDomain", sipDomain);
		OrderUtil.appendXmlNode(buffer, "parentDomain", parentDomain);
		OrderUtil.appendXmlNode(buffer, "stationLocation", stationLocation);
		OrderUtil.appendXmlNode(buffer, "equipmentProvidedBy",
				equipmentProvidedBy);
		OrderUtil.appendXmlNode(buffer, "address", address);
		OrderUtil.appendXmlNode(buffer, "secAddress", secAddress);
		OrderUtil.appendXmlNode(buffer, "CustSigConstraint", custSigConstraint);
		OrderUtil.appendXmlNode(buffer, "UpdateComment", updateComment); 
		OrderUtil.appendXmlNode(buffer, "proxyCluster", proxyCluster);
		OrderUtil.appendXmlNode(buffer, "stripCcInd", stripCcInd);
		OrderUtil.appendXmlNode(buffer, "termCallingInd", termCallingInd);
		OrderUtil.appendXmlNode(buffer, "attendantRegLine", attendantRegLine);
		OrderUtil.appendXmlNode(buffer, "blfURL", blfURL);
		if (multilineAppearance != null) {
			buffer.append(multilineAppearance);
		}
		OrderUtil.appendXmlNode(buffer, "sbcEnabledFlag", sbcEnabledFlag);
		OrderUtil.appendXmlNode(buffer, "networkFeatures", networkFeatures);
		if (sca != null) {
			buffer.append(sca);
		}
		OrderUtil.appendXmlNode(buffer, "brixInd", brixInd);
		OrderUtil.appendXmlNode(buffer, "subId", subId);
		OrderUtil.appendXmlNode(buffer, "STNLinePort", STNLinePort);
		OrderUtil.appendXmlNode(buffer, "hubLocationId", hubLocationId);

		
		OrderUtil.appendXmlNode(buffer, "gwyFqdn", gwyFqdn);
		OrderUtil.appendXmlNode(buffer, "gwyHunt", gwyHunt);

		
		OrderUtil.appendXmlNode(buffer, "aggregateOffnetCcl", aggregateOffnetCcl);
		OrderUtil.appendXmlNode(buffer, "sigTierOverrideFlag", sigTierOverrideFlag);
		OrderUtil.appendXmlNode(buffer, "signalingRateLookupValue", signalingRateLookupValue);
		OrderUtil.appendXmlNode(buffer, "ipVersion", ipVersion);
		OrderUtil.appendXmlNode(buffer, "cpeUEid", cpeUEid);
		OrderUtil.appendXmlNode(buffer, "instanceId", pqInstanceId);
		
		if(gatewaySbcs != null){
			for(GatewayDeviceSBCDetail gtSbc : gatewaySbcs)
				OrderUtil.appendXmlNode(buffer, "GatewaySbc", gtSbc);
		}
		if (ipSecTunnel != null) {
			OrderUtil.appendXmlNode(buffer, "IpSecTunnel", ipSecTunnel);
		}

		buffer.append("</Device>").append("\n");
		return buffer.toString();
	}*/

	public DeviceEntity getDeviceEntity() {
		return deviceEntity;
	}

	public void setDeviceEntity(DeviceEntity deviceEntity) {
		this.deviceEntity = deviceEntity;
	}

	public GroupType getTrunkType() {
		return trunkType;
	}

	public void setTrunkType(GroupType trunkType) {
		this.trunkType = trunkType;
	}

	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	
	public String getCpeIpAddress() {
		return cpeIpAddress;
	}

	public void setCpeIpAddress(String cpeIpAddress) {
		this.cpeIpAddress = cpeIpAddress;
	}

	public DeviceEntity() {
	}

	public DeviceEntity(DeviceEntity device) {

		deviceMapId = device.getDeviceMapId();
		deviceNameId = device.getDeviceNameId();
		bsDeviceId = device.getBsDeviceId();
		locationId = device.getLocationId();
		customerId = device.getCustomerId();
		departmentId = device.getDepartmentId();
		deviceName = device.getDeviceName();
		deviceType = device.getDeviceType();
		deviceTypeId = device.getDeviceId();
		deviceCharId = device.getDeviceCharId();
		transport = device.getTransport();

		codec = device.getCodec();
		polycomFirmwareVersion = device.getPolycomFirmwareVersion();
		deviceLoginID = device.getDeviceLoginID();
		linePort = device.getLinePort();
		mac = device.getMac();
		serialNumber = device.getSerialNumber();
		portsAvailable = device.getPortsAvailable();
		cpeUsername = device.getCpeUsername();
		cpePassword = device.getCpePassword();
		bizLocation = device.getBizLocation();
		stationLocation = device.getStationLocation();
		equipmentProvidedBy = device.getEquipmentProvidedBy();
		address = device.getAddress();
		cpeIpAddress = device.getCpeIpAddress();
		secAddress = device.getSecAddress();
		proxyCluster = device.getProxyCluster();
		stripCcInd = device.getStripCcInd();
        sTn = device.getSTN();
		termCallingInd = device.getTermCallingInd();
		attendantRegLine = device.getAttendantRegLine();
		blfURL = device.getBlfURL();
		sbcEnabledFlag = device.getSbcEnabledFlag();
		/*if (device.getMultilineAppearance() != null)
			multilineAppearance = new MultilineAppearance(device
					.getMultilineAppearance());
		if (device.getSca() != null)
			sca = new SharedCallAppearance(device.getSca());*/
		brixInd = device.getBrixInd();
		subId = device.getSubId();
        networkFeatures = device.getNetworkFeatures();        
		STNLinePort = device.getSTNLinePort();
		hubLocationId = device.getHubLocationId();
		internalAdmin = device.getInternalAdmin();
		
		gwyFqdn = device.getGwyFqdn();
		gwyHunt = device.getGwyHunt(); 

		aggregateOffnetCcl = device.getAggregateOffnetCcl();
		sigTierOverrideFlag = device.getSigTierOverrideFlag();
		signalingRateLookupValue = device.getSignalingRateLookupValue();
		
		
		/*if(device.getGatewaySbcs() != null)
			gatewaySbcs = new ArrayList<GatewayDeviceSBCDetail>(device.getGatewaySbcs());*/
		sipDomain = device.getSipDomain();
		parentDomain = device.getParentDomain();
		ipVersion = device.getIpVersion();
		cpeUEid = device.getCPEUIId();
		pqInstanceId = device.getPqInstanceId();
		custSigConstraint = device.getCustSigConstraint();	
		updateComment = device.getUpdateComment();
	}

	
	public long getInternalAdmin() {
		return internalAdmin;
	}

	public void setInternalAdmin(long internalAdmin) {
		this.internalAdmin = internalAdmin;
	}

	public Long getDeviceSeqId() {
		return deviceMapId;
	}

	public void setDeviceSeqId(Long deviceMapId) {
		this.deviceMapId = deviceMapId;
	}

	public Long getDeviceMapId() {
		return deviceMapId;
	}

	public void setDeviceMapId(Long deviceMapId) {
		this.deviceMapId = deviceMapId;
	}

	public String getLocationId() {
		return locationId;
	}

	public void setLocationId(String locationId) {
		this.locationId = locationId;
	}
	
	public String getSubId() {
		return subId;
	}

	public void setsubId(String subId) {
		this.subId = subId;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getDepartmentId() {
		return departmentId;
	}

	public void setDepartmentId(String departmentId) {
		this.departmentId = departmentId;
	}

	public String getDeviceName() {
		return deviceName;
	}

	public void setDeviceName(String deviceName) {
		this.deviceName = deviceName;
	}

	public Integer getDeviceType() {
		return deviceType;
	}

	public void setDeviceType(Integer deviceType) {
		this.deviceType = deviceType;
	}

	public void setDeviceCharId(DeviceCharIdTypeEnum deviceCharId) {
		this.deviceCharId = deviceCharId;
	}

	public DeviceCharIdTypeEnum getDeviceCharId() {
		return deviceCharId;
	}

	public void setTransport(String transport) {
		this.transport = transport;
	}

	public String getTransport() {
		return transport;
	}

	public Boolean isSharedGateway() {
		if (deviceType != null && deviceType == VzbVoipEnum.DeviceType.CPE_ENTPRISE_GTWY_SHARED)
			return true;
		else
			return false;
	}
	
	public String getDeviceId() {
		return deviceTypeId;
	}

	public void setDeviceId(String deviceId) {
		this.deviceTypeId = deviceId;
	}

	public String getCodec() {
		return codec;
	}

	public void setCodec(String codec) {
		this.codec = codec;
	}

	public String getPolycomFirmwareVersion() {
		return polycomFirmwareVersion;
	}

	public void setPolycomFirmwareVersion(String polycomFirmwareVersion) {
		this.polycomFirmwareVersion = polycomFirmwareVersion;
	}

	public String getDeviceLoginID() {
		return deviceLoginID;
	}

	public void setDeviceLoginID(String deviceLoginID) {
		this.deviceLoginID = deviceLoginID;
	}

	public String getLinePort() {
		return linePort;
	}

	public void setLinePort(String linePort) {
		this.linePort = linePort;
	}

	public String getMac() {
		return mac;
	}

	public void setMac(String mac) {
		this.mac = mac;
	}

	public String getSerialNumber() {
		return serialNumber;
	}

	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}

	public Integer getPortsAvailable() {
		return portsAvailable;
	}

	public void setPortsAvailable(Integer portsAvailable) {
		this.portsAvailable = portsAvailable;
	}

	public String getBizLocation() {
		return bizLocation;
	}

	public void setBizLocation(String bizLocation) {
		this.bizLocation = bizLocation;
	}

	public String getStationLocation() {
		return stationLocation;
	}

	public void setStationLocation(String stationLocation) {
		this.stationLocation = stationLocation;
	}

	public String getEquipmentProvidedBy() {
		return equipmentProvidedBy;
	}

	public void setEquipmentProvidedBy(String equipmentProvidedBy) {
		this.equipmentProvidedBy = equipmentProvidedBy;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getStripCcInd() {
		return stripCcInd;
	}

	public void setStripCcInd(String stripCcInd) {
		this.stripCcInd = stripCcInd;
	}

        public String getSTN() {
		return sTn;
	}

	public void setSTN(String sTn) {
		
		if(sTn != null){
			sTn = sTn.trim();
		}
		this.sTn = sTn;
	}

	public String getTermCallingInd() {
		return termCallingInd;
	}

	public void setTermCallingInd(String termCallingInd) {
		this.termCallingInd = termCallingInd;
	}

	public String getCpeUsername() {
		return cpeUsername;
	}

	public void setCpeUsername(String cpeUsername) {
		this.cpeUsername = cpeUsername;
	}

	public String getCpePassword() {
		return cpePassword;
	}

	public void setCpePassword(String cpePassword) {
		this.cpePassword = cpePassword;
	}

	public Integer getAttendantRegLine() {
		return attendantRegLine;
	}

	public void setAttendantRegLine(Integer attendantRegLine) {
		this.attendantRegLine = attendantRegLine;
	}

	public String getBlfURL() {
		return blfURL;
	}

	public void setBlfURL(String blfURL) {
		this.blfURL = blfURL;
	}

	/*public MultilineAppearance getMultilineAppearance() {
		return multilineAppearance;
	}

	public void setMultilineAppearance(MultilineAppearance multilineAppearance) {
		this.multilineAppearance = multilineAppearance;
	}
*/
	public String getSecAddress() {
		return secAddress;
	}

	public void setSecAddress(String secAddress) {
		this.secAddress = secAddress;
	}

	/**
	 * @return the sbcEnabledFlag
	 */
	public String getSbcEnabledFlag() {
		return this.sbcEnabledFlag;
	}

	/**
	 * @param sbcEnabledFlag
	 *            the sbcEnabledFlag to set
	 */
	public void setSbcEnabledFlag(String sbcEnabledFlag) {
		this.sbcEnabledFlag = sbcEnabledFlag;
	}


	public String getSTNLinePort() {
		return STNLinePort;
	}

	 public void setSTNLinePort(String STNLinePort) {
		this.STNLinePort = STNLinePort;
	 }

	/*public void copyCommonInfo(Device device) {
		
		// Copy everything except Device user specific info like line port etc
		
		if (null != device) {
			deviceMapId = device.getDeviceMapId();
			bsDeviceId = device.getBsDeviceId();
			locationId = device.getLocationId();
			customerId = device.getCustomerId();
			departmentId = device.getDepartmentId();
			deviceName = device.getDeviceName();
			deviceNameId = device.getDeviceNameId();
			deviceType = device.getDeviceType();
			deviceTypeId = device.getDeviceId();
			codec = device.getCodec();
			deviceCharId = device.getDeviceCharId();
			transport = device.getTransport();
			polycomFirmwareVersion = device.getPolycomFirmwareVersion();
			deviceLoginID = device.getDeviceLoginID();
			mac = device.getMac();
			serialNumber = device.getSerialNumber();
			portsAvailable = device.getPortsAvailable();
			bizLocation = device.getBizLocation();
			stationLocation = device.getStationLocation();
			equipmentProvidedBy = device.getEquipmentProvidedBy();
			address = device.getAddress();
			secAddress = device.getSecAddress();
			stripCcInd = device.getStripCcInd();
            sTn = device.getSTN();
			termCallingInd = device.getTermCallingInd();
			attendantRegLine = device.getAttendantRegLine();
			blfURL = device.getBlfURL();
			sbcEnabledFlag = device.getSbcEnabledFlag();
			brixInd = device.getBrixInd();
			subId = device.getSubId();
			STNLinePort = device.getSTNLinePort();
			
			gwyFqdn = device.getGwyFqdn();
			gwyHunt = device.getGwyHunt(); 

			aggregateOffnetCcl = device.getAggregateOffnetCcl();
			sigTierOverrideFlag = device.getSigTierOverrideFlag();
			signalingRateLookupValue = device.getSignalingRateLookupValue();
			ipVersion = device.getIpVersion();
			cpeUEid = device.getCPEUIId();
			pqInstanceId = device.getPqInstanceId();
			
			if(getGatewaySbcs() == null && device.getGatewaySbcs() != null){
				for(GatewayDeviceSBCDetail gatewaySbc : device.getGatewaySbcs())
					addToGatewaySbcs(new GatewayDeviceSBCDetail(gatewaySbc));
			}

			
			
		} else {
			LogUtil.log("Device Object is NULL");
		}
	}*/

	public String getDeviceTypeStr() {
		if (deviceType == null)
			return null;
		else
			return VzbVoipEnum.DeviceType.acronym(deviceType);
	}

	/*public SharedCallAppearance getSca() {
		return sca;
	}

	public void setSca(SharedCallAppearance sca) {
		this.sca = sca;
		if(null != sca && null != sca.getLabel() && !sca.getLabel().isEmpty()) {
			this.setEndPointType(EndPointTypeEnum.SCA);
		}
		else{
			this.setEndPointType(EndPointTypeEnum.PRIMARY);
		}
	}*/
	
	public void setEndPointType(EndPointTypeEnum endPointType){
		this.endPointType = endPointType;
	}

	public EndPointTypeEnum getEndPointType(){
		return this.endPointType;
	}
	
	public int getEntityType() {
		return OrderEntity.DEVICE.getIndex();
	}

	public String getEntityId() {
		if (deviceMapId == null)
			return null;
		else
			return deviceMapId.toString();
	}

	public String getEntityName() {
		return deviceName;
	}

	public HashSet<ParentEntity> getParentList() {
		if(customerId != null)
			addParentToList(new ParentEntity(VzbVoipEnum.OrderEntity.ENTERPRISE, null, customerId));
		if(locationId != null)
			addParentToList(new ParentEntity(VzbVoipEnum.OrderEntity.LOCATION, null, locationId));
		if(deviceTypeId != null)
			addParentToList(new ParentEntity(VzbVoipEnum.OrderEntity.DEVICE_TYPE, null, deviceTypeId));
		/*if(gatewaySbcs != null){
			for(GatewayDeviceSBCDetail gtwySbc : gatewaySbcs){
				if(gtwySbc.getSbcCLLI() != null && locationId != null){
					addParentToList(new ParentEntity(VzbVoipEnum.OrderEntity.SBC, gtwySbc.getSbcCLLI(), locationId));
				}
			}
		}*/

		return super.getParentList();
	}

	public Boolean getBrixInd() {
		return brixInd;
	}

	public String getBrixIndStr() {
		if (brixInd == null)
			return null;
		else
			return brixInd ? "Y" : "N";
	}

	public void setBrixInd(Boolean brixInd) {
		this.brixInd = brixInd;
	}

/*	public boolean isSoftDevice() {
		return (getSca() != null && "Xten Soft Device".equals(getSca()
				.getLabel()));
	}

	public boolean isFmcgDevice() {
		return (getSca() != null && "Fmcg Device".equals(getSca().getLabel()));
	}
*/
	public void setGwyFqdn(String gwyFqdn) {
		this.gwyFqdn = gwyFqdn;
	}

	public String getGwyFqdn() {
		return gwyFqdn;
	}

	public String getSipDomain() {
		return sipDomain;
	}

	public void setSipDomain(String sipDomain) {
		this.sipDomain = sipDomain;
	}

	public String getParentDomain() {
		return parentDomain;
	}

	public void setParentDomain(String parentDomain) {
		this.parentDomain = parentDomain;
	}

	public CallingPartyFormatEnum getCallingPartyFormat() {
		return callingPartyFormat;
	}

	public void setCallingPartyFormat(CallingPartyFormatEnum callingPartyFormat) {
		this.callingPartyFormat = callingPartyFormat;
	}

	public String getGwyHunt() {
		return gwyHunt;
	}

	public void setGwyHunt(String gwyHunt) {
		this.gwyHunt = gwyHunt;
	}

	public String getBsDeviceId() {
		return bsDeviceId;
	}

	public void setBsDeviceId(String bsDeviceId) {
		this.bsDeviceId = bsDeviceId;
	}

	public String getNetworkFeatures() {
		return networkFeatures;
	}

	public void setNetworkFeatures(String networkFeatures) {
		this.networkFeatures = networkFeatures;
	}

	public String getHubLocationId() {
		return hubLocationId;
	}

	public void setHubLocationId(String hubLocationId) {
		this.hubLocationId = hubLocationId;
	}

	public String getDeviceNameId() {
		return deviceNameId;
	}

	public void setDeviceNameId(String deviceNameId) {
		this.deviceNameId = deviceNameId;
	}

	public String getDeviceTypeId() {
		return deviceTypeId;
	}

	public void setDeviceTypeId(String deviceTypeId) {
		this.deviceTypeId = deviceTypeId;
	}

/*	public ArrayList<GatewayDeviceSBCDetail> getGatewaySbcs() {
		return gatewaySbcs;
	}

	public void setGatewaySbcs(ArrayList<GatewayDeviceSBCDetail> gatewaySbcs) {
		this.gatewaySbcs = gatewaySbcs;
	}

	public void addToGatewaySbcs(GatewayDeviceSBCDetail gatewaySbc) {
		if(gatewaySbcs == null)
			gatewaySbcs = new ArrayList<GatewayDeviceSBCDetail>();
		
		this.gatewaySbcs.add(gatewaySbc);
	}*/

	public void setSubId(String subId) {
		this.subId = subId;
	}
	
	/*public GatewayDeviceSBCDetail getGatwaySbc(int index){
		GatewayDeviceSBCDetail retGtSbc = null;
		if(gatewaySbcs != null){
			for(GatewayDeviceSBCDetail gtSbc : gatewaySbcs){
				if(gtSbc.getSbcIndex() != null && gtSbc.getSbcIndex() == index){
					retGtSbc = gtSbc;
					break;
				}
			}
		}
		return retGtSbc;
	}*/

	public void setProxyCluster(String proxyCluster) {
		this.proxyCluster = proxyCluster;
	}

	public String getProxyCluster() {
		return proxyCluster;
	}

	public Integer getAggregateOffnetCcl() {
		return aggregateOffnetCcl;
	}

	public void setAggregateOffnetCcl(Integer aggregateOffnetCcl) {
		this.aggregateOffnetCcl = aggregateOffnetCcl;
	}

	public Boolean getSigTierOverrideFlag() {
		return sigTierOverrideFlag;
	}

	public void setSigTierOverrideFlag(Boolean sigTierOverrideFlag) {
		this.sigTierOverrideFlag = sigTierOverrideFlag;
	}

	public BigDecimal getSignalingRateLookupValue() {
		return signalingRateLookupValue;
	}

	public void setSignalingRateLookupValue(BigDecimal signalingRateLookupValue) {
		this.signalingRateLookupValue = signalingRateLookupValue;
	}
	/*public void removeGtwSbc(GatewayDeviceSBCDetail gatewaySbc) {
		LogUtil.log("Enter Device removeGtwSbc() ");
		ArrayList<GatewayDeviceSBCDetail> gtwSbcs = getGatewaySbcs();
		LogUtil.log("Enter Device removeGtwSbc() size:"+gtwSbcs.size());
		if (gtwSbcs != null && gtwSbcs.size() > 0) {
			
			Iterator<GatewayDeviceSBCDetail> gtwSbcItr = gtwSbcs.iterator();
			while(gtwSbcItr.hasNext()){
				GatewayDeviceSBCDetail sbcDtl = (GatewayDeviceSBCDetail)gtwSbcItr.next();
				if (sbcDtl.getSbcCLLI().equals(gatewaySbc.getSbcCLLI())) {
					LogUtil.log("Enter Device removeGtwSbc() GatewayDeviceSBCDetail clli equals to gatewaySbc.getSbcCLLI():");
					gtwSbcItr.remove();
					break;
				}
			}
			
		}
	}
*/
	public IPVersionEnum getIpVersion() {
		return ipVersion;
	}

	public void setIpVersion(IPVersionEnum ipVersion) {
		this.ipVersion = ipVersion;
	}

	public void setCPEUEId(String cpeUEId) {
		this.cpeUEid = cpeUEId;
	}
	
	public String getCPEUIId() {
		return this.cpeUEid;
	}

	public Long getPqInstanceId() {
		return pqInstanceId;
	}

	public void setPqInstanceId(Long instanceId) {
		this.pqInstanceId = instanceId;
	}
	
	/*
	 * This method is to copy the newly received device changes only on to the old device.
	 * 
	 */
	public void copyDelta(DeviceEntity device){
		
		if(device.getDeviceMapId() != null) deviceMapId = device.getDeviceMapId();
		if(device.getDeviceNameId() != null) deviceNameId = device.getDeviceNameId();
		if(device.getBsDeviceId() != null) bsDeviceId = device.getBsDeviceId();
		if(device.getLocationId() != null) locationId = device.getLocationId();
		if(device.getCustomerId() != null) customerId = device.getCustomerId();
		if(device.getDepartmentId() != null) departmentId = device.getDepartmentId();
		if(device.getDeviceName() != null) deviceName = device.getDeviceName();
		if(device.getDeviceType() != null) deviceType = device.getDeviceType();
		if(device.getDeviceId() != null) deviceTypeId = device.getDeviceId();
		if(device.getDeviceCharId() != null) deviceCharId = device.getDeviceCharId();
		if(device.getTransport() != null) transport = device.getTransport();
		if(device.getCodec() != null) codec = device.getCodec();
		if(device.getPolycomFirmwareVersion() != null) polycomFirmwareVersion = device.getPolycomFirmwareVersion();
		if(device.getDeviceLoginID() != null) deviceLoginID = device.getDeviceLoginID();
		if(device.getLinePort() != null) linePort = device.getLinePort();
		if(device.getMac() != null) mac = device.getMac();
		if(device.getSerialNumber() != null) serialNumber = device.getSerialNumber();
		if(device.getPortsAvailable() != null) portsAvailable = device.getPortsAvailable();
		if(device.getCpeUsername() != null) cpeUsername = device.getCpeUsername();
		if(device.getCpePassword() != null) cpePassword = device.getCpePassword();
		if(device.getBizLocation() != null) bizLocation = device.getBizLocation();
		if(device.getStationLocation() != null) stationLocation = device.getStationLocation();
		if(device.getEquipmentProvidedBy() != null) equipmentProvidedBy = device.getEquipmentProvidedBy();
		if(device.getAddress() != null) address = device.getAddress();
		if(device.getCpeIpAddress() != null) address = device.getCpeIpAddress();
		if(device.getSecAddress() != null) secAddress = device.getSecAddress();
		if(device.getProxyCluster() != null) proxyCluster = device.getProxyCluster();
		if(device.getStripCcInd() != null) stripCcInd = device.getStripCcInd();
		if(device.getSTN() != null) sTn = device.getSTN();
		if(device.getTermCallingInd() != null) termCallingInd = device.getTermCallingInd();
		if(device.getAttendantRegLine() != null) attendantRegLine = device.getAttendantRegLine();
		if(device.getBlfURL() != null) blfURL = device.getBlfURL();
		if(device.getSbcEnabledFlag() != null) sbcEnabledFlag = device.getSbcEnabledFlag();
		// Do not copy sub structures which will not be received on the order.
		/*if (device.getMultilineAppearance() != null)
			multilineAppearance = new MultilineAppearance(
					device.getMultilineAppearance());
		if (device.getSca() != null)
			sca = new SharedCallAppearance(device.getSca());*/
		if(device.getBrixInd() != null) brixInd = device.getBrixInd();
		if(device.getSubId() != null) subId = device.getSubId();
		if(device.getNetworkFeatures() != null) networkFeatures = device.getNetworkFeatures();
		if(device.getSTNLinePort() != null) STNLinePort = device.getSTNLinePort();
		if(device.getHubLocationId() != null) hubLocationId = device.getHubLocationId();
		if(device.getInternalAdmin() != internalAdmin) internalAdmin = device.getInternalAdmin();
		if(device.getGwyFqdn() != null) gwyFqdn = device.getGwyFqdn();
		if(device.getGwyHunt() != null) gwyHunt = device.getGwyHunt();
		if(device.getAggregateOffnetCcl() != null) aggregateOffnetCcl = device.getAggregateOffnetCcl();
		if(device.getSigTierOverrideFlag() != null) sigTierOverrideFlag = device.getSigTierOverrideFlag();
		if(device.getSignalingRateLookupValue() != null) signalingRateLookupValue = device.getSignalingRateLookupValue();

		// Do not copy sub structures which will not be received on the order.
		/*if (device.getGatewaySbcs() != null)
			gatewaySbcs = new ArrayList<GatewayDeviceSBCDetail>(
					device.getGatewaySbcs());*/
		if(device.getSipDomain() != null) sipDomain = device.getSipDomain();
		if(device.getParentDomain() != null) parentDomain = device.getParentDomain();
		if(device.getIpVersion() != null) ipVersion = device.getIpVersion();
		if(device.getCPEUIId() != null) cpeUEid = device.getCPEUIId();
		if(device.getPqInstanceId() != null) pqInstanceId = device.getPqInstanceId();
		if(device.getCustSigConstraint() != null) custSigConstraint = device.getCustSigConstraint();
		if(device.getUpdateComment() != null) updateComment = device.getUpdateComment(); 
		
	}

	public void setTsoMigLock(short tsoMigLock) {
		this.tsoMigLock = tsoMigLock;
	}

	public short getTsoMigLock() {
		return this.tsoMigLock;
	}

	/*public void setIpSecTunnelInfo(IPSecTunnel ipSecTunnel) {
		this.ipSecTunnel = ipSecTunnel;
	}
	
	public IPSecTunnel getIpSecTunnelInfo() {
		return this.ipSecTunnel;
    }*/

	public String getCustSigConstraint() {
		return custSigConstraint;	
	}

	public void setCustSigConstraint(String custSigConstraint) {
		this.custSigConstraint = custSigConstraint;
	}

	public String getUpdateComment() {
		return updateComment;
	}

	public void setUpdateComment(String updateComment) {
		this.updateComment = updateComment;
	}

	public String getsTn() {
		return sTn;
	}

	public void setsTn(String sTn) {
		this.sTn = sTn;
	}

	public String getCpeUEid() {
		return cpeUEid;
	}

	public void setCpeUEid(String cpeUEid) {
		this.cpeUEid = cpeUEid;
	}

	public String getFeatureType() {
		return featureType;
	}

	public void setFeatureType(String featureType) {
		this.featureType = featureType;
	}

	public String getZeroSupp() {
		return zeroSupp;
	}

	public void setZeroSupp(String zeroSupp) {
		this.zeroSupp = zeroSupp;
	}

	public String getBillFlag() {
		return billFlag;
	}

	public void setBillFlag(String billFlag) {
		this.billFlag = billFlag;
	}

	public EsapEnum.SignalingDirection getSigDir() {
		return sigDir;
	}

	public void setSigDir(EsapEnum.SignalingDirection sigDir) {
		this.sigDir = sigDir;
	}

	public String getDeviceLevel() {
		return deviceLevel;
	}

	public void setDeviceLevel(String deviceLevel) {
		this.deviceLevel = deviceLevel;
	}

	public String getTrunkId() {
		return trunkId;
	}

	public void setTrunkId(String trunkId) {
		this.trunkId = trunkId;
	}

	public String getProtocol() {
		return protocol;
	}

	public void setProtocol(String protocol) {
		this.protocol = protocol;
	}

	public String getAccessDevice() {
		return accessDevice;
	}

	public void setAccessDevice(String accessDevice) {
		this.accessDevice = accessDevice;
	}

	public String getBwDeviceId() {
		return bwDeviceId;
	}

	public void setBwDeviceId(String bwDeviceId) {
		this.bwDeviceId = bwDeviceId;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public SolutionType getSolutionType() {
		return solutionType;
	}

	public void setSolutionType(SolutionType solutionType) {
		this.solutionType = solutionType;
	}

	public String getIpAddress() {
		return ipAddress;
	}

	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}

	
	public void setTransportProtocol(TransportProtocol transportProtocol) {
		this.transportProtocol = transportProtocol;
	}

	public TransportProtocol getTransportProtocol() {
		return transportProtocol;
	}

	public String getPort() {
		return port;
	}

	public void setPort(String port) {
		this.port = port;
	}

	public long getEnvOrderId() {
		return envOrderId;
	}

	public void setEnvOrderId(long envOrderId) {
		this.envOrderId = envOrderId;
	}

	public long getInteralOrderId() {
		return interalOrderId;
	}

	public void setInteralOrderId(long interalOrderId) {
		this.interalOrderId = interalOrderId;
	}

	public String getProvisionCategory() {
		return provisionCategory;
	}

	public void setProvisionCategory(String provisionCategory) {
		this.provisionCategory = provisionCategory;
	}

	public Integer getDeviceBsType() {
		return deviceBsType;
	}

	public void setDeviceBsType(Integer deviceBsType) {
		this.deviceBsType = deviceBsType;
	}

	public AuthFeatureType getAuthFeatureType() {
		return authFeatureType;
	}

	public void setAuthFeatureType(AuthFeatureType authFeatureType) {
		this.authFeatureType = authFeatureType;
	}

	@Override
	public String toString() {
		return "DeviceEntity [deviceMapId=" + deviceMapId + ", deviceNameId=" + deviceNameId + ", locationId="
				+ locationId + ", customerId=" + customerId + ", departmentId=" + departmentId + ", bsDeviceId="
				+ bsDeviceId + ", deviceName=" + deviceName + ", deviceType=" + deviceType + ", deviceBsType="
				+ deviceBsType + ", deviceCharId=" + deviceCharId + ", transport=" + transport + ", deviceTypeId="
				+ deviceTypeId + ", codec=" + codec + ", polycomFirmwareVersion=" + polycomFirmwareVersion
				+ ", deviceLoginID=" + deviceLoginID + ", linePort=" + linePort + ", mac=" + mac + ", serialNumber="
				+ serialNumber + ", portsAvailable=" + portsAvailable + ", cpeUsername=" + cpeUsername
				+ ", cpePassword=" + cpePassword + ", bizLocation=" + bizLocation + ", stationLocation="
				+ stationLocation + ", equipmentProvidedBy=" + equipmentProvidedBy + ", proxyCluster=" + proxyCluster
				+ ", address=" + address + ", secAddress=" + secAddress + ", stripCcInd=" + stripCcInd
				+ ", callingPartyFormat=" + callingPartyFormat + ", termCallingInd=" + termCallingInd
				+ ", attendantRegLine=" + attendantRegLine + ", blfURL=" + blfURL + ", brixInd=" + brixInd
				+ ", endPointType=" + endPointType + ", authFeatureType=" + authFeatureType + ", sTn=" + sTn
				+ ", STNLinePort=" + STNLinePort + ", gwyFqdn=" + gwyFqdn + ", sbcEnabledFlag=" + sbcEnabledFlag
				+ ", sipDomain=" + sipDomain + ", parentDomain=" + parentDomain + ", gwyHunt=" + gwyHunt
				+ ", internalAdmin=" + internalAdmin + ", provisionCategory=" + provisionCategory + ", subId=" + subId
				+ ", networkFeatures=" + networkFeatures + ", hubLocationId=" + hubLocationId + ", aggregateOffnetCcl="
				+ aggregateOffnetCcl + ", sigTierOverrideFlag=" + sigTierOverrideFlag + ", signalingRateLookupValue="
				+ signalingRateLookupValue + ", ipVersion=" + ipVersion + ", cpeUEid=" + cpeUEid + ", pqInstanceId="
				+ pqInstanceId + ", tsoMigLock=" + tsoMigLock + ", custSigConstraint=" + custSigConstraint
				+ ", updateComment=" + updateComment + ", zeroSupp=" + zeroSupp + ", featureType=" + featureType
				+ ", billFlag=" + billFlag + ", sigDir=" + sigDir + ", deviceLevel=" + deviceLevel + ", trunkId="
				+ trunkId + ", protocol=" + protocol + ", accessDevice=" + accessDevice + ", bwDeviceId=" + bwDeviceId
				+ ", description=" + description + ", solutionType=" + solutionType + ", ipAddress=" + ipAddress
				+ ", transportProtocol=" + transportProtocol + ", port=" + port + ", region=" + region + ", trunkType="
				+ trunkType + ", envOrderId=" + envOrderId + ", interalOrderId=" + interalOrderId + ", deviceEntity="
				+ deviceEntity +",cpeIpaddress="+cpeIpAddress+ "]";
	}

	public boolean isNewDevice() {
		return isNewDevice;
	}

	public void setNewDevice(boolean isNewDevice) {
		this.isNewDevice = isNewDevice;
	}

	public String getAsClli() {
		return asClli;
	}

	public void setAsClli(String asClli) {
		this.asClli = asClli;
	}


}

