package com.vz.esap.translation.dao.repository;

import java.util.List;

import com.vz.esap.translation.dao.model.TblRetailService;
import com.vz.esap.translation.dao.model.TblRetailServiceExample;


public interface CustomTblRetailServiceMapper extends TblRetailServiceMapper {

	List<TblRetailService> findRetailServices(TblRetailServiceExample tblRetailServiceExample);

}