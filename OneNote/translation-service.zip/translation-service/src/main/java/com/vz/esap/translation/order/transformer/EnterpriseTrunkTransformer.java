package com.vz.esap.translation.order.transformer;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Component;

import com.vz.esap.translation.entity.EnterpriseTrunkEntity;
import com.vz.esap.translation.exception.ApplicationInterfaceException;
import com.vz.esap.translation.exception.GenericException;
import com.vz.esap.translation.exception.TranslatorException;
import com.vz.esap.translation.order.model.request.VOIPOrderRequest;

@Component
public interface EnterpriseTrunkTransformer {

	/**
	 * @param orderId
	 * @param parentId
	 * @param action
	 * @param delta
	 * @return enterpriseTrunk
	 * @throws TranslatorException
	 */
	EnterpriseTrunkEntity transformOrderDetailsToEnterpriseTrunk(long orderId, long parentId, String action,
			boolean delta, List<String> paramActionExclusionList) throws TranslatorException;

	/**
	 * @param enterpriseTrunkEntity
	 * @return enterpriseTrunk
	 */
	EnterpriseTrunkEntity copyEtDelta(EnterpriseTrunkEntity enterpriseTrunkEntity);

	/**
	 * 
	 * @param voipOrderRequest
	 * @param enterpriseTrunkEntity
	 * @return
	 * @throws TranslatorException
	 * @throws GenericException
	 * @throws IllegalAccessException
	 * @throws ApplicationInterfaceException
	 */
	EnterpriseTrunkEntity enrichEnterpriseTrunkEntityWithInventory(VOIPOrderRequest voipOrderRequest,
			EnterpriseTrunkEntity enterpriseTrunkEntity)
			throws TranslatorException, GenericException, IllegalAccessException, ApplicationInterfaceException;

	/**
	 * 
	 * @param resultantRow
	 * @return
	 */
	EnterpriseTrunkEntity enterpriseTrunkInventoryToEnterpriseTrunkEntityTransformer(Map<String, String> resultantRow);

}
