package com.vz.esap.translation.entity;

import java.util.HashSet;

import com.vz.esap.translation.enums.EsapEnum.SignalingDirection;
import com.vz.esap.translation.enums.EsapEnum.TnType;

import EsapEnumPkg.VzbVoipEnum;

public class TNEntity extends Entity {

	public static final int ON = 1;
	public static final int OFF = 0;

	public static enum DeleteType {
		DISCONNECT(VzbVoipEnum.TNDeleteType.DISCONNECT), PORT_OUT(VzbVoipEnum.TNDeleteType.PORT_OUT);

		int esapEnum;
		private DeleteType(int esapEnum) {
			this.esapEnum = esapEnum;
		}
		public int getEsapEnum() {
			return esapEnum;
		}
		public static DeleteType valueOf(int esapEnum) {
			for (DeleteType dt : DeleteType.values())
				if (dt.getEsapEnum() == esapEnum)
					return dt;
			return null;
		}
	}

	public static enum PortOutType {
		TO_RANGE_HOLDER(VzbVoipEnum.PortOutType.TO_RANGE_HOLDER), TO_NON_RANGE_HOLDER(VzbVoipEnum.PortOutType.TO_NON_RANGE_HOLDER);
		int esapEnum;
		private PortOutType(int esapEnum) {
			this.esapEnum = esapEnum;
		}
		public int getEsapEnum() {
			return esapEnum;
		}
		public static PortOutType valueOf(int esapEnum) {
			for (PortOutType po : PortOutType.values())
				if (po.getEsapEnum() == esapEnum)
					return po;
			return null;
		}
	}

	public static enum PortInType {
		FROM_RANGE_HOLDER(VzbVoipEnum.PortInType.FROM_RANGE_HOLDER), FROM_NON_RANGE_HOLDER(VzbVoipEnum.PortInType.FROM_NON_RANGE_HOLDER), WINBACK(VzbVoipEnum.PortInType.WINBACK);
		int esapEnum;
		private PortInType(int esapEnum) {
			this.esapEnum = esapEnum;
		}
		public int getEsapEnum() {
			return esapEnum;
		}
		public static PortInType valueOf(int esapEnum) {
			for (PortInType pi : PortInType.values())
				if (pi.getEsapEnum() == esapEnum)
					return pi;
			return null;
		}
	}

	public static enum OnOffStatus {

		ON(1), OFF(0), NONE(-1);
		int statusNumber;

		private OnOffStatus(int statusNumber) {
			this.statusNumber = statusNumber;
		}

		public int getStatusNumber() {
			return statusNumber;
		}

		public static OnOffStatus valueOf(int statusNumber) {
			for (OnOffStatus ofs : OnOffStatus.values())
				if (ofs.getStatusNumber() == statusNumber)
					return ofs;

			return null;
		}
	}

/*	public static enum TnTypeEnum {

		HIPC(VzbVoipEnum.TnType.HIPC), 
		PBX(VzbVoipEnum.TnType.PBX), 
		KEY(VzbVoipEnum.TnType.KEY), 
		RES(VzbVoipEnum.TnType.RES),
		VMA(VzbVoipEnum.TnType.VMA),
		BA_PORTAL(VzbVoipEnum.TnType.BA_PORTAL),
		AUTO_ATTENDANT(VzbVoipEnum.TnType.AUTO_ATTENDANT),
		PBX_PILOT_TN(VzbVoipEnum.TnType.PBX_PILOT_TN),
		HUNT_GROUP(VzbVoipEnum.TnType.HUNT_GROUP),
		VOICE_PORTAL(VzbVoipEnum.TnType.VOICE_PORTAL),
		ET(VzbVoipEnum.TnType.ET),
		VILO(VzbVoipEnum.TnType.VILO),
		ALTERNATE_TN(VzbVoipEnum.TnType.ALTERNATE_TN),
		
		int tnType;

		private TnTypeEnum(int tnType) {
			this.tnType = tnType;
		}

		public int getTnTypeEnum() {
			return tnType;
		}

		public static TnTypeEnum valueOf(int tnType) {
            for (TnTypeEnum tn : TnTypeEnum.values()){
                if (tn.getTnTypeEnum() == tnType)
                  return tn;
            }
			return null;
		}
	}*/
	
	
	public static enum PortStatus {

		NATIVE(VzbVoipEnum.PortStatus.NATIVE), PORT_PENDING(VzbVoipEnum.PortStatus.PORT_PENDING), PORTED(VzbVoipEnum.PortStatus.PORTED);

		int esapEnum;

		private PortStatus(int esapEnum) {
			this.esapEnum = esapEnum;
		}

		public int getEsapEnum() {
			return esapEnum;
		}

		public static PortStatus valueOf(int esapEnum) {
			for (PortStatus ps : PortStatus.values())
				if (ps.getEsapEnum() == esapEnum)
					return ps;

			return null;
		}

	}
	
	private String locationId;
	private String customerId;
	private Long tnPoolId;
	private String tn;
	private String portingFlag;
	private String trunkId;
	private PortStatus portStatus;
	private String switchClli;
	private Boolean existingTN;
	private OnOffStatus onOffStatus;
	private Integer pubIp;
	private Integer pubIpIn; //VoV
	private Integer pubIpOut;
	private TnType tnType;
	private Boolean available;
	private Long subscriberId;
	private Long groupTNId;
	private String territory;
	private String region;
	private Long sTnInd;
	private Integer actDeact;
	private boolean activation;
	private boolean deactivation;
	private PortInType portInType;
	private DeleteType deleteType;
	private PortOutType portOutType;
	private String deviceName;
	private String portingIndicator;
	private String originalCarrierPrefix;
	private String losingCarrierPrefix;
	private String gainingCarrierPrefix;
	private String gatewayNumber;
	private String subStatus;
	private String entityAction;
	private String tspCode;
	private int transitionType;
	private String PSALI;
	private String linePort;
	private String replacementCLLI;
	private Boolean isR2RMig;
	private String oldLocationId;
	private Boolean oldLocationEmpty;
	private String tnDisposition;
	private String lidb;
	private String verizonBTN;
	private String emergencyFirstName;
	private String emergencyMiddleName;
	private String emergencyLastName;
	private String emergencyBldngDesignator;
	private String emergencyBldngValue;
	private String emergencyFloorDesignator;
	private String emergencyFloorValue;
	private String emergencyRoomValue;
	private String emergencyRoomDesignator;
	private String cnamOutBoundFirstName;
	private String cnamOutBoundLastName;
	private String newVerizonBTN;
	private SignalingDirection signalingDirection;
	private String industryPortability;
	private String portingServiceAddress;
	private String ildRestriction;
	private String country;
	private String currentLecBtn;
	private String nomadic911;
	private String tnAssignment;
	private String pointToNumber;
	private String provider;
	private String huntGroupSequence;
	private String tnTypeOrdering;

	public OnOffStatus getOnOffStatus() {
		return onOffStatus;
	}

	public void setOnOffStatus(OnOffStatus onOffStatus) {
		this.onOffStatus = onOffStatus;
	}

	public Long getTnPoolId() {
		return tnPoolId;
	}

	public void setTnPoolId(Long tnPoolId) {
		this.tnPoolId = tnPoolId;
	}

	
	public String getReplacementCLLI() {
		return replacementCLLI;
	}

	public void setReplacementCLLI(String replacementCLLI) {
		this.replacementCLLI = replacementCLLI;
	}
	
	public String getPSALI() {
		return PSALI;
	}

	public void setPSALI(String PSALI) {
		this.PSALI = PSALI;
	}
	
	public String getTspCode() {
		return tspCode;
	}

	public void setTspCode(String tspCode) {
		this.tspCode = tspCode;
	}
	


	public TNEntity(String tn, String portingFlag, Long tnPoolId) {
		setTn(tn);
		this.portingFlag = portingFlag;
		this.tnPoolId = tnPoolId;
		activation = false;
		deactivation = false;
	}

	public TNEntity(String tn, String portingFlag) {
		setTn(tn);
		activation = false;
		deactivation = false;
		this.portingFlag = portingFlag;
	}

	public TNEntity() {
		activation = false;
		deactivation = false;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((customerId == null) ? 0 : customerId.hashCode());
		result = prime * result + ((locationId == null) ? 0 : locationId.hashCode());
		result = prime * result + ((portingFlag == null) ? 0 : portingFlag.hashCode());
		result = prime * result + ((switchClli == null) ? 0 : switchClli.hashCode());
		result = prime * result + ((tn == null) ? 0 : tn.hashCode());
		result = prime * result + ((tnPoolId == null) ? 0 : tnPoolId.hashCode());
		result = prime * result + ((trunkId == null) ? 0 : trunkId.hashCode());
		result = prime * result + ((sTnInd == null) ? 0 : sTnInd.hashCode());
		result = prime * result + ((pubIp == null) ? 0 : pubIp.hashCode());
		result = prime * result + ((pubIpIn == null) ? 0 : pubIpIn.hashCode()); //VoV
		result = prime * result + ((pubIpOut == null) ? 0 : pubIpOut.hashCode());

		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (null == obj)
			return false;
		if (!(obj instanceof TNEntity))
			return false;
		return this.tn.equals(((TNEntity) obj).getTn());
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public Long getSTNInd() {
		return sTnInd;
	}

	public void setSTNInd(Long sTnInd) {
		this.sTnInd = sTnInd;
	}

	public String getLocationId() {
		return locationId;
	}

	public void setLocationId(String locationId) {
		this.locationId = locationId;
	}

	public Long getTNPoolId() {
		return tnPoolId;
	}

	public void setTNPoolId(Long tnPoolId) {
		this.tnPoolId = tnPoolId;

		if (tnPoolId != null)
			setExistingTN(true);
	}

	public String getTn() {
		return tn;
	}

	public void setTn(String tn) {
		if (tn != null && tn.length() > 0 && tn.indexOf(' ') > -1) {
			tn = tn.trim();
		}
		this.tn = tn;
	}

	public String getPortingFlag() {
		return portingFlag;
	}

	public void setPortingFlag(String portingFlag) {
		this.portingFlag = portingFlag;
		if ("Y".equalsIgnoreCase(portingFlag))
			portStatus = PortStatus.PORT_PENDING;
		
		if("Y".equalsIgnoreCase(portingFlag) && this.tnType == TnType.VILO){
			portStatus=PortStatus.PORTED;			
		}	

	}

	public String getTrunkId() {
		return trunkId;
	}

	public void setTrunkId(String trunkId) {
		this.trunkId = trunkId;
	}

	public String getSwitchClli() {
		return switchClli;
	}

	public void setSwitchClli(String switchClli) {
		this.switchClli = switchClli;
	}

	public int getEntityType() {
		return VzbVoipEnum.OrderEntity.RES_TN;
	}

	public String getEntityId() {
		return tn;
	}

	public String getEntityName() {
		return tn;
	}

	public HashSet<ParentEntity> getParentList() {
		// addParentToList(new ParentEntity(VzbVoipEnum.OrderEntity.ENTERPRISE,
		// null, customerId));
		addParentToList(new ParentEntity(VzbVoipEnum.OrderEntity.LOCATION, null, locationId));

		if (tn != null && tn.length() > 0)
			addParentToList(new ParentEntity(VzbVoipEnum.OrderEntity.TN, tn, null));

		return super.getParentList();
	}

	public Integer getSubscriberOrTnType() {

		if (portStatus != null && (portStatus == PortStatus.PORT_PENDING || portStatus == PortStatus.PORTED))
			return VzbVoipEnum.SubscriberOrTnStatus.PORTED;
		else
			return VzbVoipEnum.SubscriberOrTnStatus.NATIVE;
		/*
		 * if ("Y".equals(portingFlag)) return
		 * VzbVoipEnum.SubscriberOrTnStatus.PORTED; else return
		 * VzbVoipEnum.SubscriberOrTnStatus.NATIVE;
		 */
	}

	public PortStatus getPortStatus() {
		return portStatus;
	}

	public void setPortStatus(PortStatus portStatus) {
		this.portStatus = portStatus;
		if (PortStatus.PORT_PENDING.equals(portStatus))
			portingFlag = "Y";
		else if (portStatus != null)
			portingFlag = "N";
	}

	public Boolean isExistingTN() {
		return existingTN;
	}

	public void setExistingTN(Boolean existingTN) {
		this.existingTN = existingTN;
	}

	public TnType getTnType() {
		return tnType;
	}

	public void setTnTypeEnum(TnType tnType) {
		this.tnType = tnType;
	}

	public Boolean getAvailable() {
		return available;
	}

	public void setAvailable(Boolean available) {
		this.available = available;
	}

	public Long getSubscriberId() {
		return subscriberId;
	}

	public void setSubscriberId(Long subscriberId) {
		this.subscriberId = subscriberId;
	}

	public Long getGroupTNId() {
		return groupTNId;
	}

	public void setGroupTNId(Long groupTNId) {
		this.groupTNId = groupTNId;
	}

	public Integer getActDeact() {
		return actDeact;
	}

	public void setActDeact(Integer actDeact) {
		this.actDeact = actDeact;
	}

	public boolean isPortPendingAndBSTnActivate() {
		boolean status = false;

		if (null == tn) {
			return status;
		}

		if (null != portStatus && null != broadsoftTNActivation) {
			if (TNEntity.PortStatus.PORT_PENDING.equals(portStatus) && broadsoftTNActivation.intValue() == VzbVoipEnum.TnActivation.ON) {
				status = true;
			}
		}
		if (null != portingFlag && null != broadsoftTNActivation) {
			if ("Y".equals(portingFlag) && broadsoftTNActivation.intValue() == VzbVoipEnum.TnActivation.ON) {
				status = true;
			}
		}

		return status;
	}
	
	public boolean isPortPending() {
		boolean status = false;

		if (null == tn) {
			return status;
		}

		if (null != portStatus) {
			if (TNEntity.PortStatus.PORT_PENDING.equals(portStatus)) {
				status = true;
			}
		}
		if (null != portingFlag) {
			if ("Y".equals(portingFlag) ) {
				status = true;
			}
		}

		return status;
	}

	public String getTerritory() {
		return territory;
	}

	public void setTerritory(String territory) {
		this.territory = territory;
	}

	//@deprecated
	public OnOffStatus getPubIpStatus() {
		Integer tmpPubIp = getPubIp();
		if (tmpPubIp == null)
			return null;
		int pip = tmpPubIp.intValue();
		return (pip == 0 ? OnOffStatus.OFF : (pip == 1 ? OnOffStatus.ON : null));
	}

	//@deprecated
	public void setPubIpStatus(OnOffStatus pubIpStatus) {
		if (pubIpStatus != null)
			setPubIp(pubIpStatus.getStatusNumber());
		else
			setPubIp(null);
	}

	public Integer getPubIp() {
		return pubIp;
	}

	public void setPubIp(Integer pubIp) {
		if (pubIp == null) {
			this.pubIp = null;
			return;
		}
		int pubip = pubIp.intValue();
		if (pubip == VzbVoipEnum.OnOffType.ON)
			this.pubIp = OnOffStatus.ON.statusNumber;
		else if (pubip == VzbVoipEnum.OnOffType.OFF)
			this.pubIp = OnOffStatus.OFF.statusNumber;
		else
			this.pubIp = null;
	}
		
	public Integer getPubIpIn() { //VoV
		return pubIpIn;
	}

	public void setPubIpIn(Integer pubIpIn) {
		if (pubIpIn == null) {
			this.pubIpIn = null;
			return;
		}
		int pubipin = pubIpIn.intValue();
		if (pubipin == VzbVoipEnum.OnOffType.ON)
			this.pubIpIn = OnOffStatus.ON.statusNumber;
		else if (pubipin == VzbVoipEnum.OnOffType.OFF)
			this.pubIpIn = OnOffStatus.OFF.statusNumber;
		else
			this.pubIpIn = null;
	}

	public Integer getPubIpOut() {
		return pubIpOut;
	}

	public void setPubIpOut(Integer pubIpOut) {
		if (pubIpOut == null) {
			this.pubIpOut = null;
			return;
		}
		int pubipout = pubIpOut.intValue();
		if (pubipout == VzbVoipEnum.OnOffType.ON)
			this.pubIpOut = OnOffStatus.ON.statusNumber;
		else if (pubipout == VzbVoipEnum.OnOffType.OFF)
			this.pubIpOut = OnOffStatus.OFF.statusNumber;
		else
			this.pubIpOut = null;
	}

	public boolean isActivation() {
		return activation;
	}

	public void setActivation(boolean activation) {
		this.activation = activation;
	}

	public boolean isDeactivation() {
		return deactivation;
	}

	public void setDeactivation(boolean deactivation) {
		this.deactivation = deactivation;
	}

	public PortInType getPortInType() {
		return portInType;
	}

	public void setPortInType(PortInType portinType) {
		this.portInType = portinType;
	}

	public void setDeleteType(DeleteType deleteType) {
		this.deleteType = deleteType;
	}

	public DeleteType getDeleteType() {
		return deleteType;
	}

	public void setPortOutType(PortOutType portOutType) {
		this.portOutType = portOutType;
	}

	public PortOutType getPortOutType() {
		return portOutType;
	}

	public String getPortingIndicator() {
		return portingIndicator;
	}

	public void setPortingIndicator(String portingIndicator) {
		this.portingIndicator = portingIndicator;
	}

	public String getOriginalCarrierPrefix() {
		return originalCarrierPrefix;
	}

	public void setOriginalCarrierPrefix(String originalCarrierPrefix) {
		this.originalCarrierPrefix = originalCarrierPrefix;
	}

	public String getLosingCarrierPrefix() {
		return losingCarrierPrefix;
	}

	public void setLosingCarrierPrefix(String losingCarrierPrefix) {
		this.losingCarrierPrefix = losingCarrierPrefix;
	}

	public String getGainingCarrierPrefix() {
		return gainingCarrierPrefix;
	}

	public void setGainingCarrierPrefix(String gainingCarrierPrefix) {
		this.gainingCarrierPrefix = gainingCarrierPrefix;
	}

	public String getGatewayNumber() {
		return gatewayNumber;
	}

	public void setGatewayNumber(String gatewayNumber) {
		this.gatewayNumber = gatewayNumber;
	}

	public void setSubStatus(String subStatus) {
		this.subStatus = subStatus;
	}

	public String getSubStatus() {
		return subStatus;
	}
	
	public int getTransitionType() {
		return transitionType;
	}

	public void setTransitionType(int transitionType) {
		this.transitionType = transitionType;
	}

	/**
	 * Sets values for PortinType, PortoutType, and DeleteType based on 
	 * Porting info i.e, OriginalCarrierPrefix, PortingIndicator, GainingCarrierPrefix etc
	 */
	public void processPortingInfo(){
		if("N".equals(portingIndicator)){
			portStatus = PortStatus.NATIVE;
		}
		else if("I".equals(portingIndicator)){
			if(losingCarrierPrefix != null && losingCarrierPrefix.equals(originalCarrierPrefix)){
				portInType = PortInType.FROM_RANGE_HOLDER;
			}
			if(losingCarrierPrefix != null && !losingCarrierPrefix.equals(originalCarrierPrefix)){
				portInType = PortInType.FROM_NON_RANGE_HOLDER;
			}
		}
		else if("W".equals(portingIndicator)){
			portInType = PortInType.WINBACK;
		}
/*		else if("O".equals(portingIndicator)){
			deleteType = DeleteType.PORT_OUT;
			
			if(gainingCarrierPrefix != null && gainingCarrierPrefix.equals(originalCarrierPrefix)){
				portOutType = PortOutType.TO_RANGE_HOLDER;
			}
			else if(gainingCarrierPrefix != null && !gainingCarrierPrefix.equals(originalCarrierPrefix)){
				portOutType = PortOutType.TO_NON_RANGE_HOLDER;
			}
		}
*/	}

	
	public void processPortingInfo(boolean delete){
		
		//processPortingInfo();
		if(delete){
			if(subStatus == null || !subStatus.equals("PORTOUT")){
				deleteType = DeleteType.DISCONNECT;
			}
			else if(subStatus.equals("PORTOUT")){
				deleteType = DeleteType.PORT_OUT;
				
				if(PortStatus.NATIVE.equals(portStatus)){
					portOutType = PortOutType.TO_NON_RANGE_HOLDER;
				}
				else if(gainingCarrierPrefix != null && gainingCarrierPrefix.equals(originalCarrierPrefix)){
					portOutType = PortOutType.TO_RANGE_HOLDER;
				}
				else if(gainingCarrierPrefix != null && !gainingCarrierPrefix.equals(originalCarrierPrefix)){
					portOutType = PortOutType.TO_NON_RANGE_HOLDER;
				}
			}
		}
	}
	
	/**
	 * Copies PortingInfo from tnRecord. 
	 * Is Used on delete TN requests to populated INV TN record with portout info that came on the order
	 * Does not copy/overwrite PortInType as INV has this value
	 * @param tnRecord
	 */
	public void copyPortingInfo(TNEntity tnRecord){
		portOutType = tnRecord.getPortOutType();
		deleteType = tnRecord.getDeleteType();
		portingIndicator = tnRecord.getPortingIndicator();
		subStatus = tnRecord.getSubStatus();
		originalCarrierPrefix = tnRecord.getOriginalCarrierPrefix();
		losingCarrierPrefix = tnRecord.getLosingCarrierPrefix();
		gainingCarrierPrefix = tnRecord.getGainingCarrierPrefix();
		gatewayNumber = tnRecord.getGatewayNumber();
	}
	
	public void copyDelta(TNEntity tnRecord){
		
		if(tnRecord.getLocationId() != null) locationId = tnRecord.getLocationId();
		if(tnRecord.getCustomerId() != null) customerId = tnRecord.getCustomerId();
		if(tnRecord.getTNPoolId() != null) tnPoolId = tnRecord.getTNPoolId();
		setTn(tnRecord.getTn());
		if(tnRecord.getPortingFlag() != null) portingFlag = tnRecord.getPortingFlag();
		if(tnRecord.getTrunkId() != null) trunkId = tnRecord.getTrunkId();
		if(tnRecord.getSwitchClli() != null) switchClli = tnRecord.getSwitchClli();
		if(tnRecord.getPortStatus() != null) portStatus = tnRecord.getPortStatus();
		if(tnRecord.isExistingTN() != null) existingTN = tnRecord.isExistingTN();
		if(tnRecord.getTnType() != null) tnType = tnRecord.getTnType();
		if(tnRecord.getOnOffStatus() != null) onOffStatus = tnRecord.getOnOffStatus();
		if(tnRecord.getPubIp() != null) pubIp = tnRecord.getPubIp();
        if(tnRecord.getPubIpIn() != null) pubIpIn = tnRecord.getPubIpIn();//VOV
        if(tnRecord.getPubIpOut() != null) pubIpOut = tnRecord.getPubIpOut();
        if(tnRecord.getAvailable() != null) available = tnRecord.getAvailable();
		if(tnRecord.getSubscriberId() != null) subscriberId = tnRecord.getSubscriberId();
		if(tnRecord.getGroupTNId() != null) groupTNId = tnRecord.getGroupTNId();
		if(tnRecord.getSTNInd() != null) sTnInd = tnRecord.getSTNInd();
		if(tnRecord.getActDeact() != null) actDeact = tnRecord.getActDeact();
		if (null != tnRecord.getAttribMap()) {
			addAllAttrib(tnRecord.getAttribMap());
		}
		if(tnRecord.getPortInType() != null) portInType = tnRecord.getPortInType();
		if(tnRecord.getPortOutType() != null) portOutType = tnRecord.getPortOutType();
		if(tnRecord.getDeleteType() != null) deleteType = tnRecord.getDeleteType();
		if(tnRecord.getPortingIndicator() != null) portingIndicator = tnRecord.getPortingIndicator();
		if(tnRecord.getSubStatus() != null) subStatus = tnRecord.getSubStatus();
		if(tnRecord.getOriginalCarrierPrefix() != null) originalCarrierPrefix = tnRecord.getOriginalCarrierPrefix();
		if(tnRecord.getLosingCarrierPrefix() != null) losingCarrierPrefix = tnRecord.getLosingCarrierPrefix();
		if(tnRecord.getGainingCarrierPrefix() != null) gainingCarrierPrefix = tnRecord.getGainingCarrierPrefix();
		if(tnRecord.getGatewayNumber() != null) gatewayNumber = tnRecord.getGatewayNumber();
		if(tnRecord.getTspCode() != null) tspCode = tnRecord.getTspCode();
		if(tnRecord.getTransitionType() != transitionType) transitionType = tnRecord.getTransitionType();
		if(tnRecord.getReplacementCLLI() != null) replacementCLLI = tnRecord.getReplacementCLLI();
		if(tnRecord.getPSALI() != null) PSALI = tnRecord.getPSALI();
		if(tnRecord.getVerizonBTN() != null) verizonBTN = tnRecord.getVerizonBTN();
		
		
		
		
	}

	public String getOldLocationId() {
		return oldLocationId;
	}

	public void setOldLocationId(String oldLocationId) {
		this.oldLocationId = oldLocationId;
	}

	public void setOldLocationEmptyFlag(Boolean yesno) {
		this.oldLocationEmpty = yesno;
	}
	
	public Boolean getOldLocatinEmptyFlag() {
		return this.oldLocationEmpty;
	}

	public String getVerizonBTN() {
		return verizonBTN;
	}

	public void setVerizonBTN(String verizonBTN) {
		this.verizonBTN = verizonBTN;
	}

	public String getTnDisposition() {
		return tnDisposition;
	}

	public void setTnDisposition(String tnDisposition) {
		this.tnDisposition = tnDisposition;
	}

	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	public String getLidb() {
		return lidb;
	}

	public void setLidb(String lidb) {
		this.lidb = lidb;
	}

	public Long getsTnInd() {
		return sTnInd;
	}

	public void setsTnInd(Long sTnInd) {
		this.sTnInd = sTnInd;
	}

	public Boolean getIsR2RMig() {
		return isR2RMig;
	}

	public void setIsR2RMig(Boolean isR2RMig) {
		this.isR2RMig = isR2RMig;
	}

	public Boolean getOldLocationEmpty() {
		return oldLocationEmpty;
	}

	public void setOldLocationEmpty(Boolean oldLocationEmpty) {
		this.oldLocationEmpty = oldLocationEmpty;
	}

	public String getEmergencyFirstName() {
		return emergencyFirstName;
	}

	public void setEmergencyFirstName(String emergencyFirstName) {
		this.emergencyFirstName = emergencyFirstName;
	}

	public String getEmergencyMiddleName() {
		return emergencyMiddleName;
	}

	public void setEmergencyMiddleName(String emergencyMiddleName) {
		this.emergencyMiddleName = emergencyMiddleName;
	}

	public String getEmergencyLastName() {
		return emergencyLastName;
	}

	public void setEmergencyLastName(String emergencyLastName) {
		this.emergencyLastName = emergencyLastName;
	}

	public String getEmergencyBldngDesignator() {
		return emergencyBldngDesignator;
	}

	public void setEmergencyBldngDesignator(String emergencyBldngDesignator) {
		this.emergencyBldngDesignator = emergencyBldngDesignator;
	}

	public String getEmergencyBldngValue() {
		return emergencyBldngValue;
	}

	public void setEmergencyBldngValue(String emergencyBldngValue) {
		this.emergencyBldngValue = emergencyBldngValue;
	}

	public String getEmergencyFloorDesignator() {
		return emergencyFloorDesignator;
	}

	public void setEmergencyFloorDesignator(String emergencyFloorDesignator) {
		this.emergencyFloorDesignator = emergencyFloorDesignator;
	}

	public String getEmergencyFloorValue() {
		return emergencyFloorValue;
	}

	public void setEmergencyFloorValue(String emergencyFloorValue) {
		this.emergencyFloorValue = emergencyFloorValue;
	}

	public String getEmergencyRoomValue() {
		return emergencyRoomValue;
	}

	public void setEmergencyRoomValue(String emergencyRoomValue) {
		this.emergencyRoomValue = emergencyRoomValue;
	}

	public String getCnamOutBoundFirstName() {
		return cnamOutBoundFirstName;
	}

	public void setCnamOutBoundFirstName(String cnamOutBoundFirstName) {
		this.cnamOutBoundFirstName = cnamOutBoundFirstName;
	}

	public String getCnamOutBoundLastName() {
		return cnamOutBoundLastName;
	}

	public void setCnamOutBoundLastName(String cnamOutBoundLastName) {
		this.cnamOutBoundLastName = cnamOutBoundLastName;
	}

	public String getNewVerizonBTN() {
		return newVerizonBTN;
	}

	public void setNewVerizonBTN(String newVerizonBTN) {
		this.newVerizonBTN = newVerizonBTN;
	}

	public SignalingDirection getSignalingDirection() {
		return signalingDirection;
	}

	public void setSignalingDirection(SignalingDirection signalingDirection) {
		this.signalingDirection = signalingDirection;
	}

	public String getIndustryPortability() {
		return industryPortability;
	}

	public void setIndustryPortability(String industryPortability) {
		this.industryPortability = industryPortability;
	}

	public String getPortingServiceAddress() {
		return portingServiceAddress;
	}

	public void setPortingServiceAddress(String portingServiceAddress) {
		this.portingServiceAddress = portingServiceAddress;
	}

	public String getIldRestriction() {
		return ildRestriction;
	}

	public void setIldRestriction(String ildRestriction) {
		this.ildRestriction = ildRestriction;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getCurrentLecBtn() {
		return currentLecBtn;
	}

	public void setCurrentLecBtn(String currentLecBtn) {
		this.currentLecBtn = currentLecBtn;
	}

	public String getNomadic911() {
		return nomadic911;
	}

	public void setNomadic911(String nomadic911) {
		this.nomadic911 = nomadic911;
	}

	public String getTnAssignment() {
		return tnAssignment;
	}

	public void setTnAssignment(String tnAssignment) {
		this.tnAssignment = tnAssignment;
	}

	public String getPointToNumber() {
		return pointToNumber;
	}

	public void setPointToNumber(String pointToNumber) {
		this.pointToNumber = pointToNumber;
	}

	public String getProvider() {
		return provider;
	}

	public void setProvider(String provider) {
		this.provider = provider;
	}

	public String getHuntGroupSequence() {
		return huntGroupSequence;
	}

	public void setHuntGroupSequence(String huntGroupSequence) {
		this.huntGroupSequence = huntGroupSequence;
	}

	public Boolean getExistingTN() {
		return existingTN;
	}

	public void setTnType(TnType tnType) {
		this.tnType = tnType;
	}

	public String getEmergencyRoomDesignator() {
		return emergencyRoomDesignator;
	}

	public void setEmergencyRoomDesignator(String emergencyRoomDesignator) {
		this.emergencyRoomDesignator = emergencyRoomDesignator;
	}

	public String getTnTypeOrdering() {
		return tnTypeOrdering;
	}

	public void setTnTypeOrdering(String tnTypeOrdering) {
		this.tnTypeOrdering = tnTypeOrdering;
	}

	public String getDeviceName() {
		return deviceName;
	}

	public void setDeviceName(String deviceName) {
		this.deviceName = deviceName;
	}

	public String getEntityAction() {
		return entityAction;
	}

	public void setEntityAction(String entityAction) {
		this.entityAction = entityAction;
	}

	public String getLinePort() {
		return linePort;
	}

	public void setLinePort(String linePort) {
		this.linePort = linePort;
	}

	
/*	public void setR2RMigration(Boolean r2rMgrn) {
		this.isR2RMig = r2rMgrn;
	}
	
	public Boolean isR2RMigratingTN() {
		if (this.isR2RMig == null)
			return Boolean.FALSE;
		return this.isR2RMig; 
	}*/
	
}

