package com.vz.esap.translation.order.model.pc;

import com.fasterxml.jackson.annotation.JsonProperty;

public class IPCCIDADNSInfo {

	@JsonProperty(value = "DeviceName")
	private String deviceName;

	@JsonProperty(value = "CpeIpAddress")
	private String cpeIpAddress;

	@JsonProperty(value = "CpeFqdn")
	private String cpeFqdn;

	public String getDeviceName() {
		return deviceName;
	}

	public void setDeviceName(String deviceName) {
		this.deviceName = deviceName;
	}

	public String getCpeIpAddress() {
		return cpeIpAddress;
	}

	public void setCpeIpAddress(String cpeIpAddress) {
		this.cpeIpAddress = cpeIpAddress;
	}

	public String getCpeFqdn() {
		return cpeFqdn;
	}

	public void setCpeFqdn(String cpeFqdn) {
		this.cpeFqdn = cpeFqdn;
	}

}
