package com.vz.esap.translation.order.model.request;

public class ChangedElement {

	private String ValueIdentifier;

	private String ChangeIdentifier;

	private String NewValue;

	private String FeatureInstanceId;

	private String OriginalValue;

	private String FeatureCode;

	private String SpecificationCode;

	private String ChangeType;

	public String getValueIdentifier() {
		return ValueIdentifier;
	}

	public void setValueIdentifier(String ValueIdentifier) {
		this.ValueIdentifier = ValueIdentifier;
	}

	public String getChangeIdentifier() {
		return ChangeIdentifier;
	}

	public void setChangeIdentifier(String ChangeIdentifier) {
		this.ChangeIdentifier = ChangeIdentifier;
	}

	public String getNewValue() {
		return NewValue;
	}

	public void setNewValue(String NewValue) {
		this.NewValue = NewValue;
	}

	public String getFeatureInstanceId() {
		return FeatureInstanceId;
	}

	public void setFeatureInstanceId(String FeatureInstanceId) {
		this.FeatureInstanceId = FeatureInstanceId;
	}

	public String getOriginalValue() {
		return OriginalValue;
	}

	public void setOriginalValue(String OriginalValue) {
		this.OriginalValue = OriginalValue;
	}

	public String getFeatureCode() {
		return FeatureCode;
	}

	public void setFeatureCode(String FeatureCode) {
		this.FeatureCode = FeatureCode;
	}

	public String getSpecificationCode() {
		return SpecificationCode;
	}

	public void setSpecificationCode(String SpecificationCode) {
		this.SpecificationCode = SpecificationCode;
	}

	public String getChangeType() {
		return ChangeType;
	}

	public void setChangeType(String ChangeType) {
		this.ChangeType = ChangeType;
	}

	public String toString() {
		return "ClassPojo [ValueIdentifier = " + ValueIdentifier + ", ChangeIdentifier = " + ChangeIdentifier
				+ ", NewValue = " + NewValue + ", FeatureInstanceId = " + FeatureInstanceId + ", OriginalValue = "
				+ OriginalValue + ", FeatureCode = " + FeatureCode + ", SpecificationCode = " + SpecificationCode
				+ ", ChangeType = " + ChangeType + "]";
	}
}
