package com.vz.esap.translation.dao.repository;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Component;

@Component
public interface CustomCustomerMapper extends CustomerMapper {

	String getOldEnterpriseIdForTSOMgration(Map<String, Object> params);

	String getCustomerRegionBasedOnCountry(Map<String, Object> params);

	List<String> getBillableFeatures();

	Long getCustomerCount(Map<String, Object> params);

	long getEnvOrderIdSeqNextVal();

	long getOrderIdSeqNextVal();
	
	long getEnterpriseTrunkIdSeqNextVal();
	
	long getEnterpriseIdSeqNextVal();
	
	long getGroupTnIdSeqNextVal();
	
	long getDeviceMapIdSeqNextVal();

	long getGroupIdSeqNextVal();
	
	long getLocationIdSeqNextVal();

	long getSubscriberIdSeqNextVal();
}
