package com.vz.esap.translation.entity;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.vz.esap.translation.enums.EsapEnum.AuthFeatureType;
import com.vz.esap.translation.enums.EsapEnum.OrderEntity;
import com.vz.esap.translation.enums.EsapEnum.SolutionType;
import com.vz.esap.translation.order.model.request.DigitString;
import com.vz.esap.translation.order.model.request.GCMInfo;
import com.vz.esap.translation.order.model.request.TsoMigrationEntReferenceData;

import EsapEnumPkg.VzbVoipEnum;
import EsapEnumPkg.VzbVoipEnums;
import EsapEnumPkg.VzbVoipEnums.E2EIMigrationStatusEnum;
import EsapEnumPkg.VzbVoipEnums.IPVersionEnum;
import EsapEnumPkg.VzbVoipEnums.OrderPlatformEnum;

public class CustomerEntity extends Entity {

	private static final Logger LOG = LoggerFactory.getLogger(CustomerEntity.class);

	public static enum SlaType {
		CORPORATE, SITE;
	}

	public static enum QosIndicator {
		NONE, STANDARD, PREMIUM;
	}

	private static final long serialVersionUID = 1L;
	private String customerId;
	private String customerName;
	private String rivCustomer;
	private String contactFirstName;
	private String contactLastName;
	private String contactTitle;
	private String contactAddress1;
	private String contactAddress2;
	private String contactCity;
	private String contactState;
	private String contactZip;
	private String contactCountry;
	private String contactPhone1;
	private String contactPhone2;
	private String contactFax;
	private String contactMobile;
	private String contactPager;
	private String contactEmail;
	private Integer regionType;
	// private String regionTypeStr;
	private String accountTeamName;
	private String accountTeamFirstName;
	private String accountTeamLastName;
	private String accountTeamPhone;
	private String accountTeamEmail;
	private String accountTeamCountryDialling;
	private String accountTeamAreaDialling;
	private String accountTeamDialNumber;
	private String countryDialing;
	private String areaDialing;
	private String dialNumber;
	private String e2EIFeatur;
	private String newEntId;
	private String nonTrustedIPCalls; // pubIp
	private String allowOnNet; // on_net_interco ??
	private String sipDomain;
	private String orderComment;
	private Integer billingSystem;
	// private String billingSystemStr;
	private BigInteger vnetCorpId;
	private Integer centrexType;
	// private String centrexTypeStr;
	private String agencyHierCode;
	private String xrefCustomerId;
	private String contractInd;
	private String adminFirstName;
	private String adminLastName;
	private String adminEmail;
	private String adminWebLoginId;
	private String adminPassword;
	private Boolean enterpriseCclIndicator;
	private String enterpriseCclIndicatorStr;
	private Boolean tntCclInd;
	private String tntCclIndStr;
	private String bsAppServer;
	private String asClli;
	private QosIndicator qosIndicator;
	private SlaType slaType;
	private Integer callingPlanId;
	private Integer ieanLength;
	private String vmPartitionId;
	private String commonCustId;
	private String commonCustName;
	HashMap<String, Boolean> authServices;
	private List<AuthService> authService;
	HashSet<String> sipDomains;
	protected String billContactPriPhone;
	protected String billContactAltPhone;
	protected String billContactCell;
	protected String billContactPager;
	protected String billContactEmail;
	protected String billContactAddr1;
	protected String billContactAddr2;
	protected String billContactCity;
	protected String billContactState;
	protected String billContactZip;
	protected String billContactCountry;
	protected Long salesSegment;
	protected String salesRepId;
	protected String salesRepName;
	protected String salesRepPhone;
	protected String salesRepEmail;
	protected String custCorpId;
	protected Long orderVerification;
	protected String supportName;
	protected String supportPhone;
	protected Long emeaServiceSupport;
	protected String custSensitivityLevel;
	protected Long custGarmStatus;
	protected Long custActiveInd;
	protected Integer bsBlockInd;
	protected Boolean sbcAutomation;
	protected Integer productType;
	private String microNode;
	private OrderPlatformEnum orderPlatform;// open
	private String authPbxUnReachableFeature;
	private String authCFNR;
	private String ncaId;
	private String etRouteOverflowAuthorization;
	private String usagePlan;
	private String numberOfFreeMinutes;
	private String routeExhaust;
	private String e2EIFeature;
	private ArrayList<DigitString> digitStrings;

	private String calnetSubContractInd;
	private Boolean enableEnterpriseExtensionDialing;
	/* APAC Attributes */
	private String naspId;
	private String marketType;
	/* End - APAC */
	private String LOR;

	// IPCC CustomerEntity load sharing flag
	private String sbcLoadSharing;
	private String defaultSubnet;

	private boolean entONNETFlag;
	// private SbcLoadSharing loadSharingSbcs;--open
	private String gchId;
	private String virtualAddrLine;
	private String virtualAddrCity;
	private String virtualAddrState;
	private String virtualAddrZip;
	private String virtualAddrCountry;
	private String lorId;

	// Added for new Voip Trunking Service optimization
	private String soEnabled;
	private String usLDAndLocalBestPool;
	private String usLDOnlyBestPool;
	private String emeaApacBestPool;
	private String bestPlusPoolId;
	private String bestPlusCclPoolId;
	private String entServicePlan;
	private String entCountryCode;
	private String bestPlusTier;
	private String bestPlusCclTier;
	private String usLDAndLocalBestPlusPool;
	private String usLDAndLocalBestPlusCclPool;
	private String usLDAndLocalBestPlusPoolId;
	private String usLDAndLocalBestPlusCclPoolId;
	private String usLDOnlyBestPlusPool;
	private String usLDOnlyBestPlusCclPool;
	private String usLDOnlyBestPlusPoolId;
	private String usLDOnlyBestPlusCclPoolId;
	private String emeaApacBestPlusPool;
	private String emeaApacBestPlusCclPool;
	private String emeaApacBestPlusPoolId;
	private String emeaApacBestPlusCclPoolId;
	private GCMInfo gcmInfo;
	private Long designId;
	private String catalogVersionTime;
	// ---Added For IPCC----
	private String viloTnMonthlyMinutes;
	private String viloTnMonthlyCCL;
	private String tollFreeMonthlyMins;
	private String tollFreeMonthlyCCL;
	private String uifnMonthlyMins;
	private String uifnCCL;
	private String itfsMins;
	private String monthlyITFSCCL;
	private String viloPortingCustName;
	private Date viloPortingAuthDate;
	private String viloTollFreePortingCustName;
	private Date viloTollFreePortingAuthDate;
	private String uifnPortingCustName;
	private Date uifnPortingAuthDate;
	private String itfsPortingCustName;
	private Date itfsPortingAuthDate;
	private IPVersionEnum ipVersion;
	private String CustomerDomain;
	private String itsfTNQuantity;
	private String uifnTNQuantity;
	private String viloTNQuantity;
	private String inboundTNQuantity;
	private Long cummulativeCcl;
	private Boolean ipccCustOnChg;
	private String parentEnterpriseId;
	private TsoMigrationEntReferenceData tsoMigrationEntReferenceData;
	private VzbVoipEnums.EnterpriseTrunkingTypeEnum enterpriseTrunkingType;// open
	private E2EIMigrationStatusEnum e2eiMigStatus;
	private Long e2eiMigLock;
	private String bwEnterpriseId;
	private String voiceVpn;
	//xoo
	private SolutionType solutionType;
	private String region;
	private AuthFeatureType authFeatureType;
	private long envOrderId;
	private long internalOrderId;
	private String provisionCategory;
	private CustomerEntity customerEntity;
	
	
	public CustomerEntity getCustomerEntity() {
		return customerEntity;
	}

	public void setCustomerEntity(CustomerEntity customerEntity) {
		this.customerEntity = customerEntity;
	}

	@Override
	public int getEntityType() {
		return OrderEntity.ENTERPRISE.getIndex();
	}

	@Override
	public String getEntityName() {
		return customerName;
	}

	@Override
	public String getEntityId() {
		return customerId;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getRivCustomer() {
		return rivCustomer;
	}

	public void setRivCustomer(String rivCustomer) {
		this.rivCustomer = rivCustomer;
	}

	public String getContactFirstName() {
		return contactFirstName;
	}

	public void setContactFirstName(String contactFirstName) {
		this.contactFirstName = contactFirstName;
	}

	public String getContactLastName() {
		return contactLastName;
	}

	public void setContactLastName(String contactLastName) {
		this.contactLastName = contactLastName;
	}

	public String getContactTitle() {
		return contactTitle;
	}

	public void setContactTitle(String contactTitle) {
		this.contactTitle = contactTitle;
	}

	public String getContactAddress1() {
		return contactAddress1;
	}

	public void setContactAddress1(String contactAddress1) {
		this.contactAddress1 = contactAddress1;
	}

	public String getContactAddress2() {
		return contactAddress2;
	}

	public void setContactAddress2(String contactAddress2) {
		this.contactAddress2 = contactAddress2;
	}

	public String getContactCity() {
		return contactCity;
	}

	public void setContactCity(String contactCity) {
		this.contactCity = contactCity;
	}

	public String getContactState() {
		return contactState;
	}

	public void setContactState(String contactState) {
		this.contactState = contactState;
	}

	public String getContactZip() {
		return contactZip;
	}

	public void setContactZip(String contactZip) {
		this.contactZip = contactZip;
	}

	public String getContactCountry() {
		return contactCountry;
	}

	public void setContactCountry(String contactCountry) {
		this.contactCountry = contactCountry;
	}

	public String getContactPhone1() {
		return contactPhone1;
	}

	public void setContactPhone1(String contactPhone1) {
		this.contactPhone1 = contactPhone1;
	}

	public String getContactPhone2() {
		return contactPhone2;
	}

	public void setContactPhone2(String contactPhone2) {
		this.contactPhone2 = contactPhone2;
	}

	public String getContactFax() {
		return contactFax;
	}

	public void setContactFax(String contactFax) {
		this.contactFax = contactFax;
	}

	public String getContactMobile() {
		return contactMobile;
	}

	public void setContactMobile(String contactMobile) {
		this.contactMobile = contactMobile;
	}

	public String getContactPager() {
		return contactPager;
	}

	public void setContactPager(String contactPager) {
		this.contactPager = contactPager;
	}

	public String getContactEmail() {
		return contactEmail;
	}

	public void setContactEmail(String contactEmail) {
		this.contactEmail = contactEmail;
	}

	public Integer getRegionType() {
		return regionType;
	}

	public void setRegionType(Integer regionType) {
		this.regionType = regionType;
	}

	public String getAccountTeamName() {
		return accountTeamName;
	}

	public void setAccountTeamName(String accountTeamName) {
		this.accountTeamName = accountTeamName;
	}

	public String getAccountTeamPhone() {
		return accountTeamPhone;
	}

	public void setAccountTeamPhone(String accountTeamPhone) {
		this.accountTeamPhone = accountTeamPhone;
	}

	public String getAccountTeamEmail() {
		return accountTeamEmail;
	}

	public void setAccountTeamEmail(String accountTeamEmail) {
		this.accountTeamEmail = accountTeamEmail;
	}

	public String getNonTrustedIPCalls() {
		return nonTrustedIPCalls;
	}

	public void setNonTrustedIPCalls(String nonTrustedIPCalls) {
		this.nonTrustedIPCalls = nonTrustedIPCalls;
	}

	public String getAllowOnNet() {
		return allowOnNet;
	}

	public void setAllowOnNet(String allowOnNet) {
		this.allowOnNet = allowOnNet;
	}

	public String getSipDomain() {
		return sipDomain;
	}

	public void setSipDomain(String sipDomain) {
		this.sipDomain = sipDomain;
	}

	public String getOrderComment() {
		return orderComment;
	}

	public void setOrderComment(String orderComment) {
		this.orderComment = orderComment;
	}

	public Integer getBillingSystem() {
		return billingSystem;
	}

	public void setBillingSystem(Integer billingSystem) {
		this.billingSystem = billingSystem;
	}

	public BigInteger getVnetCorpId() {
		return vnetCorpId;
	}

	public void setVnetCorpId(BigInteger vnetCorpId) {
		this.vnetCorpId = vnetCorpId;
	}

	public Integer getCentrexType() {
		return centrexType;
	}

	public void setCentrexType(Integer centrexType) {
		this.centrexType = centrexType;
	}

	public String getAgencyHierCode() {
		return agencyHierCode;
	}

	public void setAgencyHierCode(String agencyHierCode) {
		this.agencyHierCode = agencyHierCode;
	}

	public String getXrefCustomerId() {
		return xrefCustomerId;
	}

	public void setXrefCustomerId(String xrefCustomerId) {
		this.xrefCustomerId = xrefCustomerId;
	}

	public String getContractInd() {
		return contractInd;
	}

	public void setContractInd(String contractInd) {
		this.contractInd = contractInd;
	}

	public String getAdminFirstName() {
		return adminFirstName;
	}

	public void setAdminFirstName(String adminFirstName) {
		this.adminFirstName = adminFirstName;
	}

	public String getAdminLastName() {
		return adminLastName;
	}

	public void setAdminLastName(String adminLastName) {
		this.adminLastName = adminLastName;
	}

	public String getAdminEmail() {
		return adminEmail;
	}

	public void setAdminEmail(String adminEmail) {
		this.adminEmail = adminEmail;
	}

	public String getAdminWebLoginId() {
		return adminWebLoginId;
	}

	public void setAdminWebLoginId(String adminWebLoginId) {
		this.adminWebLoginId = adminWebLoginId;
	}

	public String getAdminPassword() {
		return adminPassword;
	}

	public void setAdminPassword(String adminPassword) {
		this.adminPassword = adminPassword;
	}

	public Boolean getEnterpriseCclIndicator() {
		return enterpriseCclIndicator;
	}

	public void setEnterpriseCclIndicator(Boolean enterpriseCclIndicator) {
		this.enterpriseCclIndicator = enterpriseCclIndicator;
	}

	public Boolean getTntCclInd() {
		return tntCclInd;
	}

	public void setTntCclInd(Boolean tntCclInd) {
		this.tntCclInd = tntCclInd;
	}

	public String getBsAppServer() {
		return bsAppServer;
	}

	public void setBsAppServer(String bsAppServer) {
		this.bsAppServer = bsAppServer;
	}

	public QosIndicator getQosIndicator() {
		return qosIndicator;
	}

	public void setQosIndicator(QosIndicator qosIndicator) {
		this.qosIndicator = qosIndicator;
	}

	public SlaType getSlaType() {
		return slaType;
	}

	public void setSlaType(SlaType slaType) {
		this.slaType = slaType;
	}

	public Integer getCallingPlanId() {
		return callingPlanId;
	}

	public void setCallingPlanId(Integer callingPlanId) {
		this.callingPlanId = callingPlanId;
	}

	public Integer getIeanLength() {
		return ieanLength;
	}

	public void setIeanLength(Integer ieanLength) {
		this.ieanLength = ieanLength;
	}

	public String getVmPartitionId() {
		return vmPartitionId;
	}

	public void setVmPartitionId(String vmPartitionId) {
		this.vmPartitionId = vmPartitionId;
	}

	public String getCommonCustId() {
		return commonCustId;
	}

	public void setCommonCustId(String commonCustId) {
		this.commonCustId = commonCustId;
	}

	public String getCommonCustName() {
		return commonCustName;
	}

	public void setCommonCustName(String commonCustName) {
		this.commonCustName = commonCustName;
	}

	public HashMap<String, Boolean> getAuthServices() {
		return authServices;
	}

	public void setAuthServices(HashMap<String, Boolean> authServices) {
		this.authServices = authServices;
	}

	public HashSet<String> getSipDomains() {
		return sipDomains;
	}

	public void setSipDomains(HashSet<String> sipDomains) {
		this.sipDomains = sipDomains;
	}

	public String getBillContactPriPhone() {
		return billContactPriPhone;
	}

	public void setBillContactPriPhone(String billContactPriPhone) {
		this.billContactPriPhone = billContactPriPhone;
	}

	public String getBillContactAltPhone() {
		return billContactAltPhone;
	}

	public void setBillContactAltPhone(String billContactAltPhone) {
		this.billContactAltPhone = billContactAltPhone;
	}

	public String getBillContactCell() {
		return billContactCell;
	}

	public void setBillContactCell(String billContactCell) {
		this.billContactCell = billContactCell;
	}

	public String getBillContactPager() {
		return billContactPager;
	}

	public void setBillContactPager(String billContactPager) {
		this.billContactPager = billContactPager;
	}

	public String getBillContactEmail() {
		return billContactEmail;
	}

	public void setBillContactEmail(String billContactEmail) {
		this.billContactEmail = billContactEmail;
	}

	public String getBillContactAddr1() {
		return billContactAddr1;
	}

	public void setBillContactAddr1(String billContactAddr1) {
		this.billContactAddr1 = billContactAddr1;
	}

	public String getBillContactAddr2() {
		return billContactAddr2;
	}

	public void setBillContactAddr2(String billContactAddr2) {
		this.billContactAddr2 = billContactAddr2;
	}

	public String getBillContactCity() {
		return billContactCity;
	}

	public void setBillContactCity(String billContactCity) {
		this.billContactCity = billContactCity;
	}

	public String getBillContactState() {
		return billContactState;
	}

	public void setBillContactState(String billContactState) {
		this.billContactState = billContactState;
	}

	public String getBillContactZip() {
		return billContactZip;
	}

	public void setBillContactZip(String billContactZip) {
		this.billContactZip = billContactZip;
	}

	public String getBillContactCountry() {
		return billContactCountry;
	}

	public void setBillContactCountry(String billContactCountry) {
		this.billContactCountry = billContactCountry;
	}

	public Long getSalesSegment() {
		return salesSegment;
	}

	public void setSalesSegment(Long salesSegment) {
		this.salesSegment = salesSegment;
	}

	public String getSalesRepId() {
		return salesRepId;
	}

	public void setSalesRepId(String salesRepId) {
		this.salesRepId = salesRepId;
	}

	public String getSalesRepName() {
		return salesRepName;
	}

	public void setSalesRepName(String salesRepName) {
		this.salesRepName = salesRepName;
	}

	public String getSalesRepPhone() {
		return salesRepPhone;
	}

	public void setSalesRepPhone(String salesRepPhone) {
		this.salesRepPhone = salesRepPhone;
	}

	public String getSalesRepEmail() {
		return salesRepEmail;
	}

	public void setSalesRepEmail(String salesRepEmail) {
		this.salesRepEmail = salesRepEmail;
	}

	public String getCustCorpId() {
		return custCorpId;
	}

	public void setCustCorpId(String custCorpId) {
		this.custCorpId = custCorpId;
	}

	public Long getOrderVerification() {
		return orderVerification;
	}

	public void setOrderVerification(Long orderVerification) {
		this.orderVerification = orderVerification;
	}

	public String getSupportName() {
		return supportName;
	}

	public void setSupportName(String supportName) {
		this.supportName = supportName;
	}

	public String getSupportPhone() {
		return supportPhone;
	}

	public void setSupportPhone(String supportPhone) {
		this.supportPhone = supportPhone;
	}

	public Long getEmeaServiceSupport() {
		return emeaServiceSupport;
	}

	public void setEmeaServiceSupport(Long emeaServiceSupport) {
		this.emeaServiceSupport = emeaServiceSupport;
	}

	public String getCustSensitivityLevel() {
		return custSensitivityLevel;
	}

	public void setCustSensitivityLevel(String custSensitivityLevel) {
		this.custSensitivityLevel = custSensitivityLevel;
	}

	public Long getCustGarmStatus() {
		return custGarmStatus;
	}

	public void setCustGarmStatus(Long custGarmStatus) {
		this.custGarmStatus = custGarmStatus;
	}

	public Long getCustActiveInd() {
		return custActiveInd;
	}

	public void setCustActiveInd(Long custActiveInd) {
		this.custActiveInd = custActiveInd;
	}

	public Integer getBsBlockInd() {
		return bsBlockInd;
	}

	public void setBsBlockInd(Integer bsBlockInd) {
		this.bsBlockInd = bsBlockInd;
	}

	public Integer getProductType() {
		return productType;
	}

	public void setProductType(Integer productType) {
		this.productType = productType;
	}

	public String getMicroNode() {
		return microNode;
	}

	public void setMicroNode(String microNode) {
		this.microNode = microNode;
	}

	public String getCalnetSubContractInd() {
		return calnetSubContractInd;
	}

	public void setCalnetSubContractInd(String calnetSubContractInd) {
		this.calnetSubContractInd = calnetSubContractInd;
	}

	public String getNaspId() {
		return naspId;
	}

	public void setNaspId(String naspId) {
		this.naspId = naspId;
	}

	public String getMarketType() {
		return marketType;
	}

	public void setMarketType(String marketType) {
		this.marketType = marketType;
	}

	public String getLOR() {
		return LOR;
	}

	public void setLOR(String lOR) {
		LOR = lOR;
	}

	public String getSbcLoadSharing() {
		return sbcLoadSharing;
	}

	public void setSbcLoadSharing(String sbcLoadSharing) {
		this.sbcLoadSharing = sbcLoadSharing;
	}

	public String getDefaultSubnet() {
		return defaultSubnet;
	}

	public void setDefaultSubnet(String defaultSubnet) {
		this.defaultSubnet = defaultSubnet;
	}

	public boolean isEntONNETFlag() {
		return entONNETFlag;
	}

	public void setEntONNETFlag(boolean entONNETFlag) {
		this.entONNETFlag = entONNETFlag;
	}

	public String getGchId() {
		return gchId;
	}

	public void setGchId(String gchId) {
		this.gchId = gchId;
	}

	public String getVirtualAddrLine() {
		return virtualAddrLine;
	}

	public void setVirtualAddrLine(String virtualAddrLine) {
		this.virtualAddrLine = virtualAddrLine;
	}

	public String getVirtualAddrCity() {
		return virtualAddrCity;
	}

	public void setVirtualAddrCity(String virtualAddrCity) {
		this.virtualAddrCity = virtualAddrCity;
	}

	public String getVirtualAddrState() {
		return virtualAddrState;
	}

	public void setVirtualAddrState(String virtualAddrState) {
		this.virtualAddrState = virtualAddrState;
	}

	public String getVirtualAddrZip() {
		return virtualAddrZip;
	}

	public void setVirtualAddrZip(String virtualAddrZip) {
		this.virtualAddrZip = virtualAddrZip;
	}

	public String getVirtualAddrCountry() {
		return virtualAddrCountry;
	}

	public void setVirtualAddrCountry(String virtualAddrCountry) {
		this.virtualAddrCountry = virtualAddrCountry;
	}

	public String getLorId() {
		return lorId;
	}

	public void setLorId(String lorId) {
		this.lorId = lorId;
	}

	public String getSoEnabled() {
		return soEnabled;
	}

	public void setSoEnabled(String soEnabled) {
		this.soEnabled = soEnabled;
	}

	public String getUsLDAndLocalBestPool() {
		return usLDAndLocalBestPool;
	}

	public void setUsLDAndLocalBestPool(String usLDAndLocalBestPool) {
		this.usLDAndLocalBestPool = usLDAndLocalBestPool;
	}

	public String getUsLDOnlyBestPool() {
		return usLDOnlyBestPool;
	}

	public void setUsLDOnlyBestPool(String usLDOnlyBestPool) {
		this.usLDOnlyBestPool = usLDOnlyBestPool;
	}

	public String getEmeaApacBestPool() {
		return emeaApacBestPool;
	}

	public void setEmeaApacBestPool(String emeaApacBestPool) {
		this.emeaApacBestPool = emeaApacBestPool;
	}

	public String getBestPlusPoolId() {
		return bestPlusPoolId;
	}

	public void setBestPlusPoolId(String bestPlusPoolId) {
		this.bestPlusPoolId = bestPlusPoolId;
	}

	public String getBestPlusCclPoolId() {
		return bestPlusCclPoolId;
	}

	public void setBestPlusCclPoolId(String bestPlusCclPoolId) {
		this.bestPlusCclPoolId = bestPlusCclPoolId;
	}

	public String getEntServicePlan() {
		return entServicePlan;
	}

	public void setEntServicePlan(String entServicePlan) {
		this.entServicePlan = entServicePlan;
	}

	public String getEntCountryCode() {
		return entCountryCode;
	}

	public void setEntCountryCode(String entCountryCode) {
		this.entCountryCode = entCountryCode;
	}

	public String getBestPlusTier() {
		return bestPlusTier;
	}

	public void setBestPlusTier(String bestPlusTier) {
		this.bestPlusTier = bestPlusTier;
	}

	public String getBestPlusCclTier() {
		return bestPlusCclTier;
	}

	public void setBestPlusCclTier(String bestPlusCclTier) {
		this.bestPlusCclTier = bestPlusCclTier;
	}

	public String getUsLDAndLocalBestPlusPool() {
		return usLDAndLocalBestPlusPool;
	}

	public void setUsLDAndLocalBestPlusPool(String usLDAndLocalBestPlusPool) {
		this.usLDAndLocalBestPlusPool = usLDAndLocalBestPlusPool;
	}

	public String getUsLDAndLocalBestPlusCclPool() {
		return usLDAndLocalBestPlusCclPool;
	}

	public void setUsLDAndLocalBestPlusCclPool(String usLDAndLocalBestPlusCclPool) {
		this.usLDAndLocalBestPlusCclPool = usLDAndLocalBestPlusCclPool;
	}

	public String getUsLDAndLocalBestPlusPoolId() {
		return usLDAndLocalBestPlusPoolId;
	}

	public void setUsLDAndLocalBestPlusPoolId(String usLDAndLocalBestPlusPoolId) {
		this.usLDAndLocalBestPlusPoolId = usLDAndLocalBestPlusPoolId;
	}

	public String getUsLDAndLocalBestPlusCclPoolId() {
		return usLDAndLocalBestPlusCclPoolId;
	}

	public void setUsLDAndLocalBestPlusCclPoolId(String usLDAndLocalBestPlusCclPoolId) {
		this.usLDAndLocalBestPlusCclPoolId = usLDAndLocalBestPlusCclPoolId;
	}

	public String getUsLDOnlyBestPlusPool() {
		return usLDOnlyBestPlusPool;
	}

	public void setUsLDOnlyBestPlusPool(String usLDOnlyBestPlusPool) {
		this.usLDOnlyBestPlusPool = usLDOnlyBestPlusPool;
	}

	public String getUsLDOnlyBestPlusCclPool() {
		return usLDOnlyBestPlusCclPool;
	}

	public void setUsLDOnlyBestPlusCclPool(String usLDOnlyBestPlusCclPool) {
		this.usLDOnlyBestPlusCclPool = usLDOnlyBestPlusCclPool;
	}

	public String getUsLDOnlyBestPlusPoolId() {
		return usLDOnlyBestPlusPoolId;
	}

	public void setUsLDOnlyBestPlusPoolId(String usLDOnlyBestPlusPoolId) {
		this.usLDOnlyBestPlusPoolId = usLDOnlyBestPlusPoolId;
	}

	public String getUsLDOnlyBestPlusCclPoolId() {
		return usLDOnlyBestPlusCclPoolId;
	}

	public void setUsLDOnlyBestPlusCclPoolId(String usLDOnlyBestPlusCclPoolId) {
		this.usLDOnlyBestPlusCclPoolId = usLDOnlyBestPlusCclPoolId;
	}

	public String getEmeaApacBestPlusPool() {
		return emeaApacBestPlusPool;
	}

	public void setEmeaApacBestPlusPool(String emeaApacBestPlusPool) {
		this.emeaApacBestPlusPool = emeaApacBestPlusPool;
	}

	public String getEmeaApacBestPlusCclPool() {
		return emeaApacBestPlusCclPool;
	}

	public void setEmeaApacBestPlusCclPool(String emeaApacBestPlusCclPool) {
		this.emeaApacBestPlusCclPool = emeaApacBestPlusCclPool;
	}

	public String getEmeaApacBestPlusPoolId() {
		return emeaApacBestPlusPoolId;
	}

	public void setEmeaApacBestPlusPoolId(String emeaApacBestPlusPoolId) {
		this.emeaApacBestPlusPoolId = emeaApacBestPlusPoolId;
	}

	public String getEmeaApacBestPlusCclPoolId() {
		return emeaApacBestPlusCclPoolId;
	}

	public void setEmeaApacBestPlusCclPoolId(String emeaApacBestPlusCclPoolId) {
		this.emeaApacBestPlusCclPoolId = emeaApacBestPlusCclPoolId;
	}

	public Long getDesignId() {
		return designId;
	}

	public void setDesignId(Long designId) {
		this.designId = designId;
	}

	public String getCatalogVersionTime() {
		return catalogVersionTime;
	}

	public void setCatalogVersionTime(String catalogVersionTime) {
		this.catalogVersionTime = catalogVersionTime;
	}

	public String getViloTnMonthlyMinutes() {
		return viloTnMonthlyMinutes;
	}

	public void setViloTnMonthlyMinutes(String viloTnMonthlyMinutes) {
		this.viloTnMonthlyMinutes = viloTnMonthlyMinutes;
	}

	public String getViloTnMonthlyCCL() {
		return viloTnMonthlyCCL;
	}

	public void setViloTnMonthlyCCL(String viloTnMonthlyCCL) {
		this.viloTnMonthlyCCL = viloTnMonthlyCCL;
	}

	public String getTollFreeMonthlyMins() {
		return tollFreeMonthlyMins;
	}

	public void setTollFreeMonthlyMins(String tollFreeMonthlyMins) {
		this.tollFreeMonthlyMins = tollFreeMonthlyMins;
	}

	public String getTollFreeMonthlyCCL() {
		return tollFreeMonthlyCCL;
	}

	public void setTollFreeMonthlyCCL(String tollFreeMonthlyCCL) {
		this.tollFreeMonthlyCCL = tollFreeMonthlyCCL;
	}

	public String getUifnMonthlyMins() {
		return uifnMonthlyMins;
	}

	public void setUifnMonthlyMins(String uifnMonthlyMins) {
		this.uifnMonthlyMins = uifnMonthlyMins;
	}

	public String getUifnCCL() {
		return uifnCCL;
	}

	public void setUifnCCL(String uifnCCL) {
		this.uifnCCL = uifnCCL;
	}

	public String getItfsMins() {
		return itfsMins;
	}

	public void setItfsMins(String itfsMins) {
		this.itfsMins = itfsMins;
	}

	public String getMonthlyITFSCCL() {
		return monthlyITFSCCL;
	}

	public void setMonthlyITFSCCL(String monthlyITFSCCL) {
		this.monthlyITFSCCL = monthlyITFSCCL;
	}

	public String getViloPortingCustName() {
		return viloPortingCustName;
	}

	public void setViloPortingCustName(String viloPortingCustName) {
		this.viloPortingCustName = viloPortingCustName;
	}

	public Date getViloPortingAuthDate() {
		return viloPortingAuthDate;
	}

	public void setViloPortingAuthDate(Date viloPortingAuthDate) {
		this.viloPortingAuthDate = viloPortingAuthDate;
	}

	public String getViloTollFreePortingCustName() {
		return viloTollFreePortingCustName;
	}

	public void setViloTollFreePortingCustName(String viloTollFreePortingCustName) {
		this.viloTollFreePortingCustName = viloTollFreePortingCustName;
	}

	public Date getViloTollFreePortingAuthDate() {
		return viloTollFreePortingAuthDate;
	}

	public void setViloTollFreePortingAuthDate(Date viloTollFreePortingAuthDate) {
		this.viloTollFreePortingAuthDate = viloTollFreePortingAuthDate;
	}

	public String getUifnPortingCustName() {
		return uifnPortingCustName;
	}

	public void setUifnPortingCustName(String uifnPortingCustName) {
		this.uifnPortingCustName = uifnPortingCustName;
	}

	public Date getUifnPortingAuthDate() {
		return uifnPortingAuthDate;
	}

	public void setUifnPortingAuthDate(Date uifnPortingAuthDate) {
		this.uifnPortingAuthDate = uifnPortingAuthDate;
	}

	public String getItfsPortingCustName() {
		return itfsPortingCustName;
	}

	public void setItfsPortingCustName(String itfsPortingCustName) {
		this.itfsPortingCustName = itfsPortingCustName;
	}

	public Date getItfsPortingAuthDate() {
		return itfsPortingAuthDate;
	}

	public void setItfsPortingAuthDate(Date itfsPortingAuthDate) {
		this.itfsPortingAuthDate = itfsPortingAuthDate;
	}

	public String getCustomerDomain() {
		return CustomerDomain;
	}

	public void setCustomerDomain(String customerDomain) {
		CustomerDomain = customerDomain;
	}

	public String getItsfTNQuantity() {
		return itsfTNQuantity;
	}

	public void setItsfTNQuantity(String itsfTNQuantity) {
		this.itsfTNQuantity = itsfTNQuantity;
	}

	public String getUifnTNQuantity() {
		return uifnTNQuantity;
	}

	public void setUifnTNQuantity(String uifnTNQuantity) {
		this.uifnTNQuantity = uifnTNQuantity;
	}

	public String getViloTNQuantity() {
		return viloTNQuantity;
	}

	public void setViloTNQuantity(String viloTNQuantity) {
		this.viloTNQuantity = viloTNQuantity;
	}

	public String getInboundTNQuantity() {
		return inboundTNQuantity;
	}

	public void setInboundTNQuantity(String inboundTNQuantity) {
		this.inboundTNQuantity = inboundTNQuantity;
	}

	public Long getCummulativeCcl() {
		return cummulativeCcl;
	}

	public void setCummulativeCcl(Long cummulativeCcl) {
		this.cummulativeCcl = cummulativeCcl;
	}

	public Boolean getIpccCustOnChg() {
		return ipccCustOnChg;
	}

	public void setIpccCustOnChg(Boolean ipccCustOnChg) {
		this.ipccCustOnChg = ipccCustOnChg;
	}

	public String getParentEnterpriseId() {
		return parentEnterpriseId;
	}

	public void setParentEnterpriseId(String parentEnterpriseId) {
		this.parentEnterpriseId = parentEnterpriseId;
	}

	public Long getE2eiMigLock() {
		return e2eiMigLock;
	}

	public void setE2eiMigLock(Long e2eiMigLock) {
		this.e2eiMigLock = e2eiMigLock;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public void addAuthService(String service, Boolean authorised) {
		if (authServices == null)
			authServices = new HashMap<String, Boolean>();

		authServices.put(service, authorised);
	}

	public void addToSipDomains(String domain) {
		if (sipDomains == null)
			sipDomains = new HashSet<String>();

		if (!sipDomains.contains(domain))
			this.sipDomains.add(domain);
	}

	public OrderPlatformEnum getOrderPlatform() {
		return orderPlatform;
	}

	public void setOrderPlatform(OrderPlatformEnum orderPlatform) {
		this.orderPlatform = orderPlatform;
	}

	public VzbVoipEnums.EnterpriseTrunkingTypeEnum getEnterpriseTrunkingType() {
		return enterpriseTrunkingType;
	}

	public void setEnterpriseTrunkingType(VzbVoipEnums.EnterpriseTrunkingTypeEnum enterpriseTrunkingType) {
		this.enterpriseTrunkingType = enterpriseTrunkingType;
	}

	public boolean isIPCC() {
		if (null != productType && productType == VzbVoipEnum.ProductType.IPCCC) {
			return true;
		}
		return false;
	}

	public String getRegionTypeStr(CustomerEntity customer) {

		/*
		 * LOG.info(" Assign 6 In Customer Entity Region Type: {}",
		 * customer.getRegionType().intValue());
		 * LOG.info(" Assign 7 In Customer Entity Region Type Acronym: {}",
		 * VzbVoipEnum.RegionType.acronym(customer.getRegionType().intValue()));
		 */

		if (customer.getRegionType() == null)
			return null;
		else
			return VzbVoipEnum.RegionType.acronym(customer.getRegionType().intValue());
	}

	public String getBillingSystemStr() {
		if (billingSystem == null)
			return null;
		else
			return VzbVoipEnum.BillingSystemType.acronym(getBillingSystem().intValue());
	}

	public String getCentrexTypeStr() {
		if (centrexType == null)
			return null;
		else
			return VzbVoipEnum.CentrexType.acronym(getCentrexType().intValue());
	}

	public String getEnterpriseCclIndicatorStr() {
		if (enterpriseCclIndicator == null)
			return null;
		else
			return enterpriseCclIndicator ? "Y" : "N";
	}

	public String getTntCclIndStr() {
		if (tntCclInd == null)
			return null;
		else
			return tntCclInd ? "Y" : "N";
	}

	public String getIpccCustOnChgStr() {
		if (ipccCustOnChg == null)
			return null;
		else
			return ipccCustOnChg ? "Y" : "N";
	}

	public ArrayList<DigitString> getDigitStrings() {
		return digitStrings;
	}

	public void setDigitStrings(ArrayList<DigitString> digitStrings) {
		this.digitStrings = digitStrings;
	}

	public GCMInfo getGcmInfo() {
		return gcmInfo;
	}

	public void setGcmInfo(GCMInfo gcmInfo) {
		this.gcmInfo = gcmInfo;
	}

	public Boolean getSbcAutomation() {
		return sbcAutomation;
	}

	public void setSbcAutomation(Boolean sbcAutomation) {
		this.sbcAutomation = sbcAutomation;
	}

	public IPVersionEnum getIpVersion() {
		return ipVersion;
	}

	public void setIpVersion(IPVersionEnum ipVersion) {
		this.ipVersion = ipVersion;
	}

	public TsoMigrationEntReferenceData getTsoMigrationEntReferenceData() {
		return tsoMigrationEntReferenceData;
	}

	public void setTsoMigrationEntReferenceData(TsoMigrationEntReferenceData tsoMigrationEntReferenceData) {
		this.tsoMigrationEntReferenceData = tsoMigrationEntReferenceData;
	}

	public E2EIMigrationStatusEnum getE2eiMigStatus() {
		return e2eiMigStatus;
	}

	public void setE2eiMigStatus(E2EIMigrationStatusEnum e2eiMigStatus) {
		this.e2eiMigStatus = e2eiMigStatus;
	}

	public void setEnterpriseCclIndicatorStr(String enterpriseCclIndicatorStr) {
		this.enterpriseCclIndicatorStr = enterpriseCclIndicatorStr;
	}

	public void setTntCclIndStr(String tntCclIndStr) {
		this.tntCclIndStr = tntCclIndStr;
	}

	public String getAccountTeamFirstName() {
		return accountTeamFirstName;
	}

	public void setAccountTeamFirstName(String accountTeamFirstName) {
		this.accountTeamFirstName = accountTeamFirstName;
	}

	public String getAccountTeamLastName() {
		return accountTeamLastName;
	}

	public void setAccountTeamLastName(String accountTeamLastName) {
		this.accountTeamLastName = accountTeamLastName;
	}

	public String getAccountTeamCountryDialling() {
		return accountTeamCountryDialling;
	}

	public void setAccountTeamCountryDialling(String accountTeamCountryDialling) {
		this.accountTeamCountryDialling = accountTeamCountryDialling;
	}

	public String getAccountTeamAreaDialling() {
		return accountTeamAreaDialling;
	}

	public void setAccountTeamAreaDialling(String accountTeamAreaDialling) {
		this.accountTeamAreaDialling = accountTeamAreaDialling;
	}

	public String getAccountTeamDialNumber() {
		return accountTeamDialNumber;
	}

	public void setAccountTeamDialNumber(String accountTeamDialNumber) {
		this.accountTeamDialNumber = accountTeamDialNumber;
	}

	public String getCountryDialing() {
		return countryDialing;
	}

	public void setCountryDialing(String countryDialing) {
		this.countryDialing = countryDialing;
	}

	public String getDialNumber() {
		return dialNumber;
	}

	public void setDialNumber(String dialNumber) {
		this.dialNumber = dialNumber;
	}

	public String getAreaDialing() {
		return areaDialing;
	}

	public void setAreaDialing(String areaDialing) {
		this.areaDialing = areaDialing;
	}

	public String getE2EIFeatur() {
		return e2EIFeatur;
	}

	public void setE2EIFeatur(String e2eiFeatur) {
		e2EIFeatur = e2eiFeatur;
	}

	public String getNewEntId() {
		return newEntId;
	}

	public void setNewEntId(String newEntId) {
		this.newEntId = newEntId;
	}

	public String getAuthPbxUnReachableFeature() {
		return authPbxUnReachableFeature;
	}

	public void setAuthPbxUnReachableFeature(String authPbxUnReachableFeature) {
		this.authPbxUnReachableFeature = authPbxUnReachableFeature;
	}

	public String getAuthCFNR() {
		return authCFNR;
	}

	public void setAuthCFNR(String authCFNR) {
		this.authCFNR = authCFNR;
	}

	public String getNcaId() {
		return ncaId;
	}

	public void setNcaId(String ncaId) {
		this.ncaId = ncaId;
	}

	public String getEtRouteOverflowAuthorization() {
		return etRouteOverflowAuthorization;
	}

	public void setEtRouteOverflowAuthorization(String etRouteOverflowAuthorization) {
		this.etRouteOverflowAuthorization = etRouteOverflowAuthorization;
	}

	public String getUsagePlan() {
		return usagePlan;
	}

	public void setUsagePlan(String usagePlan) {
		this.usagePlan = usagePlan;
	}

	public String getNumberOfFreeMinutes() {
		return numberOfFreeMinutes;
	}

	public void setNumberOfFreeMinutes(String numberOfFreeMinutes) {
		this.numberOfFreeMinutes = numberOfFreeMinutes;
	}

	public String getRouteExhaust() {
		return routeExhaust;
	}

	public void setRouteExhaust(String routeExhaust) {
		this.routeExhaust = routeExhaust;
	}

	public String getE2EIFeature() {
		return e2EIFeature;
	}

	public void setE2EIFeature(String e2eiFeature) {
		e2EIFeature = e2eiFeature;
	}

	public String getBwEnterpriseId() {
		return bwEnterpriseId;
	}

	public void setBwEnterpriseId(String bwEnterpriseId) {
		this.bwEnterpriseId = bwEnterpriseId;
	}

	public String getVoiceVpn() {
		return voiceVpn;
	}

	public void setVoiceVpn(String voiceVpn) {
		this.voiceVpn = voiceVpn;
	}

	public SolutionType getSolutionType() {
		return solutionType;
	}

	public void setSolutionType(SolutionType solutionType) {
		this.solutionType = solutionType;
	}

	public Boolean getEnableEnterpriseExtensionDialing() {
		return enableEnterpriseExtensionDialing;
	}

	public void setEnableEnterpriseExtensionDialing(Boolean enableEnterpriseExtensionDialing) {
		this.enableEnterpriseExtensionDialing = enableEnterpriseExtensionDialing;
	}

	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	public AuthFeatureType getAuthFeatureType() {
		return authFeatureType;
	}

	public void setAuthFeatureType(AuthFeatureType authFeatureType) {
		this.authFeatureType = authFeatureType;
	}

	public long getEnvOrderId() {
		return envOrderId;
	}

	public void setEnvOrderId(long envOrderId) {
		this.envOrderId = envOrderId;
	}

	public long getInternalOrderId() {
		return internalOrderId;
	}

	public void setInternalOrderId(long internalOrderId) {
		this.internalOrderId = internalOrderId;
	}

	public String getProvisionCategory() {
		return provisionCategory;
	}

	public void setProvisionCategory(String provisionCategory) {
		this.provisionCategory = provisionCategory;
	}
	
	public List<AuthService> getAuthService() {
		return authService;
	}

	public void setAuthService(List<AuthService> authService) {
		this.authService = authService;
	}
	
	public void prepareAuthService(String name, String featureQuantity, Boolean authorise) {
		if(authService == null)
			authService = new ArrayList<>();
		
		AuthService authService1= new AuthService();
		authService1.setName(name);
		authService1.setFeatureQuantity(featureQuantity);
		authService1.setAuthorise(authorise);
		
		authService.add(authService1);
	}
	
	public String getAsClli() {
		return asClli;
	}

	public void setAsClli(String asClli) {
		this.asClli = asClli;
	}
}
