package com.vz.esap.translation.order.transformer;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.vz.esap.translation.dao.model.TblOrderDetails;
import com.vz.esap.translation.entity.EnterpriseTrunkEntity;
import com.vz.esap.translation.entity.ParamInfo;
import com.vz.esap.translation.entity.TrunkGroupEntity;
import com.vz.esap.translation.enums.EsapEnum.SolutionType;
import com.vz.esap.translation.exception.ApplicationInterfaceException;
import com.vz.esap.translation.exception.GenericException;
import com.vz.esap.translation.exception.TranslatorException;
import com.vz.esap.translation.exception.TranslatorException.ErrorCode;
import com.vz.esap.translation.order.dao.VOIPOrderDao;
import com.vz.esap.translation.order.model.request.VOIPOrderRequest;
import com.vz.esap.translation.order.service.helper.OrderServiceHelper;

/**
 * @author chattni
 *
 */
@Component
public class EnterpriseTrunkTransformerImpl implements EnterpriseTrunkTransformer {
	@Autowired
	private VOIPOrderDao voipOrderDao;

	@Autowired
	private ParamInfoTransformer paramInfoTransformer;

	@Autowired
	private OrderServiceHelper orderServiceHelper;

	private static final Logger LOG = LoggerFactory.getLogger(EnterpriseTrunkTransformerImpl.class);

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.vz.esap.translation.order.transformer.EnterpriseTrunkTransformer#
	 * transformOrderDetailsToEnterpriseTrunk(long, long, java.lang.String, boolean)
	 */
	@Override
	public EnterpriseTrunkEntity transformOrderDetailsToEnterpriseTrunk(long orderId, long parentId, String action,
			boolean delta, List<String> paramActionExclusionList) throws TranslatorException {
		LOG.info("In transformOrderDetailsToEnterpriseTrunk ordId:{} parentId:{} action:{} delta:{}", orderId, parentId,
				action, delta);
		EnterpriseTrunkEntity enterpriseTrunkEntity = null;
		TblOrderDetails tblOrderDetails = null;
		List<TblOrderDetails> ordDetails = null;
		ParamInfo root = null;

		try {

			tblOrderDetails = new TblOrderDetails();
			tblOrderDetails.setOrderId(orderId);
			tblOrderDetails.setAction(action);
			tblOrderDetails.setParentId(parentId);

			ordDetails = voipOrderDao.getOrderDetailsWithActionAndParent(parentId, action, delta, null,
					tblOrderDetails);

			LOG.info("List Size:{}", ordDetails.size());
			root = new ParamInfo("Root", null, null);
			root = paramInfoTransformer.transformOrderDetailsToParamInfo(ordDetails, root, 0, null);
			LOG.debug("ET : root : {} ", root);

			enterpriseTrunkEntity = createEnterpriseTrunkFromParamInfo(root, null, paramActionExclusionList);

		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new TranslatorException(ErrorCode.TRANSFORMER_FAILURE,
					"Exception occured in transformOrderDetailsToEnterpriseTrunk");
		}
		LOG.info("Exit transformOrderDetailsToEnterpriseTrunk");
		return enterpriseTrunkEntity;
	}

	/**
	 * @param parent
	 * @param eTrunk
	 * @return eTrunk
	 * @throws TranslatorException
	 */
	private EnterpriseTrunkEntity createEnterpriseTrunkFromParamInfo(ParamInfo parent, EnterpriseTrunkEntity eTrunk, List<String> paramActionExclusionList)
			throws TranslatorException {
		LOG.info("Exit createEnterpriseTrunkFromParamInfo");

		try {
			if (eTrunk == null) {
				eTrunk = new EnterpriseTrunkEntity();
			}
			if (parent.getChildParams() == null) {
				return eTrunk;
			}
			for (ParamInfo param : parent.getChildParams()) {
				LOG.debug("Name:{} ,  Value:{} ", param.getName(), param.getValue());
				
				if (paramActionExclusionList != null && !paramActionExclusionList.isEmpty()) {
					boolean skip = false;

					for (String exclude : paramActionExclusionList) {
						exclude = paramInfoTransformer.translateTODActToPIAct(exclude);

						if (exclude.equalsIgnoreCase(param.getAction())) {
							LOG.info("Param Excluded = {} For Actual Action = {} , The Excluding Action = {}",
									param.getName(), param.getAction(), exclude);
							skip = true;
						}
					}
					if (skip)
						continue;
				}

				if (eTrunk == null) {
					eTrunk = new EnterpriseTrunkEntity();
				}

				if (param.getName().equals("EnterpriseTrunkId")) {
					eTrunk.setEnterpriseTrunkId(Long.parseLong(param.getValue()));
				} else if (param.getName().equals("EnterpriseTrunkName")) {
					eTrunk.setEnterpriseTrunkName(param.getValue());
				} else if (param.getName().equals("CustomerId")) {
					eTrunk.setCustomerId(param.getValue());
				} else if (param.getName().equals("MaxRerouteAttempts")) {
					eTrunk.setMaxRerouteAttempts(Integer.parseInt(param.getValue()));
				} else if (param.getName().equals("MaxRerouteAttemptsPriority")) {
					eTrunk.setMaxRerouteAttemptsPriority(Integer.parseInt(param.getValue()));
				} else if (param.getName().equals("RouteExhaustAction")) {
					eTrunk.setRouteExhaustAction(param.getValue());
				} else if (param.getName().equals("RouteExhaustForwardTN")) {
					eTrunk.setRouteExhaustForwardTN(param.getValue());
				} else if (param.getName().equals("AdditionalAttribs")) {
					if (param.getChildParams() != null) {
						for (ParamInfo par2 : param.getChildParams()) {
							eTrunk.addAttrib(par2.getName(), par2.getValue());
						}
					}
				}
				// XO Changes
				else if (param.getName().equals("BWEnterpriseId")) {
					eTrunk.setBwEntId(param.getValue());
				} else if (param.getName().equals("BWEnterpriseTrunkId")) {
					eTrunk.setBwEtId(param.getValue());
				} else if (param.getName().equals("EnterpriseTrunkType")) {
					eTrunk.setEtType(param.getValue());
				} else if (param.getName().equals("TrunkGroupId")) {
					eTrunk.setBwTrunkGroupId(param.getValue());
				} else if (param.getName().equals("OrderingAlgorithm")) {
					eTrunk.setOrderingAlgorithm(param.getValue());
				} else if (param.getName().equals("SignalingDirection")) {
					eTrunk.setSignalDirection(param.getValue());
					eTrunk.setEtType(param.getValue());
				} else if (param.getName().equals("SolutionType")) {
					eTrunk.setSolutionType(SolutionType.valueOf(param.getValue()));
				} else if (param.getName().equals("Region")) {
					eTrunk.setRegion(param.getValue());
				} else if (param.getName().equals("ProvisionCategory")) {
					eTrunk.setProvisionCategory(param.getValue());
				} else if (param.getName().equals("RedundancyPriorityType")) {
					eTrunk.setRedundancyPriorityType(param.getValue());
				} else if (param.getName().equals("AsClli")) {
					eTrunk.setAsClli(param.getValue());
				}

				// XO Changes
			}
		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new TranslatorException(ErrorCode.TRANSFORMER_FAILURE,
					"Exception occured in createEnterpriseTrunkFromParamInfo");
		}
		LOG.info("Exit createEnterpriseTrunkFromParamInfo");
		return eTrunk;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.vz.esap.translation.order.transformer.EnterpriseTrunkTransformer#
	 * copyEtDelta(com.vz.esap.translation.entity.EnterpriseTrunkEntity)
	 */
	@Override
	public EnterpriseTrunkEntity copyEtDelta(EnterpriseTrunkEntity enterpriseTrunkEntity) {
		LOG.info("Entered copyEtDelta");
		EnterpriseTrunkEntity et = new EnterpriseTrunkEntity();

		if (enterpriseTrunkEntity.getEnterpriseTrunkId() != null)
			et.setEnterpriseTrunkId(enterpriseTrunkEntity.getEnterpriseTrunkId());
		if (enterpriseTrunkEntity.getEnterpriseTrunkName() != null)
			et.setEnterpriseTrunkName(enterpriseTrunkEntity.getEnterpriseTrunkName());
		if (enterpriseTrunkEntity.getMaxRerouteAttempts() != null)
			et.setMaxRerouteAttempts(enterpriseTrunkEntity.getMaxRerouteAttempts());
		if (enterpriseTrunkEntity.getMaxRerouteAttemptsPriority() != null)
			et.setMaxRerouteAttemptsPriority(enterpriseTrunkEntity.getMaxRerouteAttemptsPriority());
		if (enterpriseTrunkEntity.getCustomerId() != null)
			et.setCustomerId(enterpriseTrunkEntity.getCustomerId());
		if (enterpriseTrunkEntity.getRouteExhaustAction() != null)
			et.setRouteExhaustAction(enterpriseTrunkEntity.getRouteExhaustAction());
		if (enterpriseTrunkEntity.getRouteExhaustForwardTN() != null)
			et.setRouteExhaustForwardTN(enterpriseTrunkEntity.getRouteExhaustForwardTN());

		LOG.info("Exit copyEtDelta");
		return et;
	}

	@Override
	public EnterpriseTrunkEntity enrichEnterpriseTrunkEntityWithInventory(VOIPOrderRequest voipOrderRequest,
			EnterpriseTrunkEntity enterpriseTrunkEntity)
			throws TranslatorException, GenericException, IllegalAccessException, ApplicationInterfaceException {
		LOG.info("Entered enrichEnterpriseTrunkEntityWithInventory");

		EnterpriseTrunkEntity enterpriseTrunkEntityInv = orderServiceHelper
				.getEntityDetailsFromInventory(enterpriseTrunkEntity.getEnterpriseTrunkId() != null
						? String.valueOf(enterpriseTrunkEntity.getEnterpriseTrunkId())
						: null, EnterpriseTrunkEntity.class);

		// Copying Location Inv Details to Original Location Entity

		LOG.debug("++Level 10+++++Original trunkGrp Entity : {} ", enterpriseTrunkEntity);

		LOG.debug("++Level 10+++++Changed trunkGrp Entity : {} ", enterpriseTrunkEntity.getEnterpriseTrunkEntity());

		LOG.debug("++Level 10+++++Original trunkGrp Entity enterpriseTrunkEntityInv : {} ", enterpriseTrunkEntityInv);

		LOG.debug("++Level 10+++++Changed trunkGrp Entity enterpriseTrunkEntityInv.getenterpriseTrunkEntity() : {} ",
				enterpriseTrunkEntityInv.getEnterpriseTrunkEntity());

		enterpriseTrunkEntity = copyFields(enterpriseTrunkEntityInv, enterpriseTrunkEntity);

		LOG.debug("++Level 11+++++Original trunkGrp Entity : {} ", enterpriseTrunkEntity);

		LOG.debug("++Level 11+++++Changed trunkGrp Entity : {} ", enterpriseTrunkEntity.getEnterpriseTrunkEntity());

		if (enterpriseTrunkEntity.getEnterpriseTrunkEntity() != null) {
			EnterpriseTrunkEntity enterpriseTrunkEntityChanged = enterpriseTrunkEntity.getEnterpriseTrunkEntity();

			// Copying Location Inv Details to Changed Location Entity
			copyFields(enterpriseTrunkEntity, enterpriseTrunkEntityChanged);

			LOG.debug("++Level 3+++++Original trunkGrp Entity : {} ", enterpriseTrunkEntity);

			LOG.debug("++Level 3+++++Changed trunkGrp Entity : {} ", enterpriseTrunkEntity.getEnterpriseTrunkEntity());

		}

		LOG.info("Exit enrichEnterpriseTrunkEntityWithInventory Enterprise Trunk Enriched = {} ",
				enterpriseTrunkEntity);
		return enterpriseTrunkEntity;
	}
	
	private EnterpriseTrunkEntity copyFields(EnterpriseTrunkEntity currentETEntity, EnterpriseTrunkEntity resultETEntity) {
		
		// Inventory -> original
		if (resultETEntity.getEnterpriseTrunkId() == null && currentETEntity.getEnterpriseTrunkId() != null) {
			resultETEntity.setEnterpriseTrunkId(currentETEntity.getEnterpriseTrunkId());
		}
		if (resultETEntity.getEnterpriseTrunkName() == null && currentETEntity.getEnterpriseTrunkName() != null) {
			resultETEntity.setEnterpriseTrunkName(currentETEntity.getEnterpriseTrunkName());
		}
		if (resultETEntity.getCustomerId() == null && currentETEntity.getCustomerId() != null) {
			resultETEntity.setCustomerId(currentETEntity.getCustomerId());
		}
		if (resultETEntity.getMaxRerouteAttempts() == null && currentETEntity.getMaxRerouteAttempts() != null) {
			resultETEntity.setMaxRerouteAttempts(currentETEntity.getMaxRerouteAttempts());
		}
		if (resultETEntity.getMaxRerouteAttemptsPriority() == null && currentETEntity.getMaxRerouteAttemptsPriority() != null) {
			resultETEntity.setMaxRerouteAttemptsPriority(currentETEntity.getMaxRerouteAttemptsPriority());
		}
		if (resultETEntity.getRouteExhaustAction() == null && currentETEntity.getRouteExhaustAction() != null) {
			resultETEntity.setRouteExhaustAction(currentETEntity.getRouteExhaustAction());
		}
		if (resultETEntity.getRouteExhaustForwardTN() == null && currentETEntity.getRouteExhaustForwardTN() != null) {
			resultETEntity.setRouteExhaustForwardTN(currentETEntity.getRouteExhaustForwardTN());
		}
		if (resultETEntity.getBwEntId() == null && currentETEntity.getBwEntId() != null) {
			resultETEntity.setBwEntId(currentETEntity.getBwEntId());
		}
		if (resultETEntity.getEtType() == null && currentETEntity.getEtType() != null) {
			resultETEntity.setEtType(currentETEntity.getEtType());
		}
		if (resultETEntity.getBwTrunkGroupId() == null && currentETEntity.getBwTrunkGroupId() != null) {
			resultETEntity.setBwTrunkGroupId(currentETEntity.getBwTrunkGroupId());
		}
		if (resultETEntity.getOrderingAlgorithm() == null && currentETEntity.getOrderingAlgorithm() != null) {
			resultETEntity.setOrderingAlgorithm(currentETEntity.getOrderingAlgorithm());
		}
		if (resultETEntity.getSignalDirection() == null && currentETEntity.getSignalDirection() != null) {
			resultETEntity.setSignalDirection(currentETEntity.getSignalDirection());
		}
		if (resultETEntity.getEtType() == null && currentETEntity.getEtType() != null) {
			resultETEntity.setEtType(currentETEntity.getEtType());
		}
		if (resultETEntity.getSolutionType() == null && currentETEntity.getSolutionType() != null) {
			resultETEntity.setSolutionType(currentETEntity.getSolutionType());
		}
		if (resultETEntity.getRegion() == null && currentETEntity.getRegion() != null) {
			resultETEntity.setRegion(currentETEntity.getRegion());
		}
		if (resultETEntity.getBwEtId() == null && currentETEntity.getBwEtId() != null) {
			resultETEntity.setBwEtId(currentETEntity.getBwEtId());
		}

		return resultETEntity;
	}

	@Override
	public EnterpriseTrunkEntity enterpriseTrunkInventoryToEnterpriseTrunkEntityTransformer(
			Map<String, String> resultantRow) {
		// TODO Auto-generated method stub
		
		EnterpriseTrunkEntity   enterpriseTrunkEntity=new EnterpriseTrunkEntity();
		
		enterpriseTrunkEntity.setEnterpriseTrunkId(resultantRow.get("ENTERPRISE_TRUNK_ID") != null ? Long.valueOf(resultantRow.get("ENTERPRISE_TRUNK_ID")) : null);
		enterpriseTrunkEntity.setEnterpriseTrunkName((resultantRow.get("ENTERPRISE_TRUNK_ID")));
		enterpriseTrunkEntity.setCustomerId(resultantRow.get("CUSTOMER_ID"));
		enterpriseTrunkEntity.setBwTrunkGroupId(resultantRow.get("TRUNKGROUPID"));
		enterpriseTrunkEntity.setBwEntId(resultantRow.get("BWENTERPRISEID"));
		enterpriseTrunkEntity.setEtType(resultantRow.get("ENTERPRISETRUNKTYPE"));
		enterpriseTrunkEntity.setBwEtId(resultantRow.get("BWENTERPRISETRUNKID"));
		enterpriseTrunkEntity.setMaxRerouteAttempts(resultantRow.get("MAXREROUTEATTEMPTS") != null ? Integer.valueOf(resultantRow.get("MAXREROUTEATTEMPTS")) : null);
		enterpriseTrunkEntity.setRouteExhaustAction(resultantRow.get("ROUTEEXHAUSTIONACTION"));
		enterpriseTrunkEntity.setOrderingAlgorithm(resultantRow.get("ORDERINGALGORITHM"));
		enterpriseTrunkEntity.setEnterpriseTrunkName(resultantRow.get("TRUNKGROUPNAME"));
		enterpriseTrunkEntity.setOrderingAlgorithm(resultantRow.get("REDUNDENCY"));
		enterpriseTrunkEntity.setOrderingAlgorithm(resultantRow.get("REDUNDANCY_PRIORITY_TYPE"));
		return enterpriseTrunkEntity;
	}

}
