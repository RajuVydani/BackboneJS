/**
 * 
 */
package com.vz.esap.translation.order.model.request;

/**
 * @author mancsh2
 *
 */
public interface GCMInfoType {

	/**
	 * Gets the value of the PricingInfo property.
	 *
	 * <p>
	 * This accessor method returns a reference to the live list, not a snapshot.
	 * Therefore any modification you make to the returned list will be present
	 * inside the JAXB object. This is why there is not a <CODE>set</CODE> method
	 * for the PricingInfo property.
	 *
	 * <p>
	 * For example, to add a new item, do as follows:
	 * 
	 * <pre>
	 * getPricingInfo().add(newItem);
	 * </pre>
	 *
	 *
	 * <p>
	 * Objects of the following type(s) are allowed in the list
	 * {@link E2EIPCESAPInterface.PricingInfoType}
	 *
	 */
	java.util.List getPricingInfo();

	/**
	 * Gets the value of the quoteId property.
	 *
	 * @return possible object is {@link java.lang.String}
	 */
	java.lang.String getQuoteId();

	/**
	 * Sets the value of the quoteId property.
	 *
	 * @param value
	 *            allowed object is {@link java.lang.String}
	 */
	void setQuoteId(java.lang.String value);

	/**
	 * Gets the value of the customerPriceBookId property.
	 *
	 * @return possible object is {@link java.lang.String}
	 */
	java.lang.String getCustomerPriceBookId();

	/**
	 * Sets the value of the customerPriceBookId property.
	 *
	 * @param value
	 *            allowed object is {@link java.lang.String}
	 */
	void setCustomerPriceBookId(java.lang.String value);

	/**
	 * Gets the value of the contractId property.
	 *
	 * @return possible object is {@link java.lang.String}
	 */
	java.lang.String getContractId();

	/**
	 * Sets the value of the contractId property.
	 *
	 * @param value
	 *            allowed object is {@link java.lang.String}
	 */
	void setContractId(java.lang.String value);

	/**
	 * Gets the value of the productIdentifier property.
	 *
	 * @return possible object is {@link java.lang.String}
	 */
	java.lang.String getProductIdentifier();

	/**
	 * Sets the value of the productIdentifier property.
	 *
	 * @param value
	 *            allowed object is {@link java.lang.String}
	 */
	void setProductIdentifier(java.lang.String value);

}
