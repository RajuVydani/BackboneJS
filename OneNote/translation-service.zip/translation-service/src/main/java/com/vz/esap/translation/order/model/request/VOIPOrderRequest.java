package com.vz.esap.translation.order.model.request;

public class VOIPOrderRequest {

	private long sequenceNumber;
	private VerificationData VerificationData;

	public VerificationData getVerificationData() {
		return VerificationData;
	}

	public void setVerificationData(VerificationData VerificationData) {
		this.VerificationData = VerificationData;
	}

	public PortingInfo[] getPortingInfo() {
		return PortingInfo;
	}

	public void setPortingInfo(PortingInfo[] PortingInfo) {
		this.PortingInfo = PortingInfo;
	}

	public RouterConfig[] getRouterConfig() {
		return RouterConfig;
	}

	public void setRouterConfig(RouterConfig[] RouterConfig) {
		this.RouterConfig = RouterConfig;
	}

	public AdditionalInfo getAdditionalInfo() {
		return AdditionalInfo;
	}

	public void setAdditionalInfo(AdditionalInfo AdditionalInfo) {
		this.AdditionalInfo = AdditionalInfo;
	}

	public Location getLocation() {
		return Location;
	}

	public void setLocation(Location Location) {
		this.Location = Location;
	}

	public CircuitInfo[] getCircuitInfo() {
		return CircuitInfo;
	}

	public void setCircuitInfo(CircuitInfo[] CircuitInfo) {
		this.CircuitInfo = CircuitInfo;
	}

	public ConvergedService getConvergedService() {
		return ConvergedService;
	}

	public void setConvergedService(ConvergedService ConvergedService) {
		this.ConvergedService = ConvergedService;
	}

	public OrderHeader getOrderHeader() {
		return OrderHeader;
	}

	public void setOrderHeader(OrderHeader OrderHeader) {
		this.OrderHeader = OrderHeader;
	}

	public ChangeManagement[] getChangeManagement() {
		return ChangeManagement;
	}

	public void setChangeManagement(ChangeManagement[] ChangeManagement) {
		this.ChangeManagement = ChangeManagement;
	}

	private PortingInfo[] PortingInfo;

	private RouterConfig[] RouterConfig;

	private AdditionalInfo AdditionalInfo;

	private Location Location;

	private CircuitInfo[] CircuitInfo;

	private ConvergedService ConvergedService;

	private OrderHeader OrderHeader;

	private NBSConfig NBSConfig;

	private CircuitInfo circuitInfoObj;

	private ChangeManagement[] ChangeManagement;

	private Customer Customer;

	private TnActivation tnActivation;

	public String toString() {
		return "ClassPojo [VerificationData = " + VerificationData + ", PortingInfo = " + PortingInfo
				+ ", RouterConfig = " + RouterConfig + ", AdditionalInfo = " + AdditionalInfo + ", Location = "
				+ Location + ", CircuitInfo = " + CircuitInfo + ", ConvergedService = " + ConvergedService
				+ ", OrderHeader = " + OrderHeader + ", ChangeManagement = " + ChangeManagement + "]";
	}

	/**
	 * @return the sequenceNumber
	 */
	public long getSequenceNumber() {
		return sequenceNumber;
	}

	/**
	 * @param sequenceNumber
	 *            the sequenceNumber to set
	 */
	public void setSequenceNumber(long sequenceNumber) {
		this.sequenceNumber = sequenceNumber;
	}

	public NBSConfig getNbsConfig() {
		return NBSConfig;
	}

	public void setNbsConfig(NBSConfig nbsConfig) {
		this.NBSConfig = nbsConfig;
	}

	public CircuitInfo getCircuitInfoObj() {
		return circuitInfoObj;
	}

	public Customer getCustomer() {
		return Customer;
	}

	public void setCustomer(Customer customer) {
		Customer = customer;
	}

	public void setCircuitInfoObj(CircuitInfo circuitInfoObj) {
		this.circuitInfoObj = circuitInfoObj;
	}

	public NBSConfig getNBSConfig() {
		return NBSConfig;
	}

	public void setNBSConfig(NBSConfig nBSConfig) {
		NBSConfig = nBSConfig;
	}

	public TnActivation getTnActivation() {
		return tnActivation;
	}

	public void setTnActivation(TnActivation tnActivation) {
		this.tnActivation = tnActivation;
	}
}