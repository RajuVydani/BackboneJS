package com.vz.esap.translation.order.model.request;

public class OrderManagerContact {

	private String ContactLastName;

	private String ContactFirstName;

	private Communication[] Communication;

	private String ContactComments;

	public String getContactLastName() {
		return ContactLastName;
	}

	public void setContactLastName(String ContactLastName) {
		this.ContactLastName = ContactLastName;
	}

	public String getContactFirstName() {
		return ContactFirstName;
	}

	public void setContactFirstName(String ContactFirstName) {
		this.ContactFirstName = ContactFirstName;
	}

	public Communication[] getCommunication() {
		return Communication;
	}

	public void setCommunication(Communication[] Communication) {
		this.Communication = Communication;
	}

	public String getContactComments() {
		return ContactComments;
	}

	public void setContactComments(String ContactComments) {
		this.ContactComments = ContactComments;
	}

	public String toString() {
		return "ClassPojo [ContactLastName = " + ContactLastName + ", ContactFirstName = " + ContactFirstName
				+ ", Communication = " + Communication + ", ContactComments = " + ContactComments + "]";
	}
}
