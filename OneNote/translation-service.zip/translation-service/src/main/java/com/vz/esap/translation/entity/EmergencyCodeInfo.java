package com.vz.esap.translation.entity;

public class EmergencyCodeInfo {
	private String emergencyNumber;
	private String emergencyCode;

	public String getEmergencyNumber() {
		return emergencyNumber;
	}

	public void setEmergencyNumber(String emergencyNumber) {
		this.emergencyNumber = emergencyNumber;
	}

	public String getEmergencyCode() {
		return emergencyCode;
	}

	public void setEmergencyCode(String emergencyCode) {
		this.emergencyCode = emergencyCode;
	}

	public ParamInfo getParamInfo(String action) {
		ParamInfo emerCodeInfo = new ParamInfo("EmergencyCodeInfo", null,
				action);
		emerCodeInfo.addNotNullValChild("EmerMappingCode", emergencyCode,
				action);
		emerCodeInfo.addNotNullValChild("EmergencyNumber", emergencyNumber,
				action);
		return emerCodeInfo;
	}

	public ParamInfo getChangeParam(EmergencyCodeInfo oldEmerInfo, boolean supp) {
		ParamInfo emerInfoParam = new ParamInfo("EmergencyCodeInfo", null, null);
		emerInfoParam.addChangeParam("EmerMappingCode",
				oldEmerInfo.getEmergencyCode(), emergencyCode, supp);
		emerInfoParam.addChangeParam("EmergencyNumber",
				oldEmerInfo.getEmergencyNumber(), emergencyNumber, supp);
		return emerInfoParam;
	}

	public static EmergencyCodeInfo createInstanceFromParamInfo(ParamInfo param) {
		EmergencyCodeInfo emerInfo = null;
		if (param != null && param.getChildParams() != null) {
			emerInfo = new EmergencyCodeInfo();
			for (ParamInfo childParam : param.getChildParams()) {
				if (childParam.getName().equals("EmerMappingCode")) {
					emerInfo.setEmergencyCode(childParam.getValue());
				} else if (childParam.getName().equals("EmergencyNumber")) {
					emerInfo.setEmergencyNumber(childParam.getValue());
				}
			}
		}
		return emerInfo;
	}
} // EOF
