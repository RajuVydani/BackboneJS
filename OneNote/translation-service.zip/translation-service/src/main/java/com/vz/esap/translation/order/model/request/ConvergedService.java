package com.vz.esap.translation.order.model.request;

public class ConvergedService {

	private String Name;

	private String CatalogVersionTime;

	private String Type;

	private String ID;

	private Specification[] Specification;

	private Feature[] Feature;

	public String getName() {
		return Name;
	}

	public void setName(String Name) {
		this.Name = Name;
	}

	public String getCatalogVersionTime() {
		return CatalogVersionTime;
	}

	public void setCatalogVersionTime(String CatalogVersionTime) {
		this.CatalogVersionTime = CatalogVersionTime;
	}

	public String getType() {
		return Type;
	}

	public void setType(String Type) {
		this.Type = Type;
	}

	public String getID() {
		return ID;
	}

	public void setID(String ID) {
		this.ID = ID;
	}

	public Specification[] getSpecification() {
		return Specification;
	}

	public void setSpecification(Specification[] Specification) {

		this.Specification = Specification;
	}

	public Feature[] getFeature() {
		return Feature;
	}

	public void setFeature(Feature[] Feature) {
		this.Feature = Feature;
	}

	public String toString() {
		return "ClassPojo [Name = " + Name + ", CatalogVersionTime = " + CatalogVersionTime + ", Type = " + Type
				+ ", ID = " + ID + ", Specification = " + Specification + ", Feature = " + Feature + "]";
	}
}
