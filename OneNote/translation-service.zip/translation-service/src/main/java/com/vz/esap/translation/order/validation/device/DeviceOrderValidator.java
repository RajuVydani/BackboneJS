package com.vz.esap.translation.order.validation.device;

import java.util.List;

import com.vz.esap.translation.order.model.request.VOIPOrderRequest;

/**
 * @author kalagsu
 *
 */
public interface DeviceOrderValidator {

	/**
	 * @param voipOrderRequest
	 * @return missingFields
	 */
	List<String> validate(VOIPOrderRequest voipOrderRequest);
}
