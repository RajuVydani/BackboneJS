package com.vz.esap.translation.order.model.pc;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;

import com.fasterxml.jackson.annotation.JsonProperty;

@XmlAccessorType(XmlAccessType.FIELD)
public class Communication {
	
	@XmlElement(name = "AreaDialing")
	@JsonProperty(value = "AreaDialing")
	private String areaDialing;

	@XmlElement(name = "Extension")
	@JsonProperty(value = "Extension")
	private String extension;

	@XmlElement(name = "Channel")
	@JsonProperty(value = "Channel")
	private String channel;

	@XmlElement(name = "DialNumber")
	@JsonProperty(value = "DialNumber")
	private String dialNumber;

	@XmlElement(name = "CountryDialing")
	@JsonProperty(value = "CountryDialing")
	private String countryDialing;

	@XmlElement(name = "URI")
	@JsonProperty(value = "URI")
	private String uri;

	public String getAreaDialing() {
		return areaDialing;
	}

	public void setAreaDialing(String AreaDialing) {
		this.areaDialing = AreaDialing;
	}

	public String getExtension() {
		return extension;
	}

	public void setExtension(String Extension) {
		this.extension = Extension;
	}

	public String getChannel() {
		return channel;
	}

	public void setChannel(String Channel) {
		this.channel = Channel;
	}

	public String getDialNumber() {
		return dialNumber;
	}

	public void setDialNumber(String DialNumber) {
		this.dialNumber = DialNumber;
	}

	public String getCountryDialing() {
		return countryDialing;
	}

	public void setCountryDialing(String CountryDialing) {
		this.countryDialing = CountryDialing;
	}

	public String getURI() {
		return uri;
	}

	public void setURI(String URI) {
		this.uri = URI;
	}

	@Override
	public String toString() {
		return "ClassPojo [AreaDialing = " + areaDialing + ", Extension = " + extension + ", Channel = " + channel
				+ ", DialNumber = " + dialNumber + ", CountryDialing = " + countryDialing + ", URI = " + uri + "]";
	}
}
