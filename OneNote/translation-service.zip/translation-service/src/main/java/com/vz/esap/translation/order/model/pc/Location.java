package com.vz.esap.translation.order.model.pc;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;

import com.fasterxml.jackson.annotation.JsonProperty;

@XmlAccessorType(XmlAccessType.FIELD)
public class Location {

	@XmlElement(name = "Name")
	@JsonProperty(value = "Name")
	private String name;

	@XmlElement(name = "PrimaryLocationContact")
	@JsonProperty(value = "PrimaryLocationContact")
	private PrimaryLocationContact primaryLocationContact;

	@XmlElement(name = "ActionCode")
	@JsonProperty(value = "ActionCode")
	private String actionCode;

	@XmlElement(name = "Type")
	@JsonProperty(value = "Type")
	private String type;

	@XmlElement(name = "OrderManagerContact")
	@JsonProperty(value = "OrderManagerContact")
	private OrderManagerContact orderManagerContact;

	@XmlElement(name = "LocationAddress")
	@JsonProperty(value = "LocationAddress")
	private LocationAddress locationAddress;

	@XmlElement(name = "Id")
	@JsonProperty(value = "Id")
	private String id;

	@XmlElement(name = "SalesManagerContact")
	@JsonProperty(value = "SalesManagerContact")
	private SalesManagerContact salesManagerContact;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public PrimaryLocationContact getPrimaryLocationContact() {
		return primaryLocationContact;
	}

	public void setPrimaryLocationContact(
			PrimaryLocationContact primaryLocationContact) {
		this.primaryLocationContact = primaryLocationContact;
	}

	public String getActionCode() {
		return actionCode;
	}

	public void setActionCode(String actionCode) {
		this.actionCode = actionCode;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public OrderManagerContact getOrderManagerContact() {
		return orderManagerContact;
	}

	public void setOrderManagerContact(OrderManagerContact orderManagerContact) {
		this.orderManagerContact = orderManagerContact;
	}

	public LocationAddress getLocationAddress() {
		return locationAddress;
	}

	public void setLocationAddress(LocationAddress locationAddress) {
		this.locationAddress = locationAddress;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public SalesManagerContact getSalesManagerContact() {
		return salesManagerContact;
	}

	public void setSalesManagerContact(SalesManagerContact salesManagerContact) {
		this.salesManagerContact = salesManagerContact;
	}

	@Override
	public String toString() {
		return "ClassPojo [Name = " + name + ", PrimaryLocationContact = "
				+ primaryLocationContact + ", ActionCode = " + actionCode
				+ ", Type = " + type + ", OrderManagerContact = "
				+ orderManagerContact + ", LocationAddress = "
				+ locationAddress + ", Id = " + id + ", SalesManagerContact = "
				+ salesManagerContact + "]";
	}
}
