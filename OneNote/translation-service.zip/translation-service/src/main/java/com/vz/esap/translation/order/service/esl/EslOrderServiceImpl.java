package com.vz.esap.translation.order.service.esl;

import static java.util.Arrays.stream;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.vz.esap.translation.connector.model.DBServiceResponse;
import com.vz.esap.translation.constant.GenericConstant;
import com.vz.esap.translation.constant.TranslationConstant;
import com.vz.esap.translation.dao.model.TblEnvOrder;
import com.vz.esap.translation.dao.model.TblOrder;
import com.vz.esap.translation.dao.model.TblOrderDetails;
import com.vz.esap.translation.dao.model.TblSafeStore;
import com.vz.esap.translation.entity.LocationEntity;
import com.vz.esap.translation.entity.NbsEntity;
import com.vz.esap.translation.enums.EsapEnum.LocationType;
import com.vz.esap.translation.enums.EsapEnum.OrderEntity;
import com.vz.esap.translation.enums.EsapEnum.PcMilestone;
import com.vz.esap.translation.enums.EsapEnum.PcResponseType;
import com.vz.esap.translation.enums.EsapEnum.StatusCode;
import com.vz.esap.translation.exception.GenericException;
import com.vz.esap.translation.exception.TranslatorException;
import com.vz.esap.translation.exception.TranslatorException.ErrorCode;
import com.vz.esap.translation.order.dao.VOIPOrderDao;
import com.vz.esap.translation.order.model.request.Feature;
import com.vz.esap.translation.order.model.request.ParamInfo;
import com.vz.esap.translation.order.model.request.VOIPOrderRequest;
import com.vz.esap.translation.order.model.response.VoipOrderResponse;
import com.vz.esap.translation.order.parser.NbsOrderParser;
import com.vz.esap.translation.order.service.NotificationService;
import com.vz.esap.translation.order.service.OrderServiceBase;
import com.vz.esap.translation.order.service.VOIPResponseGenerator;
import com.vz.esap.translation.order.service.device.DeviceOrderService;
import com.vz.esap.translation.order.service.enterprise.EnterpriseOrderService;
import com.vz.esap.translation.order.service.enterprisetrunk.EnterpriseTrunkOrderService;
import com.vz.esap.translation.order.service.helper.OrderServiceHelper;
import com.vz.esap.translation.order.service.location.LocationOrderService;
import com.vz.esap.translation.order.service.nbs.NbsOrderServiceImpl;
import com.vz.esap.translation.order.service.trunk.TrunkOrderServiceImpl;
import com.vz.esap.translation.order.transformer.EnterpriseTblOrderServiceDataTransformer;
import com.vz.esap.translation.order.transformer.NbsTblOrderDetailsDataTransformerImpl;
import com.vz.esap.translation.order.transformer.TblSafeStoreTransformer;
import com.vz.esap.translation.order.transformer.VoipRequestTransformer;
import com.vz.esap.translation.util.InventoryUtil;
import com.vz.esap.translation.util.TranslationUtility;

import EsapEnumPkg.WorkOrderEnum;

/**
 * @author chattni
 *
 */
@Service
public class EslOrderServiceImpl extends OrderServiceBase implements EslOrderService {

	private static final Logger LOG = LoggerFactory.getLogger(EslOrderServiceImpl.class);

	private static final String NO = "N";

	@Autowired
	private VOIPOrderDao voipOrderDao;

	@Autowired
	private TblSafeStoreTransformer tblSafeStoreTransformer;

	@Autowired
	private OrderServiceHelper orderServiceHelperImpl;

	@Autowired
	private VOIPResponseGenerator voipResponseGenerator;

	@Autowired
	private VoipRequestTransformer voipRequestTransformerImpl;

	@Autowired
	private EnterpriseOrderService enterpriseOrderService;

	@Autowired
	private LocationOrderService locationOrderService;

	@Autowired
	private DeviceOrderService deviceOrderService;

	@Autowired
	private EnterpriseTrunkOrderService enterpriseTrunkOrderServiceImpl;

	@Autowired
	private TrunkOrderServiceImpl trunkOrderServiceImpl;

	@Autowired
	private NbsOrderServiceImpl nbsOrderServiceImpl;

	@Autowired
	private NbsTblOrderDetailsDataTransformerImpl nbsTblOrderDetailsDataTransformerImpl;

	@Autowired
	private NbsOrderParser nbsOrderParserImpl;

	@Autowired
	private NotificationService notificationServiceImpl;

	@Autowired
	private InventoryUtil inventoryUtil;

	@Autowired
	private EnterpriseTblOrderServiceDataTransformer enterpriseTblOrderServiceData;

	@Autowired
	private TranslationUtility translationUtility;
	
	private ObjectMapper mapper = new ObjectMapper();

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.vz.esap.translation.order.service.esl.EslOrderService#
	 * createEslEsipValidateOrder(com.vz.esap.translation.order.model.request.
	 * VOIPOrderRequest, java.util.Map)
	 */
	@Override
	public VoipOrderResponse createEslEsipValidateOrder(VOIPOrderRequest voipOrderRequest,
			Map<String, String> productDetails) throws GenericException, TranslatorException {
		LOG.info("Entered createEslEsipValidateOrder");
		VoipOrderResponse voipOrderResponse = null;
		DBServiceResponse dbServiceResponse = null;
		VOIPOrderRequest voipOrderGeneratedRequest = null;
		int version;
		List<Feature> features = null;
		boolean isNewEsipEnterprise = false;

		try {

			int orderVersion = Integer.parseInt(voipOrderRequest.getOrderHeader().getWorkOrderVersion());
			if (orderVersion > 0) {
				LOG.info("Handling supp orders whose previous orders in \"InProgress\" status.");
				orderServiceHelperImpl.handleOrdersInProgress(voipOrderRequest);
			}
			
			voipOrderRequest = translationUtility.setAsClli(voipOrderRequest);
			
			LOG.info("AsClli================================>>> {}", voipOrderRequest.getOrderHeader().getAsClli());

			if (voipOrderRequest.getOrderHeader().getGCHId() == null)
				throw new TranslatorException(ErrorCode.ESAP_MISSING_REQUIRED_DATA,
						"GCHID is not present in the request BOD");
			dbServiceResponse = orderServiceHelperImpl
					.getEnterpriseInformationFromGchId(voipOrderRequest.getOrderHeader().getGCHId(), voipOrderRequest);

			version = Integer.parseInt(voipOrderRequest.getOrderHeader().getWorkOrderVersion());

			isNewEsipEnterprise = orderServiceHelperImpl.isNewEsipEnterprise(voipOrderRequest, dbServiceResponse);

			// Install Not Supp
			if (dbServiceResponse != null && "I".equalsIgnoreCase(voipOrderRequest.getOrderHeader().getOrderType())) {

				// Install Brand New Customer Supp + V0
				if (version == 0 && isNewEsipEnterprise)// DONOT DELETE: dbServiceResponse.getNumberOfRecords() == 0
				{
					LOG.info("New Customer");
					// Enrich voipOrderRequest for install new Enterprise
					voipOrderGeneratedRequest = voipRequestTransformerImpl
							.enrichVoipRequestWithEnterprise(voipOrderRequest, productDetails, dbServiceResponse, true);
					voipOrderGeneratedRequest = voipRequestTransformerImpl.enrichVoipRequestWithEt(
							voipOrderGeneratedRequest, productDetails, dbServiceResponse, true);

					LOG.info("Voip Order Request Enriched Completely : {}",
							mapper.writerWithDefaultPrettyPrinter().writeValueAsString(voipOrderGeneratedRequest));

					voipOrderResponse = createEslEsipValidatePassOrder(voipOrderGeneratedRequest, true);
				}
				// Install Existing New Customer V0
				else {
					if (version == 0) // DONOT DELETE: dbServiceResponse.getNumberOfRecords() >
										// 0 && version == 0
					{
						LOG.info("Existing Customer");
						voipOrderGeneratedRequest = voipRequestTransformerImpl.modifyOrderHeader(voipOrderRequest,
								dbServiceResponse, false, productDetails);

						voipOrderGeneratedRequest = voipRequestTransformerImpl.enrichVoipRequestWithEt(
								voipOrderGeneratedRequest, productDetails, dbServiceResponse, false);

						voipOrderResponse = createEslEsipValidatePassOrder(voipOrderGeneratedRequest, false);
					}
					// Install Existing New Customer V>0
					else if (version > 0) // DONOT DELETE: dbServiceResponse.getNumberOfRecords() >
											// 0 && version > 0
					{
						LOG.info("Existing Customer For Supp");

						TblEnvOrder tblEnvOrder = voipOrderDao.getTblEnvOrderDetailsFromInventory(dbServiceResponse,
								TranslationConstant.TBL_ENTERPRISE);

						if (tblEnvOrder != null && tblEnvOrder.getOrderNumber()
								.equalsIgnoreCase(voipOrderRequest.getOrderHeader().getWorkOrderNumber())) {
							LOG.info("This Customer was created as the previous Version of Order");
							// Enrich voipOrderRequest for install new Enterprise
							voipOrderGeneratedRequest = voipRequestTransformerImpl.enrichVoipRequestWithEnterprise(
									voipOrderRequest, productDetails, dbServiceResponse, false);

							voipOrderGeneratedRequest = voipRequestTransformerImpl.enrichVoipRequestWithEt(
									voipOrderGeneratedRequest, productDetails, dbServiceResponse, false);

							LOG.info("Voip Order Request Enriched Completely : {}", mapper
									.writerWithDefaultPrettyPrinter().writeValueAsString(voipOrderGeneratedRequest));
						} else {
							//This loop is for same gchid and same vpn.
							LOG.info("Existing Customer::supp::Same VPN");
							voipOrderGeneratedRequest = voipRequestTransformerImpl
									.modifyOrderHeader(voipOrderRequest, dbServiceResponse, false, productDetails);
							
							voipOrderGeneratedRequest = voipRequestTransformerImpl.enrichVoipRequestWithEt(
									voipOrderGeneratedRequest, productDetails, dbServiceResponse, false);
						}

						voipOrderResponse = createEslEsipValidatePassOrder(voipOrderGeneratedRequest, false);
					}
				}
			} else if ("C".equalsIgnoreCase(voipOrderRequest.getOrderHeader().getOrderType())) {

				LOG.info("MAC Order");

				voipOrderGeneratedRequest = voipRequestTransformerImpl.modifyOrderHeader(voipOrderRequest,
						dbServiceResponse, false, productDetails);

				features = stream(voipOrderGeneratedRequest.getConvergedService().getFeature())
						.filter(feature -> "FET_XO_TRU".equalsIgnoreCase(feature.getCode()))
						.collect(Collectors.toList());

				if (!features.isEmpty()) {
					voipOrderGeneratedRequest = voipRequestTransformerImpl.enrichVoipRequestWithEt(
							voipOrderGeneratedRequest, productDetails, dbServiceResponse, false);
				}

				voipOrderResponse = createEslEsipValidatePassOrder(voipOrderGeneratedRequest, false);

			}

		} catch (TranslatorException ex) {
			LOG.error("Exception {} {} ", ex.getMessage(), ex);
			throw new TranslatorException(ex.getErrorCode(), ex.getMessage());
		} catch (Exception e) {

			notificationServiceImpl.notifyFailures(voipResponseGenerator.preparePCMilestone(voipOrderRequest,
					PcMilestone.ACTIVATION_COMPLETE.getValue(), StatusCode.ESP_FAILURE,
					PcResponseType.ORDER.getValue()));

			LOG.error("Exception {} {} ", e.getMessage(), e);
			throw new GenericException(GenericException.GENERIC_EXCEPTION, "Exception in the provide input arguments");
		}

		LOG.info("Exited createEslEsipValidateOrder");
		return voipOrderResponse;
	}

	/**
	 * @param voipOrderRequest
	 * @param isNewCustomer
	 * @return voipOrderResponse
	 * @throws GenericException
	 * @throws TranslatorException
	 */
	VoipOrderResponse createEslEsipValidatePassOrder(VOIPOrderRequest voipOrderRequest, boolean isNewCustomer)
			throws GenericException, TranslatorException {
		LOG.info("Entered createEslEsipValidatePassOrder");

		VoipOrderResponse voipOrderResponse = null;
		long sequenceNumber = -1;
		TblSafeStore tblSafeStoreObject = null;
		TblEnvOrder tblEnvOrderObject = null;
		TblOrder tblOrderObject = null;
		long detailCounts = -1;
		long serviceCounts = -1;
		String virtualAddrCountry = null;

		try {
			sequenceNumber = voipOrderRequest.getSequenceNumber();
			LOG.info("TblSafeOrder  SequenceNo : {}", sequenceNumber);

			// Update TblSafeStore
			tblSafeStoreObject = tblSafeStoreTransformer.prepareTblSafeStoreData(sequenceNumber);
			voipOrderDao.updateTblSafeStoreTranslationStartTime(tblSafeStoreObject);

			tblEnvOrderObject = orderServiceHelperImpl.createEsipEslEnvOrder(voipOrderRequest,
					WorkOrderEnum.Status.WO_RECV_SEGMENT);

			tblOrderObject = orderServiceHelperImpl.createEsipEslOrderHeader(voipOrderRequest,
					WorkOrderEnum.Status.WO_RECV_SEGMENT, tblEnvOrderObject);

			detailCounts = orderServiceHelperImpl.createEsipEslOrderDetails(voipOrderRequest, tblOrderObject,
					isNewCustomer);

			//ESVRRS-19513
			if ("C".equalsIgnoreCase(voipOrderRequest.getOrderHeader().getOrderType())) {
				translationUtility.populateEntityFlag(tblOrderObject);
			}
			//ESVRRS-19513
			
			if (voipOrderRequest.getLocation() != null && voipOrderRequest.getLocation().getLocationAddress() != null)
				virtualAddrCountry = voipOrderRequest.getLocation().getLocationAddress().getCountryCode();

			serviceCounts = orderServiceHelperImpl.createValidateOrderServices(tblOrderObject, virtualAddrCountry);

			voipOrderDao.updateTblEnvOrderStatus(tblEnvOrderObject.getEnvOrderId(), WorkOrderEnum.Status.WO_INIT);
			voipOrderDao.updateTblOrderStatus(tblOrderObject.getOrderId(), WorkOrderEnum.Status.WO_INIT);

			LOG.info("Info {}-{}", detailCounts, serviceCounts);

			voipOrderResponse = voipResponseGenerator.prepareSuccessOrderResponse(voipOrderRequest);
			LOG.info("Entered createEslEsipValidatePassOrder {}", voipOrderResponse.getOrderStatus());

		} catch (Exception te) {
			LOG.error("Exception {}", te);
			if (tblEnvOrderObject != null) {
				voipOrderDao.updateTblEnvOrderStatus(tblEnvOrderObject.getEnvOrderId(),
						WorkOrderEnum.Status.WO_TRANSLATION_FAIL);
				throw new TranslatorException(ErrorCode.ORDER_CREATION_FAILURE, "Failed to create Order");
			} else {
				throw new GenericException(GenericConstant.GENERIC_EXCEPTION, "Generic Exception has occured");
			}
		}

		LOG.info("Exited createEslEsipValidatePassOrder");
		return voipOrderResponse;

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.vz.esap.translation.order.service.esl.EslOrderService#
	 * createEslEsipReleaseOrder(com.vz.esap.translation.order.model.request.
	 * VOIPOrderRequest, java.util.Map)
	 */
	@Override
	public VoipOrderResponse createEslEsipReleaseOrder(VOIPOrderRequest voipOrderRequest,
			Map<String, String> productDetails) throws TranslatorException, GenericException {
		LOG.info("Entered createEslEsipReleaseOrder");
		List<TblEnvOrder> tblEnvOrderList = null;
		List<TblOrder> tblOrderList = null;
		List<TblOrderDetails> tblOrderDetailsList;
		TblEnvOrder tblEnvOrder = null;
		VoipOrderResponse voipOrderResponse = null;
		Map<String, String> paramNameValue = null;
		String isNbsProvRequired = null;
		Boolean entityFlag = false;

		try {

			// Find Validation Env Order
			tblEnvOrderList = orderServiceHelperImpl.getMatchingValidationEnvOrder(voipOrderRequest);

			if (tblEnvOrderList.get(0) != null && tblEnvOrderList.get(0).getEnterpriseId() != null) {
				voipOrderRequest.getOrderHeader().setEnterpriseId(tblEnvOrderList.get(0).getEnterpriseId());

			}

			LOG.info("Env Order Id of Validation Pass = {}", tblEnvOrderList.get(0).getEnvOrderId());

			// Find Validation Order
			tblOrderList = orderServiceHelperImpl.getMatchingPassOrder(tblEnvOrderList.get(0));

			//ESVRRS-19513
			entityFlag = translationUtility.isEntityFlagExists(tblOrderList.get(0));
			//ESVRRS-19513
			if("C".equalsIgnoreCase(voipOrderRequest.getOrderHeader().getOrderType()) && entityFlag) {
				// soft success has to return as entities doesn't exists..
				LOG.info("#Entities doesn't exists for order##");
				tblEnvOrder = createTblEnvOrder(null, tblOrderList.get(0), voipOrderRequest,
						WorkOrderEnum.Status.WO_COMPLETE);

				voipOrderResponse = voipResponseGenerator.prepareSuccessOrderResponse(voipOrderRequest);
				paramNameValue = new HashMap<>();
				paramNameValue.put(TranslationConstant.NBS_PROV, NO);
				notificationServiceImpl.notifySuccess(voipResponseGenerator.preparePCMilestone(voipOrderRequest,
						PcMilestone.ORDER_ACCEPTANCE.getValue(), StatusCode.ESP_SUCCESS,
						PcResponseType.ORDER.getValue(),paramNameValue));
			}else {
			// Find matching Order details
			for (TblOrder tblOrderBean : tblOrderList) {
				LOG.info("ValidationOrderId: {}", tblOrderBean.getOrderId());
				tblOrderDetailsList = orderServiceHelperImpl.getMatchingOrderDetails(tblOrderBean);
				LOG.info("Order Details Size: {}", tblOrderDetailsList.size());

				if (voipOrderRequest.getOrderHeader().getMinorOrderType() != null)
					voipOrderRequest.getOrderHeader().setMinorOrderType(tblEnvOrderList.get(0).getMinorOrderType());

				tblEnvOrder = createTblEnvOrder(tblOrderDetailsList.get(0), tblOrderBean, voipOrderRequest,
						WorkOrderEnum.Status.WO_RECV_SEGMENT);

				// Find Entities and route
				for (TblOrderDetails tblOrderDetails : tblOrderDetailsList) {
					LOG.info("TblOrderDetails Param Detail Id : {} , Param Name : {} ",
							tblOrderDetails.getOrderDetailId(), tblOrderDetails.getParamName());
					if ("Enterprise".equalsIgnoreCase(tblOrderDetails.getParamName()))
						voipOrderResponse = enterpriseOrderService.processReleaseOrder(tblOrderDetails, tblOrderBean,
								tblEnvOrder, voipOrderRequest, tblOrderDetailsList);
					else if ("Location".equalsIgnoreCase(tblOrderDetails.getParamName()))
						voipOrderResponse = locationOrderService.processReleaseOrder(tblOrderDetails, tblOrderBean,
								tblEnvOrder, voipOrderRequest, tblOrderDetailsList);
					else if ("Device".equalsIgnoreCase(tblOrderDetails.getParamName()))
						voipOrderResponse = deviceOrderService.processReleaseOrder(tblOrderDetails, tblOrderBean,
								tblEnvOrder, voipOrderRequest, tblOrderDetailsList);
					else if ("Group".equalsIgnoreCase(tblOrderDetails.getParamName()))
						voipOrderResponse = trunkOrderServiceImpl.processReleaseOrder(tblOrderDetails, tblOrderBean,
								tblEnvOrder, voipOrderRequest, tblOrderDetailsList);
					else if ("EnterpriseTrunk".equalsIgnoreCase(tblOrderDetails.getParamName()))
						voipOrderResponse = enterpriseTrunkOrderServiceImpl.processReleaseOrder(tblOrderBean,
								tblOrderDetails, tblEnvOrder, voipOrderRequest, tblOrderDetailsList);
					else if ("SonusNbs".equalsIgnoreCase(tblOrderDetails.getParamName()))
						voipOrderResponse = nbsOrderServiceImpl.processReleaseOrder(tblOrderDetails, tblOrderBean,
								tblEnvOrder, voipOrderRequest, tblOrderDetailsList);
				}

				// voipOrderDao.createParentChildOrderRelationship(tblEnvOrder);

				int orderVersion = Integer.parseInt(voipOrderRequest.getOrderHeader().getWorkOrderVersion());
				LOG.info("Order version:: {}", orderVersion);

				if (orderVersion > 0) {

					orderServiceHelperImpl.handlePreviousOrder(voipOrderRequest, null, tblEnvOrder.getEnvOrderId());
					// voipOrderDao.createParentChildOrderRelationship(tblEnvOrder, FlowPath.R);
				}

				voipOrderDao.createParentChildOrderRelationship(tblEnvOrder);

				if (orderVersion == 0) {
					voipOrderDao.updateTblEnvOrderStatus(tblEnvOrder.getEnvOrderId(), WorkOrderEnum.Status.WO_INIT);
				} else {
					orderServiceHelperImpl.updateTblEnvOrderStatusWithCurrOrdFlow(voipOrderRequest,
							tblEnvOrder.getEnvOrderId());
				}

				isNbsProvRequired = nbsOrderServiceImpl.isNbsProvisioningRequired(tblEnvOrder);

				paramNameValue = new HashMap<>();
				paramNameValue.put(TranslationConstant.NBS_PROV, isNbsProvRequired);

			}

			notificationServiceImpl.notifySuccess(
					voipResponseGenerator.preparePCMilestone(voipOrderRequest, PcMilestone.ORDER_ACCEPTANCE.toString(),
							StatusCode.ESP_SUCCESS, PcResponseType.ORDER.getValue(), paramNameValue));
			}
		
		} catch (TranslatorException ex) {
			LOG.error("Exception {} {} ", ex.getMessage(), ex);
			throw new TranslatorException(ex.getErrorCode(), ex.getMessage());
		} catch (Exception e) {
			if (tblEnvOrder != null && tblEnvOrder.getEnvOrderId() != null)
				voipOrderDao.updateTblEnvOrderStatus(tblEnvOrder.getEnvOrderId(),
						WorkOrderEnum.Status.WO_TRANSLATION_FAIL);

			LOG.error("Exception {} {}", e.getMessage(), e);

			notificationServiceImpl.notifyFailures(voipResponseGenerator.preparePCMilestone(voipOrderRequest,
					PcMilestone.ORDER_ACCEPTANCE.getValue(), StatusCode.ESP_FAILURE, PcResponseType.ORDER.getValue()));

			throw new GenericException(GenericException.GENERIC_EXCEPTION, "Exception in createEslEsipReleaseOrder");
		}
		LOG.info("Exit createEslEsipReleaseOrder");
		return voipOrderResponse;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.vz.esap.translation.order.service.esl.EslOrderService#configNbsDetails(
	 * com.vz.esap.translation.order.model.request.VOIPOrderRequest)
	 */
	@Override
	public VoipOrderResponse configNbsDetails(VOIPOrderRequest voipOrderRequest)
			throws TranslatorException, GenericException {
		LOG.info("Entered configNbsDetails");

		List<TblEnvOrder> tblEnvOrderList = null;
		List<TblOrder> tblOrderList = null;
		List<TblOrderDetails> tblOrderDetailsList = null;
		VoipOrderResponse voipOrderResponse = null;
		List<ParamInfo> entityParamInfos = null;
		List<TblOrderDetails> parentTblOrderDetails = null;
		ArrayList<NbsEntity> nbsEntityList = null;
		ParamInfo paramRoot = null;

		try {

			if (voipOrderRequest.getNbsConfig() == null) {
				throw new TranslatorException(ErrorCode.INVALID_XML, "NBS Config Missing");
			}

			// Find Validation Env Order
			tblEnvOrderList = orderServiceHelperImpl.getMatchingReleaseEnvOrder(voipOrderRequest, 0,
					Arrays.asList(Long.valueOf(WorkOrderEnum.Status.WO_COMPLETE)));

			// Find Validation Order
			tblOrderList = orderServiceHelperImpl.getMatchingPassOrder(tblEnvOrderList.get(0));

			// Find matching Order details
			for (TblOrder tblOrderBean : tblOrderList) {
				LOG.info("Order Id: {} and UpStream Task Id : {}", tblOrderBean.getOrderId(),
						tblOrderBean.getUpstreamTaskId());

				if (tblOrderBean.getUpstreamTaskId() == OrderEntity.SONUS_NBS.ordinal()) {
					LOG.info("NBS Order Id: {}", tblOrderBean.getOrderId());

					tblOrderDetailsList = orderServiceHelperImpl.getMatchingOrderDetails(tblOrderBean);

					parentTblOrderDetails = tblOrderDetailsList.stream()
							.filter(tblOrderDetails -> "SonusNbs".equalsIgnoreCase(tblOrderDetails.getParamName()))
							.collect(Collectors.toList());

					paramRoot = new ParamInfo("NbsConfig", null, "n");

					// create Nbs Object
					nbsEntityList = nbsOrderParserImpl.parseNbsOrder(voipOrderRequest);

					entityParamInfos = nbsTblOrderDetailsDataTransformerImpl
							.prepareTblOrderDetailsEntityParamDataForNbs(voipOrderRequest, tblOrderBean, nbsEntityList,
									paramRoot);

					voipOrderDao.upsertTblOrderDetails(tblOrderDetailsList.get(0).getOrderId(), entityParamInfos, "n",
							parentTblOrderDetails.get(0).getOrderDetailId(), 1);

					LOG.info("Order Details Size: {}", tblOrderDetailsList.size());
				}
			}

			voipOrderResponse = voipResponseGenerator.prepareSuccessOrderResponse(voipOrderRequest);

			notificationServiceImpl.notifySuccess(voipResponseGenerator.preparePCMilestone(voipOrderRequest,
					PcMilestone.NBS_PROV.getValue(), StatusCode.ESP_SUCCESS, PcResponseType.ORDER.getValue()));

		} catch (TranslatorException ex) {
			LOG.error("Exception {} ", ex.getMessage());
			throw new TranslatorException(ex.getErrorCode(), ex.getMessage());
		} catch (Exception e) {

			notificationServiceImpl.notifyFailures(voipResponseGenerator.preparePCMilestone(voipOrderRequest,
					PcMilestone.NBS_PROV.getValue(), StatusCode.ESP_FAILURE, PcResponseType.ORDER.getValue()));

			LOG.error("Exception {} ", e.getMessage());
			throw new GenericException(GenericException.GENERIC_EXCEPTION, "Exception in configNbsDetails");
		}
		LOG.info("Exited configNbsDetails");
		return voipOrderResponse;
	}

	@Override
	public VoipOrderResponse configCircuitInfo(VOIPOrderRequest voipOrderRequest)
			throws TranslatorException, GenericException {
		LOG.info("Entered configCircuitInfo");

		List<TblEnvOrder> tblEnvOrderList = null;
		List<TblOrder> tblOrderList = null;
		List<TblOrderDetails> tblOrderDetailsList = null;
		VoipOrderResponse voipOrderResponse = null;
		List<ParamInfo> entityParamInfos = null;
		ParamInfo entityParamInfo = null;
		List<TblOrderDetails> parentTblOrderDetails = null;
		ArrayList<NbsEntity> nbsEntityList = null;
		LocationEntity location = null;
		ParamInfo paramRoot = null;

		try {

			if (voipOrderRequest.getCircuitInfo() == null) {
				throw new TranslatorException(ErrorCode.INVALID_XML, "Circuit Info is Missing");
			}

			// Find Validation Env Order
			tblEnvOrderList = orderServiceHelperImpl.getMatchingReleaseEnvOrder(voipOrderRequest, 0, null);

			// Find Validation Order
			tblOrderList = orderServiceHelperImpl.getMatchingPassOrder(tblEnvOrderList.get(0));

			// Find matching Order details
			for (TblOrder tblOrderBean : tblOrderList) {
				OrderServiceBase.LOG.info("Order Id: {} and UpStream Task Id : {}", tblOrderBean.getOrderId(),
						tblOrderBean.getUpstreamTaskId());

				if (tblOrderBean.getUpstreamTaskId() == OrderEntity.SONUS_NBS.getIndex()) {
					OrderServiceBase.LOG.info("NBS Order Id: {}", tblOrderBean.getOrderId());

					tblOrderDetailsList = orderServiceHelperImpl.getMatchingOrderDetails(tblOrderBean);

					parentTblOrderDetails = tblOrderDetailsList.stream()
							.filter(tblOrderDetails -> "SonusNbs".equalsIgnoreCase(tblOrderDetails.getParamName())
									|| "Location".equalsIgnoreCase(tblOrderDetails.getParamName()))
							.collect(Collectors.toList());

					paramRoot = new ParamInfo("CircuitInfo", null, "n");

					for (TblOrderDetails tblOrderDetails : parentTblOrderDetails) {
						if ("SonusNbs".equalsIgnoreCase(tblOrderDetails.getParamName())) {
							// create Nbs Object
							nbsEntityList = nbsOrderParserImpl.parseNbsOrder(voipOrderRequest);// change
							entityParamInfos = nbsTblOrderDetailsDataTransformerImpl
									.prepareTblOrderDetailsEntityParamDataForNbs(voipOrderRequest, tblOrderBean,
											nbsEntityList, paramRoot);
						}
						if ("Location".equalsIgnoreCase(tblOrderDetails.getParamName())) {
							location = locationOrderParser.parseLocationOrder(voipOrderRequest);
							entityParamInfo = locationTblOrderDetailsDataTransformerImpl
									.prepareTblOrderDetailsEntityParamDataForLocation(voipOrderRequest, tblOrderBean,
											location, null);
						}
					}

					voipOrderDao.upsertTblOrderDetails(tblOrderDetailsList, entityParamInfos, "n",
							parentTblOrderDetails.get(0).getOrderDetailId(), 1);

					OrderServiceBase.LOG.info("Order Details Size: {}", tblOrderDetailsList.size());
				}

				voipOrderResponse = voipResponseGenerator.prepareSuccessOrderResponse(voipOrderRequest);
			}

			notificationServiceImpl.notifySuccess(voipResponseGenerator.preparePCMilestone(voipOrderRequest,
					PcMilestone.CIRCUIT_INFO_ACCEPTANCE.getValue(), StatusCode.ESP_SUCCESS,
					PcResponseType.ORDER.getValue()));

		} catch (TranslatorException ex) {

			notificationServiceImpl.notifyFailures(voipResponseGenerator.preparePCMilestone(voipOrderRequest,
					PcMilestone.CIRCUIT_INFO_ACCEPTANCE.getValue(), StatusCode.ESP_FAILURE,
					PcResponseType.ORDER.getValue()));

			OrderServiceBase.LOG.error("Exception {} ", ex.getMessage());
			throw new TranslatorException(ex.getErrorCode(), ex.getMessage());
		} catch (Exception e) {

			notificationServiceImpl.notifyFailures(voipResponseGenerator.preparePCMilestone(voipOrderRequest,
					PcMilestone.CIRCUIT_INFO_ACCEPTANCE.getValue(), StatusCode.ESP_FAILURE,
					PcResponseType.ORDER.getValue()));

			OrderServiceBase.LOG.error("Exception {} ", e.getMessage());
			throw new GenericException(GenericException.GENERIC_EXCEPTION, "Exception in configCircuitInfo");
		}
		LOG.info("Exited configCircuitInfo");
		return voipOrderResponse;
	}

	/**
	 * TODO - Disconn
	 * 
	 * @param voipOrderRequest
	 * @return voipOrderResponse
	 * @throws GenericException
	 * @throws TranslatorException
	 */
	@Override
	public VoipOrderResponse createEslEsipLocSuspOrder(VOIPOrderRequest voipOrderRequest,
			Map<String, String> productDetails) throws TranslatorException, GenericException {
		LOG.info("Entered createEslEsipLocSuspOrder");

		VoipOrderResponse voipOrderResponse = null;
		String voipLocation = null;
		String enterpriseID = null;
		String customerId = null;
		long sequenceNumber = -1;
		TblSafeStore tblSafeStoreObject = null;
		TblEnvOrder tblEnvOrderObject = null;
		String virtualAddrCountry = null;
		LocationEntity locationEntityInv = null;
		Map<String, String> locRows = null;
		DBServiceResponse dbServiceResponse = null;

		try {
			if (voipOrderRequest.getOrderHeader().getVoipLocationId() == null
					|| voipOrderRequest.getOrderHeader().getVoipLocationId().isEmpty()) {
				throw new TranslatorException(ErrorCode.INVALID_XML, "Voip Location ID is Missing");
			}

			if (voipOrderRequest.getOrderHeader().getGCHId() == null)
				throw new TranslatorException(ErrorCode.ESAP_MISSING_REQUIRED_DATA,
						"GCHID is not present in the request BOD");		
			dbServiceResponse = orderServiceHelperImpl
					.getEnterpriseInformationFromGchId(voipOrderRequest.getOrderHeader().getGCHId());

			voipOrderRequest = translationUtility.setAsClli(voipOrderRequest);//add broadsoft clli.
			
			voipOrderRequest = voipRequestTransformerImpl.modifyOrderHeader(voipOrderRequest, dbServiceResponse, false,
					productDetails);

			voipLocation = voipOrderRequest.getOrderHeader().getVoipLocationId();

			locRows = inventoryUtil.getTblLocationFromLocationId(voipLocation, null, null);
			if (locRows != null && locRows.get("LOCATION_TYPE") != null
					&& LocationType.ESIP_ESL.getIndex() == Integer.valueOf(locRows.get("LOCATION_TYPE"))) {
				enterpriseID = orderServiceHelperImpl.findRemoteLocationEnterpriseId(voipLocation);
				if (enterpriseID != null) {
					throw new TranslatorException(ErrorCode.EBL_EXISTS_FOR_THE_ESL,
							"ESL Can not be Deleted as EBL Exists");
				}
			}
			locationEntityInv = orderServiceHelperImpl.getEntityDetailsFromInventory(voipLocation,
					LocationEntity.class);
			if (locationEntityInv != null && locationEntityInv.getLocRegion() != null)
				virtualAddrCountry = locationEntityInv.getLocRegion();
			else
				virtualAddrCountry = "US";
			voipOrderRequest.getOrderHeader().setRegion(virtualAddrCountry);

			LOG.info("EslOrderServiceImpl:: virtualAddrCountry - {}", virtualAddrCountry);

			if (locationEntityInv != null && locationEntityInv.getCustomerId() != null) {
				customerId = locationEntityInv.getCustomerId();
				LOG.info("Customer Id : {}", customerId);
				voipOrderRequest.getOrderHeader().setEnterpriseId(customerId);
			}

			sequenceNumber = voipOrderRequest.getSequenceNumber();
			LOG.info("TblSafeOrder  SequenceNo : {}", sequenceNumber);

			// Updating Tbl safe store
			tblSafeStoreObject = tblSafeStoreTransformer.prepareTblSafeStoreData(sequenceNumber);
			voipOrderDao.updateTblSafeStoreTranslationStartTime(tblSafeStoreObject);

			// Create Env Order
			tblEnvOrderObject = orderServiceHelperImpl.createEsipEslEnvOrder(voipOrderRequest,
					WorkOrderEnum.Status.WO_RECV_SEGMENT);

			orderServiceHelperImpl.createLocationOrderFromInventoryDetails(voipOrderRequest, tblEnvOrderObject);
			LOG.info("Location order is placed");

			// TODO: 1/17. Please propagate below to Flex
			voipOrderResponse = voipResponseGenerator.prepareSuccessOrderResponse(voipOrderRequest);

			voipOrderDao.createParentChildOrderRelationship(tblEnvOrderObject);

			voipOrderDao.updateTblEnvOrderStatus(tblEnvOrderObject.getEnvOrderId(), WorkOrderEnum.Status.WO_INIT);

			// Commentting below as PC do not need this milestone
			/*
			 * notificationServiceImpl.notifySuccess(voipResponseGenerator.
			 * preparePCMilestone(voipOrderRequest, PcMilestone.ORDER_ACCEPTANCE.getValue(),
			 * StatusCode.ESP_SUCCESS, PcResponseType.ORDER.getValue()));
			 */

		} catch (TranslatorException ex) {
			
			notificationServiceImpl.notifyFailures(voipResponseGenerator.preparePCMilestone(voipOrderRequest,
					PcMilestone.REL_SUSPEND.getValue(), StatusCode.ESP_FAILURE,
					PcResponseType.ORDER.getValue()));
			
			LOG.error("Exception {} ", ex.getMessage());
			throw new TranslatorException(ex.getErrorCode(), ex.getMessage());

		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new GenericException(GenericException.GENERIC_EXCEPTION,
					"Generic Exception in createEslEsipLocSuspOrder");

		}

		LOG.info("Exit createEslEsipLocSuspOrder");
		return voipOrderResponse;
	}

	/**
	 * TODO - Disconn
	 * 
	 * @param voipOrderRequest
	 * @return voipOrderResponse
	 * @throws GenericException
	 * @throws TranslatorException
	 */
	@Override
	public VoipOrderResponse createEslEsipLocDeactOrder(VOIPOrderRequest voipOrderRequest,
			Map<String, String> productDetails) throws TranslatorException, GenericException {
		LOG.info("Entered createEslEsipLocDeactOrder");
		VoipOrderResponse voipOrderResponse = null;
		List<TblEnvOrder> suspenedTblEnvOrderObjects = null;
		long sequenceNumber = -1;
		TblSafeStore tblSafeStoreObject = null;
		TblEnvOrder tblEnvOrderObject = null;
		DBServiceResponse dbServiceResponse = null;
		int relSuspendOrderClassify = 33;
		Map<String, String> locRows = null;
		String voipLocation = null;
		String remoteLocationEnterpriseID = null;

		try {
			suspenedTblEnvOrderObjects = orderServiceHelperImpl.getMatchingPrevPassEnvOrder(voipOrderRequest,
					WorkOrderEnum.Status.WO_COMPLETE, relSuspendOrderClassify);

			if (suspenedTblEnvOrderObjects == null || suspenedTblEnvOrderObjects.isEmpty()
					|| suspenedTblEnvOrderObjects.get(0) == null
					|| suspenedTblEnvOrderObjects.get(0).getEnvOrderId() == null) {
				throw new TranslatorException(TranslatorException.ErrorCode.VALIDATION_NOT_COMPLETE,
						"Suspend is not complete for Order:" + voipOrderRequest.getOrderHeader().getWorkOrderNumber());
			}

			if (voipOrderRequest.getOrderHeader().getGCHId() == null)
				throw new TranslatorException(ErrorCode.ESAP_MISSING_REQUIRED_DATA,
						"GCHID is not present in the request BOD");
			dbServiceResponse = orderServiceHelperImpl
					.getEnterpriseInformationFromGchId(voipOrderRequest.getOrderHeader().getGCHId());
			
			voipOrderRequest = translationUtility.setAsClli(voipOrderRequest);//add broadsoft clli.

			voipOrderRequest = voipRequestTransformerImpl.modifyOrderHeader(voipOrderRequest, dbServiceResponse, false,
					productDetails);

			LOG.info("createEslEsipLocDeactOrder::REL_SUSPEND order is succesfully completed for work order - {}",
					voipOrderRequest.getOrderHeader().getWorkOrderNumber());

			// Verify any more locations exists
			voipLocation = voipOrderRequest.getOrderHeader().getVoipLocationId();

			boolean isOtherActiveLocationPresent = true;

			locRows = inventoryUtil.getTblLocationFromLocationId(voipLocation, null, null);
			if (locRows != null && locRows.get("LOCATION_TYPE") != null
					&& LocationType.ESIP_ESL.getIndex() == Integer.valueOf(locRows.get("LOCATION_TYPE"))) {

				remoteLocationEnterpriseID = orderServiceHelperImpl.findRemoteLocationEnterpriseId(voipLocation);

				if (remoteLocationEnterpriseID != null) {
					LOG.info("Remote Location Exist");
					throw new TranslatorException(ErrorCode.EBL_EXISTS_FOR_THE_ESL,
							"ESL Can not be Deleted as EBL Exists");
				}
				LOG.info("Remote Location Do not Exist");

				sequenceNumber = voipOrderRequest.getSequenceNumber();
				LOG.info("TblSafeOrder  SequenceNo : {}", sequenceNumber);
				// Update TblSafeStore
				tblSafeStoreObject = tblSafeStoreTransformer.prepareTblSafeStoreData(sequenceNumber);
				voipOrderDao.updateTblSafeStoreTranslationStartTime(tblSafeStoreObject);
				// Create Env Order
				tblEnvOrderObject = orderServiceHelperImpl.createEsipEslEnvOrder(voipOrderRequest,
						WorkOrderEnum.Status.WO_RECV_SEGMENT);

				// No more locations exists
				// (REL_DEACTIVATE - If LocationType = 5 and no more locations then create
				// Enterprise Order and Location Order with Tbl_Order_Details for disconnect.)

				orderServiceHelperImpl.createLocationOrderFromInventoryDetails(voipOrderRequest, tblEnvOrderObject);
				LOG.info("Location order is placed");

				isOtherActiveLocationPresent = orderServiceHelperImpl.isOtherActiveLocationPresentUnderEnterpriseInBw(
						voipOrderRequest.getOrderHeader().getEnterpriseId(),
						Arrays.asList(voipOrderRequest.getOrderHeader().getVoipLocationId()));

				LOG.info("isOtherActiveLocationPresent --> {}", isOtherActiveLocationPresent);

				if (!isOtherActiveLocationPresent) {

					orderServiceHelperImpl.createEnterpriseOrderFromInventoryDetails(voipOrderRequest,
							tblEnvOrderObject);
					orderServiceHelperImpl.insertEnterpriseFlagintoTOD(tblEnvOrderObject,"ET_EXISTS ","Y");
				}else {
					orderServiceHelperImpl.insertEnterpriseFlagintoTOD(tblEnvOrderObject,"ET_EXISTS ","N");
				}

				voipOrderResponse = voipResponseGenerator.prepareSuccessOrderResponse(voipOrderRequest);

				voipOrderDao.createParentChildOrderRelationship(tblEnvOrderObject);

				voipOrderDao.updateTblEnvOrderStatus(tblEnvOrderObject.getEnvOrderId(), WorkOrderEnum.Status.WO_HALTED);

				// ESL_Disconnect milestone
				Map<String, String> paramNameValue = inventoryUtil.getEslDisconnectMileStoneData(voipOrderRequest);

				// ESL_Disconnect milestone

				// Commentting below as PC do not need this milestone
				/*
				 * notificationServiceImpl.notifySuccess(voipResponseGenerator.
				 * preparePCMilestone(voipOrderRequest, PcMilestone.ORDER_ACCEPTANCE.getValue(),
				 * StatusCode.ESP_SUCCESS, PcResponseType.ORDER.getValue()));
				 */

				// Adding new Milestone VALIDATE_DEACT
				notificationServiceImpl.notifySuccess(voipResponseGenerator.preparePCMilestone(voipOrderRequest,
						PcMilestone.VALIDATE_DEACT.getValue(), StatusCode.ESP_SUCCESS,
						PcResponseType.VALIDATION.getValue(), paramNameValue));

			}

		} catch (TranslatorException ex) {
			LOG.error("Exception {} ", ex.getMessage());
			throw new TranslatorException(ex.getErrorCode(), ex.getMessage());

		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new GenericException(GenericException.GENERIC_EXCEPTION,
					"Generic Exception in createEslEsipLocDeactOrder");

		}
		LOG.info("Exiting createEslEsipLocDeactOrder");
		return voipOrderResponse;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.vz.esap.translation.order.service.esl.EslOrderService#
	 * getEsipLocationStatus(com.vz.esap.translation.order.model.request.
	 * VOIPOrderRequest)
	 */
	@Override
	public VoipOrderResponse getEsipLocationStatus(VOIPOrderRequest voipOrderRequest)
			throws TranslatorException, GenericException {
		LOG.info("Entered getEsipLocationStatus");

		VoipOrderResponse voipOrderResponse = null;
		Map<String, String> locationResultMap;
		StatusCode statusCode = null;

		try {
			locationResultMap = inventoryUtil
					.getTblLocationFromLocationId(voipOrderRequest.getOrderHeader().getVoipLocationId(), null, null);

			if (locationResultMap != null && locationResultMap.get("LOCATION_TYPE") != null
					&& LocationType.ESIP_ESL.getIndex() == Integer.valueOf(locationResultMap.get("LOCATION_TYPE")) && locationResultMap.get("ACTIVE_IND").equalsIgnoreCase("1")) {
				LOG.info("Inside getEsipLocationStatus For ESL");
				statusCode = StatusCode.LOC_ACTIVE;

			} else {
				LOG.info("Inside getEsipLocationStatus Location Not Found");
				statusCode = StatusCode.LOC_INACTIVE;

			}

			voipOrderResponse = voipResponseGenerator.preparePCMilestone(voipOrderRequest, null, statusCode,
					PcResponseType.ORDER.getValue());

		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());

		}
		LOG.info("Exited getEsipLocationStatus");
		return voipOrderResponse;
	}

	@Override
	public VoipOrderResponse createEslPreIntegrationTestOrder(VOIPOrderRequest voipOrderRequest,
			Map<String, String> productDetails) throws GenericException {
		LOG.info("Entered createEslPreIntegrationTestOrder");
		VoipOrderResponse voipOrderResponse = null;
		StatusCode statusCode = StatusCode.ESP_SUCCESS; // need to decide with Niladri.

		try {

			voipOrderResponse = voipResponseGenerator.preparePCMilestone(voipOrderRequest,
					PcMilestone.PIT_COMPLETE.getValue(), statusCode, PcResponseType.ORDER.getValue());

			notificationServiceImpl.notifySuccess(voipOrderResponse);

		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new GenericException(GenericException.GENERIC_EXCEPTION,
					"Generic Exception in createEslPreIntegrationTestOrder");

		}
		LOG.info("Exiting createEslPreIntegrationTestOrder");
		return voipOrderResponse;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.vz.esap.translation.order.service.esl.EslOrderService#
	 * createEslCompletionOrder(com.vz.esap.translation.order.model.request.
	 * VOIPOrderRequest, java.util.Map)
	 */
	@Override
	public VoipOrderResponse createEslCompletionOrder(VOIPOrderRequest voipOrderRequest,
			Map<String, String> productDetails) throws GenericException {
		LOG.info("Entered createEslCompletionOrder");
		VoipOrderResponse voipOrderResponse = null;
		StatusCode statusCode = StatusCode.ESP_SUCCESS; // Temporary

		try {

			voipOrderResponse = voipResponseGenerator.preparePCMilestone(voipOrderRequest,
					PcMilestone.LOCATION_COMPLETE.getValue(), statusCode, PcResponseType.ORDER.toString());

			notificationServiceImpl.notifySuccess(voipOrderResponse);

		} catch (Exception e) {
			LOG.error("Exception {} ", e.getMessage());
			throw new GenericException(GenericException.GENERIC_EXCEPTION,
					"Generic Exception in createEslCompletionOrder");

		}
		LOG.info("Exiting createEslCompletionOrder");
		return voipOrderResponse;
	}
}
