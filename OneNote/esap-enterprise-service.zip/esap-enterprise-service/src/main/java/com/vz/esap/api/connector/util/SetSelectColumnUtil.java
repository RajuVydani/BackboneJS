package com.vz.esap.api.connector.util;

import java.util.HashSet;
import java.util.Set;

public class SetSelectColumnUtil {
	
	public static Set<String> getSelectColumnSetForTNPool() {
		final String COLUMN_FEAT1 = "LOCATION_ID";
		final String COLUMN_FEAT2 = "DEPARTMENT_ID";
		final String COLUMN_FEAT3 = "TN";
		final String COLUMN_FEAT4 = "TN_STATUS";
		final String COLUMN_FEAT5 = "PORTED_STATUS";
		final String COLUMN_FEAT6 = "NPA_SPLIT_STATUS";
		final String COLUMN_FEAT7 = "CREATED_BY";
		final String COLUMN_FEAT8 = "CREATION_DATE";
		final String COLUMN_FEAT9 = "MODIFIED_BY";
		final String COLUMN_FEAT10 = "LAST_MODIFIED_DATE";
		final String COLUMN_FEAT11 = "SWITCH_CLLI";
		final String COLUMN_FEAT12 = "TRUNK";
		final String COLUMN_FEAT13 = "ENV_ORDER_ID";
		final String COLUMN_FEAT14 = "ACTIVE_IND";
		final String COLUMN_FEAT15 = "TN_TYPE";
		final String COLUMN_FEAT16 = "TN_ON_OFF";
		final String COLUMN_FEAT17 = "STN_IND";
		final String COLUMN_FEAT18 = "ACT_DEACT";
		final String COLUMN_FEAT19 = "LI_IND";
		final String COLUMN_FEAT20 = "PUBIP";
		final String COLUMN_FEAT21 = "PORTIN_TYPE";
		final String COLUMN_FEAT22 = "TSP_CODE";
		final String COLUMN_FEAT23 = "REPLACEMENT_CLI";
		final String COLUMN_FEAT24 = "TRANSITION_TYPE";
		final String COLUMN_FEAT25 = "PS_ALI";
		final String COLUMN_FEAT26 = "CNAM_UPDATE_STATUS";
		final String COLUMN_FEAT27 = "CNAM_UPDATE_DATE";
		final String COLUMN_FEAT28 = "VERIZON_BTN";
		final String COLUMN_FEAT29 = "PUBIP_IN";
		final String COLUMN_FEAT30 = "PUBIP_OUT";

		Set<String> columnFeatures = new HashSet<>();

		columnFeatures.add(COLUMN_FEAT1);
		columnFeatures.add(COLUMN_FEAT2);
		columnFeatures.add(COLUMN_FEAT3);
		columnFeatures.add(COLUMN_FEAT4);
		columnFeatures.add(COLUMN_FEAT5);
		columnFeatures.add(COLUMN_FEAT6);
		columnFeatures.add(COLUMN_FEAT7);
		columnFeatures.add(COLUMN_FEAT8);
		columnFeatures.add(COLUMN_FEAT9);
		columnFeatures.add(COLUMN_FEAT10);
		columnFeatures.add(COLUMN_FEAT11);
		columnFeatures.add(COLUMN_FEAT12);
		columnFeatures.add(COLUMN_FEAT13);
		columnFeatures.add(COLUMN_FEAT14);
		columnFeatures.add(COLUMN_FEAT15);
		columnFeatures.add(COLUMN_FEAT16);
		columnFeatures.add(COLUMN_FEAT17);
		columnFeatures.add(COLUMN_FEAT18);
		columnFeatures.add(COLUMN_FEAT19);
		columnFeatures.add(COLUMN_FEAT20);
		columnFeatures.add(COLUMN_FEAT21);
		columnFeatures.add(COLUMN_FEAT22);
		columnFeatures.add(COLUMN_FEAT23);
		columnFeatures.add(COLUMN_FEAT24);
		columnFeatures.add(COLUMN_FEAT25);
		columnFeatures.add(COLUMN_FEAT26);
		columnFeatures.add(COLUMN_FEAT27);
		columnFeatures.add(COLUMN_FEAT28);
		columnFeatures.add(COLUMN_FEAT29);
		columnFeatures.add(COLUMN_FEAT30);
		return columnFeatures;
	}

}
