package com.vz.fxo.inventory.enterprise.support;

import java.util.List;
import java.util.ArrayList;
import java.sql.Timestamp;
import esap.db.DBTblDialPlan;
import esap.db.DBTblEnterprise;
import esap.db.TblDialPlanDbBean;

public class DialPlanBean
{
        protected int dialPlanId;
        protected long iasaDialPlanId;
        protected String enterpriseId;
        protected String dialPlanName;
        protected long defaultFlag;
        protected long emergencyIndicator;
        protected long termntind;
        protected long presacceptstatus;
        protected long presscreenstatus;
        protected long presscreenlist;
        protected long origcallregstat;
        protected long numconreg;
        protected long regtimeext;
        protected long localDaStat;
        protected long publicNetwGw;
        protected long publicDefaultGw;
        protected long blockAllCall;
        protected long onNetStat;
        protected String billingno;
        protected long ocsstat;
        protected long ocs;
        protected long enumStat;
        protected String primaryEnumDomain;
        protected String altEnumDomain;
        protected long maxenterprise;
        protected long activeInd;
        protected String createdBy;
        protected String modifiedBy;
        protected java.sql.Timestamp lastModifiedDate;
		protected boolean getAll;
		protected long envOrderId;
		protected long liInd;
		protected long apacInd;
		protected short oldOnNetStat;
		protected short enumistat;

	protected List<SipDomainBean> sipDomainDbList;
	protected List<TerminatingRoutingBean> termRoutingDbList;
 
        DialPlanBean()
        {      
               dialPlanId = 0;
               iasaDialPlanId = -1;
               enterpriseId = new String("NONE");
               dialPlanName = new String("");
               defaultFlag = -1;
               emergencyIndicator = -1;
               termntind = -1;
               presacceptstatus = -1;
               presscreenstatus = -1;
               presscreenlist = -1;
               origcallregstat = -1;
               numconreg = 1;
               regtimeext = 600;
               localDaStat =-1;
               publicNetwGw =-1;
               publicDefaultGw =-1;
               blockAllCall =-1;
               onNetStat =-1;
               billingno = new String("NONE");
               ocsstat = 1;
               ocs = -1;
               enumStat = -1;
               primaryEnumDomain = new String("NONE");
               altEnumDomain = new String("NONE");
               maxenterprise = -1;
               activeInd = 1;
               createdBy = new String("");
	           modifiedBy = new String("");
			   getAll = false;
               //lastModifiedDate
			this.envOrderId = -1; 
			liInd = -1; 
			apacInd = -1; 
			oldOnNetStat = -1; 
			enumistat = -1; 
        }      
        
        DialPlanBean(DialPlanBean dialPlanBean){
         //Argument constructor
        }
        public int getDialPlanId() {
		return dialPlanId;
	}
	    public void setDialPlanId(int dialPlanId) {
		this.dialPlanId = dialPlanId;
	}
        public long getIasaDialPlanId() {
		return iasaDialPlanId;
	}
	    public void setIasaDialPlanId(long iasaDialPlanId) {
		this.iasaDialPlanId = iasaDialPlanId;
	}
	    public String getEnterpriseId() {
		return enterpriseId;
    }
	    public void setEnterpriseId(String enterpriseId) {
		this.enterpriseId = enterpriseId;
	}
        public String getDialPlanName() {
		return dialPlanName;
	}
	    public void setDialPlanName(String dialPlanName) {
		this.dialPlanName = dialPlanName;
	}	    
        public long getDefaultFlag(){
        return defaultFlag;
    }
        public void setDefaultFlag(long defaultFlag){
    	this.defaultFlag=defaultFlag;
    }
        public long getEmergencyIndicator(){
        return emergencyIndicator; 	
    }
        public void setEmergencyIndicator(long emergencyIndicator){
        this.emergencyIndicator=emergencyIndicator; 	
    }
        public long getTermntind(){
        return termntind;
    }
        public void setTermntind(long termntind){
        this.termntind=termntind;      	
    }
        public long getPresacceptstatus(){
        return presacceptstatus;	
    }
        public void setPresacceptstatus(long presacceptstatus){
        this.presacceptstatus=presacceptstatus; 	
    }
        public long getPresscreenstatus(){
        return presscreenstatus; 	
    }
        public void setPresscreenstatus(long presscreenstatus){
        this.presscreenstatus=presscreenstatus;
    }
        public long getPresscreenlist(){
        return presscreenlist;	
    }
        public void setPresscreenlist(long presscreenlist){
        this.presscreenlist=presscreenlist;	
    }
        public long getOrigcallregstat(){
        return origcallregstat;	
    }
        public void setOrigcallregstat(long origcallregstat){
        this.origcallregstat=origcallregstat;
     }
        public long getNumconreg(){
        return numconreg;	
     }
        public void setNumconreg(long numconreg){
        this.numconreg=numconreg;	
     }
        public long getRegtimeext(){
        return regtimeext;	
     }
        public void setRegtimeext(long regtimeext){
        this.regtimeext=regtimeext;	
     }      
        public long getLocalDaStat(){
        return localDaStat;	
     }
        public void setLocalDaStat(long localDaStat){
        this.localDaStat=localDaStat;	
     }
        public long getPublicNetwGw(){
        return publicNetwGw;	
     }
        public void setPublicNetwGw(long publicNetwGw){
        this.publicNetwGw=publicNetwGw;
     } 
        public long getPublicDefaultGw(){
        return publicDefaultGw;	
     }
        public void setPublicDefaultGw(long publicDefaultGw){
        this.publicDefaultGw=publicDefaultGw;	
     }      
        public long getBlockAllCall(){
        return blockAllCall;	
     }
        public void setBlockAllCall(long blockAllCall){
         this.blockAllCall=blockAllCall;	
     }
        public long getOnNetStat(){
        return onNetStat;	
    }
        public void setOnNetStat(long onNetStat){
        this.onNetStat=onNetStat;
    } 
	    public long getOcs(){
	    return ocs;	
    }
	    public void setOcs(long ocs){
	    this.ocs=ocs;	
    }
	    public long getEnumStat(){
	    return enumStat;	
    }
	   public void setEnumStat(long enumStat){
	   this.enumStat=enumStat;
   }   

	   public String getPrimaryEnumDomain() {
	   return primaryEnumDomain;
  }
	   public void setPrimaryEnumDomain(String primaryEnumDomain) {
	   this.primaryEnumDomain=primaryEnumDomain;
  }           
	   public String getAltEnumDomain() {
	   return altEnumDomain;
  }
	   public void setAltEnumDomain(String altEnumDomain) {
	   this.altEnumDomain=altEnumDomain;
  }    
	   public long getActiveInd(){
	   return activeInd;	
  }
	   public void setActiveInd(long activeInd){
	   this.activeInd=activeInd;
  }   
	   public String getCreatedBy() {
       return createdBy;
  }
	   public void setCreatedBy(String createdBy) {
	   this.createdBy=createdBy;
  }   
	    public String getModifiedBy() {
		return modifiedBy;
  }
	    public void setModifiedBy(String modifiedBy) {
	    this.modifiedBy = modifiedBy;
  }   
	    public Timestamp getLastModifiedDate() {
		return lastModifiedDate;
  }
	    public void setLastModifiedDate(java.sql.Timestamp lastModifiedDate) {
	    this.lastModifiedDate=lastModifiedDate;
  }

		public String getBillingno() {
			return billingno;
		}

		public void setBillingno(String billingno) {
			this.billingno = billingno;
		}

		public long getOcsstat() {
			return ocsstat;
		}

		public void setOcsstat(long ocsstat) {
			this.ocsstat = ocsstat;
		}

		public long getMaxenterprise() {
			return maxenterprise;
		}

		public void setMaxenterprise(long maxenterprise) {
			this.maxenterprise = maxenterprise;
		}          

	public List<SipDomainBean> getSipDomainDbList() {
		return sipDomainDbList;
	}

	public void setSipDomainDbList(List<SipDomainBean> sipDomainDbList) {
		this.sipDomainDbList = sipDomainDbList;
	}

	public List<TerminatingRoutingBean> getTermRoutingDbList() {
		return termRoutingDbList;
	}

	public void setTermRoutingDbList(List<TerminatingRoutingBean> termRoutingDbList) {
		this.termRoutingDbList = termRoutingDbList;
	}

	/**
	 * @param dpBean
	 */
	public boolean getGetAll() {
        return getAll;
    }

    public void setGetAll(boolean getAll) {
        this.getAll = getAll;
    }
	public void copyFrom(TblDialPlanDbBean dpBean) {
		setDialPlanId(dpBean.getDialPlanId());
		setIasaDialPlanId(dpBean.getIasaDialPlanId());
		setEnterpriseId(dpBean.getEnterpriseId());
		setDialPlanName(dpBean.getDialPlanName());
		setDefaultFlag(dpBean.getDefaultFlag());
		setEmergencyIndicator(dpBean.getEmergencyIndicator());
		setTermntind(dpBean.getTermntind());
		setPresacceptstatus(dpBean.getPresacceptstatus());
		setPresscreenstatus(dpBean.getPresscreenstatus());
		setPresscreenlist(dpBean.getPresscreenlist());
		setOrigcallregstat(dpBean.getOrigcallregstat());
		setNumconreg(dpBean.getNumconreg());
		setRegtimeext(dpBean.getRegtimeext());
		setLocalDaStat(dpBean.getLocalDaStat());
		setPublicNetwGw(dpBean.getPublicNetwGw());
		setPublicDefaultGw(dpBean.getPublicDefaultGw());
		setBlockAllCall(dpBean.getBlockAllCall());
		setOnNetStat(dpBean.getOnNetStat());
		setBillingno(dpBean.getBillingno());
		setOcsstat(dpBean.getOcsstat());
		setOcs(dpBean.getOcs());
		setEnumStat(dpBean.getEnumStat());
		setPrimaryEnumDomain(dpBean.getPrimaryEnumDomain());
		setAltEnumDomain(dpBean.getAltEnumDomain());
		setMaxenterprise(dpBean.getMaxenterprise());
		setActiveInd(dpBean.getActiveInd());
		setCreatedBy(dpBean.getCreatedBy());
		setModifiedBy(dpBean.getModifiedBy());
		setLastModifiedDate(dpBean.getLastModifiedDate());
		setEnvOrderId(dpBean.getEnvOrderId());
		setLiInd(dpBean.getLiInd());
		setApacInd(dpBean.getApacInd());
		setOldOnNetStat(dpBean.getOldOnNetStat());
		setEnumistat(dpBean.getEnumistat());
	}

	public long getEnvOrderId() {
		return envOrderId;
	}
	public void setEnvOrderId(long envOrderId) {
		this.envOrderId = envOrderId;
	}

	public long getLiInd() {
        return liInd;
    }
    public void setLiInd(long liInd) {
        this.liInd = liInd;
    }

	public long getApacInd() {
        return apacInd;
    }
    public void setApacInd(long apacInd) {
        this.apacInd = apacInd;
    }

	public short getOldOnNetStat() {
        return oldOnNetStat;
    }
    public void setOldOnNetStat(short oldOnNetStat) {
        this.oldOnNetStat = oldOnNetStat;
    }
	public short getEnumistat() {
        return enumistat;
    }
    public void setEnumistat(short enumistat) {
        this.enumistat= enumistat;
    }

	public void initilizeTODefault() {
        enterpriseId = new String("");
        dialPlanName = new String("");
        defaultFlag = 0;
        emergencyIndicator = 0;
        termntind = 0;
        presacceptstatus = 0;
        presscreenstatus = 0;
        presscreenlist = 0;
        origcallregstat = 0;
        numconreg = 1;
        regtimeext = 600;
        localDaStat =0;
        publicNetwGw =0;
        publicDefaultGw =0;
        blockAllCall =0;
        onNetStat =0;
        billingno = new String("");
        ocsstat = 1;
        ocs = 0;
        enumStat = 0;
        primaryEnumDomain = new String("");
        altEnumDomain = new String("");
        maxenterprise = 0;
        activeInd = 1;
        createdBy = new String("");
        modifiedBy = new String("");
		//getAll = false;
    	this.envOrderId = 0; 
    	this.liInd= -1; 
    	this.apacInd= -1; 
    	this.oldOnNetStat= -1; 
		this.enumistat= 0;
	}
	
}

