/**
 * 
 */
package com.vz.esap.api.connector.service.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.StringTokenizer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.vz.esap.api.connector.util.DomainInterfaceUtil;
import com.vz.esap.api.connector.util.SetSelectColumnUtil;
import com.vz.esap.api.constant.ESAPDBQueryEnum;
import com.vz.esap.api.exception.ApplicationInterfaceException;
import com.vz.esap.api.exception.VZBAFException;
import com.vz.esap.api.generated.pojo.DBOperationRequest;
import com.vz.esap.api.generated.pojo.DBOperationResponse;
import com.vz.esap.api.generated.pojo.DatabaseServiceRequest;
import com.vz.esap.api.generated.pojo.DatabaseServiceResponse;
import com.vz.esap.api.generated.pojo.WhereClause;
import com.vz.esap.api.model.DBServiceResponse;
import com.vz.esap.api.model.TblRow;
import com.vz.esap.api.service.model.DepartmentBean;
import com.vz.esap.api.service.model.DeviceTypeBean;
import com.vz.esap.api.service.model.DigitStringBean;
import com.vz.esap.api.service.model.EnterpriseBean;
import com.vz.esap.api.service.model.FeaturePackageBean;
import com.vz.esap.api.service.model.FeaturesBean;
import com.vz.esap.api.service.model.TblGroupFeaturesDbBean;
import com.vz.esap.api.service.model.TblSubFeatureDbBean;
import com.vz.esap.api.service.model.VzbFeaturesDbBean;

/**
 * @author Aricent
 * 
 */
@Service
public class InventoryDomainDataServiceImpl {

	private static final Logger logger = LoggerFactory.getLogger(InventoryDomainDataServiceImpl.class);
	private static final String INVENTORY_DOMAIN_SERVICE = "InventoryDomainService:";
	private ObjectMapper mapper = new ObjectMapper();
	private DomainInterfaceUtil domainInterfaceUtil = DomainInterfaceUtil.getDomainInterfaceUtil();
	
	
	/*@Autowired
	private RestTemplate restTemplate;*/
	private RestTemplate restTemplate = new RestTemplate();
	@Value("${inventory.databaseServiceUrl}")
	private String inventoryDatabaseServiceURL; 
	@Value("${inventory.dbOperationsUrl}")
	private String inventoryDatabasePreConfiguredQueryServiceURL;
	//private String inventoryDatabaseServiceURL = "http://pbxomzstd03.vzbi.com:40016/dataBase";


	private DBServiceResponse searchInventory(String tableName, Set<String> selectColumnSet,
			List<String[]> whereClauseList) throws ApplicationInterfaceException {
		DBServiceResponse responseData = null;

		logger.debug("Entering searchInventory(): {} ");

		
		try {

			DatabaseServiceRequest request = new DatabaseServiceRequest();
			request.setDbOperation("SELECT");
			request.setTableName(tableName);
			List<String> selectColumnList = new ArrayList<String>(selectColumnSet);
			logger.info("searchInventory(): Table: {} SelectColumn: {} WhereCondition: {}", tableName, selectColumnList,
					whereClauseList);
			request.setColumnNames(selectColumnList);
			WhereClause whereClauseRequest = new WhereClause();

			List<String> whereClauseColumnName = new ArrayList<>();
			List<String> whereClauseColumnValue = new ArrayList<>();
			for (String[] whereClauseArray : whereClauseList) {
				whereClauseColumnName.add(whereClauseArray[0]);
				whereClauseColumnValue.add(whereClauseArray[1]);
			}
			whereClauseRequest.setColumnNames(whereClauseColumnName);
			whereClauseRequest.setColumnValues(whereClauseColumnValue);
			request.setWhereClause(Collections.singletonList(whereClauseRequest));

			long startTime = System.currentTimeMillis();
			logger.info("searchInventory(): Making HTTP POST Request for tableName:{} at time:{}", tableName,
					startTime);
			logger.debug("searchInventory(): Service URL: {}", inventoryDatabaseServiceURL);
			
			logger.info("searchInventory(): Service request: {}", mapper.writerWithDefaultPrettyPrinter().writeValueAsString(request));
			

			DatabaseServiceResponse inventoryDBServiceResponse = restTemplate
					.postForObject(inventoryDatabaseServiceURL, request,
							DatabaseServiceResponse.class);
			
			if (inventoryDBServiceResponse == null)
				throw new ApplicationInterfaceException("No response received from Inventory DB service");

			long endTime = System.currentTimeMillis();

			logger.debug("searchInventory(): HTTP Response: {} ", inventoryDBServiceResponse);

			responseData = domainInterfaceUtil.convertDBResponseToTblData(inventoryDBServiceResponse);

			logger.debug("searchInventory(): Received HTTP POST Response for tableName:{} at time:{}", tableName,
					endTime);
			logger.info("searchInventory(): Time taken for Response for tableName:{} is:{} ms", tableName,
					(endTime - startTime));

			logger.info("Exiting searchInventory() ");

		} catch (HttpStatusCodeException e) {
			logger.error("Exception received from InventoryDBService Service: {} ", inventoryDatabaseServiceURL);
			logger.error("Exception received from InventoryDBService Service: {} ", e);
			logger.error("Execption during searchInventory execution code:{} , text:{}", e.getStatusCode(),
					e.getResponseBodyAsString());
			throw new ApplicationInterfaceException(INVENTORY_DOMAIN_SERVICE + e.getMessage());
		} catch (RestClientException e) {
			logger.error("Exception received from InventoryDBService Service: {} ", inventoryDatabaseServiceURL);
			logger.error("Exception received from InventoryDBService Service: {} ", e);
			throw new ApplicationInterfaceException(INVENTORY_DOMAIN_SERVICE + e.getMessage());
		} catch (JsonProcessingException e) {
			logger.error("Exception received from InventoryDBService Service: {} ", inventoryDatabaseServiceURL);
			logger.error("Exception received from InventoryDBService Service: {} ", e);
			throw new ApplicationInterfaceException(INVENTORY_DOMAIN_SERVICE + e.getMessage());
		}

		return responseData;
	}

	/**
	 * @param tableName
	 * @param updateKeyValuePairList
	 * @param whereClauseList
	 * @return numOfRecordsUpdated
	 * @throws ApplicationInterfaceException
	 */
	private Long updateInventory(String tableName, List<String[]> updateKeyValuePairList, List<String[]> whereClauseList)
			throws ApplicationInterfaceException {

		logger.info("Entering updateInventory(): {} ", tableName);
	
		
		Long numberOfRecords = null;

		try {

			logger.debug("searchInventory(): Request Message: {}", tableName);
			DatabaseServiceRequest request = new DatabaseServiceRequest();
			request.setDbOperation("UPDATE");
			request.setTableName(tableName);

			List<String> updateColumnNameList = new ArrayList<>();
			List<String> updateColumnValueList = new ArrayList<>();
			for (String[] updateKeyValuePairArray : updateKeyValuePairList) {
				updateColumnNameList.add(updateKeyValuePairArray[0]);
				updateColumnValueList.add(updateKeyValuePairArray[1]);
			}
			request.setColumnNames(updateColumnNameList);
			request.setColumnValues(updateColumnValueList);

			WhereClause whereClauseRequest = new WhereClause();

			List<String> whereClauseColumnName = new ArrayList<>();
			List<String> whereClauseColumnValue = new ArrayList<>();
			for (String[] whereClauseArray : whereClauseList) {
				whereClauseColumnName.add(whereClauseArray[0]);
				whereClauseColumnValue.add(whereClauseArray[1]);
			}
			whereClauseRequest.setColumnNames(whereClauseColumnName);
			whereClauseRequest.setColumnValues(whereClauseColumnValue);
			request.setWhereClause(Collections.singletonList(whereClauseRequest));

			long startTime = System.currentTimeMillis();

			logger.info("updateInventory(): Making HTTP POST Request for workOrderNumber:{} at time:{}", tableName,
					startTime);
			logger.info("updateInventory(): Service URL: {}", inventoryDatabaseServiceURL);
			logger.info("updateInventory(): Service restTemplate: {}", restTemplate);

			logger.info("updateInventory(): Making HTTP POST Request for workOrderNumber:{} at time:{}", tableName,
					startTime);
			logger.info("updateInventory(): Service URL: {}", inventoryDatabaseServiceURL);
			logger.info("updateInventory(): Service restTemplate: {}", restTemplate);
			logger.info("searchInventory(): Service request: {}", mapper.writerWithDefaultPrettyPrinter().writeValueAsString(request));

			DatabaseServiceResponse inventoryDBServiceResponse = restTemplate.postForObject(inventoryDatabaseServiceURL,
					request, DatabaseServiceResponse.class);

			long endTime = System.currentTimeMillis();

			logger.info("InventoryDBResponse:" + inventoryDBServiceResponse);

			if (inventoryDBServiceResponse == null) {
				throw new ApplicationInterfaceException("No response received");
			}

			numberOfRecords = inventoryDBServiceResponse.getNumberOfRecords() == null ? 0 : inventoryDBServiceResponse.getNumberOfRecords();

			logger.info("updateInventory(): Received HTTP POST Response for tableName:{} at time:{}", tableName,
					endTime);
			logger.info("updateInventory(): Time taken for Response for tableName:{} is:{} ms", tableName,
					(endTime - startTime));

			logger.debug("updateInventory(): Response from InventoryDBService: {}", inventoryDBServiceResponse);

			logger.info("Exiting updateInventory() : No. of Records updated : {} ", numberOfRecords);

		} catch (HttpStatusCodeException e) {
			logger.error("Exception received from InventoryDBService Service: {} ", inventoryDatabaseServiceURL);
			logger.error("Exception received from InventoryDBService Service: {} ", e);
			logger.error("Execption during searchInventory execution code:{} , text:{}", e.getStatusCode(),
					e.getResponseBodyAsString());
			throw new ApplicationInterfaceException(INVENTORY_DOMAIN_SERVICE + e.getMessage());

		} catch (RestClientException e) {
			logger.error("Exception received from InventoryDBService Service: {} ", inventoryDatabaseServiceURL);
			logger.error("Exception received from InventoryDBService Service: {} ", e);
			throw new ApplicationInterfaceException(INVENTORY_DOMAIN_SERVICE + e.getMessage());
		} catch (JsonProcessingException e) {
			logger.error("Exception received from InventoryDBService Service: {} ", inventoryDatabaseServiceURL);
			logger.error("Exception received from InventoryDBService Service: {} ", e);
			throw new ApplicationInterfaceException(INVENTORY_DOMAIN_SERVICE + e.getMessage());
		}

		return numberOfRecords;
	}

	/**
	 * @param tableName
	 * @param insertKeyValuePairList
	 * @param sequenceKeyValuePairList
	 * @return numOfRecordsUpdated
	 * @throws ApplicationInterfaceException
	 */
	private Long insertInventory(String tableName, List<String[]> insertKeyValuePairList,
			List<String[]> sequenceKeyValuePairList) throws ApplicationInterfaceException {

		logger.info("Entering insertInventory(): {} ", tableName);
		
		Long numberOfRecords = null;

		try {

			logger.debug("insertInventory(): Request Message: {}", tableName);
			DatabaseServiceRequest request = new DatabaseServiceRequest();
			request.setDbOperation("INSERT");
			request.setTableName(tableName);

			List<String> updateColumnNameList = new ArrayList<>();
			List<String> updateColumnValueList = new ArrayList<>();
			for (String[] updateKeyValuePairArray : insertKeyValuePairList) {
				updateColumnNameList.add(updateKeyValuePairArray[0]);
				updateColumnValueList.add(updateKeyValuePairArray[1]);
			}
			request.setColumnNames(updateColumnNameList);
			request.setColumnValues(updateColumnValueList);

			if (sequenceKeyValuePairList != null) {
				List<String> sequenceColumnNameList = new ArrayList<>();
				List<String> sequenceColumnValueList = new ArrayList<>();
				for (String[] sequenceKeyValueArray : sequenceKeyValuePairList) {
					sequenceColumnNameList.add(sequenceKeyValueArray[0]);
					sequenceColumnValueList.add(sequenceKeyValueArray[1]);
				}
				request.setSequenceColumnName(sequenceColumnNameList);
				request.setSequenceColumnValue(sequenceColumnValueList);
			}

			long startTime = System.currentTimeMillis();

			logger.info("insertInventory(): Making HTTP POST Request for workOrderNumber:{} at time:{}", tableName,
					startTime);
			logger.info("insertInventory(): Service URL: {}", inventoryDatabaseServiceURL);
			//logger.info("insertInventory(): Service request: {}", request);
			logger.info("searchInventory(): Service request: {}", mapper.writerWithDefaultPrettyPrinter().writeValueAsString(request));

			DatabaseServiceResponse inventoryDBServiceResponse = restTemplate.postForObject(inventoryDatabaseServiceURL,
					request, DatabaseServiceResponse.class);

			if (inventoryDBServiceResponse == null) {
				throw new ApplicationInterfaceException("insertInventory(): No response received");
			}

			long endTime = System.currentTimeMillis();
			
			numberOfRecords = inventoryDBServiceResponse.getNumberOfRecords() == null ? 0 : inventoryDBServiceResponse.getNumberOfRecords();

			logger.info("insertInventory(): Received HTTP POST Response for tableName:{} at time:{}", tableName,
					endTime);
			logger.info("insertInventory(): Time taken for Response for tableName:{} is:{} ms", tableName,
					(endTime - startTime));
			logger.debug("insertInventory(): Response from InventoryDBService: {}", inventoryDBServiceResponse);
			logger.info("Exiting insertInventory() ");

		} catch (HttpStatusCodeException e) {
			logger.error("Exception received from InventoryDBService Service: {} ", inventoryDatabaseServiceURL);
			logger.error("Exception received from InventoryDBService Service: {} ", e);
			logger.error("Execption during insertInventory execution code:{} , text:{}", e.getStatusCode(),
					e.getResponseBodyAsString());
			throw new ApplicationInterfaceException(INVENTORY_DOMAIN_SERVICE + e.getMessage());
		} catch (RestClientException e) {
			logger.error("Exception received from InventoryDBService Service: {} ", inventoryDatabaseServiceURL);
			logger.error("Exception received from InventoryDBService Service: {} ", e);
			throw new ApplicationInterfaceException(INVENTORY_DOMAIN_SERVICE + e.getMessage());
		} catch (JsonProcessingException e) {
			logger.error("Exception received from InventoryDBService Service: {} ", inventoryDatabaseServiceURL);
			logger.error("Exception received from InventoryDBService Service: {} ", e);
			throw new ApplicationInterfaceException(INVENTORY_DOMAIN_SERVICE + e.getMessage());
		}
		return numberOfRecords;
	}

	@SuppressWarnings("unchecked")
	private <T> T searchInventoryForSingleValue(String tableName, String columnName, List<String[]> whereClauseList,
			Class<T> responseClass) throws ApplicationInterfaceException {
		Set<String> selectColumnSet = new HashSet<>();
		selectColumnSet.add(columnName);
		T responseType = null;

		try {
			HashSet<String> supportedType = new HashSet<>();
			supportedType.add("java.lang.String");
			supportedType.add("java.lang.Integer");
			supportedType.add("java.lang.Long");
			supportedType.add("java.lang.Float");
			supportedType.add("java.lang.Double");

			String responseClassType = responseClass.getName();
			//System.out.println("responseClassType:" + responseClassType);

			if (!supportedType.contains(responseClassType))
				throw new ApplicationInterfaceException("Unsupported dataype");

			DBServiceResponse tblData = searchInventory(tableName, selectColumnSet, whereClauseList);

			Optional<String> responseValueOpt = Optional.ofNullable(tblData)
					.map(tblDataObj -> tblDataObj.getTableRows())
					.map(tblRows -> tblRows.size() > 0 ? tblRows.get(0) : null).map(firstRow -> firstRow.getTblRow())
					.map(firstRowCells -> firstRowCells.get(columnName)).map(specificCell -> specificCell.getValue());

			String responseValue = responseValueOpt.orElse(null);
			if (responseValue != null && !"".equalsIgnoreCase(responseValue.trim())) {
				switch (responseClassType) {
				case "java.lang.String":
					responseType = (T) responseValue;
					break;
				case "java.lang.Integer":
					responseType = (T) Integer.valueOf(responseValue);
					break;
				case "java.lang.Long":
					responseType = (T) Long.valueOf(responseValue);
					break;
				case "java.lang.Float":
					responseType = (T) Float.valueOf(responseValue);
					break;
				case "java.lang.Double":
					responseType = (T) Double.valueOf(responseValue);
				}
			}

		} catch (Exception e) {
			logger.error("Exception received from InventoryDBService Service: {} ", e);
			throw new ApplicationInterfaceException(INVENTORY_DOMAIN_SERVICE + e.getMessage());
		}

		return responseType;
	}

	
	public int getWeightFromTG(String trunkGroupIdStr, int priority) throws ApplicationInterfaceException {
		ArrayList<String[]> whereClause = new ArrayList<String[]>();
		whereClause.add(new String[] { "trunk_group_id", trunkGroupIdStr });
		whereClause.add(new String[] { "priority", priority + "" });
		Integer weight = searchInventoryForSingleValue("tbl_tso_et_tg_map", "weight", whereClause, Integer.class);
		logger.info("getWeightFromTG() : weight: {} for TrunkGroupId: {} and priority: {} ", weight, trunkGroupIdStr, priority);
		if (weight == null || weight.intValue() == 0) {
			logger.debug("Entry not found for TG " + trunkGroupIdStr + " and priority " + priority);
			weight = genWeightFromInv(trunkGroupIdStr);
		}
		logger.info("getWeightFromTG() : Returning weight: {} for TrunkGroupId: {} and priority: {} ", weight, trunkGroupIdStr, priority);
		return weight;
	}

	private Integer genWeightFromInv(String trunkGrpId) throws ApplicationInterfaceException {

		logger.debug("genWeightFromInv " + trunkGrpId);
		StringBuffer qryBuffer = new StringBuffer();
		// "select esbc.bandwidth , eb.weight from tbl_tso_et_ebi_map eb ,
		// tbl_tso_trunk_group tg, tbl_tso_enterprise_sbc_map esbc,
		// tbl_tso_enterprise_trunk et where tg.trunk_group_id= ? and
		// eb.ebi_id=tg.ebi_id and tg.nwk_node_device_id =
		// esbc.nwk_node_device_id and et.enterprise_id=esbc.ENTERPRISE_ID and
		// et.enterprise_trunk_id = eb.enterprise_trunk_id"
		PreparedStatement pstm = null;
		ResultSet res = null;
		// long tgId = Long.parseLong(trunkGrpId);
		int sbcBandwidth = 0;
		int weight = 0;
		int ebiWeight = 0;
		int WEIGHT_MIN = 1;
		int WEIGHT_MAX = 65536;

		Map<Integer, Integer> trunkGroupSbcMap = new HashMap<Integer, Integer>();

		HashSet<String> columnNames = new HashSet<String>();
		columnNames.add("bandwidth");
		columnNames.add("weight");
		ArrayList<String[]> whereClause = new ArrayList<String[]>();
		whereClause.add(new String[] { "trunk_group_id", trunkGrpId });

		DBServiceResponse resultTblData = searchInventory("tbl_tso_et_ebi_map ", columnNames, whereClause);

		for (TblRow tblRows : resultTblData.getTableRows()) {
			sbcBandwidth = Integer.parseInt(tblRows.getTblRow().get("bandwidth").getValue());
			weight = Integer.parseInt(tblRows.getTblRow().get("weight").getValue());
		}

		int sbcBwMbps = sbcBandwidth / 1000;

		if (sbcBwMbps <= 1)
			sbcBwMbps = 1;

		ebiWeight = (weight * sbcBwMbps) / 10;

		if (ebiWeight <= 0)
			ebiWeight = WEIGHT_MIN;

		if (ebiWeight >= 65536)
			ebiWeight = WEIGHT_MAX;

		logger.info("ebiWeight " + ebiWeight);

		return ebiWeight;
	}

	
	public String getTrunkGroupName(int trunkGroupId) throws ApplicationInterfaceException {

		// sql.append("select trunk_group_name from TBL_TSO_TRUNK_GROUP where
		// trunk_group_id=?");

		ArrayList<String[]> whereClause = new ArrayList<String[]>();
		whereClause.add(new String[] { "trunk_group_id", Integer.toString(trunkGroupId) });
		String result = searchInventoryForSingleValue("TBL_TSO_TRUNK_GROUP", "trunk_group_name", whereClause,
				String.class);
		return result;

	}

	
	public String getRoutingGroupId(int trunkGroupId) throws ApplicationInterfaceException {

		// String ROUTING_GROUP_ID_SQL =
		// "SELECT ROUTING_GROUP_ID FROM TBL_TSO_TRUNK_GROUP WHERE
		// TRUNK_GROUP_ID=?";

		ArrayList<String[]> whereClause = new ArrayList<String[]>();
		whereClause.add(new String[] { "ROUTING_GROUP_ID", Integer.toString(trunkGroupId) });
		String result = searchInventoryForSingleValue("tbl_tso_et_tg_map", "ROUTING_GROUP_ID", whereClause,
				String.class);
		return result;

	}

	
	public Map<Integer, Integer> getTrunkGroupSbcMap(long ebiId) throws ApplicationInterfaceException {

		// String TRUNK_GROUP_SBC_INFO_SQL =
		// "SELECT TRUNK_GROUP_ID, NWK_NODE_DEVICE_ID FROM TBL_TSO_TRUNK_GROUP
		// WHERE EBI_ID=?"

		Map<Integer, Integer> trunkGroupSbcMap = new HashMap<Integer, Integer>();

		HashSet<String> columnNames = new HashSet<String>();
		columnNames.add("TRUNK_GROUP_ID");
		columnNames.add("NWK_NODE_DEVICE_ID");
		ArrayList<String[]> whereClause = new ArrayList<String[]>();
		whereClause.add(new String[] { "ROUTING_GROUP_ID", Long.toString(ebiId) });
		DBServiceResponse resultTblData = searchInventory("TBL_TSO_TRUNK_GROUP", columnNames, whereClause);

		for (TblRow tblRows : resultTblData.getTableRows()) {
			String trunkGroupId = tblRows.getTblRow().get("TRUNK_GROUP_ID").getValue();
			String nwkNodeDeviceId = tblRows.getTblRow().get("NWK_NODE_DEVICE_ID").getValue();
			trunkGroupSbcMap.put(Integer.valueOf(trunkGroupId), Integer.valueOf(nwkNodeDeviceId));
		}
		return trunkGroupSbcMap;
	}

	
	public int getSbcBandwidth(String enterpriseId, int nwkNodeDeviceId) throws ApplicationInterfaceException {

		// String SBC_BANDWIDTH_SQL =
		// "select BANDWIDTH from TBL_TSO_ENTERPRISE_SBC_MAP where
		// NWK_NODE_DEVICE_ID=? and ENTERPRISE_ID = ?";

		ArrayList<String[]> whereClause = new ArrayList<String[]>();
		whereClause.add(new String[] { "ENTERPRISE_ID", enterpriseId });
		whereClause.add(new String[] { "NWK_NODE_DEVICE_ID", Integer.toString(nwkNodeDeviceId) });
		Integer result = searchInventoryForSingleValue("TBL_TSO_ENTERPRISE_SBC_MAP", "BANDWIDTH", whereClause,
				Integer.class);
		result = (result == null) ? 0 : result;
		return result;
	}

	
	public HashMap<Integer, List<Integer>> getPriorityTrunkGroupFromET(String enterpriseTrunkId)
			throws ApplicationInterfaceException {
		// sql.append("select trunk_group_id, priority from tbl_tso_et_tg_map
		// where enterprise_trunk_id=? ")

		HashSet<String> columnNames = new HashSet<String>();
		columnNames.add("trunk_group_id");
		columnNames.add("priority");
		ArrayList<String[]> whereClause = new ArrayList<String[]>();
		whereClause.add(new String[] { "enterprise_trunk_id", enterpriseTrunkId });
		DBServiceResponse resultTblData = searchInventory("tbl_tso_et_tg_map", columnNames, whereClause);

		HashMap<Integer, List<Integer>> priorityAndTrunkGroup = new HashMap<Integer, List<Integer>>();

		for (TblRow entry : resultTblData.getTableRows()) {

			if (entry.getTblRow().get("priority").getValue() != null
					&& entry.getTblRow().get("trunk_group_id").getValue() != null) {
				int priority = Integer.parseInt(entry.getTblRow().get("priority").getValue());
				int trunkGroupId = Integer.parseInt(entry.getTblRow().get("trunk_group_id").getValue());
				List<Integer> trunkGroupList = priorityAndTrunkGroup.get(priority);
				if (trunkGroupList != null) {
					trunkGroupList.add(trunkGroupId);
				} else {
					trunkGroupList = new ArrayList<Integer>();
					trunkGroupList.add(trunkGroupId);
					priorityAndTrunkGroup.put(priority, trunkGroupList);
				}
				// trunkGroupCount += trunkGroupList.size();
			}
		}

		return priorityAndTrunkGroup;

	}

	
	public void updateTNStatus(int status, String tn) throws ApplicationInterfaceException {

		List<String[]> updateKeyValuePairList = new ArrayList<>();
		updateKeyValuePairList.add(new String[] { "STATUS", String.valueOf(status) });

		List<String[]> whereClauseList = new ArrayList<>();
		whereClauseList.add(new String[] { "TN", tn });

		Long numRecords = updateInventory("TBL_TSO_RG_CLID_POOL", updateKeyValuePairList, whereClauseList);
		logger.info("updateTNStatus: No. of records updated: {}", numRecords);
	}

	
	public void updateGroupClid(String tnToAdd, String enterpriseId, String routingGroupId)
			throws ApplicationInterfaceException {

		List<String[]> updateKeyValuePairList = new ArrayList<>();
		updateKeyValuePairList.add(new String[] { "GROUP_CLID", tnToAdd });

		List<String[]> whereClauseList = new ArrayList<>();
		whereClauseList.add(new String[] { "ENTERPRISE_ID", enterpriseId });
		whereClauseList.add(new String[] { "ROUTING_GROUP_ID", routingGroupId });

		updateInventory("TBL_TSO_ROUTING_GROUP", updateKeyValuePairList, whereClauseList);
	}

	
	public String getTn() throws ApplicationInterfaceException {
		List<String[]> whereClause = new ArrayList<>();
		whereClause.add(new String[] { "STATUS", "0" });
		whereClause.add(new String[] { "ROWNUM", "1" });

		String tnToAdd = searchInventoryForSingleValue("TBL_TSO_RG_CLID_POOL", "TN", whereClause, String.class);
		return tnToAdd;
	}

	
	public List<String> getEnterpriseAuthFeatures(String enterpriseId, String featureType)
			throws ApplicationInterfaceException {
		List<String> featureList = new ArrayList<String>();

		/*
		 * select F.NAME FROM TBL_ENTERPRISE E, TBL_AUTH_SERVICES S ,
		 * TBL_VZB_FEATURES F WHERE E.AUTH_SERVICES_ID = S.AUTH_SERVICE_ID AND
		 * S.FEATURE_ID = F.FEATURE_ID AND E.ENTERPRISE_ID = ? --100013170 AND
		 * E.ACTIVE_IND = 1 AND S.IS_AUTHORIZED = 'Y' AND F.FEATURE_TYPE = ?
		 * --'U';
		 */

		List<String> values = Arrays.asList(enterpriseId, featureType);
		DBServiceResponse response = executePreconfiguredQuery(ESAPDBQueryEnum.GET_ENT_AUTH_FEATURE_NAME, "Network", values);

		/*if (response == null || response.getTableRows() == null || response.getTableRows().isEmpty()) {
			throw new ApplicationInterfaceException("No Data Found in the DB");
		}*/
		
		for (TblRow row : response.getTableRows()) {
			featureList.add(row.getTblRow().get("NAME").getValue());
		}
		return featureList;

	}
	
	
	
	public List<String> getEntAuthFeatureIdList(String enterpriseId, String featureType) throws ApplicationInterfaceException {
		List<String> featureList = new ArrayList<String>();
		
		/*select F.FEATURE_ID FROM TBL_ENTERPRISE E, TBL_AUTH_SERVICES  S , TBL_VZB_FEATURES F
		WHERE E.AUTH_SERVICES_ID = S.AUTH_SERVICE_ID
		AND S.FEATURE_ID = F.FEATURE_ID
		AND E.ENTERPRISE_ID = ? --100013170 AND E.ACTIVE_IND = 1
		AND S.IS_AUTHORIZED = 'Y'
		AND F.FEATURE_TYPE = ? --'U';*/
		
		
		List<String> values = Arrays.asList(enterpriseId, featureType);
		DBServiceResponse response = executePreconfiguredQuery(ESAPDBQueryEnum.GET_ENT_AUTH_FEATURE_ID, "Network", values);
		/*if (response == null || response.getTableRows() == null || response.getTableRows().isEmpty()) {
			throw new ApplicationInterfaceException("No Data Found in the DB");
		}*/
		for (TblRow row : response.getTableRows()) {
			featureList.add(row.getTblRow().get("FEATURE_ID").getValue());
		}
		return featureList;

	}

	
	public int getEnterpriseTrunkCallCapacity(String enterpriseId) throws ApplicationInterfaceException {

		// Query = SELECT
		// ENTERPRISE_ID,CUST_TYPE,CUST_MARKET,PLATFORM_INDICATOR,VM_PARTITION_ID,PUBIP,ON_NET_INTERCO,SIP_DOMAIN,AS_ID,ENTCCL_IND,IEAN_LENGTH,QOS_IND,VNET_CORP_ID,CONTRACT_IND,AGENCY_HIER_CODE,XREF_CUSTOMER_ID,CALLING_PLAN_ID,AUTH_SERVICES_ID,ACTIVE_IND,CREATED_BY,
		// CREATION_DATE,MODIFIED_BY,LAST_MODIFIED_DATE,BS_BLOCK_IND,ENV_ORDER_ID,SBC_ACTIVATION_SYSTEM,
		// SLA_TYPE,RIV_CUSTOMER,SBC_MIG_IND,IPAC_FLAG,LOR_FLAG,ENT_TRUNK_CCL_SUM,LOAD_SHARING,LOR_ID,
		// ADDRESS,CITY,STATE,ZIP,COUNTRY,SO_ENABLED,US_LD_AND_LOCAL_BEST_POOL,US_LD_ONLY_BEST_POOL,
		// EMEA_APAC_BEST_POOL,HYBRID_IND,APPROVED_CCL,CUST_PRICE_BOOK_ID,CONTRACT_ID,
		// QUOTE_ID,DESIGN_ID,US_LD_AND_LOCAL_BEST_PLUS_POOL,US_LD_ONLY_BEST_PLUS_POOL,
		// EMEA_APAC_BEST_PLUS_POOL,CATALOGUE_REFERENCE_TIME,DEF_SUBNET,ENT_CUM_CCL
		// FROM TBL_ENTERPRISE
		// where ENTERPRISE_ID = '"+enterpriseId+"';
		int entTrunkCC = 0;
		long tmpTrunkCC = 0;
		try {
			ArrayList<String[]> whereClause = new ArrayList<String[]>();
			whereClause.add(new String[] { "ENTERPRISE_ID", enterpriseId });
			tmpTrunkCC = searchInventoryForSingleValue("TBL_ENTERPRISE", "ENT_TRUNK_CCL_SUM", whereClause, Long.class);
			// return result;
		} catch (Exception e) {
			logger.error("Exception in getEnterpriseTrunkCallCapacity(): {} ", e);
			tmpTrunkCC = 0;
		}
		entTrunkCC = (int) tmpTrunkCC;
		return entTrunkCC;
	}

	
	public List<String> getFeatureIdList(String cntryCode) throws ApplicationInterfaceException {
		// sql query= select feature_id, facode from tbl_facodes where
		// cntry_code = \'" + getCntryCode() + "\'
		// union select feature_id, facode from tbl_facodes where feature_id not
		// in (select feature_id from tbl_facodes where cntry_code = \'" +
		// getCntryCode() + "\') and cntry_code = \'ALL\'"
		List<String> facodeList = null;
		try {
			HashSet<String> columnNames = new HashSet<String>();
			columnNames.add("feature_id");
			columnNames.add("facode");
			ArrayList<String[]> whereClause = new ArrayList<String[]>();
			if (cntryCode != null && !"".equals(cntryCode)) {
				whereClause.add(new String[] { "cntry_code", cntryCode });
			} else {
				whereClause.add(new String[] { "cntry_code", "ALL" });
			}

			DBServiceResponse facodeTableData = searchInventory("TBL_ENTERPRISE", columnNames, whereClause);
			facodeList = new ArrayList<String>();
			for (TblRow tblRows : facodeTableData.getTableRows()) {
				facodeList.add(tblRows.getTblRow().get("feature_id").getValue());
			}
		} catch (Exception e) {
			logger.error("Exception in getFeatureIdList(): {} ", e);
			// log_msg("Exception in getEnterpriseTrunkCallCapacity() :"+e);
		}
		return facodeList;
	}

	
	public Map<String, String> getFacodeDetails(String cntryCode) throws ApplicationInterfaceException {
		Map<String, String> faCodeFeatureMap = null;
		try {
			HashSet<String> columnNames = new HashSet<String>();
			columnNames.add("feature_id");
			columnNames.add("facode");
			ArrayList<String[]> whereClause = new ArrayList<String[]>();
			if (cntryCode != null && !"".equals(cntryCode)) {
				whereClause.add(new String[] { "cntry_code", cntryCode });
			} else {
				whereClause.add(new String[] { "cntry_code", "ALL" });
			}

			DBServiceResponse facodeTableData = searchInventory("TBL_ENTERPRISE", columnNames, whereClause);
			faCodeFeatureMap = new HashMap<String, String>();
			for (TblRow tblRows : facodeTableData.getTableRows()) {
				String featureId = tblRows.getTblRow().get("feature_id").getValue();
				String facode = tblRows.getTblRow().get("facode").getValue();
				faCodeFeatureMap.put(featureId, facode);
			}
		} catch (Exception e) {
			logger.error("Exception in getFacodeDetails(): {} ", e);
		}
		return faCodeFeatureMap;
	}

	// TODO Implementation Pending
	public boolean getAuthDetailsForEnterprise(String enterpriseId, EnterpriseBean eb) {
		return false;/*
		try {
			final String COLUMN_TN = "AUTH_SERVICES_ID";
			final String TABLE_NAME = "TBL_ENTERPRISE";

			Set<String> columnNames = new HashSet<>();
			columnNames.add(COLUMN_TN);

			List<String[]> whereClause = new ArrayList<>();
			whereClause.add(new String[] { "ENTERPRISE_ID", enterpriseId });

			boolean getAll = false;
			if (!getAll) {
				whereClause.add(new String[] { "ACTIVE_IND", "1" });
			} else {
				whereClause.add(new String[] { "ACTIVE_IND", "0" });
			}

			
			 * Query: select AUTH_SERVICES_ID from TBL_ENTERPRISE where
			 * ACTIVE_IND = "1";
			 

			DBServiceResponse resultSet = searchInventory(TABLE_NAME, columnNames, whereClause);

			if (resultSet.getTableRows() == null || resultSet.getTableRows().isEmpty()) {
				throw new ApplicationInterfaceException("Result set is empty");
			}

			// Retrieving the AUTH_SERVICES_ID
			long authSerId = 0;
			for (TblRow tblRows : resultSet.getTableRows()) {
				try {
					authSerId = Long.parseLong(tblRows.getTblRow().get(COLUMN_TN).getValue());
				} catch (Exception e) {
					logger.error("Exception in getAuthDetailsForEnterprise(): {} ", e);
				}
			}

			if (authSerId > 0) {
				if (!getAuthFeaturesByAuthServicesId((int) authSerId, eb)) {
					// setStatus(InvErrorCode.INTERNAL_ERROR);
					// setStatusDesc("FAILURE in getAuthDetails Enterprise. No
					// auth services for the given auth services id.");
					logger.error(
							"FAILURE in getAuthDetails Enterprise. No auth services for the given  auth services id.");
					return false;
				}
			} else {
				// setStatus(InvErrorCode.INTERNAL_ERROR);
				// setStatusDesc("FAILURE in getAuthDetails Enterprise. Invalid
				// auth services id for enterprise");
				// System.out.println("FAILURE in getAuthDetails Enterprise.
				// Invalid auth services id for enterprise");
				return false;
			}

		} catch (Exception e) {
			logger.error("Exception in getAuthDetailsForEnterprise11(): {} ", e);
			// setStatus(InvErrorCode.DB_EXCEPTION);
			// setStatusDesc("DB FAILURE in getAuthDetails for Enterprise");
			return false;
		}
		// setStatus(InvErrorCode.SUCCESS);
		// setStatusDesc("Successfully retrieved auth details for enterprise
		// from the DB");
		return true;
	*/}

	// TODO Implementation Pending
	boolean getAuthFeaturesByAuthServicesId(int authServId, EnterpriseBean eb) throws ApplicationInterfaceException {
		return false;/*
		
		 * TblAuthServicesQuery authQry = new TblAuthServicesQuery();
		 * authQry.whereAuthServiceIdEQ(authServId); LogUtil.info(
		 * "before authFeaturesQry"); authQry.query(dbCon); LogUtil.info(
		 * "after authFeaturesQry");
		 
		final String COLUMN_TN = "AUTH_SERVICES_ID";
		final String COLUMN_TN1 = "FEATURE_ID";
		final String COLUMN_TN2 = "IS_AUTHORIZED";
		final String COLUMN_TN3 = "CREATED_BY";
		final String COLUMN_TN4 = "CREATION_DATE";
		final String COLUMN_TN5 = "MODIFIED_BY";
		final String COLUMN_TN6 = "LAST_MODIFIED_DATE";
		final String COLUMN_TN7 = "ENV_ORDER_ID";

		final String TABLE_NAME = "TBL_AUTH_SERVICES";

		Set<String> columnNames = new HashSet<>();
		columnNames.add(COLUMN_TN);
		columnNames.add(COLUMN_TN1);
		columnNames.add(COLUMN_TN2);
		columnNames.add(COLUMN_TN3);
		columnNames.add(COLUMN_TN4);
		columnNames.add(COLUMN_TN5);
		columnNames.add(COLUMN_TN6);
		columnNames.add(COLUMN_TN7);

		List<String[]> whereClause = new ArrayList<>();
		whereClause.add(new String[] { "AUTH_SERVICES_ID", Integer.toString(authServId) });

		
		 * Query: select AUTH_SERVICES_ID from TBL_ENTERPRISE where ACTIVE_IND =
		 * "1";
		 

		DBServiceResponse resultSet = searchInventory(TABLE_NAME, columnNames, whereClause);
		// EnterpriseBean eb= new EnterpriseBean();
		List<FeaturesBean> authFeaturesList = new ArrayList<FeaturesBean>();
		for (TblRow tblRows : resultSet.getTableRows()) {
			FeaturesBean featObj = new FeaturesBean();
			if ((tblRows.getTblRow().get("AUTH_SERVICES_ID").getValue() != null
					&& (((tblRows.getTblRow().get("AUTH_SERVICES_ID").getValue().equalsIgnoreCase("Y")))))) {
				featObj.setIsAuthorized(true);
			} else
				featObj.setIsAuthorized(false);
			if (Integer.parseInt(tblRows.getTblRow().get("ENV_ORDER_ID").getValue()) > 0)
				featObj.setEnvOrderId(Integer.parseInt(tblRows.getTblRow().get("ENV_ORDER_ID").getValue()));

			DBServiceResponse vzbFeatQrySet = getFeatureId(tblRows.getTblRow().get("FEATURE_ID").getValue());

			if (vzbFeatQrySet.getTableRows().size() == 1) {
				VzbFeaturesDbBean vzbFeatObj = new VzbFeaturesDbBean();
				for (TblRow tblvzbFeatRows : resultSet.getTableRows()) {
					vzbFeatObj.copyFromBean(tblvzbFeatRows);
				}
				// vzbFeatObj.copyFromBean(vzbFeatQry);
				featObj.setFeaturesDbBean(vzbFeatObj);
				authFeaturesList.add(featObj);
				eb.setAuthFeaturesList(authFeaturesList);
			}
		}
		if (authFeaturesList.size() <= 0) {
			logger.info("authFeatures list size is 0");
			return false;
		}
		logger.info("auth featrues list size:" + authFeaturesList.size());

		return true;
	*/}

	DBServiceResponse getFeatureId(String featureId) throws ApplicationInterfaceException {
		/*
		 * TblAuthServicesQuery authQry = new TblAuthServicesQuery();
		 * authQry.whereAuthServiceIdEQ(authServId); LogUtil.info(
		 * "before authFeaturesQry"); authQry.query(dbCon); LogUtil.info(
		 * "after authFeaturesQry");
		 */
		final String COLUMN_FEAT1 = "FEATURE_ID";
		final String COLUMN_FEAT2 = "NAME";
		final String COLUMN_FEAT3 = "DESCRIPTION";
		final String COLUMN_FEAT4 = "PLATFORM_INDICATOR";
		final String COLUMN_FEAT5 = "IASA_ID";
		final String COLUMN_FEAT6 = "ICP_ID";
		final String COLUMN_FEAT7 = "IS_BILLABLE";
		final String COLUMN_FEAT8 = "IS_BROADSOFT_HIDDEN";
		final String COLUMN_FEAT9 = "FEATURE_TYPE";
		final String COLUMN_FEAT10 = "FEATURE_LEVEL";
		final String COLUMN_FEAT11 = "MODIFIED_BY";
		final String COLUMN_FEAT12 = "LAST_MODIFIED_DATE";
		final String COLUMN_FEAT13 = "BILL_LEVEL";
		final String COLUMN_FEAT14 = "IS_DISPLAYABLE";
		final String COLUMN_FEAT15 = "CSSOP_DISABLE";
		final String COLUMN_FEAT16 = "E2EI_ALLOW_MOD";

		Set<String> columnFeatures = new HashSet<>();

		columnFeatures.add(COLUMN_FEAT1);
		columnFeatures.add(COLUMN_FEAT2);
		columnFeatures.add(COLUMN_FEAT3);
		columnFeatures.add(COLUMN_FEAT4);
		columnFeatures.add(COLUMN_FEAT5);
		columnFeatures.add(COLUMN_FEAT6);
		columnFeatures.add(COLUMN_FEAT7);
		columnFeatures.add(COLUMN_FEAT8);
		columnFeatures.add(COLUMN_FEAT9);
		columnFeatures.add(COLUMN_FEAT10);
		columnFeatures.add(COLUMN_FEAT11);
		columnFeatures.add(COLUMN_FEAT12);
		columnFeatures.add(COLUMN_FEAT13);
		columnFeatures.add(COLUMN_FEAT14);
		columnFeatures.add(COLUMN_FEAT15);
		columnFeatures.add(COLUMN_FEAT16);

		final String TABLE_NAME = "TBL_VZB_FEATURES";

		List<String[]> whereClause1 = new ArrayList<>();
		whereClause1.add(new String[] { "FEATURE_ID", featureId });

		DBServiceResponse resultSet = searchInventory(TABLE_NAME, columnFeatures, whereClause1);

		return resultSet;
	}

	public String getRoutingGroupId(String enterpriseId) throws ApplicationInterfaceException {

		// assignRoutingGroupId(enterpriseId);

		// select routing_group_id from tbl_tso_routing_group where
		// enterprise_id=?

		String routingGroupId = null;
		ArrayList<String[]> whereClause = new ArrayList<String[]>();
		whereClause.add(new String[] { "enterprise_id", enterpriseId });
		routingGroupId = searchInventoryForSingleValue("tbl_tso_routing_group", "routing_group_id", whereClause,
				String.class);

		return routingGroupId;
	}

	/**
	 * TODO Implementation pending
	 * 
	 * @param enterpriseId
	 * @return
	 * @throws Exception
	 */
	public boolean assignRoutingGroupId(String enterpriseId) throws ApplicationInterfaceException {

		// PreparedStatement stmtInsertNewRoutingGroupId = null;
		// ResultSet rsRoutingGroupIdGenerator = null;

		/*
		 * private static final String INSERT_NEW_ROUTING_GROUP_ID =
		 * "insert into tbl_tso_routing_group(" +
		 * "ROUTING_GROUP_ID,ROUTING_GROUP_NAME,ENTERPRISE_ID,GROUP_CLID,USE_FLAG,CREATED_BY,CREATION_DATE,MODIFIED_BY,LAST_MODIFIED_DATE) values "
		 * + "(?,?,?,?,?,?,?,?,?)";
		 */

		String routingGroupName = enterpriseId + "_RoutingGroup0";
		String routingGroupId = enterpriseId + "_RG0";
		String groupClId = null;
		String modifiedBy = "Admin";
		int useFlag = 1;
		String createdBy = "test";
		Timestamp creationDate = new Timestamp(System.currentTimeMillis());
		Timestamp lastModifiedDate = new Timestamp(System.currentTimeMillis());

		try {

			List<String[]> insertKeyValuePairList = new ArrayList<>();
			insertKeyValuePairList.add(new String[] { "ROUTING_GROUP_ID", routingGroupId });
			insertKeyValuePairList.add(new String[] { "ROUTING_GROUP_NAME", routingGroupName });
			insertKeyValuePairList.add(new String[] { "ENTERPRISE_ID", enterpriseId });
			insertKeyValuePairList.add(new String[] { "GROUP_CLID", groupClId });
			insertKeyValuePairList.add(new String[] { "USE_FLAG", String.valueOf(useFlag) });
			insertKeyValuePairList.add(new String[] { "CREATED_BY", createdBy });
			insertKeyValuePairList.add(new String[] { "CREATION_DATE", creationDate.toString() });
			insertKeyValuePairList.add(new String[] { "MODIFIED_BY", modifiedBy });
			insertKeyValuePairList.add(new String[] { "LAST_MODIFIED_DATE", lastModifiedDate.toString() });

			List<String[]> sequenceColumnNameValueList = new ArrayList<>();
			sequenceColumnNameValueList.add(new String[] { "ENTITY_ID", "TBL_ORDER_TASK_ENTITY_SEQ" });

			long count = insertInventory("TBL_TSO_ROUTING_GROUP", insertKeyValuePairList, null);

			if (count == 1) {
				return true;
			} else {
				logger.warn("Failed to insert Routing Group  : " + routingGroupName + " for Enterprise" + enterpriseId);
				return false;
			}

		} catch (Exception e) {
			logger.error("Exception in assignRoutingGroupId(): {} ", e);
			logger.error("Failed to insert Routing Group  : " + routingGroupName + " for Enterprise" + enterpriseId);
			throw new ApplicationInterfaceException("Failed to assign Routing Group" + routingGroupName);
		}
	}

	
	public String getBroadsoftTimeZone(String timeZone) throws ApplicationInterfaceException {

		logger.debug("In getBroadsoftTimeZone");
		logger.debug("timeZone = " + timeZone);

		String broadsoftTimeZone = null;

		if (timeZone == null)
			return null;

		ArrayList<String[]> whereClause = new ArrayList<String[]>();
		whereClause.add(new String[] { "TIME_ZONE_ID", timeZone });
		broadsoftTimeZone = searchInventoryForSingleValue("TBL_TIME_ZONE", "BS_ZONE", whereClause, String.class);

		if (broadsoftTimeZone == null || broadsoftTimeZone.length() == 0) {
			logger.debug("in getBroadsoftTimeZone; TimeZone.getTimeZoneMap() returned invalid/empty Map");
		} else {
			logger.debug("in getBroadsoftTimeZone; broadsoftTimeZone=" + broadsoftTimeZone);
		}

		/*
		 * TimeZone tz = new TimeZone(connection); if (tz.getTimeZones()) {
		 * Map<String, String> tzMap = tz.getTimeZoneMap();
		 * 
		 * if (tzMap == null || tzMap.size() < 1) { logger.debug(
		 * "in getBroadsoftTimeZone; TimeZone.getTimeZoneMap() returned invalid/empty Map"
		 * ); } else { broadsoftTimeZone = tzMap.get(timeZone); } } else {
		 * logger .debug(
		 * "in getBroadsoftTimeZone; TimeZone.getTimeZones() returned False" );
		 * }
		 * 
		 * logger.debug("in getBroadsoftTimeZone; broadsoftTimeZone=" +
		 * broadsoftTimeZone); return broadsoftTimeZone;
		 */
		return broadsoftTimeZone;
	}

	
	public String getDeviceType(String orderDeviceType) throws ApplicationInterfaceException {
		String bsDeviceType = null;

		ArrayList<String[]> whereClause = new ArrayList<String[]>();
		whereClause.add(new String[] { "ORDER_DEVICE_TYPE", orderDeviceType });
		bsDeviceType = searchInventoryForSingleValue("TBL_TSO_BS_DEVICE_MAP", "BS_DEVICE_TYPE", whereClause,
				String.class);

		return bsDeviceType;

	}

	//TODO Implementation pending
	
	public boolean isNewEbiAdded(long ebiIdInTod, String enterpriseTrunkId) throws ApplicationInterfaceException {
		return false;/*

		//TODO Implementation pending
		// select trunk_group_id from tbl_tso_et_Tg_map where trunk_group_id in
		// (select trunk_group_id from tbl_tso_trunk_group where ebi_id = ? )
		// and enterprise_trunk_id = ?"
		boolean isNewEbi = false;
		ArrayList<String[]> whereClause = new ArrayList<String[]>();
		// whereClause.add(new String[] { "ORDER_DEVICE_TYPE", orderDeviceType
		// });
		// bsDeviceType = searchInventoryForSingleValue("trunk_group_id",
		// "trunk_group_id", whereClause, String.class);

		return isNewEbi;
	*/}

	//TODO Implementation pending - insert api for VZB_BS_MOD_EBI_PRIORITY_WEIGHT_17
	
	public void doInsert(String enterpriseId, int trunkGroupId, int nwkNodeDeviceId, String enterpriseTrunkId,
			int priority, int weight, int status) throws ApplicationInterfaceException {/*
		//TODO Implementation pending
		logger.debug(" doInsert change for etId");
		int WEIGHT_MIN = 1;
		int WEIGHT_MAX = 65536;
		int trunkGroupWeight = 0;
		int sbcBandwidth = 0;
		logger.debug("weight from tod;" + weight);

		sbcBandwidth = getSbcBandwidth(enterpriseId, nwkNodeDeviceId);
		logger.debug("SbcBandwidth:" + sbcBandwidth);
		int sbcBwMbps = sbcBandwidth / 1000;
		if (sbcBwMbps <= 1)
			sbcBwMbps = 1;
		logger.debug("SbcBandwidth Mbps:" + sbcBwMbps);
		// Code changes for Naming Convention
		trunkGroupWeight = (weight * sbcBwMbps) / 10;
		if (trunkGroupWeight <= 0)
			trunkGroupWeight = WEIGHT_MIN;
		if (trunkGroupWeight >= WEIGHT_MAX)
			trunkGroupWeight = WEIGHT_MAX;
		logger.debug("TrunkGroupWeight:" + trunkGroupWeight);
		// String INSERT_ET_TG_ENTRY_SQL =
		// "INSERT INTO TBL_TSO_ET_TG_MAP(ENTERPRISE_TRUNK_ID, TRUNK_GROUP_ID,
		// PRIORITY, WEIGHT, STATUS) VALUES (?,?,?,?,?)";
		// stmt = conn.prepareStatement(INSERT_ET_TG_ENTRY_SQL);

	*/}

	//TODO Implementation pending
	
	public HashMap<Integer, List<Integer>> getPriorityTrunkGroupFromETEBIMap(String enterpriseTrunkId) {
		return null;/*
		//TODO Implementation pending
		logger.debug("Executing getPriorityTrunkGroupFromETEBIMap()... ");

		StringBuffer sql = new StringBuffer();
		PreparedStatement pStmt = null;
		ResultSet rs = null;

		List<Integer> trunkGroupIdList = new ArrayList<Integer>();

		HashMap<Integer, List<Integer>> trunkPriorityMap = new HashMap<Integer, List<Integer>>();

		// JOIN QUERY
		// sql.append("select distinct b.trunk_group_id , a.priority from
		// tbl_tso_et_ebi_map a ,tbl_tso_trunk_group b where b.ebi_id=a.ebi_id
		// and a.enterprise_trunk_id= ? ");

		try {
			HashSet<String> columnNames = new HashSet<String>();
			columnNames.add("trunk_group_id");
			columnNames.add("priority");

			ArrayList<String[]> whereClause = new ArrayList<String[]>();
			whereClause.add(new String[] { "enterprise_trunk_id", enterpriseTrunkId });

			// need to get data from join query
			// TblData facodeTableData =
			// searchInventory("tbl_tso_et_ebi_map & tbl_tso_trunk_group",
			// columnNames, whereClause);
			DBServiceResponse trunkPriorityData = null;
			for (TblRow tblRows : trunkPriorityData.getTableRows()) {
				int trunkGroupId = Integer.parseInt(tblRows.getTblRow().get("trunk_group_id").getValue());
				int priority = Integer.parseInt(tblRows.getTblRow().get("priority").getValue());
				if (!trunkPriorityMap.isEmpty() && trunkPriorityMap.containsKey(priority)) {
					trunkGroupIdList = trunkPriorityMap.get(priority);
					trunkGroupIdList.add(trunkGroupId);
					trunkPriorityMap.put(priority, trunkGroupIdList);
				} else {
					trunkGroupIdList = new ArrayList<Integer>();
					trunkGroupIdList.add(trunkGroupId);
					trunkPriorityMap.put(priority, trunkGroupIdList);
				}
				logger.debug("Fetched TrunkGroups and Priority for ET : " + enterpriseTrunkId + " Priority:" + priority
						+ " TrunkGroupList;" + trunkGroupIdList);
			}
		} catch (Exception e) {
			// log_msg("Exception in getEnterpriseTrunkCallCapacity() :"+e);
			e.printStackTrace();
		}
		logger.debug("returning trunkPriorityMap..." + trunkPriorityMap);
		return trunkPriorityMap;
	*/}

	
	public String getConfigParamValue(String processName, String paramName) throws ApplicationInterfaceException {
		String paramValue = "";

		ArrayList<String[]> whereClause = new ArrayList<String[]>();
		whereClause.add(new String[] { "PROCESS_NAME", processName });
		whereClause.add(new String[] { "PARAM_NAME", paramName });

		paramValue = searchInventoryForSingleValue("TBL_CONFIG_PARAMS", "PARAM_VALUE", whereClause, String.class);

		return paramValue;
	}

	

	public String getEntTrunkName(String enterpriseTrunkId, String enterpriseId) throws ApplicationInterfaceException {
		String entTrName = null;
		ArrayList<String[]> whereClause = new ArrayList<String[]>();
		whereClause.add(new String[] { "ENTERPRISE_TRUNK_ID", enterpriseTrunkId });
		whereClause.add(new String[] { "ENTERPRISE_ID", enterpriseId });

		entTrName = searchInventoryForSingleValue("TBL_TSO_ENTERPRISE_TRUNK", "ENTERPRISE_TRUNK_NAME", whereClause,
				String.class);
		return entTrName;
	}

	

	public long getEbiId(String trunkGroupId) throws ApplicationInterfaceException {
		// select ebi_id from tbl_tso_trunk_group where trunk_group_id =
		long ebiId = 0;
		ArrayList<String[]> whereClause = new ArrayList<String[]>();
		whereClause.add(new String[] { "trunk_group_id", trunkGroupId });

		ebiId = searchInventoryForSingleValue("tbl_tso_trunk_group", "ebi_id", whereClause, Long.class);
		return ebiId;
	}

	
	public void doPriorityUpdate(int trunkGroupId, String enterpriseTrunkId, int newpriority)
			throws ApplicationInterfaceException {

		List<String[]> updateKeyValuePairList = new ArrayList<>();
		updateKeyValuePairList.add(new String[] { "PRIORITY", Integer.toString(newpriority) });

		List<String[]> whereClauseList = new ArrayList<>();
		whereClauseList.add(new String[] { "TRUNK_GROUP_ID", Integer.toString(trunkGroupId) });
		whereClauseList.add(new String[] { "ENTERPRISE_TRUNK_ID", enterpriseTrunkId });

		updateInventory("TBL_TSO_ET_TG_MAP", updateKeyValuePairList, whereClauseList);
	}

	
	public boolean isTrunkGroupSame(int trunkGroupId, long ebiId) throws ApplicationInterfaceException {
		logger.debug("Executing isTrunkGroupSame()... ");
		boolean isTGroupSame = false;
		ArrayList<String[]> whereClause = new ArrayList<String[]>();
		whereClause.add(new String[] { "trunk_group_id", Integer.toString(trunkGroupId) });
		whereClause.add(new String[] { "ebi_id", Long.toString(ebiId) });

		String trunkGroupIdFromDB = searchInventoryForSingleValue("tbl_tso_trunk_group", "trunk_group_id", whereClause,
				String.class);
		if (trunkGroupIdFromDB != null && !"".equalsIgnoreCase(trunkGroupIdFromDB))
			isTGroupSame = true;
		
		return isTGroupSame;
	}

	
	public void doWeightUpdate(String enterpriseId, int trunkGroupId, int nwkNodeDeviceId, String enterpriseTrunkId,
			int weight) throws ApplicationInterfaceException {
		int ebiWeight = 0;
		int sbcBandwidth = 0;
		logger.debug("weight from tod;" + weight);

		sbcBandwidth = getSbcBandwidth(enterpriseId, nwkNodeDeviceId);
		logger.debug("SbcBandwidth:" + sbcBandwidth);
		int sbcBwMbps = sbcBandwidth / 1000;
		if (sbcBwMbps <= 1)
			sbcBwMbps = 1;
		logger.debug("SbcBandwidth Mbps:" + sbcBwMbps);
		if (sbcBwMbps < 1) {
			sbcBwMbps = 1;
		}
		ebiWeight = (weight * sbcBwMbps) / 10;
		int WEIGHT_MIN = 1;
		int WEIGHT_MAX = 65536;
		if (ebiWeight <= 0)
			ebiWeight = WEIGHT_MIN;
		if (ebiWeight >= WEIGHT_MAX)
			ebiWeight = WEIGHT_MAX;
		logger.debug("EbiWeight:" + ebiWeight);

		List<String[]> updateKeyValuePairList = new ArrayList<>();
		updateKeyValuePairList.add(new String[] { "WEIGHT", Integer.toString(ebiWeight) });

		List<String[]> whereClauseList = new ArrayList<>();
		whereClauseList.add(new String[] { "TRUNK_GROUP_ID", Integer.toString(trunkGroupId) });
		whereClauseList.add(new String[] { "ENTERPRISE_TRUNK_ID", enterpriseTrunkId });

		updateInventory("TBL_TSO_ET_TG_MAP", updateKeyValuePairList, whereClauseList);

	}

	
	public void doUpdate(String enterpriseId, int trunkGroupId, int nwkNodeDeviceId, String enterpriseTrunkId,
			int priority, int weight) throws ApplicationInterfaceException {
		int ebiWeight = 0;
		int sbcBandwidth = 0;
		logger.debug("weight from tod;" + weight);

		sbcBandwidth = getSbcBandwidth(enterpriseId, nwkNodeDeviceId);
		logger.debug("SbcBandwidth:" + sbcBandwidth);
		int sbcBwMbps = sbcBandwidth / 1000;
		if (sbcBwMbps <= 1)
			sbcBwMbps = 1;
		logger.debug("SbcBandwidth Mbps:" + sbcBwMbps);
		ebiWeight = (weight * sbcBwMbps) / 10;
		int WEIGHT_MIN = 1;
		int WEIGHT_MAX = 65536;
		if (ebiWeight <= 0)
			ebiWeight = WEIGHT_MIN;
		if (ebiWeight >= WEIGHT_MAX)
			ebiWeight = WEIGHT_MAX;
		logger.debug("EbiWeight:" + ebiWeight);
		// String UPD_ET_TG_ENTRY_SQL =
		// "UPDATE TBL_TSO_ET_TG_MAP SET PRIORITY = ? , WEIGHT = ? where
		// TRUNK_GROUP_ID = ? and ENTERPRISE_TRUNK_ID = ?";

		List<String[]> updateKeyValuePairList = new ArrayList<>();
		updateKeyValuePairList.add(new String[] { "WEIGHT", Integer.toString(ebiWeight) });

		List<String[]> whereClauseList = new ArrayList<>();
		whereClauseList.add(new String[] { "TRUNK_GROUP_ID", Integer.toString(trunkGroupId) });
		whereClauseList.add(new String[] { "ENTERPRISE_TRUNK_ID", enterpriseTrunkId });

		updateInventory("TBL_TSO_ET_TG_MAP", updateKeyValuePairList, whereClauseList);
	}

	
	public void updateStatusToActive(String enterpriseTrunkId) throws ApplicationInterfaceException {
		final short ACTIVE = 1;

		List<String[]> updateKeyValuePairList = new ArrayList<>();
		updateKeyValuePairList.add(new String[] { "STATUS", Short.toString(ACTIVE) });

		List<String[]> whereClauseList = new ArrayList<>();
		whereClauseList.add(new String[] { "ENTERPRISE_TRUNK_ID", enterpriseTrunkId });

		updateInventory("TBL_TSO_ET_TG_MAP", updateKeyValuePairList, whereClauseList);

	}

	
	public void deleteEntryFromTblETTGMapByEntTrunkName(String enterpriseTrunkName, int status)
			throws ApplicationInterfaceException {
		// String DELETE_ET_TG_ENTRY = " delete from TBL_TSO_ET_TG_MAP where
		// ENTERPRISE_TRUNK_ID in ( select ENTERPRISE_TRUNK_ID from
		// TBL_TSO_ENTERPRISE_TRUNK where ENTERPRISE_TRUNK_NAME = ? and status =
		// ?)";
		logger.info("Entering deleteEntryFromTblETTGMap, trunkGroupId: {} ", enterpriseTrunkName);
		List<String[]> whereClauseList = new ArrayList<>();
		whereClauseList.add(new String[] { "ENTERPRISE_TRUNK_NAME", enterpriseTrunkName });
		whereClauseList.add(new String[] { "status", Integer.toString(status) });

		Long numberOfRecord = deleteInventory("TBL_TSO_ET_TG_MAP", whereClauseList);
		if (numberOfRecord == 0) {
			throw new ApplicationInterfaceException("Delete operation did not delete any record");
		}
		logger.info("Exiting deleteEntryFromTblETTGMap, numberOfRecordsDeleted: {}", numberOfRecord);

	}

	/*
	 * 
	 */

	private Long deleteInventory(String tableName, List<String[]> whereClauseList)
			throws ApplicationInterfaceException {

		logger.info("Entering deleteInventory(): {} ", tableName);
		
		Long numberOfRecords = null;

		try {

			logger.debug("deleteInventory(): Request Message: {}", tableName);
			DatabaseServiceRequest request = new DatabaseServiceRequest();
			request.setDbOperation("DELETE");
			request.setTableName(tableName);

			WhereClause whereClauseRequest = new WhereClause();

			List<String> whereClauseColumnName = new ArrayList<>();
			List<String> whereClauseColumnValue = new ArrayList<>();
			for (String[] whereClauseArray : whereClauseList) {
				whereClauseColumnName.add(whereClauseArray[0]);
				whereClauseColumnValue.add(whereClauseArray[1]);
			}
			whereClauseRequest.setColumnNames(whereClauseColumnName);
			whereClauseRequest.setColumnValues(whereClauseColumnValue);
			request.setWhereClause(Collections.singletonList(whereClauseRequest));

			long startTime = System.currentTimeMillis();
			logger.info("deleteInventory(): Making HTTP POST Request for workOrderNumber:{} at time:{}", tableName,
					startTime);
			logger.info("deleteInventory(): Service URL: {}", inventoryDatabaseServiceURL);
			logger.info("deleteInventory(): Service restTemplate: {}", restTemplate);

			DatabaseServiceResponse inventoryDBServiceResponse = restTemplate.postForObject(inventoryDatabaseServiceURL,
					request, DatabaseServiceResponse.class);

			if (inventoryDBServiceResponse == null)
				throw new ApplicationInterfaceException("No response received from Inventory Service");
			
			long endTime = System.currentTimeMillis();

			numberOfRecords = inventoryDBServiceResponse.getNumberOfRecords() == null ? 0 : inventoryDBServiceResponse.getNumberOfRecords();

			logger.info("deleteInventory(): Received HTTP POST Response for tableName:{} at time:{}", tableName,
					endTime);
			logger.info("deleteInventory(): Time taken for Response for tableName:{} is:{} ms", tableName,
					(endTime - startTime));

			logger.debug("deleteInventory(): Response from InventoryDBService: {}", inventoryDBServiceResponse);

			logger.info("Exiting deleteInventory() ");

		} catch (HttpStatusCodeException e) {
			logger.error("Exception received from InventoryDBService Service URL: {} ", inventoryDatabaseServiceURL);
			logger.error("Exception received from InventoryDBService Service: {} ", e);
			logger.error("Execption during searchInventory execution code:{} , text:{}", e.getStatusCode(),
					e.getResponseBodyAsString());
			throw new ApplicationInterfaceException(INVENTORY_DOMAIN_SERVICE + e.getMessage());
		} catch (RestClientException e) {
			logger.error("Exception received from InventoryDBService Service: {} ", inventoryDatabaseServiceURL);
			logger.error("Exception received from InventoryDBService Service: {} ", e);
			throw new ApplicationInterfaceException(INVENTORY_DOMAIN_SERVICE + e.getMessage());
		}

		return numberOfRecords;

	}

	
	public DBServiceResponse getfacAuthMap(String facodeFeatureId) throws ApplicationInterfaceException {
		DBServiceResponse facodeTableData = null;
		try {
			HashSet<String> columnNames = new HashSet<String>();
			columnNames.add("FACODE_AUTH_MAP_ID");
			columnNames.add("FACODE_FEATURE_ID");
			columnNames.add("AUTH_FEATURE_ID");
			columnNames.add("facode");
			ArrayList<String[]> whereClause = new ArrayList<String[]>();

			whereClause.add(new String[] { "facode_feature_id", facodeFeatureId });

			facodeTableData = searchInventory("TBL_FACODE_AUTH_MAP", columnNames, whereClause);

		} catch (Exception e) {
			logger.error("Exception received in getfacAuthMap: {} ", e);
		}
		return facodeTableData;

	}

	
	public String getDomainNameFromEnterprise(String enterpriseId) throws ApplicationInterfaceException {
		List<String[]> whereClauseList = new ArrayList<>();
		whereClauseList.add(new String[] { "ENTERPRISE_ID", enterpriseId });

		String sipDomain = searchInventoryForSingleValue("TBL_ENTERPRISE", "SIP_DOMAIN", whereClauseList, String.class);
		return sipDomain;

	}

	
	public void deleteEntryFromTblETTGMap(String trunkGroupId) throws ApplicationInterfaceException {
		logger.info("Entering deleteEntryFromTblETTGMap, trunkGroupId: {} ", trunkGroupId);
		List<String[]> whereClauseList = new ArrayList<>();
		whereClauseList.add(new String[] { "TRUNK_GROUP_ID", trunkGroupId });

		Long numberOfRecord = deleteInventory("TBL_TSO_ET_TG_MAP", whereClauseList);
		if (numberOfRecord == 0) {
			throw new ApplicationInterfaceException("Delete operation did not delete any record");
		}
		logger.info("Exiting deleteEntryFromTblETTGMap, numberOfRecordsDeleted: {}", numberOfRecord);

	}

	

	public void deleteEntryFromTblETTGMapbyName(String enterpriseTrunkName, int status) throws VZBAFException {

		// String DELETE_ET_TG_ENTRY =
		// " delete from TBL_TSO_ET_TG_MAP where ENTERPRISE_TRUNK_ID in ( select
		// ENTERPRISE_TRUNK_ID from TBL_TSO_ENTERPRISE_TRUNK where
		// ENTERPRISE_TRUNK_NAME = ? )";

		// " delete from TBL_TSO_ET_TG_MAP where ENTERPRISE_TRUNK_ID in ( select
		// ENTERPRISE_TRUNK_ID from TBL_TSO_ENTERPRISE_TRUNK where
		// ENTERPRISE_TRUNK_NAME = ? and status = ?)";
		Long count = 0l;

		logger.debug("deleteEntryFromTblETTGMap() deleting enterprise trunk name {} and status {}", enterpriseTrunkName,
				status);

		try {

			ArrayList<String[]> whereClause = new ArrayList<String[]>();
			whereClause.add(new String[] { "ENTERPRISE_TRUNK_NAME", enterpriseTrunkName });

			if (status != -1) {
				whereClause.add(new String[] { "status", String.valueOf(status) });
			}
			String enterpriseTrunkID = searchInventoryForSingleValue("TBL_TSO_ENTERPRISE_TRUNK", "ENTERPRISE_TRUNK_ID",
					whereClause, String.class);

			whereClause.clear();
			whereClause.add(new String[] { "ENTERPRISE_TRUNK_ID", enterpriseTrunkID });

			count = deleteInventory("TBL_TSO_ET_TG_MAP", whereClause);

			logger.debug(
					"Deleted " + count + "  entries from TblTsoEtTgMap for EnterpriseTrunkName:" + enterpriseTrunkName);
		} catch (Exception e) {
			logger.error("Exception received in deleteEntryFromTblETTGMapbyName: {} ", e);
			throw new VZBAFException(
					"Exception while deleting to delete ET TG map Entry for ent trunk name:" + enterpriseTrunkName);
		}

	}

	// TODO implementation pending : INNER Query
	
	public HashMap<Integer, Integer> getTrunkGroupEBIMap(String enterpriseTrunkId) {

		logger.debug("Executing getTrunkGroupEBIMap()... ");

		HashMap<Integer, Integer> trunkGroupEBIMap = new HashMap<Integer, Integer>();

		/*
		 * 
		 * StringBuffer sql = new StringBuffer(); PreparedStatement pStmt =
		 * null; ResultSet rs = null;
		 * 
		 * 
		 * 
		 * sql.append(
		 * "select trunk_group_id, ebi_id from tbl_tso_trunk_group where ebi_id in (select ebi_id from tbl_tso_trunk_group where trunk_group_id in (select trunk_group_id from tbl_tso_et_tg_map where enterprise_trunk_id = ?))"
		 * );
		 * 
		 * try { pStmt = connection.prepareStatement(sql.toString());
		 * 
		 * if (pStmt != null) { pStmt.setString(1, enterpriseTrunkId); rs =
		 * pStmt.executeQuery(); while (rs.next()) { int trunkGroupId =
		 * rs.getInt(1); int ebiId = rs.getInt(2);
		 * trunkGroupEBIMap.put(trunkGroupId, ebiId); }
		 * 
		 * logger.debug( "Fetched TrunkGroups and Priority for ET : " +
		 * enterpriseTrunkId + " trunkGroupEBIMap:" + trunkGroupEBIMap); }
		 * 
		 * }
		 * 
		 * catch (SQLException sqe) { sqe.printStackTrace(); logger.debug(
		 * "DB_FAILURE in getTrunkGroupEBIMap"); throw sqe; } catch (Exception
		 * e) { e.printStackTrace(); logger.debug(
		 * "FAILURE in getTrunkGroupEBIMap "); } finally { if (pStmt != null) {
		 * pStmt.close(); } if (rs != null) { rs.close(); } } logger.debug(
		 * "returning trunkGroupEBIMap..." + trunkGroupEBIMap);
		 */
		return trunkGroupEBIMap;
	}

	
	public HashMap<Integer, List<Integer>> getPriorityTrunkGroupFromET(String enterpriseTrunkId, int status) {

		logger.debug("Executing getTrunkGroupandPriority()... trunk_group_id :{} and priority :", enterpriseTrunkId,
				status);
		List<Integer> trunkGroupIdList = new ArrayList<Integer>();
		HashMap<Integer, List<Integer>> trunkPriorityMap = new HashMap<Integer, List<Integer>>();

		// sql.append("select trunk_group_id, priority from tbl_tso_et_tg_map
		// where enterprise_trunk_id=? and status = ?");

		try {
			HashSet<String> columnNames = new HashSet<String>();
			columnNames.add("trunk_group_id");
			columnNames.add("priority");

			ArrayList<String[]> whereClause = new ArrayList<String[]>();
			whereClause.add(new String[] { "enterprise_trunk_id", enterpriseTrunkId });
			whereClause.add(new String[] { "status", String.valueOf(status) });

			DBServiceResponse trunkPriorityData = searchInventory("TBL_TSO_ET_TG_MAP", columnNames, whereClause);
			for (TblRow tblRows : trunkPriorityData.getTableRows()) {
				int trunkGroupId = Integer.parseInt(tblRows.getTblRow().get("trunk_group_id").getValue());
				int priority = Integer.parseInt(tblRows.getTblRow().get("priority").getValue());
				if (!trunkPriorityMap.isEmpty() && trunkPriorityMap.containsKey(priority)) {
					trunkGroupIdList = trunkPriorityMap.get(priority);
					trunkGroupIdList.add(trunkGroupId);
					trunkPriorityMap.put(priority, trunkGroupIdList);
				} else {
					trunkGroupIdList = new ArrayList<Integer>();
					trunkGroupIdList.add(trunkGroupId);
					trunkPriorityMap.put(priority, trunkGroupIdList);
				}
				logger.debug("Fetched TrunkGroups and Priority for ET : " + enterpriseTrunkId + " Priority:" + priority
						+ " TrunkGroupList;" + trunkGroupIdList);
			}
		} catch (Exception e) {
			logger.error("Exception in getEnterpriseTrunkCallCapacity() :", e);
		}
		logger.debug("returning trunkPriorityMap..." + trunkPriorityMap);
		return trunkPriorityMap;
	}

	
	public void deleteTrunkGroupFromInv(String trunkGroupName) throws ApplicationInterfaceException {
		logger.info("Entering deleteTrunkGroupFromInv, trunkGroupId: {} ", trunkGroupName);
		List<String[]> whereClauseList = new ArrayList<>();
		whereClauseList.add(new String[] { "TRUNK_GROUP_NAME", trunkGroupName });
		Long numberOfRecord = deleteInventory("TBL_TSO_TRUNK_GROUP", whereClauseList);
		if (numberOfRecord == 0) {
			throw new ApplicationInterfaceException("Delete operation did not delete any record");
		}
		logger.info("Exiting deleteTrunkGroupFromInv, numberOfRecordsDeleted: {}", numberOfRecord);
	}

	
	public int statusFromTblGroupTransStat(long orderId, String sgroupId, String userListId, int enmStatus, String oper)
			throws ApplicationInterfaceException {
		logger.info("Entering into statusFromTblOrderTrunkGroupDel()");
		if ("DEL".equals(oper)) {
			// DELETE FROM TBL_GROUP_TRANSACTION_STATUS where ORDER_ID = ?
			List<String[]> whereClauseList = new ArrayList<>();
			whereClauseList.add(new String[] { "ORDER_ID", String.valueOf(orderId) });
			Long numberOfRecordsDeleted = deleteInventory("TBL_GROUP_TRANSACTION_STATUS", whereClauseList);
			logger.info("Deleted {} records from TBL_GROUP_TRANSACTION_STATUS", numberOfRecordsDeleted);
			return 0;
		}

		Set<String> columnSet = new HashSet<>();
		columnSet.add("ORDER_ID");
		columnSet.add("GROUP_ID");
		columnSet.add("USER_ID");
		columnSet.add("STATUS");

		List<String[]> whereClauseList = new ArrayList<>();
		whereClauseList.add(new String[] { "ORDER_ID", String.valueOf(orderId) });
		whereClauseList.add(new String[] { "GROUP_ID", sgroupId });
		whereClauseList.add(new String[] { "USER_ID", userListId });

		int numOfRecords = 0;
		DBServiceResponse responseData = searchInventory("TBL_GROUP_TRANSACTION_STATUS", columnSet, whereClauseList);
		if (responseData != null && responseData.getTableRows() != null) {
			numOfRecords = responseData.getTableRows().size();

			if (numOfRecords >= 1 && oper.equals("SEL")) {
				String responseStatus = responseData.getTableRows().get(0).getTblRow().get("STATUS").getValue();
				return Integer.parseInt(responseStatus);
			}

			if (numOfRecords == 1 && oper.equals("UPD")) {
				List<String[]> updateKeyValuePairList = new ArrayList<>();
				updateKeyValuePairList.add(new String[] { "STATUS", String.valueOf(enmStatus) });

				whereClauseList = new ArrayList<>();
				whereClauseList.add(new String[] { "ORDER_ID", String.valueOf(orderId) });
				whereClauseList.add(new String[] { "GROUP_ID", sgroupId });
				whereClauseList.add(new String[] { "USER_ID", userListId });

				updateInventory("TBL_GROUP_TRANSACTION_STATUS", updateKeyValuePairList, whereClauseList);
			} else if (numOfRecords == 0 && oper.equals("INS")) {

				// INSERT INTO TBL_GROUP_TRANSACTION_STATUS
				// (ORDER_ID,GROUP_ID,USER_ID,STATUS) VALUES
				List<String[]> insertKeyValuePairList = new ArrayList<>();
				insertKeyValuePairList.add(new String[] { "ORDER_ID", String.valueOf(orderId) });
				insertKeyValuePairList.add(new String[] { "GROUP_ID", sgroupId });
				insertKeyValuePairList.add(new String[] { "USER_ID", userListId });
				insertKeyValuePairList.add(new String[] { "STATUS", String.valueOf(enmStatus) });
				insertInventory("TBL_GROUP_TRANSACTION_STATUS", insertKeyValuePairList, null);
			}
		}
		return 0;

	}

	

	public boolean isTrunkGroupExisting(String trunkGroupId) throws ApplicationInterfaceException {

		boolean status = false;
		logger.info("Executing isTrunkGroupExisting trunkGroupId : {} ", trunkGroupId);

		// sql.append("select count(*) from tbl_tso_et_tg_map where
		// trunk_group_id = ? ");

		List<String[]> whereClauseList = new ArrayList<>();
		whereClauseList.add(new String[] { "TRUNK_GROUP_ID", trunkGroupId });
		Long count = searchInventoryForSingleValue("TBL_TSO_ET_TG_MAP", "count(*)", whereClauseList, Long.class);

		logger.info("Fetched status count for TrunkGroupId: {}", count);

		if (count <= 0) {
			status = false;
		} else {
			status = true;
		}

		return status;
	}

	
	public int getWeightForTG(String trunkGroupId, String enterpriseTrunkId) throws ApplicationInterfaceException {

		logger.info("Executing getNwkNodeDeviceIdForTG()... ");

		// sql.append("select weight from tbl_tso_et_tg_map where trunk_group_id
		// = ? and enterprise_trunk_id = ?");

		List<String[]> whereClauseList = new ArrayList<>();
		whereClauseList.add(new String[] { "trunk_group_id", trunkGroupId });
		whereClauseList.add(new String[] { "enterprise_trunk_id", enterpriseTrunkId });
		Integer weight = searchInventoryForSingleValue("TBL_TSO_ET_TG_MAP", "WEIGHT", whereClauseList, Integer.class);

		logger.info("returning ebiId For TG: {}", weight);

		return weight;
	}

	
	public int getNwkNodeDeviceIdForTG(String trunkGroupId) throws ApplicationInterfaceException {

		logger.info("Executing getNwkNodeDeviceIdForTG()... ");
		// sql.append("select nwk_node_device_id from tbl_tso_trunk_group where
		// trunk_group_id = ?");

		List<String[]> whereClauseList = new ArrayList<>();
		whereClauseList.add(new String[] { "trunk_group_id", trunkGroupId });

		Integer nwkNodeDeviceId = searchInventoryForSingleValue("TBL_TSO_TRUNK_GROUP", "NWK_NODE_DEVICE_ID",
				whereClauseList, Integer.class);

		logger.info("Fetched nwkNodeDeviceId for TrunkGroupId :{} ", trunkGroupId);

		return nwkNodeDeviceId;

	}

	// TODO Implemenation pending
	
	public void doInsertInETTGMap(String serviceProviderId, int trunkGroupId, int nwkNodeDeviceId,
			String enterpriseTrunkId, int priority, int weight, int status) {/*

		int WEIGHT_MIN = 1;
		int WEIGHT_MAX = 65536;
		int trunkGroupWeight = 0;
		int sbcBandwidth = 0;
		logger.debug("weight from tod;" + weight);
		PreparedStatement stmt = null;

		try {
			String INSERT_ET_TG_ENTRY_SQL = "INSERT INTO TBL_TSO_ET_TG_MAP(ENTERPRISE_TRUNK_ID, TRUNK_GROUP_ID, PRIORITY, WEIGHT, STATUS) VALUES (?,?,?,?,?)";
			stmt = conn.prepareStatement(INSERT_ET_TG_ENTRY_SQL);
			stmt.setLong(1, Long.parseLong(enterpriseTrunkId));
			stmt.setInt(2, trunkGroupId);
			stmt.setInt(3, priority);
			stmt.setInt(4, weight);
			stmt.setInt(5, status);
			if (1 != stmt.executeUpdate()) {
				throw new VZBAFException("Failed to insert entry into ET TG Map for trunkGroupid:" + trunkGroupId);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw new VZBAFException(
					"Exception while connecting to database to insert entry into ET TG Map for trunkGroupid:"
							+ trunkGroupId);
		} finally {
			if (stmt != null) {
				stmt.close();
			}
		}

	*/}

	public String getFeatureName(long featureId) throws ApplicationInterfaceException {
		String featureName = null;

		List<String[]> whereClause = new ArrayList<>();
		whereClause.add(new String[] { "FEATURE_ID", Long.toString(featureId) });

		featureName = searchInventoryForSingleValue("TBL_VZB_FEATURES", "NAME", whereClause, String.class);

		return featureName;
	}

	
	public List<String> getTrunkGroupInfo(String ebiId, String trunkGroupName) throws ApplicationInterfaceException {

		List<String> trunkGroupInfoList = new ArrayList<>();
		// TODO Consider using Map instead of ArrayList. Old implementation - Dependent on ordering

		Set<String> selectColumnSet = new HashSet<>();
		selectColumnSet.add("TRUNK_GROUP_ID");
		selectColumnSet.add("ROUTING_GROUP_ID");

		ArrayList<String[]> whereClauseList = new ArrayList<String[]>();
		whereClauseList.add(new String[] { "EBI_ID", ebiId });
		whereClauseList.add(new String[] { "TRUNK_GROUP_NAME", trunkGroupName });

		DBServiceResponse responseData = searchInventory("TBL_TSO_TRUNK_GROUP", selectColumnSet, whereClauseList);
		List<TblRow> rowList = responseData.getTableRows();
		// Only Taking the first row returned
		if (rowList != null && rowList.size() > 0) {
			String trunkGroupId = rowList.get(0).getTblRow().get("TRUNK_GROUP_ID").getValue();
			String routingGroupId = rowList.get(0).getTblRow().get("ROUTING_GROUP_ID").getValue();
			trunkGroupInfoList.add(trunkGroupId);
			trunkGroupInfoList.add(routingGroupId);
		}

		return trunkGroupInfoList;

	}

	
	public String getLocationNameForId(String locationId) throws ApplicationInterfaceException {
		logger.info("Entering getLocationNameForId : {}", locationId);

		String locationName = null;
		ArrayList<String[]> whereClause = new ArrayList<String[]>();
		whereClause.add(new String[] { "LOCATION_ID", locationId });

		locationName = searchInventoryForSingleValue("TBL_LOCATION", "LOCATION_NAME", whereClause, String.class);
		logger.info("Exiting getLocationNameForId : {}, ReturnValue: {}", locationId, locationName);

		return locationName;
	}

	
	public int getExtensionLength(String locationId) throws ApplicationInterfaceException {
		int extenstionLength = 0;
		ArrayList<String[]> whereClause = new ArrayList<String[]>();
		whereClause.add(new String[] { "location_id", locationId });

		extenstionLength = searchInventoryForSingleValue("TBL_LOCATION", "EXT_LENGTH", whereClause, Integer.class);
		return extenstionLength;
	}

	public DBServiceResponse executePreconfiguredQuery(ESAPDBQueryEnum sqlKey, String sourceService,
			List<String> values) throws ApplicationInterfaceException {

		DBServiceResponse responseData = null;
		
		
		logger.info("executePreconfiguredQuery(): sqlKey:{} , sourceService:{} , values:{}", sqlKey, sourceService,
				values);

		try {
			List<DBOperationRequest> requestList = new ArrayList<DBOperationRequest>();
			DBOperationRequest request = new DBOperationRequest();
			request.setSqlKey(sqlKey.name());
			request.setSourceService(sourceService);
			request.setQueryReferenceId(0L);
			request.setColumnValues(values);

			requestList.add(request);

			long startTime = System.currentTimeMillis();
			logger.debug("executePreconfiguredQuery(): Making HTTP POST Request for sql:{} at time:{}", sqlKey,
					startTime);
			logger.debug("executePreconfiguredQuery(): Service URL: {}", inventoryDatabasePreConfiguredQueryServiceURL);
			logger.debug("executePreconfiguredQuery(): Service restTemplate: {}", restTemplate);

			DBOperationResponse[] dbOperationResponse = restTemplate
					.postForObject(inventoryDatabasePreConfiguredQueryServiceURL, requestList, DBOperationResponse[].class);

			if (dbOperationResponse == null || dbOperationResponse.length == 0)
				throw new ApplicationInterfaceException(INVENTORY_DOMAIN_SERVICE + "No Response from Service");

			long endTime = System.currentTimeMillis();

			logger.debug("executePreconfiguredQuery(): Received HTTP POST Response at time:{}", endTime);
			logger.info("executePreconfiguredQuery(): Time taken for Response for {} ms", (endTime - startTime));

			logger.debug("executePreconfiguredQuery(): HTTP Response: {} " + dbOperationResponse[0]);

			responseData = domainInterfaceUtil.convertDBResponseToTblData(dbOperationResponse[0]);

			logger.info("Exiting executePreconfiguredQuery() ");

		} catch (HttpStatusCodeException e) {
			logger.error("Exception received from InventoryDBService Service URL: {} ", inventoryDatabasePreConfiguredQueryServiceURL);
			logger.error("Exception received from InventoryDBService Service: {} ", e);
			logger.error("Execption during executePreconfiguredQuery execution code:{} , text:{}", e.getStatusCode(),
					e.getResponseBodyAsString());
			throw new ApplicationInterfaceException(INVENTORY_DOMAIN_SERVICE + e.getMessage());
		} catch (RestClientException e) {
			logger.error("Exception received from InventoryDBService Service URL: {} ", inventoryDatabasePreConfiguredQueryServiceURL);
			logger.error("Exception received from InventoryDBService Service: {} ", e);
			throw new ApplicationInterfaceException(INVENTORY_DOMAIN_SERVICE + e.getMessage());
		}
		return responseData;

	}

	
	public List<String> getBlockedVCEFeatureList() throws ApplicationInterfaceException {
		List<String> unauthorizedVCEFeatureList = new ArrayList<String>();
		String featureIdInQueryClause = getFeatureIdsInQueryClause();
		// select name from tbl_vzb_features where feature_id in
		List<String> values = Arrays.asList(featureIdInQueryClause);
		DBServiceResponse response = executePreconfiguredQuery(ESAPDBQueryEnum.GET_BLOCKED_VCE_FET_LST, "Network",
				values);

		for (TblRow row : response.getTableRows()) {
			unauthorizedVCEFeatureList.add(row.getTblRow().get("NAME").getValue());
		}

		return unauthorizedVCEFeatureList;
	}

	private String getFeatureIdsInQueryClause() throws ApplicationInterfaceException {
		StringBuilder paramInClause = new StringBuilder();

		String paramValue = null;

		List<String[]> whereClause = new ArrayList<>();
		whereClause.add(new String[] { "PROCESS_NAME", "VCE" });
		whereClause.add(new String[] { "PARAM_NAME", "FEATURE_IDS" });

		paramValue = searchInventoryForSingleValue("TBL_CONFIG_PARAMS", "PARAM_VALUE", whereClause, String.class);

		if (paramValue != null && paramValue.indexOf(",") != -1) {
			String params[] = paramValue.split(",");
			paramInClause.append("(");
			int count = 0;
			for (String param : params) {
				if (count == (params.length - 1)) {
					paramInClause.append(param);
				} else {
					paramInClause.append(param).append(",");
				}
				count++;
			}
			paramInClause.append(")");
		}
		return paramInClause.toString();
	}

	
	public String getLocDetails(String locationId) throws ApplicationInterfaceException {
		String callingPlanId = null;
		ArrayList<String[]> whereClause = new ArrayList<String[]>();
		whereClause.add(new String[] { "location_id", locationId });

		callingPlanId = searchInventoryForSingleValue("TBL_LOCATION", "CALLING_PLAN_ID", whereClause, String.class);

		return callingPlanId;
	}

	
	public Map<String, String> getCallingPlan(String callingPlanId) throws ApplicationInterfaceException {
		/*
		 * TblAuthServicesQuery authQry = new TblAuthServicesQuery();
		 * authQry.whereAuthServiceIdEQ(authServId); LogUtil.info(
		 * "before authFeaturesQry"); authQry.query(dbCon); LogUtil.info(
		 * "after authFeaturesQry");
		 */
		final String COLUMN_FEAT1 = "CALLING_PLAN_ID";
		final String COLUMN_FEAT2 = "CALLING_PLAN_NAME";
		final String COLUMN_FEAT3 = "DEFAULT_IND";
		final String COLUMN_FEAT4 = "I_INTRA_LOCATION";
		final String COLUMN_FEAT5 = "I_INTER_LOCATION";
		final String COLUMN_FEAT6 = "I_COLLECT_CALLS";
		final String COLUMN_FEAT7 = "O_INTRA_LOCATION";
		final String COLUMN_FEAT8 = "O_LOCAL";
		final String COLUMN_FEAT9 = "O_TOLL_FREE";
		final String COLUMN_FEAT10 = "O_TOLL";
		final String COLUMN_FEAT11 = "O_INTERNATIONAL";
		final String COLUMN_FEAT12 = "O_CASUAL";
		final String COLUMN_FEAT13 = "O_OPERATOR_ASSISTED";
		final String COLUMN_FEAT14 = "O_CHARGED_DIR_ASSIST";
		final String COLUMN_FEAT15 = "O_SPL_SERVICES1";
		final String COLUMN_FEAT16 = "O_SPL_SERVICES2";
		final String COLUMN_FEAT17 = "O_PRM_SERVICES1";
		final String COLUMN_FEAT18 = "O_PRM_SERVICES2";
		final String COLUMN_FEAT19 = "O_URL_DIALING";
		final String COLUMN_FEAT20 = "O_UNKNOWN";
		final String COLUMN_FEAT21 = "F_INTRA_LOCATION";
		final String COLUMN_FEAT22 = "F_LOCAL";
		final String COLUMN_FEAT23 = "F_TOLL_FREE";
		final String COLUMN_FEAT24 = "F_TOLL";
		final String COLUMN_FEAT25 = "F_INTERNATIONAL";
		final String COLUMN_FEAT26 = "F_CASUAL";
		final String COLUMN_FEAT27 = "F_OPERATOR_ASSISTED";
		final String COLUMN_FEAT28 = "F_CHARGED_DIR_ASSIST";
		final String COLUMN_FEAT29 = "F_SPL_SERVICES1";
		final String COLUMN_FEAT30 = "F_SPL_SERVICES2";
		final String COLUMN_FEAT31 = "F_PRM_SERVICES1";
		final String COLUMN_FEAT32 = "F_PRM_SERVICES2";
		final String COLUMN_FEAT33 = "F_URL_DIALING";
		final String COLUMN_FEAT34 = "F_UNKNOWN";
		final String COLUMN_FEAT35 = "B_INTER_LOCATION";
		final String COLUMN_FEAT36 = "TELEPHONE1";
		final String COLUMN_FEAT37 = "TELEPHONE2";
		final String COLUMN_FEAT38 = "TELEPHONE3";
		final String COLUMN_FEAT39 = "CREATED_BY";
		final String COLUMN_FEAT40 = "CREATION_DATE";
		final String COLUMN_FEAT41 = "MODIFIED_BY";
		final String COLUMN_FEAT42 = "LAST_MODIFIED_DATE";
		final String COLUMN_FEAT43 = "ENV_ORDER_ID";

		Set<String> columnFeatures = new HashSet<>();

		columnFeatures.add(COLUMN_FEAT1);
		columnFeatures.add(COLUMN_FEAT2);
		columnFeatures.add(COLUMN_FEAT3);
		columnFeatures.add(COLUMN_FEAT4);
		columnFeatures.add(COLUMN_FEAT5);
		columnFeatures.add(COLUMN_FEAT6);
		columnFeatures.add(COLUMN_FEAT7);
		columnFeatures.add(COLUMN_FEAT8);
		columnFeatures.add(COLUMN_FEAT9);
		columnFeatures.add(COLUMN_FEAT10);
		columnFeatures.add(COLUMN_FEAT11);
		columnFeatures.add(COLUMN_FEAT12);
		columnFeatures.add(COLUMN_FEAT13);
		columnFeatures.add(COLUMN_FEAT14);
		columnFeatures.add(COLUMN_FEAT15);
		columnFeatures.add(COLUMN_FEAT16);
		columnFeatures.add(COLUMN_FEAT17);
		columnFeatures.add(COLUMN_FEAT18);
		columnFeatures.add(COLUMN_FEAT19);
		columnFeatures.add(COLUMN_FEAT20);
		columnFeatures.add(COLUMN_FEAT21);
		columnFeatures.add(COLUMN_FEAT22);
		columnFeatures.add(COLUMN_FEAT23);
		columnFeatures.add(COLUMN_FEAT24);
		columnFeatures.add(COLUMN_FEAT25);
		columnFeatures.add(COLUMN_FEAT26);
		columnFeatures.add(COLUMN_FEAT27);
		columnFeatures.add(COLUMN_FEAT28);
		columnFeatures.add(COLUMN_FEAT29);
		columnFeatures.add(COLUMN_FEAT30);
		columnFeatures.add(COLUMN_FEAT31);
		columnFeatures.add(COLUMN_FEAT32);
		columnFeatures.add(COLUMN_FEAT33);
		columnFeatures.add(COLUMN_FEAT34);
		columnFeatures.add(COLUMN_FEAT35);
		columnFeatures.add(COLUMN_FEAT36);
		columnFeatures.add(COLUMN_FEAT37);
		columnFeatures.add(COLUMN_FEAT38);
		columnFeatures.add(COLUMN_FEAT39);
		columnFeatures.add(COLUMN_FEAT40);
		columnFeatures.add(COLUMN_FEAT41);
		columnFeatures.add(COLUMN_FEAT42);
		columnFeatures.add(COLUMN_FEAT43);

		final String TABLE_NAME = "TBL_CALLING_PLANS";

		List<String[]> whereClause1 = new ArrayList<>();
		whereClause1.add(new String[] { "CALLING_PLAN_ID", callingPlanId });

		DBServiceResponse resultSet = searchInventory(TABLE_NAME, columnFeatures, whereClause1);
		Map<String, String> callingPlanMap = new HashMap<String, String>();
		for (TblRow tblRows : resultSet.getTableRows()) {

			callingPlanMap.put("CALLING_PLAN_ID", tblRows.getTblRow().get("CALLING_PLAN_ID").getValue());
			callingPlanMap.put("CALLING_PLAN_NAME", tblRows.getTblRow().get("CALLING_PLAN_NAME").getValue());
			callingPlanMap.put("DEFAULT_IND", tblRows.getTblRow().get("DEFAULT_IND").getValue());
			callingPlanMap.put("I_INTRA_LOCATION", tblRows.getTblRow().get("I_INTRA_LOCATION").getValue());
			callingPlanMap.put("I_INTER_LOCATION", tblRows.getTblRow().get("I_INTER_LOCATION").getValue());
			callingPlanMap.put("I_COLLECT_CALLS", tblRows.getTblRow().get("I_COLLECT_CALLS").getValue());
			callingPlanMap.put("O_INTRA_LOCATION", tblRows.getTblRow().get("O_INTRA_LOCATION").getValue());
			callingPlanMap.put("O_LOCAL", tblRows.getTblRow().get("O_LOCAL").getValue());
			callingPlanMap.put("O_TOLL_FREE", tblRows.getTblRow().get("O_TOLL_FREE").getValue());
			callingPlanMap.put("O_TOLL", tblRows.getTblRow().get("O_TOLL").getValue());
			callingPlanMap.put("O_INTERNATIONAL", tblRows.getTblRow().get("O_INTERNATIONAL").getValue());
			callingPlanMap.put("O_CASUAL", tblRows.getTblRow().get("O_CASUAL").getValue());
			callingPlanMap.put("O_OPERATOR_ASSISTED", tblRows.getTblRow().get("O_OPERATOR_ASSISTED").getValue());
			callingPlanMap.put("O_CHARGED_DIR_ASSIST", tblRows.getTblRow().get("O_CHARGED_DIR_ASSIST").getValue());
			callingPlanMap.put("O_SPL_SERVICES1", tblRows.getTblRow().get("O_SPL_SERVICES1").getValue());
			callingPlanMap.put("O_SPL_SERVICES2", tblRows.getTblRow().get("O_SPL_SERVICES2").getValue());
			callingPlanMap.put("O_PRM_SERVICES1", tblRows.getTblRow().get("O_PRM_SERVICES1").getValue());
			callingPlanMap.put("O_PRM_SERVICES2", tblRows.getTblRow().get("O_PRM_SERVICES2").getValue());
			callingPlanMap.put("O_URL_DIALING", tblRows.getTblRow().get("O_URL_DIALING").getValue());
			callingPlanMap.put("O_UNKNOWN", tblRows.getTblRow().get("O_UNKNOWN").getValue());
			callingPlanMap.put("F_INTRA_LOCATION", tblRows.getTblRow().get("F_INTRA_LOCATION").getValue());
			callingPlanMap.put("F_LOCAL", tblRows.getTblRow().get("F_LOCAL").getValue());
			callingPlanMap.put("F_TOLL_FREE", tblRows.getTblRow().get("F_TOLL_FREE").getValue());
			callingPlanMap.put("F_TOLL", tblRows.getTblRow().get("F_TOLL").getValue());
			callingPlanMap.put("F_INTERNATIONAL", tblRows.getTblRow().get("F_INTERNATIONAL").getValue());
			callingPlanMap.put("F_CASUAL", tblRows.getTblRow().get("F_CASUAL").getValue());
			callingPlanMap.put("F_OPERATOR_ASSISTED", tblRows.getTblRow().get("F_OPERATOR_ASSISTED").getValue());
			callingPlanMap.put("F_CHARGED_DIR_ASSIST", tblRows.getTblRow().get("F_CHARGED_DIR_ASSIST").getValue());
			callingPlanMap.put("F_SPL_SERVICES1", tblRows.getTblRow().get("F_SPL_SERVICES1").getValue());
			callingPlanMap.put("F_SPL_SERVICES2", tblRows.getTblRow().get("F_SPL_SERVICES2").getValue());
			callingPlanMap.put("F_PRM_SERVICES1", tblRows.getTblRow().get("F_PRM_SERVICES1").getValue());
			callingPlanMap.put("F_PRM_SERVICES2", tblRows.getTblRow().get("F_PRM_SERVICES2").getValue());
			callingPlanMap.put("F_URL_DIALING", tblRows.getTblRow().get("F_URL_DIALING").getValue());
			callingPlanMap.put("F_UNKNOWN", tblRows.getTblRow().get("F_UNKNOWN").getValue());
			callingPlanMap.put("B_INTER_LOCATION", tblRows.getTblRow().get("B_INTER_LOCATION").getValue());
			callingPlanMap.put("TELEPHONE1", tblRows.getTblRow().get("TELEPHONE1").getValue());
			callingPlanMap.put("TELEPHONE2", tblRows.getTblRow().get("TELEPHONE2").getValue());
			callingPlanMap.put("TELEPHONE3", tblRows.getTblRow().get("TELEPHONE2").getValue());
			callingPlanMap.put("CREATED_BY", tblRows.getTblRow().get("CREATED_BY").getValue());
			callingPlanMap.put("CREATION_DATE", tblRows.getTblRow().get("CREATION_DATE").getValue());
			callingPlanMap.put("MODIFIED_BY", tblRows.getTblRow().get("MODIFIED_BY").getValue());
			callingPlanMap.put("LAST_MODIFIED_DATE", tblRows.getTblRow().get("LAST_MODIFIED_DATE").getValue());
			callingPlanMap.put("ENV_ORDER_ID", tblRows.getTblRow().get("ENV_ORDER_ID").getValue());
		}
		return callingPlanMap;
	}

	
	public List<DigitStringBean> getDigitStringBeanByCallingPlanId(String callingPlanId)
			throws ApplicationInterfaceException {

		List<DigitStringBean> digitStringList = new ArrayList<DigitStringBean>();

		Set<String> selectColumnSet = new HashSet<>();
		selectColumnSet.add("CALLING_PLAN_ID");
		selectColumnSet.add("DIGIT_STRING_ID");
		selectColumnSet.add("I_ALLOW");
		selectColumnSet.add("O_ALLOW");
		selectColumnSet.add("F_ALLOW");
		selectColumnSet.add("B_ALLOW");

		ArrayList<String[]> whereClauseList = new ArrayList<String[]>();
		whereClauseList.add(new String[] { "CALLING_PLAN_ID", callingPlanId });

		DBServiceResponse callingPlanDigits = searchInventory("TBL_CALLING_PLAN_DIGITS", selectColumnSet,
				whereClauseList);
		for (TblRow tblRows : callingPlanDigits.getTableRows()) {
			String digitStringId = tblRows.getTblRow().get("DIGIT_STRING_ID").getValue();

			Set<String> selectColumnSet1 = new HashSet<>();
			selectColumnSet1.add("DIGIT_STRING_ID");
			selectColumnSet1.add("ENTERPRISE_ID");
			selectColumnSet1.add("DIGIT_STRING");
			selectColumnSet1.add("ACTIVE_IND");
			selectColumnSet1.add("CREATED_BY");
			selectColumnSet1.add("CREATION_DATE");
			selectColumnSet1.add("MODIFIED_BY");
			selectColumnSet1.add("LAST_MODIFIED_DATE");

			ArrayList<String[]> whereClauseList1 = new ArrayList<String[]>();
			whereClauseList1.add(new String[] { "DIGIT_STRING_ID", digitStringId });
			whereClauseList1.add(new String[] { "ACTIVE_IND", "1" });

			DBServiceResponse digitStringData = searchInventory("TBL_DIGIT_STRINGS", selectColumnSet1, whereClauseList1);

			for (TblRow rows : digitStringData.getTableRows()) {
				DigitStringBean digitStringBean = new DigitStringBean();
				digitStringBean
						.setCallingPlanId(Integer.parseInt(tblRows.getTblRow().get("CALLING_PLAN_ID").getValue()));
				digitStringBean.setDigitStringId(Integer.parseInt(rows.getTblRow().get("DIGIT_STRING_ID").getValue()));
				digitStringBean.setDigitString(rows.getTblRow().get("DIGIT_STRING").getValue());
				digitStringBean.setIAllow(Integer.parseInt(tblRows.getTblRow().get("I_ALLOW").getValue()));
				digitStringBean.setOAllow(Integer.parseInt(tblRows.getTblRow().get("O_ALLOW").getValue()));
				digitStringBean.setBAllow(Integer.parseInt(tblRows.getTblRow().get("F_ALLOW").getValue()));
				digitStringBean.setFAllow(Integer.parseInt(tblRows.getTblRow().get("B_ALLOW").getValue()));
				digitStringBean.setActiveInd(1);
				digitStringList.add(digitStringBean);
			}
		}

		logger.info("Size of the list " + digitStringList.size());

		return digitStringList;
	}

	/*
	 * Returns only Protocol , BSDeviceType and BSDeviceName field info , need
	 * to make change as per the requirement
	 * 
	 * (non-Javadoc)
	 * 
	 * @see com.vz.esap.bs.connector.service.IInventoryDomainDataService#
	 * getInvSipDeviceType(int)
	 */
	
	public DeviceTypeBean getInvSipDeviceType(int orderDeviceId) throws ApplicationInterfaceException {

		logger.debug("getInvSipDeviceType() SIP orderDeviceId {}", orderDeviceId);

		DeviceTypeBean deviceTypeBean = null;
		ArrayList<String[]> whereClause = new ArrayList<String[]>();
		whereClause.add(new String[] { "SIP_DEVICE_ID", String.valueOf(orderDeviceId) });

		String deviceTypeID = searchInventoryForSingleValue("TBL_SIP_DEVICE_INFO", "DEVICE_TYPE_ID", whereClause,
				String.class);

		whereClause = new ArrayList<String[]>();

		// SELECT
		// DEVICE_TYPE_ID,DEVICE_TYPE_NAME,DEVICE_REALTYPE_ID,DEVICE_BSTYPE_ID,MODIFIED_BY,LAST_MODIFIED_DATE,DISPLAY_INDICATOR,IS_SHARED_CALL_ENABLED,DEVICE_VENDOR,DEVICE_MODEL,IS_CPE_DEVICE,IS_BLF_DEVICE,MAX_LINE_KEYS,PROTOCOL,ENV_ORDER_ID,UEID,DEVICE_CHAR_ID
		// FROM TBL_DEVICE_TYPES
		whereClause.add(new String[] { "DEVICE_TYPE_ID", deviceTypeID });

		Set<String> selectColumnSet = new HashSet<>();
		selectColumnSet.add("DEVICE_BSTYPE_ID");
		selectColumnSet.add("PROTOCOL");

		DBServiceResponse deviceTypeResponse = searchInventory("TBL_DIGIT_STRINGS", selectColumnSet, whereClause);
		for (TblRow rows : deviceTypeResponse.getTableRows()) {
			deviceTypeBean = new DeviceTypeBean();
			deviceTypeBean.setDeviceBstype(Integer.parseInt(rows.getTblRow().get("SIP_DEVICE_ID").getValue()));
			deviceTypeBean.setProtocol(rows.getTblRow().get("PROTOCOL").getValue());
			deviceTypeBean.setDeviceBsname(getDeviceBSName(deviceTypeBean.getDeviceBstypeId()));
		}
		return deviceTypeBean;
	}

	/**
	 * 
	 * @param deviceBstypeId
	 * @return
	 * @throws ApplicationInterfaceException
	 */
	private String getDeviceBSName(long deviceBstypeId) throws ApplicationInterfaceException {

		logger.debug("getDeviceBSName() SIP deviceBstypeId {}", deviceBstypeId);

		// SELECT
		// DEVICE_BSTYPE_ID,DEVICE_BSNAME,DEVICE_BSTYPE,MAX_NUM_PORTS,MODIFIED_BY,LAST_MODIFIED_DATE,IP_REQUIRED,PORT_ALLOWED
		// FROM TBL_DEVICE_BSTYPE

		ArrayList<String[]> whereClause = new ArrayList<String[]>();
		whereClause.add(new String[] { "DEVICE_BSTYPE_ID", String.valueOf(deviceBstypeId) });

		String bsDeviceName = searchInventoryForSingleValue("TBL_DEVICE_BSTYPE", "DEVICE_BSNAME", whereClause,
				String.class);

		logger.debug("getDeviceBSName() SIP BSDeviceName {}", bsDeviceName);

		return bsDeviceName;
	}

	/*
	 * Returns only Protocol , BSDeviceType and BSDeviceName field info , need
	 * to make change as per the requirement
	 * 
	 */
	
	public DeviceTypeBean getInvGatewayDeviceDeviceType(int orderDeviceId) throws ApplicationInterfaceException {

		logger.debug("getInvGatewayDeviceDeviceType() Gateway Device orderDeviceId {}", orderDeviceId);

		// SELECT
		// GATEWAY_DEVICE_ID,DEVICE_NAME,DEVICE_TYPE_ID,GATEWAY_ADDRESS,GATEWAY_SEC_ADDRESS,CALLING_PARTY_FORMAT,TERM_CALLING_IND,SBC_ID,CREATED_BY,CREATION_DATE,MODIFIED_BY,LAST_MODIFIED_DATE,ENV_ORDER_ID,DEVICE_CHAR_ID,TRANSPORT,PORTS_AVAILABLE,PORTS_ASSIGNED,GATEWAY_FQDN,GATEWAY_HUNT,SBC_PROV_METHOD,SBC_MIG_IND,IASA_CPE_LOCAL_GWYID,STN_POOL_ID,STN_LINE_PORT,SEC_SBC_ID,INTERNAL_ADMIN,AGGREGATE_OFFNET_CCL,SIGNALING_TIER_LOOKUP_VALUE,TIER_OVERRIDE_FLAG,IP_VERSION,PQ_INSTANCE_ID,TSO_MIG_LOCK,IPSEC_TUNNEL_ID,CUST_SIG_CONSTRAINT,UPDATE_COMMENT
		// FROM TBL_GATEWAY_DEVICE_INFO

		DeviceTypeBean deviceTypeBean = null;
		ArrayList<String[]> whereClause = new ArrayList<String[]>();
		whereClause.add(new String[] { "GATEWAY_DEVICE_ID", String.valueOf(orderDeviceId) });
		String deviceTypeID = searchInventoryForSingleValue("TBL_GATEWAY_DEVICE_INFO", "DEVICE_TYPE_ID", whereClause,
				String.class);

		whereClause = new ArrayList<String[]>();

		// SELECT
		// DEVICE_TYPE_ID,DEVICE_TYPE_NAME,DEVICE_REALTYPE_ID,DEVICE_BSTYPE_ID,MODIFIED_BY,LAST_MODIFIED_DATE,DISPLAY_INDICATOR,IS_SHARED_CALL_ENABLED,DEVICE_VENDOR,DEVICE_MODEL,IS_CPE_DEVICE,IS_BLF_DEVICE,MAX_LINE_KEYS,PROTOCOL,ENV_ORDER_ID,UEID,DEVICE_CHAR_ID
		// FROM TBL_DEVICE_TYPES
		whereClause.add(new String[] { "DEVICE_TYPE_ID", deviceTypeID });

		Set<String> selectColumnSet = new HashSet<>();
		selectColumnSet.add("DEVICE_BSTYPE_ID");
		selectColumnSet.add("PROTOCOL");

		DBServiceResponse deviceTypeResponse = searchInventory("TBL_DEVICE_TYPES", selectColumnSet, whereClause);

		for (TblRow rows : deviceTypeResponse.getTableRows()) {
			deviceTypeBean = new DeviceTypeBean();
			deviceTypeBean.setDeviceBstype(Integer.parseInt(rows.getTblRow().get("SIP_DEVICE_ID").getValue()));
			deviceTypeBean.setProtocol(rows.getTblRow().get("PROTOCOL").getValue());
			deviceTypeBean.setDeviceBsname(getDeviceBSName(deviceTypeBean.getDeviceBstypeId()));
		}
		return deviceTypeBean;
	}

	
	public String getGatewayDeviceIPAddress(int gatewayDeviceId) throws ApplicationInterfaceException {

		logger.debug("getGatewayDeviceIPAddress() SIP deviceBstypeId {}", gatewayDeviceId);
		// SELECT
		// GATEWAY_DEVICE_ID,DEVICE_NAME,DEVICE_TYPE_ID,GATEWAY_ADDRESS,GATEWAY_SEC_ADDRESS,CALLING_PARTY_FORMAT,TERM_CALLING_IND,SBC_ID,CREATED_BY,CREATION_DATE,MODIFIED_BY,LAST_MODIFIED_DATE,ENV_ORDER_ID,DEVICE_CHAR_ID,TRANSPORT,PORTS_AVAILABLE,PORTS_ASSIGNED,GATEWAY_FQDN,GATEWAY_HUNT,SBC_PROV_METHOD,SBC_MIG_IND,IASA_CPE_LOCAL_GWYID,STN_POOL_ID,STN_LINE_PORT,SEC_SBC_ID,INTERNAL_ADMIN,AGGREGATE_OFFNET_CCL,SIGNALING_TIER_LOOKUP_VALUE,TIER_OVERRIDE_FLAG,IP_VERSION,PQ_INSTANCE_ID,TSO_MIG_LOCK,IPSEC_TUNNEL_ID,CUST_SIG_CONSTRAINT,UPDATE_COMMENT
		// FROM TBL_GATEWAY_DEVICE_INFO

		ArrayList<String[]> whereClause = new ArrayList<String[]>();
		whereClause.add(new String[] { "GATEWAY_DEVICE_ID", String.valueOf(gatewayDeviceId) });

		String gatedeviceIPAddress = searchInventoryForSingleValue("TBL_GATEWAY_DEVICE_INFO", "GATEWAY_ADDRESS",
				whereClause, String.class);

		logger.debug("getDeviceBSName() SIP GATEWAY_ADDRESS IPADRESS {}", gatedeviceIPAddress);

		return gatedeviceIPAddress;
	}

	
	public List<DepartmentBean> getDepartmentListForEnterprise(String enterpriseId)
			throws ApplicationInterfaceException {
		logger.info("calling getDepartmentListForEnterprise with input - " + enterpriseId);
		List<DepartmentBean> deptList = null;

		// call the inv method to get the list of depts for a enterprise.

		deptList = getDepartmentListByEnterpriseId(enterpriseId);
		// deptList = entObj.getDepartmentList();

		logger.info("dept list from inventry - " + deptList);
		return deptList;
	}

	private List<DepartmentBean> getDepartmentListByEnterpriseId(String enterpriseId)
			throws ApplicationInterfaceException {

		List<DepartmentBean> deptLst = null;

		final String COLUMN_FEAT1 = "DEPARTMENT_ID";
		final String COLUMN_FEAT2 = "DEPARTMENT_NAME";
		final String COLUMN_FEAT3 = "CALLING_PLAN_ID";

		Set<String> columnFeatures = new HashSet<>();

		columnFeatures.add(COLUMN_FEAT1);
		columnFeatures.add(COLUMN_FEAT2);
		columnFeatures.add(COLUMN_FEAT3);

		final String TABLE_NAME = "TBL_DEPARTMENT";

		List<String[]> whereClause1 = new ArrayList<>();
		whereClause1.add(new String[] { "ENTERPRISE_ID", enterpriseId });

		DBServiceResponse resultSet = searchInventory(TABLE_NAME, columnFeatures, whereClause1);
		deptLst = new ArrayList<DepartmentBean>();

		for (TblRow tblRows : resultSet.getTableRows()) {

			DepartmentBean invDepBean = new DepartmentBean();
			invDepBean.setDepartmentId(tblRows.getTblRow().get("DEPARTMENT_ID").getValue());
			invDepBean.setDepartmentName(tblRows.getTblRow().get("DEPARTMENT_NAME").getValue());
			invDepBean.setCallingPlanId(Long.parseLong(tblRows.getTblRow().get("CALLING_PLAN_ID").getValue()));
			deptLst.add(invDepBean);

		}
		return deptLst;
	}

	public long getLocCCL(String locationId) throws ApplicationInterfaceException {
		logger.info("Entering getLocCCL : {}", locationId);

		Long locTrunkCclSum = null;
		ArrayList<String[]> whereClause = new ArrayList<String[]>();
		whereClause.add(new String[] { "LOCATION_ID", locationId });

		locTrunkCclSum = searchInventoryForSingleValue("TBL_LOCATION", "LOC_TRUNK_CCL_SUM", whereClause, Long.class);
		logger.info("Exiting getLocCCL : {}", locationId);

		return locTrunkCclSum;
	}

	
	public boolean getBestPoolValuesForEnterprise(String enterpriseId, String locationId)
			throws ApplicationInterfaceException {
		logger.info("Entering getBestPoolValuesForEnterprise enterpriseId: {} locationId: {}", enterpriseId,
				locationId);

		// TODO Multiple queries can be optimized to be sent in single request

		HashSet<String> selectColumnSet = new HashSet<String>();
		selectColumnSet.add("US_LD_AND_LOCAL_BEST_POOL");
		selectColumnSet.add("US_LD_ONLY_BEST_POOL");
		selectColumnSet.add("EMEA_APAC_BEST_POOL");
		selectColumnSet.add("SO_ENABLED");
		ArrayList<String[]> whereClauseList = new ArrayList<String[]>();
		whereClauseList.add(new String[] { "ENTERPRISE_ID", enterpriseId });

		DBServiceResponse resultTblData = searchInventory("TBL_ENTERPRISE", selectColumnSet, whereClauseList);

		int usLdAndLocalBestPool = 0;
		int usLdOnlyBestPool = 0;
		int emeaApacBestPool = 0;
		int soEnabled = 0;

		if (resultTblData != null && resultTblData.getTableRows() != null) {
			for (TblRow tblRows : resultTblData.getTableRows()) {
				String usLdAndLocalBestPoolStr = tblRows.getTblRow().get("US_LD_AND_LOCAL_BEST_POOL").getValue();
				if (usLdAndLocalBestPoolStr != null && !usLdAndLocalBestPoolStr.trim().equalsIgnoreCase(""))
					usLdAndLocalBestPool = Integer.parseInt(usLdAndLocalBestPoolStr);

				String usLdOnlyBestPoolStr = tblRows.getTblRow().get("US_LD_ONLY_BEST_POOL").getValue();
				if (usLdOnlyBestPoolStr != null && !usLdOnlyBestPoolStr.trim().equalsIgnoreCase(""))
					usLdOnlyBestPool = Integer.parseInt(usLdOnlyBestPoolStr);

				String emeaApacBestPoolStr = tblRows.getTblRow().get("EMEA_APAC_BEST_POOL").getValue();
				if (emeaApacBestPoolStr != null && !emeaApacBestPoolStr.trim().equalsIgnoreCase(""))
					emeaApacBestPool = Integer.parseInt(emeaApacBestPoolStr);

				String soEnabledStr = tblRows.getTblRow().get("SO_ENABLED").getValue();
				if (soEnabledStr != null && !soEnabledStr.trim().equalsIgnoreCase(""))
					soEnabled = Integer.parseInt(soEnabledStr);

			}
		}

		if (soEnabled != 1) {
			logger.info("Exiting getBestPoolValuesForEnterprise soEnabled: {} , returning false ", soEnabled);
			return false;
		}

		whereClauseList = new ArrayList<String[]>();
		whereClauseList.add(new String[] { "LOCATION_ID", locationId });
		Long maxConCalOffnet = searchInventoryForSingleValue("TBL_LOCATION", "MAX_CONCURRENT_OFFNET", whereClauseList,
				Long.class);

		if (soEnabled == 1 && maxConCalOffnet != null && maxConCalOffnet.longValue() > 0) {
			logger.info("Exiting getBestPoolValuesForEnterprise soEnabled: {} , maxConCalOffnet: {} returning true ", soEnabled, maxConCalOffnet);
			return true;
		}

		if (usLdAndLocalBestPool > 0 || usLdOnlyBestPool > 0 || emeaApacBestPool > 0) {
			logger.info("Exiting getBestPoolValuesForEnterprise (usLdAndLocalBestPool > 0 || usLdOnlyBestPool > 0 || emeaApacBestPool > 0) returning false ");
			return false;
		}

		logger.info("Exiting getBestPoolValuesForEnterprise enterpriseId: {} locationId: {}", enterpriseId, locationId);

		return true;
	}

	
	public long getCCLSum(String enterpriseId) throws ApplicationInterfaceException {
		logger.info("Entering getCCLSum : {}", enterpriseId);

		Long entTrunkCclSum = null;
		ArrayList<String[]> whereClause = new ArrayList<String[]>();
		whereClause.add(new String[] { "ENTERPRISE_ID", enterpriseId });

		entTrunkCclSum = searchInventoryForSingleValue("TBL_ENTERPRISE", "ENT_TRUNK_CCL_SUM", whereClause, Long.class);
		logger.info("Exiting getCCLSum : {}", enterpriseId);

		return entTrunkCclSum;
	}

	
	public List<String> getRoutingGroupIdListFromEnterprise(String enterpriseId) throws ApplicationInterfaceException {
		logger.info("Entering getRoutingGroupIdListFromEnterprise : {}", enterpriseId);

		List<String> routingGroupIdList = new ArrayList<>();

		Set<String> selectColumnNames = new HashSet<>();
		selectColumnNames.add("ROUTING_GROUP_ID");

		List<String[]> whereClauseList = new ArrayList<>();
		whereClauseList.add(new String[] { "ENTERPRISE_ID", enterpriseId });

		DBServiceResponse response = searchInventory("TBL_TSO_ROUTING_GROUP", selectColumnNames, whereClauseList);

		if (response != null && response.getTableRows() != null) {
			for (TblRow row : response.getTableRows()) {
				routingGroupIdList.add(row.getTblRow().get("ROUTING_GROUP_ID").getValue());
			}
		}
		logger.info("Exiting getRoutingGroupIdListFromEnterprise : {}", enterpriseId);

		return routingGroupIdList;
	}

	
	public List<Integer> getTrunkGroupIdFromEnterprise(String enterpriseId) throws ApplicationInterfaceException {
		logger.info("Entering getTrunkGroupIdFromEnterprise : {}", enterpriseId);
		List<Integer> trunkGroupIdList = new ArrayList<>();

		/*
		 * SELECT TRUNK_GROUP_ID FROM TBL_TSO_TRUNK_GROUP WHERE ROUTING_GROUP_ID
		 * IN (SELECT ROUTING_GROUP_ID FROM TBL_TSO_ROUTING_GROUP WHERE
		 * ENTERPRISE_ID=?);
		 */

		List<String> values = Arrays.asList(enterpriseId);
		DBServiceResponse response = executePreconfiguredQuery(ESAPDBQueryEnum.GET_TRUNK_GROUP_ID_FROM_ENTERPRISE_ID,
				"Network", values);
		for (TblRow row : response.getTableRows()) {
			trunkGroupIdList.add(Integer.parseInt(row.getTblRow().get("TRUNK_GROUP_ID").getValue()));
		}
		logger.info("Exiting getTrunkGroupIdFromEnterprise : {}", enterpriseId);

		return trunkGroupIdList;

	}

	
	public Long updateEntTrunkCCLSum(String enterpriseId, Long entTrunkCclSum) throws ApplicationInterfaceException {
		List<String[]> updateKeyValuePairList = new ArrayList<>();
		updateKeyValuePairList.add(new String[] { "ENT_TRUNK_CCL_SUM", entTrunkCclSum.toString() });

		List<String[]> whereClauseList = new ArrayList<>();
		whereClauseList.add(new String[] { "ENTERPRISE_ID", enterpriseId });

		Long result = updateInventory("TBL_ENTERPRISE", updateKeyValuePairList, whereClauseList);

		return result;
	}

	
	public int getLocationTrunkCallCapacity(String locationId) throws ApplicationInterfaceException {
		logger.info("Entering getLocationTrunkCallCapacity : {}", locationId);

		int locTrunkCclSum = 0;
		ArrayList<String[]> whereClause = new ArrayList<String[]>();
		whereClause.add(new String[] { "LOCATION_ID", locationId });

		locTrunkCclSum = searchInventoryForSingleValue("TBL_LOCATION", "LOC_TRUNK_CCL_SUM", whereClause, Integer.class);
		logger.info("Exiting getLocationTrunkCallCapacity Return Value: {}", locTrunkCclSum);

		return locTrunkCclSum;
	}

	
	public String getDepartmentNameByDepartmentId(String departmentId) throws ApplicationInterfaceException {
		logger.info("Entering getDepartmentNameByDepartmentId : {}", departmentId);

		String departmentName = null;
		ArrayList<String[]> whereClause = new ArrayList<String[]>();
		whereClause.add(new String[] { "DEPARTMENT_ID", departmentId });

		departmentName = searchInventoryForSingleValue("TBL_DEPARTMENT", "DEPARTMENT_NAME", whereClause, String.class);
		logger.info("Exiting getDepartmentNameByDepartmentId Return Value: {}", departmentName);

		return departmentName;
	}

	
	public void parseBSErrAndUpdInv(String entity, String errResp, String entityVal, int orderCCl)
			throws ApplicationInterfaceException {
		logger.info("Entering parseBSErrAndUpdInv : {} {} {} {} ", entity, errResp, entityVal, orderCCl);

		StringTokenizer lstr = new StringTokenizer(errResp, " ");
		long cclSum = 0;
		String cclVal = null;
		if (errResp != null && errResp.indexOf("calls must be at least") != -1) {
			while (lstr.hasMoreTokens()) {
				logger.info(lstr.nextToken());
				lstr.nextToken();
				lstr.nextToken();
				lstr.nextToken();
				lstr.nextToken();
				lstr.nextToken();
				lstr.nextToken();
				cclVal = lstr.nextToken().trim();
				break;
			}
		}
		logger.info(cclVal + " cclVal ");
		cclSum += Long.valueOf(cclVal) + orderCCl;
		if (entity != null && entity.equals("ENT")) {
			logger.info("***** Enterprise update ****** ");
			updEnterpriseCCLSum(cclSum, entityVal);

		} else if (entity != null && entity.equals("LOC")) {
			logger.info("***** Location update ****** ");
			updLocationCCLSum(cclSum, entityVal);
		}
		logger.info("Exiting parseBSErrAndUpdInv");

	}

	private void updLocationCCLSum(long cclSum, String locationId) throws ApplicationInterfaceException {
		logger.info("Entering updLocationCCLSum : cclSum:{} locationId:{} ", cclSum, locationId);

		List<String[]> updateKeyValuePairList = new ArrayList<>();
		updateKeyValuePairList.add(new String[] { "LOC_TRUNK_CCL_SUM", String.valueOf(cclSum) });

		List<String[]> whereClauseList = new ArrayList<>();
		whereClauseList.add(new String[] { "LOCATION_ID", locationId });

		updateInventory("TBL_LOCATION", updateKeyValuePairList, whereClauseList);
		logger.info("Exiting updLocationCCLSum ");

	}

	private void updEnterpriseCCLSum(long cclSum, String enterpriseId) throws ApplicationInterfaceException {
		logger.info("Entering updEnterpriseCCLSum : cclSum:{} enterpriseId:{} ", cclSum, enterpriseId);

		List<String[]> updateKeyValuePairList = new ArrayList<>();
		updateKeyValuePairList.add(new String[] { "ENT_TRUNK_CCL_SUM", String.valueOf(cclSum) });

		List<String[]> whereClauseList = new ArrayList<>();
		whereClauseList.add(new String[] { "ENTERPRISE_ID", enterpriseId });

		updateInventory("TBL_LOCATION", updateKeyValuePairList, whereClauseList);
		logger.info("Exiting updEnterpriseCCLSum ");

	}

	
	public String getDomainNameFromLocationId(String locationId) throws ApplicationInterfaceException {
		List<String[]> whereClauseList = new ArrayList<>();
		whereClauseList.add(new String[] { "LOCATION_ID", locationId });

		String sipDomain = searchInventoryForSingleValue("TBL_LOCATION", "SIP_DOMAIN", whereClauseList, String.class);
		return sipDomain;

	}

	
	public String getDomainNameFromLocationId(String locationId, boolean getAllFlag)
			throws ApplicationInterfaceException {
		List<String[]> whereClauseList = new ArrayList<>();
		whereClauseList.add(new String[] { "LOCATION_ID", locationId });
		if (!getAllFlag)
			whereClauseList.add(new String[] { "ACTIVE_IND", "1" });

		// TODO If getAllFlag ==true then ACTIVE_IND != 0 but NOT EQUALS NOT
		// SUPPORTED IN QUERY YET

		String sipDomain = searchInventoryForSingleValue("TBL_LOCATION", "SIP_DOMAIN", whereClauseList, String.class);
		return sipDomain;
	}

	
	public void storeSessionId(String sessionId, String deviceName) throws ApplicationInterfaceException{

		logger.debug("In storeSessionId: Device = " + deviceName);

		/*
		 * TblRouteInfoQuery routeInfoQuery = new TblRouteInfoQuery();
		 * routeInfoQuery.whereDeviceEQ(deviceName);
		 * routeInfoQuery.whereParamNameEQ("SESSION_ID");
		 * routeInfoQuery.query(connection); ArrayList resultList =
		 * routeInfoQuery.getResultArrayList();
		 * 
		 * if (resultList.size() > 1) { throw new Exception(
		 * "More than one sessionId for Device: " + deviceName +
		 * "; inconsistent state"); } if (resultList.size() == 1) { //
		 * SESSION_ID already exists for device; update it. DBTblRouteInfo
		 * tblRouteInfo = new DBTblRouteInfo();
		 * tblRouteInfo.whereDeviceEQ(deviceName);
		 * tblRouteInfo.whereParamNameEQ("SESSION_ID");
		 * tblRouteInfo.setParamValue(sessionId);
		 * tblRouteInfo.updateSpByWhere(connection); connection.commit(); } else
		 * if (resultList.size() == 0) { // No SESSION_ID present for device;
		 * insert the session id. DBTblRouteInfo tblRouteInfo = new
		 * DBTblRouteInfo(); tblRouteInfo.setDevice(deviceName);
		 * tblRouteInfo.setParamName("SESSION_ID");
		 * tblRouteInfo.setParamValue(sessionId);
		 * tblRouteInfo.setConnectionType("G"); tblRouteInfo.insert(connection);
		 * connection.commit(); }
		 */
	}

	
	public List<String> getTnsList(String envOrderId, String taskName) throws ApplicationInterfaceException {
		logger.info("Entering getTnsList : {}", envOrderId);
		List<String> tnsList = new ArrayList<String>();
		HashSet<String> columnNames = new HashSet<String>();
		columnNames.add("TN");

		ArrayList<String[]> whereClause = new ArrayList<String[]>();
		whereClause.add(new String[] { "ENV_ORDER_ID", envOrderId });
		whereClause.add(new String[] { "TASK_NAME", taskName });

		DBServiceResponse facodeTableData = searchInventory("TBL_FAIL_ENTITY_INFO", columnNames, whereClause);
		for (TblRow tblRows : facodeTableData.getTableRows()) {
			tnsList.add(tblRows.getTblRow().get("TN").getValue());
		}
		logger.info("Exiting getTnsList : {}");

		return tnsList;
	}

	
	public String getBSLang(String webLanguage) throws ApplicationInterfaceException {

		// SELECT WEB_LANGUAGE,BS_LANGUAGE FROM TBL_BS_LANGUAGE_MAP

		List<String[]> whereClauseList = new ArrayList<>();
		whereClauseList.add(new String[] { "WEB_LANGUAGE", webLanguage });

		String bsLang = searchInventoryForSingleValue("TBL_BS_LANGUAGE_MAP", "BS_LANGUAGE", whereClauseList,
				String.class);

		/*
		 * TblBsLanguageMapQuery bsLanguageQuery = new TblBsLanguageMapQuery();
		 * bsLanguageQuery.whereWebLanguageEQ(webLanguage);
		 * bsLanguageQuery.query(connection); ArrayList resultList =
		 * bsLanguageQuery.getResultArrayList();
		 * 
		 * if (resultList.size() == 0) { log_msg(5,
		 * " No Entries in tbl_bs_language_map for web Language: " +
		 * webLanguage); } else if (resultList.size() == 1) {
		 * TblBsLanguageMapDbBean tblBsLanguageMap = (TblBsLanguageMapDbBean)
		 * resultList .get(0); bsLang = tblBsLanguageMap.getBsLanguage();
		 * log_msg(5, "BS lang  value based on web Language : " + webLanguage +
		 * " is : " + bsLang);
		 * 
		 * } else { log_msg(5,
		 * " More than one entry  in tbl_bs_language_map for web Language: " +
		 * webLanguage);
		 * 
		 * }
		 */
		return bsLang;
	}

	
	public long getWebLangFromInv(String locationId) throws ApplicationInterfaceException {

		/*
		 * SELECT
		 * LOCATION_ID,ENTERPRISE_ID,DIAL_PLAN_ID,ORDER_SOURCE,LOCATION_NAME,
		 * LOC_ADDRESS,LOC_CITY,LOC_STATE,LOC_ZIP,LOC_COUNTRY,NPANXX,TIME_ZONE,
		 * USE_DAYLIGHT_SAVINGS,DAYLIGHT_SAVINGS_REGION,WEB_LANG,IXPLUS_ID,
		 * IXPLUS_ENV_ID,BILL_TYPE,BILL_ACCT_NUM,NETCOM_SERVICE_ID,CV2_SERVICE,
		 * MANAGED_SERVICE,SERVICE_TYPE_OFFERING,VOIP_SERVICE_TYPE,
		 * HYBRID_SERVICE_TYPE,ACCESS_TYPE,PUB_IP,CIRCUIT_ID,UUNET_SITE_ID,
		 * SIP_DOMAIN,SBC_IND,SBC_ID,SIP_ENABLED,PUBLIC_GTWY_DPID,
		 * DEFAULT_GTWY_DPID,TRUNK_TYPE,VOIP_CLUB,SERVICE_LEVEL,LOC_MARKET,
		 * MAX_EXT_LENGTH,EXT_LENGTH,PRIVATE_NUM_LENGTH,LINE_PORT_LENGTH,
		 * ABBR_DIALING_CODE,ENABLE_CALL_PARK,ENABLE_ACCOUNT_CODE,
		 * ENABLE_AUTH_CODE,LOCAL_DIR_ASSISTANCE,NAT_DIR_ASSISTANCE,
		 * CONCCALL_STAT,MAX_CONCURRENT_CALLS,MAX_CONCURRENT_OFFNET,MAX_INBOUND,
		 * MAX_SLG,MAX_NG,MAX_SUBSCRIBERS,MAX_PUBLIC_TN,BLOCK_ALL_CALLS,
		 * RPID_PRIV,OVERRIDE_CID_NAME,OVERRIDE_SUB_PRIVATE,OVERRIDE_CID_NUM,
		 * RPID_POOL_ID,RPID,BTN_POOL_ID,SWITCH_CLLI,TRUNK,ACT_TEAM_NAME,
		 * ACT_TEAM_PHONE,ACT_TEAM_EMAIL,CONTACT_NAME,CONTACT_PHONE,
		 * CONTACT_EMAIL,HICR_SERVICE,VM_TYPE,VM_LANG,VM_SMDI_AUTH_TOGGLE,
		 * VM_CPE_IP_ADDRESS,MAX_VM_BOX,CALLING_PLAN_ID,ACTIVE_IND,ACTIVE_DATE,
		 * TERM_DATE,CREATED_BY,CREATION_DATE,MODIFIED_BY,LAST_MODIFIED_DATE,
		 * ENV_ORDER_ID,EMER_POOL_ID,EMER_LOCATION_CODE,LOCATION_TYPE,
		 * FMCG_LOCATION_TYPE,HUB_LOCATION_ID,HUB_GATEWAY_DEVICE_ID,
		 * LOCATION_MASK,A_NUM_MASK,B_NUM_MASK,VPN_NAME,TBL_VPN_ID_MAPPING_ID,
		 * SBC_PROV_METHOD,PRODUCTION_INDICATOR,QOS_IND,RIV_LOCATION,NOTES,
		 * SBC_MIG_IND,AFTER_HOURS_INSTALL_FLAG,HIGH_VOLUME_INSTALL_FLAG,
		 * EXPEDITE,LOC_CCL_IND,BILLING_ACTIVATED,CALLING_NAME_IND,
		 * ENHANCED_ANI_IND,STN_POOL_ID,TW_FQDN,TW_SBC_ID,IASA_ORDER_ID,
		 * LOC_TERRITORY,LOC_REGION,BILLING_SYSTEM,CONFIG_ALLOWED,
		 * PRODUCT_IDENTIFIER,E911_SERVICE,ALTERNET_CALLER_ID,VARRS_FLAG,
		 * ISR_DESIGN_ID,LOC_TRUNK_CCL_SUM,SUB_AGENCY_HIER_CODE,
		 * PHYSICAL_LOCATION_ID,PHYSICAL_LOCATION_NAME,DIALING_COUNTRY_CODE,
		 * RESTRICTED_ACCESS,CALL_FWD_PLAN_NAME,LOR_ID,HYBRID_ASSIGNED,
		 * ENTERPRISE_TRUNK_ID,PQ_INSTANCE_ID,PENDING_RPID,CNAM_UPDATE_STATUS,
		 * CNAM_UPDATE_DATE,TSO_MIG_LOCK,E2EI_MIG_FLAG,E2EI_MIG_DATE,
		 * UI_PROV_FLAG,CALNET_SUB_CONTRACT_ID,ADDRESS_ID FROM TBL_LOCATION
		 * where 0=0" + this.clause + this.orderBy);
		 */
		List<String[]> whereClauseList = new ArrayList<>();
		whereClauseList.add(new String[] { "LOCATION_ID", locationId });

		Set<String> selectColumnNames = new HashSet<>();
		selectColumnNames.add("WEB_LANG");
		Long webLang = 0l;

		DBServiceResponse response = searchInventory("TBL_LOCATION", selectColumnNames, whereClauseList);

		try {
			if (response.getTableRows().size() == 0) {
				logger.error(" No Entries in tbl_location for locId: " + locationId);
				/*
				 * logServiceImpl.insertOrderLog("No entries based on locId :" +
				 * locationId + " in tbl_location");
				 */
				throw new ApplicationInterfaceException("No Entries in tbl_location for locId: " + locationId);
			} else if (response.getTableRows().size() == 1) {

				String resp = response.getTableRows().get(0).getTblRow().get("WEB_LANG").getValue();
				if (resp != null) {
					webLang = Long.parseLong(resp);
				}
				logger.info("Web lang  value based on locId : {}", webLang);

			} else {
				logger.error(" More than one entry  in tbl_location for locId: " + locationId);
				/*
				 * insertOrderLog("More than one entry for locId:" + locationId
				 * + " in tbl_location ");
				 */
				throw new ApplicationInterfaceException(
						"More than one entry in tbl_location for locId: " + locationId + "; inconsistent state");
			}
		} catch (Exception e) {
			logger.error("Error while pulling web language from DB ", e);

		}

		return webLang;
	}

	
	public void deleteFailedTNsOnEnvOrderId(String envOrderId, String task) throws ApplicationInterfaceException {
		logger.info("Entering deleteByEnvOrderId, envOrderId: {} ", envOrderId);
		List<String[]> whereClauseList = new ArrayList<>();
		whereClauseList.add(new String[] { "ENV_ORDER_ID", envOrderId });
		whereClauseList.add(new String[] { "TASK_NAME", task });

		Long numberOfRecord = deleteInventory("TBL_FAIL_ENTITY_INFO", whereClauseList);
		if (numberOfRecord == 0) {
			throw new ApplicationInterfaceException("Delete operation did not delete any record");
		}
		logger.info("Exiting deleteEntryFromTblETTGMap, numberOfRecordsDeleted: {}", numberOfRecord);

	}
	
	
	public List<String> getEtTnFeaturesByTn(String tn, String featureType) throws ApplicationInterfaceException {

		logger.info("Entering getEtTnFeaturesByTn, tn: {} , featureType:{}" , tn, featureType);
		List<String> featureList = new ArrayList<String>();
		// SELECT ENTERPRISE_TRUNK_ID, TN_POOL_ID, ET_TN_ID from TBL_TSO_ET_TN
		// where TN_POOL_ID = (SELECT TN_POOL_ID from TBL_PUBLIC_TN_POOL where TN= ? --'18172395426');

		
		List<String> values = Arrays.asList(tn);
		DBServiceResponse response = executePreconfiguredQuery(ESAPDBQueryEnum.GET_DETAILS_FROM_TSO_ET_TN_BY_TN_POOLID, "Network", values);
		if (response == null || response.getTableRows() == null || response.getTableRows().isEmpty()) {
			logger.error("No ET TN found for this ID/TN:" + tn);
			return featureList;
		}
		String enterpriseTrunkId = null;
		String tnPoolId = null;
		String etTnId = null;
		for (TblRow row : response.getTableRows()) {
			enterpriseTrunkId = row.getTblRow().get("ENTERPRISE_TRUNK_ID").getValue();
			tnPoolId = row.getTblRow().get("TN_POOL_ID").getValue();
			etTnId = row.getTblRow().get("ET_TN_ID").getValue();
		}
		
		List<String[]> whereClauseList = new ArrayList<>();
		whereClauseList.add(new String[] { "ENTERPRISE_TRUNK_ID", enterpriseTrunkId });
		String enterpriseId = searchInventoryForSingleValue("TBL_TSO_ENTERPRISE_TRUNK", "ENTERPRISE_ID", whereClauseList, String.class);
		if (enterpriseId == null || "".equalsIgnoreCase(enterpriseId.trim())) {
			logger.error("Enterprise Id wasn't found for this ID/TN:" + tn);
			return featureList;
		}
		
		whereClauseList = new ArrayList<>();
		whereClauseList.add(new String[] { "TN_POOL_ID", tnPoolId });
		String locationId = searchInventoryForSingleValue("TBL_PUBLIC_TN_POOL", "LOCATION_ID", whereClauseList, String.class);
		if (locationId == null || "".equalsIgnoreCase(locationId.trim())) {
			logger.error("Location Id wasn't found for this ID/TN:" + tn);
			return featureList;
		}
		
		whereClauseList = new ArrayList<>();
		whereClauseList.add(new String[] { "LOCATION_ID", locationId });
		String packageId = searchInventoryForSingleValue("TBL_LOC_PACKAGE", "PACKAGE_ID", whereClauseList, String.class);
		if (packageId == null || "".equalsIgnoreCase(packageId.trim())) {
			logger.error("Package Id wasn't found for this ID/TN:" + tn);
			return featureList;
		}
		
		List<String> entAuthFeatureIdList = getEntAuthFeatureIdList(enterpriseId, featureType);
		if (entAuthFeatureIdList == null || entAuthFeatureIdList.size() < 1) {
			logger.error("FAILURE in getEtTnFeaturesByIdOrTn() - Enterprise auth feature list is null or empty List");
			return featureList;
		}
		
		List<String> disabledFeatureIdList = getEtTnDisabledFeatureIdList(etTnId);
		
		Map<String,String> packageFeatureIdList = getPkgFeatureIdList(packageId, featureType);
		
		if (packageFeatureIdList == null || packageFeatureIdList.isEmpty()) {
			logger.error("FAILURE in getEtTnFeaturesByIdOrTn() - Package features not found for the given and package:"+packageId);
			return featureList;
		}
		
		for (Map.Entry<String, String> entry : packageFeatureIdList.entrySet()) {
			if (entAuthFeatureIdList.contains(entry.getKey())) {
				if (disabledFeatureIdList == null || !disabledFeatureIdList.contains(entry.getKey())) {
					featureList.add(entry.getValue());
				} else {
					logger.info("FeatureId = {}  is in the disable feature list, hence not included in the assign feature list", entry.getKey());
				}
			} else {
				logger.info("FeatureId = {}  is not authorized for the Ent, hence not included in the assign feature list", entry.getKey());
			}
		}
		logger.info("Exiting getEtTnFeaturesByTnId, tn: {} , featureType:{}" , tn, featureType);
		
		return featureList;
	}

	private Map<String, String> getPkgFeatureIdList(String packageId, String featureType) throws ApplicationInterfaceException {
		
		/*SELECT FEATURE_ID, NAME FROM TBL_VZB_FEATURES WHERE FEATURE_ID IN 
		( SELECT FEATURE_ID FROM TBL_PKG_FEATURES WHERE PACKAGE_ID = ? --13 AND IS_SELECTED = 'Y') 
		AND FEATURE_TYPE= ? --'U';*/
		
		Map<String,String> featureMap = new HashMap<>();
		List<String> values = Arrays.asList(packageId,featureType);

		DBServiceResponse response = executePreconfiguredQuery(ESAPDBQueryEnum.GET_FEATURES_BY_PACKAGE_ID, "Network", values);
		if (response == null || response.getTableRows() == null || response.getTableRows().isEmpty()) {
			return featureMap;
		}
		for (TblRow row : response.getTableRows()) {
			featureMap.put(row.getTblRow().get("FEATURE_ID").getValue(),row.getTblRow().get("NAME").getValue());
		}
		return featureMap;
	}

	private List<String> getEtTnDisabledFeatureIdList(String etTnId) throws ApplicationInterfaceException {
		logger.info("Entering getEtTnDisabledFeatureIdList : {}", etTnId);
		List<String> disabledFeatureIdList = new ArrayList<String>();
		HashSet<String> selectColumnNameSet = new HashSet<String>();
		selectColumnNameSet.add("FEATURE_ID");
		
		ArrayList<String[]> whereClause = new ArrayList<String[]>();
		whereClause.add(new String[] { "ET_TN_ID", etTnId });

		DBServiceResponse tsoEtTnExcldFeaturesData = searchInventory("TBL_TSO_ET_TN_EXCLD_FEATURES", selectColumnNameSet, whereClause);
		for (TblRow tblRows : tsoEtTnExcldFeaturesData.getTableRows()) {
			disabledFeatureIdList.add(tblRows.getTblRow().get("ET_TN_ID").getValue());
		}
		logger.info("Exiting getEtTnDisabledFeatureIdList()");

		return disabledFeatureIdList;		
	}

	
	public Map<String, String> getFeatureConfigValues(String featureAction) throws ApplicationInterfaceException {

		// SELECT
		// SWITCH_TYPE,FEATURE,ORDER_ATTRIB_NAME,ATTRIB_NAME,ACTION,DEFAULT_VALUE
		// FROM TBL_FEATURE_ATTRIBS

		logger.info("getFeatureConfigValues() featureAction : {} ", featureAction);

		Map<String, String> featureConfigMap = new HashMap<String, String>();

		HashSet<String> columnNames = new HashSet<String>();
		columnNames.add("FEATURE");
		columnNames.add("DEFAULT_VALUE");
		ArrayList<String[]> whereClause = new ArrayList<String[]>();
		whereClause.add(new String[] { "ATTRIB_NAME", "Status" });
		whereClause.add(new String[] { "SWITCH_TYPE", "Broadsoft"});
		whereClause.add(new String[] { "ACTION", featureAction});
		
		
		DBServiceResponse resultTblData = searchInventory("TBL_FEATURE_ATTRIBS", columnNames, whereClause);

		for (TblRow tblRows : resultTblData.getTableRows()) {
			String feature = tblRows.getTblRow().get("FEATURE").getValue();
			String defaultValue = tblRows.getTblRow().get("DEFAULT_VALUE").getValue();
			featureConfigMap.put(feature, defaultValue);
		}
		return featureConfigMap;
		
	}

	
	public List<String> getETTnLineFeaturesByTN(String tn) throws ApplicationInterfaceException {
		/*SELECT NAME FROM TBL_VZB_FEATURES VZB WHERE FEATURE_ID
		IN (
		select feature_id from TBL_TSO_ET_TN_FEATURES where et_tn_id IN (SELECT ETTN.ET_TN_ID 
		FROM TBL_TSO_ET_TN ETTN ,TBL_PUBLIC_TN_POOL TP WHERE ETTN.TN_POOL_ID = TP.TN_POOL_ID AND TP.TN= ? --18172395426));*/
		
		
		/*Created new query to pull service name for more than one TN 
		 * select distinct  TP.TN,TBL_VZB_FEATURES.NAME from TBL_VZB_FEATURES , tbl_tso_et_tn_features ,TBL_TSO_ET_TN ETTN ,TBL_PUBLIC_TN_POOL TP where tbl_tso_et_tn_features.et_tn_id = ETTN.ET_TN_ID and 
				ETTN.TN_POOL_ID = TP.TN_POOL_ID AND TP.TN in  ( '14102728141','14102728140')
		*/
		List<String> featureList = new ArrayList<String>();
		List<String> values = Arrays.asList(tn);

		DBServiceResponse response = executePreconfiguredQuery(ESAPDBQueryEnum.GET_ET_TN_FEATURES, "Network", values);
		if (response == null || response.getTableRows() == null || response.getTableRows().isEmpty()) {
			return featureList;
		}
		for (TblRow row : response.getTableRows()) {
			featureList.add(row.getTblRow().get("NAME").getValue());
		}
		return featureList;
	}

	
	public String getFeatureByNameAndType(String feature, String featureType) throws ApplicationInterfaceException {
		ArrayList<String[]> whereClauseList = new ArrayList<String[]>();
		whereClauseList.add(new String[] { "NAME", feature });
		whereClauseList.add(new String[] { "FEATURE_TYPE", featureType });
		
		String featureName = searchInventoryForSingleValue("TBL_VZB_FEATURES", "NAME", whereClauseList, String.class);
		return featureName;
	}


	
	public void updateFlowStatus(int status, String orderDetailId) throws ApplicationInterfaceException {
		List<String[]> updateKeyValuePairList = new ArrayList<>();
		updateKeyValuePairList.add(new String[] { "STATUS", String.valueOf(status) });

		List<String[]> whereClauseList = new ArrayList<>();
		whereClauseList.add(new String[] { "ORDER_DETAIL_ID", orderDetailId });

		updateInventory("TBL_ORDER_DETAILS", updateKeyValuePairList, whereClauseList);

	}

	
	public Long getCallingNameIndicatorForLocation(String locationId) throws ApplicationInterfaceException {
		ArrayList<String[]> whereClauseList = new ArrayList<String[]>();
		whereClauseList.add(new String[] { "LOCATION_ID", locationId });
		
		Long callingNameInd = searchInventoryForSingleValue("TBL_LOCATION", "CALLING_NAME_IND", whereClauseList, Long.class);
		return callingNameInd;
	}

	
	public boolean isDeviceShared(String deviceId, String locationId) throws ApplicationInterfaceException {
		List<String[]> selectKeyValuePairList = new ArrayList<>();
		selectKeyValuePairList.add(new String[] { "LOCATION_ID", locationId });

		List<String[]> whereClauseList = new ArrayList<>();
		whereClauseList.add(new String[] { "GATEWAY_DEVICE_ID", deviceId });
		long locationID =searchInventoryForSingleValue("TBL_DEVICE_MAP", "LOCATION_ID", whereClauseList, Long.class);
		boolean flag = false;
		if(locationID == 1){
			flag =true;
		} 
		return flag;
	}

	
	public Map<String, String> getLocationTnList(String locationId) throws ApplicationInterfaceException {
		
		logger.info("getLocationTnList() locationId : {} ", locationId);
		Map<String, String> tnMap = new HashMap<String, String>();
		HashSet<String> columnNames = new HashSet<String>();
		columnNames.add("TN");
		columnNames.add("ENV_ORDER_ID");
		ArrayList<String[]> whereClause = new ArrayList<String[]>();
		whereClause.add(new String[] { "LOCATION_ID", locationId });
		DBServiceResponse resultTblData = searchInventory("TBL_PUBLIC_TN_POOL", columnNames, whereClause);

		for (TblRow tblRows : resultTblData.getTableRows()) {
			String tn = tblRows.getTblRow().get("TN").getValue();
			String envOrderId = tblRows.getTblRow().get("ENV_ORDER_ID").getValue();
			tnMap.put(tn,envOrderId);
		}
		logger.info("getLocationTnList() locationId : {}  Number of Tn {}", locationId,tnMap.size());
		return tnMap;
	}

	
	public String getHostNE(int bsAsId) throws ApplicationInterfaceException {

		ArrayList<String[]> whereClauseList = new ArrayList<String[]>();
		whereClauseList.add(new String[] { "BS_AS_ID", String.valueOf(bsAsId) });
		String featureName = searchInventoryForSingleValue("TBL_BS_AS", "AS_NAME", whereClauseList, String.class);
		return featureName;
	}

	/***
	 * 
	 * This method is used to get the Features based on SubId or TN
	 * 
	 * @param subId
	 * @param subIdIsTn
	 * @param featureType
	 * @return
	 * @throws ApplicationInterfaceException
	 */
	public List<FeaturePackageBean> getNetFeaturesBySubIdOrTn(String subId,
			boolean subIdIsTn, String featureType)
			throws ApplicationInterfaceException {

		String locationIdLocal = null;
		String entIdLocal = null;
		String isSelected = null;
		long pkgIdLocal = 0;
		long groupTnId = 0;
		long groupId = 0;
		long fmcgPkgId = 0;
		boolean foundMatchingPkgId = false;
		boolean foundAtLeastOneFeature = false;
		FeaturePackageBean resultFeatPkgBean = new FeaturePackageBean();
		ArrayList<FeaturePackageBean> featPkgList = new ArrayList<FeaturePackageBean>();
		ArrayList<FeaturesBean> featList = new ArrayList<FeaturesBean>();
		try {
			if (subId != null && !subId.equalsIgnoreCase("")) {
				if (subIdIsTn) {
					long tnPoolId = getTnPoolIdByTn(subId);
					ArrayList<String[]> grpTnQryWhereClauseList = new ArrayList<String[]>();
					grpTnQryWhereClauseList.add(new String[] { "TN_POOL_ID",
							String.valueOf(tnPoolId) });
					Set<String> grpTnQrySelectColumnNameSet = new HashSet<>();
					grpTnQrySelectColumnNameSet.add("TN_POOL_ID");
					grpTnQrySelectColumnNameSet.add("GROUP_TN_ID");
					grpTnQrySelectColumnNameSet.add("GROUP_ID");
					grpTnQrySelectColumnNameSet.add("SUB_ID");
					DBServiceResponse query1 = searchInventory(" TBL_GROUP_TN",
							grpTnQrySelectColumnNameSet,
							grpTnQryWhereClauseList);
					if (query1.getTableRows().size() > 0) {
						for (TblRow tblRows : query1.getTableRows()) {
							groupTnId = Long.parseLong(tblRows.getTblRow()
									.get("GROUP_TN_ID").getValue());
							groupId = Long.parseLong(tblRows.getTblRow()
									.get("GROUP_ID").getValue());
							subId = tblRows.getTblRow().get("SUB_ID")
									.getValue();

							// sub query
							if (subId != null && !"".equalsIgnoreCase(subId)) {
								ArrayList<String[]> whereClaus = new ArrayList<String[]>();
								whereClaus.add(new String[] { "SUB_ID",
										String.valueOf(subId) });
								Set<String> selectColumnName = new HashSet<>();
								selectColumnName.add("SUB_ID");
								selectColumnName.add("FEATURE_PKG_ID");
								DBServiceResponse subQuery = searchInventory(
										"TBL_SUBSCRIBER", selectColumnName,
										whereClaus);
								if (subQuery.getTableRows().size() > 0) {
									for (TblRow tblRow : subQuery
											.getTableRows()) {
										fmcgPkgId = Long.parseLong(tblRow
												.getTblRow()
												.get("FEATURE_PKG_ID")
												.getValue());

									}
								}
							}

							ArrayList<String[]> whereClau = new ArrayList<String[]>();
							whereClau.add(new String[] { "GROUP_ID",
									String.valueOf(groupId) });
							Set<String> grpQryselectColumnNam = new HashSet<>();
							grpQryselectColumnNam.add("GROUP_ID");
							grpQryselectColumnNam.add("LOCATION_ID");
							grpQryselectColumnNam.add("PACKAGE_ID");
							DBServiceResponse grpQrysubQuery = searchInventory(
									"TBL_GROUP", grpQryselectColumnNam,
									whereClau);
							if (grpQrysubQuery.getTableRows().size() > 0) {
								for (TblRow tblRows1 : grpQrysubQuery
										.getTableRows()) {
									locationIdLocal = tblRows1.getTblRow()
											.get("LOCATION_ID").getValue();
									pkgIdLocal = Long.parseLong(tblRows1
											.getTblRow().get("PACKAGE_ID")
											.getValue());
									ArrayList<String[]> whereClaus1 = new ArrayList<String[]>();
									whereClaus1.add(new String[] {
											"LOCATION_ID",
											String.valueOf(locationIdLocal) });
									Set<String> locationQryselectColumnName = new HashSet<>();
									locationQryselectColumnName
											.add("LOCATION_ID");
									locationQryselectColumnName
											.add("ENTERPRISE_ID");
									DBServiceResponse locationQrysubQuery = searchInventory(
											"TBL_LOCATION",
											locationQryselectColumnName,
											whereClaus1);
									if (locationQrysubQuery.getTableRows()
											.size() > 0) {
										for (TblRow tblRow2 : locationQrysubQuery
												.getTableRows()) {
											entIdLocal = tblRow2.getTblRow()
													.get("ENTERPRISE_ID")
													.getValue();
										}
									}
								}
							} else {
								logger.info("tn is not part of valid group in ESAP. ");
								return null;
							}
						}
					} else {
						logger.info("SubId is not valid in ESAP. No Group Tn entries found for this Tn");
						return null;
					}
				} else {
					ArrayList<String[]> whereClause1 = new ArrayList<String[]>();
					whereClause1.add(new String[] { "SUB_ID",
							String.valueOf(subId) });
					Set<String> selectColumnNam = new HashSet<>();
					selectColumnNam.add("SUB_ID");
					selectColumnNam.add("LOCATION_ID");
					selectColumnNam.add("FEATURE_PKG_ID");
					DBServiceResponse subQuery3 = searchInventory(
							"TBL_SUBSCRIBER", selectColumnNam, whereClause1);
					if (subQuery3.getTableRows().size() > 0) {
						for (TblRow tblRows2 : subQuery3.getTableRows()) {
							locationIdLocal = tblRows2.getTblRow()
									.get("LOCATION_ID").getValue();
							pkgIdLocal = Long.parseLong(tblRows2.getTblRow()
									.get("FEATURE_PKG_ID").getValue());
							ArrayList<String[]> whereClaus2 = new ArrayList<String[]>();
							whereClaus2.add(new String[] { "LOCATION_ID",
									String.valueOf(locationIdLocal) });
							Set<String> selectColumnName1 = new HashSet<>();
							selectColumnName1.add("LOCATION_ID");
							selectColumnName1.add("ENTERPRISE_ID");
							DBServiceResponse subQuery4 = searchInventory(
									"TBL_LOCATION", selectColumnName1,
									whereClaus2);
							if (subQuery4.getTableRows().size() > 0) {
								for (TblRow tblRow3 : subQuery4.getTableRows()) {
									entIdLocal = tblRow3.getTblRow()
											.get("ENTERPRISE_ID").getValue();
									if (entIdLocal == null) {
										logger.info("Unable to retrieve enterprise for this tn");
										return null;
									}
								}
							}

						}
					} else {
						logger.info("SubId is not valid in ESAP");
						return null;
					}
				}
			} else {

				logger.info("SubId is not set");
				return null;
			}

			logger.info("locationId = " + locationIdLocal);
			logger.info("enterpriseId = " + entIdLocal);
			logger.info("featureType = " + featureType);
			logger.info("packageId = " + pkgIdLocal);
			// get the list of Ent auth features, to later verify if the pkg
			// features are all authorized
			List<String> entAuthFeatureIdList = getEntAuthFeatureIdList(
					entIdLocal, featureType);
			List<String> disabledFeatureIdList = null;
			if (groupTnId > 0 || groupId > 0) {
				disabledFeatureIdList = getDisabledFeatureIdList(groupTnId,
						groupId);
			}
			if (entAuthFeatureIdList == null || entAuthFeatureIdList.size() < 1) {
				logger.info("FAILURE in getFeaturePackagcesForLocationByPackageIdAndLocationId. Enterprise auth feature list is null or empty List.");
				return null;
			}
			int numberOfPkgs = 1;
			if (fmcgPkgId > 0) {
				numberOfPkgs = 2;
			}

			for (int i = 0; i < numberOfPkgs; i++) {
				// NOTE: this means we have fmcg Pkg Id.
				if (i == 1) {
					pkgIdLocal = fmcgPkgId;
				}
				ArrayList<String[]> whereClause2 = new ArrayList<String[]>();
				whereClause2.add(new String[] { "PACKAGE_ID",
						String.valueOf(pkgIdLocal) });
				Set<String> pkgQryselectColumnName = new HashSet<>();
				pkgQryselectColumnName.add("PACKAGE_ID");
				DBServiceResponse pkgQry = searchInventory("TBL_PACKAGE",
						pkgQryselectColumnName, whereClause2);
				if (pkgQry.getTableRows().size() > 0) {
					for (TblRow tblRows11 : pkgQry.getTableRows()) {
						foundMatchingPkgId = true;
						ArrayList<String[]> whereClaus2 = new ArrayList<String[]>();
						whereClaus2.add(new String[] { "PACKAGE_ID",
								String.valueOf(pkgIdLocal) });
						whereClaus2.add(new String[] { "IS_SELECTED",
								String.valueOf('Y') });
						Set<String> selectColumnName11 = new HashSet<>();
						selectColumnName11.add("PACKAGE_ID");
						selectColumnName11.add("IS_SELECTED");
						selectColumnName11.add("FEATURE_ID");
						DBServiceResponse pkgFeatQry = searchInventory(
								"TBL_PKG_FEATURES", selectColumnName11,
								whereClaus2);
						if (pkgFeatQry.getTableRows().size() > 0) {
							for (TblRow tblRow2 : pkgFeatQry.getTableRows()) {
								long featId = Long.parseLong(tblRow2
										.getTblRow().get("FEATURE_ID")
										.getValue());
								isSelected = tblRow2.getTblRow()
										.get("IS_SELECTED").getValue();
								// check if the feature id is in the list of Ent
								// auth features.
								if (entAuthFeatureIdList.contains("" + featId)) {
									// ignore if its part of disabled list
									if (disabledFeatureIdList == null
											|| !disabledFeatureIdList
													.contains("" + featId)) {
										// for the featureid, get the details
										// from TBL_VZB_FEATURES and collect in
										// a list.
										ArrayList<String[]> fwhereClause2 = new ArrayList<String[]>();
										fwhereClause2.add(new String[] {
												"FEATURE_ID",
												String.valueOf(featId) });;
										// optional search for featureType
										if (featureType != null
												&& featureType.trim().length() > 0) {
											fwhereClause2
													.add(new String[] {
															"FEATURE_TYPE",
															String.valueOf(featureType) });
										}
										Set<String> fselectColumnNamee1 = new HashSet<>();
										fselectColumnNamee1.add("FEATURE_ID");
										fselectColumnNamee1.add("FEATURE_TYPE");
										fselectColumnNamee1.add("NAME");
										
										DBServiceResponse vzbFeatQry = searchInventory(
												"TBL_VZB_FEATURES",
												fselectColumnNamee1,
												fwhereClause2);
										if (vzbFeatQry.getTableRows().size() > 0) {
											for (TblRow vzbRowss : vzbFeatQry
													.getTableRows()) {
												foundAtLeastOneFeature = true;
												VzbFeaturesDbBean vzbFeatBean = new VzbFeaturesDbBean();
												vzbFeatBean.setFeatureId(Integer.valueOf(vzbRowss
														.getTblRow().get("FEATURE_ID")
														.getValue()));
												vzbFeatBean.setFeatureType(vzbRowss
														.getTblRow().get("FEATURE_TYPE")
														.getValue());
												vzbFeatBean.setName(vzbRowss
														.getTblRow().get("NAME")
														.getValue());
												//vzbFeatBean.copyFromBean(vzbRowss);
												if (vzbFeatBean != null) {
													FeaturesBean featBean = new FeaturesBean();
													featBean.setFeaturesDbBean(vzbFeatBean);
													featBean.setIsSelected(isSelected
															.equals("Y") ? true
															: false);
													featList.add(featBean);
												}
											}
										} else {
											logger.info("FAILURE :Pkg features not found for the given location id and package name");
											return null;
										}

									} else {
										logger.info("FeatureId = "
												+ featId
												+ " is in the disable feature list, hence not included in the assign feature list");
									}

								} else {
									logger.info("FeatureId = "
											+ featId
											+ " is not authorized for the Ent, hence not included in the assign feature list");
								}
							}
						} else {
							logger.info("FAILURE :Pkg features not found for the given location id and package name");
							return null;
						}
					}

				} else {
					logger.info("FAILURE :Pkg features not found for the given location id and package name");
					return null;
				}

			}
			if (!foundMatchingPkgId) {
				logger.info("FAILURE :Package id not found for the given location id and package name");
				return null;
			}
			// getBillable features for subId
			if (!subIdIsTn || fmcgPkgId > 0) {

				ArrayList<String[]> subWhereClause22 = new ArrayList<String[]>();
				subWhereClause22.add(new String[] { "SUB_ID",
						String.valueOf(subId) });
				subWhereClause22.add(new String[] { "IS_SELECTED",
						String.valueOf('Y') });
				Set<String> subSelectColumnNamee11 = new HashSet<>();
				subSelectColumnNamee11.add("SUB_ID");
				subSelectColumnNamee11.add("IS_SELECTED");
				subSelectColumnNamee11.add("FEATURE_ID");
				DBServiceResponse subSubQuery11 = searchInventory(
						"TBL_SUB_FEATURE", subSelectColumnNamee11,
						subWhereClause22);
				if (subSubQuery11.getTableRows().size() > 0) {

					for (TblRow subTblRows11 : subSubQuery11.getTableRows()) {
						long featureId = Long.parseLong(subTblRows11
								.getTblRow().get("FEATURE_ID").getValue());
						TblSubFeatureDbBean subFeatBean = new TblSubFeatureDbBean();
						subFeatBean.copyFromBean(subTblRows11);
						if (entAuthFeatureIdList.contains("" + featureId)) {
							ArrayList<String[]> vzbFeatQryWhereClause = new ArrayList<String[]>();
							subWhereClause22.add(new String[] { "FEATURE_ID",
									String.valueOf(featureId) });
							if (featureType != null
									&& featureType.trim().length() > 0) {
								subWhereClause22.add(new String[] {
										"FEATURE_TYPE", featureType });
							}
							Set<String> vzbFeatQrySubSelectColumnName = new HashSet<>();
							vzbFeatQrySubSelectColumnName.add("FEATURE_ID");
							vzbFeatQrySubSelectColumnName.add("FEATURE_TYPE");

							DBServiceResponse vzbFeatQry = searchInventory(
									"TBL_VZB_FEATURES",
									vzbFeatQrySubSelectColumnName,
									vzbFeatQryWhereClause);
							if (vzbFeatQry.getTableRows().size() > 0) {
								for (TblRow vzbFeatQrySubTblRows : vzbFeatQry
										.getTableRows()) {
									foundAtLeastOneFeature = true;
									VzbFeaturesDbBean vzbFeatBean = new VzbFeaturesDbBean();
									
									vzbFeatBean.setFeatureId(Integer.valueOf(vzbFeatQrySubTblRows
											.getTblRow().get("FEATURE_ID")
											.getValue()));
									vzbFeatBean.setFeatureType(vzbFeatQrySubTblRows
											.getTblRow().get("FEATURE_TYPE")
											.getValue());
									vzbFeatBean.setName(vzbFeatQrySubTblRows
											.getTblRow().get("NAME")
											.getValue());
								/*	vzbFeatBean
											.copyFromBean(vzbFeatQrySubTblRows);*/
									if (vzbFeatBean != null) {
										FeaturesBean featBean = new FeaturesBean();
										featBean.setFeaturesDbBean(vzbFeatBean);
										featBean.setIsSelected(isSelected
												.equals("Y") ? true : false);
										featList.add(featBean);
									}
								}

							}

						}

					}

				}

			}

			if (subIdIsTn && groupId > 0) {
				ArrayList<String[]> grpFeatQuerySubwhereClause = new ArrayList<String[]>();
				grpFeatQuerySubwhereClause.add(new String[] { "GROUP_ID",
						String.valueOf(groupId) });
				Set<String> grpFeatQuerySubSelectColumnName = new HashSet<>();
				grpFeatQuerySubSelectColumnName.add("GROUP_ID");
				grpFeatQuerySubSelectColumnName.add("FEATURE_ID");
				DBServiceResponse grpFeatQuery = searchInventory(
						"TBL_GROUP_FEATURES", grpFeatQuerySubSelectColumnName,
						grpFeatQuerySubwhereClause);
				if (grpFeatQuery.getTableRows().size() > 0) {

					for (TblRow grpFeatQueryTblRows : grpFeatQuery
							.getTableRows()) {
						long featureId = Long.parseLong(grpFeatQueryTblRows
								.getTblRow().get("FEATURE_ID").getValue());
						TblGroupFeaturesDbBean grpFeatBean = new TblGroupFeaturesDbBean();
						grpFeatBean.copyFromBean(grpFeatQueryTblRows);
						if (entAuthFeatureIdList.contains("" + featureId)) {
							ArrayList<String[]> vzbFeatQryWhereClause = new ArrayList<String[]>();
							vzbFeatQryWhereClause.add(new String[] {
									"FEATURE_ID", String.valueOf(featureId) });
							if (featureType != null
									&& featureType.trim().length() > 0) {
								vzbFeatQryWhereClause.add(new String[] {
										"FEATURE_TYPE", featureType });
							}
							Set<String> vzbFeatQrySubSelectColumnName = new HashSet<>();
							vzbFeatQrySubSelectColumnName.add("FEATURE_ID");
							vzbFeatQrySubSelectColumnName.add("FEATURE_TYPE");
							vzbFeatQrySubSelectColumnName.add("NAME");
							DBServiceResponse vzbFeatQry = searchInventory(
									"TBL_VZB_FEATURES",
									vzbFeatQrySubSelectColumnName,
									vzbFeatQryWhereClause);
							if (vzbFeatQry.getTableRows().size() > 0) {
								for (TblRow vzbFeatQrySubTblRows : vzbFeatQry
										.getTableRows()) {
									foundAtLeastOneFeature = true;
									VzbFeaturesDbBean vzbFeatBean = new VzbFeaturesDbBean();
									
									vzbFeatBean.setFeatureId(Integer.valueOf(vzbFeatQrySubTblRows
											.getTblRow().get("FEATURE_ID")
											.getValue()));
									vzbFeatBean.setFeatureType(vzbFeatQrySubTblRows
											.getTblRow().get("FEATURE_TYPE")
											.getValue());
									vzbFeatBean.setName(vzbFeatQrySubTblRows
											.getTblRow().get("NAME")
											.getValue());
								/*	vzbFeatBean
											.copyFromBean(vzbFeatQrySubTblRows);*/
									if (vzbFeatBean != null) {
										FeaturesBean featBean = new FeaturesBean();
										featBean.setFeaturesDbBean(vzbFeatBean);
										featList.add(featBean);
									}
								}
							}

						}

					}

				}

			}
			if (!foundAtLeastOneFeature) {
				logger.info("No features where found for the given location id and package name");
				return null;
			}

		} catch (Exception e) {
			logger.error("DB FAILURE in Location::getNetFeaturesBySubIdOrTn: {} ", e);
			return null;
		} // set the results for output
		resultFeatPkgBean.setFeatureList(featList);
		featPkgList.add(resultFeatPkgBean);
		logger.info("Successfully retrieved getFeatureListByFeaturePackageId for FeaturePackage from the DB");
		return featPkgList;
	}

	/**
	 * This method is used to get TnPoolId based on Tn
	 * 
	 * @param tn
	 * @return
	 * @throws ApplicationInterfaceException
	 */
	public long getTnPoolIdByTn(String tn) throws ApplicationInterfaceException {
		logger.info("Entering Location::getTnPoolIdByTn");
		logger.info("!! Tn " + tn);
		logger.info("!! AFter printing");
		long tnPoolId = 0;
		if (tn == null || tn.trim().equals("")) {
			tn = "0";
		}
		try {
			Set<String> columnFeatures = SetSelectColumnUtil.getSelectColumnSetForTNPool();

			ArrayList<String[]> whereClause = new ArrayList<String[]>();
			whereClause.add(new String[] { "TN_POOL_ID", String.valueOf(tn) });
			DBServiceResponse tnQry = searchInventory("TBL_PUBLIC_TN_POOL", columnFeatures, whereClause);
			if (tnQry.getTableRows().size() > 0) {
				for (TblRow tblRow : tnQry.getTableRows()) {
					tnPoolId = Long.parseLong(tblRow.getTblRow().get("TN_POOL_ID").getValue());
				}
			} else {
				logger.info("TN [" + tn + "] Not Found");
				return tnPoolId;

			}

			logger.info("Retrieved TN Id [" + tnPoolId + "] For Tn [" + tn + "]");

		} catch (Exception e) {
			logger.info("Exception: Failed to retrieve TN Id: {}", e);
			return tnPoolId;
		}

		logger.info("Successfully retrived TN Id");
		return tnPoolId;
	}

	/**
	 * This method is used to get the disabled feature id list based on group tn
	 * id and group id
	 * 
	 * @param groupTnId
	 * @param groupId
	 * @return
	 * @throws ApplicationInterfaceException
	 */
	public List<String> getDisabledFeatureIdList(long groupTnId, long groupId) throws ApplicationInterfaceException {
		List<String> disabledFeatureIdList = new ArrayList<String>();
		ArrayList<String[]> whereClause = new ArrayList<String[]>();
		whereClause.add(new String[] { "GROUP_TN_ID", String.valueOf(groupTnId) });
		Set<String> selectColumnName = new HashSet<>();
		selectColumnName.add("GROUP_TN_ID");
		selectColumnName.add("FEATURE_ID");
		DBServiceResponse subQuery1 = searchInventory("TBL_GROUP_TN_EXCLD_FEATURES", selectColumnName, whereClause);
		if (subQuery1.getTableRows().size() > 0) {
			for (TblRow tblRow : subQuery1.getTableRows()) {
				disabledFeatureIdList.add("" + tblRow.getTblRow().get("FEATURE_ID").getValue());
			}
		}

		ArrayList<String[]> whereClause1 = new ArrayList<String[]>();
		whereClause1.add(new String[] { "GROUP_ID", String.valueOf(groupId) });
		Set<String> selectColumnName1 = new HashSet<>();
		selectColumnName1.add("GROUP_ID");
		selectColumnName1.add("FEATURE_ID");
		DBServiceResponse subQuery2 = searchInventory("TBL_GROUP_EXCLD_FEATURES", selectColumnName1, whereClause1);
		if (subQuery2.getTableRows().size() > 0) {
			for (TblRow tblRow1 : subQuery2.getTableRows()) {
				disabledFeatureIdList.add("" + tblRow1.getTblRow().get("FEATURE_ID").getValue());
			}
		}
		return disabledFeatureIdList;
	}

	
	public Map<String, List<String>> getETTnLineFeaturesByTNBulk(
			Set<String> keySet) throws ApplicationInterfaceException {
		
		logger.info("Entering getETTnLineFeaturesByTNBulk");
		
		/*
		 * 
		 * select distinct TP.TN,TBL_VZB_FEATURES.NAME from TBL_VZB_FEATURES ,
		 * tbl_tso_et_tn_features ,TBL_TSO_ET_TN ETTN ,TBL_PUBLIC_TN_POOL TP
		 * where tbl_tso_et_tn_features.et_tn_id = ETTN.ET_TN_ID and
		 * ETTN.TN_POOL_ID = TP.TN_POOL_ID AND TP.TN in ( ?) order by TP.TN
		 */
		Map<String,List<String>> featureListMap = new HashMap<String, List<String>>();
		@SuppressWarnings("rawtypes")
		List<String> values = new ArrayList(keySet);
		List<String> featureList = null;
		DBServiceResponse response = executePreconfiguredQuery(ESAPDBQueryEnum.GET_ET_TN_FEATURES_BULK, "Network", values);
		if (response == null || response.getTableRows() == null || response.getTableRows().isEmpty()) {
			return featureListMap;
		}
		for (TblRow row : response.getTableRows()) {
			String tn = row.getTblRow().get("TP.TN").getValue();
			String featureName = row.getTblRow().get("TBL_VZB_FEATURES.NAME").getValue();
			if (featureListMap.get(tn) == null){
					featureList = new ArrayList<String>();
					featureList.add(featureName);
					featureListMap.put(tn,featureList);
			}else{
				featureListMap.get(tn).add(featureName);
			}
		}
		if(featureListMap.isEmpty()){
			logger.info("No feature list found for given set of Tns");
		}
		return featureListMap;
	}

	/**
	 * This method returns the orderType associated with given service name . 
	 * 
	 * @param wfServiceName
	 * @param systemEntityType TODO
	 * @return
	 */
	public String getOrderType(String wfServiceName, String systemEntityType) throws ApplicationInterfaceException{
	
		logger.debug("Entering getOrderType");
		
		ArrayList<String[]> whereClause = new ArrayList<String[]>();
		whereClause.add(new String[] { "WF_SERVICE", wfServiceName });
		whereClause.add(new String[] { "ENTITY_TYPE", systemEntityType });
		String orderType = searchInventoryForSingleValue("TBL_RETAIL_SERVICE_FXO", "ORDER_TYPE", whereClause, String.class);
		
		return orderType;
	}
	

}