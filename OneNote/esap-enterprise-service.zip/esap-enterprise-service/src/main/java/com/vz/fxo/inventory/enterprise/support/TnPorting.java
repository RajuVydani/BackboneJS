package com.vz.fxo.inventory.enterprise.support;

import java.sql.Connection;
import java.sql.SQLException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import esap.db.DBTblTnPortingInfo;
import esap.db.TblTnPortingInfoDbBean;
import esap.db.TblTnPortingInfoQuery;

public class TnPorting extends TnPortingBean {

	private static Logger log = LoggerFactory.getLogger(TnPorting.class.toString());
	// connection variable
	Connection dbCon;
	InvErrorCode status = InvErrorCode.INTERNAL_ERROR;

	public TnPorting() {
		this.dbCon = null;
	}
	// constructors
	public TnPorting(Connection dbCon) {
		this.dbCon = dbCon;
	}

	public TnPorting(TnPortingBean tnPortingBean, Connection dbCon) {
		super(tnPortingBean);
		this.dbCon = dbCon;
	}

	// setter & getter
	public void setStatus(InvErrorCode status) {
		this.status = status;
	}

	public Connection getDbCon() {
		return dbCon;
	}

	public void setDbCon(Connection dbCon) {
		this.dbCon = dbCon;
	}

	// Methods
	/**
	 * Adds the porting info
	 * 
	 * @return
	 * @throws SQLException
	 * @throws Exception
	 */
	public boolean addTnPorting() throws SQLException, Exception {

		DBTblTnPortingInfo tnPortingDbBean = new DBTblTnPortingInfo();

		tnPortingDbBean.setTnPoolId(getTnPoolId());
		tnPortingDbBean.setPortingInd(getPortingInd());
		tnPortingDbBean.setSubStatus(getSubStatus());
		tnPortingDbBean.setGatewayNumber(getGatewayNumber());
		tnPortingDbBean.setLosingCarrierPrefix(getLosingCarrierPrefix());
		tnPortingDbBean.setGainingCarrierPrefix(getGainingCarrierPrefix());
		tnPortingDbBean.setOriginalCarrierPrefix(getOriginalCarrierPrefix());

		// insert into tbl_tn_poring_info
		tnPortingDbBean.insertSpecific(dbCon);
		setStatus(InvErrorCode.SUCCESS);
		return true;
	}

	/**
	 * Deletes the porting record for the pool id
	 * 
	 * @return
	 */
	public boolean deleteTnPorting() {
		try {
			if (getTnPoolId() <= 0) {
				setStatus(InvErrorCode.INVALID_INPUT);
				return false;
			}
			log.info("In delete Tn Pool Id from tbl_tn_porting_info");

			DBTblTnPortingInfo TnPortingDbBean = new DBTblTnPortingInfo();
			TnPortingDbBean.whereTnPoolIdEQ(getTnPoolId());
			int tnPoolIdDeleted = TnPortingDbBean.deleteByWhere(dbCon);
			log.info("Tn pool id " + getTnPoolId()
					+ "is successfully deleted from tbl_tn_porting_info : ");
		} catch (SQLException s) {
			s.printStackTrace();
			setStatus(InvErrorCode.DB_EXCEPTION);
			log.info("DB_FAILURE in deleteTnPorting");
			return false;
		}
		setStatus(InvErrorCode.SUCCESS);
		return true;
	}

	/**
	 * gets the Porting info details using tn pool id
	 * 
	 * @return
	 */
	public boolean getTnPortingByTnPoolId() {
		try {

			TblTnPortingInfoQuery tnPortingQry = new TblTnPortingInfoQuery();

			tnPortingQry.whereTnPoolIdEQ(getTnPoolId());
			tnPortingQry.query(dbCon);
			if (tnPortingQry.size() <= 0) {
				log.info("INV_FAILURE in getTnPortingByTnPoolId TnPorting. No Record found for given Tn Pool Id : "
						+ getTnPoolId());
				return false;
			} else {
				populateResult(tnPortingQry);
			}
		} catch (SQLException e) {
			e.printStackTrace();
			setStatus(InvErrorCode.DB_EXCEPTION);
			return false;
		} catch (Exception e) {
			e.printStackTrace();
			log.info("Exception while getting an Tn porting info by tn pool id.");
			return false;
		}
		setStatus(InvErrorCode.SUCCESS);
		return true;
	}

	/**
	 * assigns the values from Db to the bean
	 * 
	 * @param tnPortingQry
	 */
	private void populateResult(TblTnPortingInfoQuery tnPortingQry) {
		TblTnPortingInfoDbBean tnPortingInfoDbBean = tnPortingQry.getDbBean(0);

		setTnPoolId(tnPortingInfoDbBean.getTnPoolId());
		setPortingInd(tnPortingInfoDbBean.getPortingInd());
		setSubStatus(tnPortingInfoDbBean.getSubStatus());
		setGatewayNumber(tnPortingInfoDbBean.getGatewayNumber());
		setLosingCarrierPrefix(tnPortingInfoDbBean.getLosingCarrierPrefix());
		setGainingCarrierPrefix(tnPortingInfoDbBean.getGainingCarrierPrefix());
		setOriginalCarrierPrefix(tnPortingInfoDbBean.getOriginalCarrierPrefix());

	}

	/**
	 * Updates the required changes
	 * 
	 * @return
	 */
	public boolean updateTnPorting() {
		try {
			int nCount = 0;
			if (getTnPoolId() <= 0) {
				setStatus(InvErrorCode.INVALID_INPUT);
				log.info("FAILURE in updateTnPorting . invalid TnPoolId.");
				return false;
			}

			DBTblTnPortingInfo tnPortingDbBean = getTnPortingInfoToUpdate();
			tnPortingDbBean.whereTnPoolIdEQ(getTnPoolId());
			nCount = tnPortingDbBean.updateSpByWhere(dbCon);
			if (nCount == 0) {
				try {
					addTnPorting();
					log.info("Record inserted successfully in tbl_tn_porting_info.");
				} catch (Exception e) {
					e.printStackTrace();
					setStatus(InvErrorCode.DB_EXCEPTION);
					return false;
				}
			} else if (nCount < 0) {
				log.info("FAILURE in updateTnPorting. Db exception");
				return false;
			}

		} catch (SQLException s) {
			s.printStackTrace();
			setStatus(InvErrorCode.DB_EXCEPTION);
			log.info("DB_FAILURE in updateTnPorting");
			return false;
		}
		setStatus(InvErrorCode.SUCCESS);
		return true;
	}

	/**
	 * gets the updated value and assign it to the bean to be saved
	 * 
	 * @return
	 * @throws SQLException
	 */
	private DBTblTnPortingInfo getTnPortingInfoToUpdate() throws SQLException {

		DBTblTnPortingInfo tnPortingInfoDbBean = new DBTblTnPortingInfo();
		TnPortingBean defaultTnPortingBean = new TnPortingBean();

		TnPortingBean inputTnPortingBean = this;

		/* Set the new fields if required. */

		tnPortingInfoDbBean.setTnPoolId(getTnPoolId());

		if (!inputTnPortingBean.getPortingInd().equals(
				defaultTnPortingBean.getPortingInd())) {
			tnPortingInfoDbBean.setPortingInd(inputTnPortingBean
					.getPortingInd());
		}
		if (!inputTnPortingBean.getSubStatus().equals(
				defaultTnPortingBean.getSubStatus())) {
			tnPortingInfoDbBean.setSubStatus(inputTnPortingBean.getSubStatus());
		}
		if (!inputTnPortingBean.getGatewayNumber().equals(
				defaultTnPortingBean.getGatewayNumber())) {
			tnPortingInfoDbBean.setGatewayNumber(inputTnPortingBean
					.getGatewayNumber());
		}
		if (!inputTnPortingBean.getLosingCarrierPrefix().equals(
				defaultTnPortingBean.getLosingCarrierPrefix())) {
			tnPortingInfoDbBean.setLosingCarrierPrefix(inputTnPortingBean
					.getLosingCarrierPrefix());
		}
		if (!inputTnPortingBean.getGainingCarrierPrefix().equals(
				defaultTnPortingBean.getGainingCarrierPrefix())) {
			tnPortingInfoDbBean.setGainingCarrierPrefix(inputTnPortingBean
					.getGainingCarrierPrefix());
		}
		if (!inputTnPortingBean.getOriginalCarrierPrefix().equals(
				defaultTnPortingBean.getOriginalCarrierPrefix())) {
			tnPortingInfoDbBean.setOriginalCarrierPrefix(inputTnPortingBean
					.getOriginalCarrierPrefix());
		}

		return tnPortingInfoDbBean;
	}

	/**
	 * gets the info from the Db and updates the bean
	 * 
	 * @return
	 * @throws SQLException
	 */
	public boolean getDetails() throws SQLException {
		try {
			log.info("In TnPorting getDetails for Tn pool id : "
					+ getTnPoolId());

			TblTnPortingInfoQuery tnPortingInfoQry = new TblTnPortingInfoQuery();
			String whereClause = " where tn_pool_id = " + getTnPoolId();
			tnPortingInfoQry.queryByWhere(dbCon, whereClause);

			if (tnPortingInfoQry.size() > 0) {

				setTnPoolId((tnPortingInfoQry.getDbBean(0)).getTnPoolId());
				setPortingInd((tnPortingInfoQry.getDbBean(0)).getPortingInd());
				setSubStatus((tnPortingInfoQry.getDbBean(0)).getSubStatus());
				setGatewayNumber((tnPortingInfoQry.getDbBean(0))
						.getGatewayNumber());
				setLosingCarrierPrefix((tnPortingInfoQry.getDbBean(0))
						.getLosingCarrierPrefix());
				setGainingCarrierPrefix((tnPortingInfoQry.getDbBean(0))
						.getGainingCarrierPrefix());
				setOriginalCarrierPrefix((tnPortingInfoQry.getDbBean(0))
						.getOriginalCarrierPrefix());

			} else {
				log.info("No record found for Tn pool id : " + getTnPoolId());
				return false;
			}
		} catch (SQLException s) {
			s.printStackTrace();
			setStatus(InvErrorCode.DB_EXCEPTION);
			return false;
		}
		setStatus(InvErrorCode.SUCCESS);
		return true;
	}
}
