package com.vz.fxo.inventory.enterprise.support;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import EsapEnumPkg.VzbVoipEnum;
import esap.db.DBTblGroup;
import esap.db.DBTblGroupExcldFeatures;
import esap.db.DBTblGroupFeatures;
import esap.db.DBTblVzbFeatures;
import esap.db.TblDeviceMapQuery;
import esap.db.TblGroupExcldFeaturesQuery;
import esap.db.TblGroupFeaturesQuery;
import esap.db.TblGroupQuery;
import esap.db.TblGroupTnQuery;
import esap.db.TblLocPackageQuery;
import esap.db.TblLocationQuery;
import esap.db.TblPackageQuery;
import esap.db.TblPublicTnPoolQuery;
import esap.db.TblVzbFeaturesQuery;
import com.vz.fxo.inventory.enterprise.query.Criteria.ColumnName;
import com.vz.fxo.inventory.enterprise.query.Criteria.SortBy;

public class PBXGroup extends PBXGroupBean{

	private static Logger log = LoggerFactory.getLogger(PBXGroup.class.toString());
	
	String statusCode;
        String statusDesc;
         Connection dbCon;
        public static String oldPilotTn="";
        public static String oldExtension="";
	boolean rollbackFlag;
        InvErrorCode status = InvErrorCode.INTERNAL_ERROR;
        
        public PBXGroup(Connection dbCon)
        {
                this.dbCon = dbCon;
		this.rollbackFlag = false;
        }

        public PBXGroup(PBXGroupBean pbxBean, Connection dbCon)
        {
                super(pbxBean);
                this.dbCon = dbCon;
		this.rollbackFlag = false;
        }
	public boolean getRollbackFlag()
        {
            return rollbackFlag;
        }
        public void setRollbackFlag(boolean rollbackFlag)
        {
            this.rollbackFlag = rollbackFlag;
        }


    	public int getStatusCode()
        {
            return status.getErrorCode();
        }
        public void setStatus(InvErrorCode status)
        {
            this.status = status;
        }
        public String getStatusDesc()
        {
            return status.getErrorDesc();
        }
        public Connection getDbCon() {
                return dbCon;
        }
        public void setDbCon(Connection dbCon) {
                this.dbCon = dbCon;
        }

	//methods
        public boolean addToDB() throws Exception
        {
                try
                {
			DBTblGroup grpDB = new DBTblGroup();
			if(getGroupId() > 0 )
				grpDB.setGroupId(getGroupId());
			else
			{
				int grpId = grpDB.getGroupIdSeqNextVal(dbCon);
				grpDB.setGroupId(grpId);
				setGroupId(grpId);
			}
				log.info("group Id before inserting grp: "+getGroupId());
			grpDB.setLocationId(getLocationId()); 
			if(getLinePortLength() != -1)
				grpDB.setLinePortLength(getLinePortLength());
		
			if(getInvitationTimer() != -1 ){
				grpDB.setInvitationTimer(getInvitationTimer());
			}
			
			if(getPqInstanceId() != -1 ){
				grpDB.setPqInstanceId(getPqInstanceId());
			}

			if(departmentId != null && !getDepartmentId().equals("NONE") && !"".equals(getDepartmentId()))
				grpDB.setDepartmentId(getDepartmentId()); 
			else
				grpDB.setDepartmentIdNull(); 
			if(getGroupName() != null && !getGroupName().equals("NONE") && !"".equals(getGroupName()))
			grpDB.setGroupName(getGroupName()); 
			grpDB.setGroupType(VzbVoipEnum.TrunkGroupType.PBX); 
			grpDB.setPackageId(getPackageId()); 
			if(getPackageStr() != null)
                    	{
                        	log.info("In getPackageStr"+getPackageStr());
				String whereLocClause =  " where location_id = \'"+locationId+"\'";
                                TblLocPackageQuery locPkgQry = new TblLocPackageQuery();
                                locPkgQry.queryByWhere(dbCon, whereLocClause);
				log.info("in icp, locpkgQry.size:"+locPkgQry.size());
                                for(int k = 0; k < locPkgQry.size();k++)
                                {
                                        TblPackageQuery pkgQry = new TblPackageQuery();
                                        pkgQry.wherePackageIdEQ((locPkgQry.getDbBean(k)).getPackageId());
                                        pkgQry.query(dbCon);
                                        log.info("pkgQry size:"+pkgQry.size());
                                        if(pkgQry.size() == 1)
                                                log.info("pkg name in the db"+(pkgQry.getDbBean(0)).getPackageName());
                                        if(pkgQry.size() == 1 && ((pkgQry.getDbBean(0)).getPackageName()).equals(getPackageStr()))
                                        {
                                                log.info("icp pkg id"+
(pkgQry.getDbBean(0)).getPackageId());
                                                grpDB.setPackageId((pkgQry.getDbBean(0)).getPackageId());
						setLogTrail("Feature Package added to Group:"+getPackageStr());
                                        }

			 	}
                                        log.info("after k for loop" );

                   	}
                        else
			{
                        	log.info("featurepkgstr is null!!!!");
				setLogTrail("Feature Package is null");
			}

			grpDB.setDeviceMapId(getDeviceMapId()); 
			log.info("getGatewayDeviceId():"+getGatewayDeviceId());	
			if(getGatewayDeviceId() > 0)
			{
				TblDeviceMapQuery devQry = new TblDeviceMapQuery();
				devQry.whereGatewayDeviceIdEQ(getGatewayDeviceId());
				devQry.query(dbCon);
				if(devQry.size() > 0)
				{
					log.info("deviceMapid:"+(devQry.getDbBean(0)).getDeviceMapId());
					grpDB.setDeviceMapId((devQry.getDbBean(0)).getDeviceMapId());
					setLogTrail("Feature Package is null");
				}
				else{
					log.info("Unable to add Trunk Group. Device is incorrect/invalid.");
					setLogTrail("Unable to add Trunk Group. Device is incorrect/invalid.");
				}
			}
			if(getCidFirstName() != null && !getCidFirstName().equals("NONE") && !"".equals(getCidFirstName()))
			grpDB.setCidFirstName(getCidFirstName()); 
			if(getCidLastName() != null && !getCidLastName().equals("NONE") && !"".equals(getCidLastName()))
			grpDB.setCidLastName(getCidLastName()); 
        		if(getPbxCidTn().equals(""))
          			log.info("PbxCidTn is still set to default value");

			if(!getPbxCidTn().equals("NONE") && !getPbxCidTn().equals(""))
			{
				PublicTnPool pubTnObj = new PublicTnPool(dbCon);
                		pubTnObj.setLocationId(getLocationId());
						if(departmentId != null && !getDepartmentId().equals("NONE") && !"".equals(getDepartmentId()))
                			pubTnObj.setDepartmentId(getDepartmentId());
            			else
                			pubTnObj.setDepartmentId("");

                		pubTnObj.setTn(getPbxCidTn());
                		pubTnObj.setTnStatus(VzbVoipEnum.TnStatus.ASSIGNED);
                		pubTnObj.setTnType(VzbVoipEnum.TnType.PBX);
                		pubTnObj.setEnvOrderId(getEnvOrderId());
                		pubTnObj.setTnType(VzbVoipEnum.TnType.PBX_PILOT_TN); 

                		pubTnObj.setPortedStatus("" + VzbVoipEnum.PortStatus.NATIVE);
		                if(getCreatedBy() != null  && !getCreatedBy().equals(""))
	                        	pubTnObj.setCreatedBy(getCreatedBy());
		                else
		       	                pubTnObj.setCreatedBy("ESAP_INV");

		                if(getModifiedBy() != null  && !getModifiedBy().equals(""))
		                        pubTnObj.setModifiedBy(getModifiedBy());
		                else
		                        pubTnObj.setModifiedBy("ESAP_INV");


                		if(!pubTnObj.addPublicTnPool())
                		{
                        		log.info("Failed to Add Tn to Public Tn Pool");
                        		return false;
                		}
                		log.info("Successfully inserted Public TN Pool");
				grpDB.setPbxCidPoolId(pubTnObj.getTnPoolId());
				grpDB.setPbxPilotPoolId(pubTnObj.getTnPoolId()); 
			}
			if(getExtension() != null && !getExtension().equals("NONE") && !"".equals(getExtension()))
			grpDB.setExtension(getExtension()); 
			if(getPrivateNumber() != null && !getPrivateNumber().equals("NONE") && !"".equals(getPrivateNumber()))
			grpDB.setPrivateNumber(getPrivateNumber()); 
			grpDB.setPbxMaxCclLimit(getPbxMaxCclLimit()); 
			if(getLinePort() != null && !getLinePort().equals("NONE") && !"".equals(getLinePort()))
			grpDB.setLinePort(getLinePort());
			
			//IR1421386 Null pointer Exception.
			// Fix - Checking null for getPbxRedirectTn and setting the value.
			if (getPbxRedirectTn() != null && !getPbxRedirectTn().equals("NONE") ){
				grpDB.setPbxRedirectTn(getPbxRedirectTn());
			}else{
				grpDB.setPbxRedirectTnNull(); 
			}
			
			if(getPbxRedirectTrunkId() <= 0)
				grpDB.setPbxRedirectTrunkIdNull(); 
			else
				grpDB.setPbxRedirectTrunkId(getPbxRedirectTrunkId()); 
			grpDB.setActiveInd(getActiveInd()); 
                        if(getEnvOrderId() >0 )
				grpDB.setEnvOrderId(getEnvOrderId()); 
			else
				grpDB.setEnvOrderIdNull(); 
                        if(getCreatedBy() != null  && !getCreatedBy().equals("") )
                                grpDB.setCreatedBy(getCreatedBy());
                        else
                                grpDB.setCreatedBy("ESAP_INV");

                        if(getModifiedBy() != null  && !getModifiedBy().equals(""))
                                grpDB.setModifiedBy(getModifiedBy());
                        else
                                grpDB.setModifiedBy("ESAP_INV");

			grpDB.setLastModifiedDate(new Timestamp(System.currentTimeMillis())); 
			grpDB.setCreationDate(new Timestamp(System.currentTimeMillis())); 
			FkValidationUtil.isValidGroup(dbCon,grpDB);
			grpDB.insert(dbCon);
			 for (int k = 0; k < excludedFeaturesList.size(); k++)
                        {
                                TblVzbFeaturesQuery vzbFeatQry = new TblVzbFeaturesQuery();
                                vzbFeatQry.whereNameEQ(((excludedFeaturesList.get(k)).getFeaturesDbBean()).getName());
                                vzbFeatQry.whereFeatureTypeNE("C");
                                vzbFeatQry.query(dbCon);
                                if(vzbFeatQry.size() == 1)
                                {
                                        DBTblGroupExcldFeatures  grpExcldFeat = new DBTblGroupExcldFeatures();
					grpExcldFeat.getGroupFeatureIdSeqNextVal(dbCon);
					log.info("group Id before inserting ecld feature: "+getGroupId());
                                        grpExcldFeat.setGroupId(getGroupId());
                                        grpExcldFeat.setFeatureId((vzbFeatQry.getDbBean(0)).getFeatureId());
					 if(getCreatedBy() != null  && !getCreatedBy().equals(""))
                                		grpExcldFeat.setCreatedBy(getCreatedBy());
                        		 else
                                		grpExcldFeat.setCreatedBy("ESAP_INV");

                        		if(getModifiedBy() != null  && !getModifiedBy().equals(""))
                                		grpExcldFeat.setModifiedBy(getModifiedBy());
                        		else
                                		grpExcldFeat.setModifiedBy("ESAP_INV");

                        		grpExcldFeat.setLastModifiedDate(new Timestamp(System.currentTimeMillis()));
                        		grpExcldFeat.setCreationDate(new Timestamp(System.currentTimeMillis()));
					grpExcldFeat.insert(dbCon);

                                }
                                else
                                {
                                        log.info("Valid Excluded feature not found in the db"+((excludedFeaturesList.get(k)).getFeaturesDbBean()).getName());
                                        return false;
                                }
                        }
			for (int k = 0; k < groupFeaturesList.size(); k++)
                        {
                                TblVzbFeaturesQuery vzbFeatQry = new TblVzbFeaturesQuery();
                                vzbFeatQry.whereNameEQ(((groupFeaturesList.get(k)).getFeaturesDbBean()).getName());
                                vzbFeatQry.whereFeatureTypeNE("C");
                                vzbFeatQry.query(dbCon);
                                if(vzbFeatQry.size() == 1)
                                {
                                        DBTblGroupFeatures  grpFeat = new DBTblGroupFeatures();
                                        grpFeat.getGroupFeatureIdSeqNextVal(dbCon);
                                        log.info("group Id before inserting feature: "+getGroupId());
                                        grpFeat.setGroupId(getGroupId());
                                       if(getEnvOrderId() > 0)
                                        	grpFeat.setEnvOrderId(getEnvOrderId());    
					else
                                        	grpFeat.setEnvOrderIdNull();    
                                        grpFeat.setFeatureId((vzbFeatQry.getDbBean(0)).getFeatureId());
                                         if(getCreatedBy() != null  && !getCreatedBy().equals(""))
                                                grpFeat.setCreatedBy(getCreatedBy());
                                         else
                                                grpFeat.setCreatedBy("ESAP_INV");

                                        if(getModifiedBy() != null  && !getModifiedBy().equals(""))
                                                grpFeat.setModifiedBy(getModifiedBy());
                                        else
                                                grpFeat.setModifiedBy("ESAP_INV");

                                        grpFeat.setLastModifiedDate(new Timestamp(System.currentTimeMillis()));
                                        grpFeat.setCreationDate(new Timestamp(System.currentTimeMillis()));
                                        grpFeat.insert(dbCon);

                                }
                                else
                                {
                                        log.info("Valid Group feature not found in the db"+((groupFeaturesList.get(k)).getFeaturesDbBean()).getName());
                                        return false;
                                }
                        }

 		}
                catch(SQLException s)
                {
               		s.printStackTrace(); 
			        setStatus(InvErrorCode.DB_EXCEPTION);
                   	setLogTrail("DB Exception: "+ s.getMessage());
                    log.info("DB_FAILURE in addToDB PBXGroup" + s.getMessage());
                        return false;
                }
                setStatus(InvErrorCode.SUCCESS);
                //setStatusDesc("Successfully inserted PBXGroup into the DB");
                return true;
        }

	public boolean deleteFromDB() throws SQLException, Exception{ 
                //try
                //{
                	log.info("deleteFromDB :: groupId = " + groupId);
                        if ( groupId <=0 ) {
                                setStatus(InvErrorCode.INVALID_INPUT);
                                log.info("FAILURE in deleteFromDB PBXGroup. groupId missing.");
                                return false;
                        }
                        /* Remove the child records of Group */
                        deleteGroupTnForGroup();
                        deleteExcludedFeaturesForGroup();
                        deleteGroupFeaturesForGroup();
                        deletePilotTns();
                        DBTblGroup pbxGroupDbBean = new DBTblGroup();
                        pbxGroupDbBean.whereGroupIdEQ(getGroupId());
                       	pbxGroupDbBean.deleteByWhere(dbCon);
                        log.info("deleteFromDB :: deleted groupId = " + groupId);

                /*} catch(SQLException s) {
               		s.printStackTrace(); 
                        setStatus(InvErrorCode.DB_EXCEPTION);
                        log.info("DB_FAILURE in deleteFromDB PBXGroup");
                        return false;
                }*/
                setStatus(InvErrorCode.SUCCESS);
                return true;
        }

		public void deletePilotTns() throws SQLException, Exception{
			TblGroupQuery grpTnQuery = new TblGroupQuery();
			grpTnQuery.whereGroupIdEQ(getGroupId());
            grpTnQuery.query(dbCon);
			
            for(int i = 0; i < grpTnQuery.size(); i++)
			{
            	setPbxCidPoolId(grpTnQuery.getDbBean(i).getPbxCidPoolId());
			}

			if(getPbxCidPoolId() <= 0)
			{
				log.info("PBX CID Pool Id not Found");
				return;
			}
			
			PublicTnPool publicTnPool = new PublicTnPool(dbCon);
            publicTnPool.setTnPoolId((int)getPbxCidPoolId());
            log.info("getPbxCidPoolId  value is === > " +getPbxCidPoolId());
            log.info("publicTnPool Group value is =====> " + publicTnPool);
            log.info("RollBack value is =====> " + rollbackFlag);
            
            PreparedStatement pstmt=null;
            try {
            	pstmt=dbCon.prepareStatement("UPDATE tbl_public_tn_pool set tn_status="+VzbVoipEnum.TnStatus.AVAILABLE+" where tn_pool_id="+getPbxCidPoolId());
            	pstmt.executeUpdate();
            } catch (Exception e) {
                throw new SQLException("deletePilotTns to database failed");
             } finally {
                   if(pstmt != null) {
                    pstmt.close();
                   }
             }
            
            if(rollbackFlag){
            	if(!publicTnPool.deletePublicTnPool()) {
            		//setErrstatus(InvErrorCode.ERROR_DELETING_PUBLIC_TN_POOL_FROM_PBX_GROUP_TN);
      				log.info("Error while deleting Public Tn Poll from PBXGroupTn.");
            		//return false;
            	}
            } else {
            	publicTnPool.setTnStatus(VzbVoipEnum.TnStatus.AVAILABLE);
            	publicTnPool.setActiveInd(VzbVoipEnum.ActiveInd.ACTIVE);
            	if(!publicTnPool.updatePublicTnPool()) {
            		//setErrstatus(InvErrorCode.ERROR_DELETING_PUBLIC_TN_POOL_FROM_PBX_GROUP_TN);
      				log.info("Error while deleting Public Tn Poll from PBXGroupTn.");
            		//return false;
            	}
            }
		}
		        public long deleteGroupTnForGroup() throws SQLException, Exception {
        	
        		log.info("deleteGroupTnForGroup ::");

                TblGroupTnQuery grpTnQuery = new TblGroupTnQuery();
				grpTnQuery.whereGroupIdEQ(getGroupId());
                grpTnQuery.query(dbCon);
				long rowSize = grpTnQuery.size();
                log.info("deleteGroupTnForGroup :: grpTnQuery size" + grpTnQuery.size());
				for(int i = 0; i < grpTnQuery.size(); i++)
				{
					PBXGroupTn pbxGroupTn = new PBXGroupTn(dbCon);
					pbxGroupTn.setGroupTnId(grpTnQuery.getDbBean(i).getGroupTnId());
					pbxGroupTn.setEnvOrderId(getEnvOrderId());
					pbxGroupTn.setModifiedBy(getModifiedBy());
					pbxGroupTn.deleteFromDB();
                	log.info("deleteGroupTnForGroup:: deleted PBXGroupTn with groupTnId:"+pbxGroupTn.getGroupTnId());
				}

				// Recursive call to make sure we are not picking up only 
				// DB generated max rows!!
				if(rowSize != 0) {
					log.info("Calling deleteGroupTnForGroup() recursively to make sure there is no rec left in db.");
					deleteGroupTnForGroup();
				}

				return rowSize;
        }
		/*
        public void deleteGroupTnForGroup() throws SQLException, Exception {
        	
        		log.info("deleteGroupTnForGroup ::");

                TblGroupTnQuery grpTnQuery = new TblGroupTnQuery();
				grpTnQuery.whereGroupIdEQ(getGroupId());
                grpTnQuery.query(dbCon);
                log.info("deleteGroupTnForGroup :: grpTnQuery size" + grpTnQuery.size());
				for(int i = 0; i < grpTnQuery.size(); i++)
				{
					PBXGroupTn pbxGroupTn = new PBXGroupTn(dbCon);
					pbxGroupTn.setGroupTnId(grpTnQuery.getDbBean(i).getGroupTnId());
					pbxGroupTn.deleteFromDB();
                	log.info("deleteGroupTnForGroup:: deleted PBXGroupTn with groupTnId:"+pbxGroupTn.getGroupTnId());
				}

                        
        }
		*/

        public void deleteExcludedFeaturesForGroup() throws SQLException {
        	log.info("deleteExcludedFeaturesForGroup ::");

                TblGroupExcldFeaturesQuery excFeaturesQuery = new TblGroupExcldFeaturesQuery();
                String whereClause =  " where group_id = "+getGroupId();
                excFeaturesQuery.queryByWhere(dbCon, whereClause);

                log.info("deleteExcludedFeaturesForGroup:: Queried ExcludedFeaturesForGroup");
                        DBTblGroupExcldFeatures excFeaturesDbBean = new DBTblGroupExcldFeatures();
                        excFeaturesDbBean.whereGroupIdEQ(getGroupId());
                        excFeaturesDbBean.deleteByWhere(dbCon);
                        
                log.info("deleteExcludedFeaturesForGroup:: deleted ExcludedFeaturesForGroup");
        }
		 public void deleteGroupFeaturesForGroup() throws SQLException {
            log.info("deletegroupFeaturesForGroup ::");

                        DBTblGroupFeatures grpFeaturesDbBean = new DBTblGroupFeatures();
                        grpFeaturesDbBean.whereGroupIdEQ(getGroupId());
                        grpFeaturesDbBean.deleteByWhere(dbCon);

                log.info("deleteGrpFeaturesForGroup:: deleted GroupFeaturesForGroup");
        }


        public void deletePublicTnPoolForGroupTn(TblGroupTnQuery grpTnQuery) throws SQLException, Exception {

                PublicTnPool publicTnPool = new PublicTnPool(dbCon);
                        for(int i=0; i<grpTnQuery.size(); i++){
                                publicTnPool.setTnPoolId((int)grpTnQuery.getDbBean(i).getTnPoolId());
				if(rollbackFlag)
                                	publicTnPool.deletePublicTnPool();
				else
				{
					publicTnPool.setTnStatus(VzbVoipEnum.TnStatus.AVAILABLE);
					publicTnPool.updatePublicTnPool();
				}
                        }
        }



        public boolean modifyInDB() throws SQLException, Exception{
                //try{
                        if ( getGroupId() <= 0) {
                                setStatus(InvErrorCode.INVALID_INPUT);
                                log.info("FAILURE in modifyInDB PBXGroup. GroupId missing.");
                                return false;
                        }
                        DBTblGroup groupBean = getPBXGroupToUpdate();
			groupBean.whereGroupIdEQ(getGroupId());
						FkValidationUtil.isValidGroupForMod(dbCon,groupBean);
                        if(groupBean.updateSpByWhere(dbCon) <= 0)
						{
                			setStatus(InvErrorCode.SUCCESS);
                        	log.info("Nothing to modify for PBX.");
                        	return true;   
						}

              /*} catch(SQLException s) {
               		s.printStackTrace(); 
                	setStatus(InvErrorCode.DB_EXCEPTION);
                        log.info("DB_FAILURE in modifyInDB PBXGroup.");
                        return false;
                }*/
                setStatus(InvErrorCode.SUCCESS);
                return true;
        }

       /**
         * The current PBX Group details are extracted using getDetails()
         * and the new field values are updated over that. The method
         * will update the fields that are supplied on the current instance
         * if they are different from the default values for the respective field.
         *
         * @return The Group to be updated.
         */
        @SuppressWarnings("unused")
        private DBTblGroup getPBXGroupToUpdate()  throws SQLException, Exception{
                DBTblGroup pbxGroupDbBean = new DBTblGroup();

                /* Create a new instance of PBXGroupBean. The new instance
                 * would hold default values for the all the PBXGroup fields.*/
                PBXGroupBean defaultPBXGroupBean = new PBXGroupBean();


                PBXGroup inputPBXGroup = this;

                if ( inputPBXGroup.getLocationId() != null &&
                                !inputPBXGroup.getLocationId().equals(defaultPBXGroupBean.getLocationId()) ){
                        pbxGroupDbBean.setLocationId(inputPBXGroup.getLocationId());
                }

                if ( inputPBXGroup.getDepartmentId() != null &&
                                !inputPBXGroup.getDepartmentId().equals(defaultPBXGroupBean.getDepartmentId()) ){
                        pbxGroupDbBean.setDepartmentId(inputPBXGroup.getDepartmentId());
                }
                if ( inputPBXGroup.getGroupName() != null &&
                                !inputPBXGroup.getGroupName().equals(defaultPBXGroupBean.getGroupName()) ){
                        pbxGroupDbBean.setGroupName(inputPBXGroup.getGroupName());
                }

                
                if (inputPBXGroup.getPackageId() != defaultPBXGroupBean.getPackageId())
                {	
                	log.info("In getPBXGroupToUpdate :: Overiding Feature Package ID " + inputPBXGroup.getPackageId());
                	pbxGroupDbBean.setPackageId(inputPBXGroup.getPackageId());
                }	
                else if(inputPBXGroup.getPackageStr() != null)
                {
                	long packageId = getPackageIdByPackageStr(inputPBXGroup.getPackageStr());
                	if(packageId > 0)
                	{
                		log.info("In getPBXGroupToUpdate :: Overiding Feature Package ID 2" + packageId);
                		pbxGroupDbBean.setPackageId(packageId);
                	}	
                }

                if ( inputPBXGroup.getDeviceMapId() != defaultPBXGroupBean.getDeviceMapId()) {
                        pbxGroupDbBean.setDeviceMapId(inputPBXGroup.getDeviceMapId());
                        log.info("Overriding ::  Device ID " + inputPBXGroup.getDeviceMapId());
                }
				if ( inputPBXGroup.getGatewayDeviceId() != defaultPBXGroupBean.getGatewayDeviceId()) {
					log.info("inputPBXGroup.getGatewayDeviceId():"+inputPBXGroup.getGatewayDeviceId());
                	TblDeviceMapQuery devQry = new TblDeviceMapQuery();
                	devQry.whereGatewayDeviceIdEQ(inputPBXGroup.getGatewayDeviceId());
                	devQry.query(dbCon);
                	if(devQry.size() > 0)
                	{
                    	log.info("deviceMapid:"+(devQry.getDbBean(0)).getDeviceMapId());
                    	pbxGroupDbBean.setDeviceMapId((devQry.getDbBean(0)).getDeviceMapId());
                    	setLogTrail("Device Map being updated"+(devQry.getDbBean(0)).getDeviceMapId());
                	}
                	else
                    	log.info("Couldn't find any deviceMap for the given gatewaydeviceId"+inputPBXGroup.getGatewayDeviceId());
				}

                if ( inputPBXGroup.getCidFirstName() != null &&
                                !inputPBXGroup.getCidFirstName().equals(defaultPBXGroupBean.getCidFirstName()) ){
                        pbxGroupDbBean.setCidFirstName(inputPBXGroup.getCidFirstName());
                }
                if ( inputPBXGroup.getCidLastName() != null &&
                                !inputPBXGroup.getCidLastName().equals(defaultPBXGroupBean.getCidLastName()) ){
                        pbxGroupDbBean.setCidLastName(inputPBXGroup.getCidLastName());
                }
                
                log.info("Old Extension value is ==== > " +oldExtension);
                
                if ( (inputPBXGroup.getExtension() != null &&
                                !inputPBXGroup.getExtension().equals(defaultPBXGroupBean.getExtension()))
                                || ("NULL".equals(oldExtension))){
                        pbxGroupDbBean.setExtension(inputPBXGroup.getExtension());
                }

                if ( inputPBXGroup.getPrivateNumber() != null &&
                                !inputPBXGroup.getPrivateNumber().equals(defaultPBXGroupBean.getPrivateNumber()) ){
                        pbxGroupDbBean.setPrivateNumber(inputPBXGroup.getPrivateNumber());
                }

                if ( inputPBXGroup.getLinePort() != null &&
                                !inputPBXGroup.getLinePort().equals(defaultPBXGroupBean.getLinePort()) ){
                        pbxGroupDbBean.setLinePort(inputPBXGroup.getLinePort());
                }
                if ( inputPBXGroup.getActiveInd() != defaultPBXGroupBean.getActiveInd()) {
                        pbxGroupDbBean.setActiveInd(inputPBXGroup.getActiveInd());
                }

                if ( inputPBXGroup.getPbxRedirectTn() != null && 
                          !inputPBXGroup.getPbxRedirectTn().equals(defaultPBXGroupBean.getPbxRedirectTn()) ){ 
                        pbxGroupDbBean.setPbxRedirectTn(inputPBXGroup.getPbxRedirectTn());
                }

                if ( inputPBXGroup.getPbxRedirectTrunkId() != defaultPBXGroupBean.getPbxRedirectTrunkId()) {
						if(inputPBXGroup.getPbxRedirectTrunkId() <= 0)
                        	pbxGroupDbBean.setPbxRedirectTrunkIdNull();
						else
                        	pbxGroupDbBean.setPbxRedirectTrunkId(inputPBXGroup.getPbxRedirectTrunkId());
                }
                
                if ( inputPBXGroup.getLinePortLength() != defaultPBXGroupBean.getLinePortLength()) {
					if(inputPBXGroup.getLinePortLength() <= 0)
                    	pbxGroupDbBean.setLinePortLengthNull();
					else
                    	pbxGroupDbBean.setLinePortLength(inputPBXGroup.getLinePortLength());
                }
               
				if ( inputPBXGroup.getInvitationTimer() != defaultPBXGroupBean.getInvitationTimer()) {
					if(inputPBXGroup.getInvitationTimer() <= 0)
                    	pbxGroupDbBean.setInvitationTimerNull();
					else
                    	pbxGroupDbBean.setInvitationTimer(inputPBXGroup.getInvitationTimer());
                }
				
				if ( inputPBXGroup.getPqInstanceId() != defaultPBXGroupBean.getPqInstanceId()) {
					if(inputPBXGroup.getPqInstanceId() <= 0)
                    	pbxGroupDbBean.setPqInstanceIdNull();
					else
                    	pbxGroupDbBean.setPqInstanceId(inputPBXGroup.getPqInstanceId());
                }
 
                if ( inputPBXGroup.getPbxMaxCclLimit() != defaultPBXGroupBean.getPbxMaxCclLimit()) {
                        pbxGroupDbBean.setPbxMaxCclLimit(inputPBXGroup.getPbxMaxCclLimit());
                }
                log.info("In getPBXGroupToUpdate :: Current Call" + pbxGroupDbBean.getPbxMaxCclLimit());
               if ( inputPBXGroup.getEnvOrderId() != defaultPBXGroupBean.getEnvOrderId()) {
                    pbxGroupDbBean.setEnvOrderId(inputPBXGroup.getEnvOrderId());
            }
	        if(inputPBXGroup.getModifiedBy() != null &&
					!( "".equalsIgnoreCase(inputPBXGroup.getModifiedBy()) ) )
			pbxGroupDbBean.setModifiedBy(inputPBXGroup.getModifiedBy());
		else
			pbxGroupDbBean.setModifiedBy("ESAP_INV");

                pbxGroupDbBean.setLastModifiedDate(new Timestamp(System.currentTimeMillis()));
			if( inputPBXGroup.getPbxCidTn() != defaultPBXGroupBean.getPbxCidTn() )
			{
                PreparedStatement pstmt=null;
                ResultSet rs=null;
                try{
            	oldPilotTn="";
                String sqlQuery="select pool.tn from tbl_group grp,tbl_public_tn_pool pool where pool.tn_pool_id= grp.pbx_cid_pool_id "+
                                " and grp.group_id= "+inputPBXGroup.getGroupId();
                
                log.info("SQL value is === "+sqlQuery);
                pstmt=dbCon.prepareStatement(sqlQuery);
                rs=pstmt.executeQuery();
                while(rs.next()){
                	oldPilotTn=String.valueOf(rs.getLong(1));
                }
                modifyCurrentTn(inputPBXGroup.getGroupId());  
                
                
                log.info("Old Pilot Tn is ===> "+oldPilotTn);
                if(oldPilotTn!=null && oldPilotTn.trim().length() >0 && inputPBXGroup.getPbxCidTn() != null && !inputPBXGroup.getPbxCidTn().trim().equals("NONE")){
                releasePrevoiusTn(oldPilotTn);
                }
                }catch(Exception e){
                	e.printStackTrace();
                	log.info("Exception si ===> "+ e.getMessage());
                	throw e;
                } finally {
                	if( rs != null) {
                		rs.close();
                	}
                	if(pstmt !=  null){
                		pstmt.close();
                	}
                }
			}
                return pbxGroupDbBean;

        }//ToUpdate
        
        public void modifyCurrentTn(int groupId) throws Exception { 	
			
			if(getPbxCidTn() != null && getPbxCidTn().trim().length() > 0 && !getPbxCidTn().trim().equals("NONE"))
			{
        	PublicTnPool pubTnObj = new PublicTnPool(dbCon);
    		pubTnObj.setLocationId(getLocationId());
			if(getDepartmentId() != null && !getDepartmentId().equals("NONE") && !"".equals(getDepartmentId()))
    			pubTnObj.setDepartmentId(getDepartmentId());
			else
    			pubTnObj.setDepartmentId("");
    		if(getPbxCidTn()!=null && !"".equals(getPbxCidTn().trim()) && !"NONE".equals(getPbxCidTn().trim())){
    		pubTnObj.setTn(getPbxCidTn());
    		}
    		
    		pubTnObj.setTnStatus(VzbVoipEnum.TnStatus.ASSIGNED);
    		pubTnObj.setTnType(VzbVoipEnum.TnType.PBX_PILOT_TN);
    		pubTnObj.setEnvOrderId(getEnvOrderId());
		
    		pubTnObj.setPortedStatus("" + VzbVoipEnum.PortStatus.NATIVE);
            if(getCreatedBy() != null  && !getCreatedBy().equals(""))
                	pubTnObj.setCreatedBy(getCreatedBy());
            else
   	                pubTnObj.setCreatedBy("ESAP_INV");

            if(getModifiedBy() != null  && !getModifiedBy().equals(""))
                    pubTnObj.setModifiedBy(getModifiedBy());
            else
                    pubTnObj.setModifiedBy("ESAP_INV");
            

    		if(!pubTnObj.addPublicTnPool())
    		{
            		log.info("Failed to Add Tn to Public Tn Pool");
    		}
			else
			{
        	log.info("End of TN Poool update====>" + pubTnObj.getTnPoolId());
        	
        	
        	PreparedStatement pstmt=null;
        	try{
        	String sql="update tbl_group set pbx_pilot_pool_id="+pubTnObj.getTnPoolId()+",pbx_cid_pool_id= "+pubTnObj.getTnPoolId() +" where group_id="+groupId;
        	log.info("SQL value is ====> " + sql);
        	pstmt=dbCon.prepareStatement(sql);
        	pstmt.execute();
        	}finally{
        		if(pstmt!=null)pstmt.close();
        	}
        	
			}
			}
	        else if (getPbxCidTn() == null || getPbxCidTn().trim().length()<= 0) 	
           {
			PreparedStatement pstmt=null;
			try{
			String sql="update tbl_group set pbx_pilot_pool_id = 0,pbx_cid_pool_id = 0 where group_id = "+groupId;
			log.info("SQL value is ====> " + sql);
			pstmt=dbCon.prepareStatement(sql);
			pstmt.execute();
			}finally{
        		if(pstmt!=null)pstmt.close();
        	}
	
		}

        	
        }
        
        public void releasePrevoiusTn(String tn) throws Exception { 	
        	log.info("releasePrevoiusTn ======== > "+tn);
        	//PublicTnPool pubTnObj = new PublicTnPool(dbCon);
        	//ResultSet rs=null;
        	PreparedStatement pstmt=null;
        	try{
        	String query="update tbl_public_tn_pool set tn_status="+VzbVoipEnum.TnStatus.AVAILABLE+" , tn_type = "+VzbVoipEnum.TnType.RES+" where tn='"+tn+"'";
        	log.info(" query for releasePrevoiusTn -> " + query);
        	pstmt=dbCon.prepareStatement(query);
        	pstmt.execute();
        	}catch(Exception e){
        		e.printStackTrace();
        		throw e;
        	}finally{
        		if(pstmt!=null)pstmt.close();
        	}
        	log.info("End of TN Poool update====>");
        }
        
        
        
        public boolean getDetails()
        {
	               try
                {
                        log.info("In PBXGroup getDetails; PBX GroupId="+getGroupId());
                        TblGroupQuery pbxGroupQuery = new TblGroupQuery();
                        String whereClause = new String("");
						if(getAll == false)
                        	whereClause = " where group_Id = "+getGroupId() + " and active_ind = 1";
						else
                        	whereClause = " where group_Id = "+getGroupId() + " and active_ind != 0";
                        pbxGroupQuery.queryByWhere(dbCon, whereClause);
						clearPBXGroup();
                        log.info("In PBXGroup getDetails; PBX Group size="+pbxGroupQuery.size());

                        if(pbxGroupQuery.size() == 1){
                                setLocationId((pbxGroupQuery.getDbBean(0)).getLocationId());
                                setDepartmentId((pbxGroupQuery.getDbBean(0)).getDepartmentId());
                                setGroupName((pbxGroupQuery.getDbBean(0)).getGroupName());
                                //setGroupType((pbxGroupQuery.getDbBean(0)).getGroupType());
                                //setPkgFeatureId((pbxGroupQuery.getDbBean(0)).getPkgFeatureId());
                                log.info("In getDetails :: Device ID Retreived" + (pbxGroupQuery.getDbBean(0)).getDeviceMapId());
                                setDeviceMapId((pbxGroupQuery.getDbBean(0)).getDeviceMapId());
                                setCidFirstName((pbxGroupQuery.getDbBean(0)).getCidFirstName());
                                setCidLastName((pbxGroupQuery.getDbBean(0)).getCidLastName());
                                setExtension((pbxGroupQuery.getDbBean(0)).getExtension());
                                setPrivateNumber((pbxGroupQuery.getDbBean(0)).getPrivateNumber());
                                setPackageId((pbxGroupQuery.getDbBean(0)).getPackageId());
                                setPbxCidPoolId((pbxGroupQuery.getDbBean(0)).getPbxCidPoolId());
                                  setLinePort((pbxGroupQuery.getDbBean(0)).getLinePort());
                                setActiveInd((pbxGroupQuery.getDbBean(0)).getActiveInd());
                                 setEnvOrderId(pbxGroupQuery.getDbBean(0).getEnvOrderId());  
                                setCreatedBy((pbxGroupQuery.getDbBean(0)).getCreatedBy());
                                setModifiedBy((pbxGroupQuery.getDbBean(0)).getModifiedBy());
                                setLastModifiedDate((pbxGroupQuery.getDbBean(0)).getLastModifiedDate());
                                setCreationDate((pbxGroupQuery.getDbBean(0)).getCreationDate());
                                setPbxMaxCclLimit((pbxGroupQuery.getDbBean(0)).getPbxMaxCclLimit());
                                setPbxRedirectTn((pbxGroupQuery.getDbBean(0)).getPbxRedirectTn());
                                setPbxRedirectTrunkId((pbxGroupQuery.getDbBean(0)).getPbxRedirectTrunkId());
                                setLinePortLength((pbxGroupQuery.getDbBean(0)).getLinePortLength());
								setInvitationTimer((pbxGroupQuery.getDbBean(0)).getInvitationTimer());
								setPqInstanceId((pbxGroupQuery.getDbBean(0)).getPqInstanceId());
								getGroupFeatureListByGroupId();
                        }
                        else
                        {
                        	setStatus(InvErrorCode.DB_EXCEPTION); 
                                return false;
                        }
                }catch(SQLException s){
               			s.printStackTrace(); 
                                setStatus(InvErrorCode.DB_EXCEPTION);
                   				setLogTrail("DB Exception: "+ s.getMessage());
                                return false;
                }
                        setStatus(InvErrorCode.SUCCESS);
                        return true;
	} //getDetails Ends

        public boolean validate(){return true;}
        public boolean getDetailsByGroupNameAndLocationId()
        {
		try
                {
			if(getGroupName() == null || getGroupName() == "" || getLocationId() == null || getLocationId() == null)
			{
				setStatus(InvErrorCode.INVALID_INPUT);
                        	//setStatusDesc("INV_FAILURE in getDetails PBX group. Invalid Input");
                        	return false;
			}
			TblGroupQuery grpQry = new TblGroupQuery();
			String whereClause = new String("");
			if(getAll == false)
				whereClause = " where group_name = /'" + getGroupName() + "/' and " + "location_id = /'" + getLocationId() +  "/' and " + "group_type = " + VzbVoipEnum.TrunkGroupType.PBX + " and active_ind = 1";
			else
				whereClause = " where group_name = /'" + getGroupName() + "/' and " + "location_id = /'" + getLocationId() +  "/' and " + "group_type = " + VzbVoipEnum.TrunkGroupType.PBX + " and active_ind != 0";
			log.info("whereClause:"+whereClause);
			grpQry.queryByWhere(dbCon, whereClause);
			if(grpQry.size() == 1)
			{
				setGroupId((grpQry.getDbBean(0)).getGroupId());
				setLocationId((grpQry.getDbBean(0)).getLocationId());
				setDepartmentId((grpQry.getDbBean(0)).getDepartmentId());
				setGroupName((grpQry.getDbBean(0)).getGroupName());
				setPackageId((grpQry.getDbBean(0)).getPackageId());
				setDeviceMapId((grpQry.getDbBean(0)).getDeviceMapId());
				setCidFirstName((grpQry.getDbBean(0)).getCidFirstName());
				setCidLastName((grpQry.getDbBean(0)).getCidLastName());
				setPbxCidPoolId((grpQry.getDbBean(0)).getPbxCidPoolId());
				TblPublicTnPoolQuery ptnPoolQry = new TblPublicTnPoolQuery();
				ptnPoolQry.whereTnPoolIdEQ((int)(grpQry.getDbBean(0)).getPbxCidPoolId());
                                ptnPoolQry.query(dbCon);
                                if(ptnPoolQry.size() > 0)
				{
					setPbxCidTn((ptnPoolQry.getDbBean(0)).getTn());
				}else{
					setPbxCidTn("");
				}
				setExtension((grpQry.getDbBean(0)).getExtension());
				setPrivateNumber((grpQry.getDbBean(0)).getPrivateNumber());
				setPbxMaxCclLimit((grpQry.getDbBean(0)).getPbxMaxCclLimit());
                                setPbxRedirectTn((grpQry.getDbBean(0)).getPbxRedirectTn());
                                setPbxRedirectTrunkId((grpQry.getDbBean(0)).getPbxRedirectTrunkId());
				setActiveInd((grpQry.getDbBean(0)).getActiveInd());
				setCreatedBy((grpQry.getDbBean(0)).getCreatedBy());
				setModifiedBy((grpQry.getDbBean(0)).getModifiedBy());
				setCreationDate((grpQry.getDbBean(0)).getCreationDate());
				setLastModifiedDate((grpQry.getDbBean(0)).getLastModifiedDate());
                                setEnvOrderId(grpQry.getDbBean(0).getEnvOrderId()); 	
              			setCreatedBy((grpQry.getDbBean(0)).getCreatedBy());
				setModifiedBy((grpQry.getDbBean(0)).getModifiedBy());
				setCreationDate((grpQry.getDbBean(0)).getCreationDate());
				setLastModifiedDate((grpQry.getDbBean(0)).getLastModifiedDate());
				 setLinePortLength((grpQry.getDbBean(0)).getLinePortLength());
				setInvitationTimer((grpQry.getDbBean(0)).getInvitationTimer());
				setPqInstanceId((grpQry.getDbBean(0)).getPqInstanceId());
				getGroupFeatureListByGroupId();
                        }
                }
                catch(SQLException s)
                {
               		s.printStackTrace(); 
                        setStatus(InvErrorCode.DB_EXCEPTION);
                   		setLogTrail("DB Exception: "+ s.getMessage());
                        //setStatusDesc("DB_FAILURE in getDetails PBX group");
                        return false;
                }
                setStatus(InvErrorCode.SUCCESS);
                //setStatusDesc("Successfully retrieved pbx group from db");
                return true;
        }
	
	public boolean getDetailsByGroupId()
        {
                try
                {
                        log.info("In PBXGroup:getDetailsByGroupId");
                        if(getGroupId() <= 0)
                        {
                                setStatus(InvErrorCode.INVALID_INPUT);
                                //setStatusDesc("INV_FAILURE in getDetails PBX group. Invalid Input");
                                return false;
                        }
                        TblGroupQuery grpQry = new TblGroupQuery();
                        grpQry.whereGroupIdEQ(getGroupId());
						if(getAll == false)
                        	grpQry.whereActiveIndEQ(1);
						else
                        	grpQry.whereActiveIndNE(0);
                        grpQry.query(dbCon);
                        if(grpQry.size() == 1)
                        {
                                setGroupId((grpQry.getDbBean(0)).getGroupId());
                                setLocationId((grpQry.getDbBean(0)).getLocationId());
                                setDepartmentId((grpQry.getDbBean(0)).getDepartmentId());
                                setGroupName((grpQry.getDbBean(0)).getGroupName());
                                setPackageId((grpQry.getDbBean(0)).getPackageId());
                                setDeviceMapId((grpQry.getDbBean(0)).getDeviceMapId());
                                TblDeviceMapQuery devMapQry = new TblDeviceMapQuery();
                                devMapQry.whereDeviceMapIdEQ((int)(grpQry.getDbBean(0)).getDeviceMapId());
				devMapQry.query(dbCon);
                                if(devMapQry.size() > 0)
                                {
                                        setGatewayDeviceId((devMapQry.getDbBean(0)).getGatewayDeviceId());
                                }
                                setCidFirstName((grpQry.getDbBean(0)).getCidFirstName());
                                setCidLastName((grpQry.getDbBean(0)).getCidLastName());
                                setPbxCidPoolId((grpQry.getDbBean(0)).getPbxCidPoolId());
                                TblPublicTnPoolQuery ptnPoolQry = new TblPublicTnPoolQuery();
                                ptnPoolQry.whereTnPoolIdEQ((int)(grpQry.getDbBean(0)).getPbxCidPoolId());
                                ptnPoolQry.query(dbCon);
                                if(ptnPoolQry.size() > 0)
                                {
                                        setPbxCidTn((ptnPoolQry.getDbBean(0)).getTn());
                                }else{
                                	setPbxCidTn("");
                                }
                                
                                setExtension((grpQry.getDbBean(0)).getExtension());
                                setPrivateNumber((grpQry.getDbBean(0)).getPrivateNumber());
                                setPbxMaxCclLimit((grpQry.getDbBean(0)).getPbxMaxCclLimit());
                                setPbxRedirectTn((grpQry.getDbBean(0)).getPbxRedirectTn());
                                setPbxRedirectTrunkId((grpQry.getDbBean(0)).getPbxRedirectTrunkId());
                               setActiveInd((grpQry.getDbBean(0)).getActiveInd());
                                setEnvOrderId(grpQry.getDbBean(0).getEnvOrderId());                    
                         setCreatedBy((grpQry.getDbBean(0)).getCreatedBy());
                                                setModifiedBy((grpQry.getDbBean(0)).getModifiedBy());
                                                setLastModifiedDate((grpQry.getDbBean(0)).getLastModifiedDate());
						setCreationDate((grpQry.getDbBean(0)).getCreationDate());
						 setLinePortLength((grpQry.getDbBean(0)).getLinePortLength());
						setInvitationTimer((grpQry.getDbBean(0)).getInvitationTimer());
						setPqInstanceId((grpQry.getDbBean(0)).getPqInstanceId());
								getGroupFeatureListByGroupId();
                        }
                }
                catch(SQLException s)
                {
                        s.printStackTrace();
                        setStatus(InvErrorCode.DB_EXCEPTION);
                   		setLogTrail("DB Exception: "+ s.getMessage());
                        //setStatusDesc("DB_FAILURE in getDetails PBX group");
                        return false;
                }
                setStatus(InvErrorCode.SUCCESS);
                //setStatusDesc("Successfully retrieved pbx group from db");
                return true;
        }

	
	public int getLineCountByGroupId()
	{
        try
        {
        	log.info("In PBXGroup:getLineCountByGroupId");
        	if(getGroupId() <= 0)
        	{
        		setStatus(InvErrorCode.INVALID_INPUT);
        		//setStatusDesc("INV_FAILURE in getLineCountByGroupId PBX group. Invalid Input");
        		return -1;
        	}
            setStatus(InvErrorCode.SUCCESS);
            //setStatusDesc("Successfully retrieved pbx group line count from db");
        	TblGroupTnQuery grpQry = new TblGroupTnQuery();
			if(getAll == false)
        		return grpQry.getRecCountByWhere(dbCon, "where group_id = "+getGroupId() + " and active_ind = 1");
			else
        		return grpQry.getRecCountByWhere(dbCon, "where group_id = "+getGroupId() + " and active_ind != 0");
        }
        catch(SQLException s)
        {
               		s.printStackTrace(); 
                setStatus(InvErrorCode.DB_EXCEPTION);
                setLogTrail("DB Exception: "+ s.getMessage());
				
                //setStatusDesc("DB_FAILURE in getLineCountByGroupId PBX group");
                return -1;
        }

	}
	
	public boolean getPbxTnListByGroupId()
	{
		PreparedStatement pstmt = null;
 		ResultSet rs = null;
		try
		{
			if(getGroupId()<= 0) 
			{
				setStatus(InvErrorCode.INVALID_INPUT);
				//setStatusDesc("INV_FAILURE in getDetails PBX groupTn. Invalid Input");
				return false;
			}

			TblVzbFeaturesQuery vzbFeatQry = new TblVzbFeaturesQuery();
   			String whereCls = " where 1=1";
   			HashMap<Integer, String> vzbFeatMap = new HashMap<Integer, String>();
   			vzbFeatQry.queryByWhere(dbCon, whereCls);
   			for(int j = 0; j < vzbFeatQry.size(); j++)
   			{
   				vzbFeatMap.put(vzbFeatQry.getDbBean(j).getFeatureId(), vzbFeatQry.getDbBean(j).getName());
   			}
   			log.info("vzbFeatMap.size():"+vzbFeatMap.size());
			PBXGroupTn pbxGrpTnObj = new PBXGroupTn(dbCon);
			pbxGrpTnObj.setGroupId(getGroupId());
			HashMap<Long, List<Long>> groupTnToExcldFeatMap = pbxGrpTnObj.getExcludedFeatureListByGroupId();
			if(groupTnToExcldFeatMap != null)
   			log.info("groupTnToExcldFeatMap.size():"+groupTnToExcldFeatMap.size());

			StringBuffer sqlTbl = new StringBuffer();
	 		
			sqlTbl.append(" SELECT GT.GROUP_TN_ID,GT.GROUP_ID,GT.TN_POOL_ID,GT.SEQUENCE_NO,");
            sqlTbl.append(" GT.EXTENSION,GT.PRIVATE_NUMBER,GT.LINE_PORT,");
            sqlTbl.append(" GT.CID_FIRST_NAME,GT.CID_LAST_NAME,GT.VM_MAXSIZE_ID,");
            sqlTbl.append(" GT.VM_BOX_NUM,TP.LOCATION_ID,TP.DEPARTMENT_ID,");
            sqlTbl.append(" TP.TN,TP.TN_STATUS,TP.PORTED_STATUS,TP.NPA_SPLIT_STATUS,");
            sqlTbl.append(" TP.SWITCH_CLLI,TP.TRUNK,TP.ENV_ORDER_ID,TP.ACTIVE_IND,");
            sqlTbl.append(" TP.CREATED_BY,TP.MODIFIED_BY,");
            sqlTbl.append(" GT.SUB_ID, GT.ICP_SUB_ID,");
            //IR #1353501  - For CSSOP TN_ON_OFF Needs to check
            sqlTbl.append(" TP.TN_ON_OFF,");
            sqlTbl.append(" TP.ACT_DEACT,");
            sqlTbl.append(" TP.CNAM_UPDATE_STATUS,TP.CNAM_UPDATE_DATE ");
            sqlTbl.append(" FROM  TBL_GROUP_TN GT, TBL_PUBLIC_TN_POOL TP");
            sqlTbl.append(" WHERE GT.group_id = ? AND TP.TN_POOL_ID = GT.TN_POOL_ID AND GT.ACTIVE_IND = 1");
            //sqlTbl.append(" AND TP.STN_IND != 0 ");
         	log.info("SQL [" + sqlTbl.toString() + "]");

			pstmt = dbCon.prepareStatement(sqlTbl.toString());
			pstmt.setLong(1,getGroupId());
			rs = pstmt.executeQuery();
                                      
         	while (rs.next())
         	{
				PBXGroupTn pbxGrpTn = new PBXGroupTn(dbCon);
				pbxGrpTn.setGroupId(rs.getInt(2));
            pbxGrpTn.setGroupTnId(rs.getInt(1));
            pbxGrpTn.setTnPoolId(rs.getLong(3));
            pbxGrpTn.setSequenceNo(rs.getLong(4));
            pbxGrpTn.setExtension(rs.getString(5));
            pbxGrpTn.setPrivateNumber(rs.getString(6));
            pbxGrpTn.setLinePort(rs.getString(7));
            pbxGrpTn.setCidFirstName(rs.getString(8));
            pbxGrpTn.setCidLastName(rs.getString(9));
            pbxGrpTn.setActiveInd(rs.getLong(21));
            pbxGrpTn.setVmxNumber(rs.getString(11));
            int vmxSizeId = rs.getInt(10);
				if (vmxSizeId == 0)
              		pbxGrpTn.setVmxSize(0);
            	else if (vmxSizeId == 1)
              		pbxGrpTn.setVmxSize(20);
            	else if (vmxSizeId == 2)
              		pbxGrpTn.setVmxSize(50);
			pbxGrpTn.setCreatedBy(rs.getString(22));
            pbxGrpTn.setModifiedBy(rs.getString(23));
            pbxGrpTn.setSubId(rs.getString(24));
            pbxGrpTn.setIcpSubId(rs.getString(25));
                                            
            PublicTnPoolBean ptBean = pbxGrpTn.getPublicTnPoolObj();
            ptBean.setTn(rs.getString(14));
			//log.info("TN:"+ptBean.getTn());
            ptBean.setPortedStatus(rs.getString(16));
            //IR #1353501  - For CSSOP TN_ON_OFF Needs to check
            ptBean.setTnOnOff(rs.getLong(26));
          //log.info("PbxGroup ptBean.getTnOnOff for CSSOP " + ptBean.getTnOnOff());
            ptBean.setActDeact(rs.getShort(27));
            pbxGrpTn.setCnamUpdateStatus(rs.getLong(28));
            pbxGrpTn.setCnamUpdateDate(rs.getTimestamp(29));
            pbxGrpTn.setPublicTnPoolObj(ptBean);

			if(groupTnToExcldFeatMap.size() > 0)
			{
				List<FeaturesBean> excldFeatList = null; 
				List<Long> featList = groupTnToExcldFeatMap.get(new Long(pbxGrpTn.getGroupTnId()));
				//log.info("group tn Id:"+pbxGrpTn.getGroupTnId());
				if(featList != null && featList.size() > 0)
				{
					//log.info("Have exclude features for group tn Id:"+pbxGrpTn.getGroupTnId());
				excldFeatList = new ArrayList<FeaturesBean>();
				Iterator  featIter = featList.iterator();
				while(featIter.hasNext())
				{
				FeaturesBean featBean = new FeaturesBean();
                DBTblVzbFeatures vzbFeat = new DBTblVzbFeatures();
				vzbFeat.setFeatureId(((Long)featIter.next()).intValue());
				String featName = vzbFeatMap.get(vzbFeat.getFeatureId());
				if(featName != null && !featName.equals(""))
					vzbFeat.setName(featName);

				//log.info("featureId:"+vzbFeat.getFeatureId()+"feature Name:"+vzbFeat.getName());
                featBean.setFeaturesDbBean(vzbFeat);
				excldFeatList.add(featBean);
				}
				if(excldFeatList != null && excldFeatList.size() > 0)
				{
					//log.info("FOr groupTnId:"+pbxGrpTn.getGroupTnId()+":number of excluded features:"+excldFeatList.size());
					pbxGrpTn.setExcludedFeaturesList(excldFeatList);
				}
				}
			}
			pbxGroupTnList.add(pbxGrpTn);

			}
		}
		catch(SQLException s)
		{
			setStatus(InvErrorCode.DB_EXCEPTION);
            setLogTrail("DB Exception: "+ s.getMessage());
			s.printStackTrace(); 
			return false;
		}finally{ //#IR1440263 closing statement and results set
			   try{
				   if ( pstmt != null) {
					   pstmt.close();
				   }
				   if ( rs != null ){
					   rs.close();
				   }
			   }catch(Exception e){
				   setStatus(InvErrorCode.DB_EXCEPTION);
            		setLogTrail("DB Exception: "+ e.getMessage());
				   e.printStackTrace();
				   return false;
				   //log.info(" Closing Resouces Exception " + e);
			   }
		   }
		setStatus(InvErrorCode.SUCCESS);
		return true;
	}

	
	
	public List<PBXGroupTn> getAllPbxTnListByGroupId()
	{
		log.info("PbxGroup::getAllPbxTnListByGroupId");
		
		List<PBXGroupTn> pbxGroupTnList =new ArrayList<PBXGroupTn>();
		
		PreparedStatement pstmt = null;
 		ResultSet rs = null;
		try
		{
			if(getGroupId()<= 0) 
			{
				setStatus(InvErrorCode.INVALID_INPUT);
				//setStatusDesc("INV_FAILURE in getDetails PBX groupTn. Invalid Input");
				return pbxGroupTnList;
			}

			TblVzbFeaturesQuery vzbFeatQry = new TblVzbFeaturesQuery();
   			String whereCls = " where 1=1";
   			HashMap<Integer, String> vzbFeatMap = new HashMap<Integer, String>();
   			vzbFeatQry.queryByWhere(dbCon, whereCls);
   			for(int j = 0; j < vzbFeatQry.size(); j++)
   			{
   				vzbFeatMap.put(vzbFeatQry.getDbBean(j).getFeatureId(), vzbFeatQry.getDbBean(j).getName());
   			}
   			log.info("vzbFeatMap.size():"+vzbFeatMap.size());
			PBXGroupTn pbxGrpTnObj = new PBXGroupTn(dbCon);
			pbxGrpTnObj.setGroupId(getGroupId());
			

			StringBuffer sqlTbl = new StringBuffer();
	 		
			sqlTbl.append(" SELECT GT.GROUP_TN_ID,GT.GROUP_ID,GT.TN_POOL_ID,GT.SEQUENCE_NO,");
            sqlTbl.append(" GT.EXTENSION,GT.PRIVATE_NUMBER,GT.LINE_PORT,");
            sqlTbl.append(" GT.CID_FIRST_NAME,GT.CID_LAST_NAME,GT.VM_MAXSIZE_ID,");
            sqlTbl.append(" GT.VM_BOX_NUM,TP.LOCATION_ID,TP.DEPARTMENT_ID,");
            sqlTbl.append(" TP.TN,TP.TN_STATUS,TP.PORTED_STATUS,TP.NPA_SPLIT_STATUS,");
            sqlTbl.append(" TP.SWITCH_CLLI,TP.TRUNK,TP.ENV_ORDER_ID,TP.ACTIVE_IND,");
            sqlTbl.append(" TP.CREATED_BY,TP.MODIFIED_BY,");
            sqlTbl.append(" GT.SUB_ID, GT.ICP_SUB_ID,");
            //IR #1353501  - For CSSOP TN_ON_OFF Needs to check
            sqlTbl.append(" TP.TN_ON_OFF,");
            sqlTbl.append(" TP.ACT_DEACT,");
            sqlTbl.append(" TP.CNAM_UPDATE_STATUS,TP.CNAM_UPDATE_DATE ");
            sqlTbl.append(" FROM  TBL_GROUP_TN GT, TBL_PUBLIC_TN_POOL TP");
            sqlTbl.append(" WHERE GT.group_id = ? AND TP.TN_POOL_ID = GT.TN_POOL_ID ");
            //sqlTbl.append(" AND TP.STN_IND != 0 ");
         	log.info("SQL [" + sqlTbl.toString() + "]");

			pstmt = dbCon.prepareStatement(sqlTbl.toString());
			pstmt.setLong(1,getGroupId());
			rs = pstmt.executeQuery();
                                      
         	while (rs.next())
         	{
				PBXGroupTn pbxGrpTn = new PBXGroupTn(dbCon);
				pbxGrpTn.setGroupId(rs.getInt(2));
            pbxGrpTn.setGroupTnId(rs.getInt(1));
            pbxGrpTn.setTnPoolId(rs.getLong(3));
            pbxGrpTn.setSequenceNo(rs.getLong(4));
            pbxGrpTn.setExtension(rs.getString(5));
            pbxGrpTn.setPrivateNumber(rs.getString(6));
            pbxGrpTn.setLinePort(rs.getString(7));
            pbxGrpTn.setCidFirstName(rs.getString(8));
            pbxGrpTn.setCidLastName(rs.getString(9));
            pbxGrpTn.setActiveInd(rs.getLong(21));
            pbxGrpTn.setVmxNumber(rs.getString(11));
            int vmxSizeId = rs.getInt(10);
				if (vmxSizeId == 0)
              		pbxGrpTn.setVmxSize(0);
            	else if (vmxSizeId == 1)
              		pbxGrpTn.setVmxSize(20);
            	else if (vmxSizeId == 2)
              		pbxGrpTn.setVmxSize(50);
			pbxGrpTn.setCreatedBy(rs.getString(22));
            pbxGrpTn.setModifiedBy(rs.getString(23));
            pbxGrpTn.setSubId(rs.getString(24));
            pbxGrpTn.setIcpSubId(rs.getString(25));
                                            
            PublicTnPoolBean ptBean = pbxGrpTn.getPublicTnPoolObj();
            ptBean.setTn(rs.getString(14));
			//log.info("TN:"+ptBean.getTn());
            ptBean.setPortedStatus(rs.getString(16));
            //IR #1353501  - For CSSOP TN_ON_OFF Needs to check
            ptBean.setTnOnOff(rs.getLong(26));
          //log.info("PbxGroup ptBean.getTnOnOff for CSSOP " + ptBean.getTnOnOff());
            ptBean.setActDeact(rs.getShort(27));
            pbxGrpTn.setCnamUpdateStatus(rs.getLong(28));
            pbxGrpTn.setCnamUpdateDate(rs.getTimestamp(29));
            pbxGrpTn.setPublicTnPoolObj(ptBean);

			
			pbxGroupTnList.add(pbxGrpTn);

			}
		}
		catch(SQLException s)
		{
			setStatus(InvErrorCode.DB_EXCEPTION);
            setLogTrail("DB Exception: "+ s.getMessage());
			s.printStackTrace(); 
			return pbxGroupTnList;
		}finally{ //#IR1440263 closing statement and results set
			   try{
				   if ( pstmt != null) {
					   pstmt.close();
				   }
				   if ( rs != null ){
					   rs.close();
				   }
			   }catch(Exception e){
				   setStatus(InvErrorCode.DB_EXCEPTION);
            		setLogTrail("DB Exception: "+ e.getMessage());
				   e.printStackTrace();
				   return pbxGroupTnList;
				   //log.info(" Closing Resouces Exception " + e);
			   }
		   }
		setStatus(InvErrorCode.SUCCESS);
		return pbxGroupTnList;
	}




/*************************************************/	
	public boolean getPbxTnListByGroupIdFilterSTN(int offsetNo, int noOfRecs,HashMap<ColumnName, List<String>> pbxLineMap,String searchCondition,HashMap<ColumnName, SortBy> sortMap)
	{
		PreparedStatement pstmt = null;
 		ResultSet rs = null;
		try
		{
			if(getGroupId()<= 0) 
			{
				setStatus(InvErrorCode.INVALID_INPUT);
				//setStatusDesc("INV_FAILURE in getDetails PBX groupTn. Invalid Input");
				return false;
			}

			TblVzbFeaturesQuery vzbFeatQry = new TblVzbFeaturesQuery();
   			String whereCls = " where 1=1";
   			HashMap<Integer, String> vzbFeatMap = new HashMap<Integer, String>();
   			vzbFeatQry.queryByWhere(dbCon, whereCls);
   			for(int j = 0; j < vzbFeatQry.size(); j++)
   			{
   				vzbFeatMap.put(vzbFeatQry.getDbBean(j).getFeatureId(), vzbFeatQry.getDbBean(j).getName());
   			}
   			log.info("vzbFeatMap.size():"+vzbFeatMap.size());
			PBXGroupTn pbxGrpTnObj = new PBXGroupTn(dbCon);
			pbxGrpTnObj.setGroupId(getGroupId());
			HashMap<Long, List<Long>> groupTnToExcldFeatMap = pbxGrpTnObj.getExcludedFeatureListByGroupId();
			if(groupTnToExcldFeatMap != null)
   			log.info("groupTnToExcldFeatMap.size():"+groupTnToExcldFeatMap.size());

			StringBuffer sqlTbl = new StringBuffer();
			sqlTbl.append(" select * from (select a.*, rownum rnum from ( " );
			sqlTbl.append(" SELECT GT.GROUP_TN_ID,GT.GROUP_ID,GT.TN_POOL_ID,GT.SEQUENCE_NO,");
            sqlTbl.append(" GT.EXTENSION,GT.PRIVATE_NUMBER,GT.LINE_PORT,");
            sqlTbl.append(" GT.CID_FIRST_NAME,GT.CID_LAST_NAME,GT.VM_MAXSIZE_ID,");
            sqlTbl.append(" GT.VM_BOX_NUM,TP.LOCATION_ID,TP.DEPARTMENT_ID,");
            sqlTbl.append(" TP.TN,TP.TN_STATUS,TP.PORTED_STATUS,TP.NPA_SPLIT_STATUS,");
            sqlTbl.append(" TP.SWITCH_CLLI,TP.TRUNK,TP.ENV_ORDER_ID,TP.ACTIVE_IND,");
            sqlTbl.append(" TP.CREATED_BY,TP.MODIFIED_BY,");
            sqlTbl.append(" GT.SUB_ID, GT.ICP_SUB_ID,");
            //IR #1353501  - For CSSOP TN_ON_OFF Needs to check
            sqlTbl.append(" TP.TN_ON_OFF,");
            sqlTbl.append(" TP.ACT_DEACT,");
            sqlTbl.append(" TP.CNAM_UPDATE_STATUS,TP.CNAM_UPDATE_DATE ");
            //sqlTbl.append(" ROWNUM reqRowNum "); //control records- Commented to achieve sorting 
            sqlTbl.append(" FROM  TBL_GROUP_TN GT, TBL_PUBLIC_TN_POOL TP");
            sqlTbl.append(" WHERE GT.group_id = ? AND TP.TN_POOL_ID = GT.TN_POOL_ID AND GT.ACTIVE_IND = 1");
            sqlTbl.append(" AND TP.PORTED_STATUS != 1 AND TP.ACTIVE_IND = 1 AND TP.TN_ON_OFF != 0");
            sqlTbl.append(" AND TP.STN_IND != 1 ");
            
         // Changes as part of JULY-2015 release - Start
        	if (null != pbxLineMap && pbxLineMap.size() > 0) {
    			int clause = 0;
    			StringBuffer condition = new StringBuffer(" AND ( ");
    			for (Iterator it = pbxLineMap.entrySet().iterator(); it.hasNext();) {
    				Map.Entry entry = (Map.Entry) it.next();
    				ColumnName key = (ColumnName) entry.getKey();
    				String columnName = key.getColumnName();
    				List<String> columnValues = (List<String>) entry.getValue();
    				String columnValue = null;
    				if (null != columnValues && columnValues.size() > 0) {
    					for (Iterator itr = columnValues.iterator(); itr.hasNext();) {
    						columnValue = (String) itr.next();
    						if(columnValue.indexOf("*") != -1)
    							columnValue = columnValue.replaceAll("\\*", "");
    						if (null != columnName && null != columnValue && columnName.trim().length() > 0 && columnValue.trim().length() > 0) {
    							clause++;
    							if(clause != 1)
    							{
    								condition.append(searchCondition).append(" ");
    							}

    							condition.append(" lower(");

    							condition.append(columnName).append(") like '%").append(columnValue.toLowerCase()).append("%' ");
    							if (itr.hasNext()) {
    								condition.append(searchCondition).append(" ");
    							}
    						}
    					}
    				}
    			}
    			condition.append(" ) ");
    			if (clause > 0) {
    				sqlTbl.append(condition);
    			}
    		}
    		
    		if (null != sortMap) {
    			Iterator it = sortMap.entrySet().iterator();
    			if (it.hasNext())
    				sqlTbl.append(" order by ");
    			for (; it.hasNext();) {
    				Map.Entry entry = (Map.Entry) it.next();
    				ColumnName key = (ColumnName) entry.getKey();
    				SortBy sortBy = (SortBy) entry.getValue();
    				log.info("Sort By is: "+(SortBy) entry.getValue());
    				log.info("Sort By value is: "+sortBy);
    				if (sortBy == SortBy.ASC)
    					sqlTbl.append(key.getColumnName()).append(" ").append(SortBy.ASC).append(" ");
      				else if (sortBy == SortBy.DESC)
      					sqlTbl.append(key.getColumnName()).append(" ").append(SortBy.DESC).append(" ");
    				if (it.hasNext())
    					sqlTbl.append(", ");
    			}
    		}
    		// Changes as part of JULY-2015 release - End
    		
          //to check pagination 
            sqlTbl.append(" ) a WHERE " ); 
            sqlTbl.append(" rownum <= ");  
            sqlTbl.append(offsetNo+noOfRecs); 
            sqlTbl.append(" ) where rnum >= "); 
            sqlTbl.append(offsetNo+1); 
         	log.info("SQL ::  [" + sqlTbl.toString() + "]");
			

			pstmt = dbCon.prepareStatement(sqlTbl.toString());
			pstmt.setLong(1,getGroupId());
			rs = pstmt.executeQuery();
                                      
         	while (rs.next())
         	{
				PBXGroupTn pbxGrpTn = new PBXGroupTn(dbCon);
				pbxGrpTn.setGroupId(rs.getInt(2));
            pbxGrpTn.setGroupTnId(rs.getInt(1));
            pbxGrpTn.setTnPoolId(rs.getLong(3));
            pbxGrpTn.setSequenceNo(rs.getLong(4));
            pbxGrpTn.setExtension(rs.getString(5));
            pbxGrpTn.setPrivateNumber(rs.getString(6));
            pbxGrpTn.setLinePort(rs.getString(7));
            pbxGrpTn.setCidFirstName(rs.getString(8));
            pbxGrpTn.setCidLastName(rs.getString(9));
            pbxGrpTn.setActiveInd(rs.getLong(21));
            pbxGrpTn.setVmxNumber(rs.getString(11));
            int vmxSizeId = rs.getInt(10);
				if (vmxSizeId == 0)
              		pbxGrpTn.setVmxSize(0);
            	else if (vmxSizeId == 1)
              		pbxGrpTn.setVmxSize(20);
            	else if (vmxSizeId == 2)
              		pbxGrpTn.setVmxSize(50);
			pbxGrpTn.setCreatedBy(rs.getString(22));
            pbxGrpTn.setModifiedBy(rs.getString(23));
            pbxGrpTn.setSubId(rs.getString(24));
            pbxGrpTn.setIcpSubId(rs.getString(25));
                                            
            PublicTnPoolBean ptBean = pbxGrpTn.getPublicTnPoolObj();
            ptBean.setTn(rs.getString(14));
			//log.info("TN:"+ptBean.getTn());
            ptBean.setPortedStatus(rs.getString(16));
            //IR #1353501  - For CSSOP TN_ON_OFF Needs to check
            ptBean.setTnOnOff(rs.getLong(26));
          //log.info("PbxGroup ptBean.getTnOnOff for CSSOP " + ptBean.getTnOnOff());
            ptBean.setActDeact(rs.getShort(27));
            pbxGrpTn.setCnamUpdateStatus(rs.getLong(28));
            pbxGrpTn.setCnamUpdateDate(rs.getTimestamp(29));
            pbxGrpTn.setPublicTnPoolObj(ptBean);

			if(groupTnToExcldFeatMap.size() > 0)
			{
				List<FeaturesBean> excldFeatList = null; 
				List<Long> featList = groupTnToExcldFeatMap.get(new Long(pbxGrpTn.getGroupTnId()));
				//log.info("group tn Id:"+pbxGrpTn.getGroupTnId());
				if(featList != null && featList.size() > 0)
				{
					//log.info("Have exclude features for group tn Id:"+pbxGrpTn.getGroupTnId());
				excldFeatList = new ArrayList<FeaturesBean>();
				Iterator  featIter = featList.iterator();
				while(featIter.hasNext())
				{
				FeaturesBean featBean = new FeaturesBean();
                DBTblVzbFeatures vzbFeat = new DBTblVzbFeatures();
				vzbFeat.setFeatureId(((Long)featIter.next()).intValue());
				String featName = vzbFeatMap.get(vzbFeat.getFeatureId());
				if(featName != null && !featName.equals(""))
					vzbFeat.setName(featName);

				//log.info("featureId:"+vzbFeat.getFeatureId()+"feature Name:"+vzbFeat.getName());
                featBean.setFeaturesDbBean(vzbFeat);
				excldFeatList.add(featBean);
				}
				if(excldFeatList != null && excldFeatList.size() > 0)
				{
					//log.info("FOr groupTnId:"+pbxGrpTn.getGroupTnId()+":number of excluded features:"+excldFeatList.size());
					pbxGrpTn.setExcludedFeaturesList(excldFeatList);
				}
				}
			}
			pbxGroupTnList.add(pbxGrpTn);

			}
		}
		catch(SQLException s)
		{
			setStatus(InvErrorCode.DB_EXCEPTION);
            setLogTrail("DB Exception: "+ s.getMessage());
			s.printStackTrace(); 
			return false;
		}finally{ //#IR1440263 closing statement and results set
			   try{
				   if ( pstmt != null) {
					   pstmt.close();
				   }
				   if ( rs != null ){
					   rs.close();
				   }
			   }catch(Exception e){
				   setStatus(InvErrorCode.DB_EXCEPTION);
            		setLogTrail("DB Exception: "+ e.getMessage());
				   e.printStackTrace();
				   return false;
				   //log.info(" Closing Resouces Exception " + e);
			   }
		   }
		setStatus(InvErrorCode.SUCCESS);
		return true;
	}
   public boolean getPbxTnRangeByGroupId(String startTn, String endTn, String extension, String condition)
   {
	 PreparedStatement pstmt = null;
	 ResultSet rs = null;
	 StringBuffer sql = new StringBuffer();
	 StringBuffer sqlTbl = new StringBuffer();

      try
      {
         if(getGroupId()<= 0)
         {
            setStatus(InvErrorCode.INVALID_INPUT);
            //setStatusDesc("INV_FAILURE in getDetails PBX groupTn. Invalid Input");
            return false;
         }
        

			sqlTbl.append(" (SELECT GT.GROUP_TN_ID,GT.GROUP_ID,GT.TN_POOL_ID,GT.SEQUENCE_NO,");
			sqlTbl.append(" GT.EXTENSION,GT.PRIVATE_NUMBER,GT.LINE_PORT,");
			sqlTbl.append(" GT.CID_FIRST_NAME,GT.CID_LAST_NAME,GT.VM_MAXSIZE_ID,");
			sqlTbl.append(" GT.VM_BOX_NUM,TP.LOCATION_ID,TP.DEPARTMENT_ID,");
			sqlTbl.append(" TP.TN,TP.TN_STATUS,TP.PORTED_STATUS,TP.NPA_SPLIT_STATUS,");
			sqlTbl.append(" TP.SWITCH_CLLI,TP.TRUNK,TP.ENV_ORDER_ID,TP.ACTIVE_IND,");
			sqlTbl.append(" TP.CREATED_BY,TP.MODIFIED_BY,");
            sqlTbl.append(" GT.SUB_ID, GT.ICP_SUB_ID,");
            //IR #1353501  - For CSSOP TN_ON_OFF Needs to check
            sqlTbl.append(" TP.TN_ON_OFF,");
            sqlTbl.append(" TP.ACT_DEACT,");
            sqlTbl.append(" TP.CNAM_UPDATE_STATUS,TP.CNAM_UPDATE_DATE ");
			sqlTbl.append(" FROM  TBL_GROUP_TN GT, TBL_PUBLIC_TN_POOL TP");
			sqlTbl.append(" WHERE GT.group_id = ? AND TP.TN_POOL_ID = GT.TN_POOL_ID ");
			//sqlTbl.append(" AND TP.STN_IND != 0 ");
	 		sql.append(" SELECT * FROM " + sqlTbl.toString());



         if ((startTn == null || startTn.length() <= 0) && (endTn != null && endTn.length() > 0))
         {
				sql.append(" WHERE (TN BETWEEN ");
				sql.append(" (SELECT  min(to_char(TN)) FROM  TBL_GROUP_TN GT, TBL_PUBLIC_TN_POOL TP");
				sql.append(" WHERE GT.group_id = ?  AND TP.TN_POOL_ID = GT.TN_POOL_ID)");
				sql.append(" AND");
				sql.append(" (SELECT  max(to_char(TN)) FROM  TBL_GROUP_TN GT, TBL_PUBLIC_TN_POOL TP");
				sql.append(" WHERE GT.group_id = ?  AND TP.TN_POOL_ID = GT.TN_POOL_ID AND TN LIKE ? )) ");
         	if ((extension != null && extension.length() > 0) && (condition != null && condition.length() > 0))
         	{
    				sql.append(condition + " EXTENSION = ?  ");
         	}

         }
         else if ((startTn != null && startTn.length() > 0) && (endTn == null || endTn.length() <= 0))
         {
				sql.append(" WHERE ( TN BETWEEN ");
				sql.append(" (SELECT  min(to_char(TN)) FROM  TBL_GROUP_TN GT, TBL_PUBLIC_TN_POOL TP");
				sql.append(" WHERE GT.group_id = ?  AND TP.TN_POOL_ID = GT.TN_POOL_ID AND TN LIKE ?)");
				sql.append(" AND");
				sql.append(" (SELECT  max(to_char(TN)) FROM  TBL_GROUP_TN GT, TBL_PUBLIC_TN_POOL TP");
				sql.append(" WHERE GT.group_id = ?  AND TP.TN_POOL_ID = GT.TN_POOL_ID )) ");
         	if ((extension != null && extension.length() > 0) && (condition != null && condition.length() > 0))
         	{
    				sql.append(condition + " EXTENSION = ?  ");
         	}
         }
         else if ((startTn != null && startTn.length() > 0) && (endTn != null && endTn.length() > 0))
         {
				sql.append(" WHERE ( TN BETWEEN ");
				sql.append(" (SELECT  min(to_char(TN)) FROM  TBL_GROUP_TN GT, TBL_PUBLIC_TN_POOL TP");
				sql.append(" WHERE GT.group_id = ?  AND TP.TN_POOL_ID = GT.TN_POOL_ID AND TN LIKE ?)");
				sql.append(" AND");
				sql.append(" (SELECT  max(to_char(TN)) FROM  TBL_GROUP_TN GT, TBL_PUBLIC_TN_POOL TP");
				sql.append(" WHERE GT.group_id = ?  AND TP.TN_POOL_ID = GT.TN_POOL_ID AND TN LIKE ? )) ");
	 			// sql.append(" AND ( TP.TN  BETWEEN (select min(to_char(TN)) from tbl_public_tn_pool where tn like ?) AND ");
            // sql.append(" (select max(to_char(TN)) from tbl_public_tn_pool where tn like  ?) )");
         	if ((extension != null && extension.length() > 0) && (condition != null && condition.length() > 0))
         	{
    				sql.append(condition + " EXTENSION = ?  ");
         	}
         }
         else if (extension != null && extension.length() > 0)
         {
    		sql.append("WHERE  EXTENSION = ?  ");
         }

         log.info("SQL [" + sql.toString() + "]");

			pstmt = dbCon.prepareStatement(sql.toString());
			pstmt.setLong(1,getGroupId());
         if ((startTn == null || startTn.length() <= 0) && (endTn != null && endTn.length() > 0))
         {
			pstmt.setLong(2,getGroupId());
			pstmt.setLong(3,getGroupId());
         pstmt.setString(4, endTn);
         	if ((extension != null && extension.length() > 0) && (condition != null && condition.length() > 0))
               pstmt.setString(5, extension);
         }
         else if ((startTn != null && startTn.length() > 0) && (endTn == null || endTn.length() <= 0))
         {
			pstmt.setLong(2,getGroupId());
         pstmt.setString(3, startTn);
			pstmt.setLong(4,getGroupId());

         	if ((extension != null && extension.length() > 0) && (condition != null && condition.length() > 0))
               pstmt.setString(5, extension);
         }
         else if ((startTn != null && startTn.length() > 0) && (endTn != null && endTn.length() > 0))
         {
			pstmt.setLong(2,getGroupId());
			pstmt.setString(3, startTn);
			pstmt.setLong(4,getGroupId());
			pstmt.setString(5, endTn);
         	if ((extension != null && extension.length() > 0) && (condition != null && condition.length() > 0))
					pstmt.setString(6, extension);
         }
         else if (extension != null && extension.length() > 0)
         {
					pstmt.setString(2, extension);
         }

			rs = pstmt.executeQuery();

         // TblGroupTnQuery grpTnQry = new TblGroupTnQuery();
         // grpTnQry.whereGroupIdEQ(getGroupId());
         // grpTnQry.query(dbCon);
         // for(int i=0; i<grpTnQry.size(); i++)
         while (rs.next())
         {
           // log.info("TnPoolId [" + rs.getLong(3) + "]");
            PBXGroupTn pbxGrpTn = new PBXGroupTn(dbCon);

            pbxGrpTn.setGroupId(rs.getInt(2));
            pbxGrpTn.setGroupTnId(rs.getInt(1));
            pbxGrpTn.setTnPoolId(rs.getLong(3));
            pbxGrpTn.setSequenceNo(rs.getLong(4));
            pbxGrpTn.setExtension(rs.getString(5));
            pbxGrpTn.setPrivateNumber(rs.getString(6));
            pbxGrpTn.setLinePort(rs.getString(7));
            pbxGrpTn.setCidFirstName(rs.getString(8));
            pbxGrpTn.setCidLastName(rs.getString(9));
            pbxGrpTn.setActiveInd(rs.getLong(21));
            pbxGrpTn.setVmxNumber(rs.getString(11));

            /*
             * Get the excluded Feature List
             */
            pbxGrpTn.getExcludedFeatureListByGroupTnId();

            int vmxSizeId = rs.getInt(10);

            if (vmxSizeId == 0)
              pbxGrpTn.setVmxSize(0);
            else if (vmxSizeId == 1)
              pbxGrpTn.setVmxSize(20);
            else if (vmxSizeId == 2)
              pbxGrpTn.setVmxSize(50);

				/*****************
            try{
               TblVmBoxSizeQuery vmBoxSize = new TblVmBoxSizeQuery();
               vmBoxSize.whereVmBoxSizeIdEQ(vmxSizeId);
               vmBoxSize.query(dbCon);
               log.info("VM Box Size ID: " + vmxSizeId);
               if(vmBoxSize.size() > 0)
            }
            catch(Exception e){
               e.printStackTrace();
            }
            ***********************/

            //log.info("VM Box Size ID in TnBean: " + pbxGrpTn.getVmxSize());

            pbxGrpTn.setCreatedBy(rs.getString(22));
            pbxGrpTn.setModifiedBy(rs.getString(23));
            pbxGrpTn.setSubId(rs.getString(24));
            pbxGrpTn.setIcpSubId(rs.getString(25));
           // log.info("subId for FMCG : "+pbxGrpTn.getSubId());

            // log.info("Doing TN Query");
            // TblPublicTnPoolQuery ptnPoolQry = new TblPublicTnPoolQuery();
            // ptnPoolQry.whereTnPoolIdEQ((int)(grpTnQry.getDbBean(i)).getTnPoolId());
            // ptnPoolQry.query(dbCon);

               PublicTnPoolBean ptBean = pbxGrpTn.getPublicTnPoolObj();
               ptBean.setTn(rs.getString(14));
               ptBean.setPortedStatus(rs.getString(16));
               //IR #1353501  - For CSSOP TN_ON_OFF Needs to check
               ptBean.setTnOnOff(rs.getLong(26));
               //log.info("PbxGroup ptBean.getTnOnOff for CSSOP " + ptBean.getTnOnOff());
               ptBean.setActDeact(rs.getShort(27));
               pbxGrpTn.setCnamUpdateStatus(rs.getLong(28));
               pbxGrpTn.setCnamUpdateDate(rs.getTimestamp(29));
               pbxGrpTn.setPublicTnPoolObj(ptBean);

            pbxGroupTnList.add(pbxGrpTn);
         }			
      }
      catch(SQLException s)
      {
         setStatus(InvErrorCode.DB_EXCEPTION);
         setLogTrail("DB Exception: "+ s.getMessage());
         s.printStackTrace();
         //setStatusDesc("DB_FAILURE in getDetails PBX group tn");
         return false;
      }
      finally{ 
		   try{
			   if ( pstmt != null) {
				   pstmt.close();
			   }
			   if ( rs != null ){
				   rs.close();
			   }
		   }catch(Exception e){
			   setStatus(InvErrorCode.DB_EXCEPTION);
       		   setLogTrail("DB Exception: "+ e.getMessage());
			   e.printStackTrace();
			   return false;
		   }
	   }
      setStatus(InvErrorCode.SUCCESS);
      //setStatusDesc("Successfully retrieved pbx group from db");
      return true;
   }
/*************************************************/	
   public boolean getPbxTnRangeByGroupIdFilterSTN(String startTn, String endTn, String extension, String condition,int offsetNo,int noOfRecs,HashMap<ColumnName, List<String>> pbxLineMap,String searchCondition,HashMap<ColumnName, SortBy> sortMap)
   {
	 PreparedStatement pstmt = null;
	 ResultSet rs = null;
	 StringBuffer sql = new StringBuffer();
	 StringBuffer sqlTbl = new StringBuffer();
	 StringBuffer paginationQry = new StringBuffer();//for pagination

      try
      {
         if(getGroupId()<= 0)
         {
            setStatus(InvErrorCode.INVALID_INPUT);
            //setStatusDesc("INV_FAILURE in getDetails PBX groupTn. Invalid Input");
            return false;
         }
        

			sqlTbl.append(" (SELECT GT.GROUP_TN_ID,GT.GROUP_ID,GT.TN_POOL_ID,GT.SEQUENCE_NO,");
			sqlTbl.append(" GT.EXTENSION,GT.PRIVATE_NUMBER,GT.LINE_PORT,");
			sqlTbl.append(" GT.CID_FIRST_NAME,GT.CID_LAST_NAME,GT.VM_MAXSIZE_ID,");
			sqlTbl.append(" GT.VM_BOX_NUM,TP.LOCATION_ID,TP.DEPARTMENT_ID,");
			sqlTbl.append(" TP.TN,TP.TN_STATUS,TP.PORTED_STATUS,TP.NPA_SPLIT_STATUS,");
			sqlTbl.append(" TP.SWITCH_CLLI,TP.TRUNK,TP.ENV_ORDER_ID,TP.ACTIVE_IND,");
			sqlTbl.append(" TP.CREATED_BY,TP.MODIFIED_BY,");
            sqlTbl.append(" GT.SUB_ID, GT.ICP_SUB_ID,");
            //IR #1353501  - For CSSOP TN_ON_OFF Needs to check
            sqlTbl.append(" TP.TN_ON_OFF,");
            sqlTbl.append(" TP.ACT_DEACT,");
            sqlTbl.append(" TP.CNAM_UPDATE_STATUS,TP.CNAM_UPDATE_DATE ");
			sqlTbl.append(" FROM  TBL_GROUP_TN GT, TBL_PUBLIC_TN_POOL TP");
			sqlTbl.append(" WHERE GT.group_id = ? AND TP.TN_POOL_ID = GT.TN_POOL_ID ");
			sqlTbl.append(" AND TP.PORTED_STATUS != 1 AND TP.ACTIVE_IND = 1 AND TP.TN_ON_OFF != 0 AND TP.STN_IND != 1 )");
	 		//sql.append(" SELECT * FROM " + sqlTbl.toString());
	 		//For pagination 
	 		sql.append(" Select GROUP_TN_ID,GROUP_ID,TN_POOL_ID,SEQUENCE_NO, EXTENSION,PRIVATE_NUMBER,LINE_PORT,"); 
	 		sql.append(" CID_FIRST_NAME,CID_LAST_NAME,VM_MAXSIZE_ID, VM_BOX_NUM,LOCATION_ID,DEPARTMENT_ID, TN,TN_STATUS,"); 
	 		sql.append(" PORTED_STATUS,NPA_SPLIT_STATUS, SWITCH_CLLI,TRUNK,ENV_ORDER_ID,ACTIVE_IND, CREATED_BY,MODIFIED_BY,"); 
	 		sql.append(" SUB_ID, ICP_SUB_ID, TN_ON_OFF, ACT_DEACT,CNAM_UPDATE_STATUS,CNAM_UPDATE_DATE from "+sqlTbl.toString()); 


         if ((startTn == null || startTn.length() <= 0) && (endTn != null && endTn.length() > 0))
         {
				sql.append(" WHERE (TN BETWEEN ");
				sql.append(" (SELECT  min(to_char(TN)) FROM  TBL_GROUP_TN GT, TBL_PUBLIC_TN_POOL TP");
				sql.append(" WHERE GT.group_id = ?  AND TP.TN_POOL_ID = GT.TN_POOL_ID AND TP.PORTED_STATUS != 1 AND TP.ACTIVE_IND = 1 AND TP.TN_ON_OFF != 0 AND TP.STN_IND != 1)");
				sql.append(" AND");
				sql.append(" (SELECT  max(to_char(TN)) FROM  TBL_GROUP_TN GT, TBL_PUBLIC_TN_POOL TP");
				sql.append(" WHERE GT.group_id = ?  AND TP.TN_POOL_ID = GT.TN_POOL_ID AND TN LIKE ? AND TP.PORTED_STATUS != 1 AND TP.ACTIVE_IND = 1 AND TP.TN_ON_OFF != 0 AND TP.STN_IND != 1)) ");
         	if ((extension != null && extension.length() > 0) && (condition != null && condition.length() > 0))
         	{
    				sql.append(condition + " EXTENSION = ?  ");
         	}

         }
         else if ((startTn != null && startTn.length() > 0) && (endTn == null || endTn.length() <= 0))
         {
				sql.append(" WHERE ( TN BETWEEN ");
				sql.append(" (SELECT  min(to_char(TN)) FROM  TBL_GROUP_TN GT, TBL_PUBLIC_TN_POOL TP");
				sql.append(" WHERE GT.group_id = ?  AND TP.TN_POOL_ID = GT.TN_POOL_ID AND TN LIKE ? AND TP.PORTED_STATUS != 1 AND TP.ACTIVE_IND = 1 AND TP.TN_ON_OFF != 0 AND TP.STN_IND != 1)");
				sql.append(" AND");
				sql.append(" (SELECT  max(to_char(TN)) FROM  TBL_GROUP_TN GT, TBL_PUBLIC_TN_POOL TP");
				sql.append(" WHERE GT.group_id = ?  AND TP.TN_POOL_ID = GT.TN_POOL_ID AND TP.PORTED_STATUS != 1 AND TP.ACTIVE_IND = 1 AND TP.TN_ON_OFF != 0 AND TP.STN_IND != 1 )) ");
         	if ((extension != null && extension.length() > 0) && (condition != null && condition.length() > 0))
         	{
    				sql.append(condition + " EXTENSION = ?  ");
         	}
         }
         else if ((startTn != null && startTn.length() > 0) && (endTn != null && endTn.length() > 0))
         {
				sql.append(" WHERE ( TN BETWEEN ");
				sql.append(" (SELECT  min(to_char(TN)) FROM  TBL_GROUP_TN GT, TBL_PUBLIC_TN_POOL TP");
				sql.append(" WHERE GT.group_id = ?  AND TP.TN_POOL_ID = GT.TN_POOL_ID AND TN LIKE ? AND TP.PORTED_STATUS != 1 AND TP.ACTIVE_IND = 1 AND TP.TN_ON_OFF != 0 AND TP.STN_IND != 1)");
				sql.append(" AND");
				sql.append(" (SELECT  max(to_char(TN)) FROM  TBL_GROUP_TN GT, TBL_PUBLIC_TN_POOL TP");
				sql.append(" WHERE GT.group_id = ?  AND TP.TN_POOL_ID = GT.TN_POOL_ID AND TN LIKE ? AND TP.PORTED_STATUS != 1 AND TP.ACTIVE_IND = 1 AND TP.TN_ON_OFF != 0 AND TP.STN_IND != 1)) ");
	 			// sql.append(" AND ( TP.TN  BETWEEN (select min(to_char(TN)) from tbl_public_tn_pool where tn like ?) AND ");
            // sql.append(" (select max(to_char(TN)) from tbl_public_tn_pool where tn like  ?) )");
         	if ((extension != null && extension.length() > 0) && (condition != null && condition.length() > 0))
         	{
    				sql.append(condition + " EXTENSION = ?  ");
         	}
         }
         else if (extension != null && extension.length() > 0)
         {
    		sql.append("WHERE  EXTENSION = ?  ");
         }
         
         // Changes as part of JULY-2015 release - Start
        	if (null != pbxLineMap && pbxLineMap.size() > 0) {
    			int clause = 0;
    			StringBuffer cond = new StringBuffer(" AND ( ");
    			for (Iterator it = pbxLineMap.entrySet().iterator(); it.hasNext();) {
    				Map.Entry entry = (Map.Entry) it.next();
    				ColumnName key = (ColumnName) entry.getKey();
    				String columnName = key.getColumnName();
    				List<String> columnValues = (List<String>) entry.getValue();
    				String columnValue = null;
    				if (null != columnValues && columnValues.size() > 0) {
    					for (Iterator itr = columnValues.iterator(); itr.hasNext();) {
    						columnValue = (String) itr.next();
    						if(columnValue.indexOf("*") != -1)
    							columnValue = columnValue.replaceAll("\\*", "");
    						if (null != columnName && null != columnValue && columnName.trim().length() > 0 && columnValue.trim().length() > 0) {
    							clause++;
    							if(clause != 1)
    							{
    								cond.append(searchCondition).append(" ");
    							}

    							cond.append(" lower(");

    							cond.append(columnName).append(") like '%").append(columnValue.toLowerCase()).append("%' ");
    							if (itr.hasNext()) {
    								cond.append(searchCondition).append(" ");
    							}
    						}
    					}
    				}
    			}
    			cond.append(" ) ");
    			if (clause > 0) {
    				sql.append(cond);
    			}
    		}
        	
    		if (null != sortMap) {
    			Iterator it = sortMap.entrySet().iterator();
    			if (it.hasNext())
    				sql.append(" order by ");
    			for (; it.hasNext();) {
    				Map.Entry entry = (Map.Entry) it.next();
    				ColumnName key = (ColumnName) entry.getKey();
    				SortBy sortBy = (SortBy) entry.getValue();
    				if (sortBy == SortBy.ASC)
    					sql.append(key.getColumnName()).append(" ").append(SortBy.ASC).append(" ");
    				else if (sortBy == SortBy.DESC)
    					sql.append(key.getColumnName()).append(" ").append(SortBy.DESC).append(" ");
    				if (it.hasNext())
    					sql.append(", ");
    			}
    		}
    		// Changes as part of JULY-2015 release - End

       //to check pagination 
         paginationQry.append("select * from (select a.*, rownum rnum from ( "+sql.toString()+" ) a "); 
         paginationQry.append("where rownum <= ");  
         paginationQry.append(offsetNo+noOfRecs); 
         paginationQry.append(" ) where rnum >= "); 
         paginationQry.append(offsetNo+1); 
         log.info("SQL [" + paginationQry.toString() + "]");

			pstmt = dbCon.prepareStatement(paginationQry.toString());
			pstmt.setLong(1,getGroupId());
         if ((startTn == null || startTn.length() <= 0) && (endTn != null && endTn.length() > 0))
         {
			pstmt.setLong(2,getGroupId());
			pstmt.setLong(3,getGroupId());
         pstmt.setString(4, endTn);
         	if ((extension != null && extension.length() > 0) && (condition != null && condition.length() > 0))
               pstmt.setString(5, extension);
         }
         else if ((startTn != null && startTn.length() > 0) && (endTn == null || endTn.length() <= 0))
         {
			pstmt.setLong(2,getGroupId());
         pstmt.setString(3, startTn);
			pstmt.setLong(4,getGroupId());

         	if ((extension != null && extension.length() > 0) && (condition != null && condition.length() > 0))
               pstmt.setString(5, extension);
         }
         else if ((startTn != null && startTn.length() > 0) && (endTn != null && endTn.length() > 0))
         {
			pstmt.setLong(2,getGroupId());
			pstmt.setString(3, startTn);
			pstmt.setLong(4,getGroupId());
			pstmt.setString(5, endTn);
         	if ((extension != null && extension.length() > 0) && (condition != null && condition.length() > 0))
					pstmt.setString(6, extension);
         }
         else if (extension != null && extension.length() > 0)
         {
					pstmt.setString(2, extension);
         }

			rs = pstmt.executeQuery();

         // TblGroupTnQuery grpTnQry = new TblGroupTnQuery();
         // grpTnQry.whereGroupIdEQ(getGroupId());
         // grpTnQry.query(dbCon);
         // for(int i=0; i<grpTnQry.size(); i++)
         while (rs.next())
         {
           // log.info("TnPoolId [" + rs.getLong(3) + "]");
            PBXGroupTn pbxGrpTn = new PBXGroupTn(dbCon);

            pbxGrpTn.setGroupId(rs.getInt(2));
            pbxGrpTn.setGroupTnId(rs.getInt(1));
            pbxGrpTn.setTnPoolId(rs.getLong(3));
            pbxGrpTn.setSequenceNo(rs.getLong(4));
            pbxGrpTn.setExtension(rs.getString(5));
            pbxGrpTn.setPrivateNumber(rs.getString(6));
            pbxGrpTn.setLinePort(rs.getString(7));
            pbxGrpTn.setCidFirstName(rs.getString(8));
            pbxGrpTn.setCidLastName(rs.getString(9));
            pbxGrpTn.setActiveInd(rs.getLong(21));
            pbxGrpTn.setVmxNumber(rs.getString(11));

            /*
             * Get the excluded Feature List
             */
            pbxGrpTn.getExcludedFeatureListByGroupTnId();

            int vmxSizeId = rs.getInt(10);

            if (vmxSizeId == 0)
              pbxGrpTn.setVmxSize(0);
            else if (vmxSizeId == 1)
              pbxGrpTn.setVmxSize(20);
            else if (vmxSizeId == 2)
              pbxGrpTn.setVmxSize(50);

				/*****************
            try{
               TblVmBoxSizeQuery vmBoxSize = new TblVmBoxSizeQuery();
               vmBoxSize.whereVmBoxSizeIdEQ(vmxSizeId);
               vmBoxSize.query(dbCon);
               log.info("VM Box Size ID: " + vmxSizeId);
               if(vmBoxSize.size() > 0)
            }
            catch(Exception e){
               e.printStackTrace();
            }
            ***********************/

            //log.info("VM Box Size ID in TnBean: " + pbxGrpTn.getVmxSize());

            pbxGrpTn.setCreatedBy(rs.getString(22));
            pbxGrpTn.setModifiedBy(rs.getString(23));
            pbxGrpTn.setSubId(rs.getString(24));
            pbxGrpTn.setIcpSubId(rs.getString(25));
           // log.info("subId for FMCG : "+pbxGrpTn.getSubId());

            // log.info("Doing TN Query");
            // TblPublicTnPoolQuery ptnPoolQry = new TblPublicTnPoolQuery();
            // ptnPoolQry.whereTnPoolIdEQ((int)(grpTnQry.getDbBean(i)).getTnPoolId());
            // ptnPoolQry.query(dbCon);

               PublicTnPoolBean ptBean = pbxGrpTn.getPublicTnPoolObj();
               ptBean.setTn(rs.getString(14));
               ptBean.setPortedStatus(rs.getString(16));
               //IR #1353501  - For CSSOP TN_ON_OFF Needs to check
               ptBean.setTnOnOff(rs.getLong(26));
               //log.info("PbxGroup ptBean.getTnOnOff for CSSOP " + ptBean.getTnOnOff());
               ptBean.setActDeact(rs.getShort(27));
               pbxGrpTn.setCnamUpdateStatus(rs.getLong(28));
               pbxGrpTn.setCnamUpdateDate(rs.getTimestamp(29));
               pbxGrpTn.setPublicTnPoolObj(ptBean);

            pbxGroupTnList.add(pbxGrpTn);
         }			
      }
      catch(SQLException s)
      {
         setStatus(InvErrorCode.DB_EXCEPTION);
         setLogTrail("DB Exception: "+ s.getMessage());
         s.printStackTrace();
         //setStatusDesc("DB_FAILURE in getDetails PBX group tn");
         return false;
      }
      finally{ 
		   try{
			   if ( pstmt != null) {
				   pstmt.close();
			   }
			   if ( rs != null ){
				   rs.close();
			   }
		   }catch(Exception e){
			   setStatus(InvErrorCode.DB_EXCEPTION);
       		   setLogTrail("DB Exception: "+ e.getMessage());
			   e.printStackTrace();
			   return false;
		   }
	   }
      setStatus(InvErrorCode.SUCCESS);
      //setStatusDesc("Successfully retrieved pbx group from db");
      return true;
   }
	public long getPackageIdByPackageStr(String pkgStr)
	{
		log.info("Entering getPackageIdByPackageStr");
		long packageId = 0;
		try
		{
			String whereLocClause =  " where location_id = \'"+locationId+"\'";
			TblLocPackageQuery locPkgQry = new TblLocPackageQuery();
			locPkgQry.queryByWhere(dbCon, whereLocClause);
			for(int k = 0; k < locPkgQry.size();k++)
			{
				TblPackageQuery pkgQry = new TblPackageQuery();
				pkgQry.wherePackageIdEQ((locPkgQry.getDbBean(k)).getPackageId());
				pkgQry.query(dbCon);
				
				if(pkgQry.size() == 1 && ((pkgQry.getDbBean(0)).getPackageName()).equals(getPackageStr()))
				{
					packageId = (pkgQry.getDbBean(0)).getPackageId();
					break;
				}
			}
		}
		catch(SQLException s)
		{
			setStatus(InvErrorCode.DB_EXCEPTION);
               		s.printStackTrace(); 
         setLogTrail("DB Exception: "+ s.getMessage());
			//setStatusDesc("DB_FAILURE in getPackageIdByPackageStr");
			return -1;
		}
		
		log.info("Successfully Retrieved PackageId");
		return packageId;
	}
	public boolean getExcludedFeatureListByGroupId()
	{
		try
		{
		if(getGroupId() <= 0)
                {
                        setStatus(InvErrorCode.INVALID_INPUT);
                        //setStatusDesc("INVi_FAILURE in getExcludedFeaturesList");
                        return false;
                }

		TblGroupExcldFeaturesQuery grpExcldFeatQry = new TblGroupExcldFeaturesQuery();
		grpExcldFeatQry.whereGroupIdEQ(getGroupId());
		grpExcldFeatQry.query(dbCon);
		if(grpExcldFeatQry.size() > 0)
		{
			for(int i = 0; i < grpExcldFeatQry.size(); i++)
			{
				TblVzbFeaturesQuery vzbFeatQry = new TblVzbFeaturesQuery();
				vzbFeatQry.whereFeatureIdEQ((int)(grpExcldFeatQry.getDbBean(i)).getFeatureId());
                vzbFeatQry.whereFeatureTypeNE("C");
				vzbFeatQry.query(dbCon);
				if(vzbFeatQry.size() == 1)
				{
					FeaturesBean featBean = new FeaturesBean();
					DBTblVzbFeatures vzbFeat = new DBTblVzbFeatures();
					vzbFeat.copyFromBean(vzbFeatQry.getDbBean(0));
					featBean.setFeaturesDbBean(vzbFeat);
					excludedFeaturesList.add(featBean);
				}
			}
		}
		}
		catch(SQLException s)
                {
                        setStatus(InvErrorCode.DB_EXCEPTION);
         				setLogTrail("DB Exception: "+ s.getMessage());
               		s.printStackTrace(); 
                        //setStatusDesc("DB_FAILURE in getExcludedFeaturesList");
                        return false;
                }
		return true;
	}
		 public boolean getGroupFeatureListByGroupId()
    {
        try
        {
        if(getGroupId() <= 0)
                {
                        setStatus(InvErrorCode.INVALID_INPUT);
                        return false;
                }

        TblGroupFeaturesQuery grpFeatQry = new TblGroupFeaturesQuery();
        grpFeatQry.whereGroupIdEQ(getGroupId());
        grpFeatQry.query(dbCon);
        if(grpFeatQry.size() > 0)
        {
            for(int i = 0; i < grpFeatQry.size(); i++)
            {
                TblVzbFeaturesQuery vzbFeatQry = new TblVzbFeaturesQuery();
                vzbFeatQry.whereFeatureIdEQ((int)(grpFeatQry.getDbBean(i)).getFeatureId());
                vzbFeatQry.whereFeatureTypeNE("C");
                vzbFeatQry.query(dbCon);
                if(vzbFeatQry.size() == 1)
                {
                    FeaturesBean featBean = new FeaturesBean();
                    DBTblVzbFeatures vzbFeat = new DBTblVzbFeatures();
                    vzbFeat.copyFromBean(vzbFeatQry.getDbBean(0));
                    featBean.setFeaturesDbBean(vzbFeat);
                    groupFeaturesList.add(featBean);
                }
            }
        }
        }
        catch(SQLException s)
                {
                        setStatus(InvErrorCode.DB_EXCEPTION);
                   	setLogTrail("DB Exception: "+ s.getMessage());
                    s.printStackTrace();
                        return false;
                }
        return true;
    }

        public boolean addGroupFeaturesForPBXGroup() throws SQLException, Exception
{
//            try {
                    if (groupFeaturesList.size() > 0) {
                            for (int i = 0; i < groupFeaturesList.size(); i++) {
                         	   TblVzbFeaturesQuery vzbFeatQry = new TblVzbFeaturesQuery();
                                vzbFeatQry.whereFeatureIdEQ(((groupFeaturesList.get(i)).getFeaturesDbBean()).getFeatureId());
                                vzbFeatQry.whereFeatureTypeNE("C");
                                vzbFeatQry.query(dbCon);
                                if(vzbFeatQry.size() == 1)
                                {		
                                        DBTblGroupFeatures  grpFeat = new DBTblGroupFeatures();
                                        grpFeat.getGroupFeatureIdSeqNextVal(dbCon);
                                        grpFeat.setGroupId(getGroupId());
                                        grpFeat.setFeatureId((vzbFeatQry.getDbBean(0)).getFeatureId());
                                        if(getCreatedBy() != null  && !getCreatedBy().equals(""))
                                                grpFeat.setCreatedBy(getCreatedBy());
                                         else
                                                grpFeat.setCreatedBy("ESAP_INV");

                                        if(getModifiedBy() != null  && !getModifiedBy().equals(""))
                                                grpFeat.setModifiedBy(getModifiedBy());
                                        else
                                                grpFeat.setModifiedBy("ESAP_INV");

                                        grpFeat.setLastModifiedDate(new Timestamp(System.currentTimeMillis()));
                                        grpFeat.setCreationDate(new Timestamp(System.currentTimeMillis()));
                                        grpFeat.insert(dbCon);

                                }
                                else
                                {
                                        log.info("Valid Group feature not found in the db"+((groupFeaturesList.get(i)).getFeaturesDbBean()).getName());
                            			setStatus(InvErrorCode.INTERNAL_ERROR);
                                        return false;
                                }     
                            }
                    } else {
                            setStatus(InvErrorCode.SUCCESS);
                            log.info("No groupExcFeatures to Add");
                            return true;
                    }
			 /*}
             catch(Exception e) {
                    setStatus(InvErrorCode.DB_EXCEPTION);
                    log.info("FAILURE in addGroupFeautresForPBXGroup.");
               	e.printStackTrace(); 
                    return false;
            }*/
            setStatus(InvErrorCode.SUCCESS);
            return true;
        }
	//wrapper add for excludedfeaturesList
        public boolean addExcludedFeautresForPBXGroup() throws SQLException, Exception
{
//            try {
                    if (excludedFeaturesList.size() > 0) {
                            for (int i = 0; i < excludedFeaturesList.size(); i++) {
                         	   TblVzbFeaturesQuery vzbFeatQry = new TblVzbFeaturesQuery();
                                vzbFeatQry.whereFeatureIdEQ(((excludedFeaturesList.get(i)).getFeaturesDbBean()).getFeatureId());
                                vzbFeatQry.whereFeatureTypeNE("C");
                                vzbFeatQry.query(dbCon);
                                if(vzbFeatQry.size() == 1)
                                {		
                                        DBTblGroupExcldFeatures  grpExcldFeat = new DBTblGroupExcldFeatures();
                                        grpExcldFeat.getGroupFeatureIdSeqNextVal(dbCon);
                                        grpExcldFeat.setGroupId(getGroupId());
                                        grpExcldFeat.setFeatureId((vzbFeatQry.getDbBean(0)).getFeatureId());
                                         if(getCreatedBy() != null  && !getCreatedBy().equals(""))
                                                grpExcldFeat.setCreatedBy(getCreatedBy());
                                         else
                                                grpExcldFeat.setCreatedBy("ESAP_INV");

                                        if(getModifiedBy() != null  && !getModifiedBy().equals(""))
                                                grpExcldFeat.setModifiedBy(getModifiedBy());
                                        else
                                                grpExcldFeat.setModifiedBy("ESAP_INV");

                                        grpExcldFeat.setLastModifiedDate(new Timestamp(System.currentTimeMillis()));
                                        grpExcldFeat.setCreationDate(new Timestamp(System.currentTimeMillis()));
                                        grpExcldFeat.insert(dbCon);

                                }
                                else
                                {
                                        log.info("Valid Excluded feature not found in the db"+((excludedFeaturesList.get(i)).getFeaturesDbBean()).getName());
                                        return false;
                                }     
                            }
                    } else {
                            setStatus(InvErrorCode.SUCCESS);
                            ////setStatusDesc("");
                            log.info("No groupExcFeatures to Add");
                            return true;
                    }

            /*} catch (Exception e) {
                    setStatus(InvErrorCode.ERROR_ADDING_EXCLD_FEATURE_TO_GROUP);
                    log.info("FAILURE in addExcludedFeautresForPBXGroup.");
               	e.printStackTrace(); 
                    return false;
            }*/
            setStatus(InvErrorCode.SUCCESS);
            return true;
        }

		//wrapper delete for excludedfeaturesList
        public boolean deleteExcludedfeaturesListForPBXGroup() throws SQLException, Exception
 {
         //       try {
            if (excludedFeaturesList.size() > 0) {
                    for (int i = 0; i < excludedFeaturesList.size(); i++) {
                        DBTblGroupExcldFeatures excFeaturesDbBean = new DBTblGroupExcldFeatures();
                        excFeaturesDbBean.whereFeatureIdEQ(((excludedFeaturesList.get(i)).getFeaturesDbBean()).getFeatureId());
                        excFeaturesDbBean.whereGroupIdEQ(getGroupId());
                        if (excFeaturesDbBean.deleteByWhere(dbCon) <= 0) {
                            log.info("Error while deleting Exclude Features from PBXGroup."+((excludedFeaturesList.get(i)).getFeaturesDbBean()).getFeatureId());
                        }
                                                                                                                             
                    }
            } else {
                setStatus(InvErrorCode.SUCCESS);
                // //setErrstatus("");
                log.info("No excludedfeaturesList to Delete");
                return true;
            }
        /*} catch (Exception e) {
            e.printStackTrace();
            setStatus(InvErrorCode.ERROR_DELETING_EXCLD_FEATURE_TO_GROUP);
            System.out
                    .println("FAILURE in deleteExcludedfeaturesListForPBXGroup.");
            return false;
        }*/
        setStatus(InvErrorCode.SUCCESS);
        return true;
                        
        }

		 public boolean deleteGroupFeaturesListForPBXGroup() throws SQLException, Exception
{
     //      try {
               if (groupFeaturesList.size() > 0) {
                   for (int i = 0; i < groupFeaturesList.size(); i++) {
                       TblGroupFeaturesQuery grpFeaturesQuery = new TblGroupFeaturesQuery();
						grpFeaturesQuery.whereGroupIdEQ(getGroupId());
                        grpFeaturesQuery.query(dbCon);
                         if(grpFeaturesQuery.size() <= 0)
      					   return false; 
                       for(int j = 0; j < grpFeaturesQuery.size();j++)
                       {
                           DBTblGroupFeatures grpFeaturesDbBean = new DBTblGroupFeatures();
                           grpFeaturesDbBean.whereGroupIdEQ(getGroupId());
                           grpFeaturesDbBean.whereFeatureIdEQ(((groupFeaturesList.get(i)).getFeaturesDbBean()).getFeatureId());
                           grpFeaturesDbBean.deleteByWhere(dbCon);
                     }
                   }
               } else {
                   setStatus(InvErrorCode.SUCCESS);
                   log.info("No groupfeaturesList to Delete");
                   return true;
               }

           /*} catch (Exception e) {
                    e.printStackTrace();
               setStatus(InvErrorCode.DB_EXCEPTION);
               log.info("FAILURE in deleteGroupFeaturesListForPBXGroup.");
               return false;
           }*/
           setStatus(InvErrorCode.SUCCESS);
           return true;
        }

	//wrapper Modify for excludedfeaturesList
        public boolean modifyExcludedfeaturesListForPBXGroup() {
     	   try {
     		   if (excludedFeaturesList.size() > 0) {
     			   for (int i = 0; i < excludedFeaturesList.size(); i++) {
     				   TblGroupExcldFeaturesQuery excFeaturesQuery = new TblGroupExcldFeaturesQuery();
     				   String whereClause =  " where group_id = "+getGroupId();
     				   excFeaturesQuery.queryByWhere(dbCon, whereClause);
                                 if(excFeaturesQuery.size() <= 0)
     					   return false; 
     				   for(int j = 0; j < excFeaturesQuery.size();j++)
     				   {
     					   DBTblGroupExcldFeatures excFeaturesDbBean = new DBTblGroupExcldFeatures();
     					   excFeaturesDbBean.whereGroupIdEQ(getGroupId());
     					   excFeaturesDbBean.whereFeatureIdEQ(((excludedFeaturesList.get(i)).getFeaturesDbBean()).getFeatureId());
     			           if(excFeaturesDbBean.updateSpByWhere(dbCon) <= 0) {
								String msg = "Failed to update TblGroupExcldFeatures, FeatureId=" + ((excludedFeaturesList.get(i)).getFeaturesDbBean()).getFeatureId() + " does not exist.";
								setLogTrail(msg);
								log.info(msg);
    						   return false; 	
						   }
                       }
     			   }
     		   } else {
     			   setStatus(InvErrorCode.SUCCESS);
     			   ////setStatusDesc("");
     			   log.info("No excludedfeaturesList to Modify");
     			   return true;
     		   }

     	   } catch (Exception e) {
     		   setStatus(InvErrorCode.ERROR_MODIFYING_EXCLD_FEATURE_TO_GROUP);
     		   log.info("FAILURE in modifyExcludedfeaturesListForPBXGroup.");
               	e.printStackTrace(); 
     		   return false;
     	   }
     	   setStatus(InvErrorCode.SUCCESS);
     	   return true;
        }
	public boolean addFeaturePackageToPBXGroup() {
                try {
           /*   FeaturePackage featPkg = new FeaturePackage(featurePackageObj, dbCon);
			
			ArrayList<Integer> feats = new ArrayList<Integer>();
			feats.add(Integer.parseInt(featPkg.getFeatureId()));
                        if (!featPkg.addToDB(feats)) {
				setStatus(InvErrorCode.INTERNAL_ERROR);
                                ////setStatusDesc(gwDev.getStatusDesc());
                                return false;
                        }
			*/
			/*
                        DBTblGroup groupDbBean = new DBTblGroup();
                        groupDbBean.setPackageId(featurePackageObj.getPackageId());
                     groupDbBean.setenvOrderId(device.getEnvOrderId()); 
                        if(featurePackageObj.getModifiedBy() != null && featurePackageObj.getModifiedBy().trim() != "")
                        	groupDbBean.setModifiedBy(groupDbBean.getModifiedBy());
                        else
                        	groupDbBean.setModifiedBy("ESAP_INV");
                        groupDbBean.setLastModifiedDate(new Timestamp(System.currentTimeMillis()));
                        groupDbBean.whereGroupIdEQ(getGroupId());
                        groupDbBean.updateSpByWhere(dbCon);
			*/
                } catch (Exception e) {
                        setStatus(InvErrorCode.ERROR_ADDING_FEATURE_PACKAGE_TO_GROUP);
                        log.info("FAILURE in addFeaturePackageToPBXGroup.");
               		e.printStackTrace(); 
                        return false;
                }
                setStatus(InvErrorCode.SUCCESS);
                return true;
        }

        public boolean deleteFeaturePackageToPBXGroup() {
                try {
                        FeaturePackage featPkg = new FeaturePackage(featurePackageObj, dbCon);

                        if (!featPkg.deletePkgFeature()) {
				setStatus(InvErrorCode.INTERNAL_ERROR);
                                ////setStatusDesc(gwDev.getStatusDesc());
                                return false;
                        }
                } catch (Exception e) {
                        setStatus(InvErrorCode.ERROR_DELETING_FEATURE_PACKAGE_TO_GROUP);
                        log.info("FAILURE in deleteFeaturePackageToPBXGroup.");
               		e.printStackTrace(); 
                        return false;
                }
                setStatus(InvErrorCode.SUCCESS);
                return true;
        }

        public boolean modifyFeaturePackageToPBXGroup() {
                try {
             /* FeaturePackage featPkg = new FeaturePackage(featurePackageObj, dbCon);
			    ArrayList<Integer> feats = new ArrayList<Integer>();
	     		feats.add(featPkg.getFeaturePackageId());

                        if (!featPkg.modifyPkgFeatureInDB(feats)) {
                        	setStatus(InvErrorCode.INTERNAL_ERROR);
                                ////setStatusDesc(gwDev.getStatusDesc());
                                return false;
                        }
            */      
                } catch (Exception e) {
                        setStatus(InvErrorCode.ERROR_MODIFYING_FEATURE_PACKAGE_TO_GROUP);
                        log.info("FAILURE in modifyFeaturePackageToPBXGroup.");
               		e.printStackTrace(); 
                        return false;
                }
                setStatus(InvErrorCode.SUCCESS);
                return true;
        }
	public boolean getDeviceForPBXGroup() {

		try{
	                Device devObj = new Device(dbCon);
        	        devObj.setDeviceMapId(new Long(getDeviceMapId()).intValue());
                	if (devObj.getDeviceDetailsByDeviceMapId()) {   
                        	long gwDevId = devObj.getGwDeviceId();
                        	GatewayDevice gtwDev = new GatewayDevice(dbCon);
                        	gtwDev.setGatewayDeviceId(gwDevId);
                        	if (gtwDev.getGwDeviceDetailsByGatewayDeviceId()) 
                                	device = gtwDev;
                        	else
                                	return false;
                	} else
                        	return false;

		}catch (Exception e ) {
               		e.printStackTrace(); 
                        setStatus(InvErrorCode.INTERNAL_ERROR);
                        log.info("FAILURE in getDeviceToPBXGroup.");
                        return false;
		}
		setStatus(InvErrorCode.SUCCESS);
                return true;
        }

	public boolean addDeviceToPBXGroup() {
                try {
                        GatewayDevice gwDev = new GatewayDevice(device, dbCon);
                        if (!gwDev.addGatewayDevice()) {
				setStatus(InvErrorCode.INTERNAL_ERROR);
                                ////setStatusDesc(gwDev.getStatusDesc());
                                log.info(gwDev.getStatusDesc());
                                return false;
                        }
                        DBTblGroup groupDbBean = new DBTblGroup();
                        groupDbBean.setDeviceMapId(device.getGatewayDeviceId());
                        if(device.getModifiedBy() != null && !(device.getModifiedBy().trim().equals("")))
                        	groupDbBean.setModifiedBy(groupDbBean.getModifiedBy());
                        else
                        	groupDbBean.setModifiedBy("ESAP_INV");
                        groupDbBean.setLastModifiedDate(new Timestamp(System.currentTimeMillis()));
                        groupDbBean.whereGroupIdEQ(getGroupId());
                    	FkValidationUtil.isValidGroupForMod(dbCon,groupDbBean);
                        groupDbBean.updateSpByWhere(dbCon);

                } catch (Exception e) {
               		e.printStackTrace(); 
                        setStatus(InvErrorCode.ERROR_ADDING_DEVICE_TO_GROUP);
                        log.info("FAILURE in addDeviceToPBXGroup.");
                        return false;
                }
                setStatus(InvErrorCode.SUCCESS);
                return true;
        }

        public boolean deleteDeviceFromPBXGroup() {
		
                try {
                        GatewayDevice gwDev = new GatewayDevice(device, dbCon);
                        if (!gwDev.deleteGatewayDevice()) {
				setStatus(InvErrorCode.INTERNAL_ERROR);
                                ////setStatusDesc(gwDev.getStatusDesc());
                                log.info(gwDev.getStatusDesc());
                                return false;
                        }
                } catch (Exception e) {
               		e.printStackTrace(); 
                        setStatus(InvErrorCode.ERROR_DELETING_DEVICE_TO_GROUP);
                        log.info("FAILURE in deleteDeviceFromPBXGroup.");
                        return false;
                }
                setStatus(InvErrorCode.SUCCESS);
                return true;
	}


        public boolean modifyDeviceFromPBXGroup() {
		
                try {
                        GatewayDevice gwDev = new GatewayDevice(device, dbCon);
                        if (!gwDev.updateGatewayDevice()) {
				setStatus(InvErrorCode.INTERNAL_ERROR);
                                ////setStatusDesc(gwDev.getStatusDesc());
                                log.info(gwDev.getStatusDesc());
                                return false;
                        }
                } catch (Exception e) {
               		e.printStackTrace(); 
                        setStatus(InvErrorCode.ERROR_MODIFYING_DEVICE_TO_GROUP);
                        log.info("FAILURE in addDeviceToPBXGroup.");
                        return false;
                }
                setStatus(InvErrorCode.SUCCESS);
                return true;
	}
	public boolean addPbxGroupTnForPBXGroup() {
        	try {
        		if (pbxGroupTnList.size() > 0) {
        			for (int i = 0; i < pbxGroupTnList.size(); i++) {
        				PBXGroupTnBean pbxGroupTnBean = pbxGroupTnList.get(i);
        				PBXGroupTn pbxGroupTn = new PBXGroupTn(pbxGroupTnBean, dbCon);
        				if (!pbxGroupTn.addToDB()) {
        					setStatus(InvErrorCode.INTERNAL_ERROR);
        					////setStatusDesc(dialPlan.getStatusDesc());
        					return false;
        				}
        			}
        		} else {
        			setStatus(InvErrorCode.SUCCESS);
        			////setStatusDesc("");
        			log.info("No pbxGroupTn to Add");
        			return true;
        		}

        	} catch (Exception e) {
               		e.printStackTrace(); 
        		setStatus(InvErrorCode.ERROR_ADDING_GROUP_TN_TO_GROUP);
        		log.info("FAILURE in addPbxGroupTnForPBXGroup.");
        		return false;
        	}
        	setStatus(InvErrorCode.SUCCESS);
        	return true;
        }
	public boolean deletePbxGroupTnForPBXGroup() {
        	try {
        		if (pbxGroupTnList.size() > 0) {
        			for (int i = 0; i < pbxGroupTnList.size(); i++) {
        				PBXGroupTnBean pbxGroupTnBean = pbxGroupTnList.get(i);
        				PBXGroupTn pbxGroupTn = new PBXGroupTn(pbxGroupTnBean, dbCon);
        				if (!pbxGroupTn.deleteFromDB()) {
        					setStatus(InvErrorCode.INTERNAL_ERROR);
        					////setStatusDesc(dialPlan.getStatusDesc());
        					return false;
        				}
        			}
        		} else {
        			setStatus(InvErrorCode.SUCCESS);
        			////setStatusDesc("");
        			log.info("No pbxGroupTn to Delete");
        			return true;
        		}

        	} catch (Exception e) {
               		e.printStackTrace(); 
        		setStatus(InvErrorCode.ERROR_DELETING_GROUP_TN_TO_GROUP);
        		log.info("FAILURE in deletePbxGroupTnForPBXGroup.");
        		return false;
        	}
        	setStatus(InvErrorCode.SUCCESS);
        	return true;
        }
	public boolean modifyPbxGroupTnForPBXGroup() {
        	try {
        		if (pbxGroupTnList.size() > 0) {
        			for (int i = 0; i < pbxGroupTnList.size(); i++) {
        				PBXGroupTnBean pbxGroupTnBean = pbxGroupTnList.get(i);
        				PBXGroupTn pbxGroupTn = new PBXGroupTn(pbxGroupTnBean, dbCon);
        				if (!pbxGroupTn.modifyInDB()) {
        					setStatus(InvErrorCode.INTERNAL_ERROR);
        					//setStatusDesc(dialPlan.getStatusDesc());
        					return false;
        				}
        			}
        		} else {
        			setStatus(InvErrorCode.SUCCESS);
        			log.info("No pbxGroupTn to Add");
        			return true;
        		}

        	} catch (Exception e) {
        		setStatus(InvErrorCode.ERROR_MODIFYING_GROUP_TN_TO_GROUP);
        		log.info("FAILURE in addPbxGroupTnForPBXGroup.");
               		e.printStackTrace(); 
        		return false;
        	}
        	setStatus(InvErrorCode.SUCCESS);
        	return true;
        }	
		public List<String> getVmBoxNumberListByGroupId() throws SQLException
        {
					ArrayList<String> vmBoxNumList = new ArrayList<String>();
                    TblGroupTnQuery grpTnQry = new TblGroupTnQuery();
                    grpTnQry.whereGroupIdEQ(getGroupId());
                    grpTnQry.query(dbCon);
                    if(grpTnQry.size() > 0)
                    {
                        for(int k = 0; k <grpTnQry.size(); k++)
                        {
                            if(grpTnQry.getDbBean(k).getVmBoxNum() != null && !grpTnQry.getDbBean(k).getVmBoxNum().equalsIgnoreCase(""))
                            vmBoxNumList.add(grpTnQry.getDbBean(k).getVmBoxNum());
                        }
                    }
            return vmBoxNumList;
        }

		public boolean isValidCCL() throws Exception
    {
        boolean returnCode = true;
        TblLocationQuery locQry = new TblLocationQuery();
        locQry.whereLocationIdEQ(getLocationId());
        locQry.query(dbCon);
        if(locQry.size() > 0)
        {
            List<Long> locCclList =new ArrayList();
            locCclList.add(locQry.getDbBean(0).getMaxConcurrentCalls());
            locCclList.add(locQry.getDbBean(0).getMaxConcurrentOffnet());
            locCclList.add(locQry.getDbBean(0).getMaxInbound());
            locCclList.add(locQry.getDbBean(0).getMaxSlg());
            locCclList.add(locQry.getDbBean(0).getMaxNg());
            Long maxCcl = Collections.max(locCclList);
            long locMaxCcl = maxCcl.longValue();
            log.info("MaxCcl of location:"+locMaxCcl);
                                                                                                                             
            long sumOfGrpCcl = getPbxMaxCclLimit();
            TblGroupQuery grpQry = new TblGroupQuery();
            grpQry.whereLocationIdEQ(getLocationId());
            //IR #1457636 OM Seq issue for Drop One PBX Grp1 and Adding PBX Grp2 in the SUPP Pass
            grpQry.whereActiveIndEQ(VzbVoipEnum.YesNoType.Y);
            grpQry.query(dbCon);
            if(grpQry.size() > 0)
            {
                for(int i = 0; i <grpQry.size(); i++)
                {
					if(grpQry.getDbBean(i).getGroupId() != getGroupId())
                    	sumOfGrpCcl += grpQry.getDbBean(i).getPbxMaxCclLimit();
                }
            }
            log.info("SumOfGrpCcl "+sumOfGrpCcl);
                                                                                                                             
            if(sumOfGrpCcl > locMaxCcl)
                returnCode = false;
        }
        return returnCode;
    }

	//IR #1457636 OM Seq issue for Drop One PBX Grp1 and Adding PBX Grp2 in the SUPP Pass. No need to take care of Tns now - Anand	
	public boolean setDeletePending() throws SQLException,Exception
    {
        if (groupId == -1)
        {
            setStatus(InvErrorCode.INVALID_INPUT);
            return false;
        }
        DBTblGroup tblGroupQuery = new DBTblGroup();
        tblGroupQuery.whereGroupIdEQ(groupId);
        tblGroupQuery.setActiveInd(VzbVoipEnum.ActiveInd.DELETE_PENDING);
        tblGroupQuery.updateSpByWhere(dbCon);
        return true;
    }

	

}
