/**
 * 
 */
package com.vz.esap.api.service.model;

/**
 * @author Deepak Kumar
 * @Desc This class is being used to store parameters and values of order details
 * 
 */
public class TableOrderDetailsParam {

	private String paramName;
	private String paramValue;
	private String action;
	private long parentId;
	private int leaf;

	public String getParamName() {
		return paramName;
	}

	public void setParamName(String paramName) {
		this.paramName = paramName;
	}

	public String getParamValue() {
		return paramValue;
	}

	public void setParamValue(String paramValue) {
		this.paramValue = paramValue;
	}

	public long getParentId() {
		return parentId;
	}

	public void setParentId(long parentId2) {
		this.parentId = parentId2;
	}

	public int getLeaf() {
		return leaf;
	}

	public void setLeaf(int leaf) {
		this.leaf = leaf;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

}