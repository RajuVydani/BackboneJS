package com.vz.fxo.inventory.enterprise.support;

import java.util.List;
import java.util.ArrayList;

public class PBXGroupTnBean
{
    protected List<FeaturesBean> excludedFeaturesList;
    protected PublicTnPoolBean publicTnPoolObj;//will be lazy initialized
    protected List<String> logTrail;

    protected int groupTnId;
    protected int groupId;
    protected long tnPoolId;
    protected long sequenceNo;
    protected String extension;
    protected String privateNumber;
    protected String linePort;
    protected String cidFirstName;
    protected String cidLastName;
    protected String vmxNumber;
    protected int vmxSize;
    protected long activeInd;
    protected long envOrderId;
    protected String createdBy;
    protected String modifiedBy;
    protected java.sql.Timestamp creationDate;
    protected java.sql.Timestamp lastModifiedDate;
    protected boolean getAll;
    protected String subId;
    protected String icpSubId;
    protected SubscriberBean subscriberBeanObj;
    protected List<GroupTnFeaturesBean> grpTnFeaturesList;
    protected long CnamUpdateStatus;
    protected java.sql.Timestamp CnamUpdateDate;
    
    protected String tn;

    public SubscriberBean getSubscriberBeanObj()
    {
        return subscriberBeanObj;
    }

    public void setSubscriberBeanObj(SubscriberBean subscriberBeanObj)
    {
        this.subscriberBeanObj = subscriberBeanObj;
    }

    public void setLogTrail(List<String> logTrail)
    {
        this.logTrail = logTrail;
    }

    /**
     * Default Constructor -- Initializes all fields to default values.
     */
    public PBXGroupTnBean()
    {
        this.excludedFeaturesList = null;
        this.publicTnPoolObj = null;
        this.logTrail = null;
        this.groupTnId = 0;
        this.groupId = 0;
        this.tnPoolId = -1;
        this.sequenceNo = 0;
        this.extension = new String("NONE");
        this.privateNumber = new String("NONE");
        this.linePort = new String("NONE");
        this.cidFirstName = new String("NONE");
        this.cidLastName = new String("NONE");
        //this.status = new String("1");
        this.envOrderId = 0;
        this.createdBy = new String("");
        this.modifiedBy = new String("");
        this.creationDate = null;
        this.lastModifiedDate = null;
        excludedFeaturesList = new ArrayList<FeaturesBean>();
        publicTnPoolObj = new PublicTnPoolBean();
        logTrail = new ArrayList<String>();
        this.activeInd = 1;
        this.vmxSize = -1;
        this.vmxNumber = new String("NONE");
        this.getAll = false;
        this.subId = new String("NONE");
        this.icpSubId = new String("NONE");
        this.subscriberBeanObj = new SubscriberBean();
        this.grpTnFeaturesList = new ArrayList<GroupTnFeaturesBean>();
        this.CnamUpdateStatus = -1;
        this.CnamUpdateDate = null;
    }

    /**
     * Constructor
     * 
     * @param pbxGroupTnBean
     */
    public PBXGroupTnBean(PBXGroupTnBean pbxGroupTnBean)
    {
        this.excludedFeaturesList = pbxGroupTnBean.excludedFeaturesList;
        this.publicTnPoolObj = pbxGroupTnBean.publicTnPoolObj;
        this.logTrail = pbxGroupTnBean.logTrail;
        this.groupTnId = pbxGroupTnBean.groupTnId;
        this.groupId = pbxGroupTnBean.groupId;
        this.tnPoolId = pbxGroupTnBean.tnPoolId;
        this.sequenceNo = pbxGroupTnBean.sequenceNo;
        this.extension = pbxGroupTnBean.extension;
        this.privateNumber = pbxGroupTnBean.privateNumber;
        this.linePort = pbxGroupTnBean.linePort;
        this.cidFirstName = pbxGroupTnBean.cidFirstName;
        this.cidLastName = pbxGroupTnBean.cidLastName;
        //	this.status = pbxGroupTnBean.status;
        this.envOrderId = pbxGroupTnBean.envOrderId;
        this.createdBy = pbxGroupTnBean.createdBy;
        this.modifiedBy = pbxGroupTnBean.modifiedBy;
        this.creationDate = pbxGroupTnBean.creationDate;
        this.lastModifiedDate = pbxGroupTnBean.lastModifiedDate;
        this.excludedFeaturesList = pbxGroupTnBean.excludedFeaturesList;
        this.publicTnPoolObj = pbxGroupTnBean.publicTnPoolObj;
        this.logTrail = pbxGroupTnBean.logTrail;
        this.activeInd = pbxGroupTnBean.activeInd;
        this.vmxNumber = pbxGroupTnBean.vmxNumber;
        this.vmxSize = pbxGroupTnBean.vmxSize;
        this.getAll = pbxGroupTnBean.getAll;
        this.subId = pbxGroupTnBean.subId;
        this.icpSubId = pbxGroupTnBean.icpSubId;
        this.subscriberBeanObj = pbxGroupTnBean.subscriberBeanObj;
        this.grpTnFeaturesList = pbxGroupTnBean.grpTnFeaturesList;
        this.CnamUpdateStatus = pbxGroupTnBean.CnamUpdateStatus;
        this.CnamUpdateDate = pbxGroupTnBean.CnamUpdateDate;
    }

    /**
	 * @return the cnamUpdateStatus
	 */
	public long getCnamUpdateStatus() {
		return CnamUpdateStatus;
	}

	/**
	 * @param cnamUpdateStatus the cnamUpdateStatus to set
	 */
	public void setCnamUpdateStatus(long cnamUpdateStatus) {
		CnamUpdateStatus = cnamUpdateStatus;
	}

	/**
	 * @return the cnamUpdateDate
	 */
	public java.sql.Timestamp getCnamUpdateDate() {
		return CnamUpdateDate;
	}

	/**
	 * @param cnamUpdateDate the cnamUpdateDate to set
	 */
	public void setCnamUpdateDate(java.sql.Timestamp cnamUpdateDate) {
		CnamUpdateDate = cnamUpdateDate;
	}

	public void setLogTrail(String logStr)
    {
        logTrail.add(logStr);
    }

    public List<String> getLogTrail()
    {
        return logTrail;
    }

    public long getActiveInd()
    {
        return activeInd;
    }

    public void setActiveInd(long activeInd)
    {
        this.activeInd = activeInd;
    }

    public java.sql.Timestamp getCreationDate()
    {
        return creationDate;
    }

    public void setCreationDate(java.sql.Timestamp creationDate)
    {
        this.creationDate = creationDate;
    }

    public java.sql.Timestamp getLastModifiedDate()
    {
        return lastModifiedDate;
    }

    public void setLastModifiedDate(java.sql.Timestamp lastModifiedDate)
    {
        this.lastModifiedDate = lastModifiedDate;
    }

    public List<FeaturesBean> getExcludedFeaturesList()
    {
        return excludedFeaturesList;
    }

    public void setExcludedFeaturesList(List<FeaturesBean> excludedFeaturesList)
    {
        this.excludedFeaturesList = excludedFeaturesList;
    }

    public PublicTnPoolBean getPublicTnPoolObj()
    {
        return publicTnPoolObj;
    }

    public void setPublicTnPoolObj(PublicTnPoolBean publicTnPoolObj)
    {
        this.publicTnPoolObj = publicTnPoolObj;
    }

    public int getGroupTnId()
    {
        return groupTnId;
    }

    public void setGroupTnId(int groupTnId)
    {
        this.groupTnId = groupTnId;
    }

    public int getGroupId()
    {
        return groupId;
    }

    public void setGroupId(int groupId)
    {
        this.groupId = groupId;
    }

    public long getTnPoolId()
    {
        return tnPoolId;
    }

    public void setTnPoolId(long tnPoolId)
    {
        this.tnPoolId = tnPoolId;
    }

    public long getSequenceNo()
    {
        return sequenceNo;
    }

    public void setSequenceNo(long sequenceNo)
    {
        this.sequenceNo = sequenceNo;
    }

    public String getExtension()
    {
        return extension;
    }

    public void setExtension(String extension)
    {
        this.extension = extension;
    }

    public String getPrivateNumber()
    {
        return privateNumber;
    }

    public void setPrivateNumber(String privateNumber)
    {
        this.privateNumber = privateNumber;
    }

    public String getLinePort()
    {
        return linePort;
    }

    public void setLinePort(String linePort)
    {
        this.linePort = linePort;
    }

    public String getCidFirstName()
    {
        return cidFirstName;
    }

    public void setCidFirstName(String cidFirstName)
    {
        this.cidFirstName = cidFirstName;
    }

    public String getCidLastName()
    {
        return cidLastName;
    }

    public void setCidLastName(String cidLastName)
    {
        this.cidLastName = cidLastName;
    }

    /*	public String getStatus() {
    		return status;
    	}
    	public void setStatus(String status) {
    		this.status = status;
    	}*/
    public String getCreatedBy()
    {
        return createdBy;
    }

    public void setCreatedBy(String createdBy)
    {
        this.createdBy = createdBy;
    }

    public String getModifiedBy()
    {
        return modifiedBy;
    }

    public void setModifiedBy(String modifiedBy)
    {
        this.modifiedBy = modifiedBy;
    }

    public long getEnvOrderId()
    {
        return envOrderId;
    }

    public void setEnvOrderId(long envOrderId)
    {
        this.envOrderId = envOrderId;
    }

    /**
     * @return the vmxNumber
     */
    public String getVmxNumber()
    {
        return vmxNumber;
    }

    /**
     * @param vmxNumber
     *            the vmxNumber to set
     */
    public void setVmxNumber(String vmxNumber)
    {
        this.vmxNumber = vmxNumber;
    }

    /**
     * @return the vmxSize
     */
    public int getVmxSize()
    {
        return vmxSize;
    }

    /**
     * @param vmxSize
     *            the vmxSize to set
     */
    public void setVmxSize(int vmxSize)
    {
        this.vmxSize = vmxSize;
    }

    public boolean getGetAll()
    {
        return getAll;
    }

    public void setGetAll(boolean getAll)
    {
        this.getAll = getAll;
    }

    /**
     * @return the fmcgSubId
     */
    public String getSubId()
    {
        return subId;
    }

    /**
     * @param fmcgSubId
     *            the fmcgSubId to set
     */
    public void setSubId(String subId)
    {
        this.subId = subId;
    }
	public String getIcpSubId()
    {
        return icpSubId;
    }

    public void setIcpSubId(String icpSubId)
    {
        this.icpSubId = icpSubId;
    }

	public List<GroupTnFeaturesBean> getGrpTnFeaturesList() {
		return grpTnFeaturesList;
	}

	public void setGrpTnFeaturesList(List<GroupTnFeaturesBean> grpTnFeaturesList) {
		this.grpTnFeaturesList = grpTnFeaturesList;
	}

	public String getTn() {
		return tn;
	}

	public void setTn(String tn) {
		this.tn = tn;
	}

}
