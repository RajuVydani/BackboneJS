package com.vz.fxo.inventory.enterprise.support;

import java.util.List;


public class TnPortingBean
{
	//members
	protected int tnPoolId;
	protected String portingInd;
	protected String subStatus;
	protected String gatewayNumber;
	protected String losingCarrierPrefix;
	protected String gainingCarrierPrefix;
	protected String originalCarrierPrefix;
	protected List<String> logTrail;


	/**
	 * Default constructor 
	 */
	public TnPortingBean() 
	{
		this.tnPoolId = 0;
		this.portingInd = new String("");
		this.subStatus = new String("");
		this.gatewayNumber = new String("");
		this.losingCarrierPrefix = new String("");
		this.gainingCarrierPrefix = new String("");
		this.originalCarrierPrefix = new String("");
	}


	/**
	 * Arg Constructor
	 * @param tnPortingBean
	 */
	public TnPortingBean(TnPortingBean tnPortingBean)
	{
		this.tnPoolId = tnPortingBean.tnPoolId;
		this.portingInd = tnPortingBean.getPortingInd();
		this.subStatus = tnPortingBean.getSubStatus();
		this.gatewayNumber = tnPortingBean.getGatewayNumber();
		this.losingCarrierPrefix = tnPortingBean.getLosingCarrierPrefix();
		this.gainingCarrierPrefix = tnPortingBean.getGainingCarrierPrefix();
		this.originalCarrierPrefix = tnPortingBean.getOriginalCarrierPrefix();
	}

	/**
	 * initializer method
	 */
	public void initilizeTODefault() 
	{
		this.portingInd = new String("");
		this.subStatus = new String("");
		this.gatewayNumber = new String("");
		this.losingCarrierPrefix = new String("");
		this.gainingCarrierPrefix = new String("");
		this.originalCarrierPrefix = new String("");
	}


	/******************* Setters *****************************/

	/**
	 * @param tnPoolId the tnPoolId to set
	 */
	public void setTnPoolId(int tnPoolId) {
		this.tnPoolId = tnPoolId;
	}

	/**
	 * @param portingInd the portingInd to set
	 */
	public void setPortingInd(String portingInd) {
		this.portingInd = portingInd;
	}

	/**
	 * @param subStatus the subStatus to set
	 */
	public void setSubStatus(String subStatus) {
		this.subStatus = subStatus;
	}

	/**
	 * @param gatewayNumber the gatewayNumber to set
	 */
	public void setGatewayNumber(String gatewayNumber) {
		this.gatewayNumber = gatewayNumber;
	}

	/**
	 * @param losingCarrierPrefix the losingCarrierPrefix to set
	 */
	public void setLosingCarrierPrefix(String losingCarrierPrefix) {
		this.losingCarrierPrefix = losingCarrierPrefix;
	}

	/**
	 * @param gainingCarrierPrefix the gainingCarrierPrefix to set
	 */
	public void setGainingCarrierPrefix(String gainingCarrierPrefix) {
		this.gainingCarrierPrefix = gainingCarrierPrefix;
	}

	/**
	 * @param originalCarrierPrefix the originalCarrierPrefix to set
	 */
	public void setOriginalCarrierPrefix(String originalCarrierPrefix) {
		this.originalCarrierPrefix = originalCarrierPrefix;
	}


	/******************* Getters *****************************/

	/**
	 * @return the tnPoolId
	 */
	public int getTnPoolId() {
		return tnPoolId;
	}

	/**
	 * @return the portingInd
	 */
	public String getPortingInd() {
		return portingInd;
	}

	/**
	 * @return the subStatus
	 */
	public String getSubStatus() {
		return subStatus;
	}

	/**
	 * @return the gatewayNumber
	 */
	public String getGatewayNumber() {
		return gatewayNumber;
	}

	/**
	 * @return the losingCarrierPrefix
	 */
	public String getLosingCarrierPrefix() {
		return losingCarrierPrefix;
	}

	/**
	 * @return the gainingCarrierPrefix
	 */
	public String getGainingCarrierPrefix() {
		return gainingCarrierPrefix;
	}

	/**
	 * @return the originalCarrierPrefix
	 */
	public String getOriginalCarrierPrefix() {
		return originalCarrierPrefix;
	}
	public void setLogTrail(String logStr)
    {
            logTrail.add(logStr);
    }
    public List<String> getLogTrail()
    {
            return logTrail;
    }

}
