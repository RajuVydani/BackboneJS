package com.vz.esap.api.model;

public class OrderLogInfo {
	
	private Long orderId;
	private Long seqNo;
	private String logText;
	private Integer logType;
	private String logDate;
	private Long logIdentity;
	
	public String getLogText() {
		return logText;
	}
	public void setLogText(String logText) {
		this.logText = logText;
	}
	public String getLogDate() {
		return logDate;
	}
	public void setLogDate(String logDate) {
		this.logDate = logDate;
	}
	public Long getLogIdentity() {
		return logIdentity;
	}
	public void setLogIdentity(Long logIdentity) {
		this.logIdentity = logIdentity;
	}
	public Long getOrderId() {
		return orderId;
	}
	public void setOrderId(Long orderId) {
		this.orderId = orderId;
	}
	public Long getSeqNo() {
		return seqNo;
	}
	public void setSeqNo(Long seqNo) {
		this.seqNo = seqNo;
	}
	
	public Integer getLogType() {
		return logType;
	}
	public void setLogType(Integer logType) {
		this.logType = logType;
	}
	
	
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("OrderLogInfo [orderId=");
		builder.append(orderId);
		builder.append(", sequenceNo=");
		builder.append(seqNo);
		builder.append(", message=");
		builder.append(logText);
		builder.append(", logType=");
		builder.append(logType);
		builder.append(", date=");
		builder.append(logDate);
		builder.append("]");
		return builder.toString();
	}

}
