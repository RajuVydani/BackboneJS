package com.vz.esap.api.service.model;

import java.util.List;
import java.util.Map;

public class FacodeBean
{
	//members
	private int facodeId;
	private String facode;
	//VZB Features attributes
	private long featureId;
	private String faname;
	private String cntryCode;
	private String modifiedBy;
	private java.sql.Timestamp lastModifiedDate;
	/**
	 * The map to hold Feature Name as Key and corresponding FACode as value.
	 */
    protected Map<String, String> faCodeFeatureMap;
    protected List<String> faCodeFeatureIdList;
    protected Map<String, List> authFeatureFaCodeFeatureMap;

    	/**
	* Default Constructor -- Initializes all fields to default values.
	*/
    	public FacodeBean() {
		this.facodeId = 0;
		this.facode = new String("");
		this.featureId = 0;
		this.faname = new String("");
		this.cntryCode = new String("");
		this.modifiedBy = new String("");
		this.lastModifiedDate = null;
		this.faCodeFeatureMap = null;
		this.faCodeFeatureIdList = null;
		this.authFeatureFaCodeFeatureMap = null;
	}

	/**
	 * Constructor
	 * @param facodeBean
	 */
	public FacodeBean(FacodeBean facodeBean)
	{
		this.facodeId = facodeBean.facodeId;
		this.facode = facodeBean.facode;
		this.featureId = facodeBean.featureId;
		this.faname = facodeBean.faname;
		this.cntryCode = facodeBean.cntryCode;
		this.modifiedBy = facodeBean.modifiedBy;
		this.lastModifiedDate = facodeBean.lastModifiedDate;
		this.faCodeFeatureMap = facodeBean.faCodeFeatureMap;
		this.faCodeFeatureIdList = facodeBean.faCodeFeatureIdList;
		this.authFeatureFaCodeFeatureMap = facodeBean.authFeatureFaCodeFeatureMap;
	}

	/**
	 * The method to return map of Feature Name onto FACode..
	 * @return Returns the faCodeFeatureMap.
	 * @author banala
	 */
	public final Map<String, String> getFaCodeFeatureMap() {
		return faCodeFeatureMap;
	}

	public final Map<String, List> getAuthFeatureFaCodeFeatureMap() {
	    return authFeatureFaCodeFeatureMap;
	}

	public final List<String> getFaCodeFeatureIdList() {
		return faCodeFeatureIdList;
	}

	/**
	 * The method to set the map of Feature Name onto FACode..
	 * @param faCodeFeatureMap The faCodeFeatureMap to set.
	 * @author banala
	 */
	public final void setFaCodeFeatureMap(Map<String, String> faCodeFeatureMap) {
		this.faCodeFeatureMap = faCodeFeatureMap;
	}
        public final void setFaCodeFeatureIdList(List<String> faCodeFeatureIdList) {
		this.faCodeFeatureIdList = faCodeFeatureIdList;
	}

	public void setFacodeId(final int facodeId) {
		this.facodeId = facodeId;
	}
	public int getFacodeId(){
		return this.facodeId;
	}
	public void setFeatureId(final long featureId) {
		this.featureId = featureId;
	}
	public long getFeatureId(){
		return this.featureId;
	}
	public void setFacode(final String facode) {
		this.facode = facode;
	}
	public String getFacode(){
		return this.facode;
	}
	public void setFaname(final String faname) {
		this.faname = faname;
	}
	public String getFaname(){
		return this.faname;
	}
	public void setCntryCode(final String cntryCode) {
        this.cntryCode= cntryCode;
    }
    public String getCntryCode(){
        return this.cntryCode;
    }
	public void setModifiedBy(final String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public String getModifiedBy(){
		return this.modifiedBy;
	}
	public void setLastModifiedDate(final java.sql.Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}
	public java.sql.Timestamp getLastModifiedDate(){
		return this.lastModifiedDate;
	}
}
