package com.vz.fxo.inventory.enterprise.support; 

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.vz.fxo.inventory.enterprise.support.CallingPlan;
import com.vz.fxo.inventory.enterprise.support.DepartmentBean;
import com.vz.fxo.inventory.enterprise.support.DigitString;
import com.vz.fxo.inventory.enterprise.support.FkValidationUtil;
import com.vz.fxo.inventory.enterprise.support.InvErrorCode;

import EsapEnumPkg.VzbVoipEnum;
import esap.db.DBTblCallingPlans;
import esap.db.DBTblDepartment;
import esap.db.DBTblDeviceMap;
import esap.db.DBTblGroup;
import esap.db.DBTblPublicTnPool;
import esap.db.DBTblSubscriber;
import esap.db.TblCallingPlansQuery;
import esap.db.TblDepartmentDbBean;
import esap.db.TblDepartmentQuery;
import esap.db.TblDeviceMapQuery;
import esap.db.TblEnterpriseQuery;
import esap.db.TblGroupQuery;
import esap.db.TblPublicTnPoolQuery;
import esap.db.TblSubscriberQuery;

public class Department extends DepartmentBean
{
	private static Logger log = LoggerFactory.getLogger(Department.class
			.toString());
    //members
    private Connection connection;
    private InvErrorCode status;
	private boolean migration;

    public Department(Connection con)
    {
        this.connection = con;
		this.migration = false;
    }

    //getters - setters
    public Connection getConnection()
    {
        return connection;
    }

    public void setConnection(Connection connection)
    {
        this.connection = connection;
    }

    public int getStatusCode()
    {
        return status.getErrorCode();
    }

    public void setStatusCode(InvErrorCode status)
    {
        this.status = status;
    }

    public String getStatusDesc()
    {
        return status.getErrorDesc();
    }
	 public boolean getMigration()
        {
            return migration;
        }
                       
        public void setMigration(boolean migration)
        {
            this.migration = migration;
        }


    //methods
    public boolean validateDepartment()
    {
        return true;
    }

    public boolean addDepartment()  throws SQLException, Exception
    {
        log.info("Entering Department::addDepartment");

       // try
        //{
            DBTblDepartment depDB = new DBTblDepartment();

            depDB.setDepartmentId(getDepartmentId());
            depDB.setEnterpriseId(getEnterpriseId());
            if(!"NONE".equals(getParentDeptId()) && !"".equals(getParentDeptId())){
            depDB.setParentDeptId(getParentDeptId());
            }else{
            depDB.setParentDeptIdNull();
            }
            
            if(!"NONE".equals(getDepartmentName()) && !"".equals(getDepartmentName())){
            depDB.setDepartmentName(getDepartmentName());
            }else{
            depDB.setDepartmentNameNull();
            }
            
            if(!"NONE".equals(getContactNumber()) && !"".equals(getContactNumber())){
            depDB.setContactNumber(getContactNumber());
            }else{
            depDB.setContactNumberNull();
            }
            
            if(!"NONE".equals(getContactName()) && !"".equals(getContactName())){
            depDB.setContactName(getContactName());
            }else{
            depDB.setContactNameNull();
            }
            
            if(getCallingPlanId()!=-1){
            depDB.setCallingPlanId(getCallingPlanId());
            }
            
            log.info("EnvOrderId = <" + getEnvOrderId() + ">");
    	    if(getEnvOrderId() > 0)
    	    	depDB.setEnvOrderId(getEnvOrderId());
    	    else
    	    	depDB.setEnvOrderIdNull();

            depDB.setActiveInd(getActiveInd());
			if(!migration || (migration && getCallingPlanId() <= 0))
			{
				
				//IR #1355849 Look for a param name <ParentDepartmentId> - if this is present , query the tbl department to find out the callingPlanId for the Parent Department - Use this Calling Plan Id to create the default calling plan for the new Department
				// If order does not come with the ParentCallingPlan, look for tbl enterprise to get the CallingPlanId, use this to create the default calling plan for the new department 
	            
				int callPlanId = 0;
				//boolean flag = false;
				log.info("getParentDeptId() " + getParentDeptId());
				if(!"NONE".equals(getParentDeptId()) && !"".equals(getParentDeptId())){
					String parentDepartmentId = getParentDeptId();
					
					TblDepartmentQuery departmentQry = new TblDepartmentQuery();
					//departmentQry.whereParentDeptIdEQ(parentDepartmentId);
					departmentQry.whereDepartmentIdEQ(parentDepartmentId);
					departmentQry.query(connection);
					
					if ( departmentQry.size() > 0){
						callPlanId = (int)departmentQry.getDbBean(0).getCallingPlanId();
						log.info(" CallPlanId is available for ParentDepartmentId " + callPlanId );
						//flag = true;
					}
					
						
				}else{
					String whereCls = " where enterprise_id = \'" + getEnterpriseId() + "\'";
		            TblEnterpriseQuery entQry = new TblEnterpriseQuery();
		            entQry.queryByWhere(connection, whereCls);
	            
		            if (entQry.size() > 0)
		            {
		                
		                if (entQry.getDbBean(0).getPlatformIndicator() == VzbVoipEnum.Platform.IASA)
		                {
		                    callPlanId = 0;
		                    //flag = true;
		                }
		                if (entQry.getDbBean(0).getPlatformIndicator() == VzbVoipEnum.Platform.ICP)
		                {
		                    callPlanId = 1;
		                    //flag = true;
		                }
		            }
				}
				
				//if (flag ){
	                TblCallingPlansQuery callPlanQry = new TblCallingPlansQuery();
	                callPlanQry.whereCallingPlanIdEQ(callPlanId);
	                callPlanQry.query(connection);
	                if (callPlanQry.size() > 0)
	                {
	                    DBTblCallingPlans callingPlanDbBean = new DBTblCallingPlans();
	                    callingPlanDbBean.copyFromBean(callPlanQry.getDbBean(0));
	                    callPlanId = callingPlanDbBean.getCallingPlanIdSeqNextVal(connection);
	                    callingPlanDbBean.setDefaultInd(0);
	                    callingPlanDbBean.setCallingPlanId(callPlanId);
						if(getDepartmentName() != null && !getDepartmentName().equals(""))
	                	{
	                    	String tmpCallingPlanName = getDepartmentName()+"_Calling Plan";
	                    	callingPlanDbBean.setCallingPlanName(tmpCallingPlanName);
	                	}
	
	                    if (getModifiedBy() != null && !("".equalsIgnoreCase(getModifiedBy())))
	                    {
	                        callingPlanDbBean.setModifiedBy(getModifiedBy());
	                    } else
	                    {
	                        callingPlanDbBean.setModifiedBy("ESAP_INV");
	                    }
	                    if (getCreatedBy() != null && !("".equalsIgnoreCase(getCreatedBy())))
	                    {
	                        callingPlanDbBean.setCreatedBy(getCreatedBy());
	                    } else
	                    {
	                        callingPlanDbBean.setCreatedBy("ESAP_INV");
	                    }
	                    callingPlanDbBean.setLastModifiedDate(new Timestamp(System.currentTimeMillis()));
	                    callingPlanDbBean.insert(connection);
	                }
	                depDB.setCallingPlanId(callPlanId);
	                
					DigitString digitStringObj = new DigitString(connection);
	            	if(digitStringObj.addDigitStringsForCallingPlanByEnterpriseId(callPlanId, getEnterpriseId(), getCreatedBy()))
	                	setLogTrail("digitStrings mapped for CallingPlan if any.");
	            	else
	            	{
	                	setLogTrail("Failed to map digitStrings for CallingPlan.");
	                	setStatusCode(InvErrorCode.ERROR_MAPPING_DIGITSTRINGS_TO_CALLINGPLAN);
	                	log.info("Failed to map digitStrings for CallingPlan.");
	                	return false;
	            	}
	
	           // }
			}
            if (getModifiedBy() != null && !getModifiedBy().equals(""))
                depDB.setModifiedBy(getModifiedBy());
            else
                depDB.setModifiedBy("ESAP_INV");
            if (getCreatedBy() != null && !getCreatedBy().equals(""))
                depDB.setCreatedBy(getCreatedBy());
            else
                depDB.setCreatedBy("ESAP_INV");

            depDB.setLastModifiedDate(new Timestamp(System.currentTimeMillis()));
            depDB.setCreationDate(new Timestamp(System.currentTimeMillis()));
            depDB.insert(connection);
        /*}
        catch (SQLException s)
        {
            s.printStackTrace();
            setStatusCode(InvErrorCode.ERROR_ADDING_DEPARTMENT);
	    setLogTrail("Department::addDepartment :: " + getStatusDesc());	
            return false;
        }*/
	setStatusCode(InvErrorCode.SUCCESS);
        setLogTrail("Department::addDepartment :: Successfully Added Department.");
        return true;
    }

    public boolean deleteDepartment() throws SQLException, Exception
    {
        log.info("Entering Department::deleteDepartment");

       // try
        //{
            if (getDepartmentId() == null || getDepartmentId().equalsIgnoreCase(""))
            {
                setStatusCode(InvErrorCode.INVALID_INPUT);
		setLogTrail("Department::deleteDepartment :: " + getStatusDesc());
                return false;
            }

            /*
             * Department Id in all the Child tables should be nullified.
             * tbl_public_tn_pool
             * tbl_subscriber
             * tbl_device_map
             * tbl_group
             */
            deletePublicTnPool();
            deleteSubscriber();
            deleteDeviceMap();
            deleteGroup();
			long callPlanId = 0;
                                                                                                                             
            TblDepartmentQuery deptQry = new TblDepartmentQuery();
            deptQry.whereDepartmentIdEQ(departmentId);
            deptQry.query(connection);
            if (deptQry.size() > 0)
            {
                callPlanId = deptQry.getDbBean(0).getCallingPlanId();
				log.info("CallPlanId:"+callPlanId);
            }



            DBTblDepartment depDB = new DBTblDepartment();

            depDB.whereDepartmentIdEQ(getDepartmentId());
            //depDB.setDepartmentId(getDepartmentId());
            depDB.deleteByWhere(connection);
			if(callPlanId > 0 )
                {
                CallingPlan callingPlanObj = new CallingPlan(connection);
                callingPlanObj.setCallingPlanId((int)callPlanId);
                callingPlanObj.deleteCallingPlan();
                }
			
        /*}
        catch (SQLException s)
        {
            s.printStackTrace();
            setStatusCode(InvErrorCode.ERROR_DELETING_DEPARTMENT);
	    setLogTrail("Department::deleteDepartment :: " + getStatusDesc());
            return false;
        }*/
        setStatusCode(InvErrorCode.SUCCESS);
        setLogTrail("Department::deleteDepartment :: Successfully Deleted Department.");

        return true;
    }

    /**
     * The method to nullify Department Id in PublicTnPool records corresponding to current
     * Department Id
     *
     * @throws SQLException
     *             Thrown when any DB error occurs.
     * @author banala
     */
    private void deletePublicTnPool() throws SQLException,Exception
    {
        DBTblPublicTnPool dbTblPublicTnPool = new DBTblPublicTnPool();
        dbTblPublicTnPool.setDepartmentIdNull();

        dbTblPublicTnPool.whereDepartmentIdEQ(getDepartmentId());
        FkValidationUtil.isValidPublicTNPoolForMod(connection,dbTblPublicTnPool);
        dbTblPublicTnPool.updateSpByWhere(connection);
	setLogTrail("Department::deletePublicTnPool :: PublicTnPool disasssociated Successfully from Department.");
    }

    /**
     * The method to nullify Department Id in Subscriber records corresponding to current Department
     * Id
     *
     * @throws SQLException
     *             Thrown when any DB error occurs.
     * @author banala
     */
    private void deleteSubscriber() throws SQLException,Exception
    {
        DBTblSubscriber dbTblSubscriber = new DBTblSubscriber();
        dbTblSubscriber.setDepartmentIdNull();

        dbTblSubscriber.whereDepartmentIdEQ(getDepartmentId());
        FkValidationUtil.isValidSubscriberObjForMod(connection,dbTblSubscriber);
        dbTblSubscriber.updateSpByWhere(connection);
	setLogTrail("Department::deleteSubscriber :: Subscriber disasssociated Successfully from Department.");
    }

    /**
     * The method to nullify Department Id in DeviceMap records corresponding to current Department
     * Id
     *
     * @throws SQLException
     *             Thrown when any DB error occurs.
     * @author banala
     */
    private void deleteDeviceMap() throws SQLException,Exception
    {
        DBTblDeviceMap dbTblDeviceMap = new DBTblDeviceMap();
        dbTblDeviceMap.setDepartmentIdNull();

        dbTblDeviceMap.whereDepartmentIdEQ(getDepartmentId());
        FkValidationUtil.isValidDeviceMapForMod(connection,dbTblDeviceMap);
        dbTblDeviceMap.updateSpByWhere(connection);
	setLogTrail("Department::deleteDeviceMap :: DeviceMap disasssociated Successfully from Department.");
    }

    /**
     * The method to nullify Department Id in Group records corresponding to current Department Id
     *
     * @throws SQLException
     *             Thrown when any DB error occurs.
     * @author banala
     */
    private void deleteGroup() throws SQLException,Exception
    {
        DBTblGroup dbTblGroup = new DBTblGroup();
        dbTblGroup.setDepartmentIdNull();

        dbTblGroup.whereDepartmentIdEQ(getDepartmentId());
        FkValidationUtil.isValidGroupForMod(connection,dbTblGroup);
        dbTblGroup.updateSpByWhere(connection);
	setLogTrail("Department::deleteGroup :: Group disasssociated Successfully from Department.");
    }

    public boolean updateDepartment() throws SQLException, Exception
    {
       // try
        //{
            if (getDepartmentId() == null || getDepartmentId().equalsIgnoreCase(""))
            {
                setStatusCode(InvErrorCode.MISSING_DEPT_ID);
                log.info("FAILURE in updateDepartment Department. DepartmentId missing.");
		setLogTrail("Department::updateDepartment :: " + getStatusDesc());
                return false;
            }

            DBTblDepartment departmentBean = getDepartmentToUpdate();
            log.info("getDepartmentId()  Value is ===> " + getDepartmentId());
            departmentBean.whereDepartmentIdEQ(getDepartmentId());
            if ( departmentBean.updateSpByWhere(connection) <= 0 ) {
            	return false;
            }

        /*}
        catch (SQLException s)
        {
	    s.printStackTrace();
            setStatusCode(InvErrorCode.DB_EXCEPTION);
            LogUtil.info("DB_FAILURE in modifyInDB Department");
	    setLogTrail("Department::updateDepartment :: " + getStatusDesc());
            return false;
        }*/
        setStatusCode(InvErrorCode.SUCCESS);
	setLogTrail("Department::updateDepartment :: Successfully updated Department.");
        return true;
    }

    /**
     * The current Department details are extracted using getDetails() and the new field values are
     * updated over that. The method will update the fields that are supplied on the current
     * instance iff they are different from the default values for the respective field.
     *
     * @return The Department to be updated.
     */
    private DBTblDepartment getDepartmentToUpdate()
    {
        DBTblDepartment departmentDbBean = new DBTblDepartment();

        /* Create a new instance of DepartmentBean. The new instance
         * would hold default values for the all the Department fields.*/
        DepartmentBean defaultDepartmentBean = new DepartmentBean();

        Department inputDepartment = this;

        /*Set the new fields if required.*/
        departmentDbBean.setDepartmentId(getDepartmentId());

        if (inputDepartment.getDepartmentName() != null
                && !inputDepartment.getDepartmentName().equals(defaultDepartmentBean.getDepartmentName()))
        {
            departmentDbBean.setDepartmentName(inputDepartment.getDepartmentName());
        }
        
        if("".equals(inputDepartment.getDepartmentName())){
        	departmentDbBean.setDepartmentNameNull();
        }

        if (inputDepartment.getEnterpriseId() != null
                && !inputDepartment.getEnterpriseId().equals(defaultDepartmentBean.getEnterpriseId()))
        {
            departmentDbBean.setEnterpriseId(inputDepartment.getEnterpriseId());
        }
        log.info(" ######################################### ");
        log.info("inputDepartment.getParentDeptId()  " + inputDepartment.getParentDeptId());
        log.info("defaultDepartmentBean.getParentDeptId()  " + defaultDepartmentBean.getParentDeptId());
        log.info(" ######################################### ");

        if (inputDepartment.getParentDeptId() != null
                && !inputDepartment.getParentDeptId().equals(defaultDepartmentBean.getParentDeptId()))
        {
            departmentDbBean.setParentDeptId(inputDepartment.getParentDeptId());
        }
        
        if("".equals(inputDepartment.getParentDeptId())){
        	departmentDbBean.setParentDeptIdNull();
        }

        if (inputDepartment.getContactNumber() != null
                && !inputDepartment.getContactNumber().equals(defaultDepartmentBean.getContactNumber()))
        {
            departmentDbBean.setContactNumber(inputDepartment.getContactNumber());
        }
        
    
        if("".equals(inputDepartment.getContactNumber())){
        	departmentDbBean.setContactNumberNull();
        }
        
        if (inputDepartment.getContactName() != null
                && !inputDepartment.getContactName().equals(defaultDepartmentBean.getContactName()))
        {
            departmentDbBean.setContactName(inputDepartment.getContactName());
        }
        
        if("".equals(inputDepartment.getContactName())){
        	departmentDbBean.setContactNameNull();
        }
        
     

	if ( inputDepartment.getActiveInd() != defaultDepartmentBean.getActiveInd()) 
	{
             departmentDbBean.setActiveInd(inputDepartment.getActiveInd());
        }


        if (inputDepartment.getCallingPlanId() != defaultDepartmentBean.getCallingPlanId())
        {
            departmentDbBean.setCallingPlanId(inputDepartment.getCallingPlanId());
        }
        
        if(inputDepartment.getCallingPlanId()==0){
        	departmentDbBean.setCallingPlanIdNull();
        }

        if (inputDepartment.getEnvOrderId() != defaultDepartmentBean.getEnvOrderId()) {
        	departmentDbBean.setEnvOrderId(inputDepartment.getEnvOrderId());
        }

        if( inputDepartment.getModifiedBy() != null &&
		!( "".equalsIgnoreCase(inputDepartment.getModifiedBy()) ) ) {
        	departmentDbBean.setModifiedBy(inputDepartment.getModifiedBy());
        } else {
		departmentDbBean.setModifiedBy("ESAP_INV");
        }

        departmentDbBean.setLastModifiedDate(new Timestamp(System.currentTimeMillis()));

        return departmentDbBean;
    }

    public boolean getDepartmentDetailsByDepartmentId()
    {
        log.info("Entering Department::getDepartmentDetailsByDepartmentId");

        try
        {
            TblDepartmentQuery depQry = new TblDepartmentQuery();
            depQry.whereDepartmentIdEQ(getDepartmentId());
            depQry.whereActiveIndEQ(1);
            depQry.query(connection);
            if (depQry.size() <= 0)
            {
                log.info("Department Id not Found");
                return false;
            }
            TblDepartmentDbBean depBean = depQry.getDbBean(0);
            setDepartmentId(depBean.getDepartmentId());
            setEnterpriseId(depBean.getEnterpriseId());
            setParentDeptId(depBean.getParentDeptId());
            setDepartmentName(depBean.getDepartmentName());
            setContactNumber(depBean.getContactNumber());
            setContactName(depBean.getContactName());
            setCallingPlanId(depBean.getCallingPlanId());
            setActiveInd(depBean.getActiveInd());
            setCreatedBy(depBean.getCreatedBy());
            setModifiedBy(depBean.getModifiedBy());
            setCreationDate(depBean.getCreationDate());
            setLastModifiedDate(depBean.getLastModifiedDate());
	    setEnvOrderId(depBean.getEnvOrderId());
        }
        catch (SQLException e)
        {
            e.printStackTrace();
            setStatusCode(InvErrorCode.ERROR_GET_DETAILS_BY_DEPARTMENT_ID);
            return false;
        }

        setStatusCode(InvErrorCode.SUCCESS);
        return true;
    }

    public boolean getDepartmentDetailsByDepartmentName()
    {
        log.info("Entering Department::getDepartmentDetailsByDepartmentName");

        try
        {
            TblDepartmentQuery depQry = new TblDepartmentQuery();
            depQry.whereDepartmentNameEQ(getDepartmentName());
            depQry.whereActiveIndEQ(1);
            depQry.query(connection);
            if (depQry.size() <= 0)
            {
                log.info("Department Name not Found");
                return false;
            }
            TblDepartmentDbBean depBean = depQry.getDbBean(0);
            setDepartmentId(depBean.getDepartmentId());
            setEnterpriseId(depBean.getEnterpriseId());
            setParentDeptId(depBean.getParentDeptId());
            setDepartmentName(depBean.getDepartmentName());
            setContactNumber(depBean.getContactNumber());
            setContactName(depBean.getContactName());
            setCallingPlanId(depBean.getCallingPlanId());
            setActiveInd(depBean.getActiveInd());
            setCreatedBy(depBean.getCreatedBy());
            setModifiedBy(depBean.getModifiedBy());
            setCreationDate(depBean.getCreationDate());
            setLastModifiedDate(depBean.getLastModifiedDate());
	    setEnvOrderId(depBean.getEnvOrderId());
        }
        catch (SQLException e)
        {
            e.printStackTrace();
            setStatusCode(InvErrorCode.ERROR_GET_DETAILS_BY_DEPARTMENT_NAME);
            return false;
        }

        setStatusCode(InvErrorCode.SUCCESS);
        return true;
    }

    public boolean isDepartmentTiedToGroups()
    {
        try
        {
            // check if the department is associated to a Group (PBX/Key)
            TblGroupQuery qry = new TblGroupQuery();
            String whereClause = " where department_id = " + getDepartmentId();
            qry.queryByWhere(connection, whereClause);
            if (qry.size() <= 0)
            {
                log.info("Department Id [" + getDepartmentId() + "] not found in tbl_group");
            } else
            {
                log.info("Department Id [" + getDepartmentId() + "] found in tbl_group");
		setLogTrail("Department::isDepartmentTiedToGroups :: Department Tied To Group");
                return true;
            }
        }
        catch (SQLException e)
        {
            e.printStackTrace();
            setStatusCode(InvErrorCode.DB_EXCEPTION);
            return false;
        }

        return false;
    }

    public boolean isDepartmentTiedToPublicTNPool()
    {
        try
        {
            // check if the department is associated to a Public TN Pool
            TblPublicTnPoolQuery qry = new TblPublicTnPoolQuery();
            String whereClause = " where department_id = " + getDepartmentId();
            qry.queryByWhere(connection, whereClause);
            if (qry.size() <= 0)
            {
                log.info("Department Id [" + getDepartmentId() + "] not associated to Public TN Pool");
            } else
            {
                log.info("Department Id [" + getDepartmentId() + "] associated to Public TN Pool");
		setLogTrail("Department::isDepartmentTiedToPublicTNPool :: Department Tied To PublicTNPool");
                return true;
            }
        }
        catch (SQLException e)
        {
            e.printStackTrace();
            setStatusCode(InvErrorCode.DB_EXCEPTION);
            return false;
        }

        return false;
    }

    public boolean isDepartmentTiedToSubscriber()
    {
        try
        {
            // check if the department is associated to a subscriber
            TblSubscriberQuery qry = new TblSubscriberQuery();
            String whereClause = " where department_id = " + getDepartmentId();
            qry.queryByWhere(connection, whereClause);
            if (qry.size() <= 0)
            {
                log.info("Department Id [" + getDepartmentId() + "] not associated to Subscriber");
            } else
            {
                log.info("Department Id [" + getDepartmentId() + "] associated to Subscriber");
		setLogTrail("Department::isDepartmentTiedToSubscriber :: Department Tied To Subscriber");
                return true;
            }
        }
        catch (SQLException e)
        {
            e.printStackTrace();
            setStatusCode(InvErrorCode.DB_EXCEPTION);
            return false;
        }

        return false;
    }

    public boolean isDepartmentTiedToDeviceMap()
    {
        try
        {
            // check if the department is associated to a device
            TblDeviceMapQuery qry = new TblDeviceMapQuery();
            String whereClause = " where department_id = " + getDepartmentId();
            qry.queryByWhere(connection, whereClause);
            if (qry.size() <= 0)
            {
                log.info("Department Id [" + getDepartmentId() + "] not associated to Device");
            } else
            {
                log.info("Department Id [" + getDepartmentId() + "] associated to Device");
		setLogTrail("Department::isDepartmentTiedToDevicer :: Department Tied To Device");
                return true;
            }
        }
        catch (SQLException e)
        {
            e.printStackTrace();
            setStatusCode(InvErrorCode.DB_EXCEPTION);
            return false;
        }

        return false;
    }

    /**
     * The method to get the map of Subscriber_Id to Sip Domain for a specified Department.
     * 
     * @return				Map of Subscriber_Id to Sip Domain
     * @throws SQLException	Thrown when any DB error occurs.
     * @author banala
     */
    public Map<String, String> getSubIdAndSipDomainMapByDepartmentId() throws SQLException{
    	Map<String, String> mapSubId2SipDomain = null;
    	PreparedStatement pStmt = null;
		ResultSet rs = null;

    	/*
    	 * For a given department _id first retrieve all the subscribers from tbl_subscriber.
    	 * In subscriber table u will get subId and location Id, with that location Id 
    	 * retrieve the sipDomain from tbl_location.
    	 */
    	String sql = "select s.SUB_ID, l.SIP_DOMAIN from TBL_SUBSCRIBER s, TBL_LOCATION l " +
				" where s.LOCATION_ID = l.LOCATION_ID and s.DEPARTMENT_ID = ? ";

		setLogTrail("Department::getSubIdAndSipDomainMapByDepartmentId :: SQL >> " + sql);
		setLogTrail("Department::getSubIdAndSipDomainMapByDepartmentId :: DEPARTMENT_ID >> " + departmentId);

		try {
			pStmt = connection.prepareStatement(sql);

			if ( pStmt != null ) {
				pStmt.setString(1, departmentId);
				rs = pStmt.executeQuery();
			}

			if ( rs != null ){
				mapSubId2SipDomain = new HashMap<String, String>();

				while (rs.next()) {
					mapSubId2SipDomain.put(rs.getString(1), rs.getString(2));		        	  
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw e;
		} finally {
			releaseResource(pStmt, rs);
		}

    	return mapSubId2SipDomain;
    }

	public Map<String, String> getBsSubIdAndSipDomainMapByDepartmentId() throws SQLException{
        Map<String, String> mapSubId2SipDomain = null;
        PreparedStatement pStmt = null;
        ResultSet rs = null;
                                  
        /*
         * For a given department _id first retrieve all the subscribers from tbl_subscriber.
         * In subscriber table u will get subId and location Id, with that location Id
         * retrieve the sipDomain from tbl_location.
         */
        String sql = "select s.BS_SUB_ID, l.SIP_DOMAIN from TBL_SUBSCRIBER s, TBL_LOCATION l " +
                " where s.LOCATION_ID = l.LOCATION_ID and s.DEPARTMENT_ID = ? ";
                                  
        setLogTrail("Department::getSubIdAndSipDomainMapByDepartmentId :: SQL >> " + sql);
        setLogTrail("Department::getSubIdAndSipDomainMapByDepartmentId :: DEPARTMENT_ID >> " + departmentId);
                                  
        try {
            pStmt = connection.prepareStatement(sql);
                                  
            if ( pStmt != null ) {
                pStmt.setString(1, departmentId);
                rs = pStmt.executeQuery();
            }
                                  
            if ( rs != null ){
                mapSubId2SipDomain = new HashMap<String, String>();
                                  
                while (rs.next()) {
					String bsSubId  = rs.getString(1);
					if(bsSubId != null || !bsSubId.equals(""))
                    	mapSubId2SipDomain.put(bsSubId, rs.getString(2));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw e;
        } finally {
            releaseResource(pStmt, rs);
        }
                                  
        return mapSubId2SipDomain;
	}

    /**
     * The method to get the map of TN to Sip Domain for a specified Department.
     * 
     * @return				Map of TN to Sip Domain
     * @throws SQLException	Thrown when any DB error occurs.
     * @author banala
     */
    public Map<String, String> getGroupTnAndSipDomainMapByDepartmentId() throws SQLException{
    	Map<String, String> mapTn2SipDomain = null;
    	PreparedStatement pStmt = null;
		ResultSet rs = null;

    	/*
    	 * For a given department _id first you have to retrieve all the tns from 
    	 * tbl_group->tbl_group_tn->tbl_public_tn_pool. In tbl_group table u will get
    	 * location Id, with that location Id retrieve the sipDomain from tbl_location.
    	 */
		String sql = " select x.tn, l.SIP_DOMAIN from TBL_LOCATION l, " +
				" (select ptp.tn, g.location_id from tbl_group g, tbl_group_tn gtn, tbl_public_tn_pool ptp " +
				" where g.GROUP_ID = gtn.GROUP_ID and gtn.TN_POOL_ID = ptp.TN_POOL_ID and g.DEPARTMENT_ID=? ) x " +
				" where l.LOCATION_ID = x.location_id";

		setLogTrail("Department::getGroupTnAndSipDomainMapByDepartmentId :: SQL >> " + sql);
		setLogTrail("Department::getGroupTnAndSipDomainMapByDepartmentId :: DEPARTMENT_ID >> " + departmentId);

		try {
			pStmt = connection.prepareStatement(sql);
			
			if ( pStmt != null ) {
				pStmt.setString(1, departmentId);
				rs = pStmt.executeQuery();
			}

			if ( rs != null ){
				mapTn2SipDomain = new HashMap<String, String>();

				while (rs.next()) {
					mapTn2SipDomain.put(rs.getString(1), rs.getString(2));		        	  
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw e;
		} finally {
			releaseResource(pStmt, rs);
		}
    	return mapTn2SipDomain;
    }

	/**
	 * The method to release the SQL resources.
	 * @param stmt	The Statement to be Closed
	 * @param rs	The Result Set to be Closed
	 * @author banala
	 */
	private void releaseResource(Statement stmt, ResultSet rs) {
		try {
			if ( stmt != null ) {
				stmt.close();
			}
			if ( rs != null ){
				rs.close();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
