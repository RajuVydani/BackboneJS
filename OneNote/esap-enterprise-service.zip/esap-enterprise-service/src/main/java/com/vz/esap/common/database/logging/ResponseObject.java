package com.vz.esap.common.database.logging;

public class ResponseObject {
	public final static int SUCCESS = 0;
	public final static int FAILURE = 1;
	
	int statusCode;
	public int getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(int statusCode) {
		this.statusCode = statusCode;
	}
	public String getStatusDescription() {
		return statusDescription;
	}
	public void setStatusDescription(String statusDescription) {
		this.statusDescription = statusDescription;
	}
	String statusDescription;
}
