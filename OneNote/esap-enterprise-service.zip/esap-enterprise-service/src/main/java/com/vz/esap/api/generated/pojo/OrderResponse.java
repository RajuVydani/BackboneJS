
package com.vz.esap.api.generated.pojo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "entityGroupInfo",
    "OrderHeader",
    "statusCode",
    "statusDescription"
})
public class OrderResponse {

    @JsonProperty("entityGroupInfo")
    private List<EntityGroupInfo> entityGroupInfo = new ArrayList<EntityGroupInfo>();
    @JsonProperty("OrderHeader")
    private OrderHeader_ orderHeader;
    @JsonProperty("statusCode")
    private String statusCode;
    @JsonProperty("statusDescription")
    private String statusDescription;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("entityGroupInfo")
    public List<EntityGroupInfo> getEntityGroupInfo() {
        return entityGroupInfo;
    }

    @JsonProperty("entityGroupInfo")
    public void setEntityGroupInfo(List<EntityGroupInfo> entityGroupInfo) {
        this.entityGroupInfo = entityGroupInfo;
    }

    @JsonProperty("OrderHeader")
    public OrderHeader_ getOrderHeader() {
        return orderHeader;
    }

    @JsonProperty("OrderHeader")
    public void setOrderHeader(OrderHeader_ orderHeader) {
        this.orderHeader = orderHeader;
    }

    @JsonProperty("statusCode")
    public String getStatusCode() {
        return statusCode;
    }

    @JsonProperty("statusCode")
    public void setStatusCode(String statusCode) {
        this.statusCode = statusCode;
    }

    @JsonProperty("statusDescription")
    public String getStatusDescription() {
        return statusDescription;
    }

    @JsonProperty("statusDescription")
    public void setStatusDescription(String statusDescription) {
        this.statusDescription = statusDescription;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(entityGroupInfo).append(orderHeader).append(statusCode).append(statusDescription).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof OrderResponse) == false) {
            return false;
        }
        OrderResponse rhs = ((OrderResponse) other);
        return new EqualsBuilder().append(entityGroupInfo, rhs.entityGroupInfo).append(orderHeader, rhs.orderHeader).append(statusCode, rhs.statusCode).append(statusDescription, rhs.statusDescription).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
