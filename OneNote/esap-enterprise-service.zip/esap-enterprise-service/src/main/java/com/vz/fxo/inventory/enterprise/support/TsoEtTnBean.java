package com.vz.fxo.inventory.enterprise.support; 
 
import java.io.Serializable;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
 
public class TsoEtTnBean implements Serializable { 
     
    protected long etTnId; 
    protected long enterpriseTrunkId; 
    protected long tnPoolId; 
    protected String extension; 
    protected String privateNumber; 
    protected String clidFirstName; 
    protected String clidLastName; 
    protected long vmMaxsizeId; 
    protected String vmBoxNum; 
    protected long activeInd; 
    protected int envOrderId; 
    protected String subId; 
    protected int pitSipTrxId; 
    protected String createdBy; 
    protected Timestamp creationDate; 
    protected String modifiedBy; 
    protected Timestamp lastModifiedDate; 
    protected List<TsoEtTnFeaturesBean> etTnFeaturesList; 
    protected List<FeaturesBean> etTnExclFeaturesList; 
    protected PublicTnPoolBean publicTnPoolObj; 
    protected List<String> logTrail; 
    protected SubscriberBean subscriberBeanObj; 
     
    public  TsoEtTnBean(){ 
        this.etTnId = 0; 
        this.enterpriseTrunkId = 0; 
        this.tnPoolId = 0; 
        this.extension = new String("NONE"); 
        this.privateNumber = new String("NONE"); 
        this.clidFirstName = new String("NONE"); 
        this.clidLastName = new String("NONE"); 
        this.vmMaxsizeId = -1; 
        this.vmBoxNum = new String("NONE"); 
        this.activeInd = 1; 
        this.envOrderId = 0; 
        this.subId = new String("NONE"); 
        this.pitSipTrxId = -1; 
        this.createdBy = new String(""); 
        this.creationDate = null; 
        this.modifiedBy = new String(""); 
        this.lastModifiedDate = null; 
        this.logTrail = null; 
        this.etTnExclFeaturesList = null; 
        logTrail = new ArrayList<String>(); 
        this.publicTnPoolObj = null; 
        etTnExclFeaturesList = new ArrayList<FeaturesBean>(); 
        publicTnPoolObj = new PublicTnPoolBean(); 
        this.subscriberBeanObj = new SubscriberBean(); 
        this.etTnFeaturesList = new ArrayList<TsoEtTnFeaturesBean>(); 
    } 
     
    public  TsoEtTnBean(TsoEtTnBean tsoEtTnBean){ 
         
        this.etTnId = tsoEtTnBean.etTnId; 
        this.enterpriseTrunkId = tsoEtTnBean.enterpriseTrunkId; 
        this.tnPoolId = tsoEtTnBean.tnPoolId; 
        this.extension = tsoEtTnBean.extension; 
        this.privateNumber = tsoEtTnBean.privateNumber; 
        this.clidFirstName = tsoEtTnBean.clidFirstName; 
        this.clidLastName = tsoEtTnBean.clidLastName; 
        this.vmMaxsizeId = tsoEtTnBean.vmMaxsizeId; 
        this.vmBoxNum = tsoEtTnBean.vmBoxNum; 
        this.activeInd = tsoEtTnBean.activeInd; 
        this.envOrderId = tsoEtTnBean.envOrderId; 
        this.subId = tsoEtTnBean.subId; 
        this.pitSipTrxId = tsoEtTnBean.pitSipTrxId; 
        this.createdBy=tsoEtTnBean.createdBy; 
        this.creationDate=tsoEtTnBean.creationDate; 
        this.modifiedBy=tsoEtTnBean.modifiedBy; 
        this.lastModifiedDate=tsoEtTnBean.lastModifiedDate; 
        this.etTnExclFeaturesList = tsoEtTnBean.etTnExclFeaturesList; 
        this.publicTnPoolObj = tsoEtTnBean.publicTnPoolObj; 
        this.logTrail = tsoEtTnBean.logTrail; 
        this.subscriberBeanObj = tsoEtTnBean.subscriberBeanObj; 
        this.etTnFeaturesList = tsoEtTnBean.etTnFeaturesList; 
    } 
     
    public SubscriberBean getSubscriberBeanObj() 
    { 
        return subscriberBeanObj; 
    } 
 
    public void setSubscriberBeanObj(SubscriberBean subscriberBeanObj) 
    { 
        this.subscriberBeanObj = subscriberBeanObj; 
    } 
     
    public void setLogTrail(String logStr) 
    { 
        logTrail.add(logStr); 
    } 
 
    
    public long getEtTnId() { 
        return etTnId; 
    } 
 
    public void setEtTnId(long etTnId) { 
        this.etTnId = etTnId; 
    } 
 
    public long getEnterpriseTrunkId() { 
        return enterpriseTrunkId; 
    } 
 
    public void setEnterpriseTrunkId(long enterpriseTrunkId) { 
        this.enterpriseTrunkId = enterpriseTrunkId; 
    } 
 
    public long getTnPoolId() { 
        return tnPoolId; 
    } 
 
    public void setTnPoolId(long tnPoolId) { 
        this.tnPoolId = tnPoolId; 
    } 
 
    public String getExtension() { 
        return extension; 
    } 
 
    public void setExtension(String extension) { 
        this.extension = extension; 
    } 
 
    public String getPrivateNumber() { 
        return privateNumber; 
    } 
 
    public void setPrivateNumber(String privateNumber) { 
        this.privateNumber = privateNumber; 
    } 
 
    public String getClidFirstName() { 
        return clidFirstName; 
    } 
 
    public void setClidFirstName(String clidFirstName) { 
        this.clidFirstName = clidFirstName; 
    } 
 
    public String getClidLastName() { 
        return clidLastName; 
    } 
 
    public void setClidLastName(String clidLastName) { 
        this.clidLastName = clidLastName; 
    } 
 
    public long getVmMaxsizeId() { 
        return vmMaxsizeId; 
    } 
 
    public void setVmMaxsizeId(long vmMaxsizeId) { 
        this.vmMaxsizeId = vmMaxsizeId; 
    } 
 
    public String getVmBoxNum() { 
        return vmBoxNum; 
    } 
 
    public void setVmBoxNum(String vmBoxNum) { 
        this.vmBoxNum = vmBoxNum; 
    } 
 
    public long getActiveInd() { 
        return activeInd; 
    } 
 
    public void setActiveInd(long activeInd) { 
        this.activeInd = activeInd; 
    } 
 
    public int getEnvOrderId() { 
        return envOrderId; 
    } 
 
    public void setEnvOrderId(int envOrderId) { 
        this.envOrderId = envOrderId; 
    } 
 
    public String getSubId() { 
        return subId; 
    } 
 
    public void setSubId(String subId) { 
        this.subId = subId; 
    } 
 
    public int getPitSipTrxId() { 
        return pitSipTrxId; 
    } 
 
    public void setPitSipTrxId(int pitSipTrxId) { 
        this.pitSipTrxId = pitSipTrxId; 
    } 
 
    public String getCreatedBy() { 
        return createdBy; 
    } 
 
    public void setCreatedBy(String createdBy) { 
        this.createdBy = createdBy; 
    } 
 
    public Timestamp getCreationDate() { 
        return creationDate; 
    } 
 
    public void setCreationDate(Timestamp creationDate) { 
        this.creationDate = creationDate; 
    } 
 
    public String getModifiedBy() { 
        return modifiedBy; 
    } 
 
    public void setModifiedBy(String modifiedBy) { 
        this.modifiedBy = modifiedBy; 
    } 
 
    public Timestamp getLastModifiedDate() { 
        return lastModifiedDate; 
    } 
 
    public void setLastModifiedDate(Timestamp lastModifiedDate) { 
        this.lastModifiedDate = lastModifiedDate; 
    } 
 
    public List<TsoEtTnFeaturesBean> getEtTnFeaturesList() { 
        return etTnFeaturesList; 
    } 
 
    public void setEtTnFeaturesList(List<TsoEtTnFeaturesBean> etTnFeaturesList) { 
        this.etTnFeaturesList = etTnFeaturesList; 
    } 
 
    public List<FeaturesBean> getEtTnExclFeaturesList() { 
        return etTnExclFeaturesList; 
    } 
 
    public void setEtTnExclFeaturesList( 
            List<FeaturesBean> etTnExclFeaturesList) { 
        this.etTnExclFeaturesList = etTnExclFeaturesList; 
    } 
 
    public PublicTnPoolBean getPublicTnPoolObj() { 
        return publicTnPoolObj; 
    } 
 
    public void setPublicTnPoolObj(PublicTnPoolBean publicTnPoolObj) { 
        this.publicTnPoolObj = publicTnPoolObj; 
    } 
 
    public List<String> getLogTrail() { 
        return logTrail; 
    } 
 
    public void setLogTrail(List<String> logTrail) { 
        this.logTrail = logTrail; 
    } 
 
} 

