/**
 * PasswordUtil.java
 *
 * Description: This class helps you to generate a password with a given seed
 */

package com.vz.esap.api.connector.util;

import java.security.*;
import java.io.ByteArrayOutputStream;

public class PasswordUtil 
{
    private static String md5Space = "Iqe1NETOiLVdP7nHcyY9vz4xh8J03uZ56CXgSm2MjlKwDoApfGFRaBWQbrUkl";
    private static String passwdSpace = new String(getPasswdSpace());

    static int noOfAlpha = 3;
    static int noOfNumeric = 2;

    private static byte[] getPasswdSpace() 
    {
        ByteArrayOutputStream bao = new ByteArrayOutputStream();
        for (byte i = 'a'; i <= 'z'; i++)
            bao.write(i);
        for (byte i = '0'; i <= '9'; i++)
            bao.write(i);
        for (byte i = 'A'; i <= 'Z'; i++)
            bao.write(i);
        for (byte i = 'a'; i <= 'z'; i++)
            bao.write(i);
        return bao.toByteArray();
    }

    public static String getMd5Password(String seed) 
    {
        MessageDigest md = null;

        try 
        {
            md = MessageDigest.getInstance("MD5");
        }
        catch (Exception e) 
        {
            e.printStackTrace();
            return new String(seed);
        }

        byte[] digestVal = md.digest(seed.getBytes());
        byte[] hexBytes = new byte[32];
        convertHex(digestVal, hexBytes);
        StringBuffer pwdsb = new StringBuffer();

        // convert sum of 4 hex digits to char
        for (int i = 0; i < 8; i++) 
        {
            int sum = hexBytes[i] + hexBytes[i + 8] + hexBytes[i + 16] + hexBytes[i + 24];
            pwdsb.append(md5Space.charAt(sum)); // convert the sum to a String Character
        }
        return pwdsb.toString();
    }

    public static String getSha1Password(String seed) 
    {
        MessageDigest md = null;

        try 
        {
            md = MessageDigest.getInstance("SHA-1");
        }
        catch (Exception e) 
        {
            e.printStackTrace();
            return new String(seed);
        }

        byte[] digestVal = md.digest(seed.getBytes());
        byte[] hexBytes = new byte[40];

        // printHex(digestVal);
        // convert hex to individual digits
        convertHex(digestVal, hexBytes);
        StringBuffer pwdsb = new StringBuffer();

        // convert sum of 5 hex digits to char
        for (int i = 0; i < 8; i++) 
        {
            int sum = hexBytes[i] + hexBytes[i + 8] + hexBytes[i + 16] + hexBytes[i + 24] + hexBytes[i + 32];
            pwdsb.append(passwdSpace.charAt(sum)); // convert the sum to a String Character
        }
        return pwdsb.toString();
    }

    private static void convertHex(byte[] val, byte[] hexBytes) 
    {
        int k = 0;

        // convert hex to individual digits
        for (int i = 0; i < val.length; i++) 
        {
            byte b = val[i];
            hexBytes[k++] = (byte) ((b & 0xf0) >> 4);
            hexBytes[k++] = (byte) (b & 0x0f);
        }
    }

    public static void main(String argv[])
    {
        //System.out.println("SHA-1 password:" + getSha1Password(argv[0]));
        //System.out.println("MD5 password:" + getMd5Password(argv[0]));
    }
}


