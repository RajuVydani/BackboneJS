/**
 * File: VZB_INV_DEL_ENTERPRISE.java
 *
 * Author: Anand A. Ranade
 *
 * Modified by:
 *
 */

package com.vz.fxo.inventory.enterprise.actionfunction;

import java.sql.SQLException;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.vz.esap.api.model.ESAPEntityEnum;
import com.vz.esap.api.model.dto.OrderDomainServiceDTO;
import com.vz.esap.api.model.ordering.EntityBatch;
import com.vz.esap.api.model.ordering.EntityData;
import com.vz.esap.api.model.ordering.TableOrderDetailsParam;
import com.vz.fxo.inventory.enterprise.support.Enterprise;
import com.vz.fxo.inventory.enterprise.support.VzbInvException;
import com.vz.fxo.inventory.enterprise.GenericActionFunction;
import com.vz.fxo.inventory.enterprise.helper.ActionFunctionHelper;
import com.vz.fxo.inventory.enterprise.helper.EnterpriseHelper;

import EsapEnumPkg.VzbVoipEnum;

public class VZB_INV_DEL_ENTERPRISE_FXO extends GenericActionFunction {

	private static Logger log = LoggerFactory.getLogger(VZB_INV_DEL_ENTERPRISE_FXO.class.toString());
    // Added Helper class to get code coverage for new keyword scenario
	private EnterpriseHelper enterpriseHelper = new EnterpriseHelper();
    Enterprise enterprise = null;
	@Override
	public int go() {
		log.info("Task VZB_INV_DEL_ENTERPRISE Started WorkOrderNumber : {}", this.workOrderNumber);
		try {
			OrderDomainServiceDTO domainServiceDTO = getOrderDomainDetail(ESAPEntityEnum.ENTERPRISE);
			Map<String, EntityBatch> entityTypeMap = domainServiceDTO.getEntityTypeMap();
			EntityBatch entityBatch = entityTypeMap.get(ESAPEntityEnum.ENTERPRISE.toString());

			enterpriseId = ActionFunctionHelper.getEnterpriseId(entityBatch);
			ActionFunctionHelper.checkForNull("EnterpriseId", enterpriseId);

			Map<String, EntityData> entityMap = entityBatch.getEntity();
			EntityData entityData = entityMap.entrySet().iterator().next().getValue();

		//	Enterprise enterprise = new Enterprise(connection);
			 // Added to get code coverage for new keyword scenario
			enterprise = enterpriseHelper.getEnterprise(connection);

			enterprise.setEnterpriseId(enterpriseId);
			enterprise.setCustomerId(enterpriseId);

			String orgSystem = null;
			TableOrderDetailsParam orgSystemParam = ActionFunctionHelper.getTableOrderDetaisParam(entityData,
					"OriginatingSystem");
			if (!(orgSystemParam == null))
				orgSystem = orgSystemParam.getParamValue();

			if (orgSystem!=null &&  !orgSystem.equals("CSSOP")) {
				TableOrderDetailsParam rollbackParam = ActionFunctionHelper.getTableOrderDetaisParam(entityData,
						"ROLLBACK");
				if (!(rollbackParam == null))
					enterprise.setRollbackFlag(true);
			}
			if (envOrderId != null) {
				enterprise.setEnvOrderId(Long.valueOf(envOrderId));
			}
			/**
			 * delete CallingPlanId delete gateway device from device table
			 * delete dial plan update enterprise update customer
			 */
			insertOrderLog("Deleting Enterprise from ESAP inventory");
		//	if (enterprise.deleteFromDB()) {
		 if (enterprise.deleteNonTsoFromDB()) {
				
				// insertOrderLog(INV_SUCCESS, "Successfully deleted Enterprise
				// from ESAP inventory");
				log.info("Successfully deleted Enterprise from ESAP inventory");
				insertOrderLog("Successfully deleted Enterprise from ESAP inventory");
			} else {
				log.error("Inventory Base Returned Error <{}", enterprise.getStatusDesc(), ">");
				insertOrderLog("Inventory Base Returned Error ::" + enterprise.getStatusDesc() + "::");
				throw new VzbInvException("ESP_VZB_INV_DEL_ENTERPRISE_FAILED", "ESP_VZB_INV_DEL_ENTERPRISE_FAILED");
			}
			/**
			 * VoIP TSO Migration
			 */
			String entityName = "Enterprise";
			String entityType = String.valueOf(VzbVoipEnum.OrderEntity.ENTERPRISE);
			ActionFunctionHelper.updateEntMigration(entityName, entityType, enterpriseId, connection);
			ActionFunctionHelper.deleteTnETMapTbl(enterpriseId, connection);
			connection.commit();

		} catch (VzbInvException e) {
			log.error("Exception:{}"+e.getMessage());
			try {
				connection.rollback();
			} catch (Exception e1) {
				log.error("Exception:{}"+e1.getMessage());
			}
			insertOrderLogError("VZB_INV_DEL_ENTERPRISE:VzbInvException"+e.getMessage());
			insertOrderLog("VzbInvException "+ e.getMessage());
			logFinalMessage = e.getMessage();
			logSucessFail = false;
			handleActionFunctionError(e.getMessage(), e.getMessage());
			return INV_FAILURE;
		} catch (SQLException e) {
			log.error("SQLException:{}"+e.getMessage());
			try {
				connection.rollback();
			} catch (Exception e1) {
				log.error("Exception:{}"+e1.getMessage());
			}
			insertOrderLogError("VZB_INV_DEL_ENTERPRISE:SQLException"+e.getMessage());
			insertOrderLog("SQLException "+ e.getMessage());
			logFinalMessage = e.getMessage();
			logSucessFail = false;
			log.error("In VZB_INV_DEL_ENTERPRISE e.getErrorCode():" + e.getErrorCode());
			if (e.getErrorCode() == -60)
				handleActionFunctionError("ESP_VZB_INV_DEADLOCK", e.getMessage());
			else
				handleActionFunctionError("ESP_VZB_INV_DEL_ENTERPRISE_FAILED", e.getMessage());
			return INV_FAILURE;
		}

		catch (Exception e) {
			log.error("Exception:{}"+e.getMessage());
			try {
				connection.rollback();
			} catch (Exception e1) {
				log.error("Exception:{}"+e1.getMessage());
			}
			insertOrderLogError("VZB_INV_DEL_ENTERPRISE:Exception"+e.getMessage());
			insertOrderLog("Exception "+ e.getMessage());
			logFinalMessage = e.getMessage();
			logSucessFail = false;
			handleActionFunctionError("ESP_VZB_INV_DEL_ENTERPRISE_FAILED", e.getMessage());
			return INV_FAILURE;
		} finally {
			addLogMessageToDb();
			if (logSucessFail){
				log.info("Task - VZB_INV_DEL_ENTERPRISE  completed successfully");
				insertOrderLog("Task - VZB_INV_DEL_ENTERPRISE  completed successfully");
			}
			else{
				log.error("final log:{}",logFinalMessage);
				insertOrderLog(logFinalMessage);
			}
		}

		return INV_SUCCESS;
	}

}
