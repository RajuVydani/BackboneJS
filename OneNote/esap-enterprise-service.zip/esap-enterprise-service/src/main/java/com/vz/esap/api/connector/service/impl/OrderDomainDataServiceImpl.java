/**
 * 
 */
package com.vz.esap.api.connector.service.impl;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.vz.esap.api.connector.util.DomainInterfaceUtil;
import com.vz.esap.api.constant.ESAPDBQueryEnum;
import com.vz.esap.api.exception.ApplicationInterfaceException;
import com.vz.esap.api.generated.pojo.DBOperationRequest;
import com.vz.esap.api.generated.pojo.DBOperationResponse;
import com.vz.esap.api.generated.pojo.DatabaseServiceRequest;
import com.vz.esap.api.generated.pojo.DatabaseServiceResponse;
import com.vz.esap.api.generated.pojo.OrderRequest;
import com.vz.esap.api.generated.pojo.OrderResponse;
import com.vz.esap.api.generated.pojo.TblFailEntityInfo;
import com.vz.esap.api.generated.pojo.WhereClause;
import com.vz.esap.api.model.DBServiceResponse;
import com.vz.esap.api.model.FailEntityInfo;
import com.vz.esap.api.model.OrderDomainServiceRequest;
import com.vz.esap.api.model.ResponseObject;
import com.vz.esap.api.model.TblRow;
import com.vz.esap.api.model.dto.OrderDomainServiceDTO;
import com.vz.esap.api.service.model.EnitityEnum;
import com.vz.esap.api.service.model.TblEnvOrderCallHeader;
import com.vz.esap.api.service.model.TblOrderCallHeader;

import EsapEnumPkg.EntityEnum;
import esap.db.TblEnvOrderDbBean;
import esap.db.TblOrderDbBean;

/**
 * @author Aricent
 * 
 */
@Service
public class OrderDomainDataServiceImpl  {

	private static final Logger logger = LoggerFactory.getLogger(OrderDomainDataServiceImpl.class);
	private static final String ORDERING_DOMAIN_SERVICE = "OrderingDomainService:";
	private ObjectMapper mapper = new ObjectMapper();
	
	private DomainInterfaceUtil domainInterfaceUtil = DomainInterfaceUtil.getDomainInterfaceUtil();
	
	//@Autowired
	private RestTemplate restTemplate = new RestTemplate();

	@Value("${orderDomain.getOrderDetails}") 
	private String orderDomainServiceBaseURL;
	//private String orderDomainServiceBaseURL = "http://pbxomzstd03.vzbi.com:40046/ordering";
	
	@Value("${orderDomain.databaseService}") 
	private String orderDomainDBServiceBaseURL;
	// private String orderDomainDBServiceBaseURL = "http://pbxomzstd03.vzbi.com:40043/dataBase";
	
	
	@Value("${orderDomain.falloutService}") 
	private String orderDomainFalloutServiceBaseURL;
	// private String orderDomainFalloutServiceBaseURL = "http://pbxomzstd03.vzbi.com:40047/fallout";
	
	public OrderDomainServiceDTO getOrderDomainData(OrderDomainServiceRequest requestDTO, boolean isParamDetailMapView)
			throws ApplicationInterfaceException {
		String workOrderNumber = requestDTO.getOrderHeader().getWorkOrderNumber();
		logger.info("Entering getOrderDomainData(): {} ", workOrderNumber);
		logger.info("getOrderDomainData(): isParamDetailMapView: {} ", isParamDetailMapView);

		OrderDomainServiceDTO responseDTO = null;
		final String orderDomainServiceURL = orderDomainServiceBaseURL.concat("/getOrderDetails");

		try {

		
			OrderRequest requestView = domainInterfaceUtil.transformRequestDTOToView(requestDTO);
			
			logger.info("getOrderDomainData(): Request Message: {}", mapper.writerWithDefaultPrettyPrinter().writeValueAsString(requestView));
			
			long startTime = System.currentTimeMillis();
			logger.info("getOrderDomainData(): Making HTTP POST Request for workOrderNumber:{} at time:{}",
					workOrderNumber, startTime);
			logger.info("getOrderDomainData(): Service URL: {}", orderDomainServiceURL);
			logger.info("getOrderDomainData(): Service restTemplate: {}", restTemplate);
		
			//Replaced postForObject to exchange for data swap issue
			
			/*OrderResponse orderResponse = restTemplate.postForObject(orderDomainServiceURL, requestView,
					OrderResponse.class);*/
			
			HttpEntity<OrderRequest> entity = new HttpEntity<OrderRequest>(requestView);
			ResponseEntity<OrderResponse> responseEntity = restTemplate.exchange(orderDomainServiceURL, HttpMethod.POST,
					entity, OrderResponse.class);
			OrderResponse orderResponse = responseEntity.getBody();


			long endTime = System.currentTimeMillis();

			logger.info("getOrderDomainData(): Received HTTP POST Response for workOrderNumber:{} at time:{}",
					workOrderNumber, endTime);
			logger.info("getOrderDomainData(): Time taken for Response for workOrderNumber:{} is:{} ms",
					workOrderNumber, endTime - startTime);

			if (orderResponse != null && !"0".equalsIgnoreCase(orderResponse.getStatusCode()))
				throw new ApplicationInterfaceException(ORDERING_DOMAIN_SERVICE + orderResponse.getStatusDescription());

			responseDTO = domainInterfaceUtil.transformResponseViewToDTO(orderResponse,isParamDetailMapView);

			logger.info("Exiting getOrderDomainData(): {} ", responseDTO.getOrderHeader().getWorkOrderNumber());

		} catch (HttpStatusCodeException e) {
			logger.error("Exception received from OrderDomain Service URL: {} ", orderDomainServiceURL);
			logger.error("Exception received from OrderDomain Service: {} ", e);
			logger.error("Execption during getOrderDomainData execution code:{} , text:{}", e.getStatusCode(),
					e.getResponseBodyAsString());
			throw new ApplicationInterfaceException(ORDERING_DOMAIN_SERVICE + e.getMessage());
		} catch (RestClientException e) {
			logger.error("Exception received from OrderDomain Service URL: {} ", orderDomainServiceURL);
			logger.error("Exception received from OrderDomain Service: {} ", e);
			throw new ApplicationInterfaceException(ORDERING_DOMAIN_SERVICE + e.getMessage());
		} catch (JsonProcessingException e) {
			logger.error("Exception received from OrderDomain Service URL: {} ", orderDomainServiceURL);
			logger.error("Exception received from OrderDomain Service: {} ", e);
			throw new ApplicationInterfaceException(ORDERING_DOMAIN_SERVICE + e.getMessage());
		}

		return responseDTO;
	}
	
	
	
	public OrderDomainServiceDTO getOrderDomainData(OrderDomainServiceRequest requestDTO) throws ApplicationInterfaceException {
		return getOrderDomainData(requestDTO,true);
	}
	public OrderDomainServiceDTO getOrderDomainDataWithAllAction(OrderDomainServiceRequest requestDTO) throws ApplicationInterfaceException {
		return getOrderDomainData(requestDTO,false);
	}
	
	public Long initTaskEntityStatus(String orderId) throws ApplicationInterfaceException {
		logger.info("Entering initTaskEntityStatus");
		Set<String> selectColumnSet = new HashSet<>();
		selectColumnSet.add("ENTITY_ID");

		ArrayList<String[]> whereClauseList = new ArrayList<>();
		whereClauseList.add(new String[] { "ORDER_ID", orderId });

		DBServiceResponse responseData = searchOrderingDomain("TBL_ORDER_TASK_ENTITY", selectColumnSet,
				whereClauseList);

		if (responseData == null) {
			throw new ApplicationInterfaceException("Null Response from Ordering DB Service");
		}

		Long numberOfRecords = responseData.getNumberOfRecords();
		logger.info("Exiting initTaskEntityStatus numberOfRecords: ", numberOfRecords);
		return numberOfRecords;
	}

	
	public void addTaskEntity(String orderId, String entityName, String status) throws ApplicationInterfaceException {
		logger.info("Entering addTaskEntity");
		List<String[]> insertKeyValuePairList = new ArrayList<>();
		insertKeyValuePairList.add(new String[] { "ORDER_ID", orderId });
		insertKeyValuePairList.add(new String[] { "ENTITY_NAME", entityName });
		insertKeyValuePairList.add(new String[] { "STATUS", status });

		List<String[]> sequenceColumnNameValueList = new ArrayList<>();
		sequenceColumnNameValueList.add(new String[] { "ENTITY_ID", "TBL_ORDER_TASK_ENTITY_SEQ" });

		long numberOfRecords = insertOrderingDomain("TBL_ORDER_TASK_ENTITY", insertKeyValuePairList,
				sequenceColumnNameValueList);
		logger.info("Exiting addTaskEntity, numberOfRecords" + numberOfRecords);

	}

	
	public String getTaskEntityStatus(String orderId, String entityName) throws ApplicationInterfaceException {
		logger.info("Entering getTaskEntityStatus");

		ArrayList<String[]> whereClause = new ArrayList<>();
		whereClause.add(new String[] { "PROCESS_NAME", orderId });
		whereClause.add(new String[] { "PARAM_NAME", entityName });

		String status = searchOrderingForSingleValue("TBL_ORDER_TASK_ENTITY", "STATUS", whereClause, String.class);

		return status;

	}

	
	public void deleteTaskEntity(String orderId, String entityName) throws ApplicationInterfaceException {
		logger.info("Entering deleteTaskEntity");
		List<String[]> whereClauseList = new ArrayList<>();
		whereClauseList.add(new String[] { "ORDER_ID", orderId });
		whereClauseList.add(new String[] { "ENTITY_NAME", entityName });
		Long numberOfRecords = deleteOrderingDomain("TBL_ORDER_TASK_ENTITY", whereClauseList);
		if (numberOfRecords == 0) {
			throw new ApplicationInterfaceException("Delete operation did not delete any record");
		}
		logger.info("Exiting deleteTaskEntity, numberOfRecords" + numberOfRecords);
	}

	
	public void addTaskEntity(String orderId, String entityName, String status, String existingStatus)
			throws ApplicationInterfaceException {
		logger.info("Entering addTaskEntity");

		if (status.equals(existingStatus)) {
			// No change in status; no need to update DB
			return;
		}
		if ("UNKNOWN".equals(existingStatus)) {
			logger.info("addTaskEntity, Unknown Status : adding task entity");
			addTaskEntity(orderId, entityName, status);
		} else {
			List<String[]> updateKeyValuePairList = new ArrayList<>();
			updateKeyValuePairList.add(new String[] { "STATUS", status });

			List<String[]> whereClauseList = new ArrayList<>();
			whereClauseList.add(new String[] { "ORDER_ID", orderId });
			whereClauseList.add(new String[] { "ENTITY_NAME", entityName });

			Long numOfRecords = updateOrderingDomain("TBL_ORDER_TASK_ENTITY", updateKeyValuePairList, whereClauseList);
			logger.info("addTaskEntity, Updated numberOfRecords" + numOfRecords);

		}

		logger.info("Exiting addTaskEntity");

	}
	
	
	/**
	 * @param tableName
	 * @param insertKeyValuePairList
	 * @param sequenceKeyValuePairList
	 * @return
	 * @throws ApplicationInterfaceException
	 */
	private Long insertOrderingDomain(String tableName, List<String[]> insertKeyValuePairList,
			List<String[]> sequenceKeyValuePairList) throws ApplicationInterfaceException {

		logger.info("Entering insertOrderingDomain(): {} ", tableName);
		final String insertOrderingDomainURL = orderDomainDBServiceBaseURL.concat("/databaseService");
		Long response = null;

		try {

			logger.debug("insertOrderingDomain(): Request Message: {}", tableName);
			DatabaseServiceRequest request = new DatabaseServiceRequest();
			request.setDbOperation("INSERT");
			request.setTableName(tableName);

			List<String> updateColumnNameList = new ArrayList<>();
			List<String> updateColumnValueList = new ArrayList<>();
			for (String[] updateKeyValuePairArray : insertKeyValuePairList) {
				updateColumnNameList.add(updateKeyValuePairArray[0]);
				updateColumnValueList.add(updateKeyValuePairArray[1]);
			}
			request.setColumnNames(updateColumnNameList);
			request.setColumnValues(updateColumnValueList);
			
			if (sequenceKeyValuePairList != null) {
				List<String> sequenceColumnNameList = new ArrayList<>();
				List<String> sequenceColumnValueList = new ArrayList<>();
				for (String[] sequenceKeyValueArray : sequenceKeyValuePairList) {
					sequenceColumnNameList.add(sequenceKeyValueArray[0]);
					sequenceColumnValueList.add(sequenceKeyValueArray[1]);
				}
				request.setSequenceColumnName(sequenceColumnNameList);
				request.setSequenceColumnValue(sequenceColumnValueList);
			}

			long startTime = System.currentTimeMillis();

			logger.info("insertOrderingDomain(): Making HTTP POST Request for workOrderNumber:{} at time:{}", tableName,
					startTime);
			logger.info("insertOrderingDomain(): Service URL: {}", insertOrderingDomainURL);
			logger.info("insertOrderingDomain(): Service request: {}",mapper.writerWithDefaultPrettyPrinter().writeValueAsString(request));

			DatabaseServiceResponse orderingDBServiceResponse = restTemplate
					.postForObject(insertOrderingDomainURL, request, DatabaseServiceResponse.class);

			long endTime = System.currentTimeMillis();

			if (orderingDBServiceResponse == null)
				throw new ApplicationInterfaceException("No Response Recieved from Order DB Service");
			
			response=orderingDBServiceResponse.getNumberOfRecords();

			logger.info("insertOrderingDomain(): Received HTTP POST Response for tableName:{} at time:{}", tableName,
					endTime);
			logger.info("insertOrderingDomain(): Time taken for Response for tableName:{} is:{} ms", tableName,
					endTime - startTime);
			logger.debug("insertOrderingDomain(): Response from OrderingDBService: {}", orderingDBServiceResponse);
			logger.info("Exiting insertOrderingDomain() ");

		} catch (HttpStatusCodeException e) {
			logger.error("Exception received from OrderingDBService Service URL: {} ", insertOrderingDomainURL);
			logger.error("Exception received from OrderingDBService Service: {} ", e);
			logger.error("Execption during insertOrderingDomain execution code:{} , text:{}", e.getStatusCode(), e.getResponseBodyAsString());
			throw new ApplicationInterfaceException(ORDERING_DOMAIN_SERVICE + e.getMessage());
		} catch (RestClientException e) {
			logger.error("Exception received from OrderingDBService Service URL: {} ",	insertOrderingDomainURL);
			logger.error("Exception received from OrderingDBService Service: {} ", e);
			throw new ApplicationInterfaceException(ORDERING_DOMAIN_SERVICE + e.getMessage());
		} catch (JsonProcessingException e) {
			logger.error("Exception received from OrderingDBService Service URL: {} ",	insertOrderingDomainURL);
			logger.error("Exception received from OrderingDBService Service: {} ", e);
			throw new ApplicationInterfaceException(ORDERING_DOMAIN_SERVICE + e.getMessage());
		}
		return response;
	}
	
	/**
	 * @param tableName
	 * @param whereClauseList
	 * @return
	 * @throws ApplicationInterfaceException
	 */
	private Long deleteOrderingDomain(String tableName, List<String[]> whereClauseList) throws ApplicationInterfaceException {

		logger.info("Entering deleteOrderingDomain(): {} ", tableName);
		final String deleteOrderingDomainURL = orderDomainDBServiceBaseURL.concat("/databaseService");
		Long response = null;

		try {

			logger.debug("deleteOrderingDomain(): Request Message: {}", tableName);
			DatabaseServiceRequest request = new DatabaseServiceRequest();
			request.setDbOperation("DELETE");
			request.setTableName(tableName);

			WhereClause whereClauseRequest = new WhereClause();

			List<String> whereClauseColumnName = new ArrayList<>();
			List<String> whereClauseColumnValue = new ArrayList<>();
			for (String[] whereClauseArray : whereClauseList) {
				whereClauseColumnName.add(whereClauseArray[0]);
				whereClauseColumnValue.add(whereClauseArray[1]);
			}
			whereClauseRequest.setColumnNames(whereClauseColumnName);
			whereClauseRequest.setColumnValues(whereClauseColumnValue);
			request.setWhereClause(Collections.singletonList(whereClauseRequest));

			long startTime = System.currentTimeMillis();
			logger.info("deleteOrderingDomain(): Making HTTP POST Request for workOrderNumber:{} at time:{}", tableName,
					startTime);
			logger.info("deleteOrderingDomain(): Service URL: {}", deleteOrderingDomainURL);
			logger.info("deleteOrderingDomain(): Service restTemplate: {}", restTemplate);

			DatabaseServiceResponse orderingDBServiceResponse = restTemplate.postForObject(deleteOrderingDomainURL,
					request, DatabaseServiceResponse.class);

			long endTime = System.currentTimeMillis();

			logger.info("OrderingDBService:" + orderingDBServiceResponse);

			if (orderingDBServiceResponse == null)
				throw new ApplicationInterfaceException("No Response Recieved from Order DB Service");
			
			response=orderingDBServiceResponse.getNumberOfRecords();

			logger.info("deleteOrderingDomain(): Received HTTP POST Response for tableName:{} at time:{}", tableName,
					endTime);
			logger.info("deleteOrderingDomain(): Time taken for Response for tableName:{} is:{} ms", tableName,
					endTime - startTime);

			logger.debug("deleteOrderingDomain(): Response from OrderingDBService: {}", orderingDBServiceResponse);

			logger.info("Exiting deleteOrderingDomain() ");

		} catch (HttpStatusCodeException e) {
			logger.error("Exception received from OrderingDBService Service URL: {} ", deleteOrderingDomainURL);
			logger.error("Exception received from OrderingDBService Service: {} ", e);
			logger.error("Execption during deleteOrderingDomain execution code:{} , text:{}", e.getStatusCode(),
					e.getResponseBodyAsString());
			throw new ApplicationInterfaceException(ORDERING_DOMAIN_SERVICE + e.getMessage());
		} catch (RestClientException e) {
			logger.error("Exception received from OrderingDBService Service URL: {} ", deleteOrderingDomainURL);
			logger.error("Exception received from OrderingDBService Service: {} ", e);
			throw new ApplicationInterfaceException(ORDERING_DOMAIN_SERVICE + e.getMessage());
		}

		return response;

	}
	
	
	/**
	 * @param tableName
	 * @param updateKeyValuePairList
	 * @param whereClauseList
	 * @return
	 * @throws ApplicationInterfaceException
	 */
	private Long updateOrderingDomain(String tableName,
			List<String[]> updateKeyValuePairList,
			List<String[]> whereClauseList)
			throws ApplicationInterfaceException {

		logger.info("Entering updateOrderingDomain(): {} ", tableName);
		final String updateOrderingDomainURL = orderDomainDBServiceBaseURL.concat("/databaseService");

		Long numOfRecords = null;

		try {

			logger.debug("updateOrderingDomain(): Request Message: {}", tableName);
			DatabaseServiceRequest request = new DatabaseServiceRequest();
			request.setDbOperation("UPDATE");
			request.setTableName(tableName);

			List<String> updateColumnNameList = new ArrayList<>();
			List<String> updateColumnValueList = new ArrayList<>();
			for (String[] updateKeyValuePairArray : updateKeyValuePairList) {
				updateColumnNameList.add(updateKeyValuePairArray[0]);
				updateColumnValueList.add(updateKeyValuePairArray[1]);
			}
			request.setColumnNames(updateColumnNameList);
			request.setColumnValues(updateColumnValueList);

			WhereClause whereClauseRequest = new WhereClause();

			List<String> whereClauseColumnName = new ArrayList<>();
			List<String> whereClauseColumnValue = new ArrayList<>();
			for (String[] whereClauseArray : whereClauseList) {
				whereClauseColumnName.add(whereClauseArray[0]);
				whereClauseColumnValue.add(whereClauseArray[1]);
			}
			whereClauseRequest.setColumnNames(whereClauseColumnName);
			whereClauseRequest.setColumnValues(whereClauseColumnValue);
			request.setWhereClause(Collections.singletonList(whereClauseRequest));

			long startTime = System.currentTimeMillis();

			logger.info("updateOrderingDomain(): Making HTTP POST Request for workOrderNumber:{} at time:{}", tableName,
					startTime);
			logger.info("updateOrderingDomain(): Service URL: {}", updateOrderingDomainURL);
			logger.info("updateOrderingDomain(): Service restTemplate: {}", restTemplate);

			DatabaseServiceResponse response = restTemplate.postForObject(updateOrderingDomainURL,
					request, DatabaseServiceResponse.class);

			long endTime = System.currentTimeMillis();

			logger.info("OrderingDBResponse:" + response);

			if (response == null)
				throw new ApplicationInterfaceException("No Response Recieved from Order DB Service");
			
			numOfRecords = response.getNumberOfRecords();

			logger.info("updateOrderingDomain(): Received HTTP POST Response for tableName:{} at time:{}", tableName,
					endTime);
			logger.info("updateOrderingDomain(): Time taken for Response for tableName:{} is:{} ms", tableName,
					endTime - startTime);

			logger.debug("updateOrderingDomain(): Response from OrderingDBService: {}", response);

			logger.info("Exiting updateOrderingDomain() ");

		} catch (HttpStatusCodeException e) {
			logger.error("Exception received from OrderingDBService Service URL: {} ", updateOrderingDomainURL);
			logger.error("Exception received from OrderingDBService Service: {} ", e);
			logger.error("Execption during updateOrderingDomain execution code:{} , text:{}", e.getStatusCode(),
					e.getResponseBodyAsString());
			throw new ApplicationInterfaceException(ORDERING_DOMAIN_SERVICE + e.getMessage());

		} catch (RestClientException e) {

			logger.error("Exception received from OrderingDBService Service URL: {} ", updateOrderingDomainURL);
			logger.error("Exception received from OrderingDBService Service: {} ", e);
			throw new ApplicationInterfaceException(ORDERING_DOMAIN_SERVICE + e.getMessage());
		}

		return numOfRecords;
	}
	
	/**
	 * @param tableName
	 * @param selectColumnSet
	 * @param whereClauseList
	 * @return
	 * @throws ApplicationInterfaceException
	 */
	private DBServiceResponse searchOrderingDomain(String tableName,
			Set<String> selectColumnSet, List<String[]> whereClauseList)
			throws ApplicationInterfaceException {
		DBServiceResponse responseData = null;

		logger.info("Entering searchOrderingDomain(): {} ");
		final String searchOrderingDomainURL = orderDomainDBServiceBaseURL.concat("/databaseService");

		try {

			DatabaseServiceRequest request = new DatabaseServiceRequest();
			request.setDbOperation("SELECT");
			request.setTableName(tableName);
			List<String> selectColumnList = new ArrayList<>(selectColumnSet);
			logger.info("searchOrderingDomain(): Table: {} SelectColumn: {} WhereCondition: {}", tableName,
					selectColumnList, whereClauseList);
			request.setColumnNames(selectColumnList);
			WhereClause whereClauseRequest = new WhereClause();

			List<String> whereClauseColumnName = new ArrayList<>();
			List<String> whereClauseColumnValue = new ArrayList<>();
			for (String[] whereClauseArray : whereClauseList) {
				whereClauseColumnName.add(whereClauseArray[0]);
				whereClauseColumnValue.add(whereClauseArray[1]);
			}
			whereClauseRequest.setColumnNames(whereClauseColumnName);
			whereClauseRequest.setColumnValues(whereClauseColumnValue);
			request.setWhereClause(Collections.singletonList(whereClauseRequest));

			long startTime = System.currentTimeMillis();
			logger.info("searchOrderingDomain(): Making HTTP POST Request for tableName:{} at time:{}", tableName,
					startTime);
			logger.info("searchOrderingDomain(): Service URL: {}", searchOrderingDomainURL);
			logger.info("searchOrderingDomain(): Service restTemplate: {}", restTemplate);

			DatabaseServiceResponse response = restTemplate.postForObject(searchOrderingDomainURL,
					request, DatabaseServiceResponse.class);

			
			if (response == null)
				throw new ApplicationInterfaceException("No Response Recieved from Order DB Service");
			 

			long endTime = System.currentTimeMillis();

			logger.info("searchOrderingDomain(): HTTP Response: {} ", response);

			responseData = domainInterfaceUtil.convertDBResponseToTblData(response);

			logger.info("searchOrderingDomain(): Received HTTP POST Response for tableName:{} at time:{}", tableName,
					endTime);
			logger.info("searchOrderingDomain(): Time taken for Response for tableName:{} is:{} ms", tableName,
					endTime - startTime);

			logger.info("Exiting searchOrderingDomain() ");

		} catch (HttpStatusCodeException e) {
			logger.error("Exception received from OrderingDBService Service URL: {} ", searchOrderingDomainURL);
			logger.error("Exception received from OrderingDBService Service: {} ", e);
			logger.error("Execption during searchOrderingDomain() execution code:{} , text:{}", e.getStatusCode(),
					e.getResponseBodyAsString());
			throw new ApplicationInterfaceException(ORDERING_DOMAIN_SERVICE + e.getMessage());
		} catch (RestClientException e) {
			logger.error("Exception received from OrderingDBService Service URL: {} ", searchOrderingDomainURL);
			logger.error("Exception received from OrderingDBService Service: {} ", e);
			throw new ApplicationInterfaceException(ORDERING_DOMAIN_SERVICE + e.getMessage());
		}

		return responseData;
	}
	

	/**
	 * @param tableName
	 * @param columnName
	 * @param whereClauseList
	 * @param responseClass
	 * @return
	 * @throws ApplicationInterfaceException
	 */
	@SuppressWarnings("unchecked")
	private <T> T searchOrderingForSingleValue(String tableName, String columnName, List<String[]> whereClauseList,
			Class<T> responseClass) throws ApplicationInterfaceException {
		Set<String> selectColumnSet = new HashSet<>();
		selectColumnSet.add(columnName);
		T responseType = null;

		try {
			HashSet<String> supportedType = new HashSet<>();
			supportedType.add("java.lang.String");
			supportedType.add("java.lang.Integer");
			supportedType.add("java.lang.Long");
			supportedType.add("java.lang.Float");
			supportedType.add("java.lang.Double");

			String responseClassType = responseClass.getName();
			logger.info("responseClassType:" + responseClassType);

			if (!supportedType.contains(responseClassType))
				throw new ApplicationInterfaceException("Unsupported dataype");

			DBServiceResponse tblData = searchOrderingDomain(tableName, selectColumnSet, whereClauseList);
			
			Optional<String> responseValueOpt = Optional.ofNullable(tblData)
			.map(tblDataObj -> tblDataObj.getTableRows())
			.map(tblRows -> tblRows.size() > 0 ? tblRows.get(0) : null)
			.map(firstRow -> firstRow.getTblRow())
			.map(firstRowCells -> firstRowCells.get(columnName))
			.map(specificCell -> specificCell.getValue());
			
			String responseValue = responseValueOpt.orElse(null);
			if (responseValue != null) {
				switch (responseClassType) {
				case "java.lang.String":
					responseType = (T) responseValue;
					break;
				case "java.lang.Integer":
					responseType = (T) Integer.valueOf(responseValue);
					break;
				case "java.lang.Long":
					responseType = (T) Long.valueOf(responseValue);
					break;
				case "java.lang.Float":
					responseType = (T) Float.valueOf(responseValue);
					break;
				case "java.lang.Double":
					responseType = (T) Double.valueOf(responseValue);
				}
			}

		} catch (Exception e) {
			logger.error("Exception received from OrderingDB Service: {} ", e);
			throw new ApplicationInterfaceException(ORDERING_DOMAIN_SERVICE + e.getMessage());
		}

		return responseType;
	}

	
	public Long insertTblOrderDetails(Long parentId, Long orderId, String paramName, String paramValue)
			throws ApplicationInterfaceException {
		// TODO Fetch SEQ_NO from entityBatch
		
		List<String[]> insertKeyValuePairList = new ArrayList<>();
		insertKeyValuePairList.add(new String[] { "PARENT_ID", String.valueOf(parentId) });
		insertKeyValuePairList.add(new String[] { "ORDER_ID", String.valueOf(orderId) });
		insertKeyValuePairList.add(new String[] { "SEQ_NO", "0" });
		insertKeyValuePairList.add(new String[] { "PARAM_TYPE", "C" });
		insertKeyValuePairList.add(new String[] { "FLOW_STATUS", "0" });
		insertKeyValuePairList.add(new String[] { "DATA_TYPE", "2" });
		insertKeyValuePairList.add(new String[] { "LEAF", "1" });
		insertKeyValuePairList.add(new String[] { "PARAM_NAME", paramName });
		insertKeyValuePairList.add(new String[] { "PARAM_VALUE", paramValue });
		insertKeyValuePairList.add(new String[] { "ACTION", "n" });
		
		List<String[]> sequenceKeyValuePairList = new ArrayList<>();
		sequenceKeyValuePairList.add(new String[] { "ORDER_DETAIL_ID", "ORDER_DETAIL_ID_SEQ" });
		
		Long numberOfRecords = insertOrderingDomain("TBL_ORDER_DETAILS", insertKeyValuePairList, sequenceKeyValuePairList);
		
		return numberOfRecords;
	}

	
	public void updateTnOrderStatus(String workOrderNumber, String workOrderVersion, String envOrderId)
			throws ApplicationInterfaceException {
		final String orderDomainUpdateTNOrderStatusURL = orderDomainServiceBaseURL.concat("/updateTNOrderStatus");

		try {

			logger.debug("updateTnOrderStatus(): Request workOrderNumber: {}, workOrderVesion: {}, envOrderId: {}", workOrderNumber, workOrderVersion, envOrderId);
						
			long startTime = System.currentTimeMillis();
			logger.info("updateTnOrderStatus(): Making HTTP POST Request for workOrderNumber:{} at time:{}", workOrderNumber, startTime);
			logger.info("updateTnOrderStatus(): Service URL: {}", orderDomainUpdateTNOrderStatusURL);
			logger.info("updateTnOrderStatus(): Service restTemplate: {}", restTemplate);
			
			Map<String, String> paramMap = new HashMap<>();
			paramMap.put("workOrderNumber", workOrderNumber);
			paramMap.put("workOrderVersion", workOrderVersion);
			paramMap.put("envOrderId", envOrderId);
			
			ResponseObject orderUpdateStatusServiceResponse = restTemplate.postForObject(orderDomainUpdateTNOrderStatusURL, paramMap,
					ResponseObject.class);
			
			if (orderUpdateStatusServiceResponse == null)
				throw new ApplicationInterfaceException("updateTnOrderStatus(): No response received from Ordering Service");

			long endTime = System.currentTimeMillis();

			logger.info("updateTnOrderStatus(): Time taken for Response for tableName:{} is:{} ms", "",
					endTime - startTime);
			logger.debug("updateTnOrderStatus(): Response from OrderingDomainService: {}", orderUpdateStatusServiceResponse);
			logger.info("Exiting updateTnOrderStatus() ");

		} catch (HttpStatusCodeException e) {
			logger.error("Exception received from OrderingDomainService URL : {} ", orderDomainUpdateTNOrderStatusURL);
			logger.error("Exception received from OrderingDomainService : {} ", e);
			logger.error("Execption during updateTnOrderStatus execution code:{} , text:{}", e.getStatusCode(),
					e.getResponseBodyAsString());
			throw new ApplicationInterfaceException(ORDERING_DOMAIN_SERVICE + e.getMessage());
		} catch (RestClientException e) {
			logger.error("Exception received from OrderingDomainService URL: {} ", orderDomainUpdateTNOrderStatusURL);
			logger.error("Exception received from OrderingDomainService : {} ", e);
			throw new ApplicationInterfaceException(ORDERING_DOMAIN_SERVICE + e.getMessage());
		}

	}
	
	
	public void setTnFalloutStatus(List<FailEntityInfo> failEntityInfoList)
			throws ApplicationInterfaceException {
		final String orderDomainSetTNFalloutStatusURL = orderDomainFalloutServiceBaseURL.concat("/setTnFalloutStatus");

		try {

			if (failEntityInfoList == null || failEntityInfoList.isEmpty()) {
				throw new ApplicationInterfaceException("Empty or Null List");
			}

			logger.info("setTnFalloutStatus(): Input List Size: {} ", failEntityInfoList.size());
			
			List<TblFailEntityInfo> failEntityInfoRestList = domainInterfaceUtil
					.transformRequestDTOToView(failEntityInfoList);

			long startTime = System.currentTimeMillis();
			logger.info("setTnFalloutStatus(): Making HTTP POST Request  Service URL:{} at time:{}", orderDomainSetTNFalloutStatusURL,
					startTime);
			ResponseObject orderFalloutServiceResponse = restTemplate.postForObject(orderDomainSetTNFalloutStatusURL,
					failEntityInfoRestList, ResponseObject.class);
			
			if (orderFalloutServiceResponse == null)
				throw new ApplicationInterfaceException("setTnFalloutStatus(): No response received from Ordering Fallout Service");

			long endTime = System.currentTimeMillis();

			logger.info("setTnFalloutStatus(): Time taken for Response for tableName:{} is:{} ms", "",
					endTime - startTime);
			logger.info("setTnFalloutStatus(): Response from OrderLogService: {}", orderFalloutServiceResponse);
			logger.info("Exiting setTnFalloutStatus() ");

		} catch (HttpStatusCodeException e) {
			logger.error("Exception received from OrderingDomainService URL: {} ", orderDomainSetTNFalloutStatusURL);
			logger.error("Exception received from OrderingDomainService : {} ", e);
			logger.error("Execption during setTnFalloutStatus execution code:{} , text:{}", e.getStatusCode(),
					e.getResponseBodyAsString());
			throw new ApplicationInterfaceException(ORDERING_DOMAIN_SERVICE + e.getMessage());
		} catch (RestClientException e) {
			logger.error("Exception received from OrderingDomainService URL: {} ", orderDomainSetTNFalloutStatusURL);
			logger.error("Exception received from OrderingDomainService : {} ", e);
			throw new ApplicationInterfaceException(ORDERING_DOMAIN_SERVICE + e.getMessage());
		}

	}
	
	
	public void clearTnFalloutStatus(List<FailEntityInfo> failEntityInfoList)
			throws ApplicationInterfaceException {
		final String orderDomainSetTNFalloutStatusURL = orderDomainFalloutServiceBaseURL.concat("/clearFallouts");

		try {

			if (failEntityInfoList == null || failEntityInfoList.isEmpty()) {
				throw new ApplicationInterfaceException("Empty or Null List");
			}
			logger.info("setTnFalloutStatus(): Input List Size: {} ", failEntityInfoList.size());
			
			List<TblFailEntityInfo> failEntityInfoRestList = domainInterfaceUtil
					.transformRequestDTOToView(failEntityInfoList);

			long startTime = System.currentTimeMillis();
			logger.info("clearTnFalloutStatus(): Making HTTP POST Request at time:{}  Service URL: {} ",
					startTime,orderDomainSetTNFalloutStatusURL);
			
			logger.info("clearTnFalloutStatus(): Request Message: {}", mapper.writerWithDefaultPrettyPrinter().writeValueAsString(failEntityInfoRestList));
			
			ResponseObject orderFalloutServiceResponse = restTemplate.postForObject(orderDomainSetTNFalloutStatusURL,
					failEntityInfoRestList, ResponseObject.class);
			
			
			if (orderFalloutServiceResponse == null)
				throw new ApplicationInterfaceException("clearTnFalloutStatus(): No response received from Ordering Fallout Service");

			long endTime = System.currentTimeMillis();
			
			logger.info("clearTnFalloutStatus(): Time taken for Response for tableName:{} is:{} ms", "",
					endTime - startTime);
			logger.debug("clearTnFalloutStatus(): Response from OrderLogService: {}", orderFalloutServiceResponse);
			logger.info("Exiting clearTnFalloutStatus() ");

		} catch (HttpStatusCodeException e) {
			logger.error("Exception received from OrderingDomainService URL: {} ", orderDomainSetTNFalloutStatusURL);
			logger.error("Exception received from OrderingDomainService : {} ", e);
			logger.error("Execption during clearTnFalloutStatus execution code:{} , text:{}", e.getStatusCode(),
					e.getResponseBodyAsString());
			throw new ApplicationInterfaceException(ORDERING_DOMAIN_SERVICE + e.getMessage());
		} catch (RestClientException e) {
			logger.error("Exception received from OrderingDomainService URL: {} ", orderDomainSetTNFalloutStatusURL);
			logger.error("Exception received from OrderingDomainService : {} ", e);
			throw new ApplicationInterfaceException(ORDERING_DOMAIN_SERVICE + e.getMessage());
		} catch (JsonProcessingException e) {
			logger.error("Exception received from OrderingDomainService URL: {} ", orderDomainSetTNFalloutStatusURL);
			logger.error("Exception received from OrderingDomainService : {} ", e);
			throw new ApplicationInterfaceException(ORDERING_DOMAIN_SERVICE + e.getMessage());
		}

	}
	
	/**
	 * This method pulls fail Tns list from OrderDomain
	 * 
	 * @param envOrderId
	 * @param taskName
	 * @return
	 * @throws ApplicationInterfaceException
	 */
	public List<String> getFailEntityInfo(String envOrderId, String taskName) throws ApplicationInterfaceException {
		final String orderDomainGetFailEntityInfoURL = orderDomainFalloutServiceBaseURL.concat("/getFailEntityInfo");

		logger.info("taskName(): envOrderID:{} , taskName :{}", envOrderId, taskName);
		List<String> responseDTO = new ArrayList<String>();
		try {

			if (envOrderId == null || taskName == null) {
				throw new ApplicationInterfaceException("Empty or Null List");
			}

			FailEntityInfo entityInfo = new FailEntityInfo();
			entityInfo.setEnvOrderId(envOrderId);
			entityInfo.setTaskName(taskName);

			ArrayList<FailEntityInfo> failEntityInfoRestList = new ArrayList<>();
			failEntityInfoRestList.add(entityInfo);

			long startTime = System.currentTimeMillis();
			logger.info("clearTnFalloutStatus(): Making HTTP POST Request at time:{}  Service URL: {} ", startTime,
					orderDomainGetFailEntityInfoURL);

			logger.info("clearTnFalloutStatus(): Request Message: {}",
					mapper.writerWithDefaultPrettyPrinter().writeValueAsString(failEntityInfoRestList));

			List<LinkedHashMap> orderFalloutServiceResponse = restTemplate
					.postForObject(orderDomainGetFailEntityInfoURL, failEntityInfoRestList, ArrayList.class);

			responseDTO = domainInterfaceUtil
					.transformOrderFaillOutEntityInfoResponseViewToDTO(orderFalloutServiceResponse);

			if (orderFalloutServiceResponse == null)
				throw new ApplicationInterfaceException(
						"clearTnFalloutStatus(): No response received from Ordering Fallout Service");

			long endTime = System.currentTimeMillis();

			logger.info("clearTnFalloutStatus(): Time taken for Response for tableName:{} is:{} ms", "",
					endTime - startTime);
			logger.debug("clearTnFalloutStatus(): Response from OrderLogService: {}", orderFalloutServiceResponse);
			logger.info("Exiting clearTnFalloutStatus() ");

		} catch (HttpStatusCodeException e) {
			logger.error("Exception received from OrderingDomainService URL: {} ", orderDomainGetFailEntityInfoURL);
			logger.error("Exception received from OrderingDomainService : {} ", e);
			logger.error("Execption during clearTnFalloutStatus execution code:{} , text:{}", e.getStatusCode(),
					e.getResponseBodyAsString());
			throw new ApplicationInterfaceException(ORDERING_DOMAIN_SERVICE + e.getMessage());
		} catch (RestClientException e) {
			logger.error("Exception received from OrderingDomainService URL: {} ", orderDomainGetFailEntityInfoURL);
			logger.error("Exception received from OrderingDomainService : {} ", e);
			throw new ApplicationInterfaceException(ORDERING_DOMAIN_SERVICE + e.getMessage());
		} catch (JsonProcessingException e) {
			logger.error("Exception received from OrderingDomainService URL: {} ", orderDomainGetFailEntityInfoURL);
			logger.error("Exception received from OrderingDomainService : {} ", e);
			throw new ApplicationInterfaceException(ORDERING_DOMAIN_SERVICE + e.getMessage());
		}

		return responseDTO;
	}
	
	public ArrayList<TblEnvOrderDbBean> getTblEnvOrderDbBeanList(String envOrderId) throws ApplicationInterfaceException{
		
		ArrayList<TblEnvOrderDbBean> rsList = new ArrayList<TblEnvOrderDbBean>();
		Set<String> selectColumnSet = new HashSet<>();
		
		/*SELECT ENV_ORDER_ID,PREV_PASS_ENV_ORDER_ID,SEQUENCE_NO,SYSTEM,ORDER_NUMBER,MASTER_ORDER_NUMBER,
		 * CLLI,REGION,JURISDICTION,WIRE_CENTER,SOURCE_ADDR,CUSTOMER_NAME,ORDER_REMARKS,RECEIVE_DATE,
		 * DUE_DATE,COMPLETION_DATE,ORDER_TYPE,ORDER_STATUS,ORDER_PRIORITY,CREATED_BY,ORDER_LOCK_DATE,
		 * ORDER_LOCKED_BY,LAST_MODIFIED,MODIFIED_BY,VERSION_NUMBER,ORDER_CLASSIFY,MAIN_TN,PROCESS_DATE,
		 * ASSIGN_DATE,PARENT_ORDER_ID,VZ_ID,WORK_GROUP,ERROR_CODE,NEW_PASS_WAITING,TRANSACTION_ID,
		 * PROJECT_ID,TECHNOLOGY,ORIGIN,SERVICE_TYPE,ASGM_VERSION,ORDER_CATEGORY,MINOR_ORDER_TYPE,
		 * ENTERPRISE_ID,LOCATION_ID,BULK_ORDER,EXPEDITE,RESP_HANDLER,PRODUCT_TYPE,E2EI_SENSITIVITY_LEVEL,
		 * ESAP_CLUSTER FROM TBL_ENV_ORDER*/
				
		for(TblEnvOrderCallHeader tblEnvOrderCallHeader: TblEnvOrderCallHeader.values()){
			selectColumnSet.add(tblEnvOrderCallHeader.toString());
		}
		
		ArrayList<String[]> whereClauseList = new ArrayList<>();
		whereClauseList.add(new String[] { "ENV_ORDER_ID", envOrderId });
		
		DBServiceResponse responseData = searchOrderingDomain("TBL_ENV_ORDER", selectColumnSet, whereClauseList);
		
		for (TblRow row : responseData.getTableRows()) {
			TblEnvOrderDbBean tblEnvOrderDbBean = new TblEnvOrderDbBean();
			if(row.getTblRow().get(TblEnvOrderCallHeader.ENV_ORDER_ID.toString()).getValue() != null)
				tblEnvOrderDbBean.setEnvOrderId(Integer.parseInt(row.getTblRow().get(TblEnvOrderCallHeader.ENV_ORDER_ID.toString()).getValue()));
			if(row.getTblRow().get(TblEnvOrderCallHeader.PREV_PASS_ENV_ORDER_ID.toString()).getValue() != null)
				tblEnvOrderDbBean.setPrevPassEnvOrderId(Long.parseLong(row.getTblRow().get(TblEnvOrderCallHeader.PREV_PASS_ENV_ORDER_ID.toString()).getValue()));
			if(row.getTblRow().get(TblEnvOrderCallHeader.SEQUENCE_NO.toString()).getValue() != null)
				tblEnvOrderDbBean.setSequenceNo(Long.parseLong(row.getTblRow().get(TblEnvOrderCallHeader.SEQUENCE_NO.toString()).getValue()));
			if(row.getTblRow().get(TblEnvOrderCallHeader.SYSTEM.toString()).getValue() != null)
				tblEnvOrderDbBean.setSystem(row.getTblRow().get(TblEnvOrderCallHeader.SYSTEM.toString()).getValue());
			if(row.getTblRow().get(TblEnvOrderCallHeader.ORDER_NUMBER.toString()).getValue() != null)
				tblEnvOrderDbBean.setOrderNumber(row.getTblRow().get(TblEnvOrderCallHeader.ORDER_NUMBER.toString()).getValue());
			if(row.getTblRow().get(TblEnvOrderCallHeader.MASTER_ORDER_NUMBER.toString()).getValue() != null)
				tblEnvOrderDbBean.setMasterOrderNumber(row.getTblRow().get(TblEnvOrderCallHeader.MASTER_ORDER_NUMBER.toString()).getValue());
			if(row.getTblRow().get(TblEnvOrderCallHeader.CLLI.toString()).getValue() != null)
				tblEnvOrderDbBean.setClli(row.getTblRow().get(TblEnvOrderCallHeader.CLLI.toString()).getValue());
			if(row.getTblRow().get(TblEnvOrderCallHeader.REGION.toString()).getValue() != null)
				tblEnvOrderDbBean.setRegion(row.getTblRow().get(TblEnvOrderCallHeader.REGION.toString()).getValue());
			if(row.getTblRow().get(TblEnvOrderCallHeader.JURISDICTION.toString()).getValue() != null)
				tblEnvOrderDbBean.setJurisdiction(row.getTblRow().get(TblEnvOrderCallHeader.JURISDICTION.toString()).getValue());
			if(row.getTblRow().get(TblEnvOrderCallHeader.WIRE_CENTER.toString()).getValue() != null)
				tblEnvOrderDbBean.setWireCenter(Long.parseLong(row.getTblRow().get(TblEnvOrderCallHeader.WIRE_CENTER.toString()).getValue()));
			if(row.getTblRow().get(TblEnvOrderCallHeader.SOURCE_ADDR.toString()).getValue() != null)
				tblEnvOrderDbBean.setSourceAddr(row.getTblRow().get(TblEnvOrderCallHeader.SOURCE_ADDR.toString()).getValue());
			if(row.getTblRow().get(TblEnvOrderCallHeader.CUSTOMER_NAME.toString()).getValue() != null)
				tblEnvOrderDbBean.setCustomerName(row.getTblRow().get(TblEnvOrderCallHeader.CUSTOMER_NAME.toString()).getValue());
			if(row.getTblRow().get(TblEnvOrderCallHeader.ORDER_REMARKS.toString()).getValue() != null)
				tblEnvOrderDbBean.setOrderRemarks(row.getTblRow().get(TblEnvOrderCallHeader.ORDER_REMARKS.toString()).getValue());
			if(row.getTblRow().get(TblEnvOrderCallHeader.RECEIVE_DATE.toString()).getValue() != null)
				tblEnvOrderDbBean.setReceiveDate(Timestamp.valueOf(row.getTblRow().get(TblEnvOrderCallHeader.RECEIVE_DATE.toString()).getValue()));
			if(row.getTblRow().get(TblEnvOrderCallHeader.DUE_DATE.toString()).getValue() != null)
				tblEnvOrderDbBean.setDueDate(Timestamp.valueOf(row.getTblRow().get(TblEnvOrderCallHeader.DUE_DATE.toString()).getValue()));
			if(row.getTblRow().get(TblEnvOrderCallHeader.COMPLETION_DATE.toString()).getValue() != null)
				tblEnvOrderDbBean.setCompletionDate(Timestamp.valueOf(row.getTblRow().get(TblEnvOrderCallHeader.COMPLETION_DATE.toString()).getValue()));
			if(row.getTblRow().get(TblEnvOrderCallHeader.ORDER_TYPE.toString()).getValue() != null)
				tblEnvOrderDbBean.setOrderType(Long.parseLong(row.getTblRow().get(TblEnvOrderCallHeader.ORDER_TYPE.toString()).getValue()));
			if(row.getTblRow().get(TblEnvOrderCallHeader.ORDER_STATUS.toString()).getValue() != null)
				tblEnvOrderDbBean.setOrderStatus(Long.parseLong(row.getTblRow().get(TblEnvOrderCallHeader.ORDER_STATUS.toString()).getValue()));
			if(row.getTblRow().get(TblEnvOrderCallHeader.ORDER_PRIORITY.toString()).getValue() != null)
				tblEnvOrderDbBean.setOrderPriority(Long.parseLong(row.getTblRow().get(TblEnvOrderCallHeader.ORDER_PRIORITY.toString()).getValue()));
			if(row.getTblRow().get(TblEnvOrderCallHeader.CREATED_BY.toString()).getValue() != null)
				tblEnvOrderDbBean.setCreatedBy(row.getTblRow().get(TblEnvOrderCallHeader.CREATED_BY.toString()).getValue());
			if(row.getTblRow().get(TblEnvOrderCallHeader.ORDER_LOCK_DATE.toString()).getValue() != null)
				tblEnvOrderDbBean.setOrderLockDate(Timestamp.valueOf(row.getTblRow().get(TblEnvOrderCallHeader.ORDER_LOCK_DATE.toString()).getValue()));
			if(row.getTblRow().get(TblEnvOrderCallHeader.ORDER_LOCKED_BY.toString()).getValue() != null)
				tblEnvOrderDbBean.setOrderLockedBy(row.getTblRow().get(TblEnvOrderCallHeader.ORDER_LOCKED_BY.toString()).getValue());
			if(row.getTblRow().get(TblEnvOrderCallHeader.LAST_MODIFIED.toString()).getValue() != null)
				tblEnvOrderDbBean.setLastModified(Timestamp.valueOf(row.getTblRow().get(TblEnvOrderCallHeader.LAST_MODIFIED.toString()).getValue()));
			if(row.getTblRow().get(TblEnvOrderCallHeader.MODIFIED_BY.toString()).getValue() != null)
				tblEnvOrderDbBean.setModifiedBy(row.getTblRow().get(TblEnvOrderCallHeader.MODIFIED_BY.toString()).getValue());
			if(row.getTblRow().get(TblEnvOrderCallHeader.VERSION_NUMBER.toString()).getValue() != null)
				tblEnvOrderDbBean.setVersionNumber(row.getTblRow().get(TblEnvOrderCallHeader.VERSION_NUMBER.toString()).getValue());
			if(row.getTblRow().get(TblEnvOrderCallHeader.ORDER_CLASSIFY.toString()).getValue() != null)
				tblEnvOrderDbBean.setOrderClassify(Long.parseLong(row.getTblRow().get(TblEnvOrderCallHeader.ORDER_CLASSIFY.toString()).getValue()));
			if(row.getTblRow().get(TblEnvOrderCallHeader.MAIN_TN.toString()).getValue() != null)
				tblEnvOrderDbBean.setMainTn(row.getTblRow().get(TblEnvOrderCallHeader.MAIN_TN.toString()).getValue());
			if(row.getTblRow().get(TblEnvOrderCallHeader.PROCESS_DATE.toString()).getValue() != null)
				tblEnvOrderDbBean.setProcessDate(Timestamp.valueOf(row.getTblRow().get(TblEnvOrderCallHeader.PROCESS_DATE.toString()).getValue()));
			if(row.getTblRow().get(TblEnvOrderCallHeader.ASSIGN_DATE.toString()).getValue() != null)
				tblEnvOrderDbBean.setAssignDate(Timestamp.valueOf(row.getTblRow().get(TblEnvOrderCallHeader.ASSIGN_DATE.toString()).getValue()));
			if(row.getTblRow().get(TblEnvOrderCallHeader.PARENT_ORDER_ID.toString()).getValue() != null)
				tblEnvOrderDbBean.setParentOrderId(Long.parseLong(row.getTblRow().get(TblEnvOrderCallHeader.PARENT_ORDER_ID.toString()).getValue()));
			if(row.getTblRow().get(TblEnvOrderCallHeader.VZ_ID.toString()).getValue() != null)
				tblEnvOrderDbBean.setVzId(row.getTblRow().get(TblEnvOrderCallHeader.VZ_ID.toString()).getValue());
			if(row.getTblRow().get(TblEnvOrderCallHeader.WORK_GROUP.toString()).getValue() != null)
				tblEnvOrderDbBean.setWorkGroup(row.getTblRow().get(TblEnvOrderCallHeader.WORK_GROUP.toString()).getValue());
			if(row.getTblRow().get(TblEnvOrderCallHeader.NEW_PASS_WAITING.toString()).getValue() != null)
				tblEnvOrderDbBean.setNewPassWaiting(row.getTblRow().get(TblEnvOrderCallHeader.NEW_PASS_WAITING.toString()).getValue());
			if(row.getTblRow().get(TblEnvOrderCallHeader.TRANSACTION_ID.toString()).getValue() != null)
				tblEnvOrderDbBean.setTransactionId(Long.parseLong(row.getTblRow().get(TblEnvOrderCallHeader.TRANSACTION_ID.toString()).getValue()));
			if(row.getTblRow().get(TblEnvOrderCallHeader.PROJECT_ID.toString()).getValue() != null)
				tblEnvOrderDbBean.setProjectId(row.getTblRow().get(TblEnvOrderCallHeader.PROJECT_ID.toString()).getValue());
			if(row.getTblRow().get(TblEnvOrderCallHeader.TECHNOLOGY.toString()).getValue() != null)
				tblEnvOrderDbBean.setTechnology(row.getTblRow().get(TblEnvOrderCallHeader.TECHNOLOGY.toString()).getValue());
			if(row.getTblRow().get(TblEnvOrderCallHeader.ORIGIN.toString()).getValue() != null)
				tblEnvOrderDbBean.setOrigin(row.getTblRow().get(TblEnvOrderCallHeader.ORIGIN.toString()).getValue());
			if(row.getTblRow().get(TblEnvOrderCallHeader.SERVICE_TYPE.toString()).getValue() != null)
				tblEnvOrderDbBean.setServiceType(row.getTblRow().get(TblEnvOrderCallHeader.SERVICE_TYPE.toString()).getValue());
			if(row.getTblRow().get(TblEnvOrderCallHeader.ASGM_VERSION.toString()).getValue() != null)
				tblEnvOrderDbBean.setAsgmVersion(row.getTblRow().get(TblEnvOrderCallHeader.ASGM_VERSION.toString()).getValue());
			if(row.getTblRow().get(TblEnvOrderCallHeader.ORDER_CATEGORY.toString()).getValue() != null)
				tblEnvOrderDbBean.setOrderCategory(row.getTblRow().get(TblEnvOrderCallHeader.ORDER_CATEGORY.toString()).getValue());
			if(row.getTblRow().get(TblEnvOrderCallHeader.MINOR_ORDER_TYPE.toString()).getValue() != null)
				tblEnvOrderDbBean.setMinorOrderType(row.getTblRow().get(TblEnvOrderCallHeader.MINOR_ORDER_TYPE.toString()).getValue());
			if(row.getTblRow().get(TblEnvOrderCallHeader.ENTERPRISE_ID.toString()).getValue() != null)
				tblEnvOrderDbBean.setEnterpriseId(row.getTblRow().get(TblEnvOrderCallHeader.ENTERPRISE_ID.toString()).getValue());
			if(row.getTblRow().get(TblEnvOrderCallHeader.LOCATION_ID.toString()).getValue() != null)
				tblEnvOrderDbBean.setLocationId(row.getTblRow().get(TblEnvOrderCallHeader.LOCATION_ID.toString()).getValue());
			if(row.getTblRow().get(TblEnvOrderCallHeader.BULK_ORDER.toString()).getValue() != null)
				tblEnvOrderDbBean.setBulkOrder(row.getTblRow().get(TblEnvOrderCallHeader.BULK_ORDER.toString()).getValue());
			if(row.getTblRow().get(TblEnvOrderCallHeader.EXPEDITE.toString()).getValue() != null)
				tblEnvOrderDbBean.setExpedite(row.getTblRow().get(TblEnvOrderCallHeader.EXPEDITE.toString()).getValue());
			if(row.getTblRow().get(TblEnvOrderCallHeader.RESP_HANDLER.toString()).getValue() != null)
				tblEnvOrderDbBean.setRespHandler(row.getTblRow().get(TblEnvOrderCallHeader.RESP_HANDLER.toString()).getValue());
			if(row.getTblRow().get(TblEnvOrderCallHeader.PRODUCT_TYPE.toString()).getValue() != null)
				tblEnvOrderDbBean.setProductType(Long.parseLong(row.getTblRow().get(TblEnvOrderCallHeader.PRODUCT_TYPE.toString()).getValue()));
			if(row.getTblRow().get(TblEnvOrderCallHeader.E2EI_SENSITIVITY_LEVEL.toString()).getValue() != null)
				tblEnvOrderDbBean.setE2eiSensitivityLevel(row.getTblRow().get(TblEnvOrderCallHeader.E2EI_SENSITIVITY_LEVEL.toString()).getValue());
			if(row.getTblRow().get(TblEnvOrderCallHeader.ESAP_CLUSTER.toString()).getValue() != null)
				tblEnvOrderDbBean.setEsapCluster(row.getTblRow().get(TblEnvOrderCallHeader.ESAP_CLUSTER.toString()).getValue());
			rsList.add(tblEnvOrderDbBean);
		}
		return rsList;
	}
	
	public ArrayList<TblOrderDbBean> getTblOrderDbBeanList(String orderNumber) throws ApplicationInterfaceException{
		ArrayList<TblOrderDbBean> rsList = new ArrayList<TblOrderDbBean>();
		Set<String> selectColumnSet = new HashSet<>();
		
		/*SELECT ORDER_ID,ENV_ORDER_ID,PREV_PASS_ORDER_ID,DEST_SYSTEM,APPTYPE_ID,ORDER_STATUS,
		 * PREV_ORDER_STATUS,DUE_DATE,WORK_GROUP,PRIORITY,RECVD_DATE,SOURCE_SYSTEM,SOURCE_SERVICE,
		 * MANUAL_ORDER,COMPLETED_DATE,FAILED_DATE,VZ_ID,RESPONSE_REQD,START_DATE,UPDATED_DATE,
		 * UPSTREAM_WO_ID,UPSTREAM_FLOW_ID,UPSTREAM_TASK_ID,TDN,NPA,CLLI,TIMEZONE_OFFSET,CATALOG,
		 * WIRE_CENTER,PARENT_ORDER,TRANSLATOR_ID,LOCKED_FROM_STATUS,LOCKED_BY_VZ_ID,RETURN_STATUS,
		 * COS,ACCOUNT_NUMBER,TRANSACTION_NUMBER,VERSION_NO,FLOW_PATH,ORDER_TYPE,MINOR_ORDER_TYPE,
		 * SOACS_CODE,ACTION,APS_STATE,EXK,PROJECT_ID,ERROR_CODE,ESAP_CLUSTER FROM TBL_ORDER*/
		
		for(TblOrderCallHeader tblOrderCallHeader: TblOrderCallHeader.values()){
			selectColumnSet.add(tblOrderCallHeader.toString());
		}
				
		ArrayList<String[]> whereClauseList = new ArrayList<>();
		whereClauseList.add(new String[] { "ORDER_ID", orderNumber });
		
		DBServiceResponse responseData = searchOrderingDomain("TBL_ORDER", selectColumnSet, whereClauseList);
		
		for (TblRow row : responseData.getTableRows()) {
			TblOrderDbBean tblOrderDbBean = new TblOrderDbBean();
			if(row.getTblRow().get(TblOrderCallHeader.ORDER_ID.toString()).getValue() != null)
				tblOrderDbBean.setOrderId(Integer.parseInt(row.getTblRow().get(TblOrderCallHeader.ORDER_ID.toString()).getValue()));
			if(row.getTblRow().get(TblOrderCallHeader.ENV_ORDER_ID.toString()).getValue() != null)
				tblOrderDbBean.setEnvOrderId(Long.parseLong(row.getTblRow().get(TblOrderCallHeader.ENV_ORDER_ID.toString()).getValue()));
			if(row.getTblRow().get(TblOrderCallHeader.PREV_PASS_ORDER_ID.toString()).getValue() != null)
				tblOrderDbBean.setPrevPassOrderId(Long.parseLong(row.getTblRow().get(TblOrderCallHeader.PREV_PASS_ORDER_ID.toString()).getValue()));
			if(row.getTblRow().get(TblOrderCallHeader.DEST_SYSTEM.toString()).getValue() != null)
				tblOrderDbBean.setDestSystem(row.getTblRow().get(TblOrderCallHeader.DEST_SYSTEM.toString()).getValue());
			if(row.getTblRow().get(TblOrderCallHeader.APPTYPE_ID.toString()).getValue() != null)
				tblOrderDbBean.setApptypeId(Long.parseLong(row.getTblRow().get(TblOrderCallHeader.APPTYPE_ID.toString()).getValue()));
			if(row.getTblRow().get(TblOrderCallHeader.ORDER_STATUS.toString()).getValue() != null)
				tblOrderDbBean.setOrderStatus(Integer.parseInt(row.getTblRow().get(TblOrderCallHeader.ORDER_STATUS.toString()).getValue()));
			if(row.getTblRow().get(TblOrderCallHeader.PREV_ORDER_STATUS.toString()).getValue() != null)
				tblOrderDbBean.setPrevOrderStatus(Integer.parseInt(row.getTblRow().get(TblOrderCallHeader.PREV_ORDER_STATUS.toString()).getValue()));
			if(row.getTblRow().get(TblOrderCallHeader.DUE_DATE.toString()).getValue() != null)
				tblOrderDbBean.setDueDate(Timestamp.valueOf(row.getTblRow().get(TblOrderCallHeader.DUE_DATE.toString()).getValue()));
			if(row.getTblRow().get(TblOrderCallHeader.WORK_GROUP.toString()).getValue() != null)
				tblOrderDbBean.setWorkGroup(row.getTblRow().get(TblOrderCallHeader.WORK_GROUP.toString()).getValue());
			if(row.getTblRow().get(TblOrderCallHeader.PRIORITY.toString()).getValue() != null)
				tblOrderDbBean.setPriority(Long.parseLong(row.getTblRow().get(TblOrderCallHeader.PRIORITY.toString()).getValue()));
			if(row.getTblRow().get(TblOrderCallHeader.RECVD_DATE.toString()).getValue() != null)
				tblOrderDbBean.setRecvdDate(Timestamp.valueOf(row.getTblRow().get(TblOrderCallHeader.RECVD_DATE.toString()).getValue()));
			if(row.getTblRow().get(TblOrderCallHeader.SOURCE_SYSTEM.toString()).getValue() != null)
				tblOrderDbBean.setSourceSystem(row.getTblRow().get(TblOrderCallHeader.SOURCE_SYSTEM.toString()).getValue());
			if(row.getTblRow().get(TblOrderCallHeader.SOURCE_SERVICE.toString()).getValue() != null)
				tblOrderDbBean.setSourceService(row.getTblRow().get(TblOrderCallHeader.SOURCE_SERVICE.toString()).getValue());
			if(row.getTblRow().get(TblOrderCallHeader.MANUAL_ORDER.toString()).getValue() != null)
				tblOrderDbBean.setManualOrder(row.getTblRow().get(TblOrderCallHeader.MANUAL_ORDER.toString()).getValue());
			if(row.getTblRow().get(TblOrderCallHeader.COMPLETED_DATE.toString()).getValue() != null)
				tblOrderDbBean.setCompletedDate(Timestamp.valueOf(row.getTblRow().get(TblOrderCallHeader.COMPLETED_DATE.toString()).getValue()));
			if(row.getTblRow().get(TblOrderCallHeader.FAILED_DATE.toString()).getValue() != null)
				tblOrderDbBean.setFailedDate(Timestamp.valueOf(row.getTblRow().get(TblOrderCallHeader.FAILED_DATE.toString()).getValue()));
			if(row.getTblRow().get(TblOrderCallHeader.VZ_ID.toString()).getValue() != null)
				tblOrderDbBean.setVzId(row.getTblRow().get(TblOrderCallHeader.VZ_ID.toString()).getValue());
			if(row.getTblRow().get(TblOrderCallHeader.RESPONSE_REQD.toString()).getValue() != null)
				tblOrderDbBean.setResponseReqd(Long.parseLong(row.getTblRow().get(TblOrderCallHeader.RESPONSE_REQD.toString()).getValue()));
			if(row.getTblRow().get(TblOrderCallHeader.START_DATE.toString()).getValue() != null)
				tblOrderDbBean.setStartDate(Timestamp.valueOf(row.getTblRow().get(TblOrderCallHeader.START_DATE.toString()).getValue()));
			if(row.getTblRow().get(TblOrderCallHeader.UPDATED_DATE.toString()).getValue() != null)
				tblOrderDbBean.setUpdatedDate(Timestamp.valueOf(row.getTblRow().get(TblOrderCallHeader.UPDATED_DATE.toString()).getValue()));
			if(row.getTblRow().get(TblOrderCallHeader.UPSTREAM_WO_ID.toString()).getValue() != null)
				tblOrderDbBean.setUpstreamWoId(row.getTblRow().get(TblOrderCallHeader.UPSTREAM_WO_ID.toString()).getValue());
			if(row.getTblRow().get(TblOrderCallHeader.UPSTREAM_FLOW_ID.toString()).getValue() != null)
				tblOrderDbBean.setUpstreamFlowId(row.getTblRow().get(TblOrderCallHeader.UPSTREAM_FLOW_ID.toString()).getValue());
			if(row.getTblRow().get(TblOrderCallHeader.UPSTREAM_TASK_ID.toString()).getValue() != null)
				tblOrderDbBean.setUpstreamTaskId(Long.parseLong(row.getTblRow().get(TblOrderCallHeader.UPSTREAM_TASK_ID.toString()).getValue()));
			if(row.getTblRow().get(TblOrderCallHeader.TDN.toString()).getValue() != null)
				tblOrderDbBean.setTdn(row.getTblRow().get(TblOrderCallHeader.TDN.toString()).getValue());
			if(row.getTblRow().get(TblOrderCallHeader.NPA.toString()).getValue() != null)
				tblOrderDbBean.setNpa(row.getTblRow().get(TblOrderCallHeader.NPA.toString()).getValue());
			if(row.getTblRow().get(TblOrderCallHeader.CLLI.toString()).getValue() != null)
				tblOrderDbBean.setClli(row.getTblRow().get(TblOrderCallHeader.CLLI.toString()).getValue());
			if(row.getTblRow().get(TblOrderCallHeader.TIMEZONE_OFFSET.toString()).getValue() != null)
				tblOrderDbBean.setTimezoneOffset(Long.parseLong(row.getTblRow().get(TblOrderCallHeader.TIMEZONE_OFFSET.toString()).getValue()));
			if(row.getTblRow().get(TblOrderCallHeader.CATALOG.toString()).getValue() != null)
				tblOrderDbBean.setCatalog(row.getTblRow().get(TblOrderCallHeader.CATALOG.toString()).getValue());
			if(row.getTblRow().get(TblOrderCallHeader.WIRE_CENTER.toString()).getValue() != null)
				tblOrderDbBean.setWireCenter(Long.parseLong(row.getTblRow().get(TblOrderCallHeader.WIRE_CENTER.toString()).getValue()));
			if(row.getTblRow().get(TblOrderCallHeader.PARENT_ORDER.toString()).getValue() != null)
				tblOrderDbBean.setParentOrder(Long.parseLong(row.getTblRow().get(TblOrderCallHeader.PARENT_ORDER.toString()).getValue()));
			if(row.getTblRow().get(TblOrderCallHeader.TRANSLATOR_ID.toString()).getValue() != null)
				tblOrderDbBean.setTranslatorId(row.getTblRow().get(TblOrderCallHeader.TRANSLATOR_ID.toString()).getValue());
			if(row.getTblRow().get(TblOrderCallHeader.LOCKED_FROM_STATUS.toString()).getValue() != null)
				tblOrderDbBean.setLockedFromStatus(Long.parseLong(row.getTblRow().get(TblOrderCallHeader.LOCKED_FROM_STATUS.toString()).getValue()));
			if(row.getTblRow().get(TblOrderCallHeader.LOCKED_BY_VZ_ID.toString()).getValue() != null)
				tblOrderDbBean.setLockedByVzId(row.getTblRow().get(TblOrderCallHeader.LOCKED_BY_VZ_ID.toString()).getValue());
			if(row.getTblRow().get(TblOrderCallHeader.RETURN_STATUS.toString()).getValue() != null)
				tblOrderDbBean.setReturnStatus(Long.parseLong(row.getTblRow().get(TblOrderCallHeader.RETURN_STATUS.toString()).getValue()));
			if(row.getTblRow().get(TblOrderCallHeader.COS.toString()).getValue() != null)
				tblOrderDbBean.setCos(row.getTblRow().get(TblOrderCallHeader.COS.toString()).getValue());
			if(row.getTblRow().get(TblOrderCallHeader.ACCOUNT_NUMBER.toString()).getValue() != null)
				tblOrderDbBean.setAccountNumber(row.getTblRow().get(TblOrderCallHeader.ACCOUNT_NUMBER.toString()).getValue());
			if(row.getTblRow().get(TblOrderCallHeader.TRANSACTION_NUMBER.toString()).getValue() != null)
				tblOrderDbBean.setTransactionNumber(row.getTblRow().get(TblOrderCallHeader.TRANSACTION_NUMBER.toString()).getValue());
			if(row.getTblRow().get(TblOrderCallHeader.VERSION_NO.toString()).getValue() != null)
				tblOrderDbBean.setVersionNo(row.getTblRow().get(TblOrderCallHeader.VERSION_NO.toString()).getValue());
			if(row.getTblRow().get(TblOrderCallHeader.FLOW_PATH.toString()).getValue() != null)
				tblOrderDbBean.setFlowPath(row.getTblRow().get(TblOrderCallHeader.FLOW_PATH.toString()).getValue());
			if(row.getTblRow().get(TblOrderCallHeader.ORDER_TYPE.toString()).getValue() != null)
				tblOrderDbBean.setOrderType(row.getTblRow().get(TblOrderCallHeader.ORDER_TYPE.toString()).getValue());
			if(row.getTblRow().get(TblOrderCallHeader.MINOR_ORDER_TYPE.toString()).getValue() != null)
				tblOrderDbBean.setMinorOrderType(row.getTblRow().get(TblOrderCallHeader.MINOR_ORDER_TYPE.toString()).getValue());
			if(row.getTblRow().get(TblOrderCallHeader.SOACS_CODE.toString()).getValue() != null)
				tblOrderDbBean.setSoacsCode(Long.parseLong(row.getTblRow().get(TblOrderCallHeader.SOACS_CODE.toString()).getValue()));
			if(row.getTblRow().get(TblOrderCallHeader.ACTION.toString()).getValue() != null)
				tblOrderDbBean.setAction(row.getTblRow().get(TblOrderCallHeader.ACTION.toString()).getValue());
			if(row.getTblRow().get(TblOrderCallHeader.APS_STATE.toString()).getValue() != null)
				tblOrderDbBean.setApsState(Long.parseLong(row.getTblRow().get(TblOrderCallHeader.APS_STATE.toString()).getValue()));
			if(row.getTblRow().get(TblOrderCallHeader.EXK.toString()).getValue() != null)
				tblOrderDbBean.setExk(row.getTblRow().get(TblOrderCallHeader.EXK.toString()).getValue());
			if(row.getTblRow().get(TblOrderCallHeader.PROJECT_ID.toString()).getValue() != null)
				tblOrderDbBean.setProjectId(row.getTblRow().get(TblOrderCallHeader.PROJECT_ID.toString()).getValue());
			if(row.getTblRow().get(TblOrderCallHeader.ERROR_CODE.toString()).getValue() != null)
				tblOrderDbBean.setErrorCode(row.getTblRow().get(TblOrderCallHeader.ERROR_CODE.toString()).getValue());
			if(row.getTblRow().get(TblOrderCallHeader.ESAP_CLUSTER.toString()).getValue() != null)
				tblOrderDbBean.setEsapCluster(row.getTblRow().get(TblOrderCallHeader.ESAP_CLUSTER.toString()).getValue());
			rsList.add(tblOrderDbBean);
		}
		
		return rsList;
	}
	
	public DBServiceResponse executePreconfiguredQuery(ESAPDBQueryEnum sqlKey, String sourceService,
			List<String> values) throws ApplicationInterfaceException {

		DBServiceResponse responseData = null;
		
		final String searchOrderingDomainURL = orderDomainDBServiceBaseURL.concat("/dbOperation");
		logger.info("executePreconfiguredQuery(): sqlKey:{} , sourceService:{} , values:{}", sqlKey, sourceService,
				values);

		try {
			List<DBOperationRequest> requestList = new ArrayList<DBOperationRequest>();
			DBOperationRequest request = new DBOperationRequest();
			request.setSqlKey(sqlKey.name());
			request.setSourceService(sourceService);
			request.setQueryReferenceId(0L);
			request.setColumnValues(values);

			requestList.add(request);

			long startTime = System.currentTimeMillis();
			logger.debug("executePreconfiguredQuery(): Making HTTP POST Request for sql:{} at time:{}", sqlKey,
					startTime);
			logger.debug("executePreconfiguredQuery(): Service URL: {}", searchOrderingDomainURL);
			logger.debug("executePreconfiguredQuery(): Service restTemplate: {}", restTemplate);

			DBOperationResponse[] dbOperationResponse = restTemplate
					.postForObject(searchOrderingDomainURL, requestList, DBOperationResponse[].class);

			if (dbOperationResponse == null || dbOperationResponse.length == 0)
				throw new ApplicationInterfaceException(ORDERING_DOMAIN_SERVICE + "No Response from Service");

			long endTime = System.currentTimeMillis();

			logger.debug("executePreconfiguredQuery(): Received HTTP POST Response at time:{}", endTime);
			logger.info("executePreconfiguredQuery(): Time taken for Response for {} ms", (endTime - startTime));

			logger.debug("executePreconfiguredQuery(): HTTP Response: {} " + dbOperationResponse[0]);

			responseData = domainInterfaceUtil.convertDBResponseToTblData(dbOperationResponse[0]);

			logger.info("Exiting executePreconfiguredQuery() ");

		} catch (HttpStatusCodeException e) {
			logger.error("Exception received from InventoryDBService Service URL: {} ", orderDomainDBServiceBaseURL);
			logger.error("Exception received from InventoryDBService Service: {} ", e);
			logger.error("Execption during executePreconfiguredQuery execution code:{} , text:{}", e.getStatusCode(),
					e.getResponseBodyAsString());
			throw new ApplicationInterfaceException(ORDERING_DOMAIN_SERVICE + e.getMessage());
		} catch (RestClientException e) {
			logger.error("Exception received from InventoryDBService Service URL: {} ", orderDomainDBServiceBaseURL);
			logger.error("Exception received from InventoryDBService Service: {} ", e);
			throw new ApplicationInterfaceException(ORDERING_DOMAIN_SERVICE + e.getMessage());
		}
		return responseData;

	}
	
	public long getTblEnvOrderRespIdSeqNextVal() throws ApplicationInterfaceException{
		long tblEnvOrderRespId = 0l;

		/*"SELECT TBL_ENV_ORDER_RESP_ID_SEQ.NEXTVAL FROM DUAL"*/

		List<String> values = new ArrayList<String>();
		DBServiceResponse response = executePreconfiguredQuery(ESAPDBQueryEnum.GET_TBL_ENV_ORDER_RESP_ID_SEQ, "VZB_PC_COMPLETE_LOCATION", values);
		
		for (TblRow row : response.getTableRows()) {
			tblEnvOrderRespId = Long.parseLong(row.getTblRow().get("NEXTVAL").getValue());
		}
		return tblEnvOrderRespId;
	}
	
	public void insertIntoEnvOrderResp(long envOrderId, long sequenceNo, long tblEnvOrderRespId, Timestamp respDate, String responseMessage, String respErrorCode, String respType) throws ApplicationInterfaceException{
		logger.info("Entering insertIntoEnvOrderResp");
		
		/*INSERT INTO TBL_ENV_ORDER_RESP(TBL_ENV_ORDER_RESP_ID,SEQUENCE_NO,ENV_ORDER_ID,
		 * ORDER_ID,RESP_DATE,RESP_TYPE,RESP_DESC,RESP_ERROR_CODE,MILESTONE) 
		 * VALUES (TBL_ENV_ORDER_RESP_ID_SEQ.NEXTVAL,?,?,?,?,?,?,?,?)*/
		
		String sequenceNoParam = String.valueOf(sequenceNo);
		String envOrderIdParam = String.valueOf(envOrderId);
		String orderIdParam = String.valueOf(-1);
		String respDateParam = String.valueOf(respDate);
		String responseErrorCode = (respErrorCode == null) ? "ESP_SUCCESS"
				: respErrorCode;
		String milestoneParam = String.valueOf(12);
		String tblEnvOrderRespIdParam = String.valueOf(tblEnvOrderRespId);
		
		List<String[]> insertKeyValuePairList = new ArrayList<>();
		insertKeyValuePairList.add(new String[] { "SEQUENCE_NO", sequenceNoParam });
		insertKeyValuePairList.add(new String[] { "ENV_ORDER_ID", envOrderIdParam });
		insertKeyValuePairList.add(new String[] { "ORDER_ID",  orderIdParam});
		insertKeyValuePairList.add(new String[] { "RESP_DATE",  respDateParam});
		insertKeyValuePairList.add(new String[] { "RESP_TYPE",  respType});
		insertKeyValuePairList.add(new String[] { "RESP_DESC",  responseMessage});
		insertKeyValuePairList.add(new String[] { "RESP_ERROR_CODE",  responseErrorCode});
		insertKeyValuePairList.add(new String[] { "MILESTONE",  milestoneParam});
		
		List<String[]> sequenceKeyValuePairList = new ArrayList<>();
		sequenceKeyValuePairList.add(new String[] { "TBL_ENV_ORDER_RESP_ID", "TBL_ENV_ORDER_RESP_ID_SEQ" });
		
		insertOrderingDomain("TBL_ENV_ORDER_RESP", insertKeyValuePairList, sequenceKeyValuePairList);
		
		logger.info("Exiting insertIntoEnvOrderResp");
	}
}
