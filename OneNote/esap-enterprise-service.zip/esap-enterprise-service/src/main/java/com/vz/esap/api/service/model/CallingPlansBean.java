package com.vz.esap.api.service.model;

import java.io.Serializable;
import java.sql.Timestamp;

public class CallingPlansBean implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private int callingPlanId;
	private String callingPlanName;
	private long defaultInd;
	private long iIntraLocation;
	private long iInterLocation;
	private long iCollectCalls;
	private long oIntraLocation;
	private long oLocal;
	private long oTollFree;
	private long oToll;
	private long oInternational;
	private long oCasual;
	private long oOperatorAssisted;
	private long oChargedDirAssist;
	private long oSplServices1;
	private long oSplServices2;
	private long oPrmServices1;
	private long oPrmServices2;
	private long oUrlDialing;
	private long oUnknown;
	private long fIntraLocation;
	private long fLocal;
	private long fTollFree;
	private long fToll;
	private long fInternational;
	private long fCasual;
	private long fOperatorAssisted;
	private long fChargedDirAssist;
	private long fSplServices1;
	private long fSplServices2;
	private long fPrmServices1;
	private long fPrmServices2;
	private long fUrlDialing;
	private long fUnknown;
	private long bInterLocation;
	private String telephone1;
	private String telephone2;
	private String telephone3;
	private String createdBy;
	private Timestamp creationDate;
	private String modifiedBy;
	private Timestamp lastModifiedDate;
	private long envOrderId;

	public String toString() {
		return "callingPlanId=" + this.callingPlanId + "\n" + "callingPlanName=" + this.callingPlanName + "\n"
				+ "defaultInd=" + this.defaultInd + "\n" + "iIntraLocation=" + this.iIntraLocation + "\n"
				+ "iInterLocation=" + this.iInterLocation + "\n" + "iCollectCalls=" + this.iCollectCalls + "\n"
				+ "oIntraLocation=" + this.oIntraLocation + "\n" + "oLocal=" + this.oLocal + "\n" + "oTollFree="
				+ this.oTollFree + "\n" + "oToll=" + this.oToll + "\n" + "oInternational=" + this.oInternational + "\n"
				+ "oCasual=" + this.oCasual + "\n" + "oOperatorAssisted=" + this.oOperatorAssisted + "\n"
				+ "oChargedDirAssist=" + this.oChargedDirAssist + "\n" + "oSplServices1=" + this.oSplServices1 + "\n"
				+ "oSplServices2=" + this.oSplServices2 + "\n" + "oPrmServices1=" + this.oPrmServices1 + "\n"
				+ "oPrmServices2=" + this.oPrmServices2 + "\n" + "oUrlDialing=" + this.oUrlDialing + "\n" + "oUnknown="
				+ this.oUnknown + "\n" + "fIntraLocation=" + this.fIntraLocation + "\n" + "fLocal=" + this.fLocal + "\n"
				+ "fTollFree=" + this.fTollFree + "\n" + "fToll=" + this.fToll + "\n" + "fInternational="
				+ this.fInternational + "\n" + "fCasual=" + this.fCasual + "\n" + "fOperatorAssisted="
				+ this.fOperatorAssisted + "\n" + "fChargedDirAssist=" + this.fChargedDirAssist + "\n"
				+ "fSplServices1=" + this.fSplServices1 + "\n" + "fSplServices2=" + this.fSplServices2 + "\n"
				+ "fPrmServices1=" + this.fPrmServices1 + "\n" + "fPrmServices2=" + this.fPrmServices2 + "\n"
				+ "fUrlDialing=" + this.fUrlDialing + "\n" + "fUnknown=" + this.fUnknown + "\n" + "bInterLocation="
				+ this.bInterLocation + "\n" + "telephone1=" + this.telephone1 + "\n" + "telephone2=" + this.telephone2
				+ "\n" + "telephone3=" + this.telephone3 + "\n" + "createdBy=" + this.createdBy + "\n" + "creationDate="
				+ this.creationDate + "\n" + "modifiedBy=" + this.modifiedBy + "\n" + "lastModifiedDate="
				+ this.lastModifiedDate + "\n" + "envOrderId=" + this.envOrderId + "\n";
	}

	public void setCallingPlanId(int callingPlanId) {
		this.callingPlanId = callingPlanId;
	}

	public int getCallingPlanId() {
		return this.callingPlanId;
	}

	public void setCallingPlanName(String callingPlanName) {
		this.callingPlanName = callingPlanName;
	}

	public String getCallingPlanName() {
		return this.callingPlanName;
	}

	public void setDefaultInd(long defaultInd) {
		this.defaultInd = defaultInd;
	}

	public long getDefaultInd() {
		return this.defaultInd;
	}

	public void setIIntraLocation(long iIntraLocation) {
		this.iIntraLocation = iIntraLocation;
	}

	public long getIIntraLocation() {
		return this.iIntraLocation;
	}

	public void setIInterLocation(long iInterLocation) {
		this.iInterLocation = iInterLocation;
	}

	public long getIInterLocation() {
		return this.iInterLocation;
	}

	public void setICollectCalls(long iCollectCalls) {
		this.iCollectCalls = iCollectCalls;
	}

	public long getICollectCalls() {
		return this.iCollectCalls;
	}

	public void setOIntraLocation(long oIntraLocation) {
		this.oIntraLocation = oIntraLocation;
	}

	public long getOIntraLocation() {
		return this.oIntraLocation;
	}

	public void setOLocal(long oLocal) {
		this.oLocal = oLocal;
	}

	public long getOLocal() {
		return this.oLocal;
	}

	public void setOTollFree(long oTollFree) {
		this.oTollFree = oTollFree;
	}

	public long getOTollFree() {
		return this.oTollFree;
	}

	public void setOToll(long oToll) {
		this.oToll = oToll;
	}

	public long getOToll() {
		return this.oToll;
	}

	public void setOInternational(long oInternational) {
		this.oInternational = oInternational;
	}

	public long getOInternational() {
		return this.oInternational;
	}

	public void setOCasual(long oCasual) {
		this.oCasual = oCasual;
	}

	public long getOCasual() {
		return this.oCasual;
	}

	public void setOOperatorAssisted(long oOperatorAssisted) {
		this.oOperatorAssisted = oOperatorAssisted;
	}

	public long getOOperatorAssisted() {
		return this.oOperatorAssisted;
	}

	public void setOChargedDirAssist(long oChargedDirAssist) {
		this.oChargedDirAssist = oChargedDirAssist;
	}

	public long getOChargedDirAssist() {
		return this.oChargedDirAssist;
	}

	public void setOSplServices1(long oSplServices1) {
		this.oSplServices1 = oSplServices1;
	}

	public long getOSplServices1() {
		return this.oSplServices1;
	}

	public void setOSplServices2(long oSplServices2) {
		this.oSplServices2 = oSplServices2;
	}

	public long getOSplServices2() {
		return this.oSplServices2;
	}

	public void setOPrmServices1(long oPrmServices1) {
		this.oPrmServices1 = oPrmServices1;
	}

	public long getOPrmServices1() {
		return this.oPrmServices1;
	}

	public void setOPrmServices2(long oPrmServices2) {
		this.oPrmServices2 = oPrmServices2;
	}

	public long getOPrmServices2() {
		return this.oPrmServices2;
	}

	public void setOUrlDialing(long oUrlDialing) {
		this.oUrlDialing = oUrlDialing;
	}

	public long getOUrlDialing() {
		return this.oUrlDialing;
	}

	public void setOUnknown(long oUnknown) {
		this.oUnknown = oUnknown;
	}

	public long getOUnknown() {
		return this.oUnknown;
	}

	public void setFIntraLocation(long fIntraLocation) {
		this.fIntraLocation = fIntraLocation;
	}

	public long getFIntraLocation() {
		return this.fIntraLocation;
	}

	public void setFLocal(long fLocal) {
		this.fLocal = fLocal;
	}

	public long getFLocal() {
		return this.fLocal;
	}

	public void setFTollFree(long fTollFree) {
		this.fTollFree = fTollFree;
	}

	public long getFTollFree() {
		return this.fTollFree;
	}

	public void setFToll(long fToll) {
		this.fToll = fToll;
	}

	public long getFToll() {
		return this.fToll;
	}

	public void setFInternational(long fInternational) {
		this.fInternational = fInternational;
	}

	public long getFInternational() {
		return this.fInternational;
	}

	public void setFCasual(long fCasual) {
		this.fCasual = fCasual;
	}

	public long getFCasual() {
		return this.fCasual;
	}

	public void setFOperatorAssisted(long fOperatorAssisted) {
		this.fOperatorAssisted = fOperatorAssisted;
	}

	public long getFOperatorAssisted() {
		return this.fOperatorAssisted;
	}

	public void setFChargedDirAssist(long fChargedDirAssist) {
		this.fChargedDirAssist = fChargedDirAssist;
	}

	public long getFChargedDirAssist() {
		return this.fChargedDirAssist;
	}

	public void setFSplServices1(long fSplServices1) {
		this.fSplServices1 = fSplServices1;
	}

	public long getFSplServices1() {
		return this.fSplServices1;
	}

	public void setFSplServices2(long fSplServices2) {
		this.fSplServices2 = fSplServices2;
	}

	public long getFSplServices2() {
		return this.fSplServices2;
	}

	public void setFPrmServices1(long fPrmServices1) {
		this.fPrmServices1 = fPrmServices1;
	}

	public long getFPrmServices1() {
		return this.fPrmServices1;
	}

	public void setFPrmServices2(long fPrmServices2) {
		this.fPrmServices2 = fPrmServices2;
	}

	public long getFPrmServices2() {
		return this.fPrmServices2;
	}

	public void setFUrlDialing(long fUrlDialing) {
		this.fUrlDialing = fUrlDialing;
	}

	public long getFUrlDialing() {
		return this.fUrlDialing;
	}

	public void setFUnknown(long fUnknown) {
		this.fUnknown = fUnknown;
	}

	public long getFUnknown() {
		return this.fUnknown;
	}

	public void setBInterLocation(long bInterLocation) {
		this.bInterLocation = bInterLocation;
	}

	public long getBInterLocation() {
		return this.bInterLocation;
	}

	public void setTelephone1(String telephone1) {
		this.telephone1 = telephone1;
	}

	public String getTelephone1() {
		return this.telephone1;
	}

	public void setTelephone2(String telephone2) {
		this.telephone2 = telephone2;
	}

	public String getTelephone2() {
		return this.telephone2;
	}

	public void setTelephone3(String telephone3) {
		this.telephone3 = telephone3;
	}

	public String getTelephone3() {
		return this.telephone3;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreationDate(Timestamp creationDate) {
		this.creationDate = creationDate;
	}

	public Timestamp getCreationDate() {
		return this.creationDate;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public String getModifiedBy() {
		return this.modifiedBy;
	}

	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}

	public void setEnvOrderId(long envOrderId) {
		this.envOrderId = envOrderId;
	}

	public long getEnvOrderId() {
		return this.envOrderId;
	}

	public void copyFrom(CallingPlansBean obj) {
		setCallingPlanId(obj.getCallingPlanId());
		setCallingPlanName(obj.getCallingPlanName());
		setDefaultInd(obj.getDefaultInd());
		setIIntraLocation(obj.getIIntraLocation());
		setIInterLocation(obj.getIInterLocation());
		setICollectCalls(obj.getICollectCalls());
		setOIntraLocation(obj.getOIntraLocation());
		setOLocal(obj.getOLocal());
		setOTollFree(obj.getOTollFree());
		setOToll(obj.getOToll());
		setOInternational(obj.getOInternational());
		setOCasual(obj.getOCasual());
		setOOperatorAssisted(obj.getOOperatorAssisted());
		setOChargedDirAssist(obj.getOChargedDirAssist());
		setOSplServices1(obj.getOSplServices1());
		setOSplServices2(obj.getOSplServices2());
		setOPrmServices1(obj.getOPrmServices1());
		setOPrmServices2(obj.getOPrmServices2());
		setOUrlDialing(obj.getOUrlDialing());
		setOUnknown(obj.getOUnknown());
		setFIntraLocation(obj.getFIntraLocation());
		setFLocal(obj.getFLocal());
		setFTollFree(obj.getFTollFree());
		setFToll(obj.getFToll());
		setFInternational(obj.getFInternational());
		setFCasual(obj.getFCasual());
		setFOperatorAssisted(obj.getFOperatorAssisted());
		setFChargedDirAssist(obj.getFChargedDirAssist());
		setFSplServices1(obj.getFSplServices1());
		setFSplServices2(obj.getFSplServices2());
		setFPrmServices1(obj.getFPrmServices1());
		setFPrmServices2(obj.getFPrmServices2());
		setFUrlDialing(obj.getFUrlDialing());
		setFUnknown(obj.getFUnknown());
		setBInterLocation(obj.getBInterLocation());
		setTelephone1(obj.getTelephone1());
		setTelephone2(obj.getTelephone2());
		setTelephone3(obj.getTelephone3());
		setCreatedBy(obj.getCreatedBy());
		setCreationDate(obj.getCreationDate());
		setModifiedBy(obj.getModifiedBy());
		setLastModifiedDate(obj.getLastModifiedDate());
		setEnvOrderId(obj.getEnvOrderId());
	}
}
