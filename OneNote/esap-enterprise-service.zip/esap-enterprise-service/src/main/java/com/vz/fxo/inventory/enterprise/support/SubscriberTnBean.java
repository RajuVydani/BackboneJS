package com.vz.fxo.inventory.enterprise.support;

import java.util.ArrayList;
import java.util.List;
import java.sql.Timestamp;

import esap.db.TblSubscriberTnDbBean;

public class SubscriberTnBean
{
	//members
	private int subscriberTnId;
	private long natUserId;
	private String userId;
	private String subId;
	private long npaSplitStatus;
	private String modifiedBy;
	private String createdBy;
	private String extension;
	private long slotNo;
	protected java.sql.Timestamp creationDate;
	protected java.sql.Timestamp lastModifiedDate;
	protected long envOrderId;
    protected List<String> logTrail;
    protected long tnOnOff; 
    protected short actDeact; 

    	/**
	 * Default Constructor -- Initializes all fields to default values.
	 */
    	public SubscriberTnBean() {
    	this.logTrail = new ArrayList<String>();	
		this.subscriberTnId = 0;
		this.natUserId = 0;
		this.userId = "";
		this.subId = new String("");
		this.npaSplitStatus = 0;
		this.modifiedBy = new String("");
		this.createdBy = new String("");
		this.creationDate = null;
		this.lastModifiedDate = null;
		this.envOrderId = 0;
		this.slotNo=-1;
		this.extension = "NONE";
		//IR #1353501  - For CSSOP TN_ON_OFF Needs to check
		this.tnOnOff = -1; 
		this.actDeact = -1; 
	}
	/**
	 * Constructor
	 * @param subTnBean
	 */
	public SubscriberTnBean(SubscriberTnBean subTnBean){
		this.subscriberTnId = subTnBean.subscriberTnId;
		this.natUserId = subTnBean.natUserId;
		this.userId = subTnBean.userId;
		this.subId = subTnBean.subId;
		this.npaSplitStatus = subTnBean.npaSplitStatus;
		this.modifiedBy = subTnBean.modifiedBy;
		this.createdBy = subTnBean.createdBy;
		this.creationDate = subTnBean.creationDate;
		this.lastModifiedDate = subTnBean.lastModifiedDate;
		this.envOrderId = subTnBean.envOrderId ;
		this.extension = subTnBean.extension;
		this.slotNo = subTnBean.slotNo;
		this.logTrail = subTnBean.logTrail;
		//IR #1353501  - For CSSOP TN_ON_OFF Needs to check
		this.tnOnOff = subTnBean.tnOnOff;
		this.actDeact = subTnBean.actDeact;
	}
	
	public SubscriberTnBean(TblSubscriberTnDbBean subTnBean){
		this.subscriberTnId = subTnBean.getSubscriberTnId();       
		this.natUserId = 	subTnBean.getNatUserId();	
		if(!subTnBean.getUserId().equalsIgnoreCase("0"))
			this.userId =  subTnBean.getUserId(); 
		
		this.subId = subTnBean.getSubId();
		this.npaSplitStatus = subTnBean.getNpaSplitStatus();
		this.modifiedBy = subTnBean.getModifiedBy();
		this.createdBy = subTnBean.getCreatedBy();
		this.creationDate =subTnBean.getCreationDate();
		this.lastModifiedDate =subTnBean.getLastModifiedDate();
		this.envOrderId = subTnBean.getEnvOrderId();
		this.extension = subTnBean.getExtension();
		this.slotNo =subTnBean.getSlotNumber();
		//IR #1353501  - For CSSOP TN_ON_OFF Needs to check
		//this.tnOnOff = subTnBean.getTnOnOff();
	}

	//getter - setters
	public String getCreatedBy() {
		return createdBy;
	}
	public Timestamp getLastModifiedDate() {
		return lastModifiedDate;
	}
	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public long getNatUserId() {
		return natUserId;
	}
	public void setNatUserId(long natUserId) {
		this.natUserId = natUserId;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getSubId() {
		return subId;
	}
	public void setSubId(String subId) {
		this.subId = subId;
	}
	public long getNpaSplitStatus() {
		return npaSplitStatus;
	}
	public void setNpaSplitStatus(long npaSplitStatus) {
		this.npaSplitStatus = npaSplitStatus;
	}
	public String getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public int getSubscriberTnId() {
		return subscriberTnId;
	}
	public void setSubscriberTnId(int subscriberTnId) {
		this.subscriberTnId = subscriberTnId;
	}
	public java.sql.Timestamp getCreationDate() {
		return creationDate;
	}
	public void setCreationDate(java.sql.Timestamp creationDate) {
		this.creationDate = creationDate;
	}

	public long getEnvOrderId() {
		return envOrderId;
	}
	public void setEnvOrderId(long envOrderId) {
		this.envOrderId = envOrderId;
	}
	
   public void setExtension(String extension) {
	   this.extension = extension;
   }
  
   public String getExtension(){
	   return extension;
   }
   
   public void setSlotNo(long slotNo){
	   this.slotNo = slotNo;
  }
  public long getSlotNo() {
	  return slotNo;
  }
  public void setLogTrail(String logStr)
  {
      logTrail.add(logStr);
  }

  public List<String> getLogTrail()
  {
      return logTrail;
  }
	
  public long getTnOnOff() {
	return tnOnOff;
  }
  public void setTnOnOff(long tnOnOff) {
	this.tnOnOff = tnOnOff;
  }

	public short getActDeact() 
	{
    	return actDeact;
  	}
  	public void setActDeact(short actDeact) {
    	this.actDeact = actDeact;
  	}
}

