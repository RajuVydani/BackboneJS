/**
 * 
 */
package com.vz.fxo.inventory.enterprise.support;
import java.io.Serializable;
import java.sql.Timestamp;

/**
 * @author v034934
 *
 */
public class FmcgVendorBean implements Serializable {

	protected int fmcgVendorId;
	protected String fmcgVendorName;
	protected String fmcgVendorDesc;
	protected String createdBy;
	protected Timestamp creationDate;
	protected String modifiedBy;
	protected Timestamp lastModifiedDate;
	
	/**
	 * 
	 *Default Constructor -- Initializes all fields to default values.
	 */
    public FmcgVendorBean() {
            this.fmcgVendorId = 0;
            this.fmcgVendorDesc = new String("");
            this.createdBy = null;
            this.modifiedBy = new String("");
            this.creationDate = null;
            this.lastModifiedDate = null;
    }
	/**
	 * Constructor
	 * @param fmcgVendorDbBean
	 */	
	public FmcgVendorBean(FmcgVendorBean fmcgVendorDbBean) {
		this.fmcgVendorId = fmcgVendorDbBean.fmcgVendorId;
		this.fmcgVendorName = fmcgVendorDbBean.fmcgVendorName;
		this.fmcgVendorDesc = fmcgVendorDbBean.fmcgVendorDesc;
		this.createdBy = fmcgVendorDbBean.createdBy;
		this.creationDate = fmcgVendorDbBean.creationDate;
		this.modifiedBy = fmcgVendorDbBean.modifiedBy;
		this.lastModifiedDate = fmcgVendorDbBean.lastModifiedDate;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public Timestamp getCreationDate() {
		return creationDate;
	}
	public void setCreationDate(Timestamp creationDate) {
		this.creationDate = creationDate;
	}
	public String getFmcgVendorDesc() {
		return fmcgVendorDesc;
	}
	public void setFmcgVendorDesc(String fmcgVendorDesc) {
		this.fmcgVendorDesc = fmcgVendorDesc;
	}
	public int getFmcgVendorId() {
		return fmcgVendorId;
	}
	public void setFmcgVendorId(int fmcgVendorId) {
		this.fmcgVendorId = fmcgVendorId;
	}
	public String getFmcgVendorName() {
		return fmcgVendorName;
	}
	public void setFmcgVendorName(String fmcgVendorName) {
		this.fmcgVendorName = fmcgVendorName;
	}
	public Timestamp getLastModifiedDate() {
		return lastModifiedDate;
	}
	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}
	public String getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	
	
	public String toString(){
		StringBuilder sb = new StringBuilder();
		String nl = System.getProperty("line.separator");
		
		sb.append(nl)
		.append("fmcgVendorId: 		").append(fmcgVendorId).append(nl)
		.append("fmcgVendorName:    ").append(fmcgVendorName).append(nl)
		.append("fmcgVendorDesc:  ").append(fmcgVendorDesc).append(nl)
		.append("createdBy:   		").append(createdBy).append(nl)
		.append("creationDate:  	").append(creationDate).append(nl)
		.append("modifiedBy:   		").append(modifiedBy).append(nl)
		.append("lastModifiedDate:  ").append(lastModifiedDate).append(nl);
		
		return sb.toString();
	}
	
}
