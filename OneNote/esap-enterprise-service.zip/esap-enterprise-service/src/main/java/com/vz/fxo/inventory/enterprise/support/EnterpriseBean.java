package com.vz.fxo.inventory.enterprise.support;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import EsapEnumPkg.EsapMigrationEnum;
import EsapEnumPkg.VzbVoipEnum;
import esap.db.DBTblBsAs;
import esap.db.IasaCustomerDbBean;
import esap.db.IpcomCustomerDbBean;
import esap.db.TblDigitStringsDbBean;
import esap.db.TblVzbStateGatewayMapDbBean;

public class EnterpriseBean implements Serializable {
	// members

	protected List<GatewayDeviceBean> deviceList;
	protected List<FeaturesBean> authFeaturesList;
	//KR-start policy changes
	protected List<PolicyFeaturesBean> policyFeaturesList;
	protected List<ServicePackFeaturesBean> servicePackFeaturesList;
	protected String bwEnterPrsiseId;
	protected String authFeatureType;
	protected int defaultAuthServiceId=0;
	//KR-end
	protected DBTblBsAs bsAsDbBean;
	protected CallingPlanBean callingPlanBean;
	protected List<DialPlanBean> dialPlanList;
	protected List<PrefixRoutingBean> prefixRoutingList;
	protected List<TblVzbStateGatewayMapDbBean> thirdPartyDeviceList;
	protected List<String> logTrail;
	protected List<DepartmentBean> departmentList;
	protected List<EnterpriseAdminBean> entAdminList;
	protected List<TblDigitStringsDbBean> digitStringList;
	protected List<TblEntBillFeaturesBean> entBillFeatBeanList;
	protected TblEntBillFeaturesBean entBillFeatBean;
	protected String customerId;
	protected String accountName;
	protected String customerName;
	protected long regionId;
	protected long isRIVCustomer;

	protected long productType;
	protected long billingSystem;
	protected String orderSource;
	protected String contactFirstName;
	protected String contactLastName;
	protected String contactTitle;
	protected String contactPrimaryPhone;
	protected String contactAltPhone;
	protected String contactFax;
	protected String contactCell;
	protected String contactPager;
	protected String contactEmail;
	protected String contactAddr1;
	protected String contactAddr2;
	protected String contactCity;
	protected String contactState;
	protected String contactZip;
	protected String contactCountry;
	protected String billContactPriPhone;
	protected String billContactAltPhone;
	protected String billContactCell;
	protected String billContactPager;
	protected String billContactEmail;
	protected String billContactAddr1;
	protected String billContactAddr2;
	protected String billContactCity;
	protected String billContactState;
	protected String billContactZip;
	protected String billContactCountry;
	protected long salesSegment;
	protected String salesRepId;
	protected String salesRepName;
	protected String salesRepPhone;
	protected String salesRepEmail;
	protected String custCorpId;
	protected long orderVerification;
	protected String supportName;
	protected String supportPhone;
	protected long emeaServiceSupport;
	protected String custSensitivityLevel;
	protected long custGarmStatus;
	protected long custActiveInd;
	protected long custSbcMigInd;// YesNoType
	protected long custIcpMigrated;// YesNoType

	protected long customerType;
	protected long custMarket;
	protected long platformIndicator;
	protected String vmPartitionId;
	protected long pubIp;
	protected long onNetInterco;
	protected String sipDomain;
	protected long asId;
	protected long entCclInd;
	protected long qosInd;
	protected long ieanLength;
	protected String vnetCorpId;
	protected String contractInd;
	protected String agencyHierCode;
	protected String xrefCustomerId;
	protected long callingPlanId;
	protected long authServicesId;
	//KR-start 
	protected long policyServicesId;
	protected long servicePackServicesId;
	//KR -end
	protected long entActiveInd;
	protected long entSbcMigInd;// YesNoType

	protected long bsBlockInd;
	protected long envOrderId;
	protected String createdBy;
	protected String modifiedBy;
	protected java.sql.Timestamp creationDate;
	protected java.sql.Timestamp lastModifiedDate;
	protected boolean getAll;

	/* New Fields added by Vijaykumar.S on (24-08-09) */
	protected String commonCustomerId;
	protected String commonCustomerName;
	protected String vpnName;
	protected String sbcActivationSystem;
	protected long emeaBillingSystem;

	// Jan 2011 Release Changes
	protected String naspId;
	// IR #1484223: for GUI
	protected long onNetStat;
	// 53938.AA Business Continuity Ph 1 - changes for july 2011
	protected String lorFlag;

	protected long loadSharing;// for sbc loadsharing
	protected long orderPlatform;
	protected short restrictedAccess;

	protected String lorId;
	protected String address;
	protected String city;
	protected String state;
	protected String zip;
	protected String country;
	protected short soEnabled;
	protected long usLdAndLocalBestPool;
	protected long usLdOnlyBestPool;
	protected long emeaApacBestPool;
	protected long usLdAndLocalBestPlusPool;
	protected long usLdOnlyBestPlusPool;
	protected long emeaApacBestPlusPool;
	protected String gchId;
	protected short hybridInd;
	protected long approvedCcl;
	protected long entTrunkCclSum;
	protected long enterpriseTrunkingType;
	protected String custPriceBookId;
	protected String contractId;
	protected String quoteId;
	protected Timestamp catalogueReferenceTime;
	protected long designId;

	// GSAM E2EI R5
	protected String e2eiSensitvityLevel;
	private long e2eiMigStatus;
	private long e2eiMigLock;
	private Timestamp e2eiMigDate;

	protected short calnetSubContractId; // added by z658915 for CALNET_SUB_CONTRACT_ID
	
	protected long entCumCcl;
	
	

	

	/**
	 * Default Constructor -- Initializes all fields to default values.
	 */
	public EnterpriseBean() {
		deviceList = new ArrayList<GatewayDeviceBean>();
		authFeaturesList = new ArrayList<FeaturesBean>();
		//KR- start policy features
		policyFeaturesList=new ArrayList<PolicyFeaturesBean>();
		servicePackFeaturesList=new ArrayList<ServicePackFeaturesBean>();
		////KR- end
		bsAsDbBean = new DBTblBsAs();
		entBillFeatBean = new TblEntBillFeaturesBean();
		entBillFeatBeanList = new ArrayList<TblEntBillFeaturesBean>();
		dialPlanList = new ArrayList<DialPlanBean>();
		digitStringList = new ArrayList<TblDigitStringsDbBean>();
		logTrail = new ArrayList<String>();
		this.callingPlanBean = new CallingPlanBean();
		this.prefixRoutingList = new ArrayList<PrefixRoutingBean>();
		this.thirdPartyDeviceList = new ArrayList<TblVzbStateGatewayMapDbBean>();
		departmentList = null;

		entAdminList = new ArrayList<EnterpriseAdminBean>();
		this.customerId = new String("");
		this.accountName = new String("NONE");
		this.customerName = new String("NONE");
		this.regionId = 0;
		this.productType = 0;
		this.billingSystem = 0;
		this.orderSource = new String("NONE");
		this.contactFirstName = new String("NONE");
		this.contactLastName = new String("NONE");
		this.contactTitle = new String("NONE");
		this.contactPrimaryPhone = new String("NONE");
		this.contactAltPhone = new String("NONE");
		this.contactFax = new String("NONE");
		this.sbcActivationSystem = new String("NONE");
		this.contactCell = new String("NONE");
		this.contactPager = new String("NONE");
		this.contactEmail = new String("NONE");
		this.contactAddr1 = new String("NONE");
		this.contactAddr2 = new String("NONE");
		this.contactCity = new String("NONE");
		this.contactState = new String("NONE");
		this.contactZip = new String("NONE");
		this.contactCountry = new String("NONE");
		this.billContactPriPhone = new String("NONE");
		this.billContactAltPhone = new String("NONE");
		this.billContactCell = new String("NONE");
		this.billContactPager = new String("NONE");
		this.billContactEmail = new String("NONE");
		this.billContactAddr1 = new String("NONE");
		this.billContactAddr2 = new String("NONE");
		this.billContactCity = new String("NONE");
		this.billContactState = new String("NONE");
		this.billContactZip = new String("NONE");
		this.billContactCountry = new String("NONE");
		this.salesSegment = -1;
		this.salesRepId = new String("NONE");
		this.salesRepName = new String("NONE");
		this.salesRepPhone = new String("NONE");
		this.salesRepEmail = new String("NONE");
		this.custCorpId = new String("NONE");
		this.orderVerification = -1;
		this.supportName = new String("NONE");
		this.supportPhone = new String("NONE");
		this.emeaServiceSupport = 0;
		this.custSensitivityLevel = new String("");
		this.custGarmStatus = 0;
		this.custActiveInd = 1;
		this.custSbcMigInd = 0;
		this.custIcpMigrated = 0;
		this.customerType = 0;
		this.custMarket = 0;
		this.platformIndicator = 0;
		this.vmPartitionId = new String("NONE");
		this.pubIp = -1;
		this.onNetInterco = 0;
		this.sipDomain = new String("NONE");
		this.asId = -1;
		this.entCclInd = 0;
		this.qosInd = 0;
		this.ieanLength = -1;
		this.vnetCorpId = new String("NONE");
		this.contractInd = new String("NONE");
		this.agencyHierCode = new String("NONE");
		this.xrefCustomerId = new String("NONE");
		this.callingPlanId = 0;
		this.authServicesId = 0;
		this.entActiveInd = 1;
		this.entSbcMigInd = 0;
		this.bsBlockInd = 0;
		this.envOrderId = -1;
		this.createdBy = new String("");
		this.modifiedBy = new String("");
		this.creationDate = null;
		this.lastModifiedDate = null;
		this.commonCustomerId = new String("NONE");
		this.vpnName = new String("NONE");
		this.getAll = false;
		this.emeaBillingSystem = -1;
		this.isRIVCustomer = -1;
		// Jan 2011 Release changes
		this.naspId = "";
		this.onNetStat = -1;
		// 53938.AA Business Continuity Ph 1 - changes for july 2011
		this.lorFlag = "NONE";
		this.loadSharing = 0;
		this.orderPlatform = 0;
		this.restrictedAccess = -1;
		this.lorId = "NONE";
		this.address = "NONE";
		this.city = "NONE";
		this.state = "NONE";
		this.zip = "NONE";
		this.country = "NONE";
		this.soEnabled = -1;
		this.usLdAndLocalBestPool = -1;
		this.usLdOnlyBestPool = -1;
		this.emeaApacBestPool = -1;
		this.gchId = "NONE";
		this.hybridInd = -1;
		this.approvedCcl = -1;
		this.entTrunkCclSum = -1;
		this.enterpriseTrunkingType = 1;
		this.custPriceBookId = "NONE";
		this.contractId = "NONE";
		this.quoteId = "NONE";
		this.catalogueReferenceTime = null;
		this.designId = -1;
		this.e2eiSensitvityLevel = "1";
		this.usLdAndLocalBestPlusPool = -1;
		this.usLdOnlyBestPlusPool = -1;
		this.emeaApacBestPlusPool = -1;

		this.calnetSubContractId = -1; // added by z658915
		this.entCumCcl = -1;
	}

	/**
	 * Constructor
	 * 
	 * @param enterpriseBean
	 */
	public EnterpriseBean(EnterpriseBean enterpriseBean) {
		this.deviceList = enterpriseBean.deviceList;
		this.authFeaturesList = enterpriseBean.authFeaturesList;
		//KR-start policy  changes 
		this.policyFeaturesList=enterpriseBean.policyFeaturesList;
		this.servicePackFeaturesList=enterpriseBean.servicePackFeaturesList;
		//KR-end
		this.bsAsDbBean = enterpriseBean.bsAsDbBean;
		this.entBillFeatBean = enterpriseBean.entBillFeatBean;
		this.entBillFeatBeanList = enterpriseBean.entBillFeatBeanList;
		this.callingPlanBean = enterpriseBean.callingPlanBean;
		this.dialPlanList = enterpriseBean.dialPlanList;
		this.prefixRoutingList = enterpriseBean.prefixRoutingList;
		this.thirdPartyDeviceList = enterpriseBean.thirdPartyDeviceList;
		this.logTrail = enterpriseBean.logTrail;
		this.departmentList = enterpriseBean.departmentList;
		this.entAdminList = enterpriseBean.entAdminList;
		this.customerId = enterpriseBean.customerId;
		this.accountName = enterpriseBean.accountName;
		this.customerName = enterpriseBean.customerName;
		this.regionId = enterpriseBean.regionId;
		this.productType = enterpriseBean.productType;
		this.billingSystem = enterpriseBean.billingSystem;
		this.orderSource = enterpriseBean.orderSource;
		this.contactFirstName = enterpriseBean.contactFirstName;
		this.contactLastName = enterpriseBean.contactLastName;
		this.contactTitle = enterpriseBean.contactTitle;
		this.contactPrimaryPhone = enterpriseBean.contactPrimaryPhone;
		this.contactAltPhone = enterpriseBean.contactAltPhone;
		this.contactFax = enterpriseBean.contactFax;
		this.contactCell = enterpriseBean.contactCell;
		this.contactPager = enterpriseBean.contactPager;
		this.contactEmail = enterpriseBean.contactEmail;
		this.contactAddr1 = enterpriseBean.contactAddr1;
		this.contactAddr2 = enterpriseBean.contactAddr2;
		this.contactCity = enterpriseBean.contactCity;
		this.contactState = enterpriseBean.contactState;
		this.contactZip = enterpriseBean.contactZip;
		this.contactCountry = enterpriseBean.contactCountry;
		this.billContactPriPhone = enterpriseBean.billContactPriPhone;
		this.billContactAltPhone = enterpriseBean.billContactAltPhone;
		this.billContactCell = enterpriseBean.billContactCell;
		this.billContactPager = enterpriseBean.billContactPager;
		this.billContactEmail = enterpriseBean.billContactEmail;
		this.billContactAddr1 = enterpriseBean.billContactAddr1;
		this.billContactAddr2 = enterpriseBean.billContactAddr2;
		this.billContactCity = enterpriseBean.billContactCity;
		this.billContactState = enterpriseBean.billContactState;
		this.billContactZip = enterpriseBean.billContactZip;
		this.billContactCountry = enterpriseBean.billContactCountry;
		this.salesSegment = enterpriseBean.salesSegment;
		this.salesRepId = enterpriseBean.salesRepId;
		this.salesRepName = enterpriseBean.salesRepName;
		this.salesRepPhone = enterpriseBean.salesRepPhone;
		this.salesRepEmail = enterpriseBean.salesRepEmail;
		this.custCorpId = enterpriseBean.custCorpId;
		this.orderVerification = enterpriseBean.orderVerification;
		this.supportName = enterpriseBean.supportName;
		this.supportPhone = enterpriseBean.supportPhone;
		this.emeaServiceSupport = enterpriseBean.emeaServiceSupport;
		this.custSensitivityLevel = enterpriseBean.custSensitivityLevel;
		this.custGarmStatus = enterpriseBean.custGarmStatus;
		this.custActiveInd = enterpriseBean.custActiveInd;
		this.custSbcMigInd = enterpriseBean.custSbcMigInd;
		this.custIcpMigrated = enterpriseBean.custIcpMigrated;
		this.customerType = enterpriseBean.customerType;
		this.custMarket = enterpriseBean.custMarket;
		this.platformIndicator = enterpriseBean.platformIndicator;
		this.vmPartitionId = enterpriseBean.vmPartitionId;
		this.pubIp = enterpriseBean.pubIp;
		this.onNetInterco = enterpriseBean.onNetInterco;
		this.sipDomain = enterpriseBean.sipDomain;
		this.asId = enterpriseBean.asId;
		this.entCclInd = enterpriseBean.entCclInd;
		this.qosInd = enterpriseBean.qosInd;
		this.ieanLength = enterpriseBean.ieanLength;
		this.vnetCorpId = enterpriseBean.vnetCorpId;
		this.contractInd = enterpriseBean.contractInd;
		this.agencyHierCode = enterpriseBean.agencyHierCode;
		this.xrefCustomerId = enterpriseBean.xrefCustomerId;
		this.callingPlanId = enterpriseBean.callingPlanId;
		this.authServicesId = enterpriseBean.authServicesId;
		this.entSbcMigInd = enterpriseBean.entSbcMigInd;
		this.bsBlockInd = enterpriseBean.bsBlockInd;
		this.envOrderId = enterpriseBean.envOrderId;
		this.createdBy = enterpriseBean.createdBy;
		this.modifiedBy = enterpriseBean.modifiedBy;
		this.creationDate = enterpriseBean.creationDate;
		this.lastModifiedDate = enterpriseBean.lastModifiedDate;
		this.commonCustomerId = enterpriseBean.commonCustomerId;
		this.vpnName = enterpriseBean.vpnName;
		this.commonCustomerName = enterpriseBean.commonCustomerName;
		this.getAll = enterpriseBean.getAll;
		this.emeaBillingSystem = enterpriseBean.emeaBillingSystem;
		this.sbcActivationSystem = enterpriseBean.sbcActivationSystem;
		this.digitStringList = enterpriseBean.digitStringList;
		this.isRIVCustomer = enterpriseBean.isRIVCustomer;

		// Jan 2011 Release Changes
		this.naspId = enterpriseBean.naspId;
		this.onNetStat = enterpriseBean.onNetStat;
		// 53938.AA Business Continuity Ph 1 - changes for july 2011
		this.lorFlag = enterpriseBean.lorFlag;
		this.loadSharing = enterpriseBean.loadSharing;
		this.orderPlatform = enterpriseBean.orderPlatform;
		this.restrictedAccess = enterpriseBean.restrictedAccess;
		this.lorId = enterpriseBean.lorId;
		this.address = enterpriseBean.address;
		this.city = enterpriseBean.city;
		this.state = enterpriseBean.state;
		this.zip = enterpriseBean.zip;
		this.country = enterpriseBean.country;
		this.soEnabled = enterpriseBean.soEnabled;
		this.usLdAndLocalBestPool = enterpriseBean.usLdAndLocalBestPool;
		this.usLdOnlyBestPool = enterpriseBean.usLdOnlyBestPool;
		this.emeaApacBestPool = enterpriseBean.emeaApacBestPool;
		this.gchId = enterpriseBean.gchId;
		this.hybridInd = enterpriseBean.hybridInd;
		this.approvedCcl = enterpriseBean.approvedCcl;
		this.entTrunkCclSum = enterpriseBean.entTrunkCclSum;
		this.enterpriseTrunkingType = enterpriseBean.enterpriseTrunkingType;
		this.custPriceBookId = enterpriseBean.custPriceBookId;
		this.contractId = enterpriseBean.contractId;
		this.quoteId = enterpriseBean.quoteId;
		this.catalogueReferenceTime = enterpriseBean.catalogueReferenceTime;
		this.designId = enterpriseBean.designId;
		this.e2eiSensitvityLevel = enterpriseBean.e2eiSensitvityLevel;

		this.calnetSubContractId = enterpriseBean.calnetSubContractId; // added by z658915
		
		this.entCumCcl = enterpriseBean.entCumCcl;

	}

	/**
	 * Constructor
	 * 
	 * @param DBIasaCustomer
	 *            iasaCustomer, DBIpcomCustomer ipcomCustomer
	 */
	public EnterpriseBean(IasaCustomerDbBean iasaCustomer,
			IpcomCustomerDbBean ipcomCustomer) {
		// this.deviceList = enterpriseBean.deviceList;
		// this.authFeaturesList = enterpriseBean.authFeaturesList;
		// this.bsAsDbBean = enterpriseBean.bsAsDbBean;
		// this.callingPlanBean = enterpriseBean.callingPlanBean;
		// this.dialPlanList = enterpriseBean.dialPlanList;
		// this.prefixRoutingList = enterpriseBean.prefixRoutingList;
		// this.thirdPartyDeviceList = enterpriseBean.thirdPartyDeviceList;
		// this.logTrail = enterpriseBean.logTrail;
		// this.departmentList = enterpriseBean.departmentList;
		// this.entAdminList = enterpriseBean.entAdminList;
		this.customerId = ipcomCustomer.getCustId();
		this.accountName = iasaCustomer.getAccountName();
		this.customerName = ipcomCustomer.getCustName();
		this.regionId = iasaCustomer.getRegionId();
		this.productType = iasaCustomer.getProductType();
		this.billingSystem = ipcomCustomer.getBillingPlatformType();
		this.orderSource = iasaCustomer.getOrderSource();
		this.contactFirstName = iasaCustomer.getCustContactFirstName();
		this.contactLastName = iasaCustomer.getCustContactLastName();
		this.contactTitle = iasaCustomer.getCustContactTitle();
		this.contactPrimaryPhone = iasaCustomer.getCustContactPriPhone();
		this.contactAltPhone = iasaCustomer.getCustContactAltPhone();
		this.contactFax = iasaCustomer.getCustContactFax();
		this.contactCell = iasaCustomer.getCustContactCell();
		this.contactPager = iasaCustomer.getCustContactPager();
		this.contactEmail = iasaCustomer.getCustContactEmail();
		this.contactAddr1 = iasaCustomer.getCustContactAddr1();
		this.contactAddr2 = iasaCustomer.getCustContactAddr2();
		this.contactCity = iasaCustomer.getCustContactCity();
		this.contactState = iasaCustomer.getCustContactState();
		this.contactZip = iasaCustomer.getCustContactZip();
		this.contactCountry = iasaCustomer.getCustContactCountry();
		this.billContactPriPhone = iasaCustomer.getBillContactPriPhone();
		this.billContactAltPhone = iasaCustomer.getBillContactAltPhone();
		this.billContactCell = iasaCustomer.getBillContactCell();
		this.billContactPager = iasaCustomer.getBillContactPager();
		this.billContactEmail = iasaCustomer.getBillContactEmail();
		this.billContactAddr1 = iasaCustomer.getBillContactAddr1();
		this.billContactAddr2 = iasaCustomer.getBillContactAddr2();
		this.billContactCity = iasaCustomer.getBillContactCity();
		this.billContactState = iasaCustomer.getBillContactState();
		this.billContactZip = iasaCustomer.getBillContactZip();
		this.billContactCountry = iasaCustomer.getBillContactCountry();
		String sSalesSegment = iasaCustomer.getSalesSegment();
		this.salesSegment = VzbVoipEnum.SalesSegment
				.valueByAcronym(sSalesSegment);
		this.salesRepId = iasaCustomer.getSalesRepId();
		this.salesRepName = iasaCustomer.getSalesRepName();
		this.salesRepPhone = iasaCustomer.getSalesRepPhone();
		this.salesRepEmail = iasaCustomer.getSalesRepEmail();
		this.custCorpId = iasaCustomer.getCustCorpId();
		String sOrderVerification = iasaCustomer.getOrderVerification();
		if (sOrderVerification != null) {
			if (sOrderVerification.equalsIgnoreCase("No Verification")) {
				this.orderVerification = VzbVoipEnum.OrderVerification.NO_VERIFICATION;
			} else if (sOrderVerification
					.equalsIgnoreCase("Branch/Account Team")) {
				this.orderVerification = VzbVoipEnum.OrderVerification.BRANCH_ACCOUNT_TEAM;
			} else if (sOrderVerification.equalsIgnoreCase("Hub")) {
				this.orderVerification = VzbVoipEnum.OrderVerification.HUB;
			}
		}
		this.supportName = iasaCustomer.getSupportName();
		this.supportPhone = iasaCustomer.getSupportPhone();
		this.emeaServiceSupport = iasaCustomer.getEmeaServiceSupport();
		// this.custSensitivityLevel = ipcomCustomer.getShhhhhhhhhhhhhhhhhhhh
		String sCustGarmStatus = iasaCustomer.getCustGarmStatus();
		this.custGarmStatus = VzbVoipEnum.CustomerGarmStatus
				.valueByAcronym(sCustGarmStatus);
		// this.custActiveInd = iasaCustomer.
		// this.customerType = ipcomCustomer.getCustType();
		this.custMarket = ipcomCustomer.getCustMarket();
		this.platformIndicator = ipcomCustomer.getPlatformIndicator();
		this.vmPartitionId = ipcomCustomer.getVmPartitionId();
		this.pubIp = ipcomCustomer.getPubip();
		this.onNetInterco = ipcomCustomer.getOnnetInterco();
		// this.sipDomain = ipcomCustomer.getS
		// this.asId = ipcomCustomer.get
		this.entCclInd = ipcomCustomer.getEntcclInd();
		this.qosInd = ipcomCustomer.getQosInd();
		// this.ieanLength = ipcomCustomer.getIean();
		this.vnetCorpId = ipcomCustomer.getVnetCorpId();
		this.contractInd = ipcomCustomer.getContractInd();
		this.agencyHierCode = ipcomCustomer.getAgencyHierCode();
		this.xrefCustomerId = ipcomCustomer.getXrefCustId();
		// this.callingPlanId = iasamCustomer.getCa
		// this.authServicesId = ipcomCustomer.getAutj
		// this.entActiveInd = iasaCustomer.getEnt0i
		// this.bsBlockInd = ipcomCustomer.
		// this.envOrderId = ipcomCustomer.envOrderId;
		// this.createdBy = iasaCustomer.getCreatedBy();
		// this.modifiedBy = iasaCustomer.getMo
		this.creationDate = iasaCustomer.getCreatedDate();
		// this.lastModifiedDate = iasaCustomer.getLastModifiedDate();
		// this.commonCustomerId = iasaCustomer.getCcId();
		// this.vpnName = iasaCustomer.getV
		// this.commonCustomerName = ipcomCustomer.commonCustomerName;
		// this.getAll = iasaCustomer.getA
		// Jan 2011 Release Changes
		// this.naspId = iasaCustomer.naspId;
		String sEmeaBillingSystem = ipcomCustomer.getEmeaBillingSystem();
		this.emeaBillingSystem = VzbVoipEnum.BillingSystemType
				.valueByAcronym(sEmeaBillingSystem);
		// this.sbcActivationSystem=ipcomCustomer.getSbcProv();
		// this.digitStringList = iasaCustomer.getD0
		String freezFlag = ipcomCustomer.getUiProvFlag();
		if (freezFlag != null) {
			if (Long.parseLong(freezFlag) == EsapMigrationEnum.FreezeFlag.NON_LEGACY) {
				this.isRIVCustomer = VzbVoipEnum.YesNoType.Y;
			} else {
				this.isRIVCustomer = VzbVoipEnum.YesNoType.N;
			}
		}

		this.logTrail = new ArrayList<String>();
		// 53938.AA Business Continuity Ph 1 - changes for july 2011
		// this.lorFlag = iasaCustomer.getLorFlag();

	}

	// added by z658915 starts for calnet changes
	public short getCalnetSubContractId() {
		return calnetSubContractId;
	}

	public void setCalnetSubContractId(short calnetSubContractId) {
		this.calnetSubContractId = calnetSubContractId;
	}

	// added by z658915 ends for calnet changes

	public void setEmeaBillingSystem(long emeaBillingSystem) {
		this.emeaBillingSystem = emeaBillingSystem;
	}

	public long getEmeaBillingSystem() {
		return this.emeaBillingSystem;
	}

	public CallingPlanBean getCallingPlanBean() {
		return callingPlanBean;
	}

	public void setCallingPlanBean(CallingPlanBean callingPlanBean) {
		this.callingPlanBean = callingPlanBean;
	}

	public List<TblVzbStateGatewayMapDbBean> getThirdPartyDeviceList() {
		return thirdPartyDeviceList;
	}

	public void setThirdPartyDeviceList(
			List<TblVzbStateGatewayMapDbBean> thirdPartyDeviceList) {
		this.thirdPartyDeviceList = thirdPartyDeviceList;
	}

	public void setLogTrail(String logStr) {
		logTrail.add(logStr);
	}

	public List<String> getLogTrail() {
		return logTrail;
	}

	public java.sql.Timestamp getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(java.sql.Timestamp creationDate) {
		this.creationDate = creationDate;
	}

	public java.sql.Timestamp getLastModifiedDate() {
		return lastModifiedDate;
	}

	public void setLastModifiedDate(java.sql.Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getAccountName() {
		return accountName;
	}

	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public long getRegionId() {
		return regionId;
	}

	public void setRegionId(long regionId) {
		this.regionId = regionId;
	}

	public long getProductType() {
		return productType;
	}

	public void setProductType(long productType) {
		this.productType = productType;
	}

	public long getBillingSystem() {
		return billingSystem;
	}

	public void setBillingSystem(long billingSystem) {
		this.billingSystem = billingSystem;
	}

	public String getOrderSource() {
		return orderSource;
	}

	public void setOrderSource(String orderSource) {
		this.orderSource = orderSource;
	}

	public String getContactFirstName() {
		return contactFirstName;
	}

	public String getSbcActivationSystem() {
		return sbcActivationSystem;
	}

	public void setSbcActivationSystem(String sbcActivationSystem) {
		this.sbcActivationSystem = sbcActivationSystem;
	}

	public void setContactFirstName(String contactFirstName) {
		this.contactFirstName = contactFirstName;
	}

	public String getContactLastName() {
		return contactLastName;
	}

	public void setContactLastName(String contactLastName) {
		this.contactLastName = contactLastName;
	}

	public String getContactTitle() {
		return contactTitle;
	}

	public void setContactTitle(String contactTitle) {
		this.contactTitle = contactTitle;
	}

	public String getContactPrimaryPhone() {
		return contactPrimaryPhone;
	}

	public void setContactPrimaryPhone(String contactPrimaryPhone) {
		this.contactPrimaryPhone = contactPrimaryPhone;
	}

	public String getContactAltPhone() {
		return contactAltPhone;
	}

	public void setContactAltPhone(String contactAltPhone) {
		this.contactAltPhone = contactAltPhone;
	}

	public String getContactFax() {
		return contactFax;
	}

	public void setContactFax(String contactFax) {
		this.contactFax = contactFax;
	}

	public String getContactCell() {
		return contactCell;
	}

	public void setContactCell(String contactCell) {
		this.contactCell = contactCell;
	}

	public String getContactPager() {
		return contactPager;
	}

	public void setContactPager(String contactPager) {
		this.contactPager = contactPager;
	}

	public String getContactEmail() {
		return contactEmail;
	}

	public void setContactEmail(String contactEmail) {
		this.contactEmail = contactEmail;
	}

	public String getContactAddr1() {
		return contactAddr1;
	}

	public void setContactAddr1(String contactAddr1) {
		this.contactAddr1 = contactAddr1;
	}

	public String getContactAddr2() {
		return contactAddr2;
	}

	public void setContactAddr2(String contactAddr2) {
		this.contactAddr2 = contactAddr2;
	}

	public String getContactCity() {
		return contactCity;
	}

	public void setContactCity(String contactCity) {
		this.contactCity = contactCity;
	}

	public String getContactState() {
		return contactState;
	}

	public void setContactState(String contactState) {
		this.contactState = contactState;
	}

	public String getContactZip() {
		return contactZip;
	}

	public void setContactZip(String contactZip) {
		this.contactZip = contactZip;
	}

	public String getContactCountry() {
		return contactCountry;
	}

	public void setContactCountry(String contactCountry) {
		this.contactCountry = contactCountry;
	}

	public String getBillContactPriPhone() {
		return billContactPriPhone;
	}

	public void setBillContactPriPhone(String billContactPriPhone) {
		this.billContactPriPhone = billContactPriPhone;
	}

	public String getBillContactAltPhone() {
		return billContactAltPhone;
	}

	public void setBillContactAltPhone(String billContactAltPhone) {
		this.billContactAltPhone = billContactAltPhone;
	}

	public String getBillContactCell() {
		return billContactCell;
	}

	public void setBillContactCell(String billContactCell) {
		this.billContactCell = billContactCell;
	}

	public String getBillContactPager() {
		return billContactPager;
	}

	public void setBillContactPager(String billContactPager) {
		this.billContactPager = billContactPager;
	}

	public String getBillContactEmail() {
		return billContactEmail;
	}

	public void setBillContactEmail(String billContactEmail) {
		this.billContactEmail = billContactEmail;
	}

	public String getBillContactAddr1() {
		return billContactAddr1;
	}

	public void setBillContactAddr1(String billContactAddr1) {
		this.billContactAddr1 = billContactAddr1;
	}

	public String getBillContactAddr2() {
		return billContactAddr2;
	}

	public void setBillContactAddr2(String billContactAddr2) {
		this.billContactAddr2 = billContactAddr2;
	}

	public String getBillContactCity() {
		return billContactCity;
	}

	public void setBillContactCity(String billContactCity) {
		this.billContactCity = billContactCity;
	}

	public String getBillContactState() {
		return billContactState;
	}

	public void setBillContactState(String billContactState) {
		this.billContactState = billContactState;
	}

	public String getBillContactZip() {
		return billContactZip;
	}

	public void setBillContactZip(String billContactZip) {
		this.billContactZip = billContactZip;
	}

	public String getBillContactCountry() {
		return billContactCountry;
	}

	public void setBillContactCountry(String billContactCountry) {
		this.billContactCountry = billContactCountry;
	}

	public long getSalesSegment() {
		return salesSegment;
	}

	public void setSalesSegment(long salesSegment) {
		this.salesSegment = salesSegment;
	}

	public String getSalesRepId() {
		return salesRepId;
	}

	public void setSalesRepId(String salesRepId) {
		this.salesRepId = salesRepId;
	}

	public String getSalesRepName() {
		return salesRepName;
	}

	public void setSalesRepName(String salesRepName) {
		this.salesRepName = salesRepName;
	}

	public String getSalesRepPhone() {
		return salesRepPhone;
	}

	public void setSalesRepPhone(String salesRepPhone) {
		this.salesRepPhone = salesRepPhone;
	}

	public String getSalesRepEmail() {
		return salesRepEmail;
	}

	public void setSalesRepEmail(String salesRepEmail) {
		this.salesRepEmail = salesRepEmail;
	}

	public String getCustCorpId() {
		return custCorpId;
	}

	public void setCustCorpId(String custCorpId) {
		this.custCorpId = custCorpId;
	}

	public long getOrderVerification() {
		return orderVerification;
	}

	public void setOrderVerification(long orderVerification) {
		this.orderVerification = orderVerification;
	}

	public String getSupportName() {
		return supportName;
	}

	public void setSupportName(String supportName) {
		this.supportName = supportName;
	}

	public String getSupportPhone() {
		return supportPhone;
	}

	public void setSupportPhone(String supportPhone) {
		this.supportPhone = supportPhone;
	}

	public long getEmeaServiceSupport() {
		return emeaServiceSupport;
	}

	public void setEmeaServiceSupport(long emeaServiceSupport) {
		this.emeaServiceSupport = emeaServiceSupport;
	}

	public String getCustSensitivityLevel() {
		return custSensitivityLevel;
	}

	public void setCustSensitivityLevel(String custSensitivityLevel) {
		this.custSensitivityLevel = custSensitivityLevel;
	}

	public long getCustGarmStatus() {
		return custGarmStatus;
	}

	public void setCustGarmStatus(long custGarmStatus) {
		this.custGarmStatus = custGarmStatus;
	}

	public long getCustActiveInd() {
		return custActiveInd;
	}

	public void setCustActiveInd(long custActiveInd) {
		this.custActiveInd = custActiveInd;
	}

	public long getCustSbcMigInd() {
		return custSbcMigInd;
	}

	public void setCustSbcMigInd(long sbcMigInd) {
		this.custSbcMigInd = sbcMigInd;
	}

	public long getCustIcpMigrated() {
		return custIcpMigrated;
	}

	public void setCustIcpMigrated(long icbMigrated) {
		this.custIcpMigrated = icbMigrated;
	}

	public String getEnterpriseId() {
		return customerId;
	}

	public void setEnterpriseId(String customerId) {
		this.customerId = customerId;
	}

	public long getCustomerType() {
		return customerType;
	}

	public void setCustomerType(long customerType) {
		this.customerType = customerType;
	}

	public long getCustMarket() {
		return custMarket;
	}

	public void setCustMarket(long custMarket) {
		this.custMarket = custMarket;
	}

	public long getPlatformIndicator() {
		return platformIndicator;
	}

	public void setPlatformIndicator(long platformIndicator) {
		this.platformIndicator = platformIndicator;
	}

	public String getVmPartitionId() {
		return vmPartitionId;
	}

	public void setVmPartitionId(String vmPartitionId) {
		this.vmPartitionId = vmPartitionId;
	}

	public long getPubIp() {
		return pubIp;
	}

	public void setPubIp(long pubIp) {
		this.pubIp = pubIp;
	}

	public long getOnNetInterco() {
		return onNetInterco;
	}

	public void setOnNetInterco(long onNetInterco) {
		this.onNetInterco = onNetInterco;
	}

	public String getSipDomain() {
		return sipDomain;
	}

	public void setSipDomain(String sipDomain) {
		this.sipDomain = sipDomain;
	}

	public long getAsId() {
		return asId;
	}

	public void setAsId(long asId) {
		this.asId = asId;
	}

	public long getEntCclInd() {
		return entCclInd;
	}

	public void setEntCclInd(long entCclInd) {
		this.entCclInd = entCclInd;
	}

	public long getQosInd() {
		return qosInd;
	}

	public void setQosInd(long qosInd) {
		this.qosInd = qosInd;
	}

	public long getIeanLength() {
		return ieanLength;
	}

	public void setIeanLength(long ieanLength) {
		this.ieanLength = ieanLength;
	}

	public String getVnetCorpId() {
		return vnetCorpId;
	}

	public void setVnetCorpId(String vnetCorpId) {
		this.vnetCorpId = vnetCorpId;
	}

	public String getContractInd() {
		return contractInd;
	}

	public void setContractInd(String contractInd) {
		this.contractInd = contractInd;
	}

	public String getAgencyHierCode() {
		return agencyHierCode;
	}

	public void setAgencyHierCode(String agencyHierCode) {
		this.agencyHierCode = agencyHierCode;
	}

	public String getXrefCustomerId() {
		return xrefCustomerId;
	}

	public void setXrefCustomerId(String xrefCustomerId) {
		this.xrefCustomerId = xrefCustomerId;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public long getCallingPlanId() {
		return callingPlanId;
	}

	public void setCallingPlanId(long callingPlanId) {
		this.callingPlanId = callingPlanId;
	}

	public long getAuthServicesId() {
		return authServicesId;
	}

	public void setAuthServicesId(long authServicesId) {
		this.authServicesId = authServicesId;
	}
	//KR- start policyServiceId
	public void setPolicyServicesId(long policyServicesId) {
		this.policyServicesId = policyServicesId;
	}
	
	public long getPolicyServicesId() {
		return policyServicesId;
	}
	
	public void setServicePackServicesId(long servicePackServicesId) {
		this.servicePackServicesId = servicePackServicesId;
	}
	
	public long getServicePackServicesId() {
		return servicePackServicesId;
	}
	public String getBwEnterPrsiseId() {
		return bwEnterPrsiseId;
	}

	public void setBwEnterPrsiseId(String bwEnterPrsiseId) {
		this.bwEnterPrsiseId = bwEnterPrsiseId;
	}
	//KR- end

	public long getEntActiveInd() {
		return entActiveInd;
	}

	public void setEntActiveInd(long entActiveInd) {
		this.entActiveInd = entActiveInd;
	}

	public long getEntSbcMigInd() {
		return entSbcMigInd;
	}

	public void setEntSbcMigInd(long sbcMigInd) {
		this.entSbcMigInd = sbcMigInd;
	}

	public long getBsBlockInd() {
		return bsBlockInd;
	}

	public void setBsBlockInd(long bsBlockInd) {
		this.bsBlockInd = bsBlockInd;
	}

	public List<GatewayDeviceBean> getDeviceList() {
		return deviceList;
	}

	public void setDeviceList(List<GatewayDeviceBean> deviceList) {
		this.deviceList = deviceList;
	}

	public List<DepartmentBean> getDepartmentList() {
		return departmentList;
	}

	public void setDepartmentList(List<DepartmentBean> departmentList) {
		this.departmentList = departmentList;
	}

	public List<TblDigitStringsDbBean> getDigitStringList() {
		return digitStringList;
	}

	public void setDigitStringList(List<TblDigitStringsDbBean> departmentList) {
		this.digitStringList = digitStringList;
	}

	public List<DialPlanBean> getDialPlanList() {
		return dialPlanList;
	}

	public void setDialPlanList(List<DialPlanBean> dialPlanList) {
		this.dialPlanList = dialPlanList;
	}

	public List<FeaturesBean> getAuthFeaturesList() {
		return authFeaturesList;
	}

	public void setAuthFeaturesList(List<FeaturesBean> authFeaturesList) {
		this.authFeaturesList = authFeaturesList;
	}
	//KR-Start policy changes
	public List<PolicyFeaturesBean> getPolicyFeaturesList() {
		return policyFeaturesList;
	}
	
	public void setPolicyFeaturesList(List<PolicyFeaturesBean> policyFeaturesList) {
		this.policyFeaturesList = policyFeaturesList;
	}
	
	public List<ServicePackFeaturesBean> getServicePackFeaturesList() {
		return servicePackFeaturesList;
	}
	
	public void setServicePackFeaturesList(List<ServicePackFeaturesBean> servicePackFeaturesList) {
		this.servicePackFeaturesList = servicePackFeaturesList;
	}
	
	//KR-End

	public DBTblBsAs getBsAsDbBean() {
		return bsAsDbBean;
	}

	public void setBsAsDbBean(DBTblBsAs bsAsDbBean) {
		this.bsAsDbBean = bsAsDbBean;
	}

	public TblEntBillFeaturesBean getEntBillFeatBean() {
		return entBillFeatBean;
	}

	public void setEntBillFeatBean(TblEntBillFeaturesBean entBillFeatBean) {
		this.entBillFeatBean = entBillFeatBean;
	}

	public List<TblEntBillFeaturesBean> getEntBillFeatBeanList() {
		return entBillFeatBeanList;
	}

	public void setEntBillFeatBeanList(
			List<TblEntBillFeaturesBean> entBillFeatBeanList) {
		this.entBillFeatBeanList = entBillFeatBeanList;
	}

	public long getEnvOrderId() {
		return envOrderId;
	}

	public void setEnvOrderId(long envOrderId) {
		this.envOrderId = envOrderId;
	}

	public boolean getGetAll() {
		return getAll;
	}

	public void setGetAll(boolean getAll) {
		this.getAll = getAll;
	}

	public String getCommonCustomerId() {
		return commonCustomerId;
	}

	public void setCommonCustomerId(String commonCustomerId) {
		this.commonCustomerId = commonCustomerId;
	}

	public String getCommonCustomerName() {
		return commonCustomerName;
	}

	public void setCommonCustomerName(String commonCustomerName) {
		this.commonCustomerName = commonCustomerName;
	}

	public String getVpnName() {
		return vpnName;
	}

	public void setVpnName(String vpnName) {
		this.vpnName = vpnName;
	}

	public List<EnterpriseAdminBean> getEntAdminList() {
		return entAdminList;
	}

	public void setEntAdminList(List<EnterpriseAdminBean> entAdminList) {
		this.entAdminList = entAdminList;
	}

	public List<PrefixRoutingBean> getPrefixRoutingList() {
		return prefixRoutingList;
	}

	public void setPrefixRoutingList(List<PrefixRoutingBean> prefixRoutingList) {
		this.prefixRoutingList = prefixRoutingList;
	}

	public void setIsRIVCustomer(long isRIVCustomer) {
		this.isRIVCustomer = isRIVCustomer;
	}

	public long getIsRIVCustomer() {
		return this.isRIVCustomer;
	}

	public long getOrderPlatform() {
		return orderPlatform;
	}

	public void setOrderPlatform(long orderPlatform) {
		this.orderPlatform = orderPlatform;
	}

	// Jan 2011 Release Changes
	public String getNaspId() {
		return naspId;
	}

	public void setNaspId(String naspId) {
		this.naspId = naspId;
	}

	public long getOnNetStat() {
		return onNetStat;
	}

	public void setOnNetStat(long onNetStat) {
		this.onNetStat = onNetStat;
	}

	// 53938.AA Business Continuity Ph 1 - changes for july 2011
	public String getLorFlag() {
		return lorFlag;
	}

	public void setLorFlag(String lorFlag) {
		this.lorFlag = lorFlag;
	}

	public void setLoadSharing(long loadSharing) {
		this.loadSharing = loadSharing;
	}

	public long getLoadSharing() {
		return this.loadSharing;
	}

	public short getRestrictedAccess() {
		return restrictedAccess;
	}

	public void setRestrictedAccess(short restrictedAccess) {
		this.restrictedAccess = restrictedAccess;
	}

	public void setLorId(final String lorId) {
		this.lorId = lorId;
	}

	public String getLorId() {
		return this.lorId;
	}

	public void setAddress(final String address) {
		this.address = address;
	}

	public String getAddress() {
		return this.address;
	}

	public void setCity(final String city) {
		this.city = city;
	}

	public String getCity() {
		return this.city;
	}

	public void setState(final String state) {
		this.state = state;
	}

	public String getState() {
		return this.state;
	}

	public void setZip(final String zip) {
		this.zip = zip;
	}

	public String getZip() {
		return this.zip;
	}

	public void setCountry(final String country) {
		this.country = country;
	}

	public String getCountry() {
		return this.country;
	}

	public void setSoEnabled(final short soEnabled) {
		this.soEnabled = soEnabled;
	}

	public short getSoEnabled() {
		return this.soEnabled;
	}

	public void setUsLdAndLocalBestPool(final long usLdAndLocalBestPool) {
		this.usLdAndLocalBestPool = usLdAndLocalBestPool;
	}

	public long getUsLdAndLocalBestPool() {
		return this.usLdAndLocalBestPool;
	}

	public void setUsLdOnlyBestPool(final long usLdOnlyBestPool) {
		this.usLdOnlyBestPool = usLdOnlyBestPool;
	}

	public long getUsLdOnlyBestPool() {
		return this.usLdOnlyBestPool;
	}

	public void setEmeaApacBestPool(final long emeaApacBestPool) {
		this.emeaApacBestPool = emeaApacBestPool;
	}

	public long getEmeaApacBestPool() {
		return this.emeaApacBestPool;
	}

	public void setUsLdAndLocalBestPlusPool(final long usLdAndLocalBestPlusPool) {
		this.usLdAndLocalBestPlusPool = usLdAndLocalBestPlusPool;
	}

	public long getUsLdAndLocalBestPlusPool() {
		return this.usLdAndLocalBestPlusPool;
	}

	public void setUsLdOnlyBestPlusPool(final long usLdOnlyBestPlusPool) {
		this.usLdOnlyBestPlusPool = usLdOnlyBestPlusPool;
	}

	public long getUsLdOnlyBestPlusPool() {
		return this.usLdOnlyBestPlusPool;
	}

	public void setEmeaApacBestPlusPool(final long emeaApacBestPlusPool) {
		this.emeaApacBestPlusPool = emeaApacBestPlusPool;
	}

	public long getEmeaApacBestPlusPool() {
		return this.emeaApacBestPlusPool;
	}

	public String getGchId() {
		return gchId;
	}

	public void setGchId(String gchId) {
		this.gchId = gchId;
	}

	public short getHybridInd() {
		return hybridInd;
	}

	public void setHybridInd(short hybridInd) {
		this.hybridInd = hybridInd;
	}

	/**
	 * @return the approvedCcl
	 */
	public long getApprovedCcl() {
		return approvedCcl;
	}

	/**
	 * @param approvedCcl
	 *            the approvedCcl to set
	 */
	public void setApprovedCcl(long approvedCcl) {
		this.approvedCcl = approvedCcl;
	}

	/**
	 * @return the entTrunkCclSum
	 */
	public long getEntTrunkCclSum() {
		return entTrunkCclSum;
	}

	/**
	 * @param entTrunkCclSum
	 *            the entTrunkCclSum to set
	 */
	public void setEntTrunkCclSum(long entTrunkCclSum) {
		this.entTrunkCclSum = entTrunkCclSum;
	}

	public long getEnterpriseTrunkingType() {
		return enterpriseTrunkingType;
	}

	public void setEnterpriseTrunkingType(long enterpriseTrunkingType) {
		this.enterpriseTrunkingType = enterpriseTrunkingType;
	}

	public String getCustPriceBookId() {
		return custPriceBookId;
	}

	public void setCustPriceBookId(String custPriceBookId) {
		this.custPriceBookId = custPriceBookId;
	}

	public String getContractId() {
		return contractId;
	}

	public void setContractId(String contractId) {
		this.contractId = contractId;
	}

	public String getQuoteId() {
		return quoteId;
	}

	public void setQuoteId(String quoteId) {
		this.quoteId = quoteId;
	}

	public Timestamp getCatalogueReferenceTime() {
		return catalogueReferenceTime;
	}

	public void setCatalogueReferenceTime(final Timestamp catalogueReferenceTime) {
		this.catalogueReferenceTime = catalogueReferenceTime;
	}

	public long getDesignId() {
		return designId;
	}

	public void setDesignId(long designId) {
		this.designId = designId;
	}

	public String getE2eiSensitivityLevel() {
		return e2eiSensitvityLevel;
	}

	public void setE2eiSensitivityLevel(String e2eiSensitvityLevel) {
		this.e2eiSensitvityLevel = e2eiSensitvityLevel;
	}

	public void setE2eiMigStatus(long e2eiMigStatus) {
		this.e2eiMigStatus = e2eiMigStatus;
	}

	public long getE2eiMigStatus() {
		return this.e2eiMigStatus;
	}

	public long getE2eiMigLock() {
		return this.e2eiMigLock;
	}

	public void setE2eiMigLock(long migLock) {
		this.e2eiMigLock = migLock;
	}

	public void setE2eiMigDate(Timestamp migDate) {
		this.e2eiMigDate = migDate;
	}

	public Timestamp getE2eiMigDate() {
		return this.e2eiMigDate;
	}

	public long getEntCumCcl() {
		return entCumCcl;
	}

	public void setEntCumCcl(long entCumCcl) {
		this.entCumCcl = entCumCcl;
	}
	
	public String getAuthFeatureType() {
		return authFeatureType;
	}

	public void setAuthFeatureType(String authFeatureType) {
		this.authFeatureType = authFeatureType;
	}
	public int getDefaultAuthServiceId() {
		return defaultAuthServiceId;
	}

	public void setDefaultAuthServiceId(int defaultAuthServiceId) {
		this.defaultAuthServiceId = defaultAuthServiceId;
	}

	public void initilizeTODefault() {

		departmentList = null;

		entAdminList = new ArrayList<EnterpriseAdminBean>();
		// this.customerId = new String("");
		this.accountName = new String("");
		this.customerName = new String("");
		this.regionId = 0;
		this.productType = 0;
		this.billingSystem = 0;
		this.orderSource = new String("");
		this.contactFirstName = new String("");
		this.contactLastName = new String("");
		this.contactTitle = new String("");
		this.contactPrimaryPhone = new String("");
		this.contactAltPhone = new String("");
		this.contactFax = new String("");
		this.contactCell = new String("");
		this.contactPager = new String("");
		this.contactEmail = new String("");
		this.contactAddr1 = new String("");
		this.contactAddr2 = new String("");
		this.contactCity = new String("");
		this.contactState = new String("");
		this.contactZip = new String("");
		this.contactCountry = new String("");
		this.billContactPriPhone = new String("");
		this.billContactAltPhone = new String("");
		this.billContactCell = new String("");
		this.billContactPager = new String("");
		this.billContactEmail = new String("");
		this.billContactAddr1 = new String("");
		this.billContactAddr2 = new String("");
		this.billContactCity = new String("");
		this.billContactState = new String("");
		this.billContactZip = new String("");
		this.billContactCountry = new String("");
		this.salesSegment = -1;
		this.salesRepId = new String("");
		this.salesRepName = new String("");
		this.salesRepPhone = new String("");
		this.salesRepEmail = new String("");
		this.custCorpId = new String("");
		this.orderVerification = -1;
		this.supportName = new String("");
		this.supportPhone = new String("");
		this.emeaServiceSupport = 0;
		this.custSensitivityLevel = new String("");
		this.custGarmStatus = 0;
		this.custActiveInd = 1;
		this.customerType = 0;
		this.custMarket = 0;
		this.platformIndicator = 0;
		this.vmPartitionId = new String("");
		this.pubIp = 0;
		this.onNetInterco = 0;
		this.sipDomain = new String("");
		this.asId = 0;
		this.entCclInd = 0;
		this.qosInd = 0;
		this.ieanLength = 0;
		this.vnetCorpId = new String("");
		this.contractInd = new String("");
		this.agencyHierCode = new String("");
		this.xrefCustomerId = new String("");
		this.callingPlanId = 0;
		this.authServicesId = 0;
		this.entActiveInd = 0;
		this.bsBlockInd = 0;
		this.envOrderId = 0;
		this.createdBy = new String("");
		this.modifiedBy = new String("");
		this.creationDate = null;
		this.lastModifiedDate = null;
		this.commonCustomerId = new String("");
		this.vpnName = new String("");
		this.emeaBillingSystem = -1;
		this.isRIVCustomer = -1;
		// this.getAll = false;
		// Jan 2011 Release Changes
		this.naspId = "";
		this.onNetStat = -1;
		// 53938.AA Business Continuity Ph 1 - changes for july 2011
		this.lorFlag = "N";
		this.loadSharing = 0;
		this.orderPlatform = 0;
		this.restrictedAccess = 0;

		this.lorId = "";
		this.address = "";
		this.city = "";
		this.state = "";
		this.zip = "";
		this.country = "";
		this.soEnabled = 0;
		this.usLdAndLocalBestPool = 0;
		this.usLdOnlyBestPool = 0;
		this.emeaApacBestPool = 0;
		this.usLdAndLocalBestPlusPool = 0;
		this.usLdOnlyBestPlusPool = 0;
		this.emeaApacBestPlusPool = 0;
		this.gchId = "";
		this.hybridInd = 0;
		this.approvedCcl = 0;
		this.entTrunkCclSum = 0;
		this.enterpriseTrunkingType = 0;
		this.custPriceBookId = "";
		this.contractId = "";
		this.quoteId = "";
		this.catalogueReferenceTime = null;
		this.designId = 0;
		this.calnetSubContractId = -1;
		this.entCumCcl = -1;
		this.authFeatureType=new String("");
		this.defaultAuthServiceId=0;
	}
	//
}// EOF
