package com.vz.esap.api.model;

import EsapEnumPkg.TaskExitEnum;


public class ResponseObject {
	
	public static int SUCCESS = TaskExitEnum.ErrorType.SUCCEED;
	public static int FAILURE = TaskExitEnum.ErrorType.FAIL;
	public final static int SUCCESS_SKIP = TaskExitEnum.ErrorType.SUCCESS_SKIP;

	int statusCode;
	String statusDescription;

	public int getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(int statusCode) {
		this.statusCode = statusCode;
	}

	public String getStatusDescription() {
		return statusDescription;
	}

	public void setStatusDescription(String statusDescription) {
		this.statusDescription = statusDescription;
	}

	/*public static void main(String args[]) throws JsonProcessingException {

		ObjectMapper mapper = new ObjectMapper();
		ResponseObject obj = new ResponseObject();

		// Object to JSON in file
		// mapper.writeValue(new File("c:\\file.json"), obj);

		// Object to JSON in String
		obj.setStatusCode(1);
		obj.setStatusDescription("Activation Job is successful for TN");
		

		String jsonInString = mapper.writeValueAsString(obj);
		
		//System.out.println("JSON Object ==>" + jsonInString);

	}*/
}
