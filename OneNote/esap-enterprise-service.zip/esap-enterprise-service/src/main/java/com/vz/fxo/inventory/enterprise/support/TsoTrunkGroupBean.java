package com.vz.fxo.inventory.enterprise.support;

import java.io.Serializable;
import java.sql.Timestamp;

public class TsoTrunkGroupBean implements Serializable {
	
	
	protected long trunkGroupId;
	protected String trunkGroupName;
	protected String tgrpId;
	protected String routingGroupId;
	protected String pilotUserUserId;
	protected String pilotExtension;
	protected int nwkNodeDeviceId;
	protected long ebiId;
	protected long deviceId;
	protected String bsDeviceType;
	protected String deviceFqdn;
	protected String linePort;
	protected String createdBy;
	protected Timestamp creationDate;
	protected String modifiedBy;
	protected Timestamp lastModifiedDate;
    
	
	public TsoTrunkGroupBean()
	{
		this.trunkGroupId = 0;
		this.trunkGroupName = new String("");
		this.tgrpId = new String("");
		this.routingGroupId=new String("");
		this.pilotUserUserId = new String("");
		this.pilotExtension = new String("");
		this.nwkNodeDeviceId=0;
		this.ebiId=0;
		this.deviceId=0;
		this.bsDeviceType=new String("");
		this.deviceFqdn=new String("");
		this.linePort=new String("");
		this.createdBy = new String("");
		this.creationDate = null;
		this.modifiedBy = new String("");
		this.lastModifiedDate = null;
		
	}
    
    public TsoTrunkGroupBean(TsoTrunkGroupBean tsoTrunkGroupBean)
	{
    	this.trunkGroupId=	tsoTrunkGroupBean.trunkGroupId;
    	this.trunkGroupName = tsoTrunkGroupBean.trunkGroupName;
    	this.tgrpId =tsoTrunkGroupBean.tgrpId;
    	this.routingGroupId=tsoTrunkGroupBean.routingGroupId;
    	this.pilotUserUserId =tsoTrunkGroupBean.pilotUserUserId;
    	this.pilotExtension =tsoTrunkGroupBean.pilotExtension;
    	this.nwkNodeDeviceId=tsoTrunkGroupBean.nwkNodeDeviceId;
    	this.ebiId=tsoTrunkGroupBean.ebiId;
    	this.deviceId=tsoTrunkGroupBean.deviceId;
    	this.bsDeviceType=tsoTrunkGroupBean.bsDeviceType;
		this.deviceFqdn=tsoTrunkGroupBean.deviceFqdn;
		this.linePort=tsoTrunkGroupBean.linePort;
        this.modifiedBy = tsoTrunkGroupBean.modifiedBy;
		this.createdBy = tsoTrunkGroupBean.createdBy;
		this.creationDate = tsoTrunkGroupBean.creationDate;
		this.lastModifiedDate = tsoTrunkGroupBean.lastModifiedDate;
		
	}
  
    public long getTrunkGroupId() {
		return trunkGroupId;
	}

	public void setTrunkGroupId(long trunkGroupId) {
		this.trunkGroupId = trunkGroupId;
	}

	public String getTrunkGroupName() {
		return trunkGroupName;
	}

	public void setTrunkGroupName(String trunkGroupName) {
		this.trunkGroupName = trunkGroupName;
	}

	public String getTgrpId() {
		return tgrpId;
	}

	public void setTgrpId(String tgrpId) {
		this.tgrpId = tgrpId;
	}

	public String getRoutingGroupId() {
		return routingGroupId;
	}

	public void setRoutingGroupId(String routingGroupId) {
		this.routingGroupId = routingGroupId;
	}

	public String getPilotUserUserId() {
		return pilotUserUserId;
	}

	public void setPilotUserUserId(String pilotUserUserId) {
		this.pilotUserUserId = pilotUserUserId;
	}

	public String getPilotExtension() {
		return pilotExtension;
	}

	public void setPilotExtension(String pilotExtension) {
		this.pilotExtension = pilotExtension;
	}

	public long getEbiId() {
		return ebiId;
	}

	public void setEbiId(long ebiId) {
		this.ebiId = ebiId;
	}

	public long getDeviceId() {
		return deviceId;
	}

	public void setDeviceId(long deviceId) {
		this.deviceId = deviceId;
	}

	public String getBsDeviceType() {
		return bsDeviceType;
	}

	public void setBsDeviceType(String bsDeviceType) {
		this.bsDeviceType = bsDeviceType;
	}

	public String getDeviceFqdn() {
		return deviceFqdn;
	}

	public void setDeviceFqdn(String deviceFqdn) {
		this.deviceFqdn = deviceFqdn;
	}

	public String getLinePort() {
		return linePort;
	}

	public void setLinePort(String linePort) {
		this.linePort = linePort;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(Timestamp creationDate) {
		this.creationDate = creationDate;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Timestamp getLastModifiedDate() {
		return lastModifiedDate;
	}

	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public int getNwkNodeDeviceId() {
		return nwkNodeDeviceId;
	}

	public void setNwkNodeDeviceId(int nwkNodeDeviceId) {
		this.nwkNodeDeviceId = nwkNodeDeviceId;
	}

	
}
