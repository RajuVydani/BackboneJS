package com.vz.fxo.inventory.enterprise.support;
/*
 Name                 Null?    Type          
-------------------- -------- ------------- 
NBS_CLUSTER_INFO_ID  NOT NULL NUMBER        
NBS_POOL_ID                   NUMBER        
NBS_TYPE                      VARCHAR2(120) 
BS_AS_MAPPING_ID              NUMBER        
INTERNAL_PORT                 VARCHAR2(80)  
INTERNAL_32_IP                VARCHAR2(80)  
EXTERNAL_PORT                 VARCHAR2(80)  
EXTERNAL_28_IP_BLOCK          VARCHAR2(80)  
EXTERNAL_IP_2W                VARCHAR2(80)  
EXTERNAL_IP_IB                VARCHAR2(80)  
WT_INTERNAL_PORT              VARCHAR2(80)  
WT_EXTERNAL_PORT              VARCHAR2(80)  
CPE_EXTERNAL_PORT             VARCHAR2(80)  
CPE_EXTERNAL_IP               VARCHAR2(80)  
NIF_IP_1                      VARCHAR2(80)  
NIF_IP_2                      VARCHAR2(80)  
NIF_IP_3                      VARCHAR2(80)  
NIF_IP_4                      VARCHAR2(80)  
VPN_ID                        VARCHAR2(80)  
VPN_NAME                      VARCHAR2(120) 
LOCATION_ID                   VARCHAR2(20)  
GROUP_ID                      VARCHAR2(20)  
STATUS                        NUMBER        
CREATED_BY           NOT NULL VARCHAR2(50)  
CREATION_DATE        NOT NULL DATE          
MODIFIED_BY          NOT NULL VARCHAR2(50)  
LAST_MODIFIED_DATE   NOT NULL DATE            
 */
public class NbsClusterInfoBean {
   //members

   protected int nbsClusterInfoId;
   protected int nbsPoolId;
   protected String nbsType;
   protected int bsAsMapping;
   protected String internalPort;
   protected String internal32Ip;
   protected String externalPort;    
   protected String external28IpBlock;
   protected String externalIp2w;
   protected String externalIpIb;
   protected String wtInternalPort;     
   protected String wtExternalPort;    
   protected String cpeExternalPort;
   protected String nifIp1;
   protected String nifIp2;
   protected String nifIp3;
   protected String nifIp4;
   protected String vpnId;
   protected String vpnName;   
   protected String locationId;
   protected String groupId;
   protected int status;
   protected String createdBy;
   protected String modifiedBy;
   protected java.sql.Timestamp creationDate;
   protected java.sql.Timestamp lastModifiedDate;
   protected boolean getAll;
  
   /**
    * Default Constructor -- Initializes all fields to default values.
    */
   public NbsClusterInfoBean() {
           
       this.nbsClusterInfoId=0;
	   this.nbsPoolId=0;
	   this.nbsType="NONE";
	   this.bsAsMapping=0;
	   this.internalPort="NONE";
	   this.internal32Ip="NONE";
	   this.externalPort= "NONE";   
	   this.external28IpBlock="NONE";
	   this.externalIp2w="NONE";
	   this.externalIpIb="NONE";
	   this.wtInternalPort="NONE";    
	   this.wtExternalPort="NONE"; 
	   this.cpeExternalPort="NONE";
	   this.nifIp1="NONE";
	   this.nifIp2="NONE";
	   this.nifIp3="NONE";
	   this.nifIp4="NONE";
	   this.vpnId="NONE";
	   this.vpnName="NONE";   
	   this.locationId="NONE";
	   this.groupId="NONE";
	   this.status=0;
	  
   }

   /**
    * Constructor
    *
    * @param poolBean
    */
   public NbsClusterInfoBean(NbsClusterInfoBean nbsClusterInfoBean) {
    
       this.nbsClusterInfoId=nbsClusterInfoBean.nbsClusterInfoId;
	   this.nbsPoolId=nbsClusterInfoBean.nbsPoolId;
	   this.nbsType=nbsClusterInfoBean.nbsType;
	   this.bsAsMapping=nbsClusterInfoBean.bsAsMapping;
	   this.internalPort=nbsClusterInfoBean.internalPort;
	   this.internal32Ip=nbsClusterInfoBean.internal32Ip;
	   this.externalPort= nbsClusterInfoBean.externalPort;   
	   this.external28IpBlock=nbsClusterInfoBean.external28IpBlock;
	   this.externalIp2w=nbsClusterInfoBean.externalIp2w;
	   this.externalIpIb=nbsClusterInfoBean.externalIpIb;
	   this.wtInternalPort=nbsClusterInfoBean.wtExternalPort;    
	   this.wtExternalPort=nbsClusterInfoBean.wtExternalPort; 
	   this.cpeExternalPort=nbsClusterInfoBean.cpeExternalPort;
	   this.nifIp1=nbsClusterInfoBean.nifIp1;
	   this.nifIp2=nbsClusterInfoBean.nifIp2;
	   this.nifIp3=nbsClusterInfoBean.nifIp3;
	   this.nifIp4=nbsClusterInfoBean.nifIp4;
	   this.vpnId=nbsClusterInfoBean.vpnId;
	   this.vpnName=nbsClusterInfoBean.vpnName;   
	   this.locationId=nbsClusterInfoBean.locationId;
	   this.groupId=nbsClusterInfoBean.groupId;
	   this.status=nbsClusterInfoBean.status;
     
   }

  

public void initilizeTODefault() {
    
      this.nbsClusterInfoId=0;
	   this.nbsPoolId=0;
	   this.nbsType="NONE";
	   this.bsAsMapping=0;
	   this.internalPort="NONE";
	   this.internal32Ip="NONE";
	   this.externalPort= "NONE";   
	   this.external28IpBlock="NONE";
	   this.externalIp2w="NONE";
	   this.externalIpIb="NONE";
	   this.wtInternalPort="NONE";    
	   this.wtExternalPort="NONE"; 
	   this.cpeExternalPort="NONE";
	   this.nifIp1="NONE";
	   this.nifIp2="NONE";
	   this.nifIp3="NONE";
	   this.nifIp4="NONE";
	   this.vpnId="NONE";
	   this.vpnName="NONE";   
	   this.locationId="NONE";
	   this.groupId="NONE";
	   this.status=0;
    
   }

public int getNbsClusterInfoId() {
	return nbsClusterInfoId;
}

public void setNbsClusterInfoId(int nbsClusterInfoId) {
	this.nbsClusterInfoId = nbsClusterInfoId;
}

public int getNbsPoolId() {
	return nbsPoolId;
}

public void setNbsPoolId(int nbsPoolId) {
	this.nbsPoolId = nbsPoolId;
}

public String getNbsType() {
	return nbsType;
}

public void setNbsType(String nbsType) {
	this.nbsType = nbsType;
}

public int getBsAsMapping() {
	return bsAsMapping;
}

public void setBsAsMapping(int bsAsMapping) {
	this.bsAsMapping = bsAsMapping;
}

public String getInternalPort() {
	return internalPort;
}

public void setInternalPort(String internalPort) {
	this.internalPort = internalPort;
}

public String getInternal32Ip() {
	return internal32Ip;
}

public void setInternal32Ip(String internal32Ip) {
	this.internal32Ip = internal32Ip;
}

public String getExternalPort() {
	return externalPort;
}

public void setExternalPort(String externalPort) {
	this.externalPort = externalPort;
}

public String getExternal28IpBlock() {
	return external28IpBlock;
}

public void setExternal28IpBlock(String external28IpBlock) {
	this.external28IpBlock = external28IpBlock;
}

public String getExternalIp2w() {
	return externalIp2w;
}

public void setExternalIp2w(String externalIp2w) {
	this.externalIp2w = externalIp2w;
}

public String getExternalIpIb() {
	return externalIpIb;
}

public void setExternalIpIb(String externalIpIb) {
	this.externalIpIb = externalIpIb;
}

public String getWtInternalPort() {
	return wtInternalPort;
}

public void setWtInternalPort(String wtInternalPort) {
	this.wtInternalPort = wtInternalPort;
}

public String getWtExternalPort() {
	return wtExternalPort;
}

public void setWtExternalPort(String wtExternalPort) {
	this.wtExternalPort = wtExternalPort;
}

public String getCpeExternalPort() {
	return cpeExternalPort;
}

public void setCpeExternalPort(String cpeExternalPort) {
	this.cpeExternalPort = cpeExternalPort;
}

public String getNifIp1() {
	return nifIp1;
}

public void setNifIp1(String nifIp1) {
	this.nifIp1 = nifIp1;
}

public String getNifIp2() {
	return nifIp2;
}

public void setNifIp2(String nifIp2) {
	this.nifIp2 = nifIp2;
}

public String getNifIp3() {
	return nifIp3;
}

public void setNifIp3(String nifIp3) {
	this.nifIp3 = nifIp3;
}

public String getNifIp4() {
	return nifIp4;
}

public void setNifIp4(String nifIp4) {
	this.nifIp4 = nifIp4;
}

public String getVpnId() {
	return vpnId;
}

public void setVpnId(String vpnId) {
	this.vpnId = vpnId;
}

public String getVpnName() {
	return vpnName;
}

public void setVpnName(String vpnName) {
	this.vpnName = vpnName;
}

public String getLocationId() {
	return locationId;
}

public void setLocationId(String locationId) {
	this.locationId = locationId;
}

public String getGroupId() {
	return groupId;
}

public void setGroupId(String groupId) {
	this.groupId = groupId;
}

public int getStatus() {
	return status;
}

public void setStatus(int status) {
	this.status = status;
}

public String getCreatedBy() {
	return createdBy;
}

public void setCreatedBy(String createdBy) {
	this.createdBy = createdBy;
}

public String getModifiedBy() {
	return modifiedBy;
}

public void setModifiedBy(String modifiedBy) {
	this.modifiedBy = modifiedBy;
}

public java.sql.Timestamp getCreationDate() {
	return creationDate;
}

public void setCreationDate(java.sql.Timestamp creationDate) {
	this.creationDate = creationDate;
}

public java.sql.Timestamp getLastModifiedDate() {
	return lastModifiedDate;
}

public void setLastModifiedDate(java.sql.Timestamp lastModifiedDate) {
	this.lastModifiedDate = lastModifiedDate;
}

public boolean isGetAll() {
	return getAll;
}

public void setGetAll(boolean getAll) {
	this.getAll = getAll;
}



   //
} //EOF