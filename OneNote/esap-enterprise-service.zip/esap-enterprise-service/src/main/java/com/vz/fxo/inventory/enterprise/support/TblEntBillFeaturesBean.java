package com.vz.fxo.inventory.enterprise.support;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.sql.Timestamp;

public class TblEntBillFeaturesBean implements Serializable{
	protected String enterpriseId;
	protected String locationId;
	protected String featureCode;
	protected String pbli;
	protected String chargeType;
	protected String chargeFrequency;
	protected String unitOfMeasure;
	protected String billTime;
	protected Long featureInstanceId;
	protected Timestamp catalogueReferenceTime;
	protected long featureType;
    protected List<String> logTrail;
	
	
	public TblEntBillFeaturesBean() {
		this.enterpriseId = "";
		this.locationId = "";
		this.featureCode = "";
		this.pbli = "";
		this.chargeType = "";
		this.chargeFrequency = "";
		this.unitOfMeasure = "";
		this.billTime = "";
		this.featureInstanceId = 0L;
		this.catalogueReferenceTime = null;
		this.featureType = 0;
        logTrail = new ArrayList<String>();
	}
	
	public TblEntBillFeaturesBean(TblEntBillFeaturesBean entBillFeaturesBean) {
		this.enterpriseId = entBillFeaturesBean.enterpriseId;
		this.locationId = entBillFeaturesBean.locationId;
		this.featureCode = entBillFeaturesBean.featureCode;
		this.pbli = entBillFeaturesBean.pbli;
		this.chargeType = entBillFeaturesBean.chargeType;
		this.chargeFrequency = entBillFeaturesBean.chargeFrequency;
		this.unitOfMeasure = entBillFeaturesBean.unitOfMeasure;
		this.billTime = entBillFeaturesBean.billTime;
		this.featureInstanceId = entBillFeaturesBean.featureInstanceId;
		this.catalogueReferenceTime = entBillFeaturesBean.catalogueReferenceTime;
		this.featureType = entBillFeaturesBean.featureType;
        logTrail = entBillFeaturesBean.logTrail;
	}
	
	/**
	 * @return the featureInstanceId
	 */
	public Long getFeatureInstanceId() {
		return featureInstanceId;
	}

	/**
	 * @param featureInstanceId the featureInstanceId to set
	 */
	public void setFeatureInstanceId(Long featureInstanceId) {
		this.featureInstanceId = featureInstanceId;
	}

	/** Getters and Setters for EntBillFeaturesBean **/
	
	public List<String> getLogTrail() {
		return logTrail;
	}

	public void setLogTrail(String logStr) {
        logTrail.add(logStr);
    }


	public String getEnterpriseId() {
		return enterpriseId;
	}

	public void setEnterpriseId(String enterpriseId) {
		this.enterpriseId = enterpriseId;
	}

	public String getLocationId() {
		return locationId;
	}

	public void setLocationId(String locationId) {
		this.locationId = locationId;
	}

	public String getFeatureCode() {
		return featureCode;
	}

	public void setFeatureCode(String featureCode) {
		this.featureCode = featureCode;
	}

	public String getPbli() {
		return pbli;
	}

	public void setPbli(String pbli) {
		this.pbli = pbli;
	}

	public String getChargeType() {
		return chargeType;
	}

	public void setChargeType(String chargeType) {
		this.chargeType = chargeType;
	}

	public String getChargeFrequency() {
		return chargeFrequency;
	}

	public void setChargeFrequency(String chargeFrequency) {
		this.chargeFrequency = chargeFrequency;
	}

	public String getUnitOfMeasure() {
		return unitOfMeasure;
	}

	public void setUnitOfMeasure(String unitOfMeasure) {
		this.unitOfMeasure = unitOfMeasure;
	}

	public String getBillTime() {
		return billTime;
	}

	public void setBillTime(String billTime) {
		this.billTime = billTime;
	}
    
    public Timestamp getCatalogueReferenceTime() {
		return catalogueReferenceTime;
	}

	public void setCatalogueReferenceTime(final Timestamp catalogueReferenceTime) {
		this.catalogueReferenceTime = catalogueReferenceTime;
    }

	public long getFeatureType() {
		return featureType;
	}

	public void setFeatureType(long featureType) {
		this.featureType = featureType;
	}
	
	
}

