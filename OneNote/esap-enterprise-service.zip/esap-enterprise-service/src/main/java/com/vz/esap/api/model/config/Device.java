package com.vz.esap.api.model.config;

import java.util.ArrayList;
import java.util.List;

//This entity corresponds to TBL_DEVICE_INFO
public class Device {
	private String deviceName;
	private Integer status;
	private Integer loginStatus;
	private Integer connectStatus;
	private List<TableRouteInfoParam> routeInfoParamList;
	
	public Device(DeviceBuilder deviceBuilder) {
		this.deviceName = deviceBuilder.deviceName;
		this.status = deviceBuilder.status;
		this.loginStatus = deviceBuilder.loginStatus;
		this.connectStatus = deviceBuilder.connectStatus;
		this.routeInfoParamList = deviceBuilder.routeInfoParamList;
	}
	
	public String getDeviceName() {
		return deviceName;
	}
	public void setDeviceName(String deviceName) {
		this.deviceName = deviceName;
	}
	public Integer getStatus() {
		return status;
	}
	public void setStatus(Integer status) {
		this.status = status;
	}
	public Integer getLoginStatus() {
		return loginStatus;
	}
	public void setLoginStatus(Integer loginStatus) {
		this.loginStatus = loginStatus;
	}
	public Integer getConnectStatus() {
		return connectStatus;
	}
	public void setConnectStatus(Integer connectStatus) {
		this.connectStatus = connectStatus;
	}
	public List<TableRouteInfoParam> getRouteInfoParamList() {
		return routeInfoParamList;
	}
	public void setRouteInfoParamList(List<TableRouteInfoParam> routeInfoParamList) {
		this.routeInfoParamList = routeInfoParamList;
	}
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Device [deviceName=");
		builder.append(deviceName);
		builder.append(", Status=");
		builder.append(status);
		builder.append(", loginStatus=");
		builder.append(loginStatus);
		builder.append(", connectStatus=");
		builder.append(connectStatus);
		builder.append(", routeInfoParamList=");
		builder.append(routeInfoParamList);
		builder.append("]");
		return builder.toString();
	}
	
	public static class DeviceBuilder {
		private String deviceName;
		private Integer status;
		private Integer loginStatus;
		private Integer connectStatus;
		private List<TableRouteInfoParam> routeInfoParamList = new ArrayList<>();
		
		public DeviceBuilder withDeviceName(String deviceName) {
			this.deviceName = deviceName;
			return this;
		}
		public DeviceBuilder withStatus(Integer status) {
			this.status = status;
			return this;
		}
		public DeviceBuilder withLoginStatus(Integer loginStatus) {
			this.loginStatus = loginStatus;
			return this;
		}
		public DeviceBuilder withConnectStatus(Integer connectStatus) {
			this.connectStatus = connectStatus;
			return this;
		}
		public DeviceBuilder addTableRouteParamInfo(TableRouteInfoParam tableRouteInfoParam) {
			routeInfoParamList.add(tableRouteInfoParam);
			return this;
		}
		public Device build() {
			return new Device(this);
		}
		
		
	}

	
}
