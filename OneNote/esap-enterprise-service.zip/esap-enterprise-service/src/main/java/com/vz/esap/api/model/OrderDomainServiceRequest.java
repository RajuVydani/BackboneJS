package com.vz.esap.api.model;

import java.util.ArrayList;
import java.util.List;

import com.vz.esap.api.model.ordering.OrderHeader;
import com.vz.esap.api.model.ordering.OrderSearchFilter;

public class OrderDomainServiceRequest {

	private OrderHeader orderHeader;
	private List<OrderSearchFilter> entitySearchInfo;

	public OrderDomainServiceRequest(OrderDomainServiceRequestBuilder orderDomainServiceRequestBuilder) {
		this.orderHeader = orderDomainServiceRequestBuilder.orderHeader;
		this.entitySearchInfo = orderDomainServiceRequestBuilder.entitySearchInfo;
	}

	public OrderHeader getOrderHeader() {
		return orderHeader;
	}

	public void setOrderHeader(OrderHeader orderHeader) {
		this.orderHeader = orderHeader;
	}

	public List<OrderSearchFilter> getSearchFilter() {
		return entitySearchInfo;
	}

	public void setSearchFilter(List<OrderSearchFilter> entitySearchInfo) {
		this.entitySearchInfo = entitySearchInfo;
	}

	public static class OrderDomainServiceRequestBuilder {
		private OrderHeader orderHeader;
		private List<OrderSearchFilter> entitySearchInfo = new ArrayList<>();

		public OrderDomainServiceRequestBuilder withOrderHeader(OrderHeader orderHeader) {
			this.orderHeader = orderHeader;
			return this;
		}

		public OrderDomainServiceRequestBuilder addSearchFilter(OrderSearchFilter entitySearchInfo) {
			this.entitySearchInfo.add(entitySearchInfo);
			return this;
		}

		public OrderDomainServiceRequest build() {
			return new OrderDomainServiceRequest(this);
		}

	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("OrderDomainServiceRequest [orderHeader=");
		builder.append(orderHeader);
		builder.append(", searchFilter=");
		builder.append(entitySearchInfo);
		builder.append("]");
		return builder.toString();
	}
	
	

}
