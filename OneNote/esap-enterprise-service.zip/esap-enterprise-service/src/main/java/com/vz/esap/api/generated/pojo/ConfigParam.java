
package com.vz.esap.api.generated.pojo;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "configParamsId",
    "processName",
    "paramGroup",
    "paramName",
    "paramValue",
    "status",
    "description"
})
public class ConfigParam {

    @JsonProperty("configParamsId")
    private Long configParamsId;
    @JsonProperty("processName")
    private String processName;
    @JsonProperty("paramGroup")
    private String paramGroup;
    @JsonProperty("paramName")
    private String paramName;
    @JsonProperty("paramValue")
    private String paramValue;
    @JsonProperty("status")
    private String status;
    @JsonProperty("description")
    private String description;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("configParamsId")
    public Long getConfigParamsId() {
        return configParamsId;
    }

    @JsonProperty("configParamsId")
    public void setConfigParamsId(Long configParamsId) {
        this.configParamsId = configParamsId;
    }

    @JsonProperty("processName")
    public String getProcessName() {
        return processName;
    }

    @JsonProperty("processName")
    public void setProcessName(String processName) {
        this.processName = processName;
    }

    @JsonProperty("paramGroup")
    public String getParamGroup() {
        return paramGroup;
    }

    @JsonProperty("paramGroup")
    public void setParamGroup(String paramGroup) {
        this.paramGroup = paramGroup;
    }

    @JsonProperty("paramName")
    public String getParamName() {
        return paramName;
    }

    @JsonProperty("paramName")
    public void setParamName(String paramName) {
        this.paramName = paramName;
    }

    @JsonProperty("paramValue")
    public String getParamValue() {
        return paramValue;
    }

    @JsonProperty("paramValue")
    public void setParamValue(String paramValue) {
        this.paramValue = paramValue;
    }

    @JsonProperty("status")
    public String getStatus() {
        return status;
    }

    @JsonProperty("status")
    public void setStatus(String status) {
        this.status = status;
    }

    @JsonProperty("description")
    public String getDescription() {
        return description;
    }

    @JsonProperty("description")
    public void setDescription(String description) {
        this.description = description;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(configParamsId).append(processName).append(paramGroup).append(paramName).append(paramValue).append(status).append(description).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof ConfigParam) == false) {
            return false;
        }
        ConfigParam rhs = ((ConfigParam) other);
        return new EqualsBuilder().append(configParamsId, rhs.configParamsId).append(processName, rhs.processName).append(paramGroup, rhs.paramGroup).append(paramName, rhs.paramName).append(paramValue, rhs.paramValue).append(status, rhs.status).append(description, rhs.description).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
