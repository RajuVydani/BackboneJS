
/** 
 * AcctAuthCodes.java
 * esap.vzbvoip.inventory
 */
package com.vz.fxo.inventory.enterprise.support;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Timestamp;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import esap.db.DBTblAcctAuthCodes;
import esap.db.DBTblLocation;
import esap.db.TblAcctAuthCodesQuery;

/**
 * @author TATA CONSULTANCY SERVICES Ltd.
 * ESAP
 * May 16, 2009
 */
public class AcctAuthCodes extends AcctAuthCodesBean{

	private static Logger log = LoggerFactory.getLogger(AcctAuthCodes.class.toString());
	
	/**
	 * Variable Declaration
	 */
	private Connection dbCon		= null;

	InvErrorCode status = InvErrorCode.INTERNAL_ERROR;
	public int getStatusCode() {
		return status.getErrorCode();
	}
	public void setStatus(InvErrorCode status) {
		this.status = status;
	}
	public String getStatusDesc() {
		return status.getErrorDesc();
	}


	/**
	 * @param connection
	 */
	public AcctAuthCodes(Connection connection) {
		this.dbCon = connection;
	}
	
	/**
	 * @param acctAuthCodes, connection
	 */
	public AcctAuthCodes(AcctAuthCodes acctAuthCodes, Connection connection) {
		super(acctAuthCodes);
		this.dbCon = connection;
	}

	/**
	 * @param acctAuthCodes, connection
	 */
	public AcctAuthCodes(AcctAuthCodesBean acctAuthCodes, Connection connection) {
		setIntAcctAuthCodesId(acctAuthCodes.getIntAcctAuthCodesId());
		setStrLocationId(acctAuthCodes.getStrLocationId());
		setStrAcctAuthCode(acctAuthCodes.getStrAcctAuthCode());
		setStrAcctAuthDesc(acctAuthCodes.getStrAcctAuthDesc());
		setLongCodeType(acctAuthCodes.getLongCodeType());
		setStrCreatedBy(acctAuthCodes.getStrCreatedBy());
		setStrCreationDate(acctAuthCodes.getStrCreationDate());
		setStrModifiedBy(getStrModifiedBy());
		setStrLastModifiedDate(acctAuthCodes.getStrLastModifiedDate());
		setEnvOrderId(acctAuthCodes.getEnvOrderId());
		this.dbCon = connection;
	}
	/**
	 * @Param addToDB
	 * @description: Adds AcctAuthCode to DB
	 * @return boolean
	 * @throws SQLException
	 * @author Thejas
	 * @editedby
	 */
	public boolean addToDB() throws SQLException, Exception
{
		setLogTrail("AcctAuthCodes::addToDB  BEGIN");
//		try {
			DBTblAcctAuthCodes acctAuthCodeBean = new DBTblAcctAuthCodes();
			/** Create the next id */
			int intAcctAuthCodesId = acctAuthCodeBean.getAcctAuthCodesIdSeqNextVal(dbCon);
			setIntAcctAuthCodesId(intAcctAuthCodesId);
			
			/** Setting in DB Bean */
			acctAuthCodeBean.setAcctAuthCodesId(getIntAcctAuthCodesId());
			acctAuthCodeBean.setLocationId(getStrLocationId());
			acctAuthCodeBean.setAcctAuthCode(getStrAcctAuthCode());
			acctAuthCodeBean.setAcctAuthDesc(getStrAcctAuthDesc());
			if(getLongCodeType() == -1)
				acctAuthCodeBean.setCodeTypeNull();
			else
				acctAuthCodeBean.setCodeType(getLongCodeType());
			
			log.info("EnvOrderId = <" + getEnvOrderId() + ">");
    	    		if(getEnvOrderId() > 0)
    	    			acctAuthCodeBean.setEnvOrderId(getEnvOrderId());
			else
    	    			acctAuthCodeBean.setEnvOrderIdNull();

			if(getStrCreatedBy() != null && !getStrCreatedBy().equals(""))
				acctAuthCodeBean.setCreatedBy(getStrCreatedBy());
			else
				acctAuthCodeBean.setCreatedBy("ESAP_INV");
			acctAuthCodeBean.setCreationDate(new Timestamp(System.currentTimeMillis()));
			if(getStrModifiedBy() != null && !getStrModifiedBy().equals(""))
				acctAuthCodeBean.setModifiedBy(getStrModifiedBy());
			else
				acctAuthCodeBean.setModifiedBy("ESAP_INV");
			acctAuthCodeBean.setLastModifiedDate(new Timestamp(System.currentTimeMillis()));
			
			acctAuthCodeBean.insert(dbCon);
		/*}catch (SQLException e) {
			setStatus(InvErrorCode.DB_EXCEPTION);
			e.printStackTrace();
			setLogTrail("AcctAuthCodes::addToDB  DB_FAILURE in addToDB AcctAuthCodes");
			return false;
		}*/
		setStatus(InvErrorCode.SUCCESS);
		setLogTrail("AcctAuthCodes::addToDB :: Successfully inserted AcctAuthCodes. ID " + getIntAcctAuthCodesId());
		return true;
	}

	/**
	 * The method to modify the AcctAuthCodes record.
	 *
	 * AcctAuthCodes Id should be set before calling this method.
	 *
	 * @return	true	Record has been updated SUCCESSFULLY
	 * 			false	AcctAuthCodes Id missing / Record update Unsuccessful /
	 * 					Some Error occured.
	 */
	public boolean modifyInDB(){
		try
		{
			if ( getIntAcctAuthCodesId() <= 0) {
				setStatus(InvErrorCode.INTERNAL_ERROR);
				log.info("FAILURE in modifyInDB AcctAuthCode. AcctAuthCodeId missing.");
				setLogTrail("AcctAuthCodes::modifyInDB :: FAILURE in modifyInDB AcctAuthCode. AcctAuthCodeId missing.");
				return false;
			}

			DBTblAcctAuthCodes acctAuthCodesBean = getAcctAuthCodesToUpdate();
			acctAuthCodesBean.whereAcctAuthCodesIdEQ(getIntAcctAuthCodesId());

			if ( acctAuthCodesBean.updateSpByWhere(dbCon) <= 0 ) {
				return false;
			}
		} catch(SQLException s) {
			s.printStackTrace();
			setStatus(InvErrorCode.DB_EXCEPTION);
			s.printStackTrace();
			log.info("DB_FAILURE in modifyInDB AcctAuthCodes");
			setLogTrail("AcctAuthCodes::modifyInDB :: DB_FAILURE in modifyInDB AcctAuthCodes");
			return false;
		}
		setStatus(InvErrorCode.SUCCESS);
		setLogTrail("AcctAuthCodes::modifyInDB :: Successfully UPDATED AcctAuthCodes. ID " + getIntAcctAuthCodesId());

		return true;
	}
	public boolean modifyInDBByLocationANDAuthCode() throws Exception,SQLException{
		/*try
		{*/
			 if(getStrLocationId()==  null ||  getStrLocationId().equals("")) {
				 setStatus(InvErrorCode.INTERNAL_ERROR);
                 return false;
			 }
			 if(getStrAcctAuthCode()==  null ||  getStrAcctAuthCode().equals("")) {
					setStatus(InvErrorCode.INTERNAL_ERROR);
              return false;
			 }

			DBTblAcctAuthCodes acctAuthCodesBean = getAcctAuthCodesToUpdate();
			acctAuthCodesBean.whereLocationIdEQ(getStrLocationId());
			acctAuthCodesBean.whereAcctAuthCodeEQ(getStrAcctAuthCode());
	

			if ( acctAuthCodesBean.updateSpByWhere(dbCon) <= 0 ) {
				return false;
			}
		/*} catch(SQLException s) {
			s.printStackTrace();
			setStatus(InvErrorCode.DB_EXCEPTION);
			s.printStackTrace();
			log.info("DB_FAILURE in modifyInDB AcctAuthCodes");
			setLogTrail("AcctAuthCodes::modifyInDB :: DB_FAILURE in modifyInDB AcctAuthCodes");
			return false;
		}*/
		setStatus(InvErrorCode.SUCCESS);
		setLogTrail("AcctAuthCodes::modifyInDB :: Successfully UPDATED AcctAuthCodes. ID " + getIntAcctAuthCodesId());

		return true;
	}
	
	/**
	 * The current AcctAuthCodes details are extracted using getDetails()
	 * and the new field values are updated over that. The method
	 * will update the fields that are supplied on the current instance
	 * if they are different from the default values for the respective field.
	 *
	 * @return The AcctAuth Codes to be updated.
	 */
	@SuppressWarnings("unused")
	private DBTblAcctAuthCodes getAcctAuthCodesToUpdate() {
		DBTblAcctAuthCodes acctAuthCodesDbBean = new DBTblAcctAuthCodes();

		/* Create a new instance of AcctAuthCodesBean. The new instance
		 * would hold default values for the all the AcctAuthCodes fields.*/
		AcctAuthCodesBean defaultAcctAuthCodesBean = new AcctAuthCodesBean();

		AcctAuthCodes inputAcctAuthCodes = this;
		if(getIntAcctAuthCodesId() >0 ) {
			acctAuthCodesDbBean.setAcctAuthCodesId(getIntAcctAuthCodesId());
                }

		if ( inputAcctAuthCodes.getStrLocationId() != null &&
				!inputAcctAuthCodes.getStrLocationId().equals(defaultAcctAuthCodesBean.getStrLocationId()) ){
			acctAuthCodesDbBean.setLocationId(inputAcctAuthCodes.getStrLocationId());
		}

		if ( inputAcctAuthCodes.getStrAcctAuthCode() != null &&
				!inputAcctAuthCodes.getStrAcctAuthCode().equals(defaultAcctAuthCodesBean.getStrAcctAuthCode()) ){
			acctAuthCodesDbBean.setAcctAuthCode(inputAcctAuthCodes.getStrAcctAuthCode());
		}
		
		if ( inputAcctAuthCodes.getStrAcctAuthDesc() != null &&
				!inputAcctAuthCodes.getStrAcctAuthDesc().equals(defaultAcctAuthCodesBean.getStrAcctAuthDesc()) ){
			acctAuthCodesDbBean.setAcctAuthDesc(inputAcctAuthCodes.getStrAcctAuthDesc());
		}
		
		if ( inputAcctAuthCodes.getLongCodeType() != defaultAcctAuthCodesBean.getLongCodeType()){
			acctAuthCodesDbBean.setCodeType(inputAcctAuthCodes.getLongCodeType());
		}
		
        	if (inputAcctAuthCodes.getEnvOrderId() != defaultAcctAuthCodesBean.getEnvOrderId()) {
        		acctAuthCodesDbBean.setEnvOrderId(inputAcctAuthCodes.getEnvOrderId());
        	}

		if( inputAcctAuthCodes.getStrModifiedBy() != null &&
		    !( "".equalsIgnoreCase(inputAcctAuthCodes.getStrModifiedBy()) ) ) {
			acctAuthCodesDbBean.setModifiedBy(inputAcctAuthCodes.getStrModifiedBy());
		} else {
			acctAuthCodesDbBean.setModifiedBy("ESAP_INV");
	    	}

		acctAuthCodesDbBean.setLastModifiedDate(new Timestamp(System.currentTimeMillis()));
		return acctAuthCodesDbBean;
	}
	
	/**
	 * @Param getDetails
	 * @description: 
	 * @return boolean
	 * @throws ESAPException
	 * @author Thejas
	 * @editedby
	 */
	public boolean getDetails()
	{
		try
		{
			setLogTrail("In AcctAuthCodes getDetails AcctAuthCodeId="+getIntAcctAuthCodesId());
			log.info("In AcctAuthCodes getDetails; AcctAuthCodeId="+getIntAcctAuthCodesId());
			TblAcctAuthCodesQuery locQry = new TblAcctAuthCodesQuery();
			String whereClause = " where acct_auth_codes_id = \'"+getIntAcctAuthCodesId()+"\'";
			locQry.queryByWhere(dbCon, whereClause);
			if(locQry.size() == 1){
				setStrLocationId((locQry.getDbBean(0)).getLocationId());
				setStrAcctAuthCode((locQry.getDbBean(0)).getAcctAuthCode());
				setStrAcctAuthDesc((locQry.getDbBean(0)).getAcctAuthDesc());
				setLongCodeType((locQry.getDbBean(0)).getCodeType());
				setStrCreatedBy((locQry.getDbBean(0)).getCreatedBy());
				setStrCreationDate((locQry.getDbBean(0)).getCreationDate());
				setStrModifiedBy((locQry.getDbBean(0)).getModifiedBy());
				setStrLastModifiedDate((locQry.getDbBean(0)).getLastModifiedDate());
				setEnvOrderId((locQry.getDbBean(0)).getEnvOrderId());		
			}else
			{
				setStatus(InvErrorCode.DATA_NOTFOUND);
				setLogTrail("AcctAuthCodes::getDetails :: FAILURE in getDetails AcctAuthcodes.Couldn't find any AcctAuthCodes with the given AcctAuthCodesId");
				return false;
			}
			
		}catch(SQLException s)
		{
			s.printStackTrace();
			setStatus(InvErrorCode.DB_EXCEPTION);
			setLogTrail("AcctAuthCodes::getDetails :: DB_FAILURE in getDetails AcctAuthCodes");
			return false;
		}
		setStatus(InvErrorCode.SUCCESS);
		setLogTrail("AcctAuthCodes::getDetails :: Successfully retrieved AcctAuthCodes from db. ID " + getIntAcctAuthCodesId());
		return true;
	}
	/****Z562196 code start ****/
	/**
	 * @Param deleteFromDB
	 * @description: Deletes the AcctAuthCodes from DB
	 * @return boolean
	 * @throws ESAPException
	 * @author Guru
	 * @editedby
	 */
	public boolean deleteFromDBByLocationANDAuthCode() throws Exception,SQLException{
		/*try
		{*/
			 if(getStrLocationId()==  null ||  getStrLocationId().equals("")) {
				 setStatus(InvErrorCode.INTERNAL_ERROR);
                    return false;
			 }
			 if(getStrAcctAuthCode()==  null ||  getStrAcctAuthCode().equals("")) {
				 setStatus(InvErrorCode.INTERNAL_ERROR);
                 return false;
			 }
			DBTblAcctAuthCodes acctAuthCodesDbBean = new DBTblAcctAuthCodes();
			acctAuthCodesDbBean.whereLocationIdEQ(getStrLocationId());
			acctAuthCodesDbBean.whereAcctAuthCodeEQ(getStrAcctAuthCode());
			acctAuthCodesDbBean.deleteByWhere(dbCon);
			
		/*} catch(SQLException s) {
			s.printStackTrace();
			setStatus(InvErrorCode.DB_EXCEPTION);
			log.info("DB_FAILURE in deleteFromDB AcctAuthCodes");
			setLogTrail("AcctAuthCodes::deleteFromDB :: DB_FAILURE in deleteFromDB AcctAuthCodes");
			return false;
		}*/
		setStatus(InvErrorCode.SUCCESS);
		setLogTrail("AcctAuthCodes::deleteFromDB :: Successfully DELETED AcctAuthCodes" + getIntAcctAuthCodesId() + "from  the DB");
		return true;
	}
	/****Z562196 code end ****/
	/**
	 * @Param deleteFromDB
	 * @description: Deletes the AcctAuthCodes from DB
	 * @return boolean
	 * @throws ESAPException
	 * @author Thejas
	 * @editedby
	 */
	public boolean deleteFromDB(){
		try
		{
			if(getIntAcctAuthCodesId() <= 0)
                        {
						setStatus(InvErrorCode.INTERNAL_ERROR);
                        return false;
                        }

			DBTblAcctAuthCodes acctAuthCodesDbBean = new DBTblAcctAuthCodes();
			acctAuthCodesDbBean.whereAcctAuthCodesIdEQ(getIntAcctAuthCodesId());
			//acctAuthCodesDbBean.setAcctAuthCodesId(getIntAcctAuthCodesId());
			acctAuthCodesDbBean.deleteByWhere(dbCon);
			
		} catch(SQLException s) {
			s.printStackTrace();
			setStatus(InvErrorCode.DB_EXCEPTION);
			log.info("DB_FAILURE in deleteFromDB AcctAuthCodes");
			setLogTrail("AcctAuthCodes::deleteFromDB :: DB_FAILURE in deleteFromDB AcctAuthCodes");
			return false;
		}
		setStatus(InvErrorCode.SUCCESS);
		setLogTrail("AcctAuthCodes::deleteFromDB :: Successfully DELETED AcctAuthCodes" + getIntAcctAuthCodesId() + "from  the DB");
		return true;
	}
	/**
	 * @return the dbCon
	 */
	public Connection getDbCon() {
		return this.dbCon;
	}

	/**
	 * @param dbCon the dbCon to set
	 */
	public void setDbCon(Connection dbCon) {
		this.dbCon = dbCon;
	}


	
	
}
