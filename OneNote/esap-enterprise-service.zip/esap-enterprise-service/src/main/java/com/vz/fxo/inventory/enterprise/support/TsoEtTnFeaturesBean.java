package com.vz.fxo.inventory.enterprise.support;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.ArrayList;

/**
 * @author Sandip Banerjee
 *
 */

public class TsoEtTnFeaturesBean implements Serializable{
	
	
	 	protected long etTnFeatureId;
	 	protected long etTnId;
	 	protected long featureId;
	 	protected String createdBy;
	 	protected Timestamp creationDate;
	 	protected String modifiedBy;
	 	protected Timestamp lastModifiedDate;
	 	protected long envOrderId;
	
	public TsoEtTnFeaturesBean(){
    	this.etTnFeatureId=0;
    	this.etTnId=0;
    	this.featureId=0;
    	this.createdBy = new String("");
        this.creationDate = null;
	    this.modifiedBy = new String("");
		this.lastModifiedDate = null;
    	this.envOrderId=0;
  }
  
    public TsoEtTnFeaturesBean(TsoEtTnFeaturesBean tsoEtTnFeaturesBean){
       	this.etTnFeatureId=tsoEtTnFeaturesBean.etTnFeatureId;
       	this.etTnId=tsoEtTnFeaturesBean.etTnId;
       	this.featureId=tsoEtTnFeaturesBean.featureId;
       	this.createdBy=tsoEtTnFeaturesBean.createdBy;
       	this.creationDate = tsoEtTnFeaturesBean.creationDate;
	    this.modifiedBy = tsoEtTnFeaturesBean.modifiedBy;
		this.lastModifiedDate = tsoEtTnFeaturesBean.lastModifiedDate;
		this.envOrderId=tsoEtTnFeaturesBean.envOrderId;
    }

	public long getEtTnFeatureId() {
		return etTnFeatureId;
	}

	public void setEtTnFeatureId(long etTnFeatureId) {
		this.etTnFeatureId = etTnFeatureId;
	}

	public long getEtTnId() {
		return etTnId;
	}

	public void setEtTnId(long etTnId) {
		this.etTnId = etTnId;
	}

	public long getFeatureId() {
		return featureId;
	}

	public void setFeatureId(long featureId) {
		this.featureId = featureId;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(Timestamp creationDate) {
		this.creationDate = creationDate;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Timestamp getLastModifiedDate() {
		return lastModifiedDate;
	}

	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public long getEnvOrderId() {
		return envOrderId;
	}

	public void setEnvOrderId(long envOrderId) {
		this.envOrderId = envOrderId;
	}
   

}
