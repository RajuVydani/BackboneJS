
package com.vz.esap.api.generated.pojo;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "bsAsId",
    "asName",
    "asClli",
    "asIpAddress",
    "asPort",
    "asGroupWebLink",
    "asGlobalWebLink",
    "version",
    "asProfile",
    "proxyClusterId",
    "cappedFlag",
    "overrideCappedFlag",
    "displayIndicator",
    "activeIndicator",
    "modifiedBy",
    "lastModifiedDate",
    "envOrderId",
    "bsNodeName",
    "asSecIpAddress",
    "asSecPort",
    "clusterHostName",
    "wServerIp",
    "versionMinor",
    "monitorUserSel",
    "tnActivation",
    "defaultSystemDomain",
    "esapCluster"
})
public class BsasMapping {

    @JsonProperty("bsAsId")
    private Long bsAsId;
    @JsonProperty("asName")
    private String asName;
    @JsonProperty("asClli")
    private String asClli;
    @JsonProperty("asIpAddress")
    private String asIpAddress;
    @JsonProperty("asPort")
    private Long asPort;
    @JsonProperty("asGroupWebLink")
    private String asGroupWebLink;
    @JsonProperty("asGlobalWebLink")
    private String asGlobalWebLink;
    @JsonProperty("version")
    private String version;
    @JsonProperty("asProfile")
    private String asProfile;
    @JsonProperty("proxyClusterId")
    private Long proxyClusterId;
    @JsonProperty("cappedFlag")
    private String cappedFlag;
    @JsonProperty("overrideCappedFlag")
    private String overrideCappedFlag;
    @JsonProperty("displayIndicator")
    private String displayIndicator;
    @JsonProperty("activeIndicator")
    private String activeIndicator;
    @JsonProperty("modifiedBy")
    private String modifiedBy;
    @JsonProperty("lastModifiedDate")
    private String lastModifiedDate;
    @JsonProperty("envOrderId")
    private Long envOrderId;
    @JsonProperty("bsNodeName")
    private String bsNodeName;
    @JsonProperty("asSecIpAddress")
    private Object asSecIpAddress;
    @JsonProperty("asSecPort")
    private Object asSecPort;
    @JsonProperty("clusterHostName")
    private Object clusterHostName;
    @JsonProperty("wServerIp")
    private Object wServerIp;
    @JsonProperty("versionMinor")
    private Object versionMinor;
    @JsonProperty("monitorUserSel")
    private Long monitorUserSel;
    @JsonProperty("tnActivation")
    private Long tnActivation;
    @JsonProperty("defaultSystemDomain")
    private String defaultSystemDomain;
    @JsonProperty("esapCluster")
    private Object esapCluster;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("bsAsId")
    public Long getBsAsId() {
        return bsAsId;
    }

    @JsonProperty("bsAsId")
    public void setBsAsId(Long bsAsId) {
        this.bsAsId = bsAsId;
    }

    @JsonProperty("asName")
    public String getAsName() {
        return asName;
    }

    @JsonProperty("asName")
    public void setAsName(String asName) {
        this.asName = asName;
    }

    @JsonProperty("asClli")
    public String getAsClli() {
        return asClli;
    }

    @JsonProperty("asClli")
    public void setAsClli(String asClli) {
        this.asClli = asClli;
    }

    @JsonProperty("asIpAddress")
    public String getAsIpAddress() {
        return asIpAddress;
    }

    @JsonProperty("asIpAddress")
    public void setAsIpAddress(String asIpAddress) {
        this.asIpAddress = asIpAddress;
    }

    @JsonProperty("asPort")
    public Long getAsPort() {
        return asPort;
    }

    @JsonProperty("asPort")
    public void setAsPort(Long asPort) {
        this.asPort = asPort;
    }

    @JsonProperty("asGroupWebLink")
    public String getAsGroupWebLink() {
        return asGroupWebLink;
    }

    @JsonProperty("asGroupWebLink")
    public void setAsGroupWebLink(String asGroupWebLink) {
        this.asGroupWebLink = asGroupWebLink;
    }

    @JsonProperty("asGlobalWebLink")
    public String getAsGlobalWebLink() {
        return asGlobalWebLink;
    }

    @JsonProperty("asGlobalWebLink")
    public void setAsGlobalWebLink(String asGlobalWebLink) {
        this.asGlobalWebLink = asGlobalWebLink;
    }

    @JsonProperty("version")
    public String getVersion() {
        return version;
    }

    @JsonProperty("version")
    public void setVersion(String version) {
        this.version = version;
    }

    @JsonProperty("asProfile")
    public String getAsProfile() {
        return asProfile;
    }

    @JsonProperty("asProfile")
    public void setAsProfile(String asProfile) {
        this.asProfile = asProfile;
    }

    @JsonProperty("proxyClusterId")
    public Long getProxyClusterId() {
        return proxyClusterId;
    }

    @JsonProperty("proxyClusterId")
    public void setProxyClusterId(Long proxyClusterId) {
        this.proxyClusterId = proxyClusterId;
    }

    @JsonProperty("cappedFlag")
    public String getCappedFlag() {
        return cappedFlag;
    }

    @JsonProperty("cappedFlag")
    public void setCappedFlag(String cappedFlag) {
        this.cappedFlag = cappedFlag;
    }

    @JsonProperty("overrideCappedFlag")
    public String getOverrideCappedFlag() {
        return overrideCappedFlag;
    }

    @JsonProperty("overrideCappedFlag")
    public void setOverrideCappedFlag(String overrideCappedFlag) {
        this.overrideCappedFlag = overrideCappedFlag;
    }

    @JsonProperty("displayIndicator")
    public String getDisplayIndicator() {
        return displayIndicator;
    }

    @JsonProperty("displayIndicator")
    public void setDisplayIndicator(String displayIndicator) {
        this.displayIndicator = displayIndicator;
    }

    @JsonProperty("activeIndicator")
    public String getActiveIndicator() {
        return activeIndicator;
    }

    @JsonProperty("activeIndicator")
    public void setActiveIndicator(String activeIndicator) {
        this.activeIndicator = activeIndicator;
    }

    @JsonProperty("modifiedBy")
    public String getModifiedBy() {
        return modifiedBy;
    }

    @JsonProperty("modifiedBy")
    public void setModifiedBy(String modifiedBy) {
        this.modifiedBy = modifiedBy;
    }

    @JsonProperty("lastModifiedDate")
    public String getLastModifiedDate() {
        return lastModifiedDate;
    }

    @JsonProperty("lastModifiedDate")
    public void setLastModifiedDate(String lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }

    @JsonProperty("envOrderId")
    public Long getEnvOrderId() {
        return envOrderId;
    }

    @JsonProperty("envOrderId")
    public void setEnvOrderId(Long envOrderId) {
        this.envOrderId = envOrderId;
    }

    @JsonProperty("bsNodeName")
    public String getBsNodeName() {
        return bsNodeName;
    }

    @JsonProperty("bsNodeName")
    public void setBsNodeName(String bsNodeName) {
        this.bsNodeName = bsNodeName;
    }

    @JsonProperty("asSecIpAddress")
    public Object getAsSecIpAddress() {
        return asSecIpAddress;
    }

    @JsonProperty("asSecIpAddress")
    public void setAsSecIpAddress(Object asSecIpAddress) {
        this.asSecIpAddress = asSecIpAddress;
    }

    @JsonProperty("asSecPort")
    public Object getAsSecPort() {
        return asSecPort;
    }

    @JsonProperty("asSecPort")
    public void setAsSecPort(Object asSecPort) {
        this.asSecPort = asSecPort;
    }

    @JsonProperty("clusterHostName")
    public Object getClusterHostName() {
        return clusterHostName;
    }

    @JsonProperty("clusterHostName")
    public void setClusterHostName(Object clusterHostName) {
        this.clusterHostName = clusterHostName;
    }

    @JsonProperty("wServerIp")
    public Object getWServerIp() {
        return wServerIp;
    }

    @JsonProperty("wServerIp")
    public void setWServerIp(Object wServerIp) {
        this.wServerIp = wServerIp;
    }

    @JsonProperty("versionMinor")
    public Object getVersionMinor() {
        return versionMinor;
    }

    @JsonProperty("versionMinor")
    public void setVersionMinor(Object versionMinor) {
        this.versionMinor = versionMinor;
    }

    @JsonProperty("monitorUserSel")
    public Long getMonitorUserSel() {
        return monitorUserSel;
    }

    @JsonProperty("monitorUserSel")
    public void setMonitorUserSel(Long monitorUserSel) {
        this.monitorUserSel = monitorUserSel;
    }

    @JsonProperty("tnActivation")
    public Long getTnActivation() {
        return tnActivation;
    }

    @JsonProperty("tnActivation")
    public void setTnActivation(Long tnActivation) {
        this.tnActivation = tnActivation;
    }

    @JsonProperty("defaultSystemDomain")
    public String getDefaultSystemDomain() {
        return defaultSystemDomain;
    }

    @JsonProperty("defaultSystemDomain")
    public void setDefaultSystemDomain(String defaultSystemDomain) {
        this.defaultSystemDomain = defaultSystemDomain;
    }

    @JsonProperty("esapCluster")
    public Object getEsapCluster() {
        return esapCluster;
    }

    @JsonProperty("esapCluster")
    public void setEsapCluster(Object esapCluster) {
        this.esapCluster = esapCluster;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(bsAsId).append(asName).append(asClli).append(asIpAddress).append(asPort).append(asGroupWebLink).append(asGlobalWebLink).append(version).append(asProfile).append(proxyClusterId).append(cappedFlag).append(overrideCappedFlag).append(displayIndicator).append(activeIndicator).append(modifiedBy).append(lastModifiedDate).append(envOrderId).append(bsNodeName).append(asSecIpAddress).append(asSecPort).append(clusterHostName).append(wServerIp).append(versionMinor).append(monitorUserSel).append(tnActivation).append(defaultSystemDomain).append(esapCluster).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof BsasMapping) == false) {
            return false;
        }
        BsasMapping rhs = ((BsasMapping) other);
        return new EqualsBuilder().append(bsAsId, rhs.bsAsId).append(asName, rhs.asName).append(asClli, rhs.asClli).append(asIpAddress, rhs.asIpAddress).append(asPort, rhs.asPort).append(asGroupWebLink, rhs.asGroupWebLink).append(asGlobalWebLink, rhs.asGlobalWebLink).append(version, rhs.version).append(asProfile, rhs.asProfile).append(proxyClusterId, rhs.proxyClusterId).append(cappedFlag, rhs.cappedFlag).append(overrideCappedFlag, rhs.overrideCappedFlag).append(displayIndicator, rhs.displayIndicator).append(activeIndicator, rhs.activeIndicator).append(modifiedBy, rhs.modifiedBy).append(lastModifiedDate, rhs.lastModifiedDate).append(envOrderId, rhs.envOrderId).append(bsNodeName, rhs.bsNodeName).append(asSecIpAddress, rhs.asSecIpAddress).append(asSecPort, rhs.asSecPort).append(clusterHostName, rhs.clusterHostName).append(wServerIp, rhs.wServerIp).append(versionMinor, rhs.versionMinor).append(monitorUserSel, rhs.monitorUserSel).append(tnActivation, rhs.tnActivation).append(defaultSystemDomain, rhs.defaultSystemDomain).append(esapCluster, rhs.esapCluster).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
