package com.vz.fxo.inventory.reponsegenerator;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.vz.fxo.inventory.enterprise.enums.EsapEnum.FunctionCode;
import com.vz.fxo.inventory.enterprise.enums.EsapEnum.MileStone;
import com.vz.fxo.inventory.enterprise.enums.EsapEnum.OrderOrigin;
import com.vz.fxo.inventory.enterprise.enums.EsapEnum.OrderType;
import com.vz.fxo.inventory.enterprise.enums.EsapEnum.ResponseType;
import com.vz.fxo.inventory.enterprise.enums.EsapEnum.StatusCode;
import com.vz.fxo.inventory.enterprise.support.Enterprise;
import com.vz.fxo.inventory.enterprise.support.VzbInvException;
import com.vz.fxo.inventory.model.pc.Entity;
import com.vz.fxo.inventory.model.pc.OrderHeader;
import com.vz.fxo.inventory.model.pc.OrderStatus;
import com.vz.fxo.inventory.model.pc.VoipOrderResponse;


/**
 * @author Abhiram Varma
 * 
 *  Used for generating the required Response after populating required values 
 *
 */
@Component
public class VOIPResponseGeneratorImpl implements VOIPResponseGenerator {
		
	@Override
	public VoipOrderResponse preparePCMilestone(Enterprise enterprise,Long orderNumber,String workOrderNuStringmber, String workOrderNumberVersion, MileStone milestone,
			StatusCode statusCode) throws VzbInvException {
		VoipOrderResponse voipOrderResponse = new VoipOrderResponse();
		OrderStatus orderStatus = null;
		OrderHeader orderHeader = null;

		try {
			orderHeader = new OrderHeader();
			orderHeader.setWorkOrderNumber(orderNumber!=null ?String.valueOf(orderNumber):null);
			orderHeader.setUnoServiceId(orderNumber!=null ?String.valueOf(orderNumber):null);
			orderHeader.setFunctionCode(FunctionCode.RELEASE.toString());
			orderHeader.setWorkOrderVersion(workOrderNumberVersion);
			orderHeader.setTransactionID(workOrderNuStringmber);
			orderHeader.setOrderType(OrderType.getValueReverse("IN"));
			orderHeader.setOriginatingSystem(OrderOrigin.ESAP.toString());
			orderHeader.setResponseType(ResponseType.ORDER.toString());

			voipOrderResponse.setOrderHeader(orderHeader);

			orderStatus = new OrderStatus();
			orderStatus.setStatusCode(statusCode.toString());
			orderStatus.setStatusDescription(statusCode.toString());
			orderStatus.setMilestone(milestone.toString());
			List<Entity>  entities=new ArrayList<>();
			addEntityToList("VoipServiceEntityType","ENTERPRISE_SIP",entities);
			addEntityToList("MaxConcurrentCalls","2",entities);
			addEntityToList("LocationEntityType","",entities);
			addEntityToList("EnterpriseName",enterprise.getCustomerName(),entities);
			addEntityToList("VPNName",enterprise.getVpnName(),entities);
			addEntityToList("SipDomain",enterprise.getSipDomain(),entities);
			addEntityToList("EnterpriseID",enterprise.getEnterpriseId(),entities);
			addEntityToList("CPEDeviceId","",entities);
			orderStatus.setEntities(entities);
			orderStatus.setSystem("ESAP");

			voipOrderResponse.setOrderStatus(orderStatus);
		} catch (Exception e) {
			throw new VzbInvException("ESP_VZB_INV_PC_NOTIFICATION_FAILED",
					"Unexpected Error while Preparing PCMilestone");
		} finally {
			voipOrderResponse.setOrderHeader(orderHeader);
			voipOrderResponse.setOrderStatus(orderStatus);
		}
		return voipOrderResponse;

	}
	
	public List<Entity> addEntityToList(String key,String value,List<Entity> entityList){
		Entity entity=new Entity();
		entity.setType(key);
		entity.setValue(value);
		entityList.add(entity);
		return entityList;
	}

}