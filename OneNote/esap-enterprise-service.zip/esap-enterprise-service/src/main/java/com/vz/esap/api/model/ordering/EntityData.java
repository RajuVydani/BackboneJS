package com.vz.esap.api.model.ordering;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

/**
 * This DTO represents a single row in TBL_ORDER and all the associated
 * Param Info details from TBL_ORDER_DETAILS. 
 * @entityType  represents the type of entity like TN, LOCATION, DEVICE etc as defined in VzbVoipEnum.OrderEntity
 * @entityKey represents the key name from the Param Info map. Ex "LocationId" for entityType "Location" 
 * @entityValue represents the id value for the associated entityKey. Like "26089" for LocationId
 * @paramMap contains all the Param Info associated with Entity from TBL_ORDER_DETAILS.
 * @paramMap HashKey is PARAM_NAME from TBL_ORDER_DETAILS and Value is ParamDetail representing each row of detail table.
 *
 */
public class EntityData {
	private String entityType;
	private String entityKey;
	private String entityValue;
	private Map<String, TableOrderDetailsParam> paramMap;
	private List<TableOrderDetailsParam> paramList;	
	private Map<String, TableOrderDetailsParam> newParamDetailMap;

	public EntityData(EntityDataBuilder entityDataBuilder) {
		this.entityType = entityDataBuilder.entityType;
		this.entityKey = entityDataBuilder.entityKey;
		this.entityValue = entityDataBuilder.entityValue;
		this.paramMap = entityDataBuilder.paramMap;
		this.paramList = entityDataBuilder.paramList;
		this.newParamDetailMap = entityDataBuilder.newParamDetailMap;
	}

	public String getEntityType() {
		return entityType;
	}

	public void setEntityType(String entityType) {
		this.entityType = entityType;
	}

	public String getEntityKey() {
		return entityKey;
	}

	public void setEntityKey(String entityKey) {
		this.entityKey = entityKey;
	}

	public String getEntityValue() {
		return entityValue;
	}

	public void setEntityValue(String entityValue) {
		this.entityValue = entityValue;
	}

	public Map<String, TableOrderDetailsParam> getParamMap() {
		return paramMap;
	}

	public void setParamMap(Map<String, TableOrderDetailsParam> paramMap) {
		this.paramMap = paramMap;
	}
	
	public List<TableOrderDetailsParam> getParamList() {
		return paramList;
	}

	public void setParamList(List<TableOrderDetailsParam> paramList) {
		this.paramList = paramList;
	}

	public Map<String, TableOrderDetailsParam> getNewParamDetailMap() {
		return newParamDetailMap;
	}

	public void setNewParamDetailMap(Map<String, TableOrderDetailsParam> newParamDetailMap) {
		this.newParamDetailMap = newParamDetailMap;
	}

	@Override
	public String toString() {
		Gson gson = new GsonBuilder().setPrettyPrinting().create();
		String json = gson.toJson(this);
		return json;
		
		/*StringBuilder builder = new StringBuilder();
		builder.append("\n EntityData \n \t \t [entityType=");
		builder.append(entityType);
		builder.append(", entityKey=");
		builder.append(entityKey);
		builder.append(", entityValue=");
		builder.append(entityValue);
		builder.append(", paramMap=");
		builder.append(paramMap);
		builder.append("]");
		return builder.toString();*/
	}

	public static class EntityDataBuilder {
		private String entityType;
		private String entityKey;
		private String entityValue;
		private Map<String, TableOrderDetailsParam> paramMap = new HashMap<>();
		private Map<String, TableOrderDetailsParam> newParamDetailMap = new HashMap<>();
		
		private List<TableOrderDetailsParam> paramList = new ArrayList<>();

		
		public EntityDataBuilder withEntityType(String entityType) {
			this.entityType = entityType;
			return this;
		}
		public EntityDataBuilder withEntityKey(String entityKey) {
			this.entityKey = entityKey;
			return this;
		}
		public EntityDataBuilder withEntityValue(String entityValue) {
			this.entityValue = entityValue;
			return this;
		}
		public EntityDataBuilder putParamDetail(TableOrderDetailsParam paramDetail) {
			this.paramMap.put(paramDetail.getParamName(),paramDetail);
			return this;
		}
		public EntityDataBuilder putParamDetailOnOrderId(TableOrderDetailsParam paramDetail) {
			this.newParamDetailMap.put(paramDetail.getOrderDetailId(),paramDetail);
			return this;
		}
		public EntityDataBuilder addParamDetail(TableOrderDetailsParam paramDetail) {
			this.paramList.add(paramDetail);
			return this;
		}
		public EntityData build() {
			return new EntityData(this);
		}
		
	}


	
}

