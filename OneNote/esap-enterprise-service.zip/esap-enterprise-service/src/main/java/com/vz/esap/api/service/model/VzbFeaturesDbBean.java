package com.vz.esap.api.service.model;

import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Vector;

import com.vz.esap.api.model.DBServiceResponse;
import com.vz.esap.api.model.TblRow;



public class VzbFeaturesDbBean {

	private boolean bsequenceQueried;
	private int featureId;
	private boolean bfeatureIdSet;
	private String name;
	private boolean bnameSet;
	private String description;
	private boolean bdescriptionSet;
	private boolean bdescriptionNull;
	private long platformIndicator;
	private boolean bplatformIndicatorSet;
	private long iasaId;
	private boolean biasaIdSet;
	private boolean biasaIdNull;
	private long icpId;
	private boolean bicpIdSet;
	private boolean bicpIdNull;
	private long isBillable;
	private boolean bisBillableSet;
	private long isBroadsoftHidden;
	private boolean bisBroadsoftHiddenSet;
	private boolean bisBroadsoftHiddenNull;
	private String featureType;
	private boolean bfeatureTypeSet;
	private boolean bfeatureTypeNull;
	private String featureLevel;
	private boolean bfeatureLevelSet;
	private boolean bfeatureLevelNull;
	private String modifiedBy;
	private boolean bmodifiedBySet;
	private Timestamp lastModifiedDate;
	private boolean blastModifiedDateSet;
	private long billLevel;
	private boolean bbillLevelSet;
	private boolean bbillLevelNull;
	private long isDisplayable;
	private boolean bisDisplayableSet;
	private short cssopDisable;
	private boolean bcssopDisableSet;
	private boolean bcssopDisableNull;
	private short e2eiAllowMod;
	private boolean be2eiAllowModSet;
	private boolean be2eiAllowModNull;
	private Vector clauseValues;
	private String propfile;
	private String clause;
	public boolean isBsequenceQueried() {
		return bsequenceQueried;
	}
	public void setBsequenceQueried(boolean bsequenceQueried) {
		this.bsequenceQueried = bsequenceQueried;
	}
	public int getFeatureId() {
		return featureId;
	}
	public void setFeatureId(int featureId) {
		this.featureId = featureId;
	}
	public boolean isBfeatureIdSet() {
		return bfeatureIdSet;
	}
	public void setBfeatureIdSet(boolean bfeatureIdSet) {
		this.bfeatureIdSet = bfeatureIdSet;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public boolean isBnameSet() {
		return bnameSet;
	}
	public void setBnameSet(boolean bnameSet) {
		this.bnameSet = bnameSet;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public boolean isBdescriptionSet() {
		return bdescriptionSet;
	}
	public void setBdescriptionSet(boolean bdescriptionSet) {
		this.bdescriptionSet = bdescriptionSet;
	}
	public boolean isBdescriptionNull() {
		return bdescriptionNull;
	}
	public void setBdescriptionNull(boolean bdescriptionNull) {
		this.bdescriptionNull = bdescriptionNull;
	}
	public long getPlatformIndicator() {
		return platformIndicator;
	}
	public void setPlatformIndicator(long platformIndicator) {
		this.platformIndicator = platformIndicator;
	}
	public boolean isBplatformIndicatorSet() {
		return bplatformIndicatorSet;
	}
	public void setBplatformIndicatorSet(boolean bplatformIndicatorSet) {
		this.bplatformIndicatorSet = bplatformIndicatorSet;
	}
	public long getIasaId() {
		return iasaId;
	}
	public void setIasaId(long iasaId) {
		this.iasaId = iasaId;
	}
	public boolean isBiasaIdSet() {
		return biasaIdSet;
	}
	public void setBiasaIdSet(boolean biasaIdSet) {
		this.biasaIdSet = biasaIdSet;
	}
	public boolean isBiasaIdNull() {
		return biasaIdNull;
	}
	public void setBiasaIdNull(boolean biasaIdNull) {
		this.biasaIdNull = biasaIdNull;
	}
	public long getIcpId() {
		return icpId;
	}
	public void setIcpId(long icpId) {
		this.icpId = icpId;
	}
	public boolean isBicpIdSet() {
		return bicpIdSet;
	}
	public void setBicpIdSet(boolean bicpIdSet) {
		this.bicpIdSet = bicpIdSet;
	}
	public boolean isBicpIdNull() {
		return bicpIdNull;
	}
	public void setBicpIdNull(boolean bicpIdNull) {
		this.bicpIdNull = bicpIdNull;
	}
	public long getIsBillable() {
		return isBillable;
	}
	public void setIsBillable(long isBillable) {
		this.isBillable = isBillable;
	}
	public boolean isBisBillableSet() {
		return bisBillableSet;
	}
	public void setBisBillableSet(boolean bisBillableSet) {
		this.bisBillableSet = bisBillableSet;
	}
	public long getIsBroadsoftHidden() {
		return isBroadsoftHidden;
	}
	public void setIsBroadsoftHidden(long isBroadsoftHidden) {
		this.isBroadsoftHidden = isBroadsoftHidden;
	}
	public boolean isBisBroadsoftHiddenSet() {
		return bisBroadsoftHiddenSet;
	}
	public void setBisBroadsoftHiddenSet(boolean bisBroadsoftHiddenSet) {
		this.bisBroadsoftHiddenSet = bisBroadsoftHiddenSet;
	}
	public boolean isBisBroadsoftHiddenNull() {
		return bisBroadsoftHiddenNull;
	}
	public void setBisBroadsoftHiddenNull(boolean bisBroadsoftHiddenNull) {
		this.bisBroadsoftHiddenNull = bisBroadsoftHiddenNull;
	}
	public String getFeatureType() {
		return featureType;
	}
	public void setFeatureType(String featureType) {
		this.featureType = featureType;
	}
	public boolean isBfeatureTypeSet() {
		return bfeatureTypeSet;
	}
	public void setBfeatureTypeSet(boolean bfeatureTypeSet) {
		this.bfeatureTypeSet = bfeatureTypeSet;
	}
	public boolean isBfeatureTypeNull() {
		return bfeatureTypeNull;
	}
	public void setBfeatureTypeNull(boolean bfeatureTypeNull) {
		this.bfeatureTypeNull = bfeatureTypeNull;
	}
	public String getFeatureLevel() {
		return featureLevel;
	}
	public void setFeatureLevel(String featureLevel) {
		this.featureLevel = featureLevel;
	}
	public boolean isBfeatureLevelSet() {
		return bfeatureLevelSet;
	}
	public void setBfeatureLevelSet(boolean bfeatureLevelSet) {
		this.bfeatureLevelSet = bfeatureLevelSet;
	}
	public boolean isBfeatureLevelNull() {
		return bfeatureLevelNull;
	}
	public void setBfeatureLevelNull(boolean bfeatureLevelNull) {
		this.bfeatureLevelNull = bfeatureLevelNull;
	}
	public String getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public boolean isBmodifiedBySet() {
		return bmodifiedBySet;
	}
	public void setBmodifiedBySet(boolean bmodifiedBySet) {
		this.bmodifiedBySet = bmodifiedBySet;
	}
	public Timestamp getLastModifiedDate() {
		return lastModifiedDate;
	}
	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}
	public boolean isBlastModifiedDateSet() {
		return blastModifiedDateSet;
	}
	public void setBlastModifiedDateSet(boolean blastModifiedDateSet) {
		this.blastModifiedDateSet = blastModifiedDateSet;
	}
	public long getBillLevel() {
		return billLevel;
	}
	public void setBillLevel(long billLevel) {
		this.billLevel = billLevel;
	}
	public boolean isBbillLevelSet() {
		return bbillLevelSet;
	}
	public void setBbillLevelSet(boolean bbillLevelSet) {
		this.bbillLevelSet = bbillLevelSet;
	}
	public boolean isBbillLevelNull() {
		return bbillLevelNull;
	}
	public void setBbillLevelNull(boolean bbillLevelNull) {
		this.bbillLevelNull = bbillLevelNull;
	}
	public long getIsDisplayable() {
		return isDisplayable;
	}
	public void setIsDisplayable(long isDisplayable) {
		this.isDisplayable = isDisplayable;
	}
	public boolean isBisDisplayableSet() {
		return bisDisplayableSet;
	}
	public void setBisDisplayableSet(boolean bisDisplayableSet) {
		this.bisDisplayableSet = bisDisplayableSet;
	}
	public short getCssopDisable() {
		return cssopDisable;
	}
	public void setCssopDisable(short cssopDisable) {
		this.cssopDisable = cssopDisable;
	}
	public boolean isBcssopDisableSet() {
		return bcssopDisableSet;
	}
	public void setBcssopDisableSet(boolean bcssopDisableSet) {
		this.bcssopDisableSet = bcssopDisableSet;
	}
	public boolean isBcssopDisableNull() {
		return bcssopDisableNull;
	}
	public void setBcssopDisableNull(boolean bcssopDisableNull) {
		this.bcssopDisableNull = bcssopDisableNull;
	}
	public short getE2eiAllowMod() {
		return e2eiAllowMod;
	}
	public void setE2eiAllowMod(short e2eiAllowMod) {
		this.e2eiAllowMod = e2eiAllowMod;
	}
	public boolean isBe2eiAllowModSet() {
		return be2eiAllowModSet;
	}
	public void setBe2eiAllowModSet(boolean be2eiAllowModSet) {
		this.be2eiAllowModSet = be2eiAllowModSet;
	}
	public boolean isBe2eiAllowModNull() {
		return be2eiAllowModNull;
	}
	public void setBe2eiAllowModNull(boolean be2eiAllowModNull) {
		this.be2eiAllowModNull = be2eiAllowModNull;
	}
	public Vector getClauseValues() {
		return clauseValues;
	}
	public void setClauseValues(Vector clauseValues) {
		this.clauseValues = clauseValues;
	}
	public String getPropfile() {
		return propfile;
	}
	public void setPropfile(String propfile) {
		this.propfile = propfile;
	}
	public String getClause() {
		return clause;
	}
	public void setClause(String clause) {
		this.clause = clause;
	}
	
	final String COLUMN_FEAT1 = "FEATURE_ID";
    final String COLUMN_FEAT2 = "NAME";
    final String COLUMN_FEAT3 = "DESCRIPTION";
    final String COLUMN_FEAT4 = "PLATFORM_INDICATOR";
    final String COLUMN_FEAT5 = "IASA_ID";
    final String COLUMN_FEAT6 = "ICP_ID";
    final String COLUMN_FEAT7 = "IS_BILLABLE";
    final String COLUMN_FEAT8 = "IS_BROADSOFT_HIDDEN";
    final String COLUMN_FEAT9 = "FEATURE_TYPE";
    final String COLUMN_FEAT10 = "FEATURE_LEVEL";
    final String COLUMN_FEAT11 = "MODIFIED_BY";
    final String COLUMN_FEAT12 = "LAST_MODIFIED_DATE";
    final String COLUMN_FEAT13 = "BILL_LEVEL";
    final String COLUMN_FEAT14 = "IS_DISPLAYABLE";
    final String COLUMN_FEAT15 = "CSSOP_DISABLE";
    final String COLUMN_FEAT16 = "E2EI_ALLOW_MOD";
	
	public void copyFromBean(TblRow tblvzbFeatRows) throws ParseException {
		setFeatureId(Integer.parseInt(tblvzbFeatRows.getTblRow().get("FEATURE_ID").getValue()));
		setName(tblvzbFeatRows.getTblRow().get("NAME").getValue());
		setDescription(tblvzbFeatRows.getTblRow().get("DESCRIPTION").getValue());
		setPlatformIndicator(Long.parseLong(tblvzbFeatRows.getTblRow().get("PLATFORM_INDICATOR").getValue()));
		setIasaId(Long.parseLong(tblvzbFeatRows.getTblRow().get("IASA_ID").getValue()));
		setIcpId(Long.parseLong(tblvzbFeatRows.getTblRow().get("ICP_ID").getValue()));
		setIsBillable(Long.parseLong(tblvzbFeatRows.getTblRow().get("IS_BILLABLE").getValue()));
		setIsBroadsoftHidden(Long.parseLong(tblvzbFeatRows.getTblRow().get("IS_BROADSOFT_HIDDEN").getValue()));
		setFeatureType(tblvzbFeatRows.getTblRow().get("FEATURE_TYPE").getValue());
		setFeatureLevel(tblvzbFeatRows.getTblRow().get("FEATURE_LEVEL").getValue());
		setModifiedBy(tblvzbFeatRows.getTblRow().get("MODIFIED_BY").getValue());		
		setBillLevel(Long.parseLong(tblvzbFeatRows.getTblRow().get("BILL_LEVEL").getValue()));
		setIsDisplayable(Long.parseLong(tblvzbFeatRows.getTblRow().get("IS_DISPLAYABLE").getValue()));
		setCssopDisable(Short.parseShort(tblvzbFeatRows.getTblRow().get("CSSOP_DISABLE").getValue()));
		setE2eiAllowMod(Short.parseShort(tblvzbFeatRows.getTblRow().get("E2EI_ALLOW_MOD").getValue()));
		
		
		
		
		setLastModifiedDate(getTimeStampDate(tblvzbFeatRows.getTblRow().get("LAST_MODIFIED_DATE").getValue()));
	}
	
	private Timestamp getTimeStampDate(String value) throws ParseException {
		DateFormat formatter;
		formatter = new SimpleDateFormat("dd/MM/yyyy");
		Date date = (Date) formatter.parse(value);
		Timestamp timeStampDate = new Timestamp(date.getTime());
		return timeStampDate;
	}
}
