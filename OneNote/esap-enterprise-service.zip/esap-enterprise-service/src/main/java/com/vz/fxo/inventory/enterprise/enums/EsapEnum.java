package com.vz.fxo.inventory.enterprise.enums;

import java.util.HashMap;

public abstract class EsapEnum {

	public static enum StatusCode {
		ESP_FAILURE("ESP_FAILURE"), ESP_SUCCESS("ESP_SUCCESS"), UNKNOWN("UNKNOWN"), ESP_MILESTONE_SUCCESS("ESP_MILESTONE_SUCCESS"), ESP_MILESTONE_FAILURE("ESP_MILESTONE_FAILURE");

		private String statusCode;

		StatusCode(String statusCode) {
			this.statusCode = statusCode;
		}

		public String getValue() {
			return statusCode;
		}

		public String toString() {
			return statusCode;
		}

		public static StatusCode getStatusCode(String statusCode) {
			for (StatusCode value : StatusCode.values()) {
				if (value.toString().equals(statusCode))
					return value;
			}

			return null;
		}
	}

	public static enum MileStone {
		ESAP_MISSING_REQUIRED_DATA("ESAP_MISSING_REQUIRED_DATA"), ESAP_DATA_ALREADY_EXISTS(
				"ESAP_DATA_ALREADY_EXISTS"), UNKNOWN("UNKNOWN"), WO_COMPLETE("COMPLETE")
		, VALIDATE_ORDER_WITH_ESAP("Validate-Order-With-ESAP"), RELEASE_ORDER_WITH_ESAP("Send-Order-Release-To-ESAP")
		, IP_VLAN_INFO_WITH_LOGICAL("Send-IP-VLAN-Info-To-ESAP"), NBS_START_TRIGGER_FROM_ESAP("Receive-NBS-Start-Trigger-From-ESAP"),
		NBS_START("NBS_START"), ENTERPRISE_INFO("ENTERPRISE_INFO"); 
		// Add more Status from WorkOrderEnum.data

		private String mileStone;

		MileStone(String mileStone) {
			this.mileStone = mileStone;
		}

		public String getValue() {
			return mileStone;
		}

		public String toString() {
			return mileStone;
		}

		public static MileStone getMileStone(String mileStone) {
			for (MileStone value : MileStone.values()) {
				if (value.toString().equals(mileStone))
					return value;
			}

			return null;
		}

	}

	public static class OrderType {
		private static HashMap<String, String> orderTypeMap = new HashMap<String, String>();
		private static HashMap<String, String> orderTypeReverseMap = new HashMap<String, String>();
		static {
		orderTypeMap.put("I", "IN");
		orderTypeMap.put("O", "OUT");
		orderTypeMap.put("C", "CHANGE");
		orderTypeMap.put("S", "SUSPEND");
		orderTypeMap.put("R", "RELEASE");

		orderTypeReverseMap.put("IN", "I");
		orderTypeReverseMap.put("OUT", "O");
		orderTypeReverseMap.put("CHANGE", "C");
		orderTypeReverseMap.put("SUSPEND", "S");
		orderTypeReverseMap.put("RELEASE", "R");
		}

		public static String getValue(char key) {
		return orderTypeMap.get(key + "") != null ? orderTypeMap.get(key + "") : "UNKNOWN";
		}
		public static String getValueReverse(String key) {
		return orderTypeReverseMap.get(key + "") != null ? orderTypeReverseMap.get(key + "") : "UNKNOWN";
		}
		}

	public static class Clli {
		private static HashMap<String, String> clliMap = new HashMap<String, String>();
		static {
			clliMap.put("VZB_INV_VALIDATE_E2EI_ORDER", "RIVDITINV01");
			clliMap.put("VZB_CSSOP_VEC_VALIDATE", "RIVDITCSP01");
			clliMap.put("VZB_IASA_VALIDATE_E2EI_ORDER", "RIVDITIAS01");
		}

		public static String getValue(String key) {
			return clliMap.get(key + "") != null ? clliMap.get(key + "") : "UNKNOWN";
		}
	}

	public static enum OrderAction {
		DELETE("O"), ADD("I"), MODIFY("C"), VALIDATE("V"), NONE("N");

		protected String orderAction = null;

		OrderAction(String orderAction) {
			this.orderAction = orderAction;
		}

		public String toString() {
			return orderAction;
		}

		public static OrderAction reverse(OrderAction orderAction) {
			if (orderAction.equals(ADD))
				return DELETE;
			else if (orderAction.equals(DELETE))
				return ADD;
			else
				return orderAction;
		}

		public static OrderAction getAction(String orderAction) {
			for (OrderAction action : OrderAction.values()) {
				if (action.toString().equals(orderAction))
					return action;
			}

			return null;
		}

		public String getValue() {
			return orderAction;
		}

	}

	public static enum Service {
		BS, CCRS, CS2K, CSSOP, CUCM, ESAP, FMC, IASA, ICP, INV, IPSM, IXPLUS, NS, RS, SBC, TWSBC, FMCGREPORT, SSI, VM, ISR, CPE, DMS, IPRO, SCM, PC, VPLAN, GCM, OPRO, VESDW, PQ;
	};

	public static enum FlowPath {
		// Note: Should maitain correct sequence for these enum values
		// It is used to determine the sequence of orders
		R, D, F;
	};

	public static enum OrderPass {

		RELEASE, VALIDATE;
	};

	public static enum RedundancyType {

		NONE, PRIORITY, LOADSHARING;
	};

	public static enum RedundancyPriorityType {

		PRIMARY, SECONDARY;
	};

	public static enum SignalingDirection {

		TWO_WAY, INBOUND;
	};

	public static enum TrunkGroupType {

		PBX, KEY, TWO_WAY, INBOUND;
	};

	public static enum OrderEntity {
		//TODO725- understand
		GUI, ENTERPRISE, DEPARTMENT, LOCATION, DEVICE, PBX, KEY, PBX_TN, KEY_TN, SUBSCRIBER, RES_TN, CALLING_PLAN, FEATURE_PKG, VALIDATION, DIAL_PLAN, DEVICE_TYPE, BSAS, PUBLIC_ROUTING, TERM_ROUTING, BA_PORTAL_TN, FMC_DIALPLAN, FMC_DEVICE, SBC, SYSTEM_UPDATE, TN, IPAC_CUSTOMER, IPAC_HA_PAIR, IPAC_CONF_TN, BSAS_MAP, IPAC_DEVICE, SBC_REGION_MAP, MICRONODE, TWSBC, FMCGREPORT, PREFIX_PLAN_RULE, PREFIX_PLAN, EMERGENCY_CODE, CORP_SETTING, CS2K, SBC_CONFIG, PIT, SBC_LOAD_SHARING, FRAUD_BLOCK, ENTERPRISE_TRUNK, VPN_SBC_INFO, TSO_SBC, EBI, ET_TN, ROUTING_GROUP, ET_EBI, TSOMGRNRPRT, R2R_TRANSITION, IPTERM, VILO_TN, IPCC_SBC, IPSEC, VRDMGRNRPRT, ET_GROUP, PC_CKT_QUERY, BMT, BMT_USER, BMT_EBI, BMT_TRUNK_GROUP, BMT_ENTERPRISE_TRUNK, TWO_WAY, INBOUND, SONUS_NBS, TWO_WAY_TN, INBOUND_TN, LINE, PRI_DID, LINE_TN, DID_TN, NON_PRI_DID;
		public int getIndex() { return ordinal() + 1; }
	};


	public static enum SolutionType {

		ESIP_ESL, ESIP_EBL, IPFLEX;
	};
	
	public static enum NbsType {
		TWO_WAY, INBOUND, BOTH;
	}
	
	public static enum RoutingEnd {
		ESL_I_VAL, ESL_I_REL;
	}
	
	public static enum RegionType {

		US, EMEA, APAC;
		private String countryRegion;

		private RegionType() {

		}

		private RegionType(String countryRegion) {
			this.countryRegion = countryRegion;
		}

		public String getCountryCode() {
			String countryCode = null;
			if (countryRegion.equalsIgnoreCase("US"))
				countryCode = String.valueOf((ordinal() + 1));
			if (countryRegion.equalsIgnoreCase("EMEA"))
				countryCode = String.valueOf((ordinal() + 2));
			if (countryRegion.equalsIgnoreCase("APAC"))
				countryCode = String.valueOf((ordinal() + 8));
			return countryCode;
		}
	};
	
	public static enum SonusType {
		PSX, GSX;
	}
	
	public static enum PortType {

		INTERNAL, EXTERNAL;
	};
	
	public static enum FunctionCode {

		RELEASE, VALIDATE, NBS_PROV_CONFIG;
	};
	
	public static enum ResponseType {

		ORDER;
	};
	public static enum OrderOrigin {

		OPro, GUI, CSSOP, IASA, UPI, IORDER, ICP, UNO, AM, VPLAN, ESAP;
		}
}
