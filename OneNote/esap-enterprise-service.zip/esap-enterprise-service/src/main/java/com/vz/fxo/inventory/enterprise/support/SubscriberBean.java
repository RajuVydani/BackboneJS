package com.vz.fxo.inventory.enterprise.support;

import java.util.ArrayList;
import java.util.List;

public class SubscriberBean
{
    //members*/
    protected List<SipDeviceBean> sipDeviceBeanList;
    protected List<SubscriberDeviceBean> subDevBeanList;
    protected SubscriberBean[] subBeanList;
    protected List<SubFeaturesBean> subFeatBeanList;
    protected PublicTnPoolBean pubTnBeanObj;
    protected SubscriberTnBean subTnObj;
    protected List<String> logTrail;
    protected List<SubscriberTnBean> subTnList;
    protected int subscriberTnId;
    protected long natUserId;
    protected long npaSplitStatus;
    protected String userId;
    protected String subId;
    //IR #1353501  - For CSSOP TN_ON_OFF Needs to check
    protected long tnOnOff;
    protected String[] subIds;
    protected String bsSubId;

    protected String locationId;
    protected String departmentId;
    protected long ppId;
    protected String regRingTime;
    protected String lastName;
    protected String firstName;
    protected String middleInitial;
    protected String companyName;
    protected String email;
    protected String homePhone;
    protected String workPhone;
    protected String mobilePhone;
    protected String timeZone;
    protected long webLang;
    protected long accessLevel;
    protected String webLoginId;
    protected String webPassword;
    protected String sipUsername;
    protected String sipPassword;
    protected String sipAddress;
    protected long mobileUser;
    protected long pkgFeatureId;
    protected String pkgFeatureStr;
    protected String callerIdFirstName;
    protected String callerIdLastName;
    protected long vmLang;
    protected long receptionistType;
    protected long vmMaxSize;
    protected long vmMaxSizeId;
    protected String vmBoxNum;
    protected String vmRouteNum;
    protected String vmPasscode;
    protected String vmPin;
    protected long vmStatus;
    protected long vmActiveDate;
    protected long vmTermDate;
    protected long vmChangeDate;
    protected long sipActiveDate;
    protected long sipTermDate;
    protected String deviceType;
    protected long subAddrId; //is this required?
    protected long mwiDeviceId;
    protected String rpId;
    protected long rpidPriv;
    protected long rpIdPoolId;
    protected String linePort;
    protected String extension;
    protected long pubIp;
    protected long registrationType;
    protected long registrationStatus;
    protected String registrationKey;
    protected String adminSecretQuestion;
    protected String adminSecretAnswer;
    protected String secretQuestion;
    protected String secretAnswer;
    protected long searchOption;
    protected long allowUserSearch;
    protected String modifiedBy;
    protected String createdBy;
    protected String authUserName;
    protected String authPassword;
    protected String sipRegistrarDomain;
    protected long sipRegistrationInterval;
    protected long brixInd;
	protected long userType;
    protected long callingPlanId; //Added
    protected long activeInd;
    protected java.sql.Timestamp creationDate;
    protected java.sql.Timestamp lastModifiedDate;
    protected long envOrderId;
    protected long fmcgSubId;
    protected long subscriberType;
    protected FmcgSubscriberBean fmcgSubscriberObj;
    protected String authSeed;
	protected boolean getAll;
	//Jan 2011 Release changes
	protected String deviceLoginId;
	protected String drowssapDevice;
	protected short actDeact;
	
	// 53266.AM APAC VOIP LNP - changes for july 2011
	protected short emerNoA;
	protected String emergencyOverride;
	protected long CnamUpdateStatus;
    protected java.sql.Timestamp CnamUpdateDate;
    
    protected short billingType;			//added by z658915for BILLING_TYPE


	

    /**
     * Default Constructor -- Initializes all fields to default values.
     */
    public SubscriberBean()
    {
        this.logTrail = new ArrayList<String>();
        this.sipDeviceBeanList = new ArrayList<SipDeviceBean>();
        this.subTnList = new ArrayList<SubscriberTnBean>();
        this.subBeanList = null;
        this.subDevBeanList = new ArrayList<SubscriberDeviceBean>();   
        this.subFeatBeanList = new ArrayList<SubFeaturesBean>();
        this.pubTnBeanObj = new PublicTnPoolBean();
        this.subTnObj = new SubscriberTnBean();
        this.subscriberTnId = 0;
        this.natUserId = 0;
        this.npaSplitStatus = -1;
        this.userId = new String("");
        this.tnOnOff = -1;
        this.actDeact = -1;
        this.subId = new String("");
        this.subIds = null;
        this.bsSubId = new String("");
        this.locationId = new String("");
        this.departmentId = new String("NONE");
        this.ppId = 0;
        this.regRingTime = new String("");
        this.lastName = new String("NONE");
        this.firstName = new String("NONE");
        this.middleInitial = new String("NONE");
        this.companyName = new String("NONE");
        this.email = new String("NONE");
        this.homePhone = new String("NONE");
        this.workPhone = new String("NONE");
        this.mobilePhone = new String("NONE");
        this.timeZone = new String("NONE");
        this.webLang = -1;
        this.accessLevel = 0;
        this.webLoginId = new String("NONE");
        this.webPassword = new String("NONE");
        this.sipUsername = new String("NONE");
        this.sipPassword = new String("NONE");
        this.sipAddress = new String("NONE");
        this.mobileUser = -1;
        this.pkgFeatureId = -1;
        this.pkgFeatureStr = new String("");
        this.callerIdFirstName = new String("NONE");
        this.callerIdLastName = new String("NONE");
        this.vmLang = -1;
        this.receptionistType = -1;
        this.vmMaxSize = -1;
        this.vmMaxSizeId = -1;
        this.vmBoxNum = new String("NONE");
        this.vmRouteNum = new String("NONE");
        this.vmPasscode = new String("NONE");
        this.vmPin = new String("NONE");
        this.vmStatus = -1;
        this.vmActiveDate = -1;
        this.vmTermDate = -1;
        this.vmChangeDate = -1;
        this.sipActiveDate = 0;
        this.sipTermDate = 0;
        this.deviceType = new String("");
        this.subAddrId = -1;
        this.mwiDeviceId = 0;
        this.rpId = new String("NONE");
        this.rpidPriv = 0;
        this.rpIdPoolId = 0;
        this.linePort = new String("");
        this.extension = new String("NONE");
        this.pubIp = 0;
        this.registrationType = 0;
        this.registrationStatus = -1;
        this.registrationKey = new String("NONE");
        this.adminSecretQuestion = new String("NONE");
        this.adminSecretAnswer = new String("NONE");
        this.secretQuestion = new String("NONE");
        this.secretAnswer = new String("NONE");
        this.searchOption = -1;
        this.allowUserSearch = -1;
        this.modifiedBy = new String("");
        this.createdBy = new String("");
        this.authUserName = new String("NONE");
        this.authPassword = new String("NONE");
        this.sipRegistrarDomain = new String("NONE");
        this.sipRegistrationInterval = 0;
        this.brixInd = -1;
        this.userType = -1;
        this.callingPlanId = -1;
        this.activeInd = 1;
        this.creationDate = null;
        this.lastModifiedDate = null;
        this.envOrderId = -1;
        this.fmcgSubId = -1;
        this.subscriberType = 3; //default value
        this.authSeed = new String("NONE");
        this.fmcgSubscriberObj = new FmcgSubscriberBean();
        //Jan 2011 Release changes
        this.deviceLoginId = "NONE";
        this.drowssapDevice = "NONE";
        // 53266.AM APAC VOIP LNP - changes for july 2011
        this.emerNoA = 1;
        this.emergencyOverride = null;
        this.CnamUpdateStatus = -1;
        this.CnamUpdateDate = null;
        
        this.billingType = -1;			//added by z658915
        
    }

    /**
     * Constructor
     *
     * @param subscriberBean
     */
    public SubscriberBean(SubscriberBean subscriberBean)
    {
        this.sipDeviceBeanList = subscriberBean.sipDeviceBeanList;
        this.subDevBeanList = subscriberBean.subDevBeanList;
        this.subBeanList = subscriberBean.subBeanList;
        this.subFeatBeanList = subscriberBean.subFeatBeanList;
        this.pubTnBeanObj = subscriberBean.pubTnBeanObj;
        this.subTnObj = subscriberBean.subTnObj;
        this.logTrail = subscriberBean.logTrail;
        this.subscriberTnId = subscriberBean.subscriberTnId;
        this.natUserId = subscriberBean.natUserId;
        this.npaSplitStatus = subscriberBean.npaSplitStatus;
        this.userId = subscriberBean.userId;
        this.tnOnOff = subscriberBean.tnOnOff;
        this.actDeact = subscriberBean.actDeact;
        this.subId = subscriberBean.subId; 
        this.subIds = subscriberBean.subIds;
        this.bsSubId = subscriberBean.bsSubId;
        this.locationId = subscriberBean.locationId;
        this.departmentId = subscriberBean.departmentId;
        this.ppId = subscriberBean.ppId;
        this.regRingTime = subscriberBean.regRingTime;
        this.lastName = subscriberBean.lastName;
        this.firstName = subscriberBean.firstName;
        this.middleInitial = subscriberBean.middleInitial;
        this.companyName = subscriberBean.companyName;
        this.email = subscriberBean.email;
        this.homePhone = subscriberBean.homePhone;
        this.workPhone = subscriberBean.workPhone;
        this.mobilePhone = subscriberBean.mobilePhone;
        this.timeZone = subscriberBean.timeZone;
        this.webLang = subscriberBean.webLang;
        this.accessLevel = subscriberBean.accessLevel;
        this.webLoginId = subscriberBean.webLoginId;
        this.webPassword = subscriberBean.webPassword;
        this.sipUsername = subscriberBean.sipUsername;
        this.sipPassword = subscriberBean.sipPassword;
        this.sipAddress = subscriberBean.sipAddress;
        this.mobileUser = subscriberBean.mobileUser;
        this.pkgFeatureId = subscriberBean.pkgFeatureId;
        this.pkgFeatureStr = subscriberBean.pkgFeatureStr;
        this.callerIdFirstName = subscriberBean.callerIdFirstName;
        this.callerIdLastName = subscriberBean.callerIdLastName;
        this.vmLang = subscriberBean.vmLang;
        this.receptionistType = subscriberBean.receptionistType;
        this.vmMaxSize = subscriberBean.vmMaxSize;
        this.vmMaxSizeId = subscriberBean.vmMaxSizeId;
        this.vmBoxNum = subscriberBean.vmBoxNum;
        this.vmRouteNum = subscriberBean.vmRouteNum;
        this.vmPasscode = subscriberBean.vmPasscode;
        this.vmPin = subscriberBean.vmPin;
        this.vmStatus = subscriberBean.vmStatus;
        this.vmActiveDate = subscriberBean.vmActiveDate;
        this.vmTermDate = subscriberBean.vmTermDate;
        this.vmChangeDate = subscriberBean.vmChangeDate;
        this.sipActiveDate = subscriberBean.sipActiveDate;
        this.sipTermDate = subscriberBean.sipTermDate;
        this.deviceType = subscriberBean.deviceType;
        this.subAddrId = subscriberBean.subAddrId;
        this.mwiDeviceId = subscriberBean.mwiDeviceId;
        this.rpId = subscriberBean.rpId;
        this.rpidPriv = subscriberBean.rpidPriv;
        this.rpIdPoolId = subscriberBean.rpIdPoolId;
        this.linePort = subscriberBean.linePort;
        this.extension = subscriberBean.extension;
        this.pubIp = subscriberBean.pubIp;
        this.registrationType = subscriberBean.registrationType;
        this.registrationStatus = subscriberBean.registrationStatus;
        this.registrationKey = subscriberBean.registrationKey;
        this.adminSecretQuestion = subscriberBean.adminSecretQuestion;
        this.adminSecretAnswer = subscriberBean.adminSecretAnswer;
        this.secretQuestion = subscriberBean.secretQuestion;
        this.secretAnswer = subscriberBean.secretAnswer;
        this.searchOption = subscriberBean.searchOption;
        this.allowUserSearch = subscriberBean.allowUserSearch;
        this.modifiedBy = subscriberBean.modifiedBy;
        this.createdBy = subscriberBean.createdBy;
        this.callingPlanId = subscriberBean.callingPlanId;
        this.activeInd = subscriberBean.activeInd;
        this.creationDate = subscriberBean.creationDate;
        this.lastModifiedDate = subscriberBean.lastModifiedDate;
        this.envOrderId = subscriberBean.envOrderId;
        this.fmcgSubId = subscriberBean.fmcgSubId;
        this.subscriberType = subscriberBean.subscriberType;
        this.fmcgSubscriberObj = subscriberBean.fmcgSubscriberObj;
        this.authUserName = subscriberBean.authUserName;
        this.authPassword = subscriberBean.authPassword;
        this.sipRegistrarDomain = subscriberBean.sipRegistrarDomain;
        this.sipRegistrationInterval = subscriberBean.sipRegistrationInterval;
        this.brixInd = subscriberBean.brixInd;
        this.userType = subscriberBean.userType;
        this.fmcgSubscriberObj = subscriberBean.fmcgSubscriberObj;
        this.authSeed = subscriberBean.authSeed;
        this.subTnList =  subscriberBean.subTnList;
        //Jan 2011 Release changes
        this.deviceLoginId = subscriberBean.deviceLoginId;
        this.drowssapDevice = subscriberBean.drowssapDevice;
        // 53266.AM APAC VOIP LNP - changes for july 2011
        this.emerNoA = subscriberBean.emerNoA;
        this.emergencyOverride = subscriberBean.emergencyOverride;
        this.CnamUpdateStatus = subscriberBean.CnamUpdateStatus;
        this.CnamUpdateDate = subscriberBean.CnamUpdateDate;
        
        //calnet changes
        this.billingType = subscriberBean.billingType;			//added by z658915
        
    }

	/**
	 * @return the cnamUpdateStatus
	 */
	public long getCnamUpdateStatus() {
		return CnamUpdateStatus;
	}

	/**
	 * @param cnamUpdateStatus the cnamUpdateStatus to set
	 */
	public void setCnamUpdateStatus(long cnamUpdateStatus) {
		CnamUpdateStatus = cnamUpdateStatus;
	}

	/**
	 * @return the cnamUpdateDate
	 */
	public java.sql.Timestamp getCnamUpdateDate() {
		return CnamUpdateDate;
	}

	/**
	 * @param cnamUpdateDate the cnamUpdateDate to set
	 */
	public void setCnamUpdateDate(java.sql.Timestamp cnamUpdateDate) {
		CnamUpdateDate = cnamUpdateDate;
	}

	public boolean isGetAll() {
			return getAll;
		}
	public void setGetAll(boolean getAll) {
			this.getAll = getAll;
		}

    public void setLogTrail(String logStr)
    {
        logTrail.add(logStr);
    }

    public List<String> getLogTrail()
    {
        return logTrail;
    }

    public java.sql.Timestamp getCreationDate()
    {
        return creationDate;
    }

    public void setCreationDate(java.sql.Timestamp creationDate)
    {
        this.creationDate = creationDate;
    }

    public java.sql.Timestamp getLastModifiedDate()
    {
        return lastModifiedDate;
    }

    public void setLastModifiedDate(java.sql.Timestamp lastModifiedDate)
    {
        this.lastModifiedDate = lastModifiedDate;
    }

    public long getNpaSplitStatus()
    {
        return npaSplitStatus;
    }

    public void setNpaSplitStatus(long npaSplitStatus)
    {
        this.npaSplitStatus = npaSplitStatus;
    }

    public String getMobilePhone()
    {
        return mobilePhone;
    }

    public void setMobilePhone(String mobilePhone)
    {
        this.mobilePhone = mobilePhone;
    }

    public List<SipDeviceBean> getSipDeviceBeanList()
    {
        return sipDeviceBeanList;
    }

    public void setSipDeviceBeanList(List<SipDeviceBean> sipDeviceBeanList)
    {
        this.sipDeviceBeanList = sipDeviceBeanList;
    }

    public List<SubscriberDeviceBean> getSubDevBeanList()
    {
        return subDevBeanList;
    }

    public void setSubDevBeanList(List<SubscriberDeviceBean> subDevBeanList)
    {
        this.subDevBeanList = subDevBeanList;
    }
    
    public SubscriberBean[] getSubBeanList()
    {
        return subBeanList;
    }

    public void setBeanList(SubscriberBean[] subBeanList)
    {
        this.subBeanList = subBeanList;
    }
    
    

    public List<SubFeaturesBean> getSubFeatBeanList()
    {
        return subFeatBeanList;
    }

    public void setSubFeatBeanList(List<SubFeaturesBean> subFeatBeanList)
    {
        this.subFeatBeanList = subFeatBeanList;
    }

    public PublicTnPoolBean getPubTnBeanObj()
    {
        return pubTnBeanObj;
    }

    public FmcgSubscriberBean getFmcgSubscriberObj()
    {
        return fmcgSubscriberObj;
    }

    public void setFmcgSubscriberObj(FmcgSubscriberBean fmcgSubscriberObj)
    {
        this.fmcgSubscriberObj = fmcgSubscriberObj;
    }

    public void setPubTnBeanObj(PublicTnPoolBean pubTnBeanObj)
    {
        this.pubTnBeanObj = pubTnBeanObj;
    }

    public int getSubscriberTnId()
    {
        return subscriberTnId;
    }

    public void setSubscriberTnId(int subscriberTnId)
    {
        this.subscriberTnId = subscriberTnId;
    }

    public long getNatUserId()
    {
        return natUserId;
    }

    public void setNatUserId(long natUserId)
    {
        this.natUserId = natUserId;
    }

  //IR #1353501  - For CSSOP TN_ON_OFF Needs to check
    public long getTnOnOff() {
		return tnOnOff;
	}

	public void setTnOnOff(long tnOnOff) {
		this.tnOnOff = tnOnOff;
	}

	public short getActDeact() {
        return actDeact;
    }

    public void setActDeact(short actDeact) {
        this.actDeact = actDeact;
    }

	public String getUserId()
    {
        return userId;
    }

    public void setUserId(String userId)
    {
        this.userId = userId;
    }

    public String getSubId()
    {
        return subId;
    }

    public void setSubId(String subId)
    {
        this.subId = subId;
    }
    
    public String[] getSubIds() {
		return subIds;
	}

	public void setSubIds(String[] subIds) {
		this.subIds = subIds;
	}

    public String getBsSubId()
    {
        return bsSubId;
    }

    public void setBsSubId(String bsSubId)
    {
        this.bsSubId = bsSubId;
    }

    public String getLocationId()
    {
        return locationId;
    }

    public void setLocationId(String locationId)
    {
        this.locationId = locationId;
    }

    public String getDepartmentId()
    {
        return departmentId;
    }

    public void setDepartmentId(String departmentId)
    {
        this.departmentId = departmentId;
    }

    public long getPpId()
    {
        return ppId;
    }

    public void setPpId(long ppId)
    {
        this.ppId = ppId;
    }

    public String getRegRingTime()
    {
        return regRingTime;
    }

    public void setRegRingTime(String regRingTime)
    {
        this.regRingTime = regRingTime;
    }

    public String getLastName()
    {
        return lastName;
    }

    public void setLastName(String lastName)
    {
        this.lastName = lastName;
    }

    public String getFirstName()
    {
        return firstName;
    }

    public void setFirstName(String firstName)
    {
        this.firstName = firstName;
    }

    public String getMiddleInitial()
    {
        return middleInitial;
    }

    public void setMiddleInitial(String middleInitial)
    {
        this.middleInitial = middleInitial;
    }

    public String getCompanyName()
    {
        return companyName;
    }

    public void setCompanyName(String companyName)
    {
        this.companyName = companyName;
    }

    public String getEmail()
    {
        return email;
    }

    public void setEmail(String email)
    {
        this.email = email;
    }

    public String getHomePhone()
    {
        return homePhone;
    }

    public void setHomePhone(String homePhone)
    {
        this.homePhone = homePhone;
    }

    public String getWorkPhone()
    {
        return workPhone;
    }

    public void setWorkPhone(String workPhone)
    {
        this.workPhone = workPhone;
    }

    public String getTimeZone()
    {
        return timeZone;
    }

    public void setTimeZone(String timeZone)
    {
        this.timeZone = timeZone;
    }

    public long getWebLang()
    {
        return webLang;
    }

    public void setWebLang(long webLang)
    {
        this.webLang = webLang;
    }

    public long getAccessLevel()
    {
        return accessLevel;
    }

    public void setAccessLevel(long accessLevel)
    {
        this.accessLevel = accessLevel;
    }

    /*public long getAccessLevel() {
    	return accessLevel;
    }
    public void setAccessLevel(long accessLevel) {
    	this.accessLevel = accessLevel;
    }*/
    public String getWebLoginId()
    {
        return webLoginId;
    }

    public void setWebLoginId(String webLoginId)
    {
        this.webLoginId = webLoginId;
    }

    public String getWebPassword()
    {
        return webPassword;
    }

    public void setWebPassword(String webPassword)
    {
        this.webPassword = webPassword;
    }

    public String getSipUsername()
    {
        return sipUsername;
    }

    public void setSipUsername(String sipUsername)
    {
        this.sipUsername = sipUsername;
    }

    public String getSipPassword()
    {
        return sipPassword;
    }

    public void setSipPassword(String sipPassword)
    {
        this.sipPassword = sipPassword;
    }

    public String getSipAddress()
    {
        return sipAddress;
    }

    public void setSipAddress(String sipAddress)
    {
        this.sipAddress = sipAddress;
    }

    public long getMobileUser()
    {
        return mobileUser;
    }

    public void setMobileUser(long mobileUser)
    {
        this.mobileUser = mobileUser;
    }

    public long getPkgFeatureId()
    {
        return pkgFeatureId;
    }

    public void setPkgFeatureId(long pkgFeatureId)
    {
        this.pkgFeatureId = pkgFeatureId;
    }

    public String getPkgFeatureStr()
    {
        return pkgFeatureStr;
    }

    public void setPkgFeatureStr(String pkgFeatureStr)
    {
        this.pkgFeatureStr = pkgFeatureStr;
    }

    public String getCallerIdFirstName()
    {
        return callerIdFirstName;
    }

    public void setCallerIdFirstName(String callerIdFirstName)
    {
        this.callerIdFirstName = callerIdFirstName;
    }

    public String getCallerIdLastName()
    {
        return callerIdLastName;
    }

    public void setCallerIdLastName(String callerIdLastName)
    {
        this.callerIdLastName = callerIdLastName;
    }

    public long getVmLang()
    {
        return vmLang;
    }

    public void setVmLang(long vmLang)
    {
        this.vmLang = vmLang;
    }

    public long getVmMaxSize()
    {
        return vmMaxSize;
    }

    public void setVmMaxSize(long vmMaxSize)
    {
        this.vmMaxSize = vmMaxSize;
    }

    public long getVmMaxSizeId()
    {
        return vmMaxSizeId;
    }

    public void setVmMaxSizeId(long vmMaxSizeId)
    {
        this.vmMaxSizeId = vmMaxSizeId;
    }

    public String getVmBoxNum()
    {
        return vmBoxNum;
    }

    public void setVmBoxNum(String vmBoxNum)
    {
        this.vmBoxNum = vmBoxNum;
    }

    public String getVmRouteNum()
    {
        return vmRouteNum;
    }

    public void setVmRouteNum(String vmRouteNum)
    {
        this.vmRouteNum = vmRouteNum;
    }

    public String getVmPasscode()
    {
        return vmPasscode;
    }

    public void setVmPasscode(String vmPasscode)
    {
        this.vmPasscode = vmPasscode;
    }

    public String getVmPin()
    {
        return vmPin;
    }

    public void setVmPin(String vmPin)
    {
        this.vmPin = vmPin;
    }

    public long getVmStatus()
    {
        return vmStatus;
    }

    public void setVmStatus(long vmStatus)
    {
        this.vmStatus = vmStatus;
    }

    public long getVmActiveDate()
    {
        return vmActiveDate;
    }

    public void setVmActiveDate(long vmActiveDate)
    {
        this.vmActiveDate = vmActiveDate;
    }

    public long getVmTermDate()
    {
        return vmTermDate;
    }

    public void setVmTermDate(long vmTermDate)
    {
        this.vmTermDate = vmTermDate;
    }

    public long getVmChangeDate()
    {
        return vmChangeDate;
    }

    public void setVmChangeDate(long vmChangeDate)
    {
        this.vmChangeDate = vmChangeDate;
    }

    public long getSipActiveDate()
    {
        return sipActiveDate;
    }

    public void setSipActiveDate(long sipActiveDate)
    {
        this.sipActiveDate = sipActiveDate;
    }

    public long getSipTermDate()
    {
        return sipTermDate;
    }

    public void setSipTermDate(long sipTermDate)
    {
        this.sipTermDate = sipTermDate;
    }

    public String getDeviceType()
    {
        return deviceType;
    }

    public void setDeviceType(String deviceType)
    {
        this.deviceType = deviceType;
    }

    public long getSubAddrId()
    {
        return subAddrId;
    }

    public void setSubAddrId(long subAddrId)
    {
        this.subAddrId = subAddrId;
    }

    public long getMwiDeviceId()
    {
        return mwiDeviceId;
    }

    public void setMwiDeviceId(long mwiDeviceId)
    {
        this.mwiDeviceId = mwiDeviceId;
    }

    public String getRpId()
    {
        return rpId;
    }

    public void setRpId(String rpId)
    {
        this.rpId = rpId;
    }

    public long getRpidPriv()
    {
        return rpidPriv;
    }

    public void setRpidPriv(long rpidPriv)
    {
        this.rpidPriv = rpidPriv;
    }

    public long getRpIdPoolId()
    {
        return rpIdPoolId;
    }

    public void setRpIdPoolId(long rpIdPoolId)
    {
        this.rpIdPoolId = rpIdPoolId;
    }

    public String getLinePort()
    {
        return linePort;
    }

    public void setLinePort(String linePort)
    {
        this.linePort = linePort;
    }

    public String getExtension()
    {
        return extension;
    }

    public void setExtension(String extension)
    {
        this.extension = extension;
    }

    public long getPubIp()
    {
        return pubIp;
    }

    public void setPubIp(long pubIp)
    {
        this.pubIp = pubIp;
    }

    public long getRegistrationType()
    {
        return registrationType;
    }

    public void setRegistrationType(long registrationType)
    {
        this.registrationType = registrationType;
    }

    public long getRegistrationStatus()
    {
        return registrationStatus;
    }

    public void setRegistrationStatus(long registrationStatus)
    {
        this.registrationStatus = registrationStatus;
    }

    public String getRegistrationKey()
    {
        return registrationKey;
    }

    public void setRegistrationKey(String registrationKey)
    {
        this.registrationKey = registrationKey;
    }

    public String getAdminSecretQuestion()
    {
        return adminSecretQuestion;
    }

    public void setAdminSecretQuestion(String adminSecretQuestion)
    {
        this.adminSecretQuestion = adminSecretQuestion;
    }

    public String getAdminSecretAnswer()
    {
        return adminSecretAnswer;
    }

    public void setAdminSecretAnswer(String adminSecretAnswer)
    {
        this.adminSecretAnswer = adminSecretAnswer;
    }

    public String getSecretQuestion()
    {
        return secretQuestion;
    }

    public void setSecretQuestion(String secretQuestion)
    {
        this.secretQuestion = secretQuestion;
    }
	public String getAuthUserName()
    {
        return authUserName;
    }

    public void setAuthUserName(String authUserName)
    {
        this.authUserName = authUserName;
    }
	public String getAuthPassword()
    {
        return authPassword;
    }

    public void setAuthPassword(String authPassword)
    {
        this.authPassword = authPassword;
    }
	public String getSipRegistrarDomain()
    {
        return sipRegistrarDomain;
    }

    public void setSipRegistrarDomain(String sipRegistrarDomain)
    {
        this.sipRegistrarDomain = sipRegistrarDomain;
    }
	 public long getBrixInd()
    {
        return brixInd;
    }

    public void setBrixInd(long brixInd)
    {
        this.brixInd = brixInd;
    }
	 public long getSipRegistrationInterval()
    {
        return sipRegistrationInterval;
    }

    public void setSipRegistrationInterval(long sipRegistrationInterval)
    {
        this.sipRegistrationInterval = sipRegistrationInterval;
    }

	public String getSecretAnswer()
    {
        return secretAnswer;
    }

    public void setSecretAnswer(String secretAnswer)
    {
        this.secretAnswer = secretAnswer;
    }

    public long getSearchOption()
    {
        return searchOption;
    }

    public void setSearchOption(long searchOption)
    {
        this.searchOption = searchOption;
    }

    public long getAllowUserSearch()
    {
        return allowUserSearch;
    }

    public void setAllowUserSearch(long allowUserSearch)
    {
        this.allowUserSearch = allowUserSearch;
    }

    public SubscriberTnBean getSubTnObj()
    {
        return subTnObj;
    }

    public void setSubTnObj(SubscriberTnBean subTnObj)
    {
        this.subTnObj = subTnObj;
    }

    public String getModifiedBy()
    {
        return modifiedBy;
    }

    public void setModifiedBy(String modifiedBy)
    {
        this.modifiedBy = modifiedBy;
    }

    public String getCreatedBy()
    {
        return createdBy;
    }

    public void setCreatedBy(String createdBy)
    {
        this.createdBy = createdBy;
    }

    public long getCallingPlanId()
    {
        return callingPlanId;
    }

    public void setCallingPlanId(long callingPlanId)
    {
        this.callingPlanId = callingPlanId;
    }

    public long getActiveInd()
    {
        return activeInd;
    }

    public void setActiveInd(long activeInd)
    {
        this.activeInd = activeInd;
    }

    public long getEnvOrderId()
    {
        return envOrderId;
    }

    public void setEnvOrderId(long envOrderId)
    {
        this.envOrderId = envOrderId;
    }

    /**
     * @return Returns the fmcgSubId.
     */
    public long getFmcgSubId()
    {
        return fmcgSubId;
    }

    /**
     * @param fmcgSubId
     *            The fmcgSubId to set.
     */
    public void setFmcgSubId(long fmcgSubId)
    {
        this.fmcgSubId = fmcgSubId;
    }
    
    public String getAuthSeed() {
		return authSeed;
	}

	public void setAuthSeed(String authSeed) {
		this.authSeed = authSeed;
	}

	public long getSubscriberType()
    {
        return subscriberType;
    }

    public void setSubscriberType(long subscriberType)
    {
        this.subscriberType = subscriberType;
    }

    public void setLogTrail(List<String> logTrail)
    {
        this.logTrail = logTrail;
    }

    public void setSubTnBeanList(List<SubscriberTnBean> subTnBean)
    {
        this.subTnList = subTnBean;
    }

    public List<SubscriberTnBean> getSubTnBeanList()
    {
        return subTnList;
    }
	public long getUserType() {
		return userType;
	}

	public void setUserType(long userType) {
		this.userType = userType;
	}
	public long getReceptionistType() {
        return receptionistType;
    }

    public void setReceptionistType(long receptionistType) {
        this.receptionistType = receptionistType;
    }

    //Jan 2011 Release changes
    public String getDeviceLoginId() {
		return deviceLoginId;
	}

	public void setDeviceLoginId(String deviceLoginId) {
		this.deviceLoginId = deviceLoginId;
	}

	public String getDevicePassword() {
		return drowssapDevice;
	}

	public void setDevicePassword(String devicePassword) {
		this.drowssapDevice = devicePassword;
	}
	
	// 53266.AM APAC VOIP LNP - changes for july 2011
	public short getEmerNoA() {
		return emerNoA;
	}

	public void setEmerNoA(short emerNoA) {
		this.emerNoA = emerNoA;
	}

	public String getEmergencyOverride() {
		return emergencyOverride;
	}

	public void setEmergencyOverride(String emergencyOverride) {
		this.emergencyOverride = emergencyOverride;
	}
	
	//added by z658915 starts for calnet changes
	public short getBillingType() {
		return billingType;
	}

	public void setBillingType(short billingType) {
		this.billingType = billingType;
	}
	//added by z658915 ends for calnet changes

	public void initilizeTODefault() {
        this.logTrail = new ArrayList<String>();
        this.subTnList = new ArrayList<SubscriberTnBean>();
        this.sipDeviceBeanList = new ArrayList<SipDeviceBean>();
        this.subBeanList = null;
        this.subDevBeanList = new ArrayList<SubscriberDeviceBean>();
        this.subFeatBeanList = new ArrayList<SubFeaturesBean>();
        this.pubTnBeanObj = new PublicTnPoolBean();
        this.subTnObj = new SubscriberTnBean();
        this.subscriberTnId = 0;
        this.natUserId = 0;
        this.npaSplitStatus = 0;
        this.userId = new String("");
        //this.subId = new String("");
        this.subIds = null;
        this.bsSubId = new String("");
        this.locationId = new String("");
        this.departmentId = new String("");
        this.ppId = 0;
        this.regRingTime = new String("");
        this.lastName = new String("");
        this.firstName = new String("");
        this.middleInitial = new String("");
        this.companyName = new String("");
        this.email = new String("");
        this.homePhone = new String("");
        this.workPhone = new String("");
        this.mobilePhone = new String("");
        this.timeZone = new String("");
        this.webLang = 0;
        this.accessLevel = 0;
        this.webLoginId = new String("");
        this.webPassword = new String("");
        this.sipUsername = new String("");
        this.sipPassword = new String("");
        this.sipAddress = new String("");
        this.mobileUser = 0;
        this.pkgFeatureId = 0;
        this.pkgFeatureStr = new String("");
        this.callerIdFirstName = new String("");
        this.callerIdLastName = new String("");
        this.vmLang = 0;
        this.vmMaxSize = 0;
        this.vmMaxSizeId = 0;
        this.vmBoxNum = new String("");
        this.vmRouteNum = new String("");
        this.vmPasscode = new String("");
        this.vmPin = new String("");
        this.vmStatus = 0;
        this.vmActiveDate = 0;
        this.vmTermDate = 0;
        this.vmChangeDate = 0;
        this.sipActiveDate = 0;
        this.sipTermDate = 0;
        this.deviceType = new String("");
        this.subAddrId = 0;
        this.mwiDeviceId = 0;
        this.rpId = new String("");
        this.rpidPriv = 0;
        this.rpIdPoolId = 0;
        this.linePort = new String("");
        this.extension = new String("");
        this.pubIp = 0;
        this.registrationType = 0;
        this.registrationStatus = 0;
        this.registrationKey = new String("");
        this.adminSecretQuestion = new String("");
        this.adminSecretAnswer = new String("");
        this.secretQuestion = new String("");
        this.secretAnswer = new String("");
        this.searchOption = 0;
       // this.allowUserSearch = 0;
        this.modifiedBy = new String("");
        this.createdBy = new String("");
        this.authUserName = new String("");
        this.authPassword = new String("");
        this.sipRegistrarDomain = new String("");
        this.sipRegistrationInterval = 0;
        this.brixInd = 0;
        this.userType = 0;
        this.callingPlanId = -1;
        this.activeInd = 0;
        this.creationDate = null;
        this.lastModifiedDate = null;
        this.envOrderId = 0;
        this.fmcgSubId = 0;
        this.subscriberType = 0;
        this.authSeed = new String("");
      //Jan 2011 Release changes
        this.deviceLoginId = "";
        this.drowssapDevice = "";
        this.fmcgSubscriberObj = new FmcgSubscriberBean();
        this.fmcgSubscriberObj.initilizeTODefault();
        // 53266.AM APAC VOIP LNP - changes for july 2011
        this.emerNoA = 1;
        this.emergencyOverride = null;
        this.CnamUpdateStatus = -1;
        this.CnamUpdateDate = null;
        
        this.billingType = -1;
        
       }

	
}

