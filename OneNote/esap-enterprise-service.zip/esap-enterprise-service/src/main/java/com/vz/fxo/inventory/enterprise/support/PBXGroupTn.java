/****************************************
This Class will have all methods related to PBX group
Author : Pallavi Vankayalapati
 ****************************************/
package com.vz.fxo.inventory.enterprise.support;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Timestamp;

import esap.db.DBTblGatewayDeviceInfo;
import esap.db.DBTblGroupTn;
import esap.db.DBTblGroupTnExcldFeatures;
import esap.db.DBTblGroupTnFeatures;
import esap.db.DBTblSipDeviceInfo;
import esap.db.DBTblVzbFeatures;
import esap.db.TblDeviceMapDbBean;
import esap.db.TblDeviceMapQuery;
import esap.db.TblGroupQuery;
import esap.db.TblGroupTnExcldFeaturesQuery;
import esap.db.TblGroupTnQuery;
import esap.db.TblVzbFeaturesQuery;
import EsapEnumPkg.VzbVoipEnum;
import java.util.HashMap;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class PBXGroupTn extends PBXGroupTnBean {
	
	private static Logger log = LoggerFactory.getLogger(PublicTnPool.class.toString());
	
	String statusCode;
	String statusDesc;
	//Connection connection;
	
	private Connection connection;
	
	boolean rollbackFlag;
	boolean removeTnFlag;
	private boolean isExistingTn;
	InvErrorCode errstatus = InvErrorCode.INTERNAL_ERROR;

	public PBXGroupTn(Connection connection) {
		this.rollbackFlag = false;
		this.removeTnFlag = false;
		this.connection = connection;
		this.isExistingTn = false;
	}

	public PBXGroupTn(PBXGroupTnBean pbxTnBean, Connection connection) {
		super(pbxTnBean);
		this.rollbackFlag = false;
		this.removeTnFlag = false;
		this.isExistingTn = false;
		this.connection = connection;
	}

	public boolean getIsExistingTn() {
		return isExistingTn;
	}

	public void setIsExistingTn(boolean isExistingTn) {
		this.isExistingTn = isExistingTn;
	}

	public boolean getRollbackFlag() {
		return rollbackFlag;
	}

	public void setRollbackFlag(boolean rollbackFlag) {
		this.rollbackFlag = rollbackFlag;
	}

	public boolean getRemoveTnFlag() {
        return removeTnFlag;
    }

    public void setRemoveTnFlag(boolean removeTnFlag) {
        this.removeTnFlag = removeTnFlag;
    }

	public int getStatusCode() {
		return errstatus.getErrorCode();
	}

	public void setErrstatus(InvErrorCode status) {
		this.errstatus = status;
	}

	public String getStatusDesc() {
		return errstatus.getErrorDesc();
	}

	public Connection getconnection() {
		return connection;
	}

	public void setconnection(Connection connection) {
		this.connection = connection;
	}

	public boolean setDeletePending() throws SQLException {
		if (groupTnId <= 0) {
			setErrstatus(InvErrorCode.INVALID_INPUT);
			return false;
		}
		DBTblGroupTn grpTnDB = new DBTblGroupTn();
		grpTnDB.whereGroupTnIdEQ(groupTnId);
		grpTnDB.setActiveInd(VzbVoipEnum.ActiveInd.DELETE_PENDING);
		if (grpTnDB.updateSpByWhere(connection) <= 0) {
			setErrstatus(InvErrorCode.ERROR_DELETING_PBX_GROUP_TN);
			log.info("Error while deleting PBXGroupTn.");
		}
		setErrstatus(InvErrorCode.SUCCESS);
		log.info("Succssfully set Delete Pending PBXGroupTn.");
		return true;
	}

	// methods
	public boolean addToDB() throws Exception,SQLException {
	//	try {
			DBTblGroupTn grpTnDB = new DBTblGroupTn();
			if (getGroupTnId() > 0)
				grpTnDB.setGroupTnId(getGroupTnId());
			else {
				int grpTnId = grpTnDB.getGroupTnIdSeqNextVal(connection);
				setGroupTnId(grpTnId);
			}


			if (!"".equals(getIcpSubId()) && !"NONE".equals(getIcpSubId())) {
				grpTnDB.setIcpSubId(getIcpSubId());
			}
			else
				grpTnDB.setIcpSubId("GRP"+getGroupTnId());

			grpTnDB.setGroupId(getGroupId());
			grpTnDB.setSequenceNo(getSequenceNo());

			if (!"".equals(getExtension()) && !"NONE".equals(getExtension())) {
				grpTnDB.setExtension(getExtension());
			}

			log.info("Extension = <" + getExtension() + ">");
			// grpTnDB.setActiveInd(getActiveInd());
			if (getTnPoolId() > 0)
				grpTnDB.setTnPoolId(getTnPoolId());
			else if (!addToPublicTnPool()) {
				setErrstatus(InvErrorCode.DB_EXCEPTION);
				// setStatusDesc("INV_FAILURE in addToDB PBXGroupTn.Failed to
				// ADD Public Tn Pool");
				log.error("INV_FAILURE in addToDB PBXGroupTn.Failed to ADD Public Tn Pool");
				return false;
			}
			log.info("TnPoolId = " + getTnPoolId());

			if (getTnPoolId() > 0) {
				grpTnDB.setTnPoolId(getTnPoolId());
			}

			if ( !"NONE".equals(getPrivateNumber())) {
				grpTnDB.setPrivateNumber(getPrivateNumber());
			}

			log.info("getLinePort ==> " + getLinePort());
			if ( !"NONE".equals(getLinePort())) {
				grpTnDB.setLinePort(getLinePort());
			}

			if (  !"NONE".equals(getCidFirstName())) {
				grpTnDB.setCidFirstName(getCidFirstName());
			}

			if (  !"NONE".equals(getCidLastName())) {
				grpTnDB.setCidLastName(getCidLastName());
			}
			
			if(!"NONE".equals(getVmxNumber()))
			grpTnDB.setVmBoxNum(getVmxNumber());

			int vmxSize = getVmxSize();
			if (vmxSize < 0)
				grpTnDB.setVmMaxsizeIdNull();
			else
				grpTnDB.setVmMaxsizeId(getVmxSize());
			/*******************************************************************
			 * try{ TblVmBoxSizeQuery vmBoxSize = new TblVmBoxSizeQuery();
			 * vmBoxSize.whereMessagesEQ(vmxSize); vmBoxSize.query(connection);
			 * if(vmBoxSize.size() > 0)
			 * grpTnDB.setVmMaxsizeId(vmBoxSize.getDbBean(0).getVmBoxSizeId()); }
			 * catch(Exception e){ }
			 ******************************************************************/

			grpTnDB.setActiveInd(getActiveInd());
			if (getCreatedBy() != null && !getCreatedBy().equals(""))
				grpTnDB.setCreatedBy(getCreatedBy());
			else
				grpTnDB.setCreatedBy("ESAP_INV");
			if (getModifiedBy() != null && !getModifiedBy().equals(""))
				grpTnDB.setModifiedBy(getModifiedBy());
			else
				grpTnDB.setModifiedBy("ESAP_INV");
			grpTnDB.setLastModifiedDate(new Timestamp(System
					.currentTimeMillis()));
			grpTnDB.setCreationDate(new Timestamp(System.currentTimeMillis()));
			if (getEnvOrderId() > 0)
				grpTnDB.setEnvOrderId(getEnvOrderId());
			else
				grpTnDB.setEnvOrderIdNull();
			if (getSubId().equals("NONE"))
				grpTnDB.setSubIdNull();
			else
				grpTnDB.setSubId(getSubId());

			grpTnDB.insert(connection);
			for (int k = 0; k < excludedFeaturesList.size(); k++) {
				TblVzbFeaturesQuery vzbFeatQry = new TblVzbFeaturesQuery();
				vzbFeatQry.whereNameEQ(((excludedFeaturesList.get(k))
						.getFeaturesDbBean()).getName());
				vzbFeatQry.whereFeatureTypeNE("C");
				vzbFeatQry.query(connection);
				if (vzbFeatQry.size() == 1) {
					DBTblGroupTnExcldFeatures grpExcldFeat = new DBTblGroupTnExcldFeatures();
					grpExcldFeat.getGroupTnFeatureIdSeqNextVal(connection);
					grpExcldFeat.setGroupTnId(grpTnDB.getGroupTnId());
					grpExcldFeat.setFeatureId((vzbFeatQry.getDbBean(0))
							.getFeatureId());
					if (getEnvOrderId() > 0)
						grpExcldFeat.setEnvOrderId(getEnvOrderId());
					else
						grpExcldFeat.setEnvOrderIdNull();
					if (getCreatedBy() != null && !getCreatedBy().equals(""))
						grpExcldFeat.setCreatedBy(getCreatedBy());
					else
						grpExcldFeat.setCreatedBy("ESAP_INV");
					if (getModifiedBy() != null && !getModifiedBy().equals(""))
						grpExcldFeat.setModifiedBy(getModifiedBy());
					else
						grpExcldFeat.setModifiedBy("ESAP_INV");
					if (getEnvOrderId() > 0)
						grpExcldFeat.setEnvOrderId(getEnvOrderId());
					else
						grpExcldFeat.setEnvOrderIdNull();
					grpExcldFeat.setLastModifiedDate(new Timestamp(System
							.currentTimeMillis()));
					grpExcldFeat.setCreationDate(new Timestamp(System
							.currentTimeMillis()));
					grpExcldFeat.insert(connection);
				} else {
					System.out
							.println("Valid Excluded feature not found in the db"
									+ ((excludedFeaturesList.get(k))
											.getFeaturesDbBean()).getName());
					return false;
				}
				
			}
			for(int i = 0; i < getGrpTnFeaturesList().size(); i++)
			   {
		    	  GroupTnFeaturesBean grpTnBean = getGrpTnFeaturesList().get(i);
				 DBTblGroupTnFeatures grpTnFeaturesDbObj = new DBTblGroupTnFeatures();
				 grpTnFeaturesDbObj.setGrpTnFeatureId(grpTnFeaturesDbObj.getGrpTnFeatureIdSeqNextVal(connection));
				 grpTnFeaturesDbObj.setGroupTnId(grpTnDB.getGroupTnId());
				 grpTnFeaturesDbObj.setFeatureId(grpTnBean.getFeatureId());
				 grpTnFeaturesDbObj.setCreatedBy("ESAP_INV");
				 grpTnFeaturesDbObj.setCreationDate(new Timestamp(System
							.currentTimeMillis()));
				 grpTnFeaturesDbObj.setModifiedBy("ESAP_INV");
				 grpTnFeaturesDbObj.setLastModifiedDate(new Timestamp(System
							.currentTimeMillis()));
				 grpTnFeaturesDbObj.setEnvOrderId(grpTnBean.getEnvOrderId());

				 grpTnFeaturesDbObj.insert(connection);
			  }
			//incrementORdecrementPortsAssigned("Y");
		/*} catch (SQLException s) {
			s.printStackTrace();
			setErrstatus(InvErrorCode.DB_EXCEPTION);
			// setStatusDesc("DB_FAILURE in addToDB PBXGroupTn");
			log.info("DB_FAILURE in addToDB PBXGroupTn");
			return false;
		} catch (Exception ee) {
			ee.printStackTrace();
			setErrstatus(InvErrorCode.DB_EXCEPTION);
			// setStatusDesc("DB_FAILURE in addToDB PBXGroupTn");
			log.info("DB_FAILURE in addToDB PBXGroupTn");
		}*/
		setErrstatus(InvErrorCode.SUCCESS);
		// setStatusDesc("Successfully inserted PBXGroupTn into the DB");
		return true;
	}

	
	public void incrementORdecrementPortsAssigned(String incrDecr) throws Exception, SQLException {
		
		if(incrDecr != null && (incrDecr.equalsIgnoreCase("Y") || incrDecr.equalsIgnoreCase("N"))) {
        TblGroupQuery grpQry = new TblGroupQuery();
        grpQry.whereGroupIdEQ(getGroupId());
        grpQry.query(connection);
        if(grpQry.size() >0 ) {  
		   int deviceMapId =  (int) (grpQry.getDbBean(0)).getDeviceMapId();
		
		TblDeviceMapQuery deviceMapqry = new TblDeviceMapQuery();
		deviceMapqry.whereDeviceMapIdEQ(deviceMapId);
		deviceMapqry.query(connection);
		if(deviceMapqry.size() > 0) {
			TblDeviceMapDbBean deviceMapbean = deviceMapqry.getDbBean(0);
			if(deviceMapbean.getSipDeviceId() >0) {
				SipDevice sipDev = new SipDevice(connection);
				sipDev.setSipDeviceId((int)deviceMapbean.getSipDeviceId());
				if(sipDev.getDetails())
				{
	    			DBTblSipDeviceInfo sipDevObj = new DBTblSipDeviceInfo();
					sipDevObj.whereSipDeviceIdEQ(sipDev.getSipDeviceId());	
					int updatedCount = 0;
				if(incrDecr.equalsIgnoreCase("Y"))	{
					//incremetn Value
					if(sipDev.getPortsAssigned() >0){
						sipDevObj.setPortsAssigned(sipDev.getPortsAssigned() +  1);	
					} else {
						sipDevObj.setPortsAssigned(1);
					}
				} else if (incrDecr.equalsIgnoreCase("N")) {
					//decement value
					if(sipDev.getPortsAssigned() >0){
						sipDevObj.setPortsAssigned(sipDev.getPortsAssigned() -  1);	
					} else {
						sipDevObj.setPortsAssignedNull();
					}
				}

					FkValidationUtil.isValidSipDeviceInfoForMod(connection,sipDevObj);
					updatedCount = sipDevObj.updateSpByWhere(connection);
					
					
				}
				
			} else if(deviceMapbean.getGatewayDeviceId()>0){
				GatewayDevice gwDev = new GatewayDevice(connection);
	            gwDev.setGatewayDeviceId(deviceMapbean.getGatewayDeviceId());
	            if(gwDev.getDetails())
	            {
	            		DBTblGatewayDeviceInfo gwDevObj = new DBTblGatewayDeviceInfo();
	                    gwDevObj.whereGatewayDeviceIdEQ(gwDev.getGatewayDeviceId());
	                    int updatedCount = 0;
	                	if(incrDecr.equalsIgnoreCase("Y"))	{  
	                		//increment
    						if(gwDev.getPortsAssigned() >0){
    							gwDevObj.setPortsAssigned(gwDev.getPortsAssigned() +  1);	
    						} else {
    							gwDevObj.setPortsAssigned(1);
    						}  
	                	} else if (incrDecr.equalsIgnoreCase("N")) {
	                		//decrement
							if(gwDev.getPortsAssigned() >0){
								gwDevObj.setPortsAssigned(gwDev.getPortsAssigned() -  1);	
							} else {
								gwDevObj.setPortsAssignedNull();
							}    
	                	}
						  updatedCount = gwDevObj.updateSpByWhere(connection);	
	                

	            }
				
			}
		}
      }	
    }		
 }
	
	
	
	public boolean addToPublicTnPool() throws Exception, SQLException {
		log.info("Entering PBXGroupTn::addToPublicTnPool");
		if (getPublicTnPoolObj().getTnPoolId() > 0) {
			log.info("TnPool Id found. Skip Tn Pool Insert");
			setTnPoolId(getPublicTnPoolObj().getTnPoolId());
			return true;
		}
		if (getPublicTnPoolObj().getTn().equals("")) {
			log.info("No Public Tn Found.");
			return false;
		}
		PublicTnPool pubTnObj = new PublicTnPool(connection, getPublicTnPoolObj());
		
		//APAC LNP sep 2011
		try
		{
			PublicTnPool pubTnObjToGetPorting = (PublicTnPool) getPublicTnPoolObj();
			pubTnObj.setTnPorting(pubTnObjToGetPorting.getTnPorting());
			log.info("PBXGrroupTN::addToPublicTnPool() : tn porting object is set");
		}
		catch(ClassCastException cce)
		{
			log.info("Exception while casting PublicTnPoolBean into PublicTnPool.");
			throw cce;
		}
		
		if (!pubTnObj.addPublicTnPool()) {
			log.info("Failed to Add Tn to Public Tn Pool");
			return false;
		}
		setTnPoolId(pubTnObj.getTnPoolId());
		log.info("TnPoolId = " + pubTnObj.getTnPoolId());
		log.info("Successfully inserted Public TN Pool");
		return true;
	}

	public boolean deleteFromDB() throws SQLException, Exception{
		//try {
		log.info("PBXGroupTN:: deleteFromDB started");
			if (groupTnId <= 0) {
				setErrstatus(InvErrorCode.INVALID_INPUT);
				log.info("## FAILURE in deleteFromDB PBXGroupTn. groupTnId missing.");
				return false;
			}
			deleteExcludedFeaturesForGroupTn();
			// deleting tn features in tbl_group_tn_features for the grouptnid
			deleteGroupTnFeatures();
			TblGroupTnQuery grpTnQuery = new TblGroupTnQuery();
			grpTnQuery.whereGroupTnIdEQ(getGroupTnId());
			grpTnQuery.query(connection);
			int tnPoolId = (int) grpTnQuery.getDbBean(0).getTnPoolId();
			setGroupId((int)grpTnQuery.getDbBean(0).getGroupId());
			String subId = new String("");
			subId = grpTnQuery.getDbBean(0).getSubId();
			//incrementORdecrementPortsAssigned("N");
               
			DBTblGroupTn pbxGroupTnDbBean = new DBTblGroupTn();
			pbxGroupTnDbBean.whereGroupTnIdEQ(getGroupTnId());
			if (pbxGroupTnDbBean.deleteByWhere(connection) <= 0) {
				setErrstatus(InvErrorCode.ERROR_DELETING_PBX_GROUP_TN);
				log.info("Error while deleting PBXGroupTn.");
				return false;
			}
			if (subId != null && !subId.equalsIgnoreCase("")) {
				Subscriber subobj = new Subscriber(connection);
				subobj.setSubId(subId);
				subobj.delSubscriber();
			}

			PublicTnPool publicTnPool = new PublicTnPool(connection);
			publicTnPool.setTnPoolId(tnPoolId);
			publicTnPool.setEnvOrderId(getEnvOrderId());
			publicTnPool.setModifiedBy(getModifiedBy());
			publicTnPool.setLastModifiedDate(new Timestamp(System.currentTimeMillis()));

			log.info("tnPoolId===>" + tnPoolId);
			log.info("rollbackFlag===>" + rollbackFlag);
			log.info("removeTnFlag===>" + removeTnFlag);
			if ((rollbackFlag && !isExistingTn) || removeTnFlag) {
				if (!publicTnPool.deletePublicTnPool()) {
					setErrstatus(InvErrorCode.ERROR_DELETING_PUBLIC_TN_POOL_FROM_PBX_GROUP_TN);
					log.info("##Error while deleting Public Tn Poll from PBXGroupTn.");
					return false;
				}
			} else {
				publicTnPool.setTnStatus(VzbVoipEnum.TnStatus.AVAILABLE);
				publicTnPool.setActiveInd(VzbVoipEnum.ActiveInd.ACTIVE);
				if (!publicTnPool.updatePublicTnPool()) {
					setErrstatus(InvErrorCode.ERROR_DELETING_PUBLIC_TN_POOL_FROM_PBX_GROUP_TN);
					log.info("##Error while deleting Public Tn Poll from PBXGroupTn.");
					return false;
				}

			}
		/*} catch (SQLException s) {
			setErrstatus(InvErrorCode.DB_EXCEPTION);
			log.info("DB_FAILURE in deleteFromDB KeyGroup");
			s.printStackTrace();
			return false;
		} catch (Exception ee) {
			setErrstatus(InvErrorCode.DB_EXCEPTION);
			log.info("DB_FAILURE in deleteFromDB KeyGroup");
			ee.printStackTrace();
			return false;
		}*/
		setErrstatus(InvErrorCode.SUCCESS);
		log.info("PBXGroupTN:: deleteFromDB End");
		return true;
	}
	
	
	public boolean deleteFromDBExceptPNP() throws SQLException, Exception{
			if (groupTnId <= 0) {
				setErrstatus(InvErrorCode.INVALID_INPUT);
				System.out
						.println("FAILURE in deleteFromDB PBXGroupTn. groupTnId missing.");
				return false;
			}
			deleteExcludedFeaturesForGroupTn();
			// deleting tn features in tbl_group_tn_features for the grouptnid
			deleteGroupTnFeatures();
			TblGroupTnQuery grpTnQuery = new TblGroupTnQuery();
			grpTnQuery.whereGroupTnIdEQ(getGroupTnId());
			grpTnQuery.query(connection);
			int tnPoolId = (int) grpTnQuery.getDbBean(0).getTnPoolId();
			setGroupId((int)grpTnQuery.getDbBean(0).getGroupId());
			String subId = new String("");
			subId = grpTnQuery.getDbBean(0).getSubId();
			//incrementORdecrementPortsAssigned("N");
               
			DBTblGroupTn pbxGroupTnDbBean = new DBTblGroupTn();
			pbxGroupTnDbBean.whereGroupTnIdEQ(getGroupTnId());
			if (pbxGroupTnDbBean.deleteByWhere(connection) <= 0) {
				setErrstatus(InvErrorCode.ERROR_DELETING_PBX_GROUP_TN);
				log.info("Error while deleting PBXGroupTn.");
				return false;
			}
			if (subId != null && !subId.equalsIgnoreCase("")) {
				Subscriber subobj = new Subscriber(connection);
				subobj.setSubId(subId);
				subobj.delSubscriber();
			}

			
			PublicTnPool publicTnPool = new PublicTnPool(connection);
			publicTnPool.setTnPoolId(tnPoolId);
			publicTnPool.setEnvOrderId(getEnvOrderId());
			publicTnPool.setModifiedBy(getModifiedBy());
			publicTnPool.setLastModifiedDate(new Timestamp(System.currentTimeMillis()));

			log.info("tnPoolId=== <" + tnPoolId+">  rollbackFlag=== <" + rollbackFlag+"> removeTnFlag=== <" + removeTnFlag+">");
			
			if ((rollbackFlag && !isExistingTn) || removeTnFlag) {
				/**
				 * Commenting below PublicTnPool delete code to handle it in System Update
				 */
				/*if (!publicTnPool.deletePublicTnPool()) {
					setErrstatus(InvErrorCode.ERROR_DELETING_PUBLIC_TN_POOL_FROM_PBX_GROUP_TN);
					System.out
							.println("Error while deleting Public Tn Poll from PBXGroupTn.");
					return false;
				}*/
				
				/**
				 * Commenting above PublicTnPool delete code to handle it in System Update
				 */
			} else {
				publicTnPool.setTnStatus(VzbVoipEnum.TnStatus.AVAILABLE);
				publicTnPool.setActiveInd(VzbVoipEnum.ActiveInd.ACTIVE);
				if (!publicTnPool.updatePublicTnPool()) {
					setErrstatus(InvErrorCode.ERROR_DELETING_PUBLIC_TN_POOL_FROM_PBX_GROUP_TN);
					System.out
							.println("Error while deleting Public Tn Poll from PBXGroupTn.");
					return false;
				}

			}
	
		setErrstatus(InvErrorCode.SUCCESS);
		return true;
	}
	
	public void deleteGroupTnFeatures() throws SQLException, Exception {
		DBTblGroupTnFeatures grpTnFeatDbBean = new DBTblGroupTnFeatures();
		log.info("getGroupTnId()====>" + getGroupTnId());
		grpTnFeatDbBean.whereGroupTnIdEQ(getGroupTnId());
		if (grpTnFeatDbBean.deleteByWhere(connection) < 0) {
			//setErrstatus(InvErrorCode.ERROR_DELETING_GROUP_TN_FEATURES_FROM_PBX_GROUP_TN);
			log.info("Error while deleting Group Tn Features from PBXGroupTn.");
		}
	}

	public void deletePublicTnPoolForGroupTn() throws SQLException, Exception {

		TblGroupTnQuery grpTnQuery = new TblGroupTnQuery();
		grpTnQuery.whereGroupTnIdEQ(getGroupTnId());
		grpTnQuery.query(connection);

		PublicTnPool publicTnPool = new PublicTnPool(connection);
		for (int i = 0; i < grpTnQuery.size(); i++) {
			publicTnPool.setTnPoolId((int) grpTnQuery.getDbBean(i)
					.getTnPoolId());
			if (rollbackFlag) {
				if (!publicTnPool.deletePublicTnPool()) {
					setErrstatus(InvErrorCode.ERROR_DELETING_PUBLIC_TN_POOL_FROM_PBX_GROUP_TN);
					System.out
							.println("Error while deleting Public Tn Poll from PBXGroupTn.");
				}

			} else {
				publicTnPool.setTnStatus(VzbVoipEnum.TnStatus.AVAILABLE);
				publicTnPool.setActiveInd(VzbVoipEnum.ActiveInd.ACTIVE);
				if (!publicTnPool.updatePublicTnPool()) {
					setErrstatus(InvErrorCode.ERROR_DELETING_PUBLIC_TN_POOL_FROM_PBX_GROUP_TN);
					System.out
							.println("Error while deleting Public Tn Poll from PBXGroupTn.");
				}
			}
		}
	}

	public void deleteExcludedFeaturesForGroupTn() throws SQLException {
		DBTblGroupTnExcldFeatures excTnFeaturesDbBean = new DBTblGroupTnExcldFeatures();
		log.info("getGroupTnId()====>" + getGroupTnId());
		excTnFeaturesDbBean.whereGroupTnIdEQ(getGroupTnId());
		if (excTnFeaturesDbBean.deleteByWhere(connection) < 0) {
			setErrstatus(InvErrorCode.ERROR_DELETING_EXCLUDE_FEATURES_FROM_PBX_GROUP_TN);
			log.info("##Error while deleting Exclude Features from PBXGroupTn.");
		}
	}

	/**
	 * The method to modify the PBXGroupTn record.
	 * 
	 * Group Tn Id should be set before calling this method.
	 * 
	 * @return true Record has been updated SUCCESSFULLY false Group Tn Id
	 *         missing / Record update Unsuccessful / Some Error occured.
	 */

	
	public boolean modifyInDB() {
		try {
			if (getGroupTnId() <= 0) {
				setErrstatus(InvErrorCode.INVALID_INPUT);
				System.out
						.println("FAILURE in modifyInDB PBXGroupTn. Invalid GroupTnId. ");
				return false;
			}
			log.info("DEBRAJ Inside modifyInDB");
			DBTblGroupTn groupTnBean = getPBXGroupTnToUpdate();
			groupTnBean.whereGroupTnIdEQ(getGroupTnId());
			if (groupTnBean.updateSpByWhere(connection) <= 0) {
				if (getTnPoolId() > 0) {
					log.info("DEBRAJ Inside modifyInDB @@@@@");
					DBTblGroupTn groupTnBea = getPBXGroupTnToUpdate();
					groupTnBea.whereTnPoolIdEQ(getTnPoolId());
					if (groupTnBea.updateSpByWhere(connection) <= 0) {
						setErrstatus(InvErrorCode.ERROR_MODIFYING_PBX_GROUP_TN);
						log.info("Error while modifying PBXGroupTn.");
						return false;
					}
				} else if (getTn() != null && getTn().length() > 0) {
					DBTblGroupTn groupTnBea = getPBXGroupTnToUpdate();
					PublicTnPool pnpObj = new PublicTnPool(connection);
					long tnPId = pnpObj.getTnPoolIdByTn(getTn());
					groupTnBea.whereTnPoolIdEQ(tnPId);
					if (groupTnBea.updateSpByWhere(connection) <= 0) {
						setErrstatus(InvErrorCode.ERROR_MODIFYING_PBX_GROUP_TN);
						log.info("Error while modifying PBXGroupTn.");
						return false;
					}
				}else{
					setErrstatus(InvErrorCode.ERROR_MODIFYING_PBX_GROUP_TN);
					log.info("Error while modifying PBXGroupTn.");
					return false;
				}
			}

		} catch (SQLException s) {
			setErrstatus(InvErrorCode.DB_EXCEPTION);
			log.info("DB_FAILURE in modifyInDB KeyGroup.");
			s.printStackTrace();
			return false;
		}
		setErrstatus(InvErrorCode.SUCCESS);
		return true;
	}


	
	


	/**
	 * The current Key Group TN details are extracted using getDetails() and the
	 * new field values are updated over that. The method will update the fields
	 * that are supplied on the current instance if they are different from the
	 * default values for the respective field.
	 * 
	 * @return The Group Tn to be updated.
	 */
	private DBTblGroupTn getPBXGroupTnToUpdate() {
		log.info("Inside getPBXGroupTnToUpdate");
		DBTblGroupTn pbxGroupTnDbBean = new DBTblGroupTn();
		/*
		 * Create a new instance of PBXGroupTnBean. The new instance would hold
		 * default values for the all the PBXGroupTn fields.
		 */
		PBXGroupTnBean defaultPBXGrpTnBean = new PBXGroupTnBean();
		PBXGroupTn inputPBXGrpTn = this;
		if (inputPBXGrpTn.getIcpSubId() != null && !inputPBXGrpTn.getIcpSubId().equals(defaultPBXGrpTnBean.getIcpSubId())) {
			pbxGroupTnDbBean.setIcpSubId(inputPBXGrpTn.getIcpSubId());
			log.info("IcpSubId = <" + inputPBXGrpTn.getIcpSubId() + ">");
		}
		if (inputPBXGrpTn.getGroupId() != defaultPBXGrpTnBean.getGroupId()) {
			pbxGroupTnDbBean.setGroupId(inputPBXGrpTn.getGroupId());
		}
		if (inputPBXGrpTn.getTnPoolId() != defaultPBXGrpTnBean.getTnPoolId()) {
			pbxGroupTnDbBean.setTnPoolId(inputPBXGrpTn.getTnPoolId());
		}
		if (inputPBXGrpTn.getSequenceNo() != defaultPBXGrpTnBean
				.getSequenceNo()) {
			pbxGroupTnDbBean.setSequenceNo(inputPBXGrpTn.getSequenceNo());
		}
		if (inputPBXGrpTn.getExtension() != null
				&& !inputPBXGrpTn.getExtension().equals(
						defaultPBXGrpTnBean.getExtension())) {
			pbxGroupTnDbBean.setExtension(inputPBXGrpTn.getExtension());
			log.info("Extension = <" + inputPBXGrpTn.getExtension()
					+ ">");
		}
		
		if(inputPBXGrpTn.getExtension()==null || "".equals(inputPBXGrpTn.getExtension())){
			pbxGroupTnDbBean.setExtensionNull();
		}
		
		if (inputPBXGrpTn.getPrivateNumber() != null
				&& !inputPBXGrpTn.getPrivateNumber().equals(
						defaultPBXGrpTnBean.getPrivateNumber())) {
			pbxGroupTnDbBean.setPrivateNumber(inputPBXGrpTn.getPrivateNumber());
		}		
		
		if ("".equals(inputPBXGrpTn.getPrivateNumber())) {
			pbxGroupTnDbBean.setPrivateNumberNull();
		}
		
		/* pbxGroupTnDbBean.setLinePort(currentPBXGrpTn.getLinePort()); */
		if (inputPBXGrpTn.getLinePort() != null
				&& !inputPBXGrpTn.getLinePort().equals(
						defaultPBXGrpTnBean.getLinePort())) {
			pbxGroupTnDbBean.setLinePort(inputPBXGrpTn.getLinePort());
		}

		if ("".equals(inputPBXGrpTn.getLinePort())) {
			pbxGroupTnDbBean.setLinePortNull();
		}
		if (inputPBXGrpTn.getCidFirstName() != null
				&& !inputPBXGrpTn.getCidFirstName().equals(
						defaultPBXGrpTnBean.getCidFirstName())) {
			pbxGroupTnDbBean.setCidFirstName(inputPBXGrpTn.getCidFirstName());
		}

		if ("".equals(inputPBXGrpTn.getCidFirstName())) {
			pbxGroupTnDbBean.setCidFirstNameNull();
		}
		if (inputPBXGrpTn.getCidLastName() != null
				&& !inputPBXGrpTn.getCidLastName().equals(
						defaultPBXGrpTnBean.getCidLastName())) {
			pbxGroupTnDbBean.setCidLastName(inputPBXGrpTn.getCidLastName());
		}

		if ("".equals(inputPBXGrpTn.getCidLastName())) {
			pbxGroupTnDbBean.setCidLastNameNull();
		}
		/* pbxGroupTnDbBean.setVmMaxsizeId(currentPBXGrpTn.getVmxSize()); */
		if (inputPBXGrpTn.getVmxSize() != defaultPBXGrpTnBean.getVmxSize()) {
			pbxGroupTnDbBean.setVmMaxsizeId(inputPBXGrpTn.getVmxSize());
		}
		
		if ( inputPBXGrpTn.getVmxSize()==0) {
			pbxGroupTnDbBean.setVmMaxsizeIdNull();
		}
		
		if (inputPBXGrpTn.getVmxNumber() != null
				&& !inputPBXGrpTn.getVmxNumber().equals(
						defaultPBXGrpTnBean.getVmxNumber())) {
			pbxGroupTnDbBean.setVmBoxNum(inputPBXGrpTn.getVmxNumber());
		}
		
		if ("".equals(inputPBXGrpTn.getVmxNumber())) {
			pbxGroupTnDbBean.setVmBoxNumNull();
		}
		
		/*
		 * if ( inputPBXGrpTn.getStatus() != null &&
		 * !inputPBXGrpTn.getStatus().equals(defaultPBXGrpTnBean.getStatus()) ){
		 * pbxGroupTnDbBean.setStatus(inputPBXGrpTn.getStatus()); }
		 */

		if (inputPBXGrpTn.getActiveInd() != defaultPBXGrpTnBean.getActiveInd()) {
			pbxGroupTnDbBean.setActiveInd(inputPBXGrpTn.getActiveInd());
		}
		if (inputPBXGrpTn.getEnvOrderId() != defaultPBXGrpTnBean
				.getEnvOrderId()) {
			pbxGroupTnDbBean.setEnvOrderId(inputPBXGrpTn.getEnvOrderId());
		}
		if (inputPBXGrpTn.getModifiedBy() != null
				&& !("".equalsIgnoreCase(inputPBXGrpTn.getModifiedBy())))
			pbxGroupTnDbBean.setModifiedBy(getModifiedBy());
		else
			pbxGroupTnDbBean.setModifiedBy("ESAP_INV");
		pbxGroupTnDbBean.setLastModifiedDate(new Timestamp(System
				.currentTimeMillis()));

		// Added as new column introduced in the table fmcg_sub_id
		if (inputPBXGrpTn.getSubId() != null
				&& !inputPBXGrpTn.getSubId().equals(
						defaultPBXGrpTnBean.getSubId())) {
			if (inputPBXGrpTn.getSubId().equals(""))
				pbxGroupTnDbBean.setSubIdNull();
			else
				pbxGroupTnDbBean.setSubId(inputPBXGrpTn.getSubId());
		}

		return pbxGroupTnDbBean;
	}// To Update

	public boolean validate() {
		return true;
	}

	public boolean getDetailsByGroupTnId() {
		try {
			if (getGroupTnId() <= 0) {
				setErrstatus(InvErrorCode.INVALID_INPUT);
				// setErrstatus("INV_FAILURE in getDetails PBX groupTn. Invalid
				// Input");
				return false;
			}
			TblGroupTnQuery grpTnQry = new TblGroupTnQuery();
			String whereClause = new String("");
			if (getAll == false)
				whereClause = " where group_tn_id = " + getGroupTnId()
						+ " and active_ind = 1";
			else
				whereClause = " where group_tn_id = " + getGroupTnId()
						+ " and active_ind != 0";
			grpTnQry.queryByWhere(connection, whereClause);
			if (grpTnQry.size() == 1) {
				setGroupId((int) (grpTnQry.getDbBean(0)).getGroupId());
				setGroupTnId((grpTnQry.getDbBean(0)).getGroupTnId());
				// TODO
				setTnPoolId((grpTnQry.getDbBean(0)).getTnPoolId());
				PublicTnPool tnPool = new PublicTnPool(connection);
				tnPool.setTnPoolId((int) getTnPoolId());
				if (!tnPool.getPublicTnPoolDetailsByTnPoolId()) {
					setErrstatus(InvErrorCode.NOTFOUND_TN_POOL_ID);
					// setStatusDesc("NOTFOUND_TN_POOL_ID in
					// getDetailsByGroupTnId. Failed to getPublic Tn Pool");
					System.out
							.println("NOTFOUND_TN_POOL_ID in getDetailsByGroupTnId. PBXGroupTn.Failed to get Public Tn Pool");
					return false;
				}
				publicTnPoolObj = tnPool;
				setSequenceNo((grpTnQry.getDbBean(0)).getSequenceNo());
				setExtension((grpTnQry.getDbBean(0)).getExtension());
				setPrivateNumber((grpTnQry.getDbBean(0)).getPrivateNumber());
				setLinePort((grpTnQry.getDbBean(0)).getLinePort());
				setCidFirstName((grpTnQry.getDbBean(0)).getCidFirstName());
				setCidLastName((grpTnQry.getDbBean(0)).getCidLastName());
				// setStatus((grpTnQry.getDbBean(0)).getStatus());
			    setVmxNumber((grpTnQry.getDbBean(0)).getVmBoxNum());
				setVmxSize((int)(grpTnQry.getDbBean(0)).getVmMaxsizeId());	
                 setActiveInd((grpTnQry.getDbBean(0)).getActiveInd());
				setEnvOrderId(grpTnQry.getDbBean(0).getEnvOrderId());
				setCreatedBy((grpTnQry.getDbBean(0)).getCreatedBy());
				setModifiedBy((grpTnQry.getDbBean(0)).getModifiedBy());
		        setLastModifiedDate((grpTnQry.getDbBean(0)).getLastModifiedDate());
				setCreationDate((grpTnQry.getDbBean(0)).getCreationDate());		
                // Added as new column introduced in the table fmcg_sub_id
				setSubId((grpTnQry.getDbBean(0)).getSubId());
				setIcpSubId((grpTnQry.getDbBean(0)).getIcpSubId());
		        getExcludedFeatureListByGroupTnId();	
              }
		} catch (SQLException s) {
			setErrstatus(InvErrorCode.DB_EXCEPTION);
			// setStatusDesc("DB_FAILURE in getDetails PBX group tn");
			s.printStackTrace();
			return false;
		}
		setErrstatus(InvErrorCode.SUCCESS);
		// setStatusDesc("Successfully retrieved pbx groupTn from db");
		return true;
	}
	
	public boolean getAllDetailsByGroupTnId() {
		try {
			if (getGroupTnId() <= 0) {
				setErrstatus(InvErrorCode.INVALID_INPUT);
				// setErrstatus("INV_FAILURE in getDetails PBX groupTn. Invalid
				// Input");
				return false;
			}
			TblGroupTnQuery grpTnQry = new TblGroupTnQuery();
			String whereClause = new String("");
			if (getAll == false)
				whereClause = " where group_tn_id = " + getGroupTnId()
						+ " and active_ind = 1";
			else
				whereClause = " where group_tn_id = " + getGroupTnId()
						+ " and active_ind != 0";
			grpTnQry.queryByWhere(connection, whereClause);
			if (grpTnQry.size() == 1) {
				setGroupId((int) (grpTnQry.getDbBean(0)).getGroupId());
				setGroupTnId((grpTnQry.getDbBean(0)).getGroupTnId());
				// TODO
				setTnPoolId((grpTnQry.getDbBean(0)).getTnPoolId());
				PublicTnPool tnPool = new PublicTnPool(connection);
				tnPool.setTnPoolId((int) getTnPoolId());
				log.info("Value of get ALL is ******: "+getAll);
				tnPool.setGetAll(true);
				if (!tnPool.getPublicTnPoolDetailsByTnPoolId()) {
					setErrstatus(InvErrorCode.NOTFOUND_TN_POOL_ID);
					// setStatusDesc("NOTFOUND_TN_POOL_ID in
					// getDetailsByGroupTnId. Failed to getPublic Tn Pool");
					System.out
							.println("NOTFOUND_TN_POOL_ID in getDetailsByGroupTnId. PBXGroupTn.Failed to get Public Tn Pool");
					return false;
				}
				publicTnPoolObj = tnPool;
				setSequenceNo((grpTnQry.getDbBean(0)).getSequenceNo());
				setExtension((grpTnQry.getDbBean(0)).getExtension());
				setPrivateNumber((grpTnQry.getDbBean(0)).getPrivateNumber());
				setLinePort((grpTnQry.getDbBean(0)).getLinePort());
				setCidFirstName((grpTnQry.getDbBean(0)).getCidFirstName());
				setCidLastName((grpTnQry.getDbBean(0)).getCidLastName());
				// setStatus((grpTnQry.getDbBean(0)).getStatus());
			    setVmxNumber((grpTnQry.getDbBean(0)).getVmBoxNum());
				setVmxSize((int)(grpTnQry.getDbBean(0)).getVmMaxsizeId());	
                 setActiveInd((grpTnQry.getDbBean(0)).getActiveInd());
				setEnvOrderId(grpTnQry.getDbBean(0).getEnvOrderId());
				setCreatedBy((grpTnQry.getDbBean(0)).getCreatedBy());
				setModifiedBy((grpTnQry.getDbBean(0)).getModifiedBy());
		        setLastModifiedDate((grpTnQry.getDbBean(0)).getLastModifiedDate());
				setCreationDate((grpTnQry.getDbBean(0)).getCreationDate());		
                // Added as new column introduced in the table fmcg_sub_id
				setSubId((grpTnQry.getDbBean(0)).getSubId());
				setIcpSubId((grpTnQry.getDbBean(0)).getIcpSubId());
		        getExcludedFeatureListByGroupTnId();	
              }
		} catch (SQLException s) {
			setErrstatus(InvErrorCode.DB_EXCEPTION);
			// setStatusDesc("DB_FAILURE in getDetails PBX group tn");
			s.printStackTrace();
			return false;
		}
		setErrstatus(InvErrorCode.SUCCESS);
		// setStatusDesc("Successfully retrieved pbx groupTn from db");
		return true;
	}


	 public HashMap<Long, List<Long>> getExcludedFeatureListByGroupId() {
   HashMap<Long, List<Long>> groupTnToExcldFeatMap = new HashMap<Long, List<Long>>();
   PreparedStatement pstmt = null;
   ResultSet rs = null;
   try {
   if (getGroupId() <= 0) {
   setErrstatus(InvErrorCode.INVALID_INPUT);
   return groupTnToExcldFeatMap;
   }
   StringBuffer sqlTbl = new StringBuffer();
  
   sqlTbl.append(" SELECT E.GROUP_TN_ID, E.FEATURE_ID ");
   sqlTbl.append(" FROM  TBL_GROUP_TN GT, TBL_GROUP_TN_EXCLD_FEATURES E ");
   sqlTbl.append(" WHERE GT.GROUP_ID = ? and GT.GROUP_TN_ID = E.GROUP_TN_ID ORDER BY E.GROUP_TN_ID ");
   log.info("SQL [" + sqlTbl.toString() + "]");
   
   pstmt = connection.prepareStatement(sqlTbl.toString());
   pstmt.setLong(1,getGroupId());
   rs = pstmt.executeQuery();
  
   long currGroupTnId = 0;
   while (rs.next())
   {
   currGroupTnId = rs.getLong(1);
	//log.info("groupTnId:"+currGroupTnId+"featureId:"+rs.getLong(2));
   List<Long> l = groupTnToExcldFeatMap.get(currGroupTnId);
   if(l == null)
	{
		//log.info("Adding list to group tn ID:"+currGroupTnId);
   groupTnToExcldFeatMap.put(currGroupTnId, l=new ArrayList<Long>());
	}
 	l.add(rs.getLong(2));
   }
   } catch (SQLException s) {
   setErrstatus(InvErrorCode.DB_EXCEPTION);
   s.printStackTrace();
   return groupTnToExcldFeatMap;
   }finally{ //#IR1440263 closing statement and results set
	   try{
		   if ( pstmt != null) {
			   pstmt.close();
		   }
		   if ( rs != null ){
			   rs.close();
		   }
	   }catch(Exception e){
		   setErrstatus(InvErrorCode.DB_EXCEPTION);
		   e.printStackTrace();
		   return groupTnToExcldFeatMap;
		   //log.info(" Closing Resouces Exception " + e);
	   }
   }
   return groupTnToExcldFeatMap;
   }

	public boolean getExcludedFeatureListByGroupTnId() {
		try {
			if (getGroupTnId() <= 0) {
				setErrstatus(InvErrorCode.INVALID_INPUT);
				// setStatusDesc("INV_FAILURE in getExcludedFeaturesList");
				return false;
			}
			TblGroupTnExcldFeaturesQuery grpExcldFeatQry = new TblGroupTnExcldFeaturesQuery();
			grpExcldFeatQry.whereGroupTnIdEQ(getGroupTnId());
			grpExcldFeatQry.query(connection);
			if (grpExcldFeatQry.size() > 0) {
				for (int i = 0; i < grpExcldFeatQry.size(); i++) {
					TblVzbFeaturesQuery vzbFeatQry = new TblVzbFeaturesQuery();
					vzbFeatQry.whereFeatureIdEQ((int) (grpExcldFeatQry
							.getDbBean(i)).getFeatureId());
					vzbFeatQry.whereFeatureTypeNE("C");
					vzbFeatQry.query(connection);
					if (vzbFeatQry.size() == 1) {
						FeaturesBean featBean = new FeaturesBean();
						DBTblVzbFeatures vzbFeat = new DBTblVzbFeatures();
						vzbFeat.copyFromBean(vzbFeatQry.getDbBean(0));
						featBean.setFeaturesDbBean(vzbFeat);
						//excludedFeaturesList.add(featBean);
						//TODO need to check ERROR condition
					}
				}
			}
		} catch (SQLException s) {
			setErrstatus(InvErrorCode.DB_EXCEPTION);
			// setStatusDesc("DB_FAILURE in getExcludedFeaturesList");
			s.printStackTrace();
			return false;
		}
		return true;
	}

	// wrapper add for excludedfeaturesList
	public boolean addExcludedFeautresForPBXGroup() {
		try {
			if (excludedFeaturesList.size() > 0) {
				for (int i = 0; i < excludedFeaturesList.size(); i++) {
					TblVzbFeaturesQuery vzbFeatQry = new TblVzbFeaturesQuery();
					vzbFeatQry.whereFeatureIdEQ(((excludedFeaturesList.get(i))
							.getFeaturesDbBean()).getFeatureId());
					vzbFeatQry.whereFeatureTypeNE("C");
					vzbFeatQry.query(connection);
					if (vzbFeatQry.size() == 1) {
						DBTblGroupTnExcldFeatures grpExcldFeat = new DBTblGroupTnExcldFeatures();
						grpExcldFeat.getGroupTnFeatureIdSeqNextVal(connection);
						grpExcldFeat.setGroupTnId(getGroupTnId());
						grpExcldFeat.setFeatureId((vzbFeatQry.getDbBean(0))
								.getFeatureId());
						if (getEnvOrderId() > 0)
							grpExcldFeat.setEnvOrderId(getEnvOrderId());
						else
							grpExcldFeat.setEnvOrderIdNull();
						if (getCreatedBy() != null
								&& !getCreatedBy().equals(""))
							grpExcldFeat.setCreatedBy(getCreatedBy());
						else
							grpExcldFeat.setCreatedBy("ESAP_INV");
						if (getModifiedBy() != null
								&& !getModifiedBy().equals(""))
							grpExcldFeat.setModifiedBy(getModifiedBy());
						else
							grpExcldFeat.setModifiedBy("ESAP_INV");
						grpExcldFeat.setLastModifiedDate(new Timestamp(System
								.currentTimeMillis()));
						grpExcldFeat.setCreationDate(new Timestamp(System
								.currentTimeMillis()));
						grpExcldFeat.insert(connection);
					} else {
						System.out
								.println("Valid Excluded feature not found in the db"
										+ ((excludedFeaturesList.get(i))
												.getFeaturesDbBean()).getName());
						return false;
					}
				}
			} else {
				setErrstatus(InvErrorCode.SUCCESS);
				// //setStatusDesc("");
				log.info("No groupExcFeatures to Add");
				return true;
			}
		} catch (Exception e) {
			e.printStackTrace();
			setErrstatus(InvErrorCode.ERROR_ADDING_EXCLD_FEATURE_TO_GROUP_TN);
			log.info("FAILURE in addExcludedFeautresForPBXGroup.");
			return false;
		}
		setErrstatus(InvErrorCode.SUCCESS);
		return true;
	}

	// wrapper delete for excludedfeaturesList
    public boolean deleteExcludedfeaturesListForPBXGroup() {
        try {
            if (excludedFeaturesList.size() > 0) {
                for (int i = 0; i < excludedFeaturesList.size(); i++) {
                        DBTblGroupTnExcldFeatures excFeaturesDbBean = new DBTblGroupTnExcldFeatures();
                        excFeaturesDbBean.whereFeatureIdEQ(((excludedFeaturesList.get(i)).getFeaturesDbBean()).getFeatureId());
                        excFeaturesDbBean.whereGroupTnIdEQ(getGroupTnId());
                        if (excFeaturesDbBean.deleteByWhere(connection) <= 0) {
                            setErrstatus(InvErrorCode.ERROR_DELETING_EXCLUDE_FEATURES_FROM_PBX_GROUP_TN);
                            log.info("Error while deleting Exclude Features from PBXGroupTn."+((excludedFeaturesList.get(i)).getFeaturesDbBean()).getFeatureId());
                        }
                                                                                                                             
                    }
            } else {
                setErrstatus(InvErrorCode.SUCCESS);
                // //setErrstatus("");
                log.info("No excludedfeaturesList to Delete");
                return true;
            }
        } catch (Exception e) {
            e.printStackTrace();
            setErrstatus(InvErrorCode.ERROR_DELETING_EXCLD_FEATURE_TO_GROUP_TN);
            System.out
                    .println("FAILURE in deleteExcludedfeaturesListForPBXGroup.");
            return false;
        }
        setErrstatus(InvErrorCode.SUCCESS);
        return true;
    }


	// wrapper Modify for excludedfeaturesList
	public boolean modifyExcludedfeaturesListForPBXGroup() {
		try {
			if (excludedFeaturesList.size() > 0) {
				for (int i = 0; i < excludedFeaturesList.size(); i++) {
					TblGroupTnExcldFeaturesQuery excFeaturesQuery = new TblGroupTnExcldFeaturesQuery();
					String whereClause = " where group_id = " + getGroupId();
					excFeaturesQuery.queryByWhere(connection, whereClause);
					for (int j = 0; j < excFeaturesQuery.size(); j++) {
						DBTblGroupTnExcldFeatures excFeaturesDbBean = new DBTblGroupTnExcldFeatures();
						excFeaturesDbBean
								.whereFeatureIdEQ(((excludedFeaturesList.get(i))
										.getFeaturesDbBean()).getFeatureId());
						// excFeaturesDbBean.updateSpByWhere(connection);
						if (excFeaturesDbBean.updateSpByWhere(connection) <= 0) {
							setErrstatus(InvErrorCode.ERROR_MODIFYING_EXCLUDE_FEATURES_FROM_PBX_GROUP_TN);
							System.out
									.println("Error while mofifying Exclude Features from PBXGroupTn.");
							return false;
						}

					}
				}
			} else {
				setErrstatus(InvErrorCode.SUCCESS);
				// //setStatusDesc("");
				log.info("No excludedfeaturesList to Modify");
				return true;
			}
		} catch (Exception e) {
			e.printStackTrace();
			setErrstatus(InvErrorCode.ERROR_MODIFYING_EXCLD_FEATURE_TO_GROUP_TN);
			System.out
					.println("FAILURE in modifyExcludedfeaturesListForPBXGroup.");
			return false;
		}
		setErrstatus(InvErrorCode.SUCCESS);
		return true;
	}

	/**
	 * The wrapper method to get Public Tn Pool for a PBXGroupTn
	 * 
	 * @return true if retrieve Public Tn Pool bean false if it fails to
	 *         retrieve Public Tn Pool bean
	 * @throws SQLException
	 *             If any DB Error occurs.
	 */
	public boolean getPublicTnPoolForPBXGroupTn() {
		try {
			// retrieve PBXGroupTn details to get the PublicTnPoolId(TN_POOL_ID)
			boolean ret = getDetailsByGroupTnId();
			if (!ret) {
				setErrstatus(InvErrorCode.INV_FAILURE);
				System.out
						.println("FAILURE in getDetailsByGroupTnId PBXGroupTn. PBXGroupTn.getDetailsByGroupTnId returned false in getPublicTnPoolForPBXGroupTn");
				return false;
			}
			System.out
					.println("In the Inventry, the PublicTnPoolId Id for PBXGroupTn = "
							+ groupTnId + " is -> " + tnPoolId);
			// if PublicTnPoolId is valid, query the PublicTnPool class for
			// details.
			PublicTnPool pubTnPool = new PublicTnPool(connection);
			pubTnPool.setTnPoolId(new Long(tnPoolId).intValue());
			ret = pubTnPool.getDetails();
			if (!ret) {
				setErrstatus(InvErrorCode.INV_FAILURE);
				System.out
						.println("FAILURE in PBXGroupTn.getDetails . PBXGroupTn.getDetails returned false in getPublicTnPoolForPBXGroupTn");
				return false;
			}
			setPublicTnPoolObj((PublicTnPoolBean) pubTnPool);
		} catch (Exception e) {
			e.printStackTrace();
			setErrstatus(InvErrorCode.DB_EXCEPTION);
			log.info("FAILURE in getDetails PBXGroupTn");
			return false;
		}
		setErrstatus(InvErrorCode.SUCCESS);
		log.info("Successfully retrieved PBXGroupTn from the DB");
		return true;
	}

	/**
	 * The wrapper method to Add Public Tn Pool to a PBXGroupTn
	 * 
	 * @throws SQLException
	 *             If any DB Error occurs.
	 */
	public boolean addPublicTnPoolToPBXGroupTn() {
		try {
			PublicTnPool publicTnPool = new PublicTnPool(connection, publicTnPoolObj);

			if (!publicTnPool.addPublicTnPool()) {
				setErrstatus(InvErrorCode.INTERNAL_ERROR);
				// //setStatusDesc(publicTnPool.getStatusDesc());
				log.info(publicTnPool.getStatusDesc());
				return false;
			}
			DBTblGroupTn groupTnDbBean = new DBTblGroupTn();
			groupTnDbBean.setTnPoolId(publicTnPoolObj.getTnPoolId());
			if (getEnvOrderId() < 0)
				groupTnDbBean.setEnvOrderId(getEnvOrderId());
			else
				groupTnDbBean.setEnvOrderIdNull();
			if (publicTnPoolObj.getModifiedBy() != null
					&& !"".equals(publicTnPoolObj.getModifiedBy()))
				groupTnDbBean.setModifiedBy(groupTnDbBean.getModifiedBy());
			else
				groupTnDbBean.setModifiedBy("ESAP_INV");
			groupTnDbBean.setLastModifiedDate(new Timestamp(System
					.currentTimeMillis()));
			groupTnDbBean.whereGroupTnIdEQ(getGroupTnId());
			groupTnDbBean.updateSpByWhere(connection);
		} catch (Exception e) {
			e.printStackTrace();
			setErrstatus(InvErrorCode.ERROR_ADDING_PUBLICTNPOOL_TO_GROUP_TN);
			// //setStatusDesc("FAILURE in addPublicTnPoolToPBXGroupTn.");
			log.info("FAILURE in addPublicTnPoolToPBXGroupTn.");
			return false;
		}
		setErrstatus(InvErrorCode.SUCCESS);
		// //setStatusDesc("Successfully added PublicTnPool to PBXGroupTn");
		return true;
	}

	/**
	 * The wrapper method to delete Public Tn Pool for a PBXGroupTn
	 * 
	 * @throws SQLException
	 *             If any DB Error occurs.
	 */
	public boolean deletePublicTnPoolToPBXGroupTn() throws SQLException, Exception {

		try {
			PublicTnPool publicTnPool = new PublicTnPool(connection, publicTnPoolObj);
			if (rollbackFlag) {
				if (!publicTnPool.deletePublicTnPool()) {
					setErrstatus(InvErrorCode.INTERNAL_ERROR);
					// //setStatusDesc(publicTnPool.getStatusDesc());
					log.info(publicTnPool.getStatusDesc());
					return false;
				}
			} else {
				publicTnPool.setTnStatus(VzbVoipEnum.TnStatus.AVAILABLE);
				if (!publicTnPool.updatePublicTnPool()) {
					setErrstatus(InvErrorCode.INTERNAL_ERROR);
					log.info(publicTnPool.getStatusDesc());
					return false;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			setErrstatus(InvErrorCode.ERROR_DELETING_PUBLICTNPOOL_TO_GROUP_TN);
			// //setStatusDesc("FAILURE in deletePublicTnPoolForPBXGroupTn().");
			log.info("FAILURE in deletePublicTnPoolForPBXGroupTn().");
			return false;
		}
		setErrstatus(InvErrorCode.SUCCESS);
		// //setStatusDesc("Successfully deleted PublicTnPool from PBXGroupTn");
		return true;

	}

	/**
	 * The wrapper method to Add Public Tn Pool to a PBXGroupTn
	 * 
	 * @throws SQLException
	 *             If any DB Error occurs.
	 */
	public boolean updatePublicTnPoolToPBXGroupTn() throws SQLException, Exception{
		//try {
			PublicTnPool publicTnPool = new PublicTnPool(connection, publicTnPoolObj);
			// publicTnPool.setTnPoolId(new Long(getTnPoolId()).intValue());
			if (!publicTnPool.updatePublicTnPool()) {
				setErrstatus(InvErrorCode.INTERNAL_ERROR);
				// //setStatusDesc(publicTnPool.getStatusDesc());
				log.info(publicTnPool.getStatusDesc());
				return false;
			}
		/*} catch (Exception e) {
			e.printStackTrace();
			setErrstatus(InvErrorCode.ERROR_MODIFYING_PUBLICTNPOOL_TO_GROUP_TN);
			// //setStatusDesc("FAILURE in updatePublicTnPoolToPBXGroupTn.");
			log.info("FAILURE in updatePublicTnPoolToPBXGroupTn.");
			return false;
		}*/
		setErrstatus(InvErrorCode.SUCCESS);
		// //setStatusDesc("Successfully updated PublicTnPool to PBXGroupTn");
		return true;
	}

	/**
	 * The wrapper method to get Subscriber for a PbxGroupTn
	 * 
	 * @return true if retrieve Public Tn Pool bean false if it fails to
	 *         retrieve Public Tn Pool bean
	 * @throws SQLException
	 *             If any DB Error occurs.
	 */
	public boolean getSubscriberForPBXGroupTn() {
		try {
			// retrieve PbxGroupTn details to get the PublicTnPoolId(TN_POOL_ID)
			boolean ret = getDetailsByGroupTnId();
			if (!ret) {
				setErrstatus(InvErrorCode.INV_FAILURE);
				System.out
						.println("FAILURE in getDetailsByGroupTnId PbxGroupTn. PbxGroupTn.getDetailsByGroupTnId returned false in getPublicTnPoolForPBXGroupTn");
				return false;
			}
			System.out
					.println("In the Inventry, the PublicTnPoolId Id for PBXGroupTn = "
							+ groupTnId + " is -> " + tnPoolId);

			// if FmcgSubId is valid, query the Subscriber class for details.
			Subscriber subscriber = new Subscriber(connection);
			FmcgSubscriber fmcgSubscriber = new FmcgSubscriber(connection);
			fmcgSubscriber.setFmcgSubId(new Integer((int) tnPoolId).intValue());
			ret = fmcgSubscriber.getFmcgSubscriberDetailsById();
			if (!ret) {
				setErrstatus(InvErrorCode.INV_FAILURE);
				System.out
						.println("FAILURE in PBXGroupTn.getDetails . PBXGroupTn.getDetails returned false in getPublicTnPoolForPBXGroupTn");
				return false;
			}
			subscriber
					.setFmcgSubscriberObj((FmcgSubscriberBean) fmcgSubscriber);

			// if SubId is valid, query the Subscriber class for details.

			subscriber.setSubId(new String(tnPoolId + ""));
			ret = subscriber.getSubscriberDetailsBySubId();
			if (!ret) {
				setErrstatus(InvErrorCode.INV_FAILURE);
				System.out
						.println("FAILURE in PBXGroupTn.getDetails . PBXGroupTn.getDetails returned false in getPublicTnPoolForPBXGroupTn");
				return false;
			}
			setSubscriberBeanObj((SubscriberBean) subscriber);

		} catch (Exception e) {
			e.printStackTrace();
			setErrstatus(InvErrorCode.DB_EXCEPTION);
			log.info("FAILURE in getDetails PBXGroupTn");
			return false;
		}
		setErrstatus(InvErrorCode.SUCCESS);
		log.info("Successfully retrieved PBXGroupTn from the DB");
		return true;
	}

}



