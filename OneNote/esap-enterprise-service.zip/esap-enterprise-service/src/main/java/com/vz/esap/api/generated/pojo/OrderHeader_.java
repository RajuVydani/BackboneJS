
package com.vz.esap.api.generated.pojo;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "UNOServiceId",
    "WorkOrderNumber",
    "WorkOrderVersion",
    "TransactionID",
    "MsgSegmentNo",
    "LastSegment",
    "FunctionCode",
    "OrderType",
    "OriginatingSystem",
    "EnterpriseId",
    "VOIPLocationId",
    "GCHId",
    "NASPId",
    "EnvOrderId"
})
public class OrderHeader_ {

    @JsonProperty("UNOServiceId")
    private String uNOServiceId;
    @JsonProperty("WorkOrderNumber")
    private String workOrderNumber;
    @JsonProperty("WorkOrderVersion")
    private String workOrderVersion;
    @JsonProperty("TransactionID")
    private String transactionID;
    @JsonProperty("MsgSegmentNo")
    private String msgSegmentNo;
    @JsonProperty("LastSegment")
    private String lastSegment;
    @JsonProperty("FunctionCode")
    private String functionCode;
    @JsonProperty("OrderType")
    private String orderType;
    @JsonProperty("OriginatingSystem")
    private String originatingSystem;
    @JsonProperty("EnterpriseId")
    private String enterpriseId;
    @JsonProperty("VOIPLocationId")
    private String vOIPLocationId;
    @JsonProperty("GCHId")
    private String gCHId;
    @JsonProperty("NASPId")
    private String nASPId;
    @JsonProperty("EnvOrderId")
    private Long envOrderId;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("UNOServiceId")
    public String getUNOServiceId() {
        return uNOServiceId;
    }

    @JsonProperty("UNOServiceId")
    public void setUNOServiceId(String uNOServiceId) {
        this.uNOServiceId = uNOServiceId;
    }

    @JsonProperty("WorkOrderNumber")
    public String getWorkOrderNumber() {
        return workOrderNumber;
    }

    @JsonProperty("WorkOrderNumber")
    public void setWorkOrderNumber(String workOrderNumber) {
        this.workOrderNumber = workOrderNumber;
    }

    @JsonProperty("WorkOrderVersion")
    public String getWorkOrderVersion() {
        return workOrderVersion;
    }

    @JsonProperty("WorkOrderVersion")
    public void setWorkOrderVersion(String workOrderVersion) {
        this.workOrderVersion = workOrderVersion;
    }

    @JsonProperty("TransactionID")
    public String getTransactionID() {
        return transactionID;
    }

    @JsonProperty("TransactionID")
    public void setTransactionID(String transactionID) {
        this.transactionID = transactionID;
    }

    @JsonProperty("MsgSegmentNo")
    public String getMsgSegmentNo() {
        return msgSegmentNo;
    }

    @JsonProperty("MsgSegmentNo")
    public void setMsgSegmentNo(String msgSegmentNo) {
        this.msgSegmentNo = msgSegmentNo;
    }

    @JsonProperty("LastSegment")
    public String getLastSegment() {
        return lastSegment;
    }

    @JsonProperty("LastSegment")
    public void setLastSegment(String lastSegment) {
        this.lastSegment = lastSegment;
    }

    @JsonProperty("FunctionCode")
    public String getFunctionCode() {
        return functionCode;
    }

    @JsonProperty("FunctionCode")
    public void setFunctionCode(String functionCode) {
        this.functionCode = functionCode;
    }

    @JsonProperty("OrderType")
    public String getOrderType() {
        return orderType;
    }

    @JsonProperty("OrderType")
    public void setOrderType(String orderType) {
        this.orderType = orderType;
    }

    @JsonProperty("OriginatingSystem")
    public String getOriginatingSystem() {
        return originatingSystem;
    }

    @JsonProperty("OriginatingSystem")
    public void setOriginatingSystem(String originatingSystem) {
        this.originatingSystem = originatingSystem;
    }

    @JsonProperty("EnterpriseId")
    public String getEnterpriseId() {
        return enterpriseId;
    }

    @JsonProperty("EnterpriseId")
    public void setEnterpriseId(String enterpriseId) {
        this.enterpriseId = enterpriseId;
    }

    @JsonProperty("VOIPLocationId")
    public String getVOIPLocationId() {
        return vOIPLocationId;
    }

    @JsonProperty("VOIPLocationId")
    public void setVOIPLocationId(String vOIPLocationId) {
        this.vOIPLocationId = vOIPLocationId;
    }

    @JsonProperty("GCHId")
    public String getGCHId() {
        return gCHId;
    }

    @JsonProperty("GCHId")
    public void setGCHId(String gCHId) {
        this.gCHId = gCHId;
    }

    @JsonProperty("NASPId")
    public String getNASPId() {
        return nASPId;
    }

    @JsonProperty("NASPId")
    public void setNASPId(String nASPId) {
        this.nASPId = nASPId;
    }

    @JsonProperty("EnvOrderId")
    public Long getEnvOrderId() {
        return envOrderId;
    }

    @JsonProperty("EnvOrderId")
    public void setEnvOrderId(Long envOrderId) {
        this.envOrderId = envOrderId;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(uNOServiceId).append(workOrderNumber).append(workOrderVersion).append(transactionID).append(msgSegmentNo).append(lastSegment).append(functionCode).append(orderType).append(originatingSystem).append(enterpriseId).append(vOIPLocationId).append(gCHId).append(nASPId).append(envOrderId).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof OrderHeader_) == false) {
            return false;
        }
        OrderHeader_ rhs = ((OrderHeader_) other);
        return new EqualsBuilder().append(uNOServiceId, rhs.uNOServiceId).append(workOrderNumber, rhs.workOrderNumber).append(workOrderVersion, rhs.workOrderVersion).append(transactionID, rhs.transactionID).append(msgSegmentNo, rhs.msgSegmentNo).append(lastSegment, rhs.lastSegment).append(functionCode, rhs.functionCode).append(orderType, rhs.orderType).append(originatingSystem, rhs.originatingSystem).append(enterpriseId, rhs.enterpriseId).append(vOIPLocationId, rhs.vOIPLocationId).append(gCHId, rhs.gCHId).append(nASPId, rhs.nASPId).append(envOrderId, rhs.envOrderId).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
