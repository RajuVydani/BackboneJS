/**
 * 
 */
package com.vz.esap.api.constant;

/**
 * @author Rajesh Bandla
 *
 */
public class E2EIConstants {

	public static final String E2E_PC_ESAP_INTERFACE_NAME = "E2EIPCESAPInterface";
	public static final String E2E_ORDR_TYPE = "E2EIPCESAPInterface.VOIPOrderRequest";
	public static final String E2E_ENTERPRISE_ORDER = "PR_VOIP_ENTERPRISE";
	public static final String E2E_CHANGE_ID_FEAT_SPEC = "FEATURE_OR_SPEC";
	public static final String E2E_CHANGE_ID_PRIM_FIRST_NAME = "PRIM_CONTACT_F_NAME";
	public static final String E2E_CHANGE_ID_PRIM_LAST_NAME = "PRIM_CONTACT_L_NAME";
	public static final String E2E_CHANGE_ID_PRIM_CONTACT_COMMENTS = "PRIM_CONTACT_COMMENTS";
	public static final String E2E_CHANGE_ID_PRIM_CNTRY_DIALING = "PRIM_COUNTRY_DIALING";
	public static final String E2E_CHANGE_ID_PRIM_AREA_DIALING = "PRIM_AREA_DIALING";
	public static final String E2E_CHANGE_ID_PRIM_DIAL_NUMBER = "PRIM_DIAL_NUMBER";
	public static final String E2E_CHANGE_ID_PRIM_EXTN = "PRIM_EXTENSION";
	public static final String E2E_CHANGE_ID_PRIM_URI = "PRIM_URI";
	public static final String E2E_CHANGE_ID_OM_FIRST_NAME = "OM_CONTACT_F_NAME";
	public static final String E2E_CHANGE_ID_OM_LAST_NAME = "OM_CONTACT_L_NAME";
	public static final String E2E_CHANGE_ID_OM_CONTACT_COMMENTS = "OM_CONTACT_COMMENTS";
	public static final String E2E_CHANGE_ID_OM_CNTRY_DIALING = "OM_COUNTRY_DIALING";
	public static final String E2E_CHANGE_ID_OM_AREA_DIALING = "OM_AREA_DIALING";
	public static final String E2E_CHANGE_ID_OM_DIAL_NUMBER = "OM_DIAL_NUMBER";
	public static final String E2E_CHANGE_ID_OM_EXTN = "OM_EXTENSION";
	public static final String E2E_CHANGE_ID_OM_URI = "OM_URI";
	public static final String E2E_CHANGE_ID_ADDRESS_LINE = "ADDRESSLINE";
	public static final String E2E_CHANGE_ID_CITY = "CITY";
	public static final String E2E_CHANGE_ID_STATE = "STATE";
	public static final String E2E_CHANGE_ID_ZIP = "ZIP";
	public static final String E2E_CHANGE_ID_CNTRY_CODE = "COUNTRY_CODE";
	public static final String E2E_CHANGE_ID_CNTRY_NAME = "COUNTRY_NAME";
	public static final String E2E_CHANGE_ID_BLLNG_ACCT_NUM = "BILLING_ACCT_NUMBER";
	public static final String E2E_CHANGE_ID_DUE_DATE = "DUE_DATE";
	public static final String E2E_CHANGE_TYPE_CHANGED = "CHANGED";
	public static final String E2E_CHANGE_TYPE_ADDED = "ADDED";
	public static final String E2E_CHANGE_TYPE_REMOVED = "REMOVED";
	
	public static final String E2E_ENT_FEATURE_NAME = "EFET_VOIP_ENT_LVL";
	public static final String E2E_LOC_FEATURE_NAME = "EFET_VOIP_LOC_LVL";
	public static final String E2E_DEVICE_FEATURE_NAME = "EFET_VOIP_DEVICE_LVL";
	public static final String E2E_EBI_FEATURE_NAME = "EFET_VOIP_EBI_LVL";
	public static final String E2E_TRUNK_GROUP_FEATURE_NAME = "EFET_VOIP_TRUNK_LVL";
	public static final String E2E_TN_FEATURE_NAME = "EFET_VOIP_TN_LVL";
	public static final String E2E_BEST_PLUS_FEATURE_NAME = "FET_VOIP_BEST_PLUS";
	
	public static final long CnamOrderCreation = 0;
	public static final long CnamOrderMsgSentToPC = 1;
	public static final long IproCnamResp = 4;
	public static final long PcCnamQuery = 2;
	public static final long EsapCnamResp = 3;
	public static final String CNAM_ORDER_REQ = "CNAM_ORDER_REQ";
	public static final String IPRO_CNAM_RESP = "IPRO_CNAM_RESP";
	public static final String PC_CNAM_QRY = "PC_CNAM_QRY";
	public static final String ESAP_CNAM_RESP = "ESAP_CNAM_RESP";
	
	
	//large order
	public static final String E2E_LOR_QUERY = "SELECT SVC_CAP_ID,  CAP_ACTION_CODE,  SPEC_CODE,  SPEC_VALUE,  BOD_SVC_CAPABILITY_ID,  TN_TYPE FROM TBL_LOR_TN_DETAILS tltd, (SELECT rn,  unique_svc_cap_id  FROM    (SELECT rownum rn,      unique_svc_cap_id    FROM "
	+ " ( SELECT DISTINCT(SVC_CAP_ID) unique_svc_cap_id      FROM TBL_LOR_TN_DETAILS      WHERE SVC_CAP_ID NOT IN ( SELECT DISTINCT SVC_CAP_ID FROM TBL_LOR_TN_DETAILS        WHERE ORDER_NUMBER     = ?" +
	"   AND ORDER_VERSION  = ? AND ((spec_code='ESP_TRANSITION_TYPE' AND (Upper(spec_value) = 'W2R')) OR (spec_code ='SP_VOIP_TN_DISPOSITION' AND (Upper(spec_value) = 'R'        OR Upper(spec_value)   = 'D'))) )"
	+ " AND ORDER_NUMBER  = ? AND ORDER_VERSION = ? ORDER BY svc_cap_id))  WHERE rn >=?  AND rn   <= ?  ) unicapids WHERE tltd.SVC_CAP_ID = unicapids.unique_svc_cap_id ORDER BY tltd.SVC_CAP_ID";
}
