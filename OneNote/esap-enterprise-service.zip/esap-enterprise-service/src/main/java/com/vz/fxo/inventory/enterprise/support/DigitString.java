/****************************************
  This Class will have all methods related to Key group
Author : Pallavi Vankayalapati
 ****************************************/
package com.vz.fxo.inventory.enterprise.support;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import EsapEnumPkg.VzbVoipEnum;
import esap.db.DBTblCallingPlanDigits;
import esap.db.DBTblDigitStrings;
import esap.db.TblCallingPlanDigitsQuery;
import esap.db.TblDigitStringsQuery;

public class DigitString extends DigitStringBean{
	
	private static Logger log = LoggerFactory.getLogger(DigitString.class
			.toString());


	String statusCode;
	String statusDesc;
	Connection dbCon;
	InvErrorCode status = InvErrorCode.INTERNAL_ERROR;

	public DigitString(Connection dbCon)
	{
		this.dbCon = dbCon;
	}

	public DigitString(DigitStringBean digitStringBean, Connection dbCon)
	{
		super(digitStringBean);
		this.dbCon = dbCon;
	}
	public int getStatusCode()
    {
        return status.getErrorCode();
    }
    public void setStatus(InvErrorCode status)
    {
        this.status = status;
    }
    public String getStatusDesc()
    {
        return status.getErrorDesc();
    }
	public Connection getDbCon() {
		return dbCon;
	}
	public void setDbCon(Connection dbCon) {
		this.dbCon = dbCon;
	}

	public boolean addDigitStringsForCallingPlanByEnterpriseId(int callPlanId, String enterpriseId, String user) throws SQLException, Exception

	{
//		try
//		{
			if(callPlanId > 0)
				setCallingPlanId(callPlanId);
			log.info("Adding digitString mapping for calling planId:"+callPlanId);
			if(user != null && !user.equals(""))
			{
				setCreatedBy(user);
				setModifiedBy(user);
			}
			TblDigitStringsQuery digitStringQry = new TblDigitStringsQuery();
			digitStringQry.whereEnterpriseIdEQ(enterpriseId);
			digitStringQry.query(dbCon);
			log.info("Number of digitStrings to be added to Calling are:"+digitStringQry.size());
			if(digitStringQry.size() > 0)
			{
				for(int i =0; i < digitStringQry.size(); i++)
				{
					setDigitStringId(digitStringQry.getDbBean(i).getDigitStringId());
					addToDB();
				}
			}
		/*}
		catch(SQLException s)
        {
            s.printStackTrace();
            setStatus(InvErrorCode.DB_EXCEPTION);
            log.info("DB_FAILURE in addDigitStringsForCallingPlanByEnterpriseId");
            return false;
        }*/
        setStatus(InvErrorCode.SUCCESS);

		return true;
	}	


	//for Migration - Add Location Calling Plan Digits based on Enterprise
	public boolean migrateLocCPDigitsFromEnterprise(int callPlanId, String enterpriseId, String user) throws SQLException, Exception

    {
//        try
 //       {
            if(callPlanId > 0)
                setCallingPlanId(callPlanId);
            log.info("Adding digitString mapping for calling planId:"+callPlanId);
            if(user != null && !user.equals(""))
            {
                setCreatedBy(user);
                setModifiedBy(user);
            }
                                                                                                                                  
            Enterprise entObj = new Enterprise(dbCon);
            entObj.setEnterpriseId(enterpriseId);
            entObj.setGetAll(true);
            if(entObj.getDetails() != true)
            {
                log.info("Failed to Retrieve Calling Plan Id by Enterprise [" + enterpriseId + "]");
                return false;
            }
                                                                                                                                  
            TblDigitStringsQuery digitStringQry = new TblDigitStringsQuery();
            digitStringQry.whereEnterpriseIdEQ(enterpriseId);
            digitStringQry.query(dbCon);
            log.info("Number of digitStrings to be added to Calling are:"+digitStringQry.size());
            if(digitStringQry.size() > 0)
            {
                for(int i =0; i < digitStringQry.size(); i++)
                {
                    setDigitStringId(digitStringQry.getDbBean(i).getDigitStringId());
                    TblCallingPlanDigitsQuery dQry = new TblCallingPlanDigitsQuery();
                    dQry.whereCallingPlanIdEQ(((Long)entObj.getCallingPlanId()).intValue());
                    dQry.whereDigitStringIdEQ(getDigitStringId());
                    dQry.query(dbCon);
                    if(dQry.size() <= 0)
                    {
                        log.info("No Calling Plan Digit Found by Enterprise CP Id [" + entObj.getCallingPlanId() + " and DigitString Id [" + getDigitStringId() + "]");
                        return false;
                    }
                    setIAllow(dQry.getDbBean(0).getIAllow());
                    setOAllow(dQry.getDbBean(0).getOAllow());
                    setFAllow(dQry.getDbBean(0).getFAllow());
                    setBAllow(dQry.getDbBean(0).getBAllow());
                                                                                                                                  
                    addToDB();
                }
            }
		/*}
        catch(SQLException s)
        {
            s.printStackTrace();
            setStatus(InvErrorCode.DB_EXCEPTION);
            log.info("DB_FAILURE in addDigitStringsForCallingPlanByEnterpriseId");
            return false;
        }*/
        setStatus(InvErrorCode.SUCCESS);
                    
        return true;
    }
	//methods
	public boolean addToDB() throws SQLException, Exception
	{
		//try
		//{
			DBTblCallingPlanDigits callingPlanDigits = new DBTblCallingPlanDigits();
			if(getCallingPlanId() > 0 )
				callingPlanDigits.setCallingPlanId(getCallingPlanId());
			else
			{
				setStatus(InvErrorCode.INVALID_INPUT);
				log.info("CallingPlanId is mandatory for adding calling plan digits");
				return false;
			}

			callingPlanDigits.setDigitStringId(getDigitStringId());
			//TODO if digitStringId is < 0 derive it from DigitString
			if(getIAllow() > -1)
				callingPlanDigits.setIAllow(getIAllow());
			else
				callingPlanDigits.setIAllow(VzbVoipEnum.CallingPlanCallType.ALLOW);
			if(getOAllow() > -1)
				callingPlanDigits.setOAllow(getOAllow());
			else
				callingPlanDigits.setOAllow(VzbVoipEnum.CallingPlanCallType.ALLOW);
			if(getBAllow() > -1)
				callingPlanDigits.setBAllow(getBAllow());
			else
				callingPlanDigits.setBAllow(VzbVoipEnum.CallingPlanCallType.ALLOW);
			if(getFAllow() > -1)
				callingPlanDigits.setFAllow(getFAllow());
			else
				callingPlanDigits.setFAllow(VzbVoipEnum.CallingPlanCallType.ALLOW);
			if (getModifiedBy() != null && !("".equalsIgnoreCase(getModifiedBy())))
            {
                callingPlanDigits.setModifiedBy(getModifiedBy());
            } else
            {
                callingPlanDigits.setModifiedBy("ESAP_INV");
            }
            if (getCreatedBy() != null && !("".equalsIgnoreCase(getCreatedBy())))
            {
                callingPlanDigits.setCreatedBy(getCreatedBy());
            } else
            {
                callingPlanDigits.setCreatedBy("ESAP_INV");
            }
			callingPlanDigits.setCreationDate(new Timestamp(System.currentTimeMillis()));
            callingPlanDigits.setLastModifiedDate(new Timestamp(System.currentTimeMillis()));
			callingPlanDigits.insert(dbCon);

		/*}
		catch(SQLException s)
		{
			s.printStackTrace();
			setStatus(InvErrorCode.DB_EXCEPTION);
			log.info("DB_FAILURE in addToDB DigitString");
			return false;
		}*/
		setStatus(InvErrorCode.SUCCESS);
		return true;
	}
	/*With given CallingPlanId and digitStringId(optional) delete the callingPlanDigits*/
	public boolean deleteCallingPlanDigits() throws SQLException, Exception{
         log.info("deleteCallingPlanDigits ::");
	//	try
	//	{
			if ( callingPlanId <=0 ) {
                                setStatus(InvErrorCode.INVALID_INPUT);
                                log.info("FAILURE in deleteCallingPlanDigits DigitString. callingPlanId missing.");
                                return false;
                        }
			DBTblCallingPlanDigits callingPlanDigits = new DBTblCallingPlanDigits();
                        callingPlanDigits.whereCallingPlanIdEQ(getCallingPlanId());
						if(getDigitStringId() > 0)
                        callingPlanDigits.whereDigitStringIdEQ(getDigitStringId());
                        callingPlanDigits.deleteByWhere(dbCon);
		/*}
		catch(SQLException s) {
                        s.printStackTrace();
                        setStatus(InvErrorCode.DB_EXCEPTION);
                        log.info("DB_FAILURE in deleteCallingPlanDigits DigitString");
                        return false;
                }*/
                setStatus(InvErrorCode.SUCCESS);
                return true;

    }

	/*With the given DigitStringId delete entries from tbl_digit_strings */
	public boolean deleteDigitStringByDigitStringId(){
        	try
                {

			if ( digitStringId <=0 ) {
								setStatus(InvErrorCode.INVALID_INPUT);
                                log.info("FAILURE in deleteDigitStringByDigitStringId DigitString. digitStringId missing.");
                                return false;
                        }
                       //commented below code to fix jira issue:ESVRRS-654
						/*TblCallingPlanDigitsQuery callingPlanDigitsQry = new TblCallingPlanDigitsQuery();
						callingPlanDigitsQry.whereDigitStringIdEQ(getDigitStringId());
						callingPlanDigitsQry.query(dbCon);
						if(callingPlanDigitsQry.size() > 0)
						{
							//TODO add status code setStatus(
                            log.info("FAILURE in deleteDigitStringByDigitStringId DigitString. DigitString is mapped to callingplan.");
                                return false;
						}*/
                        DBTblDigitStrings digitStringsDbBean = new DBTblDigitStrings();
                        log.info("digitStringId is "+getDigitStringId());
                        digitStringsDbBean.whereDigitStringIdEQ(getDigitStringId());
                       	digitStringsDbBean.deleteByWhere(dbCon);

                } catch(SQLException s) {
						/*s.printStackTrace();
                        setStatus(InvErrorCode.DB_EXCEPTION);
                        log.info("DB_FAILURE in deleteDigitStringByDigitStringId DigitString");
                        return false;*/
                        log.info("In catch :deleteDigitStringByDigitStringId####");
                        return true;
                }
                setStatus(InvErrorCode.SUCCESS);
                return true;
    	}
		 /*With the given enterpriseId delete entries from tbl_digit_strings */
    public boolean deleteDigitStringByEnterpriseId() throws SQLException, Exception{
            //try
             //   {

				log.info("deleteDigitStringByEnterpriseId:");
            if ( enterpriseId == null || enterpriseId.equals("") || enterpriseId.equals("NONE")) {
                                setStatus(InvErrorCode.INVALID_INPUT);
                                log.info("FAILURE in deleteDigitStringByDigitStringId DigitString. enterpriseId missing.");
                                return false;
                        }
				log.info("deleteDigitStringByEnterpriseId:");
                        TblCallingPlanDigitsQuery callingPlanDigitsQry = new TblCallingPlanDigitsQuery();
                        callingPlanDigitsQry.whereDigitStringIdEQ(getDigitStringId());
                        callingPlanDigitsQry.query(dbCon);
                        if(callingPlanDigitsQry.size() > 0)
                        {
                            //TODO add status code setStatus(
                            log.info("FAILURE in deleteDigitStringByDigitStringId DigitString. DigitString is mapped to callingplan.");
                                return false;
                        }
                        DBTblDigitStrings digitStringsDbBean = new DBTblDigitStrings();
                        digitStringsDbBean.whereEnterpriseIdEQ(getEnterpriseId());
                        digitStringsDbBean.deleteByWhere(dbCon);

                /*} catch(SQLException s) {
                        s.printStackTrace();
                        setStatus(InvErrorCode.DB_EXCEPTION);
                        log.info("DB_FAILURE in deleteDigitStringByDigitStringId DigitString");
                        return false;
                }*/
                setStatus(InvErrorCode.SUCCESS);
                return true;
        }


	 /**
         * The method to modify the CallingPlanDigits record.
         *
         * Calling Plan Id and should be set before calling this method.
         *
         * @return      true    Record has been updated SUCCESSFULLY
         *                      false   Group Id missing / Record update Unsuccessful /
         *                                      Some Error occured.
         */

	public boolean modifyInDB() throws SQLException, Exception{
		//try{
			if ( getDigitStringId() <= 0 || getCallingPlanId() <= 0) {
				setStatus(InvErrorCode.INVALID_INPUT);
				log.info("FAILURE in modifyInDB KeyGroup. GroupId missing.");
				return false;
			}
			log.info("Inside modifyInDB");
			DBTblCallingPlanDigits callPlanDigits = getCallingPlanDigitsToUpdate();
			callPlanDigits.whereDigitStringIdEQ(getDigitStringId());
			callPlanDigits.whereCallingPlanIdEQ(getCallingPlanId());
			if(callPlanDigits.updateSpByWhere(dbCon) <= 0)
			{
                log.info("Nothing to modify in Key Group.");
				setStatus(InvErrorCode.SUCCESS);
				return true;
			}
		/*} catch(SQLException s) {
			s.printStackTrace();
			setStatus(InvErrorCode.DB_EXCEPTION);
                        log.info("DB_FAILURE in modifyInDB KeyGroup.");
                        return false;
                }*/
                setStatus(InvErrorCode.SUCCESS);
		return true;
	}

       /**
         * The current Key Group details are extracted using getDetails()
         * and the new field values are updated over that. The method
         * will update the fields that are supplied on the current instance
         * if they are different from the default values for the respective field.
         *
         * @return The Group to be updated.
         */
        @SuppressWarnings("unused")
        private DBTblCallingPlanDigits getCallingPlanDigitsToUpdate() throws SQLException {
			log.info("Inside getKeyGroupToUpdate");
			DBTblCallingPlanDigits callingPlanDigitsDbBean = new DBTblCallingPlanDigits();

		    /* Create a new instance of KeyGroupBean. The new instance
             * would hold default values for the all the KeyGroup fields.*/
            DigitStringBean defaultDigitStringBean = new DigitStringBean();

            DigitString inputDigitString = this;

            if ( inputDigitString.getIAllow() !=defaultDigitStringBean.getIAllow()) {
                    callingPlanDigitsDbBean.setIAllow(inputDigitString.getIAllow());
            }
            if ( inputDigitString.getOAllow() !=defaultDigitStringBean.getOAllow()) {
                    callingPlanDigitsDbBean.setOAllow(inputDigitString.getOAllow());
            }
            if ( inputDigitString.getBAllow() !=defaultDigitStringBean.getBAllow()) {
                    callingPlanDigitsDbBean.setBAllow(inputDigitString.getBAllow());
            }
            if ( inputDigitString.getFAllow() !=defaultDigitStringBean.getFAllow()) {
                    callingPlanDigitsDbBean.setFAllow(inputDigitString.getFAllow());
            }
                                                                                                                             
	    	if(getCreatedBy() != null  && !getCreatedBy().equals(""))
                    callingPlanDigitsDbBean.setCreatedBy(getCreatedBy());
            else
                    callingPlanDigitsDbBean.setCreatedBy("ESAP_INV");


	    	if(getModifiedBy() != null  && !getModifiedBy().equals(""))
                 callingPlanDigitsDbBean.setModifiedBy(getModifiedBy());
            else
                 callingPlanDigitsDbBean.setModifiedBy("ESAP_INV");

            callingPlanDigitsDbBean.setLastModifiedDate(new Timestamp(System.currentTimeMillis()));

		return callingPlanDigitsDbBean;

	}//ToUpdate

	public boolean getDetails()
	{
				/*
            try
            {
				clearKeyGroup();
                log.info("In KeyGroup getDetails; Key GroupId="+getGroupId());
                TblGroupQuery keyGroupQuery = new TblGroupQuery();
				String whereClause = new String("");
            	if(getAll == false)
                	whereClause = " where group_id = "+getGroupId() + " and active_ind = 1";
				else
                	whereClause = " where group_id = "+getGroupId() + " and active_ind != 0";
                log.info("whereClause is "+whereClause);
                keyGroupQuery.queryByWhere(dbCon, whereClause);
                log.info("keyGroupQuery.size is "+keyGroupQuery.size());
                if(keyGroupQuery.size() == 1){
                	log.info("In getDetails No of Records = 1");
				setLocationId((keyGroupQuery.getDbBean(0)).getLocationId());
				setDepartmentId((keyGroupQuery.getDbBean(0)).getDepartmentId());
				setGroupName((keyGroupQuery.getDbBean(0)).getGroupName());
				setGroupType((keyGroupQuery.getDbBean(0)).getGroupType());
				setPackageId((keyGroupQuery.getDbBean(0)).getPackageId());
				if((keyGroupQuery.getDbBean(0)).getPackageId() > 0)
				{
					TblPackageQuery pkgQry = new TblPackageQuery();
					pkgQry.wherePackageIdEQ((keyGroupQuery.getDbBean(0)).getPackageId());
					pkgQry.query(dbCon);
					if(pkgQry.size() == 1)
						setPackageStr((pkgQry.getDbBean(0)).getPackageName());
				}
				setDeviceMapId((keyGroupQuery.getDbBean(0)).getDeviceMapId());
				setCidFirstName((keyGroupQuery.getDbBean(0)).getCidFirstName());
				setCidLastName((keyGroupQuery.getDbBean(0)).getCidLastName());
				setExtension((keyGroupQuery.getDbBean(0)).getExtension());
				setPrivateNumber((keyGroupQuery.getDbBean(0)).getPrivateNumber());
				setLinePort((keyGroupQuery.getDbBean(0)).getLinePort());
				setKeyTerminationType((keyGroupQuery.getDbBean(0)).getKeyTerminationType());
				setKeyFwdTn((keyGroupQuery.getDbBean(0)).getKeyFwdTn());
				setKeyVmMaxsizeId((keyGroupQuery.getDbBean(0)).getKeyVmMaxsizeId());
				TblVmBoxSizeQuery vmBoxQry = new TblVmBoxSizeQuery();
				vmBoxQry.whereVmBoxSizeIdEQ((int)getKeyVmMaxsizeId());
				vmBoxQry.query(dbCon);
				if(vmBoxQry.size() > 0)
					setKeyVmMaxsize(vmBoxQry.getDbBean(0).getMessages());
				setKeyVmBoxNum((keyGroupQuery.getDbBean(0)).getKeyVmBoxNum());
				setActiveInd((keyGroupQuery.getDbBean(0)).getActiveInd());
				setModifiedBy((keyGroupQuery.getDbBean(0)).getModifiedBy());
				setCreatedBy((keyGroupQuery.getDbBean(0)).getCreatedBy());
				setLastModifiedDate((keyGroupQuery.getDbBean(0)).getLastModifiedDate());
				setCreationDate((keyGroupQuery.getDbBean(0)).getCreationDate());
				setLinePortLength((keyGroupQuery.getDbBean(0)).getLinePortLength());
				getGroupFeatureListByGroupId();
                log.info(".getPrivateNumber " +(keyGroupQuery.getDbBean(0)).getPrivateNumber());
                }
				else
	            {
					setStatus(InvErrorCode.DB_EXCEPTION); 
	                    return false;
	            }
            }
            catch(SQLException s){
			s.printStackTrace();
            	setStatus(InvErrorCode.DB_EXCEPTION);
            	return false;
            }
			*/
	    	setStatus(InvErrorCode.SUCCESS);
	    	return true;
	} //getDetails Ends


	public boolean validate(){return true;}

       public ArrayList<String> getDetails(String enterpriseId)
       {
          ArrayList<String> digitStringList = new  ArrayList<String>();

          // TO DO IMPLEMENTATION
       
          return digitStringList;
       }

}
