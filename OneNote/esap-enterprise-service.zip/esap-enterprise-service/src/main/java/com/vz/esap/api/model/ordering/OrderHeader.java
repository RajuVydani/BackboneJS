package com.vz.esap.api.model.ordering;

public class OrderHeader {

	private String unoServiceId;
	private String envOrderId;
	private String workOrderNumber;
	private String workOrderId;
	private String workOrderVersion;
	private String transactionID;
	private String functionCode;
	private String orderType;
	private String responseType;
	private String enterpriseId;
	private String voipLocationId;
	private String gchId;
	private String naspId;

	private OrderHeader(OrderHeaderBuilder orderHeaderBuilder) {
		this.unoServiceId = orderHeaderBuilder.unoServiceId;
		this.envOrderId = orderHeaderBuilder.envOrderId;
		this.workOrderNumber = orderHeaderBuilder.workOrderNumber;
		this.workOrderId = orderHeaderBuilder.workOrderId;
		this.workOrderVersion = orderHeaderBuilder.workOrderVersion;
		this.transactionID = orderHeaderBuilder.transactionID;
		this.functionCode = orderHeaderBuilder.functionCode;
		this.orderType = orderHeaderBuilder.orderType;
		this.responseType = orderHeaderBuilder.responseType;
		this.enterpriseId = orderHeaderBuilder.enterpriseId;
		this.voipLocationId = orderHeaderBuilder.voipLocationId;
		this.gchId = orderHeaderBuilder.gchId;
		this.naspId = orderHeaderBuilder.naspId;

	}

	public String getUnoServiceId() {
		return unoServiceId;
	}

	public void setUnoServiceId(String unoServiceId) {
		this.unoServiceId = unoServiceId;
	}

	public String getEnvOrderId() {
		return envOrderId;
	}

	public void setEnvOrderId(String envOrderId) {
		this.envOrderId = envOrderId;
	}

	public String getWorkOrderNumber() {
		return workOrderNumber;
	}

	public void setWorkOrderNumber(String workOrderNumber) {
		this.workOrderNumber = workOrderNumber;
	}

	public String getWorkOrderVersion() {
		return workOrderVersion;
	}

	public void setWorkOrderVersion(String workOrderVersion) {
		this.workOrderVersion = workOrderVersion;
	}

	public String getTransactionID() {
		return transactionID;
	}

	public void setTransactionID(String transactionID) {
		this.transactionID = transactionID;
	}

	public String getFunctionCode() {
		return functionCode;
	}

	public void setFunctionCode(String functionCode) {
		this.functionCode = functionCode;
	}

	public String getOrderType() {
		return orderType;
	}

	public void setOrderType(String orderType) {
		this.orderType = orderType;
	}

	public String getResponseType() {
		return responseType;
	}

	public void setResponseType(String responseType) {
		this.responseType = responseType;
	}

	public String getEnterpriseId() {
		return enterpriseId;
	}

	public void setEnterpriseId(String enterpriseId) {
		this.enterpriseId = enterpriseId;
	}

	public String getVoipLocationId() {
		return voipLocationId;
	}

	public void setVoipLocationId(String voipLocationId) {
		this.voipLocationId = voipLocationId;
	}

	public String getGchId() {
		return gchId;
	}

	public void setGchId(String gchId) {
		this.gchId = gchId;
	}

	public String getNaspId() {
		return naspId;
	}

	public void setNaspId(String naspId) {
		this.naspId = naspId;
	}

	public String getWorkOrderId() {
		return workOrderId;
	}

	public void setWorkOrderId(String workOrderId) {
		this.workOrderId = workOrderId;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("OrderHeader [unoServiceId=");
		builder.append(unoServiceId);
		builder.append(", envOrderId=");
		builder.append(envOrderId);
		builder.append(", workOrderNumber=");
		builder.append(workOrderNumber);
		builder.append(", workOrderId=");
		builder.append(workOrderId);
		builder.append(", workOrderVersion=");
		builder.append(workOrderVersion);
		builder.append(", transactionID=");
		builder.append(transactionID);
		builder.append(", functionCode=");
		builder.append(functionCode);
		builder.append(", orderType=");
		builder.append(orderType);
		builder.append(", responseType=");
		builder.append(responseType);
		builder.append(", enterpriseId=");
		builder.append(enterpriseId);
		builder.append(", voipLocationId=");
		builder.append(voipLocationId);
		builder.append(", gchId=");
		builder.append(gchId);
		builder.append(", naspId=");
		builder.append(naspId);
		builder.append("]");
		return builder.toString();
	}

	public static class OrderHeaderBuilder {
		private String unoServiceId;
		private String envOrderId;
		private String workOrderNumber;
		private String workOrderId;
		private String workOrderVersion;
		private String transactionID;
		private String functionCode;
		private String orderType;
		private String responseType;
		private String enterpriseId;
		private String voipLocationId;
		private String gchId;
		private String naspId;

		public OrderHeaderBuilder withUnoServiceId(String unoServiceId) {
			this.unoServiceId = unoServiceId;
			return this;
		}

		public OrderHeaderBuilder withEnvOrderId(String envOrderId) {
			this.envOrderId = envOrderId;
			return this;
		}

		public OrderHeaderBuilder withWorkOrderNumber(String workOrderNumber) {
			this.workOrderNumber = workOrderNumber;
			return this;
		}

		public OrderHeaderBuilder withWorkOrderId(String workOrderId) {
			this.workOrderId = workOrderId;
			return this;
		}

		public OrderHeaderBuilder withWorkOrderVersion(String workOrderVersion) {
			this.workOrderVersion = workOrderVersion;
			return this;
		}

		public OrderHeaderBuilder withTransactionID(String transactionID) {
			this.transactionID = transactionID;
			return this;
		}

		public OrderHeaderBuilder withFunctionCode(String functionCode) {
			this.functionCode = functionCode;
			return this;
		}

		public OrderHeaderBuilder withOrderType(String orderType) {
			this.orderType = orderType;
			return this;
		}

		public OrderHeaderBuilder withResponseType(String responseType) {
			this.responseType = responseType;
			return this;
		}

		public OrderHeaderBuilder withEnterpriseId(String enterpriseId) {
			this.enterpriseId = enterpriseId;
			return this;
		}

		public OrderHeaderBuilder withVoipLocationId(String voipLocationId) {
			this.voipLocationId = voipLocationId;
			return this;
		}

		public OrderHeaderBuilder withGchId(String gchId) {
			this.gchId = gchId;
			return this;
		}

		public OrderHeaderBuilder withNaspId(String naspId) {
			this.naspId = naspId;
			return this;
		}
		
		public OrderHeader build() {
			return new OrderHeader(this);
		}

	}

}
