package com.vz.esap.api.model.config;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonProperty;

public class BsAsConfigData {

	private Integer bsAsId;

	private String asName;

	private String asClli;

	private String asIpAddress;

	private Integer asPort;

	private String asGroupWebLink;

	private String asGlobalWebLink;

	private String version;

	private String asProfile;

	private Integer proxyClusterId;

	private String cappedFlag;

	private String overrideCappedFlag;

	private String displayIndicator;

	private String activeIndicator;

	private String modifiedBy;

	private String lastModifiedDate;

	private Integer envOrderId;

	private String bsNodeName;

	private Object asSecIpAddress;

	private Object asSecPort;

	private Object clusterHostName;

	private Object wServerIp;

	private Object versionMinor;

	private Integer monitorUserSel;

	private Integer tnActivation;

	private String defaultSystemDomain;

	private Object esapCluster;

	@JsonProperty("bsAsId")
	public Integer getBsAsId() {
		return bsAsId;
	}

	public void setBsAsId(Integer bsAsId) {
		this.bsAsId = bsAsId;
	}

	public String getAsName() {
		return asName;
	}

	public void setAsName(String asName) {
		this.asName = asName;
	}

	public String getAsClli() {
		return asClli;
	}

	public void setAsClli(String asClli) {
		this.asClli = asClli;
	}

	public String getAsIpAddress() {
		return asIpAddress;
	}

	public void setAsIpAddress(String asIpAddress) {
		this.asIpAddress = asIpAddress;
	}

	public Integer getAsPort() {
		return asPort;
	}

	public void setAsPort(Integer asPort) {
		this.asPort = asPort;
	}

	public String getAsGroupWebLink() {
		return asGroupWebLink;
	}

	public void setAsGroupWebLink(String asGroupWebLink) {
		this.asGroupWebLink = asGroupWebLink;
	}

	public String getAsGlobalWebLink() {
		return asGlobalWebLink;
	}

	public void setAsGlobalWebLink(String asGlobalWebLink) {
		this.asGlobalWebLink = asGlobalWebLink;
	}

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	public String getAsProfile() {
		return asProfile;
	}

	public void setAsProfile(String asProfile) {
		this.asProfile = asProfile;
	}

	public Integer getProxyClusterId() {
		return proxyClusterId;
	}

	public void setProxyClusterId(Integer proxyClusterId) {
		this.proxyClusterId = proxyClusterId;
	}

	public String getCappedFlag() {
		return cappedFlag;
	}

	public void setCappedFlag(String cappedFlag) {
		this.cappedFlag = cappedFlag;
	}

	public String getOverrideCappedFlag() {
		return overrideCappedFlag;
	}

	public void setOverrideCappedFlag(String overrideCappedFlag) {
		this.overrideCappedFlag = overrideCappedFlag;
	}

	public String getDisplayIndicator() {
		return displayIndicator;
	}

	public void setDisplayIndicator(String displayIndicator) {
		this.displayIndicator = displayIndicator;
	}

	public String getActiveIndicator() {
		return activeIndicator;
	}

	public void setActiveIndicator(String activeIndicator) {
		this.activeIndicator = activeIndicator;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public String getLastModifiedDate() {
		return lastModifiedDate;
	}

	public void setLastModifiedDate(String lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public Integer getEnvOrderId() {
		return envOrderId;
	}

	public void setEnvOrderId(Integer envOrderId) {
		this.envOrderId = envOrderId;
	}

	public String getBsNodeName() {
		return bsNodeName;
	}

	public void setBsNodeName(String bsNodeName) {
		this.bsNodeName = bsNodeName;
	}

	public Object getAsSecIpAddress() {
		return asSecIpAddress;
	}

	public void setAsSecIpAddress(Object asSecIpAddress) {
		this.asSecIpAddress = asSecIpAddress;
	}

	public Object getAsSecPort() {
		return asSecPort;
	}

	public void setAsSecPort(Object asSecPort) {
		this.asSecPort = asSecPort;
	}

	public Object getClusterHostName() {
		return clusterHostName;
	}

	public void setClusterHostName(Object clusterHostName) {
		this.clusterHostName = clusterHostName;
	}

	public Object getWServerIp() {
		return wServerIp;
	}

	public void setWServerIp(Object wServerIp) {
		this.wServerIp = wServerIp;
	}

	public Object getVersionMinor() {
		return versionMinor;
	}

	public void setVersionMinor(Object versionMinor) {
		this.versionMinor = versionMinor;
	}

	public Integer getMonitorUserSel() {
		return monitorUserSel;
	}

	public void setMonitorUserSel(Integer monitorUserSel) {
		this.monitorUserSel = monitorUserSel;
	}

	public Integer getTnActivation() {
		return tnActivation;
	}

	public void setTnActivation(Integer tnActivation) {
		this.tnActivation = tnActivation;
	}

	public String getDefaultSystemDomain() {
		return defaultSystemDomain;
	}

	public void setDefaultSystemDomain(String defaultSystemDomain) {
		this.defaultSystemDomain = defaultSystemDomain;
	}

	public Object getEsapCluster() {
		return esapCluster;
	}

	public void setEsapCluster(Object esapCluster) {
		this.esapCluster = esapCluster;
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}

	@Override
	public int hashCode() {
		return new HashCodeBuilder().append(bsAsId).append(asName)
				.append(asClli).append(asIpAddress).append(asPort)
				.append(asGroupWebLink).append(asGlobalWebLink).append(version)
				.append(asProfile).append(proxyClusterId).append(cappedFlag)
				.append(overrideCappedFlag).append(displayIndicator)
				.append(activeIndicator).append(modifiedBy)
				.append(lastModifiedDate).append(envOrderId).append(bsNodeName)
				.append(asSecIpAddress).append(asSecPort)
				.append(clusterHostName).append(wServerIp).append(versionMinor)
				.append(monitorUserSel).append(tnActivation)
				.append(defaultSystemDomain).append(esapCluster).toHashCode();
	}

	@Override
	public boolean equals(Object other) {
		if (other == this) {
			return true;
		}
		if ((other instanceof BsAsConfigData) == false) {
			return false;
		}
		BsAsConfigData rhs = ((BsAsConfigData) other);
		return new EqualsBuilder().append(bsAsId, rhs.bsAsId)
				.append(asName, rhs.asName).append(asClli, rhs.asClli)
				.append(asIpAddress, rhs.asIpAddress)
				.append(asPort, rhs.asPort)
				.append(asGroupWebLink, rhs.asGroupWebLink)
				.append(asGlobalWebLink, rhs.asGlobalWebLink)
				.append(version, rhs.version).append(asProfile, rhs.asProfile)
				.append(proxyClusterId, rhs.proxyClusterId)
				.append(cappedFlag, rhs.cappedFlag)
				.append(overrideCappedFlag, rhs.overrideCappedFlag)
				.append(displayIndicator, rhs.displayIndicator)
				.append(activeIndicator, rhs.activeIndicator)
				.append(modifiedBy, rhs.modifiedBy)
				.append(lastModifiedDate, rhs.lastModifiedDate)
				.append(envOrderId, rhs.envOrderId)
				.append(bsNodeName, rhs.bsNodeName)
				.append(asSecIpAddress, rhs.asSecIpAddress)
				.append(asSecPort, rhs.asSecPort)
				.append(clusterHostName, rhs.clusterHostName)
				.append(wServerIp, rhs.wServerIp)
				.append(versionMinor, rhs.versionMinor)
				.append(monitorUserSel, rhs.monitorUserSel)
				.append(tnActivation, rhs.tnActivation)
				.append(defaultSystemDomain, rhs.defaultSystemDomain)
				.append(esapCluster, rhs.esapCluster).isEquals();
	}

}
