package com.vz.fxo.inventory.enterprise.service;

import com.vz.esap.api.model.ResponseObject;
import com.vz.fxo.inventory.enterprise.support.VzbInvException;
import com.vz.fxo.inventory.model.pc.VoipOrderResponse;

public interface NotificationService {
	
	/**
	 * @param voipOrderResponse
	 * @return responseObject
	 * @throws GenericException 
	 */
	public ResponseObject notifyFailures(VoipOrderResponse voipOrderResponse) throws VzbInvException;
	

	/**
	 * @param voipOrderResponse
	 * @return responseObject
	 * @throws GenericException 
	 * @throws VzbInvException 
	 */
	public ResponseObject notifySuccess(VoipOrderResponse voipOrderResponse) throws  VzbInvException;



}
