/**
 * 
 */
package com.vz.esap.api.model;

/**
 * @author Deepak Kumar
 * 
 */
public class DeviceClliServiceRequest {

	private String baseClli;
	private String clli;
	private String droTimeOut;
	private String loopBackOn;
	private String officeId;
	private String region;
	private String switchType;
	private String switchVer;

	
	/**
	 * @return the baseClli
	 */
	public String getBaseClli() {
		return baseClli;
	}

	/**
	 * @param baseClli
	 *            the baseClli to set
	 */
	public void setBaseClli(String baseClli) {
		this.baseClli = baseClli;
	}

	/**
	 * @return the clli
	 */
	public String getClli() {
		return clli;
	}

	/**
	 * @param clli
	 *            the clli to set
	 */
	public void setClli(String clli) {
		this.clli = clli;
	}

	/**
	 * @return the droTimeOut
	 */
	public String getDroTimeOut() {
		return droTimeOut;
	}

	/**
	 * @param droTimeOut
	 *            the droTimeOut to set
	 */
	public void setDroTimeOut(String droTimeOut) {
		this.droTimeOut = droTimeOut;
	}

	/**
	 * @return the loopBackOn
	 */
	public String getLoopBackOn() {
		return loopBackOn;
	}

	/**
	 * @param loopBackOn
	 *            the loopBackOn to set
	 */
	public void setLoopBackOn(String loopBackOn) {
		this.loopBackOn = loopBackOn;
	}

	/**
	 * @return the officeId
	 */
	public String getOfficeId() {
		return officeId;
	}

	/**
	 * @param officeId
	 *            the officeId to set
	 */
	public void setOfficeId(String officeId) {
		this.officeId = officeId;
	}

	/**
	 * @return the region
	 */
	public String getRegion() {
		return region;
	}

	/**
	 * @param region
	 *            the region to set
	 */
	public void setRegion(String region) {
		this.region = region;
	}

	/**
	 * @return the switchType
	 */
	public String getSwitchType() {
		return switchType;
	}

	/**
	 * @param switchType
	 *            the switchType to set
	 */
	public void setSwitchType(String switchType) {
		this.switchType = switchType;
	}

	/**
	 * @return the switchVer
	 */
	public String getSwitchVer() {
		return switchVer;
	}

	/**
	 * @param switchVer
	 *            the switchVer to set
	 */
	public void setSwitchVer(String switchVer) {
		this.switchVer = switchVer;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "ConfigDomainServiceRequest [baseClli=" + baseClli + ", clli="
				+ clli + ", droTimeOut=" + droTimeOut + ", loopBackOn="
				+ loopBackOn + ", officeId=" + officeId + ", region=" + region
				+ ", switchType=" + switchType + ", switchVer=" + switchVer
				+ "]";
	}

}
