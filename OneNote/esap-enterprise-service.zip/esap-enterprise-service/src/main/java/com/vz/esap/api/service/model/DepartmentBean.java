package com.vz.esap.api.service.model;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

public class DepartmentBean {
	//members
	protected String departmentId;
	protected String enterpriseId;
	protected String parentDeptId;
	protected String departmentName;
	protected String contactNumber;
	protected String contactName;
	protected long callingPlanId;
	protected long activeInd;
	protected String createdBy;
	protected String modifiedBy;
	protected Timestamp creationDate;
	protected Timestamp lastModifiedDate;
	protected List<String> logTrail;
	protected long envOrderId;

	/**
	 * Default Constructor -- Initializes all fields to default values.
	 */
	public DepartmentBean() {
		this.departmentId = new String("");
		this.enterpriseId = new String("");
		this.parentDeptId = new String("NONE");
		this.departmentName = new String("NONE");
		this.contactNumber = new String("NONE");
		this.contactName = new String("NONE");
		this.callingPlanId = -1;
		this.createdBy = new String("NONE");
		this.modifiedBy = new String("NONE");
		this.creationDate = null;
		this.lastModifiedDate = null;
		this.logTrail = new ArrayList<String>();
		this.activeInd = 1;
		this.envOrderId = 0;
	}
	/**
	 * Constructor
	 * @param departmentBean
	 */
	public DepartmentBean(DepartmentBean departmentBean) {
		this.departmentId = departmentBean.departmentId;
		this.enterpriseId = departmentBean.enterpriseId;
		this.parentDeptId = departmentBean.parentDeptId;
		this.departmentName = departmentBean.departmentName;
		this.contactNumber = departmentBean.contactNumber;
		this.contactName = departmentBean.contactName;
		this.callingPlanId = departmentBean.callingPlanId;
		this.createdBy = departmentBean.createdBy;
		this.modifiedBy = departmentBean.modifiedBy;
		this.creationDate = departmentBean.creationDate;
		this.lastModifiedDate = departmentBean.lastModifiedDate;
		this.logTrail = departmentBean.logTrail;
		this.activeInd = departmentBean.activeInd;
		this.envOrderId = departmentBean.envOrderId ;
	}

	public String getDepartmentId() {
		return departmentId;
	}
	public void setDepartmentId(String departmentId) {
		this.departmentId = departmentId;
	}
	public String getEnterpriseId() {
		return enterpriseId;
	}

	public void setEnterpriseId(String enterpriseId) {
		this.enterpriseId = enterpriseId;
	}
	public String getParentDeptId() {
		return parentDeptId;
	}
	public void setParentDeptId(String parentDeptId) {
		this.parentDeptId = parentDeptId;
	}
	public String getDepartmentName() {
		return departmentName;
	}
	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}
	public String getContactNumber() {
		return contactNumber;
	}
	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}
	public String getContactName() {
		return contactName;
	}
	public void setContactName(String contactName) {
		this.contactName = contactName;
	}
	public long getCallingPlanId() {
		return callingPlanId;
	}
	public void setCallingPlanId(long callingPlanId) {
		this.callingPlanId = callingPlanId;
	}
	public String getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public Timestamp getCreationDate() {
		return this.creationDate;
	}
	public void setCreationDate(Timestamp creationDate) {
		this.creationDate = creationDate;
	}
	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}
	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public void setLogTrail(String logStr) {
		logTrail.add(logStr);
	}

	public List<String> getLogTrail() {
		return logTrail;
	}
	public long getActiveInd() {
        	return activeInd;
    	}
    	public void setActiveInd(long activeInd) {
        	this.activeInd = activeInd;
    	}

    /*
    compare two DepartmentBean objs by comparing their department ids
    */
    public boolean equals(Object obj) {

        if (obj==null)
            return false;

        String deptid = ((DepartmentBean)obj).getDepartmentId();

        if (deptid==null)
            return false;

        return (deptid.equals(getDepartmentId()) );
    }

    public String toString() {
        return ""+getDepartmentId();
    }

    public int hashCode() {

        //if dept id is a number return it, else return a default 0
        try {
            return new Integer(getDepartmentId()).intValue();
        } catch (Throwable t) {
            //err
        }

        return 0;
    }

	public long getEnvOrderId() {
		return envOrderId;
	}
	public void setEnvOrderId(long envOrderId) {
		this.envOrderId = envOrderId;
	}

}
