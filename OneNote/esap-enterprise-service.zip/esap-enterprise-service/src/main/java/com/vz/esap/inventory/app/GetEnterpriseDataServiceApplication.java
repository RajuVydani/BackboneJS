package com.vz.esap.inventory.app;

/**
 * @author Siva Adabala
 *
 */


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.context.annotation.ComponentScan;

@EnableDiscoveryClient
@SpringBootApplication
@ComponentScan("com.vz")
public class GetEnterpriseDataServiceApplication {
 
	public static void main(String[] args) {
		System.out.println("Started...!!!");
        SpringApplication.run(GetEnterpriseDataServiceApplication.class, args);
        System.out.println("Booted...!!!");
	}
	
}