package com.vz.fxo.inventory.enterprise.support;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Timestamp;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import esap.db.DBTblSipDeviceInfo;
import esap.db.TblDeviceMapQuery;
import esap.db.TblSipDeviceInfoDbBean;
import esap.db.TblSipDeviceInfoQuery;
import esap.db.TblSubscriberDeviceQuery;


public class SipDevice extends SipDeviceBean
{
	private static Logger log = LoggerFactory.getLogger(SipDevice.class.toString());
	//members
	private Connection connection;
	//private String statusCode;
	//private String statusDesc;
	
	public SipDevice(Connection con)
	{
		this.connection = con;
	}
	public SipDevice(Connection con, SipDeviceBean sipDeviceBean)
	{
		super(sipDeviceBean);
		this.connection = con;
	}
	
	//getters - setters
	InvErrorCode status = InvErrorCode.INTERNAL_ERROR;
	public int getStatusCode() {
		return status.getErrorCode();
	}

	public void setStatus(InvErrorCode status) {
		this.status = status;
	}

	public String getStatusDesc() {
		return status.getErrorDesc();
	}

	public Connection getConnection() {
		return connection;
	}

	public void setConnection(Connection connection) {
		this.connection = connection;
	}

	public void populateSipDeviceBean(TblSipDeviceInfoDbBean sipDvBean)
	{
		log.info("Entering SipDevice::populateSipDeviceBean");
		setSipDeviceId(sipDvBean.getSipDeviceId());
		setBsDeviceId(sipDvBean.getBsDeviceId());
		setDeviceName(sipDvBean.getDeviceName());
		setDeviceTypeId(sipDvBean.getDeviceTypeId());
		setMacAddress(sipDvBean.getMacAddress());
		setIpAddress(sipDvBean.getIpAddress());
		setIpSecAddress(sipDvBean.getIpSecAddress());
		setSerialNumber(sipDvBean.getSerialNumber());
		setPortsAvailable(sipDvBean.getPortsAvailable());
		setCpeUserName(sipDvBean.getCpeUsername());
		setCpePassword(sipDvBean.getCpePassword());
		//Jan 2011 Release changes
		setCpeNetworkFeatures(sipDvBean.getCpeNetworkFeatures());
		setCodecId(sipDvBean.getCodecId());
		setBusinessLocation(sipDvBean.getBusinessLocation());
		setStationLocation(sipDvBean.getStationLocation());
		setDeviceLocation(sipDvBean.getDeviceLocation());
		setFirmwareVersionId(sipDvBean.getFirmwareVersionId());
                setEnvOrderId(sipDvBean.getEnvOrderId()); 
		setCreatedBy(sipDvBean.getCreatedBy());
		setCreationDate(sipDvBean.getCreationDate());
		setModifiedBy(sipDvBean.getModifiedBy());
		setLastModifiedDate(sipDvBean.getLastModifiedDate());
		setBrixInd(sipDvBean.getBrixInd());
		setInternalAdmin(sipDvBean.getInternalAdmin());
	}
	
	public boolean getSipDeviceDetailsBySipDeviceId() 
	{
		log.info("Entering Device::getSipDeviceDetailsBySipDeviceId");
		
		try
		{
			TblSipDeviceInfoQuery sipDvQry = new TblSipDeviceInfoQuery();
			sipDvQry.whereSipDeviceIdEQ(getSipDeviceId());
			sipDvQry.query(connection);
			if(sipDvQry.size() <= 0)
			{
				setStatus(InvErrorCode.INTERNAL_ERROR);
				log.info("Sip Device not Found");
				return false;
			}
			TblSipDeviceInfoDbBean sipDvBean = sipDvQry.getDbBean(0);
			populateSipDeviceBean(sipDvBean);
			if(getDeviceTypeId() > 0)
			{
				DeviceType devType = new DeviceType(connection);
				devType.setDeviceTypeId((int)getDeviceTypeId());
				if(devType.getDetails())
					deviceTypeBean = devType;
			}
			
		}
		catch(SQLException s)
		{
			s.printStackTrace();
			setStatus(InvErrorCode.DB_EXCEPTION);
			return false;
		}

		setStatus(InvErrorCode.SUCCESS);
		return true;
	}
			
	public boolean validateSipDevice()
	{
		return true;
	}
	
	public boolean addSipDevice() throws SQLException, Exception
	{
		log.info("Entering SipDevice::addSipDevice");
        log.info("SipDeviceId = " + getSipDeviceId());
		
		//try
		//{
			DBTblSipDeviceInfo sipDvDB = new DBTblSipDeviceInfo();
			if(getSipDeviceId() > 0)
				sipDvDB.setSipDeviceId(getSipDeviceId());
			else
			{ 
			
				int sipDvSeqId = sipDvDB.getSipDeviceIdSeqNextVal(connection);
				sipDvDB.setSipDeviceId(sipDvSeqId);
				setSipDeviceId(sipDvSeqId);
			}
			if(!getBsDeviceId().equals("") && !getBsDeviceId().equals("NONE"))
				sipDvDB.setBsDeviceId(getBsDeviceId());
			else
			{
				sipDvDB.setBsDeviceId(Integer.toString(getSipDeviceId()));
			}
			
			if(!getDeviceName().equals("")) 
				sipDvDB.setDeviceName(getDeviceName());
			if(getDeviceTypeId() > -1)
				sipDvDB.setDeviceTypeId(getDeviceTypeId());
			else if((getDeviceTypeBean()).getDeviceTypeName() != null && (getDeviceTypeBean()).getDeviceTypeName() != "")
			{
				log.info("DeviceTypeName:"+(getDeviceTypeBean()).getDeviceTypeName());
				DeviceType devType = new DeviceType(connection,getDeviceTypeBean());

				if( devType.getDeviceTypeIdByDeviceTypeName() )
				{
					sipDvDB.setDeviceTypeId(devType.getDeviceTypeId());
				}
			}
			log.info("DeviceTyoeId:"+sipDvDB.getDeviceTypeId()+"SipDeviceId = " + getSipDeviceId());
			if(sipDvDB.getDeviceTypeId() <= 0)
			{
				//setStatus(InvErrorCode.SIP_DEVICE_DEVICE_TYPE_ID_NULL);
				//return false;
			}
			else
			{
				 DeviceType devType = new DeviceType(connection,getDeviceTypeBean());
				 devType.setDeviceTypeId((int)sipDvDB.getDeviceTypeId());

                if( devType.getDetails())
                {
					if(devType.getMaxNumPorts() <= 0)
						sipDvDB.setPortsAvailableNull();
					else
						sipDvDB.setPortsAvailable(devType.getMaxNumPorts());
                }

			}
			
			log.info("getMacAddress======> " +getMacAddress());
			
			if( !getMacAddress().equals("NONE")){
				sipDvDB.setMacAddress(getMacAddress());
			}
			else{
				sipDvDB.setMacAddressNull();
			}
			
			log.info("getIpAddress======> " +getIpAddress());	
			if( !getIpAddress().equals("NONE")){
				sipDvDB.setIpAddress(getIpAddress());
			}else{
				sipDvDB.setIpAddressNull();
			}
			
			log.info("getIpSecAddress()===>" +getIpSecAddress());
			
			if(!getIpSecAddress().equals("NONE"))
				sipDvDB.setIpSecAddress(getIpSecAddress());
			else{
				sipDvDB.setIpSecAddressNull();
			}
			log.info("getSerialNumber======> " +getSerialNumber());	
			
			if( !"NONE".equals(getSerialNumber()))
				sipDvDB.setSerialNumber(getSerialNumber());
			else{
				sipDvDB.setSerialNumberNull();
			}
			
			log.info("getCpeUserName======> " +getCpeUserName());
			if( !getCpeUserName().equals("NONE") )
				sipDvDB.setCpeUsername(getCpeUserName());
			else
				sipDvDB.setCpeUsernameNull();	
			
			log.info("getCpePassword======> " +getCpePassword());
			if( !getCpePassword().equals("NONE") )
				sipDvDB.setCpePassword(getCpePassword());
			else
				sipDvDB.setCpePasswordNull();	
			
			//Jan 2011 Release Changes  
			if (cpeNetworkFeatures != null && !cpeNetworkFeatures.equalsIgnoreCase("") && !cpeNetworkFeatures.equalsIgnoreCase("NONE") ){
				sipDvDB.setCpeNetworkFeatures(cpeNetworkFeatures);
			}
			log.info(" sipDvDB.setCpeNetworkFeatures() " + sipDvDB.getCpeNetworkFeatures());
			
			log.info("getCodecId====>" +getCodecId());
			if(getCodecId()!=-1){
				sipDvDB.setCodecId(getCodecId());
			}
			else{
				sipDvDB.setCodecId(0);
			}
			
			log.info("getBusinessLocation()===>" +getBusinessLocation());
			
			if( !getBusinessLocation().equals("NONE") )
				sipDvDB.setBusinessLocation(getBusinessLocation());
			else
				sipDvDB.setBusinessLocationNull();	
			
			log.info("getStationLocation()===>" +getStationLocation());
			
			if( !getStationLocation().equals("NONE") )
				sipDvDB.setStationLocation(getStationLocation());
			else
				sipDvDB.setStationLocationNull();	
			
			log.info("getDeviceLocation()===>" +getDeviceLocation());
			
			if(!getDeviceLocation().equals(""))
				sipDvDB.setDeviceLocation(getDeviceLocation());
			else
				sipDvDB.setDeviceLocationNull();	
			
			log.info("getFirmwareVersionId()===>" +getFirmwareVersionId());
			
			
			
			if(getFirmwareVersionId() >0){
				sipDvDB.setFirmwareVersionId(getFirmwareVersionId());
			}
			
			
		        if(getEnvOrderId() > 0)
				sipDvDB.setEnvOrderId(getEnvOrderId()); 
			else
				sipDvDB.setEnvOrderIdNull(); 
                        if(getCreatedBy() != null && !getCreatedBy().equals(""))
		    	        sipDvDB.setCreatedBy(getCreatedBy());
		    else
		    	sipDvDB.setCreatedBy("ESAP_INV");
                        
            log.info("getBrixInd====>" + getBrixInd());
			if (getBrixInd() != -1) {
				sipDvDB.setBrixInd(getBrixInd());
			} 		
			
		    if(getModifiedBy() != null && !getModifiedBy().equals(""))
		    	sipDvDB.setModifiedBy(getModifiedBy());
		    else
		    	sipDvDB.setModifiedBy("ESAP_INV");
		    
            log.info("Codec = " +  getCodecId()); 
			
			sipDvDB.setInternalAdmin(getInternalAdmin());
            sipDvDB.setCreationDate(new Timestamp(System.currentTimeMillis()));
		    sipDvDB.setLastModifiedDate(new Timestamp(System.currentTimeMillis()));
		    sipDvDB.setPortsAssigned(0);
		    
		    log.info("sipDvDB====>" + sipDvDB);
		    FkValidationUtil.isValidSipDeviceInfo(connection,sipDvDB);
			sipDvDB.insert(connection);
		/*}		
		catch(SQLException s)
		{
			s.printStackTrace();
			setStatus(InvErrorCode.DB_EXCEPTION);
			return false;
		}*/

		return true;
	}
	
	public boolean deleteSipDevice() throws SQLException, Exception
	{
		log.info("Entering SipDevice::deleteSipDevice");

       // try
        //{
		if(sipDeviceId <= 0)
		{
			setStatus(InvErrorCode.SIP_DEVICE_DEVICE_TYPE_ID_NULL);
                                return false;
		}
            DBTblSipDeviceInfo sipDevDB = new DBTblSipDeviceInfo();
	    	sipDevDB.whereSipDeviceIdEQ(sipDeviceId);     
			int sipDevDeleted =sipDevDB.deleteByWhere(connection);
            log.info("Number of sipDevDeleted :"+sipDevDeleted);

        /*}
        catch (SQLException s)
        {
		s.printStackTrace();
		setStatus(InvErrorCode.DB_EXCEPTION);
            return false;
        }*/
        return true;
	}
	
	public boolean updateSipDevice() throws SQLException, Exception
	{
		//try
		//{
			if ( getSipDeviceId() <= 0) {
				setStatus(InvErrorCode.SIP_DEVICE_DEVICE_TYPE_ID_NULL);
				log.info("FAILURE in updateSipDevice SipDevice. SipDeviceId missing.");
				return false;
			}
			

			log.info("before call");
			DBTblSipDeviceInfo sipDeviceBean = getSipDeviceToUpdate();
			log.info("sipDevBean.getSipDeviceId():"+sipDeviceBean.getSipDeviceId());
			log.info("sipDevBean.getSerialNumber():"+sipDeviceBean.getSerialNumber());
			sipDeviceBean.whereSipDeviceIdEQ(sipDeviceId);
			FkValidationUtil.isValidSipDeviceInfoForMod(connection,sipDeviceBean);
	                if (sipDeviceBean.updateSpByWhere(connection) <= 0)
				return false; 	
                 	log.info("after update");
/*		} catch(SQLException s) {
			 s.printStackTrace();
			 setStatus(InvErrorCode.DB_EXCEPTION);
			log.info("DB_FAILURE in updateSipDevice SipDevice");
			return false;
		}*/
		setStatus(InvErrorCode.SUCCESS);
		return true;
	}

    /**
	 * The current Sip details are extracted using getDetails()
	 * and the new field values are updated over that. The method
	 * will update the fields that are supplied on the current instance
	 * iff they are different from the default values for the respective field.
	 *
	 * @return The SipDevice to be updated.
     * @throws SQLException 
	 */
	private DBTblSipDeviceInfo getSipDeviceToUpdate() throws SQLException {
		DBTblSipDeviceInfo sipDeviceinfoDbBean = new DBTblSipDeviceInfo();

		/* Create a new instance of SipDeviceBean. The new instance
		 * would hold default values for the all the Sip Device fields.*/
		SipDeviceBean defaultSipDeviceBean = new SipDeviceBean();

		SipDevice inputSipDevice = this;

		/*Set the new fields if required.*/
		sipDeviceinfoDbBean.setSipDeviceId(getSipDeviceId());
		log.info("inputSipDevice.getBsDeviceId()======> " +inputSipDevice.getBsDeviceId());
		if ( inputSipDevice.getBsDeviceId() != null &&
				!inputSipDevice.getBsDeviceId().equals(defaultSipDeviceBean.getBsDeviceId()) ){
			sipDeviceinfoDbBean.setBsDeviceId(inputSipDevice.getBsDeviceId());
		}
		
		log.info("inputSipDevice.getDeviceName()======> " +inputSipDevice.getDeviceName());
		
		if ( inputSipDevice.getDeviceName() != null &&
				!inputSipDevice.getDeviceName().equals(defaultSipDeviceBean.getDeviceName()) ){
			sipDeviceinfoDbBean.setDeviceName(inputSipDevice.getDeviceName());
		}
		
		log.info("inputSipDevice.getDeviceTypeId()======> " +inputSipDevice.getDeviceTypeId());
		if ( inputSipDevice.getDeviceTypeId() != defaultSipDeviceBean.getDeviceTypeId()){
			sipDeviceinfoDbBean.setDeviceTypeId(inputSipDevice.getDeviceTypeId());
		}

		if ( inputSipDevice.getMacAddress() != null &&
			!inputSipDevice.getMacAddress().equals(defaultSipDeviceBean.getMacAddress()) ){
			sipDeviceinfoDbBean.setMacAddress(inputSipDevice.getMacAddress());
		}
		
		log.info("inputSipDevice.getMacAddress()==>"+inputSipDevice.getMacAddress());
		if("".equals(inputSipDevice.getMacAddress())){
			sipDeviceinfoDbBean.setMacAddressNull();
		}
		
		log.info("inputSipDevice.getIpAddress()==>"+inputSipDevice.getIpAddress());
		if ( inputSipDevice.getIpAddress() != null &&
                        !inputSipDevice.getIpAddress().equals(defaultSipDeviceBean.getIpAddress()) ){
                        sipDeviceinfoDbBean.setIpAddress(inputSipDevice.getIpAddress());
                }
		
		if("".equals(inputSipDevice.getIpAddress())){
			sipDeviceinfoDbBean.setIpAddressNull();
		}
		
		log.info("inputSipDevice.getIpAddress()==>"+inputSipDevice.getIpSecAddress());
		
		if ( inputSipDevice.getIpSecAddress() != null &&
                        !inputSipDevice.getIpSecAddress().equals(defaultSipDeviceBean.getIpSecAddress()) ){
                        sipDeviceinfoDbBean.setIpSecAddress(inputSipDevice.getIpSecAddress());
                }
		log.info("#########################################");
		log.info("inputSipDevice.getSerialNumber()======> " +inputSipDevice.getSerialNumber());
		log.info("defaultSipDeviceBean.getSerialNumber()======> " +defaultSipDeviceBean.getSerialNumber());
		log.info("#########################################");
		
		if ( inputSipDevice.getSerialNumber() != null &&
			!inputSipDevice.getSerialNumber().equals(defaultSipDeviceBean.getSerialNumber()) ){
			sipDeviceinfoDbBean.setSerialNumber(inputSipDevice.getSerialNumber());
		}
		
		if("".equals(inputSipDevice.getSerialNumber())){
			sipDeviceinfoDbBean.setSerialNumberNull();
		}
		
		log.info("inputSipDevice.getPortsAvailable()==>"+inputSipDevice.getPortsAvailable());
		if ( inputSipDevice.getPortsAvailable() != defaultSipDeviceBean.getPortsAvailable()) {
			sipDeviceinfoDbBean.setPortsAvailable(inputSipDevice.getPortsAvailable());
		}
		
		if(inputSipDevice.getPortsAvailable()==0){
			sipDeviceinfoDbBean.setPortsAvailableNull();
		}
		
		log.info("inputSipDevice.getIpAddress()==>"+inputSipDevice.getCpeUserName());
		if ( inputSipDevice.getCpeUserName() != null &&
			!inputSipDevice.getCpeUserName().equals(defaultSipDeviceBean.getCpeUserName()) ){
			sipDeviceinfoDbBean.setCpeUsername(inputSipDevice.getCpeUserName());
		}
		
		if("".equals(inputSipDevice.getCpeUserName())){
			sipDeviceinfoDbBean.setCpeUsernameNull();
		}
		
		log.info("inputSipDevice.getIpAddress()==>"+inputSipDevice.getCpePassword());
		if ( inputSipDevice.getCpePassword() != null &&
			!inputSipDevice.getCpePassword().equals(defaultSipDeviceBean.getCpePassword()) ){
			sipDeviceinfoDbBean.setCpePassword(inputSipDevice.getCpePassword());
		}
		
		if("".equals(inputSipDevice.getCpePassword())){
			sipDeviceinfoDbBean.setCpePasswordNull();
		}
		
		//Jan 2011 Release changes
		if( inputSipDevice.getCpeNetworkFeatures() != null && 
				!inputSipDevice.getCpeNetworkFeatures().equals(defaultSipDeviceBean.getCpeNetworkFeatures())){
			sipDeviceinfoDbBean.setCpeNetworkFeatures(inputSipDevice.getCpeNetworkFeatures());
		}
		log.info(" sipDeviceinfoDbBean.getCpeNetworkFeatures " +  sipDeviceinfoDbBean.getCpeNetworkFeatures() );
		
		log.info("inputSipDevice.getCodecId()==>"+inputSipDevice.getCodecId());
		if ( inputSipDevice.getCodecId() != defaultSipDeviceBean.getCodecId() && inputSipDevice.getCodecId() >= 0){
			sipDeviceinfoDbBean.setCodecId(inputSipDevice.getCodecId());
		}
		
		log.info("inputSipDevice.getBusinessLocation()==>"+inputSipDevice.getBusinessLocation());
		if ( inputSipDevice.getBusinessLocation() != null &&
			!inputSipDevice.getBusinessLocation().equals(defaultSipDeviceBean.getBusinessLocation()) ){
			sipDeviceinfoDbBean.setBusinessLocation(inputSipDevice.getBusinessLocation());
		}
		
		if("".equals(inputSipDevice.getBusinessLocation())){
			sipDeviceinfoDbBean.setBusinessLocationNull();
		}
		
		log.info("inputSipDevice.getBrixInd()==>"+inputSipDevice.getBrixInd());
		if ( inputSipDevice.getBrixInd() != defaultSipDeviceBean.getBrixInd()){
			sipDeviceinfoDbBean.setBrixInd(inputSipDevice.getBrixInd());
		}
		
		if(inputSipDevice.getBrixInd()==0){
			sipDeviceinfoDbBean.setBrixIndNull();
		}
		
		log.info("inputSipDevice.getStationLocation()==>"+inputSipDevice.getStationLocation());
		if ( inputSipDevice.getStationLocation() != null &&
			!inputSipDevice.getStationLocation().equals(defaultSipDeviceBean.getStationLocation()) ){
			sipDeviceinfoDbBean.setStationLocation(inputSipDevice.getStationLocation());
		}
		
		if("".equals(inputSipDevice.getStationLocation())){
			sipDeviceinfoDbBean.setStationLocationNull();
		}
		
		log.info("inputSipDevice.getDeviceLocation()==>"+inputSipDevice.getDeviceLocation());
		if ( inputSipDevice.getDeviceLocation() != null &&
			!inputSipDevice.getDeviceLocation().equals(defaultSipDeviceBean.getDeviceLocation()) ){
			sipDeviceinfoDbBean.setDeviceLocation(inputSipDevice.getDeviceLocation());
		}
		
		if("".equals(inputSipDevice.getDeviceLocation())){
			sipDeviceinfoDbBean.setDeviceLocationNull();
		}
		
		log.info("inputSipDevice.getFirmwareVersionId()==>"+inputSipDevice.getFirmwareVersionId());
		if ((inputSipDevice.getFirmwareVersionId() != defaultSipDeviceBean.getFirmwareVersionId()) &&
				(inputSipDevice.getFirmwareVersionId()!=0)){
			sipDeviceinfoDbBean.setFirmwareVersionId(inputSipDevice.getFirmwareVersionId());
		}
		
		if(inputSipDevice.getFirmwareVersionId()==0){
			sipDeviceinfoDbBean.setFirmwareVersionIdNull();
		}
		
		if(inputSipDevice.getInternalAdmin() != defaultSipDeviceBean.getInternalAdmin())
		{
			sipDeviceinfoDbBean.setInternalAdmin(inputSipDevice.getInternalAdmin());
		}
		
		if ( inputSipDevice.getIsManaged() != defaultSipDeviceBean.getIsManaged()){
			sipDeviceinfoDbBean.setIsManaged(inputSipDevice.getIsManaged());
		}
                if ( inputSipDevice.getEnvOrderId() != defaultSipDeviceBean.getEnvOrderId()){
			sipDeviceinfoDbBean.setEnvOrderId(inputSipDevice.getEnvOrderId());
		}      
		if( inputSipDevice.getModifiedBy() != null &&
				!( "".equalsIgnoreCase(inputSipDevice.getModifiedBy()) ) ) {
			sipDeviceinfoDbBean.setModifiedBy(inputSipDevice.getModifiedBy());
		} else {
			sipDeviceinfoDbBean.setModifiedBy("ESAP_INV");
	    	}

		sipDeviceinfoDbBean.setLastModifiedDate(new Timestamp(System.currentTimeMillis()));
		log.info("sipDeviceinfoDbBean===> " +sipDeviceinfoDbBean);
		return sipDeviceinfoDbBean;
	}

	public boolean getDetails() 
	{
		try
		{
			log.info("In sipDevice getDetails; Sip device id="+getSipDeviceId());
			TblSipDeviceInfoQuery sipDeviceQry = new TblSipDeviceInfoQuery();
			String whereClause = " where sip_device_id = \'"+getSipDeviceId()+"\'";
			sipDeviceQry.queryByWhere(connection, whereClause);
			if(sipDeviceQry.size() == 1){
				this.setBsDeviceId((sipDeviceQry.getDbBean(0)).getBsDeviceId());
				this.setDeviceName((sipDeviceQry.getDbBean(0)).getDeviceName());
				this.setDeviceTypeId((sipDeviceQry.getDbBean(0)).getDeviceTypeId());
				this.setMacAddress((sipDeviceQry.getDbBean(0)).getMacAddress());
				this.setIpAddress((sipDeviceQry.getDbBean(0)).getIpAddress());
				this.setIpSecAddress((sipDeviceQry.getDbBean(0)).getIpSecAddress());
				this.setSerialNumber((sipDeviceQry.getDbBean(0)).getSerialNumber());
				this.setPortsAssigned((sipDeviceQry.getDbBean(0)).getPortsAssigned());
				this.setPortsAvailable((sipDeviceQry.getDbBean(0)).getPortsAvailable());
				this.setCpeUserName((sipDeviceQry.getDbBean(0)).getCpeUsername());
				this.setCodecId((sipDeviceQry.getDbBean(0)).getCodecId());
				this.setBrixInd((sipDeviceQry.getDbBean(0)).getBrixInd());
				//Jan 2011 Release changes
				this.setCpeNetworkFeatures(sipDeviceQry.getDbBean(0).getCpeNetworkFeatures());
				this.setBusinessLocation((sipDeviceQry.getDbBean(0)).getBusinessLocation());
				this.setStationLocation((sipDeviceQry.getDbBean(0)).getStationLocation());
				this.setDeviceLocation((sipDeviceQry.getDbBean(0)).getDeviceLocation());
				this.setFirmwareVersionId((sipDeviceQry.getDbBean(0)).getFirmwareVersionId());
				this.setIsManaged((sipDeviceQry.getDbBean(0)).getIsManaged());
				this.setInternalAdmin((sipDeviceQry.getDbBean(0)).getInternalAdmin());
                this.setEnvOrderId((sipDeviceQry.getDbBean(0)).getEnvOrderId()); 	
        		this.setCreatedBy((sipDeviceQry.getDbBean(0)).getCreatedBy());
				this.setCreationDate((sipDeviceQry.getDbBean(0)).getCreationDate());
				this.setModifiedBy((sipDeviceQry.getDbBean(0)).getModifiedBy());
				this.setLastModifiedDate((sipDeviceQry.getDbBean(0)).getLastModifiedDate());
				
			}else
			{
				setStatus(InvErrorCode.NO_DEVICE_RECORD_FOUND);
				return false;
			}
			
		}catch(SQLException s)
		{
			s.printStackTrace();
			setStatus(InvErrorCode.DB_EXCEPTION);
			return false;
		}
		setStatus(InvErrorCode.SUCCESS);
		return true;
	}

	public long getLinesAssigned()
	{
		long linesAssigned = 0;
		try
		{
		if(sipDeviceId <= 0)
        {
			log.info("Invalid input, hjave to set sipDeviceId");
			setStatus(InvErrorCode.SIP_DEVICE_DEVICE_TYPE_ID_NULL);
            return 0;
        }
		TblDeviceMapQuery devQry = new TblDeviceMapQuery();
		devQry.whereSipDeviceIdEQ(sipDeviceId);
		devQry.query(connection);
		if(devQry.size() <= 0)
		{
			log.info("INvalid Device");
			return 0;
		}
		TblSubscriberDeviceQuery subDevQry = new TblSubscriberDeviceQuery();
		subDevQry.whereDeviceMapIdEQ(devQry.getDbBean(0).getDeviceMapId());
		subDevQry.query(connection);
		linesAssigned = subDevQry.size();
		}
		catch(SQLException s)
        {
            s.printStackTrace();
            setStatus(InvErrorCode.DB_EXCEPTION);
            return 0;

        }

		return linesAssigned;
	}
}
