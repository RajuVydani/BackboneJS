package com.vz.fxo.inventory.enterprise.service;

import java.sql.Connection;
import java.sql.SQLException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.vz.esap.api.connector.service.impl.ConfigDomainDataServiceImpl;
import com.vz.esap.api.connector.service.impl.InventoryDomainDataServiceImpl;
import com.vz.esap.api.connector.service.impl.OrderDomainDataServiceImpl;
import com.vz.esap.api.connector.service.impl.OrderLogServiceImpl;
import com.vz.esap.api.model.InventoryServiceRequest;
import com.vz.esap.api.model.ESAPEntityEnum;
import com.vz.fxo.inventory.enterprise.GenericActionFunction;
//import com.vz.esap.inventory.tn.helper.ServiceHelper;
import com.vz.fxo.inventory.enterprise.helper.FxoInventoryErrorEntityMgmtHelper;
import com.vz.fxo.inventory.enterprise.helper.FxoServiceHelper;

@Component
public class ActionFunctionHelper {

	private static Logger log = LoggerFactory
			.getLogger(ActionFunctionHelper.class.toString());
      public <T extends GenericActionFunction> GenericActionFunction getActionFunctionImpl(T obj,
                  InventoryServiceRequest request,ConfigDomainDataServiceImpl configDomainDataService,
                  OrderDomainDataServiceImpl  orderDomainDataService,
                  OrderLogServiceImpl orderLogService,
                  InventoryDomainDataServiceImpl inventoryDomainDataService,
                  FxoInventoryErrorEntityMgmtHelper bsErrorEntityMgmtHelper,
                  Connection connection) throws SQLException {

    	    FxoServiceHelper.setRequestAttributes(request, obj, ESAPEntityEnum.ENTERPRISE.toString());
	        obj.setConfigDomainDataService(configDomainDataService);
	        obj.setOrderDomainDataService(orderDomainDataService);
	        obj.setOrderLogService(orderLogService);
	        obj.setInventoryDomainDataService(inventoryDomainDataService);
	        obj.setBsErrorEntityMgmtHelper(bsErrorEntityMgmtHelper);
	        obj.setConnection(connection);

            return obj;
      }
      
      public <T extends GenericActionFunction> GenericActionFunction getLocActionFunctionImpl(T obj,
  			InventoryServiceRequest request, ConfigDomainDataServiceImpl configDomainDataService,
            OrderDomainDataServiceImpl  orderDomainDataService,
            OrderLogServiceImpl orderLogService,
            InventoryDomainDataServiceImpl inventoryDomainDataService,
            FxoInventoryErrorEntityMgmtHelper bsErrorEntityMgmtHelper,
            Connection connection) throws SQLException {

  		FxoServiceHelper.setRequestAttributes(request, obj, ESAPEntityEnum.LOCATION.toString());
  		obj.setConfigDomainDataService(configDomainDataService);
  		obj.setOrderDomainDataService(orderDomainDataService);
  		obj.setOrderLogService(orderLogService);
  		obj.setInventoryDomainDataService(inventoryDomainDataService);
  		obj.setBsErrorEntityMgmtHelper(bsErrorEntityMgmtHelper);
  		obj.setConnection(connection);

  		return obj;
  	}
      
      public static void closeDBConnection(GenericActionFunction obj) {
  		if (obj!= null && obj.getConnection() != null){
  			try {
  				obj.getConnection().close();
  			} catch (SQLException e) {
  				log.error("Error whiling closing SQL Connection",e);
  			}
  		}
  	}		


}
