package com.vz.fxo.inventory.enterprise.support;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.sql.*;


public class EsipEnterpriseTrunkBean implements Serializable {

	
    protected String enterpriseTrunkId;
    protected String enterpriseTrunkName;
    protected String enterpriseId;
    protected String bwEnterpriseTrunkId;
	protected String bwEnterpriseId;
    protected String enterpriseTrunkType;
    protected String maxRerouteAttempts; 
    protected String routeExhaustAction;  
    protected String orderingAlgoritham;
    protected String trunkGroupId;
    protected String trunkGroupName;    
    protected String createdBy;
    protected Timestamp creationDate;
    protected String modifiedBy;
    protected Timestamp lastModifiedDate;
    protected List<String> logTrail;
    
    public EsipEnterpriseTrunkBean(){
    	//this.enterpriseTrunkId="0";
    	this.enterpriseTrunkId=new String("");
    	this.enterpriseTrunkName=new String("");
    	this.enterpriseId=new String("");
    	//this.maxRerouteAttempts="0";
    	//this.routeExhaustAction="-1";
    	this.enterpriseTrunkType="";
    	this.maxRerouteAttempts="";
    	this.routeExhaustAction="";    	
     	this.bwEnterpriseTrunkId="";
     	this.bwEnterpriseId="";
     	this.orderingAlgoritham="";     	
     	this.trunkGroupId="";
     	this.trunkGroupName="";
    	this.createdBy = new String("");
        this.creationDate = null;
	    this.modifiedBy = new String("");
		this.lastModifiedDate = null;
		logTrail = new ArrayList<String>();
    	
    }
  
    
    public EsipEnterpriseTrunkBean(EsipEnterpriseTrunkBean esipEnterpriseTrunkBean){
    	
    	this.enterpriseTrunkId=esipEnterpriseTrunkBean.enterpriseTrunkId;
    	this.enterpriseTrunkName=esipEnterpriseTrunkBean.enterpriseTrunkName;
    	this.enterpriseId=esipEnterpriseTrunkBean.enterpriseId;
    	this.maxRerouteAttempts=esipEnterpriseTrunkBean.maxRerouteAttempts;
    	this.orderingAlgoritham=esipEnterpriseTrunkBean.orderingAlgoritham;
    	this.trunkGroupId=esipEnterpriseTrunkBean.trunkGroupId;
    	this.routeExhaustAction=esipEnterpriseTrunkBean.routeExhaustAction;
    	this.trunkGroupName=esipEnterpriseTrunkBean.trunkGroupName;
    	this.createdBy = esipEnterpriseTrunkBean.createdBy;
        this.creationDate = esipEnterpriseTrunkBean.creationDate;
	    this.modifiedBy = esipEnterpriseTrunkBean.modifiedBy;
		this.lastModifiedDate = esipEnterpriseTrunkBean.lastModifiedDate;	
		this.logTrail = esipEnterpriseTrunkBean.logTrail;
		
		this.enterpriseTrunkType=esipEnterpriseTrunkBean.enterpriseTrunkType;
    	this.bwEnterpriseId=esipEnterpriseTrunkBean.bwEnterpriseId;
    	this.bwEnterpriseTrunkId=esipEnterpriseTrunkBean.bwEnterpriseTrunkId;
    }
    
    /**
	 * @return the logTrail
	 */
	public List<String> getLogTrail() {
		return logTrail;
	}

	/**
	 * @param logTrail the logTrail to set
	 */
	public void setLogTrail(String logStr) {
		logTrail.add(logStr);
	}

	public String getEnterpriseTrunkId() {
		return enterpriseTrunkId;
	}

	public void setEnterpriseTrunkId(String enterpriseTrunkId) {
		this.enterpriseTrunkId = enterpriseTrunkId;
	}

	public String getEnterpriseTrunkName() {
		return enterpriseTrunkName;
	}

	public void setEnterpriseTrunkName(String enterpriseTrunkName) {
		this.enterpriseTrunkName = enterpriseTrunkName;
	}

	public String getEnterpriseId() {
		return enterpriseId;
	}

	public void setEnterpriseId(String enterpriseId) {
		this.enterpriseId = enterpriseId;
	}

	public String getMaxRerouteAttempts() {
		return maxRerouteAttempts;
	}

	public void setMaxRerouteAttempts(String maxRerouteAttempts) {
		this.maxRerouteAttempts = maxRerouteAttempts;
	}


	public String getRouteExhaustAction() {
		return routeExhaustAction;
	}

	public void setRouteExhaustAction(String routeExhaustAction) {
		this.routeExhaustAction = routeExhaustAction;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(Timestamp creationDate) {
		this.creationDate = creationDate;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Timestamp getLastModifiedDate() {
		return lastModifiedDate;
	}
	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}
    public String getBwEnterpriseTrunkId() {
		return bwEnterpriseTrunkId;
	}


	public void setBwEnterpriseTrunkId(String bwEnterpriseTrunkId) {
		this.bwEnterpriseTrunkId = bwEnterpriseTrunkId;
	}


	public String getBwEnterpriseId() {
		return bwEnterpriseId;
	}


	public void setBwEnterpriseId(String bwEnterpriseId) {
		this.bwEnterpriseId = bwEnterpriseId;
	}


	public String getEnterpriseTrunkType() {
		return enterpriseTrunkType;
	}


	public void setEnterpriseTrunkType(String enterpriseTrunkType) {
		this.enterpriseTrunkType = enterpriseTrunkType;
	}


	public String getOrderingAlgoritham() {
		return orderingAlgoritham;
	}


	public void setOrderingAlgoritham(String orderingAlgoritham) {
		orderingAlgoritham = orderingAlgoritham;
	}


	public String getTrunkGroupId() {
		return trunkGroupId;
	}


	public void setTrunkGroupId(String trunkGroupId) {
		this.trunkGroupId = trunkGroupId;
	}


	public String getTrunkGroupName() {
		return trunkGroupName;
	}


	public void setTrunkGroupName(String trunkGroupName) {
		this.trunkGroupName = trunkGroupName;
	}

	

}
