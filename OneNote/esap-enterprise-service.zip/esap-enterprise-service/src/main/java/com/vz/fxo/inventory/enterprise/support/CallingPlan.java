package com.vz.fxo.inventory.enterprise.support;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.HashMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import EsapEnumPkg.VzbVoipEnum;
import esap.db.DBTblCallingPlanDigits;
import esap.db.DBTblCallingPlans;
import esap.db.TblCallingPlanDigitsQuery;
import esap.db.TblCallingPlansDbBean;
import esap.db.TblCallingPlansQuery;
import esap.db.TblDepartmentQuery;
import esap.db.TblDigitStringsQuery;
import esap.db.TblEnterpriseQuery;
import esap.db.TblLocationQuery;
import esap.db.TblSubscriberQuery;

public class CallingPlan extends CallingPlanBean {

	private static Logger log = LoggerFactory.getLogger(CallingPlan.class
			.toString());
	private Connection dbCon;
	private InvErrorCode status = InvErrorCode.INTERNAL_ERROR;

	public int getStatusCode() {
		return status.getErrorCode();
	}

	public void setStatus(InvErrorCode status) {
		this.status = status;
	}

	public String getStatusDesc() {
		return status.getErrorDesc();
	}

	public Connection getDbCon() {
		return dbCon;
	}

	public void setDbCon(Connection dbCon) {
		this.dbCon = dbCon;
	}

	public CallingPlan(Connection dbCon) {
		this.dbCon = dbCon;
	}

	public CallingPlan(CallingPlanBean callingPlanBean, Connection dbCon) {
		super(callingPlanBean);
		this.dbCon = dbCon;
	}

	// Methods
	public boolean addToDB() throws SQLException, Exception {
		// try
		// {
		DBTblCallingPlans cpDbBean = new DBTblCallingPlans();

		cpDbBean.setCallingPlanId(getCallingPlanId());
		cpDbBean.setCallingPlanName(getCallingPlanName());
		if (getDefaultInd() != -1)
			cpDbBean.setDefaultInd(getDefaultInd());

		if (getIIntraLocation() != -1)
			cpDbBean.setIIntraLocation(getIIntraLocation());

		if (getIInterLocation() != -1)
			cpDbBean.setIInterLocation(getIInterLocation());

		if (getICollectCalls() != -1)
			cpDbBean.setICollectCalls(getICollectCalls());

		if (getOIntraLocation() != -1)
			cpDbBean.setOIntraLocation(getOIntraLocation());

		if (getOLocal() != -1)
			cpDbBean.setOLocal(getOLocal());

		if (getOTollFree() != -1)
			cpDbBean.setOTollFree(getOTollFree());

		if (getOToll() != -1)
			cpDbBean.setOToll(getOToll());

		if (getICollectCalls() != -1)
			cpDbBean.setOInternational(getOInternational());

		if (getOCasual() != -1)
			cpDbBean.setOCasual(getOCasual());

		if (getOOperatorAssisted() != -1)
			cpDbBean.setOOperatorAssisted(getOOperatorAssisted());

		if (getOChargedDirAssist() != -1)
			cpDbBean.setOChargedDirAssist(getOChargedDirAssist());

		if (getOSplServices1() != -1)
			cpDbBean.setOSplServices1(getOSplServices1());

		if (getOSplServices2() != -1)
			cpDbBean.setOSplServices2(getOSplServices2());

		if (getOPrmServices1() != -1)
			cpDbBean.setOPrmServices1(getOPrmServices1());

		if (getOPrmServices2() != -1)
			cpDbBean.setOPrmServices2(getOPrmServices2());

		if (getOUrlDialing() != -1)
			cpDbBean.setOUrlDialing(getOUrlDialing());

		if (getOUnknown() != -1)
			cpDbBean.setOUnknown(getOUnknown());

		if (getFIntraLocation() != -1)
			cpDbBean.setFIntraLocation(getFIntraLocation());

		if (getFLocal() != -1)
			cpDbBean.setFLocal(getFLocal());

		if (getFTollFree() != -1)
			cpDbBean.setFTollFree(getFTollFree());

		if (getFToll() != -1)
			cpDbBean.setFToll(getFToll());

		if (getFInternational() != -1)
			cpDbBean.setFInternational(getFInternational());

		if (getFCasual() != -1)
			cpDbBean.setFCasual(getFCasual());

		if (getFOperatorAssisted() != -1)
			cpDbBean.setFOperatorAssisted(getFOperatorAssisted());

		if (getFChargedDirAssist() != -1)
			cpDbBean.setFChargedDirAssist(getFChargedDirAssist());

		if (getFSplServices1() != -1)
			cpDbBean.setFSplServices1(getFSplServices1());

		if (getFSplServices2() != -1)
			cpDbBean.setFSplServices2(getFSplServices2());

		if (getFPrmServices1() != -1)
			cpDbBean.setFPrmServices1(getFPrmServices1());

		if (getFPrmServices2() != -1)
			cpDbBean.setFPrmServices2(getFPrmServices2());

		if (getFUrlDialing() != -1)
			cpDbBean.setFUrlDialing(getFUrlDialing());

		if (getFUnknown() != -1)
			cpDbBean.setFUnknown(getFUnknown());

		if (getBInterLocation() != -1)
			cpDbBean.setBInterLocation(getBInterLocation());

		if (getTelephone1() != null && !("NONE".equals(getTelephone1())))
			cpDbBean.setTelephone1(getTelephone1());

		if (getTelephone2() != null && !("NONE".equals(getTelephone2())))
			cpDbBean.setTelephone2(getTelephone2());

		if (getTelephone3() != null && !("NONE".equals(getTelephone3())))
			cpDbBean.setTelephone3(getTelephone3());

		if (getEnvOrderId() > 0)
			cpDbBean.setEnvOrderId(getEnvOrderId());
		cpDbBean.setModifiedBy("ESAP_INV");
		cpDbBean.setCreatedBy("ESAP_INV");
		cpDbBean.setLastModifiedDate(new Timestamp(System.currentTimeMillis()));
		cpDbBean.setCreationDate(new Timestamp(System.currentTimeMillis()));

		cpDbBean.insert(dbCon);
		/*
		 * } catch (SQLException s) { s.printStackTrace();
		 * setStatus(InvErrorCode.ERROR_ADDING_CALLING_PLAN);
		 * setLogTrail("CallingPlan::addToDB :: " + getStatusDesc()); return
		 * false; }
		 */
		setStatus(InvErrorCode.SUCCESS);
		setLogTrail("CallingPlan::addToDB :: Successfully Added.");
		return true;
	}

	public boolean deleteCallingPlan() throws SQLException, Exception

	{
		// try
		// {
		if (getCallingPlanId() <= 0) {
			setStatus(InvErrorCode.MISSING_CALLING_PLAN_ID);
			setLogTrail("CallingPlan::deleteCallingPlan :: " + getStatusDesc());
			return false;
		}

		log.info("CallingPlan::deleteCallingPlan :: " + getCallingPlanId());

		if (getCallingPlanId() == 1 || getCallingPlanId() == 0) {
			log.info("CallingPlan::deleteCallingPlan :: " + getCallingPlanId());
			return true;
		}

		// Check if calling plan is appearing as FK
		// in other related tables
		/*
		 * if (isCallingPlanTiedToEnterprise() || isCallingPlanTiedToLocation()
		 * || isCallingPlanTiedToDepartment() || isCallingPlanTiedToSubscriber()
		 * || isCallingPlanTiedToCallingPlanDigits()) { setLogTrail(
		 * "CallingPlan::deleteCallingPlan :: CallingPlan Tied to either of the following..."
		 * ); setLogTrail(
		 * "Enterprise , Location , Department , Subscriber , CallingPlanDigits"
		 * ); return false; }
		 */

		DigitString digitStringObj = new DigitString(dbCon);
		digitStringObj.setCallingPlanId(getCallingPlanId());
		digitStringObj.deleteCallingPlanDigits();

		log.info("In deleteCallingPlan:" + getCallingPlanId());
		DBTblCallingPlans callingPlanBean = new DBTblCallingPlans();
		callingPlanBean.whereCallingPlanIdEQ(getCallingPlanId());
		int callingPlansDeleted = callingPlanBean.deleteByWhere(dbCon);
		log.info("Number of callingPlans deleted:" + callingPlansDeleted);
		/*
		 * } catch (SQLException s) { s.printStackTrace();
		 * setStatus(InvErrorCode.ERROR_DELETING_CALLINGPLAN);
		 * setLogTrail("CallingPlan::deleteCallingPlan :: " + getStatusDesc());
		 * return false; }
		 */
		setStatus(InvErrorCode.SUCCESS);
		setLogTrail("CallingPlan::deleteCallingPlan :: Successfully Deleted. ID "
				+ getCallingPlanId());
		return true;
	}

	public boolean getDetails() {
		try {
			TblCallingPlansQuery cpQry = new TblCallingPlansQuery();

			cpQry.whereCallingPlanIdEQ(getCallingPlanId());
			cpQry.query(dbCon);

			if (cpQry.size() == 1) {
				TblCallingPlansDbBean cpBean = cpQry.getDbBean(0);

				setCallingPlanId(cpBean.getCallingPlanId());
				setCallingPlanName(cpBean.getCallingPlanName());
				setDefaultInd(cpBean.getDefaultInd());
				setIIntraLocation(cpBean.getIIntraLocation());
				setIInterLocation(cpBean.getIInterLocation());
				setICollectCalls(cpBean.getICollectCalls());
				setOIntraLocation(cpBean.getOIntraLocation());
				setOLocal(cpBean.getOLocal());
				setOTollFree(cpBean.getOTollFree());

				setOToll(cpBean.getOToll());

				setOInternational(cpBean.getOInternational());
				setOCasual(cpBean.getOCasual());
				setOOperatorAssisted(cpBean.getOOperatorAssisted());
				setOChargedDirAssist(cpBean.getOChargedDirAssist());
				setOSplServices1(cpBean.getOSplServices1());
				setOSplServices2(cpBean.getOSplServices2());
				setOPrmServices1(cpBean.getOPrmServices1());
				setOPrmServices2(cpBean.getOPrmServices2());
				setOUrlDialing(cpBean.getOUrlDialing());
				setOUnknown(cpBean.getOUnknown());
				setFIntraLocation(cpBean.getFIntraLocation());
				setFLocal(cpBean.getFLocal());
				setFToll(cpBean.getFToll());
				setFTollFree(cpBean.getFTollFree());
				setFInternational(cpBean.getFInternational());
				setFCasual(cpBean.getFCasual());
				setFOperatorAssisted(cpBean.getFOperatorAssisted());
				setFChargedDirAssist(cpBean.getFChargedDirAssist());
				setFSplServices1(cpBean.getFSplServices1());
				setFSplServices2(cpBean.getFSplServices2());
				setFPrmServices1(cpBean.getFPrmServices1());
				setFPrmServices2(cpBean.getFPrmServices2());
				setFUrlDialing(cpBean.getFUrlDialing());
				setFUnknown(cpBean.getFUnknown());
				setBInterLocation(cpBean.getBInterLocation());
				setTelephone1(cpBean.getTelephone1());
				setTelephone2(cpBean.getTelephone2());
				setTelephone3(cpBean.getTelephone3());
				setEnvOrderId(cpBean.getEnvOrderId());
				setCreatedBy(cpBean.getCreatedBy());
				setModifiedBy(cpBean.getModifiedBy());
				setLastModifiedDate(cpBean.getLastModifiedDate());
				setCreationDate(cpBean.getCreationDate());
				getDigitStringListByCallingPlanId();
			} else {
				setStatus(InvErrorCode.NOTFOUND_CALLING_PLAN);
				log.info("FAILURE in getDetails CallingPlan. Invalid calling_plan_id");
				return false;
			}
		} catch (SQLException e) {
			e.printStackTrace();
			setStatus(InvErrorCode.DB_EXCEPTION);
			return false;
		} catch (Exception e) {
			setStatus(InvErrorCode.INTERNAL_ERROR);
			e.printStackTrace();
			return false;
		}

		setStatus(InvErrorCode.SUCCESS);
		return true;
	}

	public boolean getDigitStringListByCallingPlanId() throws Exception {
		TblCallingPlanDigitsQuery callingPlanDigitsQry = new TblCallingPlanDigitsQuery();
		callingPlanDigitsQry.whereCallingPlanIdEQ(getCallingPlanId());
		callingPlanDigitsQry.query(dbCon);
		if (callingPlanDigitsQry.size() > 0) {
			for (int i = 0; i < callingPlanDigitsQry.size(); i++) {
				DBTblCallingPlanDigits callingPlanDigitsDbBean = new DBTblCallingPlanDigits();
				callingPlanDigitsDbBean.copyFromBean(callingPlanDigitsQry
						.getDbBean(i));
				TblDigitStringsQuery digitStringsQry = new TblDigitStringsQuery();
				digitStringsQry.whereDigitStringIdEQ(callingPlanDigitsDbBean
						.getDigitStringId());
				digitStringsQry.whereActiveIndEQ(1);
				digitStringsQry.query(dbCon);
				if (digitStringsQry.size() > 0) {
					DigitStringBean digitStringBean = new DigitStringBean();
					digitStringBean.setCallingPlanId(callingPlanDigitsDbBean
							.getCallingPlanId());
					digitStringBean.setDigitStringId(callingPlanDigitsDbBean
							.getDigitStringId());
					digitStringBean.setDigitString(digitStringsQry.getDbBean(0)
							.getDigitString());
					digitStringBean.setIAllow(callingPlanDigitsDbBean
							.getIAllow());
					digitStringBean.setOAllow(callingPlanDigitsDbBean
							.getOAllow());
					digitStringBean.setBAllow(callingPlanDigitsDbBean
							.getBAllow());
					digitStringBean.setFAllow(callingPlanDigitsDbBean
							.getFAllow());
					digitStringBean.setActiveInd(1);
					digitStringList.add(digitStringBean);
				}
			}
		}
		return true;
	}

	/**
	 * The method to modify the Calling Plan record.
	 * 
	 * Calling Plan Id should be set before calling this method.
	 * 
	 * @return true Record has been updated SUCCESSFULLY false Callin Plan Id
	 *         missing / Record update Unsuccessful / Some Error occured.
	 */
	public boolean modifyInDB() throws SQLException, Exception {
		// try
		// {
		if (callingPlanId <= 0) {
			setStatus(InvErrorCode.MISSING_CALLING_PLAN_ID);
			setLogTrail("CallingPlan::modifyInDB :: " + getStatusDesc());
			log.info("FAILURE in modifyInDB CallingPlan. Calling Plan Id missing.");
			return false;
		}
		DBTblCallingPlans callingPlansDbBean = getCallingPlanToUpdate();

		if (callingPlansDbBean == null) {
			setStatus(InvErrorCode.NOTFOUND_CALLING_PLAN);
			setLogTrail("CallingPlan::modifyInDB :: " + getStatusDesc());
			log.info("FAILURE in modifyInDB CallingPlan. Calling Plan missing.");
			return false;
		} else {
			callingPlansDbBean.whereCallingPlanIdEQ(callingPlanId);
			// callingPlansDbBean.updateSpByWhere(dbCon);
			if (callingPlansDbBean.updateSpByWhere(dbCon) <= 0)
				return false;
		}
		/*
		 * } catch (SQLException s) { s.printStackTrace();
		 * setStatus(InvErrorCode.ERROR_MODIFYING_CALLING_PLAN);
		 * setLogTrail("CallingPlan::modifyInDB :: " + getStatusDesc());
		 * log.info("DB_FAILURE in modifyInDB CallingPlan"); return false; }
		 */
		setStatus(InvErrorCode.SUCCESS);
		log.info("Successfully UPDATED calling plan into the DB");
		return true;
	}

	/**
	 * query from db and overlay updated values.
	 * 
	 * @return The CallingPlan to be updated.
	 * @throws SQLException
	 */
	private DBTblCallingPlans getCallingPlanToUpdate() throws SQLException {
		DBTblCallingPlans cpDbBean = new DBTblCallingPlans();
		TblCallingPlansDbBean qryBean = null;

		TblCallingPlansQuery cpQry = new TblCallingPlansQuery();
		cpQry.whereCallingPlanIdEQ(callingPlanId);
		cpQry.query(dbCon);

		if (cpQry.size() != 1)
			return null;
		else
			qryBean = cpQry.getDbBean(0);

		// cpDbBean.copyFromBean(cpQry.getDbBean(0)); set only fields that have
		// been modified

		CallingPlan inputCP = this;

		if (callingPlanName != null
				&& !callingPlanName.equals(qryBean.getCallingPlanName())) {
			cpDbBean.setCallingPlanName(callingPlanName);
		}
		log.info("inputCP.getDefaultInd()=======>" + inputCP.getDefaultInd());
		log.info(" qryBean.getDefaultInd()=======>" + qryBean.getDefaultInd());
		if (inputCP.getDefaultInd() != qryBean.getDefaultInd()) {
			cpDbBean.setDefaultInd(inputCP.getDefaultInd());
		}
		if (inputCP.getIIntraLocation() != qryBean.getIIntraLocation()) {
			cpDbBean.setIIntraLocation(inputCP.getIIntraLocation());
		}
		if (inputCP.getIInterLocation() != qryBean.getIInterLocation()) {
			cpDbBean.setIInterLocation(inputCP.getIInterLocation());
		}
		if (inputCP.getICollectCalls() != qryBean.getICollectCalls()) {
			cpDbBean.setICollectCalls(inputCP.getICollectCalls());
		}
		if (inputCP.getOIntraLocation() != qryBean.getOIntraLocation()) {
			cpDbBean.setOIntraLocation(inputCP.getOIntraLocation());
		}
		if (inputCP.getOLocal() != qryBean.getOLocal()) {
			cpDbBean.setOLocal(inputCP.getOLocal());
		}
		if (inputCP.getOTollFree() != qryBean.getOTollFree()) {
			cpDbBean.setOTollFree(inputCP.getOTollFree());
		}
		if (inputCP.getOToll() != qryBean.getOToll()) {
			cpDbBean.setOToll(inputCP.getOToll());
		}
		log.info("inputCP.getOInternational() ===> "
				+ inputCP.getOInternational());
		log.info("qryBean.getOInternational() ===> "
				+ qryBean.getOInternational());
		if (inputCP.getOInternational() != qryBean.getOInternational()) {
			cpDbBean.setOInternational(inputCP.getOInternational());
		}
		if (inputCP.getOCasual() != qryBean.getOCasual()) {
			cpDbBean.setOCasual(inputCP.getOCasual());
		}
		if (inputCP.getOOperatorAssisted() != qryBean.getOOperatorAssisted()) {
			cpDbBean.setOOperatorAssisted(inputCP.getOOperatorAssisted());
		}
		if (inputCP.getOChargedDirAssist() != qryBean.getOChargedDirAssist()) {
			cpDbBean.setOChargedDirAssist(inputCP.getOChargedDirAssist());
		}
		if (inputCP.getOSplServices1() != qryBean.getOSplServices1()) {
			cpDbBean.setOSplServices1(inputCP.getOSplServices1());
		}
		if (inputCP.getOSplServices2() != qryBean.getOSplServices2()) {
			cpDbBean.setOSplServices2(inputCP.getOSplServices2());
		}
		if (inputCP.getOPrmServices1() != qryBean.getOPrmServices1()) {
			cpDbBean.setOPrmServices1(inputCP.getOPrmServices1());
		}
		if (inputCP.getOPrmServices2() != qryBean.getOPrmServices2()) {
			cpDbBean.setOPrmServices2(inputCP.getOPrmServices2());
		}
		if (inputCP.getOUrlDialing() != qryBean.getOUrlDialing()) {
			cpDbBean.setOUrlDialing(inputCP.getOUrlDialing());
		}
		if (inputCP.getOUnknown() != qryBean.getOUnknown()) {
			cpDbBean.setOUnknown(inputCP.getOUnknown());
		}
		if (inputCP.getFIntraLocation() != qryBean.getFIntraLocation()) {
			cpDbBean.setFIntraLocation(inputCP.getFIntraLocation());
		}
		if (inputCP.getFLocal() != qryBean.getFLocal()) {
			cpDbBean.setFLocal(inputCP.getFLocal());
		}
		if (inputCP.getFTollFree() != qryBean.getFTollFree()) {
			cpDbBean.setFTollFree(inputCP.getFTollFree());
		}
		if (inputCP.getFToll() != qryBean.getFToll()) {
			cpDbBean.setFToll(inputCP.getFToll());
		}
		if (inputCP.getFInternational() != qryBean.getFInternational()) {
			cpDbBean.setFInternational(inputCP.getFInternational());
		}
		if (inputCP.getFCasual() != qryBean.getFCasual()) {
			cpDbBean.setFCasual(inputCP.getFCasual());
		}
		if (inputCP.getFOperatorAssisted() != qryBean.getFOperatorAssisted()) {
			cpDbBean.setFOperatorAssisted(inputCP.getFOperatorAssisted());
		}
		if (inputCP.getFChargedDirAssist() != qryBean.getFChargedDirAssist()) {
			cpDbBean.setFChargedDirAssist(inputCP.getFChargedDirAssist());
		}
		if (inputCP.getFSplServices1() != qryBean.getFSplServices1()) {
			cpDbBean.setFSplServices1(inputCP.getFSplServices1());
		}
		if (inputCP.getFSplServices2() != qryBean.getFSplServices2()) {
			cpDbBean.setFSplServices2(inputCP.getFSplServices2());
		}
		if (inputCP.getFPrmServices1() != qryBean.getFPrmServices1()) {
			cpDbBean.setFPrmServices1(inputCP.getFPrmServices1());
		}
		if (inputCP.getFPrmServices2() != qryBean.getFPrmServices2()) {
			cpDbBean.setFPrmServices2(inputCP.getFPrmServices2());
		}
		if (inputCP.getFUrlDialing() != qryBean.getFUrlDialing()) {
			cpDbBean.setFUrlDialing(inputCP.getFUrlDialing());
		}
		if (inputCP.getFUnknown() != qryBean.getFUnknown()) {
			cpDbBean.setFUnknown(inputCP.getFUnknown());
		}
		if (inputCP.getBInterLocation() != qryBean.getBInterLocation()) {
			cpDbBean.setBInterLocation(inputCP.getBInterLocation());
		}
		if (inputCP.getTelephone1() != null
				&& !inputCP.getTelephone1().equals(qryBean.getTelephone1())) {
			cpDbBean.setTelephone1(inputCP.getTelephone1());
		}
		if (inputCP.getTelephone2() != null
				&& !inputCP.getTelephone2().equals(qryBean.getTelephone2())) {
			cpDbBean.setTelephone2(inputCP.getTelephone2());
		}
		if (inputCP.getTelephone3() != null
				&& !inputCP.getTelephone3().equals(qryBean.getTelephone3())) {
			cpDbBean.setTelephone3(inputCP.getTelephone3());
		}
		if (inputCP.getEnvOrderId() != qryBean.getEnvOrderId()) {
			cpDbBean.setEnvOrderId(inputCP.getEnvOrderId());
		}
		if (inputCP.getModifiedBy() != null
				&& !inputCP.getModifiedBy().equals(qryBean.getModifiedBy())) {
			cpDbBean.setModifiedBy(inputCP.getModifiedBy());
		}
		cpDbBean.setLastModifiedDate(new Timestamp(System.currentTimeMillis()));
		return cpDbBean;
	}

	public boolean isCallingPlanTiedToEnterprise() {
		try {
			// check if the calling plan is associated to an enterprise
			TblEnterpriseQuery entQuery = new TblEnterpriseQuery();

			entQuery.whereCallingPlanIdEQ(getCallingPlanId());
			entQuery.query(dbCon);

			if (entQuery.size() <= 0) {
				log.info("Calling Plan ID [" + getCallingPlanId()
						+ "] not associated to an Enterprise");
			} else {
				log.info("Calling Plan ID [" + getCallingPlanId()
						+ "] associated to an Enterprise");
				return true;
			}
		} catch (SQLException s) {
			s.printStackTrace();
			setStatus(InvErrorCode.DB_EXCEPTION);
			log.info("DB_FAILURE in isCallingPlanTiedToEnterprise");
			return false;
		}

		return false;
	}

	public boolean isCallingPlanTiedToLocation() {
		try {
			// check if the calling plan is associated to an location
			TblLocationQuery locQuery = new TblLocationQuery();
			locQuery.whereCallingPlanIdEQ(getCallingPlanId());
			locQuery.query(dbCon);

			if (locQuery.size() <= 0) {
				log.info("Calling Plan ID [" + getCallingPlanId()
						+ "] not associated to Location");
			} else {
				log.info("Calling Plan ID [" + getCallingPlanId()
						+ "] associated to an Location");
				return true;
			}
		} catch (SQLException s) {
			s.printStackTrace();
			setStatus(InvErrorCode.INTERNAL_ERROR);
			log.info("DB_FAILURE in isCallingPlanTiedToLocation");
			return false;
		}
		return false;
	}

	public boolean isCallingPlanTiedToDepartment() {
		try {
			// check if the calling plan is associated to department
			TblDepartmentQuery deptQuery = new TblDepartmentQuery();

			deptQuery.whereCallingPlanIdEQ(getCallingPlanId());
			deptQuery.query(dbCon);

			if (deptQuery.size() <= 0) {
				log.info("Calling Plan ID [" + getCallingPlanId()
						+ "] not associated to an Department");
			} else {
				log.info("Calling Plan ID [" + getCallingPlanId()
						+ "] associated to an Department");
				return true;
			}
		} catch (SQLException s) {
			s.printStackTrace();
			setStatus(InvErrorCode.DB_EXCEPTION);

			log.info("DB_FAILURE in isCallingPlanTiedToDepartment");
			return false;
		}
		return false;
	}

	public boolean isCallingPlanTiedToSubscriber() {
		try {
			// check if the calling plan is associated to a subscriber
			TblSubscriberQuery subQuery = new TblSubscriberQuery();

			subQuery.whereCallingPlanIdEQ(getCallingPlanId());
			subQuery.query(dbCon);

			if (subQuery.size() <= 0) {
				log.info("Calling Plan ID [" + getCallingPlanId()
						+ "] not associated to Subscriber");
			} else {
				log.info("Calling Plan ID [" + getCallingPlanId()
						+ "] associated to Subscriber");
				return true;
			}
		} catch (SQLException s) {
			s.printStackTrace();
			setStatus(InvErrorCode.DB_EXCEPTION);
			log.info("DB_FAILURE in isCallingPlanTiedToSubscriber");
			return false;
		}
		return false;
	}

	public boolean isCallingPlanTiedToCallingPlanDigits() {
		try {
			// check if the calling plan is associated to calling plan digits
			TblCallingPlanDigitsQuery cpQuery = new TblCallingPlanDigitsQuery();

			cpQuery.whereCallingPlanIdEQ(getCallingPlanId());
			cpQuery.query(dbCon);

			if (cpQuery.size() <= 0) {
				log.info("Calling Plan ID [" + getCallingPlanId()
						+ "] not associated to Calling Plan Digits");
			} else {
				log.info("Calling Plan ID [" + getCallingPlanId()
						+ "] associated to Calling Plan Digits");
				return true;
			}
		} catch (SQLException s) {
			s.printStackTrace();
			setStatus(InvErrorCode.DB_EXCEPTION);
			log.info("DB_FAILURE in isCallingPlanTiedToCallingPlanDigits");
			return false;
		}
		return false;
	}

	public boolean getDetailsByName() {
		try {
			TblCallingPlansQuery cpQry = new TblCallingPlansQuery();

			cpQry.whereCallingPlanNameEQ(getCallingPlanName());
			cpQry.query(dbCon);

			if (cpQry.size() == 1) {
				updateValues(cpQry.getDbBean(0));

			} else {
				setStatus(InvErrorCode.NOTFOUND_CALLING_PLAN);
				log.info("FAILURE in getDetails CallingPlan. Invalid calling_plan_name");
				return false;
			}
		} catch (SQLException e) {
			e.printStackTrace();
			setStatus(InvErrorCode.DB_EXCEPTION);
			return false;
		} catch (Exception e) {
			e.printStackTrace();
			setStatus(InvErrorCode.INTERNAL_ERROR);
			return false;
		}
		setStatus(InvErrorCode.SUCCESS);
		return true;
	}

	public long getCallingPlanType(String paramValue) {
		long calliIngPlanType = 0;
		try {
			log.info("Param Value is=====>" + paramValue);
			if (VzbVoipEnum.CallingPlanCallType.acronym(
					VzbVoipEnum.CallingPlanCallType.ALLOW).equalsIgnoreCase(
					paramValue)) {
				calliIngPlanType = VzbVoipEnum.CallingPlanCallType.ALLOW;
			} else if (VzbVoipEnum.CallingPlanCallType.acronym(
					VzbVoipEnum.CallingPlanCallType.DENY).equalsIgnoreCase(
					paramValue)) {
				calliIngPlanType = VzbVoipEnum.CallingPlanCallType.DENY;
			} else if (VzbVoipEnum.CallingPlanCallType.acronym(
					VzbVoipEnum.CallingPlanCallType.TRANSFER1)
					.equalsIgnoreCase(paramValue)) {
				calliIngPlanType = VzbVoipEnum.CallingPlanCallType.TRANSFER1;
			} else if (VzbVoipEnum.CallingPlanCallType.acronym(
					VzbVoipEnum.CallingPlanCallType.TRANSFER2)
					.equalsIgnoreCase(paramValue)) {
				calliIngPlanType = VzbVoipEnum.CallingPlanCallType.TRANSFER2;
			} else if (VzbVoipEnum.CallingPlanCallType.acronym(
					VzbVoipEnum.CallingPlanCallType.TRANSFER3)
					.equalsIgnoreCase(paramValue)) {
				calliIngPlanType = VzbVoipEnum.CallingPlanCallType.TRANSFER3;
			} else if (VzbVoipEnum.CallingPlanCallType.acronym(
					VzbVoipEnum.CallingPlanCallType.AUTHORIZE)
					.equalsIgnoreCase(paramValue)) {
				calliIngPlanType = VzbVoipEnum.CallingPlanCallType.AUTHORIZE;
			}

		} catch (Exception e) {
			e.printStackTrace();
			log.info("##############################");
			log.info("Exception getCallingPlanType is=======>" + e.getMessage());
			log.info("##############################");
		}
		log.info("calliIngPlanType=====>" + calliIngPlanType);
		return calliIngPlanType;
	}

	/**
	 * @param cpBean
	 */
	private void updateValues(TblCallingPlansDbBean cpBean) {
		setCallingPlanId(cpBean.getCallingPlanId());
		setCallingPlanName(cpBean.getCallingPlanName());
		setDefaultInd(cpBean.getDefaultInd());
		setIIntraLocation(cpBean.getIIntraLocation());
		setIInterLocation(cpBean.getIInterLocation());
		setICollectCalls(cpBean.getICollectCalls());
		setOIntraLocation(cpBean.getOIntraLocation());
		setOLocal(cpBean.getOLocal());
		setOTollFree(cpBean.getOTollFree());

		setOToll(cpBean.getOToll());

		setOInternational(cpBean.getOInternational());
		setOCasual(cpBean.getOCasual());
		setOOperatorAssisted(cpBean.getOOperatorAssisted());
		setOChargedDirAssist(cpBean.getOChargedDirAssist());
		setOSplServices1(cpBean.getOSplServices1());
		setOSplServices2(cpBean.getOSplServices2());
		setOPrmServices1(cpBean.getOPrmServices1());
		setOPrmServices2(cpBean.getOPrmServices2());
		setOUrlDialing(cpBean.getOUrlDialing());
		setOUnknown(cpBean.getOUnknown());
		setFIntraLocation(cpBean.getFIntraLocation());
		setFLocal(cpBean.getFLocal());
		setFTollFree(cpBean.getFToll());
		setFInternational(cpBean.getFInternational());
		setFCasual(cpBean.getFCasual());
		setFOperatorAssisted(cpBean.getFOperatorAssisted());
		setFChargedDirAssist(cpBean.getFChargedDirAssist());
		setFSplServices1(cpBean.getFSplServices1());
		setFSplServices2(cpBean.getFSplServices2());
		setFPrmServices1(cpBean.getFPrmServices1());
		setFPrmServices2(cpBean.getFPrmServices2());
		setFUrlDialing(cpBean.getFUrlDialing());
		setFUnknown(cpBean.getFUnknown());
		setBInterLocation(cpBean.getBInterLocation());
		setTelephone1(cpBean.getTelephone1());
		setTelephone2(cpBean.getTelephone2());
		setTelephone3(cpBean.getTelephone3());
		setCreatedBy(cpBean.getCreatedBy());
		setEnvOrderId(cpBean.getEnvOrderId());
		setModifiedBy(cpBean.getModifiedBy());
		setLastModifiedDate(cpBean.getLastModifiedDate());
		setCreationDate(cpBean.getCreationDate());
	}

	public HashMap<String, String> getLocationIdOrDepartmentIdByCallingPlanId()
			throws SQLException {
		if (getCallingPlanId() <= 0) {
			setStatus(InvErrorCode.INVALID_INPUT);
			log.info("Calling Plan should be set before calling this method.getLocationIdOrDepartmentIdByCallingPlanId");
			return null;
		}
		HashMap<String, String> entityMap = new HashMap<String, String>();
		TblLocationQuery locQry = new TblLocationQuery();
		locQry.whereCallingPlanIdEQ(getCallingPlanId());
		locQry.query(dbCon);
		if (locQry.size() > 0) {
			entityMap.put("LOCATION_ID", locQry.getDbBean(0).getLocationId());
		} else {
			TblDepartmentQuery deptQry = new TblDepartmentQuery();
			deptQry.whereCallingPlanIdEQ(getCallingPlanId());
			deptQry.query(dbCon);
			if (deptQry.size() > 0) {
				entityMap.put("DEPARTMENT_ID", deptQry.getDbBean(0)
						.getDepartmentId());
			}
		}
		return entityMap;
	}

	public boolean addDigitStringListToDb() throws SQLException, Exception {
		// try
		// {
		if (digitStringList != null)
			for (int i = 0; i < digitStringList.size(); i++) {
				DigitString digitStringObj = new DigitString(
						digitStringList.get(i), dbCon);
				digitStringObj.setCallingPlanId(getCallingPlanId());
				digitStringObj.addToDB();
			}
		/*
		 * } catch (Exception e) { e.printStackTrace();
		 * setStatus(InvErrorCode.INTERNAL_ERROR); return false; }
		 */
		setStatus(InvErrorCode.SUCCESS);
		return true;

	}

	public boolean delDigitStringListFromDb() {
		try {
			if (digitStringList != null)
				for (int i = 0; i < digitStringList.size(); i++) {
					DigitString digitStringObj = new DigitString(
							digitStringList.get(i), dbCon);
					digitStringObj.setCallingPlanId(getCallingPlanId());
					digitStringObj.deleteCallingPlanDigits();
				}
		} catch (Exception e) {
			e.printStackTrace();
			setStatus(InvErrorCode.INTERNAL_ERROR);
			return false;
		}
		setStatus(InvErrorCode.SUCCESS);
		return true;

	}

	// Provided the below API as part of IR# 5503300 - Digit string delete order
	// from CSSOP is not deleting the inv data and still has record causing
	// subsequent add to fail
	public boolean delAllDigitStringListFromDb() {
		log.info("Inside delAllDigitStringListFromDb API :: ");
		try {
			if (digitStringList != null)
				for (int i = 0; i < digitStringList.size(); i++) {
					log.info("Inside delAllDigitStringListFromDb API :FOR ");
					DigitString digitStringObj = new DigitString(
							digitStringList.get(i), dbCon);
					digitStringObj.setCallingPlanId(getCallingPlanId());
					digitStringObj.deleteDigitStringByDigitStringId();
				}
		} catch (Exception e) {
			e.printStackTrace();
			setStatus(InvErrorCode.INTERNAL_ERROR);
			return false;
		}
		setStatus(InvErrorCode.SUCCESS);
		return true;

	}

	public boolean modDigitStringListInDb() throws SQLException, Exception {
		// try
		// {
		if (digitStringList != null)
			for (int i = 0; i < digitStringList.size(); i++) {
				DigitString digitStringObj = new DigitString(
						digitStringList.get(i), dbCon);
				digitStringObj.setCallingPlanId(getCallingPlanId());
				digitStringObj.modifyInDB();
			}
		/*
		 * } catch (Exception e) { e.printStackTrace();
		 * setStatus(InvErrorCode.INTERNAL_ERROR); return false; }
		 */
		setStatus(InvErrorCode.SUCCESS);
		return true;

	}

}
