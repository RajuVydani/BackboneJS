package com.vz.esap.api.connector.util;


public class ConfigInterfaceUtil {
	
	
	/*public static ConfigDomainServiceDTO transformResponseViewToDTO(ConfigDetailResponse sourceView) {
		ConfigDomainServiceDTO.ConfigDomainServiceDTOBuilder builder = new ConfigDomainServiceDTO.ConfigDomainServiceDTOBuilder();

		// BSConfigData Not present in GetConfigParam API
		if (sourceView.getBsConfigData() != null) {
			BSConfigData.BSConfigDataBuilder bsConfigDataBuilder = new BSConfigData.BSConfigDataBuilder();
			bsConfigDataBuilder.withBaseClli(sourceView.getBsConfigData().getBaseClli());
	
			Device.DeviceBuilder deviceBuilder = null;
			for (com.vz.esap.bs.generated.pojo.Device device : sourceView.getBsConfigData().getDevices()) {
				deviceBuilder = new Device.DeviceBuilder();
				deviceBuilder.withDeviceName(device.getDevice());
				deviceBuilder.withLoginStatus(device.getLoginStatus());
	
				TableRouteInfoParam.TableRouteInfoParamBuilder tableRouteInfoParamBuilder = null;
				for (NameValuePair nameValuePair : device.getNameValuePair()) {
					tableRouteInfoParamBuilder = new TableRouteInfoParam.TableRouteInfoParamBuilder();
					tableRouteInfoParamBuilder.withParamName(nameValuePair.getParamName());
					tableRouteInfoParamBuilder.withParamValue(nameValuePair.getParamValue());
					deviceBuilder.addTableRouteParamInfo(tableRouteInfoParamBuilder.build());
				}
				bsConfigDataBuilder.addDevice(deviceBuilder.build());
			}
			builder.withBsConfigData(bsConfigDataBuilder.build());
		}

		// TblConfigParams Not present in GetAllDevices API
		if (sourceView.getConfigParams() != null) {
			TableConfigDetailsParam.TableConfigDetailsParamBuilder tableConfigDetailsParamBuilder = null;
			for (ConfigParam configParam : sourceView.getConfigParams()) {
				tableConfigDetailsParamBuilder = new TableConfigDetailsParam.TableConfigDetailsParamBuilder();
				tableConfigDetailsParamBuilder.withConfigParamId(Long.parseLong(configParam.getConfigParamsId().toString()));
				tableConfigDetailsParamBuilder.withDescription(configParam.getDescription());
				tableConfigDetailsParamBuilder.withParamGroup(configParam.getDescription());
				tableConfigDetailsParamBuilder.withParamName(configParam.getParamName());
				tableConfigDetailsParamBuilder.withParamValue(configParam.getParamValue());
				tableConfigDetailsParamBuilder.withProcessName(configParam.getProcessName());
				tableConfigDetailsParamBuilder.withStatus(configParam.getStatus());
	
				builder.addTableConfigDetailsParam(tableConfigDetailsParamBuilder.build());
			}
		}

		ConfigDomainServiceDTO configDomainServiceDTO = builder.build();

		//System.out.println("ConfigDomainServiceDTO:=>" + configDomainServiceDTO);

		return configDomainServiceDTO;
	}*/

/*	public static ConfigDomainServiceDTO prepareResponseFromInputJsonFile(File jsonFile) {

		ObjectMapper objectMapper = new ObjectMapper();
		ConfigResponse response;
		ConfigDomainServiceDTO dto = null;
		try {
			response = objectMapper.readValue(jsonFile, ConfigResponse.class);

			dto = transformResponseViewToDTO(response);

		} catch (JsonParseException e) {
			e.printStackTrace();
		} catch (JsonMappingException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return dto;
	}*/

}
