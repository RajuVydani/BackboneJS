package com.vz.fxo.inventory.enterprise.support;

import java.util.ArrayList;
import java.util.List;

public class TwoWayGroupBean {

	protected FeaturePackageBean featurePackageObj;
	protected GatewayDeviceBean device;
	protected List<FeaturesBean> excludedFeaturesList;
	protected List<FeaturesBean> groupFeaturesList;
	protected List<PBXGroupTn> pbxGroupTnList;//will be lazy initialized
	protected List<String> logTrail;

	protected int groupId;
	protected String locationId;
	protected String departmentId;
	protected String groupName;
	protected long packageId;
	protected String packageStr;
	protected long deviceMapId;
	protected long gatewayDeviceId;
	protected String cidFirstName;
    	protected String cidLastName;
    	protected long pbxCidPoolId;
    	protected String pbxCidTn;
    	protected String extension;
    	protected String privateNumber;
	protected long pbxMaxCclLimit;
	protected String linePort;
	protected long activeInd;
	protected String pbxRedirectTn;
	protected long pbxRedirectTrunkId;
     protected long envOrderId;  
	protected String modifiedBy;
	protected String createdBy;
	protected java.sql.Timestamp creationDate;
    protected java.sql.Timestamp lastModifiedDate;
	protected boolean getAll;
	protected long linePortLength;
	protected long invitationTimer;
	protected long pqInstanceId;
	protected long CnamUpdateStatus;
	protected java.sql.Timestamp CnamUpdateDate;
	
	//Added for XO
	protected String trunkgroup_id;
	protected String otg_id;
	protected String Signaling_direction;
	protected String DbErrorMessage;


	/**
	 * Default Constructor -- Initializes all fields to default values.
	 */
    	public TwoWayGroupBean()
    	{
		this.featurePackageObj = null;
		this.device = null;
		this.excludedFeaturesList = null;
		this.pbxGroupTnList = null;
		this.logTrail = null;
		this.groupId = -1;
		this.locationId = new String("NONE");
		this.departmentId = new String("NONE");
		this.groupName = new String("NONE");
		this.packageId = -1;
		this.packageStr = new String("NONE");
		this.deviceMapId = -1;
		this.gatewayDeviceId = -1;
		this.cidFirstName = new String("NONE");
		this.cidLastName = new String("NONE");
		this.pbxCidPoolId = -1;
		this.pbxCidTn = new String("NONE");
		this.extension = new String("NONE");
		this.privateNumber = new String("NONE");
		this.pbxMaxCclLimit = -1;
		this.linePort = new String("NONE");
		this.activeInd = 1;
		this.pbxRedirectTn = new String("NONE");
		this.pbxRedirectTrunkId = -1;
	   this.envOrderId = -1; 		
                this.modifiedBy = new String("NONE");
		this.createdBy = new String("NONE");
		this.lastModifiedDate = null;
		this.creationDate = null;
		this.linePortLength =  -1;
		this.invitationTimer =  -1;
		this.pqInstanceId = -1;
		this.CnamUpdateStatus = -1;
		this.CnamUpdateDate = null;
		
		featurePackageObj = new FeaturePackageBean();
		device = new GatewayDeviceBean();
		excludedFeaturesList = new ArrayList<FeaturesBean>();
		groupFeaturesList = new ArrayList<FeaturesBean>();
		pbxGroupTnList = new  ArrayList<PBXGroupTn>();
		logTrail = new ArrayList<String>();
		this.getAll = false;
	}
	
	public void clearPBXGroup()
        {
        this.locationId ="" ;
        this.departmentId =""; 
        this.groupName = "";
        this.packageStr = "";
        this.cidFirstName =""; 
        this.cidLastName = "";
        this.pbxCidTn = "";
        this.extension = "";
        this.privateNumber = "";
        this.linePort = "";
        this.pbxRedirectTn =""; 
                this.modifiedBy =""; 
        this.createdBy = "";
    }


	/**
     	* Constructor
     	* @param pbxGroupBean
     	*/
    	public TwoWayGroupBean(TwoWayGroupBean twoWayGroupBean)
    	{
		this.featurePackageObj = twoWayGroupBean.featurePackageObj;
		this.device = twoWayGroupBean.device;
		this.excludedFeaturesList = twoWayGroupBean.excludedFeaturesList;
		this.groupFeaturesList = twoWayGroupBean.groupFeaturesList;
		this.pbxGroupTnList = twoWayGroupBean.pbxGroupTnList;
		this.logTrail = twoWayGroupBean.logTrail;
		this.groupId = twoWayGroupBean.groupId;
		this.locationId = twoWayGroupBean.locationId;
		this.departmentId = twoWayGroupBean.departmentId;
		this.groupName = twoWayGroupBean.groupName;
		this.packageId = twoWayGroupBean.packageId;
		this.packageStr = twoWayGroupBean.packageStr;
		this.deviceMapId = twoWayGroupBean.deviceMapId;
		this.gatewayDeviceId = twoWayGroupBean.gatewayDeviceId;
		this.cidFirstName = twoWayGroupBean.cidFirstName;
		this.cidLastName = twoWayGroupBean.cidLastName;
		this.pbxCidPoolId = twoWayGroupBean.pbxCidPoolId;
		this.pbxCidTn = twoWayGroupBean.pbxCidTn;
		this.extension = twoWayGroupBean.extension;
		this.privateNumber = twoWayGroupBean.privateNumber;
		this.pbxMaxCclLimit = twoWayGroupBean.pbxMaxCclLimit;
		this.linePort = twoWayGroupBean.linePort;
		this.activeInd = twoWayGroupBean.activeInd;
		this.pbxRedirectTn = twoWayGroupBean.pbxRedirectTn;
		this.pbxRedirectTrunkId = twoWayGroupBean.pbxRedirectTrunkId;
                this.envOrderId = twoWayGroupBean.envOrderId;	
                this.modifiedBy = twoWayGroupBean.modifiedBy;
		this.createdBy = twoWayGroupBean.createdBy;
		this.lastModifiedDate = twoWayGroupBean.lastModifiedDate;
		this.featurePackageObj = twoWayGroupBean.featurePackageObj;
		this.linePortLength = twoWayGroupBean.linePortLength;
		this.invitationTimer = twoWayGroupBean.invitationTimer;
		this.pqInstanceId = twoWayGroupBean.pqInstanceId;
        	this.device = twoWayGroupBean.device;
		this.creationDate = twoWayGroupBean.creationDate;
		this.getAll = twoWayGroupBean.getAll;
		this.CnamUpdateDate = twoWayGroupBean.CnamUpdateDate;
		this.CnamUpdateStatus = twoWayGroupBean.CnamUpdateStatus;
    	}
    	
	/**
	 * @return the cnamUpdateStatus
	 */
	public long getCnamUpdateStatus() {
		return CnamUpdateStatus;
	}

	/**
	 * @param cnamUpdateStatus the cnamUpdateStatus to set
	 */
	public void setCnamUpdateStatus(long cnamUpdateStatus) {
		CnamUpdateStatus = cnamUpdateStatus;
	}

	/**
	 * @return the cnamUpdateDate
	 */
	public java.sql.Timestamp getCnamUpdateDate() {
		return CnamUpdateDate;
	}

	/**
	 * @param cnamUpdateDate the cnamUpdateDate to set
	 */
	public void setCnamUpdateDate(java.sql.Timestamp cnamUpdateDate) {
		CnamUpdateDate = cnamUpdateDate;
	}

	public void setLogTrail(String logStr)
        {
                logTrail.add(logStr);
        }
        public List<String> getLogTrail()
        {
                return logTrail;
        }
	
	public java.sql.Timestamp getLastModifiedDate() {
		return lastModifiedDate;
	}

	public void setLastModifiedDate(java.sql.Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public java.sql.Timestamp getCreationDate() {
        	return creationDate;
    	}
                                                                                                                             
    	public void setCreationDate(java.sql.Timestamp creationDate) {
        	this.creationDate = creationDate;
    	}

	public FeaturePackageBean getFeaturePackageObj() {
		return featurePackageObj;
	}
	public void setFeaturePackageObj(FeaturePackageBean featurePackageObj) {
		this.featurePackageObj = featurePackageObj;
	}
	public GatewayDeviceBean getDevice() {
		return device;
	}
	public void setDevice(GatewayDeviceBean device) {
		this.device = device;
	}
	public List<FeaturesBean> getExcludedFeaturesList() {
		return excludedFeaturesList;
	}
	public void setExcludedFeaturesList(List<FeaturesBean> excludedFeaturesList) {
		this.excludedFeaturesList = excludedFeaturesList;
	}
	public List<FeaturesBean> getGroupFeaturesList() {
                return groupFeaturesList;
        }
        public void setGroupFeaturesList(List<FeaturesBean> groupFeaturesList) {
                this.groupFeaturesList = groupFeaturesList;
        }

	public List<PBXGroupTn> getPbxGroupTnList() {
		return pbxGroupTnList;
	}
	public void setPbxGroupTnList(List<PBXGroupTn> pbxGroupTnList) {
		this.pbxGroupTnList = pbxGroupTnList;
	}
	public long getPbxCidPoolId() {
		return pbxCidPoolId;
	}
	public void setPbxCidPoolId(long pbxCidPoolId) {
		this.pbxCidPoolId = pbxCidPoolId;
	}
	public String getPbxCidTn() {
		return pbxCidTn;
	}
	public void setPbxCidTn(String pbxCidTn) {
		this.pbxCidTn = pbxCidTn;
	}
	public String getLinePort() {
                return linePort;
        }
        public void setLinePort(String linePort) {
                this.linePort = linePort;
        }

	public int getGroupId() {
		return groupId;
	}
	public void setGroupId(int groupId) {
		this.groupId = groupId;
	}
	public String getLocationId() {
		return locationId;
	}
	public void setLocationId(String locationId) {
		this.locationId = locationId;
	}
	public String getDepartmentId() {
		return departmentId;
	}
	public void setDepartmentId(String departmentId) {
		this.departmentId = departmentId;
	}
	public String getGroupName() {
		return groupName;
	}
	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}
	public long getPackageId() {
		return packageId;
	}
	public void setPackageId(long packageId) {
		this.packageId = packageId;
	}
	public long getDeviceMapId() {
		return deviceMapId;
	}
	public void setDeviceMapId(long deviceMapId) {
		this.deviceMapId = deviceMapId;
	}
	public String getPbxRedirectTn() {
		return pbxRedirectTn;
	}
	public void setPbxRedirectTn(String pbxRedirectTn) {
		this.pbxRedirectTn = pbxRedirectTn;
	}
	public long getPbxRedirectTrunkId() {
		return pbxRedirectTrunkId;
	}
	public void setPbxRedirectTrunkId(long pbxRedirectTrunkId) {
		this.pbxRedirectTrunkId = pbxRedirectTrunkId;
	}
	public long getGatewayDeviceId() {
                return gatewayDeviceId;
        }
        public void setGatewayDeviceId(long gatewayDeviceId) {
                this.gatewayDeviceId = gatewayDeviceId;
        }
	public String getCidFirstName() {
		return cidFirstName;
	}
	public void setCidFirstName(String cidFirstName) {
		this.cidFirstName = cidFirstName;
	}
	public String getPackageStr() {
                return packageStr;
        }
        public void setPackageStr(String packageStr) {
                this.packageStr = packageStr;
	}		
	public String getCidLastName() {
		return cidLastName;
	}
	public void setCidLastName(String cidLastName) {
		this.cidLastName = cidLastName;
	}
	public String getExtension() {
		return extension;
	}
	public void setExtension(String extension) {
		this.extension = extension;
	}
	public String getPrivateNumber() {
		return privateNumber;
	}
	public void setPrivateNumber(String privateNumber) {
		this.privateNumber = privateNumber;
	}
	public long getPbxMaxCclLimit() {
		return pbxMaxCclLimit;
	}
	public void setPbxMaxCclLimit(long pbxMaxCclLimit) {
		this.pbxMaxCclLimit = pbxMaxCclLimit;
	}
	public long getActiveInd() {
		return activeInd;
	}
	public void setActiveInd(long activeInd) {
		this.activeInd = activeInd;
	}
	public String getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public String getCreatedBy() {
                return createdBy;
        }
        public void setCreatedBy(String createdBy) {
                this.createdBy = createdBy;
        } 
        public long getEnvOrderId() {
		return envOrderId;
	}
	public void setEnvOrderId(long envOrderId) {
		this.envOrderId = envOrderId;
	}
	public boolean getGetAll() {
        return getAll;
    }

    public void setGetAll(boolean getAll) {
        this.getAll = getAll;
    }
    
	public long getLinePortLength() {
		return linePortLength;
	}
	public void setLinePortLength(long linePortLength) {
		this.linePortLength = linePortLength;
	} 

	public long getInvitationTimer() {
		return invitationTimer;
	}

	public void setInvitationTimer(long invitationTimer) {
		this.invitationTimer = invitationTimer;
	}

	public long getPqInstanceId() {
		return pqInstanceId;
	}

	public void setPqInstanceId(long pqInstanceId) {
		this.pqInstanceId = pqInstanceId;
	}

	//Added for XO 
	
	public String getTrunkgroup_id() {
		return trunkgroup_id;
	}

	public void setTrunkgroup_id(String trunkgroup_id) {
		this.trunkgroup_id = trunkgroup_id;
	}

	public String getOtg_id() {
		return otg_id;
	}

	public void setOtg_id(String otg_id) {
		this.otg_id = otg_id;
	}

	public String getSignaling_direction() {
		return Signaling_direction;
	}

	public void setSignaling_direction(String signaling_direction) {
		Signaling_direction = signaling_direction;
	}
	public String getDbErrorMessage() {
		return DbErrorMessage;
	}

	public void setDbErrorMessage(String dbErrorMessage) {
		DbErrorMessage = dbErrorMessage;
	}
	//end


}
