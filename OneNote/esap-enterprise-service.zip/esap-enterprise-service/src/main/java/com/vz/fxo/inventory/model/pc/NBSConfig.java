package com.vz.fxo.inventory.model.pc;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

@XmlRootElement(name = "NBSConfig")
@XmlAccessorType(XmlAccessType.FIELD)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
public class NBSConfig {
	@XmlElement(name = "Region")
	@JsonProperty(value = "Region")
	private String region;
	
	@XmlElement(name = "NBSCluster")
	@JsonProperty(value = "NBSCluster")
	private String nBSCluster;
	
	@XmlElement(name = "RouterStatus")
	@JsonProperty(value = "RouterStatus")
	private String routerStatus;
	
	@XmlElement(name = "VpnName")
	@JsonProperty(value = "VpnName")
	private String vpnName;
	
	@XmlElement(name = "IPVersion")
	@JsonProperty(value = "IPVersion")
	private String iPVersion;
	
	@XmlElement(name = "IPExt28")
	@JsonProperty(value = "IPExt28")
	private String iPExt28;
	
	
	@XmlElement(name = "IPInt32")
	@JsonProperty(value = "IPInt32")
	private String iPInt32;

	@XmlElement(name = "SR1")
	@JsonProperty(value = "SR1")
	private String sR1;
	
	@XmlElement(name = "SR2")
	@JsonProperty(value = "SR2")
	private String sR2;
	
	
	@XmlElement(name = "VLan")
	@JsonProperty(value = "VLan")
	private String vLan;
	
	@XmlElement(name = "CircuitId")
	@JsonProperty(value = "CircuitId")
	private String circuitId;

	/**
	 * @return the region
	 */
	public String getRegion() {
		return region;
	}

	/**
	 * @param region the region to set
	 */
	public void setRegion(String region) {
		this.region = region;
	}

	/**
	 * @return the nBSCluster
	 */
	public String getnBSCluster() {
		return nBSCluster;
	}

	/**
	 * @param nBSCluster the nBSCluster to set
	 */
	public void setnBSCluster(String nBSCluster) {
		this.nBSCluster = nBSCluster;
	}

	/**
	 * @return the routerStatus
	 */
	public String getRouterStatus() {
		return routerStatus;
	}

	/**
	 * @param routerStatus the routerStatus to set
	 */
	public void setRouterStatus(String routerStatus) {
		this.routerStatus = routerStatus;
	}

	/**
	 * @return the vpnName
	 */
	public String getVpnName() {
		return vpnName;
	}

	/**
	 * @param vpnName the vpnName to set
	 */
	public void setVpnName(String vpnName) {
		this.vpnName = vpnName;
	}

	/**
	 * @return the iPVersion
	 */
	public String getiPVersion() {
		return iPVersion;
	}

	/**
	 * @param iPVersion the iPVersion to set
	 */
	public void setiPVersion(String iPVersion) {
		this.iPVersion = iPVersion;
	}

	/**
	 * @return the iPExt28
	 */
	public String getiPExt28() {
		return iPExt28;
	}

	/**
	 * @param iPExt28 the iPExt28 to set
	 */
	public void setiPExt28(String iPExt28) {
		this.iPExt28 = iPExt28;
	}

	/**
	 * @return the iPInt32
	 */
	public String getiPInt32() {
		return iPInt32;
	}

	/**
	 * @param iPInt32 the iPInt32 to set
	 */
	public void setiPInt32(String iPInt32) {
		this.iPInt32 = iPInt32;
	}

	/**
	 * @return the sR1
	 */
	public String getsR1() {
		return sR1;
	}

	/**
	 * @param sR1 the sR1 to set
	 */
	public void setsR1(String sR1) {
		this.sR1 = sR1;
	}

	/**
	 * @return the sR2
	 */
	public String getsR2() {
		return sR2;
	}

	/**
	 * @param sR2 the sR2 to set
	 */
	public void setsR2(String sR2) {
		this.sR2 = sR2;
	}



	/**
	 * @return the vLan
	 */
	public String getvLan() {
		return vLan;
	}

	/**
	 * @param vLan the vLan to set
	 */
	public void setvLan(String vLan) {
		this.vLan = vLan;
	}

	/**
	 * @return the circuitID
	 */
	public String getCircuitId() {
		return circuitId;
	}

	/**
	 * @param circuitID the circuitID to set
	 */
	public void setCircuitId(String circuitId) {
		this.circuitId = circuitId;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "NBSConfig [region=" + region + ", nBSCluster=" + nBSCluster
				+ ", routerStatus=" + routerStatus + ", vpnName=" + vpnName
				+ ", iPVersion=" + iPVersion + ", iPExt28=" + iPExt28
				+ ", iPInt32=" + iPInt32 + ", sR1=" + sR1 + ", sR2=" + sR2
				+ ", vLan=" + vLan + ", circuitId=" + circuitId + "]";
	}

	
	
}
