package com.vz.esap.api.exception;

import EsapEnumPkg.*;

public class TaskException extends Exception
{
	String return_code;
	String return_msg;
	int code;			//numeric representaion of return_code;

	public TaskException(String ret, String msg)
	{
		super(msg);
		return_code = new String(ret);
		code = TaskExitEnum.ErrorType.valueByAcronym(ret);
		return_msg = new String(msg);
	}

    public String getReturnCode()
    {
        return return_code;
    }

    public String getReturnMessage()
    {
        return return_msg;
    }

	public int getCode()
	{
		return code;
	}
}
