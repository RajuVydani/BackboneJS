
package com.vz.esap.api.generated.pojo;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "entityType",
    "envOrderId",
    "errorCodes",
    "errorDescp",
    "orderId",
    "taskName",
    "tn",
    "workOrderNumber",
    "workOrderVersion"
})
public class TblFailEntityInfo {

    @JsonProperty("entityType")
    private String entityType;
    @JsonProperty("envOrderId")
    private Long envOrderId;
    @JsonProperty("errorCodes")
    private String errorCodes;
    @JsonProperty("errorDescp")
    private String errorDescp;
    @JsonProperty("orderId")
    private Long orderId;
    @JsonProperty("taskName")
    private String taskName;
    @JsonProperty("tn")
    private Long tn;
    @JsonProperty("workOrderNumber")
    private String workOrderNumber;
    @JsonProperty("workOrderVersion")
    private Long workOrderVersion;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("entityType")
    public String getEntityType() {
        return entityType;
    }

    @JsonProperty("entityType")
    public void setEntityType(String entityType) {
        this.entityType = entityType;
    }

    @JsonProperty("envOrderId")
    public Long getEnvOrderId() {
        return envOrderId;
    }

    @JsonProperty("envOrderId")
    public void setEnvOrderId(Long envOrderId) {
        this.envOrderId = envOrderId;
    }

    @JsonProperty("errorCodes")
    public String getErrorCodes() {
        return errorCodes;
    }

    @JsonProperty("errorCodes")
    public void setErrorCodes(String errorCodes) {
        this.errorCodes = errorCodes;
    }

    @JsonProperty("errorDescp")
    public String getErrorDescp() {
        return errorDescp;
    }

    @JsonProperty("errorDescp")
    public void setErrorDescp(String errorDescp) {
        this.errorDescp = errorDescp;
    }

    @JsonProperty("orderId")
    public Long getOrderId() {
        return orderId;
    }

    @JsonProperty("orderId")
    public void setOrderId(Long orderId) {
        this.orderId = orderId;
    }

    @JsonProperty("taskName")
    public String getTaskName() {
        return taskName;
    }

    @JsonProperty("taskName")
    public void setTaskName(String taskName) {
        this.taskName = taskName;
    }

    @JsonProperty("tn")
    public Long getTn() {
        return tn;
    }

    @JsonProperty("tn")
    public void setTn(Long tn) {
        this.tn = tn;
    }

    @JsonProperty("workOrderNumber")
    public String getWorkOrderNumber() {
        return workOrderNumber;
    }

    @JsonProperty("workOrderNumber")
    public void setWorkOrderNumber(String workOrderNumber) {
        this.workOrderNumber = workOrderNumber;
    }

    @JsonProperty("workOrderVersion")
    public Long getWorkOrderVersion() {
        return workOrderVersion;
    }

    @JsonProperty("workOrderVersion")
    public void setWorkOrderVersion(Long workOrderVersion) {
        this.workOrderVersion = workOrderVersion;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(entityType).append(envOrderId).append(errorCodes).append(errorDescp).append(orderId).append(taskName).append(tn).append(workOrderNumber).append(workOrderVersion).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof TblFailEntityInfo) == false) {
            return false;
        }
        TblFailEntityInfo rhs = ((TblFailEntityInfo) other);
        return new EqualsBuilder().append(entityType, rhs.entityType).append(envOrderId, rhs.envOrderId).append(errorCodes, rhs.errorCodes).append(errorDescp, rhs.errorDescp).append(orderId, rhs.orderId).append(taskName, rhs.taskName).append(tn, rhs.tn).append(workOrderNumber, rhs.workOrderNumber).append(workOrderVersion, rhs.workOrderVersion).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
