package com.vz.esap.api.service.model;

import java.util.List;
import java.io.Serializable;
public class FeaturePackageBean implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 230847508229337029L;
	protected int featurePackageId;
	protected long featurePackageType;// FeaturePackageType
	protected String featurePackageName;
	protected List<FeaturesBean> featureList;
	protected String locationId;// optional
	protected long isDefault; // optional
	protected long templateInd = -1; // optional
	protected long activeInd;
      protected long envOrderId;	
	protected String createdBy;
	protected String modifiedBy;
	protected java.sql.Timestamp createdDate;
	protected java.sql.Timestamp modifiedDate;
	protected boolean getAll;

	public FeaturePackageBean() {
		featurePackageName = new String("");
		this.activeInd = 1;
		locationId = new String("");
                envOrderId = -1;		
        	createdBy = new String("");
		modifiedBy = new String("");
		this.getAll = false;
	}

	public FeaturePackageBean(FeaturePackageBean fpBean) {
		this.featurePackageId = fpBean.featurePackageId;
		this.featurePackageType = fpBean.featurePackageType;
		this.featurePackageName = fpBean.featurePackageName;
		this.featureList = fpBean.featureList;
		this.locationId = fpBean.locationId;
		this.isDefault = fpBean.isDefault;
		this.templateInd = fpBean.templateInd;
                this.envOrderId = fpBean.envOrderId;	
         	this.createdBy = fpBean.createdBy;
		this.modifiedBy = fpBean.modifiedBy;
		this.createdDate = fpBean.createdDate;
		this.modifiedDate = fpBean.modifiedDate;
		this.activeInd = fpBean.activeInd;
		this.getAll = fpBean.getAll;
	}

	public long getFeaturePackageType() {
		return featurePackageType;
	}

	public int getFeaturePackageId() {
		return featurePackageId;
	}
	public long getActiveInd() {
        	return activeInd;
    	}

    	public void setActiveInd(long activeInd) {
        	this.activeInd = activeInd;
    	}

	public String getFeaturePackageName() {
		return featurePackageName;
	}

	public String getLocationId() {
		return locationId;
	}

	public long getIsDefault() {
		return isDefault;
	}

	public long getTemplateInd() {
		return templateInd;
	}

	public List<FeaturesBean> getFeatureList() {
		// first, using pkgname query the pkgid from TBL_PACKAGE

		// second, using the pkgid , query list of featureids from
		// TBL_PKG_FEATURES

		// third, using list of featureids, for each featureid - get details
		// from TBL_VZB_FEATURES

		return featureList;
	}

	public void setFeaturePackageType(long featurePkgType) {
		this.featurePackageType = featurePkgType;
	}

	public void setFeaturePackageId(int featurePkgId) {
		this.featurePackageId = featurePkgId;
	}

	public void setFeaturePackageName(String featPkgName) {
		this.featurePackageName = featPkgName;
	}

	public void setLocationId(String locationId) {
		this.locationId = locationId;
	}

	public void setIsDefault(long isDefault) {
		this.isDefault = isDefault;
	}

	public void setTemplateInd(long templateInd) {
		this.templateInd = templateInd;
	}

	public void setFeatureList(List<FeaturesBean> featList) {
		this.featureList = featList;
	}

	/**
	 * @return the isSelected
	 */
/*	public String getIsSelected() {
		return isSelected;
	}

	public void setIsSelected(String isSelected) {
		this.isSelected = isSelected;
	}*/

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public java.sql.Timestamp getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(java.sql.Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public java.sql.Timestamp getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(java.sql.Timestamp modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
       	public long getEnvOrderId() {
		return envOrderId;
	}
	public void setEnvOrderId(long envOrderId) {
		this.envOrderId = envOrderId;
	} 
	public boolean getGetAll() {
        return getAll;
    }

    public void setGetAll(boolean getAll) {
        this.getAll = getAll;
    }
	public void initilizeTODefault() {
		featurePackageName = new String("");
		locationId = new String("");
        envOrderId = 0;		
        createdBy = new String("");
		modifiedBy = new String("");
		
	}

}

