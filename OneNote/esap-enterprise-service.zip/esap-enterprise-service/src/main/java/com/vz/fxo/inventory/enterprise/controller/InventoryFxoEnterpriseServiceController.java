package com.vz.fxo.inventory.enterprise.controller;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeoutException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.BindException;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.vz.esap.api.model.InventoryServiceRequest;
import com.vz.fxo.inventory.enterprise.model.ResponseObject;
import com.vz.fxo.inventory.enterprise.service.InventoryFxoEnterpriseServiceImpl;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RefreshScope
@RequestMapping("/inventory/fxo/enterprise")
@Api(value = "inventory", description = "Inventory Enterprise Operations Service API")
public class InventoryFxoEnterpriseServiceController {

	@Autowired
	private InventoryFxoEnterpriseServiceImpl enterpriseServiceImpl;

	ObjectMapper mapper = new ObjectMapper();

	private static Logger log = LoggerFactory.getLogger(InventoryFxoEnterpriseServiceController.class);
	
	@RequestMapping(value = "/addEnt", method = RequestMethod.POST, produces = "application/json")
	@ApiResponses(value = { @ApiResponse(code = 0, message = "Successful"),
			@ApiResponse(code = 1, message = "Internal Server Error"), })
	public ResponseObject addEnt(
			@RequestBody InventoryServiceRequest bsRequestEntity)
			throws InterruptedException, ExecutionException, TimeoutException,
			BindException, JsonProcessingException {
	
		log.info("VZB_INV_FXO_ADD_ENTERPRISE : add() Request Object   :{}"
				, mapper.writerWithDefaultPrettyPrinter().writeValueAsString(
						bsRequestEntity));

		int flag = enterpriseServiceImpl.addEnt(bsRequestEntity);

		ResponseObject object = new ResponseObject();
		if (flag == ResponseObject.SUCCESS) {
			object.setStatusCode(ResponseObject.SUCCESS);
			object.setStatusDescription("VZB_INV_FXO_ADD_ENTERPRISE :  add enterprise Job is completed");
		} else {
			object.setStatusCode(ResponseObject.FAILURE);
			object.setStatusDescription(" VZB_INV_FXO_ADD_ENTERPRISE : add enterprise Job is failed");
		}
		log.info("VZB_INV_FXO_ADD_ENTERPRISE : add() Operation Completed response Object  :{}"
				, mapper.writerWithDefaultPrettyPrinter().writeValueAsString(
						object));
		return object;
	}

	@RequestMapping(value = "/modifyEnt", method = RequestMethod.POST, produces = "application/json")
	@ApiResponses(value = { @ApiResponse(code = 0, message = "Successful"),
			@ApiResponse(code = 1, message = "Internal Server Error"), })
	public ResponseObject modify(@RequestBody InventoryServiceRequest bsRequestEntity)
			throws InterruptedException, ExecutionException, TimeoutException, BindException, JsonProcessingException {

		log.info("VZB_INV_FXO_MOD_ENTERPRISE :  modify() Request Object   :{} "
				, mapper.writerWithDefaultPrettyPrinter().writeValueAsString(bsRequestEntity));

		int flag = enterpriseServiceImpl.modify(bsRequestEntity);

		ResponseObject object = new ResponseObject();
		if (flag == ResponseObject.SUCCESS) {
			object.setStatusCode(ResponseObject.SUCCESS);
			object.setStatusDescription("modify Enterprise Job is completed");
		} else {
			object.setStatusCode(ResponseObject.FAILURE);
			object.setStatusDescription("modify Enterprise Job is failed");
		}
		log.info("VZB_INV_FXO_MOD_ENTERPRISE :  modify() Operation Completed response Object  :{} "
				, mapper.writerWithDefaultPrettyPrinter().writeValueAsString(object));
		return object;
	}



	@RequestMapping(value = "/delEnt", method = RequestMethod.POST, produces = "application/json")
	@ApiResponses(value = { @ApiResponse(code = 0, message = "Successful"),
			@ApiResponse(code = 1, message = "Internal Server Error"), })
	public ResponseObject delEnterprise(@RequestBody InventoryServiceRequest bsRequestEntity)
			throws InterruptedException, ExecutionException, TimeoutException, BindException, JsonProcessingException {

		log.info("del() Request Object   :"
				+ mapper.writerWithDefaultPrettyPrinter().writeValueAsString(bsRequestEntity));

		int flag = enterpriseServiceImpl.del(bsRequestEntity);

		ResponseObject object = new ResponseObject();
		if (flag == ResponseObject.SUCCESS) {
			object.setStatusCode(ResponseObject.SUCCESS);
			object.setStatusDescription("del Enterprise Job is completed");
		} else {
			object.setStatusCode(ResponseObject.FAILURE);
			object.setStatusDescription("del Enterprise Job is failed");
		}
		log.info("del() Operation Completed response Object  :"
				+ mapper.writerWithDefaultPrettyPrinter().writeValueAsString(object));
		return object;
	}
	
	
}

