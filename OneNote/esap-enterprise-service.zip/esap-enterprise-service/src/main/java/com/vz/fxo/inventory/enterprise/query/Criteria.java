package com.vz.fxo.inventory.enterprise.query;

public interface Criteria {
    static enum ColumnName {
        /* Subscriber Summary */
        SS_ENTERPRISE_ID("TBL_ENTERPRISE","ENTERPRISE_ID"), 
        SS_LOCATION_ID("TBL_SUBSCRIBER","LOCATION_ID"), 
        SS_FIRST_NAME("TBL_SUBSCRIBER","FIRST_NAME"), 
        SS_LAST_NAME("TBL_SUBSCRIBER","LAST_NAME"), 
        SS_EXTENSION("TBL_SUBSCRIBER","EXTENSION"), 
        SS_VM_BOX_NUM("TBL_SUBSCRIBER","VM_BOX_NUM"), 
        SS_WEB_LOGIN_ID("TBL_SUBSCRIBER","WEB_LOGIN_ID"), 
        SS_USER_ID("TBL_SUBSCRIBER_TN","USER_ID"),
        /* End of Subscriber Summary*/
 
        SUBS_CID_FNAME("TBL_SUBSCRIBER","CID_FIRST_NAME"),
        SUBS_CID_LNAME("TBL_SUBSCRIBER","CID_LAST_NAME"),
       
        /*Location TNPool Summary*/
        TNPOOL_TN("TBL_PUBLIC_TN_POOL","TN"),
        TNPOOL_START_TN("TBL_PUBLIC_TN_POOL","TN"),
        TNPOOL_END_TN("TBL_PUBLIC_TN_POOL","TN"),
        TNPOOL_TNTYPE("TBL_PUBLIC_TN_POOL","TN_STATUS"),
        TNPOOL_ACTIVATE("TBL_PUBLIC_TN_POOL","ACT_DEACT"),
        TNPOOL_AVAILABLE_PORTPENDING("TBL_PUBLIC_TN_POOL","PORTED_STATUS"),
        TNPOOL_ASSIGNED_PORTPENDING("TBL_PUBLIC_TN_POOL","PORTED_STATUS"),
        /*End of Location TNPool Summary */
        
        /* Ringing Number Summary */
        RINGINGNO_NUMBER("TBL_PUBLIC_TN_POOL","NUMBER1"),
        RINGINGNO_FNAME("TBL_PUBLIC_TN_POOL","CLIDFIRSTNAME"),
        RINGINGNO_LNAME("TBL_PUBLIC_TN_POOL","CLIDLASTNAME"),
        /* End Of Ringing Number Summary */
        
        /* Device Line Summary */
        DEVICELINE_ENTERPRISEID("TBL_LOCATION","loc.ENTERPRISE_ID"),
        DEVICELINE_LOCATIONID("TBL_SUBSCRIBER","sub.LOCATION_ID"),
        DEVICELINE_DEPARTMENTID("TBL_SUBSCRIBER","sub.DEPARTMENT_ID"),
        DEVICELINE_BS_UID("TBL_SUBSCRIBER","sub.BS_SUB_ID"),
        DEVICELINE_CALLERID_FN("TBL_SUBSCRIBER","sub.CID_FIRST_NAME"),
        DEVICELINE_CALLERID_LN("TBL_SUBSCRIBER","sub.CID_LAST_NAME"),
        DEVICELINE_EXT("TBL_SUBSCRIBER","sub.Extension"),
        DEVICELINE_PVTNUMBER("TBL_SUBSCRIBER_TN","subtn2.user_id"),
        DEVICELINE_TN("TBL_SUBSCRIBER_TN","subtn1.user_id"),
        DEVICELINE_RESOURCETYPE("TBL_GROUP","GROUP_TYPE"),
        DEVICELINE_GRP_ENTERPRISEID("TBL_LOCATION","loc.ENTERPRISE_ID"),
        DEVICELINE_GRP_LOCATIONID("TBL_GROUP","grp.LOCATION_ID"),
        DEVICELINE_GRP_DEPARTMENTID("TBL_GROUP","grp.DEPARTMENT_ID"),
        DEVICELINE_GRP_BS_UID("TBL_GROUP_TN","grouptn.TN_POOL_ID"),
        DEVICELINE_GRP_CALLERID_FN("TBL_GROUP","grp.CID_FIRST_NAME"),
        DEVICELINE_GRP_CALLERID_LN("TBL_GROUP","grp.CID_LAST_NAME"),
        DEVICELINE_GRP_TN("TBL_GROUP_TN","tnpool.TN"),
        DEVICELINE_GRP_EXT("TBL_GROUP_TN","grouptn.Extension"),
        DEVICELINE_GRP_PVTNUMBER("TBL_GROUP_TN","grouptn.PrivateNumber"),
        DEVICELINE_GRP_RESOURCETYPE("TBL_GROUP","grp.group_type"),
        /* End Of Device Line Summary */
        
        /* Enterprise Trunk Line */
        ETLINE_CLIDFIRSTNAME("tbl_tso_et_tn","tet.clid_first_name"),
        ETLINE_CLIDLASTNAME("tbl_tso_et_tn","tet.clid_last_name"),        
        ETLINE_EXTENSION("tbl_tso_et_tn","tet.extension"),
        ETLINE_PRIVATENO("tbl_tso_et_tn","tet.private_number"),               
        ETLINE_TN("tbl_public_tn_pool","tpn.tn"),
        /* End of Enterprise Trunk Line */
        
        /* PBX Line */
        PBXLINE_CLIDFIRSTNAME("TBL_GROUP_TN","CID_FIRST_NAME"),
        PBXLINE_CLIDLASTNAME("TBL_GROUP_TN","CID_LAST_NAME"),        
        PBXLINE_EXTENSION("TBL_GROUP_TN","EXTENSION"),
        PBXLINE_PRIVATENO("TBL_GROUP_TN","PRIVATE_NUMBER"),               
        PBXLINE_TN("TBL_PUBLIC_TN_POOL","TN"),
        /* End of PBX Line */
        
        /*BS_DEVICE_NAME(""), BS_DEVICE_TYPE(""), BS_DEVICE_TYPE_ID(""), CUSTOMER_NAME(""), DEVICE_ID(""), DEVICE_NAME(""), DEVICE_REALTYPE_ID(""), DEVICE_REALTYPE_NAME(""), FEATURE(""), FEATURE_PKG_ID(
                ""), GATEWAY_DEVICE_ID(""), GROUP_ID(""), GROUP_NAME(""), GROUP_TYPE(""), LOCATION_NAME(""), NPANXX(""), PACKAGE_ID(""), PACKAGE_NAME(""), PACKAGE_TYPE(""), SIP_DEVICE_ID(""), SUB_ID(
                ""), SUBSCRIBER_TN_ID(""),TN_STATUS("")*/;
        public final String tableName;
        public final String columnName;
        
        private ColumnName(String tableName,String columnName) {
            this.tableName = tableName;
            this.columnName = columnName;
        }
        public String getValue() {
            return tableName;
        }
        public String getTableName() {
            return tableName;
        }
        public String getColumnName() {
            return columnName;
        }
    }

    static enum SearchCondition {
        AND, OR
    }

    enum SortBy {
        ASC, DESC
    }

    String getEnumName(ColumnName columnName);
    String getEnumValue(ColumnName columnName);
    String getEnumName(SearchCondition searchCondition);
    String getEnumName(SortBy sortBy);

    SearchCriteria getSearchCriteria();

    SortCriteria getSortCriteria();

    Container getContainer();
    
}


