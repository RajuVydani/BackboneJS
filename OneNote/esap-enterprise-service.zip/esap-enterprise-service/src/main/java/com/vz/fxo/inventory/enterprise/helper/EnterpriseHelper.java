package com.vz.fxo.inventory.enterprise.helper;

import java.sql.Connection;

import com.vz.fxo.inventory.enterprise.support.Enterprise;

public class EnterpriseHelper {

	public Enterprise getEnterprise(Connection connection) {
		return new Enterprise(connection);
	}
}
