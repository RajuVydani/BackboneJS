package com.vz.fxo.inventory.model.pc;

import java.util.Date;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

@XmlAccessorType(XmlAccessType.FIELD)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
public class OrderStatus {
	@XmlElement(name = "System")
	@JsonProperty(value = "System")
	private String system;
	
	@XmlElement(name = "StatusCode")
	@JsonProperty(value = "StatusCode")
	private String statusCode;
	
	@XmlElement(name = "TimeStamp")
	@JsonProperty(value = "TimeStamp")
	private Date timeStamp;
	
	@XmlElement(name = "StatusDescription")
	@JsonProperty(value = "StatusDescription")
	private String statusDescription;
	
	@XmlElement(name = "Milestone")
	@JsonProperty(value = "Milestone")
	private String milestone;
	
	@XmlElement(name = "SystemFunction")
	@JsonProperty(value = "SystemFunction")
	private String systemFunction;
	
	@XmlElement(name = "ResponseCode1")
	@JsonProperty(value = "ResponseCode1")
	private String responseCode1;
	
	@XmlElement(name = "Entity", type = Entity.class)
	@JsonProperty(value = "Entity")
	private List<Entity> entities;

	public void setEntities(List<Entity> entities) {
		this.entities = entities;
	}

	public List<Entity> getEntities() {
		return entities;
	}

	public Date getTimeStamp() {
		return timeStamp;
	}

	public void setTimeStamp(Date timeStamp) {
		this.timeStamp = timeStamp;
	}

	public String getSystem() {
		return system;
	}

	public void setSystem(String system) {
		this.system = system;
	}

	public String getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}

	public String getStatusDescription() {
		return statusDescription;
	}

	public void setStatusDescription(String statusDescription) {
		this.statusDescription = statusDescription;
	}

	public String getMilestone() {
		return milestone;
	}

	public void setMilestone(String milestone) {
		this.milestone = milestone;
	}

	public String getResponseCode1() {
		return responseCode1;
	}

	public void setResponseCode1(String responseCode1) {
		this.responseCode1 = responseCode1;
	}
	
	public String getSystemFunction() {
		return systemFunction;
	}

	public void setSystemFunction(String systemFunction) {
		this.systemFunction = systemFunction;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "OrderStatus [system=" + system + ", statusCode=" + statusCode
				+ ", timeStamp=" + timeStamp + ", statusDescription="
				+ statusDescription + ", milestone=" + milestone
				+ ", systemFunction=" + systemFunction + ", responseCode1="
				+ responseCode1 + ", entities=" + entities + "]";
	}


	
}
