package com.vz.fxo.inventory.model.pc;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

@XmlRootElement(name = "VOIPOrderResponse")
@XmlAccessorType(XmlAccessType.FIELD)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
public class VoipOrderResponse implements java.io.Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private static final Logger LOG = LoggerFactory
			.getLogger(VoipOrderResponse.class);
	
	@XmlElement(name = "OrderHeader")
	@JsonProperty(value = "OrderHeader")
	private OrderHeader orderHeader;
	
	@XmlElement(name = "OrderStatus")
	@JsonProperty(value = "OrderStatus")
	private OrderStatus orderStatus;
	
	@XmlElement(name = "NBSConfig")
	@JsonProperty(value = "NBSConfig")
	private NBSConfig  nBSConfig;
		
	@XmlElement(name = "SBCActivation")
	@JsonProperty(value = "SBCActivation")
	private String sbcActivation;
	
	@XmlElement(name = "SBCRollback")
	@JsonProperty(value = "SBCRollback")
	private String sbcRollback;
	

	@XmlElement(name = "SBCRollbackReason")
	@JsonProperty(value = "SBCRollbackReason")
	private String sbcRollbackReason;
	
	@XmlElement(name = "SBCRollbackComment")
	@JsonProperty(value = "SBCRollbackComment")
	private String sbcRollbackComment;
	
	@XmlElement(name = "ManualSBCSelection")
	@JsonProperty(value = "ManualSBCSelection")
	private String manualSBCSelection;
	
	@XmlElement(name = "VpnName")
	@JsonProperty(value = "VpnName")
	private String vpnName;
	
	@XmlElement(name = "DNSFlag")
	@JsonProperty(value = "DNSFlag")
	private String dnsFlag;
	
	@XmlElement(name = "BSNode")
	@JsonProperty(value = "BSNode")
	private String bsNode;
	
	@XmlElement(name = "HomingTabPull")
	@JsonProperty(value = "HomingTabPull")
	private String homingTabPull;

	@XmlElement(name = "CircuitID")
	@JsonProperty(value = "CircuitID")
	private String circuitID;
	
	@XmlElement(name = "ProvisioningCancel")
	@JsonProperty(value = "ProvisioningCancel")
	private String provisioningCancel;
	
	@XmlElement(name = "HoldForCDDD")
	@JsonProperty(value = "HoldForCDDD")
	private String holdForCDDD;
	
	@XmlElement(name = "HoldForHOTCUT")
	@JsonProperty(value = "HoldForHOTCUT")
	private String holdForHOTCUT;
	
	@XmlElement(name = "TN")
	@JsonProperty(value = "TN")
	private String tn;
	
	@XmlElement(name = "SBCDeactivation")
	@JsonProperty(value = "SBCDeactivation")
	private String sbcDeactivation;
	
	@XmlElement(name = "TransitionType")
	@JsonProperty(value = "TransitionType")
	private String transitionType;

	
	public OrderHeader getOrderHeader() {
		return orderHeader;
	}
	public void setOrderHeader(OrderHeader orderHeader) {
		this.orderHeader = orderHeader;
	}
	public OrderStatus getOrderStatus() {
		return orderStatus;
	}
	public void setOrderStatus(OrderStatus orderStatus) {
		this.orderStatus = orderStatus;
	}
	
	public String getSbcActivation() {
		return sbcActivation;
	}
	public void setSbcActivation(String sbcActivation) {
		this.sbcActivation = sbcActivation;
	}
	public String getSbcRollback() {
		return sbcRollback;
	}
	public void setSbcRollback(String sbcRollback) {
		this.sbcRollback = sbcRollback;
	}
	public String getSbcRollbackReason() {
		return sbcRollbackReason;
	}
	public void setSbcRollbackReason(String sbcRollbackReason) {
		this.sbcRollbackReason = sbcRollbackReason;
	}
	public String getSbcRollbackComment() {
		return sbcRollbackComment;
	}
	public void setSbcRollbackComment(String sbcRollbackComment) {
		this.sbcRollbackComment = sbcRollbackComment;
	}
	public String getManualSBCSelection() {
		return manualSBCSelection;
	}
	public void setManualSBCSelection(String manualSBCSelection) {
		this.manualSBCSelection = manualSBCSelection;
	}
	public String getVpnName() {
		return vpnName;
	}
	public void setVpnName(String vpnName) {
		this.vpnName = vpnName;
	}
	public String getDnsFlag() {
		return dnsFlag;
	}
	public void setDnsFlag(String dnsFlag) {
		this.dnsFlag = dnsFlag;
	}
	public String getBsNode() {
		return bsNode;
	}
	public void setBsNode(String bsNode) {
		this.bsNode = bsNode;
	}
	public String getHomingTabPull() {
		return homingTabPull;
	}
	public void setHomingTabPull(String homingTabPull) {
		this.homingTabPull = homingTabPull;
	}
	public String getCircuitID() {
		return circuitID;
	}
	public void setCircuitID(String circuitID) {
		this.circuitID = circuitID;
	}
	public String getProvisioningCancel() {
		return provisioningCancel;
	}
	public void setProvisioningCancel(String provisioningCancel) {
		this.provisioningCancel = provisioningCancel;
	}
	public String getHoldForCDDD() {
		return holdForCDDD;
	}
	public void setHoldForCDDD(String holdForCDDD) {
		this.holdForCDDD = holdForCDDD;
	}
	public String getHoldForHOTCUT() {
		return holdForHOTCUT;
	}
	public void setHoldForHOTCUT(String holdForHOTCUT) {
		this.holdForHOTCUT = holdForHOTCUT;
	}
	public String getTn() {
		return tn;
	}
	public void setTn(String tn) {
		this.tn = tn;
	}
	public String getSbcDeactivation() {
		return sbcDeactivation;
	}
	public void setSbcDeactivation(String sbcDeactivation) {
		this.sbcDeactivation = sbcDeactivation;
	}
	public String getTransitionType() {
		return transitionType;
	}
	public void setTransitionType(String transitionType) {
		this.transitionType = transitionType;
	}
	
	/**
	 * @return the nBSConfig
	 */
	public NBSConfig getnBSConfig() {
		return nBSConfig;
	}
	/**
	 * @param nBSConfig the nBSConfig to set
	 */
	public void setnBSConfig(NBSConfig nBSConfig) {
		this.nBSConfig = nBSConfig;
	}
	
	/**
	 * @param orderstatus
	 * @return
	 */
	public Map<String, String> getEntityMap(OrderStatus orderstatus) {
		Map<String, String> entityMap = new HashMap<>();

		List<Entity> entities =orderstatus.getEntities();

		for (Entity entity : entities) {
			LOG.debug("<Entity>::" + entity.getType() + "::" + entity.getValue());
			entityMap.put(entity.getType(), entity.getValue());
		}
		LOG.debug("RVOIP:: Leaving getEntityMap() with size {}", entityMap.size());
		return entityMap;
	}
	
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "VoipOrderResponse [orderHeader=" + orderHeader
				+ ", orderStatus=" + orderStatus + ", nBSConfig=" + nBSConfig
				+ ", sbcActivation=" + sbcActivation
				+ ", sbcRollback=" + sbcRollback + ", sbcRollbackReason="
				+ sbcRollbackReason + ", sbcRollbackComment="
				+ sbcRollbackComment + ", manualSBCSelection="
				+ manualSBCSelection + ", vpnName=" + vpnName + ", dnsFlag="
				+ dnsFlag + ", bsNode=" + bsNode + ", homingTabPull="
				+ homingTabPull + ", circuitID=" + circuitID
				+ ", provisioningCancel=" + provisioningCancel
				+ ", holdForCDDD=" + holdForCDDD + ", holdForHOTCUT="
				+ holdForHOTCUT + ", tn=" + tn + ", sbcDeactivation="
				+ sbcDeactivation + ", transitionType=" + transitionType + "]";
	}
	
}
