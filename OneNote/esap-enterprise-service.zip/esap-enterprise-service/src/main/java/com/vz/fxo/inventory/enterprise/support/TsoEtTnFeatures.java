package com.vz.fxo.inventory.enterprise.support;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import esap.db.DBTblTsoEtTnFeatures;
import esap.db.TblTsoEtTnFeaturesQuery;
import esap.db.TblVzbFeaturesQuery;

/**
 * @author Sandip Banerjee
 *
 */

public class TsoEtTnFeatures extends TsoEtTnFeaturesBean {
	
	private static Logger log = LoggerFactory.getLogger(TsoEtTnFeatures.class.toString());
	
	private InvErrorCode status;
    Connection dbCon;
    String statusDesc;
    
    public TsoEtTnFeatures(Connection dbCon){
        this.dbCon = dbCon;	
	 }
	 
	 public TsoEtTnFeatures(TsoEtTnFeaturesBean etTnFeatDbBean, Connection dbCon){
	        super(etTnFeatDbBean);
	        this.dbCon = dbCon;			
	 }
    
    
	public InvErrorCode getStatus() {
		return status;
	}
	public void setStatus(InvErrorCode status) {
		this.status = status;
	}
	public Connection getDbCon() {
		return dbCon;
	}
	public void setDbCon(Connection dbCon) {
		this.dbCon = dbCon;
	}
	public String getStatusDesc() {
		return statusDesc;
	}
	public void setStatusDesc(String statusDesc) {
		this.statusDesc = statusDesc;
	}
    
public boolean addToDB() throws SQLException,Exception{
		
		DBTblTsoEtTnFeatures   tsoEtTnFeaturesDbBean=new DBTblTsoEtTnFeatures();
		if(etTnFeatureId <= 0){
			etTnFeatureId = tsoEtTnFeaturesDbBean.getEtTnFeatureIdSeqNextVal(dbCon);
		}
		tsoEtTnFeaturesDbBean.setEtTnFeatureId(etTnFeatureId);
		tsoEtTnFeaturesDbBean.setEtTnId(etTnId);
		tsoEtTnFeaturesDbBean.setFeatureId(featureId);
		
		if (createdBy != null && !createdBy.trim().equals(""))
			tsoEtTnFeaturesDbBean.setCreatedBy(createdBy);
		else
			tsoEtTnFeaturesDbBean.setCreatedBy("ESAP_INV");
		
		if (modifiedBy != null && !modifiedBy.trim().equals(""))
			tsoEtTnFeaturesDbBean.setModifiedBy(modifiedBy);
		else
			tsoEtTnFeaturesDbBean.setModifiedBy("ESAP_INV");
		
		tsoEtTnFeaturesDbBean.setCreationDate(new Timestamp(System.currentTimeMillis()));
		tsoEtTnFeaturesDbBean.setLastModifiedDate(new Timestamp(System.currentTimeMillis()));
		tsoEtTnFeaturesDbBean.setEnvOrderId(envOrderId);	
		
		tsoEtTnFeaturesDbBean.insert(dbCon);
		
		return true;
	}

	public boolean modifyInDB() throws SQLException, Exception {
		
	    if (etTnFeatureId == 0)
	     {
	         //setStatus(InvErrorCode.MISSING_etTnFeatureId);
	         log.info("FAILURE in modifyInDB etTnFeature. etTnFeature Id missing.");
	         return false;
	     }
	    	DBTblTsoEtTnFeatures   tsoEtTnFeaturesDbBean = getTsoEtTnFeaturesToUpdate();
	    	log.info("Got TsoEtTnFeatures Details to Update for etTnFeatureId:" + etTnFeatureId);
	    	tsoEtTnFeaturesDbBean.whereEtTnFeatureIdEQ(etTnFeatureId);
	    	log.info("Going to Update eTsoEtTnFeatures in DB");
	    	//FkValidationUtil.isValidLocationForMod(dbCon,tsoEnterpriseDbBean);
	     
	     if ( tsoEtTnFeaturesDbBean.updateSpByWhere(dbCon) <= 0 ) {
	     	log.info("No TsoEtTnFeatures updated");
	     	//setStatus(InvErrorCode.NO_TsoEtTnFeatures_UPDATED);
	     	return false;
	     }
	     log.info("Successfully updated TsoEtTnFeatures");
	     setStatus(InvErrorCode.SUCCESS);
	     log.info("Successfully UPDATED TsoEtTnFeatures into the DB");
	     
	 return true;
	}
	 
	private DBTblTsoEtTnFeatures getTsoEtTnFeaturesToUpdate() throws SQLException {
		DBTblTsoEtTnFeatures   tsoEtTnFeaturesDbBean=new DBTblTsoEtTnFeatures();
	 /* Create a new instance of TsoEtTnFeaturesBean. The new instance
	  * would hold default values for the all the TsoEtTnFeaturesBean fields.*/
		TsoEtTnFeaturesBean defaultTsoEtTnFeaturesBean = new TsoEtTnFeaturesBean();
		TsoEtTnFeatures inputTsoEtTnFeatures = this;
		tsoEtTnFeaturesDbBean.setEtTnFeatureId(etTnFeatureId);
		TblTsoEtTnFeaturesQuery tsoEtTnFetQry=new TblTsoEtTnFeaturesQuery();
		tsoEtTnFetQry.whereEtTnFeatureIdEQ(inputTsoEtTnFeatures.getEtTnFeatureId());
		tsoEtTnFetQry.query(dbCon);
			if (inputTsoEtTnFeatures.getEtTnId() != 0 && inputTsoEtTnFeatures.getEtTnId()!=defaultTsoEtTnFeaturesBean.getEtTnId()){
				tsoEtTnFeaturesDbBean.setEtTnId(inputTsoEtTnFeatures.getEtTnId());
			}
			if (inputTsoEtTnFeatures.getFeatureId() != 0 && inputTsoEtTnFeatures.getFeatureId()!=defaultTsoEtTnFeaturesBean.getFeatureId()){
				tsoEtTnFeaturesDbBean.setFeatureId(inputTsoEtTnFeatures.getFeatureId());
			}
			if (inputTsoEtTnFeatures.getModifiedBy() != null && !inputTsoEtTnFeatures.getModifiedBy().equals(defaultTsoEtTnFeaturesBean.getModifiedBy())){
				tsoEtTnFeaturesDbBean.setModifiedBy(inputTsoEtTnFeatures.getModifiedBy());
			}
			if (inputTsoEtTnFeatures.getLastModifiedDate()!= null && !inputTsoEtTnFeatures.getLastModifiedDate().equals(defaultTsoEtTnFeaturesBean.getLastModifiedDate())){
				tsoEtTnFeaturesDbBean.setLastModifiedDate(inputTsoEtTnFeatures.getLastModifiedDate());
			}
			if (inputTsoEtTnFeatures.getEnvOrderId() != 0 && inputTsoEtTnFeatures.getEnvOrderId()!=defaultTsoEtTnFeaturesBean.getEnvOrderId()){
				tsoEtTnFeaturesDbBean.setEnvOrderId(inputTsoEtTnFeatures.getEnvOrderId());
			}
	
	return tsoEtTnFeaturesDbBean;
	}

	public boolean deleteFromDB() throws SQLException, Exception {
		
		if(getEtTnFeatureId() == 0){
			log.info("Invalid Input");
			setStatus(InvErrorCode.INVALID_INPUT);
			return false;
		}
					
		DBTblTsoEtTnFeatures   tsoEtTnFeaturesDbBean=new DBTblTsoEtTnFeatures();
		tsoEtTnFeaturesDbBean.whereEtTnFeatureIdEQ(etTnFeatureId);
		tsoEtTnFeaturesDbBean.deleteByWhere(dbCon);
		
		log.info("Successfully deleted tsoEtTnFeatures");
		setStatusDesc("Successfully deleted tsoEtTnFeatures ");
		
		return true;
	  }
	
	 public List<String>  getETTnLineFeaturesByETTnId (long etTnId) throws Exception {
		 log.info("In getETTnLineFeaturesByETTnId");

		 List<String>  etTnFeaturesList = new ArrayList<String>();
		 StringBuffer sql = new StringBuffer();
		 PreparedStatement pStmt = null;
		 ResultSet rs = null;
		 try{
			 sql.append("select feature_id from tbl_tso_et_tn_features where et_tn_id = ?");
			 log.info(" Sql  " + sql.toString() );

			 pStmt = dbCon.prepareStatement(sql.toString());
			 pStmt.setInt(1, (int)etTnId);
			 if (pStmt != null){
				 rs = pStmt.executeQuery();
				 while ( rs.next()){
					 long featureId = rs.getLong(1);
					 //get the feature name
					 TblVzbFeaturesQuery vzbFeatsQry = new TblVzbFeaturesQuery();
					 vzbFeatsQry.whereFeatureIdEQ((int)featureId);
					 vzbFeatsQry.query(dbCon);
					 if (vzbFeatsQry.size() > 0) {
						 etTnFeaturesList.add(vzbFeatsQry.getDbBean(0).getName());
					 }
				 }
			 }
			 log.info(" etTnFeaturesList :: "+etTnFeaturesList.size());
		 }catch (SQLException e) {
			 e.printStackTrace();
			 log.info("DB_FAILURE in getETTnLineFeaturesByETTnId");
			 //return regionId;
			 throw e;
		 }catch (Exception e) {
			 e.printStackTrace();
			 throw e;
		 }finally{
			 if (pStmt != null){
				 pStmt.close();
			 }
			 if ( rs != null ){
				 rs.close();
			 }
		 }

		 return etTnFeaturesList;
	 }
	
	 public List<String>  getETTnLineFeaturesByTN (String tn) throws Exception {
		 log.info("In getETTnLineFeaturesByTN ");
		 StringBuffer sql = new StringBuffer();
		 PreparedStatement pStmt = null;
		 ResultSet rs = null;
		 List<String>  etTnFeaturesList = new ArrayList<String>();
		 try{
			 sql.append("select ettn.ET_TN_ID from tbl_tso_et_tn ettn ,tbl_public_tn_pool tp where ettn.tn_pool_id = tp.tn_pool_id and tp.tn= \'" + tn +"\'");
			 pStmt = dbCon.prepareStatement(sql.toString());
			 if (pStmt != null){
				 rs = pStmt.executeQuery();
				 while ( rs.next()){
					 long etTnID = rs.getInt(1);
					 log.info("etTnId :: "+etTnID);
					 if(etTnID >= 0 ){
						 etTnFeaturesList.addAll(0,getETTnLineFeaturesByETTnId(etTnID));
					 }
				 }
			 }
			 log.info(" Features list size in getETTnLineFeaturesByTN : "+etTnFeaturesList.size());
		 }catch (SQLException e) {
			 e.printStackTrace();
			 log.info("DB_FAILURE in getETTnLineFeaturesByTN");
			 //return regionId;
			 throw e;
		 }catch (Exception e) {
			 e.printStackTrace();
			 throw e;
		 }finally{
			 if (pStmt != null){
				 pStmt.close();
			 }
			 if ( rs != null ){
				 rs.close();
			 }
		 }

		 return etTnFeaturesList;

	 }
	 
	 public boolean deleteFromDbByEtTnAndFeatureId() throws SQLException,  Exception{
		 boolean ret_code = true;		 
		 try
		 {
			 if ( featureId <= 0 ) {
				 log.info("FAILURE in deleteFromDBByEtTnAndFeatureId EtTnFeatures. Invalid featureId.");
				 return false;
			 }
			 if ( etTnId <= 0 ) {
				 log.info("FAILURE in deleteFromDBByEtTnAndFeatureId EtTnFeatures. Invalid etTnId.");
				 return false;
			 }
			 
			 DBTblTsoEtTnFeatures etTnFeatures = new  DBTblTsoEtTnFeatures();		       
			 etTnFeatures.whereFeatureIdEQ(getFeatureId());
			 etTnFeatures.whereEtTnIdEQ(getEtTnId());
			 
			 int etTnFeatureDeleted = etTnFeatures.deleteByWhere(dbCon);
			 log.info("etTnFeatureDeleted : " + etTnFeatureDeleted);
			 setStatus(InvErrorCode.SUCCESS);
		 }catch(SQLException s)
		 {
			 throw s;
		 }
		 catch (Exception e) {
			 throw e;
		 }
		 return ret_code; 
	 }
	 
	 public boolean deleteFromDBByEtTn() throws SQLException,  Exception{
		 boolean ret_code = true;		 
		 try
		 {
			 if ( etTnId <= 0 ) {
				 log.info("FAILURE in deleteFromDBByEtTn EtTnFeatures. Invalid ETTnId.");
				 return false;
			 }
			 DBTblTsoEtTnFeatures etTnFeatures= new  DBTblTsoEtTnFeatures();		       
			 etTnFeatures.whereEtTnIdEQ(getEtTnId());

			 int etTnFeatureDeleted = etTnFeatures.deleteByWhere(dbCon);
			 log.info("etTnFeatureDeleted : " + etTnFeatureDeleted);

			 setStatus(InvErrorCode.SUCCESS);
		 }catch(SQLException s)
		 {
			 throw s;
		 }
		 catch (Exception e) {
			 throw e;
		 }
		 return ret_code; 
	 }
}
