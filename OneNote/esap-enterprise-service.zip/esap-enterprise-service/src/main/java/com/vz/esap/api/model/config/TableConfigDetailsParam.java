package com.vz.esap.api.model.config;

public class TableConfigDetailsParam {
		
	private Long configParamId;
	private String processName;
	private String paramGroup;
	private String paramName;
	private String paramValue;
	private String status;
	private String description;
	
	private TableConfigDetailsParam(TableConfigDetailsParamBuilder tableConfigDetailsParamBuilder) {
		this.configParamId = tableConfigDetailsParamBuilder.configParamId;
		this.processName = tableConfigDetailsParamBuilder.processName;
		this.paramGroup = tableConfigDetailsParamBuilder.paramGroup;
		this.paramName = tableConfigDetailsParamBuilder.paramName;
		this.paramValue = tableConfigDetailsParamBuilder.paramValue;
		this.status = tableConfigDetailsParamBuilder.status;
		this.description = tableConfigDetailsParamBuilder.description;
	}
	
	public Long getConfigParamId() {
		return configParamId;
	}
	public void setConfigParamId(Long configParamId) {
		this.configParamId = configParamId;
	}
	public String getProcessName() {
		return processName;
	}
	public void setProcessName(String processName) {
		this.processName = processName;
	}
	public String getParamGroup() {
		return paramGroup;
	}
	public void setParamGroup(String paramGroup) {
		this.paramGroup = paramGroup;
	}
	public String getParamName() {
		return paramName;
	}
	public void setParamName(String paramName) {
		this.paramName = paramName;
	}
	public String getParamValue() {
		return paramValue;
	}
	public void setParamValue(String paramValue) {
		this.paramValue = paramValue;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("TableConfigDetailsParam [configParamId=");
		builder.append(configParamId);
		builder.append(", processName=");
		builder.append(processName);
		builder.append(", paramGroup=");
		builder.append(paramGroup);
		builder.append(", paramName=");
		builder.append(paramName);
		builder.append(", paramValue=");
		builder.append(paramValue);
		builder.append(", status=");
		builder.append(status);
		builder.append(", description=");
		builder.append(description);
		builder.append("]");
		return builder.toString();
	}
	
	public static class TableConfigDetailsParamBuilder {
		private Long configParamId;
		private String processName;
		private String paramGroup;
		private String paramName;
		private String paramValue;
		private String status;
		private String description;
		
		public TableConfigDetailsParamBuilder withConfigParamId(Long configParamId) {
			this.configParamId = configParamId;
			return this;
		}
		
		public TableConfigDetailsParamBuilder withProcessName(String processName) {
			this.processName = processName;
			return this;
		}
		
		public TableConfigDetailsParamBuilder withParamGroup(String paramGroup) {
			this.paramGroup = paramGroup;
			return this;
		}
		public TableConfigDetailsParamBuilder withParamName(String paramName) {
			this.paramName = paramName;
			return this;
		}
		public TableConfigDetailsParamBuilder withParamValue(String paramValue) {
			this.paramValue = paramValue;
			return this;
		}
		public TableConfigDetailsParamBuilder withStatus(String status) {
			this.status = status;
			return this;
		}
		public TableConfigDetailsParamBuilder withDescription(String description) {
			this.description = description;
			return this;
		}
		
		public TableConfigDetailsParam build() {
			return new TableConfigDetailsParam(this);
		}
		
	}
	
	
}
