/**
 * 
 */
package com.vz.esap.api.connector.service.impl;

import java.util.HashMap;
import java.util.Map;

import ma.glasnost.orika.BoundMapperFacade;
import ma.glasnost.orika.MapperFactory;
import ma.glasnost.orika.impl.DefaultMapperFactory;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.vz.esap.api.exception.ApplicationInterfaceException;
import com.vz.esap.api.generated.pojo.BsasMapping;
import com.vz.esap.api.generated.pojo.ConfigDetailResponse;
import com.vz.esap.api.generated.pojo.ConfigParam;
import com.vz.esap.api.generated.pojo.Device;
import com.vz.esap.api.generated.pojo.DeviceCLLIConfigResponse;
import com.vz.esap.api.generated.pojo.NameValuePair;
import com.vz.esap.api.model.ConfigDomainServiceRequest;
import com.vz.esap.api.model.DeviceClliServiceRequest;
import com.vz.esap.api.model.config.BsAsConfigData;

/**
 * @author Deepak Kumar
 * 
 */
@Service
public class ConfigDomainDataServiceImpl {

	private static final Logger logger = LoggerFactory
			.getLogger(ConfigDomainDataServiceImpl.class);
	
	private static final String CONFIG_DOMAIN_SERVICE = "ConfigDomainService:";
	
/*	@Autowired
	private RestTemplate restTemplate;*/
	private RestTemplate restTemplate = new RestTemplate();
	@Value("${configDomain.getAllDevicesForClli}")
	private String deviceCLLiServiceURL;
		
	@Value("${configDomain.getConfigDetails}")
	private String configDetailServiceURL;

	
	public HashMap<String, String> getRouterInfo(String bsClli) throws ApplicationInterfaceException {
		logger.info("getRouterInfo(): Start");
		HashMap<String, String> deviceConfig = null;

		try {
			DeviceClliServiceRequest deviceClliServiceRequest = new DeviceClliServiceRequest();
			deviceClliServiceRequest.setBaseClli(bsClli);
			
			//System.out.println("getRouterInfo() URL:  " + deviceCLLiServiceURL);
			logger.info("getRouterInfo(): URL:{} ", deviceCLLiServiceURL);
			logger.debug("getRouterInfo() Request: {} ",  deviceClliServiceRequest);
			
			long startTime = System.currentTimeMillis();
			logger.info("getRouterInfo(): Making HTTP POST Request for bsClli:{} at time:{}", bsClli, startTime);

			DeviceCLLIConfigResponse configResp = restTemplate.postForObject(
					deviceCLLiServiceURL, deviceClliServiceRequest,
					DeviceCLLIConfigResponse.class);
			
			long endTime = System.currentTimeMillis();
			
			logger.info("getRouterInfo(): Received HTTP POST Response for bsClli:{} at time:{}", bsClli, endTime);
			logger.info("getRouterInfo(): Time taken for Response for bsClli:{} is:{} ms", bsClli, (endTime-startTime));
			logger.debug("getRouterInfo(): Response from Config: : {} ", configResp);
			
			deviceConfig = new HashMap<String, String>();
			
			if (configResp.getBsConfigData() != null){
				
				//Only considering first device for router information as per existing logic//
				Device device  = configResp.getBsConfigData().getDevices().get(0);
				for (NameValuePair nameValuePair : device.getNameValuePair()){
					deviceConfig.put(nameValuePair.getParamName(), nameValuePair.getParamValue());
				}
			}
			 /* //DEV_RIVLABBSF01_1  */
			/* deviceConfig.put("BROADSOFT_IP","166.38.97.225"); 
			 deviceConfig.put("BROADSOFT_PORT", "2208");
			 deviceConfig.put("BROADSOFT_CONN_MODE", "OCS");
			 deviceConfig.put("PROV_USERNAME", "esap_prov");
			 deviceConfig.put("PROV_PASSWORD", "H4pnAnHBbeU=");
			 deviceConfig.put("ENCRYPT_BS_PASSWORD", "");
			 deviceConfig.put("BROADSOFT_VERSION", "17.0");*/

		} catch (HttpStatusCodeException e) {
			logger.error("Exception received from ConfigDomain Service: : {} ", e);
			logger.error("Exception received from ConfigDomain Service URL: {} ", deviceCLLiServiceURL);
			logger.error("Execption during getRouterInfo execution code:{} , text:{}", e.getStatusCode(), e.getResponseBodyAsString());
			throw new ApplicationInterfaceException(CONFIG_DOMAIN_SERVICE + e.getMessage());
		} catch (RestClientException e) {
			logger.error("Exception received from ConfigDomain Service URL: : {}", deviceCLLiServiceURL);
			logger.error("Exception received from getRouterInfo ConfigDomain Service: : {} ", e);
			throw new ApplicationInterfaceException(CONFIG_DOMAIN_SERVICE + e.getMessage());
		}
		return deviceConfig;
	}
	
	
	public int getActivationFlag(String bsClli,String bsAsId) throws ApplicationInterfaceException {
		
		logger.info("getActivationFlag(): Start bsClli : {} bsAsId :{}",bsClli,bsAsId);
		int response = 0;

		try {
			DeviceClliServiceRequest deviceClliServiceRequest = new DeviceClliServiceRequest();
			deviceClliServiceRequest.setBaseClli(bsClli);
			
			//System.out.println("getActivationFlag() URL:  " + deviceCLLiServiceURL);
			logger.info("getActivationFlag(): URL:{} ", deviceCLLiServiceURL);

			logger.debug("getActivationFlag() Request: {} ",  deviceClliServiceRequest);
			
			long startTime = System.currentTimeMillis();
			logger.info("getActivationFlag(): Making HTTP POST Request for bsClli:{} at time:{}", bsClli, startTime);

			DeviceCLLIConfigResponse configResp = restTemplate.postForObject(
					deviceCLLiServiceURL, deviceClliServiceRequest,
					DeviceCLLIConfigResponse.class);

			long endTime = System.currentTimeMillis();

			logger.info("getActivationFlag(): Received HTTP POST Response for bsClli:{} at time:{}", bsClli, endTime);
			logger.info("getActivationFlag(): Time taken for Response for bsClli:{} is:{} ms", bsClli, (endTime-startTime));
			
			logger.debug("getActivationFlag(): Response from Config: : {} ", configResp);
			
			int deviceCount = 0;
			long activationValue = 0;
			if (configResp.getBsConfigData().getBsasMapping() != null){
				
				for (BsasMapping bsasMapping :configResp.getBsConfigData().getBsasMapping() ){
					if (bsasMapping.getBsAsId()==Long.parseLong(bsAsId)){
						activationValue = bsasMapping.getTnActivation();
						deviceCount++;
					}
				}
				
			}
			/* if more than one device found , it would be considered as an error */
			if (deviceCount == 1) {
				if (activationValue == 1) {
					logger.info("getActivationFlag(): Response from Config: : {true} ");
					response = 5;
				} else {
					// Setting new response , 6 means activation is false
					logger.info("getActivationFlag(): Response from Config: : {false} ");
					response = 6;
				}
			} else {
				response = deviceCount;
			}

		} catch (HttpStatusCodeException e) {
			logger.error("Exception received from ConfigDomain Service: : {} ", e);
			logger.error("Exception received from ConfigDomain Service URL : {} ", deviceCLLiServiceURL);
			logger.error("Execption during getRouterInfo execution code:{} , text:{}", e.getStatusCode(), e.getResponseBodyAsString());
			throw new ApplicationInterfaceException(CONFIG_DOMAIN_SERVICE + e.getMessage());
		} catch (RestClientException e) {
			logger.error("Exception received from ConfigDomain Service: : {}", deviceCLLiServiceURL);
			logger.error("Exception received from getRouterInfo ConfigDomain Service: : {} ", e);
			throw new ApplicationInterfaceException(CONFIG_DOMAIN_SERVICE + e.getMessage());
		}
		return response;
	}
	
	
	public BsAsConfigData getBsAsMapping(String bsClli) throws ApplicationInterfaceException {
		

		BsAsConfigData bsAsConfigData = null;

		try {
			DeviceClliServiceRequest deviceClliServiceRequest = new DeviceClliServiceRequest();
			deviceClliServiceRequest.setBaseClli(bsClli);
			
			//System.out.println("getBsAsMapping() URL  " + deviceCLLiServiceURL);
			
			logger.info("getBsAsMapping(): URL: {} ", deviceCLLiServiceURL);

			logger.debug("getBsAsMapping() Request: {}  ",  deviceClliServiceRequest);
			
			long startTime = System.currentTimeMillis();
			logger.info("getBsAsMapping(): Making HTTP POST Request for bsClli:{} at time:{}", bsClli, startTime);


			DeviceCLLIConfigResponse configResp = restTemplate.postForObject(
					deviceCLLiServiceURL, deviceClliServiceRequest,
					DeviceCLLIConfigResponse.class);
			
			long endTime = System.currentTimeMillis();

			logger.info("getBsAsMapping(): Received HTTP POST Response for bsClli:{} at time:{}", bsClli, endTime);
			logger.info("getBsAsMapping(): Time taken for Response for bsClli:{} is:{} ms", bsClli, (endTime-startTime));
			
			logger.debug("getBsAsMapping(): Response from Config: {} ", configResp);
			
			
			if (configResp.getBsConfigData() != null &&  configResp.getBsConfigData().getBsasMapping() != null && 
					configResp.getBsConfigData().getBsasMapping().get(0) != null) {
				BsasMapping bsAsMapping = configResp.getBsConfigData().getBsasMapping().get(0);

				MapperFactory mapperFactory = new DefaultMapperFactory.Builder().build();

				BoundMapperFacade<BsasMapping, BsAsConfigData> boundMapper = mapperFactory.getMapperFacade(BsasMapping.class, BsAsConfigData.class);

				bsAsConfigData = boundMapper.map(bsAsMapping);
			}

		} catch (HttpStatusCodeException e) {
			logger.error("Exception received from ConfigDomain Service URL: {} ", deviceCLLiServiceURL);
			logger.error("Exception received from ConfigDomain Service: : {} ", e);
			logger.error("Execption during getBsAsMapping execution code:{} , text:{}", e.getStatusCode(), e.getResponseBodyAsString());
			throw new ApplicationInterfaceException(CONFIG_DOMAIN_SERVICE + e.getMessage());
		} catch (RestClientException e) {
			logger.error("Exception received from ConfigDomain Service: {} ", deviceCLLiServiceURL);
			logger.error("Exception received from getBsAsMapping ConfigDomain Service: {} ", e);
			throw new ApplicationInterfaceException(CONFIG_DOMAIN_SERVICE + e.getMessage());
		}
		return bsAsConfigData;
	}

	
	public Map<String, String> getTblConfigParamMap(String processName,
			String groupName) throws ApplicationInterfaceException {
		
		HashMap<String, String> configMap = null;

		try {
			ConfigDomainServiceRequest configServiceRequest = new ConfigDomainServiceRequest();
			configServiceRequest.setProcessName(processName);
			configServiceRequest.setParamGroup(groupName);
			
			//System.out.println("getTblConfigParamMap() URL  " + configDetailServiceURL);
			logger.info("getTblConfigParamMap(): URL: {} ", configDetailServiceURL);

			logger.debug("getTblConfigParamMap() Request: {} ", configServiceRequest);
			
			long startTime = System.currentTimeMillis();
			logger.info("getTblConfigParamMap(): Making HTTP POST Request for processName:{} groupName:{} at time:{}", processName, groupName, startTime);
			
			
			ConfigDetailResponse configResp = restTemplate.postForObject(
					configDetailServiceURL, configServiceRequest,
					ConfigDetailResponse.class);

			long endTime = System.currentTimeMillis();

			logger.info("getTblConfigParamMap(): Received HTTP POST Response for processName:{} groupName:{} at time:{}", processName, groupName, endTime);
			logger.info("getTblConfigParamMap(): Time taken for Response for processName:{} groupName:{} is:{} ms", processName, groupName, (endTime-startTime));
			
			logger.debug("getTblConfigParamMap(): Response from Config: {} ", configResp);
			
			if (configResp != null ){
				configMap = new HashMap<String, String>();
				for (ConfigParam configParam : configResp.getConfigParams()){
					configMap.put(configParam.getParamName(), configParam.getParamValue());
				}
			}
			

		} catch (HttpStatusCodeException e) {
			logger.error("Exception received from ConfigDomain Service URL: {} ", configDetailServiceURL);
			logger.error("Exception received from ConfigDomain Service: : {} ", e);
			logger.error("Execption during getTblConfigParamMap execution code:{} , text:{}", e.getStatusCode(), e.getResponseBodyAsString());
			throw new ApplicationInterfaceException(CONFIG_DOMAIN_SERVICE + e.getMessage());
		} catch (RestClientException e) {
			logger.error("Exception received from ConfigDomain Service: {} ", deviceCLLiServiceURL);
			logger.error("Exception received from getTblConfigParamMap ConfigDomain Service: {} ", e);
			throw new ApplicationInterfaceException(CONFIG_DOMAIN_SERVICE + e.getMessage());
		}
		return configMap;
	}

	
	public String getTblConfigParamValue(String processName, String groupName,
			String paramName) throws ApplicationInterfaceException {
		
		String configValue = null;

		try {
			ConfigDomainServiceRequest configServiceRequest = new ConfigDomainServiceRequest();
			configServiceRequest.setProcessName(processName);
			configServiceRequest.setParamGroup(groupName);
			configServiceRequest.setParamName(paramName);
			
			//System.out.println("getTblConfigParamMap() URL  " + configDetailServiceURL);
			logger.info("getTblConfigParamMap(): URL: {} ", configDetailServiceURL);

			logger.debug("getTblConfigParamMap() Request: {}  ", configServiceRequest);
			
			long startTime = System.currentTimeMillis();
			logger.info("getTblConfigParamMap(): Making HTTP POST Request for processName:{} groupName:{} at time:{}", processName, groupName, startTime);
			
			
			ConfigDetailResponse configResp = restTemplate.postForObject(
					configDetailServiceURL, configServiceRequest,
					ConfigDetailResponse.class);

			long endTime = System.currentTimeMillis();

			logger.info("getTblConfigParamMap(): Received HTTP POST Response for processName:{} groupName:{} at time:{}", processName, groupName, endTime);
			logger.info("getTblConfigParamMap(): Time taken for Response for processName:{} groupName:{} is:{} ms", processName, groupName, (endTime-startTime));
			
			logger.debug("getTblConfigParamMap(): Response from Config: {} ", configResp);

			
			if (configResp != null ){
				for (ConfigParam configParam : configResp.getConfigParams()){
					if (configParam.getParamName().equals(paramName)){
						configValue = configParam.getParamValue();
						break;
					}
				}
			}

		} catch (HttpStatusCodeException e) {
			logger.error("Exception received from ConfigDomain Service URL {} ", configDetailServiceURL);
			logger.error("Exception received from ConfigDomain Service: : {} ", e);
			logger.error("Execption during getTblConfigParamMap execution code:{} , text:{}", e.getStatusCode(), e.getResponseBodyAsString());
			throw new ApplicationInterfaceException(CONFIG_DOMAIN_SERVICE + e.getMessage());
		} catch (RestClientException e) {
			logger.error("Exception received from ConfigDomain Service: {} ", deviceCLLiServiceURL);
			logger.error("Exception received from getTblConfigParamMap ConfigDomain Service: {} ", e);
			throw new ApplicationInterfaceException(CONFIG_DOMAIN_SERVICE + e.getMessage());
		}
		return configValue;
	}
	

	
	public String getTblConfigParam(String processName, String paramName) throws ApplicationInterfaceException {
		
		String configValue = null;

		try {
			ConfigDomainServiceRequest configServiceRequest = new ConfigDomainServiceRequest();
			configServiceRequest.setProcessName(processName);
			configServiceRequest.setParamName(paramName);
			
			//System.out.println("getTblConfigParamMap() URL  " + configDetailServiceURL);
			logger.info("getTblConfigParamMap(): URL: {} ", configDetailServiceURL);

			logger.debug("getTblConfigParamMap() Request: {}  ", configServiceRequest);
			
			long startTime = System.currentTimeMillis();
			logger.info("getTblConfigParamMap(): Making HTTP POST Request for processName:{} at time:{}", processName, startTime);
			
			
			ConfigDetailResponse configResp = restTemplate.postForObject(
					configDetailServiceURL, configServiceRequest,
					ConfigDetailResponse.class);

			long endTime = System.currentTimeMillis();

			logger.info("getTblConfigParamMap(): Received HTTP POST Response for processName:{} at time:{}", processName,  endTime);
			logger.info("getTblConfigParamMap(): Time taken for Response for processName:{} groupName:{} is:{} ms", processName, (endTime-startTime));
			
			logger.debug("getTblConfigParamMap(): Response from Config: {} ", configResp);

			
			if (configResp != null ){
				for (ConfigParam configParam : configResp.getConfigParams()){
					if (configParam.getParamName().equals(paramName)){
						configValue = configParam.getParamValue();
						break;
					}
				}
			}

		} catch (HttpStatusCodeException e) {
			logger.error("Exception received from ConfigDomain Service URL: {} ", configDetailServiceURL);
			logger.error("Exception received from ConfigDomain Service: : {} ", e);
			logger.error("Execption during getTblConfigParamMap execution code:{} , text:{}", e.getStatusCode(), e.getResponseBodyAsString());
			throw new ApplicationInterfaceException(CONFIG_DOMAIN_SERVICE + e.getMessage());
		} catch (RestClientException e) {
			logger.error("Exception received from ConfigDomain Service URL: {} ", deviceCLLiServiceURL);
			logger.error("Exception received from getTblConfigParamMap ConfigDomain Service: {} ", e);
			throw new ApplicationInterfaceException(CONFIG_DOMAIN_SERVICE + e.getMessage());
		}
		return configValue;
	}
}
