package com.vz.fxo.inventory.enterprise.support;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Timestamp;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import esap.db.DBTblAuthServices;
import esap.db.DBTblPolicies;
import esap.db.DBTblPoliciesService;
import esap.db.DBTblVzbFeatures;
import esap.db.TblAuthServicesQuery;
import esap.db.TblPoliciesDbBean;
import esap.db.TblPoliciesQuery;
import esap.db.TblPoliciesServiceQuery;
import esap.db.TblVzbFeaturesDbBean;
import esap.db.TblVzbFeaturesQuery;

public class PolicyFeatures extends PolicyFeaturesBean
{
	private static Logger log = LoggerFactory.getLogger(PolicyFeatures.class.toString());
	
	Connection dbCon;
    String statusDesc;
    InvErrorCode statusCode = InvErrorCode.INTERNAL_ERROR;

	public int getStatusCode() {
		return statusCode.getErrorCode();
	}
	public void setStatusCode(InvErrorCode statusCode) {
		this.statusCode = statusCode;
	}
    public String getStatusDesc()
    {
        return statusDesc;
    }

    public void setStatusDesc(String statusDesc)
    {
        this.statusDesc = statusDesc;
    }

    public Connection getDbCon()
    {
        return dbCon;
    }

    public void setDbCon(Connection dbCon)
    {
        this.dbCon = dbCon;
    }

    public PolicyFeatures(Connection dbCon)
    {
        this.dbCon = dbCon;
    }

    public PolicyFeatures(PolicyFeaturesBean featsBean, Connection dbCon)
    {
        super(featsBean);
        this.dbCon = dbCon;
    }

	public boolean addPolicyServices()
	{
		log.info("Entering Features : addAuthServices()");
		try
		{
			DBTblPoliciesService policyServiceDbBean = new DBTblPoliciesService();
			policyServiceDbBean.setPoliciesServiceId(getPolicyServiceId());
			log.info("PolicyServiceId is {}" , getPolicyServiceId());
			policyServiceDbBean.setPolicyId(getPolicyFeaturesDbBean().getPolicyId());
		
               if(getEnvOrderId() > 0)
            	   policyServiceDbBean.setEnvOrderId((int)getEnvOrderId());	
		//	else
			//	policyServiceDbBean.setEnvOrderId();	
            if(getCreatedBy() != null && !getCreatedBy().equals("") )
            	policyServiceDbBean.setCreatedBy(getCreatedBy());
			else
				policyServiceDbBean.setCreatedBy("ESAP_INV");
			if(getModifiedBy() != null && !getModifiedBy().equals(""))
				policyServiceDbBean.setModifiedBy(getModifiedBy());
			else
				policyServiceDbBean.setModifiedBy("ESAP_INV");

			policyServiceDbBean.setCreationDate(new Timestamp(System.currentTimeMillis()));
			policyServiceDbBean.setLastModifiedDate(new Timestamp(System.currentTimeMillis()));

            log.info("PolicyId ID is {}" , policyServiceDbBean.getPolicyId());

            policyServiceDbBean.insert(dbCon);
		}
		catch(SQLException s)
		{
			s.printStackTrace();
			setStatusCode(InvErrorCode.DB_EXCEPTION);
			setStatusDesc("DB_FAILURE in addPolicyServices");
			log.info("DB_FAILURE in addPolicyServices");
			return false;
		}
		setStatusCode(InvErrorCode.SUCCESS);
		setStatusDesc("Successfully inserted addPolicyServices");
		return true;
	}

    public boolean getPolicyFeatureByPolicyNameAndType(String policyName, String policyType)
    {
    	log.info("Entering policyFeatures : getPolicyFeatureByPolicyNameAndType(), arg= {}, {}",policyName,policyType);
        try
        {
        	TblPoliciesQuery policyQry = new TblPoliciesQuery();
            String whereClause = " where policy_name='"+policyName+"' and policy_type='"+policyType+"'";
            policyQry.queryByWhere(dbCon, whereClause);

            if (policyQry.size() <= 0)
            {
                setStatusCode(InvErrorCode.NOTFOUND_VZB_FEATURE);
                log.info("policyFeatures not Found in TblPoliciesQuery matching the inputs");
                return false;
            }

            TblPoliciesDbBean policyFeatBean = policyQry.getDbBean(0);

            policyFeaturesDbBean.setPolicyName(policyFeatBean.getPolicyName());
            policyFeaturesDbBean.setPolicyType(policyFeatBean.getPolicyType());
            policyFeaturesDbBean.setPolicyId(policyFeatBean.getPolicyId());
        }
        catch (SQLException e)
        {
            e.printStackTrace();
            setStatusCode(InvErrorCode.DB_EXCEPTION);
            setStatusDesc("DB_FAILURE in getFeatureByFeatureId");
            return false;
        }
        catch (Exception e)
        {
            e.printStackTrace();
            setStatusCode(InvErrorCode.DB_EXCEPTION);
            setStatusDesc("FAILURE in getFeatureByFeatureId");
            return false;
        }

        setStatusCode(InvErrorCode.SUCCESS);
        setStatusDesc("Successfully retrieved Features");
        return true;
    }

    //EnterpriseId will be set before calling this method.
    /*public boolean getFeatureByEnterpriseId()
    {
        try
        {
            TblVzbFeaturesQuery featQry = new TblVzbFeaturesQuery();

            featQry.query(dbCon);
            if (featQry.size() <= 0)
            {
                LogUtil.info("Feature Id not Found");
            }
            TblVzbFeaturesDbBean featBean = featQry.getDbBean(0);

            setLastModifiedDate(featBean.getLastModifiedDate());
            // setBroadsoftHidden(featBean.getIsBroadsoftHidden());//TODO getIsBroadsoftHidden is undefined for type TblVzbFeaturesDbBean
            setModifiedBy(featBean.getModifiedBy());
            setFeatureType(featBean.getFeatureType());
            setFeatureId(featBean.getFeatureId());
              if(featBean.getIsBillable() == 1)
            	  setIsBillable(true);
              else
            	  setIsBillable(false);
              if(featBean.getIsAuthorized() == 1)
            	  setIsAuthorized(true);
              else
            	  setIsAuthorized(false);
            setIcpId(featBean.getIcpId());
            setIasaId(featBean.getIasaId());
            setPlatformIndicator(featBean.getPlatformIndicator());
            setDescription(featBean.getDescription());
            setName(featBean.getName());

        }
        catch (SQLException e)
        {
            e.printStackTrace();
            setStatusCode(InvErrorCode.DB_EXCEPTION);
            setStatusDesc("DB_FAILURE in getFeatureByEnterpriseId");
            return false;
        }
        catch (Exception e)
        {
            e.printStackTrace();
            setStatusCode(InvErrorCode.DB_EXCEPTION);
            setStatusDesc("FAILURE in getFeatureByEnterpriseId");
            return false;
        }

        setStatusCode(InvErrorCode.SUCCESS);
        setStatusDesc("Successfully retrieved feature");
        return true;
    }*/

    public boolean deletePolicyServices() throws SQLException, Exception
	{
    	log.info("Entering ::deletePolicyServices");

	//	try
	//	{
			if(getPolicyServiceId() <= 0)
                        {
                        setStatusCode(InvErrorCode.INVALID_INPUT);
                        return false;
                        }

			DBTblPoliciesService policyServiceDbBean = new DBTblPoliciesService();
			policyServiceDbBean.wherePoliciesServiceIdEQ(getPolicyServiceId());
			policyServiceDbBean.deleteByWhere(dbCon);
		/*}
		catch (SQLException s)
		{
			s.printStackTrace();
			setStatusCode(InvErrorCode.DB_EXCEPTION);
			setStatusDesc("DB_FAILURE in delete policyServiceDbBean");
			return false;
		}*/
		setStatusCode(InvErrorCode.SUCCESS);
		setStatusDesc("Successfully deleted policyService ");
		return true;
	}

    public boolean updatePolicyServices()
	{
		try
		{
			if(getPolicyServiceId() <= 0){
				setStatusCode(InvErrorCode.INTERNAL_ERROR);
				log.info("FAILURE in updatePolicyServices. PolicyServiceId missing.");
				return false;
			}
			DBTblPoliciesService policyServiceDbBean = getPolicyServicesToUpdate();
			policyServiceDbBean.wherePoliciesServiceIdEQ(getPolicyServiceId());
            if(policyServiceDbBean.updateSpByWhere(dbCon) <= 0)
				return false; 

		} catch(SQLException s) {
            		s.printStackTrace();
			setStatusCode(InvErrorCode.DB_EXCEPTION);
			log.info("DB_FAILURE in updateAuthServices");
			return false;
		}
		setStatusCode(InvErrorCode.SUCCESS);
		setStatusDesc("Successfully update AuthServices");
		return true;
	}
        private DBTblPoliciesService getPolicyServicesToUpdate() throws SQLException {
        DBTblPoliciesService policyServiceDbBean = new DBTblPoliciesService();
		PolicyFeaturesBean defaultPolicyFeatureBean = new PolicyFeaturesBean();


		PolicyFeatures inputFeatures = this;

		/*Set the new fields if required.*/

		policyServiceDbBean.setPoliciesServiceId(getPolicyServiceId());

		if((inputFeatures.getPolicyFeaturesDbBean()).getPolicyId() != (defaultPolicyFeatureBean.getPolicyFeaturesDbBean()).getPolicyId()){
			policyServiceDbBean.setPolicyId((long)inputFeatures.getPolicyFeaturesDbBean().getPolicyId());
		}

	
        if(inputFeatures.getEnvOrderId() != defaultPolicyFeatureBean.getEnvOrderId()){
        	policyServiceDbBean.setEnvOrderId((int)inputFeatures.getEnvOrderId());
		} 
		if(inputFeatures.getModifiedBy() != null &&
				!( "".equalsIgnoreCase(inputFeatures.getModifiedBy()) ))
			policyServiceDbBean.setModifiedBy(getModifiedBy());
		else
			policyServiceDbBean.setModifiedBy("ESAP_INV");

		policyServiceDbBean.setLastModifiedDate(new Timestamp(System.currentTimeMillis()));
		return policyServiceDbBean;
	}

	public boolean getPolicyServicesDetails() throws SQLException
	{
		try
		{
			log.info("In policyFeatures getDetails; PolicyServiceId id="+getPolicyServiceId());
			TblPoliciesServiceQuery policyServiceQry = new TblPoliciesServiceQuery();
			String whereClause = " where policies_service_id = \'"+getPolicyServiceId()+"\'";
			policyServiceQry.queryByWhere(dbCon, whereClause);
			if(policyServiceQry.size() == 1){

				setPolicyServiceId((policyServiceQry.getDbBean(0)).getPoliciesServiceId());				
				TblPoliciesQuery  policiesQuery = new TblPoliciesQuery();
				policiesQuery.wherePolicyIdEQ((int)(policyServiceQry.getDbBean(0)).getPolicyId());
				policiesQuery.query(dbCon);
				if(policiesQuery.size() >  0)
				{
					DBTblPolicies vzbFeatDbBean = new DBTblPolicies();
					vzbFeatDbBean.copyFromBean(policiesQuery.getDbBean(0));
					setPolicyFeaturesDbBean(vzbFeatDbBean);
				}
			
	                        setEnvOrderId((policyServiceQry.getDbBean(0)).getEnvOrderId());		
                         	setCreatedBy((policyServiceQry.getDbBean(0)).getCreatedBy());
				setModifiedBy((policyServiceQry.getDbBean(0)).getModifiedBy());

			}else
			{
				setStatusCode(InvErrorCode.DB_EXCEPTION);
				setStatusDesc("FAILURE in getPolicyServicesDetails .Couldn't find any entry with the given PolicyServiceId");
				return false;
			}
		}catch(SQLException s)
		{
            		s.printStackTrace();
			setStatusCode(InvErrorCode.DB_EXCEPTION);
			setStatusDesc("DB_FAILURE in getPolicyServicesDetails");
			return false;
		}
		setStatusCode(InvErrorCode.SUCCESS);
		setStatusDesc("Successfully retrieved Policy Services from db");
		return true;
	}

}
