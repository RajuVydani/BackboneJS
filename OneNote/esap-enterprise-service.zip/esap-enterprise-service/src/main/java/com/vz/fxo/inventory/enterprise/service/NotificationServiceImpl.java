package com.vz.fxo.inventory.enterprise.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.vz.esap.api.model.ResponseObject;
import com.vz.fxo.inventory.enterprise.rest.RestClientImpl;
import com.vz.fxo.inventory.enterprise.support.VzbInvException;
import com.vz.fxo.inventory.model.pc.VoipOrderResponse;

/**
 * @author Abhiram Varma
 *
 */
@Component
public class NotificationServiceImpl implements NotificationService {

	private static final Logger LOG = LoggerFactory.getLogger(NotificationServiceImpl.class);

	@Value("${ordering.pcReceiverUrl}")
	private String pcReceiverUrl;

	@Value("${ordering.svcUsername}")
	private String svcUsername;

	@Value("${ordering.svcPassword}")
	private String svcPassword;

	@Value("${spring.activemq.queue}")
	private String mqDestination;

	@Autowired
	private RestClientImpl restClientImpl;


	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.vz.esap.translation.order.service.NotificationService#notifyFailures(com.
	 * vz.esap.translation.order.model.response.VoipOrderResponse)
	 */
	@Override
	public ResponseObject notifyFailures(VoipOrderResponse voipOrderResponse) throws VzbInvException {

		ObjectMapper mapper = null;
		ResponseObject responseObject = null;
		try {

			mapper = new ObjectMapper();
			LOG.info("Entered into notifyFailures: voipOrderResponse:{}",
					mapper.writerWithDefaultPrettyPrinter().writeValueAsString(voipOrderResponse));

				responseObject = (ResponseObject) restClientImpl.invokeService(voipOrderResponse, pcReceiverUrl,
						svcUsername, svcPassword, ResponseObject.class);

			LOG.info("In Try  notifyFailures: ResponseObject :{}", responseObject);

		} catch (Exception ex) {
			LOG.info("Exception while calling Notify Service:{}", ex.getMessage());
			throw new VzbInvException("ESP_VZB_INV_PC_NOTIFICATION_FAILED", "Unexpected Error During Notifying PC");
		}
		LOG.info("Exit from notifyFailures: responseObject:{}", responseObject);
		return responseObject;
	}

	// :added for Success Notification
	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.vz.esap.translation.order.service.NotificationService#notifySuccess(com.
	 * vz.esap.translation.order.model.response.VoipOrderResponse)
	 */
	@Override
	public ResponseObject notifySuccess(VoipOrderResponse voipOrderResponse) throws VzbInvException {

		ObjectMapper mapper = null;
		ResponseObject responseObject = null;

		try {
			
			mapper = new ObjectMapper();
			LOG.info("Entered into notifySuccess: voipOrderResponse:{}",
					mapper.writerWithDefaultPrettyPrinter().writeValueAsString(voipOrderResponse));

				responseObject = (ResponseObject) restClientImpl.invokeService(voipOrderResponse, pcReceiverUrl,
						svcUsername, svcPassword, ResponseObject.class);
			

			LOG.info("In Try  notifySuccess: ResponseObject :{}", responseObject);

		} catch (Exception ex) {
			LOG.info("Exception while calling Notify Service:{}", ex.getMessage());
			throw new VzbInvException("ESP_VZB_INV_PC_NOTIFICATION_FAILED", "Unexpected Error During Notifying PC");
		}
		LOG.info("Exit from notifySuccess: responseObject:{}", responseObject);
		return responseObject;

	}
	

}
