/**
 * 
 */
package com.vz.esap.api.service.model;

/**
 * @author Aricent
 *
 */
public class BSUserBean {

}
