package com.vz.fxo.inventory.enterprise;


import java.util.Date;

/**
 *
 */
public class TriDataBean {
	/*
	 * tn_id number(9,0) not null enable,
    dial_plan_id           number not null enable,
    location_id            varchar2(30) not null ,
    noa                    number not null enable,
    tn            varchar2(33 ) not null enable,
    p1url                  varchar2(128 ),
    pringtime              varchar2(75 ),
    ptrid                  varchar2(10 ),
    pprefixdgts            varchar2(33 ),
    psuffixnum             number,
    a1url                  varchar2(128 ),
    a1ringtime             varchar2(75 ),
    a1trid                 varchar2(10 ),
    a1prefixdgts           varchar2(33 ),
    a1suffixnum            number,
    a2url                  varchar2(128 ),
    a2ringtime             varchar2(75 ),
    a2trid                 varchar2(10 ),
    a2prefixdgts           varchar2(33 ),
    a2suffixnum            number,
    created_by             varchar2(50 ) not null enable,
    creation_date          date default sysdate not null enable,
    modified_by            varchar2(50 ) not null enable,
    last_modified_date     date default sysdate not null enable,
    env_order_id           number,
	 */
	
	long tnId;
	/**
	 * @return the tnId
	 */
	public long getTnId() {
		return tnId;
	}
	/**
	 * @param tnId the tnId to set
	 */
	public void setTnId(long tnId) {
		this.tnId = tnId;
	}
	/**
	 * @return the dialPlanId
	 */
	public long getDialPlanId() {
		return dialPlanId;
	}
	/**
	 * @param dialPlanId the dialPlanId to set
	 */
	public void setDialPlanId(long dialPlanId) {
		this.dialPlanId = dialPlanId;
	}
	/**
	 * @return the locationId
	 */
	public String getLocationId() {
		return locationId;
	}
	/**
	 * @param locationId the locationId to set
	 */
	public void setLocationId(String locationId) {
		this.locationId = locationId;
	}
	/**
	 * @return the noa
	 */
	public long getNoa() {
		return noa;
	}
	/**
	 * @param noa the noa to set
	 */
	public void setNoa(long noa) {
		this.noa = noa;
	}
	/**
	 * @return the tn
	 */
	public String getTn() {
		return tn;
	}
	/**
	 * @param tn the tn to set
	 */
	public void setTn(String tn) {
		this.tn = tn;
	}
	/**
	 * @return the p1Url
	 */
	public String getP1Url() {
		return p1Url;
	}
	/**
	 * @param p1Url the p1Url to set
	 */
	public void setP1Url(String p1Url) {
		this.p1Url = p1Url;
	}
	/**
	 * @return the pRingTime
	 */
	public String getpRingTime() {
		return pRingTime;
	}
	/**
	 * @param pRingTime the pRingTime to set
	 */
	public void setpRingTime(String pRingTime) {
		this.pRingTime = pRingTime;
	}
	/**
	 * @return the pTrid
	 */
	public String getpTrid() {
		return pTrid;
	}
	/**
	 * @param pTrid the pTrid to set
	 */
	public void setpTrid(String pTrid) {
		this.pTrid = pTrid;
	}
	/**
	 * @return the pPrefixDgts
	 */
	public String getpPrefixDgts() {
		return pPrefixDgts;
	}
	/**
	 * @param pPrefixDgts the pPrefixDgts to set
	 */
	public void setpPrefixDgts(String pPrefixDgts) {
		this.pPrefixDgts = pPrefixDgts;
	}
	/**
	 * @return the pSuffixNum
	 */
	public long getpSuffixNum() {
		return pSuffixNum;
	}
	/**
	 * @param pSuffixNum the pSuffixNum to set
	 */
	public void setpSuffixNum(long pSuffixNum) {
		this.pSuffixNum = pSuffixNum;
	}
	/**
	 * @return the a1Url
	 */
	public String getA1Url() {
		return a1Url;
	}
	/**
	 * @param a1Url the a1Url to set
	 */
	public void setA1Url(String a1Url) {
		this.a1Url = a1Url;
	}
	/**
	 * @return the a1RingTime
	 */
	public String getA1RingTime() {
		return a1RingTime;
	}
	/**
	 * @param a1RingTime the a1RingTime to set
	 */
	public void setA1RingTime(String a1RingTime) {
		this.a1RingTime = a1RingTime;
	}
	/**
	 * @return the a1Trid
	 */
	public String getA1Trid() {
		return a1Trid;
	}
	/**
	 * @param a1Trid the a1Trid to set
	 */
	public void setA1Trid(String a1Trid) {
		this.a1Trid = a1Trid;
	}
	/**
	 * @return the a1PrefixDgts
	 */
	public String getA1PrefixDgts() {
		return a1PrefixDgts;
	}
	/**
	 * @param a1PrefixDgts the a1PrefixDgts to set
	 */
	public void setA1PrefixDgts(String a1PrefixDgts) {
		this.a1PrefixDgts = a1PrefixDgts;
	}
	/**
	 * @return the a1SuffixNum
	 */
	public long getA1SuffixNum() {
		return a1SuffixNum;
	}
	/**
	 * @param a1SuffixNum the a1SuffixNum to set
	 */
	public void setA1SuffixNum(long a1SuffixNum) {
		this.a1SuffixNum = a1SuffixNum;
	}
	/**
	 * @return the a2Url
	 */
	public String getA2Url() {
		return a2Url;
	}
	/**
	 * @param a2Url the a2Url to set
	 */
	public void setA2Url(String a2Url) {
		this.a2Url = a2Url;
	}
	/**
	 * @return the a2RingTime
	 */
	public String getA2RingTime() {
		return a2RingTime;
	}
	/**
	 * @param a2RingTime the a2RingTime to set
	 */
	public void setA2RingTime(String a2RingTime) {
		this.a2RingTime = a2RingTime;
	}
	/**
	 * @return the a2Trid
	 */
	public String getA2Trid() {
		return a2Trid;
	}
	/**
	 * @param a2Trid the a2Trid to set
	 */
	public void setA2Trid(String a2Trid) {
		this.a2Trid = a2Trid;
	}
	/**
	 * @return the a2PrefixDgts
	 */
	public String getA2PrefixDgts() {
		return a2PrefixDgts;
	}
	/**
	 * @param a2PrefixDgts the a2PrefixDgts to set
	 */
	public void setA2PrefixDgts(String a2PrefixDgts) {
		this.a2PrefixDgts = a2PrefixDgts;
	}
	/**
	 * @return the a2SuffixNum
	 */
	public long getA2SuffixNum() {
		return a2SuffixNum;
	}
	/**
	 * @param a2SuffixNum the a2SuffixNum to set
	 */
	public void setA2SuffixNum(long a2SuffixNum) {
		this.a2SuffixNum = a2SuffixNum;
	}
	/**
	 * @return the createdBy
	 */
	public String getCreatedBy() {
		return createdBy;
	}
	/**
	 * @param createdBy the createdBy to set
	 */
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	/**
	 * @return the creationDate
	 */
	public Date getCreationDate() {
		return creationDate;
	}
	/**
	 * @param creationDate the creationDate to set
	 */
	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}
	/**
	 * @return the modifiedBy
	 */
	public String getModifiedBy() {
		return modifiedBy;
	}
	/**
	 * @param modifiedBy the modifiedBy to set
	 */
	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	/**
	 * @return the lastModifiedDate
	 */
	public Date getLastModifiedDate() {
		return lastModifiedDate;
	}
	/**
	 * @param lastModifiedDate the lastModifiedDate to set
	 */
	public void setLastModifiedDate(Date lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}
	/**
	 * @return the envOrderId
	 */
	public long getEnvOrderId() {
		return envOrderId;
	}
	/**
	 * @param envOrderId the envOrderId to set
	 */
	public void setEnvOrderId(long envOrderId) {
		this.envOrderId = envOrderId;
	}
	long dialPlanId;
	String locationId;
	long noa;
	String tn;
	String p1Url;
	String pRingTime;
	String pTrid;
	String pPrefixDgts;
	long pSuffixNum;
	String a1Url;
	String a1RingTime;
	String a1Trid;
	String a1PrefixDgts;
	long a1SuffixNum;
	String a2Url;
	String a2RingTime;
	String a2Trid;
	String a2PrefixDgts;
	long a2SuffixNum;
	String createdBy;
	Date creationDate;
	String modifiedBy;
	Date lastModifiedDate;
	long envOrderId;
}
