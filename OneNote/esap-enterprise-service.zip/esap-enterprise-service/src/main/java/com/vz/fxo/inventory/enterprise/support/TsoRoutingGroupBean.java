package com.vz.fxo.inventory.enterprise.support;

import java.io.Serializable;
import java.sql.Timestamp;
public class TsoRoutingGroupBean implements Serializable{
	
	
    protected String routingGroupId;
    protected String routingGroupName;
    protected String enterpriseId;
    protected String groupClid;
    protected short useFlag;
    protected String createdBy;
    protected Timestamp creationDate;
    protected String modifiedBy;
    protected Timestamp lastModifiedDate;
    
  	 
	 
	 public TsoRoutingGroupBean(){
		 this.routingGroupId=new String("");
		 this.routingGroupName=new String("");
		 this.enterpriseId=new String("");
		 this.groupClid=new String("");
		 this.useFlag=0;
		 this.createdBy = new String("");
         this.creationDate = null;
	     this.modifiedBy = new String("");
		 this.lastModifiedDate = null;
	 }
	 public TsoRoutingGroupBean(TsoRoutingGroupBean tsoRoutingGroupBean){
		 
		 this.routingGroupId=tsoRoutingGroupBean.routingGroupId;
		 this.routingGroupName=tsoRoutingGroupBean.routingGroupName;
		 this.enterpriseId=tsoRoutingGroupBean.enterpriseId;
		 this.groupClid=tsoRoutingGroupBean.groupClid;
		 this.groupClid=tsoRoutingGroupBean.groupClid;
		 this.useFlag =tsoRoutingGroupBean.useFlag;
         this.creationDate =tsoRoutingGroupBean.creationDate;
	     this.modifiedBy = tsoRoutingGroupBean.modifiedBy;
		 this.lastModifiedDate =tsoRoutingGroupBean.lastModifiedDate;
		 
	 }
	public String getRoutingGroupId() {
		return routingGroupId;
	}
	public void setRoutingGroupId(String routingGroupId) {
		this.routingGroupId = routingGroupId;
	}
	public String getRoutingGroupName() {
		return routingGroupName;
	}
	public void setRoutingGroupName(String routingGroupName) {
		this.routingGroupName = routingGroupName;
	}
	public String getEnterpriseId() {
		return enterpriseId;
	}
	public void setEnterpriseId(String enterpriseId) {
		this.enterpriseId = enterpriseId;
	}
	public String getGroupClid() {
		return groupClid;
	}
	public void setGroupClid(String groupClid) {
		this.groupClid = groupClid;
	}
	public short getUseFlag() {
		return useFlag;
	}
	public void setUseFlag(short useFlag) {
		this.useFlag = useFlag;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public Timestamp getCreationDate() {
		return creationDate;
	}
	public void setCreationDate(Timestamp creationDate) {
		this.creationDate = creationDate;
	}
	public String getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public Timestamp getLastModifiedDate() {
		return lastModifiedDate;
	}
	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}
	 
	
		 
}
