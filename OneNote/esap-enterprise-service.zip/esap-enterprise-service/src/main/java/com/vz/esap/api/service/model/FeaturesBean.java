package com.vz.esap.api.service.model;

import java.io.Serializable;

public class FeaturesBean implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -312972904815578583L;

	// This class will have vzbFeatures and authservices
	protected VzbFeaturesDbBean featuresDbBean;
	protected boolean isSelected;
	protected boolean isAuthorized;
	protected int authServiceId;
	protected long envOrderId;
	protected String createdBy;
	protected String modifiedBy;
	protected int featureCount;

	public FeaturesBean() {
		isSelected = true;
		isAuthorized = false;
		authServiceId = 0;
		envOrderId = 0;
		featuresDbBean = new VzbFeaturesDbBean();
		featureCount = 0;
	}

	public FeaturesBean(FeaturesBean featBean) {
		// featuresDbBean = new DBTblVzbFeatures();
		featuresDbBean = featBean.getFeaturesDbBean();
		this.authServiceId = featBean.authServiceId;
		this.isAuthorized = featBean.isAuthorized;
		this.isSelected = featBean.isSelected;
		this.envOrderId = featBean.envOrderId;
		this.modifiedBy = featBean.modifiedBy;
		this.createdBy = featBean.createdBy;
		this.featureCount = featBean.featureCount;
	}

	public int getAuthServiceId() {
		return authServiceId;
	}

	public void setAuthServiceId(int authServiceId) {
		this.authServiceId = authServiceId;
	}

	public boolean getIsSelected() {
		return isSelected;
	}

	public boolean getIsAuthorized() {
		return isAuthorized;
	}

	public void setIsAuthorized(boolean isAuthorized) {
		this.isAuthorized = isAuthorized;
	}

	public void setIsSelected(boolean isSelected) {
		this.isSelected = isSelected;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public VzbFeaturesDbBean getFeaturesDbBean() {
		return featuresDbBean;
	}

	public void setFeaturesDbBean(VzbFeaturesDbBean vzbFeatObj) {
		this.featuresDbBean = vzbFeatObj;
	}

	public long getEnvOrderId() {
		return envOrderId;
	}

	public void setEnvOrderId(long envOrderId) {
		this.envOrderId = envOrderId;
	}

	public void setFeatureCount(int featureCount) {
		this.featureCount = featureCount;
	}

	public int getFeatureCount() {
		return featureCount;
	}
}
