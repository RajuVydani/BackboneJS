package com.vz.fxo.inventory.enterprise.support;
import java.util.List;
import java.util.ArrayList;
import java.io.Serializable;
public class KeyGroupBean implements Serializable 
{
	protected FeaturePackageBean featurePackageObj;
	protected GatewayDeviceBean device;
	protected List<FeaturesBean> excludedFeaturesList;
	protected List<FeaturesBean> groupFeaturesList;
	protected List<KeyGroupTnBean> keyGroupTnList;//will be lazy initialized
	protected List<String> logTrail;
	protected int groupId;
	protected String locationId;
	protected String departmentId;
	protected String groupName;
	protected long groupType;
	protected long packageId;
	protected String packageStr;
	protected long gatewayDeviceId;		
	protected long deviceMapId;
	protected String cidFirstName;
	protected String cidLastName;
	protected String extension;
	protected String privateNumber;
	protected String linePort;
	protected long keyTerminationType;
	protected String keyFwdTn;
	protected long keyVmMaxsize;
	protected long keyVmMaxsizeId;
	protected String keyVmBoxNum;
	protected long activeInd;
	protected long envOrderId;
	protected String createdBy;
    protected String modifiedBy;
    protected java.sql.Timestamp lastModifiedDate;
    protected java.sql.Timestamp creationDate;
	protected long linePortLength;
	protected boolean getAll;
	protected long CnamUpdateStatus;
    protected java.sql.Timestamp CnamUpdateDate;
    protected long pqInstanceId;


    	/**
   	 * Default Constructor -- Initializes all fields to default values.
   	 */
    	public KeyGroupBean() {
    		this.featurePackageObj = null;
		this.device = null;
		this.excludedFeaturesList = null;
		this.groupFeaturesList = null;
		this.keyGroupTnList = null;
		this.logTrail = null;
		this.groupId = -1;
		this.locationId = new String("NONE");
		this.departmentId = new String("NONE");
		this.groupName = new String("NONE");
		this.groupType = -1;
		this.packageId = -1;
		this.packageStr = new String("NONE");
		this.gatewayDeviceId = -1;
		this.deviceMapId = -1;
		this.cidFirstName = new String("NONE");
		this.cidLastName = new String("NONE");
		this.extension = new String("NONE");
		this.privateNumber = new String("NONE");
		this.linePort = new String("NONE");
		this.keyTerminationType = -1;
		this.keyFwdTn = new String("NONE");
		this.keyVmMaxsize = -1;
		this.keyVmMaxsizeId = -1;
		this.keyVmBoxNum = new String("NONE");
		this.activeInd = 1;
	    this.envOrderId = -1; 
		this.createdBy = new String("NONE");
		this.modifiedBy = new String("NONE");
		this.lastModifiedDate = null;
		this.creationDate = null;
		this.getAll = false;
		this.linePortLength =  -1;
		this.CnamUpdateStatus =  -1;
		this.CnamUpdateDate = null;
		this.pqInstanceId = -1;
		//Pls Verify if below lines are needed.
		featurePackageObj = new FeaturePackageBean();
    		device = new GatewayDeviceBean();
    		excludedFeaturesList = new ArrayList<FeaturesBean>();
    		groupFeaturesList = new ArrayList<FeaturesBean>();
    		keyGroupTnList = new  ArrayList<KeyGroupTnBean>();
    		logTrail = new ArrayList<String>();
	}
	public void clearKeyGroup() {
        this.locationId = "";
        this.departmentId =""; 
        this.groupName =""; 
        this.packageStr =""; 
        this.cidFirstName =""; 
        this.cidLastName =""; 
        this.extension =""; 
        this.privateNumber =""; 
        this.linePort =""; 
        this.keyFwdTn =""; 
        this.keyVmBoxNum =""; 
        this.createdBy = "";
        this.modifiedBy ="";
	}
	/**
	 * Constructor
	 * @param keyGroupBean
	 */
	public KeyGroupBean(KeyGroupBean keyGroupBean)
    	{
		this.featurePackageObj = keyGroupBean.featurePackageObj;
		this.excludedFeaturesList = keyGroupBean.excludedFeaturesList;
		this.groupFeaturesList = keyGroupBean.groupFeaturesList;
		this.keyGroupTnList = keyGroupBean.keyGroupTnList;
		this.logTrail = keyGroupBean.logTrail;
		this.groupId = keyGroupBean.groupId;
		this.locationId = keyGroupBean.locationId;
		this.departmentId = keyGroupBean.departmentId;
		this.groupName = keyGroupBean.groupName;
		this.groupType = keyGroupBean.groupType;
		this.packageId = keyGroupBean.packageId;
		this.packageStr = keyGroupBean.packageStr;
		this.gatewayDeviceId = keyGroupBean.gatewayDeviceId;
		this.deviceMapId = keyGroupBean.deviceMapId;
		this.cidFirstName = keyGroupBean.cidFirstName;
		this.cidLastName = keyGroupBean.cidLastName;
		this.extension = keyGroupBean.extension;
		this.privateNumber = keyGroupBean.privateNumber;
		this.linePort = keyGroupBean.linePort;
		this.keyTerminationType = keyGroupBean.keyTerminationType;
		this.keyFwdTn = keyGroupBean.keyFwdTn;
		this.keyVmMaxsize = keyGroupBean.keyVmMaxsize;
		this.keyVmMaxsizeId = keyGroupBean.keyVmMaxsizeId;
		this.keyVmBoxNum = keyGroupBean.keyVmBoxNum;
		this.activeInd = keyGroupBean.activeInd;
	    this.envOrderId = keyGroupBean.envOrderId; 	
		this.createdBy = keyGroupBean.createdBy;
		this.modifiedBy = keyGroupBean.modifiedBy;
		this.linePortLength = keyGroupBean.linePortLength;
		this.lastModifiedDate = keyGroupBean.lastModifiedDate;
		this.creationDate = keyGroupBean.creationDate;
		this.featurePackageObj = keyGroupBean.featurePackageObj;
        	this.device = keyGroupBean.device;
        	this.getAll = keyGroupBean.getAll;
        	this.CnamUpdateStatus = keyGroupBean.CnamUpdateStatus;
            this.CnamUpdateDate = keyGroupBean.CnamUpdateDate;
            this.pqInstanceId = keyGroupBean.pqInstanceId;
        
    	}
	/**
	 * @return the cnamUpdateStatus
	 */
	public long getCnamUpdateStatus() {
		return CnamUpdateStatus;
	}
	/**
	 * @param cnamUpdateStatus the cnamUpdateStatus to set
	 */
	public void setCnamUpdateStatus(long cnamUpdateStatus) {
		CnamUpdateStatus = cnamUpdateStatus;
	}
	/**
	 * @return the cnamUpdateDate
	 */
	public java.sql.Timestamp getCnamUpdateDate() {
		return CnamUpdateDate;
	}
	/**
	 * @param cnamUpdateDate the cnamUpdateDate to set
	 */
	public void setCnamUpdateDate(java.sql.Timestamp cnamUpdateDate) {
		CnamUpdateDate = cnamUpdateDate;
	}
	public void setLogTrail(String logStr)
        {
                logTrail.add(logStr);
        }
        public List<String> getLogTrail()
        {
                return logTrail;
        }
		public String getPackageStr() {
                return packageStr;
        }
        public void setPackageStr(String packageStr) {
                this.packageStr = packageStr;
    	}
	public FeaturePackageBean getFeaturePackageObj() {
		return featurePackageObj;
	}
	public void setFeaturePackageObj(FeaturePackageBean featurePackageObj) {
		this.featurePackageObj = featurePackageObj;
	}
	public GatewayDeviceBean getDevice() {
		return device;
	}
	public void setDevice(GatewayDeviceBean device) {
		this.device = device;
	}
	public List<FeaturesBean> getExcludedFeaturesList() {
		return excludedFeaturesList;
	}
	public void setExcludedFeaturesList(List<FeaturesBean> excludedFeaturesList) {
		this.excludedFeaturesList = excludedFeaturesList;
	}
	public List<FeaturesBean> getGroupFeaturesList() {
                return groupFeaturesList;
        }
        public void setGroupFeaturesList(List<FeaturesBean> groupFeaturesList) {
                this.groupFeaturesList = groupFeaturesList;
        }
	public List<KeyGroupTnBean> getKeyGroupTnList() {
		return keyGroupTnList;
	}
	public void setKeyGroupTnList(List<KeyGroupTnBean> keyGroupTnList) {
		this.keyGroupTnList = keyGroupTnList;
	}
	public int getGroupId() {
		return groupId;
	}
	public void setGroupId(int groupId) {
		this.groupId = groupId;
	}
	public String getLocationId() {
		return locationId;
	}
	public void setLocationId(String locationId) {
		this.locationId = locationId;
	}
	public String getDepartmentId() {
		return departmentId;
	}
	public void setDepartmentId(String departmentId) {
		this.departmentId = departmentId;
	}
	public String getGroupName() {
		return groupName;
	}
	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}
	public long getPackageId() {
		return packageId;
	}
	public void setPackageId(long packageId) {
		this.packageId = packageId;
	}
	public long getDeviceMapId() {
		return deviceMapId;
	}
	public void setDeviceMapId(long deviceMapId) {
		this.deviceMapId = deviceMapId;
	}
	public long getGatewayDeviceId() {
                return gatewayDeviceId;
        }
        public void setGatewayDeviceId(long gatewayDeviceId) {
                this.gatewayDeviceId = gatewayDeviceId;
        }
	public String getCidFirstName() {
		return cidFirstName;
	}
	public void setCidFirstName(String cidFirstName) {
		this.cidFirstName = cidFirstName;
	}
	public String getCidLastName() {
		return cidLastName;
	}
	public void setCidLastName(String cidLastName) {
		this.cidLastName = cidLastName;
	}
	public String getExtension() {
		return extension;
	}
	public void setExtension(String extension) {
		this.extension = extension;
	}
	public String getPrivateNumber() {
		return privateNumber;
	}
	public void setPrivateNumber(String privateNumber) {
		this.privateNumber = privateNumber;
	}
	public long getKeyTerminationType() {
		return keyTerminationType;
	}
	public void setKeyTerminationType(long keyTerminationType) {
		this.keyTerminationType = keyTerminationType;
	}
	public String getKeyFwdTn() {
		return keyFwdTn;
	}
	public void setKeyFwdTn(String keyFwdTn) {
		this.keyFwdTn = keyFwdTn;
	}
	public long getKeyVmMaxsize() {
		return keyVmMaxsize;
	}
	public void setKeyVmMaxsize(long keyVmMaxsize) {
		this.keyVmMaxsize = keyVmMaxsize;
	}
	public String getKeyVmBoxNum() {
		return keyVmBoxNum;
	}
	public void setKeyVmBoxNum(String keyVmBoxNum) {
		this.keyVmBoxNum = keyVmBoxNum;
	}
	public String getLinePort() {
		return linePort;
	}
	public long getGroupType() {
		return groupType;
	}
	public void setGroupType(long groupType) {
		this.groupType = groupType;
	}
	public void setLinePort(String linePort) {
		this.linePort = linePort;
	}
	public void setLogTrail(List<String> logTrail) {
		this.logTrail = logTrail;
	}
	public long getActiveInd() {
		return activeInd;
	}
	public void setActiveInd(long activeInd) {
		this.activeInd = activeInd;
	}
	public String getModifiedBy() {
        return modifiedBy;
    	}
    	public void setModifiedBy(String modifiedBy) {
        	this.modifiedBy = modifiedBy;
    	}
	public long getKeyVmMaxsizeId() {
		return keyVmMaxsizeId;
	}
	public void setKeyVmMaxsizeId(long keyVmMaxsizeId) {
		this.keyVmMaxsizeId = keyVmMaxsizeId;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public java.sql.Timestamp getLastModifiedDate() {
		return lastModifiedDate;
	}
	public void setLastModifiedDate(java.sql.Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}
	public java.sql.Timestamp getCreationDate() {
		return creationDate;
	}
	public void setCreationDate(java.sql.Timestamp creationDate) {
		this.creationDate = creationDate;
	}
	
	public long getEnvOrderId() {
		return envOrderId;
	}
	public void setEnvOrderId(long envOrderId) {
		this.envOrderId = envOrderId;
	} 
	public boolean getGetAll() {
        return getAll;
    }

    public void setGetAll(boolean getAll) {
        this.getAll = getAll;
    }
	public long getLinePortLength() {
		return linePortLength;
	}
	public void setLinePortLength(long linePortLength) {
		this.linePortLength = linePortLength;
	}
	public long getPqInstanceId() {
		return pqInstanceId;
	}
	public void setPqInstanceId(long pqInstanceId) {
		this.pqInstanceId = pqInstanceId;
	} 
	
}

