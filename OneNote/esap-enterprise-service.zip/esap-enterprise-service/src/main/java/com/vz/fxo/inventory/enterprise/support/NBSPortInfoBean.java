package com.vz.fxo.inventory.enterprise.support;

import java.util.List;
import java.util.ArrayList;

/*
NBS_PORT_INFO_ID    NOT NULL NUMBER       
PORT_NUMBER                  VARCHAR2(80) 
PORT_TYPE                    VARCHAR2(80) 
NBS_CLUSTER_INFO_ID          NUMBER       
ESL_ID                       VARCHAR2(80) 
NBS_ROUTER_DATA_ID           NUMBER       
GROUP_ID                     NUMBER(9)    
CREATED_BY          NOT NULL VARCHAR2(50) 
CREATION_DATE       NOT NULL DATE         
MODIFIED_BY         NOT NULL VARCHAR2(50) 
LAST_MODIFIED_DATE  NOT NULL DATE  
 */
public class NBSPortInfoBean
{
  //  protected List<FeaturesBean> excludedFeaturesList;
  //  protected PublicTnPoolBean publicTnPoolObj;//will be lazy initialized
    protected List<String> logTrail;

    

	protected int nbsPortInfoId;
    protected String portNumber;
    protected String portType;
    protected int nbsClusterInfoId;
    protected String eslId;
    protected String nbsRouterDataId;   
    protected int groupId;
    protected String createdBy;
    protected String modifiedBy;
    protected java.sql.Timestamp creationDate;
    protected java.sql.Timestamp lastModifiedDate;
    protected boolean getAll;
   

   

    public void setLogTrail(List<String> logTrail)
    {
        this.logTrail = logTrail;
    }

    /**
     * Default Constructor -- Initializes all fields to default values.
     */
    public NBSPortInfoBean()
    {
      
        this.logTrail = null;
        this.nbsPortInfoId = 0;      
        this.portNumber = new String("NONE");
        this.portType = new String("NONE");
        this.nbsClusterInfoId = 0;
        this.eslId = new String("NONE");
        this.nbsRouterDataId = new String("NONE");
        this.groupId = 0;     
        this.createdBy = new String("");
        this.modifiedBy = new String("");
        this.creationDate = null;
        this.lastModifiedDate = null;
     //   excludedFeaturesList = new ArrayList<FeaturesBean>();
      //  publicTnPoolObj = new PublicTnPoolBean();
        logTrail = new ArrayList<String>();       
        this.getAll = false;
     
       
       
    }

    /**
     * Constructor
     * 
     * @param pbxGroupTnBean
     */
    public NBSPortInfoBean(NBSPortInfoBean nbsPortInfoBean)
    {
    	
    	 this.nbsPortInfoId =nbsPortInfoBean.nbsPortInfoId;      
         this.portNumber = nbsPortInfoBean.portNumber;
         this.portType = nbsPortInfoBean.portType;
         this.nbsClusterInfoId = nbsPortInfoBean.nbsClusterInfoId;
         this.eslId = nbsPortInfoBean.eslId;
         this.nbsRouterDataId = nbsPortInfoBean.nbsRouterDataId;
         this.groupId = nbsPortInfoBean.groupId;     
         this.createdBy = nbsPortInfoBean.createdBy;
         this.modifiedBy = nbsPortInfoBean.modifiedBy;
         this.creationDate = nbsPortInfoBean.creationDate;
         this.lastModifiedDate = nbsPortInfoBean.lastModifiedDate;
       //  this.publicTnPoolObj = pbxGroupTnBean.publicTnPoolObj;
        // this.subscriberBeanObj = pbxGroupTnBean.subscriberBeanObj;
        // this.grpTnFeaturesList = pbxGroupTnBean.grpTnFeaturesList;
         logTrail = new ArrayList<String>();       
      
         
       
    }

    public int getNbsPortInfoId() {
		return nbsPortInfoId;
	}

	public void setNbsPortInfoId(int nbsPortInfoId) {
		this.nbsPortInfoId = nbsPortInfoId;
	}

	public String getPortNumber() {
		return portNumber;
	}

	public void setPortNumber(String portNumber) {
		this.portNumber = portNumber;
	}

	public String getPortType() {
		return portType;
	}

	public void setPortType(String portType) {
		this.portType = portType;
	}

	public int getNbsClusterInfoId() {
		return nbsClusterInfoId;
	}

	public void setNbsClusterInfoId(int nbsClusterInfoId) {
		this.nbsClusterInfoId = nbsClusterInfoId;
	}

	public String getEslId() {
		return eslId;
	}

	public void setEslId(String eslId) {
		this.eslId = eslId;
	}

	public String getNbsRouterData() {
		return nbsRouterDataId;
	}

	public void setNbsRouterData(String nbsRouterDataId) {
		this.nbsRouterDataId = nbsRouterDataId;
	}

	public int getGroupId() {
		return groupId;
	}

	public void setGroupId(int groupId) {
		this.groupId = groupId;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public java.sql.Timestamp getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(java.sql.Timestamp creationDate) {
		this.creationDate = creationDate;
	}

	public java.sql.Timestamp getLastModifiedDate() {
		return lastModifiedDate;
	}

	public void setLastModifiedDate(java.sql.Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public boolean isGetAll() {
		return getAll;
	}

	public void setGetAll(boolean getAll) {
		this.getAll = getAll;
	}

	public List<String> getLogTrail() {
		return logTrail;
	}

}
