package com.vz.esap.api.model;

public class LocationInfoServiceRequest {
	
	private String locationId;

	public String getLocationId() {
		return locationId;
	}

	public void setLocationId(String locationId) {
		this.locationId = locationId;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("LocationInfoServiceRequest [locationId=");
		builder.append(locationId);
		builder.append("]");
		return builder.toString();
	}

}
