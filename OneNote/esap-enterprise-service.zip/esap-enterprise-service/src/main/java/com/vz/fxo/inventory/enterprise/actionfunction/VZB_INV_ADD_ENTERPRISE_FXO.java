package com.vz.fxo.inventory.enterprise.actionfunction;

import static com.vz.fxo.inventory.enterprise.helper.ActionFunctionHelper.addToLocation;
import static com.vz.fxo.inventory.enterprise.helper.ActionFunctionHelper.checkForNull;
import static com.vz.fxo.inventory.enterprise.helper.ActionFunctionHelper.getAuthFeatures;
import static com.vz.fxo.inventory.enterprise.helper.ActionFunctionHelper.getEnterpriseId;
import static com.vz.fxo.inventory.enterprise.helper.ActionFunctionHelper.getPolicyServiceFeatures;
import static com.vz.fxo.inventory.enterprise.helper.ActionFunctionHelper.getServicePackServiceFeatures;
import static com.vz.fxo.inventory.enterprise.helper.ActionFunctionHelper.getTableOrderDetailsParamByName;
import static com.vz.fxo.inventory.enterprise.helper.ActionFunctionHelper.getTableOrderDetailsParamValue;
import static com.vz.fxo.inventory.enterprise.helper.ActionFunctionHelper.getTableOrderDetaisParam;
import static com.vz.fxo.inventory.enterprise.helper.ActionFunctionHelper.getVmPartitionIdSeqNextVal;
import static com.vz.fxo.inventory.enterprise.helper.ActionFunctionHelper.modifyAuthServicesForEnterprise;
import static com.vz.fxo.inventory.enterprise.helper.ActionFunctionHelper.searchParamListNew;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.vz.esap.api.model.ESAPEntityEnum;
import com.vz.esap.api.model.dto.OrderDomainServiceDTO;
import com.vz.esap.api.model.ordering.EntityBatch;
import com.vz.esap.api.model.ordering.EntityData;
import com.vz.esap.api.model.ordering.TableOrderDetailsParam;
import com.vz.fxo.inventory.enterprise.GenericActionFunction;
import com.vz.fxo.inventory.enterprise.enums.EsapEnum.MileStone;
import com.vz.fxo.inventory.enterprise.enums.EsapEnum.StatusCode;
import com.vz.fxo.inventory.enterprise.support.Enterprise;
import com.vz.fxo.inventory.enterprise.support.TblEntBillFeaturesBean;
import com.vz.fxo.inventory.enterprise.support.VzbInvException;

import EsapEnumPkg.VzbVoipEnum;
import esap.db.TblEnvOrderQuery;

public class VZB_INV_ADD_ENTERPRISE_FXO extends GenericActionFunction {
	private static Logger log = LoggerFactory.getLogger(VZB_INV_ADD_ENTERPRISE_FXO.class.toString());

	public int go() {
		log.info("Task VZB_INV_FXO_ADD_ENTERPRISE Started WorkOrderNumber : {}", this.workOrderNumber);
		try {
			OrderDomainServiceDTO domainServiceDTO = getOrderDomainDetail(ESAPEntityEnum.ENTERPRISE);
			Map<String, EntityBatch> entityTypeMap = domainServiceDTO.getEntityTypeMap();
			EntityBatch entityBatch = entityTypeMap.get(ESAPEntityEnum.ENTERPRISE.toString());
			//cleanEntityBatchSetCommonFields(entityBatch, this.orderNumber);

			enterpriseId = getEnterpriseId(entityBatch);
			checkForNull("EnterpriseId", enterpriseId);

			Map<String, EntityData> entityMap = entityBatch.getEntity();
			EntityData entityData = entityMap.entrySet().iterator().next().getValue();
			
			Enterprise enterprise = new Enterprise(connection);
			
			enterprise.setDbCon(connection);

			/*****************
			 * Information available on order will be set here
			 ******/
			/*********** ORDERING fields starts here ****/
			//if (!(getTableOrderDetaisParam(entityData, "CustomerId") == null))
				enterprise.setEnterpriseId(enterpriseId);

			//if (!(getTableOrderDetaisParam(entityData, "CustomerId") == null))
				enterprise.setCustomerId(enterpriseId);
				
		     if (!(getTableOrderDetaisParam(entityData, "BWEnterpriseId") == null))
				enterprise.setBwEnterPrsiseId(getTableOrderDetailsParamValue(entityData, "BWEnterpriseId"));
		     //Added AuthFeatureType--FET_ESIP:6  FET_DID:8  FET_LINE:7;  FET_DID_LINE:7+8
		     if (!(getTableOrderDetaisParam(entityData, "AuthFeatureType") == null)) {		    	
					enterprise.setAuthFeatureType(getTableOrderDetailsParamValue(entityData, "AuthFeatureType"));
					String authFeatureType=getTableOrderDetailsParamValue(entityData, "AuthFeatureType");	
					 log.info("AuthFeatureType "+ authFeatureType);
				    String defaultAuthServiceId=getAuthServiceIdData(authFeatureType);
				    log.info("defaultAuthServiceId "+ defaultAuthServiceId);
				    enterprise.setDefaultAuthServiceId(Integer.parseInt(defaultAuthServiceId));
		     }

			if (!(getTableOrderDetaisParam(entityData, "BsAppServer") == null))
				enterprise.setAsId(Integer.parseInt(getTableOrderDetailsParamValue(entityData, "BsAppServer")));

			if (getTableOrderDetaisParam(entityData, "CustomerName") != null
					&& !getTableOrderDetailsParamValue(entityData, "CustomerName").equalsIgnoreCase("")) {
				enterprise.setAccountName(getTableOrderDetailsParamValue(entityData, "CustomerName"));
				enterprise.setCustomerName(getTableOrderDetailsParamValue(entityData, "CustomerName"));
			} else {
				String errorMessage = "CustomerName is invalid/not present in the order";
				log.info(errorMessage);
				throw new VzbInvException("VZB_INV_FXO_ADD_ENTERPRISE_FAILED", errorMessage);
			}
			enterprise.setCustMarket(VzbVoipEnum.CustMarketType.US);//added for kr ,this is required for tnpublick pool act/deact filed.
			enterprise.setRegionId(1);
			if (!(getTableOrderDetaisParam(entityData, "RegionType") == null)) {
				enterprise.setRegionId(VzbVoipEnum.RegionType
						.valueByAcronym(getTableOrderDetailsParamValue(entityData, "RegionType")));
				if (enterprise.getRegionId() == VzbVoipEnum.RegionType.EMEA)
					enterprise.setCustMarket(VzbVoipEnum.CustMarketType.EMEA);
				else
					enterprise.setCustMarket(VzbVoipEnum.CustMarketType.US);
			}
			// Jan 2011 Release Changes - For APAC MarKetType will be there.
			if (getTableOrderDetaisParam(entityData, "MarketType") != null) {
				enterprise.setCustMarket(Integer.parseInt(getTableOrderDetailsParamValue(entityData, "MarketType")));
			}
			log.info(" Market Type ", enterprise.getCustMarket());

			if (!(getTableOrderDetaisParam(entityData, "OriginatingSystem") == null))
				enterprise.setOrderSource(getTableOrderDetailsParamValue(entityData, "OriginatingSystem"));

			if (!(getTableOrderDetaisParam(entityData, "OriginatingSystem") == null)) {
				enterprise.setCreatedBy(getTableOrderDetailsParamValue(entityData, "OriginatingSystem"));
				enterprise.setModifiedBy(getTableOrderDetailsParamValue(entityData, "OriginatingSystem"));
			} else {
				enterprise.setCreatedBy("SYSTEM");
				enterprise.setModifiedBy("SYSTEM");
			}

			if (!(getTableOrderDetaisParam(entityData, "EnterpriseTrunkingType") == null)) {
				enterprise.setEnterpriseTrunkingType(VzbVoipEnum.EnterpriseTrunkingType
						.valueByAcronym(getTableOrderDetailsParamValue(entityData, "EnterpriseTrunkingType")));
			} else {
				enterprise.setEnterpriseTrunkingType(VzbVoipEnum.EnterpriseTrunkingType.STANDARD);
			}

			if (!(getTableOrderDetaisParam(entityData, "ContactFirstName") == null))
				enterprise.setContactFirstName(getTableOrderDetailsParamValue(entityData, "ContactFirstName"));

			if (!(getTableOrderDetaisParam(entityData, "ContactLastName") == null))
				enterprise.setContactLastName(getTableOrderDetailsParamValue(entityData, "ContactLastName"));

			if (!(getTableOrderDetaisParam(entityData, "ContactTitle") == null))
				enterprise.setContactTitle(getTableOrderDetailsParamValue(entityData, "ContactTitle"));

			if (!(getTableOrderDetaisParam(entityData, "ContactPhone1") == null))
				enterprise.setContactPrimaryPhone(getTableOrderDetailsParamValue(entityData, "ContactPhone1"));

			if (!(getTableOrderDetaisParam(entityData, "ContactPhone2") == null))
				enterprise.setContactAltPhone(getTableOrderDetailsParamValue(entityData, "ContactPhone2"));

			if (!(getTableOrderDetaisParam(entityData, "ContactFax") == null))
				enterprise.setContactFax(getTableOrderDetailsParamValue(entityData, "ContactFax"));

			if (!(getTableOrderDetaisParam(entityData, "ContactMobile") == null))
				enterprise.setContactCell(getTableOrderDetailsParamValue(entityData, "ContactMobile"));

			if (!(getTableOrderDetaisParam(entityData, "ContactPager") == null))
				enterprise.setContactPager(getTableOrderDetailsParamValue(entityData, "ContactPager"));

			if (!(getTableOrderDetaisParam(entityData, "ContactEmail") == null))
				enterprise.setContactEmail(getTableOrderDetailsParamValue(entityData, "ContactEmail"));

			if (!(getTableOrderDetaisParam(entityData, "ContactAddress1") == null))
				enterprise.setContactAddr1(getTableOrderDetailsParamValue(entityData, "ContactAddress1"));

			if (!(getTableOrderDetaisParam(entityData, "ContactAddress2") == null))
				enterprise.setContactAddr2(getTableOrderDetailsParamValue(entityData, "ContactAddress2"));

			if (!(getTableOrderDetaisParam(entityData, "ContactCity") == null))
				enterprise.setContactCity(getTableOrderDetailsParamValue(entityData, "ContactCity"));

			if (!(getTableOrderDetaisParam(entityData, "ContactState") == null))
				enterprise.setContactState(getTableOrderDetailsParamValue(entityData, "ContactState"));

			if (!(getTableOrderDetaisParam(entityData, "ContactZip") == null))
				enterprise.setContactZip(getTableOrderDetailsParamValue(entityData, "ContactZip"));

			if (!(getTableOrderDetaisParam(entityData, "ContactCountry") == null))
				enterprise.setContactCountry(getTableOrderDetailsParamValue(entityData, "ContactCountry"));

			if (!(getTableOrderDetaisParam(entityData, "VnetCorpId") == null))
				enterprise.setCustCorpId(getTableOrderDetailsParamValue(entityData, "VnetCorpId"));

			if (!(getTableOrderDetaisParam(entityData, "EnterpriseCclIndicator") == null))
				enterprise.setEntCclInd(VzbVoipEnum.YesNoType
						.valueByName(getTableOrderDetailsParamValue(entityData, "EnterpriseCclIndicator")));

			if (!(getTableOrderDetaisParam(entityData, "SipDomain") == null))
				enterprise.setSipDomain(getTableOrderDetailsParamValue(entityData, "SipDomain"));

			if (!(getTableOrderDetaisParam(entityData, "BillingSystem") == null)) {
				if (enterprise.getRegionId() == VzbVoipEnum.RegionType.EMEA)
					enterprise.setEmeaBillingSystem(VzbVoipEnum.BillingSystemType
							.valueByAcronym(getTableOrderDetailsParamValue(entityData, "BillingSystem")));
				else if (enterprise.getRegionId() == VzbVoipEnum.RegionType.US)
					enterprise.setBillingSystem(VzbVoipEnum.BillingSystemType
							.valueByAcronym(getTableOrderDetailsParamValue(entityData, "BillingSystem")));
			}

			if (!(getTableOrderDetaisParam(entityData, "ProductType") == null)
					&& !(getTableOrderDetailsParamValue(entityData, "ProductType") == null)
					&& !getTableOrderDetailsParamValue(entityData, "ProductType").equals(""))
				enterprise.setProductType(Integer.parseInt(getTableOrderDetailsParamValue(entityData, "ProductType")));
			else
				enterprise.setProductType(1);
			// enterprise.setProductType(VzbVoipEnum.ProductType.valueByAcronym(orderParam.getByNameSearch("ProductType").getParamValue()));

			if (!(getTableOrderDetaisParam(entityData, "CentrexType") == null))
				enterprise.setPlatformIndicator(VzbVoipEnum.CentrexType
						.valueByAcronym(getTableOrderDetailsParamValue(entityData, "CentrexType")));

			// Mar 2013 Release - E2EI
			if (getTableOrderDetaisParam(entityData, "LORID") != null) {
				enterprise.setLorId(getTableOrderDetailsParamValue(entityData, "LORID"));
			} else if (getTableOrderDetaisParam(entityData, "LorId") != null) {
				enterprise.setLorId(getTableOrderDetailsParamValue(entityData, "LorId"));
			}
			if (getTableOrderDetaisParam(entityData, "Address") != null) {
				enterprise.setAddress(getTableOrderDetailsParamValue(entityData, "Address"));
			}
			if (getTableOrderDetaisParam(entityData, "City") != null) {
				enterprise.setCity(getTableOrderDetailsParamValue(entityData, "City"));
			}
			if (getTableOrderDetaisParam(entityData, "State") != null) {
				enterprise.setState(getTableOrderDetailsParamValue(entityData, "State"));
			}
			if (getTableOrderDetaisParam(entityData, "Zip") != null) {
				enterprise.setZip(getTableOrderDetailsParamValue(entityData, "Zip"));
			}
			if (getTableOrderDetaisParam(entityData, "Country") != null) {
				enterprise.setCountry(getTableOrderDetailsParamValue(entityData, "Country"));
			}

			// GSAM E2EI R5
			// get E2EI_SENSITIVITY_LEVEL from tbl_env_order and set it to
			// enterprise
			if (getTableOrderDetaisParam(entityData, "OrderPlatform") != null
					&& getTableOrderDetailsParamValue(entityData, "OrderPlatform") != null
					&& VzbVoipEnum.OrderPlatform.valueByAcronym(getTableOrderDetailsParamValue(entityData,
							"OrderPlatform")) == VzbVoipEnum.OrderPlatform.E2EI) {
				String entID = getTableOrderDetailsParamValue(entityData, "CustomerId");
				String envOrderId = getTableOrderDetailsParamValue(entityData, "EnvOrderId");
				String e2eiSesitivityLvl = null;
				TblEnvOrderQuery envQry = new TblEnvOrderQuery();
				envQry.whereEnterpriseIdEQ(entID);
				envQry.whereEnvOrderIdEQ(Integer.parseInt(envOrderId));
				envQry.query(connection);
				if (envQry.size() > 0) {
					e2eiSesitivityLvl = (envQry.getDbBean(0)).getE2eiSensitivityLevel();
				}
				log.info("e2eiSesitivityLvl from TblEnvOrder", e2eiSesitivityLvl);
				if (e2eiSesitivityLvl != null) {
					enterprise.setE2eiSensitivityLevel(e2eiSesitivityLvl);
				}
			}

			// IR #2579397
			if (getTableOrderDetaisParam(entityData, "HybridService") != null) {
				enterprise.setHybridInd(Short.parseShort(getTableOrderDetailsParamValue(entityData, "HybridService")));
			}
			// Mar 2013 VoipTrunkingServiceOptimization IR#2573726

			long poolValues = 0;
			long chldLDAndLocalPool = 0;
			long chldUSLDOnlyPool = 0;
			String parentEntId = null;
			if (getTableOrderDetaisParam(entityData, "SOEnabled") != null
					&& "1".equals(getTableOrderDetailsParamValue(entityData, "SOEnabled"))) {
				enterprise.setSoEnabled(Short.parseShort(getTableOrderDetailsParamValue(entityData, "SOEnabled")));

				if (!(getTableOrderDetaisParam(entityData, "RegionType") == null)
						&& enterprise.getRegionId() == VzbVoipEnum.RegionType.US) {
					// VOIP CANADA TAX Simplification changes
					if ((getTableOrderDetaisParam(entityData, "ParentEnterpriseId") != null)) {
						parentEntId = getTableOrderDetailsParamValue(entityData, "ParentEnterpriseId");
						log.info("parentEntId is {}", parentEntId);
						if (getTableOrderDetaisParam(entityData, "USLDAndLocalBestPool") != null) {
							enterprise.setUsLdAndLocalBestPool(
									Long.parseLong(getTableOrderDetailsParamValue(entityData, "USLDAndLocalBestPool")));
							chldLDAndLocalPool = chldLDAndLocalPool + Long
									.parseLong(getTableOrderDetailsParamValue(entityData, "USLDAndLocalBestPool"));
						}

						if (getTableOrderDetaisParam(entityData, "USLDOnlyBestPool") != null) {
							enterprise.setUsLdOnlyBestPool(
									Long.parseLong(getTableOrderDetailsParamValue(entityData, "USLDOnlyBestPool")));
							chldUSLDOnlyPool = chldUSLDOnlyPool
									+ Long.parseLong(getTableOrderDetailsParamValue(entityData, "USLDOnlyBestPool"));
						}
						populateTblEntParentMap(connection, enterprise.getCustomerId(), parentEntId, chldLDAndLocalPool,
								chldUSLDOnlyPool);
						populateParentBestPoolValues(connection, parentEntId, chldLDAndLocalPool, chldUSLDOnlyPool);
					} else {

						if (getTableOrderDetaisParam(entityData, "USLDAndLocalBestPool") != null) {
							enterprise.setUsLdAndLocalBestPool(
									Long.parseLong(getTableOrderDetailsParamValue(entityData, "USLDAndLocalBestPool")));
							poolValues = poolValues + Long
									.parseLong(getTableOrderDetailsParamValue(entityData, "USLDAndLocalBestPool"));
						}

						if (getTableOrderDetaisParam(entityData, "USLDOnlyBestPool") != null) {
							enterprise.setUsLdOnlyBestPool(
									Long.parseLong(getTableOrderDetailsParamValue(entityData, "USLDOnlyBestPool")));
							poolValues = poolValues
									+ Long.parseLong(getTableOrderDetailsParamValue(entityData, "USLDOnlyBestPool"));
						}
					}
				} else {
					if (getTableOrderDetaisParam(entityData, "EmeaApacBestPool") != null) {
						enterprise.setEmeaApacBestPool(
								Long.parseLong(getTableOrderDetailsParamValue(entityData, "EmeaApacBestPool")));
						poolValues = poolValues
								+ Long.parseLong(getTableOrderDetailsParamValue(entityData, "EmeaApacBestPool"));
					}
				}
			} else {
				enterprise.setSoEnabled((short) 0);
			}

			long plusPoolValues = 0;
			if (getTableOrderDetaisParam(entityData, "SOEnabled") != null
					&& "1".equals(getTableOrderDetailsParamValue(entityData, "SOEnabled"))) {
				enterprise.setSoEnabled(Short.parseShort(getTableOrderDetailsParamValue(entityData, "SOEnabled")));

				if (!(getTableOrderDetaisParam(entityData, "RegionType") == null)
						&& enterprise.getRegionId() == VzbVoipEnum.RegionType.US) {

					if (getTableOrderDetaisParam(entityData, "USLDAndLocalBestPlusPool") != null) {
						enterprise.setUsLdAndLocalBestPlusPool(
								Long.parseLong(getTableOrderDetailsParamValue(entityData, "USLDAndLocalBestPlusPool")));
						plusPoolValues = plusPoolValues + Long
								.parseLong(getTableOrderDetailsParamValue(entityData, "USLDAndLocalBestPlusPool"));
					}

					if (getTableOrderDetaisParam(entityData, "USLDOnlyBestPlusPool") != null) {
						enterprise.setUsLdOnlyBestPlusPool(
								Long.parseLong(getTableOrderDetailsParamValue(entityData, "USLDOnlyBestPlusPool")));
						plusPoolValues = plusPoolValues
								+ Long.parseLong(getTableOrderDetailsParamValue(entityData, "USLDOnlyBestPlusPool"));
					}
				} else {
					if (getTableOrderDetaisParam(entityData, "EmeaApacBestPlusPool") != null) {
						enterprise.setEmeaApacBestPlusPool(
								Long.parseLong(getTableOrderDetailsParamValue(entityData, "EmeaApacBestPlusPool")));
						plusPoolValues = plusPoolValues
								+ Long.parseLong(getTableOrderDetailsParamValue(entityData, "EmeaApacBestPlusPool"));
					}
				}
			} else {
				enterprise.setSoEnabled((short) 0);
			}

			enterprise.setEntTrunkCclSum(poolValues + plusPoolValues);

			if (!(getTableOrderDetaisParam(entityData, "VmPartitionId") == null))
				enterprise.setVmPartitionId(getTableOrderDetailsParamValue(entityData, "VmPartitionId"));
			else
				enterprise.setVmPartitionId(getVmPartitionIdSeqNextVal(connection));

			if (!(getTableOrderDetaisParam(entityData, "ContactPhone1") == null))
				enterprise.setBillContactPriPhone(getTableOrderDetailsParamValue(entityData, "ContactPhone1"));

			if (!(getTableOrderDetaisParam(entityData, "ContactPhone2") == null))
				enterprise.setBillContactAltPhone(getTableOrderDetailsParamValue(entityData, "ContactPhone2"));

			if (!(getTableOrderDetaisParam(entityData, "ContactMobile") == null))
				enterprise.setBillContactCell(getTableOrderDetailsParamValue(entityData, "ContactMobile"));

			if (!(getTableOrderDetaisParam(entityData, "ContactPager") == null))
				enterprise.setBillContactPager(getTableOrderDetailsParamValue(entityData, "ContactPager"));

			if (!(getTableOrderDetaisParam(entityData, "ContactEmail") == null))
				enterprise.setBillContactEmail(getTableOrderDetailsParamValue(entityData, "ContactEmail"));

			if (!(getTableOrderDetaisParam(entityData, "ContactAddress1") == null))
				enterprise.setBillContactAddr1(getTableOrderDetailsParamValue(entityData, "ContactAddress1"));

			if (!(getTableOrderDetaisParam(entityData, "ContactAddress2") == null))
				enterprise.setBillContactAddr2(getTableOrderDetailsParamValue(entityData, "ContactAddress2"));

			if (!(getTableOrderDetaisParam(entityData, "ContactCity") == null))
				enterprise.setBillContactCity(getTableOrderDetailsParamValue(entityData, "ContactCity"));

			if (!(getTableOrderDetaisParam(entityData, "ContactState") == null))
				enterprise.setBillContactState(getTableOrderDetailsParamValue(entityData, "ContactState"));

			if (!(getTableOrderDetaisParam(entityData, "ContactZip") == null))
				enterprise.setBillContactZip(getTableOrderDetailsParamValue(entityData, "ContactZip"));

			if (!(getTableOrderDetaisParam(entityData, "ContactCountry") == null))
				enterprise.setBillContactCountry(getTableOrderDetailsParamValue(entityData, "ContactCountry"));

			if (!(getTableOrderDetaisParam(entityData, "VnetCorpId") == null))
				enterprise.setVnetCorpId(getTableOrderDetailsParamValue(entityData, "VnetCorpId"));

			if (!(getTableOrderDetaisParam(entityData, "ContractInd") == null))
				enterprise.setContractInd(getTableOrderDetailsParamValue(entityData, "ContractInd"));

			if (!(getTableOrderDetaisParam(entityData, "AgencyHierCode") == null))
				enterprise.setAgencyHierCode(getTableOrderDetailsParamValue(entityData, "AgencyHierCode"));

			// enterprise.setTntCclInd(1);

			if (!(getTableOrderDetaisParam(entityData, "AllowOnNet") == null))
				enterprise.setOnNetInterco(
						VzbVoipEnum.YesNoType.valueByName(getTableOrderDetailsParamValue(entityData, "AllowOnNet")));

			if (!(getTableOrderDetaisParam(entityData, "QosIndicator") == null))
				enterprise.setQosInd(VzbVoipEnum.QosIndicator
						.valueByAcronym(getTableOrderDetailsParamValue(entityData, "QosIndicator")));

			if (!(getTableOrderDetaisParam(entityData, "NonTrustedIPCalls") == null))
				enterprise.setPubIp(VzbVoipEnum.YesNoType
						.valueByName(getTableOrderDetailsParamValue(entityData, "NonTrustedIPCalls")));

			enterprise.setCustSensitivityLevel("1");

			if (!(getTableOrderDetaisParam(entityData, "AccountTeamName") == null))
				enterprise.setSalesRepName(getTableOrderDetailsParamValue(entityData, "AccountTeamName"));

			if (!(getTableOrderDetaisParam(entityData, "AccountTeamPhone") == null))
				enterprise.setSalesRepPhone(getTableOrderDetailsParamValue(entityData, "AccountTeamPhone"));

			if (!(getTableOrderDetaisParam(entityData, "AccountTeamEmail") == null))
				enterprise.setSalesRepEmail(getTableOrderDetailsParamValue(entityData, "AccountTeamEmail"));

			if (!(getTableOrderDetaisParam(entityData, "IEANLength") == null))
				enterprise.setIeanLength(Long.valueOf(getTableOrderDetailsParamValue(entityData, "IEANLength")));

			if (getTableOrderDetaisParam(entityData, "EnvOrderId") != null)
				enterprise.setEnvOrderId(Long.valueOf(getTableOrderDetailsParamValue(entityData, "EnvOrderId")));

			// New Fields added by Vj on 31-08-09

			if (!(getTableOrderDetaisParam(entityData, "CommonCustomerId") == null))
				enterprise.setCommonCustomerId(getTableOrderDetailsParamValue(entityData, "CommonCustomerId"));

			if (!(getTableOrderDetaisParam(entityData, "CommonCustomerName") == null))
				enterprise.setCommonCustomerName(getTableOrderDetailsParamValue(entityData, "CommonCustomerName"));

			if (!(getTableOrderDetaisParam(entityData, "VpnName") == null))
				enterprise.setVpnName(getTableOrderDetailsParamValue(entityData, "VpnName"));

			// jan 2011 Release changes
			if (getTableOrderDetaisParam(entityData, "NaspId") != null) {
				if (getTableOrderDetailsParamValue(entityData, "NaspId") != null) {
					enterprise.setNaspId(getTableOrderDetailsParamValue(entityData, "NaspId"));
				}
			}

			log.info(" Naspid in Add Ente : {}", enterprise.getNaspId());
			// 53938.AA Business Continuity Ph 1 - changes for july 2011
			if (!(getTableOrderDetaisParam(entityData, "LOR") == null)) {
				enterprise.setLorFlag(getTableOrderDetailsParamValue(entityData, "LOR"));
			} else {
				enterprise.setLorFlag("N");
			}

			if (!(getTableOrderDetaisParam(entityData, "CustomerPriceBookId") == null))
				enterprise.setCustPriceBookId(getTableOrderDetailsParamValue(entityData, "CustomerPriceBookId"));

			if (!(getTableOrderDetaisParam(entityData, "ContractId") == null))
				enterprise.setContractId(getTableOrderDetailsParamValue(entityData, "ContractId"));

			if (!(getTableOrderDetaisParam(entityData, "QuoteId") == null))
				enterprise.setQuoteId(getTableOrderDetailsParamValue(entityData, "QuoteId"));

			if (!(getTableOrderDetaisParam(entityData, "CatalogueReferenceTime") == null)) {
				Timestamp ts = Timestamp.valueOf(getTableOrderDetailsParamValue(entityData, "CatalogueReferenceTime"));
				enterprise.setCatalogueReferenceTime(ts);
			}
			if (!(getTableOrderDetaisParam(entityData, "DesignId") == null)) {
				enterprise.setDesignId(Long.parseLong(getTableOrderDetailsParamValue(entityData, "DesignId")));
			}

			if (!(getTableOrderDetaisParam(entityData, "CummulativeCcl") == null)) {
				enterprise.setEntCumCcl(Long.parseLong(getTableOrderDetailsParamValue(entityData, "CummulativeCcl")));
			}

			TableOrderDetailsParam sbcProvMethod = getTableOrderDetaisParam(entityData, "SbcProvMethod");
			log.info("SbcProvMethod----> {}", sbcProvMethod);
			if (sbcProvMethod != null && "ESAP".equals(sbcProvMethod.getParamValue().trim())) {
				enterprise.setSbcActivationSystem("ESAP");
			} else {
				enterprise.setSbcActivationSystem("IASA");
			}

			if (!(getTableOrderDetaisParam(entityData, "OrderPlatform") == null)) {

				if (getTableOrderDetailsParamValue(entityData, "OrderPlatform") != null) {

					enterprise.setOrderPlatform(VzbVoipEnum.OrderPlatform
							.valueByAcronym(getTableOrderDetailsParamValue(entityData, "OrderPlatform")));

					if (getTableOrderDetailsParamValue(entityData, "OrderPlatform").equals("NONRIV")) {
						// Non Riv customer
						enterprise.setIsRIVCustomer(VzbVoipEnum.YesNoType.N);
						enterprise.setEntSbcMigInd(VzbVoipEnum.YesNoType.Y);
						enterprise.setCustSbcMigInd(VzbVoipEnum.YesNoType.Y);

					} else {
						// RIV or E2EI
						enterprise.setIsRIVCustomer(VzbVoipEnum.YesNoType.Y);

					}

				}
			}

			if (!(getTableOrderDetaisParam(entityData, "GCHId") == null)
					&& getTableOrderDetailsParamValue(entityData, "GCHId") != null) {
				enterprise.setGchId(getTableOrderDetailsParamValue(entityData, "GCHId"));
			}

			log.info("OrderPlatform = {}", enterprise.getOrderPlatform());
			log.info("IsRIVCustomer = {}", enterprise.getIsRIVCustomer());

			// Calnet3 changes
			if (getTableOrderDetaisParam(entityData, "CalnetSubContractInd") != null
					&& getTableOrderDetailsParamValue(entityData, "CalnetSubContractInd") != null) {
				enterprise.setCalnetSubContractId(
						Short.parseShort(getTableOrderDetailsParamValue(entityData, "CalnetSubContractInd")));
			} else {
				enterprise.setCalnetSubContractId((short) 2);
			}

			// enterprise.setActiveInd(1);
			/**************
			 * ORDERING fields ends here
			 **************************/

			/***********
			 * Fields populated during provisioning OR not coming on the order,
			 * will be left untouced
			 *****/
			/***********
			 * PROVISIONING fields OR fields not coming on the order, starts
			 * here
			 * 
			 * enterprise.setSalesSegment(orderParam.getByNameSearch(
			 * "ContactCountry").getParamValue());
			 * enterprise.setSalesRepId(orderParam.getByNameSearch(
			 * "ContactCountry").getParamValue());
			 * enterprise.setCustCorpId(orderParam.getByNameSearch(
			 * "ContactCountry").getParamValue());
			 * enterprise.setOrderVerification(orderParam.getByNameSearch(
			 * "ContactCountry").getParamValue());
			 * enterprise.setSupportName(orderParam.getByNameSearch(
			 * "ContactCountry").getParamValue());
			 * enterprise.setSupportPhone(orderParam.getByNameSearch(
			 * "ContactCountry").getParamValue());
			 * enterprise.setXrefCustomerId(orderParam.getByNameSearch(
			 * "ContactCountry").getParamValue());
			 * enterprise.setStatusCode(orderParam.getByNameSearch("CustomerId")
			 * .getParamValue()String statusCode)
			 * enterprise.setStatusDesc(orderParam.getByNameSearch("CustomerId")
			 * .getParamValue()String statusDesc)
			 * enterprise.setCustomerType(orderParam.getByNameSearch("DAP").
			 * getParamValue()String customerType)
			 * enterprise.setCustGarmStatus(orderParam.getByNameSearch("").
			 * getParamValue()String custGarmStatus) // Need Int Conversion
			 * enterprise.setEmeaServiceSupport(Integer.parseInt(orderParam.
			 * getByNameSearch("CustomerId").getParamValue()));
			 * enterprise.setBsAsId(Integer.parseInt(orderParam.getByNameSearch(
			 * "CustomerId").getParamValue()));
			 * enterprise.setCallingPlanId(Integer.parseInt(orderParam.
			 * getByNameSearch("CustomerId").getParamValue()));
			 * enterprise.setAuthServicesId(Integer.parseInt(orderParam.
			 * getByNameSearch("CustomerId").getParamValue())); // Extinct
			 * enterprise.setUsBillingSystem(orderParam.getByNameSearch(
			 * "BillingSystemType").getParamValue()); // Extinct
			 * enterprise.setEmeaBillingSystem(orderParam.getByNameSearch(
			 * "BillingSystemType").getParamValue()); // Need Long Conversion
			 * enterprise.setCustActiveInd(long custActiveInd) ;
			 * enterprise.setEntActiveInd(long entActiveInd) ;
			 * 
			 * 
			 * PROVISIONING fields OR fields not coming on the order, ends here
			 **************************/

			// get Authrised Features
			log.info("Getting Authrised Features");
			enterprise.setAuthFeaturesList(getAuthFeatures(entityData, connection, "n"));
			//KR--start added policyService features
			enterprise.setPolicyFeaturesList(getPolicyServiceFeatures(entityData, connection, "n"));
			// check the solution type here
			enterprise.setServicePackFeaturesList(getServicePackServiceFeatures(entityData, connection, "n"));
						
			// set the loadSharing to true if found else false
			if (getTableOrderDetaisParam(entityData, "SbcLoadSharingEnabled") != null) {
				if (getTableOrderDetailsParamValue(entityData, "SbcLoadSharingEnabled") != null
						&& getTableOrderDetailsParamValue(entityData, "SbcLoadSharingEnabled").equalsIgnoreCase("Y")) {
					enterprise.setLoadSharing((long) VzbVoipEnum.YesNoType
							.valueByName(getTableOrderDetailsParamValue(entityData, "SbcLoadSharingEnabled")));
				}
			}

			/**
			 * Adding EntBillFeature REcord to Inventory : Only for E2EI (NON
			 * VTSO) Orders (Till May)
			 **/

			List<TableOrderDetailsParam> pricingInfoList = searchParamListNew(entityData, "PricingInfo");
			List<TblEntBillFeaturesBean> billFeaturesList = new ArrayList<TblEntBillFeaturesBean>();
			for (TableOrderDetailsParam tmp : pricingInfoList) {
				TblEntBillFeaturesBean tblEntBillFeaturesBean = new TblEntBillFeaturesBean();

				/*****************
				 * New TOD Fields for TBL_ENT_BILL_FEATURES Information
				 * available on order will be set here
				 ******/
				/*********** ORDERING fields starts here ****/
				if (!(getTableOrderDetaisParam(entityData, "CustomerId") == null))
					tblEntBillFeaturesBean.setEnterpriseId(getTableOrderDetailsParamValue(entityData, "CustomerId"));

				if (!(getTableOrderDetailsParamByName(tmp, "FeatureInstanceId") == null))
					tblEntBillFeaturesBean.setFeatureInstanceId(
							Long.parseLong(getTableOrderDetailsParamByName(tmp, "FeatureInstanceId").getParamValue()));

				if (!(getTableOrderDetailsParamByName(tmp, "FeatureCode") == null))
					tblEntBillFeaturesBean
							.setFeatureCode(getTableOrderDetailsParamByName(tmp, "FeatureCode").getParamValue());

				if (!(getTableOrderDetailsParamByName(tmp, "PBLI") == null))
					tblEntBillFeaturesBean.setPbli(getTableOrderDetailsParamByName(tmp, "PBLI").getParamValue());

				if (!(getTableOrderDetailsParamByName(tmp, "ChargeType") == null))
					tblEntBillFeaturesBean
							.setChargeType(getTableOrderDetailsParamByName(tmp, "ChargeType").getParamValue());

				if (!(getTableOrderDetailsParamByName(tmp, "ChargeFrequency") == null))
					tblEntBillFeaturesBean.setChargeFrequency(
							getTableOrderDetailsParamByName(tmp, "ChargeFrequency").getParamValue());

				if (!(getTableOrderDetailsParamByName(tmp, "UnitOfMeasure") == null))
					tblEntBillFeaturesBean
							.setUnitOfMeasure(getTableOrderDetailsParamByName(tmp, "UnitOfMeasure").getParamValue());

				if (!(getTableOrderDetailsParamByName(tmp, "BillTime") == null))
					tblEntBillFeaturesBean
							.setBillTime(getTableOrderDetailsParamByName(tmp, "BillTime").getParamValue());

				if (!(getTableOrderDetailsParamByName(tmp, "CatalogueReferenceTime") == null)) {
					Timestamp tsb = Timestamp
							.valueOf(getTableOrderDetailsParamByName(tmp, "CatalogueReferenceTime").getParamValue());
					tblEntBillFeaturesBean.setCatalogueReferenceTime(tsb);
				}
				if (!(getTableOrderDetailsParamByName(tmp, "ServicePlan") == null)) {
					tblEntBillFeaturesBean.setFeatureType(VzbVoipEnum.ServiceLevel
							.valueByAcronym(getTableOrderDetailsParamByName(tmp, "ServicePlan").getParamValue()));
				}
				billFeaturesList.add(tblEntBillFeaturesBean);
			}
			if (billFeaturesList.size() > 0) {
				enterprise.setEntBillFeatBeanList(billFeaturesList);
			}

			// }

			/**
			 * Inserts AuthServices Inserts Customer Inserts Enterprise Inserts
			 * Dial Plan Inserts Sip Domain Inserts Enterprise Bill Features if
			 * already present in the TOD
			 */
			logTrailList.add("Adding Enterprise to Inventory");
			if (enterprise.addToDB()) {
				logTrailList.addAll(enterprise.getLogTrail());
				// e2ei: auth features based on upstream
				if (enterprise.getOrderPlatform() == VzbVoipEnum.OrderPlatform.E2EI) {
					if (!modifyAuthServicesForEnterprise(enterprise, connection, this.orderNumber)) {
						throw new VzbInvException("ESP_VZB_ADD_MOD_ENTERPRISE_FAILED",
								"modifyAuthServicesForEnterprise() failed");
					}
				}
				logTrailList.add("Successfully added Enterprise in ESAP inventory");
				notificationService.notifySuccess(voipResponseGenerator.preparePCMilestone(enterprise,this.orderNumber,this.workOrderNumber,this.workOrderNumberVersion, MileStone.ENTERPRISE_INFO, StatusCode.ESP_SUCCESS));
			} else {
				logTrailList.addAll(enterprise.getLogTrail());
				log.info("Inventory Base Returned Error < {} >", enterprise.getStatusDesc());
				logTrailList.add("Inventory Base Returned Error ::" + enterprise.getStatusDesc() + "::");
				connection.rollback();
				throw new VzbInvException("ESP_VZB_INV_ADD_ENTERPRISE_FAILED", "ESP_VZB_INV_ADD_ENTERPRISE_FAILED");
			}

			String EnterpriseReferenceId = "";
			String NewEnterpriseId = "";
			String OldEnterpriseId = "";

			if (getTableOrderDetaisParam(entityData, "EnterpriseReferenceId") != null) {
				EnterpriseReferenceId = getTableOrderDetailsParamValue(entityData, "EnterpriseReferenceId");
			}
			if (getTableOrderDetaisParam(entityData, "NewEnterpriseId") != null) {
				NewEnterpriseId = getTableOrderDetailsParamValue(entityData, "NewEnterpriseId");
			}
			if (getTableOrderDetaisParam(entityData, "OldEnterpriseId") != null) {
				OldEnterpriseId = getTableOrderDetailsParamValue(entityData, "OldEnterpriseId");
			}
			if (NewEnterpriseId != null) {
				if (!enterprise.updateTsoVampEntityMigForEnt(NewEnterpriseId, OldEnterpriseId, EnterpriseReferenceId)) {
					log.info("Unable to update Tso_enterprise_id in tbl_vamp_entity_reference ");
					throw new VzbInvException("ESP_VZB_INV_ADD_ENTERPRISE_FAILED", "updateTsoVampEntityMig() failed");
				}
				if (!enterprise.updateTblTsoEntityMigForEnt(NewEnterpriseId, OldEnterpriseId)) {
					log.info("Unable to update Tso_enterprise_id in tbl_tso_entity_migration ");
					throw new VzbInvException("ESP_VZB_INV_ADD_ENTERPRISE_FAILED",
							"updateTblTsoEntityMigForEnt() failed");
				}
			}

			// At the end commit transactions

			if (getTableOrderDetailsParamValue(entityData, "OrderPlatform").equals("E2EI")
					&& !(getTableOrderDetaisParam(entityData, "ProductType") == null)
					&& !getTableOrderDetailsParamValue(entityData, "ProductType").equals("")
					&& getTableOrderDetailsParamValue(entityData, "ProductType").equals("7")) {
				log.info(" E2EI Order with IPCCC product type ");
				String entId = getTableOrderDetailsParamValue(entityData, "CustomerId");
				log.info(" ent Id : {}", entId);
				addToLocation(entId, connection);

			}
			// added by z658915 for calnet changes

			connection.commit();

		} catch (VzbInvException e) {
			log.error("Exception:"+e.getMessage());
			try {
				connection.rollback();
			} catch (Exception e1) {
				log.error("Exception:"+e1.getMessage());
			}
			insertOrderLogError("VZB_INV_ADD_ENTERPRISE_FXO:VzbInvException"+e.getMessage()); 
			insertOrderLog("VzbInvException "+ e.getMessage());
			logFinalMessage = e.getMessage();
			logSucessFail = false;
			handleActionFunctionError(e.getMessage(), e.getMessage());
			return INV_FAILURE;
		} catch (SQLException e) {
			log.error("Exception:"+e.getMessage());
			try {
				connection.rollback();
			} catch (Exception e1) {
				log.error("Exception:"+e1.getMessage());
			}
			insertOrderLogError("VZB_INV_ADD_ENTERPRISE_FXO:SQLException"+e.getMessage());
			insertOrderLog("SQLException "+ e.getMessage());
			logFinalMessage = e.getMessage();
			logSucessFail = false;
			log.info("In VZB_INV_FXO_ADD_ENTERPRISE e.getErrorCode():"+e.getErrorCode());
			if (e.getErrorCode() == -60)
				handleActionFunctionError("ESP_VZB_INV_DEADLOCK", e.getMessage());
			else
				handleActionFunctionError("ESP_VZB_INV_ADD_ENTERPRISE_FAILED", e.getMessage());
			return INV_FAILURE;
		} catch (Exception e) {
			e.printStackTrace();
			log.error("Exception:"+e.getMessage());
			try {
				connection.rollback();
			} catch (Exception e1) {
				log.error("Exception:"+e1.getMessage());
			}
			insertOrderLogError("VZB_INV_ADD_ENTERPRISE_FXO:Exception"+e.getMessage());
			insertOrderLog("Exception "+ e.getMessage());
			// insertOrderLog(LOG_TYPE_FAIL,e.getMessage());
			logFinalMessage = e.getMessage();
			logSucessFail = false;
			handleActionFunctionError("ESP_VZB_INV_ADD_ENTERPRISE_FAILED", e.getMessage());
			return INV_FAILURE;
		}

		finally {
			addLogMessageToDb();
			if (logSucessFail)
				insertOrderLog("Task - VZB_INV_FXO_ADD_ENTERPRISE  completed successfully");
			else
				insertOrderLog(logFinalMessage);
		}

		return INV_SUCCESS;
	}

	// VOIP CANADA Changes

	public boolean populateTblEntParentMap(Connection connection, String ChildenterpriseId, String parentEntId,
			long chldLDAndLocalPool, long chldUSLDOnlyPool) {
		System.out.println("Inside populateTblEntParentMap(),ChildenterpriseId is " + ChildenterpriseId
				+ " parentEntId= " + parentEntId + " " + "chldLDAndLocalPool= " + chldLDAndLocalPool
				+ " chldUSLDOnlyPool= " + chldUSLDOnlyPool);
		StringBuffer query = new StringBuffer();
//		Statement statement = null;
		boolean addFlag = false;
		int insertStatus = 0;
		query.append("INSERT INTO TBL_ENTERPRISE_PARENT_MAP( CHILD_ENTERPRISE_ID,");
		query.append("ENTERPRISE_ID, LD_AND_LOCAL_BEST_POOL, LD_ONLY_BEST_POOL, CREATED_BY,CREATION_DATE)");
		query.append(" values ('" + ChildenterpriseId + "','" + parentEntId + "'," + chldLDAndLocalPool + ","
				+ chldUSLDOnlyPool + ",'INV',sysdate)");
		System.out.println("If statement SQL " + query.toString());
		try(Statement statement = connection.createStatement()) {
//			statement = connection.createStatement();
			insertStatus = statement.executeUpdate(query.toString());
			System.out.println("Insert if statement Query status " + insertStatus);
			if (insertStatus > 0)
				addFlag = true;

		} catch (SQLException sqle) {
			log.error("Exception:", sqle);
		}
		return addFlag;
	}

	public void populateParentBestPoolValues(Connection connection, String parentEntId, long chldLDAndLocalPool,
			long chldLDOnlyPool) {
		System.out.println("Inside populateParentBestPoolValues()  ");
		StringBuffer sql = new StringBuffer();
//		Statement st = null;
//		ResultSet rs = null;
//		PreparedStatement pstmt = null;
		long pLdAndLocalPool = 0;
		long pLdOnlyPool = 0;
		int updQryStatus = 0;
		String update_sql = "UPDATE tbl_enterprise SET US_LD_AND_LOCAL_BEST_POOL  = ?,US_LD_ONLY_BEST_POOL  = ? WHERE ENTERPRISE_ID = ?";
		sql.append("select US_LD_AND_LOCAL_BEST_POOL,US_LD_ONLY_BEST_POOL from tbl_enterprise where enterprise_id = '");
		sql.append(parentEntId);
		sql.append("'");
		System.out.println("Inside populateParentBestPoolValues()  SQL  " + sql.toString());
//		try {
		try( Statement st = connection.createStatement();
				PreparedStatement pstmt = connection.prepareStatement(update_sql);
				ResultSet rs = st.executeQuery(sql.toString());
			) {
//			st = connection.createStatement();
//			rs = st.executeQuery(sql.toString());
			while (rs.next()) {
				pLdAndLocalPool = rs.getInt("US_LD_AND_LOCAL_BEST_POOL");
				pLdOnlyPool = rs.getInt("US_LD_ONLY_BEST_POOL");
			}
			pLdAndLocalPool = pLdAndLocalPool + chldLDAndLocalPool;
			pLdOnlyPool = pLdOnlyPool + chldLDOnlyPool;
//			pstmt = connection.prepareStatement(update_sql);
			pstmt.setLong(1, pLdAndLocalPool);
			pstmt.setLong(2, pLdOnlyPool);
			pstmt.setString(3, parentEntId);
			updQryStatus = pstmt.executeUpdate();
			System.out.println("updQryStatus is " + updQryStatus);
		} catch (SQLException sqle) {
			log.error("Exception:", sqle);
		}
	}
}
