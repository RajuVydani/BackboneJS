package com.vz.fxo.inventory.enterprise.support;

public class SbcBean {
	// members
	protected int sbcId;
	protected String carrFqdn;
	protected String carrIpAddress;
	protected long carrPort;
	protected String custFqdn;
	protected String custIpAddress;
	protected long custPort;
	protected long envOrderId;
	protected String createdBy;
	protected String modifiedBy;
	protected java.sql.Timestamp creationDate;
	protected java.sql.Timestamp lastModifiedDate;

	/**
	 * Default Constructor -- Initializes all fields to default values.
	 */
	public SbcBean() {
		this.sbcId = 0;
		this.carrFqdn = new String("");
		this.carrIpAddress = new String("");
		this.carrPort = 0;
		this.custFqdn = new String("");
		this.custIpAddress = new String("");
		this.custPort = 0;
		this.envOrderId = 0;
		this.createdBy = new String("");
		this.modifiedBy = new String("");
		this.creationDate = null;
		this.lastModifiedDate = null;
	}

	/**
	 * Constructor
	 * 
	 * @param sbcBean
	 */
	public SbcBean(SbcBean sbcBean) {
		this.sbcId = sbcBean.sbcId;
		this.carrFqdn = sbcBean.carrFqdn;
		this.carrIpAddress = sbcBean.carrIpAddress;
		this.carrPort = sbcBean.carrPort;
		this.custFqdn = sbcBean.custFqdn;
		this.custIpAddress = sbcBean.custIpAddress;
		this.custPort = sbcBean.custPort;
		this.envOrderId = sbcBean.envOrderId;
		this.createdBy = sbcBean.createdBy;
		this.modifiedBy = sbcBean.modifiedBy;
		this.creationDate = sbcBean.creationDate;
		this.lastModifiedDate = sbcBean.lastModifiedDate;
	}

	// getters - setters

	public int getSbcId() {
		return sbcId;
	}

	public java.sql.Timestamp getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(java.sql.Timestamp creationDate) {
		this.creationDate = creationDate;
	}

	public java.sql.Timestamp getLastModifiedDate() {
		return lastModifiedDate;
	}

	public void setLastModifiedDate(java.sql.Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public void setSbcId(int sbcId) {
		this.sbcId = sbcId;
	}

	public String getCarrFqdn() {
		return carrFqdn;
	}

	public void setCarrFqdn(String fqdn) {
		this.carrFqdn = fqdn;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public String getCarrIpAddress() {
		return carrIpAddress;
	}

	public void setCarrIpAddress(String carrIpAddress) {
		this.carrIpAddress = carrIpAddress;
	}

	public long getCarrPort() {
		return carrPort;
	}

	public void setCarrPort(long carrPort) {
		this.carrPort = carrPort;
	}

	public String getCustFqdn() {
		return custFqdn;
	}

	public void setCustFqdn(String custFqdn) {
		this.custFqdn = custFqdn;
	}

	public String getCustIpAddress() {
		return custIpAddress;
	}

	public void setCustIpAddress(String custIpAddress) {
		this.custIpAddress = custIpAddress;
	}

	public long getCustPort() {
		return custPort;
	}

	public void setCustPort(long custPort) {
		this.custPort = custPort;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public long getEnvOrderId() {
		return envOrderId;
	}

	public void setEnvOrderId(long envOrderId) {
		this.envOrderId = envOrderId;
	}
}
