package com.vz.fxo.inventory.enterprise.support;

import esap.db.DBTblVzbFeatures;


public class FeaturesBean
{
	//This class will have vzbFeatures and authservices 
	protected DBTblVzbFeatures featuresDbBean;
	protected boolean isSelected;
	protected boolean isAuthorized;
    	protected int authServiceId; 
        protected long envOrderId;	
     	protected String createdBy;  
	protected String modifiedBy;
	protected int featureCount;

	public FeaturesBean()
	{
		isSelected = true;
		isAuthorized = false;
		authServiceId = 0;
	        envOrderId = 0;		
                featuresDbBean = new DBTblVzbFeatures();
                featureCount = 0;      
	}

	public FeaturesBean(FeaturesBean featBean)
	{
		// featuresDbBean = new DBTblVzbFeatures();
		featuresDbBean = featBean.getFeaturesDbBean();
                this.authServiceId = featBean.authServiceId;
		this.isAuthorized = featBean.isAuthorized;
		this.isSelected = featBean.isSelected;
                this.envOrderId = featBean.envOrderId;	
         	this.modifiedBy = featBean.modifiedBy;
                this.createdBy = featBean.createdBy;
                this.featureCount = featBean.featureCount;
	}
        public int getAuthServiceId() {
		return authServiceId;
	}

	public void setAuthServiceId(int authServiceId) {
		this.authServiceId = authServiceId;
	}
    public boolean getIsSelected() {
		return isSelected;
	}
    public boolean getIsAuthorized() {
		return isAuthorized;
	}

	public void setIsAuthorized(boolean isAuthorized) {
		this.isAuthorized = isAuthorized;
	}

	public void setIsSelected(boolean isSelected) {
		this.isSelected = isSelected;
	}
        public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getModifiedBy()
	{
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy)
	{
		this.modifiedBy = modifiedBy;
	}

	public DBTblVzbFeatures getFeaturesDbBean()
	{
		return featuresDbBean;
	}

	public void setFeaturesDbBean(DBTblVzbFeatures featuresDbBean)
	{
		this.featuresDbBean = featuresDbBean;
        }
        public long getEnvOrderId() {
		return envOrderId;
	}
	public void setEnvOrderId(long envOrderId) {
		this.envOrderId = envOrderId;
	} 
	
   public void 	setFeatureCount(int featureCount) {
	   this.featureCount = featureCount;
   }
   
   public int getFeatureCount() {
	   return  featureCount;
   }
}


