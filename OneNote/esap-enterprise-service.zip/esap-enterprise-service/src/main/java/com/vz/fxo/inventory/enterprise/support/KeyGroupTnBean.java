
package com.vz.fxo.inventory.enterprise.support;



import java.util.List;
import java.util.ArrayList;

public class KeyGroupTnBean
{
    protected List<FeaturesBean> excludedFeaturesList;
    protected PublicTnPoolBean publicTnPoolObj;//will be lazy initialized
    protected List<String> logTrail;

    protected int groupTnId;
    protected int groupId;
    protected long tnPoolId;
    protected long sequenceNo;
    protected String extension;
    protected String privateNumber;
    protected String linePort;
    protected String cidFirstName;
    protected String cidLastName;
    protected long keyVmMaxsize;
    protected long keyVmMaxsizeId;
    protected String keyVmBoxNum;
    //protected String status;
    protected long envOrderId;
    protected String createdBy;
    protected String modifiedBy;
     protected java.sql.Timestamp creationDate;
    protected java.sql.Timestamp lastModifiedDate; 
    protected long activeInd;
    protected boolean getAll;
    protected String subId;
	protected String icpSubId;
    protected SubscriberBean subscriberBeanObj;
    private long CnamUpdateStatus;
    private java.sql.Timestamp CnamUpdateDate;
    protected String tn;

    /**
	 * @return the cnamUpdateStatus
	 */
	public long getCnamUpdateStatus() {
		return CnamUpdateStatus;
	}

	/**
	 * @param cnamUpdateStatus the cnamUpdateStatus to set
	 */
	public void setCnamUpdateStatus(long cnamUpdateStatus) {
		CnamUpdateStatus = cnamUpdateStatus;
	}

	/**
	 * @return the cnamUpdateDate
	 */
	public java.sql.Timestamp getCnamUpdateDate() {
		return CnamUpdateDate;
	}

	/**
	 * @param cnamUpdateDate the cnamUpdateDate to set
	 */
	public void setCnamUpdateDate(java.sql.Timestamp cnamUpdateDate) {
		CnamUpdateDate = cnamUpdateDate;
	}

	public SubscriberBean getSubscriberBeanObj()
    {
        return subscriberBeanObj;
    }

    public void setSubscriberBeanObj(SubscriberBean subscriberBeanObj)
    {
        this.subscriberBeanObj = subscriberBeanObj;
    }

    public void setLogTrail(List<String> logTrail)
    {
        this.logTrail = logTrail;
    }

    /**
     * Default Constructor -- Initializes all fields to default values.
     */
    public KeyGroupTnBean()
    {
        this.excludedFeaturesList = null;
        this.publicTnPoolObj = null;
        this.logTrail = null;
        this.groupTnId = 0;
        this.groupId = 0;
        this.tnPoolId = 0;
        this.sequenceNo = 0;
        this.extension = new String("NONE");
        this.privateNumber = new String("NONE");
        this.linePort = new String("NONE");
        this.cidFirstName = new String("NONE");
        this.cidLastName = new String("NONE");
        this.keyVmMaxsize = -1;
        this.keyVmMaxsizeId = -1;
        this.keyVmBoxNum = new String("NONE");
        this.envOrderId = 0;
        this.createdBy = new String("");
        this.modifiedBy = new String("");
       this.creationDate = null;
        this.lastModifiedDate = null; 
        this.activeInd = 1;
        this.getAll = false;
        this.subId = new String("NONE");
		this.icpSubId = new String("NONE");
        this.subscriberBeanObj = new SubscriberBean();
        this.CnamUpdateStatus = -1;
        this.CnamUpdateDate = null;
        this.tn = null;
        // Pls verify if below lines are required.
        excludedFeaturesList = new ArrayList<FeaturesBean>();
        publicTnPoolObj = new PublicTnPoolBean();
        logTrail = new ArrayList<String>();
    }

    /**
     * Constructor
     * 
     * @param keyGroupTnBean
     */
    public KeyGroupTnBean(KeyGroupTnBean keyGroupTnBean)
    {
        this.excludedFeaturesList = keyGroupTnBean.excludedFeaturesList;
        this.publicTnPoolObj = keyGroupTnBean.publicTnPoolObj;
        this.logTrail = keyGroupTnBean.logTrail;
        this.groupTnId = keyGroupTnBean.groupTnId;
        this.groupId = keyGroupTnBean.groupId;
        this.tnPoolId = keyGroupTnBean.tnPoolId;
        this.sequenceNo = keyGroupTnBean.sequenceNo;
        this.extension = keyGroupTnBean.extension;
        this.privateNumber = keyGroupTnBean.privateNumber;
        this.linePort = keyGroupTnBean.linePort;
        this.cidFirstName = keyGroupTnBean.cidFirstName;
        this.cidLastName = keyGroupTnBean.cidLastName;
        this.keyVmMaxsize = keyGroupTnBean.keyVmMaxsize;
        this.keyVmMaxsizeId = keyGroupTnBean.keyVmMaxsizeId;
        this.keyVmBoxNum = keyGroupTnBean.keyVmBoxNum;
        this.envOrderId = keyGroupTnBean.envOrderId;
        this.createdBy = keyGroupTnBean.createdBy;
        this.modifiedBy = keyGroupTnBean.modifiedBy;
        this.creationDate = keyGroupTnBean.creationDate;
        this.lastModifiedDate = keyGroupTnBean.lastModifiedDate; 
        this.excludedFeaturesList = keyGroupTnBean.excludedFeaturesList;
        this.publicTnPoolObj = keyGroupTnBean.publicTnPoolObj;
        this.logTrail = keyGroupTnBean.logTrail;
        this.activeInd = keyGroupTnBean.activeInd;
        this.getAll = keyGroupTnBean.getAll;
        this.subId = keyGroupTnBean.subId;
		this.icpSubId = keyGroupTnBean.icpSubId;
        this.subscriberBeanObj = keyGroupTnBean.subscriberBeanObj;
        this.CnamUpdateStatus = keyGroupTnBean.CnamUpdateStatus;
        this.CnamUpdateDate = keyGroupTnBean.CnamUpdateDate;
        this.tn = keyGroupTnBean.tn;
    }

    public void setLogTrail(String logStr)
    {
        logTrail.add(logStr);
    }

    public List<String> getLogTrail()
    {
        return logTrail;
    }

    public long getKeyVmMaxsizeId()
    {
        return keyVmMaxsizeId;
    }

    public void setKeyVmMaxsizeId(long keyVmMaxsizeId)
    {
        this.keyVmMaxsizeId = keyVmMaxsizeId;
    }

    public List<FeaturesBean> getExcludedFeaturesList()
    {
        return excludedFeaturesList;
    }

    public void setExcludedFeaturesList(List<FeaturesBean> excludedFeaturesList)
    {
        this.excludedFeaturesList = excludedFeaturesList;
    }

    public PublicTnPoolBean getPublicTnPoolObj()
    {
        return publicTnPoolObj;
    }

    public void setPublicTnPoolObj(PublicTnPoolBean publicTnPoolObj)
    {
        this.publicTnPoolObj = publicTnPoolObj;
    }

    public int getGroupTnId()
    {
        return groupTnId;
    }

    public void setGroupTnId(int groupTnId)
    {
        this.groupTnId = groupTnId;
    }

    public int getGroupId()
    {
        return groupId;
    }

    public void setGroupId(int groupId)
    {
        this.groupId = groupId;
    }

    public long getTnPoolId()
    {
        return tnPoolId;
    }

    public void setTnPoolId(long tnPoolId)
    {
        this.tnPoolId = tnPoolId;
    }

    public long getSequenceNo()
    {
        return sequenceNo;
    }

    public void setSequenceNo(long sequenceNo)
    {
        this.sequenceNo = sequenceNo;
    }

    public String getExtension()
    {
        return extension;
    }

    public void setExtension(String extension)
    {
        this.extension = extension;
    }

    public String getPrivateNumber()
    {
        return privateNumber;
    }

    public void setPrivateNumber(String privateNumber)
    {
        this.privateNumber = privateNumber;
    }

    public String getLinePort()
    {
        return linePort;
    }

    public void setLinePort(String linePort)
    {
        this.linePort = linePort;
    }

    public String getCidFirstName()
    {
        return cidFirstName;
    }

    public void setCidFirstName(String cidFirstName)
    {
        this.cidFirstName = cidFirstName;
    }

    public String getCidLastName()
    {
        return cidLastName;
    }

    public void setCidLastName(String cidLastName)
    {
        this.cidLastName = cidLastName;
    }

    public long getKeyVmMaxsize()
    {
        return keyVmMaxsize;
    }

    public void setKeyVmMaxsize(long keyVmMaxsize)
    {
        this.keyVmMaxsize = keyVmMaxsize;
    }

    public String getKeyVmBoxNum()
    {
        return keyVmBoxNum;
    }

    public void setKeyVmBoxNum(String keyVmBoxNum)
    {
        this.keyVmBoxNum = keyVmBoxNum;
    }

    /*public String getStatus() {
    	return status;
    }
    public void setStatus(String status) {
    	this.status = status;
    }*/
    public String getCreatedBy()
    {
        return createdBy;
    }

    public void setCreatedBy(String createdBy)
    {
        this.createdBy = createdBy;
    }

    public String getModifiedBy()
    {
        return modifiedBy;
    }

    public void setModifiedBy(String modifiedBy)
    {
        this.modifiedBy = modifiedBy;
    }
    
    public java.sql.Timestamp getCreationDate()
    {
        return creationDate;
    }

    public void setCreationDate(java.sql.Timestamp creationDate)
    {
        this.creationDate = creationDate;
    }

    public java.sql.Timestamp getLastModifiedDate()
    {
        return lastModifiedDate;
    }

    public void setLastModifiedDate(java.sql.Timestamp lastModifiedDate)
    {
        this.lastModifiedDate = lastModifiedDate;
    }
    public long getActiveInd()
    {
        return activeInd;
    }

    public void setActiveInd(long activeInd)
    {
        this.activeInd = activeInd;
    }

    public long getEnvOrderId()
    {
        return envOrderId;
    }

    public void setEnvOrderId(long envOrderId)
    {
        this.envOrderId = envOrderId;
    }

    public boolean getGetAll()
    {
        return getAll;
    }

    public void setGetAll(boolean getAll)
    {
        this.getAll = getAll;
    }

    /**
     * 
     * @return
     */
    public String getSubId()
    {
        return subId;
    }

    /**
     * 
     * @param fmcgSubId
     */
    public void setSubId(String subId)
    {
        this.subId = subId;
    }
    public void initilizeTODefault() {
        this.excludedFeaturesList = null;
        this.publicTnPoolObj = null;
        this.logTrail = null;
        this.tnPoolId = 0;
        this.sequenceNo = 0;
        this.extension = new String("");
        this.privateNumber = new String("");
        this.linePort = new String("");
        this.cidFirstName = new String("");
        this.cidLastName = new String("");
        this.keyVmMaxsize = -1;
        this.keyVmMaxsizeId = -1;
        this.keyVmBoxNum = new String("");
        this.envOrderId = 0;
        this.createdBy = new String("");
        this.modifiedBy = new String("");
        this.creationDate = null;
        this.lastModifiedDate = null; 
        this.activeInd = 1;
        this.subId = new String("");
		this.icpSubId = new String("");	
        this.subscriberBeanObj = new SubscriberBean();
        this.CnamUpdateStatus = -1;
        this.CnamUpdateDate = null;
        this.tn = null;
        excludedFeaturesList = new ArrayList<FeaturesBean>();
        publicTnPoolObj = new PublicTnPoolBean();
        logTrail = new ArrayList<String>();
    }
	

	public String getIcpSubId()
    {
        return icpSubId;
    }

    public void setIcpSubId(String icpSubId)
    {
        this.icpSubId = icpSubId;
    }

	public String getTn() {
		return tn;
	}

	public void setTn(String tn) {
		this.tn = tn;
	}
    
    

}


