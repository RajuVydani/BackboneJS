package com.vz.fxo.inventory.enterprise.support;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import esap.db.DBTblEntBillFeatures;
import esap.db.TblEntBillFeaturesQuery;

public class TblEntBillFeatures extends TblEntBillFeaturesBean {
	
	private static Logger log = LoggerFactory.getLogger(TblEntBillFeatures.class.toString());

	 private InvErrorCode status;
	 Connection dbCon;
	 String statusDesc;
	 boolean rollbackFlag;
	 boolean migration;
	 boolean shellMigration;

	 
	 public TblEntBillFeatures(Connection connection)
	 {
		 super();
		 this.dbCon = connection;
		 this.rollbackFlag = false;
		 this.migration = migration;
		 this.shellMigration = shellMigration;
	 }
	 
	 public TblEntBillFeatures(TblEntBillFeaturesBean TblEntBillFeaturesBean, Connection dbCon)
	 {
		 super(TblEntBillFeaturesBean);
		 this.dbCon = dbCon;
	 }

	public InvErrorCode getStatus() {
		return status;
	}

	public void setStatus(InvErrorCode status) {
		this.status = status;
	}

	public Connection getDbCon() {
		return dbCon;
	}

	public void setDbCon(Connection dbCon) {
		this.dbCon = dbCon;
	}

	public String getStatusDesc() {
		return statusDesc;
	}

	public void setStatusDesc(String statusDesc) {
		this.statusDesc = statusDesc;
	}

	public boolean isRollbackFlag() {
		return rollbackFlag;
	}

	public void setRollbackFlag(boolean rollbackFlag) {
		this.rollbackFlag = rollbackFlag;
	}

	public boolean isMigration() {
		return migration;
	}

	public void setMigration(boolean migration) {
		this.migration = migration;
	}

	public boolean isShellMigration() {
		return shellMigration;
	}

	public void setShellMigration(boolean shellMigration) {
		this.shellMigration = shellMigration;
	}
	 
	
	public boolean addToDB() throws SQLException,Exception{


        setLogTrail("Calling addToDB.");
        DBTblEntBillFeatures  entBillFeaturesDbBean=new DBTblEntBillFeatures();
        
        entBillFeaturesDbBean.setFeatureInstanceId(featureInstanceId);
        entBillFeaturesDbBean.setEnterpriseId(enterpriseId);
        entBillFeaturesDbBean.setLocationId(locationId);
        entBillFeaturesDbBean.setPbli(pbli);
		entBillFeaturesDbBean.setFeatureCode(featureCode);
        entBillFeaturesDbBean.setChargeType(chargeType);
        entBillFeaturesDbBean.setChargeFrequency(chargeFrequency);
        entBillFeaturesDbBean.setUnitOfMeasure(unitOfMeasure);
        entBillFeaturesDbBean.setBillTime(billTime);
        entBillFeaturesDbBean.setCatalogueReferenceTime(catalogueReferenceTime);
        entBillFeaturesDbBean.setFeatureType(featureType);
        printEntBillFeatObj(entBillFeaturesDbBean);
        entBillFeaturesDbBean.insert(dbCon);
        setLogTrail("Enterprise Record added to DB.");
        return true;
    }

	 public void printEntBillFeatObj(DBTblEntBillFeatures entBillFeatObj) {
	        StringBuffer buffer = new StringBuffer();
	        buffer.append("FeatureInstanceId=").append(entBillFeatObj.getFeatureInstanceId())
            .append("\n");
	        buffer.append("EnterpriseId=").append(entBillFeatObj.getEnterpriseId())
            .append("\n");
	        buffer.append("LocationId=").append(entBillFeatObj.getLocationId())
	        .append("\n");
	        buffer.append("Pbli=").append(entBillFeatObj.getPbli())
	        .append("\n");
			buffer.append("FeatureCode=").append(entBillFeatObj.getFeatureCode())
			.append("\n");
	        buffer.append("ChargeType=").append(entBillFeatObj.getChargeType())
	        .append("\n");
	        buffer.append("ChargeFrequency=").append(entBillFeatObj.getChargeFrequency())
	        .append("\n");
	        buffer.append("UnitOfMeasure=").append(entBillFeatObj.getUnitOfMeasure())
	        .append("\n");
	        buffer.append("BillTime = ").append(entBillFeatObj.getBillTime())
	        .append("\n");
	        buffer.append("CatalogueReferenceTime = ").append(entBillFeatObj.getCatalogueReferenceTime())
	        .append("\n");
	        buffer.append("featureType = ").append(entBillFeatObj.getFeatureType())
	        .append("\n");
	        log.info(buffer.toString());
	    }
	 
	 public boolean modifyInDB() throws SQLException, Exception {

		 if (featureInstanceId == null)
         {
             log.info("FAILURE in modifyInDB:: featureInstanceId missing.");
             return false;
         }
          /*if (enterpriseId == null)
          {
              log.info("FAILURE in modifyInDB:: enterpriseId missing.");
              return false;
          }*/
          DBTblEntBillFeatures entBillFeaturesDbBean = getEntBillFeaturesToUpdate();
          log.info("Got Enterprise Bill Features Details to Update for FeatureInstanceId:" + featureInstanceId);
          //entBillFeaturesDbBean.whereEnterpriseIdEQ(enterpriseId);
          entBillFeaturesDbBean.whereFeatureInstanceIdEQ(featureInstanceId);
          log.info("Going to Update EntBillFeatures in DB");
          //FkValidationUtil.isValidLocationForMod(dbCon,tsoEnterpriseDbBean);

          if ( entBillFeaturesDbBean.updateSpByWhere(dbCon) <= 0 ) {
              log.info("No Enterprise updated");
              return false;
          }
          log.info("Successfully updated EntBillFeatures");
          setStatus(InvErrorCode.SUCCESS);
          log.info("Successfully UPDATED EntBillFeatures in the DB");
          return true;
	 }
	 
	 private DBTblEntBillFeatures getEntBillFeaturesToUpdate() throws SQLException {
		 DBTblEntBillFeatures  entBillFeaturesDbBean=new DBTblEntBillFeatures();
           /* Create a new instance of TblEntBillFeaturesBean. The new instance
            * would hold default values for the all the TblEntBillFeaturesBean fields.*/
         TblEntBillFeaturesBean defaultTblEntBillFeaturesBean = new TblEntBillFeaturesBean();
         TblEntBillFeatures inputEnterprise = this;
         entBillFeaturesDbBean.setEnterpriseId(enterpriseId);
         TblEntBillFeaturesQuery entBillFeaturesQuery=new TblEntBillFeaturesQuery();
         //entBillFeaturesQuery.whereEnterpriseIdEQ(inputEnterprise.getEnterpriseId());
         entBillFeaturesQuery.whereFeatureInstanceIdEQ(inputEnterprise.getFeatureInstanceId());
         entBillFeaturesQuery.query(dbCon);
         
         if (inputEnterprise.getFeatureInstanceId() != null
                 && !inputEnterprise.getFeatureInstanceId().equals(defaultTblEntBillFeaturesBean.getFeatureInstanceId())){
           entBillFeaturesDbBean.setFeatureInstanceId(inputEnterprise.getFeatureInstanceId());
         }
         
         if (inputEnterprise.getEnterpriseId() != null
                   && !inputEnterprise.getEnterpriseId().equals(defaultTblEntBillFeaturesBean.getEnterpriseId())){
             entBillFeaturesDbBean.setEnterpriseId(inputEnterprise.getEnterpriseId());
           }
         
         if (inputEnterprise.getLocationId() != null
                   && inputEnterprise.getLocationId()!=defaultTblEntBillFeaturesBean.getLocationId()){
             entBillFeaturesDbBean.setLocationId(inputEnterprise.getLocationId());
         }
         if (inputEnterprise.getFeatureCode() != null
                   && inputEnterprise.getFeatureCode()!=defaultTblEntBillFeaturesBean.getFeatureCode()){
             entBillFeaturesDbBean.setFeatureCode(inputEnterprise.getFeatureCode());
         }
         
         if (inputEnterprise.getPbli() != null
                 && inputEnterprise.getPbli()!=defaultTblEntBillFeaturesBean.getPbli()){
           entBillFeaturesDbBean.setPbli(inputEnterprise.getPbli());
         }
         
         if (inputEnterprise.getChargeType() != null
                 && !inputEnterprise.getChargeType().equals(defaultTblEntBillFeaturesBean.getChargeType())){
           entBillFeaturesDbBean.setChargeType(inputEnterprise.getChargeType());
         }
         if (inputEnterprise.getChargeFrequency()!= null
                   && inputEnterprise.getChargeFrequency() !=defaultTblEntBillFeaturesBean.getChargeFrequency()){
             entBillFeaturesDbBean.setChargeFrequency(inputEnterprise.getChargeFrequency());
         }
        
         
         if (inputEnterprise.getUnitOfMeasure() != null
                   && !inputEnterprise.getUnitOfMeasure().equals(defaultTblEntBillFeaturesBean.getUnitOfMeasure())){
             entBillFeaturesDbBean.setUnitOfMeasure(inputEnterprise.getUnitOfMeasure());
         }
         if (inputEnterprise.getBillTime()!= null
                   && !inputEnterprise.getBillTime().equals(defaultTblEntBillFeaturesBean.getBillTime())){
             entBillFeaturesDbBean.setBillTime(inputEnterprise.getBillTime());
         }
         
         if (inputEnterprise.getCatalogueReferenceTime()!= null
                 && !inputEnterprise.getCatalogueReferenceTime().equals(defaultTblEntBillFeaturesBean.getCatalogueReferenceTime())){
           entBillFeaturesDbBean.setCatalogueReferenceTime(inputEnterprise.getCatalogueReferenceTime());
         }
        if (inputEnterprise.getFeatureType() !=0
                 && !(inputEnterprise.getFeatureType() == defaultTblEntBillFeaturesBean.getFeatureType())){
           entBillFeaturesDbBean.setFeatureType(inputEnterprise.getFeatureType());
         }
         return entBillFeaturesDbBean;
      }
	 
	  public boolean deleteFromDB() throws SQLException, Exception {

	        if(featureInstanceId == null)
	        {
	            log.info("Invalid Input");
	            setStatus(InvErrorCode.INVALID_INPUT);
	            return false;
	        }

	        DBTblEntBillFeatures  entBillFeaturesDbBean = new DBTblEntBillFeatures();
	        entBillFeaturesDbBean.whereFeatureInstanceIdEQ(featureInstanceId);

	        if ( entBillFeaturesDbBean.deleteByWhere(dbCon) <= 0 ) {
	            log.info("No featureInstanceId found to delete "+featureInstanceId);
	            return false;
	        }

	        log.info("Successfully deleted featureInstanceId");
	        setStatusDesc("Successfully deleted featureInstanceId ");

	        return true;
	    }

	  public TblEntBillFeaturesBean getEntBillFeaturesByEnterpriseId(String enterpriseId, String locationId) throws SQLException,Exception {
          TblEntBillFeaturesBean tblEntBillFeaturesBean = null;

          log.info("Got the enterpriseid  " + enterpriseId);
          if (enterpriseId == null || "".equals(enterpriseId)) {
              log.info("enterpriseId  is null or empty");
              return tblEntBillFeaturesBean;
          }
          if (locationId == null || "".equals(locationId)) {
              log.info("locationId  is null or empty");
              return tblEntBillFeaturesBean;
          }


          StringBuffer sql = new StringBuffer();
          PreparedStatement pStmt = null;
          ResultSet rs = null;
          log.info("EntID "+enterpriseId);
          
          sql.append("select * from tbl_ent_bill_features where enterprise_id = ? and location_id = ?");
          log.info("tbl_ent_bill_features query executed" + sql);

          try {
              log.info("Inside try block");
              pStmt = dbCon.prepareStatement(sql.toString());
              if (pStmt != null) {
                  pStmt.setString(1, enterpriseId);
                  pStmt.setString(2, locationId);
                  log.info("AFTER tbl_ent_bill_features query executed" + sql);
                  rs = pStmt.executeQuery();
                  while (rs.next()) {
                	  tblEntBillFeaturesBean = new TblEntBillFeaturesBean();
                      log.info("Inside resultset loop ");

                      tblEntBillFeaturesBean.setEnterpriseId(rs.getString(1));
                      tblEntBillFeaturesBean.setLocationId(rs.getString(2));
                      tblEntBillFeaturesBean.setFeatureCode(rs.getString(3));
                      tblEntBillFeaturesBean.setPbli(rs.getString(4));
                      tblEntBillFeaturesBean.setChargeType(rs.getString(5));
                      tblEntBillFeaturesBean.setChargeFrequency(rs.getString(6));
                      tblEntBillFeaturesBean.setUnitOfMeasure(rs.getString(7));
                      tblEntBillFeaturesBean.setBillTime(rs.getString(8));
                      tblEntBillFeaturesBean.setCatalogueReferenceTime(rs.getTimestamp(9));
                      tblEntBillFeaturesBean.setFeatureType(rs.getLong(10));
                  }
                  log.info("Set TblEntBillFeaturesBean object " + tblEntBillFeaturesBean);
              }
          } catch (SQLException sqe) {
              sqe.printStackTrace();
              log.info("DB_FAILURE in tbl_ent_bill_features");
          } catch (Exception e) {
              e.printStackTrace();
              log.info("DB_FAILURE in tbl_ent_bill_features");
          } finally {
              if (pStmt != null) {
                  pStmt.close();
              }
              if (rs != null) {
                  rs.close();
              }

          }

          return tblEntBillFeaturesBean;

  }



}

