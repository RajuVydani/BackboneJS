package com.vz.fxo.inventory.enterprise.support;

public class VzbInvException  extends java.lang.Exception {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String errorCode = null;
    private String errorDesc = null;

    public VzbInvException(String eCode, String eDesc) {
        super(eDesc);
        this.errorCode = eCode;
        this.errorDesc = eDesc;
    }

    public String getErrorCode() {
        return this.errorCode;
    }

    public void setErrorCode(String errorCode) {
        this.errorCode = errorCode;
    }

    public String getErrorDesc() {
        return this.errorDesc;
    }

    public void setErrorDesc(String errorDesc) {
        this.errorDesc = errorDesc;
    }

}