package com.vz.fxo.inventory.enterprise.support;

import esap.db.DBTblPolicies;
import esap.db.DBTblPoliciesService;



public class PolicyFeaturesBean
{
	
	//This class will have DBTblPolicies and policyservices
	protected DBTblPolicies policyFeaturesDbBean;
	protected int policyServiceId; 
    protected long envOrderId;	
    protected String createdBy;  
	protected String modifiedBy;
	protected String policyName;  
	protected String broadworksDefault;  
	protected String BWProvisioningSetting;  
	protected String policyType;  

	public PolicyFeaturesBean()
	{
		
	    	policyServiceId = 0;
	        envOrderId = 0;		
	        policyFeaturesDbBean = new DBTblPolicies();
              
	}

	public PolicyFeaturesBean(PolicyFeaturesBean policyFeatBean)
	{
		// featuresDbBean = new DBTblVzbFeatures();
		policyFeaturesDbBean = policyFeatBean.getPolicyFeaturesDbBean();
        this.policyServiceId = policyFeatBean.policyServiceId;
		this.envOrderId = policyFeatBean.envOrderId;	
        this.modifiedBy = policyFeatBean.modifiedBy;
        this.createdBy = policyFeatBean.createdBy;
              
	}
    public int getPolicyServiceId() {
		return policyServiceId;
	}

	public void setPolicyServiceId(int policyServiceId) {
		this.policyServiceId = policyServiceId;
	}
    
        public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getModifiedBy()
	{
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy)
	{
		this.modifiedBy = modifiedBy;
	}

	public DBTblPolicies getPolicyFeaturesDbBean()
	{
		return policyFeaturesDbBean;
	}

	public void setPolicyFeaturesDbBean(DBTblPolicies policyFeaturesDbBean)
	{
		this.policyFeaturesDbBean = policyFeaturesDbBean;
        }
        public long getEnvOrderId() {
		return envOrderId;
	}
	public void setEnvOrderId(long envOrderId) {
		this.envOrderId = envOrderId;
	} 
	
   
}


