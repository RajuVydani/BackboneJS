/**
 * AcctAuthCodesBean.java
 * esap.vzbvoip.inventory
 */
package com.vz.fxo.inventory.enterprise.support;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

/**
 * ESAP May 16, 2009
 */
public class AcctAuthCodesBean {
	private int intAcctAuthCodesId = 0;
	private String strLocationId = null;
	private String strAcctAuthCode = null;
	private String strAcctAuthDesc = null;
	private long longCodeType = -1;
	private String strCreatedBy = null;
	private Timestamp strCreationDate = null;
	private String strModifiedBy = null;
	private Timestamp strLastModifiedDate = null;
	protected List<String> logTrail;
	protected long envOrderId;

	/**
	 * Default Constructor -- Initializes all fields to default values.
	 */
	public AcctAuthCodesBean() {
		this.intAcctAuthCodesId = 0;
		this.strLocationId = new String("");
		this.strAcctAuthCode = new String("");
		this.strAcctAuthDesc = new String("");
		this.longCodeType = -1;
		this.strCreatedBy = new String("");
		this.strCreationDate = null;
		this.strModifiedBy = new String("");
		this.strLastModifiedDate = null;
		this.logTrail = new ArrayList<String>();
		this.envOrderId = 0;
	}

	/**
	 * @description Constructor
	 * @param acctAuthCodesBean
	 */
	public AcctAuthCodesBean(AcctAuthCodesBean authBean) {
		this.intAcctAuthCodesId = authBean.intAcctAuthCodesId;
		this.strLocationId = authBean.strLocationId;
		this.strAcctAuthCode = authBean.strAcctAuthCode;
		this.strAcctAuthDesc = authBean.strAcctAuthDesc;
		this.longCodeType = authBean.longCodeType;
		this.strCreatedBy = authBean.strCreatedBy;
		this.strCreationDate = authBean.strCreationDate;
		this.strModifiedBy = authBean.strModifiedBy;
		this.strLastModifiedDate = authBean.strLastModifiedDate;
		this.logTrail = authBean.logTrail;
		this.envOrderId = authBean.envOrderId;
	}

	/**
	 * @DESCRIPTION: Display the Bean contents
	 */
	public String toString() {
		StringBuilder toString = new StringBuilder(200);
		toString.append("intAcctAuthCodesId-------------------------")
				.append(intAcctAuthCodesId).append("\n\t");
		toString.append("strLocationId------------------------------")
				.append(strLocationId).append("\n\t");
		toString.append("strAcctAuthCode----------------------------")
				.append(strAcctAuthCode).append("\n\t");
		toString.append("strAcctAuthDesc----------------------------")
				.append(strAcctAuthDesc).append("\n\t");
		toString.append("strCreatedBy-------------------------------")
				.append(strCreatedBy).append("\n\t");
		toString.append("strCreationDate----------------------------")
				.append(strCreationDate).append("\n\t");
		toString.append("strModifiedBy------------------------------")
				.append(strModifiedBy).append("\n\t");
		toString.append("strLastModifiedDate------------------------")
				.append(strLastModifiedDate).append("\n\t");
		return toString.toString();
	}

	/**
	 * @return the intAcctAuthCodesId
	 */
	public int getIntAcctAuthCodesId() {
		return this.intAcctAuthCodesId;
	}

	/**
	 * @param intAcctAuthCodesId
	 *            the intAcctAuthCodesId to set
	 */
	public void setIntAcctAuthCodesId(int intAcctAuthCodesId) {
		this.intAcctAuthCodesId = intAcctAuthCodesId;
	}

	/**
	 * @return the strLocationId
	 */
	public String getStrLocationId() {
		return this.strLocationId;
	}

	/**
	 * @param strLocationId
	 *            the strLocationId to set
	 */
	public void setStrLocationId(String strLocationId) {
		this.strLocationId = strLocationId;
	}

	/**
	 * @return the strAcctAuthCode
	 */
	public String getStrAcctAuthCode() {
		return this.strAcctAuthCode;
	}

	/**
	 * @param strAcctAuthCode
	 *            the strAcctAuthCode to set
	 */
	public void setStrAcctAuthCode(String strAcctAuthCode) {
		this.strAcctAuthCode = strAcctAuthCode;
	}

	/**
	 * @return the strAcctAuthDesc
	 */
	public String getStrAcctAuthDesc() {
		return this.strAcctAuthDesc;
	}

	/**
	 * @param strAcctAuthDesc
	 *            the strAcctAuthDesc to set
	 */
	public void setStrAcctAuthDesc(String strAcctAuthDesc) {
		this.strAcctAuthDesc = strAcctAuthDesc;
	}

	/**
	 * @return the longCodeType
	 */
	public long getLongCodeType() {
		return this.longCodeType;
	}

	/**
	 * @param longCodeType
	 *            the longCodeType to set
	 */
	public void setLongCodeType(long longCodeType) {
		this.longCodeType = longCodeType;
	}

	/**
	 * @return the strCreatedBy
	 */
	public String getStrCreatedBy() {
		return this.strCreatedBy;
	}

	/**
	 * @param strCreatedBy
	 *            the strCreatedBy to set
	 */
	public void setStrCreatedBy(String strCreatedBy) {
		this.strCreatedBy = strCreatedBy;
	}

	/**
	 * @return the strModifiedBy
	 */
	public String getStrModifiedBy() {
		return this.strModifiedBy;
	}

	/**
	 * @param strModifiedBy
	 *            the strModifiedBy to set
	 */
	public void setStrModifiedBy(String strModifiedBy) {
		this.strModifiedBy = strModifiedBy;
	}

	/**
	 * @return the strCreationDate
	 */
	public Timestamp getStrCreationDate() {
		return this.strCreationDate;
	}

	/**
	 * @param strCreationDate
	 *            the strCreationDate to set
	 */
	public void setStrCreationDate(Timestamp strCreationDate) {
		this.strCreationDate = strCreationDate;
	}

	/**
	 * @return the strLastModifiedDate
	 */
	public Timestamp getStrLastModifiedDate() {
		return this.strLastModifiedDate;
	}

	/**
	 * @param strLastModifiedDate
	 *            the strLastModifiedDate to set
	 */
	public void setStrLastModifiedDate(Timestamp strLastModifiedDate) {
		this.strLastModifiedDate = strLastModifiedDate;
	}

	public void setLogTrail(String logStr) {
		logTrail.add(logStr);
	}

	public List<String> getLogTrail() {
		return logTrail;
	}

	public long getEnvOrderId() {
		return envOrderId;
	}

	public void setEnvOrderId(long envOrderId) {
		this.envOrderId = envOrderId;
	}
}
