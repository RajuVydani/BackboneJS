package com.vz.esap.api.model.ordering;

import java.util.HashMap;
import java.util.Map;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

/**
 * 
 * EntityBatch represents the batch of entities of "specific" type in an Order
 * which is stored as a {@code Map<String, EntityData>}. Here EntityData is one 
 * individual entity stored against its Key - basically one Map.Entry per entity. <br>
 * For example, one EntityBatch instance for all the "TN" entityType and other
 * for all the "Enterprise" entityType and all the TN(s) or Enterprise(s) within
 * the batch is stored as Map. EntityBatch may optionally maintain startIndex and endIndex
 * for the entity data it is containing inside Map.
 * 
 * 
 * @author Robin Bathla
 * 
 *
 */
public class EntityBatch {
	
	private String entityType;
	private Long startIndex;
	private Long endIndex;
	private Long maxIndex;
	private Map<String,EntityData> entityBatch;
	
	private EntityBatch(EntityBatchBuilder entityBatchBuilder) {
		this.entityType = entityBatchBuilder.entityType;
		this.startIndex = entityBatchBuilder.startIndex;
		this.endIndex = entityBatchBuilder.endIndex;
		this.maxIndex = entityBatchBuilder.maxIndex;
		this.entityBatch = entityBatchBuilder.entityBatch;
	}
	
	public String getEntityType() {
		return entityType;
	}
	public void setEntityType(String entityType) {
		this.entityType = entityType;
	}
	public Long getStartIndex() {
		return startIndex;
	}
	public void setStartIndex(Long startIndex) {
		this.startIndex = startIndex;
	}
	public Long getEndIndex() {
		return endIndex;
	}
	public void setEndIndex(Long endIndex) {
		this.endIndex = endIndex;
	}
	public Long getMaxIndex() {
		return maxIndex;
	}
	public void setMaxIndex(Long maxIndex) {
		this.maxIndex = maxIndex;
	}
	public Map<String, EntityData> getEntity() {
		return entityBatch;
	}
	public void setEntity(Map<String, EntityData> entityBatch) {
		this.entityBatch = entityBatch;
	}
	
	@Override
	public String toString() {
		Gson gson = new GsonBuilder().setPrettyPrinting().create();
		String json = gson.toJson(this);
		return json;
		
		/*StringBuilder builder = new StringBuilder();
		builder.append("\n EntityBatch \n [startIndex=");
		builder.append(startIndex);
		builder.append(", endIndex=");
		builder.append(endIndex);
		builder.append(", maxIndex=");
		builder.append(maxIndex);
		builder.append(", entityBatch=");
		builder.append(entityBatch);
		builder.append("]");
		return builder.toString();*/
	}
	
	public static class EntityBatchBuilder {
		private String entityType;
		private Long startIndex;
		private Long endIndex;
		private Long maxIndex;
		private Map<String,EntityData> entityBatch = new HashMap<>();
		
		public EntityBatchBuilder withEntityType(String entityType) {
			this.entityType = entityType;
			return this;
		}
		public EntityBatchBuilder withStartIndex(Long startIndex) {
			this.startIndex = startIndex;
			return this;
		}
		public EntityBatchBuilder withEndIndex(Long endIndex) {
			this.endIndex = endIndex;
			return this;
		}
		public EntityBatchBuilder withMaxIndex(Long maxIndex) {
			this.maxIndex = maxIndex;
			return this;
		}
		public EntityBatchBuilder putEntityData(EntityData entityData) {
			this.entityBatch.put(entityData.getEntityValue(), entityData);
			return this;
		}
		
		public EntityBatch build() {
			return new EntityBatch(this);
		}	
	}	
}