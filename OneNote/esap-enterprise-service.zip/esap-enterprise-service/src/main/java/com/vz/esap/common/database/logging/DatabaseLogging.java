package com.vz.esap.common.database.logging;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.vz.esap.common.communication.RestClient;
import com.vz.fxo.inventory.enterprise.model.ResponseObject;

import EsapEnumPkg.OrderLogEnum;

@Service
public class DatabaseLogging {

	private long orderId = -1;
	private String logText;
	private long logType;
	private String taskName = null;
	private int taskSeqNo = -1;
	private int taskLogSeqNo = 1;
	private String upstreamWoId = "";
	private String svcName = null;

	private TblOrderLogDataBean tblOrderLogDataBean;
	private List<TblOrderLogDataBean> tblOrderLogDataBeanList = null;
	List<TblTaskCompletionLogDataBean> tblTaskCompletionLogDataBeansList = null;

	private String pattern = "yyyy-MM-dd HH:mm:ss.SSS";
	private SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);

	public String getTaskName() {
		return taskName;
	}

	public void setTaskName(String taskName) {
		this.taskName = taskName;
	}

	public int getTaskSeqNo() {
		return taskSeqNo;
	}

	public void setTaskSeqNo(int taskSeqNo) {
		this.taskSeqNo = taskSeqNo;
	}

	public int getTaskLogSeqNo() {
		return taskLogSeqNo;
	}

	public void setTaskLogSeqNo(int taskLogSeqNo) {
		this.taskLogSeqNo = taskLogSeqNo;
	}

	public String getUpstreamWoId() {
		return upstreamWoId;
	}

	public void setUpstreamWoId(String upstreamWoId) {
		this.upstreamWoId = upstreamWoId;
	}

	public String getSvcName() {
		return svcName;
	}

	public void setSvcName(String svcName) {
		this.svcName = svcName;
	}

	public long getOrderId() {
		return orderId;
	}

	public void setOrderId(long orderId) {
		this.orderId = orderId;
	}

	public String getLogText() {
		return logText;
	}

	public void setLogText(String logText) {
		this.logText = logText;
	}

	public long getLogType() {
		return logType;
	}

	public void setLogType(long logType) {
		this.logType = logType;
	}

	public TblOrderLogDataBean getTblOrderLogDataBean() {
		return tblOrderLogDataBean;
	}

	public void setTblOrderLogDataBean(TblOrderLogDataBean tblOrderLogDataBean) {
		this.tblOrderLogDataBean = tblOrderLogDataBean;
	}

	public List<TblOrderLogDataBean> getTblOrderLogDataBeanList() {
		return tblOrderLogDataBeanList;
	}

	public void setTblOrderLogDataBeanList(List<TblOrderLogDataBean> tblOrderLogDataBeanList) {
		this.tblOrderLogDataBeanList = tblOrderLogDataBeanList;
	}

	public List<TblTaskCompletionLogDataBean> getTblTaskCompletionLogDataBeansList() {
		return tblTaskCompletionLogDataBeansList;
	}

	public void setTblTaskCompletionLogDataBeansList(List<TblTaskCompletionLogDataBean> tblTaskCompletionLogDataBeansList) {
		this.tblTaskCompletionLogDataBeansList = tblTaskCompletionLogDataBeansList;
	}

	public DatabaseLogging() {

	}

	public DatabaseLogging(long orderId) {
		this.orderId = orderId;
		this.logText = "";
		this.logType = OrderLogEnum.EventType.INFORMATION;

		tblOrderLogDataBean = new TblOrderLogDataBean();
		tblOrderLogDataBean.setOrderId(this.orderId);
		tblOrderLogDataBean.setLogText(this.logText);
		tblOrderLogDataBean.setLogType(this.logType);
		tblOrderLogDataBean.setLogDate(simpleDateFormat.format(Calendar.getInstance().getTime()));

		tblOrderLogDataBeanList = new ArrayList<TblOrderLogDataBean>();
	}

	public DatabaseLogging(long orderId, String logText, long logType) {
		this.orderId = orderId;
		this.logText = logText;
		this.logType = logType;

		tblOrderLogDataBean = new TblOrderLogDataBean();
		tblOrderLogDataBean.setOrderId(this.orderId);
		tblOrderLogDataBean.setLogText(this.logText);
		tblOrderLogDataBean.setLogType(this.logType);
		tblOrderLogDataBean.setLogDate(simpleDateFormat.format(Calendar.getInstance().getTime()));

		tblOrderLogDataBeanList = new ArrayList<TblOrderLogDataBean>();
	}

	public void setOrderLog(String logText, long logType) throws Exception {
		if (orderId == -1) {
			throw new Exception("Order Id is not set");
		}
		tblOrderLogDataBean = new TblOrderLogDataBean();
		tblOrderLogDataBean.setOrderId(orderId);
		tblOrderLogDataBean.setLogText(logText);
		tblOrderLogDataBean.setLogType(logType);
		tblOrderLogDataBean.setLogDate(simpleDateFormat.format(Calendar.getInstance().getTime()));

		if (tblOrderLogDataBeanList == null) {
			tblOrderLogDataBeanList = new ArrayList<TblOrderLogDataBean>();
		}
		tblOrderLogDataBeanList.add(tblOrderLogDataBean);

	}

	public void addTrailList(List<String> logTrail, long logType) throws Exception {
		if (orderId == -1) {
			throw new Exception("Order Id is not set");
		}

		if (tblOrderLogDataBeanList == null) {
			tblOrderLogDataBeanList = new ArrayList<TblOrderLogDataBean>();
		}

		for (String logText : logTrail) {
			tblOrderLogDataBean = new TblOrderLogDataBean();
			tblOrderLogDataBean.setOrderId(orderId);
			tblOrderLogDataBean.setLogText(logText);
			tblOrderLogDataBean.setLogType(logType);
			tblOrderLogDataBean.setLogDate(simpleDateFormat.format(Calendar.getInstance().getTime()));
			tblOrderLogDataBeanList.add(tblOrderLogDataBean);
		}

	}
	
	public void setTaskCompletionLog(String logText, String severity,
			String taskExitType) {
		if(tblTaskCompletionLogDataBeansList == null){
			tblTaskCompletionLogDataBeansList = new ArrayList<TblTaskCompletionLogDataBean>();
		}
		TblTaskCompletionLogDataBean taskCompletionLogDataBean = new TblTaskCompletionLogDataBean();
		taskCompletionLogDataBean.setDescription(logText);
		taskCompletionLogDataBean.setEventDate(simpleDateFormat.format(Calendar
				.getInstance().getTime()));
		taskCompletionLogDataBean.setOrderId(orderId);
		taskCompletionLogDataBean.setSeqNo((long) taskLogSeqNo++);
		taskCompletionLogDataBean.setSeverity(severity);
		taskCompletionLogDataBean.setStatus(taskExitType);
		taskCompletionLogDataBean.setSvcSeqNo((long) taskSeqNo);
		taskCompletionLogDataBean.setTaskName(taskName);
		tblTaskCompletionLogDataBeansList.add(taskCompletionLogDataBean);
	}
}
