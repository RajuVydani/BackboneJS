package com.vz.esap.api.service.model;

import java.io.Serializable;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Vector;

import com.vz.esap.api.model.TblRow;

public class TblSubFeatureDbBean implements Serializable{

	//private boolean bsequenceQueried;
	private int subFeatureId;
	private boolean bsubFeatureIdSet;
	private String subId;
	private boolean bsubIdSet;
	private long featureId;
	private boolean bfeatureIdSet;
	private String isSelected;
	private boolean bisSelectedSet;
	private boolean bisSelectedNull;
	private String createdBy;
	private boolean bcreatedBySet;
	private Timestamp creationDate;
	private boolean bcreationDateSet;
	private String modifiedBy;
	private boolean bmodifiedBySet;
	private Timestamp lastModifiedDate;
	private boolean blastModifiedDateSet;
	private long envOrderId;
	private boolean benvOrderIdSet;
	private boolean benvOrderIdNull;
	//private Vector clauseValues;
	private String propfile;
	private String clause;

	public TblSubFeatureDbBean() {
		//this.bsequenceQueried = false;

		this.bsubFeatureIdSet = false;

		this.bsubIdSet = false;

		this.bfeatureIdSet = false;

		this.bisSelectedSet = false;
		this.bisSelectedNull = true;

		this.bcreatedBySet = false;

		this.bcreationDateSet = false;

		this.bmodifiedBySet = false;

		this.blastModifiedDateSet = false;

		this.benvOrderIdSet = false;
		this.benvOrderIdNull = true;

		//this.clauseValues = new Vector();
		this.propfile = "dev";
		this.clause = "";
	}

	public int getSubFeatureId() {
		return this.subFeatureId;
	}

	public boolean isSubFeatureIdSet() {
		return this.bsubFeatureIdSet;
	}

	public void setSubFeatureId(int val) {
		this.subFeatureId = val;
		this.bsubFeatureIdSet = true;
	}

	public String getSubId() {
		return this.subId;
	}

	public boolean isSubIdSet() {
		return this.bsubIdSet;
	}

	public void setSubId(String val) {
		this.subId = val;
		this.bsubIdSet = true;
	}

	public long getFeatureId() {
		return this.featureId;
	}

	public boolean isFeatureIdSet() {
		return this.bfeatureIdSet;
	}

	public void setFeatureId(long val) {
		this.featureId = val;
		this.bfeatureIdSet = true;
	}

	public String getIsSelected() {
		return this.isSelected;
	}

	public boolean isIsSelectedSet() {
		return this.bisSelectedSet;
	}

	public boolean isIsSelectedNull() {
		return this.bisSelectedNull;
	}

	public void setIsSelected(String val) {
		this.isSelected = val;
		this.bisSelectedSet = true;
		this.bisSelectedNull = false;
		if (val == null)
			this.bisSelectedNull = true;
	}

	public void setIsSelectedNull() {
		this.bisSelectedSet = true;
		this.bisSelectedNull = true;
	}

	public void setIsSelectedNull(boolean isNull) {
		this.bisSelectedSet = isNull;
		this.bisSelectedNull = isNull;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public boolean isCreatedBySet() {
		return this.bcreatedBySet;
	}

	public void setCreatedBy(String val) {
		this.createdBy = val;
		this.bcreatedBySet = true;
	}

	public Timestamp getCreationDate() {
		return this.creationDate;
	}

	public boolean isCreationDateSet() {
		return this.bcreationDateSet;
	}

	public void setCreationDate(Timestamp val) {
		this.creationDate = val;
		this.bcreationDateSet = true;
	}

	public String getModifiedBy() {
		return this.modifiedBy;
	}

	public boolean isModifiedBySet() {
		return this.bmodifiedBySet;
	}

	public void setModifiedBy(String val) {
		this.modifiedBy = val;
		this.bmodifiedBySet = true;
	}

	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}

	public boolean isLastModifiedDateSet() {
		return this.blastModifiedDateSet;
	}

	public void setLastModifiedDate(Timestamp val) {
		this.lastModifiedDate = val;
		this.blastModifiedDateSet = true;
	}

	public long getEnvOrderId() {
		return this.envOrderId;
	}

	public boolean isEnvOrderIdSet() {
		return this.benvOrderIdSet;
	}

	public boolean isEnvOrderIdNull() {
		return this.benvOrderIdNull;
	}

	public void setEnvOrderId(long val) {
		this.envOrderId = val;
		this.benvOrderIdSet = true;
		this.benvOrderIdNull = false;
	}

	public void setEnvOrderIdNull() {
		this.benvOrderIdSet = true;
		this.benvOrderIdNull = true;
	}

	public void setEnvOrderIdNull(boolean isNull) {
		this.benvOrderIdSet = isNull;
		this.benvOrderIdNull = isNull;
	}
	/*public void setGetSeq() {
		this.bsequenceQueried = false;
	}

	public void setSkipSeq() {
		this.bsequenceQueried = true;
	}
 
*/	public void copyFromBean(TblRow bean) throws ParseException {
		setSubFeatureId(Integer.parseInt(bean.getTblRow().get("SUB_FEATURE_ID").getValue()));
		setSubId(bean.getTblRow().get("SUB_ID").getValue());
		setFeatureId(Long.parseLong(bean.getTblRow().get("FEATURE_ID").getValue()));
		setIsSelected(bean.getTblRow().get("IS_SELECTED").getValue());
		setCreatedBy(bean.getTblRow().get("CREATED_BY").getValue());
		setCreationDate(getTimeStampDate(bean.getTblRow().get("CREATION_DATE").getValue()));
		setModifiedBy(bean.getTblRow().get("MODIFIED_BY").getValue());
		setLastModifiedDate(getTimeStampDate(bean.getTblRow().get("LAST_MODIFIED_DATE").getValue()));
		setEnvOrderId(Long.parseLong(bean.getTblRow().get("ENV_ORDER_ID").getValue()));
	}

	public void copyFromDBObject(TblSubFeatureDbBean bean) {
		setSubFeatureId(bean.getSubFeatureId());
		setSubId(bean.getSubId());
		setFeatureId(bean.getFeatureId());
		setIsSelected(bean.getIsSelected());
		setCreatedBy(bean.getCreatedBy());
		setCreationDate(bean.getCreationDate());
		setModifiedBy(bean.getModifiedBy());
		setLastModifiedDate(bean.getLastModifiedDate());
		setEnvOrderId(bean.getEnvOrderId());
	}
	
	private Timestamp getTimeStampDate(String value) throws ParseException {
		DateFormat formatter;
		formatter = new SimpleDateFormat("dd/MM/yyyy");
		Date date = (Date) formatter.parse(value);
		Timestamp timeStampDate = new Timestamp(date.getTime());
		return timeStampDate;
	}
	
}
