package com.vz.fxo.inventory.enterprise.query;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import com.vz.fxo.inventory.enterprise.query.Criteria.ColumnName;
import com.vz.fxo.inventory.enterprise.query.Criteria.SearchCondition;

public class SearchCriteria {
    private HashMap<ColumnName, List<String>> criteria;
    private SearchCondition condition;

    public SearchCriteria() {
        criteria = new HashMap<ColumnName, List<String>>();
    }

    public void add(ColumnName key, List<String> value) {
        criteria.put(key, value);
    }
    public void add(ColumnName key, String value) {
        if(null != value) {
            List<String> colValue = new ArrayList<String>();
            colValue.add(value);
            criteria.put(key, colValue);
        }
    }

    public HashMap<ColumnName, List<String>> getSearchCriteria() {
        return criteria;
    }

    public void setSearchCriteria(HashMap<ColumnName, List<String>> searchCriteria) {
        this.criteria = searchCriteria;
    }

    public SearchCondition getSearchCondition() {
        return condition;
    }

    public void setSearchCondition(SearchCondition searchCondition) {
        this.condition = searchCondition;
    }

    public String toString() {
        StringBuffer buffer = new StringBuffer();
        buffer.append("Criteria =").append("\n");
        for (Iterator i = criteria.keySet().iterator(); i.hasNext();) {
            ColumnName key = (ColumnName) i.next();
            List<String> columnValues = (List<String>) criteria.get(key);
            String columnValue = "";
            for (Iterator itr = columnValues.iterator(); itr.hasNext();) {
                columnValue = columnValue +(String)itr.next();
            }
            buffer.append(key + "=" + columnValue).append("\n");
        }
        buffer.append("SearchCondition =" + condition);
        return buffer.toString();
    }

}
