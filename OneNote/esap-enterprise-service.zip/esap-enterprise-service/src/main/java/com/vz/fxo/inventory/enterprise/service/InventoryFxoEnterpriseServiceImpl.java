package com.vz.fxo.inventory.enterprise.service;

import java.sql.Connection;
import java.sql.SQLException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mchange.v2.c3p0.ComboPooledDataSource;
import com.vz.esap.api.connector.service.impl.ConfigDomainDataServiceImpl;
import com.vz.esap.api.connector.service.impl.InventoryDomainDataServiceImpl;
import com.vz.esap.api.connector.service.impl.OrderDomainDataServiceImpl;
import com.vz.esap.api.connector.service.impl.OrderLogServiceImpl;
import com.vz.esap.api.model.ESAPEntityEnum;
import com.vz.esap.api.model.InventoryServiceRequest;
import com.vz.esap.api.model.ResponseObject;
import com.vz.fxo.inventory.enterprise.GenericActionFunction;
import com.vz.fxo.inventory.enterprise.actionfunction.VZB_INV_ADD_ENTERPRISE_FXO;
import com.vz.fxo.inventory.enterprise.actionfunction.VZB_INV_DEL_ENTERPRISE_FXO;
import com.vz.fxo.inventory.enterprise.actionfunction.VZB_INV_MOD_ENTERPRISE_FXO;
import com.vz.fxo.inventory.enterprise.helper.FxoInventoryErrorEntityMgmtHelper;
import com.vz.fxo.inventory.enterprise.helper.FxoServiceHelper;
import com.vz.fxo.inventory.reponsegenerator.VOIPResponseGenerator;

@Service
public class InventoryFxoEnterpriseServiceImpl {

	
	@Autowired
	public OrderDomainDataServiceImpl orderDomainDataService;
	@Autowired
	public ConfigDomainDataServiceImpl configDomainDataService;

	@Autowired
	public FxoInventoryErrorEntityMgmtHelper bsErrorEntityMgmtHelper;

	@Autowired
	public OrderLogServiceImpl orderLogService;

	@Autowired
	private ComboPooledDataSource comboPooledDataSource;

	@Autowired
	private InventoryDomainDataServiceImpl inventoryDomainDataService;
	
	@Autowired
	private NotificationService notificationService;
	
	@Autowired
	private VOIPResponseGenerator voipResponseGenerator;
	

	private Connection getConnection() throws SQLException {
		return comboPooledDataSource.getConnection();
	}
	private static Logger log = LoggerFactory.getLogger(InventoryFxoEnterpriseServiceImpl.class.toString());
	
	public <T extends GenericActionFunction> GenericActionFunction getActionFunctionImpl(T obj,
			InventoryServiceRequest request) throws SQLException {

		FxoServiceHelper.setRequestAttributes(request, obj, ESAPEntityEnum.ENTERPRISE.toString());
		obj.setConfigDomainDataService(configDomainDataService);
		obj.setOrderDomainDataService(orderDomainDataService);
		obj.setOrderLogService(orderLogService);
		obj.setInventoryDomainDataService(inventoryDomainDataService);
		obj.setBsErrorEntityMgmtHelper(bsErrorEntityMgmtHelper);
		obj.setConnection(this.getConnection());
		obj.setNotificationService(notificationService);
		obj.setVoipResponseGenerator(voipResponseGenerator);
		
		return obj;
	}

	/**
	 * This method invokes the VZB_INV_ADD_ENTERPRISE action function to add the enterprise from inventory.
	 * @param bsRequestEntity
	 * @return
	 */
	public int addEnt(InventoryServiceRequest bsRequestEntity) {
		log.info(" VZB_INV_ADD_ENTERPRISE_FXO : add Enterprise request received and calling corresponding action service");
		int processResult = ResponseObject.FAILURE;
		GenericActionFunction obj = null;
		try {
			obj = getActionFunctionImpl(new VZB_INV_ADD_ENTERPRISE_FXO(), bsRequestEntity);
			processResult = obj.doTask(true);
	   log.info(" VZB_INV_ADD_ENTERPRISE_FXO : ActionFunction Result:: processResult"+ processResult);
		} catch (SQLException e) {
			log.error(" VZB_INV_ADD_ENTERPRISE_FXO : Error while executing add enterprise action function ",e.getMessage());
		}finally {
			if (obj!= null && obj.getConnection() != null){
				try {
					obj.getConnection().close();
			    log.info(" VZB_INV_ADD_ENTERPRISE_FXO : DB connection closed");
				} catch (SQLException e) {
					log.error(" VZB_INV_ADD_ENTERPRISE_FXO : Error whiling closing SQL Connection",e.getMessage());
				}
			}
		}
	   log.info(" VZB_INV_ADD_ENTERPRISE_FXO:ServiceImpl End");
		return processResult;
	}

	/**
	 * This method invokes the VZB_INV_MOD_ENTERPRISE action function to modify the
	 * Device from inventory.
	 * 
	 * @param bsRequestEntity
	 * @return
	 */
	public int modify(InventoryServiceRequest bsRequestEntity) {

		log.info("VZB_INV_MOD_ENTERPRISE_FXO : modify request received and calling corresponding action service");
		int processResult = ResponseObject.FAILURE;
		GenericActionFunction obj = null;
		try {
			obj = getActionFunctionImpl(new VZB_INV_MOD_ENTERPRISE_FXO(), bsRequestEntity);			
			processResult = obj.doTask(true);
			log.info(" VZB_INV_MOD_ENTERPRISE_FXO : ActionFunction Result:: processResult"+ processResult);
		} catch (SQLException e) {
			log.error("VZB_INV_MOD_ENTERPRISE_FXO :  Error while executing modify action function ", e.getMessage());
		} finally {
			if (obj!= null && obj.getConnection() != null){
				try {
					obj.getConnection().close();
				log.info(" VZB_INV_MOD_ENTERPRISE_FXO : DB connection closed");
				} catch (SQLException e) {
					log.error(" VZB_INV_MOD_ENTERPRISE : Error whiling closing SQL Connection",e.getMessage());
				}
			}
		}	
		  log.info(" VZB_INV_MOD_ENTERPRISE_FXO:ServiceImpl End");
		return processResult;
	}

	/**
	 * This method invokes the VZB_INV_DEL_ENTERPRISE action function to delete the
	 * Device from inventory.
	 * 
	 * @param bsRequestEntity
	 * @return
	 */
	public int del(InventoryServiceRequest bsRequestEntity) {

		log.info("VZB_INV_DEL_ENTERPRISE_FXO:del request received and calling corresponding action service");
		int processResult = ResponseObject.FAILURE;
		GenericActionFunction obj = null;
		try {
			obj = getActionFunctionImpl(new VZB_INV_DEL_ENTERPRISE_FXO(), bsRequestEntity);
			processResult = obj.doTask(true);
		  log.info(" VZB_INV_DEL_ENTERPRISE_FXO : ActionFunction Result:: processResult"+ processResult);
		} catch (SQLException e) {
			log.error("VZB_INV_DEL_ENTERPRISE_FXO Error while executing del action function ", e.getMessage());
		}finally {
			if (obj!= null && obj.getConnection() != null){
				try {
					obj.getConnection().close();
			  log.info(" VZB_INV_DEL_ENTERPRISE_FXO : DB connection closed");
				} catch (SQLException e) {
					log.error(" VZB_INV_DEL_ENTERPRISE_FXO : Error whiling closing SQL Connection",e.getMessage());
				}
			}
		}
	 log.info("VZB_INV_DEL_ENTERPRISE_FXO:ServiceImpl End");
		return processResult;
	}
}

