package com.vz.fxo.inventory.enterprise.query;

import java.util.HashMap;
import java.util.LinkedHashMap;

import com.vz.fxo.inventory.enterprise.query.Criteria.ColumnName;
import com.vz.fxo.inventory.enterprise.query.Criteria.SortBy;

public class SortCriteria {
    LinkedHashMap<ColumnName, SortBy> sortCriteria;

    public SortCriteria() {
        sortCriteria = new LinkedHashMap<ColumnName, SortBy>();
    }

    public void add(ColumnName key, Criteria.SortBy value) {
        sortCriteria.put(key, value);
    }
    
    public HashMap<ColumnName, SortBy> getSortCriteria() {
        return sortCriteria;
    }
}
