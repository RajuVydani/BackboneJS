
package com.vz.esap.api.generated.pojo;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "workOrderNumber",
    "workOrderVersion",
    "envOrderId",
    "entityType",
    "entityId",
    "trackingId",
    "orderId",
    "tn",
    "failureFlag",
    "domain",
    "taskName",
    "errorCodes",
    "updatedTimestamp",
    "errorDescp"
})
public class OrderFalloutGetFailEntityInfo {

    @JsonProperty("workOrderNumber")
    private Object workOrderNumber;
    @JsonProperty("workOrderVersion")
    private Long workOrderVersion;
    @JsonProperty("envOrderId")
    private Long envOrderId;
    @JsonProperty("entityType")
    private Object entityType;
    @JsonProperty("entityId")
    private Object entityId;
    @JsonProperty("trackingId")
    private Object trackingId;
    @JsonProperty("orderId")
    private Long orderId;
    @JsonProperty("tn")
    private Long tn;
    @JsonProperty("failureFlag")
    private Object failureFlag;
    @JsonProperty("domain")
    private Object domain;
    @JsonProperty("taskName")
    private Object taskName;
    @JsonProperty("errorCodes")
    private Object errorCodes;
    @JsonProperty("updatedTimestamp")
    private Object updatedTimestamp;
    @JsonProperty("errorDescp")
    private Object errorDescp;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("workOrderNumber")
    public Object getWorkOrderNumber() {
        return workOrderNumber;
    }

    @JsonProperty("workOrderNumber")
    public void setWorkOrderNumber(Object workOrderNumber) {
        this.workOrderNumber = workOrderNumber;
    }

    @JsonProperty("workOrderVersion")
    public Long getWorkOrderVersion() {
        return workOrderVersion;
    }

    @JsonProperty("workOrderVersion")
    public void setWorkOrderVersion(Long workOrderVersion) {
        this.workOrderVersion = workOrderVersion;
    }

    @JsonProperty("envOrderId")
    public Long getEnvOrderId() {
        return envOrderId;
    }

    @JsonProperty("envOrderId")
    public void setEnvOrderId(Long envOrderId) {
        this.envOrderId = envOrderId;
    }

    @JsonProperty("entityType")
    public Object getEntityType() {
        return entityType;
    }

    @JsonProperty("entityType")
    public void setEntityType(Object entityType) {
        this.entityType = entityType;
    }

    @JsonProperty("entityId")
    public Object getEntityId() {
        return entityId;
    }

    @JsonProperty("entityId")
    public void setEntityId(Object entityId) {
        this.entityId = entityId;
    }

    @JsonProperty("trackingId")
    public Object getTrackingId() {
        return trackingId;
    }

    @JsonProperty("trackingId")
    public void setTrackingId(Object trackingId) {
        this.trackingId = trackingId;
    }

    @JsonProperty("orderId")
    public Long getOrderId() {
        return orderId;
    }

    @JsonProperty("orderId")
    public void setOrderId(Long orderId) {
        this.orderId = orderId;
    }

    @JsonProperty("tn")
    public Long getTn() {
        return tn;
    }

    @JsonProperty("tn")
    public void setTn(Long tn) {
        this.tn = tn;
    }

    @JsonProperty("failureFlag")
    public Object getFailureFlag() {
        return failureFlag;
    }

    @JsonProperty("failureFlag")
    public void setFailureFlag(Object failureFlag) {
        this.failureFlag = failureFlag;
    }

    @JsonProperty("domain")
    public Object getDomain() {
        return domain;
    }

    @JsonProperty("domain")
    public void setDomain(Object domain) {
        this.domain = domain;
    }

    @JsonProperty("taskName")
    public Object getTaskName() {
        return taskName;
    }

    @JsonProperty("taskName")
    public void setTaskName(Object taskName) {
        this.taskName = taskName;
    }

    @JsonProperty("errorCodes")
    public Object getErrorCodes() {
        return errorCodes;
    }

    @JsonProperty("errorCodes")
    public void setErrorCodes(Object errorCodes) {
        this.errorCodes = errorCodes;
    }

    @JsonProperty("updatedTimestamp")
    public Object getUpdatedTimestamp() {
        return updatedTimestamp;
    }

    @JsonProperty("updatedTimestamp")
    public void setUpdatedTimestamp(Object updatedTimestamp) {
        this.updatedTimestamp = updatedTimestamp;
    }

    @JsonProperty("errorDescp")
    public Object getErrorDescp() {
        return errorDescp;
    }

    @JsonProperty("errorDescp")
    public void setErrorDescp(Object errorDescp) {
        this.errorDescp = errorDescp;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(workOrderNumber).append(workOrderVersion).append(envOrderId).append(entityType).append(entityId).append(trackingId).append(orderId).append(tn).append(failureFlag).append(domain).append(taskName).append(errorCodes).append(updatedTimestamp).append(errorDescp).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof OrderFalloutGetFailEntityInfo) == false) {
            return false;
        }
        OrderFalloutGetFailEntityInfo rhs = ((OrderFalloutGetFailEntityInfo) other);
        return new EqualsBuilder().append(workOrderNumber, rhs.workOrderNumber).append(workOrderVersion, rhs.workOrderVersion).append(envOrderId, rhs.envOrderId).append(entityType, rhs.entityType).append(entityId, rhs.entityId).append(trackingId, rhs.trackingId).append(orderId, rhs.orderId).append(tn, rhs.tn).append(failureFlag, rhs.failureFlag).append(domain, rhs.domain).append(taskName, rhs.taskName).append(errorCodes, rhs.errorCodes).append(updatedTimestamp, rhs.updatedTimestamp).append(errorDescp, rhs.errorDescp).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
