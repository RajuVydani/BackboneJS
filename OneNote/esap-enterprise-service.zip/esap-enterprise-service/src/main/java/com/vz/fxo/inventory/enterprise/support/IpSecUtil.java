package com.vz.fxo.inventory.enterprise.support;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Map;
import java.util.Collections;
import java.util.regex.Matcher;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.PrintWriter;
import java.io.IOException;
import java.sql.PreparedStatement;
import java.text.Normalizer;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.InputStreamReader;

import esap.db.TblGatewayDeviceInfoQuery;
import esap.db.TblIpsecTunnelQuery;
import esap.db.TblTsoEbiQuery;

//import esap.emea.cs2k.server.communication.ServerConnectionInfo;

//import esap.vzbvoip.order.util.log;

import EsapEnumPkg.VzbVoipEnum;

public class IpSecUtil {

	private static Logger log = LoggerFactory.getLogger(IpSecUtil.class.toString());

	Connection connection;
    public static HashMap<Integer,String> mhshSubMask = new HashMap<Integer,String> ();	

	public IpSecUtil(){} 
	
	public IpSecUtil(Connection dbCon)
	{
	        this.connection = dbCon;
	}
	
public static List<IpSecTemplateBean> getIpSecSearchDetails(Connection con,IpSecSearchBean bean){
		log.info(" getIpSecSearchDetails invoked " );
		String ikeIp=bean.getIkeIp();
		String custName	=bean.getName();
		String custId = bean.getCustId();
		String custIdOrCustName = bean.getCustIdOrCustName();
		String reqDtFrom=bean.getRequestDtFrom();
		String reqDtTo=bean.getRequestDtTo();
		String reqInstallFrom=bean.getRequestInstallFrom();
		String reqInstallTo=bean.getRequestInstallTo();
		String requestBy=bean.getRequestBy();
		int requestStatus=bean.getIpsecRequestStatus();
		int ipsecTunnelId = bean.getIpsecTunnelId();
		int regionType = bean.getRegionType();
		ArrayList<IpSecTemplateBean> beanList = new ArrayList<IpSecTemplateBean>();
		
		StringBuilder query1 = new StringBuilder();
		
		if(custId != null || custName != null || custIdOrCustName != null || regionType > 0){
			query1.append("SELECT tu.ike_ip, ipsreq.request_type, tc.Customer_Name, tc.CONTACT_CITY  AS City, tc.CONTACT_STATE AS State, ipsreq.enterprise_id, ");
			query1.append("ipsreq.request_install_date, ipsreq.request_by, ipsreq.request_status, ");
			query1.append("tu.IPSEC_TUNNEL_ID, tu.SIGNALING_HOST_SUBNET_IP, tu.SIGNALING_HOST_SUBNET_MASK, ipsreq.device_type, ");
			query1.append("env.env_order_id, env.order_number, tu.city AS TUNNEL_CITY, tu.state as TUNNEL_STATE, ipsreq.comments, ipsreq.ipsec_prov_request_id, tu.preshare_key ");			
			query1.append("FROM tbl_customer tc, tbl_ipsec_tunnel tu, " +
					"tbl_ipsec_prov_request ipsreq left outer join tbl_env_order env ");
			query1.append("ON ipsreq.env_order_id=env.env_order_id ");
			query1.append("WHERE tu.ipsec_tunnel_id=ipsreq.ipsec_tunnel_id ");
			query1.append("and ipsreq.enterprise_id  =tc.customer_id ");
		}else{
			query1.append("SELECT tu.ike_ip, ipsreq.request_type, ipsreq.enterprise_id,  ");
			query1.append("ipsreq.request_install_date, ipsreq.request_by, ipsreq.request_status, ");
			query1.append("tu.IPSEC_TUNNEL_ID, tu.SIGNALING_HOST_SUBNET_IP, tu.SIGNALING_HOST_SUBNET_MASK, ipsreq.device_type, ");
			query1.append("env.env_order_id, env.order_number, tu.city AS TUNNEL_CITY, tu.state as TUNNEL_STATE, ipsreq.comments, ipsreq.ipsec_prov_request_id, tu.preshare_key ");
			query1.append("FROM  tbl_ipsec_tunnel tu, tbl_ipsec_prov_request ipsreq " +
					"left outer join tbl_env_order env ");
			query1.append("ON ipsreq.env_order_id=env.env_order_id ");
			query1.append("WHERE tu.ipsec_tunnel_id=ipsreq.ipsec_tunnel_id ");	

		}	

		if(ipsecTunnelId > 0){
			query1.append(" and tu.IPSEC_TUNNEL_ID = ").append(ipsecTunnelId).append(" ");
		}
		
		if(ikeIp != null){
			query1.append(" and tu.ike_ip = '").append(ikeIp).append("' ");
		}
		
		if(custIdOrCustName != null){
			query1.append(" and (tc.customer_id = '").append(custIdOrCustName).append("'");
			query1.append(" or tc.Customer_Name = '").append(custIdOrCustName).append("')");
		}
		if(custName != null){
			query1.append(" and tc.Customer_Name = '").append(custName).append("'");
		} 
		
		if(custId != null){
			query1.append(" and tc.customer_id = '").append(custId).append("'");
		}
		
		if(regionType > 0){
			query1.append(" and tc.region_id = ").append(regionType).append("");
		}
		
		if(reqDtFrom != null){
			query1.append(" AND ipsreq.Request_Date >= to_date('").append(reqDtFrom).append("','mm/dd/yyyy')");
		}
		
		if( reqDtTo != null){
			query1.append(" AND ipsreq.Request_Date <= to_date('").append(reqDtTo).append("','mm/dd/yyyy')");
			//query1.append(" AND ipsreq.Request_Date < '").append(reqDtTo).append("'");
		}
		
		if(reqInstallFrom != null){
			query1.append(" AND ipsreq.Request_Install_Date>= to_date('").append(reqInstallFrom).append("','mm/dd/yyyy')");
			//query1.append(" AND ipsreq.Request_Install_Date > '").append(reqInstallFrom).append("'");
		}
		if(reqInstallTo != null){
			query1.append(" AND ipsreq.Request_Install_Date <= to_date('").append(reqInstallTo).append("','mm/dd/yyyy')");
			//query1.append(" AND ipsreq.Request_Install_Date < '").append(reqInstallTo).append("'");
		}
		if(requestBy != null){
			query1.append(" and ipsreq.request_by = '").append(requestBy).append("'");
		}
		if(requestStatus != -1){
			query1.append(" and ipsreq.request_status = ").append(requestStatus);
		}
		log.info(query1.toString());
		Statement ipStmt=null;
        ResultSet ipSecRs = null;
		try{
			ipStmt=con.createStatement();
			ipSecRs=ipStmt.executeQuery(query1.toString());
		
        while(ipSecRs.next()){
        	IpSecTemplateBean ipTempBean=new IpSecTemplateBean();
        	ipTempBean.setIkeIp(ipSecRs.getString("IKE_IP"));
        	ipTempBean.setRequestType(ipSecRs.getShort("REQUEST_TYPE"));
        	if(custId != null || custName != null){
        		ipTempBean.setCustName(ipSecRs.getString("CUSTOMER_NAME"));
        		if (ipSecRs.getString("TUNNEL_CITY") == null && ipSecRs.getString("TUNNEL_STATE") == null)
        		{
        		log.info("TUNNEL_CITY , STATE not present ");
            	ipTempBean.setCity(ipSecRs.getString("CITY"));
            	ipTempBean.setState(ipSecRs.getString("STATE"));
        		} else {
        			log.info("TUNNEL_CITY , STATE present ");
        			ipTempBean.setCity(ipSecRs.getString("TUNNEL_CITY"));
        			ipTempBean.setState(ipSecRs.getString("TUNNEL_STATE"));
        		}
        	}else{
        		String customerId = ipSecRs.getString("ENTERPRISE_ID");
        		ipTempBean = getCustomerDetails(ipTempBean, customerId, con);
        		if (ipSecRs.getString("TUNNEL_CITY") == null && ipSecRs.getString("TUNNEL_STATE") == null)
        		{
        		log.info("TUNNEL_CITY , STATE not present in else ");
        		} else {
        			log.info("TUNNEL_CITY , STATE  present in else ");
        			ipTempBean.setCity(ipSecRs.getString("TUNNEL_CITY"));
        			ipTempBean.setState(ipSecRs.getString("TUNNEL_STATE"));
        		}
        	}
        	ipTempBean.setRequestInstallDate(ipSecRs.getDate("REQUEST_INSTALL_DATE"));
        	ipTempBean.setRequestBy(ipSecRs.getString("REQUEST_BY"));
        	ipTempBean.setStatus(ipSecRs.getString("REQUEST_STATUS"));
        	ipTempBean.setIpsecTunnelId(ipSecRs.getInt("IPSEC_TUNNEL_ID"));
        	
        	ipTempBean.setHostSubIP(ipSecRs.getString("SIGNALING_HOST_SUBNET_IP"));
        	ipTempBean.setHostSubMask(ipSecRs.getInt("SIGNALING_HOST_SUBNET_MASK"));
        	int deviceType = ipSecRs.getInt("DEVICE_TYPE");
        	if(deviceType == VzbVoipEnum.IpsecDeviceType.DEVICE){
        		ipTempBean.setDeviceName(getDeviceOrEbiName(Long.parseLong(ipTempBean.getIpsecTunnelId()+""), deviceType, con));
        	}else if(deviceType == VzbVoipEnum.IpsecDeviceType.EBI){
        		ipTempBean.setEbiName(getDeviceOrEbiName(Long.parseLong(ipTempBean.getIpsecTunnelId()+""), deviceType, con));
        	}
        	ipTempBean.setEnvOrdId(ipSecRs.getLong("ENV_ORDER_ID"));
        	ipTempBean.setOrderNumber(ipSecRs.getString("ORDER_NUMBER"));
        	ipTempBean.setComments(ipSecRs.getString("COMMENTS"));
        	ipTempBean.setIpsecProvReqId(ipSecRs.getLong("IPSEC_PROV_REQUEST_ID"));
        	ipTempBean.setPreSharedKey(ipSecRs.getString("PRESHARE_KEY"));
        	log.info("ipTempBean :: preshare key " + ipTempBean.getPreSharedKey());
        	beanList.add(ipTempBean);
        }
 
	}catch(SQLException sqe){
		sqe.printStackTrace();
	}catch(Exception e){
		e.printStackTrace();
	}finally{
		try{
		if(ipSecRs != null)
			ipSecRs.close();
		if(ipStmt != null)
			ipStmt.close();
		}catch (SQLException e) {
			e.printStackTrace();
		}
	}
		return beanList;
		
	}

 public static String getIPSecConfig (Connection conn, IpSecSearchBean lObjSearchBean) throws Exception 
	{
		log.info("getIPSecConfig ");
		String lsConfigData = null;
		int liIpsecTunnelId = -1, ipsecReqId = -1, devType = -1;
		String lsIKEIP = null;
		String lsEGWN = "01";// temp
		PreparedStatement pst = null, ps1 = null;
		ResultSet res = null, res1 = null;
		IpSecTemplateBean lObjtempBean = new IpSecTemplateBean ();
		HashMap<String, String> sbchshMap = new HashMap<String, String> ();
		String sbcVal = null, sbcAction = null;
		String entId = null;
		String circuitId = null;
		String extranetDevice = null;
        StringBuffer lsIPSecDataQry = new StringBuffer ();
		lsIPSecDataQry.append("SELECT IPT.IKE_IP, IPT.IPSEC_TUNNEL_ID, IPT.SIGNALING_HOST_SUBNET_IP, IPT.SIGNALING_HOST_SUBNET_MASK, IPT.PRESHARE_KEY, IPT.PROTECTED_RESOURCE, REQ.IPSEC_PROV_REQUEST_ID, CUS.CUSTOMER_NAME, CUS.CONTACT_CITY, CUS.CONTACT_STATE, REQ.ENTERPRISE_ID, REQ.DEVICE_TYPE, IPT.EXTRANET_DEVICE, IPT.CITY, IPT.STATE  FROM TBL_IPSEC_PROV_REQUEST REQ, TBL_IPSEC_TUNNEL IPT, TBL_CUSTOMER CUS WHERE ");
		String lsSBCQry = "SELECT PROV_VALUE, PROV_ACTION FROM TBL_IPSEC_PROV_REQUEST_DETAILS WHERE IPSEC_PROV_REQUEST_ID = ?";
		try
		{
            log.info("lObjSearchBean.getIpsecTunnelId() " +lObjSearchBean.getIpsecTunnelId());
			if (lObjSearchBean.getIpsecTunnelId() !=-1 && lObjSearchBean.getIpsecTunnelId() != 0)
			{
				
				liIpsecTunnelId = lObjSearchBean.getIpsecTunnelId();
				log.info("liIpsecTunnelId " + liIpsecTunnelId);
				lsIPSecDataQry.append("IPT.IPSEC_TUNNEL_ID = " +liIpsecTunnelId + "AND ");
				
			}
			
			if (lObjSearchBean.getIkeIp() != null && lObjSearchBean.getIkeIp().trim().length()>0)
			{
				lsIKEIP = lObjSearchBean.getIkeIp();
				log.info("ikeIp " + lsIKEIP);
				if (liIpsecTunnelId == -1 || liIpsecTunnelId == 0)
				{
					lsIPSecDataQry.append("IPT.IKE_IP = '" +lsIKEIP +"' AND ");
				}
			}
			lsIPSecDataQry.append("IPT.IPSEC_TUNNEL_ID = REQ.IPSEC_TUNNEL_ID AND CUS.CUSTOMER_ID = REQ.ENTERPRISE_ID");
			pst = conn.prepareStatement(lsIPSecDataQry.toString());
			res = pst.executeQuery();
			
			while(res.next())
			{
				log.info("in getIPSecConfig rset " );
				lObjtempBean.setIkeIp(res.getString(1));
				lObjtempBean.setIpsecTunnelId(res.getInt(2));
				lObjtempBean.setHostSubIP(res.getString(3));
				lObjtempBean.setHostSubMask(res.getInt(4));
				lObjtempBean.setPreSharedKey(res.getString(5));
				lObjtempBean.setProResource(res.getString(6));
				ipsecReqId = res.getInt(7);
				log.info("ipsecReqId " +ipsecReqId);
				lObjtempBean.setIpsecReqId(ipsecReqId);
				lObjtempBean.setCustName(res.getString(8));
				if (res.getString(14) == null && res.getString(15) == null)
				{
				log.info(" existing request ");	
				lObjtempBean.setCity(res.getString(9));
				lObjtempBean.setState(res.getString(10));
				}else if (res.getString(14) != null && res.getString(15) != null)
				{
					log.info("new request after this fix : city :  " +res.getString(14) + " state : " + res.getString(15));	
					lObjtempBean.setCity(res.getString(14));
					lObjtempBean.setState(res.getString(15));
				}
				entId = res.getString(11);
				log.info("entId " +entId);
				devType = res.getInt(12);
				extranetDevice = res.getString(13);
				lObjtempBean.setExtranetDevice(extranetDevice);
				log.info("devType " +devType);
				
			}
			if (devType == VzbVoipEnum.IpsecDeviceType.DEVICE)
			{
				log.info("devType is  gwy");
				//circuitId = getCircuitID(conn, entId, "gwy");
				circuitId = getDeviceCircuitID(conn, lObjtempBean.getIpsecTunnelId());
			}
			else if(devType == VzbVoipEnum.IpsecDeviceType.EBI){
				log.info("devType is  ebi");
				//circuitId = getCircuitID(conn, entId, "ebi");
				circuitId = getEbiCircuitID(conn, lObjtempBean.getIpsecTunnelId());
			}
			if (ipsecReqId != -1)
			{
			ps1 = conn.prepareStatement(lsSBCQry);
			ps1.setInt(1, ipsecReqId);
			res1 = ps1.executeQuery();
			while(res1.next())
			{
				sbcVal = res1.getString(1);
				log.info("SBC  " +sbcVal );
				if (sbcVal != null)
					sbcVal = sbcVal.trim();
				log.info("SBC after trim " + sbcVal );
				sbcAction = res1.getString(2); // check - data type is number in DB
				log.info("sbcVal " +sbcVal+ " sbcAction " + sbcAction);
				sbchshMap.put(sbcVal, sbcAction);
			}
			}
			log.info("call generateIPSecConfig ");
			lsConfigData = generateIPSecConfig(conn, lObjtempBean, sbchshMap, circuitId);
			
		}catch(Exception e)
		{
			e.printStackTrace();
			throw e;
		}finally
		{
			if (res != null)
			{
				res.close();
			}if (pst != null)
			{
				pst.close();
			}if (res1 != null)
			{
				res1.close();
			}
			if (ps1 != null)
			{
				ps1.close();
			}
		}
     return lsConfigData;
	}
 
 
 
	public static String queryGetRow1Col1(Connection dbcon, String sql) throws SQLException {
		PreparedStatement ps = null;
		ResultSet rs = null;
		String retString = null;
		try {
			ps = dbcon.prepareStatement(sql.toString());
			rs = ps.executeQuery();
			if (rs.next()) {
				retString = rs.getString(1);
			}
		} catch (SQLException e) {
			throw e;
		} finally {
			if (rs != null)
				rs.close();
			if (ps != null)
				ps.close();
		}

		return retString;
	}
	
 
 	private static String getDeviceCircuitID(Connection conn, int ipsecTunnelId) throws Exception {
		log.info("In getDeviceCircuitID - ipsecTunnelId " + ipsecTunnelId );
		String lsDvcCktQry = "SELECT circuit_id FROM tbl_location l, tbl_gateway_device_info d, tbl_device_map m WHERE d.gateway_device_id=m.device_map_id AND m.location_id=l.location_id AND d.ipsec_tunnel_id = " + ipsecTunnelId;
		
		return queryGetRow1Col1(conn, lsDvcCktQry);
			
 	}
 	
 	
 	private static String getEbiCircuitID(Connection conn, int ipsecTunnelId) throws Exception {
		log.info("In getDeviceCircuitID - ipsecTunnelId " + ipsecTunnelId );
		String lsDvcCktQry = "SELECT circuit_id FROM tbl_tso_ebi WHERE ipsec_tunnel_id= " + ipsecTunnelId;
		
		return queryGetRow1Col1(conn, lsDvcCktQry);
			
 	}

 	

public static String getDeviceOrEbiName(long ipsecTunnelId, int deviceType,Connection conn) throws Exception {
	 String deviceOrEbiName = null;
	 try{

		 if(deviceType == VzbVoipEnum.IpsecDeviceType.DEVICE){
			 TblGatewayDeviceInfoQuery tbldevcieQuery = new TblGatewayDeviceInfoQuery();
			 tbldevcieQuery.whereIpsecTunnelIdEQ(ipsecTunnelId);
			 tbldevcieQuery.query(conn);
			 if(tbldevcieQuery.getDbBean(0) != null){
				 deviceOrEbiName = tbldevcieQuery.getDbBean(0).getDeviceName();
			 }else{
				 log.info("No Device exists for ipsectunnelid :: "+ipsecTunnelId);
			 }
		 }else if(deviceType == VzbVoipEnum.IpsecDeviceType.EBI){
			 TblTsoEbiQuery tblebiQuery = new TblTsoEbiQuery();
			 tblebiQuery.whereIpsecTunnelIdEQ(ipsecTunnelId);
			 tblebiQuery.query(conn);
			 if(tblebiQuery.getDbBean(0) != null ){
				 deviceOrEbiName = tblebiQuery.getDbBean(0).getEbiName();
			 }else{
				 log.info("No EBI exists for ipsectunnelid :: "+ipsecTunnelId);
			 }
		 }
	 }catch (Exception e)
	 {
		 e.printStackTrace();
	 }
	 return deviceOrEbiName;
 }
 public static IpSecTemplateBean getCustomerDetails(IpSecTemplateBean ipTempBean, String custId,Connection conn) throws SQLException{
	 PreparedStatement stmt = null;
	 ResultSet rs = null;
	 try {
		 String query = "SELECT CUSTOMER_NAME,CONTACT_CITY,CONTACT_STATE FROM TBL_CUSTOMER WHERE CUSTOMER_ID = ?";
		 stmt = conn.prepareStatement(query);
		 stmt.setString(1, custId);
		 rs = stmt.executeQuery();

		 if(rs.next()) {
			 ipTempBean.setCustName(rs.getString("CUSTOMER_NAME"));
			 ipTempBean.setCity(rs.getString("CONTACT_CITY"));
			 ipTempBean.setState(rs.getString("CONTACT_STATE"));
		 }
	 }
	 catch(SQLException e) {
		 e.printStackTrace();
	 } finally{
		 if(stmt != null){
			 stmt.close();
		 }
		 if(rs != null){
			 rs.close();
		 }
	 }	
	 return ipTempBean;
}
 

 public static String generateIPSecConfig (Connection conn, IpSecTemplateBean mObjtempBean, HashMap<String, String> hshSbcMap, String cktId) throws Exception 
	{
		log.info("In generateIPSecConfig - cktId " + cktId);
		StringBuffer lsbConfigData = new StringBuffer();
	     HashMap<Integer,String> lhshSubMask =  new HashMap<Integer,String> (); 	
	     lhshSubMask = getSubNetMask();	
		 String pipaddr=mObjtempBean.getIkeIp(); //param('IP_IPSEC_ROUTER');  extranet IP
	     String ipaddr=mObjtempBean.getHostSubIP();       //param('IP_TRAFFIC');
	     int index=mObjtempBean.getIpsecTunnelId();//= req_id;
	     int smaskBit=mObjtempBean.getHostSubMask();   //param('SMASK'); addressbook mask	
		 String smask = lhshSubMask.get(smaskBit);
	     log.info(" smask ---> " +smask );
	     String EGWN="01";    // param('EGWN');
	     String  city=mObjtempBean.getCity() ;        //   param('CITY');
	     String comp =mObjtempBean.getCustName();//param('ENTERPRISE');
		 String state =mObjtempBean.getState();   //param('STATE');
	     String circuitId =cktId;   // param('CIRCUIT');
	     String preshare =mObjtempBean.getPreSharedKey();       //param('PRESHARED_KEY');
		 String proResource = mObjtempBean.getProResource();
		 String extranetDevice = mObjtempBean.getExtranetDevice();
		 log.info(" extranetDevice --->" +  extranetDevice);
	     int oct1=0;
	     int oct2=0;
	     int oct3=0;
	     int oct4=0;
	     String[] octs=new String[10];
		 octs =  smask.split("\\.");
		 oct1 = 255 - Integer.parseInt(octs[0]);
		 oct2 = 255 - Integer.parseInt(octs[1]);
		 oct3 = 255 - Integer.parseInt(octs[2]);
		 oct4 = 255 - Integer.parseInt(octs[3]);
		 String invMask = String.valueOf(oct1)+"."+String.valueOf(oct2)+"."+String.valueOf(oct3)+"."+String.valueOf(oct4);

		 comp = comp.replaceAll("[^a-zA-Z0-9]", "");
	     comp=comp.replaceAll("\\s+","");
	     city=city.replaceAll("\\s+","");
		 String scust = null;
		 if (comp != null && comp.length() >=4)
		 {
			log.info(" comp " + comp);
			scust = comp.substring(0, 4);
		 }else {
			scust = comp;
		 }	
		 String pcity =null;
		 if ( city.length() >=4) 
		 {
		 pcity = city.substring(0, 4);
		 }else {
			pcity = city; 
		 }
	     String saddrBook = scust+"_"+pcity+"_"+state; 
	     String invmask="null";
	    
		////////////////////////////////////////////////////////////////////////////////////////
		 int configId; //-------------> get frm sql_1
		//$requestType, $tableName, $templateName
		 String requestType;
		 String tableName;         // --------->sql_2
		 String templateName;
		//my ($requestorName, $requestorEmailAddress, $enterprise, $term_ip,
	   // $status, $serviceType, $signallingHosts, $StateCountryCode, $Country );  -------> not set yet just declared
		 String  requestorName;
		 String requestorEmailAddress;
		 String enterprise;
		 String term_ip;
		 String status;
		 String serviceType="BroadSoft Network ";
		 String signallingHosts;
		 String stateCountryCode;
		 String country="US";
		 String scity;
		 String scomp;
		 String snumname=EGWN+"_"+comp+"_"+city;
		 String comment=null;
		 String sbcAdd = null;
		 String sbcRet = null;
		 String sbcDel = null;
		 String currentTmp = null;
		 String nextTmp = null;
		 String desTmp = null;
		 String peerTmp = null;
		 String accessTmp = null;
		 String grpTmp = null;
		 String mtchTmp = null;
		 int countSbc = 0;
		 String sbc = null;
		 String node = null;
		 String sbcIP = null;
		 String nodeIp = null;
		 int sbccnt = 1;
         int cons = 119;
		 ArrayList<String> sbcArrList = new ArrayList<String>();
		 ArrayList<String> lsArrsbcList = new ArrayList<String>();
		 ArrayList<String> lsArrNodeList = new ArrayList<String>();
		 HashMap<String, String> sbcIpMap = new HashMap<String, String> ();
		 HashMap<String, String> nodeSbcMap = new  HashMap<String, String> ();
		 String template_file = getConfParams(conn, "IPSEC_TEMPLATE_PATH"); 
		 boolean cisco = false;
		 boolean pix = false;
		 boolean adtran = false;
		 boolean HSRP = false;
		 boolean ASA = false;
		 String paccessTmp = null;
		 String paddrTmp = null;
		 String pgrpTmp = null;
		 String prTmp = null;
		 String ptrantmp = null;
		 String pkmpTmp = null;
		 String anextTmp = null;
		 String adtmp = null;
		 String crnttmp = null;
		 String acurrentTmp = null;
		 String adesTmp = null;
		 String amtchTmp = null;
		 String apeerTmp =null;
		 String hcurrentTmp = null;
		 String hdesTmp = null;
		 String hpeerTmp = null;
		 String hmtchTmp = null;
		 String temp = null;
		 String permittmp = null;
		 String tempType = null;
		 String tempattr = null;
		 String wcmask = null;
		 String firewallInfo = null;
		 HashMap<String, List<String>> hshNodeSbcIPMap = new HashMap<String, List<String>> ();
		 List<String> sbcIPList = new ArrayList<String> ();
		 HashMap<String, String> sbcSiteMap = new HashMap<String, String> ();
		 if (extranetDevice == null)
		 {
			 log.info("extranetDevice null");
			 extranetDevice = index+"_"+EGWN+"_"+comp+"_"+city+"_"+ state;
			 log.info("extranetDevice "+ extranetDevice);
		 }
				if (preshare == null) 
				{
				String preshare_tmp=EGWN+"_"+city+"_"+comp+"_"+ state;
				log.info("preshare :  "+preshare_tmp);
				String tmp=encrypt(preshare_tmp);
				log.info("encoded :  "+tmp);
				if(tmp.length()>27)
					preshare=tmp.substring(0, 27);
				else 
					preshare=tmp;
				}
				
		 comment=circuitId+"_"+EGWN+"_"+comp+"_"+city+"_"+state;
		 comment=comment.replaceAll("\\s+","");
		 
		 log.info("pipaddr : " + pipaddr + " ipaddr :  " +ipaddr+ " index : " +index+ " smask : " +smask+ " city : " +city+ " comp : " +comp+ " state : " +state+ " preshare : " +preshare +" comment : " +comment);
		 
         Iterator<Map.Entry<String, String>> hshItr = hshSbcMap.entrySet().iterator();
         while(hshItr.hasNext())
         {
         	Map.Entry<String, String> ent = hshItr.next();
         	if(ent.getValue().equalsIgnoreCase("n"))
         	{
         		if(sbcAdd == null)
					{
         			    firewallInfo = getFirewallInfo(conn, ent.getKey());
						sbcAdd = ent.getKey() + " " + firewallInfo;
					}
					else{
						firewallInfo = getFirewallInfo(conn, ent.getKey());
						sbcAdd+= ","+ent.getKey() + " " + firewallInfo;
					}
         		log.info(" device add with firewall change " + sbcAdd);
         		sbcArrList.add(ent.getKey());
         		countSbc++;
         	}
         	if (ent.getValue().equalsIgnoreCase("r"))
         	{
         		if(sbcRet == null)
					{
         			    firewallInfo = getFirewallInfo(conn, ent.getKey());
						sbcRet = ent.getKey() + " " + firewallInfo;
					}
					else{
						firewallInfo = getFirewallInfo(conn, ent.getKey());
						sbcRet+= ","+ent.getKey() + " " + firewallInfo;
					}
         		log.info("device retain with firewall change " + sbcRet);
         		sbcArrList.add(ent.getKey());
         		countSbc++;
         	}
         	if(ent.getValue().equalsIgnoreCase("o"))
         	{
         		if(sbcDel == null)
					{
         				firewallInfo = getFirewallInfo(conn, ent.getKey());
						sbcDel = ent.getKey() + " " + firewallInfo;
					}
					else 
					{
						firewallInfo = getFirewallInfo(conn, ent.getKey());
						sbcDel+= ","+ent.getKey() + " " + firewallInfo;
					}
         	}
         	
         }
         if (sbcAdd != null)
         { 
         log.info("sbcAdd " +sbcAdd); 
         } if (sbcRet != null)
         {
         log.info("sbcRet " +sbcRet);
         } if (sbcDel != null)
         {
log.info("sbcDel " +sbcDel);
         } 
         
		    Hashtable<Integer,String> fileLines=new Hashtable<Integer,String>();
		    
			String currentLine;
			
			try 
			{
				BufferedReader br = new BufferedReader(new FileReader( Normalizer.normalize(template_file, Normalizer.Form.NFD) ));
				log.info("calling getSbcIPMetaData");
				sbcIpMap = getSbcIPMetaData(conn, sbcArrList);
				Iterator<Map.Entry<String, String>> sbcItr = sbcIpMap.entrySet().iterator();
				while(sbcItr.hasNext()){
					Map.Entry<String, String> entr = sbcItr.next();
					lsArrsbcList.add(entr.getKey());
				}
				sbcSiteMap = getsbcSiteMap(conn, sbcArrList);
				
				
				Iterator<Map.Entry<String, String>> nodeItr = sbcSiteMap.entrySet().iterator();
				while(nodeItr.hasNext()){
					Map.Entry<String, String> entr = nodeItr.next();
					lsArrNodeList.add(entr.getValue());
				}
				Collections.sort(lsArrNodeList);
				nodeSbcMap = getSiteIPFromSbc(conn, sbcSiteMap);
				hshNodeSbcIPMap = getSbcIPListForSite(conn, sbcArrList, lsArrNodeList);
				try {
					int ind=0;
					while ((currentLine = br.readLine()) != null)
					{
                      currentLine = currentLine.trim();
						log.info("currentLine ----> " +currentLine);
						if (currentLine.contains("EGW - CISCO"))
						{
							log.info(" EGW - CISCO line ");
							cisco = true;
						} else if (currentLine.contains("EGW - PIX"))
						{
							log.info(" EGW - PIX line ");
							cisco = false;
							pix = true;
						}
						else if (currentLine.contains("EGW - ADTRAN"))						{
							log.info(" EGW - ADTRAN line ");
							cisco = false;
							pix = false;
							adtran = true;
						} else if (currentLine.contains("CISCO HSRP"))
						{
							log.info(" CISCO HSRP line ");
							cisco = false;
							pix = false;
							adtran = false;
							HSRP = true;
						} else if (currentLine.contains("CISCO ASA"))
						{
							log.info(" CISCO ASA line ");
							cisco = false;
							pix = false;
							adtran = false;
							HSRP = false;
							ASA = true;
						} 
						if (cisco)
						{
							log.info("In CISCO ");
						if (currentLine.contains("$NODE"))
						{
							log.info(" line !$NODE ");
							String nextLine = br.readLine();
							for (int i=0; i<lsArrNodeList.size(); i++)
							{
								log.info(" in sbc arr list itr 1");
								node = lsArrNodeList.get(i);
								log.info(" sbc " + node);
								currentTmp  = currentLine.replaceAll("\\$"+"NODE", node);
								log.info("currentLine " + currentLine);
								log.info("currentTmp " + currentTmp);
								fileLines.put(ind,currentTmp);
								log.info(fileLines.get(ind));
								ind++;
								nodeIp = nodeSbcMap.get(node);
								log.info("nodeIp  " + nodeIp);
								nextTmp = nextLine.replaceAll("\\$"+"nodeIp", nodeIp);
								log.info("nextLine  " + nextLine);
								log.info("nextTmp  " + nextTmp);
								fileLines.put(ind,nextTmp);
								ind++;
							}
						} else if (currentLine.contains("crypto map sip $countNode"))
						{
							log.info("currentLine contains  crypto map sip $countNode --- " + currentLine);
							String desLine  = br.readLine();
							log.info("desLine --- " + desLine);
							String peerLine = br.readLine();
							log.info("peerLine --- " + peerLine);
							String transLine = br.readLine();
							log.info("transLine --- " + transLine);
						    String grpLine = br.readLine();
						    log.info("grpLine --- " + grpLine);
						    String mtchLine = br.readLine();
						    log.info("mtchLine --- " + mtchLine);
						    sbccnt = 1;
                         cons = 119; 
						    for (int i=0; i<lsArrNodeList.size(); i++)
						    {
                         cons++;
                         log.info(" sbc arr list iter 2" );
                         node = lsArrNodeList.get(i);
						    log.info(" node " + node);
						    currentTmp = currentLine.replaceAll("\\$"+"countNode", String.valueOf(sbccnt));
						    log.info(" currentTmp " + currentTmp);
							fileLines.put(ind,currentTmp);
							ind++;
							desTmp = desLine.replaceAll("\\$"+"NODE", node);
							log.info(" desTmp "  + desTmp);
							fileLines.put(ind,desTmp);
							ind++;
							nodeIp = nodeSbcMap.get(node);
							log.info(" sbcIP "  + nodeIp);
							peerTmp = peerLine.replaceAll("\\$"+"nodeIp", nodeIp);
							log.info(" peerTmp "  + peerTmp);
							fileLines.put(ind,peerTmp);
							ind++;
							fileLines.put(ind,transLine);
							ind++;
							fileLines.put(ind,grpLine);
							ind++;
							mtchTmp = mtchLine.replaceAll("\\$"+"countNode", String.valueOf(cons));
                         mtchTmp = mtchTmp.replace("119+", ""); 
							log.info(" sbccnt "  + sbccnt);
							log.info(" mtchTmp "  + mtchTmp);
							fileLines.put(ind,mtchTmp);
							ind++;
							sbccnt++;
						    }
						}else if (currentLine.contains("access-list 119+$countNode"))
						{
							log.info(" currentLine contains access-list 119+$countNode ---> "  + currentLine);
							sbccnt = 1;
                         cons = 119;
							for (int i=0; i<lsArrNodeList.size(); i++)
							{
                             cons++;
								log.info(" sbc arr list itr 3 "  + currentLine);
								node = lsArrNodeList.get(i);
								log.info("sbc " +node);
								sbcIPList = hshNodeSbcIPMap.get(node);
								for (int x=0; x<sbcIPList.size(); x++)
								{
								sbcIP = sbcIPList.get(x);
								wcmask = getWildCardMask(conn, sbcIP);;
								log.info("sbcIP  " +sbcIP);
								accessTmp = currentLine.replaceAll("\\$"+"countNode", String.valueOf(cons));
                             accessTmp = accessTmp.replace("119+", "");
								log.info("accessTmp 1 " +accessTmp);
								accessTmp = accessTmp.replaceAll("\\$"+"sbcIp", sbcIP);
								if (wcmask != null && !wcmask.equals(""))
								{
								accessTmp = accessTmp.replaceAll("\\$"+"wcmask", wcmask);
								}
								log.info("accessTmp 2 " +accessTmp);
								fileLines.put(ind,accessTmp);
								ind++;
								sbccnt++;
								}
							}
						}else{
							log.info(" final else condn");
							fileLines.put(ind,currentLine);
							log.info(fileLines.get(ind));
							ind++;
							}
						
						} else if (pix)
						{
							
							log.info("In PIX ");
							if (currentLine.contains("access-list 119+$countNode"))
							{
								sbccnt = 1;
								cons = 119;
								for (int i=0; i<lsArrNodeList.size(); i++)
								{
	                                cons++;
									log.info(" sbc arr list itr in PIX "  + currentLine);
									node = lsArrNodeList.get(i);
									sbcIPList = hshNodeSbcIPMap.get(node);
									for (int n=0; n<sbcIPList.size(); n++)
									{
									sbcIP = sbcIPList.get(n);
									log.info("sbcIP  " +sbcIP);
									paccessTmp = currentLine.replaceAll("\\$"+"countNode", String.valueOf(cons));
									paccessTmp = paccessTmp.replace("119+", "");
									log.info("accessTmp 1 " +accessTmp);
									paccessTmp = paccessTmp.replaceAll("\\$"+"sbcIp", sbcIP);
									log.info("accessTmp 2 " +paccessTmp);
									fileLines.put(ind,paccessTmp);
									ind++;
									sbccnt++;
									}
								}
							}else if (currentLine.contains("crypto map sip $countNode"))
							{
								log.info("currentLine contains  crypto map sip $countNode  --- " + currentLine);
								String addrLine  = br.readLine();
								log.info("addrLine --- " + addrLine);
								String pgrpLine = br.readLine();
								log.info("pgrpLine --- " + pgrpLine);
								String prLine = br.readLine();
								log.info("prLine --- " + prLine);
								String ptranLine = br.readLine();
								log.info("ptranLine --- " + ptranLine);
							    sbccnt = 1;
	                            cons = 119; 
							    for (int i=0; i<lsArrNodeList.size(); i++)
							    {
	                            cons++;
	                            log.info(" sbc arr list iter 2" );
							    node = lsArrNodeList.get(i);
							    log.info(" node " + node);
							    currentTmp = currentLine.replaceAll("\\$"+"countNode", String.valueOf(sbccnt));
							    log.info(" currentTmp " + currentTmp);
								fileLines.put(ind,currentTmp);
								ind++;
								paddrTmp =  addrLine.replaceAll("\\+\\$"+"countNode", String.valueOf(cons));
								paddrTmp = paddrTmp.replace("119", "");
								paddrTmp = paddrTmp.replaceAll("\\$"+"countNode", String.valueOf(sbccnt));
								log.info(" paddrTmp "  + paddrTmp);
								fileLines.put(ind,paddrTmp);
								ind++;
								pgrpTmp = pgrpLine.replaceAll("\\$"+"countNode", String.valueOf(sbccnt));
								fileLines.put(ind,pgrpTmp);
								ind++;
								nodeIp = nodeSbcMap.get(node);
								log.info(" nodeIp "  + nodeIp);
								prTmp = prLine.replaceAll("\\$"+"nodeIp", nodeIp);
								prTmp = prTmp.replaceAll("\\$"+"countNode", String.valueOf(sbccnt));
								log.info(" prTmp "  + prTmp);
								fileLines.put(ind,prTmp);
								ind++;
								ptrantmp = ptranLine.replaceAll("\\$"+"countNode", String.valueOf(sbccnt));
								fileLines.put(ind,ptrantmp);
								ind++;
								sbccnt++;
							    }
							}else if (currentLine.contains("isakmp key $preSharedKey"))
							{
								for (int i=0; i<lsArrNodeList.size(); i++)
								{
									log.info(" sbc arr list itr in PIX "  + currentLine);
									node = lsArrNodeList.get(i);
									log.info("node " +node);
									nodeIp = nodeSbcMap.get(node);
									log.info("nodeIp  " +nodeIp);
									pkmpTmp = currentLine.replaceAll("\\$"+"nodeIp", nodeIp);
									log.info("pkmpTmp  " +pkmpTmp);
									fileLines.put(ind,pkmpTmp);
									ind++;
								}
							}
							else{
								log.info(" In pix final else condn");
								fileLines.put(ind,currentLine);
								log.info(fileLines.get(ind));
								ind++;
							}
							
						} else if (adtran)
						{
							
							log.info("In ADTRAN ");
							if (currentLine.equals("peer $nodeIp"))
							{
								for (int i=0; i<lsArrNodeList.size(); i++)
								{
									log.info(" sbc arr list itr in ADTRAN "  + currentLine);
									node = lsArrNodeList.get(i);
									log.info("node " +node);
									nodeIp = nodeSbcMap.get(node);
									log.info("nodeIp  " +nodeIp);
									adtmp = currentLine.replaceAll("\\$"+"nodeIp", nodeIp);
									log.info("adtmp  " +adtmp);
									fileLines.put(ind,adtmp);
									ind++;
								}
							} else if (currentLine.contains("$NODE")){
								String adnxtLine  = br.readLine();
								sbccnt = 1;
								for (int i=0; i<lsArrNodeList.size(); i++)
								{
									node = lsArrNodeList.get(i);
									crnttmp = currentLine.replaceAll("\\$"+"NODE", node);
									fileLines.put(ind,crnttmp);
									ind++;
									nodeIp = nodeSbcMap.get(node);
									log.info("nodeIp   " + nodeIp );
									anextTmp = adnxtLine.replaceAll("\\$"+"nodeIp", nodeIp );
									anextTmp = anextTmp.replaceAll("\\$"+"countNode", String.valueOf(sbccnt));
									log.info("adnxtLine  " + adnxtLine);
									log.info("anextTmp  " + anextTmp);
									fileLines.put(ind,anextTmp);
									ind++;
									sbccnt++;
								}
								
							} else if (currentLine.startsWith("crypto map sip $countNode"))
							{
								log.info("currentLine contains  crypto map sip $countNode --- " + currentLine);
								String adesLine  = br.readLine();
								log.info("adesLine --- " + adesLine);
								String amtchLine = br.readLine();
								log.info("amtchLine --- " + amtchLine);
								String apeerLine = br.readLine();
								log.info("apeerLine --- " + apeerLine);
								String atransLine = br.readLine();
								log.info("transLine --- " + atransLine);
								String asecLine = br.readLine();
								 log.info("asecLine --- " + asecLine);
							    String agrpLine = br.readLine();
							    log.info("agrpLine --- " + agrpLine);
							    sbccnt = 1;
							    for (int i=0; i<lsArrNodeList.size(); i++)
							    {
	                            log.info(" sbc arr list iter 2" );
							    node = lsArrNodeList.get(i);
							    log.info(" node " + node);
							    acurrentTmp = currentLine.replaceAll("\\$"+"countNode", String.valueOf(sbccnt));
							    log.info(" currentTmp " + acurrentTmp);
								fileLines.put(ind,acurrentTmp);
								ind++;
								adesTmp = adesLine.replaceAll("\\$"+"NODE", node);
								log.info(" adesTmp "  + adesTmp);
								fileLines.put(ind,adesTmp);
								ind++;
								amtchTmp = amtchLine.replaceAll("\\$"+"countNode", String.valueOf(sbccnt));
								fileLines.put(ind,amtchTmp);
								ind++;
								nodeIp = nodeSbcMap.get(node);
								log.info(" nodeIp "  + nodeIp);
								apeerTmp = apeerLine.replaceAll("\\$"+"nodeIp", nodeIp);
								log.info(" peerTmp "  + apeerTmp);
								fileLines.put(ind,apeerTmp);
								ind++;
								fileLines.put(ind,atransLine);
								ind++;
								fileLines.put(ind,asecLine);
								ind++;
								fileLines.put(ind,agrpLine);
								ind++;
								sbccnt++;
							    }
							}else if (currentLine.contains("ip access-list extended"))
							{
								String permitLine = br.readLine();
								 sbccnt = 1;
								    for (int i=0; i<lsArrNodeList.size(); i++)
								    {
										log.info("*** ip access-list extended node change *****");
								    	node = lsArrNodeList.get(i);
										log.info(" node " +node);
								    	temp = currentLine.replaceAll("\\$"+"countNode", String.valueOf(sbccnt));
								    	fileLines.put(ind,temp);
										ind++;
										sbcIPList = hshNodeSbcIPMap.get(node);
										for (int j=0; j<sbcIPList.size(); j++)
										{
										sbcIP = sbcIPList.get(j);
										wcmask =getWildCardMask(conn, sbcIP);
										log.info(" sbcIP "  + sbcIP);
										permittmp = permitLine.replaceAll("\\$"+"sbcIp", sbcIP);
										if (wcmask != null && !wcmask.equals(""))
										{	
										permittmp = permittmp.replaceAll("\\$"+"wcmask", wcmask);	
										}
										fileLines.put(ind,permittmp);
										ind++;
										}
										sbccnt++;
								    }
							}
							else{
								log.info(" In adtran final else condn");
								fileLines.put(ind,currentLine);
								log.info(fileLines.get(ind));
								ind++;
							}
						} else if (HSRP)
						{
							log.info("In HSRP ");
							if (currentLine.contains("$NODE")){
								String hsnext = br.readLine();
                             String sbcLine = null;
								    for (int i=0; i<lsArrNodeList.size(); i++)
								    {
								    	node = lsArrNodeList.get(i);
								    	sbcLine = currentLine.replaceAll("\\$"+"NODE", node);
								    	fileLines.put(ind,sbcLine);
								    	ind++;
								    	nodeIp = nodeSbcMap.get(node);
								    	temp = hsnext.replaceAll("\\$"+"nodeIp", nodeIp);
								    	fileLines.put(ind,temp);
								    	ind++;
								    }
							} else if (currentLine.contains("crypto map sip $countNode"))
							{
								log.info("currentLine contains  crypto map sip $countSbc --- " + currentLine);
								String hdesLine  = br.readLine();
								log.info("hdesLine --- " + hdesLine);
								String hpeerLine = br.readLine();
								log.info("peerLine --- " + hpeerLine);
								String htransLine = br.readLine();
								log.info("transLine --- " + htransLine);
							    String hgrpLine = br.readLine();
							    log.info("grpLine --- " + hgrpLine);
							    String hmtchLine = br.readLine();
							    log.info("mtchLine --- " + hmtchLine);
							    String hrevLine = br.readLine();
							    log.info("hrevLine --- " + hrevLine);
							    sbccnt = 1;
	                            cons = 119; 
							    for (int i=0; i<lsArrNodeList.size(); i++)
							    {
	                            cons++;
	                            log.info(" sbc arr list iter 2" );
							    node = lsArrNodeList.get(i);
							    log.info(" node " + node);
							    hcurrentTmp = currentLine.replaceAll("\\$"+"countNode", String.valueOf(sbccnt));
							    log.info(" hcurrentTmp " + hcurrentTmp);
								fileLines.put(ind,hcurrentTmp);
								ind++;
								hdesTmp = hdesLine.replaceAll("\\$"+"NODE", node);
								log.info(" hdesTmp "  + hdesTmp);
								fileLines.put(ind,hdesTmp);
								ind++;
								nodeIp = nodeSbcMap.get(node);
								log.info(" nodeIp "  + nodeIp);
								hpeerTmp = hpeerLine.replaceAll("\\$"+"nodeIp", nodeIp);
								log.info(" peerTmp "  + hpeerTmp);
								fileLines.put(ind,hpeerTmp);
								ind++;
								fileLines.put(ind,htransLine);
								ind++;
								fileLines.put(ind,hgrpLine);
								ind++;
								hmtchTmp = hmtchLine.replaceAll("\\$"+"countNode", String.valueOf(cons));
								hmtchTmp = hmtchTmp.replace("119+", ""); 
								log.info(" sbccnt "  + sbccnt);
								log.info(" mtchTmp "  + hmtchTmp);
								fileLines.put(ind,hmtchTmp);
								ind++;
								sbccnt++;
							    }
							}else if (currentLine.contains("ip route $sbcIp"))
							{
								for (int i=0; i<lsArrsbcList.size(); i++)
								{
									 sbc = lsArrsbcList.get(i);
									 sbcIP = sbcIpMap.get(sbc);
									 temp = currentLine.replaceAll("\\$"+"sbcIp", sbcIP);
									 fileLines.put(ind,temp);
									 ind++;
								}
							} else if (currentLine.contains("access-list 119+$countNode"))
							{
								sbccnt = 1;
                             cons = 119; 
								for (int i=0; i<lsArrNodeList.size(); i++)
								{
                             cons++;
								node = lsArrNodeList.get(i);
								sbcIPList = hshNodeSbcIPMap.get(node);
								for (int k=0; k<sbcIPList.size(); k++)
								{
								sbcIP = sbcIPList.get(k);
								wcmask = getWildCardMask(conn, sbcIP);
								temp = currentLine.replaceAll("\\$"+"countNode", String.valueOf(cons));
                             temp = temp.replace("119+", "");
								temp = temp.replaceAll("\\$"+"sbcIp", sbcIP);
								if (wcmask != null && !wcmask.equals(""))
								{
								temp = temp.replaceAll("\\$"+"wcmask", wcmask);	
								}
								fileLines.put(ind,temp);
								ind++;
								sbccnt++;
								}
								}
							}
							else{
								log.info(" In  hsrp final else condn");
								fileLines.put(ind,currentLine);
								log.info(fileLines.get(ind));
								ind++;
							}
						} else if (ASA)
						{
							log.info("In ASA ");
							if (currentLine.contains("access-list 119+$countNode"))
							{
								sbccnt = 1;
                             cons = 119;
								for (int i=0; i<lsArrNodeList.size(); i++)
								{
                             cons++;
                             node = lsArrNodeList.get(i);
                             sbcIPList = hshNodeSbcIPMap.get(node);
                             for (int l=0; l<sbcIPList.size(); l++)
								{
                            	 sbcIP = sbcIPList.get(l);
								temp = currentLine.replaceAll("\\$"+"countNode", String.valueOf(cons));
                             temp = temp.replace("119+", "");
                             log.info(" ASA - temp " + temp);
								temp = temp.replaceAll("\\$"+"sbcIp", sbcIP);
                             log.info(" ASA - temp after sbcIp " +temp); 
								fileLines.put(ind,temp);
								ind++;
								sbccnt++;
								}
								}
							} else if (currentLine.contains("crypto map sip $countNode"))
							 {
								String cmtchLine = br.readLine();
								String cgrpLine = br.readLine();
								String cpeerLine = br.readLine();
								String ctransLine  = br.readLine();
								sbccnt = 1;
								cons = 119; 
								for (int i=0; i<lsArrNodeList.size(); i++)
								{
									 cons++;
			                            log.info(" sbc arr list iter 2" );
			                            node = lsArrNodeList.get(i);
									    log.info(" sbc " + sbc);
									    currentTmp = currentLine.replaceAll("\\$"+"countNode", String.valueOf(sbccnt));
									    log.info(" currentTmp " + currentTmp);
										fileLines.put(ind,currentTmp);
										ind++;
										paddrTmp =  cmtchLine.replaceAll("\\+\\$"+"countNode", String.valueOf(cons));
										paddrTmp = paddrTmp.replace("119", "");
										paddrTmp = paddrTmp.replaceAll("\\$"+"countNode", String.valueOf(sbccnt));
										log.info(" paddrTmp "  + paddrTmp);
										fileLines.put(ind,paddrTmp);
										ind++;
										pgrpTmp = cgrpLine.replaceAll("\\$"+"countNode", String.valueOf(sbccnt));
										fileLines.put(ind,pgrpTmp);
										ind++;
										nodeIp = nodeSbcMap.get(node);
										log.info(" nodeIp "  + nodeIp);
										prTmp = cpeerLine.replaceAll("\\$"+"nodeIp", nodeIp);
										prTmp = prTmp.replaceAll("\\$"+"countNode", String.valueOf(sbccnt));
										log.info(" prTmp "  + prTmp);
										fileLines.put(ind,prTmp);
										ind++;
										ptrantmp = ctransLine.replaceAll("\\$"+"countNode", String.valueOf(sbccnt));
										fileLines.put(ind,ptrantmp);
										ind++;
										sbccnt++;
								}
							 } else if (currentLine.contains("tunnel-group $nodeIp type"))
							 {
								 String attrLine = br.readLine();
								 String presharedLine = br.readLine();
								 for (int i=0; i<lsArrNodeList.size(); i++)
								 {
									 node = lsArrNodeList.get(i);
									 nodeIp = nodeSbcMap.get(node);
									 tempType = currentLine.replaceAll("\\$"+"nodeIp", nodeIp);
									 fileLines.put(ind,tempType);
									 ind++;
									 tempattr = attrLine.replaceAll("\\$"+"nodeIp", nodeIp );
									 fileLines.put(ind,tempattr);
									 ind++;
									 fileLines.put(ind,presharedLine);
									 ind++;
								 }
								 
							 }else{
									log.info(" In  hsrp final else condn");
									fileLines.put(ind,currentLine);
									log.info(fileLines.get(ind));
									ind++;
								}
							
						}else{
							log.info("Main else condn");
	                        if (currentLine.contains("NSM") && currentLine.contains("VARS"))
	                        { 
	                          log.info(" NSM VARS line ");
	                          currentLine = currentLine.trim();
	                        }
							fileLines.put(ind,currentLine);
							log.info(fileLines.get(ind));
							ind++;
							}
					}//while
				} catch (IOException e) {
					
					e.printStackTrace();
				}//inner catch
				
				//for(String line:fileLines)
				{
					//log.info(line);
				}
				
			} catch (FileNotFoundException e) {
				
				e.printStackTrace();
			}//outer catch
			int start=-1;
			Iterator<Map.Entry<Integer, String>> it = fileLines.entrySet().iterator();
			while (it.hasNext()) {
				Map.Entry<Integer, String> entry = it.next();
			log.info(entry.getKey()+"         " +entry.getValue());

                log.info(" fileLines iter " + entry.getValue()); 
				  if(entry.getValue().matches("\\s*"+"\\#"+"\\s+"+"NSM"+"\\s+"+"VARS"))
				  {
					  log.info(" line matches the regular expr ");
					  start=entry.getKey();
					  log.info("start " +start);
					  //log.info("Start   :  ");
					 // log.info("Index"+entry.getKey()+"    Line"+entry.getValue());
				  }

				  // Remove entry if key is null or equals 0.
				  if (entry.getValue().contains("$pipaddr")) 
				  {
					  log.info(" entr contains pipaddr ");
					 //log.info(fileLines.get(entry.getKey()));
					  fileLines.put(entry.getKey(),entry.getValue().replaceAll("\\$"+"pipaddr", pipaddr) );
					 // fileLines.put(entry.getKey(),entry.getValue().replace('$', ' '));
					 //log.info(fileLines.get(entry.getKey()));
				  }
				  if (entry.getValue().contains("$sigHost")) 
				  {
					  log.info(" entr contains sigHost ");
					  fileLines.put(entry.getKey(),entry.getValue().replaceAll("\\$"+"sigHost", ipaddr) );
					  //fileLines.put(entry.getKey(),entry.getValue().replace('$', ' '));
				  }
				  if (entry.getValue().contains("$maskIp")) 
				  {
					  log.info(" entr contains maskIp ");
					  fileLines.put(entry.getKey(),entry.getValue().replaceAll("\\$"+"maskIp", smask) );
					  //fileLines.put(entry.getKey(),entry.getValue().replace('$', ' '));
				  }
				  if (entry.getValue().contains("$index")) 
				  {
					  log.info(" entr contains index ");
					  fileLines.put(entry.getKey(),entry.getValue().replaceAll("\\$"+"index", Integer.toString(index)) );
					  //fileLines.put(entry.getKey(),entry.getValue().replace('$', ' '));
				  }
				  if (entry.getValue().contains("$snumname")) 
				  {
					  log.info(" entr contains snumname ");
					  fileLines.put(entry.getKey(),entry.getValue().replaceAll("\\$"+"snumname", snumname) );
					  //fileLines.put(entry.getKey(),entry.getValue().replace('$', ' '));
				  }
				  if (entry.getValue().contains("$circuitid")) 
				  {
					  log.info(" entr contains circuitid ");
                   if (circuitId != null)
                   {
					  fileLines.put(entry.getKey(),entry.getValue().replaceAll("\\$"+"circuitid", circuitId) );
                   } 
					  //fileLines.put(entry.getKey(),entry.getValue().replace('$', ' '));
				  }
				  if (entry.getValue().contains("$EGWN")) 
					  {
					  log.info(" entr contains EGWN ");
					  fileLines.put(entry.getKey(),entry.getValue().replaceAll("\\$"+"EGWN", EGWN) );
					  //fileLines.put(entry.getKey(),entry.getValue().replace('$', ' '));
					  }
				  if (entry.getValue().contains("$scity")) 
				  {
					  log.info(" entr contains scity ");
					  fileLines.put(entry.getKey(),entry.getValue().replaceAll("\\$"+"scity", city) );
					  //fileLines.put(entry.getKey(),entry.getValue().replace('$', ' '));
				  }
				  if (entry.getValue().contains("$scomp")) 
					  {
					  log.info(" entr contains scomp ");
					  fileLines.put(entry.getKey(),entry.getValue().replaceAll("\\$"+"scomp", comp) );
					  //fileLines.put(entry.getKey(),entry.getValue().replace('$', ' '));
					  }
				  if (entry.getValue().contains("$state")) 
					  {
					  log.info(" entr contains state ");
					  fileLines.put(entry.getKey(),entry.getValue().replaceAll("\\$"+"state", state) );
					  //fileLines.put(entry.getKey(),entry.getValue().replace('$', ' '));
					  }
				 /* if (entry.getValue().contains("invmask")) 
					  {
					  	fileLines.put(entry.getKey(),entry.getValue().replaceAll("invmask", this.invmask) );
					  	fileLines.put(entry.getKey(),entry.getValue().replace('$', ' '));
					  }*/
				  
				  if (entry.getValue().contains("$comment")) 
					  {
					  log.info(" entr contains comment ");
					  	fileLines.put(entry.getKey(),entry.getValue().replaceAll("\\$"+"comment", comment) );
					  	//fileLines.put(entry.getKey(),entry.getValue().replace('$', ' '));
					  }
				  if (entry.getValue().contains("$vpnid")) 
					  {
					  log.info(" entr contains vpnid ");
					  	//fileLines.put(entry.getKey(),entry.getValue().replaceAll("\\$"+"vpnid", Integer.toString(vpnid)) );
					  	//fileLines.put(entry.getKey(),entry.getValue().replace('$', ' '));
					  }
				  
				  if (entry.getValue().contains("$pidout")) 
					  {
					  log.info(" entr contains pidout ");
					  	//fileLines.put(entry.getKey(),entry.getValue().replaceAll("\\$"+"pidout", Integer.toString(pidout)) );
					  	//fileLines.put(entry.getKey(),entry.getValue().replace('$', ' '));
					  }
				 if (entry.getValue().contains("$pidin")) 
					  {
					 log.info(" entr contains pidin ");
					  //fileLines.put(entry.getKey(),entry.getValue().replaceAll("\\$"+"pidin", Integer.toString(pidin)) );
					  //fileLines.put(entry.getKey(),entry.getValue().replace('$', ' '));
					  }
				 if (entry.getValue().contains("$gid")) 
					  {
					 log.info(" entr contains gid ");
					  //fileLines.put(entry.getKey(),entry.getValue().replaceAll("\\$"+"gid", Integer.toString(gid)) );
					  //fileLines.put(entry.getKey(),entry.getValue().replace('$', ' '));
					  }
				  if (entry.getValue().contains("$svcType")) 
					  {
					  log.info(" entr contains svcType ");
					  fileLines.put(entry.getKey(),entry.getValue().replaceAll("\\$"+"svcType", serviceType)) ;
					  //fileLines.put(entry.getKey(),entry.getValue().replace('$', ' '));
					  
					  }
				  if (entry.getValue().contains("$signallingHosts")) 
					  {
					  log.info(" entr contains signallingHosts ");
					  //fileLines.put(entry.getKey(),entry.getValue().replaceAll("\\$"+"signallingHosts", signallingHosts)) ;
					  //fileLines.put(entry.getKey(),entry.getValue().replace('$', ' '));
					  }
				  if (entry.getValue().contains("$sbcAdd")) 
					  {
					  log.info(" entr contains sbcAdd ");
                                       if (sbcAdd != null)
                                       { 
					  fileLines.put(entry.getKey(),entry.getValue().replaceAll("\\$"+"sbcAdd", sbcAdd)) ;
                                       }
                                       else 
                                       {
                                        fileLines.put(entry.getKey(),entry.getValue().replaceAll("\\$"+"sbcAdd", "null")); 
                                       } 
					  //fileLines.put(entry.getKey(),entry.getValue().replace('$', ' '));
					  }
				  if (entry.getValue().contains("$sbcretain"))
				      {
					  log.info(" entr contains sbcretain ");
                   if (sbcRet != null)
                   { 
					  fileLines.put(entry.getKey(),entry.getValue().replaceAll("\\$"+"sbcretain", sbcRet)) ;
                   }
                   else {
                                       fileLines.put(entry.getKey(),entry.getValue().replaceAll("\\$"+"sbcretain", "null"));
                         }
				      }
				  if (entry.getValue().contains("$sbcDel"))
				      {
					  log.info(" entr contains sbcDel ");
                   if (sbcDel != null)
                   {
					  fileLines.put(entry.getKey(),entry.getValue().replaceAll("\\$"+"sbcDel", sbcDel)) ;
                   }
                   else {
                                       fileLines.put(entry.getKey(),entry.getValue().replaceAll("\\$"+"sbcDel", "null"));
				      }
                }
				  if (entry.getValue().contains("$preSharedKey")) 
				  {
					  log.info(" entr contains preSharedKey ");
					  //log.info(entry.getKey()+"----"+entry.getValue());
					  log.info("Prekeyshare values "+entry.getKey()+"----"+entry.getValue()+"-----"+preshare);
					  log.info(entry.getKey()+"----"+entry.getValue());
					  log.info(entry.getKey()+"----"+entry.getValue());
					  preshare = Matcher.quoteReplacement(preshare);
					  log.info(" preshare after quote replacement " + preshare);
					  fileLines.put(entry.getKey(),entry.getValue().replaceAll("\\$"+"preSharedKey", preshare) );
					  //fileLines.put(entry.getKey(),entry.getValue().replace('$', ' '));
					 // log.info(entry.getKey()+"----"+entry.getValue());
					  
				  }	
				  if (entry.getValue().contains("$proResource"))
				  {
					log.info(" entr contains proResource ");
					fileLines.put(entry.getKey(),entry.getValue().replaceAll("\\$"+"proResource", proResource)) ;	
				  }	
				 if (entry.getValue().contains("$saddrReg"))
				 {
					log.info(" entr contains saddrReg ");
					fileLines.put(entry.getKey(),entry.getValue().replaceAll("\\$"+"saddrReg", saddrBook));
				 }
				 if (entry.getValue().contains("$invmask"))
				 {
					log.info(" entr contains invmask ");
					fileLines.put(entry.getKey(),entry.getValue().replaceAll("\\$"+"invmask", invMask) );	
				 }
				 if (entry.getValue().contains("$extranet"))
				 {
					 log.info(" entr contains extranet ");
					 fileLines.put(entry.getKey(),entry.getValue().replaceAll("\\$"+"extranet", extranetDevice) );
				 }
				}
			
			lsbConfigData = write_crypto(start,fileLines);
			log.info("printing the string buffer " +lsbConfigData.toString());
			
			return lsbConfigData.toString();
		
		 
	}

	
	public static String encrypt(String preshare_tmp )
	{
		log.info("In encrypt method ");
		EncUtil eu= new EncUtil();
		String ret=eu.run(preshare_tmp);
		log.info("ret " + ret);
		return ret;
	}
	public static StringBuffer write_crypto(int start, Hashtable<Integer,String> fileLines)
	{
		log.info(" write_crypto  ");
		String map=" #=============================================================================\n";
		String crypto_file = "temp_crypt.txt";
		PrintWriter printWriter;  
		StringBuffer lsbOutput = new StringBuffer();
        try {    
            printWriter = new PrintWriter(new FileOutputStream(crypto_file, true));
            int length = fileLines.size();    
            int i;  
           
            log.info("now start with writing to Crypto  ");
            if(start!=-1)
            {
            	log.info(" start not -1 ");
            	printWriter.println(map);
	            for(i = 0; i < length; i++) {
	            	log.info(" in filelines iteration ");
	            	if(i>=start)
	            	{
	            		log.info(" start appending to str buffer ");
	            		printWriter.println(fileLines.get(i));
	            		lsbOutput.append(fileLines.get(i));
	            		lsbOutput.append("\n");
	                	log.info(fileLines.get(i));
	                	}
	            }
            }
            log.info(" o/p written to file and strbuf");
            printWriter.close();    
        }  
        catch(IOException e) {  
            log.info(e.getMessage());  
        }
        return lsbOutput;

	}
	public static String getCircuitID(Connection conn, String custId, String devType) throws Exception
	{
		log.info("In getCircuitID - custId " + custId + " devType " + devType);
		String lsEbiQry = "SELECT CIRCUIT_ID FROM TBL_TSO_EBI WHERE ENTERPRISE_ID = " + custId;
		String lsGwyQry = "SELECT CIRCUIT_ID FROM TBL_LOCATION WHERE ENTERPRISE_ID = " +custId;
		Statement stmt = null;
		ResultSet rs = null;
		String circuitId = null;
		
		try
		{
			stmt = conn.createStatement();
			if (devType  != null && devType.equalsIgnoreCase("ebi"))
			{
				log.info("In devType ebi");
			rs = stmt.executeQuery(lsEbiQry);
			}
			else if (devType  != null && devType.equalsIgnoreCase("gwy")){
				log.info("In devType gwy");
				rs = stmt.executeQuery(lsGwyQry);
			}
			while (rs.next())
			{
				circuitId = rs.getString(1);
				log.info("circuitId " +circuitId);
			}
		}catch(Exception e)
		{
			e.printStackTrace();
			throw e;
		}finally
		{
			if (rs != null){
				rs.close();
			}if (stmt != null)
			{
				stmt.close();
			}
		}
		return circuitId;
		
	}
	public static HashMap<String, String> getSbcIPMetaData(Connection conn, ArrayList<String> sbcList) throws Exception
	{
		log.info("getSbcIPMetaData ---> ");
		String lsNwkNodeQry = "SELECT CLLI, NWK_NODE_DEVICE_ID FROM TBL_NWK_NODE_DEVICE WHERE CLLI = ?";
		String lsSbcMetaDataQry = "SELECT RIVM.PARAM_VALUE FROM TBL_SBC_RIV_METADATA RIVM, TBL_NWK_NODE_DEVICE NWND WHERE RIVM.PARAM_NAME = 'CUST_SIG_BASE_IP'  AND RIVM.LEVEL_KEY = NWND.NWK_NODE_DEVICE_ID  AND RIVM.LEVEL_KEY = ?";
		PreparedStatement ps1 = null;
		PreparedStatement ps2 = null;
		ResultSet rset1 = null;
		ResultSet rset2 = null;
		String lsShortName = null;
		int nwkNodeDevId = -1, liNwkNodeDevId = -1;
		HashMap<String, Integer> lhshNwkSbcId = new HashMap<String, Integer>();
		HashMap<String, String> sbcIPhshMap = new HashMap<String, String>();
		Iterator<String> nwkSbcItr = null;
		String sbc = null, ip = null;
		try
		{
			ps1 = conn.prepareStatement(lsNwkNodeQry);
			for (String sbcVal : sbcList)
			{
			log.info("In sbcList itr for nwk node dev qry ---> sbc " +sbcVal);
			ps1.setString(1, sbcVal);
			rset1 = ps1.executeQuery();
			while(rset1.next())
			{
				lsShortName = rset1.getString(1);
				nwkNodeDevId = rset1.getInt(2);
				log.info("rset of nwkNodeqry lsShortName " + lsShortName + " nwkNodeDevId " + nwkNodeDevId);
				lhshNwkSbcId.put(lsShortName, Integer.valueOf(nwkNodeDevId));
			}
			}
			if (lhshNwkSbcId != null && !lhshNwkSbcId.isEmpty())
			{
				log.info("lhshNwkSbcId not empty");
				nwkSbcItr = lhshNwkSbcId.keySet().iterator();
				ps2 = conn.prepareStatement(lsSbcMetaDataQry);
				while(nwkSbcItr.hasNext())
				{
					sbc = nwkSbcItr.next();
					liNwkNodeDevId = lhshNwkSbcId.get(sbc);
					log.info("sbc " +sbc+ "liNwkNodeDevId " + liNwkNodeDevId);
					ps2.setString(1, String.valueOf(liNwkNodeDevId));
					rset2 = ps2.executeQuery();
					while (rset2.next())
					{
						ip = rset2.getString(1);
						log.info("rset of metadata tbl - ip " + ip );
						sbcIPhshMap.put(sbc, ip);
					}
					
				}
			}
			log.info("sbcIPhshMap size " + sbcIPhshMap.size());
			
		}catch (Exception e)
		{
			e.printStackTrace();
			throw e;
		}finally
		{
			if (rset1 != null)
			{
				rset1.close();
			}if (rset2 != null)
			{
				rset2.close();
			}if (ps1 != null)
			{
				ps1.close();
			}if (ps2 != null)
			{
				ps2.close();
			}
		}
		return sbcIPhshMap;
		
	}
	
	public static String getIpsecTunnelStatus (Connection conn, long ipsecTunnelId) throws Exception 
	{
		TblIpsecTunnelQuery tblTunnelQuery = new TblIpsecTunnelQuery();
		tblTunnelQuery.whereIpsecTunnelIdEQ(ipsecTunnelId);
		tblTunnelQuery.query(conn);
		if(tblTunnelQuery.getDbBean(0) != null){
			return getTunnelStatus(conn, tblTunnelQuery.getDbBean(0).getIkeIp());
		}
		log.info("Ipsec Tunnel doesn't exists with ID :: "+ipsecTunnelId);
		return null;
	}

 public static String getTunnelStatus (Connection conn, String ikeGwyIP) throws Exception 
 {
	 String tunnelStatus = null;
	 try{
		 log.info(" In getTunnelStatus - ikeGwyIP " + ikeGwyIP);
	     /*	
         ServerConnectionInfo connInfo = null;
         SSHClient sshClient = null;
         connInfo = getConnectionInfo(conn);
         sshClient = new SSHClient(connInfo);
         sshClient.writeln("\n");
         sshClient.read();
         sshClient.writeln("grep "+ ikeGwyIP +" /apps/azl/smarts/data/syslog/netscreen.log | tail -50");
         tunnelStatus = sshClient.read();
         log.info(sshClient);
         sshClient.close();	

	     log.info( " tunnelStatus " +tunnelStatus);	
			*/

        
		 String host = getConfParams(conn, "IPSEC_HOST"); // getHostNameFromDB -- test host name
	     String userId = getConfParams(conn, "IPSEC_USERNAME");	
		 String pcmd = "grep "+ikeGwyIP+" /apps/azl/smarts/data/syslog/netscreen.log | tail -50";
		 log.info(" pcmd ----> " + pcmd);
		 StringBuffer lstrbuff = new StringBuffer ();
		 Process pr = Runtime.getRuntime().exec("/usr/bin/ssh "+userId+"@"+host+" " +pcmd);
		 log.info(" After command exec "); 
		 String sline = null;
		 BufferedReader stdInput = new BufferedReader(new InputStreamReader(pr.getInputStream()));

		 BufferedReader stdError = new BufferedReader(new InputStreamReader(pr.getErrorStream()));

		 // read the output from the command

		 log.info("Here is the standard output of the command:\n");
		 while ((sline = stdInput.readLine()) != null) {
			 log.info(" In tunnel stat while loop ");
			 log.info(sline);
			 lstrbuff.append(sline); 
			 lstrbuff.append("<br>");
		 }
		 tunnelStatus = lstrbuff.toString();
       
	 }catch(Exception e){
	     log.info("IPSEC TUNNEL STATUS FAILURE : Error fetching status from SMARTS system");	
		 e.printStackTrace();
		 throw e;
	 }
	 return tunnelStatus;
 }


public static ServerConnectionInfo getConnectionInfo(Connection conn) {
       ServerConnectionInfo connInfo = new ServerConnectionInfo();
       try
         {
               String hostName = getConfParams(conn, "IPSEC_HOST");
               String userId = getConfParams(conn, "IPSEC_USERNAME");
         connInfo.setHostName(hostName);
         connInfo.setPort(22);
         connInfo.setUserName(userId);
         connInfo.setPassword(null);
         connInfo.setTimeOut(100);
        }catch (Exception e)
        {
         e.printStackTrace();
        }
         return connInfo;
     }

public static String getConfParams (Connection conn, String paramName) throws Exception
 {
  String configQry = "SELECT PARAM_VALUE FROM TBL_CONFIG_PARAMS WHERE PARAM_NAME = '"+paramName +"'";
  Statement stmt = null;
  ResultSet rs = null;
  String paramVal = null;
  try
  {
   stmt = conn.createStatement();
   rs = stmt.executeQuery(configQry);
   while(rs.next())
   {
    paramVal = rs.getString(1);
   }
  }catch(Exception e)
  {
   e.printStackTrace();
   throw e;
  }finally
  {
  if (rs != null)
  {
    rs.close();
  } 
  if (stmt != null)
  {
    stmt.close();
  }
   
  }
 return paramVal;
 }

public static HashMap<Integer,String> getSubNetMask() throws Exception
{
log.info("IN getSubNetMask --- ");
try
{
mhshSubMask.put(1,"128.0.0.0");
mhshSubMask.put(2,"192.0.0.0");
mhshSubMask.put(3,"224.0.0.0");
mhshSubMask.put(4,"240.0.0.0");
mhshSubMask.put(5,"248.0.0.0");
mhshSubMask.put(6,"252.0.0.0");
mhshSubMask.put(7,"254.0.0.0");
mhshSubMask.put(8,"255.0.0.0");
mhshSubMask.put(9,"255.128.0.0");
mhshSubMask.put(10,"255.192.0.0");
mhshSubMask.put(11,"255.224.0.0");
mhshSubMask.put(12,"255.240.0.0");
mhshSubMask.put(13,"255.248.0.0");
mhshSubMask.put(14,"255.252.0.0");
mhshSubMask.put(15,"255.254.0.0");
mhshSubMask.put(16,"255.255.0.0");
mhshSubMask.put(17,"255.255.128.0");
mhshSubMask.put(18,"255.255.192.0");
mhshSubMask.put(19,"255.255.224.0");
mhshSubMask.put(20,"255.255.240.0");
mhshSubMask.put(21,"255.255.248.0");
mhshSubMask.put(22,"255.255.252.0");
mhshSubMask.put(23,"255.255.254.0");
mhshSubMask.put(24,"255.255.255.0");
mhshSubMask.put(25,"255.255.255.128");
mhshSubMask.put(26,"255.255.255.192");
mhshSubMask.put(27,"255.255.255.224");
mhshSubMask.put(28,"255.255.255.240");
mhshSubMask.put(29,"255.255.255.248");
mhshSubMask.put(30,"255.255.255.252");
mhshSubMask.put(31,"255.255.255.254");
mhshSubMask.put(32,"255.255.255.255");

}catch(Exception e)
{
e.printStackTrace();
throw e;
}

return mhshSubMask;

}

public static HashMap<String, String> getSiteIPFromSbc  (Connection conn, HashMap<String, String> sbcNode) throws Exception
{
	log.info("In getSiteIPFromSbc ");
	String query = "SELECT PARAM_VALUE FROM TBL_SBC_RIV_METADATA WHERE PARAM_NAME = ? AND LEVEL_KEY IN (SELECT NWK_NODE_DEVICE_ID FROM TBL_NWK_NODE_DEVICE WHERE DEVICE_TYPE = 'SBC' AND CLLI = ?)";
	PreparedStatement ps1 = null;
	ResultSet res = null;
	HashMap<String, String> nodeIPhashMp = new HashMap<String, String>();
	Iterator<Map.Entry<String, String>> nodeSbcItr = null;
	String siteName = null, sbcClli = null;
	try
	{
		ps1 = conn.prepareStatement(query);
		nodeSbcItr = sbcNode.entrySet().iterator();
		while(nodeSbcItr.hasNext())
		{
			Map.Entry<String, String> entry = nodeSbcItr.next();
			siteName = entry.getValue();
			log.info("siteName " + siteName);
			sbcClli = entry.getKey();
			log.info("sbcClli " + sbcClli);
			ps1.setString(1, siteName);
			ps1.setString(2, sbcClli);
			res = ps1.executeQuery();
			while(res.next())
			{
				log.info("getSiteIPFromSbc resultSet ");
				nodeIPhashMp.put(siteName, res.getString(1));
			}
		}
		
		log.info("nodeIPhashMp " + nodeIPhashMp.size());
		
		
	}catch(Exception e)
	{
		e.printStackTrace();
		throw e;
		
	}finally
	{
		if (null != res)
			res.close();
		if (null != ps1)
			ps1.close();
	}
	return nodeIPhashMp;
}
public static HashMap<String, List<String>> getSbcIPListForSite (Connection conn, ArrayList<String> sbcList, ArrayList<String> NodeList) throws Exception 
{
	
	log.info("In getSbcIPListForSite ");
	String nodeClliQry = "SELECT nnd.CLLI, nws.name FROM tbl_nwk_node_device nnd, tbl_nwk_node nn , tbl_nwk_site nws WHERE nnd.NWK_NODE_ID = nn.nwk_node_id and nws.nwk_site_id = nn.nwk_site_id  and nnd.device_type = 'SBC' and nws.name = ?";
	PreparedStatement pstm = null, ps1 = null;
	ResultSet rset = null, rs1 = null;
	String Sbcip = null,nodeName = null;
	List<String> ipList = null;
	ArrayList<String> sbcArrList = null;
	HashMap<String, List<String>> hshSbcIPMap = new HashMap<String, List<String>> ();
	try
	{
		for(String node : NodeList)
		{
			StringBuffer sbcIPQry = new StringBuffer();
			sbcIPQry.append("SELECT RIVM.PARAM_VALUE, NWS.NAME FROM TBL_SBC_RIV_METADATA RIVM, TBL_NWK_NODE_DEVICE NWND , TBL_NWK_NODE NWN,  TBL_NWK_SITE NWS WHERE RIVM.PARAM_NAME = 'CUST_SIG_BASE_IP'  AND RIVM.LEVEL_KEY = NWND.NWK_NODE_DEVICE_ID AND NWND.NWK_NODE_ID = NWN.NWK_NODE_ID AND NWS.NWK_SITE_ID =  NWN.NWK_SITE_ID AND NWND.CLLI IN (");
			sbcArrList = new ArrayList<String>();
			ipList = new ArrayList<String>();
			ps1 = conn.prepareStatement(nodeClliQry);
			ps1.setString(1, node);
			rs1 = ps1.executeQuery();
			while (rs1.next())
			{
				log.info("In nodeClliQry resultset ");
				sbcArrList.add(rs1.getString(1));
			}
			sbcArrList.retainAll(sbcList);
			for(String sbc : sbcArrList)
			{
				sbcIPQry.append("'").append(sbc).append("',");
			}
			sbcIPQry.replace(sbcIPQry.length()-1, sbcIPQry.length(), ")");
			pstm = conn.prepareStatement(sbcIPQry.toString());
			rset = pstm.executeQuery();
			while(rset.next())
			{
				log.info("In sbcIPQry resultset ");
				Sbcip = rset.getString(1);
				nodeName = rset.getString(2);
				log.info("Sbcip " + Sbcip + "sitename " + nodeName);
				ipList.add(Sbcip);
			}
			
			hshSbcIPMap.put(nodeName, ipList);
		}
		
		log.info("hshSbcIPMap " + hshSbcIPMap.size());
		
	}catch(Exception e)
	{
		e.printStackTrace();
		throw e;
	}finally
	{
		if (null != rs1)
			rs1.close();
		if (null != rset)
			rset.close();
		if (null != ps1)
			ps1.close();
		if (null != pstm)
			pstm.close();
	}
	return hshSbcIPMap;
	
}
public static HashMap<String, String> getsbcSiteMap (Connection conn, ArrayList<String> sbcArrList) throws Exception 
{
	
	log.info("In getsbcSiteMap ");
	String query = "SELECT NWS.NAME , NWND.CLLI  FROM TBL_NWK_NODE NWN, TBL_NWK_NODE_DEVICE NWND, TBL_NWK_SITE NWS WHERE NWN.NWK_NODE_ID = NWND.NWK_NODE_ID AND NWN.NWK_SITE_ID = NWS.NWK_SITE_ID AND NWND.CLLI = ?";
	PreparedStatement ps = null;
	ResultSet res = null;
	HashMap<String, String> sbcSiteMap = new HashMap<String, String>();
	String siteName = null, clli = null;
	try
	{
		for (String sbcClli : sbcArrList)
		{
			ps = conn.prepareStatement(query);
			ps.setString(1, sbcClli);
			res = ps.executeQuery();
			while(res.next())
			{
				log.info("getsbcSiteMap ResultSet ");
				siteName = res.getString(1);
				clli = res.getString(2);
				log.info("siteName "+ siteName + " clli " + clli);
				sbcSiteMap.put(clli, siteName);
			}
		}
		
		log.info("sbcSiteMap "  + sbcSiteMap.size());
	}catch(Exception e)
	{
		e.printStackTrace();
		throw e;
	}finally
	{
		if (null != res)
		res.close();
		if (null != ps)
		ps.close();
	}
	return sbcSiteMap;
}

public static long checkIPSecTunnel (Connection conn, String oldIKEIP, String newIKEIP) throws Exception 
{
	log.info("checkIPSecTunnel old ike ip: "+ oldIKEIP + "new Ike ip: " +newIKEIP );
	String newIKEIPQry  = "SELECT IPSEC_TUNNEL_ID FROM TBL_IPSEC_TUNNEL WHERE IKE_IP  = ? AND TUNNEL_STATUS = 1";
	String gwoldIKEIPQry = null, eoldIKEIPQry = null;
	long liReturn = -999;
	long tunnelId = -1;
	long newTunnelId = -1;	
	int liCount = -1;
	PreparedStatement ps = null;
	PreparedStatement gwPs = null, ebiPs = null;
	ResultSet res = null, gwRs = null, ebiRs = null;
	try
	{
		ps = conn.prepareStatement(newIKEIPQry);
		if (oldIKEIP != null && oldIKEIP.trim().length() >0)
		{
			log.info("oldIKEIP is not null" );
			ps.setString(1, oldIKEIP);
			res = ps.executeQuery();
			while (res.next())
			{
				tunnelId = res.getLong(1);
				log.info("tunnelId "  + tunnelId );
				gwoldIKEIPQry = "SELECT COUNT(*) FROM TBL_GATEWAY_DEVICE_INFO WHERE IPSEC_TUNNEL_ID = ?";
				gwPs = conn.prepareStatement(gwoldIKEIPQry);
				gwPs.setLong(1, tunnelId);
				gwRs = gwPs.executeQuery();
				while(gwRs.next())
				{
					liCount = gwRs.getInt(1);
					log.info("liCount "  + liCount);
					if (liCount >1)
					{
						log.info("tunnel associated with gwy dev "   );
						liReturn = -1;
					}
				}
				 if (liReturn == -1){
					 log.info(" liReturn -1 in oldIKEIP gwy case"   );
					return liReturn;
				} else if (liReturn != -1)
				{
					log.info(" check for tunnel in ebi");
					eoldIKEIPQry = "SELECT COUNT(*) FROM TBL_TSO_EBI WHERE IPSEC_TUNNEL_ID = ?";
					ebiPs = conn.prepareStatement(eoldIKEIPQry);
					ebiPs.setLong(1, tunnelId);
					ebiRs = ebiPs.executeQuery();
					while (ebiRs.next())
					{
						liCount = ebiRs.getInt(1);
						if (liCount >1 )
						{
							log.info(" tunnel associated with ebi"   );
							liReturn = -1;
						}
					}
					if (liReturn == -1)
					{
						log.info(" liReturn -1 in oldIKEIP ebi case "   );
						return liReturn;
					}
						
				}
				
			}
		} if (newIKEIP != null && newIKEIP.trim().length() >0)
		{
			log.info(" check for tunnel with new ike ip "   );
			ps.setString(1, newIKEIP);
			res = ps.executeQuery();
			while (res.next())
			{
				newTunnelId = res.getLong(1);
				log.info("new tunnelId  " + newTunnelId);
			}
			
			if (newTunnelId != -1)
			{
				return newTunnelId;
			} 
		}
		log.info(" old/new ike ip does not exist " + tunnelId);
		liReturn = 0;
		return liReturn;
	}catch(Exception e)
	{
		e.printStackTrace();
		throw e;
	}finally 
	{
		if (res != null)
			res.close();
		if (gwRs != null)
			gwRs.close();
		if (ebiRs != null)
			ebiRs.close();
		if (ps != null)
			ps.close();
		if (gwPs != null)
			gwPs.close();
		if (ebiPs != null)
			ebiPs.close();
	}
	}

	public static String getWildCardMask (Connection dbconn , String sbcIP) throws Exception {
	String wcmaskStr = null;
	PreparedStatement ps = null;
	ResultSet res = null;
	StringBuffer metadataQry = new StringBuffer();
	metadataQry.append("SELECT PARAM_VALUE FROM TBL_SBC_RIV_METADATA WHERE PARAM_NAME = 'SUBNET_WILDCARD_MASK' AND LEVEL_KEY IN (SELECT  LEVEL_KEY FROM TBL_SBC_RIV_METADATA WHERE PARAM_NAME = 'CUST_SIG_BASE_IP' AND PARAM_VALUE = '" + sbcIP +"')");
	try
	{
		ps = dbconn.prepareStatement(metadataQry.toString());
		res = ps.executeQuery();
		while(res.next())
		{
			wcmaskStr = res.getString(1);
			break;
		}
	}
	catch(Exception e)
	{
		e.printStackTrace();
		throw e;
	}finally 
	{
		if (ps != null)
		{
			ps.close();
		}if (res != null)
		{
			res.close();
		}
	}
	return wcmaskStr;
}
	public static String getFirewallInfo(Connection conn, String sbcClli) throws Exception {
		log.info("getFirewallInfo :: SBC :: " + sbcClli);
		String firewallType = null;
		String firewallClusterName = null;
		String firewallStr = null;
		String lsMetadataQry = "SELECT PARAM_NAME, PARAM_VALUE, LEVEL_KEY FROM TBL_SBC_RIV_METADATA WHERE PARAM_NAME IN ('FIREWALL_TYPE', 'FIREWALL_CLUSTER') AND LEVEL_KEY IN (SELECT NWK_NODE_DEVICE_ID FROM TBL_NWK_NODE_DEVICE WHERE DEVICE_TYPE = 'SBC' AND CLLI = ?)";
		PreparedStatement ps1 = null;
		ResultSet rs1 = null;
		
		try
		{
			ps1 = conn.prepareStatement(lsMetadataQry);
			ps1.setString(1, sbcClli);
			rs1 = ps1.executeQuery();
			while(rs1.next()){
					if (rs1.getString(1) != null && rs1.getString(1).equals("FIREWALL_TYPE"))
					{
						firewallType = rs1.getString(2);
					} else if (rs1.getString(1) != null && rs1.getString(1).equals("FIREWALL_CLUSTER"))
					{
						firewallClusterName = rs1.getString(2);
					}
			}
			if (firewallType != null)
				firewallStr = "(Firewall Type: " +firewallType + ", Cluster Name/Netscreen Firewall1: "+firewallClusterName +")";
		}catch(Exception e)
		{
			e.printStackTrace();
			throw e;
			
		}finally {
			if (rs1 != null)
				rs1.close();
			if (ps1 != null)
				ps1.close();
		}
		log.info(" firewallStr ::: " + firewallStr);
		return firewallStr;
	}
     
}

