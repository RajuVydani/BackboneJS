/**
 * 
 */
package com.vz.fxo.inventory.enterprise.helper;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

//import com.vz.esap.api.connector.service.impl.InventoryDomainDataServiceImpl;
import com.vz.esap.api.connector.service.impl.OrderDomainDataServiceImpl;
import com.vz.esap.api.model.FailEntityInfo;

/**
 * 
 * @Author: Deepak Kumar
 * 
 * @Desc : This class is a <b>utility</b> class for
 *       {@link com.vz.esap.bs.service.executor.tn.vzbvoip.rivactionfunction.broadsoft17.VZB_BS_ACTIVATE_TN_SYSTEM_UPDATE}
 *       action function. It provides method to load and manipulate TN records
 *       in bulk . It also provides methods to control the data loading and
 *       processing.
 * 
 * */

@Component
public class FxoInventoryErrorEntityMgmtHelper {

	
	private static Logger log = LoggerFactory
			.getLogger(FxoInventoryErrorEntityMgmtHelper.class.toString());
	
	
	/**
	 * This method returns list of failed TNs for given envOrderId and taskName
	 * 
	 * @param envOrderId
	 * @param entityType
	 * @param inventoryDomainDataService
	 * @param tnActivationResult
	 */
	public List<String> getFailedEntityInfo(String envOrderId, String taskName,
			OrderDomainDataServiceImpl orderDomainDataService) {

		log.info("In BSErrorEntityMgmtHelper.getFailedTNsInfo()");
		List<String> failedTNList = new ArrayList<String>();

		try {

			failedTNList = orderDomainDataService.getFailEntityInfo(envOrderId,
					taskName);

			if (failedTNList != null) {
				log.info("In BSErrorEntityMgmtHelper.getFailedTNsInfo() total failed Entity =>"
						+ failedTNList.size());
			}

		} catch (Exception e) {
			log.error("Exception caught while reading failed TNs from DB:", e);
		}

		return failedTNList;

	}
	/**
	 * This method deletes failed TNs based on envOrderId & list of failed TNs
	 * 
	 * @param envOrderId
	 * @param tn
	 * @param task
	 * @param orderId 
	 * @param inventoryDomainDataService
	 */
	public void deletePassEntityInfo(String envOrderId, String tn, String task,
			OrderDomainDataServiceImpl orderDomainDataService, String orderId) {
		log.trace("In BSErrorEntityMgmtHelper.deletePassEntityInfo()");
		
		try {
			
			FailEntityInfo failEntityInfo = new FailEntityInfo();
			failEntityInfo.setEnvOrderId(envOrderId);
			failEntityInfo.setTaskName(task);
			failEntityInfo.setTn(tn);
			failEntityInfo.setOrderId(orderId);
			
			List<FailEntityInfo> failEntityInfoList = new ArrayList<>();
			failEntityInfoList.add(failEntityInfo);

			orderDomainDataService.clearTnFalloutStatus(failEntityInfoList);
			log.info("In BSErrorEntityMgmtHelper.deletePassEntityInfo() : task :{} is completed for the TN :{} now deleting it from TBL_FAIL_ENTITY_INFO table",task,tn);

		} catch (Exception e) {
			log.error("Exception caught while deleting all failed TNs", e);
		}
	}

	/**
	 * This method deletes all the TNs for an associated envOrderId
	 * 
	 * @param envOrderId
	 * @param task
	 * @param orderId 
	 * @param inventoryDomainDataService
	 */
	public void deletePassedTNsByEnvOrderId(String envOrderId, String task,
			OrderDomainDataServiceImpl orderDomainDataService, String orderId) {

		log.trace("In BSErrorEntityMgmtHelper.deletePassedTNsByEnvOrderId()");
		try {
			FailEntityInfo failEntityInfo = new FailEntityInfo();

			failEntityInfo.setEnvOrderId(envOrderId);
			failEntityInfo.setOrderId(orderId);
			failEntityInfo.setTaskName(task);

			List<FailEntityInfo> failEntityInfoList = new ArrayList<>();
			failEntityInfoList.add(failEntityInfo);
			
			orderDomainDataService.clearTnFalloutStatus(failEntityInfoList);

			log.info(
					"In BSErrorEntityMgmtHelper.deleteFailedTNsOnEnvOrderId() Deleting Tns for the Env Id =>{} and Task ==>{}"
							, envOrderId,task);
		} catch (Exception e) {
			log.error("Exception caught while deleting failed TNs with respect to env order id:", e.getMessage());
		}
	}
	
	
	/**
		 * This method clears set of Tns from fallout
		 * 
		 * @param envOrderId
		 * @param tnList
		 * @param task
		 * @param orderId 
		 * @param workOrderNumber 
		 * @param workOrderVersion 
		 * @param inventoryDomainDataService
		 */
		public void deletePassEntityInfo(String envOrderId, List<String> tnList, String task,
				OrderDomainDataServiceImpl orderDomainDataService, String orderId, String workOrderNumber, String workOrderVersion) {
			log.trace("In BSErrorEntityMgmtHelper.deletePassEntityInfo()");
			
			List<FailEntityInfo> failEntityInfoList = new ArrayList<>();
			try {
				for (String tn : tnList) {
					FailEntityInfo failEntityInfo = new FailEntityInfo();
					failEntityInfo.setEnvOrderId(envOrderId);
					failEntityInfo.setTaskName(task);
					failEntityInfo.setTn(tn);
					failEntityInfo.setOrderId(orderId);
					failEntityInfo.setWorkOrderNumber(workOrderNumber);
					failEntityInfo.setWorkOrderVersion(workOrderVersion);
					failEntityInfoList.add(failEntityInfo);
				}
				orderDomainDataService.clearTnFalloutStatus(failEntityInfoList);
				log.info("In BSErrorEntityMgmtHelper.deletePassEntityInfo() : task :{} is completed for the TN :{} now deleting it from TBL_FAIL_ENTITY_INFO table",task,tnList);

			} catch (Exception e) {
				log.error("Exception caught while deleting all failed TNs", e);
			}
		} 
	 
		/**
		 * This method clear one Tn from fallout 
		 * 
		 * @param envOrderId
		 * @param tn
		 * @param task
		 * @param orderDomainDataService
		 * @param orderId
		 * @param workOrderNumber
		 * @param workOrderVersion
		 */
		public void deletePassEntityInfo(String envOrderId, String tn, String task,
				OrderDomainDataServiceImpl orderDomainDataService, String orderId, String workOrderNumber, String workOrderVersion) {
			log.trace("In BSErrorEntityMgmtHelper.deletePassEntityInfo() WorkOrderNumber {} task :{} tn :{}",workOrderNumber,task,tn);
			ArrayList<String> tnList = new ArrayList<String>();
			tnList.add(tn);
			deletePassEntityInfo(envOrderId,tnList , task, orderDomainDataService, orderId, workOrderNumber, workOrderVersion);
		} 
	
	
}
