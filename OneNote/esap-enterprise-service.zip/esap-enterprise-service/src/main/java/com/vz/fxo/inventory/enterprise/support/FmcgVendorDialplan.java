package com.vz.fxo.inventory.enterprise.support;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import esap.db.DBTblFmcgVendorDialplan;
import esap.db.TblFmcgSubscriberQuery;
import esap.db.TblFmcgVendorDialplanDbBean;
import esap.db.TblFmcgVendorDialplanQuery;
/**
 * 
 * @author z987637
 * 
 */
public class FmcgVendorDialplan extends FmcgVendorDialplanBean
{
	
	private static Logger log = LoggerFactory.getLogger(FmcgVendorDialplan.class
			.toString());


    private Connection connection;
    InvErrorCode status = InvErrorCode.INTERNAL_ERROR;
    boolean rollbackFlag;

    public Connection getConnection()
    {
        return connection;
    }

    public void setConnection(Connection connection)
    {
        this.connection = connection;
    }

    public int getStatusCode()
    {
        return status.getErrorCode();
    }

    public void setStatus(InvErrorCode status)
    {
        this.status = status;
    }

    public String getStatusDesc()
    {
        return status.getErrorDesc();
    }

    public boolean validateSbc()
    {
        return true;
    }

    public FmcgVendorDialplan(Connection con)
    {
        this.connection = con;
        this.rollbackFlag = false;
    }

    /**
     * 
     * @param con
     * @param FmcgVendorDialplanBean
     */
    public FmcgVendorDialplan(Connection con, FmcgVendorDialplanBean fmcgVendorDialplan)
    {
        super(fmcgVendorDialplan);
        this.connection = con;
        this.rollbackFlag = false;
    }

    public boolean addFmcgVendorDialplan() throws SQLException, Exception

    {
        log.info("Entering VendorDialplan::addFmcgVendorDialplan");

//        try
 //       {
            DBTblFmcgVendorDialplan fmcgVendorDialplanDb = new DBTblFmcgVendorDialplan();
           
            if (getFmcgDialPlanId() > 0)
            {
                fmcgVendorDialplanDb.setFmcgDialPlanId(getFmcgDialPlanId());
            } else
            {
                long fmcgVendorDialplanSeqId = fmcgVendorDialplanDb.getFmcgDialPlanIdSeqNextVal(connection);
                fmcgVendorDialplanDb.setFmcgDialPlanId(getFmcgDialPlanId());
            }
            
            fmcgVendorDialplanDb.setFmcgVendorId(getFmcgVendorId());
            fmcgVendorDialplanDb.setFmcgDialPlanName(getFmcgDialPlanName());
            fmcgVendorDialplanDb.setFmcgType(getFmcgType());
            fmcgVendorDialplanDb.setEnterpriseId(getEnterpriseId());
            fmcgVendorDialplanDb.setLocationId(getLocationId());
            fmcgVendorDialplanDb.setGroupId(getGroupId());
            fmcgVendorDialplanDb.setActiveInd(getActiveInd());
            fmcgVendorDialplanDb.setDefaultFlag(getDefaultFlag());
            //fmcgVendorDialplanDb.setEnvOrderId(getEnvOrderId());
            if (!getCreatedBy().equals(""))
                fmcgVendorDialplanDb.setCreatedBy(getCreatedBy());
            else
                fmcgVendorDialplanDb.setCreatedBy("ESAP_INV");

            if (!getModifiedBy().equals(""))
                fmcgVendorDialplanDb.setModifiedBy(getModifiedBy());
            else
                fmcgVendorDialplanDb.setModifiedBy("ESAP_INV");

            fmcgVendorDialplanDb.setCreationDate(new Timestamp(System.currentTimeMillis()));
            fmcgVendorDialplanDb.setLastModifiedDate(new Timestamp(System.currentTimeMillis()));
            fmcgVendorDialplanDb.insert(connection);
        /*}
        catch (SQLException s)
        {
            s.printStackTrace();
            setStatus(InvErrorCode.DB_EXCEPTION);
            return false;
        }
		catch (Exception e)
        {
            e.printStackTrace();
            setStatus(InvErrorCode.ERROR_ADD_FMVG_VENDOR_DIAL_PLAN);
            return false;
        }*/
        setStatus(InvErrorCode.SUCCESS);
        return true;
    }

    public boolean isRollbackFlag()
    {
        return rollbackFlag;
    }

    public void setRollbackFlag(boolean rollbackFlag)
    {
        this.rollbackFlag = rollbackFlag;
    }

    public InvErrorCode getStatus()
    {
        return status;
    }

    public boolean getFmcgVendorDialplanDetailsById()
    {
        log.info("Entering FmcgVendorDialplan::getFmcgVendorDialplanDetailsById");

        try
        {
            TblFmcgVendorDialplanQuery fmcgDialplanQuery = new TblFmcgVendorDialplanQuery();
            log.info("Querying Fmcg Dialplan Details for id: " + getFmcgDialPlanId());
            fmcgDialplanQuery.whereFmcgDialPlanIdEQ(getFmcgDialPlanId());
            fmcgDialplanQuery.query(connection);
            if (fmcgDialplanQuery.size() <= 0)
            {
                log.info("Failed to Retrieve FmcgDialplan");
                return false;
            }

            TblFmcgVendorDialplanDbBean FmcgVendorDialplanBean = fmcgDialplanQuery.getDbBean(0);
            setFmcgVendorId(FmcgVendorDialplanBean.getFmcgVendorId());
            setFmcgDialPlanId(FmcgVendorDialplanBean.getFmcgDialPlanId());
            setFmcgDialPlanName(FmcgVendorDialplanBean.getFmcgDialPlanName());
            setFmcgType(FmcgVendorDialplanBean.getFmcgType());
            setEnterpriseId(FmcgVendorDialplanBean.getEnterpriseId());
            setLocationId(FmcgVendorDialplanBean.getLocationId());
            setGroupId(FmcgVendorDialplanBean.getGroupId());
            setActiveInd(FmcgVendorDialplanBean.getActiveInd());
            setCreatedBy(FmcgVendorDialplanBean.getCreatedBy());
            setCreationDate(FmcgVendorDialplanBean.getCreationDate());
            setModifiedBy(FmcgVendorDialplanBean.getModifiedBy());
            setLastModifiedDate(FmcgVendorDialplanBean.getLastModifiedDate());
            setEnvOrderId(FmcgVendorDialplanBean.getEnvOrderId());
        }
        catch (Exception e)
        {
            e.printStackTrace();
            setStatus(InvErrorCode.ERROR_GETTING_VENDOR_DIAL_PLAN);
            return false;
        }
        setStatus(InvErrorCode.SUCCESS);
        return true;
    }

    /**
     * This method is for fetching Fmcg Vendor for Fmcg Vendor DialPlan
     * 
     * @return
     */
    public boolean getFmcgVendorForFmcgVendorDialPlan()
    {
        try
        {
            //retrieve FmcgSubscriber details to get the FeaturePackageId(FEATURE_PKG_ID)
            boolean ret = getFmcgVendorDialplanDetailsById();
            if (!ret)
            {
                setStatus(InvErrorCode.INV_FAILURE);
                log.info("FAILURE in getFmcgVendorDialplanDetailsById");
                return false;
            }
            log.info("In the Inventry, the FeaturePackage Id for FmcgSubscriber = " + fmcgDialPlanId
                    + " is -> " + fmcgVendorId);
            //if PublicTnPoolId is valid, query the PublicTnPool class for details.
            FmcgVendor fmcgVendorObj = new FmcgVendor(connection);
            fmcgVendorObj.setFmcgVendorId(new Integer(fmcgVendorId).intValue());
            ret = fmcgVendorObj.getFmcgVendorDetailsById();
            if (!ret)
            {
                setStatus(InvErrorCode.INV_FAILURE);
                log.info("FAILURE in getFmcgVendorDetailsById");
                return false;
            }
            setFmcgVendor((FmcgVendorBean) fmcgVendorObj);
        }
        catch (Exception e)
        {
            e.printStackTrace();
            setStatus(InvErrorCode.DB_EXCEPTION);
            log.info("FAILURE in getDetails FmcgVendorDialPlan");
            return false;
        }
        setStatus(InvErrorCode.SUCCESS);
        log.info("Successfully retrieved Fmcg Vendor from the DB");
        return true;
    }

    /**
     * This method is used to delete the Vendor Dial Plan record
     * @return
     */
    public boolean deleteFromDB() throws SQLException, Exception
    {
        //try
        //{
            if (getFmcgDialPlanId() <= 0)
            {
                setStatus(InvErrorCode.INVALID_INPUT);
                return false;
            }
            DBTblFmcgVendorDialplan fmcgVendorDialplanDb = new DBTblFmcgVendorDialplan();
            fmcgVendorDialplanDb.whereFmcgDialPlanIdEQ(fmcgDialPlanId);
            fmcgVendorDialplanDb.deleteByWhere(connection);
        /*}
        catch (SQLException s)
        {
            setStatus(InvErrorCode.DB_EXCEPTION);
            log.info("DB_FAILURE in FmcgVendorDialPlan");
            s.printStackTrace();
            return false;
        }*/
        setStatus(InvErrorCode.SUCCESS);
        //setStatusDesc("Successfully DELETED Fmcg Vendor DialPlan from the DB");
        return true;
    }

   /**
     * This method is for updating the Fmcg Subscriber
     * 
     * @return
     */
    public boolean updateFmcgVendorDialPlan() throws SQLException, Exception
    {
    //    try
     //   {
            if (fmcgDialPlanId < 0)
            {
                setStatus(InvErrorCode.INTERNAL_ERROR);
                log.info("FAILURE in updateFmcgSubscriber fmcgSubId missing.");
                return false;
            }
            DBTblFmcgVendorDialplan fmcgVendorDialplanDb = getFmcgVendorDialplanInfoToUpdate();
            fmcgVendorDialplanDb.whereFmcgDialPlanIdEQ(fmcgDialPlanId);
            if (fmcgVendorDialplanDb.updateSpByWhere(connection) <= 0)
                return false;
        /*}
        catch (SQLException s)
        {
            setStatus(InvErrorCode.DB_EXCEPTION);
            log.info("DB_FAILURE in updateFmcgDevice FmcgDevice");
            s.printStackTrace();
            return false;
        }*/
        setStatus(InvErrorCode.SUCCESS);
        return true;
    }

    /**
     * This method is for getting Fmcg Subscriber for updation
     * 
     * @return
     */
    private DBTblFmcgVendorDialplan getFmcgVendorDialplanInfoToUpdate()
    {
        DBTblFmcgVendorDialplan fmcgVendorDialplanDb = new DBTblFmcgVendorDialplan();
        FmcgVendorDialplanBean defFmcgVendorDialplanBean = new FmcgVendorDialplanBean();
        FmcgVendorDialplan inputFmcgVendorDialPlan = this;
        fmcgVendorDialplanDb.setFmcgDialPlanId(fmcgDialPlanId);

        if (inputFmcgVendorDialPlan.getFmcgDialPlanName() != null
                && !inputFmcgVendorDialPlan.getFmcgDialPlanName()
                        .equals(defFmcgVendorDialplanBean.getFmcgDialPlanName()))
        {
            fmcgVendorDialplanDb.setFmcgDialPlanName(inputFmcgVendorDialPlan.getFmcgDialPlanName());
        }
        if (inputFmcgVendorDialPlan.getFmcgType() != defFmcgVendorDialplanBean.getFmcgType())
        {
            fmcgVendorDialplanDb.setFmcgType(inputFmcgVendorDialPlan.getFmcgType());
        }
        if (inputFmcgVendorDialPlan.getActiveInd() != defFmcgVendorDialplanBean.getActiveInd())
        {
            fmcgVendorDialplanDb.setActiveInd(inputFmcgVendorDialPlan.getActiveInd());
        }
        if (inputFmcgVendorDialPlan.getDefaultFlag() != defFmcgVendorDialplanBean.getDefaultFlag())
        {
            fmcgVendorDialplanDb.setDefaultFlag(inputFmcgVendorDialPlan.getDefaultFlag());
        }

        if (inputFmcgVendorDialPlan.getLocationId() != defFmcgVendorDialplanBean.getLocationId())
        {
            fmcgVendorDialplanDb.setLocationId(inputFmcgVendorDialPlan.getLocationId());
        }
        
        if (inputFmcgVendorDialPlan.getLocationId() != null && !inputFmcgVendorDialPlan.getLocationId()
                .equals(defFmcgVendorDialplanBean.getLocationId()))
            {
                fmcgVendorDialplanDb.setLocationId(inputFmcgVendorDialPlan.getLocationId());
            }
        
        if (inputFmcgVendorDialPlan.getEnvOrderId() != defFmcgVendorDialplanBean.getEnvOrderId())
        {
            fmcgVendorDialplanDb.setEnvOrderId(inputFmcgVendorDialPlan.getEnvOrderId());
        }

        if (inputFmcgVendorDialPlan.getEnterpriseId() != null && !inputFmcgVendorDialPlan.getEnterpriseId()
                        .equals(defFmcgVendorDialplanBean.getEnterpriseId()))
        {
            fmcgVendorDialplanDb.setEnterpriseId(inputFmcgVendorDialPlan.getEnterpriseId());
        }
        
        if (inputFmcgVendorDialPlan.getCreatedBy() != null
                && !("".equalsIgnoreCase(inputFmcgVendorDialPlan.getCreatedBy())))
            fmcgVendorDialplanDb.setCreatedBy(getCreatedBy());
        else
            fmcgVendorDialplanDb.setCreatedBy("ESAP_INV");

        fmcgVendorDialplanDb.setCreationDate(new Timestamp(System.currentTimeMillis()));

        if (inputFmcgVendorDialPlan.getModifiedBy() != null
                && !("".equalsIgnoreCase(inputFmcgVendorDialPlan.getModifiedBy())))
            fmcgVendorDialplanDb.setModifiedBy(getModifiedBy());
        else
            fmcgVendorDialplanDb.setModifiedBy("ESAP_INV");

        fmcgVendorDialplanDb.setLastModifiedDate(new Timestamp(System.currentTimeMillis()));

        return fmcgVendorDialplanDb;

    }

    /**
     * This method is to Add Fmcg Vendor to a Fmcg Vendor DialPlan
     * 
     * @throws SQLException
     *             If any DB Error occurs.
     */
    public boolean updateFmcgVendorToFmcgVendorDialPlan()
    {
        try
        {
            FmcgVendor fmcgVendorObj = new FmcgVendor(connection, fmcgVendor);
            //publicTnPool.setTnPoolId(new Long(getTnPoolId()).intValue());
            if (!fmcgVendorObj.updateFmcgVendor())
            {
                setStatus(InvErrorCode.INTERNAL_ERROR);
                ////setStatusDesc(publicTnPool.getStatusDesc());
                log.info(fmcgVendorObj.getStatusDesc());
                return false;
            }
        }
        catch (Exception e)
        {
            e.printStackTrace();
            setStatus(InvErrorCode.ERROR_DELETING_FMCG_VENDOR_FROM_FMCG_VENDOR_DIAL_PLAN);
            ////setStatusDesc("FAILURE in updateFmcgVendorToFmcgVendorDialPlan.");
            log.info("FAILURE in updateFmcgVendorToFmcgVendorDialPlan.");
            return false;
        }
        setStatus(InvErrorCode.SUCCESS);
        return true;
    }
    

    /**
     * This method is used to fetch the Vendor Dial Plan details by the 
     * combination of following input fields
     * @param enterpriseId
     * @param locationId
     * @param GroupId
     * @param vendorId
     * @return
     */
   
    public List<FmcgVendorDialplanBean> getDetails(String enterpriseId,String locationId)
    {
         
        log.info("Entering FmcgVendorDialplan::getDetails");
        List<FmcgVendorDialplanBean> resList = new ArrayList<FmcgVendorDialplanBean>();

        try
        {           
            TblFmcgVendorDialplanQuery fmcgDialplanQuery = new TblFmcgVendorDialplanQuery();
           
            log.info("enterpriseIdils id: " + enterpriseId);
            log.info("locationId : " + locationId);
           	
			String whereCls = " where 1=1 "; 
            if(enterpriseId != null && !("".equals(enterpriseId))){
				whereCls = whereCls + " and enterprise_id in (\'" + enterpriseId + "\', \'*\') ";
            }
            if(locationId != null && !("".equals(locationId))){
				whereCls = whereCls + " and location_id in (\'" + locationId + "\', \'*\') ";
            }
           	log.info("Where Clause = " + whereCls); 

			fmcgDialplanQuery.queryByWhere(connection, whereCls);
     
           	log.info("Retrieved [" + fmcgDialplanQuery.size() + "] Dial plans");
            if (fmcgDialplanQuery.size() <= 0)
            {
                log.info("Failed to Retrieve FmcgDialplan");
                return resList;
            }
			
			for (int i=0; i < fmcgDialplanQuery.size(); i++)
			{
				TblFmcgVendorDialplanDbBean FmcgVendorDialplanBean = fmcgDialplanQuery.getDbBean(i);
				FmcgVendorDialplanBean vdialp = new FmcgVendorDialplanBean();
					vdialp.setFmcgVendorId(FmcgVendorDialplanBean.getFmcgVendorId());
				vdialp.setFmcgDialPlanId(FmcgVendorDialplanBean.getFmcgDialPlanId());
				vdialp.setFmcgDialPlanName(FmcgVendorDialplanBean.getFmcgDialPlanName());
				vdialp.setFmcgType(FmcgVendorDialplanBean.getFmcgType());
				vdialp.setEnterpriseId(FmcgVendorDialplanBean.getEnterpriseId());
				vdialp.setLocationId(FmcgVendorDialplanBean.getLocationId());
				vdialp.setGroupId(FmcgVendorDialplanBean.getGroupId());
				vdialp.setActiveInd(FmcgVendorDialplanBean.getActiveInd());
				vdialp.setCreatedBy(FmcgVendorDialplanBean.getCreatedBy());
				vdialp.setCreationDate(FmcgVendorDialplanBean.getCreationDate());
				vdialp.setModifiedBy(FmcgVendorDialplanBean.getModifiedBy());
				vdialp.setLastModifiedDate(FmcgVendorDialplanBean.getLastModifiedDate());
				// setEnvOrderId(FmcgVendorDialplanBean.getEnvOrderId());
				FmcgVendor fvendor = new FmcgVendor(connection);
				fvendor.setFmcgVendorId(FmcgVendorDialplanBean.getFmcgVendorId());
				if(fvendor.getFmcgVendorDetailsById() != true)
					log.info("Failed to Retrieved FMCG Vendor");
				else
					vdialp.setFmcgVendor(fvendor);
				resList.add(vdialp);	
			}
        }
        catch (Exception e)
        {
            e.printStackTrace();
            setStatus(InvErrorCode.DB_EXCEPTION);
            return resList;
        }
        setStatus(InvErrorCode.SUCCESS);
        return resList;
    }
    
    
    public boolean deleteFMCGDialPlan() throws SQLException, Exception
    {
        //try
        //{
            if (getFmcgDialPlanId() <= 0)
            {
                setStatus(InvErrorCode.INVALID_INPUT);
                return false;
            }
            
            TblFmcgSubscriberQuery fmcgSubscriberQuery = new TblFmcgSubscriberQuery();
            fmcgSubscriberQuery.whereFmcgDialPlanIdEQ(getFmcgDialPlanId());
            fmcgSubscriberQuery.query(connection);

            if(fmcgSubscriberQuery.size() >0)
            {
            	log.info("This calling plan is being used by FmcgSubscriber -tbl_fmcg_subscriber");
        		return false;
            }
      
            return deleteFromDB();
         /*}
        catch (SQLException s)
        {
            setStatus(InvErrorCode.DB_EXCEPTION);
            log.info("DB_FAILURE in deleteFmcgDevice");
            s.printStackTrace();
            return false;
        }*/

    }
}
