/**
 * 
 */
package com.vz.fxo.inventory.enterprise.support;

/**
 * @author Vijaykumar Sriperambuduri(v034934)
 *
 */
public class EnterpriseAdminBean {
	protected String enterpriseId;
	protected long adminType;
	protected String adminFirstName;
	protected String adminLastName;
	protected String adminWebLoginId;
	protected String adminEmail;
	protected long regionId;
	protected long webLang;
	protected String password;
	
	/**
	 * 
	 *Default Constructor -- Initializes all fields to default values.
	 */
    public EnterpriseAdminBean() {
    	this.adminFirstName = new String("");
		this.adminLastName = new String("");
		this.adminWebLoginId = new String("");
		this.adminEmail = new String("");
		this.adminType = 0;
        this.enterpriseId = new String("");
        this.regionId = 0;
        this.password = new String("");
        this.webLang = 0;
    }
    public String toString() {
		return ("" + "enterpriseId=" + enterpriseId + "\n" + "adminType="
				+ adminType + "\n" + "adminFirstName=" + adminFirstName + "\n"
				+ "adminLastName=" + adminLastName + "\n" + "adminWebLoginId="
				+ adminWebLoginId + "\n" + "adminEmail=" + adminEmail + "\n" 
				+ "regionId=" + regionId + "\n" + "webLang=" + webLang + "\n" 
				+ "password=" + password + "\n");
	}
    /**
     * Constructor
     * @param enterpriseAdminBean
     */
	public EnterpriseAdminBean(EnterpriseAdminBean enterpriseAdminBean) {
		this.enterpriseId = enterpriseAdminBean.enterpriseId;
		this.adminType = enterpriseAdminBean.adminType;
		this.adminFirstName = enterpriseAdminBean.adminFirstName;
		this.adminLastName = enterpriseAdminBean.adminLastName;
		this.adminWebLoginId = enterpriseAdminBean.adminWebLoginId;
		this.adminEmail = enterpriseAdminBean.adminEmail;
		this.regionId = enterpriseAdminBean.regionId;
		this.webLang = enterpriseAdminBean.webLang;
		this.password = enterpriseAdminBean.password;
	}
	public String getAdminEmail() {
		return adminEmail;
	}
	public void setAdminEmail(String adminEmail) {
		this.adminEmail = adminEmail;
	}
	public String getAdminFirstName() {
		return adminFirstName;
	}
	public void setAdminFirstName(String adminFirstName) {
		this.adminFirstName = adminFirstName;
	}
	public String getAdminLastName() {
		return adminLastName;
	}
	public void setAdminLastName(String adminLastName) {
		this.adminLastName = adminLastName;
	}
	public long getAdminType() {
		return adminType;
	}
	public void setAdminType(long adminType) {
		this.adminType = adminType;
	}
	public String getAdminWebLoginId() {
		return adminWebLoginId;
	}
	public void setAdminWebLoginId(String adminWebLoginId) {
		this.adminWebLoginId = adminWebLoginId;
	}
	public String getEnterpriseId() {
		return enterpriseId;
	}
	public void setEnterpriseId(String enterpriseId) {
		this.enterpriseId = enterpriseId;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public long getRegionId() {
		return regionId;
	}
	public void setRegionId(long regionId) {
		this.regionId = regionId;
	}
	public long getWebLang() {
		return webLang;
	}
	public void setWebLang(long webLang) {
		this.webLang = webLang;
	}

}
