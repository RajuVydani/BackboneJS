/****************************************
This Class will have all methods related to Key group
Author : Pallavi Vankayalapati
 ****************************************/
package com.vz.fxo.inventory.enterprise.support;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Timestamp;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import esap.db.DBTblGatewayDeviceInfo;
import esap.db.DBTblGroupTn;
import esap.db.DBTblGroupTnExcldFeatures;
import esap.db.DBTblSipDeviceInfo;
import esap.db.DBTblVzbFeatures;
import esap.db.TblDeviceMapDbBean;
import esap.db.TblDeviceMapQuery;
import esap.db.TblGroupQuery;
import esap.db.TblGroupTnExcldFeaturesQuery;
import esap.db.TblGroupTnQuery;
import esap.db.TblVzbFeaturesQuery;
import EsapEnumPkg.VzbVoipEnum;

public class KeyGroupTn extends KeyGroupTnBean
{
    String statusCode;
    String statusDesc;
    Connection dbCon;
    boolean rollbackFlag;
	boolean removeTnFlag;
	private  boolean isExistingTn;
    InvErrorCode errstatus = InvErrorCode.INTERNAL_ERROR;

    private static Logger log = LoggerFactory.getLogger(KeyGroupTn.class.getSimpleName());


    public KeyGroupTn(Connection dbCon)
    {
        this.dbCon = dbCon;
        this.rollbackFlag = false;
		this.removeTnFlag = false;
		this.isExistingTn = false;
    }

    public KeyGroupTn(KeyGroupTnBean keyTnBean, Connection dbCon)
    {
        super(keyTnBean);
        this.dbCon = dbCon;
        this.rollbackFlag = false;
		this.removeTnFlag = false;
		this.isExistingTn = false;
    }

    public boolean getRollbackFlag()
    {
        return rollbackFlag;
    }

    public void setRollbackFlag(boolean rollbackFlag)
    {
        this.rollbackFlag = rollbackFlag;
    }

	public boolean getRemoveTnFlag() {
        return removeTnFlag;
    }

    public void setRemoveTnFlag(boolean removeTnFlag) {
        this.removeTnFlag = removeTnFlag;
    }

	public boolean getIsExistingTn()
        {
            return isExistingTn;
        }

        public void setIsExistingTn(boolean isExistingTn)
        {
            this.isExistingTn = isExistingTn;
        }


    public boolean setDeletePending() throws SQLException
    {
        if (groupTnId <= 0)
        {
            setErrstatus(InvErrorCode.INVALID_INPUT);
            return false;
        }
        DBTblGroupTn grpTnDB = new DBTblGroupTn();
        grpTnDB.whereGroupTnIdEQ(groupTnId);
        grpTnDB.setActiveInd(VzbVoipEnum.ActiveInd.DELETE_PENDING);
        //grpTnDB.updateSpByWhere(dbCon);
        if (grpTnDB.updateSpByWhere(dbCon) <= 0)
            return false;
        return true;
    }

    public int getStatusCode()
    {
        return errstatus.getErrorCode();
    }

    public void setErrstatus(InvErrorCode status)
    {
        this.errstatus = status;
    }

    public String getStatusDesc()
    {
        return errstatus.getErrorDesc();
    }

    public Connection getDbCon()
    {
        return dbCon;
    }

    public void setDbCon(Connection dbCon)
    {
        this.dbCon = dbCon;
    }

    //methods
    public boolean addToDB() throws SQLException, Exception
    {
        //try
        //{
            DBTblGroupTn grpTnDB = new DBTblGroupTn();
            if (getGroupTnId() > 0)
                grpTnDB.setGroupTnId(getGroupTnId());
            else
            {
                int grpTnId = grpTnDB.getGroupTnIdSeqNextVal(dbCon);
                setGroupTnId(grpTnId);
            }
		

			if (!"".equals(getIcpSubId()) && !"NONE".equals(getIcpSubId())) {
				grpTnDB.setIcpSubId(getIcpSubId());
			}
			else{
				grpTnDB.setIcpSubId("GRP"+getGroupTnId());
			}
            grpTnDB.setGroupId(getGroupId());
            grpTnDB.setSequenceNo(getSequenceNo());
            
            log.info("Extension = <" + getExtension() + ">");
            
            if(!"NONE".equals(getExtension())){
            grpTnDB.setExtension(getExtension());
            }
            
            
            //grpTnDB.setActiveInd(getActiveInd()); 
            if (getTnPoolId() > 0)
                grpTnDB.setTnPoolId(getTnPoolId());
            else if (!addToPublicTnPool())
            {
                setErrstatus(InvErrorCode.DB_EXCEPTION);
                //setStatusDesc("INV_FAILURE in addToDB KeyGroupTn.Failed to ADD Public Tn Pool");
                log.info("INV_FAILURE in addToDB KeyGroupTn.Failed to ADD Public Tn Pool");
                return false;
            }
            grpTnDB.setTnPoolId(getTnPoolId());
            log.info("TnPoolId = " + getTnPoolId());
            
            if(!"NONE".equals(getPrivateNumber())){
            grpTnDB.setPrivateNumber(getPrivateNumber());
            }
            
            if(!"NONE".equals(getLinePort())){
            grpTnDB.setLinePort(getLinePort());
            }
            
            if(!"NONE".equals(getCidFirstName())){ 
            grpTnDB.setCidFirstName(getCidFirstName());
            }
            
            if(!"NONE".equals(getCidLastName())){ 
            grpTnDB.setCidLastName(getCidLastName());
            }
            
            int vmxSize = (int) getKeyVmMaxsize();
            if (vmxSize < 0)
                grpTnDB.setVmMaxsizeIdNull();
            else
                grpTnDB.setVmMaxsizeId(vmxSize);
            //grpTnDB.setVmMaxsizeId(getKeyVmMaxsizeId());
            
            if(!"NONE".equals(getKeyVmBoxNum())){ 
            grpTnDB.setVmBoxNum(getKeyVmBoxNum());
            }
            
            grpTnDB.setActiveInd(getActiveInd());
            if (getCreatedBy() != null && !getCreatedBy().equals(""))
                grpTnDB.setCreatedBy(getCreatedBy());
            else
                grpTnDB.setCreatedBy("ESAP_INV");
            if (getModifiedBy() != null && !getModifiedBy().equals(""))
                grpTnDB.setModifiedBy(getModifiedBy());
            else
                grpTnDB.setModifiedBy("ESAP_INV");
            grpTnDB.setLastModifiedDate(new Timestamp(System.currentTimeMillis()));
            grpTnDB.setCreationDate(new Timestamp(System.currentTimeMillis()));
            if (getEnvOrderId() > 0)
                grpTnDB.setEnvOrderId(getEnvOrderId());
            else
                grpTnDB.setEnvOrderIdNull();

            //Added as new column introduced in the table fmcg_sub_id
			if (getSubId() != null &&  !"NONE".equals(getSubId()))
                grpTnDB.setSubId(getSubId());
            
		/*	if (getSubId() != null)
                grpTnDB.setSubId(getSubId());
            else
                grpTnDB.setSubIdNull(); */

            grpTnDB.insert(dbCon);
            for (int k = 0; k < excludedFeaturesList.size(); k++)
            {
                TblVzbFeaturesQuery vzbFeatQry = new TblVzbFeaturesQuery();
                vzbFeatQry.whereNameEQ(((excludedFeaturesList.get(k)).getFeaturesDbBean()).getName());
                vzbFeatQry.whereFeatureTypeNE("C");
                vzbFeatQry.query(dbCon);
                if (vzbFeatQry.size() == 1)
                {
                    DBTblGroupTnExcldFeatures grpExcldFeat = new DBTblGroupTnExcldFeatures();
                    grpExcldFeat.getGroupTnFeatureIdSeqNextVal(dbCon);
                    grpExcldFeat.setGroupTnId(grpTnDB.getGroupTnId());
                    grpExcldFeat.setFeatureId((vzbFeatQry.getDbBean(0)).getFeatureId());
                    if (getCreatedBy() != null && !getCreatedBy().equals(""))
                        grpExcldFeat.setCreatedBy(getCreatedBy());
                    else
                        grpExcldFeat.setCreatedBy("ESAP_INV");
                    if (getModifiedBy() != null && !getModifiedBy().equals(""))
                        grpExcldFeat.setModifiedBy(getModifiedBy());
                    else
                        grpExcldFeat.setModifiedBy("ESAP_INV");
                    grpExcldFeat.setLastModifiedDate(new Timestamp(System.currentTimeMillis()));
                    grpExcldFeat.setCreationDate(new Timestamp(System.currentTimeMillis()));
                    if (getEnvOrderId() > 0)
                        grpExcldFeat.setEnvOrderId(getEnvOrderId());
                    else
                        grpExcldFeat.setEnvOrderIdNull();
                    grpExcldFeat.insert(dbCon);
                } else
                {
                    log.info("Valid Excluded feature not found in the db"
                            + ((excludedFeaturesList.get(k)).getFeaturesDbBean()).getName());
                    return false;
                }
            }
            //incrementORdecrementPortsAssigned("Y");
        /*}
        catch (SQLException s)
        {
            s.printStackTrace();
            setErrstatus(InvErrorCode.DB_EXCEPTION);
            //setStatusDesc("DB_FAILURE in addToDB KeyGroupTn");
            log.info("DB_FAILURE in addToDB KeyGroupTn");
            return false;
        }*/
        setErrstatus(InvErrorCode.SUCCESS);
        //setStatusDesc("Successfully inserted KeyGroupTn into the DB");
        return true;
    }

    
	public void incrementORdecrementPortsAssigned(String incrDecr) throws SQLException, Exception {
		
		if(incrDecr != null && (incrDecr.equalsIgnoreCase("Y") || incrDecr.equalsIgnoreCase("N"))) {
        TblGroupQuery grpQry = new TblGroupQuery();
        grpQry.whereGroupIdEQ(getGroupId());
        grpQry.query(dbCon);
        if(grpQry.size() >0 ) {  
		   int deviceMapId =  (int) (grpQry.getDbBean(0)).getDeviceMapId();
		
		TblDeviceMapQuery deviceMapqry = new TblDeviceMapQuery();
		deviceMapqry.whereDeviceMapIdEQ(deviceMapId);
		deviceMapqry.query(dbCon);
		if(deviceMapqry.size() > 0) {
			TblDeviceMapDbBean deviceMapbean = deviceMapqry.getDbBean(0);
			if(deviceMapbean.getSipDeviceId() >0) {
				SipDevice sipDev = new SipDevice(dbCon);
				sipDev.setSipDeviceId((int)deviceMapbean.getSipDeviceId());
				if(sipDev.getDetails())
				{
	    			DBTblSipDeviceInfo sipDevObj = new DBTblSipDeviceInfo();
					sipDevObj.whereSipDeviceIdEQ(sipDev.getSipDeviceId());	
					int updatedCount = 0;
				if(incrDecr.equalsIgnoreCase("Y"))	{
					//incremetn Value
					if(sipDev.getPortsAssigned() >0){
						sipDevObj.setPortsAssigned(sipDev.getPortsAssigned() +  1);	
					} else {
						sipDevObj.setPortsAssigned(1);
					}
				} else if (incrDecr.equalsIgnoreCase("N")) {
					//decement value
					if(sipDev.getPortsAssigned() >0){
						sipDevObj.setPortsAssigned(sipDev.getPortsAssigned() -  1);	
					} else {
						sipDevObj.setPortsAssignedNull();
					}
				}

					FkValidationUtil.isValidSipDeviceInfoForMod(dbCon,sipDevObj);
					updatedCount = sipDevObj.updateSpByWhere(dbCon);
					
					
				}
				
			} else if(deviceMapbean.getGatewayDeviceId()>0){
				GatewayDevice gwDev = new GatewayDevice(dbCon);
	            gwDev.setGatewayDeviceId(deviceMapbean.getGatewayDeviceId());
	            if(gwDev.getDetails())
	            {
	            		DBTblGatewayDeviceInfo gwDevObj = new DBTblGatewayDeviceInfo();
	                    gwDevObj.whereGatewayDeviceIdEQ(gwDev.getGatewayDeviceId());
	                    int updatedCount = 0;
	                	if(incrDecr.equalsIgnoreCase("Y"))	{  
	                		//increment
    						if(gwDev.getPortsAssigned() >0){
    							gwDevObj.setPortsAssigned(gwDev.getPortsAssigned() +  1);	
    						} else {
    							gwDevObj.setPortsAssigned(1);
    						}  
	                	} else if (incrDecr.equalsIgnoreCase("N")) {
	                		//decrement
							if(gwDev.getPortsAssigned() >0){
								gwDevObj.setPortsAssigned(gwDev.getPortsAssigned() -  1);	
							} else {
								gwDevObj.setPortsAssignedNull();
							}    
	                	}
						  updatedCount = gwDevObj.updateSpByWhere(dbCon);	
	                

	            }
				
			}
		}
      }	
    }		
 }
	 
    public boolean addToPublicTnPool() throws SQLException, Exception
    {
        log.info("Entering KeyGroupTn::addToPublicTnPool");
        if (getPublicTnPoolObj().getTnPoolId() > 0)
        {
            log.info("TnPool Id found. Skip Tn Pool Insert");
            setTnPoolId(getPublicTnPoolObj().getTnPoolId());
            return true;
        }
        if (getPublicTnPoolObj().getTn().equals(""))
        {
            log.info("No Public Tn Found.");
            return false;
        }
        PublicTnPool pubTnObj = new PublicTnPool(dbCon, getPublicTnPoolObj());
        
        //APAC LNP sep 2011
        try
        {
        	PublicTnPool pubTnObjToGetPorting = (PublicTnPool) getPublicTnPoolObj();
        	pubTnObj.setTnPorting(pubTnObjToGetPorting.getTnPorting());
        	log.info("KeyGroupTn::addToPublicTnPool() : tn porting object is set");
        }
        catch(ClassCastException cce)
        {
        	log.info("Exception while casting PublicTnPoolBean into PublicTnPool.");
        	throw cce;
        }
        
        if (!pubTnObj.addPublicTnPool())
        {
            log.info("Failed to Add Tn to Public Tn Pool");
            return false;
        }
        setTnPoolId(pubTnObj.getTnPoolId());
        log.info("TnPoolId = " + pubTnObj.getTnPoolId());
        log.info("Successfully inserted Public TN Pool");
        return true;
    }

    public boolean deleteFromDB() throws Exception,SQLException
    {
        /*try
        {*/
            if (groupTnId <= 0)
            {
                setErrstatus(InvErrorCode.INVALID_INPUT);
                log.info("FAILURE in deleteFromDB KeyGroupTn. groupTnId missing.");
                return false;
            }
            deleteExcludedFeaturesForGroupTn();
            log.info("deleteExcludedFeaturesForGroupTn completed");
            TblGroupTnQuery grpTnQuery = new TblGroupTnQuery();
            grpTnQuery.whereGroupTnIdEQ(getGroupTnId());
            grpTnQuery.query(dbCon);
			if(grpTnQuery.size() > 0)
			{
		            int tnPoolId = (int) grpTnQuery.getDbBean(0).getTnPoolId();
		            setGroupId((int)grpTnQuery.getDbBean(0).getGroupId());
		            //incrementORdecrementPortsAssigned("N");
		            DBTblGroupTn keyGroupTnDbBean = new DBTblGroupTn();
		            keyGroupTnDbBean.whereGroupTnIdEQ(getGroupTnId());
		            int retValue = keyGroupTnDbBean.deleteByWhere(dbCon);
		            if (retValue <= 0)
		            {
		                setErrstatus(InvErrorCode.ERROR_DELETING_KEY_GROUP_TN);
		                log.info("Error while deleting KeyGroupTn.");
		                return false;
		            }
		            log.info("keyGroupTnDbBean.deleteByWhere completed  for <" + getGroupTnId() + ">");
		            log.info("keyGroupTnDbBean.deleteByWhere has  returned <" + retValue + ">");
		            PublicTnPool publicTnPool = new PublicTnPool(dbCon);
		            publicTnPool.setTnPoolId(tnPoolId);
					publicTnPool.setEnvOrderId(getEnvOrderId());
		          	publicTnPool.setModifiedBy(getModifiedBy());
		            publicTnPool.setLastModifiedDate(new Timestamp(System.currentTimeMillis()));
					log.info("removeTnFlag===>" + removeTnFlag);
		            if ((rollbackFlag && !isExistingTn) || removeTnFlag)
		            {
		                if (!publicTnPool.deletePublicTnPool())
		                {
		                    setErrstatus(InvErrorCode.ERROR_DELETING_PUBLIC_TN_POOL_KEY_GROUP_TN);
		                    log.info("Error while deleting Public tn pool from KeyGroupTn.");
		                    return false;
		                }
		            } else
		            {
		                publicTnPool.setTnStatus(VzbVoipEnum.TnStatus.AVAILABLE);
		                publicTnPool.setActiveInd(VzbVoipEnum.ActiveInd.ACTIVE);
		                if (!publicTnPool.updatePublicTnPool())
		                {
		                    setErrstatus(InvErrorCode.ERROR_MODIFYING_PUBLIC_TN_POOL_KEY_GROUP_TN);
		                    log.info("Error while modifying Public tn pool from KeyGroupTn.");
		                    return false;
		                }
		            }
		            log.info("deletePublicTnPoolForGroupTn  completed");
			}
			else
				log.info("GroupTNId [" + getGroupTnId() +"] not Found");
        /*}
        catch (SQLException s)
        {
            s.printStackTrace();
            setErrstatus(InvErrorCode.DB_EXCEPTION);
            log.info("DB_FAILURE in deleteFromDB KeyGroup");
            return false;
        } catch (Exception ee) {
            ee.printStackTrace();
            setErrstatus(InvErrorCode.DB_EXCEPTION);
            log.info("DB_FAILURE in deleteFromDB KeyGroup");
            return false;
        }*/
        setErrstatus(InvErrorCode.SUCCESS);
        return true;
    }

    public boolean deleteFromDBExceptPNP() throws Exception,SQLException
    {
        /*try
        {*/
            if (groupTnId <= 0)
            {
                setErrstatus(InvErrorCode.INVALID_INPUT);
                log.info("FAILURE in deleteFromDB KeyGroupTn. groupTnId missing.");
                return false;
            }
            deleteExcludedFeaturesForGroupTn();
            log.info("deleteExcludedFeaturesForGroupTn completed");
            TblGroupTnQuery grpTnQuery = new TblGroupTnQuery();
            grpTnQuery.whereGroupTnIdEQ(getGroupTnId());
            grpTnQuery.query(dbCon);
			if(grpTnQuery.size() > 0)
			{
		            int tnPoolId = (int) grpTnQuery.getDbBean(0).getTnPoolId();
		            setGroupId((int)grpTnQuery.getDbBean(0).getGroupId());
		            DBTblGroupTn keyGroupTnDbBean = new DBTblGroupTn();
		            keyGroupTnDbBean.whereGroupTnIdEQ(getGroupTnId());
		            int retValue = keyGroupTnDbBean.deleteByWhere(dbCon);
		            if (retValue <= 0)
		            {
		                setErrstatus(InvErrorCode.ERROR_DELETING_KEY_GROUP_TN);
		                log.info("Error while deleting KeyGroupTn.");
		                return false;
		            }
		            log.info("keyGroupTnDbBean.deleteByWhere completed  for <" + getGroupTnId() + ">");
		            log.info("keyGroupTnDbBean.deleteByWhere has  returned <" + retValue + ">");
		            PublicTnPool publicTnPool = new PublicTnPool(dbCon);
		            publicTnPool.setTnPoolId(tnPoolId);
					publicTnPool.setEnvOrderId(getEnvOrderId());
		          	publicTnPool.setModifiedBy(getModifiedBy());
		            publicTnPool.setLastModifiedDate(new Timestamp(System.currentTimeMillis()));
					log.info("removeTnFlag===>" + removeTnFlag);
		            if ((rollbackFlag && !isExistingTn) || removeTnFlag)
		            {
		            	/**
						 * Commenting below PublicTnPool delete code to handle it in System Update
						 */
		               /* if (!publicTnPool.deletePublicTnPool())
		                {
		                    setErrstatus(InvErrorCode.ERROR_DELETING_PUBLIC_TN_POOL_KEY_GROUP_TN);
		                    log.info("Error while deleting Public tn pool from KeyGroupTn.");
		                    return false;
		                }*/
		                /**
						 * Commenting above PublicTnPool delete code to handle it in System Update
						 */
		            } else
		            {
		                publicTnPool.setTnStatus(VzbVoipEnum.TnStatus.AVAILABLE);
		                publicTnPool.setActiveInd(VzbVoipEnum.ActiveInd.ACTIVE);
		                if (!publicTnPool.updatePublicTnPool())
		                {
		                    setErrstatus(InvErrorCode.ERROR_MODIFYING_PUBLIC_TN_POOL_KEY_GROUP_TN);
		                    log.info("Error while modifying Public tn pool from KeyGroupTn.");
		                    return false;
		                }
		            }
		            log.info("deletePublicTnPoolForGroupTn  completed");
			}
			else
				log.info("GroupTNId [" + getGroupTnId() +"] not Found");
        
        setErrstatus(InvErrorCode.SUCCESS);
        return true;
    }
    
    public boolean deletePublicTnPoolForGroupTn() throws SQLException, Exception
    {
        TblGroupTnQuery grpTnQuery = new TblGroupTnQuery();
        grpTnQuery.whereGroupTnIdEQ(getGroupTnId());
        grpTnQuery.query(dbCon);
        PublicTnPool publicTnPool = new PublicTnPool(dbCon);
        for (int i = 0; i < grpTnQuery.size(); i++)
        {
            publicTnPool.setTnPoolId((int) grpTnQuery.getDbBean(i).getTnPoolId());
            if (rollbackFlag)
            {
                if (!publicTnPool.deletePublicTnPool())
                {
                    setErrstatus(InvErrorCode.ERROR_DELETING_PUBLIC_TN_POOL_KEY_GROUP_TN);
                    log.info("Error while deleting Public tn pool from KeyGroupTn.");
                    return false;
                }
            } else
            {
                publicTnPool.setTnStatus(VzbVoipEnum.TnStatus.AVAILABLE);
                if (!publicTnPool.updatePublicTnPool())
                {
                    setErrstatus(InvErrorCode.ERROR_MODIFYING_PUBLIC_TN_POOL_KEY_GROUP_TN);
                    log.info("Error while modifying Public tn pool from KeyGroupTn.");
                    return false;
                }
            }
        }
        return true;
    }

    public boolean deleteExcludedFeaturesForGroupTn() throws SQLException
    {
        TblGroupTnExcldFeaturesQuery excTnFeaturesQuery = new TblGroupTnExcldFeaturesQuery();
        excTnFeaturesQuery.whereGroupTnIdEQ(getGroupTnId());
        excTnFeaturesQuery.query(dbCon);
        DBTblGroupTnExcldFeatures excTnFeaturesDbBean = new DBTblGroupTnExcldFeatures();
        excTnFeaturesDbBean.whereGroupTnIdEQ(getGroupTnId());
        if (excTnFeaturesDbBean.deleteByWhere(dbCon) <= 0)
        {
            setErrstatus(InvErrorCode.ERROR_DELETING_EXCLUDE_FEATURES_FROM_KEY_GROUP);
            log.info("Error while deleting Exclude Featrues from KeyGroup.");
            return false;
        }
        return true;
    }

    /**
     * The method to modify the KeyGroupTn record.
     * 
     * Group Tn Id should be set before calling this method.
     * 
     * @return true Record has been updated SUCCESSFULLY false Group Id missing / Record update
     *         Unsuccessful / Some Error occured.
     */

	
    public boolean modifyInDB() throws SQLException, Exception
    {
        try
        {
            if (getGroupTnId() <= 0)
            {
                setErrstatus(InvErrorCode.INVALID_INPUT);
                log.info("FAILURE in modifyInDB KeyGroupTn. Invalid GroupTnId. ");
                return false;
            }
            
            log.info("Inside modifyInDB");
            DBTblGroupTn groupTnBean = getKeyGroupTnToUpdate();
            groupTnBean.whereGroupTnIdEQ(getGroupTnId());
            if (groupTnBean.updateSpByWhere(dbCon) <= 0){
            	if (getTnPoolId() > 0) {
					//log.info("DEBRAJ Inside modifyInDB @@@@@");
					DBTblGroupTn groupTnBea = getKeyGroupTnToUpdate();
					groupTnBea.whereTnPoolIdEQ(getTnPoolId());
					if (groupTnBea.updateSpByWhere(dbCon) <= 0) {
						setErrstatus(InvErrorCode.ERROR_MODIFYING_KEY_GROUP_TN);
						log.info("Error while modifying KEYGroupTn.");
						return false;
					}
				}  else if (getTn() != null && getTn().length() > 0) {
					DBTblGroupTn groupTnBea = getKeyGroupTnToUpdate();
					PublicTnPool pnpObj = new PublicTnPool(dbCon);
					long tnPId = pnpObj.getTnPoolIdByTn(getTn());
					groupTnBea.whereTnPoolIdEQ(tnPId);
					if (groupTnBea.updateSpByWhere(dbCon) <= 0) {
						setErrstatus(InvErrorCode.ERROR_MODIFYING_KEY_GROUP_TN);
						log.info("Error while modifying KEYGroupTn.");
						return false;
					}
				}else {
					setErrstatus(InvErrorCode.ERROR_MODIFYING_KEY_GROUP_TN);
					log.info("Error while modifying KEYGroupTn.");
					return false;
				}
            }

        }
        catch (SQLException s)
        {
            s.printStackTrace();
            setErrstatus(InvErrorCode.DB_EXCEPTION);
            log.info("DB_FAILURE in modifyInDB KeyGroup.");
            return false;
        }
        setErrstatus(InvErrorCode.SUCCESS);
        return true;
    }

    



    /**
     * The current Key Group TN details are extracted using getDetails() and the new field values
     * are updated over that. The method will update the fields that are supplied on the current
     * instance if they are different from the default values for the respective field.
     * 
     * @return The Group Tn to be updated.
     */
    private DBTblGroupTn getKeyGroupTnToUpdate()
    {
        log.info("Inside getKeyGroupTnToUpdate");
        DBTblGroupTn keyGroupTnDbBean = new DBTblGroupTn();

        /* Create a new instance of KeyGroupTnBean. The new instance
        * would hold default values for the all the KeyGroupTn fields.*/
        KeyGroupTnBean defaultKeyGrpTnBean = new KeyGroupTnBean();
        KeyGroupTn inputKeyGrpTn = this;
		
		if (inputKeyGrpTn.getIcpSubId() != null && !inputKeyGrpTn.getIcpSubId().equals(defaultKeyGrpTnBean.getIcpSubId())) {
        	keyGroupTnDbBean.setIcpSubId(inputKeyGrpTn.getIcpSubId());
			log.info("IcpSubId = <" + inputKeyGrpTn.getIcpSubId() + ">");
		}

        if (inputKeyGrpTn.getGroupId() != defaultKeyGrpTnBean.getGroupId())
        {
            keyGroupTnDbBean.setGroupId(inputKeyGrpTn.getGroupId());
        }
        if (inputKeyGrpTn.getTnPoolId() != defaultKeyGrpTnBean.getTnPoolId())
        {
            keyGroupTnDbBean.setTnPoolId(inputKeyGrpTn.getTnPoolId());
        }

        if (inputKeyGrpTn.getSequenceNo() != defaultKeyGrpTnBean.getSequenceNo())
        {
            keyGroupTnDbBean.setSequenceNo(inputKeyGrpTn.getSequenceNo());
        }

        if (inputKeyGrpTn.getExtension() != null
                && !inputKeyGrpTn.getExtension().equals(defaultKeyGrpTnBean.getExtension()))
        {
            keyGroupTnDbBean.setExtension(inputKeyGrpTn.getExtension());
            log.info("Extension = <" + inputKeyGrpTn.getExtension() + ">");
        }
        
        if("".equals(inputKeyGrpTn.getExtension())){
        	keyGroupTnDbBean.setExtensionNull();
        }
        
        if (inputKeyGrpTn.getPrivateNumber() != null
                && !inputKeyGrpTn.getPrivateNumber().equals(defaultKeyGrpTnBean.getPrivateNumber()))
        {
            keyGroupTnDbBean.setPrivateNumber(inputKeyGrpTn.getPrivateNumber());
        }
        
        if("".equals(inputKeyGrpTn.getPrivateNumber())){
        	keyGroupTnDbBean.setPrivateNumberNull();
        }
        
        if (inputKeyGrpTn.getLinePort() != null
                && !inputKeyGrpTn.getLinePort().equals(defaultKeyGrpTnBean.getLinePort()))
        {
            keyGroupTnDbBean.setLinePort(inputKeyGrpTn.getLinePort());
        }
        
        if("".equals(inputKeyGrpTn.getLinePort())){
        	keyGroupTnDbBean.setLinePortNull();
        }
        
        if (inputKeyGrpTn.getCidFirstName() != null
                && !inputKeyGrpTn.getCidFirstName().equals(defaultKeyGrpTnBean.getCidFirstName()))
        {
            keyGroupTnDbBean.setCidFirstName(inputKeyGrpTn.getCidFirstName());
        }
        
        if("".equals(inputKeyGrpTn.getCidFirstName())){
        	keyGroupTnDbBean.setCidFirstNameNull();
        }
        
        if (inputKeyGrpTn.getCidLastName() != null
                && !inputKeyGrpTn.getCidLastName().equals(defaultKeyGrpTnBean.getCidLastName()))
        {
            keyGroupTnDbBean.setCidLastName(inputKeyGrpTn.getCidLastName());
        }
        
        if("".equals(inputKeyGrpTn.getCidLastName())){
        	keyGroupTnDbBean.setCidLastNameNull();
        }
        
        if (inputKeyGrpTn.getKeyVmMaxsizeId() != defaultKeyGrpTnBean.getKeyVmMaxsizeId())
        {
            keyGroupTnDbBean.setVmMaxsizeId(inputKeyGrpTn.getKeyVmMaxsizeId());
        }
        if (inputKeyGrpTn.getKeyVmBoxNum() != null
                && !inputKeyGrpTn.getKeyVmBoxNum().equals(defaultKeyGrpTnBean.getKeyVmBoxNum()))
        {
            keyGroupTnDbBean.setVmBoxNum(inputKeyGrpTn.getKeyVmBoxNum());
        }
        
        if("".equals(inputKeyGrpTn.getKeyVmBoxNum())){
        	keyGroupTnDbBean.setVmBoxNumNull();
        }
        
        /* if ( inputKeyGrpTn.getStatus() != null &&
        	!inputKeyGrpTn.getStatus().equals(defaultKeyGrpTnBean.getStatus()) ){
        keyGroupTnDbBean.setStatus(inputKeyGrpTn.getStatus());
         	}*/
        if (inputKeyGrpTn.getActiveInd() != defaultKeyGrpTnBean.getActiveInd())
        {
            keyGroupTnDbBean.setActiveInd(inputKeyGrpTn.getActiveInd());
        }
        if (inputKeyGrpTn.getEnvOrderId() != defaultKeyGrpTnBean.getEnvOrderId())
        {
            keyGroupTnDbBean.setEnvOrderId(inputKeyGrpTn.getEnvOrderId());
        }
        if (inputKeyGrpTn.getModifiedBy() != null && !("".equalsIgnoreCase(inputKeyGrpTn.getModifiedBy())))
            keyGroupTnDbBean.setModifiedBy(getModifiedBy());
        else
            keyGroupTnDbBean.setModifiedBy("ESAP_INV");
        keyGroupTnDbBean.setLastModifiedDate(new Timestamp(System.currentTimeMillis()));

        // Added as new column introduced in the table fmcg_sub_id
        if (inputKeyGrpTn.getSubId() != null
                && !inputKeyGrpTn.getSubId().equals(defaultKeyGrpTnBean.getSubId()))
        {
        	if(! "".equals(inputKeyGrpTn.getSubId()))
        		keyGroupTnDbBean.setSubId(inputKeyGrpTn.getSubId());
        	else
        		keyGroupTnDbBean.setSubIdNull();
        
        }

        return keyGroupTnDbBean;
    }

    public boolean validate()
    {
        return true;
    }

    public boolean getDetailsByGroupTnId()
    {
        try
        {
            if (getGroupTnId() <= 0)
            {
                setErrstatus(InvErrorCode.INVALID_INPUT);
                //setStatusDesc("INV_FAILURE in getDetails Key groupTn. Invalid Input");
                return false;
            }
            TblGroupTnQuery grpTnQry = new TblGroupTnQuery();
            String whereClause = new String("");
            if (getAll == false)
                whereClause = " where group_tn_id = " + getGroupTnId() + " and active_ind = 1";
            else
                whereClause = " where group_tn_id = " + getGroupTnId() + " and active_ind != 0";
            grpTnQry.queryByWhere(dbCon, whereClause);
            if (grpTnQry.size() == 1)
            {
                setGroupId((int) (grpTnQry.getDbBean(0)).getGroupId());
                setGroupTnId((grpTnQry.getDbBean(0)).getGroupTnId());
                setTnPoolId((grpTnQry.getDbBean(0)).getTnPoolId());
                PublicTnPool tnPool = new PublicTnPool(dbCon);
                tnPool.setTnPoolId((int) getTnPoolId());
                if (!tnPool.getPublicTnPoolDetailsByTnPoolId())
                {
                    setErrstatus(InvErrorCode.NOTFOUND_TN_POOL_ID);
                    //setStatusDesc("NOTFOUND_TN_POOL_ID in getDetailsByGroupTnId. Failed to getPublic Tn Pool");
                    log.info("NOTFOUND_TN_POOL_ID in getDetailsByGroupTnId. Failed to get Public Tn Pool");
                    return false;
                }
                publicTnPoolObj = tnPool;
                setSequenceNo((grpTnQry.getDbBean(0)).getSequenceNo());
                setExtension((grpTnQry.getDbBean(0)).getExtension());
                setPrivateNumber((grpTnQry.getDbBean(0)).getPrivateNumber());
                setLinePort((grpTnQry.getDbBean(0)).getLinePort());
                setCidFirstName((grpTnQry.getDbBean(0)).getCidFirstName());
                setCidLastName((grpTnQry.getDbBean(0)).getCidLastName());
                setActiveInd((grpTnQry.getDbBean(0)).getActiveInd());
                setKeyVmMaxsizeId((grpTnQry.getDbBean(0)).getVmMaxsizeId());
                //TODO populate KayMaxsize
                setKeyVmBoxNum((grpTnQry.getDbBean(0)).getVmBoxNum());
                //setStatus((grpTnQry.getDbBean(0)).getStatus());
                setEnvOrderId(grpTnQry.getDbBean(0).getEnvOrderId());
                setCreatedBy((grpTnQry.getDbBean(0)).getCreatedBy());
                setModifiedBy((grpTnQry.getDbBean(0)).getModifiedBy());
                setCreationDate((grpTnQry.getDbBean(0)).getCreationDate());
				setLastModifiedDate((grpTnQry.getDbBean(0)).getLastModifiedDate()); 
                 //Added as new column introduced in the table fmcg_sub_id
                setSubId((grpTnQry.getDbBean(0)).getSubId());
				setIcpSubId((grpTnQry.getDbBean(0)).getIcpSubId());	
            } else
            {
                setErrstatus(InvErrorCode.SUCCESS);
                log.info("No getDetailsByGroupTnId to Get");
                return true;
            }
        }
        catch (SQLException s)
        {
            s.printStackTrace();
            setErrstatus(InvErrorCode.DB_EXCEPTION);
            //setStatusDesc("DB_EXCEPTION in getDetails Key group tn");
            return false;
        }
        setErrstatus(InvErrorCode.SUCCESS);
        //setErrstatus("Successfully retrieved key groupTn from db");
        return true;
    }

    public boolean getExcludedFeatureListByGroupTnId()
    {
        try
        {
            if (getGroupTnId() <= 0)
            {
                setErrstatus(InvErrorCode.INVALID_INPUT);
                //setErrstatus("INV_FAILURE in getExcludedFeaturesList");
                return false;
            }
            TblGroupTnExcldFeaturesQuery grpExcldFeatQry = new TblGroupTnExcldFeaturesQuery();
            grpExcldFeatQry.whereGroupTnIdEQ(getGroupTnId());
            grpExcldFeatQry.query(dbCon);
            if (grpExcldFeatQry.size() > 0)
            {
                for (int i = 0; i < grpExcldFeatQry.size(); i++)
                {
                    TblVzbFeaturesQuery vzbFeatQry = new TblVzbFeaturesQuery();
                    vzbFeatQry.whereFeatureIdEQ((int) (grpExcldFeatQry.getDbBean(i)).getFeatureId());
                    vzbFeatQry.whereFeatureTypeNE("C");
                    vzbFeatQry.query(dbCon);
                    if (vzbFeatQry.size() == 1)
                    {
                        FeaturesBean featBean = new FeaturesBean();
                        DBTblVzbFeatures vzbFeat = new DBTblVzbFeatures();
                        vzbFeat.copyFromBean(vzbFeatQry.getDbBean(0));
                        featBean.setFeaturesDbBean(vzbFeat);
                        excludedFeaturesList.add(featBean);
                    } else
                    {
                        setErrstatus(InvErrorCode.SUCCESS);
                        log.info("No VzBFeatures to Get");
                        return true;
                    }
                }
            } else
            {
                setErrstatus(InvErrorCode.SUCCESS);
                log.info("No ExcFeatures to Get");
                return true;
            }
        }
        catch (SQLException s)
        {
            s.printStackTrace();
            setErrstatus(InvErrorCode.DB_EXCEPTION);
            //setErrstatus("DB_FAILURE in getExcludedFeaturesList");
            return false;
        }
        return true;
    }

    //wrapper add for excludedfeaturesList
    public boolean addExcludedFeautresForKeyGroup() throws SQLException, Exception
    {
        //try
        //{
            if (excludedFeaturesList.size() > 0)
            {
                for (int i = 0; i < excludedFeaturesList.size(); i++)
                {
                    TblVzbFeaturesQuery vzbFeatQry = new TblVzbFeaturesQuery();
                    vzbFeatQry.whereFeatureIdEQ(((excludedFeaturesList.get(i)).getFeaturesDbBean()).getFeatureId());
                    vzbFeatQry.whereFeatureTypeNE("C");
                    vzbFeatQry.query(dbCon);
                    if (vzbFeatQry.size() == 1)
                    {
                        DBTblGroupTnExcldFeatures grpExcldFeat = new DBTblGroupTnExcldFeatures();
                        grpExcldFeat.getGroupTnFeatureIdSeqNextVal(dbCon);
                        grpExcldFeat.setGroupTnId(getGroupTnId());
                        grpExcldFeat.setEnvOrderId(getEnvOrderId());
                        grpExcldFeat.setFeatureId((vzbFeatQry.getDbBean(0)).getFeatureId());
                        if (getCreatedBy() != null && !getCreatedBy().equals(""))
                            grpExcldFeat.setCreatedBy(getCreatedBy());
                        else
                            grpExcldFeat.setCreatedBy("ESAP_INV");
                        if (getModifiedBy() != null && !getModifiedBy().equals(""))
                            grpExcldFeat.setModifiedBy(getModifiedBy());
                        else
                            grpExcldFeat.setModifiedBy("ESAP_INV");
                        grpExcldFeat.setLastModifiedDate(new Timestamp(System.currentTimeMillis()));
                        grpExcldFeat.setCreationDate(new Timestamp(System.currentTimeMillis()));
                        grpExcldFeat.insert(dbCon);
                    } else
                    {
                        log.info("Valid Excluded feature not found in the db"
                                + ((excludedFeaturesList.get(i)).getFeaturesDbBean()).getName());
                        return false;
                    }
                }
            } else
            {
                setErrstatus(InvErrorCode.SUCCESS);
                ////setErrstatus("");
                log.info("No groupExcFeatures to Add");
                return true;
            }
        /*}
        catch (Exception e)
        {
            e.printStackTrace();
            setErrstatus(InvErrorCode.ERROR_ADDING_EXCLD_FEATURE_TO_GROUP_TN);
            log.info("FAILURE in addExcludedFeautresForKeyGroup.");
            return false;
        }*/
        setErrstatus(InvErrorCode.SUCCESS);
        return true;
    }

	 //wrapper delete for excludedfeaturesList
    public boolean deleteExcludedfeaturesListForKeyGroup() throws SQLException, Exception
    {
        //try {
            if (excludedFeaturesList.size() > 0) {                 
				for (int i = 0; i < excludedFeaturesList.size(); i++) {
                        DBTblGroupTnExcldFeatures excFeaturesDbBean = new DBTblGroupTnExcldFeatures();
                        excFeaturesDbBean.whereFeatureIdEQ(((excludedFeaturesList.get(i)).getFeaturesDbBean()).getFeatureId());
                        excFeaturesDbBean.whereGroupTnIdEQ(getGroupTnId());
                        if (excFeaturesDbBean.deleteByWhere(dbCon) <= 0) {
                            log.info("Error while deleting Exclude Features from KeyGroupTn."+((excludedFeaturesList.get(i)).getFeaturesDbBean()).getFeatureId());
                        }
                                                                                                                             
                    }
            } else {
                setErrstatus(InvErrorCode.SUCCESS);
                // //setErrstatus("");
                log.info("No excludedfeaturesList to Delete");
                return true;
            }
        /*} catch (Exception e) {
            e.printStackTrace();
            setErrstatus(InvErrorCode.ERROR_DELETING_EXCLD_FEATURE_TO_GROUP_TN);
            System.out
                    .println("FAILURE in deleteExcludedfeaturesListForPBXGroup.");
            return false;
        }*/
        setErrstatus(InvErrorCode.SUCCESS);
        return true;
    }

    //wrapper Modify for excludedfeaturesList
    public boolean modifyExcludedfeaturesListForKeyGroup()
    {
        try
        {
            if (excludedFeaturesList.size() > 0)
            {
                for (int i = 0; i < excludedFeaturesList.size(); i++)
                {
                    TblGroupTnExcldFeaturesQuery excFeaturesQuery = new TblGroupTnExcldFeaturesQuery();
                    String whereClause = " where group_id = " + getGroupId();
                    excFeaturesQuery.queryByWhere(dbCon, whereClause);
                    for (int j = 0; j < excFeaturesQuery.size(); j++)
                    {
                        DBTblGroupTnExcldFeatures excFeaturesDbBean = new DBTblGroupTnExcldFeatures();
                        excFeaturesDbBean.whereFeatureIdEQ(((excludedFeaturesList.get(i)).getFeaturesDbBean()).getFeatureId());
                        // excFeaturesDbBean.updateSpByWhere(dbCon);
                        if (excFeaturesDbBean.updateSpByWhere(dbCon) <= 0)
                        {
                            return false;
                        }
                    }
                }
            } else
            {
                setErrstatus(InvErrorCode.SUCCESS);
                ////setErrstatus("");
                log.info("No excludedfeaturesList to Modify");
                return true;
            }
        }
        catch (Exception e)
        {
            e.printStackTrace();
            setErrstatus(InvErrorCode.ERROR_MODIFYING_EXCLD_FEATURE_TO_GROUP_TN);
            log.info("FAILURE in modifyExcludedfeaturesListForKeyGroup.");
            return false;
        }
        setErrstatus(InvErrorCode.SUCCESS);
        return true;
    }

    /**
     * The wrapper method to get Public Tn Pool for a KeyGroupTn
     * 
     * @return true if retrieve Public Tn Pool bean false if it fails to retrieve Public Tn Pool
     *         bean
     * @throws SQLException
     *             If any DB Error occurs.
     */
    public boolean getPublicTnPoolForKeyGroupTn()
    {
        try
        {
            //retrieve KeyGroupTn details to get the PublicTnPoolId(TN_POOL_ID)
            boolean ret = getDetailsByGroupTnId();
            if (!ret)
            {
                setErrstatus(InvErrorCode.INV_FAILURE);
                log.info("FAILURE in getDetailsByGroupTnId KeyGroupTn. KeyGroupTn.getDetailsByGroupTnId returned false in getPublicTnPoolForKeyGroupTn");
                return false;
            }
            log.info("In the Inventry, the PublicTnPoolId Id for KeyGroupTn = " + groupTnId + " is -> "
                    + tnPoolId);
            //if PublicTnPoolId is valid, query the PublicTnPool class for details.
            PublicTnPool pubTnPool = new PublicTnPool(dbCon);
            pubTnPool.setTnPoolId(new Long(tnPoolId).intValue());
            ret = pubTnPool.getDetails();
            if (!ret)
            {
                setErrstatus(InvErrorCode.INV_FAILURE);
                log.info("FAILURE in KeyGroupTn.getDetails . KeyGroupTn.getDetails returned false in getPublicTnPoolForKeyGroupTn");
                return false;
            }
            setPublicTnPoolObj((PublicTnPoolBean) pubTnPool);
        }
        catch (Exception e)
        {
            e.printStackTrace();
            setErrstatus(InvErrorCode.DB_EXCEPTION);
            log.info("FAILURE in getDetails KeyGroupTn");
            return false;
        }
        setErrstatus(InvErrorCode.SUCCESS);
        log.info("Successfully retrieved KeyGroupTn from the DB");
        return true;
    }

    /**
     * The wrapper method to Add Public Tn Pool to a KeyGroupTn
     * 
     * @throws SQLException
     *             If any DB Error occurs.
     */
    public boolean addPublicTnPoolToKeyGroupTn()
    {
        try
        {
            PublicTnPool publicTnPool = new PublicTnPool(dbCon, publicTnPoolObj);

            if (!publicTnPool.addPublicTnPool())
            {
                setErrstatus(InvErrorCode.INTERNAL_ERROR);
                //setStatusDesc(publicTnPool.getStatusDesc());
                log.info(publicTnPool.getStatusDesc());
                return false;
            }
            DBTblGroupTn groupTnDbBean = new DBTblGroupTn();
            groupTnDbBean.setTnPoolId(publicTnPoolObj.getTnPoolId());
            groupTnDbBean.setEnvOrderId(publicTnPoolObj.getEnvOrderId());
            if (publicTnPoolObj.getModifiedBy() != null && !"".equals(publicTnPoolObj.getModifiedBy()))
                groupTnDbBean.setModifiedBy(groupTnDbBean.getModifiedBy());
            else
                groupTnDbBean.setModifiedBy("ESAP_INV");
            groupTnDbBean.setLastModifiedDate(new Timestamp(System.currentTimeMillis()));
            groupTnDbBean.whereGroupTnIdEQ(getGroupTnId());
            //groupTnDbBean.updateSpByWhere(dbCon);
            if (groupTnDbBean.updateSpByWhere(dbCon) <= 0)
            {
                return false;
            }

        }
        catch (Exception e)
        {
            e.printStackTrace();
            setErrstatus(InvErrorCode.ERROR_ADDING_PUBLICTNPOOL_TO_GROUP_TN);
            ////setStatusDesc("FAILURE in addPublicTnPoolToKeyGroupTn.");
            log.info("FAILURE in addPublicTnPoolToKeyGroupTn.");
            return false;
        }
        setErrstatus(InvErrorCode.SUCCESS);
        ////setStatusDesc("Successfully added PublicTnPool to KeyGroupTn");
        return true;
    }

    /**
     * The wrapper method to delete Public Tn Pool for a KeyGroupTn
     * 
     * @throws SQLException
     *             If any DB Error occurs.
     */
    public boolean deletePublicTnPoolToKeyGroupTn() throws SQLException
    {

        try
        {
            PublicTnPool publicTnPool = new PublicTnPool(dbCon, publicTnPoolObj);
            if (rollbackFlag)
            {
                if (!publicTnPool.deletePublicTnPool())
                {
                    setErrstatus(InvErrorCode.INTERNAL_ERROR);
                    ////setStatusDesc(publicTnPool.getStatusDesc());
                    log.info(publicTnPool.getStatusDesc());
                    return false;
                }
            } else
            {
                publicTnPool.setTnStatus(VzbVoipEnum.TnStatus.AVAILABLE);
                if (!publicTnPool.updatePublicTnPool())
                {
                    setErrstatus(InvErrorCode.INTERNAL_ERROR);
                    log.info(publicTnPool.getStatusDesc());
                    return false;
                }
            }
        }
        catch (Exception e)
        {
            e.printStackTrace();
            setErrstatus(InvErrorCode.ERROR_DELETING_PUBLICTNPOOL_TO_GROUP_TN);
            ////setStatusDesc("FAILURE in deletePublicTnPoolForKeyGroupTn().");
            log.info("FAILURE in deletePublicTnPoolForKeyGroupTn().");
            return false;
        }
        setErrstatus(InvErrorCode.SUCCESS);
        ////setStatusDesc("Successfully deleted PublicTnPool from KeyGroupTn");
        return true;

    }

    /**
     * The wrapper method to Add Public Tn Pool to a KeyGroupTn
     * 
     * @throws SQLException
     *             If any DB Error occurs.
     */
    public boolean updatePublicTnPoolToKeyGroupTn()
    {
        try
        {
            PublicTnPool publicTnPool = new PublicTnPool(dbCon, publicTnPoolObj);
            //publicTnPool.setTnPoolId(new Long(getTnPoolId()).intValue());
            if (!publicTnPool.updatePublicTnPool())
            {
                setErrstatus(InvErrorCode.INTERNAL_ERROR);
                ////setStatusDesc(publicTnPool.getStatusDesc());
                log.info(publicTnPool.getStatusDesc());
                return false;
            }
        }
        catch (Exception e)
        {
            e.printStackTrace();
            setErrstatus(InvErrorCode.ERROR_MODIFYING_PUBLICTNPOOL_TO_GROUP_TN);
            ////setStatusDesc("FAILURE in updatePublicTnPoolToKeyGroupTn.");
            log.info("FAILURE in updatePublicTnPoolToKeyGroupTn.");
            return false;
        }
        setErrstatus(InvErrorCode.SUCCESS);
        ////setErrstatus("Successfully updated PublicTnPool to KeyGroupTn");
        return true;
    }
    
    /**
     * The wrapper method to get Subscriber for a KeyGroupTn
     * 
     * @return true if retrieve Public Tn Pool bean false if it fails to retrieve Public Tn Pool
     *         bean
     * @throws SQLException
     *             If any DB Error occurs.
     */
    public boolean getSubscriberForKeyGroupTn()
    {
        try
        {
            //retrieve KeyGroupTn details to get the PublicTnPoolId(TN_POOL_ID)
            boolean ret = getDetailsByGroupTnId();
            if (!ret)
            {
                setErrstatus(InvErrorCode.INV_FAILURE);
                log.info("FAILURE in getDetailsByGroupTnId KeyGroupTn. KeyGroupTn.getDetailsByGroupTnId returned false in getPublicTnPoolForKeyGroupTn");
                return false;
            }
            log.info("In the Inventry, the PublicTnPoolId Id for KeyGroupTn = " + groupTnId + " is -> "
                    + tnPoolId);
           
            //if FmcgSubId is valid, query the Subscriber class for details.
            Subscriber subscriber = new Subscriber(dbCon);
            FmcgSubscriber fmcgSubscriber = new FmcgSubscriber(dbCon);
            fmcgSubscriber.setFmcgSubId(new Integer((int)tnPoolId).intValue());
            ret = fmcgSubscriber.getFmcgSubscriberDetailsById();
            if (!ret)
            {
                setErrstatus(InvErrorCode.INV_FAILURE);
                log.info("FAILURE in KeyGroupTn.getDetails . KeyGroupTn.getDetails returned false in getPublicTnPoolForKeyGroupTn");
                return false;
            }
            subscriber.setFmcgSubscriberObj((FmcgSubscriberBean) fmcgSubscriber);
            
            //if SubId is valid, query the Subscriber class for details.
           
            subscriber.setSubId(new String(tnPoolId+""));
            ret = subscriber.getSubscriberDetailsBySubId();
            if (!ret)
            {
                setErrstatus(InvErrorCode.INV_FAILURE);
                log.info("FAILURE in KeyGroupTn.getDetails . KeyGroupTn.getDetails returned false in getPublicTnPoolForKeyGroupTn");
                return false;
            }
            setSubscriberBeanObj((SubscriberBean) subscriber);
            
         
        }
        catch (Exception e)
        {
            e.printStackTrace();
            setErrstatus(InvErrorCode.DB_EXCEPTION);
            log.info("FAILURE in getDetails KeyGroupTn");
            return false;
        }
        setErrstatus(InvErrorCode.SUCCESS);
        log.info("Successfully retrieved KeyGroupTn from the DB");
        return true;
    }

}

