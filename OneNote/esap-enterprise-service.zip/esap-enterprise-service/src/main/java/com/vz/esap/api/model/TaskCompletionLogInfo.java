package com.vz.esap.api.model;

public class TaskCompletionLogInfo {

	/*{
	    "description": "string",
	    "eventDate": "string",
	    "orderId": 0,
	    "seqNo": 0,
	    "severity": "string",
	    "status": "string",
	    "svcSeqNo": 0,
	    "taskName": "string"
	  }*/
	
	
	private String taskName;
	private String description;
	private String severity;
	private String eventDate;
	private Long orderId;
	private Long seqNo;
	private String status;
	private Long svcSeqNo;
	
	public String getTaskName() {
		return taskName;
	}
	public void setTaskName(String taskName) {
		this.taskName = taskName;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getSeverity() {
		return severity;
	}
	public void setSeverity(String severity) {
		this.severity = severity;
	}
	public String getEventDate() {
		return eventDate;
	}
	public void setEventDate(String eventDate) {
		this.eventDate = eventDate;
	}
	public Long getOrderId() {
		return orderId;
	}
	public void setOrderId(Long orderId) {
		this.orderId = orderId;
	}
	public Long getSeqNo() {
		return seqNo;
	}
	public void setSeqNo(Long seqNo) {
		this.seqNo = seqNo;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Long getSvcSeqNo() {
		return svcSeqNo;
	}
	public void setSvcSeqNo(Long svcSeqNo) {
		this.svcSeqNo = svcSeqNo;
	}
	
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("TaskCompletionLogInfo [taskName=");
		builder.append(taskName);
		builder.append(", description=");
		builder.append(description);
		builder.append(", severity=");
		builder.append(severity);
		builder.append(", eventDate=");
		builder.append(eventDate);
		builder.append(", orderId=");
		builder.append(orderId);
		builder.append(", seqNo=");
		builder.append(seqNo);
		builder.append(", status=");
		builder.append(status);
		builder.append(", svcSeqNo=");
		builder.append(svcSeqNo);
		builder.append("]");
		return builder.toString();
	}
	
}
