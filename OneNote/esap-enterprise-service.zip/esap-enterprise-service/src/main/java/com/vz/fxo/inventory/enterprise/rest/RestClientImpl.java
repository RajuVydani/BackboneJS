package com.vz.fxo.inventory.enterprise.rest;

import org.apache.commons.codec.binary.Base64;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class RestClientImpl {

	private static final Logger LOG = LoggerFactory.getLogger(RestClientImpl.class);

	public Object invokeService(Object inputdata, String url, String svcUserName, String svcPassword,
			Class responseClassObj) {
		LOG.info("Sending request to URL: {}", url);
		RestTemplate restTemplate = new RestTemplate();

		HttpEntity<Object> input;
		ResponseEntity<Object> response = null;

		if (svcUserName != null && svcPassword != null) {
			String plainClientCredentials = svcUserName + ":" + svcPassword;
			String base64ClientCredentials = new String(Base64.encodeBase64(plainClientCredentials.getBytes()));

			HttpHeaders headers = new HttpHeaders();
			headers.add("Authorization", "Basic " + base64ClientCredentials);

			headers.setContentType(MediaType.APPLICATION_JSON);
			input = new HttpEntity<>(inputdata, headers);

			try {
				response = restTemplate.exchange(url, HttpMethod.POST, input, responseClassObj);

			} catch (Exception e) {
				throw e;
			}
		} else {
			try {

				response = (ResponseEntity<Object>) restTemplate.postForObject(url, inputdata, responseClassObj);

			} catch (Exception e) {
				throw e;
			}
		}
		LOG.info("Received response :  {}", response);
		return response.getBody();
	}
	
	
	
	
	
	public Object invokeService(Object inputdata, String url, String svcUserName, String svcPassword,
			Class responseClassObj, HttpMethod httpMethod) {
		LOG.info("Sending request to URL: {}", url);
		RestTemplate restTemplate = new RestTemplate();

		HttpEntity<Object> input;
		ResponseEntity<Object> response = null;

		if (svcUserName != null && svcPassword != null) {
			String plainClientCredentials = svcUserName + ":" + svcPassword;
			String base64ClientCredentials = new String(Base64.encodeBase64(plainClientCredentials.getBytes()));

			HttpHeaders headers = new HttpHeaders();
			headers.add("Authorization", "Basic " + base64ClientCredentials);

			headers.setContentType(MediaType.APPLICATION_JSON);
			input = new HttpEntity<>(inputdata, headers);

			try {
				if (httpMethod != null && HttpMethod.POST.equals(httpMethod)) {
					response = restTemplate.exchange(url, HttpMethod.POST, input, responseClassObj);
					
				} else if (httpMethod != null && HttpMethod.DELETE.equals(httpMethod)) {
					restTemplate.delete(url);
					
				}
			} catch (Exception e) {				
				throw e;
			}
		} else {
			try {
				
				if (httpMethod != null && HttpMethod.POST.equals(httpMethod)) {
					response = (ResponseEntity<Object>) restTemplate.postForObject(url, inputdata, responseClassObj);
				
				} else if (httpMethod != null && HttpMethod.DELETE.equals(httpMethod)) {
					LOG.info("Ready to release IP");
					
					restTemplate.delete(url);
					
					LOG.info("IP released");					
				}
			} catch (Exception e) {
				throw e;
			}
		}
		LOG.info("Received response :  {}", response);
		return response.getBody();
	}
}