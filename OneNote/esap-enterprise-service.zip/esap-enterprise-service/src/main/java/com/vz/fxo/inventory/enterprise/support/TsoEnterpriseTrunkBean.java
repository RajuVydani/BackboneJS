package com.vz.fxo.inventory.enterprise.support;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

public class TsoEnterpriseTrunkBean implements Serializable {

	
    protected long enterpriseTrunkId;
    protected String enterpriseTrunkName;
    protected String enterpriseId;
    protected long maxRerouteAttempts;
    protected long maxRerouteAttemptsPriority;
    protected long routeExhaustActivated;
    protected long routeExhaustAction;
    protected String routeExhaustFwdTn;
    protected String createdBy;
    protected Timestamp creationDate;
    protected String modifiedBy;
    protected Timestamp lastModifiedDate;
    protected List<String> logTrail;
    
    public TsoEnterpriseTrunkBean(){
    	this.enterpriseTrunkId=0;
    	this.enterpriseTrunkName=new String("");
    	this.enterpriseId=new String("");
    	this.maxRerouteAttempts=0;
    	this.maxRerouteAttemptsPriority=0;
    	this.routeExhaustActivated=-1;
    	this.routeExhaustAction=-1;
    	this.routeExhaustFwdTn=new String("NONE");
    	this.createdBy = new String("");
        this.creationDate = null;
	    this.modifiedBy = new String("");
		this.lastModifiedDate = null;
		logTrail = new ArrayList<String>();
    	
    }
  
    
    public TsoEnterpriseTrunkBean(TsoEnterpriseTrunkBean tsoEnterpriseTrunkBean){
    	
    	this.enterpriseTrunkId=tsoEnterpriseTrunkBean.enterpriseTrunkId;
    	this.enterpriseTrunkName=tsoEnterpriseTrunkBean.enterpriseTrunkName;
    	this.enterpriseId=tsoEnterpriseTrunkBean.enterpriseId;
    	this.maxRerouteAttempts=tsoEnterpriseTrunkBean.maxRerouteAttempts;
    	this.maxRerouteAttemptsPriority=tsoEnterpriseTrunkBean.maxRerouteAttemptsPriority;
    	this.routeExhaustActivated=tsoEnterpriseTrunkBean.routeExhaustActivated;
    	this.routeExhaustAction=tsoEnterpriseTrunkBean.routeExhaustAction;
    	this.routeExhaustFwdTn=tsoEnterpriseTrunkBean.routeExhaustFwdTn;
    	this.createdBy = tsoEnterpriseTrunkBean.createdBy;
        this.creationDate = tsoEnterpriseTrunkBean.creationDate;
	    this.modifiedBy = tsoEnterpriseTrunkBean.modifiedBy;
		this.lastModifiedDate = tsoEnterpriseTrunkBean.lastModifiedDate;	
		this.logTrail = tsoEnterpriseTrunkBean.logTrail;
    }
    
    /**
	 * @return the logTrail
	 */
	public List<String> getLogTrail() {
		return logTrail;
	}

	/**
	 * @param logTrail the logTrail to set
	 */
	public void setLogTrail(String logStr) {
		logTrail.add(logStr);
	}

	public long getEnterpriseTrunkId() {
		return enterpriseTrunkId;
	}

	public void setEnterpriseTrunkId(long enterpriseTrunkId) {
		this.enterpriseTrunkId = enterpriseTrunkId;
	}

	public String getEnterpriseTrunkName() {
		return enterpriseTrunkName;
	}

	public void setEnterpriseTrunkName(String enterpriseTrunkName) {
		this.enterpriseTrunkName = enterpriseTrunkName;
	}

	public String getEnterpriseId() {
		return enterpriseId;
	}

	public void setEnterpriseId(String enterpriseId) {
		this.enterpriseId = enterpriseId;
	}

	public long getMaxRerouteAttempts() {
		return maxRerouteAttempts;
	}

	public void setMaxRerouteAttempts(long maxRerouteAttempts) {
		this.maxRerouteAttempts = maxRerouteAttempts;
	}

	public long getMaxRerouteAttemptsPriority() {
		return maxRerouteAttemptsPriority;
	}

	public void setMaxRerouteAttemptsPriority(long maxRerouteAttemptsPriority) {
		this.maxRerouteAttemptsPriority = maxRerouteAttemptsPriority;
	}

	public long getRouteExhaustAction() {
		return routeExhaustAction;
	}

	public void setRouteExhaustAction(long routeExhaustAction) {
		this.routeExhaustAction = routeExhaustAction;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(Timestamp creationDate) {
		this.creationDate = creationDate;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Timestamp getLastModifiedDate() {
		return lastModifiedDate;
	}
	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public long getRouteExhaustActivated() {
		return routeExhaustActivated;
	}

	public void setRouteExhaustActivated(long routeExhaustActivated) {
		this.routeExhaustActivated = routeExhaustActivated;
	}

	public String getRouteExhaustFwdTn() {
		return routeExhaustFwdTn;
	}

	public void setRouteExhaustFwdTn(String routeExhaustFwdTn) {
		this.routeExhaustFwdTn = routeExhaustFwdTn;
	}

}
