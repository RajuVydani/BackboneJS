/**
 * 
 */
package com.vz.fxo.inventory.enterprise.helper;

import static com.vz.fxo.inventory.enterprise.helper.EnterpriseActionFunctionHelper.handleEntDigitStringActivate;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import EsapEnumPkg.VzbVoipEnum;

import com.vz.esap.api.connector.service.impl.ConfigDomainDataServiceImpl;
import com.vz.esap.api.constant.InventoryServiceConstants;
import com.vz.esap.api.exception.VZBAFException;
import com.vz.esap.api.model.ordering.EntityBatch;
import com.vz.esap.api.model.ordering.EntityData;
import com.vz.esap.api.model.ordering.TableOrderDetailsParam;
import com.vz.fxo.inventory.enterprise.support.CallingPlan;
import com.vz.fxo.inventory.enterprise.support.DigitString;
import com.vz.fxo.inventory.enterprise.support.DigitStringBean;
import com.vz.fxo.inventory.enterprise.support.Enterprise;
import com.vz.fxo.inventory.enterprise.support.FeaturesBean;
import com.vz.fxo.inventory.enterprise.support.PolicyFeaturesBean;
import com.vz.fxo.inventory.enterprise.support.PublicTnPool;
import com.vz.fxo.inventory.enterprise.support.ServicePackFeaturesBean;
import com.vz.fxo.inventory.enterprise.support.SubscriberDevice;
import com.vz.fxo.inventory.enterprise.support.SubscriberDeviceBean;
import com.vz.fxo.inventory.enterprise.support.TsoEtTn;
import com.vz.fxo.inventory.enterprise.support.VzbInvException;
import com.vz.fxo.inventory.enterprise.dao.model.TblTriTnData;

import esap.db.DBTblAuthServices;
import esap.db.DBTblEnterprise;
import esap.db.DBTblGroupTn;
import esap.db.DBTblLocation;
import esap.db.DBTblOrderDetails;
import esap.db.DBTblPkgFeatures;
import esap.db.DBTblSubFeature;
import esap.db.TblAuthServicesQuery;
import esap.db.TblDaylightSavingRegionsDbBean;
import esap.db.TblDaylightSavingRegionsQuery;
import esap.db.TblDepartmentQuery;
import esap.db.TblEnterpriseDbBean;
import esap.db.TblEnterpriseQuery;
import esap.db.TblGroupQuery;
import esap.db.TblGroupTnQuery;
import esap.db.TblLocationDbBean;
import esap.db.TblLocationQuery;
import esap.db.TblPoliciesDbBean;
import esap.db.TblPoliciesQuery;
import esap.db.TblPublicTnPoolDbBean;
import esap.db.TblPublicTnPoolQuery;
import esap.db.TblServicepackDbBean;
import esap.db.TblServicepackQuery;
import esap.db.TblVzbFeaturesDbBean;
import esap.db.TblVzbFeaturesQuery;

/**
 * This helper class provides utility method which can be used by any Action
 * Functions to retrieve values from EntityBatch and EntityData
 * 
 * @author Deepak Kumar
 * 
 * 
 */
public class ActionFunctionHelper {

	private static Logger log = LoggerFactory
			.getLogger(ActionFunctionHelper.class.toString());
	public static final String PARAM_ACTION_IN = "n";
	public static final String PARAM_ACTION_OUT = "o";
	public static final String PARAM_ACTION_R = "r";
	public static final String PARAM_ACTION_C = "c";
	public static final String FRAUD_BLOCK_BY_BS = "BS";

	private static Map<String, List<String>> enterpriseTnListMap = new HashMap<String, List<String>>();
	private final static SimpleDateFormat sdfDate = new SimpleDateFormat(
			InventoryServiceConstants.DATE_FORMAT_TIMESTAMP);

	public static boolean isEmpty(String input) {
		if ((input == null) || (input.trim().length() == 0)) {
			return true;
		}
		return false;
	}

	/**
	 * 
	 * @param pageSize
	 * @param pageNo
	 * @return
	 */
	public static long getStartPageIndex(int pageSize, int pageNo) {
		int startPageIndex = pageSize * (pageNo - 1) + 1;
		startPageIndex = startPageIndex > 0 ? startPageIndex : 1;
		return startPageIndex;
	}

	/**
	 * 
	 * @param pageSize
	 * @param pageNo
	 * @param maxIndex
	 * @return
	 */
	public static long getEndPageIndex(int pageSize, int pageNo, long maxIndex) {

		int endPageIndex = 1;
		if (pageNo <= 0) {
			endPageIndex = 1;
		} else {
			endPageIndex = (pageSize * (pageNo));
		}
		if (endPageIndex > maxIndex && pageNo > 1) {
			endPageIndex = Integer.parseInt(String.valueOf(maxIndex));
		}
		return endPageIndex;
	}

	/**
	 * 
	 * @param maxIndex
	 * @param pageSize
	 * @return
	 */
	public static int getTotalPages(Long maxIndex, int pageSize) {

		int totPage = 1;
		double pages = Double.parseDouble(String.valueOf(maxIndex)) / pageSize;
		if (pages > 0) {
			totPage = (int) Math.ceil(pages);
		}
		return totPage;
	}
	

	
	/**
	 * 
	 * @param entityBatch
	 * @return
	 */
	public static String getRegion(EntityBatch entityBatch) {

		String region = "";
		Map<String, EntityData> entityMap = entityBatch.getEntity();
		for (Map.Entry<String, EntityData> entry : entityMap.entrySet()) {
			EntityData ed = entry.getValue();
			if (ed!=null && ed.getParamMap().get("Region") != null) {
				region = ed.getParamMap().get("Region").getParamValue();
				break;
			}
		}
		return region;
	}

	/**
	 * 
	 * @param entityBatch
	 * @return
	 */
	public static String getEnterpriseId(EntityBatch entityBatch) {

		String enterpriseId = "";
		Map<String, EntityData> entityMap = entityBatch.getEntity();
		for (Map.Entry<String, EntityData> entry : entityMap.entrySet()) {
			EntityData ed = entry.getValue();
			if (ed!=null && ed.getParamMap().get("CustomerId") != null) {
				enterpriseId = ed.getParamMap().get("CustomerId")
						.getParamValue();
				break;
			}
		}
		return enterpriseId;
	}

	/**
	 * 
	 * @param entityMap
	 * @return
	 */
	public static String getLocationId(EntityBatch entityBatch) {

		String locationId = "";
		Map<String, EntityData> entityMap = entityBatch.getEntity();
		for (Map.Entry<String, EntityData> entry : entityMap.entrySet()) {
			EntityData ed = entry.getValue();
			if (ed!=null && ed.getParamMap().get("LocationId") != null) {
				locationId = ed.getParamMap().get("LocationId").getParamValue();
				break;
			}
		}
		return locationId;
	}
	


	/**
	 * This method returns the param value of given parameter based on action .
	 * If param is not found at first level , it will try to find out param at n
	 * <sb>th</sb> level
	 * 
	 * This method should not be used in bulk TN level methods.
	 * 
	 * @param entityBatch
	 * @param paramName
	 * @param paramActionIn
	 * @return
	 */
	public static String getParamValueWithAction(EntityBatch entityBatch,
			String paramName, String paramActionIn) {

		String paramValue = "";
		TableOrderDetailsParam tableOrderParam = null;
		TableOrderDetailsParam tableOrderDetailsParam;
		/*
		 * Map<String, EntityBatch> map = domainServiceDTO.getEntityTypeMap();
		 * EntityBatch entityBatch = map.get("TN");
		 */
		Map<String, EntityData> entityMap = entityBatch.getEntity();
		for (Map.Entry<String, EntityData> entry : entityMap.entrySet()) {
			EntityData ed = entry.getValue();
			if (ed.getParamMap().get(paramName) != null
					&& ed.getParamMap().get(paramName).getAction()
					.equals(paramActionIn)) {
				paramValue = ed.getParamMap().get(paramName).getParamValue();
				break;
			}
		}
		/* if not found at first level , now searching at nth level */
		if (ActionFunctionHelper.isEmpty(paramValue)) {
			for (Map.Entry<String, EntityData> entry : entityMap.entrySet()) {
				EntityData ed = entry.getValue();
				Iterator<String> iterator = ed.getNewParamDetailMap().keySet()
						.iterator();
				while (iterator.hasNext()) {
					tableOrderDetailsParam = ed.getNewParamDetailMap().get(
							iterator.next());
					tableOrderParam = getTableOrderDetailsParamByNameWithAction(
							tableOrderDetailsParam, paramName, paramActionIn);
					if (tableOrderParam != null) {
						break;
					}
				}
				if (tableOrderParam != null) {
					break;
				}

			}
		}
		if (tableOrderParam != null) {
			paramValue = tableOrderParam.getParamValue();
		}
		return paramValue;
	}

	/**
	 * This method should NOT be used from System Update functions where entity
	 * specific information is needed. Instead use the following:
	 * getTableOrderDetailsParam(EntityBatch entityBatch, String entityKey,
	 * String paramName) This method returns TOD from first entity in the batch.
	 * 
	 * @param entityBatch
	 * @param paramName
	 * @return
	 */
	public static TableOrderDetailsParam getTableOrderDetailsParam(
			EntityBatch entityBatch, String paramName) {
		TableOrderDetailsParam tableOrderParam = null;
		TableOrderDetailsParam tableOrderDetailsParam;
		Map<String, EntityData> entityMap = entityBatch.getEntity();
		for (Map.Entry<String, EntityData> entry : entityMap.entrySet()) {
			EntityData ed = entry.getValue();
			tableOrderParam = ed.getParamMap().get(paramName);
			if (tableOrderParam != null) {
				break;
			}
		}
		/* if not found at first level , now searching at nth level */
		if (tableOrderParam == null) {
			for (Map.Entry<String, EntityData> entry : entityMap.entrySet()) {
				EntityData ed = entry.getValue();
				Iterator<String> iterator = ed.getNewParamDetailMap().keySet()
						.iterator();
				while (iterator.hasNext()) {
					tableOrderDetailsParam = ed.getNewParamDetailMap().get(
							iterator.next());
					tableOrderParam = getTableOrderDetailsParamByName(
							tableOrderDetailsParam, paramName);
					if (tableOrderParam != null) {
						break;
					}
				}
				if (tableOrderParam != null) {
					break;
				}

			}
		}
		return tableOrderParam;
	}

	/**
	 * 
	 * @param paramName
	 * @param paramActionIn
	 * @param tableOrderParam
	 * @return
	 */
	public static TableOrderDetailsParam getByNameSearchWithAction(
			String paramName, String paramActionIn,
			TableOrderDetailsParam tableOrderParam) {
		TableOrderDetailsParam selectedParam = null;
		if (tableOrderParam != null && tableOrderParam.getParamDetail() != null) {
			for (TableOrderDetailsParam param : tableOrderParam
					.getParamDetail()) {
				if (param.getParamName().equals(paramName)
						&& param.getAction().equals(paramActionIn)) {
					selectedParam = param;
					break;
				}

			}
		}
		return selectedParam;
	}

	/**
	 * getIntValueFromOrderParams Get int value from order params, with a given
	 * paramName
	 * 
	 * @param entityBatch
	 */
	public static int getIntValueFromOrderParams(EntityBatch entityBatch,
			String paramName) {
		log.debug("In getIntValueFromOrderParams");
		TableOrderDetailsParam pd = getTableOrderDetailsParam(entityBatch,
				paramName);

		if (pd == null) {
			log.debug("Param: " + paramName
					+ " not found in tbl_order_details; returning 0");
			return 0;
		}

		String paramValue = pd.getParamValue();
		if ((paramValue == null) || (paramValue.trim().length() == 0)) {
			log.debug("Param: "
					+ paramName
					+ " has null or empty value in tbl_order_details; returning 0");
			return 0;
		}
		int intValue = Integer.parseInt(paramValue);
		return intValue;
	}

	/**
	 * This method returns the TableOrderDetailParam object of given parameter
	 * name . It recursively searches parameter
	 * 
	 * @param tableOrderDetailsParam
	 * @param paramName
	 * @return
	 */
	public static TableOrderDetailsParam getTableOrderDetailsParamByName(
			TableOrderDetailsParam tableOrderDetailsParam, String paramName) {
		TableOrderDetailsParam tableOrderDetailsParamSelected = null;

		for (TableOrderDetailsParam param : tableOrderDetailsParam
				.getParamDetail()) {
			if (param.getParamName().equals(paramName)) {
				tableOrderDetailsParamSelected = param;
				break;
			} else {
				tableOrderDetailsParamSelected = getTableOrderDetailsParamByName(
						param, paramName);
				if (tableOrderDetailsParamSelected != null) {
					break;
				}
			}
		}
		return tableOrderDetailsParamSelected;

	}

	/**
	 * 
	 * This method returns the TableOrderDetailParam object of given parameter
	 * name and action. It recursively searches parameter
	 * 
	 * @param tableOrderDetailsParam
	 * @param paramName
	 * @param action
	 * @return
	 */
	public static TableOrderDetailsParam getTableOrderDetailsParamByNameWithAction(
			TableOrderDetailsParam tableOrderDetailsParam, String paramName,
			String action) {
		TableOrderDetailsParam tableOrderDetailsParamSelected = null;
		if(tableOrderDetailsParam!=null){// Updated for the parent type having the same param name and action
			if(tableOrderDetailsParam.getParamName().equals(paramName) && tableOrderDetailsParam.getAction().equals(action)){
				return tableOrderDetailsParam;
			}
		}

		for (TableOrderDetailsParam param : tableOrderDetailsParam
				.getParamDetail()) {
			if (param.getParamName().equals(paramName)
					&& param.getAction().equals(action)) {
				tableOrderDetailsParamSelected = param;
				break;
			} else {
				tableOrderDetailsParamSelected = getTableOrderDetailsParamByName(
						param, paramName);
				if (tableOrderDetailsParamSelected != null) {
					break;
				}
			}
		}
		return tableOrderDetailsParamSelected;

	}

	public static TableOrderDetailsParam getByName(String name,
			TableOrderDetailsParam ebiPDList) {
		TableOrderDetailsParam pd = null;

		for (TableOrderDetailsParam param : ebiPDList.getParamDetail()) {
			if (param.getParamName().equals(name)) {
				pd = param;
				break;
			}
		}

		return pd;
	}


	public static String getCurrentTimeStamp() {
		String strDate = sdfDate.format(new Date());
		return strDate;
	}

	public static TableOrderDetailsParam getTableOrderDetaisParam(
			EntityData entityData, String paramName) {
		TableOrderDetailsParam tableOrderParam = null;
		tableOrderParam = entityData.getParamMap().get(paramName);

		/* if not found at first level , now searching at nth level */
		if (tableOrderParam == null) {
			Iterator<String> iterator = entityData.getParamMap().keySet()
					.iterator();
			while (iterator.hasNext()) {
				TableOrderDetailsParam tableOrderDetailsParamTemp = entityData
						.getParamMap().get(iterator.next());
				tableOrderParam = getTableOrderDetailsParamByName(
						tableOrderDetailsParamTemp, paramName);
				if (tableOrderParam != null) {
					break;
				}
			}
		}
		return tableOrderParam;
	}

	/**
	 * This method returns the parameter value for given param name . It looks
	 * for the parameter with in same level or at child level elements
	 * 
	 * @param entityData
	 * @param paramName
	 * @return
	 */
	public static String getTableOrderDetailsParamValue(EntityData entityData,
			String paramName) {

		String paramValue = null;
		TableOrderDetailsParam tableOrderParam = null;
		tableOrderParam = entityData.getParamMap().get(paramName);
		/* if not found at first level , now searching at nth level */
		if (tableOrderParam == null) {

			Iterator<String> iterator = entityData.getParamMap().keySet()
					.iterator();
			while (iterator.hasNext()) {
				TableOrderDetailsParam tableOrderDetailsParamTemp = entityData
						.getParamMap().get(iterator.next());
				tableOrderParam = getTableOrderDetailsParamByName(
						tableOrderDetailsParamTemp, paramName);
				if (tableOrderParam != null) {
					break;
				}
			}

		}
		if (tableOrderParam != null) {
			paramValue = tableOrderParam.getParamValue();
		}
		return paramValue;
	}

/*	public static String getTableOrderDetaisParamValueWithAction(
			EntityData entityData, String paramName, String action) {

		String paramValue = "";
		TableOrderDetailsParam tableOrderParam = null;
		if (entityData.getParamMap().get(paramName) != null && entityData.getParamMap().get(paramName).getAction().equals(action)) {
			tableOrderParam = entityData.getParamMap().get(paramName);
		}
		 if not found at first level , now searching at nth level 
		if (tableOrderParam == null) {

			Iterator<String> iterator = entityData.getParamMap().keySet()
					.iterator();
			while (iterator.hasNext()) {
				TableOrderDetailsParam tableOrderDetailsParamTemp = entityData
						.getParamMap().get(iterator.next());
				tableOrderParam = getTableOrderDetailsParamByNameWithAction(
						tableOrderDetailsParamTemp, paramName, action);
				if (tableOrderParam != null) {
					break;
				}
			}

		}
		if (tableOrderParam != null) {
			paramValue = tableOrderParam.getParamValue();
		}
		return paramValue;
	}*/
		
	public static String getTableOrderDetaisParamValueWithAction(EntityData entityData,
			String paramName, String paramActionIn) {
		TableOrderDetailsParam tableOrderParam = null;
		if (entityData.getParamMap().get(paramName) != null && entityData.getParamMap().get(paramName).getAction().equals(paramActionIn)) {
			tableOrderParam = entityData.getParamMap().get(paramName);
		}
		/* if not found at first level , now searching at map level */
		if (tableOrderParam == null) {
			Collection<TableOrderDetailsParam> tableOrderDetailsParams = entityData.getParamMap().values();
			for (TableOrderDetailsParam orderDetailsParam : tableOrderDetailsParams) {
				tableOrderParam = getTableOrderDetailsParamByNameWithAction(orderDetailsParam, paramName,
						paramActionIn);
				if (tableOrderParam != null) {
					break;
				}
			}
		}		
		if(tableOrderParam != null)
		return tableOrderParam.getParamValue();
		else {
			return "";
		}
	}
	
	public static List<TableOrderDetailsParam> searchParamListNew(EntityBatch entityBatch,
			String paramName) {
		List<TableOrderDetailsParam> paramList = null;
		Map<String, EntityData> entityMap = entityBatch.getEntity();
		for (Map.Entry<String, EntityData> entry : entityMap
				.entrySet()) {
			EntityData ed = entry.getValue();
			paramList = new ArrayList<TableOrderDetailsParam>();
			
			Collection<TableOrderDetailsParam> tableOrderDetailsParamList = ed.getNewParamDetailMap().values();// multiple vm
			for (TableOrderDetailsParam tableOrderDetailsParamItem : tableOrderDetailsParamList) {
				if ( tableOrderDetailsParamItem.getParamName() != null && tableOrderDetailsParamItem.getParamName()
						.equals(paramName)) {
					paramList.add(tableOrderDetailsParamItem);
				}else{
					paramList = getNewTableOrderDetailsParamByName(tableOrderDetailsParamItem, paramName, paramList);
				}
				
			}
		} 
		return paramList;
	}
	


	/**
	 * This method returns the param value of given parameter. If param is not
	 * found at first level , it will try to find out param at n <sb>th</sb>
	 * level
	 * 
	 * This method should not be used in bulk TN level methods.
	 * 
	 * @param entityBatch
	 * @param paramName
	 * @param paramActionIn
	 * @return TableOrderDetailsParam
	 */
	public static TableOrderDetailsParam searchParam(EntityBatch entityBatch,
			String paramName) {
		TableOrderDetailsParam param = null;
		/*
		 * Map<String, EntityBatch> map = domainServiceDTO.getEntityTypeMap();
		 * EntityBatch entityBatch = map.get("TN");
		 */
		Map<String, EntityData> entityMap = entityBatch.getEntity();
		outerloop: for (Map.Entry<String, EntityData> entry : entityMap
				.entrySet()) {// / outer param
			EntityData ed = entry.getValue();
			if (ed.getParamMap() != null) {
				if (ed.getParamMap().get(paramName) != null) {
					param = ed.getParamMap().get(paramName);
					break;
				} else {
					for (Map.Entry<String, TableOrderDetailsParam> tableOrderDetailsParam : ed
							.getParamMap().entrySet()) {
						List<TableOrderDetailsParam> tableOrderDetailsParamList = tableOrderDetailsParam
								.getValue().getParamDetail();
						for (TableOrderDetailsParam tableOrderDetailsParamItem : tableOrderDetailsParamList) {
							if (tableOrderDetailsParamItem.getParamName()
									.equals(paramName)) {
								param = tableOrderDetailsParamItem;
								break outerloop;
							}
						}
					}
				}
			}
		}
		return param;
	}

	/**
	 * This method returns the TableOrderDetailsParam
	 * 
	 * @param paramMap
	 * @param paramName
	 * @return
	 */
	public static TableOrderDetailsParam getParam(
			Map<String, TableOrderDetailsParam> paramMap, String paramName) {

		TableOrderDetailsParam tnRecordPD = paramMap.get(paramName); // getParamDetail("TNRecord");
		if (tnRecordPD == null) {
			Collection<TableOrderDetailsParam> tableOrderDetailsParams = paramMap
					.values();
			for (TableOrderDetailsParam orderDetailsParam : tableOrderDetailsParams) {
				tnRecordPD = getTableOrderDetailsParamByName(orderDetailsParam,
						paramName);
				if (tnRecordPD != null) {
					break;
				}
			}
		}
		if (tnRecordPD == null) {
			log.warn("{}  not found in order", paramName);
			return null;
		}
		return tnRecordPD;
	}

	/**
	 * This method returns the TableOrderDetailsParam for the given action
	 * 
	 * @param paramMap
	 * @param paramName
	 * @return
	 */
	public static TableOrderDetailsParam getParamWithActionForTodMap(
			Map<String, TableOrderDetailsParam> paramMap, String paramName,
			String action) {

		TableOrderDetailsParam tnRecordPD = paramMap.get(paramName); // getParamDetail("TNRecord");
		if (tnRecordPD == null) {
			Collection<TableOrderDetailsParam> tableOrderDetailsParams = paramMap
					.values();
			for (TableOrderDetailsParam orderDetailsParam : tableOrderDetailsParams) {
				tnRecordPD = getTableOrderDetailsParamByNameWithAction(
						orderDetailsParam, paramName, action);
				if (tnRecordPD != null) {
					break;
				}
			}
		}
		if (tnRecordPD == null) {
			log.warn("{}  not found in order", paramName);
			return null;
		}
		return tnRecordPD;
	}

	/***
	 * Returns a list of TableOrderDetailsParam for a given param
	 * 
	 * @param tableOrderDetailsParam
	 * @param string
	 * @return
	 */
	public static List<TableOrderDetailsParam> getChildByNameSearch(
			TableOrderDetailsParam tableOrderDetailsParam, String paramName) {

		List<TableOrderDetailsParam> listOfParams = null;

		if (tableOrderDetailsParam.getParamName() != null
				&& tableOrderDetailsParam.getParamDetail() != null) {
			listOfParams = new ArrayList<TableOrderDetailsParam>();
			log.info("Inside getChildListForParam");
			List<TableOrderDetailsParam> tableOrderDetailsParamList = tableOrderDetailsParam
					.getParamDetail();

			// traversing the child list
			for (TableOrderDetailsParam tableOrderDetailsParamChild : tableOrderDetailsParamList) {
				// For all the sub orders with the same paramName
				if (tableOrderDetailsParamChild.getParamName()
						.equals(paramName)) {
					log.info("tableOrderDetailsParamChild.getParamName() == paramName");
					listOfParams.add(tableOrderDetailsParamChild);
				}
			}

		}
		return listOfParams;
	}

	public static boolean checkForExtensionLength(String locationID,
			int extensionLength, Connection connection) throws Exception {
		boolean isLengthGreater = false;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		log.info("checkForExtensionLength In the INV Functuion && locationID===>"
				+ locationID + " extensionLength==>" + extensionLength);
		String sqlQuery = "select ext_length from   tbl_location where location_id=?";
		try {
			pstmt = connection.prepareStatement(sqlQuery);
			pstmt.setString(1, locationID);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				int extLength = rs.getInt(1);
				log.info("extLength=====>" + extLength);
				log.info("extensionLength Paramater=====>" + extensionLength);
				if (extensionLength > extLength) {
					isLengthGreater = true;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			log.info("Exception in checkForExtensionLength method"
					+ e.getMessage());
		} finally {
			if (pstmt != null)
				pstmt.close();
			if (rs != null)
				rs.close();
		}
		return isLengthGreater;
	}

	/**
	 * This method updates the values in tbl_public_tn_pool
	 * 
	 * @param tn
	 * @param publicTnPoolObj
	 * @param colTobeMod
	 * @param connection
	 * @throws Exception
	 */
	public static void updatePublicTnPoolValues(String tn,
			PublicTnPool publicTnPoolObj, List<String> colTobeMod,
			Connection connection) throws Exception {
		String updQry = "";
		StringBuffer sql = new StringBuffer();
		PreparedStatement pStmt = null;
		try {
			if (colTobeMod != null) {
				for (int i = 0; i < colTobeMod.size(); i++) {
					String colTobeModStr = colTobeMod.get(i);
					if (colTobeModStr.equalsIgnoreCase("ReplacementCli")) {
						updQry = "Replacement_Cli = '"
								+ publicTnPoolObj.getReplacementCli() + "',";
					} else if (colTobeModStr.equalsIgnoreCase("Trunk")) {
						updQry = "trunk = '" + publicTnPoolObj.getTrunk()
						+ "',";
					} else if (colTobeModStr.equalsIgnoreCase("SwitchClli")) {
						updQry = "switch_clli = '"
								+ publicTnPoolObj.getSwitchClli() + "',";
					} else if (colTobeModStr.equalsIgnoreCase("TSPCode")) {
						updQry = "tsp_code = '" + publicTnPoolObj.getTspCode()
						+ "',";
					} else if (colTobeModStr.equalsIgnoreCase("TransitionType")) {
						updQry = "transition_type = "
								+ publicTnPoolObj.getTransitionType() + ",";
					} else if (colTobeModStr.equalsIgnoreCase("PSALI")) {
						updQry = "PS_ALI = '" + publicTnPoolObj.getPsAli()
						+ "',";
					} else if (colTobeModStr.equalsIgnoreCase("VerizonBTN")) {
						updQry = "verizon_btn = '"
								+ publicTnPoolObj.getVerizonBtn() + "',";
					}
				}
			}
			if (updQry.length() > 0) {
				updQry = updQry.substring(0, updQry.length() - 1);

				sql.append(" Update tbl_public_tn_pool set ");
				sql.append(updQry);
				sql.append(" where TN = '" + tn + "' ");
			}
			log.info("SQL = [" + sql.toString() + "]");

			pStmt = connection.prepareStatement(sql.toString());
			if (null != pStmt)
				pStmt.executeUpdate();
			connection.commit();
		} catch (SQLException e) {
			log.info("ERROR: while updating the public tn pool values");
			e.printStackTrace();
		} finally {
			if (pStmt != null)
				pStmt.close();
		}

	}

	public static void deleteRollBackSubscriber(String subscriberId,
			Connection connection) throws Exception {
		log.debug("Enter deleteRollBackSubscriber method===>" + subscriberId);
		PreparedStatement pstmt = null;
		String sqlQuery = "delete from tbl_subscriber where sub_id=?";
		try {
			pstmt = connection.prepareStatement(sqlQuery);
			pstmt.setString(1, subscriberId);
			pstmt.executeUpdate();
			connection.commit();
		} catch (Exception e) {
			connection.rollback();
			// e.printStackTrace();
			log.error("Exception in deleteRollBackSubscriber is====>" + e);
			log.error("Exception in deleteRollBackSubscriber is====>"
					+ e.getMessage());
		} finally {
			if (pstmt != null)
				pstmt.close();
		}

		log.debug("Exit deleteRollBackSubscriber method===>" + subscriberId);
	}
	
	public static List<FeaturesBean> getBillableFeaturesForFmcg(
			EntityData entityData, String action, Connection connection) {
		log.debug("getBillableFeatures for  action code <" + action + ">");
		List<FeaturesBean> locationFeatures = new ArrayList<FeaturesBean>();

		try {
			if (ActionFunctionHelper.getTableOrderDetaisParam(entityData,
					"NonPkgFeatures") != null) {
				TableOrderDetailsParam pd = ActionFunctionHelper
						.getTableOrderDetaisParam(entityData,
								"NonPkgFeatures");

				log.debug("Found Billabale Features <"
						+ pd.getParamDetail().size() + ">");

				List<TableOrderDetailsParam> pdList = ActionFunctionHelper
						.getChildByNameSearch(pd, "NonPkgFeature");

				log.debug("Found Billabale Features <" + pdList.size() + ">");

				for (TableOrderDetailsParam tmp : pdList) {
					if (!tmp.getAction().equals(action))
						continue;

					String featureName = tmp.getParamValue();
					// retrieve the corresponding FeatureId
					// SELECT FEATURE_ID FROM TBL_VZB_FEATURES WHERE NAME='Auto
					// Attendant'
					log.debug("Querying Feature " + featureName);
					FeaturesBean fb = null;

					TblVzbFeaturesQuery vzbFeats = new TblVzbFeaturesQuery();
					vzbFeats.whereDescriptionLike(featureName);
					vzbFeats.query(connection);
					ArrayList<?> resultSet = vzbFeats.getResultArrayList();
					log.debug("vzbfeatures for featurename:<" + featureName
							+ "> size <" + vzbFeats.size());

					if (vzbFeats.size() > 0) {
						TblVzbFeaturesDbBean vzbFeatDbBean = (TblVzbFeaturesDbBean) resultSet
								.get(0);
						int featureId = vzbFeatDbBean.getFeatureId();
						log.debug("FeatureID <" + featureId
								+ "> in tbl_vzb_features");

						fb = new FeaturesBean();
						fb.getFeaturesDbBean().setName(featureName);
						fb.getFeaturesDbBean().setFeatureId(featureId);
						locationFeatures.add(fb);
					} else {
						log.debug("Unkown Feature " + featureName);
						continue;
					}
				}
				log.debug("found Billable Features: " + locationFeatures.size());
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return locationFeatures;

	}

	public static List<FeaturesBean> getBillableFeaturesForFmcg(
			EntityBatch entityBatch, String action, Connection connection) {
		log.debug("getBillableFeatures for  action code <" + action + ">");
		List<FeaturesBean> locationFeatures = new ArrayList<FeaturesBean>();

		try {
			if (ActionFunctionHelper.getTableOrderDetailsParam(entityBatch,
					"NonPkgFeatures") != null) {
				TableOrderDetailsParam pd = ActionFunctionHelper
						.getTableOrderDetailsParam(entityBatch,
								"NonPkgFeatures");

				log.debug("Found Billabale Features <"
						+ pd.getParamDetail().size() + ">");

				List<TableOrderDetailsParam> pdList = ActionFunctionHelper
						.getChildByNameSearch(pd, "NonPkgFeature");

				log.debug("Found Billabale Features <" + pdList.size() + ">");

				for (TableOrderDetailsParam tmp : pdList) {
					if (!tmp.getAction().equals(action))
						continue;

					String featureName = tmp.getParamValue();
					// retrieve the corresponding FeatureId
					// SELECT FEATURE_ID FROM TBL_VZB_FEATURES WHERE NAME='Auto
					// Attendant'
					log.debug("Querying Feature " + featureName);
					FeaturesBean fb = null;

					TblVzbFeaturesQuery vzbFeats = new TblVzbFeaturesQuery();
					vzbFeats.whereDescriptionLike(featureName);
					vzbFeats.query(connection);
					ArrayList<?> resultSet = vzbFeats.getResultArrayList();
					log.debug("vzbfeatures for featurename:<" + featureName
							+ "> size <" + vzbFeats.size());

					if (vzbFeats.size() > 0) {
						TblVzbFeaturesDbBean vzbFeatDbBean = (TblVzbFeaturesDbBean) resultSet
								.get(0);
						int featureId = vzbFeatDbBean.getFeatureId();
						log.debug("FeatureID <" + featureId
								+ "> in tbl_vzb_features");

						fb = new FeaturesBean();
						fb.getFeaturesDbBean().setName(featureName);
						fb.getFeaturesDbBean().setFeatureId(featureId);
						locationFeatures.add(fb);
					} else {
						log.debug("Unkown Feature " + featureName);
						continue;
					}
				}
				log.debug("found Billable Features: " + locationFeatures.size());
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return locationFeatures;

	}

	public static List<SubscriberDeviceBean> getSubDeviceList(String action,
			EntityBatch entityBatch, Connection connection) throws Exception {
		List<SubscriberDeviceBean> subDevBeanList = new ArrayList<SubscriberDeviceBean>();
		String locationId = null;
		try {
			if (null != ActionFunctionHelper.getLocationId(entityBatch)) {
				locationId = ActionFunctionHelper.getLocationId(entityBatch);
			}

			if (ActionFunctionHelper.getTableOrderDetailsParam(entityBatch,
					"Device") != null) {
				List<TableOrderDetailsParam> pdList = ActionFunctionHelper
						.getChildByNameSearch(ActionFunctionHelper
								.getTableOrderDetailsParam(entityBatch,
										"Device"), "Device");
				for (TableOrderDetailsParam tmp : pdList) {
					if (!tmp.getAction().equals(action))
						continue;

					SubscriberDevice subscriberDeviceObj = new SubscriberDevice(
							connection);
					String deviceType = new String("");

					if (!(ActionFunctionHelper.getTableOrderDetailsParam(
							entityBatch, "DeviceType") == null))
						deviceType = ActionFunctionHelper
						.getTableOrderDetailsParam(entityBatch,
								"DeviceType").getParamValue();

					if (!(ActionFunctionHelper.getTableOrderDetailsParam(
							entityBatch, "SubscriberId") == null))
						subscriberDeviceObj.setSubId(ActionFunctionHelper
								.getTableOrderDetailsParam(entityBatch,
										"SubscriberId").getParamValue());

					if (!(ActionFunctionHelper.getTableOrderDetailsParam(
							entityBatch, "DeviceMapId") == null)
							&& !(ActionFunctionHelper
									.getTableOrderDetailsParam(entityBatch,
											"DeviceSeqId").getParamValue()
									.equals("")))
						subscriberDeviceObj
						.setDeviceMapId(Long
								.valueOf(ActionFunctionHelper
										.getTableOrderDetailsParam(
												entityBatch,
												"DeviceMapId")
										.getParamValue()));

					if ((ActionFunctionHelper.getTableOrderDetailsParam(
							entityBatch, "DeviceSeqId") != null && !((ActionFunctionHelper
									.getTableOrderDetailsParam(entityBatch,
											"DeviceSeqId"))).getParamValue().equals(""))
							&& deviceType.equals("SIP_DEVICE"))
						subscriberDeviceObj
						.setSipDeviceId(Long
								.valueOf(ActionFunctionHelper
										.getTableOrderDetailsParam(
												entityBatch,
												"DeviceSeqId")
										.getParamValue()));
					else if (!(ActionFunctionHelper.getTableOrderDetailsParam(
							entityBatch, "DeviceSeqId") == null)
							&& !(ActionFunctionHelper
									.getTableOrderDetailsParam(entityBatch,
											"DeviceSeqId").getParamValue()
									.equals("")))
						subscriberDeviceObj
						.setGatewayDeviceId(Long
								.valueOf(ActionFunctionHelper
										.getTableOrderDetailsParam(
												entityBatch,
												"DeviceSeqId")
										.getParamValue()));

					if (!(ActionFunctionHelper.getTableOrderDetailsParam(
							entityBatch, "OriginatingSystem") == null)) {
						subscriberDeviceObj.setCreatedBy(ActionFunctionHelper
								.getTableOrderDetailsParam(entityBatch,
										"OriginatingSystem").getParamValue());
						subscriberDeviceObj.setModifiedBy(ActionFunctionHelper
								.getTableOrderDetailsParam(entityBatch,
										"OriginatingSystem").getParamValue());
					} else {
						subscriberDeviceObj.setModifiedBy("SYSTEM");
						subscriberDeviceObj.setCreatedBy("SYSTEM");
					}

					if (ActionFunctionHelper.getParamValueWithAction(
							entityBatch, "LinePort", "n") != null) {
						String lineport = ActionFunctionHelper
								.getParamValueWithAction(entityBatch,
										"LinePort", "n");
						isLinePortUsedBySub(lineport, locationId, "HIPC",
								connection);
						subscriberDeviceObj.setLinePort(lineport);
					} else if (action.equals("n")) {
						// insertOrderLog(LOG_TYPE_FAIL,
						// "LinePort not found on the  order ");
						// insertOrderLog("LinePort not found on the  order ");
						throw new Exception("ESP_VZB_INV_SUB_LINPORT_NOT_FOUND");
					}

					// subscriberDeviceObj.setLineKey(1);
					if (!(ActionFunctionHelper.getParamValueWithAction(
							entityBatch, "LineKeys", "n") == null)
							&& !(ActionFunctionHelper.getParamValueWithAction(
									entityBatch, "LineKeys", "n") == null)
							&& !(ActionFunctionHelper.getParamValueWithAction(
									entityBatch, "LineKeys", "n").equals("")))
						subscriberDeviceObj.setLineKey(Long
								.valueOf(ActionFunctionHelper
										.getParamValueWithAction(entityBatch,
												"LineKeys", "n")));
					else if (!(ActionFunctionHelper.getParamValueWithAction(
							entityBatch, "LineKeys", "r") == null)
							&& !(ActionFunctionHelper.getParamValueWithAction(
									entityBatch, "LineKeys", "r") == null)
							&& !(ActionFunctionHelper.getParamValueWithAction(
									entityBatch, "LineKeys", "r").equals("")))
						subscriberDeviceObj.setLineKey(Long
								.valueOf(ActionFunctionHelper
										.getParamValueWithAction(entityBatch,
												"LineKeys", "r")));

					// subscriberDeviceObj.setCallsPerLine(1);
					if (!(ActionFunctionHelper.getParamValueWithAction(
							entityBatch, "CallsPerLine", "n") == null)
							&& !(ActionFunctionHelper.getParamValueWithAction(
									entityBatch, "CallsPerLine", "n") == null)
							&& !(ActionFunctionHelper.getParamValueWithAction(
									entityBatch, "CallsPerLine", "n")
									.equals("")))
						subscriberDeviceObj.setCallsPerLine(Long
								.valueOf(ActionFunctionHelper
										.getParamValueWithAction(entityBatch,
												"CallsPerLine", "n")));
					else if (!(ActionFunctionHelper.getParamValueWithAction(
							entityBatch, "CallsPerLine", "r") == null)
							&& !(ActionFunctionHelper.getParamValueWithAction(
									entityBatch, "CallsPerLine", "r") == null)
							&& !(ActionFunctionHelper.getParamValueWithAction(
									entityBatch, "CallsPerLine", "r")
									.equals("")))
						subscriberDeviceObj.setCallsPerLine(Long
								.valueOf(ActionFunctionHelper
										.getParamValueWithAction(entityBatch,
												"CallsPerLine", "r")));

					// subscriberDeviceObj.setPortNum(1);
					// subscriberDeviceObj.setScaLineLabel("");

					log.info("SCA Value is ===== "
							+ ActionFunctionHelper.getTableOrderDetailsParam(
									entityBatch, "SCA"));
					log.info("Level Value is ===== "
							+ ActionFunctionHelper.getTableOrderDetailsParam(
									entityBatch, "Label"));
					log.info("AuthUserID Value is ===== "
							+ ActionFunctionHelper.getTableOrderDetailsParam(
									entityBatch, "AuthUserID"));
					log.info("Level Value is ===== "
							+ ActionFunctionHelper.getTableOrderDetailsParam(
									entityBatch, "Label"));

					if (!(ActionFunctionHelper.getTableOrderDetailsParam(
							entityBatch, "SCA") == null))
						subscriberDeviceObj.setScaType(ActionFunctionHelper
								.getTableOrderDetailsParam(entityBatch, "SCA")
								.getParamValue());

					if (!(ActionFunctionHelper.getTableOrderDetailsParam(
							entityBatch, "Label") == null)) {
						if (action == "c"
								&& ActionFunctionHelper
								.getTableOrderDetailsParam(entityBatch,
										"Label").getParamValue() == null) {
							subscriberDeviceObj.setScaLineLabel("");
						} else {
							subscriberDeviceObj
							.setScaLineLabel(ActionFunctionHelper
									.getTableOrderDetailsParam(
											entityBatch, "Label")
									.getParamValue());
						}
					}
					int endPointCount = ActionFunctionHelper
							.getIntValueFromOrderParams(entityBatch,
									"EndPointType");

					if (endPointCount == 2
							&& ((ActionFunctionHelper.getParamValueWithAction(
									entityBatch, "EndPointType", "n"))) != null
									&& ((ActionFunctionHelper.getParamValueWithAction(
											entityBatch, "EndPointType", "o"))) != null
											&& ((ActionFunctionHelper.getParamValueWithAction(
													entityBatch, "EndPointType", "n")))
											.equalsIgnoreCase("PRIMARY")
											&& ((ActionFunctionHelper.getParamValueWithAction(
													entityBatch, "EndPointType", "o")))
											.equalsIgnoreCase("SCA")) {
						subscriberDeviceObj.setScaLineLabel("");
					}

					// if (!( tmp.getByNameSearch("Address ") == null ))
					// subscriberDeviceObj.setScaType(tmp.getByNameSearch("Address ").getParamValue());

					if (!(ActionFunctionHelper.getTableOrderDetailsParam(
							entityBatch, "AuthUserID") == null))
						subscriberDeviceObj
						.setScaAuthUserid(ActionFunctionHelper
								.getTableOrderDetailsParam(entityBatch,
										"AuthUserID").getParamValue());

					// subscriberDeviceObj.setScaAuthUserid("")

					if (!(ActionFunctionHelper.getTableOrderDetailsParam(
							entityBatch, "BLFAttendantReqNum") == null)
							&& !(ActionFunctionHelper
									.getTableOrderDetailsParam(entityBatch,
											"BLFAttendantReqNum")
									.getParamValue() == null)
							&& !(ActionFunctionHelper
									.getTableOrderDetailsParam(entityBatch,
											"BLFAttendantReqNum")
									.getParamValue().equals("")))
						subscriberDeviceObj.setBlfAttdntRegline(Integer
								.parseInt(ActionFunctionHelper
										.getTableOrderDetailsParam(entityBatch,
												"BLFAttendantReqNum")
										.getParamValue()));

					if (!(ActionFunctionHelper.getTableOrderDetailsParam(
							entityBatch, "BlfURL") == null))
						subscriberDeviceObj.setBlfUrl(ActionFunctionHelper
								.getTableOrderDetailsParam(entityBatch,
										"BlfURL").getParamValue());

					subDevBeanList.add(subscriberDeviceObj);
				}// for
			}// if
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}

		return subDevBeanList;
	}

	public static boolean isLinePortUsedBySub(String linePort,
			String locationId, String service, Connection connection)
					throws Exception, SQLException {
		boolean isExists = false;
		PreparedStatement pStmt = null;
		ResultSet rs = null;
		String linePortSql = null;

		if (!(service.equalsIgnoreCase("HIPC")
				|| service.equalsIgnoreCase("PBX/KEY") || service
				.equalsIgnoreCase("PILOT"))) {
			throw new Exception("Invalid service passed to lineport validation");
		}

		if (service.equalsIgnoreCase("HIPC")) {

			linePortSql = " select sd.sub_id sub_id, l.location_id from tbl_subscriber_device sd, TBL_DEVICE_MAP dm, tbl_location l "
					+ " where l.sip_domain in ( select sip_domain from tbl_location where location_id = ? ) "
					+ " and dm.location_id = l.location_id "
					+ " and sd.device_map_id = dm.device_map_id "
					+ " and sd.line_port = ? ";
		} else if (service.equalsIgnoreCase("PBX/KEY")) {

			linePortSql = " select gt.group_id sub_id, l.location_id from tbl_location l, tbl_group g , tbl_group_tn gt "
					+ " where l.sip_domain in (select sip_domain from tbl_location where location_id = ? ) "
					+ " and g.location_id = l.location_id "
					+ " and gt.group_id = g.group_id "
					+ " and gt.line_port = ?  ";

		} else if (service.equalsIgnoreCase("PILOT")) {

			linePortSql = " select  g.group_id sub_id, l.location_id from tbl_location l, tbl_group g "
					+ " where l.sip_domain in (select sip_domain from tbl_location where location_id = ? ) "
					+ " and g.location_id = l.location_id "
					+ " and g.line_port =  ? ";
		}

		try {
			pStmt = connection.prepareStatement(linePortSql);
			log.info("LocationId" + locationId);
			log.info("LinePort" + linePort);
			log.info("Sql" + linePortSql);
			if (pStmt != null) {
				pStmt.setString(1, locationId);
				pStmt.setString(2, linePort);
				rs = pStmt.executeQuery();
				if (rs.next()) {
					isExists = true;
					log.info("LinePort <" + linePort
							+ "> Already in Use by SUB/GROUP <"
							+ rs.getString("sub_id") + " And locationId :"
							+ rs.getString("location_id") + ">");
					String TN = getGrpTN(rs.getString("sub_id"), linePort,
							connection);

					if (service.equalsIgnoreCase("HIPC")) {

						boolean isExtn = isSubExtnOnly(rs.getString("sub_id"),
								connection);
						if (isExtn) {
							TN = getExtnFromTblSubscriber(
									rs.getString("sub_id"), connection);
						} else {
							TN = getUserIdFromTblSubscriberTn(
									rs.getString("sub_id"), connection);
						}
					}

					throw new Exception(
							"ESP_VZB_INV_LINEPORT_ALRDY_IN_USE_BY_DIFF_SUB, LinePort "
									+ linePort + " already in Use by TN/Extn "
									+ TN + " and locationId "
									+ rs.getString("location_id"));
				}
			}

		} catch (SQLException e) {
			e.printStackTrace();
			log.info("ERROR: Exception caught while trying to query tbl_subscriber_device/tbl_group");
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (pStmt != null) {
					pStmt.close();
				}
			} catch (SQLException e) {
				throw new Exception(
						"Exception caught while closing result set/prepared statement");
			}
		}
		return isExists;
	}

	public static boolean isSubExtnOnly(String subId, Connection connection)
			throws Exception {
		PreparedStatement cntPstmt = null;
		ResultSet cntRs = null;

		StringBuffer extnSubCntSql = new StringBuffer();
		try {
			extnSubCntSql
			.append("select count(*) from tbl_subscriber sub, tbl_subscriber_tn stn where "
					+ "sub.sub_id = stn.sub_id and stn.nat_user_id = 1 and stn.sub_id = ?");
			cntPstmt = connection.prepareStatement(extnSubCntSql.toString());
			cntPstmt.setString(1, subId);
			if (null != cntPstmt)
				cntRs = cntPstmt.executeQuery();
			if (cntRs.next()) {
				if (cntRs.getInt(1) == 0) {
					log.info("cnt is 0 so extn only subscriber :: " + subId);
					return true;
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (cntRs != null) {
				cntRs.close();
			}
			if (cntPstmt != null) {
				cntPstmt.close();
			}
		}
		return false;
	}

	public static String getExtnFromTblSubscriber(String subId,
			Connection connection) throws Exception {
		PreparedStatement pStmt = null;
		ResultSet rs = null;
		String Sql = null;

		Sql = "select extension from tbl_subscriber where sub_id='" + subId
				+ "'";
		String extn = null;

		try {
			pStmt = connection.prepareStatement(Sql);

			log.info("Sql" + Sql);

			rs = pStmt.executeQuery();

			if (rs.next()) {
				extn = rs.getString("EXTENSION");
			}

		} catch (SQLException e) {

			e.printStackTrace();
			log.info("ERROR: Exception caught while trying to query tbl_subscriber_tn");
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (pStmt != null) {
					pStmt.close();
				}
			} catch (SQLException e) {
				throw new Exception(
						"Exception caught while closing result set/prepared statement");
			}
		}

		return extn;
	}

	public static String getUserIdFromTblSubscriberTn(String subId,
			Connection connection) throws Exception {
		PreparedStatement pStmt = null;
		ResultSet rs = null;
		String Sql = null;

		Sql = "select user_id from tbl_subscriber_tn where sub_id='" + subId
				+ "' and NAT_USER_ID=1";
		String userId = null;

		try {
			pStmt = connection.prepareStatement(Sql);

			log.info("Sql" + Sql);

			rs = pStmt.executeQuery();

			if (rs.next()) {
				userId = rs.getString("USER_ID");
			}

		} catch (SQLException e) {

			e.printStackTrace();
			log.info("ERROR: Exception caught while trying to query tbl_subscriber_tn");
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (pStmt != null) {
					pStmt.close();
				}
			} catch (SQLException e) {
				throw new Exception(
						"Exception caught while closing result set/prepared statement");
			}
		}

		return userId;

	}

	public static String getGrpTN(String groupId, String linePort,
			Connection connection) throws Exception {
		String lsTN = null;
		TblPublicTnPoolDbBean publicTnPoolDbBean = new TblPublicTnPoolDbBean();
		ArrayList<TblPublicTnPoolDbBean> resultList = null;
		try {
			TblGroupTnQuery groupTnQuery = new TblGroupTnQuery();
			groupTnQuery.whereGroupIdEQ(Long.parseLong(groupId));
			groupTnQuery.whereLinePortEQ(linePort);
			groupTnQuery.query(connection);
			if (groupTnQuery.size() > 0) {
				int tnPoolId = (int) groupTnQuery.getDbBean(0).getTnPoolId();
				TblPublicTnPoolQuery tnQry = new TblPublicTnPoolQuery();
				tnQry.whereTnPoolIdEQ(tnPoolId);
				tnQry.query(connection);
				resultList = tnQry.getResultArrayList();
			}

			if (resultList != null && resultList.size() > 0) {
				publicTnPoolDbBean = (TblPublicTnPoolDbBean) resultList.get(0);
				lsTN = publicTnPoolDbBean.getTn();
			}
		} catch (SQLException e) {
			e.printStackTrace();
			log.info("ERROR: Exception caught while trying to query tbl_group_tn");
		}
		return lsTN;
	}

	/**
	 * TODO Need to revisit 
	 * 
	 * @param action
	 * @param groupTnExclFeat
	 * @param entityData
	 * @param connection
	 * @return
	 */
	public static List<FeaturesBean> getxcludedFeaturesList(String action,
			boolean groupTnExclFeat, EntityData entityData,
			Connection connection) {
		List<FeaturesBean> excludedFeaturesList = new ArrayList<FeaturesBean>();

		try {
			List<TableOrderDetailsParam> exclFeatParamList = new ArrayList<TableOrderDetailsParam>();
			exclFeatParamList = searchParamListNew(entityData,"DisableFeatureList");
			for (TableOrderDetailsParam disParamDtl : exclFeatParamList) {
				if (groupTnExclFeat && disParamDtl.getParentId() != null)
					continue;
				List<TableOrderDetailsParam> pdList = ActionFunctionHelper
						.getNewTableOrderDetailsParamByName(disParamDtl,
								"Feature",
								new ArrayList<TableOrderDetailsParam>());

				for (TableOrderDetailsParam tmp : pdList) {
					if (!tmp.getAction().equals(action))
						continue;

					String featureName = tmp.getParamValue();
					// retrieve the corresponding FeatureId
					// SELECT FEATURE_ID FROM TBL_VZB_FEATURES WHERE NAME='Auto
					// Attendant'
					log.info("VZB_INV_ADD_FEATURE_PKG: Querying Feature "
							+ featureName);
					FeaturesBean fb = null;

					TblVzbFeaturesQuery vzbFeats = new TblVzbFeaturesQuery();
					vzbFeats.whereNameLike(featureName);
					vzbFeats.query(connection);
					ArrayList<?> resultSet = vzbFeats.getResultArrayList();
					log.info("VZB_INV_ADD_FEATURE_PKG: vzbfeatures for featurename: {}, size{}"
							, featureName , vzbFeats.size());

					if (vzbFeats.size() > 0) {
						TblVzbFeaturesDbBean vzbFeatDbBean = (TblVzbFeaturesDbBean) resultSet
								.get(0);
						int featureId = vzbFeatDbBean.getFeatureId();
						log.info("VZB_INV_ADD_FEATURE_PKG: FeatureID"
								+ featureId + " in tbl_vzb_features");

						fb = new FeaturesBean();
						fb.getFeaturesDbBean().setName(featureName);
						fb.getFeaturesDbBean().setFeatureId(featureId);
						excludedFeaturesList.add(fb);
					} else {
						log.info("VZB_INV_ADD_FEATURE_PKG: Unkown Feature "
								+ featureName);
						continue;
					}
				}
				log.info("found xcluded Features: "
						+ excludedFeaturesList.size());
			}
		} catch (Exception e) {
			log.error("Error while pulling feature pkg list ",e);
		}

		return excludedFeaturesList;

	}

	/**
	 * @param subscriberId
	 * @param connection
	 * @throws Exception
	 */
	public static void updateSubscriberType(String subscriberId,
			Connection connection) throws Exception {
		log.info("Enter updateSubscriberType method===>" + subscriberId);
		PreparedStatement pstmt = null;
		String sqlQuery = "update tbl_subscriber set subscriber_type="
				+ VzbVoipEnum.FmcgSubscriberType.NONE + " where sub_id=?";
		try {
			pstmt = connection.prepareStatement(sqlQuery);
			pstmt.setString(1, subscriberId);
			pstmt.executeUpdate();
			connection.commit();
		} catch (Exception e) {
			connection.rollback();
			e.printStackTrace();
			log.info("Exception in updateSubscriberType is====>"
					+ e.getMessage());
		} finally {
			if (pstmt != null)
				pstmt.close();
		}

		log.info("Exit updateSubscriberType method===>" + subscriberId);
	}

	public static TblLocationDbBean getLocationForLocationId(String locationId,Connection connection) throws SQLException {
		TblLocationDbBean locationDbBean = new TblLocationDbBean();
		ArrayList<TblLocationDbBean> resultList = null;
		try {
			TblLocationQuery locationQuery = new TblLocationQuery();
			locationQuery.whereLocationIdEQ(locationId);
			locationQuery.query(connection);

			resultList = locationQuery.getResultArrayList();
			if (resultList.size() > 0) {
				locationDbBean = (TblLocationDbBean) resultList.get(0);
			}
		} catch (SQLException e) {
			e.printStackTrace();
			log.info("ERROR: Exception caught while trying to get rpid from tbl_location");
		}
		return locationDbBean;

	}


	public static void removeTriByTn(PublicTnPool pubTnBeanObj,Connection connection) throws SQLException, Exception {
		log.info("Entering removeTriByTn");
		TblLocationDbBean locationDbBean = getLocationForLocationId(pubTnBeanObj.getLocationId(),connection);
		long dialPlanId = locationDbBean.getDialPlanId();
		pubTnBeanObj.setDialPlanId(dialPlanId);

		TsoEtTn etTnObj = new TsoEtTn(connection);
		TblTriTnData triDataBean = new TblTriTnData();
		triDataBean.setDialPlanId(pubTnBeanObj.getDialPlanId());
		triDataBean.setTn(pubTnBeanObj.getTn());
		triDataBean.setEnvOrderId(pubTnBeanObj.getEnvOrderId());
		triDataBean.setLocationId(pubTnBeanObj.getLocationId());

		if (pubTnBeanObj.getTnPoolId() > 0) {
			log.info("Retrieved TN Pool Id[" + pubTnBeanObj.getTnPoolId() + "]");
			TblPublicTnPoolQuery pubTnQry = new TblPublicTnPoolQuery();
			pubTnQry.whereTnPoolIdEQ(pubTnBeanObj.getTnPoolId());
			pubTnQry.query(connection);
			if (pubTnQry.size() > 0) {
				pubTnBeanObj.setRangeStart(pubTnQry.getDbBean(0).getTn());
				pubTnBeanObj.setRangeEnd(pubTnQry.getDbBean(0).getTn());
				//						splitTerminatingRouting(pubTnBeanObj);
				etTnObj.deleteTri(triDataBean);
				etTnObj.consolidateTriInfo(triDataBean);
				log.info("Removing TRI for Port Pending (PP) TN.");
			}
		} else if (pubTnBeanObj.getTn() != null && !(pubTnBeanObj.getTn()).equals("")) {
			log.info("Retrieved TN[" + pubTnBeanObj.getTn() + "]");
			pubTnBeanObj.setTn(pubTnBeanObj.getTn());
			pubTnBeanObj.setRangeStart(pubTnBeanObj.getTn());
			pubTnBeanObj.setRangeEnd(pubTnBeanObj.getTn());
			//					splitTerminatingRouting(pubTnBeanObj);
			etTnObj.deleteTri(triDataBean);
			etTnObj.consolidateTriInfo(triDataBean);
			log.info("Removing TRI for Port Pending TN.");
		} else {
			log.info("TN Pool id/Tn not found in the order");
			throw new VzbInvException("ESP_VZB_INV_TN_POOLID_NOT_FOUND", "ESP_VZB_INV_TN_POOLID_NOT_FOUND");
		}
	}
	
	/*********************************************************************/
	public static int getDaylightSavingsRegionId(Connection connection,String TimeZone) throws SQLException {
		int daylight_saving_region_id = 0;
		try {
			TblDaylightSavingRegionsQuery daylightSavingRegionsQuery = new TblDaylightSavingRegionsQuery();
			daylightSavingRegionsQuery.whereDaylightSavingRegionsIdEQ(Integer
					.parseInt(TimeZone));
			// daylightSavingRegionsQuery.whereDescriptionEQ(TimeZone);
			daylightSavingRegionsQuery.query(connection);
			ArrayList resultList = daylightSavingRegionsQuery.getResultArrayList();
			if (resultList.size() > 0) {
				TblDaylightSavingRegionsDbBean tblDaylightSavingRegionsBean = (TblDaylightSavingRegionsDbBean) resultList
				.get(0);
				daylight_saving_region_id = tblDaylightSavingRegionsBean
				.getDaylightSavingRegionsId();
			}
		} catch (SQLException e) {
			log.error("ERROR: get DAYLIGHT_SAVING_REGIONS_ID from tbl_daylight_saving_regions");
			e.printStackTrace();
		}
		return daylight_saving_region_id;
	}
	

	public static TblEnterpriseDbBean getEnterpriseForEnterpriseId(Connection connection,String enterpriseId)
			throws SQLException {
				log.info("In getTblEnterpriseListForEnterpriseId()");
				ArrayList<TblEnterpriseDbBean> resultList = null;
				TblEnterpriseDbBean enterpriseDbBean = null;
				try {
					TblEnterpriseQuery enterpriseQuery = new TblEnterpriseQuery();
					enterpriseQuery.whereEnterpriseIdEQ(enterpriseId);
					enterpriseQuery.query(connection);

					resultList = enterpriseQuery.getResultArrayList();
					if (resultList.size() > 0) {
						enterpriseDbBean = (TblEnterpriseDbBean) resultList.get(0);
					}
				} catch (SQLException e) {
					e.printStackTrace();
					log.error("ERROR: Exception caught while trying to get platform_indicator from tbl_enterprise");
				}
				return enterpriseDbBean;
			}
	
	public static int getKeyTnSequence(long groupId, EntityData entityData, Connection connection) throws Exception {
		int sequenceNo = 1;

		String suppType = new String("");
		String minorOrderType = new String("");

		if (!((getTableOrderDetailsParamValue(entityData, "MinorOrderType")) == null))
			minorOrderType = (getTableOrderDetailsParamValue(entityData, "MinorOrderType"));

		if (!((getTableOrderDetailsParamValue(entityData, "SUPP")) == null))
			suppType = getTableOrderDetailsParamValue(entityData, "SUPP");

		if (!suppType.equals("Y")) {
			if (minorOrderType.equals("INSTALL")) {
				if (!(getTableOrderDetailsParamValue(entityData, "SequenceNo") == null))
					sequenceNo = Integer.parseInt(getTableOrderDetailsParamValue(entityData, "SequenceNo"));
				else
					sequenceNo = getNextKeyTnSequence(groupId, connection);
			} else {
				sequenceNo = getNextKeyTnSequence(groupId, connection);
				// adjustLastKeyTnSequence(sequenceNo, groupId);
			}
		} else {

			sequenceNo = getNextKeyTnSequence(groupId, connection);
			// adjustLastKeyTnSequence(sequenceNo, groupId);

		}

		log.info("setting KEY TN Sequence to - <" + sequenceNo + ">");

		return sequenceNo;
	}

	public static int getNextKeyTnSequence(long groupId, Connection connection) throws Exception {
		int sequenceNo = 1;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		StringBuffer sql = new StringBuffer();

		sql.append(" select max(sequence_no) from tbl_group_tn where group_id = ? ");
		try {
			pstmt = connection.prepareStatement(sql.toString());
			pstmt.setLong(1, groupId);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				sequenceNo = rs.getInt(1);
			}

		} catch (Exception e) {
			e.printStackTrace();
			sequenceNo = 1;
		} finally {
			if (null != rs)
				rs.close();
			if (null != pstmt)
				pstmt.close();
		}

		log.info("getNextKeyTnSequence - <" + sequenceNo + ">");
		return sequenceNo;
	}

	public static void insLinePortToTblOrderDetails(String linePort, String action, TableOrderDetailsParam ebiPDList,
			Connection connection) throws Exception, SQLException {

		TableOrderDetailsParam pd = null;
		long parentId = 0;

		// check params vector if not found
		for (TableOrderDetailsParam param : ebiPDList.getParamDetail()) {
			if (param.getParamName().equals(action)) {
				pd = param;
				continue;
			}

			long order_id = 0;
			Long orderDetailId = insertTblOrderDetails(order_id, parentId, "LinePort", linePort, connection);

			log.info("Inserted  LinePort <" + linePort + "> with order detail id <" + orderDetailId + ">");
		}
	}

	public static long insertTblOrderDetails(long orderId, long parentId, String paramName, String paramValue,
			Connection connection) throws Exception {
		log.info("Start insertTblOrderDetails()");
		long orderDetailsId = -1;
		try {
			DBTblOrderDetails attrib = new DBTblOrderDetails();
			// The C++ code generated (that is used by translator) uses
			// order_detail_id_seq
			// while the java code generated tbl_order_details_id_seq.
			// here we need to use a direct jdbc query to get the value from
			// order_detail_id_seq
			// so that the order_details_id maintains the correct order.
			// orderDetailsId = DBUtils.getOrderDetailsIdFromSeq(connection);
			attrib.setOrderDetailId(orderDetailsId);
			attrib.setOrderId((int) orderId);
			// attrib.setSkipSeq();
			attrib.setDataType(2);
			attrib.setSeqNo(0);
			// attrib.setSeqNo(Integer.parseInt(getParam("SEQNO")));
			attrib.setParamType("C");
			attrib.setAction("n");
			attrib.setParamName(paramName);
			attrib.setParamValue(paramValue);
			attrib.setParentId(parentId);
			attrib.setFlowStatus(0);
			attrib.setLeaf(1);
			attrib.insert(connection);
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Unable to add entry to TblOrderDetails");
		} finally {
			try {
				if (connection != null)
					connection.commit();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return orderDetailsId;
	}

	public static String getLinePort(String tn, int linePortLength) throws Exception {
		String linePort = "";

		if (linePortLength < tn.length()) {
			linePort = tn.substring(tn.length() - linePortLength);
		} else {
			String zeroPadding = "";
			int lengthDiff = linePortLength - tn.length();

			for (int i = 0; i < lengthDiff; i++) {
				zeroPadding = "0" + zeroPadding;
			}
			linePort = zeroPadding + tn;
		}

		log.info("Line Port = " + linePort);
		return linePort;
	}

			private static void dummyUpdateEnterprise(String entid, Connection connection) throws SQLException {
				log.info("Inside dummyUpdateEnterprise(). Trying to get lock on records.");

				DBTblEnterprise entDb = new DBTblEnterprise();
				entDb.whereEnterpriseIdEQ(entid);
				entDb.setModifiedBy("ESAP_INV");
				int count = entDb.updateSpByWhere(connection);
				log.info("Successfully locked {} location record in ESAP by dummy update." , count);
			}
			
			private static void dummyUpdateLocation(String locid, Connection connection) throws SQLException {
				log.info("Inside dummyUpdateLocation(). Trying to get lock on records.");

				DBTblLocation locDb = new DBTblLocation();
				locDb.whereLocationIdEQ(locid);
				locDb.setModifiedBy("ESAP_INV");
				int count = locDb.updateSpByWhere(connection);
				log.info("Successfully locked {} location record in ESAP by dummy update." ,count);
			}
			
			public static void updateEntAndLocCcl(ConfigDomainDataServiceImpl configDomainDataServiceImpl, String enterpriseId, String locationId, Connection connection) throws Exception 
			{
				log.info("Entering updateEntAndLocCcl");
				PreparedStatement psm = null;
				PreparedStatement pst = null;
				try 
				{
					// IR: 1806388 This update can happen concurrently from two different order.
					// So, get the lock first.
					/*String paramVal = OrderUtil.getConfigParamValue(connection, "ENT_CCL_LOCK", "ENT_CCL_LOCK");*/
					String paramVal = configDomainDataServiceImpl.getTblConfigParam("ENT_CCL_LOCK", "ENT_CCL_LOCK");
					boolean lbConfig = false;			
					if (paramVal != null && paramVal.equals("Y")) {
						lbConfig = false;
					} else {
						lbConfig = true;
					}
					if (!lbConfig) {
						dummyUpdateEnterprise(enterpriseId,connection);
						dummyUpdateLocation(locationId,connection);

						long entCcl = 0;
						long locCcl = 0;

						//modified by venkata. to get the correct counts
						String whereCls = null; 
						TblGroupQuery grpQry = new TblGroupQuery();
						whereCls = "where location_id in (select location_id from tbl_location where enterprise_id = \'"
								+ enterpriseId
								+ "\') ";

						log.info("whereCls: {}" , whereCls);
						grpQry.queryByWhere(connection, whereCls);

						if(grpQry.size() > 0)
						{
							for(int i = 0; i <grpQry.size(); i++)
							{
								entCcl += grpQry.getDbBean(i).getPbxMaxCclLimit(); // sum of pbx_max_ccl_limit
							}
							log.info("Retrieved Enterprise Trunk CCL Cum as {}" , entCcl);
						}

						grpQry = new TblGroupQuery();
						whereCls = "where location_id = \'"
								+ locationId
								+ "\'";

						log.info("whereCls: {}" , whereCls);
						grpQry.queryByWhere(connection, whereCls);

						if(grpQry.size() > 0)
						{
							for(int i = 0; i <grpQry.size(); i++)
							{
								locCcl += grpQry.getDbBean(i).getPbxMaxCclLimit(); // sum of pbx_max_ccl_limit
							}
							log.info("Retrieved Location Trunk CCL Cum as {} " , locCcl);

						}

						DBTblLocation locDbObj = new DBTblLocation();
						DBTblEnterprise entDbObj = new DBTblEnterprise();


						entDbObj.setEntTrunkCclSum(entCcl);
						locDbObj.setLocTrunkCclSum(locCcl);

						entDbObj.whereEnterpriseIdEQ(enterpriseId);
						entDbObj.updateSpByWhere(connection);

						locDbObj.whereLocationIdEQ(locationId);
						locDbObj.updateSpByWhere(connection);

					}

					if (lbConfig) {
						System.out.println("In new ccl block ");	
						int val, locVal = -1;

						String updEntStmt = "UPDATE TBL_ENTERPRISE SET  ENT_TRUNK_CCL_SUM = (SELECT SUM(PBX_MAX_CCL_LIMIT) FROM TBL_GROUP WHERE LOCATION_ID IN (select location_id from tbl_location where enterprise_id='" +enterpriseId +"')) where enterprise_id='" + enterpriseId + "'";

						String updLocStmt = "UPDATE TBL_LOCATION SET LOC_TRUNK_CCL_SUM = (SELECT SUM(PBX_MAX_CCL_LIMIT) FROM TBL_GROUP WHERE LOCATION_ID = '" +locationId +"') WHERE LOCATION_ID = '"+locationId +"'";


						psm = connection.prepareStatement(updEntStmt);
						val = psm.executeUpdate();

						pst = connection.prepareStatement(updLocStmt);
						locVal = pst.executeUpdate();
					}

				} catch (SQLException e) {
					log.error("ERROR: while attempting to update Enterprise / Location Trunk CCL Sum",e);
					// e.printStackTrace();
				}finally {
					if (psm != null)
						psm.close();
					if (pst != null)
						pst.close();
				}
			}
			
			public static void updateHubLocForRemote (String newHubLocId , String remoteLoc, int grpId, Connection connection) throws Exception {
				log.debug(" updateHubLocForRemote : newHubLocId : {} , remoteLoc : {} , grpId: {}" , newHubLocId , remoteLoc , grpId);
				int count = -1, updateCnt = -1;
				PreparedStatement ps = null,  updPs = null;
				ResultSet res = null;
				String countQry = "select count(g.location_id) from tbl_group g , tbl_device_map dm where  g.location_id = ? and g.group_id <> ? and dm.device_map_id = g.device_map_id and dm.location_id <> ?";
				String updateLocStmt = "UPDATE TBL_LOCATION SET HUB_LOCATION_ID = '"+ newHubLocId + "' WHERE LOCATION_ID = '" + remoteLoc +"'";
				try
				{

					ps = connection.prepareStatement(countQry);
					ps.setString(1, remoteLoc);
					ps.setInt(2, grpId);
					ps.setString(3, newHubLocId);
					res = ps.executeQuery();
					while (res.next())
					{
						count = res.getInt(1);
						log.debug(" updateHubLocForRemote : count {}" , count);
					}

					if (count == 0)
					{
						log.debug(" updateHubLocForRemote : No other grp mapped to the remote loc... Hence proceed with hub loc id update");
						updPs = connection.prepareStatement(updateLocStmt);
						updateCnt = updPs.executeUpdate();
						log.debug(" updateHubLocForRemote : updateCnt {}" , updateCnt);
					}

				}catch (Exception e)
				{
					log.error("ERROR: while attempting to update updateHubLocForRemote ",e.getMessage());
					throw e;
				}finally {
					if (ps != null)
						ps.close();
					if (updPs != null)
						updPs.close();
					if (res != null)
						res.close();
				}
			}

			/**
			 * 
			 * @param paramName
			 * @param paramValue
			 * @throws VZBAFException
			 */
			public static void checkForNull(String paramName, String paramValue) throws VZBAFException {
				if ((paramValue == null) || (paramValue.trim().length() == 0)) {
					throw new VZBAFException("Invalid value for parameter " + paramName);
				}
			}

			// Updated method with newParamDetailMap for multiple parameters with same name: for multiple parameters in TOD with same name
			/***
			 *  This method should be used 
			 *  for multiple parameters in TOD with same name.
			 * @param entityData
			 * @param paramName
			 * @param paramActionIn
			 * @return
			 */
			public static String getNewTableOrderDetailsParamValueWithAction(EntityData entityData,
					String paramName, String paramActionIn) {
				TableOrderDetailsParam tableOrderParam = null;
				String paramValue = null;
				
				Iterator<TableOrderDetailsParam> itr = entityData.getNewParamDetailMap().values().iterator();
				while (itr.hasNext()) {
					TableOrderDetailsParam todParam = itr.next();
					if (todParam.getAction().equals(paramActionIn)) {
						
						if (todParam.getParamName() != null && todParam.getParamName().equals(paramName)) {
							tableOrderParam = todParam;
							break;
						} 
					}
				}

				/* if not found at first level , now searching at map level */
				if (tableOrderParam == null) {
					
					Collection<TableOrderDetailsParam> tableOrderDetailsParams = entityData.getNewParamDetailMap().values();
					for (TableOrderDetailsParam orderDetailsParam : tableOrderDetailsParams) {
						tableOrderParam = getTableOrderDetailsParamByNameWithAction(orderDetailsParam, paramName,
								paramActionIn);
						if (tableOrderParam != null) {
							break;
						}
					}
				}		
				
				if(tableOrderParam != null)
					return tableOrderParam.getParamValue();
				else {
					return paramValue;
				}
			}
			
			/***This method returns the list of the given parameter name in the entire EntityData
			   * 
			   * @param entityData
			   * @param paramName
			   * @return
			   */
			  public static List<TableOrderDetailsParam> searchParamListNew(EntityData entityData, String paramName) {
			        List<TableOrderDetailsParam> paramList = new ArrayList<TableOrderDetailsParam>();
			            
			            Collection<TableOrderDetailsParam> tableOrderDetailsParamList = entityData.getNewParamDetailMap().values();// multiple values map
			            for (TableOrderDetailsParam tableOrderDetailsParamItem : tableOrderDetailsParamList) {
			                if ( tableOrderDetailsParamItem.getParamName() != null && tableOrderDetailsParamItem.getParamName()
			                        .equals(paramName)) {
			                    paramList.add(tableOrderDetailsParamItem);
			                }else{
			                    paramList = getNewTableOrderDetailsParamByName(tableOrderDetailsParamItem, paramName, paramList);
			                }
			                
			            }

			        return paramList;
			    }
			  
			  public static List<TableOrderDetailsParam> getNewTableOrderDetailsParamByName(
			            TableOrderDetailsParam tableOrderDetailsParam, String paramName, List<TableOrderDetailsParam> paramList) {
			        
			        for (TableOrderDetailsParam childParam : tableOrderDetailsParam
			                .getParamDetail()) {
			            if (childParam.getParamName() != null && childParam.getParamName().equals(paramName)) {
			                paramList.add(childParam);
			            } else {
			                paramList = getNewTableOrderDetailsParamByName(
			                        childParam, paramName,paramList);
			            }
			        }
			        return paramList;

			    } 


			public static void setKeyTnsSequence(long groupId,EntityBatch entityBatch,Connection connection) throws Exception {
				log.info( "setKeyTnsSequence for  group id <" + groupId + ">");

				try {
					if (ActionFunctionHelper.getTableOrderDetailsParam(entityBatch, "KeyTNs") != null) {
						// ParamDetail pd  = orderParam.getByNameSearch("KeyTNs");
						// List <ParamDetail> pdList  = pd.getByNameSearchList("Feature");
						List<TableOrderDetailsParam> pdList = ActionFunctionHelper.getTableOrderDetailsParam(entityBatch, "KeyTNs") 
						.getParamDetail();

						log.info( "Found Key TNS to reset sequence <" + pdList.size()
								+ ">");

						for (TableOrderDetailsParam tmp : pdList) {
							TblPublicTnPoolQuery tnQry = new TblPublicTnPoolQuery();
							TblGroupTnQuery grpTnQry;
							DBTblGroupTn grpTnDbBean = new DBTblGroupTn();

							if (!(tmp.getAction().equals("n") || tmp.getAction()
									.equals("r")))
								continue;

							String keyTn = tmp.getParamName();
							int keyTnSeq = Integer.parseInt(tmp.getParamValue());

							log.info( "Processing KeyTN <" + keyTn + "> Sequence <"
									+ keyTnSeq + ">");

							tnQry.whereTnEQ(keyTn);
							tnQry.whereActiveIndEQ(1);
							tnQry.query(connection);
							if (tnQry.size() <= 0)
								continue;

							TblPublicTnPoolDbBean tnDbBean = tnQry.getDbBean(0);

							log.info( "Processing KeyTN <" + keyTn
									+ "> with TN Pool Id <" + tnDbBean.getTnPoolId()
									+ ">");

							grpTnQry = new TblGroupTnQuery();
							grpTnQry.whereGroupIdEQ(groupId);
							grpTnQry.whereTnPoolIdEQ(tnDbBean.getTnPoolId());

							grpTnQry.query(connection);
							if (grpTnQry.size() <= 0)
								continue;

							grpTnDbBean.copyFromBean(grpTnQry.getDbBean(0));
							grpTnDbBean.setSequenceNo(keyTnSeq);
							grpTnDbBean.whereGroupTnIdEQ(grpTnDbBean.getGroupTnId());
							grpTnDbBean.updateSpByWhere(connection);

							log.info( groupId + ":" + tnDbBean.getTnPoolId()
									+ ": Updated KeyTns  Sequence for  TN <" + keyTn
									+ "> To <" + keyTnSeq + ">");

						}
					}
				} catch (Exception e) {
					log.error("Exception{}",e);
				}

			}
			
			public static List<FeaturesBean> getBillableFeatures(String action,EntityBatch entityBatch,Connection connection) {
				log.info( "getBillableFeatures for  action code <" + action + ">");
				List<FeaturesBean> locationFeatures = new ArrayList<FeaturesBean>();

				try {
					if (getTableOrderDetailsParam(entityBatch,"NonPkgFeatures") != null) {
						TableOrderDetailsParam pd = getTableOrderDetailsParam(entityBatch,"NonPkgFeatures");

						log.info( "getBillableFeatures(): Found Billabale Features ");

						List<TableOrderDetailsParam> pdList = searchParamListNew(entityBatch, "NonPkgFeature");
						/*.getByNameSearchList("NonPkgFeature");*/

						log.info( "Found Billabale Features :{}" ,pdList.size());

						for (TableOrderDetailsParam tmp : pdList) {
							if (!tmp.getAction().equals(action))
								continue;

							String featureName = tmp.getParamValue();
							//retrieve the corresponding FeatureId
							//SELECT FEATURE_ID FROM TBL_VZB_FEATURES WHERE NAME='Auto Attendant'
							log.info( "Querying Feature " + featureName);
							FeaturesBean fb = null;

							TblVzbFeaturesQuery vzbFeats = new TblVzbFeaturesQuery();
							vzbFeats.whereDescriptionLike(featureName);
							vzbFeats.query(connection);
							ArrayList<?> resultSet = vzbFeats.getResultArrayList();
							log.info( "vzbfeatures for featurename:<" , featureName
									, "> size <" , vzbFeats.size());

							if (vzbFeats.size() > 0) {
								TblVzbFeaturesDbBean vzbFeatDbBean = (TblVzbFeaturesDbBean) resultSet
								.get(0);
								int featureId = vzbFeatDbBean.getFeatureId();
								log.info( "FeatureID <" , featureId
										, "> in tbl_vzb_features");

								fb = new FeaturesBean();
								fb.getFeaturesDbBean().setName(featureName);
								fb.getFeaturesDbBean().setFeatureId(featureId);
								locationFeatures.add(fb);
							} else {
								log.info( "Unkown Feature " + featureName);
								continue;
							}
						}
						log.info( "found Billable Features: "
								+ locationFeatures.size());
					}
				} catch (Exception e) {
					log.error("Exception{}",e);
				}

				return locationFeatures;

			}
			
			public static boolean isEsapSbcOrder(String customerId ,Connection connection) throws Exception {
				log.info("Enter isEsapSbcOrder method===> {}" , customerId);
				PreparedStatement pstmt = null;
				ResultSet rs = null;
				boolean sbcFlag = false;
				String sqlQuery = "select sbc_activation_system  from tbl_enterprise where enterprise_id=?";
				try {
					pstmt = connection.prepareStatement(sqlQuery);
					pstmt.setString(1, customerId);
					rs = pstmt.executeQuery();
					while (rs.next()) {
						String sbcValue = rs.getString(1);
						log.info("sbcValue---> {}" , sbcValue);
						if ("ESAP".equals(sbcValue)) {
							sbcFlag = true;
						}
					}
				} catch (Exception e) {
					log.info("Exception in isEsapSbcOrder is====> {}"
							, e.getMessage());
				} finally {
					if (pstmt != null)
						pstmt.close();
					if (rs != null)
						rs.close();
				}

				log.info("Exit isEsapSbcOrder method===> {}" , sbcFlag);
				return sbcFlag;
			}
			
			public static int getOrdPlatform(String customerId,Connection connection ) throws Exception
			{
				   PreparedStatement pStmnt = null;
				   ResultSet rs = null;
				   int orderPlatform = -1;
				   try{
					   String customerQuery = "SELECT ORDER_PLATFORM FROM TBL_CUSTOMER WHERE CUSTOMER_ID = ?";
					   pStmnt = connection.prepareStatement(customerQuery);
					   pStmnt.setString(1,customerId);
					   rs = pStmnt.executeQuery();

					   if (rs.next()) {
						   orderPlatform = rs.getInt(1);
					   }
				   }catch(Exception e){
					   log.error("ERROR: Exception caught while trying to get OrdPlatform", e);
				   }finally{
					   if(rs != null){
						   rs.close();
					   }if(pStmnt != null){
						   pStmnt.close();
					   }
				   }
				   return orderPlatform;
			}
			
			public static void updateEntCclForTSO (String enterpriseId, String locationId, long entCclSum, Connection connection) {
				log.info("Entering updateEntCclForTSO");
		        try 
				{
		            DBTblEnterprise entDbObj = new DBTblEnterprise();			
		            log.debug("Enterprise TrunkCcl Sum {}" , entCclSum);
		            entDbObj.setEntTrunkCclSum(entCclSum);
					
		           	entDbObj.whereEnterpriseIdEQ(enterpriseId);
		            entDbObj.updateSpByWhere(connection);

		        } catch (SQLException e) {
		            //e.printStackTrace();
		        	log.error("Exception while updateEntCclForTSO",e);
		        }	
			}
			
			public static void updateEntMigration (String entity, String entityType, String value, Connection connection) throws Exception {
				log.info("In updateEntMigration");
				PreparedStatement pstmt = null;
				StringBuffer updateStmt = new StringBuffer();
				updateStmt.append("UPDATE TBL_TSO_ENTITY_MIGRATION SET MIGRATION_STATUS = 3 WHERE ENTITY_TYPE = ? AND ");
				try
				{
					log.info("Entity type {}" , entityType);
					log.info(" entity {}",entity);
					log.info(" value {}" ,value );
					if (entityType.equals("3") && entity.equalsIgnoreCase("Location"))
					{
						updateStmt.append("LOCATION_ID = ?");
					} else if (entityType.equals("1") &&  entity.equalsIgnoreCase("Enterprise"))
					{
						updateStmt.append("ENTERPRISE_ID = ?");
					}
					
					pstmt = connection.prepareStatement(updateStmt.toString());
					pstmt.setString(1, entityType);
					pstmt.setString(2, value);
					
				}catch (Exception e)
				{
					//e.printStackTrace();
					log.error("Exception while updateEntMigration",e);
					throw e;
				}finally
				{
					if (pstmt != null)
					pstmt.close();
				}
			}
			
			
			public static void updateTnETMapTbl(String locationId, Connection connection) throws Exception {
				log.info("In updateTnETMapTbl {}", locationId);
				PreparedStatement ps = null;
				try {
					String updateQry = "update TBL_TSO_TEST_TN_ET_MAPPING set location_id=null , tn=null where location_id = ?";
					ps = connection.prepareStatement(updateQry);
					ps.setString(1, locationId);
					ps.executeUpdate();
				} catch (Exception e) {
					// e.printStackTrace();
					log.error("Exception while updateTnETMapTbl", e);
					throw e;
				} finally {
					if (ps != null)
						ps.close();
				}
			}
			
			public static void updateEntRefTbl (String entity, String entityType, String value, Connection connection) throws Exception {
				log.info("In updateEntRefTbl");
				PreparedStatement pstmt = null;
				StringBuffer updateStmt = new StringBuffer();
				updateStmt.append("UPDATE TBL_VAMP_ENTITY_REFERENCE SET TSO_LOCATION_ID = NULL WHERE ENTITY_TYPE = ? AND ENTITY_NAME = ? AND TSO_LOCATION_ID = ?");
				try
				{
					log.info("Entity type {}" , entityType);
					log.info(" entity {}" ,entity);
					log.info(" value {}" ,value );
					
					pstmt = connection.prepareStatement(updateStmt.toString());
					pstmt.setString(1, entityType);
					pstmt.setString(2, entity);
					pstmt.setString(3, value);
					pstmt.executeUpdate();
					
				}catch (Exception e)
				{
					//e.printStackTrace();
					log.error("Exception while updateEntRefTbl", e);
					throw e;
				}finally
				{
					if (pstmt != null)

					pstmt.close();
				}
			}
			
			public static String getVmPartitionIdSeqNextVal(Connection connection) throws SQLException {
				String vmPartitionId = "0";
				PreparedStatement ps = null;
				ResultSet rs = null;

				try {
					ps = connection.prepareStatement("SELECT VM_PARTITION_ID_SEQ.NEXTVAL FROM DUAL");

					rs = ps.executeQuery();
					if (rs.next()) {
						vmPartitionId = rs.getString(1);
					}
					ps.close();
				} catch (SQLException e) {
					log.error("ERROR: SELECT VM_PARTITION_ID_SEQ.NEXTVAL FROM DUAL", e);
				} finally {
					try {
						if (null != rs)
							rs.close();
					} catch (Exception e) {
					}
					try {
						if (null != ps)
							ps.close();
					} catch (Exception e) {
					}
				}
				return vmPartitionId;
			}
			//KR- start servicepack service
			public static List<ServicePackFeaturesBean> getServicePackServiceFeatures(EntityData entityData, Connection connection, String action) {
				log.info("getPolicyServiceFeatures for  action code < {} >", action);
				List<ServicePackFeaturesBean> policyServiceFeatures = new ArrayList<ServicePackFeaturesBean>();

				try {
					if (getTableOrderDetaisParam(entityData, "Solution_Type") != null) {

						//List<TableOrderDetailsParam> pdList = searchParamListNew(entityData, "PolicyType");

					//	log.info("Found PolicyType Features <{}>", pdList.size());

						//for (TableOrderDetailsParam tmp : pdList) {
							

							String solutionType = getTableOrderDetaisParam(entityData, "PolicyType").getParamValue();
							if(solutionType!=null && "ESIP-ESL".equalsIgnoreCase(solutionType)){
								solutionType="ESIP";
							}else if(solutionType!=null && "EBL-ESL".equalsIgnoreCase(solutionType)){
								solutionType="EBL";
							}
						

							log.info("policyFeature policyType < {} > ", solutionType);

							// retrieve the corresponding FeatureId
							// SELECT FEATURE_ID FROM TBL_VZB_FEATURES WHERE NAME='Auto
							// Attendant'
							log.info("Querying Feature {}", solutionType);
							ServicePackFeaturesBean fb = null;

							TblServicepackQuery servicepackFeats = new TblServicepackQuery();
							servicepackFeats.whereServicepackTypeLike(solutionType);
							servicepackFeats.query(connection);
							ArrayList<?> resultSet = servicepackFeats.getResultArrayList();
							log.info("ServicepackQuery for solutionType:<{}> size <{}>", solutionType, servicepackFeats.size());

							if (servicepackFeats.size() > 0) {
								TblServicepackDbBean vzbFeatDbBean = (TblServicepackDbBean) resultSet.get(0);
								int servicePackId = vzbFeatDbBean.getServicepackId();
								log.info("servicePackId <{}> in tbl_servicepack", servicePackId);

								fb = new ServicePackFeaturesBean();
								fb.getServicePackFeaturesDbBean().setServicepackType(solutionType);
								fb.getServicePackFeaturesDbBean().setServicepackId(servicePackId);
							
								log.info("policyfeatures getType <{}> ServicepackId <{}> ServicepackName<{}>", fb.getServicePackFeaturesDbBean().getServicepackType(),
										fb.getServicePackFeaturesDbBean().getServicepackId(), fb.getServicePackFeaturesDbBean().getServicepackName());
								policyServiceFeatures.add(fb);
							} else {
								log.info("Unkown tbl_policies of policytype  {}", solutionType);
							//	continue;
							}
					//	}
						log.info("found policyService Features: {}", policyServiceFeatures.size());
					}
				} catch (Exception e) {
					e.printStackTrace();
				}

				return policyServiceFeatures;

			}
			
			
			
			//
			//KR -start policy service changes 			
			public static List<PolicyFeaturesBean> getPolicyServiceFeatures(EntityData entityData, Connection connection, String action) {
				log.info("getPolicyServiceFeatures for  action code < {} >", action);
				List<PolicyFeaturesBean> policyServiceFeatures = new ArrayList<PolicyFeaturesBean>();

				try {
					if (getTableOrderDetaisParam(entityData, "PolicyType") != null) {

						//List<TableOrderDetailsParam> pdList = searchParamListNew(entityData, "PolicyType");

					//	log.info("Found PolicyType Features <{}>", pdList.size());

						//for (TableOrderDetailsParam tmp : pdList) {
							

							String policyType = getTableOrderDetaisParam(entityData, "PolicyType").getParamValue();
							//String isAuthorised = getTableOrderDetailsParamByName(tmp, "Authorised").getParamValue();

							log.info("policyFeature policyType < {} > ", policyType);

							// retrieve the corresponding FeatureId
							// SELECT FEATURE_ID FROM TBL_VZB_FEATURES WHERE NAME='Auto
							// Attendant'
							log.info("Querying Feature {}", policyType);
							PolicyFeaturesBean fb = null;

							TblPoliciesQuery policyFeats = new TblPoliciesQuery();
							policyFeats.wherePolicyTypeLike(policyType);
							policyFeats.query(connection);
							ArrayList<?> resultSet = policyFeats.getResultArrayList();
							log.info("vzbfeatures for featurename:<{}> size <{}>", policyType, policyFeats.size());

							if (policyFeats.size() > 0) {
								TblPoliciesDbBean vzbFeatDbBean = (TblPoliciesDbBean) resultSet.get(0);
								int policyId = vzbFeatDbBean.getPolicyId();
								log.info("policyId <{}> in tbl_policies", policyId);

								fb = new PolicyFeaturesBean();
								fb.getPolicyFeaturesDbBean().setPolicyType(policyType);
								fb.getPolicyFeaturesDbBean().setPolicyId(policyId);
							
								log.info("policyfeatures PolicyType <{}> PolicyId <{}> PolicyName<{}>", fb.getPolicyFeaturesDbBean().getPolicyType(),
										fb.getPolicyFeaturesDbBean().getPolicyId(), fb.getPolicyFeaturesDbBean().getPolicyName());
								policyServiceFeatures.add(fb);
							} else {
								log.info("Unkown tbl_policies of policytype  {}", policyType);
							//	continue;
							}
					//	}
						log.info("found policyService Features: {}", policyServiceFeatures.size());
					}
				} catch (Exception e) {
					e.printStackTrace();
				}

				return policyServiceFeatures;

			}
			
			//KR -end
			
			
			public static List<FeaturesBean> getAuthFeatures(EntityData entityData, Connection connection, String action) {
				log.info("getAuthFeatures for  action code < {} >", action);
				List<FeaturesBean> authFeatures = new ArrayList<FeaturesBean>();

				try {
					if (getTableOrderDetaisParam(entityData, "AuthService") != null) {

						List<TableOrderDetailsParam> pdList = searchParamListNew(entityData, "AuthService");

						log.info("Found Auth Features <{}>", pdList.size());

						for (TableOrderDetailsParam tmp : pdList) {
							if (!tmp.getAction().equals(action))
								continue;

							if (getTableOrderDetailsParamByName(tmp, "Name") == null)
								continue;

							if (getTableOrderDetailsParamByName(tmp, "Authorised") == null)
								continue;

							String featureName = getTableOrderDetailsParamByName(tmp, "Name").getParamValue();
							String isAuthorised = getTableOrderDetailsParamByName(tmp, "Authorised").getParamValue();

							log.info("Feature name < {} > isAuthorised < {} >", featureName, isAuthorised);

							// retrieve the corresponding FeatureId
							// SELECT FEATURE_ID FROM TBL_VZB_FEATURES WHERE NAME='Auto
							// Attendant'
							log.info("Querying Feature {}", featureName);
							FeaturesBean fb = null;

							TblVzbFeaturesQuery vzbFeats = new TblVzbFeaturesQuery();
							vzbFeats.whereNameLike(featureName);
							vzbFeats.query(connection);
							ArrayList<?> resultSet = vzbFeats.getResultArrayList();
							log.info("vzbfeatures for featurename:<{}> size <{}>", featureName, vzbFeats.size());

							if (vzbFeats.size() > 0) {
								TblVzbFeaturesDbBean vzbFeatDbBean = (TblVzbFeaturesDbBean) resultSet.get(0);
								int featureId = vzbFeatDbBean.getFeatureId();
								log.info("FeatureID <{}> in tbl_vzb_features", featureId);

								fb = new FeaturesBean();
								fb.getFeaturesDbBean().setName(featureName);
								fb.getFeaturesDbBean().setFeatureId(featureId);
								if (isAuthorised.equals("Y"))
									fb.setIsAuthorized(true);
								else
									fb.setIsAuthorized(false);
								log.info("Feature name <{}> Feature Id <{}> isAuthorised<{}>", fb.getFeaturesDbBean().getName(),
										fb.getFeaturesDbBean().getFeatureId(), fb.getIsAuthorized());
								authFeatures.add(fb);
							} else {
								log.info("Unkown Feature {}", featureName);
								continue;
							}
						}
						log.info("found Auth Features: {}", authFeatures.size());
					}
				} catch (Exception e) {
					e.printStackTrace();
				}

				return authFeatures;

			}
			
			public static boolean modifyAuthServicesForEnterprise(Enterprise enterprise,Connection connection,Long orderId)throws Exception {
				boolean retValue = true;
				PreparedStatement pstmt = null;
				ResultSet rs = null;
				StringBuffer sql = new StringBuffer();
				TblAuthServicesQuery authQry;
				DBTblAuthServices authServicesDbBean = new DBTblAuthServices();

				sql.append(" select dp.param_name, dp.param_value feature_name, ");
				sql.append(" DECODE(dp1.param_value, 'false', 'N', 'true', 'Y', 'N', 'N', 'Y', 'Y') is_allow,  ");
				sql.append(" f.feature_id, a.is_authorized, d.action authservice_action from tbl_order_details d, ");
				sql.append(" tbl_order_details dp, tbl_order_details dp1, tbl_vzb_features f, tbl_auth_services a ");
				sql.append(" where d.order_id = ? and d.param_name = 'AuthService' ");
				sql.append(" and dp.parent_id = d.order_detail_id ");
				sql.append(" and dp.param_name = 'Name' ");
				sql.append(" and f.name = dp.param_value ");
				sql.append(" and dp1.parent_id = d.order_detail_id ");
				sql.append(" and dp1.param_name = 'Authorised' ");
				sql.append(" and a.feature_id = f.feature_id ");
				sql.append(" and a.auth_service_id = ? ");

				try {
					TblEnterpriseDbBean enterpriseDbBean = getEnterprise(enterprise.getEnterpriseId(),connection);
					pstmt = connection.prepareStatement(sql.toString());
					pstmt.setLong(1, orderId);
					pstmt.setLong(2, enterpriseDbBean.getAuthServicesId());
					rs = pstmt.executeQuery();
					while (rs.next()) {
						String featureName = rs.getString(2);
						String isAllow = rs.getString(3);

						// if AuthService (parent node) has action = o, we need to set
						// isAllow=N
						// When AuthService just vanished from XML, OM will persist it
						// as follows:
						// AuthService: null(o)
						// Name: Trunk Group Unreachable (o)
						// Authorised: Y(o)
						String authServiceAction = rs.getString(6);
						log.info("AuthService has action = {} and isAllow = {}  with featureName={} ." , authServiceAction , isAllow , featureName);

						if (isAllow.equals("Y") && authServiceAction.equals("o")) {
							log.info("AuthService has action = (o), with featureName= {} setting isAllow=N." , featureName);
							isAllow = "N";
						}
						Long featureId = rs.getLong(4);
						String isAuthorized = rs.getString(5);

						if (!isAllow.equals(isAuthorized)) {
							authQry = new TblAuthServicesQuery();
							authQry.whereAuthServiceIdEQ((int) enterpriseDbBean.getAuthServicesId());
							authQry.whereFeatureIdEQ(featureId);
							authQry.query(connection);
							if (authQry.size() > 0) {
								authServicesDbBean.copyFromBean(authQry.getDbBean(0));
								authServicesDbBean.setIsAuthorized(isAllow);
								authServicesDbBean.setModifiedBy(enterprise.getModifiedBy());
								authServicesDbBean.setLastModifiedDate(enterprise.getLastModifiedDate());
								authServicesDbBean.setEnvOrderId(enterprise.getEnvOrderId());
								authServicesDbBean.update(connection);
								log.info("Feature <{}> updated from {} to {}" , featureName , isAuthorized , isAllow);
								// TODO Need to Unselect all the custom feature pkgs
								if (isAllow.equals("N")) {
									PreparedStatement stmt = null;
									ResultSet rs1 = null;
									StringBuffer sql1 = new StringBuffer();
									try {
										sql1.append(
												"select lp.package_id from  tbl_location l, tbl_loc_package lp, tbl_pkg_features pf, tbl_package p");
										sql1.append(" where l.enterprise_id = ? and l.location_id = lp.location_id ");
										sql1.append(
												" and lp.package_id = pf.package_id and p.package_id = pf.package_id and template_ind<>1 ");
										sql1.append(" and pf.feature_id = ? and pf.is_selected = 'Y'");

										stmt = connection.prepareStatement(sql1.toString());
										stmt.setString(1, enterprise.getEnterpriseId());
										stmt.setLong(2, featureId);
										rs1 = stmt.executeQuery();
										while (rs1.next()) {
											long packageId = rs1.getLong(1);
											DBTblPkgFeatures pkgFeatDbBean = new DBTblPkgFeatures();
											pkgFeatDbBean.wherePackageIdEQ(packageId);
											pkgFeatDbBean.whereFeatureIdEQ(Long.toString(featureId));
											pkgFeatDbBean.setIsSelected("N");
											pkgFeatDbBean.updateSpByWhere(connection);
											log.info("Feature <{}> PackageId:{} updated to is_selected N" , featureName ,packageId);
										}
									} finally {
										// IR #1638603
										if (stmt != null) {
											stmt.close();
										}
										if (rs1 != null) {
											rs1.close();
										}
									}

									long icpConfFeatId = getVzbFeatureId("ICP Conferencing",connection);

									if (icpConfFeatId > 0 && featureId == icpConfFeatId) {

										PreparedStatement stmt2 = null;
										ResultSet rs2 = null;
										try {
											StringBuffer sql2 = new StringBuffer();
											sql2.append(
													"select sf.sub_id, sf.sub_feature_id from  tbl_location l, tbl_subscriber s,tbl_sub_feature sf");
											sql2.append(" where l.enterprise_id = ? and l.location_id = s.location_id ");
											sql2.append("  and sf.sub_id = s.sub_id and sf.feature_id = ? ");
											log.info("Icp conferencing is being unauthorized, cascading it to subscriber: {}", sql2.toString());

											stmt2 = connection.prepareStatement(sql2.toString());
											stmt2.setString(1, enterprise.getEnterpriseId());
											stmt2.setLong(2, featureId);
											rs2 = stmt2.executeQuery();
											while (rs2.next()) {
												String subscId = rs2.getString(1);
												int subFeatId = rs2.getInt(2);
												log.info("SubFeatureId being deleted: {},SubId: {},FeatureId:{}" + subFeatId , subscId , featureId);
												DBTblSubFeature subFeatDbBean = new DBTblSubFeature();
												subFeatDbBean.whereSubFeatureIdEQ(subFeatId);
												subFeatDbBean.deleteByWhere(connection);

											}
										} finally {
											// IR #1638603
											if (stmt2 != null) {
												stmt2.close();
											}
											if (rs2 != null) {
												rs2.close();
											}
										}

									}
								} // isAllow.equals("N")
							}
						}
					}

				} catch (Exception e) {
					e.printStackTrace();
					retValue = false;
				} finally {
					try {
						if (rs != null) {
							rs.close();
						}
						if (pstmt != null) {
							pstmt.close();
						}
					} catch (SQLException e) {
						throw new Exception("Exception caught while closing result set/prepared statement");
					}
				}
				return retValue;

			}
			
			public static TblEnterpriseDbBean getEnterprise(String enterpriseId,Connection connection) throws SQLException {
				log.info("In getTblEnterpriseListForEnterpriseId()");
				ArrayList<TblEnterpriseDbBean> resultList = null;
				TblEnterpriseDbBean enterpriseDbBean = new TblEnterpriseDbBean();
				try {
					TblEnterpriseQuery enterpriseQuery = new TblEnterpriseQuery();
					enterpriseQuery.whereEnterpriseIdEQ(enterpriseId);
					enterpriseQuery.query(connection);

					resultList = enterpriseQuery.getResultArrayList();
					if (resultList.size() > 0) {
						enterpriseDbBean = (TblEnterpriseDbBean) resultList.get(0);
					}
				} catch (SQLException e) {
					e.printStackTrace();
					log.error("ERROR: Exception caught while trying to get platform_indicator from tbl_enterprise", e);
				}
				return enterpriseDbBean;
			}
			
			public static long getVzbFeatureId(String featureName,Connection connection) {
				long featureId = 0;
				log.info("getVzbFeatureId for  Feature Name <{}>" , featureName);

				try {

					TblVzbFeaturesQuery vzbFeats = new TblVzbFeaturesQuery();
					vzbFeats.whereNameLike(featureName);
					vzbFeats.query(connection);
					ArrayList<?> resultSet = vzbFeats.getResultArrayList();
					log.info("vzbfeatures for featurename:<{}>,size {}" , featureName ,vzbFeats.size());

					if (vzbFeats.size() > 0) {
						TblVzbFeaturesDbBean vzbFeatDbBean = (TblVzbFeaturesDbBean) resultSet
						.get(0);
						featureId = vzbFeatDbBean.getFeatureId();
						log.info("FeatureID <{}> in tbl_vzb_features" , featureId);
					}
				} catch (Exception e) {
					e.printStackTrace();
				}

				return featureId;
			}
			
			public static void addToLocation(String custId,Connection connection) throws Exception 
			{
				log.info("In  addToLocation {}" ,custId);
				String lsLocInsQry = "INSERT INTO TBL_LOCATION (LOCATION_ID, ENTERPRISE_ID, SBC_PROV_METHOD, RIV_LOCATION, LOC_CCL_IND, E911_SERVICE,MODIFIED_BY, CREATED_BY, BILL_TYPE, LOCATION_NAME,RPID_PRIV, ACTIVE_IND) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)";
				PreparedStatement ps = null;
				String locationId = null;
				try
				{
					ps = connection.prepareStatement(lsLocInsQry);
					locationId = "IPCC"+getLocationIdDummySeqNextVal(connection);
					log.info("Location id in addToLocation meth {}" ,locationId);
					ps.setString(1, locationId);
					ps.setString(2, custId);
					ps.setLong(3, VzbVoipEnum.SbcProvMethodType.ESAP);
					ps.setLong(4, VzbVoipEnum.YesNoType.N);
					ps.setLong(5, VzbVoipEnum.YesNoType.N);
					ps.setLong(6, VzbVoipEnum.YesNoType.N);
			        ps.setString(7, "ESAP");
			        ps.setString(8, "ESAP");
			        ps.setLong(9, 0);
			        ps.setString(10, locationId);
			        ps.setInt(11, -1);
					ps.setInt(12, 1);
					
					ps.executeUpdate();
					
					log.info("Location dummy insert completed for IPCC");
					
				}catch(Exception e)
				{
					e.printStackTrace();
					throw e;
				}finally
				{
					if (ps != null)
					{
						ps.close();
					}
				}
				
				
			}
			
			public static String getLocationIdDummySeqNextVal(Connection connection) throws SQLException {
				log.info("In getLocationIdDummySeqNextVal");
				String locationId = "0";
				PreparedStatement ps = null;
				ResultSet rs = null;

				try {
					ps = connection.prepareStatement("SELECT IPCC_LOCATION_ID_SEQ.NEXTVAL FROM DUAL");
					rs = ps.executeQuery();
					if (rs.next()) {
						locationId = rs.getString(1);
					}
					ps.close();
				} catch (SQLException e) {
					log.error("ERROR: SELECT LOCATION_ID_SEQ.NEXTVAL FROM DUAL",e);
				} finally {
					try {
						if (null != rs)
							rs.close();
					} catch (Exception e) {
					}
					try {
						if (null != ps)
							ps.close();
					} catch (Exception e) {
					}
				}
				return locationId;
			}
			
			public static void deleteTnETMapTbl(String entId,Connection connection) throws Exception {
				 log.info("In deleteTnETMapTbl " +entId);
				 PreparedStatement ps = null;
				 try
				   {
				    String delQry = "DELETE FROM TBL_TSO_TEST_TN_ET_MAPPING WHERE ENTERPRISE_ID = ?";
				    ps = connection.prepareStatement(delQry);
				    ps.setString(1, entId);
				    ps.executeUpdate();
				   }catch (Exception e)
				   {
				    e.printStackTrace();
				    throw e;
				   }finally {
				    if (ps != null)
				    ps.close();
				   } 
				}
			
			// Added by Praveen 
			
			public static TableOrderDetailsParam getTableOrderDetaisParamWithAction(EntityData entityData,
					String paramName, String paramActionIn) {
				TableOrderDetailsParam tableOrderParam = null;
				if (entityData.getParamMap().get(paramName) != null && entityData.getParamMap().get(paramName).getAction().equals(paramActionIn)) {
					tableOrderParam = entityData.getParamMap().get(paramName);
				}
				/* if not found at first level , now searching at map level */
				if (tableOrderParam == null) {
					Collection<TableOrderDetailsParam> tableOrderDetailsParams = entityData.getParamMap().values();
					for (TableOrderDetailsParam orderDetailsParam : tableOrderDetailsParams) {
						tableOrderParam = getTableOrderDetailsParamByNameWithAction(orderDetailsParam, paramName,
								paramActionIn);
						if (tableOrderParam != null) {
							break;
						}
					}
				}		
				
				return tableOrderParam;
				
			}
			
			
	// Updated method with newParamDetailMap for multiple parameters with same
	// name: for multiple parameters in TOD with same name
	/***
	 * This method should be used for multiple parameters in TOD with same name.
	 * 
	 * @param entityData
	 * @param paramName
	 * @param paramAction
	 * @return
	 */
	public static TableOrderDetailsParam getNewTableOrderDetailsParamWithAction(EntityData entityData, String paramName,
			String paramActionIn) {
		TableOrderDetailsParam tableOrderParam = null;

		Iterator<TableOrderDetailsParam> itr = entityData.getNewParamDetailMap().values().iterator();
		while (itr.hasNext()) {
			TableOrderDetailsParam todParam = itr.next();
			if (todParam.getAction().equals(paramActionIn)) {

				if (todParam.getParamName() != null && todParam.getParamName().equals(paramName)) {
					tableOrderParam = todParam;
					break;
				}
			}
		}

		/* if not found at first level , now searching at map level */
		if (tableOrderParam == null) {

			Collection<TableOrderDetailsParam> tableOrderDetailsParams = entityData.getNewParamDetailMap().values();
			for (TableOrderDetailsParam orderDetailsParam : tableOrderDetailsParams) {
				tableOrderParam = getTableOrderDetailsParamByNameWithAction(orderDetailsParam, paramName,
						paramActionIn);
				if (tableOrderParam != null) {
					break;
				}
			}
		}

		return tableOrderParam;
	}
	// added below method to coverage
	
	public static  void extractDigitStringAddAndDeleteList(EntityData entityData, List<DigitStringBean> digitStringAddList,
			List<DigitStringBean> digitStringDelList,Connection connection,Enterprise enterprise) throws Exception, SQLException, VzbInvException {
		if (digitStringAddList != null) {
			handleEntDigitStringActivate(entityData,digitStringAddList, enterprise.getEnterpriseId(),connection);
			TblDepartmentQuery deptQry = new TblDepartmentQuery();
			String whereCls = "where enterprise_id = \'" + enterprise.getEnterpriseId()
					+ "\' and Calling_plan_id is not null and calling_plan_id > 0";
			log.info("In INV MOD ENT AF: whereCls for DigitString:" + whereCls);
			deptQry.queryByWhere(connection, whereCls);
			if (deptQry.size() > 0) {
				CallingPlan callingPlanObj = new CallingPlan(connection);
				callingPlanObj.setDigitStringList(digitStringAddList);
				for (int i = 0; i < deptQry.size(); i++) {
					callingPlanObj.setCallingPlanId((int) deptQry.getDbBean(i).getCallingPlanId());
					if (!callingPlanObj.addDigitStringListToDb())
						throw new VzbInvException("ESP_VZB_INV_MOD_ENTERPRISE_FAILED",
								"add Calling plan Digits failed");
				}
			}
		}
		if (digitStringDelList != null) {
			TblDepartmentQuery deptQry = new TblDepartmentQuery();
			String whereCls = "where enterprise_id = \'" + enterprise.getEnterpriseId()
					+ "\' and Calling_plan_id is not null and calling_plan_id > 0";
			log.info("In INV MOD ENT AF: whereCls for DigitString:" + whereCls);
			deptQry.queryByWhere(connection, whereCls);
			if (deptQry.size() > 0) {
				CallingPlan callingPlanObj = new CallingPlan(connection);
				callingPlanObj.setDigitStringList(digitStringDelList);
				for (int i = 0; i < deptQry.size(); i++) {
					callingPlanObj.setCallingPlanId((int) deptQry.getDbBean(i).getCallingPlanId());
					if (!callingPlanObj.delDigitStringListFromDb())
						throw new VzbInvException("ESP_VZB_INV_MOD_ENTERPRISE_FAILED",
								"del Calling plan Digits failed");
				}
			}

			for (int i = 0; i < digitStringDelList.size(); i++) {
				DigitString digitStringObj = new DigitString(digitStringDelList.get(i), connection);
				if (!digitStringObj.deleteDigitStringByDigitStringId())
					throw new VzbInvException("ESP_VZB_INV_MOD_ENTERPRISE_FAILED",
							"add Calling plan Digits failed");
			}

		}
	}
	
	
			
}