/**
 * 
 */
package com.vz.fxo.inventory.enterprise.support;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Timestamp;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import esap.db.DBTblFmcgVendor;
import esap.db.TblFmcgVendorDbBean;
import esap.db.TblFmcgVendorQuery;
/**
 * @author Vijaykumar Sriperambuduri(v034934)
 *
 */
public class FmcgVendor extends FmcgVendorBean {
	
	private static Logger log = LoggerFactory.getLogger(FmcgVendor.class
			.toString());


	private Connection connection;
    InvErrorCode status = InvErrorCode.INTERNAL_ERROR;

    public FmcgVendor(Connection con)
    {
        this.connection = con;
    }

    //getters - setters

    public Connection getConnection() {
        return connection;
    }
                     
    public void setConnection(Connection connection) {  
        this.connection = connection;
    }                
    public int getStatusCode() 
    {
        return status.getErrorCode();
    }

    public void setStatus(InvErrorCode status)
    {
       this.status = status;
    }

    public String getStatusDesc()
    {
       return status.getErrorDesc();
    }
    public boolean validateSbc()
    {
        return true;
    }
    
    public FmcgVendor(Connection con, FmcgVendorBean fmcgVendorBean)
    {
    	super(fmcgVendorBean);
    	this.connection = con;
    }
    
    public boolean addFmcgVendor()
    {
        log.info("Entering FmcgVendor::addFmcgVendor");

        try
        {	
        	DBTblFmcgVendor fmcgVendorDb = new DBTblFmcgVendor();
        	if(getFmcgVendorId()>0){
        		fmcgVendorDb.setFmcgVendorId(getFmcgVendorId());
        	}else{
        		int fmcgDeviceSeqId = fmcgVendorDb.getFmcgVendorIdSeqNextVal(connection);
                fmcgVendorDb.setFmcgVendorId(fmcgDeviceSeqId);
        	}
        	
            fmcgVendorDb.setFmcgVendorDesc(getFmcgVendorDesc());
            fmcgVendorDb.setFmcgVendorName(getFmcgVendorName());
            if(!getCreatedBy().equals(""))
            	fmcgVendorDb.setCreatedBy(getCreatedBy());
            else
            	fmcgVendorDb.setCreatedBy("ESAP_INV");
            
            if(!getModifiedBy().equals(""))
            	fmcgVendorDb.setModifiedBy(getModifiedBy());
            else
            	fmcgVendorDb.setModifiedBy("ESAP_INV");

            fmcgVendorDb.setLastModifiedDate(new Timestamp(System.currentTimeMillis()));
            fmcgVendorDb.setCreationDate(new Timestamp(System.currentTimeMillis()));
            fmcgVendorDb.insert(connection);

        }
        catch(SQLException s)
        {
            s.printStackTrace();
            setStatus(InvErrorCode.DB_EXCEPTION);
            return false;
        }
        setStatus(InvErrorCode.SUCCESS);
        return true;
    }
    
    public boolean getFmcgVendorDetailsById()
    {
        log.info("Entering FmcgVendor::getFmcgVendorDetailsById");
        try
        {
        	TblFmcgVendorQuery fmcgVendorQry = new TblFmcgVendorQuery();
        	log.info("Querying Fmcg Device Details for id: " + getFmcgVendorId());
        	fmcgVendorQry.whereFmcgVendorIdEQ(getFmcgVendorId());
			fmcgVendorQry.query(connection);
            if(fmcgVendorQry.size() <= 0)
            {
                    log.info("Failed to Retrieve FmcgVendor Details");
                    return false;
            }
            
            TblFmcgVendorDbBean fmcgVendorBean = fmcgVendorQry.getDbBean(0);
            setCreatedBy(fmcgVendorBean.getCreatedBy());
            setFmcgVendorDesc(fmcgVendorBean.getFmcgVendorDesc());
            setFmcgVendorName(fmcgVendorBean.getFmcgVendorName());
            setModifiedBy(fmcgVendorBean.getModifiedBy());
               
        }
        catch(Exception e)
        {
            e.printStackTrace();
            setStatus(InvErrorCode.ERROR_GETTING_VENDOR_DETAILS);
            return false;
        }
        setStatus(InvErrorCode.SUCCESS);
        return true;
    }
    
    public boolean getFmcgVendorDetailsByName()
    {
        log.info("Entering FmcgVendor::getFmcgVendorDetailsByName");
        try
        {
        	TblFmcgVendorQuery fmcgVendorQry = new TblFmcgVendorQuery();
        	log.info("Querying Fmcg Device Details for Name: " + getFmcgVendorName());
        	fmcgVendorQry.whereFmcgVendorNameEQ(getFmcgVendorName());
			fmcgVendorQry.query(connection);
            if(fmcgVendorQry.size() > 0)
            {
                    log.info("FMCG Vendor name is already exist in INV");
                    return false;
            }          
        }
        catch(Exception e)
        {
            e.printStackTrace();
            setStatus(InvErrorCode.ERROR_GETTING_VENDOR_DETAILS);
            return false;
        }
        setStatus(InvErrorCode.SUCCESS);
        return true;
    }
    public boolean deleteFmcgVendor() {
		try {
			if (getFmcgVendorId() <= 0) {
				setStatus(InvErrorCode.INVALID_INPUT);
				return false;
			}
			DBTblFmcgVendor fmcgVendorDb = new DBTblFmcgVendor();
			fmcgVendorDb.whereFmcgVendorIdEQ(fmcgVendorId);
			fmcgVendorDb.deleteByWhere(connection);
		} catch (SQLException s) {
			setStatus(InvErrorCode.DB_EXCEPTION);
			log.info("DB_FAILURE in deleteFmcgVendor");
			s.printStackTrace();
			return false;
		}
		setStatus(InvErrorCode.SUCCESS);
		//setStatusDesc("Successfully DELETED Location into the DB");
		return true;
	}

	public boolean updateFmcgVendor() {
		try {
			if (fmcgVendorId < 0) {
				setStatus(InvErrorCode.INTERNAL_ERROR);
				System.out
						.println("FAILURE in updateFmcgVendor fmcgVendorId missing.");
				return false;
			}
			DBTblFmcgVendor fmcgVendorDb = getFmcgVendorInfoToUpdate();
			fmcgVendorDb.whereFmcgVendorIdEQ(getFmcgVendorId());
			if (fmcgVendorDb.updateSpByWhere(connection) <= 0)
				return false;
		} catch (SQLException s) {
			setStatus(InvErrorCode.DB_EXCEPTION);
			log.info("DB_FAILURE in updateFmcgVendor FmcgVendor");
			s.printStackTrace();
			return false;
		}
		setStatus(InvErrorCode.SUCCESS);
		return true;
	}

	private DBTblFmcgVendor getFmcgVendorInfoToUpdate() {
		DBTblFmcgVendor fmcgVendorDb = new DBTblFmcgVendor();
		FmcgVendorBean defFmcgVendorBean = new FmcgVendorBean();
		FmcgVendor inputFmcgVendor = this;
		fmcgVendorDb.setFmcgVendorId(fmcgVendorId);

		if (inputFmcgVendor.getFmcgVendorDesc() != null
				&& !inputFmcgVendor.getFmcgVendorDesc().equals(
						defFmcgVendorBean.getFmcgVendorDesc())) {
			fmcgVendorDb.setFmcgVendorDesc(inputFmcgVendor.getFmcgVendorDesc());
		}
		if (inputFmcgVendor.getFmcgVendorName() != null
				&& !inputFmcgVendor.getFmcgVendorName().equals(
						defFmcgVendorBean.getFmcgVendorName())) {
			fmcgVendorDb.setFmcgVendorName(inputFmcgVendor.getFmcgVendorName());
		}
		if (inputFmcgVendor.getCreatedBy() != null
				&& !("".equalsIgnoreCase(inputFmcgVendor.getCreatedBy())))
			fmcgVendorDb.setCreatedBy(getCreatedBy());
		else
			fmcgVendorDb.setCreatedBy("ESAP_INV");

		if (inputFmcgVendor.getModifiedBy() != null
				&& !("".equalsIgnoreCase(inputFmcgVendor.getModifiedBy())))
			fmcgVendorDb.setModifiedBy(getModifiedBy());
		else
			fmcgVendorDb.setModifiedBy("ESAP_INV");

		fmcgVendorDb.setLastModifiedDate(new Timestamp(System
				.currentTimeMillis()));

		return fmcgVendorDb;

	}
}
