/**
 * 
 */
package com.vz.esap.api.service.model;

import java.io.Serializable;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.vz.esap.api.model.TblRow;

/**
 * @author Aricent
 *
 */
public class TblGroupFeaturesDbBean implements Serializable{
	
	private boolean bsequenceQueried;
	private int groupFeatureId;
	private boolean bgroupFeatureIdSet;
	private long groupId;
	private boolean bgroupIdSet;
	private long featureId;
	private boolean bfeatureIdSet;
	private String createdBy;
	private boolean bcreatedBySet;
	private Timestamp creationDate;
	private boolean bcreationDateSet;
	private String modifiedBy;
	private boolean bmodifiedBySet;
	private Timestamp lastModifiedDate;
	private boolean blastModifiedDateSet;
	private long envOrderId;
	private boolean benvOrderIdSet;
	private boolean benvOrderIdNull;
	//private Vector clauseValues;
	private String propfile;
	private String clause;
	
	public TblGroupFeaturesDbBean() {
		this.bsequenceQueried = false;

		this.bgroupFeatureIdSet = false;

		this.bgroupIdSet = false;

		this.bfeatureIdSet = false;

		this.bcreatedBySet = false;

		this.bcreationDateSet = false;

		this.bmodifiedBySet = false;

		this.blastModifiedDateSet = false;

		this.benvOrderIdSet = false;
		this.benvOrderIdNull = true;

		//this.clauseValues = new Vector();
		this.propfile = "dev";
		this.clause = "";
	}

	/**
	 * @return the bsequenceQueried
	 */
	public boolean isBsequenceQueried() {
		return bsequenceQueried;
	}

	/**
	 * @param bsequenceQueried the bsequenceQueried to set
	 */
	public void setBsequenceQueried(boolean bsequenceQueried) {
		this.bsequenceQueried = bsequenceQueried;
	}

	/**
	 * @return the groupFeatureId
	 */
	public int getGroupFeatureId() {
		return groupFeatureId;
	}

	/**
	 * @param groupFeatureId the groupFeatureId to set
	 */
	public void setGroupFeatureId(int groupFeatureId) {
		this.groupFeatureId = groupFeatureId;
	}

	/**
	 * @return the bgroupFeatureIdSet
	 */
	public boolean isBgroupFeatureIdSet() {
		return bgroupFeatureIdSet;
	}

	/**
	 * @param bgroupFeatureIdSet the bgroupFeatureIdSet to set
	 */
	public void setBgroupFeatureIdSet(boolean bgroupFeatureIdSet) {
		this.bgroupFeatureIdSet = bgroupFeatureIdSet;
	}

	/**
	 * @return the groupId
	 */
	public long getGroupId() {
		return groupId;
	}

	/**
	 * @param groupId the groupId to set
	 */
	public void setGroupId(long groupId) {
		this.groupId = groupId;
	}

	/**
	 * @return the bgroupIdSet
	 */
	public boolean isBgroupIdSet() {
		return bgroupIdSet;
	}

	/**
	 * @param bgroupIdSet the bgroupIdSet to set
	 */
	public void setBgroupIdSet(boolean bgroupIdSet) {
		this.bgroupIdSet = bgroupIdSet;
	}

	/**
	 * @return the featureId
	 */
	public long getFeatureId() {
		return featureId;
	}

	/**
	 * @param featureId the featureId to set
	 */
	public void setFeatureId(long featureId) {
		this.featureId = featureId;
	}

	/**
	 * @return the bfeatureIdSet
	 */
	public boolean isBfeatureIdSet() {
		return bfeatureIdSet;
	}

	/**
	 * @param bfeatureIdSet the bfeatureIdSet to set
	 */
	public void setBfeatureIdSet(boolean bfeatureIdSet) {
		this.bfeatureIdSet = bfeatureIdSet;
	}

	/**
	 * @return the createdBy
	 */
	public String getCreatedBy() {
		return createdBy;
	}

	/**
	 * @param createdBy the createdBy to set
	 */
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	/**
	 * @return the bcreatedBySet
	 */
	public boolean isBcreatedBySet() {
		return bcreatedBySet;
	}

	/**
	 * @param bcreatedBySet the bcreatedBySet to set
	 */
	public void setBcreatedBySet(boolean bcreatedBySet) {
		this.bcreatedBySet = bcreatedBySet;
	}

	/**
	 * @return the creationDate
	 */
	public Timestamp getCreationDate() {
		return creationDate;
	}

	/**
	 * @param creationDate the creationDate to set
	 */
	public void setCreationDate(Timestamp creationDate) {
		this.creationDate = creationDate;
	}

	/**
	 * @return the bcreationDateSet
	 */
	public boolean isBcreationDateSet() {
		return bcreationDateSet;
	}

	/**
	 * @param bcreationDateSet the bcreationDateSet to set
	 */
	public void setBcreationDateSet(boolean bcreationDateSet) {
		this.bcreationDateSet = bcreationDateSet;
	}

	/**
	 * @return the modifiedBy
	 */
	public String getModifiedBy() {
		return modifiedBy;
	}

	/**
	 * @param modifiedBy the modifiedBy to set
	 */
	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	/**
	 * @return the bmodifiedBySet
	 */
	public boolean isBmodifiedBySet() {
		return bmodifiedBySet;
	}

	/**
	 * @param bmodifiedBySet the bmodifiedBySet to set
	 */
	public void setBmodifiedBySet(boolean bmodifiedBySet) {
		this.bmodifiedBySet = bmodifiedBySet;
	}

	/**
	 * @return the lastModifiedDate
	 */
	public Timestamp getLastModifiedDate() {
		return lastModifiedDate;
	}

	/**
	 * @param lastModifiedDate the lastModifiedDate to set
	 */
	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	/**
	 * @return the blastModifiedDateSet
	 */
	public boolean isBlastModifiedDateSet() {
		return blastModifiedDateSet;
	}

	/**
	 * @param blastModifiedDateSet the blastModifiedDateSet to set
	 */
	public void setBlastModifiedDateSet(boolean blastModifiedDateSet) {
		this.blastModifiedDateSet = blastModifiedDateSet;
	}

	/**
	 * @return the envOrderId
	 */
	public long getEnvOrderId() {
		return envOrderId;
	}

	/**
	 * @param envOrderId the envOrderId to set
	 */
	public void setEnvOrderId(long envOrderId) {
		this.envOrderId = envOrderId;
	}

	/**
	 * @return the benvOrderIdSet
	 */
	public boolean isBenvOrderIdSet() {
		return benvOrderIdSet;
	}

	/**
	 * @param benvOrderIdSet the benvOrderIdSet to set
	 */
	public void setBenvOrderIdSet(boolean benvOrderIdSet) {
		this.benvOrderIdSet = benvOrderIdSet;
	}

	/**
	 * @return the benvOrderIdNull
	 */
	public boolean isBenvOrderIdNull() {
		return benvOrderIdNull;
	}

	/**
	 * @param benvOrderIdNull the benvOrderIdNull to set
	 */
	public void setBenvOrderIdNull(boolean benvOrderIdNull) {
		this.benvOrderIdNull = benvOrderIdNull;
	}

	/**
	 * @return the propfile
	 */
	public String getPropfile() {
		return propfile;
	}

	/**
	 * @param propfile the propfile to set
	 */
	public void setPropfile(String propfile) {
		this.propfile = propfile;
	}

	/**
	 * @return the clause
	 */
	public String getClause() {
		return clause;
	}

	/**
	 * @param clause the clause to set
	 */
	public void setClause(String clause) {
		this.clause = clause;
	}
	
	public void copyFromBean(TblRow bean) throws ParseException {
		setGroupFeatureId(Integer.parseInt(bean.getTblRow().get("GROUP_FEATURE_ID").getValue()));
		setGroupId(Long.parseLong(bean.getTblRow().get("GROUP_ID").getValue()));
		setFeatureId(Long.parseLong(bean.getTblRow().get("FEATURE_ID").getValue()));
		setCreatedBy(bean.getTblRow().get("CREATED_BY").getValue());
		setCreationDate(getTimeStampDate(bean.getTblRow().get("CREATION_DATE").getValue()));
		setModifiedBy(bean.getTblRow().get("MODIFIED_BY").getValue());
		setLastModifiedDate(getTimeStampDate(bean.getTblRow().get("LAST_MODIFIED_DATE").getValue()));
		setEnvOrderId(Long.parseLong(bean.getTblRow().get("ENV_ORDER_ID").getValue()));
	}
	public void copyFromDBObject(TblGroupFeaturesDbBean bean) {
		setGroupFeatureId(bean.getGroupFeatureId());
		setGroupId(bean.getGroupId());
		setFeatureId(bean.getFeatureId());
		setCreatedBy(bean.getCreatedBy());
		setCreationDate(bean.getCreationDate());
		setModifiedBy(bean.getModifiedBy());
		setLastModifiedDate(bean.getLastModifiedDate());
		setEnvOrderId(bean.getEnvOrderId());
	}

	private Timestamp getTimeStampDate(String value) throws ParseException {
		DateFormat formatter;
		formatter = new SimpleDateFormat("dd/MM/yyyy");
		Date date = (Date) formatter.parse(value);
		Timestamp timeStampDate = new Timestamp(date.getTime());
		return timeStampDate;
	}
	
	

}
