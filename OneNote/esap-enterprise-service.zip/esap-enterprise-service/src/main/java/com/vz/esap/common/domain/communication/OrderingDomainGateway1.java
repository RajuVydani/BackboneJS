package com.vz.esap.common.domain.communication;

/**
 * @author Siva Adabala
 *
 */
import java.text.SimpleDateFormat;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.vz.esap.common.communication.RestClient;
import com.vz.esap.common.request.OrderHeader;
import com.vz.esap.common.request.TnOrderDetailsResponse;
import com.vz.esap.common.request.TnOrderHeader;

@Service
public class OrderingDomainGateway1 {
	
	private static Logger log = LoggerFactory
			.getLogger(OrderingDomainGateway1.class);

	@Value("${ordering.svcUsername}")
	private String svcUsername;

	@Value("${ordering.svcPassword}")
	private String svcPassword;

	@Value("${ordering.tblOrderLogLoggingServiceUrl}")
	private String tblOrderLogLoggingServiceUrl;
	
	@Value("${ordering.getTNOrderDetailsUrl}")
	private String getTNOrderDetailsUrl;
	
	@Autowired
	private RestClient restClient;

	private String pattern = "yyyy-MM-dd HH:mm:ss.SSS";
	private SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);

	public TnOrderDetailsResponse getAddETTnOrderDetails(OrderHeader orderHeader,long startTNRange,long endTNRange) throws JsonProcessingException{
		ObjectMapper mapper = new ObjectMapper();
		
			log.info("Input for getTnOrderDetails - :"
					+ mapper.writerWithDefaultPrettyPrinter()
							.writeValueAsString(orderHeader));
		
				TnOrderHeader tnOrderHeader = new TnOrderHeader();
				tnOrderHeader.setWorkOrderNumber(orderHeader
						.getWorkOrderNumber());
				tnOrderHeader.setWorkOrderVersion(orderHeader
						.getWorkOrderVersion());
				tnOrderHeader.setOrderType("IN"); // ADD TN
				tnOrderHeader.setTnType("ET_TN"); // ET TN
				tnOrderHeader.setStartRange(startTNRange);
				tnOrderHeader.setEndRange(endTNRange);

				
				TnOrderDetailsResponse tnOrderDetailsResponse = (TnOrderDetailsResponse) restClient
						.invokeService(tnOrderHeader, getTNOrderDetailsUrl,
								svcUsername, svcPassword,
								TnOrderDetailsResponse.class);

				log.info("InventoryTNService - Input for tnActivation :"
						+ mapper.writerWithDefaultPrettyPrinter()
								.writeValueAsString(tnOrderDetailsResponse));
		
		return tnOrderDetailsResponse;
	}
}
