/**
 * File: VZBAFException.java
 *
 * Author: Naveen Murthy
 *
 */
package com.vz.esap.api.exception;

public class VZBAFException extends Exception
{

  /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

// Constructor receives some kind of message that is saved in an instance variable.
  public VZBAFException(String err)
  {
    super(err);     // call super class constructor

  }

}

