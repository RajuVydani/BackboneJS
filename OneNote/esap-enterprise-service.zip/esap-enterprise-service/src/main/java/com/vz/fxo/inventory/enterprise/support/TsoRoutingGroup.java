package com.vz.fxo.inventory.enterprise.support;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Timestamp;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.vz.fxo.inventory.enterprise.support.InvErrorCode;

import esap.db.DBTblTsoEnterpriseTrunk;
import esap.db.DBTblTsoRoutingGroup;
import esap.db.DBTblTsoTrunkGroup;
import esap.db.TblTsoEnterpriseTrunkQuery;
import esap.db.TblTsoRoutingGroupQuery;

public class TsoRoutingGroup extends TsoRoutingGroupBean {

	private static Logger log = LoggerFactory.getLogger(TsoRoutingGroup.class
			.toString());
	private InvErrorCode status;
	Connection dbCon;
	String statusDesc;

	public InvErrorCode getStatus() {
		return status;
	}

	
	public void setStatus(InvErrorCode status) {
		this.status = status;
	}

	public Connection getDbCon() {
		return dbCon;
	}

	public void setDbCon(Connection dbCon) {
		this.dbCon = dbCon;
	}

	public String getStatusDesc() {
		return statusDesc;
	}

    public TsoRoutingGroup(Connection connection) {
        super();
        this.dbCon = connection;
    }

	public void setStatusDesc(String statusDesc) {
		this.statusDesc = statusDesc;
	}

	public boolean addToDB() throws SQLException, Exception {

		DBTblTsoRoutingGroup tsoRoutingGroupDbBean = new DBTblTsoRoutingGroup();

		tsoRoutingGroupDbBean.setRoutingGroupId(routingGroupId);
		tsoRoutingGroupDbBean.setRoutingGroupName(routingGroupName);
		tsoRoutingGroupDbBean.setEnterpriseId(enterpriseId);
		tsoRoutingGroupDbBean.setGroupClid(groupClid);
		tsoRoutingGroupDbBean.setUseFlag(useFlag);
		tsoRoutingGroupDbBean.setCreatedBy(createdBy);
		tsoRoutingGroupDbBean.setModifiedBy(modifiedBy);
		tsoRoutingGroupDbBean.setCreationDate(creationDate);
		tsoRoutingGroupDbBean.setLastModifiedDate(lastModifiedDate);

		return true;
	}

	public boolean modifyInDB() throws SQLException, Exception {

		if (routingGroupId == null) {
			//setStatus(InvErrorCode.MISSING_LOCATION_ID);
			log.info("FAILURE in modifyInDB routingGroup. routingGroup Id missing.");
			return false;
		}
		DBTblTsoRoutingGroup tsoRoutingGroupDbBean = getTsoRoutingGroupToUpdate();
		log.info("Got tsoRoutingGroup Details to Update for routingGroupId:" + routingGroupId);
		tsoRoutingGroupDbBean.whereRoutingGroupIdEQ(routingGroupId);
		log.info("Going to Update tsoRoutingGroup in DB");
		// FkValidationUtil.isValidLocationForMod(dbCon,tsoEnterpriseDbBean);
		
		if (tsoRoutingGroupDbBean.updateSpByWhere(dbCon) <= 0) {
			log.info("No tsoRoutingGroup updated");
			//setStatus(InvErrorCode.NO_LOCATION_UPDATED);
		  return false;
		}
		log.info("Successfully updated TsoRoutingGroup");
		setStatus(InvErrorCode.SUCCESS);
		log.info("Successfully UPDATED TsoRoutingGroup into the DB");
		return true;
	}

	private DBTblTsoRoutingGroup getTsoRoutingGroupToUpdate() throws SQLException {

		DBTblTsoRoutingGroup tsoRoutingGroupDbBean = new DBTblTsoRoutingGroup();
		/*
		 * Create a new instance of tsoRoutingGroupDbBean. The new instance
		 * would hold default values for the all the tsoRoutingGroupDbBean
		 * fields.
		 */
		TsoRoutingGroupBean defaultTsoRoutingGroupBean = new TsoRoutingGroupBean();
		TsoRoutingGroup inputTsoRoutingGroup = this;
		tsoRoutingGroupDbBean.setRoutingGroupId(routingGroupId);
		TblTsoRoutingGroupQuery tsoRouQry = new TblTsoRoutingGroupQuery();
		tsoRouQry.whereRoutingGroupIdEQ(inputTsoRoutingGroup.getRoutingGroupId());
		tsoRouQry.query(dbCon);

		if (inputTsoRoutingGroup.getRoutingGroupName() != null && !inputTsoRoutingGroup.getRoutingGroupName().equals(defaultTsoRoutingGroupBean.getRoutingGroupName())) {
			tsoRoutingGroupDbBean.setRoutingGroupName(inputTsoRoutingGroup.getRoutingGroupName());
		}
		if (inputTsoRoutingGroup.getEnterpriseId() != null	&& !inputTsoRoutingGroup.getEnterpriseId().equals(defaultTsoRoutingGroupBean.getEnterpriseId())) {
			tsoRoutingGroupDbBean.setEnterpriseId(inputTsoRoutingGroup.getEnterpriseId());
		}
		if (inputTsoRoutingGroup.getGroupClid() != null && !inputTsoRoutingGroup.getGroupClid().equals(defaultTsoRoutingGroupBean.getGroupClid())) {
			tsoRoutingGroupDbBean.setGroupClid(inputTsoRoutingGroup.getGroupClid());
		}
		if (inputTsoRoutingGroup.getUseFlag() != 0 && inputTsoRoutingGroup.getUseFlag() != defaultTsoRoutingGroupBean.getUseFlag()) {
			tsoRoutingGroupDbBean.setUseFlag(inputTsoRoutingGroup.getUseFlag());
		}
		if (inputTsoRoutingGroup.getModifiedBy() != null && !inputTsoRoutingGroup.getModifiedBy().equals(defaultTsoRoutingGroupBean.getModifiedBy())) {
			tsoRoutingGroupDbBean.setModifiedBy(inputTsoRoutingGroup.getModifiedBy());
		}
		if (inputTsoRoutingGroup.getLastModifiedDate() != null && !inputTsoRoutingGroup.getLastModifiedDate().equals(defaultTsoRoutingGroupBean.getLastModifiedDate())) {
			tsoRoutingGroupDbBean.setLastModifiedDate(inputTsoRoutingGroup.getLastModifiedDate());
		}

		return tsoRoutingGroupDbBean;
	}

	public boolean deleteFromDB() throws SQLException, Exception {

		if (getRoutingGroupId() == null) {
			log.info("Invalid Input");
			setStatus(InvErrorCode.INVALID_INPUT);
			return false;
		}

        DBTblTsoTrunkGroup tsoEntLorSbcBean = new DBTblTsoTrunkGroup();
        tsoEntLorSbcBean.whereRoutingGroupIdEQ(getRoutingGroupId());
        tsoEntLorSbcBean.deleteByWhere(dbCon); 

		DBTblTsoRoutingGroup tsoRoutingGroupDbBean = new DBTblTsoRoutingGroup();
		tsoRoutingGroupDbBean.whereRoutingGroupIdEQ(getRoutingGroupId());
		tsoRoutingGroupDbBean.deleteByWhere(dbCon);

		log.info("Successfully deleted TsoRoutingGroup");
		setStatusDesc("Successfully deleted TsoRoutingGroup ");

		return true;
	}

}
