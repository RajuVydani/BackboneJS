package com.vz.esap.api.model.config;

public class TableRouteInfoParam {
		
	private String device;
	private String paramName;
	private String paramValue;
	private String connectionType;
	
	private TableRouteInfoParam(TableRouteInfoParamBuilder tableRouteInfoParamBuilder) {
		this.device = tableRouteInfoParamBuilder.device;
		this.paramName = tableRouteInfoParamBuilder.paramName;
		this.paramValue = tableRouteInfoParamBuilder.paramValue;
		this.connectionType = tableRouteInfoParamBuilder.connectionType;
	}
	
	public String getDevice() {
		return device;
	}

	public void setDevice(String device) {
		this.device = device;
	}

	public String getParamName() {
		return paramName;
	}

	public void setParamName(String paramName) {
		this.paramName = paramName;
	}

	public String getParamValue() {
		return paramValue;
	}

	public void setParamValue(String paramValue) {
		this.paramValue = paramValue;
	}

	public String getConnectionType() {
		return connectionType;
	}

	public void setConnectionType(String connectionType) {
		this.connectionType = connectionType;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("TableRouteInfoParam [device=");
		builder.append(device);
		builder.append(", paramName=");
		builder.append(paramName);
		builder.append(", paramValue=");
		builder.append(paramValue);
		builder.append(", connectionType=");
		builder.append(connectionType);
		builder.append("]");
		return builder.toString();
	}

	public static class TableRouteInfoParamBuilder {
		private String device;
		private String paramName;
		private String paramValue;
		private String connectionType;
		
		public TableRouteInfoParamBuilder withDevice(String device) {
			this.device = device;
			return this;
		}
		
		public TableRouteInfoParamBuilder withParamName(String paramName) {
			this.paramName = paramName;
			return this;
		}
		public TableRouteInfoParamBuilder withParamValue(String paramValue) {
			this.paramValue = paramValue;
			return this;
		}
		public TableRouteInfoParamBuilder withConnectionType(String connectionType) {
			this.connectionType = connectionType;
			return this;
		}
		
		public TableRouteInfoParam build() {
			return new TableRouteInfoParam(this);
		}
		
	}
	
	
}
