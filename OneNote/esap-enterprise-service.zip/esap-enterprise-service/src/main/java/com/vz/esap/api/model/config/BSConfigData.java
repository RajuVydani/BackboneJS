package com.vz.esap.api.model.config;

import java.util.ArrayList;
import java.util.List;

public class BSConfigData {
	private String baseClli;
	private List<Device> deviceList;
	
	private BSConfigData(BSConfigDataBuilder bsConfigDataBuilder) {
		this.baseClli = bsConfigDataBuilder.baseClli;
		this.deviceList = bsConfigDataBuilder.deviceList;
	}
	
	public String getBaseClli() {
		return baseClli;
	}
	public void setBaseClli(String baseClli) {
		this.baseClli = baseClli;
	}
	public List<Device> getDeviceList() {
		return deviceList;
	}
	public void setDeviceList(List<Device> deviceList) {
		this.deviceList = deviceList;
	}
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("BSConfigData [baseClli=");
		builder.append(baseClli);
		builder.append(", deviceList=");
		builder.append(deviceList);
		builder.append("]");
		return builder.toString();
	}
	
	
	public static class BSConfigDataBuilder {
		private String baseClli;
		private List<Device> deviceList = new ArrayList<>();
		
		public BSConfigDataBuilder withBaseClli(String baseClli) {
			this.baseClli = baseClli;
			return this;
		}
		
		public BSConfigDataBuilder addDevice(Device device) {
			this.deviceList.add(device);
			return this;
		}
		
		public BSConfigData build() {
			return new BSConfigData(this);
		}
		
	}
	

}
