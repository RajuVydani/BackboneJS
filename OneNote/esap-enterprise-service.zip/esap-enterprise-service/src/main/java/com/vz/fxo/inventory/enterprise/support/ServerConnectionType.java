package com.vz.fxo.inventory.enterprise.support;

public class ServerConnectionType {
	public static final ServerConnectionType TELNET = new ServerConnectionType("TELNET");
	public static final ServerConnectionType SSH = new ServerConnectionType("SSH");
	
	private String type; 
	public ServerConnectionType (String type){
		this.type = type;
	}
	
	public String getName(){
		return this.type;
	}
	
	public String toString(){
		return this.type;
	}
}
