package com.vz.esap.api.model.ordering;

import java.util.ArrayList;
import java.util.List;

import com.vz.esap.api.model.ESAPEntityEnum;

public class OrderSearchFilter {

	private ESAPEntityEnum entityType;
	private Long startIndex;
	private Long endIndex;
	private List<String> paramNameList;


	private OrderSearchFilter(OrderSearchFilterBuilder orderSearchFilterBuilder) {
		this.entityType = orderSearchFilterBuilder.entityType;
		this.startIndex = orderSearchFilterBuilder.startIndex;
		this.endIndex = orderSearchFilterBuilder.endIndex;
		this.paramNameList = orderSearchFilterBuilder.paramNameList;
	}

	public ESAPEntityEnum getEntityType() {
		return entityType;
	}

	public void setEntityType(ESAPEntityEnum entityType) {
		this.entityType = entityType;
	}

	public Long getStartIndex() {
		return startIndex;
	}

	public void setStartIndex(Long startIndex) {
		this.startIndex = startIndex;
	}

	public Long getEndIndex() {
		return endIndex;
	}

	public void setEndIndex(Long endIndex) {
		this.endIndex = endIndex;
	}

	public List<String> getParamNameList() {
		return paramNameList;
	}

	public void setParamNameList(List<String> paramNameList) {
		this.paramNameList = paramNameList;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("OrderSearchFilter [entityType=");
		builder.append(entityType);
		builder.append(", startIndex=");
		builder.append(startIndex);
		builder.append(", endIndex=");
		builder.append(endIndex);
		builder.append(", paramNameList=");
		builder.append(paramNameList);
		builder.append("]");
		return builder.toString();
	}
	
	
	public static class OrderSearchFilterBuilder {
		private ESAPEntityEnum entityType;
		private Long startIndex;
		private Long endIndex;
		private List<String> paramNameList = new ArrayList<>();
		
		public OrderSearchFilterBuilder withEntityType(ESAPEntityEnum entityType) {
			this.entityType = entityType;
			return this;
		}
		
		public OrderSearchFilterBuilder withStartIndex(Long startIndex) {
			this.startIndex = startIndex;
			return this;
		}
		
		public OrderSearchFilterBuilder withEndIndex(Long endIndex) {
			this.endIndex = endIndex;
			return this;
		}
		
		public OrderSearchFilterBuilder addParamName(String paramName) {
			this.paramNameList.add(paramName);
			return this;
		}
		
		public OrderSearchFilter build() {
			return new OrderSearchFilter(this);
		}

	}

	
}
