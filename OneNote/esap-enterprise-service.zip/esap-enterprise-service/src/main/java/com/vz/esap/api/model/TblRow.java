package com.vz.esap.api.model;

import java.util.Map;

public class TblRow {
	private Map<String,TblCell> tblRow;

	public Map<String, TblCell> getTblRow() {
		return tblRow;
	}

	public void setTblRow(Map<String, TblCell> tblRow) {
		this.tblRow = tblRow;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("TblRow [tblRow=");
		builder.append(tblRow);
		builder.append("]");
		return builder.toString();
	}
	

}
