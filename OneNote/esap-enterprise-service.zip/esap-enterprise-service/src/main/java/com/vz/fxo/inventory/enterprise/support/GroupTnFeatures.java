/**
 * 
 */
package com.vz.fxo.inventory.enterprise.support;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.Timestamp;
import java.sql.ResultSet;

import esap.db.DBTblGroupTnFeatures;
import esap.db.TblVzbFeaturesQuery;

/**
 * @author V527824
 *
 */
public class GroupTnFeatures extends GroupTnFeaturesBean{
	
	private static Logger log = LoggerFactory.getLogger(PublicTnPool.class.toString());
	
	private Connection connection;
	//Connection connection;
	 
	 private InvErrorCode status;
	 InvErrorCode statusCode;
	 String statusDesc;
	 
	 public GroupTnFeatures(Connection connection){
	        this.connection = connection;	
	 }
	 
	 public GroupTnFeatures(GroupTnFeaturesBean gtfDbBean, Connection connection){
	        super(gtfDbBean);
	        this.connection = connection;			
	 }
	    
	 public Connection getconnection() {		 
		return connection;
	}

	public void setconnection(Connection connection) {
		this.connection = connection;
	}

	public InvErrorCode getStatus() {
		return status;
	}

	public int getStatusCode()
	{
        return status.getErrorCode();
    }
    public void setStatus(InvErrorCode status)
    {
        this.status = status;
    }
    public String getStatusDesc()
    {
        return status.getErrorDesc();
    }

    public void setStatusDesc(String statusDesc) {
		this.statusDesc = statusDesc;
	}
	
	 public boolean addToDB() throws SQLException,  Exception
	 {


		log.info(" addToDB() in GroupTnFeaturesBean .... ");

		 DBTblGroupTnFeatures grpTnFeaturesDbObj = new DBTblGroupTnFeatures();
		 grpTnFeaturesDbObj.setGrpTnFeatureId(grpTnFeaturesDbObj.getGrpTnFeatureIdSeqNextVal(connection));
		 grpTnFeaturesDbObj.setGroupTnId(groupTnId);
		 grpTnFeaturesDbObj.setFeatureId(featureId);
		 grpTnFeaturesDbObj.setCreatedBy(createdBy);
		 grpTnFeaturesDbObj.setCreationDate(creationDate);
		 grpTnFeaturesDbObj.setModifiedBy(modifiedBy);
		 grpTnFeaturesDbObj.setLastModifiedDate(lastModifiedDate);
		 grpTnFeaturesDbObj.setEnvOrderId(envOrderId);

		 grpTnFeaturesDbObj.insert(connection);

		log.info(" successfully inserted values in addToDB() in GroupTnFeatures .... ");

		 return true;

	 }
	 
	 
	 public boolean deleteFromDB() throws SQLException,  Exception{
		 boolean ret_code = true;		 
		 try
		 {
			 if ( grpTnFeatureId <= 0 ) {
				log.info("FAILURE in deleteFromDB GroupTnFeatures. Invalid GroupFeatureTnId.");
				 return false;
			 }
			 DBTblGroupTnFeatures grpTnFeatures = new  DBTblGroupTnFeatures();		       
			 grpTnFeatures.whereGrpTnFeatureIdEQ(getGrpTnFeatureId());

			 int grpTnFeatureDeleted = grpTnFeatures.deleteByWhere(connection);
			log.info("grpTnFeatureDeleted : " + grpTnFeatureDeleted);

			 setStatus(InvErrorCode.SUCCESS);
		 }catch(SQLException s)
		 {
			 throw s;
		 }
		 catch (Exception e) {
			 throw e;
		 }
		 return ret_code; 
	 }
	 
	 public boolean deleteFromDBByGroupTnAndFeatureId() throws SQLException,  Exception{
		 boolean ret_code = true;		 
		 try
		 {
			 if ( featureId <= 0 ) {
				log.info("FAILURE in deleteFromDBByGroupTnAndFeatureId GroupTnFeatures. Invalid GroupFeatureTnId.");
				 return false;
			 }
			 if ( groupTnId <= 0 ) {
				log.info("FAILURE in deleteFromDBByGroupTnAndFeatureId GroupTnFeatures. Invalid groupTnId.");
				 return false;
			 }
			 
			 DBTblGroupTnFeatures grpTnFeatures = new  DBTblGroupTnFeatures();		       
			 grpTnFeatures.whereFeatureIdEQ(getFeatureId());
			 grpTnFeatures.whereGroupTnIdEQ(getGroupTnId());
			 
			 int grpTnFeatureDeleted = grpTnFeatures.deleteByWhere(connection);
			log.info("grpTnFeatureDeleted : " + grpTnFeatureDeleted);

			 setStatus(InvErrorCode.SUCCESS);
		 }catch(SQLException s)
		 {
			 throw s;
		 }
		 catch (Exception e) {
			 throw e;
		 }
		 return ret_code; 
	 }
	 public boolean deleteFromDBByGroupTn() throws SQLException,  Exception{
		 boolean ret_code = true;		 
		 try
		 {
			 if ( groupTnId <= 0 ) {
				log.info("FAILURE in deleteFromDBByGroupTn GroupTnFeatures. Invalid GroupTnId.");
				 return false;
			 }
			 DBTblGroupTnFeatures grpTnFeatures = new  DBTblGroupTnFeatures();		       
			 grpTnFeatures.whereGroupTnIdEQ(getGroupTnId());

			 int grpTnFeatureDeleted = grpTnFeatures.deleteByWhere(connection);
			log.info("grpTnFeatureDeleted : " + grpTnFeatureDeleted);

			 setStatus(InvErrorCode.SUCCESS);
		 }catch(SQLException s)
		 {
			 throw s;
		 }
		 catch (Exception e) {
			 throw e;
		 }
		 return ret_code; 
	 }
	 public List<String>  getPbxTnLineFeaturesByTNGroupId (long groupTnId) throws Exception {
		//log.info("In getPbxTnLineFeaturesByTNGroupId");

		 List<String>  grpTnFeaturesList = new ArrayList<String>();
		 StringBuffer sql = new StringBuffer();
		 PreparedStatement pStmt = null;
		 ResultSet rs = null;
		 try{
			 sql.append("select feature_id from tbl_group_tn_features where group_tn_id = ?");
			   //LogUtil.info(" Sql  " + sql.toString() );

			 pStmt = connection.prepareStatement(sql.toString());
			 pStmt.setInt(1, (int)groupTnId);
			 if (pStmt != null){
				 rs = pStmt.executeQuery();
				 while ( rs.next()){
					 long featureId = rs.getLong(1);
					 //get the feature name
					 TblVzbFeaturesQuery vzbFeatsQry = new TblVzbFeaturesQuery();
					 vzbFeatsQry.whereFeatureIdEQ((int)featureId);
					 vzbFeatsQry.query(connection);
					 if (vzbFeatsQry.size() > 0) {
						 grpTnFeaturesList.add(vzbFeatsQry.getDbBean(0).getName());
					 }
				 }
			 }
			//log.info(" grpTnFeaturesList :: "+grpTnFeaturesList.size());
		 }catch (SQLException e) {
			 e.printStackTrace();
			log.info("DB_FAILURE in getPbxTnLineFeaturesByTNGroupId");
			 //return regionId;
			 throw e;
		 }catch (Exception e) {
			 e.printStackTrace();
			 throw e;
		 }finally{
			 if (pStmt != null){
				 pStmt.close();
			 }
			 if ( rs != null ){
				 rs.close();
			 }
		 }

		 return grpTnFeaturesList;
	 }

	 public List<String>  getPbxTnLineFeaturesByTN (String tn) throws Exception {
		//log.info("In getPbxTnLineFeaturesByTN ");
		 StringBuffer sql = new StringBuffer();
		 PreparedStatement pStmt = null;
		 ResultSet rs = null;
		 List<String>  grpTnFeaturesList = new ArrayList<String>();
		 try{
			 sql.append("select gt.group_tn_id from tbl_group_tn gt ,tbl_public_tn_pool tp where gt.tn_pool_id = tp.tn_pool_id and tp.tn= \'" + tn +"\'");
			 pStmt = connection.prepareStatement(sql.toString());
			 if (pStmt != null){
				 rs = pStmt.executeQuery();
				 while ( rs.next()){
					 long grpTnID = rs.getInt(1);
					log.info("grpTnID :: "+grpTnID);
					 if(grpTnID >= 0 ){
						 grpTnFeaturesList.addAll(0,getPbxTnLineFeaturesByTNGroupId(grpTnID));
					 }
				 }
			 }
			log.info(" Features list size in getPbxTnLineFeaturesByTN : "+grpTnFeaturesList.size());
		 }catch (SQLException e) {
			 e.printStackTrace();
			log.info("DB_FAILURE in getPbxTnLineFeaturesByTN");
			 //return regionId;
			 throw e;
		 }catch (Exception e) {
			 e.printStackTrace();
			 throw e;
		 }finally{
			 if (pStmt != null){
				 pStmt.close();
			 }
			 if ( rs != null ){
				 rs.close();
			 }
		 }

		 return grpTnFeaturesList;

	 }
}
