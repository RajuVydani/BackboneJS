package com.vz.fxo.inventory.enterprise.query;

public class Container {
    private String enterpriseID;
    private String locationID;
    private String departmentID;
    private String subscriberID;
    private String deviceID;
    public String toString(){
        final String NEWLINE = "\n";
        StringBuffer retValue = new StringBuffer();
        retValue.append("Container ( ");
        retValue.append(super.toString()).append(NEWLINE);
        retValue.append("enterpriseID = ").append(this.enterpriseID).append(NEWLINE);
        retValue.append("locationID = ").append(this.locationID).append(NEWLINE);
        retValue.append("departmentID = ").append(this.departmentID).append(NEWLINE);
        retValue.append("subscriberID = ").append(this.subscriberID).append(NEWLINE);
        retValue.append("deviceID = ").append(this.deviceID).append(NEWLINE);
        retValue.append(" )");
        return retValue.toString();
    }
    public String getEnterpriseID() {
        return enterpriseID;
    }
    public void setEnterpriseID(String enterpriseID) {
        this.enterpriseID = enterpriseID;
    }
    public String getLocationID() {
        return locationID;
    }
    public void setLocationID(String locationID) {
        this.locationID = locationID;
    }
    public String getDepartmentID() {
        return departmentID;
    }
    public void setDepartmentID(String departmentID) {
        this.departmentID = departmentID;
    }
    public String getSubscriberID() {
        return subscriberID;
    }
    public void setSubscriberID(String subscriberID) {
        this.subscriberID = subscriberID;
    }
    public String getDeviceID() {
        return deviceID;
    }
    public void setDeviceID(String deviceID) {
        this.deviceID = deviceID;
    }
    
}
