package com.vz.fxo.inventory.enterprise.support;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Timestamp;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import EsapEnumPkg.VzbVoipEnum;

import esap.db.DBTblGatewayDeviceInfo;
import esap.db.DBTblTsoEbi;
import esap.db.DBTblTsoEnterpriseTrunk;
import esap.db.DBTblTsoEtTgMap;
import esap.db.TblIpsecProvRequestQuery;
import esap.db.TblTsoEbiQuery;
import esap.db.TblTsoEtTgMapQuery;

public class TsoEbi extends TsoEbiBean {

	private static Logger log = LoggerFactory.getLogger(TsoEbi.class.toString());

	private InvErrorCode status;
	Connection dbCon;
	String statusDesc;
	boolean rollbackFlag;
	
	public boolean isRollbackFlag() {
		return rollbackFlag;
	}

	public void setRollbackFlag(boolean rollbackFlag) {
		this.rollbackFlag = rollbackFlag;
	}
	 
	 public TsoEbi(Connection dbCon){
	        this.dbCon = dbCon;	
	 }
	 
	 public TsoEbi(TsoEbiBean ebiBean, Connection dbCon){
	        super(ebiBean);	  
	        this.dbCon = dbCon;			
	 }

	public InvErrorCode getStatus() {
		return status;
	}

	public void setStatus(InvErrorCode status) {
		this.status = status;
	}

	public Connection getDbCon() {
		return dbCon;
	}

	public void setDbCon(Connection dbCon) {
		this.dbCon = dbCon;
	}

	public String getStatusDesc() {
		return statusDesc;
	}

	public void setStatusDesc(String statusDesc) {
		this.statusDesc = statusDesc;
	}

	public boolean addToDB() throws SQLException, Exception {

		DBTblTsoEbi TsoEbiDbBean = new DBTblTsoEbi();

		TsoEbiDbBean.setEbiId(ebiId);
		TsoEbiDbBean.setEnterpriseId(enterpriseId);
		TsoEbiDbBean.setEbiName(ebiName);
		TsoEbiDbBean.setEbiIp(ebiIp);
		TsoEbiDbBean.setEbiPort(ebiPort);
		TsoEbiDbBean.setEbiFqdn(ebiFqdn);
		TsoEbiDbBean.setIpVersion(ipVersion);
		TsoEbiDbBean.setVpnName(vpnName);
		TsoEbiDbBean.setAccessType(accessType);
		TsoEbiDbBean.setCircuitId(circuitId);
		TsoEbiDbBean.setStreetAddress(streetAddress);
		TsoEbiDbBean.setCity(city);
		TsoEbiDbBean.setState(state);
		TsoEbiDbBean.setCountryCode(countryCode);
		TsoEbiDbBean.setCreatedBy(createdBy);
		TsoEbiDbBean.setModifiedBy(modifiedBy);
		TsoEbiDbBean.setCreationDate(creationDate);
		TsoEbiDbBean.setLastModifiedDate(lastModifiedDate);
		TsoEbiDbBean.setZip(zip);
		TsoEbiDbBean.setBsDeviceType(bsDeviceType);
		TsoEbiDbBean.setIpsecTunnelId(ipsecTunnelId);
		TsoEbiDbBean.setIsPwg(isPwg);
		TsoEbiDbBean.insert(dbCon);
		log.info("Ebi record added to DB");
		//updateIpsecTunnelId();
		return true;
	}
	
	public void updateIpsecTunnelId(long ebiId, long ipsecTunnelId) throws Exception {
		DBTblTsoEbi tblEbiInfo = new DBTblTsoEbi();
		tblEbiInfo.setIpsecTunnelId(ipsecTunnelId);
		tblEbiInfo.whereEbiIdEQ(ebiId);
		int ebiRecCountUpdated = tblEbiInfo.updateSpByWhere(dbCon);
		if(ebiRecCountUpdated == 0){
			log.info("No Records Updated");
		}else{
			log.info("Successfully Updated TsoEbi For IpSecTunnelId " + ebiRecCountUpdated);
		}
	}

	public boolean modifyInDB() throws SQLException, Exception {

		if (ebiId <= 0) {
			//setStatus(InvErrorCode.MISSING_LOCATION_ID);
			log.info("FAILURE in modifyInDB ebiId. ebi Id missing.");
			return false;
		}
		DBTblTsoEbi TsoEbiDbBean = getTsoEbiToUpdate();
		log.info("Got TsoEbi Details to Update for ebiId:" + ebiId);
		TsoEbiDbBean.whereEbiIdEQ(ebiId);
		log.info("Going to Update TsoEbi in DB");
		
		if (TsoEbiDbBean.updateSpByWhere(dbCon) <= 0) {
			log.info("No TsoEbi updated");
			//setStatus(InvErrorCode.NO_LOCATION_UPDATED);
			return false;
		}
		log.info("Successfully updated TsoEbi");
		setStatus(InvErrorCode.SUCCESS);
		log.info("Successfully UPDATED TsoEbi into the DB");
	  return true;
	}

	private DBTblTsoEbi getTsoEbiToUpdate() throws SQLException {

		/*
		 * Create a new instance of TsoEbiDbBean. The new instance would hold
		 * default values for the all the TsoEbiDbBean fields.
		 */
		DBTblTsoEbi TsoEbiDbBean = new DBTblTsoEbi();

		TsoEbiBean defaultTsoEbiBean = new TsoEbiBean();
		TsoEbi inputTsoEbi = this;
		TsoEbiDbBean.setEbiId(ebiId);
		TblTsoEbiQuery tsoEbiQry = new TblTsoEbiQuery();
		tsoEbiQry.whereEbiIdEQ(ebiId);
		tsoEbiQry.query(dbCon);
		
		
		if (inputTsoEbi.getEbiName() != null && !inputTsoEbi.getEbiName().equals(defaultTsoEbiBean.getEbiName())) {
			TsoEbiDbBean.setEbiName(inputTsoEbi.getEbiName());
		}
		if (inputTsoEbi.getEbiIp() != null && !inputTsoEbi.getEbiIp().equals(defaultTsoEbiBean.getEbiIp())) {
			TsoEbiDbBean.setEbiIp(inputTsoEbi.getEbiIp());
		}
		if (inputTsoEbi.getEbiPort() != -1 && inputTsoEbi.getEbiPort() != defaultTsoEbiBean.getEbiPort()) {
			TsoEbiDbBean.setEbiPort(inputTsoEbi.getEbiPort());
		}
		
        if (inputTsoEbi.getEbiFqdn() != null && !inputTsoEbi.getEbiFqdn().equals(defaultTsoEbiBean.getEbiFqdn())) {
			TsoEbiDbBean.setEbiFqdn(inputTsoEbi.getEbiFqdn());
		}
		if (inputTsoEbi.getIpVersion() != 0 && inputTsoEbi.getIpVersion() != defaultTsoEbiBean.getIpVersion()) {
			TsoEbiDbBean.setIpVersion(inputTsoEbi.getIpVersion());
		}
		if (inputTsoEbi.getVpnName() != null && !inputTsoEbi.getVpnName().equals(defaultTsoEbiBean.getVpnName())){
			TsoEbiDbBean.setVpnName(inputTsoEbi.getVpnName());
	    }
		if (inputTsoEbi.getAccessType() != 0 && inputTsoEbi.getAccessType() != defaultTsoEbiBean.getAccessType()) {
			TsoEbiDbBean.setAccessType(inputTsoEbi.getAccessType());
		}
		if (inputTsoEbi.getCircuitId() != null && !inputTsoEbi.getCircuitId().equals(defaultTsoEbiBean.getCircuitId())){
			TsoEbiDbBean.setCircuitId(inputTsoEbi.getCircuitId());
	    }
		if (inputTsoEbi.getStreetAddress() != null && !inputTsoEbi.getStreetAddress().equals(defaultTsoEbiBean.getStreetAddress())){
			TsoEbiDbBean.setStreetAddress(inputTsoEbi.getStreetAddress());
	    }
		if (inputTsoEbi.getCity() != null && !inputTsoEbi.getCity().equals(defaultTsoEbiBean.getCity())){
			TsoEbiDbBean.setCity(inputTsoEbi.getCity());
	    }
		if (inputTsoEbi.getState() != null && !inputTsoEbi.getState().equals(defaultTsoEbiBean.getState())){
			TsoEbiDbBean.setState(inputTsoEbi.getState());
	    }
		if (inputTsoEbi.getCountryCode() != null && !inputTsoEbi.getCountryCode().equals(defaultTsoEbiBean.getCountryCode())){
			TsoEbiDbBean.setCountryCode(inputTsoEbi.getCountryCode());
	    }
		if (inputTsoEbi.getModifiedBy() != null && !inputTsoEbi.getModifiedBy().equals(defaultTsoEbiBean.getModifiedBy())){
			TsoEbiDbBean.setModifiedBy(inputTsoEbi.getModifiedBy());
		}
		if (inputTsoEbi.getLastModifiedDate()!= null && !inputTsoEbi.getLastModifiedDate().equals(defaultTsoEbiBean.getLastModifiedDate())){
			TsoEbiDbBean.setLastModifiedDate(inputTsoEbi.getLastModifiedDate());
		}
		if (inputTsoEbi.getZip() != null && !inputTsoEbi.getZip().equals(defaultTsoEbiBean.getZip())){
			TsoEbiDbBean.setZip(inputTsoEbi.getZip());
		}
		if (inputTsoEbi.getBsDeviceType()!= null && !inputTsoEbi.getBsDeviceType().equals(defaultTsoEbiBean.getBsDeviceType())){
			TsoEbiDbBean.setBsDeviceType(inputTsoEbi.getBsDeviceType());
		}
	
		return TsoEbiDbBean;
	}
	
	public boolean deleteFromDB() throws SQLException, Exception {
			
		if(ebiId <= 0)
		{
			log.info("Invalid Input");
			setStatus(InvErrorCode.INVALID_INPUT);
			return false;
		}
						
		DBTblTsoEbi TsoEbiDbBean = new DBTblTsoEbi();
		TsoEbiDbBean.whereEbiIdEQ(ebiId);
		IpSec ipsecObj = new IpSec(dbCon);
		long ipsecTunId = ipsecObj.getIpsecTunnelIdForDevice(ebiId, (short)VzbVoipEnum.IpsecDeviceType.EBI);
		log.info("ipsecTunId :: "+ipsecTunId);
		if(ipsecObj.countofDeviceForIpsecTunnel(ipsecTunId, (short)VzbVoipEnum.IpsecDeviceType.EBI) == 1){
			log.info("countofDeviceForIpsecTunnel is 1 in TsoEbi");
			ipsecObj.createIpseqDeleteRequest(ebiId,(short)VzbVoipEnum.IpsecDeviceType.EBI, getEnvOrderId(),true);
		}
		
		try{
			if ( TsoEbiDbBean.deleteByWhere(dbCon) <= 0 ) {
				log.info("No EbiId found to delete "+ebiId);
		        return false;
		    }
		}catch(SQLException e){
			TsoTrunkGroup tgObj = new TsoTrunkGroup();
			tgObj.setDbCon(dbCon);
			tgObj.setEbiId(ebiId);
			tgObj.deleteFromDBbyEbiId();
			DBTblTsoEbi ebiBean = new DBTblTsoEbi();
			ebiBean.whereEbiIdEQ(ebiId);
			if ( ebiBean.deleteByWhere(dbCon) <= 0 ) {
				log.info("No EbiId found to delete "+ebiId);
		        return false;
		    }
		}
		
			
		log.info("Successfully deleted TsoEbi");
		setStatusDesc("Successfully deleted TsoEbi");
		return true;
	}
}
