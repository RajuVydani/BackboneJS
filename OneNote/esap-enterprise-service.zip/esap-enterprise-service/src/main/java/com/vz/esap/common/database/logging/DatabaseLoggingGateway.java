package com.vz.esap.common.database.logging;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.vz.esap.common.communication.RestClient;
import com.vz.fxo.inventory.enterprise.model.ResponseObject;

@Service
public class DatabaseLoggingGateway {

	private static Logger log = LoggerFactory.getLogger(DatabaseLoggingGateway.class);

	@Value("${ordering.svcUsername}")
	private String svcUsername;

	@Value("${ordering.svcPassword}")
	private String svcPassword;

	@Value("${ordering.tblOrderLogLoggingServiceUrl}")
	private String tblOrderLogLoggingServiceUrl;

	@Value("${ordering.tblTaskCompletionLogLoggingServiceUrl}")
	private String tblTaskCompletionLogLoggingServiceUrl;
	
	@Value("${ordering.insertBulkTblOrderRspServiceUrl}")
	private String insertBulkTblOrderRspServiceUrl;

	private String pattern = "yyyy-MM-dd HH:mm:ss.SSS";
	private SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);

	public void flushOrderLogs(List<TblOrderLogDataBean> tblOrderLogDataBeanList ) {
		try {
			ObjectMapper mapper = new ObjectMapper();
			log.info("Logs to flush :"
					+ mapper.writerWithDefaultPrettyPrinter()
							.writeValueAsString(tblOrderLogDataBeanList));
			RestClient restClient = new RestClient();
			ResponseObject loggingResponse = (ResponseObject) restClient
					.invokeService(tblOrderLogDataBeanList,
							tblOrderLogLoggingServiceUrl, svcUsername,
							svcPassword, ResponseObject.class);

			log.info("Logging Response :"
					+ mapper.writerWithDefaultPrettyPrinter()
							.writeValueAsString(loggingResponse));
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			tblOrderLogDataBeanList = null;
		}
	}
	
	public void flushTaskCompletionLog(List<TblTaskCompletionLogDataBean> tblTaskCompletionLogDataBeansList) {
		try {
			ObjectMapper mapper = new ObjectMapper();
			log.info("Task Completion Logs to flush :"
					+ mapper.writerWithDefaultPrettyPrinter()
							.writeValueAsString(
									tblTaskCompletionLogDataBeansList));
			RestClient restClient = new RestClient();
			ResponseObject loggingResponse = (ResponseObject) restClient
					.invokeService(tblTaskCompletionLogDataBeansList,
							tblTaskCompletionLogLoggingServiceUrl, svcUsername,
							svcPassword, ResponseObject.class);

			log.info("Logging Response :"
					+ mapper.writerWithDefaultPrettyPrinter()
							.writeValueAsString(loggingResponse));
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		}
	}
	
	public void flushTblOrderRsp(List<TblOrderRspDataBean> tblOrderRspDataBeansList ) {
		try {
			ObjectMapper mapper = new ObjectMapper();
			log.info("Task Completion Logs to flush :"
					+ mapper.writerWithDefaultPrettyPrinter()
							.writeValueAsString(
									tblOrderRspDataBeansList));
			RestClient restClient = new RestClient();
			ResponseObject loggingResponse = (ResponseObject) restClient
					.invokeService(tblOrderRspDataBeansList,
							insertBulkTblOrderRspServiceUrl, svcUsername,
							svcPassword, ResponseObject.class);

			log.info("Logging Response :"
					+ mapper.writerWithDefaultPrettyPrinter()
							.writeValueAsString(loggingResponse));
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		}
	}
}
