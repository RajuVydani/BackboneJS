package com.vz.fxo.inventory.enterprise.support;

import esap.db.TblSubscriberDeviceDbBean;

public class SubscriberDeviceBean
{
	//members
	protected int subDeviceId;
	protected String subId;
	protected long deviceMapId;
	protected DeviceBean deviceBean;
	protected long sipDeviceId;
	protected long gatewayDeviceId;
	protected String linePort;
	protected long lineKey;
	protected long callsPerLine;
	protected long portNum;
	protected String scaLineLabel;
	protected String scaType;
	protected String scaAuthUserid;
	protected long blfAttdntRegline;
	protected String blfUrl;
	protected String shared;
    protected String softPhone;
	protected String createdBy;
	protected String modifiedBy;
	protected java.sql.Timestamp creationDate;
	protected java.sql.Timestamp lastModifiedDate;
	protected long envOrderId;

	/**
	 * Default Constructor -- Initializes all fields to default values.
	 */
    	public SubscriberDeviceBean() {
		this.subDeviceId = 0;
		this.subId = new String("");
		this.deviceMapId = 0;
		this.deviceBean = new DeviceBean();
		this.sipDeviceId = 0;
		this.gatewayDeviceId = 0;
		this.linePort = new String("");
		this.lineKey = 0;
		this.callsPerLine = 0;
		this.portNum = 0;
		this.scaLineLabel = new String("");
		this.scaType = new String("");
		this.scaAuthUserid = new String(""); 
		this.blfAttdntRegline = 0;
		this.blfUrl = new String(""); 
		this.shared = null;
		this.softPhone = null;
		this.createdBy = new String("");
		this.modifiedBy = new String(""); 
		this.envOrderId = 0;

		//Pls Verify if below lines are needed.
		deviceBean = new DeviceBean();
	}
	/**
	 * Constructor
	 * @param subDevBean
	 */
	public SubscriberDeviceBean(SubscriberDeviceBean subDevBean)
	{
		this.subDeviceId = subDevBean.subDeviceId;
		this.subId = subDevBean.subId;
		this.deviceMapId = subDevBean.deviceMapId;
		this.deviceBean = subDevBean.deviceBean;
		this.sipDeviceId = subDevBean.sipDeviceId;
		this.gatewayDeviceId = subDevBean.gatewayDeviceId;
		this.linePort = subDevBean.linePort;
		this.lineKey = subDevBean.lineKey;
		this.callsPerLine = subDevBean.callsPerLine;
		this.portNum = subDevBean.portNum;
		this.scaLineLabel = subDevBean.scaLineLabel;
		this.scaType = subDevBean.scaType;
		this.scaAuthUserid = subDevBean.scaAuthUserid;
		this.blfAttdntRegline = subDevBean.blfAttdntRegline;
		this.blfUrl = subDevBean.blfUrl;
		this.shared = subDevBean.shared;
		this.softPhone = subDevBean.softPhone;
		this.createdBy = subDevBean.createdBy;
		this.modifiedBy = subDevBean.modifiedBy;
		this.creationDate = subDevBean.creationDate;
		this.lastModifiedDate = subDevBean.lastModifiedDate;
		this.envOrderId = subDevBean.envOrderId ;
	}

	public void beanCopy(TblSubscriberDeviceDbBean dbBean)
	{
		deviceBean = new DeviceBean();
		this.subDeviceId = dbBean.getSubDeviceId();
		this.subId = dbBean.getSubId();
		this.deviceMapId = dbBean.getDeviceMapId();
		//this.sipDeviceId = dbBean.sipDeviceId;
		//this.gatewayDeviceId = dbBean.gatewayDeviceId;
		this.linePort = dbBean.getLinePort();
		this.lineKey = dbBean.getLineKey();
		this.callsPerLine = dbBean.getCallsPerLine();
		this.portNum = dbBean.getPortNum();
		this.scaLineLabel = dbBean.getScaLineLabel();
		this.scaType = dbBean.getScaType();
		this.scaAuthUserid = dbBean.getScaAuthUserid();
		this.blfAttdntRegline = dbBean.getBlfAttdntRegline();
		this.blfUrl = dbBean.getBlfUrl();
		//this.createdBy = dbBean.getCreationDate();
		this.modifiedBy = dbBean.getModifiedBy();
		//this.envOrderId = dbBean.getEnvOrderId();
	}
	
	public DeviceBean getDeviceBean() {
		return deviceBean;
	}
	public void setDeviceBean(DeviceBean deviceBean) {
		this.deviceBean = deviceBean;
	}
	public java.sql.Timestamp getCreationDate() {
		return creationDate;
	}
	public void setCreationDate(java.sql.Timestamp creationDate) {
		this.creationDate = creationDate;
	}
	public java.sql.Timestamp getLastModifiedDate() {
		return lastModifiedDate;
	}
	public void setLastModifiedDate(java.sql.Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}
	public int getSubDeviceId() {
		return subDeviceId;
	}

	public void setSubDeviceId(int subDeviceId) {
		this.subDeviceId = subDeviceId;
	}

	public String getSubId() {
		return subId;
	}

	public void setSubId(String subId) {
		this.subId = subId;
	}

	public long getDeviceMapId() {
		return deviceMapId;
	}

	public void setDeviceMapId(long deviceMapId) {
		this.deviceMapId = deviceMapId;
	}

	public long getSipDeviceId() {
		return sipDeviceId;
	}

	public void setSipDeviceId(long sipDeviceId) {
		this.sipDeviceId = sipDeviceId;
	}

	public long getGatewayDeviceId() {
		return gatewayDeviceId;
	}

	public void setGatewayDeviceId(long gatewayDeviceId) {
		this.gatewayDeviceId = gatewayDeviceId;
	}

	public String getLinePort() {
		return linePort;
	}

	public void setLinePort(String linePort) {
		this.linePort = linePort;
	}

	public long getLineKey() {
		return lineKey;
	}

	public void setLineKey(long lineKey) {
		this.lineKey = lineKey;
	}

	public long getCallsPerLine() {
		return callsPerLine;
	}

	public void setCallsPerLine(long callsPerLine) {
		this.callsPerLine = callsPerLine;
	}

	public long getPortNum() {
		return portNum;
	}

	public void setPortNum(long portNum) {
		this.portNum = portNum;
	}

	public String getScaLineLabel() {
		return scaLineLabel;
	}

	public void setScaLineLabel(String scaLineLabel) {
		this.scaLineLabel = scaLineLabel;
	}

	public String getScaType() {
		return scaType;
	}

	public void setScaType(String scaType) {
		this.scaType = scaType;
	}

	public String getScaAuthUserid() {
		return scaAuthUserid;
	}

	public void setScaAuthUserid(String scaAuthUserid) {
		this.scaAuthUserid = scaAuthUserid;
	}

	public long getBlfAttdntRegline() {
		return blfAttdntRegline;
	}

	public void setBlfAttdntRegline(long blfAttdntRegline) {
		this.blfAttdntRegline = blfAttdntRegline;
	}

	public String getBlfUrl() {
		return blfUrl;
	}

	public void setBlfUrl(String blfUrl) {
		this.blfUrl = blfUrl;
	}
	
	public  String getShared(){
		return shared;
	}
	
	public void setShared(String shared){
		this.shared = shared;
	}
	
	public String getsoftPhone(){
		return softPhone;
	}
	
	public void setsoftPhone(String softPhone){
		this.softPhone = softPhone;
	}
	

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public long getEnvOrderId() {
		return envOrderId;
	}
	public void setEnvOrderId(long envOrderId) {
		this.envOrderId = envOrderId;
	}

}
