/**
 * 
 */
package com.vz.esap.api.service.model;

/**
 * @author Deepak Kumar
 *
 */
public enum EnitityEnum {

	TN("TN"),
	ENTERPRISE("Enterprise");
	
	String entity;
	
	EnitityEnum(String enumValue){
		entity = enumValue;
	}
}

