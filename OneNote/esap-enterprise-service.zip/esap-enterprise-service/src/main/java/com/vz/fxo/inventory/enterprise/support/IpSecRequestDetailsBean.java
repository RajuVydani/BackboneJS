package com.vz.fxo.inventory.enterprise.support;

import java.io.Serializable;

public class IpSecRequestDetailsBean implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public long ipsecProvRequstId;
	public String name;
	public String provValue;
	public String provAction;

	public IpSecRequestDetailsBean(){
		this.ipsecProvRequstId=0;
		this.name="";
		this.provValue="";
		this.provAction="";
	}
	
	public IpSecRequestDetailsBean(IpSecRequestDetailsBean ipBean){
		this.ipsecProvRequstId=ipBean.ipsecProvRequstId;
		this.name=ipBean.name;
		this.provValue=ipBean.provAction;
		this.provAction=ipBean.provAction;
	}

	public long getIpsecProvRequstId() {
		return ipsecProvRequstId;
	}

	public void setIpsecProvRequstId(long ipsecProvRequstId) {
		this.ipsecProvRequstId = ipsecProvRequstId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getProvValue() {
		return provValue;
	}

	public void setProvValue(String provValue) {
		this.provValue = provValue;
	}

	public String getProvAction() {
		return provAction;
	}

	public void setProvAction(String provAction) {
		this.provAction = provAction;
	}
	

}

