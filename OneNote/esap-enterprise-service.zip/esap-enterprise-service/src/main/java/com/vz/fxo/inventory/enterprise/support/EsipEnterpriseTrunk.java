package com.vz.fxo.inventory.enterprise.support;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import esap.db.DBTblEsipEnterpriseTrunk;
import esap.db.DBTblTsoEtTgMap;
import esap.db.TblEsipEnterpriseTrunkQuery;
import esap.db.TblTsoEtTnQuery;

public class EsipEnterpriseTrunk extends EsipEnterpriseTrunkBean {
	
	private static Logger logger = LoggerFactory.getLogger(EsipEnterpriseTrunk.class.toString());
	
	private InvErrorCode status;
    Connection dbCon;
    String statusDesc;
	boolean rollbackFlag;
	/**
	 * @return the rollbackFlag
	 */
	public boolean isRollbackFlag() {
		return rollbackFlag;
	}

	/**
	 * @param rollbackFlag the rollbackFlag to set
	 */
	public void setRollbackFlag(boolean rollbackFlag) {
		this.rollbackFlag = rollbackFlag;
	}
	boolean migration;
	boolean shellMigration;
	// Constructor
	public EsipEnterpriseTrunk(Connection connection) {
		super();
		this.dbCon = connection;
		this.rollbackFlag = false;                                                                       
		this.migration = false;                                                                       
		this.shellMigration = false;
	}
	
    public String getStatusDesc() {
		return statusDesc;
	}
	public void setStatusDesc(String statusDesc) {
		this.statusDesc = statusDesc;
	}
	/*public TsoEnterpriseTrunk(Connection dbCon){
        this.dbCon = dbCon;
	 }*/
    public EsipEnterpriseTrunk(EsipEnterpriseTrunkBean esipEnterpriseTrunkBean, Connection dbCon){
        super(esipEnterpriseTrunkBean);
        this.dbCon = dbCon;
    }
	public InvErrorCode getStatus() {
		return status;
	}
	public void setStatus(InvErrorCode status) {
		this.status = status;
	}
	public Connection getDbCon() {
		return dbCon;
	}
	public void setDbCon(Connection dbCon) {
		this.dbCon = dbCon;
	}
    
	public boolean addToDB() throws SQLException,Exception{
		
		
		setLogTrail("EsipEnterpriseTrunkDbBean Calling addToDB.");
		DBTblEsipEnterpriseTrunk  esipEnterpriseTrunkDbBean=new DBTblEsipEnterpriseTrunk();
			    
		esipEnterpriseTrunkDbBean.setEnterpriseTrunkId(""+enterpriseTrunkId);
		esipEnterpriseTrunkDbBean.setEnterpriseTrunkName(enterpriseTrunkName);
		esipEnterpriseTrunkDbBean.setCustomerId(""+enterpriseId);
		esipEnterpriseTrunkDbBean.setMaxrerouteattempts(maxRerouteAttempts);	
		esipEnterpriseTrunkDbBean.setRouteexhaustionaction(routeExhaustAction);
		esipEnterpriseTrunkDbBean.setBwenterpriseid(bwEnterpriseId);
		esipEnterpriseTrunkDbBean.setBwenterprisetrunkid(bwEnterpriseTrunkId);
		esipEnterpriseTrunkDbBean.setEnterprisetrunktype(enterpriseTrunkType);
		esipEnterpriseTrunkDbBean.setOrderingalgorithm(orderingAlgoritham);
		esipEnterpriseTrunkDbBean.setTrunkgroupid(trunkGroupId);
		esipEnterpriseTrunkDbBean.setTrunkgroupname(trunkGroupName);
		
				
		if (createdBy != null && !createdBy.trim().equals(""))
			esipEnterpriseTrunkDbBean.setCreatedBy(createdBy);
		else
			esipEnterpriseTrunkDbBean.setCreatedBy("ESAP_INV");
		
		if (modifiedBy != null && !modifiedBy.trim().equals(""))
			esipEnterpriseTrunkDbBean.setModifiedBy(modifiedBy);
		else
			esipEnterpriseTrunkDbBean.setModifiedBy("ESAP_INV");
		
		esipEnterpriseTrunkDbBean.setCreationDate(new Timestamp(System.currentTimeMillis()));
		esipEnterpriseTrunkDbBean.setLastModifiedDate(new Timestamp(System.currentTimeMillis()));
		printEntTrunkDbObj(esipEnterpriseTrunkDbBean);	
		esipEnterpriseTrunkDbBean.insert(dbCon);
		setLogTrail("EsipEnterpriseTrunkDbBean Record added to DB.");
		return true;
	}
	
	public void printEntTrunkDbObj(DBTblEsipEnterpriseTrunk entTrunkDbObj) {
		StringBuffer buffer = new StringBuffer();
		buffer.append("EnterpriseTrunkId=").append(entTrunkDbObj.getEnterpriseTrunkId())
		.append("\n");
		buffer.append("EnterpriseId=").append(entTrunkDbObj.getCustomerId())
				.append("\n");
		buffer.append("EnterpriseTrunkName=").append(entTrunkDbObj.getEnterpriseTrunkName())
		.append("\n");
		buffer.append("MaxRerouteAttempts=").append(entTrunkDbObj.getMaxrerouteattempts())
		.append("\n");
		buffer.append("Bwenterpriseid=").append(entTrunkDbObj.getBwenterpriseid())
		.append("\n");
		buffer.append("Bwenterprisetrunkid=").append(entTrunkDbObj.getBwenterprisetrunkid())
		.append("\n");
		buffer.append("RouteExhaustAction=").append(entTrunkDbObj.getRouteexhaustionaction())
		.append("\n");
		buffer.append("Trunkgroupid=").append(entTrunkDbObj.getTrunkgroupid())
		.append("\n");
		buffer.append("CreatedBy=").append(entTrunkDbObj.getCreatedBy())
		.append("\n");
		buffer.append("CreationDate=").append(entTrunkDbObj.getCreationDate())
		.append("\n");
		buffer.append("ModifiedBy=").append(entTrunkDbObj.getModifiedBy())
		.append("\n");
		buffer.append("LastModifiedDate=").append(entTrunkDbObj.getLastModifiedDate())
		.append("\n");	
		
		buffer.append("Orderingalgorithm=").append(entTrunkDbObj.getOrderingalgorithm())
		.append("\n");
		
		buffer.append("Trunkgroupname=").append(entTrunkDbObj.getTrunkgroupname())
		.append("\n");
		logger.info(buffer.toString());
	}
	
	 public boolean modifyInDB() throws SQLException, Exception {
		
	           if (enterpriseTrunkId==null || "".equals(enterpriseTrunkId))
	            {
	        	   logger.info("FAILURE in modifyInDB enterpriseTrunk. enterpriseTrunk Id missing.");
	                return false;
	            }
	           DBTblEsipEnterpriseTrunk tsoEnterpriseTrunkDbBean = getEsipEnterpriseTrunkToUpdate();
	            logger.info("Got enterpriseTrunk Details to Update for enterpriseTrunkId:" + enterpriseTrunkId);
	            tsoEnterpriseTrunkDbBean.whereEnterpriseTrunkIdEQ(enterpriseTrunkId);
	            logger.info("Going to Update TsoenterpriseTrunk in DB");
	            //FkValidationUtil.isValidLocationForMod(dbCon,tsoEnterpriseDbBean);
	            
	            if ( tsoEnterpriseTrunkDbBean.updateSpByWhere(dbCon) <= 0 ) {
	            	logger.info("No TsoEnterpriseTrunk updated");
	            	return false;
	            }
	            logger.info("Successfully updated TsoEnterpriseTrunk");
	            setStatus(InvErrorCode.SUCCESS);
	            logger.info("Successfully UPDATED TsoEnterpriseTrunk into the DB");
	        return true;
	 }
	        
	 private DBTblEsipEnterpriseTrunk getEsipEnterpriseTrunkToUpdate() throws SQLException {
		 DBTblEsipEnterpriseTrunk  tsoEnterpriseTrunkDbBean=new DBTblEsipEnterpriseTrunk();
	        // Create a new instance of TsoEnterpriseTrunkBean. The new instance
	         // would hold default values for the all the TsoEnterpriseTrunkBean fields.
		 EsipEnterpriseTrunkBean defaultTsoEnterpriseTrunkBean = new EsipEnterpriseTrunkBean();
		 EsipEnterpriseTrunk inputTsoEnterprise = this;
		  tsoEnterpriseTrunkDbBean.setEnterpriseTrunkId(enterpriseTrunkId);
		  TblEsipEnterpriseTrunkQuery tsoEntQry=new TblEsipEnterpriseTrunkQuery();
		  tsoEntQry.whereEnterpriseTrunkIdEQ(""+inputTsoEnterprise.getEnterpriseTrunkId());
		  tsoEntQry.query(dbCon);
		  if (inputTsoEnterprise.getEnterpriseTrunkName() != null
	                && !inputTsoEnterprise.getEnterpriseTrunkName().equals(defaultTsoEnterpriseTrunkBean.getEnterpriseTrunkName())){
			  tsoEnterpriseTrunkDbBean.setEnterpriseTrunkName(inputTsoEnterprise.getEnterpriseTrunkName());
	        }
		  if (tsoEnterpriseTrunkDbBean.getBwenterpriseid() != null
	                && !tsoEnterpriseTrunkDbBean.getBwenterpriseid().equals(defaultTsoEnterpriseTrunkBean.getBwEnterpriseId())){
			  tsoEnterpriseTrunkDbBean.setBwenterpriseid(inputTsoEnterprise.getBwEnterpriseId());
		  }
		 /* if (inputTsoEnterprise.getMaxRerouteAttempts()!=defaultTsoEnterpriseTrunkBean.getMaxRerouteAttempts()){
			  tsoEnterpriseTrunkDbBean.setsetMaxRerouteAttempts(inputTsoEnterprise.getMaxRerouteAttempts());
		  }
		  if (inputTsoEnterprise.getMaxRerouteAttemptsPriority()!=defaultTsoEnterpriseTrunkBean.getMaxRerouteAttemptsPriority()){
			  tsoEnterpriseTrunkDbBean.setMaxRerouteAttemptsPriority(inputTsoEnterprise.getMaxRerouteAttemptsPriority());
		  }
		  if (inputTsoEnterprise.getRouteExhaustActivated() !=defaultTsoEnterpriseTrunkBean.getRouteExhaustActivated()){
			  tsoEnterpriseTrunkDbBean.setRouteExhaustActivated(inputTsoEnterprise.getRouteExhaustActivated());
		  }
		  if (inputTsoEnterprise.getRouteExhaustAction()!=defaultTsoEnterpriseTrunkBean.getRouteExhaustAction()){
			  tsoEnterpriseTrunkDbBean.setRouteExhaustAction(inputTsoEnterprise.getRouteExhaustAction());
		  }
		  if (inputTsoEnterprise.getRouteExhaustFwdTn() != null
	                && !inputTsoEnterprise.getRouteExhaustFwdTn().equals(defaultTsoEnterpriseTrunkBean.getRouteExhaustFwdTn())){
			  tsoEnterpriseTrunkDbBean.setRouteExhaustFwdTn(inputTsoEnterprise.getRouteExhaustFwdTn());
		  }
			if("".equals(inputTsoEnterprise.getRouteExhaustFwdTn())){
			  tsoEnterpriseTrunkDbBean.setRouteExhaustFwdTnNull();
		  }*/
		  if (inputTsoEnterprise.getModifiedBy() != null
	                && !inputTsoEnterprise.getModifiedBy().equals(defaultTsoEnterpriseTrunkBean.getModifiedBy())){
			  tsoEnterpriseTrunkDbBean.setModifiedBy(inputTsoEnterprise.getModifiedBy());
		  }
		  if (inputTsoEnterprise.getLastModifiedDate()!= null
	                && !inputTsoEnterprise.getLastModifiedDate().equals(defaultTsoEnterpriseTrunkBean.getLastModifiedDate())){
			  tsoEnterpriseTrunkDbBean.setLastModifiedDate(inputTsoEnterprise.getLastModifiedDate());
		  }
        return tsoEnterpriseTrunkDbBean;
	   }   
	  
	  public boolean deleteFromDB() throws SQLException, Exception {
				
		if(enterpriseTrunkId == null || "".equalsIgnoreCase(enterpriseTrunkId))
		{
			logger.info("Invalid Input");
			setStatus(InvErrorCode.INVALID_INPUT);
			setStatusDesc("enterpriseTrunkId is missed ");
			return false;
		}
        DBTblTsoEtTgMap tsoEtTgBean = new DBTblTsoEtTgMap();
        tsoEtTgBean.whereEnterpriseTrunkIdEQ(new Long(enterpriseTrunkId));
        tsoEtTgBean.deleteByWhere(dbCon);
        setLogTrail("Deleted details related to EnterpriseTrunk: "+ enterpriseTrunkId + " from tbl_tso_et_tg_map");
        deleteETTnForET();
		
        DBTblEsipEnterpriseTrunk  esipEnterpriseDbBean=new DBTblEsipEnterpriseTrunk();
        esipEnterpriseDbBean.whereEnterpriseTrunkIdEQ(""+enterpriseTrunkId);
		
		if ( esipEnterpriseDbBean.deleteByWhere(dbCon) <= 0 ) {
			logger.info("No EnterpriseTrunk found to delete "+enterpriseTrunkId);
			setStatusDesc("No EnterpriseTrunk found to delete "+enterpriseTrunkId);
            return false;
        }
		
		logger.info("Successfully deleted EsipEnterpriseTrunk");
		setStatusDesc("Successfully deleted EsipEnterpriseTrunk ");
			
		return true;
	}
	  
	  public long deleteETTnForET() throws SQLException, Exception {

		  logger.info("deleteETTnForET ::");

		  TblTsoEtTnQuery etTnQuery = new TblTsoEtTnQuery();
		  etTnQuery.whereEnterpriseTrunkIdEQ(new Long(getEnterpriseTrunkId()));
		  etTnQuery.query(dbCon);
		  long rowSize = etTnQuery.size();
		  logger.info("deleteETTnForET :: etTnQuery size" + etTnQuery.size());
		  for(int i = 0; i < etTnQuery.size(); i++)
		  {
			  TsoEtTn tsoEtTn = new TsoEtTn(dbCon);
			  tsoEtTn.setEtTnId(etTnQuery.getDbBean(i).getEtTnId());
			  tsoEtTn.setModifiedBy(getModifiedBy());
			  tsoEtTn.deleteFromDB();
			  logger.info("deleteETTnForET:: deleted tsoEtTn with groupTnId:"+tsoEtTn.getEtTnId());
		  }

		  // Recursive call to make sure we are not picking up only 
		  // DB generated max rows!!
		  if(rowSize != 0) {
			  logger.info("Calling deleteETTnForET() recursively to make sure there is no rec left in db.");
			  deleteETTnForET();
		  }

		  return rowSize;
	  }
	  
	/*public TsoEnterpriseTrunkBean getEnterpriseTrunkByEnterpriseTrunkId(String enterpriseId, long enterpriseTrunkId) throws SQLException,Exception {
			TsoEnterpriseTrunkBean tsoEnterpriseTrunkBean = null;
		
			logger.info("Got the enterpriseid  " + enterpriseId);
			if (enterpriseId == null || "".equals(enterpriseId)) {
				logger.info("enterpriseId  is null or empty");
				return tsoEnterpriseTrunkBean;
			}
			logger.info("Got enterpriseTrunkId " + enterpriseTrunkId);
			if (enterpriseTrunkId <= 0) {
				logger.info("enterpriseTrunkId  is null or empty");
				return tsoEnterpriseTrunkBean;
			}
		
			StringBuffer sql = new StringBuffer();
			PreparedStatement pStmt = null;
			ResultSet rs = null;			
			logger.info("EntID "+enterpriseId);
			logger.info("EntTrunkID "+enterpriseTrunkId);
			sql.append("select * from tbl_tso_enterprise_trunk where ENTERPRISE_ID= ? and ENTERPRISE_TRUNK_ID = ?");
			logger.info("tbl_tso_enterprise_trunk query executed" + sql);
			
			try {
				logger.info("Inside try block");
				pStmt = dbCon.prepareStatement(sql.toString());
				if (pStmt != null) {
					pStmt.setString(1, enterpriseId);
					pStmt.setLong(2, enterpriseTrunkId);
					logger.info("AFTER tbl_tso_enterprise_trunk query executed" + sql);	
					rs = pStmt.executeQuery();
					while (rs.next()) {
						tsoEnterpriseTrunkBean = new TsoEnterpriseTrunkBean();
						logger.info("Inside resultset loop ");
						
						tsoEnterpriseTrunkBean.setEnterpriseId(rs.getString(1));
						tsoEnterpriseTrunkBean.setEnterpriseTrunkName(rs.getString(2));
						tsoEnterpriseTrunkBean.setEnterpriseTrunkId(rs.getLong(3));
						tsoEnterpriseTrunkBean.setMaxRerouteAttempts(rs.getLong(4));
						tsoEnterpriseTrunkBean.setMaxRerouteAttemptsPriority(rs.getShort(5));
						tsoEnterpriseTrunkBean.setRouteExhaustActivated(rs.getLong(6));
						tsoEnterpriseTrunkBean.setRouteExhaustAction(rs.getLong(7));
						tsoEnterpriseTrunkBean.setRouteExhaustFwdTn(rs.getString(8));
						tsoEnterpriseTrunkBean.setCreatedBy(rs.getString(9));
						tsoEnterpriseTrunkBean.setCreationDate(rs.getTimestamp(10));
						tsoEnterpriseTrunkBean.setModifiedBy(rs.getString(11));
						tsoEnterpriseTrunkBean.setLastModifiedDate(rs.getTimestamp(12));
					}
					logger.info("Set tsoEnterpriseTrunkBean object "	+ tsoEnterpriseTrunkBean);
								
				}
			} catch (SQLException sqe) {
				sqe.printStackTrace();
				logger.info("DB_FAILURE in tbl_tso_enterprise_trunk");
			} catch (Exception e) {
				e.printStackTrace();
				logger.info("DB_FAILURE in tbl_tso_enterprise_trunk");
			} finally {
				if (pStmt != null) {
					pStmt.close();
				}
				if (rs != null) {
					rs.close();
				}
		
			}
		
			return tsoEnterpriseTrunkBean;
		
	}*/
}
