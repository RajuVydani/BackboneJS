
package com.vz.esap.api.generated.pojo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "tableName",
    "dbOperation",
    "columnNames",
    "columnValues",
    "sequenceColumnName",
    "sequenceColumnValue",
    "whereClause"
})
public class DatabaseServiceRequest {

    @JsonProperty("tableName")
    private String tableName;
    @JsonProperty("dbOperation")
    private String dbOperation;
    @JsonProperty("columnNames")
    private List<String> columnNames = new ArrayList<String>();
    @JsonProperty("columnValues")
    private List<String> columnValues = new ArrayList<String>();
    @JsonProperty("sequenceColumnName")
    private List<String> sequenceColumnName = new ArrayList<String>();
    @JsonProperty("sequenceColumnValue")
    private List<String> sequenceColumnValue = new ArrayList<String>();
    @JsonProperty("whereClause")
    private List<WhereClause> whereClause = new ArrayList<WhereClause>();
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("tableName")
    public String getTableName() {
        return tableName;
    }

    @JsonProperty("tableName")
    public void setTableName(String tableName) {
        this.tableName = tableName;
    }

    @JsonProperty("dbOperation")
    public String getDbOperation() {
        return dbOperation;
    }

    @JsonProperty("dbOperation")
    public void setDbOperation(String dbOperation) {
        this.dbOperation = dbOperation;
    }

    @JsonProperty("columnNames")
    public List<String> getColumnNames() {
        return columnNames;
    }

    @JsonProperty("columnNames")
    public void setColumnNames(List<String> columnNames) {
        this.columnNames = columnNames;
    }

    @JsonProperty("columnValues")
    public List<String> getColumnValues() {
        return columnValues;
    }

    @JsonProperty("columnValues")
    public void setColumnValues(List<String> columnValues) {
        this.columnValues = columnValues;
    }

    @JsonProperty("sequenceColumnName")
    public List<String> getSequenceColumnName() {
        return sequenceColumnName;
    }

    @JsonProperty("sequenceColumnName")
    public void setSequenceColumnName(List<String> sequenceColumnName) {
        this.sequenceColumnName = sequenceColumnName;
    }

    @JsonProperty("sequenceColumnValue")
    public List<String> getSequenceColumnValue() {
        return sequenceColumnValue;
    }

    @JsonProperty("sequenceColumnValue")
    public void setSequenceColumnValue(List<String> sequenceColumnValue) {
        this.sequenceColumnValue = sequenceColumnValue;
    }

    @JsonProperty("whereClause")
    public List<WhereClause> getWhereClause() {
        return whereClause;
    }

    @JsonProperty("whereClause")
    public void setWhereClause(List<WhereClause> whereClause) {
        this.whereClause = whereClause;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(tableName).append(dbOperation).append(columnNames).append(columnValues).append(sequenceColumnName).append(sequenceColumnValue).append(whereClause).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof DatabaseServiceRequest) == false) {
            return false;
        }
        DatabaseServiceRequest rhs = ((DatabaseServiceRequest) other);
        return new EqualsBuilder().append(tableName, rhs.tableName).append(dbOperation, rhs.dbOperation).append(columnNames, rhs.columnNames).append(columnValues, rhs.columnValues).append(sequenceColumnName, rhs.sequenceColumnName).append(sequenceColumnValue, rhs.sequenceColumnValue).append(whereClause, rhs.whereClause).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
