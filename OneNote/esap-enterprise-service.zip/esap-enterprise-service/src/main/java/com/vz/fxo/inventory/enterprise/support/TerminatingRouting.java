package com.vz.fxo.inventory.enterprise.support; 
import java.math.BigInteger;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Iterator;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import esap.db.DBTblTerminatingRouting;
import esap.db.TblTerminatingRoutingDbBean;
import esap.db.TblTerminatingRoutingQuery;
public class TerminatingRouting extends TerminatingRoutingBean
{
	
	private static Logger log = LoggerFactory.getLogger(TerminatingRouting.class.toString());
	Connection dbCon;
	InvErrorCode status = InvErrorCode.INTERNAL_ERROR;
	public int getStatusCode() {
		return status.getErrorCode();
	}

	public void setStatus(InvErrorCode status) {
		this.status = status;
	}

	public String getStatusDesc() {
		return status.getErrorDesc();
	}
	public Connection getDbCon() {
		return dbCon;
	}
	public void setDbCon(Connection dbCon) {
		this.dbCon = dbCon;
	}
	public TerminatingRouting(Connection dbCon)
	{
		this.dbCon = dbCon;
	}
	public TerminatingRouting(TerminatingRoutingBean termRoutingBean, Connection dbCon)
	{
		super(termRoutingBean);
		this.dbCon = dbCon;
	}
	//Methods
	public boolean addTerminatingRouting() throws SQLException, Exception

	{
//		try
//		{
			log.info("In addTerminatingRouting");
			DBTblTerminatingRouting trDbBean = new DBTblTerminatingRouting();
			//set terminating routing db bean attributes
			if(getTerminatingRoutingId()<=0)
				terminatingRoutingId = trDbBean.getTerminatingRoutingIdSeqNextVal(dbCon);
			
			trDbBean.setTerminatingRoutingId(terminatingRoutingId);
			log.info("In addTerminatingRouting:terminatingRoutingId:"+terminatingRoutingId);
			trDbBean.setDialPlanId(getDialPlanId());
			trDbBean.setNoa(getNoa());
			trDbBean.setRangeStart(getRangeStart());
			if(!"NONE".equals(getRangeEnd()) && !"".equals(getRangeEnd()))
				trDbBean.setRangeEnd(getRangeEnd());
			if(!"NONE".equals(getP1URL()) && !"".equals(getP1URL()))
				trDbBean.setP1url(getP1URL());
			if(!"NONE".equals(getPringTime()) && !"".equals(getPringTime()))
				trDbBean.setPringtime(getPringTime());
			if(!"NONE".equals(getPtrId()) && !"".equals(getPtrId()))
				trDbBean.setPtrid(getPtrId());
			if(!"NONE".equals(getPPrefixDgts()) && !"".equals(getPPrefixDgts()))
				trDbBean.setPprefixdgts(getPPrefixDgts());
			if(getPSuffixNum() != -1 )
				trDbBean.setPsuffixnum(getPSuffixNum());
			if(!"NONE".equals(getA1URL()) && !"".equals(getA1URL()))
				trDbBean.setA1url(getA1URL());
			if(!"NONE".equals(getA1RingTime()) && !"".equals(getA1RingTime()))
				trDbBean.setA1ringtime(getA1RingTime());
			if(!"NONE".equals(getA1TRId()) && !"".equals(getA1TRId()))
				trDbBean.setA1trid(getA1TRId());
			if(!"NONE".equals(getA1PrefixDgts()) && !"".equals(getA1PrefixDgts()))
				trDbBean.setA1prefixdgts(getA1PrefixDgts());
			if(getA1SuffixNum() != -1)
				trDbBean.setA1suffixnum(getA1SuffixNum());
			if(!"NONE".equals(getA2URL()) && !"".equals(getA2URL()))
				trDbBean.setA2url(getA2URL());
			if(!"NONE".equals(getA2RingTime()) && !"".equals(getA2RingTime()))
				trDbBean.setA2ringtime(getA2RingTime());
			if(!"NONE".equals(getA2TRId()) && !"".equals(getA2TRId()))
				trDbBean.setA2trid(getA2TRId());
			if(!"NONE".equals(getA2PrefixDgts()) && !"".equals(getA2PrefixDgts()))
				trDbBean.setA2prefixdgts(getA2PrefixDgts());
			if(getA2SuffixNum() != -1)
				trDbBean.setA2suffixnum(getA2SuffixNum());

			log.info("EnvOrderId = <" + getEnvOrderId() + ">");
    	    		if(getEnvOrderId() != -1)
    	    			trDbBean.setEnvOrderId(getEnvOrderId());
			//else
    	    			//trDbBean.setEnvOrderIdNull();

			if(getCreatedBy() != null && !getCreatedBy().equals(""))
				trDbBean.setCreatedBy(getCreatedBy());
			else
				trDbBean.setCreatedBy("ESAP_INV");
			if(getModifiedBy() != null && !getModifiedBy().equals(""))
				trDbBean.setModifiedBy(getModifiedBy());
			else
				trDbBean.setModifiedBy("ESAP_INV");
			trDbBean.setCreationDate(new Timestamp(System.currentTimeMillis()));
			trDbBean.setLastModifiedDate(new Timestamp(System.currentTimeMillis()));
			trDbBean.insert(dbCon);
		/*}
		catch(SQLException s)
		{
			s.printStackTrace();	
			setStatus(InvErrorCode.DB_EXCEPTION);
			log.info("DB_FAILURE in addTermiantingRouting");
			return false;
		}*/
		setStatus(InvErrorCode.SUCCESS);
		return true;
	}
	//dialPlanId will be set before calling this method. 
	public boolean getTerminatingRoutingByDialPlanId() {
		try {
			TblTerminatingRoutingQuery trQry = new TblTerminatingRoutingQuery();
			trQry.setLimitQry(false);
			initilizeTODefault();
			// populate terminating routing bean from inventory
			trQry.whereDialPlanIdEQ(getDialPlanId());
			trQry.query(dbCon);
			if (trQry.size() <= 0) {
				setStatus(InvErrorCode.NO_TRI_FOR_DIAL_PLAN);
				log.info("INV_FAILURE in getTerminatingRoutingByDialPlanId TerminatingRouting. No Record found for given Dial Plan Id.");
				return false;
			} else {
				populateResult(trQry);				
			}
		} catch (SQLException e) {
			setStatus(InvErrorCode.DB_EXCEPTION);
			e.printStackTrace();	
			return false;
		} catch (Exception e) {
			setStatus(InvErrorCode.ERROR_TRI_RECORD);
			e.printStackTrace();	
			return false;
		}
		setStatus(InvErrorCode.SUCCESS);
		return true;
	}
	// terminatingRoutingId will be set before calling this method.
	public boolean getTermRoutingByTerminatingRoutingId()
	{
		try
		{
			TblTerminatingRoutingQuery trQry = new TblTerminatingRoutingQuery();
			initilizeTODefault();
            //populate terminating routing bean from inventory   
            trQry.whereTerminatingRoutingIdEQ(getTerminatingRoutingId());
            trQry.query(dbCon);
            if (trQry.size() <= 0) {
            	setStatus(InvErrorCode.NO_TRI_FOR_TRI_ID);
				log.info("INV_FAILURE in getTermRoutingByTerminatingRoutingId TerminatingRouting. No Record found for given TerminatingRoutingId.");
				return false;
			}  else {
				populateResult(trQry);				
			}
		}
		catch(SQLException e)
		{
			setStatus(InvErrorCode.DB_EXCEPTION);
			e.printStackTrace();	
			return false;
		}
		catch(Exception e)
		{
			setStatus(InvErrorCode.ERROR_TRI_RECORD);
			e.printStackTrace();	
			return false;
		}
		setStatus(InvErrorCode.SUCCESS);
		return true;
	}
	/**
	 * The method to populate query result into the domain class
	 * @param trQry
	 */
	private void populateResult(TblTerminatingRoutingQuery trQry) {
		TblTerminatingRoutingDbBean trDbBean = trQry.getDbBean(0);
		setTerminatingRoutingId(trDbBean.getTerminatingRoutingId());
		setDialPlanId(trDbBean.getDialPlanId());
		setNoa(trDbBean.getNoa());
		setRangeStart(trDbBean.getRangeStart());
		setRangeEnd(trDbBean.getRangeEnd());
		setP1URL(trDbBean.getP1url());
		setPringTime(trDbBean.getPringtime());
		setPtrId(trDbBean.getPtrid());
		setPPrefixDgts(trDbBean.getPprefixdgts());
		setPSuffixNum(trDbBean.getPsuffixnum());
		setA1URL(trDbBean.getA1url());
		setA1RingTime(trDbBean.getA1ringtime());
		setA1TRId(trDbBean.getA1trid());
		setA1PrefixDgts(trDbBean.getA1prefixdgts());
		setA1SuffixNum(trDbBean.getA1suffixnum());
		setA2URL(trDbBean.getA2url());
		setA2RingTime(trDbBean.getA2ringtime());
		setA2TRId(trDbBean.getA2trid());
		setA2PrefixDgts(trDbBean.getA2prefixdgts());
		setA2SuffixNum(trDbBean.getA2suffixnum());
		setCreatedBy(trDbBean.getCreatedBy());
		setModifiedBy(trDbBean.getModifiedBy());
		setLastModifiedDate(trDbBean.getLastModifiedDate());
		setEnvOrderId(trDbBean.getEnvOrderId());
	}
	
	public boolean updateTerminatingRoutingWithOutTermRoutID () throws SQLException, Exception {
		log.info("Entering TerminatingRouting::updateTerminatingRouting");
		
	//	try
	//	{
			log.info("Deleting Terminating DialPlan/RangeSt/RangeEnd [" + getDialPlanId() + "/"+ getRangeStart() + "/" + getRangeEnd() + "]");
			if(this.getDialPlanId() != 0 && ( getRangeStart() != null  && !getRangeStart().equalsIgnoreCase("")) &&  (getRangeEnd() != null && getRangeEnd().equalsIgnoreCase("")))
	        {
			setStatus(InvErrorCode.INVALID_DAILPLAN_RANGEST_RANGEEND);
	        return false;
	        }
			TerminatingRoutingBean defaultTermRouting = new TerminatingRoutingBean();

			DBTblTerminatingRouting trDbBean = new DBTblTerminatingRouting();

			if(defaultTermRouting.getNoa() != getNoa())
				trDbBean.setNoa(getNoa());
			if(getRangeStart() != null && !getRangeStart().equals("") 
				&& !(defaultTermRouting.getRangeStart().equals(getRangeStart())))
				trDbBean.setRangeStart(getRangeStart());
			if(getRangeEnd() != null 	&& !(defaultTermRouting.getRangeEnd().equals(getRangeEnd()))) {
				if(!getRangeEnd().equals(""))
					trDbBean.setRangeEnd(getRangeEnd());
				else
					trDbBean.setRangeEndNull();
			}	
			if(getP1URL() != null && !(defaultTermRouting.getP1URL().equals(getP1URL()))) {
				if(!getP1URL().equals(""))
					trDbBean.setP1url(getP1URL());
				else
					trDbBean.setP1urlNull();
			}
			log.info("getPringTime() ===>"+getPringTime() );
			log.info("defaultTermRouting.getPringTime()() ===>"+defaultTermRouting.getPringTime() );
			
			if(getPringTime() != null 	&& !(defaultTermRouting.getPringTime().equals(getPringTime()))) {
				if( !getPringTime().equals(""))
					trDbBean.setPringtime(getPringTime());
				else
					trDbBean.setPringtimeNull();
			}
			if(getPtrId() != null 	&& !(defaultTermRouting.getPtrId().equals(getPtrId()))) {
				if (!getPtrId().equals(""))
					trDbBean.setPtrid(getPtrId());
				else
					trDbBean.setPtridNull();
			}	
			if(getPPrefixDgts() != null && !(defaultTermRouting.getPPrefixDgts().equals(getPPrefixDgts()))){
				if( !getPPrefixDgts().equals(""))
					trDbBean.setPprefixdgts(getPPrefixDgts());
				else
					trDbBean.setPprefixdgtsNull();
			}	
			if(defaultTermRouting.getPSuffixNum() != getPSuffixNum())
				if(getPSuffixNum() > 0)
					trDbBean.setPsuffixnum(getPSuffixNum());
				else
					trDbBean.setPsuffixnumNull();
			if(getA1URL() != null 	&& !(defaultTermRouting.getA1URL().equals(getA1URL()))) {
				if(!getA1URL().equals(""))
					trDbBean.setA1url(getA1URL());
				else
					trDbBean.setA1urlNull();
			}	
			if(getA1RingTime() != null 	&& !(defaultTermRouting.getA1RingTime().equals(getA1RingTime()))){
				if(!getA1RingTime().equals(""))
					trDbBean.setA1ringtime(getA1RingTime());
				else
					trDbBean.setA1ringtimeNull();
			}	
			if(getA1TRId() != null && !(defaultTermRouting.getA1TRId().equals(getA1TRId()))) {
				if(!getA1TRId().equals(""))
				 trDbBean.setA1trid(getA1TRId());
				else
				trDbBean.setA1tridNull();
			}	
			if(getA1PrefixDgts() != null && !(defaultTermRouting.getA1PrefixDgts().equals(getA1PrefixDgts()))) {
				if(!getA1PrefixDgts().equals(""))
					trDbBean.setA1prefixdgts(getA1PrefixDgts());
				else
					trDbBean.setA1prefixdgtsNull();	
			}	
			if(defaultTermRouting.getA1SuffixNum() != getA1SuffixNum())
				if(getA1SuffixNum() > 0 )
					trDbBean.setA1suffixnum(getA1SuffixNum());
				else
					trDbBean.setA1suffixnumNull();
			if(getA2URL() != null && !(defaultTermRouting.getA2URL().equals(getA2URL()))) {
				if(!getA2URL().equals(""))
					trDbBean.setA2url(getA2URL());
				else
					trDbBean.setA2urlNull();
			}	
			if(getA2RingTime() != null 	&& !(defaultTermRouting.getA2RingTime().equals(getA2RingTime()))) {
				if(!getA2RingTime().equals("")) 
					trDbBean.setA2ringtime(getA2RingTime());
				else
					trDbBean.setA2ringtimeNull();
			}	
			if(getA2TRId() != null 	&& !(defaultTermRouting.getA2TRId().equals(getA2TRId()))){
				if( !getA2TRId().equals(""))
					trDbBean.setA2trid(getA2TRId());
				else
					trDbBean.setA2tridNull();
			}	
			if(getA2PrefixDgts() != null &&  !(defaultTermRouting.getA2PrefixDgts().equals(getA1PrefixDgts()))) {
				if(!getA1PrefixDgts().equals(""))
					trDbBean.setA2prefixdgts(getA2PrefixDgts());
				else
					trDbBean.setA2prefixdgtsNull();	
			}	
			if(getA2SuffixNum() != defaultTermRouting.getA2SuffixNum()) {
				if(getA2SuffixNum()> 0 )
					trDbBean.setA2suffixnum(getA2SuffixNum());
				else
					trDbBean.setA2suffixnumNull();	
			}	

	        	if(getEnvOrderId() > 0 && defaultTermRouting.getEnvOrderId() != getEnvOrderId())
				trDbBean.setEnvOrderId(getEnvOrderId());
			if(getModifiedBy() != null && !"".equals(getModifiedBy()) )
				trDbBean.setModifiedBy(getModifiedBy());
			else
				trDbBean.setModifiedBy("ESAP_INV");

			trDbBean.setLastModifiedDate(new Timestamp(System.currentTimeMillis()));
			
			trDbBean.whereDialPlanIdEQ(getDialPlanId());
			trDbBean.whereRangeStartEQ(getRangeStart());
			if(getRangeEnd() != null && !getRangeEnd().equalsIgnoreCase(""))
				trDbBean.whereRangeEndEQ(getRangeEnd());


			if ( trDbBean.updateSpByWhere(dbCon) <= 0 ){
				log.info("Updating Term routing");
				return false;
			}
                /*}
		catch(SQLException s)
		{
			setStatus(InvErrorCode.DB_EXCEPTION);
			log.info("DB_FAILURE in updateTermiantingRouting");
			s.printStackTrace();	
			return false;
		}*/
		setStatus(InvErrorCode.SUCCESS);
		return true;

	}
	public boolean updateTerminatingRouting() throws SQLException, Exception 
	{
		log.info("Entering TerminatingRouting::updateTerminatingRouting");
		
	//	try
	//	{
			if(getTerminatingRoutingId() <= 0)
	        {
			setStatus(InvErrorCode.INTERNAL_ERROR);
	        return false;
	        }
			TerminatingRoutingBean defaultTermRouting = new TerminatingRoutingBean();

			DBTblTerminatingRouting trDbBean = new DBTblTerminatingRouting();
			if(getDialPlanId() > 0 && defaultTermRouting.getDialPlanId() != getDialPlanId())
				trDbBean.setDialPlanId(getDialPlanId());
			if(defaultTermRouting.getNoa() != getNoa())
				trDbBean.setNoa(getNoa());
			if(getRangeStart() != null && !getRangeStart().equals("") 
				&& !(defaultTermRouting.getRangeStart().equals(getRangeStart())))
				trDbBean.setRangeStart(getRangeStart());
			if(getRangeEnd() != null 	&& !(defaultTermRouting.getRangeEnd().equals(getRangeEnd()))) {
				if(!getRangeEnd().equals(""))
					trDbBean.setRangeEnd(getRangeEnd());
				else
					trDbBean.setRangeEndNull();
			}	
			if(getP1URL() != null && !(defaultTermRouting.getP1URL().equals(getP1URL()))) {
				if(!getP1URL().equals(""))
					trDbBean.setP1url(getP1URL());
				else
					trDbBean.setP1urlNull();
			}
			log.info("getPringTime() ===>"+getPringTime() );
			log.info("defaultTermRouting.getPringTime()() ===>"+defaultTermRouting.getPringTime() );
			
			if(getPringTime() != null 	&& !(defaultTermRouting.getPringTime().equals(getPringTime()))) {
				if( !getPringTime().equals(""))
					trDbBean.setPringtime(getPringTime());
				else
					trDbBean.setPringtimeNull();
			}
			if(getPtrId() != null 	&& !(defaultTermRouting.getPtrId().equals(getPtrId()))) {
				if (!getPtrId().equals(""))
					trDbBean.setPtrid(getPtrId());
				else
					trDbBean.setPtridNull();
			}	
			if(getPPrefixDgts() != null && !(defaultTermRouting.getPPrefixDgts().equals(getPPrefixDgts()))){
				if( !getPPrefixDgts().equals(""))
					trDbBean.setPprefixdgts(getPPrefixDgts());
				else
					trDbBean.setPprefixdgtsNull();
			}	
			if(defaultTermRouting.getPSuffixNum() != getPSuffixNum())
				if(getPSuffixNum() > 0)
					trDbBean.setPsuffixnum(getPSuffixNum());
				else
					trDbBean.setPsuffixnumNull();
			if(getA1URL() != null 	&& !(defaultTermRouting.getA1URL().equals(getA1URL()))) {
				if(!getA1URL().equals(""))
					trDbBean.setA1url(getA1URL());
				else
					trDbBean.setA1urlNull();
			}	
			if(getA1RingTime() != null 	&& !(defaultTermRouting.getA1RingTime().equals(getA1RingTime()))){
				if(!getA1RingTime().equals(""))
					trDbBean.setA1ringtime(getA1RingTime());
				else
					trDbBean.setA1ringtimeNull();
			}	
			if(getA1TRId() != null && !(defaultTermRouting.getA1TRId().equals(getA1TRId()))) {
				if(!getA1TRId().equals(""))
				 trDbBean.setA1trid(getA1TRId());
				else
				trDbBean.setA1tridNull();
			}	
			if(getA1PrefixDgts() != null && !(defaultTermRouting.getA1PrefixDgts().equals(getA1PrefixDgts()))) {
				if(!getA1PrefixDgts().equals(""))
					trDbBean.setA1prefixdgts(getA1PrefixDgts());
				else
					trDbBean.setA1prefixdgtsNull();	
			}	
			if(defaultTermRouting.getA1SuffixNum() != getA1SuffixNum())
				if(getA1SuffixNum() > 0 )
					trDbBean.setA1suffixnum(getA1SuffixNum());
				else
					trDbBean.setA1suffixnumNull();
			if(getA2URL() != null && !(defaultTermRouting.getA2URL().equals(getA2URL()))) {
				if(!getA2URL().equals(""))
					trDbBean.setA2url(getA2URL());
				else
					trDbBean.setA2urlNull();
			}	
			if(getA2RingTime() != null 	&& !(defaultTermRouting.getA2RingTime().equals(getA2RingTime()))) {
				if(!getA2RingTime().equals("")) 
					trDbBean.setA2ringtime(getA2RingTime());
				else
					trDbBean.setA2ringtimeNull();
			}	
			if(getA2TRId() != null 	&& !(defaultTermRouting.getA2TRId().equals(getA2TRId()))){
				if( !getA2TRId().equals(""))
					trDbBean.setA2trid(getA2TRId());
				else
					trDbBean.setA2tridNull();
			}	
			if(getA2PrefixDgts() != null &&  !(defaultTermRouting.getA2PrefixDgts().equals(getA1PrefixDgts()))) {
				if(!getA1PrefixDgts().equals(""))
					trDbBean.setA2prefixdgts(getA2PrefixDgts());
				else
					trDbBean.setA2prefixdgtsNull();	
			}	
			if(getA2SuffixNum() != defaultTermRouting.getA2SuffixNum()) {
				if(getA2SuffixNum()> 0 )
					trDbBean.setA2suffixnum(getA2SuffixNum());
				else
					trDbBean.setA2suffixnumNull();	
			}	

	        	if(getEnvOrderId() > 0 && defaultTermRouting.getEnvOrderId() != getEnvOrderId())
				trDbBean.setEnvOrderId(getEnvOrderId());
			if(getModifiedBy() != null && !"".equals(getModifiedBy()) )
				trDbBean.setModifiedBy(getModifiedBy());
			else
				trDbBean.setModifiedBy("ESAP_INV");

			trDbBean.setLastModifiedDate(new Timestamp(System.currentTimeMillis()));
			trDbBean.whereTerminatingRoutingIdEQ(getTerminatingRoutingId());	

			if ( trDbBean.updateSpByWhere(dbCon) <= 0 ){
				log.info("Updating Term routing");
				return false;
			}
               /* }
		catch(SQLException s)
		{
			setStatus(InvErrorCode.DB_EXCEPTION);
			log.info("DB_FAILURE in updateTermiantingRouting");
			s.printStackTrace();	
			return false;
		}*/
		setStatus(InvErrorCode.SUCCESS);
		return true;
		
	}
	
	public boolean deleteTerminatingRouting() throws SQLException, Exception
	{
		log.info("Entering TerminatingRouting::deleteTerminatingRouting");
		
		//try
		//{
			if(getTerminatingRoutingId() <= 0)
			{
				setStatus(InvErrorCode.INTERNAL_ERROR);
			return false;
			}
			DBTblTerminatingRouting trDbBean = new DBTblTerminatingRouting();
			trDbBean.whereTerminatingRoutingIdEQ(getTerminatingRoutingId());
			//trDbBean.setTerminatingRoutingId(getTerminatingRoutingId());
			log.info("Deleting Terminating Routing by Id [" + getTerminatingRoutingId() + "]");
			trDbBean.deleteByWhere(dbCon);
		/*}
		catch(SQLException s)
		{
			setStatus(InvErrorCode.DB_EXCEPTION);
			log.info("DB_FAILURE in deleteTerminatingRouting");
			s.printStackTrace();	
			return false;
		}*/
		setStatus(InvErrorCode.SUCCESS);
		return true;
	}
	
	public boolean deleteTerminatingRoutingWithRangeAndDialPlan() throws SQLException, Exception
	{
		log.info("Entering TerminatingRouting::deleteTerminatingRouting");
		
		//try
		//{

			DBTblTerminatingRouting trDbBean = new DBTblTerminatingRouting();
			trDbBean.whereDialPlanIdEQ(getDialPlanId());
			trDbBean.whereRangeStartEQ(getRangeStart());
			if(getRangeEnd() != null && !getRangeEnd().equalsIgnoreCase(""))
				trDbBean.whereRangeEndEQ(getRangeEnd());
			//trDbBean.setTerminatingRoutingId(getTerminatingRoutingId());
			log.info("Deleting Terminating DialPlan/RangeSt/RangeEnd [" + getDialPlanId() + "/"+ getRangeStart() + "/" + getRangeEnd() + "]");
			trDbBean.deleteByWhere(dbCon);
		/*}
		catch(SQLException s)
		{
			setStatus(InvErrorCode.DB_EXCEPTION);
			log.info("DB_FAILURE in deleteTerminatingRouting");
			s.printStackTrace();	
			return false;
		}*/
		setStatus(InvErrorCode.SUCCESS);
		return true;
	}	

	public static void splitTerminatingRoutingForDP(TerminatingRouting pubTnBeanObj, Connection connection) throws  SQLException, Exception
    {
                                                                                                                             
        long dialPlanId = pubTnBeanObj.getDialPlanId();
        long noa = pubTnBeanObj.getNoa();
        if(noa < 0 )
            noa = 1;
        long envOrderId = pubTnBeanObj.getEnvOrderId();
        /*Test code*/
        DBTblTerminatingRouting termDb = new DBTblTerminatingRouting();
        termDb.setDialPlanId(dialPlanId);
        //termDb.setLastModifiedDate(new Timestamp(System.currentTimeMillis()));
        termDb.whereDialPlanIdEQ(dialPlanId);
        termDb.whereNoaEQ(noa);
        termDb.updateSpByWhere(connection);
        /*Test code*/
        TblTerminatingRoutingQuery dbTermQry = new TblTerminatingRoutingQuery();
		dbTermQry.setLimitQry(false);
        dbTermQry.whereDialPlanIdEQ(dialPlanId);
        dbTermQry.whereNoaEQ(noa);
        dbTermQry.setOrderBy("RANGE_START");
        dbTermQry.query(connection);
        ArrayList <TblTerminatingRoutingDbBean> dbTriList = new  ArrayList<TblTerminatingRoutingDbBean>();
        if(dbTermQry.size() > 0 )
        {
            for(int i = 0; i < dbTermQry.size(); i++)
            {
                dbTriList.add(dbTermQry.getDbBean(i));
            }
        }
            String sInputRngStart = null;
            String sInputRngEnd = null;
        if(pubTnBeanObj != null) {
                sInputRngStart = pubTnBeanObj.getRangeStart();
                sInputRngEnd = pubTnBeanObj.getRangeEnd();
            }
            else {
                throw new Exception("Input is Null");
            }
		TblTerminatingRoutingDbBean firstNewBean = new TblTerminatingRoutingDbBean();
        TblTerminatingRoutingDbBean secondNewBean = new TblTerminatingRoutingDbBean();
        TblTerminatingRoutingDbBean oldBean = null;
        DBTblTerminatingRouting dbTermRouting = new DBTblTerminatingRouting();
                 
        Iterator itr = dbTriList.iterator();
        String action = null;
                 
        while(itr.hasNext()) {
            oldBean = (TblTerminatingRoutingDbBean) itr.next();
            firstNewBean.copyFrom(oldBean);
            secondNewBean.copyFrom(oldBean);
            action = delTriRange(oldBean, firstNewBean, secondNewBean, sInputRngStart, sInputRngEnd);
            if(action.equalsIgnoreCase("DELETE")) {
                log.info("DELETE EXISTING REC " + oldBean.getRangeStart() + "-" + oldBean.getRangeEnd());
                dbTermRouting.copyFromBean(oldBean);
                dbTermRouting.delete(connection);
            }
            else if (action.equalsIgnoreCase("SPLIT")) {
                log.info("DELETE EXISTING REC " + oldBean.getRangeStart() + "-" + oldBean.getRangeEnd());
                dbTermRouting.copyFromBean(oldBean);
                dbTermRouting.delete(connection);
                 
                log.info("INSERT NEW REC " + firstNewBean.getRangeStart() + "-" + firstNewBean.getRangeEnd());
                dbTermRouting.copyFromBean(firstNewBean);
                long terminatingRoutingId;
                terminatingRoutingId = dbTermRouting.getTerminatingRoutingIdSeqNextVal(connection);
                dbTermRouting.setTerminatingRoutingId((int)terminatingRoutingId);
                dbTermRouting.insert(connection);
                 
                log.info("INSERT NEW REC " + secondNewBean.getRangeStart() + "-" + secondNewBean.getRangeEnd());
                dbTermRouting.copyFromBean(secondNewBean);
                terminatingRoutingId = dbTermRouting.getTerminatingRoutingIdSeqNextVal(connection);
                dbTermRouting.setTerminatingRoutingId((int)terminatingRoutingId);
                dbTermRouting.insert(connection);
                 
            }
			if(action.equalsIgnoreCase("PD")) {
                log.info("DELETE EXISTING REC " + oldBean.getRangeStart() + "-" + oldBean.getRangeEnd());
                dbTermRouting.copyFromBean(oldBean);
                dbTermRouting.delete(connection);
                 
                log.info("INSERT NEW REC " + firstNewBean.getRangeStart() + "-" + firstNewBean.getRangeEnd());
                dbTermRouting.copyFromBean(firstNewBean);
                long terminatingRoutingId = dbTermRouting.getTerminatingRoutingIdSeqNextVal(connection);
                dbTermRouting.setTerminatingRoutingId((int)terminatingRoutingId);
                dbTermRouting.insert(connection);
            }
        }
    }
	
	private static String delTriRange(TblTerminatingRoutingDbBean oldBean, TblTerminatingRoutingDbBean firstNewBean, TblTerminatingRoutingDbBean secondNewBean, String inputRngStart, String inputRngEnd)
    {
        String action = null;
                                                                                                                             
        BigInteger nDbRngStart = new BigInteger(oldBean.getRangeStart());
        BigInteger nDbRngEnd = new BigInteger(oldBean.getRangeEnd());
        BigInteger nInputRngStart = new BigInteger(inputRngStart);
        BigInteger nInputRngEnd = new BigInteger(inputRngEnd);
                                                                                                                             
        BigInteger bigOne = BigInteger.valueOf(1);
                                                                                                                             
        // case 2, 4, 8, 9
        if(nInputRngEnd.compareTo(nDbRngStart) == -1 || nInputRngStart.compareTo(nDbRngEnd) == 1) {
            action = "NOACT";
        }
        // case 6, 7
        else if( (nInputRngStart.compareTo(nDbRngStart) == -1 || nInputRngStart.compareTo(nDbRngStart) == 0) &&
                 (nInputRngEnd.compareTo(nDbRngEnd) == 1 || nInputRngEnd.compareTo(nDbRngEnd) == 0) ){
            action = "DELETE";
        }
        // Case 1 Split
        else if (nInputRngStart.compareTo(nDbRngStart) == 1 && nInputRngEnd.compareTo(nDbRngEnd) == -1) {
		action = "SPLIT";
            firstNewBean.setRangeStart(leftPad(nDbRngStart, inputRngStart.length()));
            firstNewBean.setRangeEnd(leftPad(nInputRngStart.subtract(bigOne), inputRngStart.length()));
            secondNewBean.setRangeStart(leftPad(nInputRngEnd.add(bigOne), inputRngEnd.length()));
            secondNewBean.setRangeEnd(leftPad(nDbRngEnd, inputRngEnd.length()));
        }
        // Case PD
        else {
            action = "PD";
     
            BigInteger nNewRngStart = new BigInteger(oldBean.getRangeStart());
            BigInteger nNewRngEnd = new BigInteger(oldBean.getRangeEnd());
     
            if(nInputRngStart.compareTo(nDbRngStart) == -1 || nInputRngStart.compareTo(nDbRngStart) == 0) {
                nNewRngStart = nInputRngEnd.add(bigOne);
                nNewRngEnd = nDbRngEnd;
            }
            if(nInputRngEnd.compareTo(nDbRngEnd) == 1 || nInputRngEnd.compareTo(nDbRngEnd) == 0) {
                nNewRngStart = nDbRngStart;
                nNewRngEnd = nInputRngStart.subtract(bigOne);
            }
     
            firstNewBean.setRangeStart(leftPad(nNewRngStart, inputRngStart.length()));
            firstNewBean.setRangeEnd(leftPad(nNewRngEnd, inputRngEnd.length()));
        }
     
//        log.info("Old db range: " + oldBean.getRangeStart() + "-" + oldBean.getRangeEnd() +
//                           " Input Range: " + nInputRngStart + "-" + nInputRngEnd +
//                           " New First db Range: " + firstNewBean.getRangeStart() + "-" + firstNewBean.getRangeEnd() +
//                           " New Second db Range: " + secondNewBean.getRangeStart() + "-" + secondNewBean.getRangeEnd() +
//                           " Action:" + action);
     
        return action;
    }
	public static String leftPad(BigInteger nNum, int padding) {
        return nNum.toString();
        //return String.format("%0"+padding+"d", nNum.toString());
    //  return String.format("%0"+padding+"d", nNum.valueOf());
        //while(sNum.length() < len) {
        //  sNum = "0" + sNum;
        //}
        //return sNum;
    }
	
	public boolean isTriRangeValidForAdd(String rngStart, String rngEnd, long dpid) throws Exception{

		log.info(" isTriRangeValidForAdd method");
		log.info(" rngStart :: " + rngStart + " rngEnd :: " + rngEnd + " dpid :: " + dpid );
		PreparedStatement pStmt = null;
		ResultSet rs = null;
		
		try {
			StringBuffer triValSql = new StringBuffer();
			
			triValSql.append(" select * from tbl_terminating_routing");
			triValSql.append(" where (( ? between to_number(range_start) and to_number(range_end)) or ");
			triValSql.append(" ( ? between to_number(range_start) and to_number(range_end))) and dial_plan_id = ? AND NOA = 1");
			triValSql.append(" UNION select * from tbl_terminating_routing"); 
			triValSql.append(" where(to_number(range_start) between ? and ?) and");
			triValSql.append("(to_number(range_end) between ? and ?) and dial_plan_id = ? AND NOA = 1");
			log.info(" Sql  " + triValSql.toString() );
			pStmt = dbCon.prepareStatement(triValSql.toString());
			pStmt.setString(1, rngStart);
			pStmt.setString(2, rngEnd);
			pStmt.setLong(3, dpid);
			pStmt.setString(4, rngStart);
			pStmt.setString(5, rngEnd);
			pStmt.setString(6, rngStart);
			pStmt.setString(7, rngEnd);
			pStmt.setLong(8, dpid);
		
			
			if (pStmt != null){
				rs = pStmt.executeQuery();
				if ( rs.next()){
					log.info("TRI Records found....");
					return false;
				}
			}
			
			
		} catch (SQLException e) {
			e.printStackTrace();
		    //setStatus(InvErrorCode.DB_EXCEPTION);
		    log.info("DB_FAILURE in Fetching TRI records");
	        //return regionId;
		    throw e;
		} finally {
			if (pStmt != null){
				pStmt.close();
			}
			
			if ( rs != null ){
				rs.close();
			}
		}
		return true;

	}
	
}


