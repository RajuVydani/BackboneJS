package com.vz.esap.api.constant;

public interface InventoryServiceConstants 
{
	public String OneNetworkEnable_YES = "Y";
	public String OneNetworkEnable_NO = "N";
	
	public String priorityString_CLLI = "CLLI";
	public String priorityString_LATA = "LATA";
	public String priorityString_STATE = "STATE";
	public String priorityString_INVALID = "INVALID";
	public String order_source="VRD";
	public String RECORDS_ONLY="N";
	public String SUCCESS_STATUS_CODE="0";
	public String SUCCESS_STATUS_DESC="SUCCESS";
	public String FAILURE_STATUS_CODE="1";
	public String DATANOT_FOUND_DESC="Data Not Found";
	public String INVALID_REQUEST="INVALID_REQUEST"; 
	public String INVALID_REQUEST_MISSING_INPUT="Invalid Request. Bad or missing inputs.";
	
	public static final int SUCCESS_STATUS_CODE_INT = 0;
	public static final int FAILURE_STATUS_CODE_INT = 1;
	public static final String PORT_PEND = "PORT_PENDING";
	public static final String EMEA = "EMEA";
	
	public static final String DATE_FORMAT_TIMESTAMP = "yyyy-MM-dd HH:mm:ss.SSS";
	public static final String ENVORDERID = "EnvOrderId";
	
}
