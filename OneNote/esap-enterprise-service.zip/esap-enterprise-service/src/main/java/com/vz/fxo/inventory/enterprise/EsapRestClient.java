package com.vz.fxo.inventory.enterprise;



import java.sql.Connection;
import java.sql.SQLException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.vz.fxo.inventory.enterprise.support.PublicTnPool;

import esap.db.TblConfigParamsDbBean;
import esap.db.TblConfigParamsQuery;



public class EsapRestClient {
	
	private static Logger log = LoggerFactory.getLogger(EsapRestClient.class.toString());
	
	private Connection connection;
	public EsapRestClient(){
		
	}
	public EsapRestClient(Connection connection){
		this.connection = connection;
	}
//	public boolean addTriTnData(PublicTnPool publicTnPool) throws Exception{
//		DBTblTerminatingRouting termDbBean = new DBTblTerminatingRouting();
//		TblTerminatingRoutingQuery termQry = new TblTerminatingRoutingQuery();
//		String whereCls = " where (to_number(\'"
//				+ publicTnPool.getRangeStart()
//				+ "\') between to_number(range_start) and to_number(range_end)) and (to_number(\'"
//				+ publicTnPool.getRangeEnd()
//				+ "\') between to_number(range_start) and to_number(range_end)) and  noa = "
//				+ publicTnPool.getNoa();
//		LogUtil.info("whereCls" + whereCls);
//		termQry.queryByWhere(connection, whereCls);
//		if (termQry.size() > 0){
//			termDbBean.copyFromBean(termQry.getDbBean(0));
//			LogUtil.info("Term Routing already exists for the Dial Plan Id : "
//					+ termDbBean.getDialPlanId());
//			publicTnPool.setTerminatingRoutingId(termDbBean.getTerminatingRoutingId());
//			if (publicTnPool.getDialPlanId() == termDbBean.getDialPlanId()) {
//				return true;
//			} else {
//				return false;
//			}
//		} else {
//			LogUtil.info("Term Routing does not exists. Do a micro service call to perform Add TRI");
//			// Insert one TN record in TBL_TRI_TN_DATA
//			// New change are here.... to invoke Rest Service addTri api
//			HttpEntity<String> input = null;
//			ResponseEntity<String> response = null;
//			String addTriUrl = null;
//			String secondaryAddTriUrl = null;
//			try {
//				addTriUrl = getConfigParamValue("TRI", "ADD_TRI_REST_URL");
//				if (addTriUrl == null) {
//					LogUtil.info("ERROR : ADD_TRI_REST_URL is not configured in TBL_CONFIG_PARAMS");
//					throw new Exception("ADD_TRI_REST_URL is not configured in TBL_CONFIG_PARAMS");
//				}
//		
//				TriDataBean triDataBean = new TriDataBean();
//				
//				triDataBean.setTnId(1);//some dummy number. it will be taken from sequence
//				triDataBean.setDialPlanId(publicTnPool.getDialPlanId());
//				triDataBean.setLocationId(publicTnPool.getLocationId());
//				triDataBean.setNoa(publicTnPool.getNoa());
//				triDataBean.setTn(publicTnPool.getTn());
//				
//				if (!"NONE".equals(publicTnPool.getP1url()) && !"".equals(publicTnPool.getP1url())) {
//					triDataBean.setP1Url(publicTnPool.getP1url());
//				}
//				if (!"NONE".equals(publicTnPool.getPringtime())
//						&& !"".equals(publicTnPool.getPringtime())) {
//					triDataBean.setpRingTime(publicTnPool.getPringtime());
//				}
//				if (!"NONE".equals(publicTnPool.getPtrid()) && !"".equals(publicTnPool.getPtrid())) {
//					triDataBean.setpTrid(publicTnPool.getPtrid());
//				}
//				if (!"NONE".equals(publicTnPool.getPprefixdgts())
//						&& !"".equals(publicTnPool.getPprefixdgts())) {
//					triDataBean.setpPrefixDgts(publicTnPool.getPprefixdgts());
//				}
//				if (publicTnPool.getPsuffixnum() != -1) {
//					triDataBean.setpSuffixNum(publicTnPool.getPsuffixnum());
//				}
//				if (!"NONE".equals(publicTnPool.getA1url()) && !"".equals(publicTnPool.getA1url())) {
//					triDataBean.setA1Url(publicTnPool.getA1url());
//				}
//				if (!"NONE".equals(publicTnPool.getA1ringtime())
//						&& !"".equals(publicTnPool.getA1ringtime())) {
//					triDataBean.setA1RingTime(publicTnPool.getA1ringtime());
//				}
//				if (!"NONE".equals(publicTnPool.getA1trid()) && !"".equals(publicTnPool.getA1trid())) {
//					triDataBean.setA1Trid(publicTnPool.getA1trid());
//				}
//				if (!"NONE".equals(publicTnPool.getA1prefixdgts())
//						&& !"".equals(publicTnPool.getA1prefixdgts())) {
//					triDataBean.setA1PrefixDgts(publicTnPool.getA1prefixdgts());
//				}
//				if (publicTnPool.getA1suffixnum() != -1) {
//					triDataBean.setA1SuffixNum(publicTnPool.getA1suffixnum());
//				}
//				if (!"NONE".equals(publicTnPool.getA2url()) && !"".equals(publicTnPool.getA2url())) {
//					triDataBean.setA2Url(publicTnPool.getA2url());
//				}
//				if (!"NONE".equals(publicTnPool.getA2ringtime())
//						&& !"".equals(publicTnPool.getA2ringtime())) {
//					triDataBean.setA2RingTime(publicTnPool.getA2ringtime());
//				}
//				if (!"NONE".equals(publicTnPool.getA2trid()) && !"".equals(publicTnPool.getA2trid())) {
//					triDataBean.setA2Trid(publicTnPool.getA2trid());
//				}
//				if (!"NONE".equals(publicTnPool.getA2prefixdgts())
//						&& !"".equals(publicTnPool.getA2prefixdgts())) {
//					triDataBean.setA2PrefixDgts(publicTnPool.getA2prefixdgts());
//				}
//				if (publicTnPool.getA2suffixnum() != -1) {
//					triDataBean.setA2SuffixNum(publicTnPool.getA2suffixnum());
//				}
//				if (publicTnPool.getEnvOrderId() > 0) {
//					triDataBean.setEnvOrderId(publicTnPool.getEnvOrderId());
//				} else {
//					triDataBean.setEnvOrderId(-1);
//				}
//
//				if (!publicTnPool.getCreatedBy().equals("")) {
//					triDataBean.setCreatedBy(publicTnPool.getCreatedBy());
//				} else {
//					triDataBean.setCreatedBy("ESAP_INV");
//				}
//				if (!publicTnPool.getModifiedBy().equals("")) {
//					triDataBean.setModifiedBy(publicTnPool.getModifiedBy());
//				} else {
//					triDataBean.setModifiedBy("ESAP_INV");
//				}
//
//				triDataBean.setEnvOrderId(publicTnPool.getEnvOrderId());
//				
//						
//				StringBuffer buffer = new StringBuffer();
//				buffer.append("{").append( "\"tnId\":").append( triDataBean.getTnId()).append(",")
//				.append("\"dialPlanId\" :").append(triDataBean.getDialPlanId()).append(",")
//				.append("\"locationId\":").append("\"").append(triDataBean.getLocationId()).append("\",")
//				.append("\"noa\":").append(triDataBean.getNoa()).append(",")
//				.append("\"tn\":\"").append(triDataBean.getTn()).append("\",")
//				.append("\"p1Url\":\"").append(triDataBean.getP1Url()).append("\",")
//				.append("\"pRingTime\":\"").append(triDataBean.getpRingTime()).append("\",")
//				.append("\"pTrid\":\"").append(triDataBean.getpTrid()).append("\",")
//				.append("\"pPrefixDgts\":\"").append(triDataBean.getpPrefixDgts()).append("\",")
//				.append("\"pSuffixNum\":").append(triDataBean.getpSuffixNum()).append(",")
//				.append("\"a1Url\":\"").append(triDataBean.getA1Url()).append("\",")
//				.append("\"a1RingTime\":\"").append(triDataBean.getA1RingTime()).append("\",")
//				.append("\"a1Trid\":\"").append(triDataBean.getA1Trid()).append("\",")
//				.append("\"a1PrefixDgts\":\"").append(triDataBean.getA1PrefixDgts()).append("\",")
//				.append("\"a1SuffixNum\":").append(triDataBean.getA1SuffixNum()).append(",")
//				.append("\"a2Url\":\"").append(triDataBean.getA2Url()).append("\",")
//				.append("\"a2RingTime\":\"").append(triDataBean.getA2RingTime()).append("\",")
//				.append("\"a2Trid\":\"").append(triDataBean.getA2Trid()).append("\",")
//				.append("\"a2PrefixDgts\":\"").append(triDataBean.getA2PrefixDgts()).append("\",")
//				.append("\"a2SuffixNum\":").append(triDataBean.getA2SuffixNum()).append(",")
//				.append("\"createdBy\":\"").append(triDataBean.getCreatedBy()).append("\",")
//				.append("\"creationDate\":").append(triDataBean.getCreationDate()).append(",")
//				.append("\"modifiedBy\":\"").append(triDataBean.getModifiedBy()).append("\",")
//				.append("\"lastModifiedDate\":").append(triDataBean.getLastModifiedDate()).append(",")
//				.append("\"envOrderId\":").append(triDataBean.getEnvOrderId())
//				.append("}");
//				String req = buffer.toString();
//				
//				LogUtil.info("ADD TRI Request is :"+req);
//				
//				HttpHeaders headers = new HttpHeaders();
//				headers.setContentType(MediaType.APPLICATION_JSON);
//				input = new HttpEntity<>(req, headers);
//				
//				LogUtil.info("Httpentity: " + input.toString());
//				response = sendRequest(addTriUrl,input);
//				
//				LogUtil.info("addTri Response: " + response);
//			} catch (Exception e) {
//				e.printStackTrace();
//				LogUtil.info("Rest Service Failure with Primary URL:<"+addTriUrl +"> -"+ e);
//				LogUtil.info("Trying Secondary URL... "+secondaryAddTriUrl);
//				try{
//					secondaryAddTriUrl = getConfigParamValue("TRI", "SECONDARY_ADD_TRI_REST_URL");
//					if (secondaryAddTriUrl == null) {
//							LogUtil.info("ERROR : SECONDARY_ADD_TRI_REST_URL is not configured in TBL_CONFIG_PARAMS");
//							throw new Exception("SECONDARY_ADD_TRI_REST_URL is not configured in TBL_CONFIG_PARAMS");
//					}
//					if(input != null){
//						response = sendRequest(secondaryAddTriUrl,input);
//					}
//				}catch(Exception e1){
//					throw e1;
//				}
//			}
//		}
//		
//		return true;
//	}
	
	public boolean deleteTriTnData(PublicTnPool publicTnPool) throws Exception{

		log.info("Term Routing does not exists. Do a micro service call to perform Delete TRI");
		// Delete one TN record in TBL_TRI_TN_DATA
		// New change are here.... to invoke Rest Service addTri api
		//RestTemplate restTemplate = new RestTemplate();
		HttpEntity<String> input = null;
		ResponseEntity<String> response = null;
		String deleteTriUrl = null;
		String secondaryDeleteTriUrl = null;
		try {
			deleteTriUrl = getConfigParamValue("TRI", "DELETE_TRI_REST_URL");
			if (deleteTriUrl == null) {
				log.info("ERROR : DELETE_TRI_REST_URL is not configured in TBL_CONFIG_PARAMS");
				throw new Exception("DELETE_TRI_REST_URL is not configured in TBL_CONFIG_PARAMS");
			}
		
			TriDataBean triDataBean = new TriDataBean();
			
			triDataBean.setTnId(1);//some dummy number. it will be taken from sequence
			triDataBean.setDialPlanId(publicTnPool.getDialPlanId());
			triDataBean.setLocationId(publicTnPool.getLocationId());
			triDataBean.setNoa(publicTnPool.getNoa());
			triDataBean.setTn(publicTnPool.getTn());
			
			if (!"NONE".equals(publicTnPool.getP1url()) && !"".equals(publicTnPool.getP1url())) {
				triDataBean.setP1Url(publicTnPool.getP1url());
			}
			if (!"NONE".equals(publicTnPool.getPringtime())
					&& !"".equals(publicTnPool.getPringtime())) {
				triDataBean.setpRingTime(publicTnPool.getPringtime());
			}
			if (!"NONE".equals(publicTnPool.getPtrid()) && !"".equals(publicTnPool.getPtrid())) {
				triDataBean.setpTrid(publicTnPool.getPtrid());
			}
			if (!"NONE".equals(publicTnPool.getPprefixdgts())
					&& !"".equals(publicTnPool.getPprefixdgts())) {
				triDataBean.setpPrefixDgts(publicTnPool.getPprefixdgts());
			}
			if (publicTnPool.getPsuffixnum() != -1) {
				triDataBean.setpSuffixNum(publicTnPool.getPsuffixnum());
			}
			if (!"NONE".equals(publicTnPool.getA1url()) && !"".equals(publicTnPool.getA1url())) {
				triDataBean.setA1Url(publicTnPool.getA1url());
			}
			if (!"NONE".equals(publicTnPool.getA1ringtime())
					&& !"".equals(publicTnPool.getA1ringtime())) {
				triDataBean.setA1RingTime(publicTnPool.getA1ringtime());
			}
			if (!"NONE".equals(publicTnPool.getA1trid()) && !"".equals(publicTnPool.getA1trid())) {
				triDataBean.setA1Trid(publicTnPool.getA1trid());
			}
			if (!"NONE".equals(publicTnPool.getA1prefixdgts())
					&& !"".equals(publicTnPool.getA1prefixdgts())) {
				triDataBean.setA1PrefixDgts(publicTnPool.getA1prefixdgts());
			}
			if (publicTnPool.getA1suffixnum() != -1) {
				triDataBean.setA1SuffixNum(publicTnPool.getA1suffixnum());
			}
			if (!"NONE".equals(publicTnPool.getA2url()) && !"".equals(publicTnPool.getA2url())) {
				triDataBean.setA2Url(publicTnPool.getA2url());
			}
			if (!"NONE".equals(publicTnPool.getA2ringtime())
					&& !"".equals(publicTnPool.getA2ringtime())) {
				triDataBean.setA2RingTime(publicTnPool.getA2ringtime());
			}
			if (!"NONE".equals(publicTnPool.getA2trid()) && !"".equals(publicTnPool.getA2trid())) {
				triDataBean.setA2Trid(publicTnPool.getA2trid());
			}
			if (!"NONE".equals(publicTnPool.getA2prefixdgts())
					&& !"".equals(publicTnPool.getA2prefixdgts())) {
				triDataBean.setA2PrefixDgts(publicTnPool.getA2prefixdgts());
			}
			if (publicTnPool.getA2suffixnum() != -1) {
				triDataBean.setA2SuffixNum(publicTnPool.getA2suffixnum());
			}
			if (publicTnPool.getEnvOrderId() > 0) {
				triDataBean.setEnvOrderId(publicTnPool.getEnvOrderId());
			} else {
				triDataBean.setEnvOrderId(-1);
			}

			if (!publicTnPool.getCreatedBy().equals("")) {
				triDataBean.setCreatedBy(publicTnPool.getCreatedBy());
			} else {
				triDataBean.setCreatedBy("ESAP_INV");
			}
			if (!publicTnPool.getModifiedBy().equals("")) {
				triDataBean.setModifiedBy(publicTnPool.getModifiedBy());
			} else {
				triDataBean.setModifiedBy("ESAP_INV");
			}
			triDataBean.setEnvOrderId(publicTnPool.getEnvOrderId());
			
					
			StringBuffer buffer = new StringBuffer();
			buffer.append("{").append( "\"tnId\":").append( triDataBean.getTnId()).append(",")
			.append("\"dialPlanId\" :").append(triDataBean.getDialPlanId()).append(",")
			.append("\"locationId\":").append("\"").append(triDataBean.getLocationId()).append("\",")
			.append("\"noa\":").append(triDataBean.getNoa()).append(",")
			.append("\"tn\":\"").append(triDataBean.getTn()).append("\",")
			.append("\"p1Url\":\"").append(triDataBean.getP1Url()).append("\",")
			.append("\"pRingTime\":\"").append(triDataBean.getpRingTime()).append("\",")
			.append("\"pTrid\":\"").append(triDataBean.getpTrid()).append("\",")
			.append("\"pPrefixDgts\":\"").append(triDataBean.getpPrefixDgts()).append("\",")
			.append("\"pSuffixNum\":").append(triDataBean.getpSuffixNum()).append(",")
			.append("\"a1Url\":\"").append(triDataBean.getA1Url()).append("\",")
			.append("\"a1RingTime\":\"").append(triDataBean.getA1RingTime()).append("\",")
			.append("\"a1Trid\":\"").append(triDataBean.getA1Trid()).append("\",")
			.append("\"a1PrefixDgts\":\"").append(triDataBean.getA1PrefixDgts()).append("\",")
			.append("\"a1SuffixNum\":").append(triDataBean.getA1SuffixNum()).append(",")
			.append("\"a2Url\":\"").append(triDataBean.getA2Url()).append("\",")
			.append("\"a2RingTime\":\"").append(triDataBean.getA2RingTime()).append("\",")
			.append("\"a2Trid\":\"").append(triDataBean.getA2Trid()).append("\",")
			.append("\"a2PrefixDgts\":\"").append(triDataBean.getA2PrefixDgts()).append("\",")
			.append("\"a2SuffixNum\":").append(triDataBean.getA2SuffixNum()).append(",")
			.append("\"createdBy\":\"").append(triDataBean.getCreatedBy()).append("\",")
			.append("\"creationDate\":").append(triDataBean.getCreationDate()).append(",")
			.append("\"modifiedBy\":\"").append(triDataBean.getModifiedBy()).append("\",")
			.append("\"lastModifiedDate\":").append(triDataBean.getLastModifiedDate()).append(",")
			.append("\"envOrderId\":").append(triDataBean.getEnvOrderId())
			.append("}");
			String req = buffer.toString();
			
			log.info("ADD TRI Request is :"+req);
			
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			input = new HttpEntity<>(req, headers);
			

			log.info("Httpentity: " + input.toString());
			//response = restTemplate.exchange(deleteTriUrl,HttpMethod.POST, input, String.class);
			response = sendRequest(deleteTriUrl,input);
			
			log.info("deleteTri Response: " + response);
		} catch (Exception e) {
			e.printStackTrace();
			log.info("Rest Service Failure with Primary URL:<"+deleteTriUrl +"> -"+ e);
			log.info("Trying Secondary URL... "+secondaryDeleteTriUrl);
			try{
				secondaryDeleteTriUrl = getConfigParamValue("TRI", "SECONDARY_DELETE_TRI_REST_URL");
				if (secondaryDeleteTriUrl == null) {
						log.info("ERROR : SECONDARY_DELETE_TRI_REST_URL is not configured in TBL_CONFIG_PARAMS");
						throw new Exception("SECONDARY_DELETE_TRI_REST_URL is not configured in TBL_CONFIG_PARAMS");
				}
				if(input != null){
					response = sendRequest(secondaryDeleteTriUrl,input);
				}
			}catch(Exception e1){
				throw e1;
			}
		}
		
	return true;
	}
	
	/****************************************************************/
//	public void consolidateTriTnData(String locationId, String envOrderId,long dialPlanId)
//			throws Exception {
//		//TblLocationDbBean locationDbBean = getLocationForLocationId(locationId);
//		//RestTemplate restTemplate = new RestTemplate();
//		HttpEntity<String> input = null;
//		ResponseEntity<String> response = null;
//		String consolidateTriUrl = null;
//		String secondaryConsolidateTriUrl = null;
//		try {
//			consolidateTriUrl = getConfigParamValue("TRI", "CONSOLIDATE_TRI_REST_URL");
//			if (consolidateTriUrl == null) {
//				LogUtil.info("ERROR : CONSOLIDATE_TRI_REST_URL is not configured in TBL_CONFIG_PARAMS");
//				throw new Exception("CONSOLIDATE_TRI_REST_URL is not configured in TBL_CONFIG_PARAMS");
//			}
//			
//			TriDataBean triDataBean = new TriDataBean();
//
//			triDataBean.setTnId(1);// some dummy number. it will be taken from
//									// sequence
//			triDataBean.setDialPlanId(dialPlanId);
//			triDataBean.setLocationId(locationId);
//			triDataBean.setNoa(1);
//			triDataBean.setTn("");
//			triDataBean.setCreatedBy("ESAP_INV");
//			triDataBean.setModifiedBy("ESAP_INV");
//			triDataBean.setEnvOrderId(Long.parseLong(envOrderId));
//
//			StringBuffer buffer = new StringBuffer();
//			buffer.append("{").append("\"tnId\":")
//					.append(triDataBean.getTnId()).append(",")
//					.append("\"dialPlanId\" :")
//					.append(triDataBean.getDialPlanId()).append(",")
//					.append("\"locationId\":").append("\"")
//					.append(triDataBean.getLocationId()).append("\",")
//					.append("\"noa\":").append(triDataBean.getNoa())
//					.append(",").append("\"tn\":\"")
//					.append(triDataBean.getTn()).append("\",")
//					.append("\"p1Url\":\"").append(triDataBean.getP1Url())
//					.append("\",").append("\"pRingTime\":\"")
//					.append(triDataBean.getpRingTime()).append("\",")
//					.append("\"pTrid\":\"").append(triDataBean.getpTrid())
//					.append("\",").append("\"pPrefixDgts\":\"")
//					.append(triDataBean.getpPrefixDgts()).append("\",")
//					.append("\"pSuffixNum\":")
//					.append(triDataBean.getpSuffixNum()).append(",")
//					.append("\"a1Url\":\"").append(triDataBean.getA1Url())
//					.append("\",").append("\"a1RingTime\":\"")
//					.append(triDataBean.getA1RingTime()).append("\",")
//					.append("\"a1Trid\":\"").append(triDataBean.getA1Trid())
//					.append("\",").append("\"a1PrefixDgts\":\"")
//					.append(triDataBean.getA1PrefixDgts()).append("\",")
//					.append("\"a1SuffixNum\":")
//					.append(triDataBean.getA1SuffixNum()).append(",")
//					.append("\"a2Url\":\"").append(triDataBean.getA2Url())
//					.append("\",").append("\"a2RingTime\":\"")
//					.append(triDataBean.getA2RingTime()).append("\",")
//					.append("\"a2Trid\":\"").append(triDataBean.getA2Trid())
//					.append("\",").append("\"a2PrefixDgts\":\"")
//					.append(triDataBean.getA2PrefixDgts()).append("\",")
//					.append("\"a2SuffixNum\":")
//					.append(triDataBean.getA2SuffixNum()).append(",")
//					.append("\"createdBy\":\"")
//					.append(triDataBean.getCreatedBy()).append("\",")
//					.append("\"creationDate\":")
//					.append(triDataBean.getCreationDate()).append(",")
//					.append("\"modifiedBy\":\"")
//					.append(triDataBean.getModifiedBy()).append("\",")
//					.append("\"lastModifiedDate\":")
//					.append(triDataBean.getLastModifiedDate()).append(",")
//					.append("\"envOrderId\":")
//					.append(triDataBean.getEnvOrderId()).append("}");
//			String req = buffer.toString();
//
//			LogUtil.info("CONSOLIDATE TRI Request is :" + req);
//
//			HttpHeaders headers = new HttpHeaders();
//			headers.setContentType(MediaType.APPLICATION_JSON);
//			input = new HttpEntity<>(req, headers);
//
//			LogUtil.info("Httpentity: " + input.toString());
//			response = sendRequest(consolidateTriUrl,input);
//
//			LogUtil.info("consolidateTri Response: " + response);
//		} catch (Exception e) {
//			e.printStackTrace();
//			LogUtil.info("Rest Service Failure with Primary URL:<"+consolidateTriUrl +"> -"+ e);
//			LogUtil.info("Trying Secondary URL... "+secondaryConsolidateTriUrl);
//			try{
//				secondaryConsolidateTriUrl = getConfigParamValue("TRI", "SECONDARY_CONSOLIDATE_TRI_REST_URL");
//				if (secondaryConsolidateTriUrl == null) {
//						LogUtil.info("ERROR : SECONDARY_CONSOLIDATE_TRI_REST_URL is not configured in TBL_CONFIG_PARAMS");
//						throw new Exception("SECONDARY_CONSOLIDATE_TRI_REST_URL is not configured in TBL_CONFIG_PARAMS");
//				}
//				
//				if(input != null){
//					response = sendRequest(secondaryConsolidateTriUrl,input);
//				}
//			}catch(Exception e1){
//				throw e1;
//			}
//		}
//	}
	private ResponseEntity<String> sendRequest(String url,HttpEntity<String> input) throws Exception{
		ResponseEntity<String> response = null;
		try{
			RestTemplate restTemplate = new RestTemplate();
			response = restTemplate.exchange(url,HttpMethod.POST, input, String.class);
		}catch(Exception e){
			throw e;
		}
		return response;
	}
	public String getConfigParamValue(String processName, String paramName)
			throws SQLException {
		String paramValue = null;

		TblConfigParamsQuery paramsQ = new TblConfigParamsQuery();
		if (processName != null)
			paramsQ.whereProcessNameEQ(processName);
		if (paramName != null)
			paramsQ.whereParamNameEQ(paramName);
		paramsQ.query(connection);

		if (paramsQ.size() <= 0) {
			log.info("No Config Entry Found by ProcessName ["
					+ processName + "] and ParamName [" + paramName + "]");
			return paramValue;
		}

		TblConfigParamsDbBean cpBean = paramsQ.getDbBean(0);
		paramValue = cpBean.getParamValue();
		log.info("Successfully Retrieved Param Value [" + paramValue+ "]");
		return paramValue;
	}
	
//	public Object invokeService(Object inputdata,String url,String svcUserName,String svcPassword,Class responseClassObj) {
//		LogUtil.info("Sending request to URL:"+url);
//		RestTemplate restTemplate = new RestTemplate();
//		/*String plainClientCredentials = svcUserName + ":" + svcPassword;
//		String base64ClientCredentials = new String(
//				Base64.encodeBase64(plainClientCredentials.getBytes()));*/
//
//		HttpHeaders headers = new HttpHeaders();
//		//headers.add("Authorization", "Basic " + base64ClientCredentials);
//
//		headers.setContentType(MediaType.APPLICATION_JSON);
//		HttpEntity<Object> input = new HttpEntity<>(inputdata, headers);
//
//		ResponseEntity<Object> response = null;
//		try {
//
//			response = restTemplate.exchange(url, HttpMethod.POST, input,
//					responseClassObj);
//		} catch (Exception e) {
//			throw e;
//		}
//		LogUtil.info("Received response :<"+response+">");
//		return response.getBody();
//	}
}
