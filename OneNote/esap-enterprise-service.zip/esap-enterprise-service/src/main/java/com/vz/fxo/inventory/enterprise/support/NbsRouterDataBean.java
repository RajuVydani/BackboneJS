package com.vz.fxo.inventory.enterprise.support;
/*
 NBS_ROUTER_DATA_ID  NOT NULL NUMBER        
NBS_CLUSTER_INFO_ID          NUMBER        
NBS_CIRCUIT_ID               VARCHAR2(300) 
VLAN                         VARCHAR2(80)  
STATUS                       NUMBER        
SR                           VARCHAR2(200) 
SR_TYPE                      VARCHAR2(200) 
CREATED_BY          NOT NULL VARCHAR2(50)  
CREATION_DATE       NOT NULL DATE          
MODIFIED_BY         NOT NULL VARCHAR2(50)  
LAST_MODIFIED_DATE  NOT NULL DATE    
 */
public class NbsRouterDataBean {
   //members

   protected int nbsRouterDataId;
   protected int nbsclusterInfoId;
   protected String nbsCircuitId;
   protected String vlan;
   protected int status;
   protected String sr;
   protected String  sr_type;    
   protected String createdBy;
   protected String modifiedBy;
   protected java.sql.Timestamp creationDate;
   protected java.sql.Timestamp lastModifiedDate;
   protected boolean getAll;
  
   /**
    * Default Constructor -- Initializes all fields to default values.
    */
   public NbsRouterDataBean() {
      this.nbsRouterDataId = 0;
      this.nbsclusterInfoId = 0;
      this.nbsCircuitId = "NONE";
      this.vlan = "NONE";
      this.status =0;
      this.sr = "NONE";
      this.sr_type = "NONE";
   }

   /**
    * Constructor
    *
    * @param poolBean
    */
   public NbsRouterDataBean(NbsRouterDataBean poolBean) {
      this.nbsRouterDataId = poolBean.nbsRouterDataId;
      this.nbsclusterInfoId = poolBean.nbsclusterInfoId;
      this.nbsCircuitId = poolBean.nbsCircuitId;
      this.vlan = poolBean.vlan;
      this.status = poolBean.status;
      this.sr = poolBean.sr;
      this.sr_type = poolBean.sr_type;
     
   }

  

public void initilizeTODefault() {
      this.nbsRouterDataId = 0;
      this.nbsclusterInfoId = 0;
      this.nbsCircuitId = "";
      this.vlan = "";
      this.status = 0;
    
   }
	public int getNbsRouterDataId() {
		return nbsRouterDataId;
	}
	
	public void setNbsRouterDataId(int nbsRouterDataId) {
		this.nbsRouterDataId = nbsRouterDataId;
	}
	
	public int getNbsclusterInfoId() {
		return nbsclusterInfoId;
	}
	
	public void setNbsclusterInfoId(int nbsclusterInfoId) {
		this.nbsclusterInfoId = nbsclusterInfoId;
	}
	
	public String getNbsCircuitId() {
		return nbsCircuitId;
	}
	
	public void setNbsCircuitId(String nbsCircuitId) {
		this.nbsCircuitId = nbsCircuitId;
	}
	
	public String getVlan() {
		return vlan;
	}

	public void setVlan(String vlan) {
		this.vlan = vlan;
	}
	
	public int getStatus() {
		return status;
	}
	
	public void setStatus(int status) {
		this.status = status;
	}
	
	public String getSr() {
		return sr;
	}
	
	public void setSr(String sr) {
		this.sr = sr;
	}

	public String getSr_type() {
		return sr_type;
	}
	
	public void setSr_type(String sr_type) {
		this.sr_type = sr_type;
	}
	
	public String getCreatedBy() {
		return createdBy;
	}
	
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	
	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	
	public java.sql.Timestamp getCreationDate() {
		return creationDate;
	}
	
	public void setCreationDate(java.sql.Timestamp creationDate) {
		this.creationDate = creationDate;
	}
	
	public java.sql.Timestamp getLastModifiedDate() {
		return lastModifiedDate;
	}
	
	public void setLastModifiedDate(java.sql.Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public boolean isGetAll() {
		return getAll;
	}
	
	public void setGetAll(boolean getAll) {
		this.getAll = getAll;
	}

   //
} //EOF