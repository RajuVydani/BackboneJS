package com.vz.fxo.inventory.enterprise.helper;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import EsapEnumPkg.OrderLogEnum;
import EsapEnumPkg.VzbVoipEnum;

import com.vz.esap.api.connector.service.impl.ConfigDomainDataServiceImpl;
import com.vz.esap.api.connector.service.impl.OrderDomainDataServiceImpl;
import com.vz.esap.api.model.ordering.EntityBatch;
import com.vz.esap.api.model.ordering.EntityData;
import com.vz.esap.api.model.ordering.TableOrderDetailsParam;
import com.vz.fxo.inventory.enterprise.support.CallingPlan;
import com.vz.fxo.inventory.enterprise.support.DigitStringBean;
import com.vz.fxo.inventory.enterprise.support.FeaturesBean;
import com.vz.fxo.inventory.enterprise.support.IpSec;
import com.vz.fxo.inventory.enterprise.support.IpSecRequestDetailsBean;
import com.vz.fxo.inventory.enterprise.support.IpSecUtil;
import com.vz.fxo.inventory.enterprise.support.SubscriberDevice;
import com.vz.fxo.inventory.enterprise.support.SubscriberDeviceBean;

import static com.vz.fxo.inventory.enterprise.helper.ActionFunctionHelper.*;
import esap.db.DBTblEnterprise;
import esap.db.DBTblLocation;
import esap.db.TblCodecTypeDbBean;
import esap.db.TblCodecTypeQuery;
import esap.db.TblDeviceFirmwaresQuery;
import esap.db.TblEndPointCharDbBean;
import esap.db.TblEndPointCharQuery;
import esap.db.TblFirmwareVersionQuery;
import esap.db.TblGroupDbBean;
import esap.db.TblGroupQuery;
import esap.db.TblGroupTnDbBean;
import esap.db.TblGroupTnQuery;
import esap.db.TblLocationDbBean;
import esap.db.TblLocationQuery;
import esap.db.TblPublicTnPoolDbBean;
import esap.db.TblPublicTnPoolQuery;
import esap.db.TblSbcInfoDbBean;
import esap.db.TblSbcInfoQuery;
import esap.db.TblSubscriberTnQuery;
import esap.db.TblVmAccessDbBean;
import esap.db.TblVmAccessQuery;
import esap.db.TblVmBoxSizeDbBean;
import esap.db.TblVmBoxSizeQuery;
import esap.db.TblVzbFeaturesDbBean;
import esap.db.TblVzbFeaturesQuery;

//import com.vz.fxo.inventory.enterprise.support.Location;
import com.vz.fxo.inventory.enterprise.support.Sbc;

public class TNActionFunction {

	private static Logger log = LoggerFactory.getLogger(TNActionFunction.class.toString());

	protected static OrderDomainDataServiceImpl orderDomainDataService;

	public static boolean isLinePortUsedBySub(String linePort, String locationId, String service, Connection connection)
			throws Exception, SQLException {
		
		boolean isExists = false;
		PreparedStatement pStmt = null;
		ResultSet rs = null;
		String linePortSql = null;

		if (!(service.equalsIgnoreCase("HIPC") || service.equalsIgnoreCase("PBX/KEY")
				|| service.equalsIgnoreCase("PILOT"))) {
			throw new Exception("Invalid service passed to lineport validation");
		}

		if (service.equalsIgnoreCase("HIPC")) {

			linePortSql = " select sd.sub_id sub_id, l.location_id from tbl_subscriber_device sd, TBL_DEVICE_MAP dm, tbl_location l "
					+ " where l.sip_domain in ( select sip_domain from tbl_location where location_id = ? ) "
					+ " and dm.location_id = l.location_id " + " and sd.device_map_id = dm.device_map_id "
					+ " and sd.line_port = ? ";
		} else if (service.equalsIgnoreCase("PBX/KEY")) {

			linePortSql = " select gt.group_id sub_id, l.location_id from tbl_location l, tbl_group g , tbl_group_tn gt "
					+ " where l.sip_domain in (select sip_domain from tbl_location where location_id = ? ) "
					+ " and g.location_id = l.location_id " + " and gt.group_id = g.group_id "
					+ " and gt.line_port = ?  ";

		} else if (service.equalsIgnoreCase("PILOT")) {

			linePortSql = " select  g.group_id sub_id, l.location_id from tbl_location l, tbl_group g "
					+ " where l.sip_domain in (select sip_domain from tbl_location where location_id = ? ) "
					+ " and g.location_id = l.location_id " + " and g.line_port =  ? ";
		}

		try {
			pStmt = connection.prepareStatement(linePortSql);
			log.info("LocationId : {} LinePort :{} Sql :{}" , locationId,linePort,linePortSql);
			//log.info("LinePort" + linePort);
			//log.info("Sql" + linePortSql);
			if (pStmt != null) {
				pStmt.setString(1, locationId);
				pStmt.setString(2, linePort);
				rs = pStmt.executeQuery();
				if (rs.next()) {
					isExists = true;
					log.info("LinePort <" + linePort + "> Already in Use by SUB/GROUP <" + rs.getString("sub_id")
							+ " And locationId :" + rs.getString("location_id") + ">");
					String TN = getGrpTN(rs.getString("sub_id"), linePort, connection);

					if (service.equalsIgnoreCase("HIPC")) {

						boolean isExtn = isSubExtnOnly(rs.getString("sub_id"), connection);
						if (isExtn) {
							TN = getExtnFromTblSubscriber(rs.getString("sub_id"), connection);
						} else {
							TN = getUserIdFromTblSubscriberTn(rs.getString("sub_id"), connection);
						}
					}

					throw new Exception("ESP_VZB_INV_LINEPORT_ALRDY_IN_USE_BY_DIFF_SUB, LinePort " + linePort
							+ " already in Use by TN/Extn " + TN + " and locationId " + rs.getString("location_id"));
				}
			}

		} catch (SQLException e) {

			// log.error(" getSequenceValue()  exception {} ", exception);
			log.info("ERROR: Exception caught while trying to query tbl_subscriber_device/tbl_group");
			log.error("ERROR: Exception caught while trying to query tbl_subscriber_device/tbl_group", e);


			log.error(
					"ERROR: Exception caught while trying to query tbl_subscriber_device/tbl_group",
					e);


		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (pStmt != null) {
					pStmt.close();
				}
			} catch (SQLException e) {
			}
		}
		return isExists;
	}

	public static OrderDomainDataServiceImpl getOrderDomainDataService() {
		return orderDomainDataService;
	}

	public static void setOrderDomainDataService(OrderDomainDataServiceImpl orderDomainDataService) {
		TNActionFunction.orderDomainDataService = orderDomainDataService;
	}

	public static boolean isSubExtnOnly(String subId, Connection connection) throws Exception {
		PreparedStatement cntPstmt = null;
		ResultSet cntRs = null;

		StringBuffer extnSubCntSql = new StringBuffer();
		try {
			extnSubCntSql.append("select count(*) from tbl_subscriber sub, tbl_subscriber_tn stn where "
					+ "sub.sub_id = stn.sub_id and stn.nat_user_id = 1 and stn.sub_id = ?");
			cntPstmt = connection.prepareStatement(extnSubCntSql.toString());
			cntPstmt.setString(1, subId);
			if (null != cntPstmt)
				cntRs = cntPstmt.executeQuery();
			if (cntRs.next()) {
				if (cntRs.getInt(1) == 0) {
					log.info("cnt is 0 so extn only subscriber :: " + subId);
					return true;
				}
			}
		} catch (SQLException e) {
			// e.printStackTrace();
			log.info("ERROR: SQLException in isSubExtnOnly", e);
		} catch (Exception e) {
			// e.printStackTrace();
			log.info("ERROR: Exception in isSubExtnOnly", e);
		} finally {
			if (cntRs != null) {
				cntRs.close();
			}
			if (cntPstmt != null) {
				cntPstmt.close();
			}
		}
		return false;
	}


	public static String getExtnFromTblSubscriber(String subId, Connection connection) throws Exception {

		PreparedStatement pStmt = null;
		ResultSet rs = null;
		String Sql = null;


		Sql = "select extension from tbl_subscriber where sub_id='" + subId + "'";

		String extn = null;
		try {
			pStmt = connection.prepareStatement(Sql);
			log.info("getExtnFromTblSubscriber Sql :{}" , Sql);
			rs = pStmt.executeQuery();
			if (rs.next()) {
				extn = rs.getString("EXTENSION");
			}
		} catch (SQLException e) {
			log.info(
					"ERROR: Exception caught while trying to query tbl_subscriber_tn",
					e);
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (pStmt != null) {
					pStmt.close();
				}
			} catch (SQLException e) {
				throw new Exception("Exception caught while closing result set/prepared statement");
			}
		}
		return extn;
	}

	@SuppressWarnings("unchecked")
	public static String getGrpTN(String groupId, String linePort, Connection connection) throws Exception {
		String lsTN = null;
		TblPublicTnPoolDbBean publicTnPoolDbBean = new TblPublicTnPoolDbBean();
		ArrayList<TblPublicTnPoolDbBean> resultList = null;
		try {
			TblGroupTnQuery groupTnQuery = new TblGroupTnQuery();
			groupTnQuery.whereGroupIdEQ(Long.parseLong(groupId));
			groupTnQuery.whereLinePortEQ(linePort);
			groupTnQuery.query(connection);
			if (groupTnQuery.size() > 0) {
				int tnPoolId = (int) groupTnQuery.getDbBean(0).getTnPoolId();
				TblPublicTnPoolQuery tnQry = new TblPublicTnPoolQuery();
				tnQry.whereTnPoolIdEQ(tnPoolId);
				tnQry.query(connection);
				resultList = tnQry.getResultArrayList();
			}
			if (resultList != null && (!resultList.isEmpty())) {
				publicTnPoolDbBean = (TblPublicTnPoolDbBean) resultList.get(0);
				lsTN = publicTnPoolDbBean.getTn();
			}
		} catch (SQLException e) {
			// e.printStackTrace();
			log.info("ERROR: Exception caught while trying to query tbl_group_tn", e);
		}
		return lsTN;
	}


	public static String getUserIdFromTblSubscriberTn(String subId, Connection connection) throws Exception {

		PreparedStatement pStmt = null;
		ResultSet rs = null;
		String Sql = null;

		Sql = "select user_id from tbl_subscriber_tn where sub_id='" + subId
				+ "' and NAT_USER_ID=1";

		String userId = null;
		try {
			pStmt = connection.prepareStatement(Sql);
			log.info("getUserIdFromTblSubscriberTn SQL : {}", Sql);
			rs = pStmt.executeQuery();
			if (rs.next()) {
				userId = rs.getString("USER_ID");
			}
		} catch (SQLException e) {
			// e.printStackTrace();
			log.info("ERROR: Exception caught while trying to query tbl_subscriber_tn", e);
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (pStmt != null) {
					pStmt.close();
				}
			} catch (SQLException e) {
			}
		}
		return userId;
	}

	public static void insLinePortToTblOrderDetails(EntityData entityData, String linePort, String action)
			throws Exception, SQLException {

		long parentId = 0;

		TableOrderDetailsParam tableOrderDetailsParam = ActionFunctionHelper.getTableOrderDetaisParam(entityData,
				"TNRecord");
		/*
		 * Vector paramList = orderParam.getParams(); for (int i = 0; i <
		 * paramList.size(); i++) { TableOrderDetailsParam pd =
		 * (TableOrderDetailsParam) paramList.get(i); if
		 * (!pd.getAction().equals(action)) continue;
		 * 
		 * if (pd.getParamName().equals("TNRecord")) { parentId =
		 * pd.getOrderDetailId(); } }
		 */

		// new code changes
		/*
		 * for (TableOrderDetailsParam param :
		 * tableOrderDetailsParam.getParamDetail()) { if
		 * (param.getParamName().equals("TNRecord") &&
		 * param.getAction().equals(action)) { //tableOrderDetailsParamSelected
		 * = param; parentId =
		 * Long.parseLong(tableOrderDetailsParam.getOrderDetailId()); //break; }
		 * 
		 * }
		 */

		if (tableOrderDetailsParam != null && tableOrderDetailsParam.getAction().equals(action)) {
			// tableOrderDetailsParamSelected = param;
			parentId = Long.parseLong(tableOrderDetailsParam.getOrderDetailId());
			// break;
		}

		Long orderDetailId = orderDomainDataService.insertTblOrderDetails(0L, parentId, "LinePort", linePort);

		log.info("Inserted  LinePort <" + linePort + "> with order detail id <" + orderDetailId + ">");

	}

	/**
	 * This method constructs and return the line port for a given Line Port
	 * Length and TN With the construct linePort using the following algorithm
	 * if linePortLength < tn.length(), trim tn to linePortLength, to form
	 * linePortValue if linePortLength > tn.length(), padd 0 to tn to form
	 * linePortValue
	 */
	public static String getLinePort(String tn, int linePortLength) throws Exception {
		String linePort = "";

		if (linePortLength < tn.length()) {
			linePort = tn.substring(tn.length() - linePortLength);
		} else {
			String zeroPadding = "";
			int lengthDiff = linePortLength - tn.length();

			for (int i = 0; i < lengthDiff; i++) {
				zeroPadding = "0" + zeroPadding;
			}
			linePort = zeroPadding + tn;
		}

		log.info("Line Port = " + linePort);
		return linePort;
	}
/*
	@SuppressWarnings("null")
	public static void setParam(TableOrderDetailsParam tableOrderDetailsParam,
			String key, String value) {
		
		 * log_msg(logging_level, "<order-number:" + getParam("ORDER_NUMBER") +
		 * "> <wo_id:" + getParam("WO_ID") + "> Storing <" + key + "> = <" +
		 * value + ">");
		 

		try {
			TableOrderDetailsParam tmp = ActionFunctionHelper.getByName(key,
					tableOrderDetailsParam);

			if (tmp != null) {
				tmp.setParamValue(value);
			} else
				tmp.add(key, value);
		} catch (Exception e) {
			// e.printStackTrace();
			log.error("Error: is in setParam ", e);
		}
	}
*/


	/*
	 * @SuppressWarnings("null") public static void
	 * setParam(TableOrderDetailsParam tableOrderDetailsParam, String key,
	 * String value) {
	 * 
	 * log_msg(logging_level, "<order-number:" + getParam("ORDER_NUMBER") +
	 * "> <wo_id:" + getParam("WO_ID") + "> Storing <" + key + "> = <" + value +
	 * ">");
	 * 
	 * 
	 * try { TableOrderDetailsParam tmp = ActionFunctionHelper.getByName(key,
	 * tableOrderDetailsParam);
	 * 
	 * if (tmp != null) { tmp.setParamValue(value); } else tmp.add(key, value);
	 * } catch (Exception e) { // e.printStackTrace(); log.error(
	 * "Error: is in setParam ", e); } }
	 */
	@SuppressWarnings("unchecked")
	public static boolean isTnAssigned(String Tn, Connection connection) throws SQLException {
		boolean isAssigned = false;
		TblPublicTnPoolDbBean publicTnPoolDbBean = new TblPublicTnPoolDbBean();
		ArrayList<TblPublicTnPoolDbBean> resultList = null;
		try {
			TblPublicTnPoolQuery publicTnPoolQuery = new TblPublicTnPoolQuery();
			publicTnPoolQuery.whereTnEQ(Tn);
			publicTnPoolQuery.query(connection);

			resultList = publicTnPoolQuery.getResultArrayList();
			if (resultList.size() > 0) {
				publicTnPoolDbBean = (TblPublicTnPoolDbBean) resultList.get(0);
				if (publicTnPoolDbBean.getTnStatus() == VzbVoipEnum.TnStatus.ASSIGNED)
					isAssigned = true;
				log.info(
						"TN <" + Tn + "> Already exists for Location <" + publicTnPoolDbBean.getLocationId()
								+ "> with TnStatus:" + publicTnPoolDbBean.getTnStatus(),
						OrderLogEnum.EventType.INFORMATION);
				// insertOrderLog(LOG_TYPE_FAIL, "TN <" + Tn +
				// "> Already exists for Location <" +
				// publicTnPoolDbBean.getLocationId() +
				// ">"+publicTnPoolDbBean.getTnStatus());

				/*
				 * databaseLogging.setOrderLog("TN <" + Tn +
				 * "> Already exists for Location <" +
				 * publicTnPoolDbBean.getLocationId() + ">" +
				 * publicTnPoolDbBean.getTnStatus(),
				 * OrderLogEnum.EventType.INFORMATION);
				 */
			}
		} catch (SQLException e) {
			log.info("ERROR: SQLException caught while trying to query tbl_public_tn_pool",e);
		} catch (Exception e) {

			log.error(
					"ERROR: Exception caught while trying to query tbl_public_tn_pool",
					e);

		}
		return isAssigned;
	}
	/**
	 * This method checks the Tn assigned state 
	 * 
	 * @param Tn
	 * @param assignedTnMap
	 * @return
	 * @throws SQLException
	 */
	public static boolean isTnAssigned(String Tn, Map<String,Integer> assignedTnMap)
			throws SQLException {
		boolean isAssigned = false;
		Integer value = null;
		try {
			if ((value=assignedTnMap.get(Tn))!= null && value == VzbVoipEnum.TnStatus.ASSIGNED){
					isAssigned = true;
			}
		}  catch (Exception e) {
			log.error(
					"ERROR: Exception caught while checking assigned state of :{} tn",Tn,
					e);
		}
		//return isAssigned;
		return false;
	}

	@SuppressWarnings("rawtypes")
	public static int getVmBoxSizeId(String vmType, Connection connection) throws SQLException {
		int vmBoxSizeId = 0;
		try {
			TblVmBoxSizeQuery tblVmBoxSizeQry = new TblVmBoxSizeQuery();
			tblVmBoxSizeQry.whereMessagesEQ(Integer.parseInt(vmType));
			tblVmBoxSizeQry.query(connection);
			ArrayList resultList = tblVmBoxSizeQry.getResultArrayList();
			if (resultList.size() > 0) {
				TblVmBoxSizeDbBean vmBoxSizeDbBean = (TblVmBoxSizeDbBean) resultList.get(0);
				vmBoxSizeId = vmBoxSizeDbBean.getVmBoxSizeId();
			}

		} catch (SQLException e) {
			log.info("ERROR: get VM_BOX_SIZE_ID from TBL_VM_BOX_SIZE", e);
			// e.printStackTrace();
		}
		return vmBoxSizeId;
	}

	/*public static List<SubscriberDeviceBean> getGroupTNSubDeviceList(String action, Connection connection,
			EntityData entityData) throws Exception { //commented KR
		List<SubscriberDeviceBean> subDevBeanList = new ArrayList<SubscriberDeviceBean>();

		try {

			TableOrderDetailsParam groupTNFMCGDetails = ActionFunctionHelper.getTableOrderDetaisParam(entityData,
					"GroupTNFMCG");
			// TableOrderDetailsParam tableOrderDetailsParam =
			// ActionFunctionHelper.searchParam(entityData,"GroupTNFMCG") ;
			// ParamDetail pd = orderParam.getByNameSearch("GroupTNFMCG");
			TableOrderDetailsParam tableOrderDetailsParam = ActionFunctionHelper
					.getTableOrderDetailsParamByName(groupTNFMCGDetails, "Device");
			// if (orderParam.getByNameSearch("Device") != null) {
			if (tableOrderDetailsParam != null) {
				// List<ParamDetail> pdList = pd.getByNameSearchList("Device");

				for (TableOrderDetailsParam tmp : tableOrderDetailsParam
						.getParamDetail()) {
					if (!tmp.getAction().equals(action)){

						continue;
					}

					SubscriberDevice subscriberDeviceObj = new SubscriberDevice(connection);
					String deviceType = "";

					String subId = "";

					TableOrderDetailsParam subIdDetails = ActionFunctionHelper.getTableOrderDetaisParam(entityData,
							"SubscriberId");

					if (ActionFunctionHelper.getTableOrderDetailsParamByName(tmp, "DeviceType") != null)
						deviceType = ActionFunctionHelper.getTableOrderDetailsParamByName(tmp, "DeviceType")
								.getParamValue();

					/*
					 * if (!(orderParam.getByNameSearch("SubscriberId") ==
					 * null)) subscriberDeviceObj.setSubId(orderParam
					 * .getByNameSearch("SubscriberId") .getParamValue());
					 */

				/*	if ((subIdDetails != null) && (subIdDetails.getParamValue() != null)) {
						subscriberDeviceObj.setSubId(subIdDetails.getParamValue());
					}

					TableOrderDetailsParam deviceSeqIdDetails = ActionFunctionHelper
							.getTableOrderDetailsParamByName(tmp, "DeviceSeqId");

					if (ActionFunctionHelper.getTableOrderDetailsParamByName(tmp, "DeviceMapId") != null
							&& deviceSeqIdDetails.getParamValue().equals("")) {
						subscriberDeviceObj.setDeviceMapId(Long.valueOf(ActionFunctionHelper
								.getTableOrderDetailsParamByName(tmp, "DeviceMapId").getParamValue()));
					}

					if (deviceSeqIdDetails != null && !(deviceSeqIdDetails.getParamValue().equals(""))
							&& deviceType.equals("SIP_DEVICE"))
						subscriberDeviceObj.setSipDeviceId(Long.valueOf(deviceSeqIdDetails.getParamValue()));

					else if (!(deviceSeqIdDetails == null) && !(deviceSeqIdDetails.getParamValue().equals("")))
						subscriberDeviceObj.setGatewayDeviceId(Long.valueOf(deviceSeqIdDetails.getParamValue()));

					/*
					 * if (!(tmp.getByNameSearch("DeviceMapId") == null) &&
					 * !(tmp.getByNameSearch("DeviceSeqId")
					 * .getParamValue().equals("")))
					 * subscriberDeviceObj.setDeviceMapId(Long
					 * .valueOf(tmp.getByNameSearch("DeviceMapId")
					 * .getParamValue()));
					 */

					/*
					 * if (deviceSeqIdDetails!= null) {
					 * subscriberDeviceObj.setGatewayDeviceId(Long
					 * .valueOf(deviceSeqIdDetails.getParamValue())); } else if
					 * ( (deviceSeqIdDetails!=null) &&
					 * deviceType.equals("SIP_DEVICE")) {
					 * subscriberDeviceObj.setSipDeviceId(Long.valueOf(
					 * deviceSeqIdDetails.getParamValue())); }
					 */

				/*	TableOrderDetailsParam originatingSystem = ActionFunctionHelper.getTableOrderDetaisParam(entityData,
							"OriginatingSystem");

					if (originatingSystem != null) {
						subscriberDeviceObj.setCreatedBy(originatingSystem.getParamValue());
						subscriberDeviceObj.setModifiedBy(originatingSystem.getParamValue());
					} else {
						subscriberDeviceObj.setModifiedBy("SYSTEM");
						subscriberDeviceObj.setCreatedBy("SYSTEM");
					}

					if (ActionFunctionHelper.getByNameSearchWithAction("LinePort", "n", tmp) != null
							&& ActionFunctionHelper.getByNameSearchWithAction("LinePort", "n", tmp)
									.getParamValue() != null) {
						subscriberDeviceObj.setLinePort(
								ActionFunctionHelper.getByNameSearchWithAction("LinePort", "n", tmp).getParamValue());
						subscriberDeviceObj.setModifiedBy(originatingSystem.getParamValue());
					} else if (action.equals("n")) {
						// insertOrderLog(LOG_TYPE_FAIL,
						// "LinePort not found on the order ");
						log.info("LinePort not found on the  order ");
						throw new Exception("ESP_VZB_INV_SUB_LINPORT_NOT_FOUND");
					}

					// subscriberDeviceObj.setLineKey(1);
					if (ActionFunctionHelper.getByNameSearchWithAction("LineKeys", "n", tmp) != null
							&& ActionFunctionHelper.getByNameSearchWithAction("LineKeys", "n", tmp)
									.getParamValue() != null)
						subscriberDeviceObj.setLineKey(Long.valueOf(
								ActionFunctionHelper.getByNameSearchWithAction("LineKeys", "n", tmp).getParamValue()));

					else if (ActionFunctionHelper.getByNameSearchWithAction("LineKeys", "r", tmp) != null
							&& ActionFunctionHelper.getByNameSearchWithAction("LineKeys", "r", tmp)
									.getParamValue() != null)
						subscriberDeviceObj.setLineKey(Long.valueOf(
								ActionFunctionHelper.getByNameSearchWithAction("LineKeys", "r", tmp).getParamValue()));

					// subscriberDeviceObj.setCallsPerLine(1);

					if ((ActionFunctionHelper.getByNameSearchWithAction("CallsPerLine", "n", tmp) != null)
							&& (ActionFunctionHelper.getByNameSearchWithAction("CallsPerLine", "n", tmp)
									.getParamValue() != null)
							&& !(ActionFunctionHelper.getByNameSearchWithAction("CallsPerLine", "n", tmp)
									.getParamValue().equals("")))
						subscriberDeviceObj.setCallsPerLine(Long.valueOf(ActionFunctionHelper
								.getByNameSearchWithAction("CallsPerLine", "n", tmp).getParamValue()));

					else if ((ActionFunctionHelper.getByNameSearchWithAction("CallsPerLine", "r", tmp) != null)
							&& (ActionFunctionHelper.getByNameSearchWithAction("CallsPerLine", "n", tmp)
									.getParamValue() != null)
							&& !(ActionFunctionHelper.getByNameSearchWithAction("CallsPerLine", "r", tmp)
									.getParamValue().equals("")))
						subscriberDeviceObj.setCallsPerLine(Long.valueOf(ActionFunctionHelper
								.getByNameSearchWithAction("CallsPerLine", "r", tmp).getParamValue()));

					TableOrderDetailsParam scaDetails = ActionFunctionHelper.getTableOrderDetailsParamByName(tmp,
							"SCA");
					TableOrderDetailsParam labelDetails = ActionFunctionHelper.getTableOrderDetailsParamByName(tmp,
							"Label");
					TableOrderDetailsParam authUserIDDetails = ActionFunctionHelper.getTableOrderDetailsParamByName(tmp,
							"AuthUserID");

					log.info("SCA Value is ===== ", scaDetails.getParamValue());
					log.info("Level Value is ===== ", labelDetails.getParamValue());
					log.info("AuthUserID Value is ===== ", authUserIDDetails.getParamValue());

					if (scaDetails != null)

						subscriberDeviceObj.setScaType(scaDetails.getParamValue());

					if (labelDetails != null)
						subscriberDeviceObj.setScaLineLabel(labelDetails.getParamValue());

					// if (!( tmp.getByNameSearch("Address ") == null ))
					// subscriberDeviceObj.setScaType(tmp.getByNameSearch("Address
					// ").getParamValue());

					if (authUserIDDetails != null)
						subscriberDeviceObj.setScaAuthUserid(authUserIDDetails.getParamValue());

					if (!(ActionFunctionHelper.getTableOrderDetailsParamByName(tmp, "BLFAttendantReqNum") == null)
							&& ActionFunctionHelper.getTableOrderDetailsParamByName(tmp, "BLFAttendantReqNum")
									.getParamValue().equals(""))
						subscriberDeviceObj.setBlfAttdntRegline(Integer.parseInt(ActionFunctionHelper
								.getTableOrderDetailsParamByName(tmp, "BLFAttendantReqNum").getParamValue()));

					if (!(ActionFunctionHelper.getTableOrderDetailsParamByName(tmp, "BlfURL") == null))
						subscriberDeviceObj
								.setBlfUrl(ActionFunctionHelper.getTableOrderDetailsParamValue(entityData, "BlfURL"));

					subDevBeanList.add(subscriberDeviceObj);
				} // for
			} // if
		} catch (Exception e) {
			// e.printStackTrace();
			log.error("Exception : inside getGroupTNSubDeviceList ", e);
		}

		return subDevBeanList;
	}*/

	/**
	 * 
	 * @param action
	 * @param entityData
	 * @return
	 */
	public static List<FeaturesBean> getBillableFeaturesForFmcg(String action, EntityData entityData,
			Connection connection) throws Exception {

		log.info("getBillableFeaturesForFmcg for  action code <" + action + ">");
		List<FeaturesBean> locationFeatures = new ArrayList<FeaturesBean>();
		try {

			// getByNameSearch
			TableOrderDetailsParam pd = ActionFunctionHelper.getTableOrderDetaisParam(entityData, "NonPkgFeatures");
			/*
			 * if (orderParam.getByName("NonPkgFeatures") != null) { ParamDetail
			 * pd = orderParam.getByName("NonPkgFeatures");
			 */

			/*
			 * log.info("Found Billabale Features <" + pd.getParamCount() +
			 * ">");
			 */

			List<TableOrderDetailsParam> pdList = pd.getParamDetail();// ActionFunctionHelper.getChildByNameSearch(pd,
																		// "NonPkgFeature");//pd.getByNameSearchList("NonPkgFeature");

			log.info("Found Billabale Features <" + pdList.size() + ">");

			for (TableOrderDetailsParam tmp : pdList) {
				if (!tmp.getAction().equals(action))
					continue;

				String featureName = tmp.getParamValue();
				// retrieve the corresponding FeatureId
				// SELECT FEATURE_ID FROM TBL_VZB_FEATURES WHERE NAME='Auto
				// Attendant'
				log.info("Querying Feature {}" , featureName);
				FeaturesBean fb = null;

				TblVzbFeaturesQuery vzbFeats = new TblVzbFeaturesQuery();
				vzbFeats.whereDescriptionLike(featureName);
				vzbFeats.query(connection);
				ArrayList<?> resultSet = vzbFeats.getResultArrayList();
				log.info("vzbfeatures for featurename:<" + featureName + "> size <" + vzbFeats.size());

				if (vzbFeats.size() > 0) {
					TblVzbFeaturesDbBean vzbFeatDbBean = (TblVzbFeaturesDbBean) resultSet.get(0);
					int featureId = vzbFeatDbBean.getFeatureId();
					log.info("FeatureID <" + featureId + "> in tbl_vzb_features");

					fb = new FeaturesBean();
					fb.getFeaturesDbBean().setName(featureName);
					fb.getFeaturesDbBean().setFeatureId(featureId);
					locationFeatures.add(fb);
				} else {
					log.info("Unkown Feature {}" , featureName);
					continue;
				}
			}
			log.info("found Billable Features: {} " , locationFeatures.size());

		} catch (Exception e) {
			// e.printStackTrace();
			log.error("Exception : inside getBillableFeaturesForFmcg ", e);
		}

		return locationFeatures;

	}

	/*********************************************************************/
	public static List<FeaturesBean> getxcludedFeaturesList(EntityData entityData, String action,
			boolean groupTnExclFeat, Connection connection) throws Exception {
		List<FeaturesBean> excludedFeaturesList = new ArrayList<FeaturesBean>();

		try {
			// TableOrderDetailsParam pd =
			// ActionFunctionHelper.searchParam(entityBatch,
			// "DisableFeatureList");


			TableOrderDetailsParam tableOrderDetailsParam = ActionFunctionHelper.getTableOrderDetaisParam(entityData,
					"DisableFeatureList");
			if (tableOrderDetailsParam == null || tableOrderDetailsParam.getParamDetail()== null){
				return excludedFeaturesList;
			}
			List<TableOrderDetailsParam> exclFeatParamList = tableOrderDetailsParam.getParamDetail();
			for (TableOrderDetailsParam disParamDtl : exclFeatParamList) {
				if (groupTnExclFeat && !ActionFunctionHelper.isEmpty(disParamDtl.getParentId()))
					continue;
				List<TableOrderDetailsParam> pdList = ActionFunctionHelper.getChildByNameSearch(disParamDtl, "Feature");

				for (TableOrderDetailsParam tmp : pdList) {
					if (!tmp.getAction().equals(action))
						continue;

					String featureName = tmp.getParamValue();
					// retrieve the corresponding FeatureId
					// SELECT FEATURE_ID FROM TBL_VZB_FEATURES WHERE NAME='Auto
					// Attendant'
					log.info("VZB_INV_ADD_FEATURE_PKG: Querying Feature " + featureName);
					FeaturesBean fb = null;

					TblVzbFeaturesQuery vzbFeats = new TblVzbFeaturesQuery();
					vzbFeats.whereNameLike(featureName);
					vzbFeats.query(connection);
					ArrayList<?> resultSet = vzbFeats.getResultArrayList();
					log.info("VZB_INV_ADD_FEATURE_PKG: vzbfeatures for featurename:<" + featureName + "> size <"
							+ vzbFeats.size());

					if (vzbFeats.size() > 0) {
						TblVzbFeaturesDbBean vzbFeatDbBean = (TblVzbFeaturesDbBean) resultSet.get(0);
						int featureId = vzbFeatDbBean.getFeatureId();
						log.info("VZB_INV_ADD_FEATURE_PKG: FeatureID" + featureId + " in tbl_vzb_features");

						fb = new FeaturesBean();
						fb.getFeaturesDbBean().setName(featureName);
						fb.getFeaturesDbBean().setFeatureId(featureId);
						excludedFeaturesList.add(fb);
					} else {
						log.info("VZB_INV_ADD_FEATURE_PKG: Unkown Feature " + featureName);
						continue;
					}
				}
				log.info("found xcluded Features: " + excludedFeaturesList.size());
			}
		} catch (Exception e) {
			log.error("Exeption: Inside getxcludedFeaturesList ", e);
		}
		return excludedFeaturesList;

	}

	public static boolean isNOTValidExtn(String locationId, String extension, Connection connection) throws Exception {
		PreparedStatement pStmt = null;
		ResultSet rs = null;

		String extensionSql = " select 1  from tbl_subscriber where location_id = ? and extension = ?  " + " UNION "
				+ " select 1  from tbl_subscriber_tn a,tbl_subscriber b where "
				+ " b.location_id= ? and  a.sub_id = b.sub_id and a.nat_user_id='5' and a.extension =? " + " UNION "
				+ " select 1  from tbl_group c, tbl_group_tn d  where c.location_id = ? and c.group_id = d.group_id and d.extension = ? "
				+ " UNION  " + " select 1  from tbl_subscriber_tn a,tbl_subscriber b where "
				+ " b.location_id=? and  a.sub_id = b.sub_id and a.nat_user_id='6' and a.user_id =? ";
		log.info("Extension validation sql" + extensionSql);

		try {
			pStmt = connection.prepareStatement(extensionSql);
			if (null != pStmt) {
				pStmt.setString(1, locationId);
				pStmt.setString(2, extension);
				pStmt.setString(3, locationId);
				pStmt.setString(4, extension);
				pStmt.setString(5, locationId);
				pStmt.setString(6, extension);
				pStmt.setString(7, locationId);
				pStmt.setString(8, extension);
				rs = pStmt.executeQuery();
				if (rs.next()) {
					return true;
				}
			}
			return false;
		} catch (Exception e) {
			log.error("Exception : ", e.getMessage());
			throw e;
		} finally {
			try {
				if (null != pStmt)
					pStmt.close();
				if (null != rs)
					rs.close();
			} catch (Exception e) {
				log.error("Exception : ", e.getMessage());
			}
		}

	}

	public static boolean isIeanExistsForEnterprise(String iean, String enterpriseId, Connection connection)
			throws SQLException {
		log.info("In isIeanExistsForEnterprise()");
		boolean isExists = false;
		try {
			TblSubscriberTnQuery subTnQry = new TblSubscriberTnQuery();
			String whereCls = "where sub_id in (select sub_id from tbl_subscriber where location_id in (select location_id from tbl_location where enterprise_id = \'"
					+ enterpriseId + "\')) and nat_user_id = 0 and user_id = \'" + iean + "\'";
			log.info("whereCls:" + whereCls);
			subTnQry.queryByWhere(connection, whereCls);
			if (subTnQry.size() > 0) {
				isExists = true;
			}

			if (!isExists) {
				TblGroupTnQuery grpTnQry = new TblGroupTnQuery();
				whereCls = "where group_id in (select group_id from tbl_group where location_id in (select location_id from tbl_location where enterprise_id = \'"
						+ enterpriseId + "\')) and private_number = \'" + iean + "\'";
				log.info("whereCls:" + whereCls);
				grpTnQry.queryByWhere(connection, whereCls);
				if (grpTnQry.size() > 0) {
					isExists = true;
				}
			}
			if (!isExists) {
				TblGroupQuery grpQry = new TblGroupQuery();
				whereCls = "where location_id in (select location_id from tbl_location where enterprise_id = \'"
						+ enterpriseId + "\') and private_number = \'" + iean + "\'";
				log.info("whereCls:" + whereCls);
				grpQry.queryByWhere(connection, whereCls);
				if (grpQry.size() > 0) {
					isExists = true;
				}
			}
			if (!isExists) {
				TblVmAccessQuery vmAccessQry = new TblVmAccessQuery();
				whereCls = "where location_id in (select location_id from tbl_location where enterprise_id = \'"
						+ enterpriseId + "\') and private_number = \'" + iean + "\'";
				log.info("whereCls:" + whereCls);
				vmAccessQry.queryByWhere(connection, whereCls);
				if (vmAccessQry.size() > 0) {
					isExists = true;
				}
			}
		} catch (SQLException e) {
			log.error("Exception : ", e.getMessage());
			log.error("ERROR: Exception caught while trying check enterprise_id from tbl_enterprise", e);
		}
		return isExists;
	}

	/*
	 * public static boolean isIeanExistsForEnterprise(String iean, String
	 * enterpriseId, Connection connection) throws SQLException { log.info(
	 * "In isIeanExistsForEnterprise()"); boolean isExists = false; try {
	 * TblSubscriberTnQuery subTnQry = new TblSubscriberTnQuery(); String
	 * whereCls =
	 * "where sub_id in (select sub_id from tbl_subscriber where location_id in (select location_id from tbl_location where enterprise_id = \'"
	 * + enterpriseId + "\')) and nat_user_id = 0 and user_id = \'" + iean +
	 * "\'"; log.info("whereCls:" + whereCls); subTnQry.queryByWhere(connection,
	 * whereCls); if (subTnQry.size() > 0) { isExists = true; }
	 * 
	 * if (!isExists) { TblGroupTnQuery grpTnQry = new TblGroupTnQuery();
	 * whereCls =
	 * "where group_id in (select group_id from tbl_group where location_id in (select location_id from tbl_location where enterprise_id = \'"
	 * + enterpriseId + "\')) and private_number = \'" + iean + "\'";
	 * log.info("whereCls:" + whereCls); grpTnQry.queryByWhere(connection,
	 * whereCls); if (grpTnQry.size() > 0) { isExists = true; } } if (!isExists)
	 * { TblGroupQuery grpQry = new TblGroupQuery(); whereCls =
	 * "where location_id in (select location_id from tbl_location where enterprise_id = \'"
	 * + enterpriseId + "\') and private_number = \'" + iean + "\'";
	 * log.info("whereCls:" + whereCls); grpQry.queryByWhere(connection,
	 * whereCls); if (grpQry.size() > 0) { isExists = true; } } if (!isExists) {
	 * TblVmAccessQuery vmAccessQry = new TblVmAccessQuery(); whereCls =
	 * "where location_id in (select location_id from tbl_location where enterprise_id = \'"
	 * + enterpriseId + "\') and private_number = \'" + iean + "\'";
	 * log.info("whereCls:" + whereCls); vmAccessQry.queryByWhere(connection,
	 * whereCls); if (vmAccessQry.size() > 0) { isExists = true; } } } catch
	 * (SQLException e) { e.printStackTrace(); log.error(
	 * "ERROR: Exception caught while trying check enterprise_id from tbl_enterprise"
	 * , e); } return isExists; }
	 */

	/**
	 * gets the location id for the given private number if already exists
	 * 
	 * @param iean
	 *            - private number
	 * @param enterpriseId
	 *            - customer id
	 * @return
	 * @throws SQLException
	 */

	public static String getLocationIdForIean(String iean, String enterpriseId, Connection connection)
			throws SQLException {
		log.info("In getLocationIdForIean()");
		boolean isExists = false;
		String locationId = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			TblSubscriberTnQuery subTnQry = new TblSubscriberTnQuery();
			String whereCls = "where sub_id in (select sub_id from tbl_subscriber where location_id in (select location_id from tbl_location where enterprise_id = \'"
					+ enterpriseId + "\')) and nat_user_id = 0 and user_id = \'" + iean + "\'";
			log.info("whereCls:" + whereCls);
			subTnQry.queryByWhere(connection, whereCls);
			if (subTnQry.size() > 0) {
				isExists = true;
				/*
				 * TblSubscriberQuery subscriberQry = new TblSubscriberQuery();
				 * whereCls =
				 * "where sub_id in (select sub_id from tbl_subscriber_tn where nat_user_id = 0 and user_id =\'"
				 * + iean +"\')"; log.info("whereCls:" + whereCls);
				 * subscriberQry.queryByWhere(connection, whereCls);
				 * if(subscriberQry.size() > 0) { TblSubscriberDbBean
				 * subscriberBeanObj =
				 * (TblSubscriberDbBean)subscriberQry.getResultArrayList
				 * ().get(0); locationId = subscriberBeanObj.getLocationId(); }
				 */
				StringBuffer sql = new StringBuffer();
				sql.append("SELECT loc.location_id ");
				sql.append("FROM tbl_location loc, tbl_subscriber sub, tbl_subscriber_tn subt ");
				sql.append("WHERE loc.enterprise_id  = '").append(enterpriseId).append("'");
				sql.append("AND sub.location_id = loc.location_id ");
				sql.append("AND subt.sub_id = sub.sub_id ");
				sql.append("AND subt.nat_user_id = 0 AND subt.user_id = '").append(iean).append("'");
				try {
					pstmt = connection.prepareStatement(sql.toString());
					rs = pstmt.executeQuery();
					if (rs.next()) {
						locationId = rs.getString("LOCATION_ID");
					}
				} catch (Exception e) {
					log.error("Exception : ", e.getMessage());
				} finally {
					if (null != pstmt)
						pstmt.close();
					if (null != rs)
						rs.close();
				}
			}

			if (!isExists || locationId == null) {
				TblGroupTnQuery grpTnQry = new TblGroupTnQuery();
				whereCls = "where group_id in (select group_id from tbl_group where location_id in (select location_id from tbl_location where enterprise_id = \'"
						+ enterpriseId + "\')) and private_number = \'" + iean + "\'";
				log.info("whereCls:" + whereCls);
				grpTnQry.queryByWhere(connection, whereCls);
				if (grpTnQry.size() > 0) {
					isExists = true;
					/*
					 * TblGroupQuery grpQryForLocation = new TblGroupQuery();
					 * whereCls =
					 * "where group_id in (select group_id from tbl_group_tn where private_number = \'"
					 * + iean + "\')"; log.info("whereCls:" + whereCls);
					 * grpQryForLocation.queryByWhere(connection, whereCls);
					 * if(grpQryForLocation.size() > 0) { TblGroupDbBean
					 * groupBeanObj1 =
					 * (TblGroupDbBean)grpQryForLocation.getResultArrayList
					 * ().get(0); locationId = groupBeanObj1.getLocationId(); }
					 */
					StringBuffer sql = new StringBuffer();
					sql.append("SELECT tl.location_id ");
					sql.append("FROM tbl_location tl, tbl_group tg, tbl_group_tn tgt ");
					sql.append("WHERE tl.enterprise_id  = '").append(enterpriseId).append("'");
					sql.append("AND tg.location_id = tl.location_id ");
					sql.append("AND tgt.group_id = tg.group_id ");
					sql.append("AND tgt.private_number = '").append(iean).append("'");
					try {
						pstmt = connection.prepareStatement(sql.toString());
						rs = pstmt.executeQuery();
						if (rs.next()) {
							locationId = rs.getString("LOCATION_ID");
						}
					} catch (Exception e) {
						log.error("Exception : ", e.getMessage());
					} finally {
						if (null != pstmt)
							pstmt.close();
						if (null != rs)
							rs.close();
					}
				}

			}

			if (!isExists || locationId == null) {
				TblGroupQuery grpQry = new TblGroupQuery();
				whereCls = "where location_id in (select location_id from tbl_location where enterprise_id = \'"
						+ enterpriseId + "\') and private_number = \'" + iean + "\'";
				log.info("whereCls:" + whereCls);
				grpQry.queryByWhere(connection, whereCls);
				if (grpQry.size() > 0) {
					isExists = true;
					TblGroupDbBean groupBeanObj2 = (TblGroupDbBean) grpQry.getResultArrayList().get(0);
					locationId = groupBeanObj2.getLocationId();
				}
			}
			if (!isExists || locationId == null) {
				TblVmAccessQuery vmAccessQry = new TblVmAccessQuery();
				whereCls = "where location_id in (select location_id from tbl_location where enterprise_id = \'"
						+ enterpriseId + "\') and private_number = \'" + iean + "\'";
				log.info("whereCls:" + whereCls);
				vmAccessQry.queryByWhere(connection, whereCls);
				if (vmAccessQry.size() > 0) {
					isExists = true;
					TblVmAccessDbBean vmAccessDbBeanObj = (TblVmAccessDbBean) vmAccessQry.getResultArrayList().get(0);
					locationId = vmAccessDbBeanObj.getLocationId();
				}
			}
		} catch (SQLException e) {
			log.error("Exception : ", e.getMessage());
			log.error("ERROR: Exception caught while trying check enterprise_id from tbl_enterprise");
		}
		return locationId;
	}

	// **********************
	public static boolean updateTblPubTNPool(String TN, long tnType, long tnStatus, Connection connection)
			throws Exception {
		boolean lbUpdate = false;
		int liUpdRtn = -1;
		String updTNQry = "UPDATE TBL_PUBLIC_TN_POOL SET TN_STATUS = " + tnStatus + ", TN_TYPE = " + tnType
				+ "  WHERE TN = '" + TN + "'";
		Statement stmt = null;
		try {
			stmt = connection.createStatement();
			liUpdRtn = stmt.executeUpdate(updTNQry);
			if (liUpdRtn != -1) {
				lbUpdate = true;
			}
		} catch (SQLException e) {
			log.error("Exception : ", e.getMessage());
			return false;
		} finally {
			if (stmt != null) {
				stmt.close();
			}
		}
		return lbUpdate;
	}

	public static boolean isLinePortUsedByGroupTn(String linePort, Connection connection) throws Exception {
		boolean isExists = false;
		TblGroupTnDbBean groupTnDbBean = new TblGroupTnDbBean();
		ArrayList<TblGroupTnDbBean> resultList = null;
		try {
			TblGroupTnQuery groupTnQuery = new TblGroupTnQuery();
			groupTnQuery.whereLinePortEQ(linePort);
			groupTnQuery.query(connection);

			resultList = groupTnQuery.getResultArrayList();
			if (resultList.size() > 0) {
				isExists = true;
				groupTnDbBean = (TblGroupTnDbBean) resultList.get(0);
				log.info("LinePort <" + linePort + "> Already in Use by GROUP <" + groupTnDbBean.getGroupId() + ">");
				throw new Exception("ESP_VZB_INV_LINEPORT_ALRDY_IN_USE_BY_DIFF_GRPTN");
			}
		} catch (SQLException e) {
			log.error("Exception : ", e.getMessage());
			log.info("ERROR: Exception caught while trying to query tbl_group_tn");
		}
		return isExists;
	}

	public static int getKeyTnSequence(EntityData entityData, int groupId, Connection connection) throws Exception {
		int sequenceNo = 1;

		String suppType = new String("");
		String minorOrderType = new String("");

		TableOrderDetailsParam suppTypeDetails = getTableOrderDetaisParam(entityData, "SUPP");
		TableOrderDetailsParam minorOrderTypeDetails = getTableOrderDetaisParam(entityData, "MinorOrderType");
		TableOrderDetailsParam sequenceTypeDetails = getTableOrderDetaisParam(entityData, "SequenceNo");

		if (!(minorOrderTypeDetails == null))
			minorOrderType = minorOrderTypeDetails.getParamValue();

		if (!(suppTypeDetails == null))
			suppType = suppTypeDetails.getParamValue();

		if (!suppType.equals("Y")) {
			if (minorOrderType.equals("INSTALL")) {
				if (!(sequenceTypeDetails == null))
					sequenceNo = Integer.parseInt(sequenceTypeDetails.getParamValue());
				else
					sequenceNo = getNextKeyTnSequence(groupId, connection);
			} else {
				sequenceNo = getNextKeyTnSequence(groupId, connection);
				// adjustLastKeyTnSequence(sequenceNo, groupId);
			}
		} else {

			sequenceNo = getNextKeyTnSequence(groupId, connection);
			// adjustLastKeyTnSequence(sequenceNo, groupId);

		}

		log.info("setting KEY TN Sequence to - <" + sequenceNo + ">");

		return sequenceNo;
	}

	/*********************************************************************/
	public static int getNextKeyTnSequence(long groupId, Connection connection) throws Exception {
		int sequenceNo = 1;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		StringBuffer sql = new StringBuffer();

		sql.append(" select max(sequence_no) from tbl_group_tn where group_id = ? ");
		try {
			pstmt = connection.prepareStatement(sql.toString());
			pstmt.setLong(1, groupId);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				sequenceNo = rs.getInt(1);
			}

		} catch (Exception e) {
			log.error("Exception : ", e.getMessage());
			sequenceNo = 1;
		} finally {
			if (null != rs)
				rs.close();
			if (null != pstmt)
				pstmt.close();
		}

		log.info("getNextKeyTnSequence - <" + sequenceNo + ">");
		return sequenceNo;
	}

	/*public static void processClid(EntityBatch entityBatch, Location loc) {
		log.info( "In processClid().");

		// CallingPartyPrivacy not present at all n/r/c
		if (ActionFunctionHelper.getTableOrderDetailsParam(entityBatch,"CallingPartyPrivacy") != null) {
			log.info("CallingPartyPrivacy (n/r/c) not present. " +
			"Setting default to subscriber TN. Will override default values if present in tod as new value");
			loc.setRpidPriv(0);
			loc.setOverrideCidNum(0);
			loc.setOverrideSubPrivate(1); // this is default behavior
			loc.setOverrideCidName(0);
		}
		// callingPartyPrivacy (n) exist and it is Y
		if (!(ActionFunctionHelper.getParamValueWithAction(entityBatch,"CallingPartyPrivacy", "n") == null) &&
				ActionFunctionHelper.getParamValueWithAction(entityBatch,"CallingPartyPrivacy", "n").equals("Y")) {
			log.info("CallingPartyPrivacy (n) present with value Y.");
			loc.setRpidPriv(1);
			loc.setOverrideCidNum(0);
			loc.setOverrideSubPrivate(0);
			loc.setOverrideCidName(0);
		} // callingPartyPrivacy (n) exist and it is N
		else if (!(ActionFunctionHelper.getParamValueWithAction(entityBatch,"CallingPartyPrivacy", "n") == null) &&
				ActionFunctionHelper.getParamValueWithAction(entityBatch,"CallingPartyPrivacy", "n").equals("N")) {
			log.info("CallingPartyPrivacy (n) present with value N. Setting default to subscriber TN.");
			loc.setRpidPriv(0);
			loc.setOverrideCidNum(0);
			loc.setOverrideSubPrivate(1); // this is default behavior
			loc.setOverrideCidName(0);
		}

		// Now keep reading other TOD param and override the default settting.
		// Assumptions: Override values will never come as null in tod for new values.
		if (!(ActionFunctionHelper.getParamValueWithAction(entityBatch,"OverrideCidNum", "n") == null)) {
			log.info("OverrideCidNum (n) present. Will set Location level CLID NUM.");
			String overrideCidNum = ActionFunctionHelper.getParamValueWithAction(entityBatch,"OverrideCidNum", "n");
			if(overrideCidNum.equalsIgnoreCase("Y"))
				loc.setOverrideSubPrivate(0); // overriding default behavior
			if(overrideCidNum.equalsIgnoreCase("Y") || overrideCidNum.equalsIgnoreCase("N"))
				loc.setOverrideCidNum(VzbVoipEnum.YesNoType.valueByName(overrideCidNum));
		}
		if (!(ActionFunctionHelper.getParamValueWithAction(entityBatch,"OverrideSubPrivate", "n") == null)) {
			log.info("OverrideSubPrivate (n) present. Will set OverrideSubPrivate.");
			String overrideSubPrivate = ActionFunctionHelper.getParamValueWithAction(entityBatch,"OverrideSubPrivate", "n");
			if(overrideSubPrivate.equalsIgnoreCase("Y")) {
				loc.setOverrideCidName(0);
				loc.setOverrideCidNum(0);
			}
			if(overrideSubPrivate.equalsIgnoreCase("Y") || overrideSubPrivate.equalsIgnoreCase("N"))
				loc.setOverrideSubPrivate(VzbVoipEnum.YesNoType.valueByName(overrideSubPrivate));
		}

		// Now take care of the CallingPartyNumber if present as (n)
		// Do not tourch this if no (n) value exist
		String callingPartyNumber  = ActionFunctionHelper.getParamValueWithAction(entityBatch,"CallingPartyNumber", "n");
		if((callingPartyNumber != null) &&
					!(callingPartyNumber.equals("")))
		{
			log.info("CallingPartyNumber (n) present with not null/empty string value, will set RPID.");
			loc.setRpidTn(callingPartyNumber);
			loc.setRpid(callingPartyNumber);
		}
		else
		{
			log.info("CallingPartyNumber (n) present with null or empty string, will set RPID to empty string.");
			loc.setRpidTn("");
			loc.setRpid("");
		}
		


		String msg = "CLID attributes" +
		": RpidPriv=" + ((loc.getRpidPriv() == -1) ? "Unchanged" : Long.toString(loc.getRpidPriv())) +
		", RpidTn=" + ((loc.getRpidTn().equalsIgnoreCase("NONE")) ? "Unchanged" : loc.getRpidTn()) +
		", OverrideSubPrivate=" + loc.getOverrideSubPrivate() +
		", OverrideCidNum=" + loc.getOverrideCidNum() +
		", OverrideCidName=" + loc.getOverrideCidName() + ".";

		//logTrailList.add(msg);
		log.info("Leaving processClid() with {}" , msg);
	}

	*/
	
	
	
	public static List<DigitStringBean> getDigitStringList(EntityBatch entityBatch,String action, int parentId,Connection connection)
	throws Exception {
		List<DigitStringBean> digitStringBeanList = new ArrayList<DigitStringBean>();
		try {
			Map<String, EntityData> entityMap = entityBatch.getEntity();
			EntityData entityData = entityMap.entrySet().iterator().next().getValue();
			
			TableOrderDetailsParam  digitStringDetail  = ActionFunctionHelper.getTableOrderDetaisParam(entityData, "DigitString");
			if (digitStringDetail != null) {
				List<TableOrderDetailsParam> pdList = ActionFunctionHelper.searchParamListNew(entityData, "DigitString");//digitStringDetail.getParamDetail();
				for (TableOrderDetailsParam tmp : pdList) {
					if (!tmp.getAction().equals(action))
						continue;
					if (parentId == 0 && Long.parseLong(tmp.getParentId().trim())!= 0)//parseInt(tmp.getParentId()) != 0)
						continue;

					log.debug("getDigitStringList, Action"
							, tmp.getAction());

					DigitStringBean digitStringBean = new DigitStringBean();
					CallingPlan callingPlanObj = new CallingPlan(connection);

					
					if (!(ActionFunctionHelper.getTableOrderDetailsParamByName(tmp, "Id") == null))
						digitStringBean.setDigitStringId(Integer.valueOf(ActionFunctionHelper.getTableOrderDetailsParamByName(tmp, "Id").getParamValue()));
					log.info("Digit String Id:"
							+ digitStringBean.getDigitStringId());
					if (!(ActionFunctionHelper.getTableOrderDetailsParamByName(tmp, "Value") == null)) {
						digitStringBean.setDigitString(ActionFunctionHelper.getTableOrderDetailsParamByName(tmp, "Value").getParamValue());
						log.info("Digit String value:"
								+ digitStringBean.getDigitString());
					}
					
					TableOrderDetailsParam incomingDetails = ActionFunctionHelper.getByNameSearchWithAction("Incoming", "n", tmp);
					
					
					if (!(incomingDetails == null)) {
						log.info("tmp.getByNameSearchWithAction Incoming:"
								+ incomingDetails
										.getParamValue());
						log.info("VzbVoipEnum.CallingPlanCallType.valueByAcronym tmp.getByNameSearchWithAction Incoming:"
								+ VzbVoipEnum.CallingPlanCallType
								.valueByAcronym(incomingDetails
												.getParamValue()));
						digitStringBean.setIAllow(callingPlanObj
								.getCallingPlanType(incomingDetails.getParamValue()));
					}
					log.info("Digit String Incoming:"
							+ digitStringBean.getIAllow());

					TableOrderDetailsParam outgoingDetails = ActionFunctionHelper.getByNameSearchWithAction("Outgoing", "n", tmp);
					if (!(outgoingDetails == null))
						digitStringBean.setOAllow(callingPlanObj
								.getCallingPlanType(outgoingDetails.getParamValue()));
					//digitStringBean.setOAllow(VzbVoipEnum.CallingPlanCallType.valueByAcronym(tmp.getByNameSearchWithAction("Outgoing","n").getParamValue()));
					log.info("Digit String Outgoing:"
							+ digitStringBean.getOAllow());
					
					TableOrderDetailsParam fwdTransferDetails = ActionFunctionHelper.getByNameSearchWithAction("FwdTransfer", "n", tmp);
					
					if (!(fwdTransferDetails == null))
						digitStringBean.setFAllow(callingPlanObj
								.getCallingPlanType(fwdTransferDetails
												.getParamValue()));
					//digitStringBean.setFAllow(VzbVoipEnum.CallingPlanCallType.valueByAcronym(tmp.getByNameSearchWithAction("FwdTransfer","n").getParamValue()));
					log.info("Digit String FwdTransfer:"
							+ digitStringBean.getFAllow());
					
					TableOrderDetailsParam beingFwdTransferDetails = ActionFunctionHelper.getByNameSearchWithAction("BeingFwdTransfer", "n", tmp);
					if (!(beingFwdTransferDetails== null))
						digitStringBean.setBAllow(callingPlanObj
								.getCallingPlanType(beingFwdTransferDetails
												.getParamValue()));
					//digitStringBean.setBAllow(VzbVoipEnum.CallingPlanCallType.valueByAcronym(tmp.getByNameSearchWithAction("BeingFwdTransfer","n").getParamValue()));
					log.info("Digit String BeingFwdTransfer:"
							+ digitStringBean.getBAllow());
					
					TableOrderDetailsParam originatingSystem = ActionFunctionHelper.getTableOrderDetailsParam(entityBatch,"OriginatingSystem");
					
					if (!(originatingSystem == null)) {
						digitStringBean.setCreatedBy(originatingSystem
								.getParamValue());
						digitStringBean.setModifiedBy(originatingSystem
								.getParamValue());
					} else {
						digitStringBean.setModifiedBy("SYSTEM");
						digitStringBean.setCreatedBy("SYSTEM");
					}
					digitStringBeanList.add(digitStringBean);
				}
			}
		} catch (Exception e) {
			//e.printStackTrace();
			
			log.error("ERROR: Exception in getDigitStringList()", e);
		}

		return digitStringBeanList;

	}
	

	/*****************Add_PBX_GROUP *********************/
	
	public static boolean isValidPBXGroupName(String strGroupName, String strLocationId,Connection connection) throws  Exception {
		boolean returnCode = true;
		TblGroupQuery group = new TblGroupQuery();
		group.whereLocationIdEQ(strLocationId);
		group.whereGroupNameEQ(strGroupName);
		group.whereGroupTypeEQ(VzbVoipEnum.ServiceType.PBX);
		group.query(connection);

		log.info("Query ran for doesPBXGroupExist --");
		if(group!=null && group.size()>0) {
			log.info("PBX Group Found - About to throw Exception --");
			returnCode =  false;
		}
		else
			log.info("Proceeding with PBX Group insert. PBX Group name not found--");
		return returnCode;
	}
	
	public static List<FeaturesBean> getBillableFeatures(EntityData entityData,String action,Connection connection) {
		log.info( "getBillableFeatures for  action code <" + action + ">");
		List<FeaturesBean> locationFeatures = new ArrayList<FeaturesBean>();

		try {
			TableOrderDetailsParam nonPkgFeaturesDetails = ActionFunctionHelper.getTableOrderDetaisParam(entityData, "NonPkgFeatures");
			
			if (nonPkgFeaturesDetails != null) {
				//ParamDetail pd = orderParam.getByNameSearch("NonPkgFeatures");

				log.info( "Found Billabale Features  of nonPkgFeaturesDetails ");

				List<TableOrderDetailsParam> pdList = nonPkgFeaturesDetails.getParamDetail();

				log.info( "Found Billabale Features <" + pdList.size() + ">");

				for (TableOrderDetailsParam tmp : pdList) {
					if (!tmp.getAction().equals(action))
						continue;

					String featureName = tmp.getParamValue();
					//retrieve the corresponding FeatureId
					//SELECT FEATURE_ID FROM TBL_VZB_FEATURES WHERE NAME='Auto Attendant'
					log.info( "Querying Feature " + featureName);
					FeaturesBean fb = null;

					TblVzbFeaturesQuery vzbFeats = new TblVzbFeaturesQuery();
					vzbFeats.whereDescriptionLike(featureName);
					vzbFeats.query(connection);
					ArrayList<?> resultSet = vzbFeats.getResultArrayList();
					log.info( "vzbfeatures for featurename:<" + featureName
							+ "> size <" + vzbFeats.size());

					if (vzbFeats.size() > 0) {
						TblVzbFeaturesDbBean vzbFeatDbBean = (TblVzbFeaturesDbBean) resultSet
						.get(0);
						int featureId = vzbFeatDbBean.getFeatureId();
						log.info( "FeatureID <" + featureId
								+ "> in tbl_vzb_features");

						fb = new FeaturesBean();
						fb.getFeaturesDbBean().setName(featureName);
						fb.getFeaturesDbBean().setFeatureId(featureId);
						locationFeatures.add(fb);
					} else {
						log.info( "Unkown Feature " + featureName);
						continue;
					}
				}
				log.info( "found Billable Features: "
						+ locationFeatures.size());
			}
		} catch (Exception e) {
			//e.printStackTrace();
			log.error("ERROR: Exception in getBillableFeatures()", e);
		}

		return locationFeatures;

	}
	
	
	public static void updateEntAndLocCcl(ConfigDomainDataServiceImpl configDomainDataServiceImpl, String enterpriseId, String locationId, Connection connection) throws Exception 
	{
		log.info("Entering updateEntAndLocCcl");
		PreparedStatement psm = null;
		PreparedStatement pst = null;
		try 
		{
			// IR: 1806388 This update can happen concurrently from two different order.
			// So, get the lock first.
			/*String paramVal = OrderUtil.getConfigParamValue(connection, "ENT_CCL_LOCK", "ENT_CCL_LOCK");*/
			String paramVal = configDomainDataServiceImpl.getTblConfigParam("ENT_CCL_LOCK", "ENT_CCL_LOCK");
			boolean lbConfig = false;			
			if (paramVal != null && paramVal.equals("Y")) {
				lbConfig = false;
			} else {
				lbConfig = true;
			}
			if (!lbConfig) {
				dummyUpdateEnterprise(enterpriseId,connection);
				dummyUpdateLocation(locationId,connection);

				long entCcl = 0;
				long locCcl = 0;

				//modified by venkata. to get the correct counts
				String whereCls = null; 
				TblGroupQuery grpQry = new TblGroupQuery();
				whereCls = "where location_id in (select location_id from tbl_location where enterprise_id = \'"
						+ enterpriseId
						+ "\') ";

				log.info("whereCls: {}" , whereCls);
				grpQry.queryByWhere(connection, whereCls);

				if(grpQry.size() > 0)
				{
					for(int i = 0; i <grpQry.size(); i++)
					{
						entCcl += grpQry.getDbBean(i).getPbxMaxCclLimit(); // sum of pbx_max_ccl_limit
					}
					log.info("Retrieved Enterprise Trunk CCL Cum as {}" , entCcl);
				}

				grpQry = new TblGroupQuery();
				whereCls = "where location_id = \'"
						+ locationId
						+ "\'";

				log.info("whereCls: {}" , whereCls);
				grpQry.queryByWhere(connection, whereCls);

				if(grpQry.size() > 0)
				{
					for(int i = 0; i <grpQry.size(); i++)
					{
						locCcl += grpQry.getDbBean(i).getPbxMaxCclLimit(); // sum of pbx_max_ccl_limit
					}
					log.info("Retrieved Location Trunk CCL Cum as {} " , locCcl);

				}

				DBTblLocation locDbObj = new DBTblLocation();
				DBTblEnterprise entDbObj = new DBTblEnterprise();


				entDbObj.setEntTrunkCclSum(entCcl);
				locDbObj.setLocTrunkCclSum(locCcl);

				entDbObj.whereEnterpriseIdEQ(enterpriseId);
				entDbObj.updateSpByWhere(connection);

				locDbObj.whereLocationIdEQ(locationId);
				locDbObj.updateSpByWhere(connection);

			}

			if (lbConfig) {
				System.out.println("In new ccl block ");	
				int val, locVal = -1;

				String updEntStmt = "UPDATE TBL_ENTERPRISE SET  ENT_TRUNK_CCL_SUM = (SELECT SUM(PBX_MAX_CCL_LIMIT) FROM TBL_GROUP WHERE LOCATION_ID IN (select location_id from tbl_location where enterprise_id='" +enterpriseId +"')) where enterprise_id='" + enterpriseId + "'";

				String updLocStmt = "UPDATE TBL_LOCATION SET LOC_TRUNK_CCL_SUM = (SELECT SUM(PBX_MAX_CCL_LIMIT) FROM TBL_GROUP WHERE LOCATION_ID = '" +locationId +"') WHERE LOCATION_ID = '"+locationId +"'";


				psm = connection.prepareStatement(updEntStmt);
				val = psm.executeUpdate();

				pst = connection.prepareStatement(updLocStmt);
				locVal = pst.executeUpdate();
			}

		} catch (SQLException e) {
			log.error("ERROR: while attempting to update Enterprise / Location Trunk CCL Sum",e);
			log.error("ERROR: updateEntAndLocCcl in getBillableFeatures()", e);
		}finally {
			if (psm != null)
				psm.close();
			if (pst != null)
				pst.close();
		}
	}
	
	
	private static void dummyUpdateEnterprise(String entid, Connection connection) throws SQLException {
		log.info("Inside dummyUpdateEnterprise(). Trying to get lock on records.");

		DBTblEnterprise entDb = new DBTblEnterprise();
		entDb.whereEnterpriseIdEQ(entid);
		entDb.setModifiedBy("ESAP_INV");
		int count = entDb.updateSpByWhere(connection);
		log.info("Successfully locked {} location record in ESAP by dummy update." , count);
	}
	
	private static void dummyUpdateLocation(String locid, Connection connection) throws SQLException {
		log.info("Inside dummyUpdateLocation(). Trying to get lock on records.");

		DBTblLocation locDb = new DBTblLocation();
		locDb.whereLocationIdEQ(locid);
		locDb.setModifiedBy("ESAP_INV");
		int count = locDb.updateSpByWhere(connection);
		log.info("Successfully locked {} location record in ESAP by dummy update." ,count);
	}
	
	

	/*********************************************************************/ 
	/*public static Sbc getSbc(EntityBatch entityBatch,Connection connection) throws Exception {//Kr
		Sbc sbcObj = new Sbc(connection);
		TblSbcInfoQuery sbcInfo = new TblSbcInfoQuery();
		
		TableOrderDetailsParam sbcTableDetails = ActionFunctionHelper.getTableOrderDetailsParam(entityBatch,"SBC");
		if (sbcTableDetails != null) {
			//Tableorder pd = orderParam.getByNameSearch("SBC");

			//TableOrderDetailsParam outgoingDetails = ActionFunctionHelper.getByNameSearchWithAction("CustFqdn", "n", sbcTableDetails);
			
			if (ActionFunctionHelper.getByNameSearchWithAction("CustFqdn", "n", sbcTableDetails) != null) {
				sbcObj.setCustFqdn(ActionFunctionHelper.getByNameSearchWithAction("CustFqdn", "n", sbcTableDetails)
						.getParamValue());
				sbcInfo.whereCustFqdnEQ(sbcObj.getCustFqdn());
			}

			if (ActionFunctionHelper.getByNameSearchWithAction("CustIpAddr", "n", sbcTableDetails) != null) {
				sbcObj.setCustIpAddress(ActionFunctionHelper.getByNameSearchWithAction("CustIpAddr", "n", sbcTableDetails).getParamValue());
				sbcInfo.whereCustIpAddressEQ(sbcObj.getCustIpAddress());
			}

			if (ActionFunctionHelper.getByNameSearchWithAction("CustPort", "n", sbcTableDetails) != null) {
				sbcObj.setCustPort(Long.valueOf(ActionFunctionHelper.getByNameSearchWithAction("CustPort", "n", sbcTableDetails).getParamValue()));
				sbcInfo.whereCustPortEQ(sbcObj.getCustPort());
			}

			if (ActionFunctionHelper.getByNameSearchWithAction("CarrFqdn", "n", sbcTableDetails) != null) {
				sbcObj.setCarrFqdn(ActionFunctionHelper.getByNameSearchWithAction("CarrFqdn", "n", sbcTableDetails)
						.getParamValue());
				sbcInfo.whereCarrFqdnEQ(sbcObj.getCarrFqdn());
			}
			if (ActionFunctionHelper.getByNameSearchWithAction("CarrIpAddr", "n", sbcTableDetails) != null) {
				sbcObj.setCarrIpAddress(ActionFunctionHelper.getByNameSearchWithAction("CarrIpAddr", "n", sbcTableDetails).getParamValue());
				sbcInfo.whereCarrIpAddressEQ(sbcObj.getCarrIpAddress());
			}

			if (ActionFunctionHelper.getByNameSearchWithAction("CarrPort", "n", sbcTableDetails) != null) {
				sbcObj.setCarrPort(Long.valueOf(ActionFunctionHelper.getByNameSearchWithAction("CarrPort", "n", sbcTableDetails).getParamValue()));
				sbcInfo.whereCarrPortEQ(sbcObj.getCarrPort());
			}
		}
		TableOrderDetailsParam originatingSystem = ActionFunctionHelper.getTableOrderDetailsParam(entityBatch,"OriginatingSystem");
		if (!(originatingSystem == null)) {
			sbcObj.setCreatedBy(originatingSystem
					.getParamValue());
			sbcObj.setModifiedBy(originatingSystem.getParamValue());
		} else {
			sbcObj.setCreatedBy("SYSTEM");
			sbcObj.setModifiedBy("SYSTEM");
		}

		sbcInfo.query(connection);
		ArrayList<?> resultSet = sbcInfo.getResultArrayList();
		log.info( "SBC_INFO records returned  <" + sbcInfo.size());

		if (sbcInfo.size() > 0) {
			TblSbcInfoDbBean sbcInfoDbBean = (TblSbcInfoDbBean) resultSet
			.get(0);
			int sbcId = sbcInfoDbBean.getSbcId();
			log.info( "SBC_ID <" + sbcId + "> in tbl_sbc_info");
			sbcObj.setSbcId(sbcId);
		}

		return sbcObj;
	}*/
	
	
	public static List<FeaturesBean> getLocationFeatures(EntityBatch entityBatch, String action, Connection connection) {
		List<FeaturesBean> locationFeatures = new ArrayList<FeaturesBean>();
		try {
			
			TableOrderDetailsParam locationFeatureDetail = ActionFunctionHelper.getTableOrderDetailsParam(entityBatch,"LocationFeature");
			
			if (!(locationFeatureDetail == null)) {
				List<TableOrderDetailsParam> todList = locationFeatureDetail.getParamDetail();
				for (TableOrderDetailsParam tod : todList) {

					if (!tod.getAction().equals(action))
						continue;
					if (!(ActionFunctionHelper.getTableOrderDetailsParamByName(tod, "Feature")== null)) {
						String featureName =ActionFunctionHelper.getTableOrderDetailsParamByName(tod, "Feature").getParamValue();
						log.info("FeatureName:::{}" , featureName);
						FeaturesBean fb = null;
						TblVzbFeaturesQuery vzbFeats = new TblVzbFeaturesQuery();
						vzbFeats.whereNameLike(featureName);
						vzbFeats.query(connection);
						ArrayList<?> resultSet = vzbFeats.getResultArrayList();
						log.info("vzbfeatures for featurename:{} size : {}"
								, featureName , vzbFeats.size());

						if (vzbFeats.size() > 0) {
							TblVzbFeaturesDbBean vzbFeatDbBean = (TblVzbFeaturesDbBean) resultSet
							.get(0);
							int featureId = vzbFeatDbBean.getFeatureId();
							log.info("FeatureID : {}  in tbl_vzb_features" , featureId);
							fb = new FeaturesBean();
							fb.getFeaturesDbBean().setName(featureName);
							fb.getFeaturesDbBean().setFeatureId(featureId);
							fb.setFeatureCount(Integer.parseInt(ActionFunctionHelper.getTableOrderDetailsParamByName(tod, "DeltaCount").getParamValue())); 
							locationFeatures.add(fb);
						} else {
							log.info("Unkown Feature {}" , featureName);
							continue;
						}
					}
				}

			}
			// After looking under LocationFeature, we have to chk callingNameInd on order.
						// "Calling Name Retrieval" Feature is not part of LocationFeature in TOD. 
						// We have to chk callingNameInd to decide if we need to add it or not.
						// This api will add the "Calling Name Retrieval" for both 
						// 'o' and 'n'. So that it can be delete or add accordingly.
						processCallingNameRetrievalFeature(entityBatch,locationFeatures, action,connection);


					} catch (Exception e) {
						log.error("ERROR: updateEntAndLocCcl in getLocationFeatures()", e);
					}
					return locationFeatures;
				}
	
	private static void processCallingNameRetrievalFeature(EntityBatch entityBatch,List<FeaturesBean> locationFeatures, String action, Connection connection) throws Exception {

		String callingNameInd = ActionFunctionHelper.getParamValueWithAction(entityBatch,"CallingNameInd", action);
		if(callingNameInd != null) {
				if(callingNameInd.equalsIgnoreCase("Y")) {
					// This method will be called for both action 'o' and 'n' and
					// locationFeatures list will have this feature, so that it can be deleted or added.
					// Add to the locationFeatures list for addition and deletion
					// add to the locationFeatures list only if callingPartyInd = Y for action = o or n
					log.info("getLocationFeatures(): action = {} and callingNameInd = {} Will process 'Calling Name Retrieval' feature" , action , callingNameInd);
					if(action.equalsIgnoreCase("n"))
						log.info("CallingNameInd is set to Y, will add Calling Name Retrieval feature.");
					else if(action.equalsIgnoreCase("o"))
						log.info("CallingNameInd is set to N, will remove Calling Name Retrieval feature.");

					String featureName = "Calling Name Retrieval";

					TblVzbFeaturesQuery vzbFeats = new TblVzbFeaturesQuery();
					vzbFeats.whereNameLike(featureName);
					vzbFeats.query(connection);
					ArrayList<?> resultSet = vzbFeats.getResultArrayList();

					log.info("vzbfeatures for featurename:<" + featureName + "> size <" + vzbFeats.size());

					if (vzbFeats.size() > 0) {
						TblVzbFeaturesDbBean vzbFeatDbBean = (TblVzbFeaturesDbBean) resultSet.get(0);
						int featureId = vzbFeatDbBean.getFeatureId();
						log.info("FeatureID : {} in tbl_vzb_features" , featureId);
						FeaturesBean fb = new FeaturesBean();
						fb.getFeaturesDbBean().setName("Calling Name Retrieval");
						fb.getFeaturesDbBean().setFeatureId(featureId);
						fb.setFeatureCount(1);
						locationFeatures.add(fb);
					} else {
						log.info("Feature: {} not found in DB." , featureName);
						// Need to throw exception.
					}
				}
				else {
					log.info("getLocationFeatures(): action = {} and callingNameInd = {} . Will NOT process 'Calling Name Retrieval' feature." 
							,action, callingNameInd);
				}
			} else {
				log.info("callingNameInd is null, not processing.");
			}
	}
	
	
	/*public static boolean circuitIdAndVpnNameUpdateForRemoteAndHubLocations(EntityBatch entityBatch,String strEntity,String locationId, String isRemote, Connection connection) throws Exception {
		log.info("Entered circuitIdAndVpnNameUpdateForRemoteAndHubLocations() method ....");
		log.info("sysout Entered circuitIdAndVpnNameUpdateForRemoteAndHubLocations() method ....");
		
		if (isRemote.equalsIgnoreCase("REMOTE")){
			//location is remote			
			try {
				TblLocationDbBean remoteLocation = ActionFunctionHelper.getLocationForLocationId(locationId,connection);
				String hubLocationId = remoteLocation.getHubLocationId();
				
				 TblLocationDbBean hubLoc = null;
				 hubLoc = ActionFunctionHelper.getLocationForLocationId(hubLocationId,connection);
				 
				 log.info(" Got the Hub location Id from remote location ....");
				       	              
     	         String vpnName = "";
     	         String cktId = ""; 
     	            if (hubLoc != null)
                     {
         			    cktId = hubLoc.getCircuitId();
         				vpnName = hubLoc.getVpnName();
                     }     
     	   
     	            DBTblLocation locationDbBean2 = new DBTblLocation();
     				locationDbBean2.whereLocationIdEQ(locationId);
     				locationDbBean2.setCircuitId(cktId);
     				locationDbBean2.setVpnName(vpnName);
     				
     				TableOrderDetailsParam sbcAccessType = ActionFunctionHelper.getTableOrderDetailsParam(entityBatch,"SbcAccessType");
     				if (sbcAccessType != null && sbcAccessType.getParamValue() != null){
     					log.info("sbcType in circuitIdAndVpnName");
     					if("S".equals(sbcAccessType.getParamValue())) {
     						log.info("sbcType is S (IDA) circuitIdAndVpnName");
     						TableOrderDetailsParam productType = ActionFunctionHelper.getTableOrderDetailsParam(entityBatch,"ProductType");
     						  if (productType != null && productType.getParamValue() != null){
     							 log.info("ProductType is circuitIdAndVpnName");
     							 if("7".equals(productType.getParamValue())) {
     								log.info("ProductType is 7 circuitIdAndVpnName");
     								log.info("vpnName CIR {}" ,vpnName);
     								log.info("endID CIR {}" ,hubLoc.getEnterpriseId());
     								if(vpnName != null && vpnName != "") {
	     								if(vpnName.equals(hubLoc.getEnterpriseId())) {
	     									log.info("vpn name and entid are same in circuitIdAndVpnName");
	     									locationDbBean2.setVpnName(null);
	     								}
     								}
     							 }
     						  }
     					}
     				}    
     				
     				if ( locationDbBean2.updateSpByWhere(connection) <= 0 ) {
     					log.info("Unable to update cktId and vpnName for the remote Location ....");
    					return false;
    				}
     				
     				log.info("updated remote location with circuidId and vpnname from hub location ....");
				
			} catch (SQLException e) {
				log.error("ERROR: SQLException in circuitIdAndVpnNameUpdateForRemoteAndHubLocations()", e);
				log.error("ERROR: Exception occured in circuitIdAndVpnNameUpdateForRemoteAndHubLocations() method",e);
			}				
		}
		else {			
			    // location is hub location
				log.info("Location is a hub location ....");
			    Location locationValidate = new Location(connection);
			    DBTblLocation locationDbBean2 = new DBTblLocation();
				locationDbBean2.whereLocationIdEQ(locationId);
				
				String cktId2 = "";
				String vpnName2 = "";
				TableOrderDetailsParam circuitId = ActionFunctionHelper.getTableOrderDetailsParam(entityBatch,"CircuitId");
				if (!(circuitId == null))
				cktId2 =	circuitId.getParamValue();
				
				locationValidate.setLocationId(locationId);
				if(locationValidate.getDetails() && locationValidate.validAccessType()){
					if (ActionFunctionHelper.getTableOrderDetailsParam(entityBatch,"CustomerId") != null)
						vpnName2 =ActionFunctionHelper.getTableOrderDetailsParam(entityBatch,"CustomerId").getParamValue();						
				}
				else if (ActionFunctionHelper.getTableOrderDetailsParam(entityBatch,"VpnName") != null)
						vpnName2 = ActionFunctionHelper.getTableOrderDetailsParam(entityBatch,"VpnName").getParamValue();
				else 
	                  vpnName2 = locationValidate.getVpnName();
				
				log.info(" CircuitId and VpnName  {},{}",cktId2 , vpnName2 );
	 			//logTrailList.add(" CircuitId and VpnName  " + cktId2 +","+ vpnName2 );
				 				
				locationDbBean2.setCircuitId(cktId2);
				locationDbBean2.setVpnName(vpnName2);
				
				if (ActionFunctionHelper.getTableOrderDetailsParam(entityBatch,"SbcAccessType") != null && ActionFunctionHelper.getTableOrderDetailsParam(entityBatch,"SbcAccessType").getParamValue() != null){
					log.info("sbcType in circuitIdAndVpnName IF");
 					if("S".equals(ActionFunctionHelper.getTableOrderDetailsParam(entityBatch,"SbcAccessType").getParamValue())) {
 							log.info("sbcType is S (IDA) circuitIdAndVpnName");
 						  if (ActionFunctionHelper.getTableOrderDetailsParam(entityBatch,"ProductType") != null && ActionFunctionHelper.getTableOrderDetailsParam(entityBatch,"ProductType").getParamValue() != null){
 							 log.info("ProductType is circuitIdAndVpnName");
 							 if("7".equals(ActionFunctionHelper.getTableOrderDetailsParam(entityBatch,"ProductType").getParamValue())) {
 								log.info("ProductType is 7 circuitIdAndVpnName");
 								log.info("vpnName CIR {}" ,vpnName2);
 								log.info("endID CIR {}" ,locationValidate.getEnterpriseId());
 								log.info("Checking if vpnname and enterpise are same");
 								
 								if(vpnName2 != null && vpnName2 != "") {
	 								if(vpnName2.trim().equals(locationValidate.getEnterpriseId().trim())) {
	 									log.info("vpn name and entid are same in circuitIdAndVpnName");
	 									locationDbBean2.setVpnName(null);
	 								}
 								}
 							 }
 						  }
 					}
 				} 
				
				if ( locationDbBean2.updateSpByWhere(connection) <= 0 ) {
					log.info("Unable to update cktId and vpnName for the hub Location ....");
				return false;
			    }
				log.info("updated hub location with circuidId and vpnname from order param ....");
				// get all the remote locations for this hub location
				try {
		            if (locationId == null || connection == null)
		                throw new Exception();
		           
		            TblLocationQuery tlQry = new TblLocationQuery();
		            tlQry.whereHubLocationIdEQ(locationId);
		            tlQry.whereActiveIndEQ(1); 
		            tlQry.query(connection);
		            ArrayList<TblLocationDbBean> remLocs = tlQry.getResultArrayList();
		            log.info("fetched all the remote locations ....");
		            if (remLocs != null && remLocs.size() > 0 ) {		            	
		            	for(int k = 0; k<remLocs.size(); k++ ){ 		            		
		            		TblLocationDbBean remoteLocationObject = new TblLocationDbBean();
		            		remoteLocationObject = remLocs.get(k);
		            		String tempLocationId = remoteLocationObject.getLocationId();
		            		
		            		DBTblLocation tableLocationObject = new DBTblLocation();
		            		tableLocationObject.whereLocationIdEQ(tempLocationId);
		            		tableLocationObject.setCircuitId(cktId2);
		            		tableLocationObject.setVpnName(vpnName2);
		            		
		            		if (ActionFunctionHelper.getTableOrderDetailsParam(entityBatch,"SbcAccessType") != null && ActionFunctionHelper.getTableOrderDetailsParam(entityBatch,"SbcAccessType").getParamValue() != null){
		     					log.info("sbcType in circuitIdAndVpnName IFIF");
		     					if("S".equals(ActionFunctionHelper.getTableOrderDetailsParam(entityBatch,"SbcAccessType").getParamValue())) {
		     							log.info("sbcType is S (IDA) circuitIdAndVpnName");
		     						  if (ActionFunctionHelper.getTableOrderDetailsParam(entityBatch,"ProductType") != null && ActionFunctionHelper.getTableOrderDetailsParam(entityBatch,"ProductType").getParamValue() != null){
		     							 log.info("ProductType is circuitIdAndVpnName");
		     							 if("7".equals(ActionFunctionHelper.getTableOrderDetailsParam(entityBatch,"ProductType").getParamValue())) {
		     								log.info("ProductType is 7 circuitIdAndVpnName");
		     								log.info("vpnName CIR {}" ,vpnName2);
		     								log.info("endID CIR {}" ,locationValidate.getEnterpriseId());
		     								if(vpnName2 != null && vpnName2 != "") {
			     								if(vpnName2.equals(locationValidate.getEnterpriseId())) {
			     									log.info("vpn name and entid are same in circuitIdAndVpnName");
			     									locationDbBean2.setVpnName(null);
			     								}
		     								}
		     							 }
		     						  }
		     					}
		     				} 
		            		
		            		if ( tableLocationObject.updateSpByWhere(connection) <= 0 ) {
		            			log.info( "Unable to update cktId and vpnName for the remote Location from hub location ....");
		   					return false;
		   				    }	
		            		log.info("updated circuidId and vpnname for all remote locations ....");	
		            	}
		            }
		        }
		        catch (Exception e) {
		        	
		        	log.error("ERROR: Exception in circuitIdAndVpnNameUpdateForRemoteAndHubLocations()", e);
		            throw e;
		        }				
		}	
		return true;
	}*/
	
		public static int getTnPortedStatus(String tn, Connection connection) throws Exception {
				int portStatus = -1;
				TblPublicTnPoolQuery pubTnQry = new TblPublicTnPoolQuery();
				pubTnQry.whereTnEQ(tn);
				pubTnQry.query(connection);
				if (pubTnQry.size() > 0) {
					portStatus = Integer.parseInt(pubTnQry.getDbBean(0)
							.getPortedStatus());
				}
				return portStatus;
			}



		/*************** Changes regarding  VZB_INV_MOD_EBI **************/
/*		
		public static void generateIpsecTunnelReq(TableOrderDetailsParam orderParam, String enterpriseId, short deviceType,
				long deviceId, String origSystem, long envOrdId, Connection connection) throws Exception {
			boolean isIkeIpeChanged = false;
			boolean tunnelValChanged = false;
			String deviceSbc = "";
			String deviceSbcName = "";
			String ikeIp = null;
			String oldIkeIp = null;
			String egwType = null;
			short sigHostMask = 0;
			String sigHostSubnet = null;
			int tunnelCheckStatus = 0;
			long ipsecTunnelCheckReturn = -999;
			long ipsecIkeIpCheckVal = -999;
			long ipSecTunnelId = 0;
			long oldIpsecTunnelId = 0;
			try {
				if (deviceType == VzbVoipEnum.IpsecDeviceType.DEVICE) {
					deviceSbc = "GatewaySbc";
					deviceSbcName = "gwy";
				} else if (deviceType == VzbVoipEnum.IpsecDeviceType.EBI) {
					deviceSbc = "EbiSbc";
					deviceSbcName = "ebi";
				}
				if (getByNameSearchWithAction("IpSecTunnelId", "n", orderParam) != null) {
					if (getByNameSearchWithAction("IpSecTunnelId", "n", orderParam).getParamValue() != null) {
						ipSecTunnelId = Long
								.valueOf(getByNameSearchWithAction("IpSecTunnelId", "n", orderParam).getParamValue());
						if (ipSecTunnelId == 0) {
							if (getByNameSearchWithAction("IKEIP", "n", orderParam) != null) {
								if (getByNameSearchWithAction("IKEIP", "n", orderParam).getParamValue() != null) {
									ikeIp = getByNameSearchWithAction("IKEIP", "n", orderParam).getParamValue();
									ipSecTunnelId = IpSecUtil.checkIPSecTunnel(connection, null, ikeIp);
									log.info("IKEip exists in db ipsecTunnelId is :: " + ipSecTunnelId);
								}
							}
							if (ipSecTunnelId == 0) {
								log.info("New Ipsec Tunnel generate ipsec tunnel id");
								ipSecTunnelId = getSequenceValue(connection, "IPSEC_TUNNEL_ID_SEQ");
							}
						}
					}
				} else {
					if (getByNameSearchWithAction("IpSecTunnelId", "r", orderParam) != null
							&& getByNameSearchWithAction("IpSecTunnelId", "r", orderParam).getParamValue() != null) {
						ipSecTunnelId = Long
								.valueOf(getByNameSearchWithAction("IpSecTunnelId", "r", orderParam).getParamValue());
					} else if (ipSecTunnelId == 0) {
						log.info("IPSEC TUNNEL Param not populated in TOD ");
						if (getByNameSearchWithAction("IKEIP", "n", orderParam) != null) {
							if (getByNameSearchWithAction("IKEIP", "n", orderParam).getParamValue() != null) {
								ikeIp = getByNameSearchWithAction("IKEIP", "n", orderParam).getParamValue();
								ipSecTunnelId = IpSecUtil.checkIPSecTunnel(connection, null, ikeIp);
								log.info("IKEip exists in db ipsecTunnelId is :: " + ipSecTunnelId);
							}
						}
						if (ipSecTunnelId == 0) {
							log.info("New Ipsec Tunnel generate ipsec tunnel id");
							ipSecTunnelId = getSequenceValue(connection, "IPSEC_TUNNEL_ID_SEQ");
						}
					}
				}
				log.info("*** ipSecTunnelId ** " + ipSecTunnelId);
				if (ipSecTunnelId == 0) {
					log.info("No ipsec return");
					return;
				}
				if (getByNameSearchWithAction("IKEIP", "n", orderParam) != null) {
					if (getByNameSearchWithAction("IKEIP", "n", orderParam).getParamValue() != null) {
						isIkeIpeChanged = true;
						// getByNameSearchWithAction("IKEIP","n",orderParam).getParamValue();
						ikeIp = getByNameSearchWithAction("IKEIP", "n", orderParam).getParamValue();
					}
					if (getByNameSearchWithAction("IKEIP", "o", orderParam) != null
							&& getByNameSearchWithAction("IKEIP", "o", orderParam).getParamValue() != null) {
						oldIkeIp = getByNameSearchWithAction("IKEIP", "o", orderParam).getParamValue();
					}
					if (oldIkeIp != null && ikeIp != null) {
						log.info(" Old IKE IP and New IKE IP not null");
						ipsecTunnelCheckReturn = IpSecUtil.checkIPSecTunnel(connection, oldIkeIp, null);
						ipsecIkeIpCheckVal = IpSecUtil.checkIPSecTunnel(connection, null, ikeIp);
						log.info("ipsecTunnelCheckReturn " + ipsecTunnelCheckReturn + " ipsecIkeIpCheckVal "
								+ ipsecIkeIpCheckVal);
					}
				} else {
					if (getByNameSearchWithAction("IKEIP", "r", orderParam).getParamValue() != null) {
						ikeIp = getByNameSearchWithAction("IKEIP", "r", orderParam).getParamValue();
					}
				}

				IpSec ipSecObj = getIpsecWIthTunnelValues(orderParam, connection);
				ipSecObj.setIkeIp(ikeIp);
				if (isIkeIpeChanged && ipsecTunnelCheckReturn == 0 && ipsecIkeIpCheckVal == 0) { 
					log.info("Scenario 1 -> BOTH OLD AND NEW IKE IP NOT ASSOCIATED TO A DEVICE");
					// IPsec code here
					ipSecObj.createNewAndDeleteOldIpsecTunnel(deviceId, deviceType, envOrdId, true, enterpriseId,
							origSystem);

				} else if (isIkeIpeChanged && ipsecTunnelCheckReturn == 0 && ipsecIkeIpCheckVal > 0) { 
					log.info("Scenario 2 ->  OLD IKE IP NOT ASSOCIATED TO A DEV AND NEW IKE IP ASSOCIATED WITH A DEVICE");
					// IPsec code here
					ipSecObj.createIpseqDeleteRequest(deviceId, deviceType, envOrdId, true);
					ipSecObj.updateDevicewithIpsecTunnel(deviceId, deviceType, ipsecIkeIpCheckVal);
					if (ipSecObj.isTunnelValuesChanged()) {
						ipSecObj.updateIpsecTunnelValues(ipsecIkeIpCheckVal);
					}
				} else if (isIkeIpeChanged && ipsecTunnelCheckReturn == -1 && ipsecIkeIpCheckVal > 0) { 
					log.info("Scenario 3 -> BOTH OLD AND NEW IKE IP  ASSOCIATED TO A DEV ");
					ipSecObj.updateDevicewithIpsecTunnel(deviceId, deviceType, ipsecIkeIpCheckVal); 
					if (ipSecObj.isTunnelValuesChanged()) {
						ipSecObj.updateIpsecTunnelValues(ipsecIkeIpCheckVal); 
					}

				} else if (isIkeIpeChanged && ipsecTunnelCheckReturn == -1 && ipsecIkeIpCheckVal == 0) {
					log.info("Scenario 4 -> ONLY OLD IKE IP ASSOCIATED TO A DEV ");
					oldIpsecTunnelId = ipSecObj.getIpsecTunnelIdForDevice(deviceId, deviceType);
					log.info("oldIpsecTunnelId " + oldIpsecTunnelId);
					ipSecObj.addNewIpsecTunnelDetails(oldIpsecTunnelId, deviceId, deviceType, enterpriseId, origSystem,
							envOrdId);
				} else {
					log.info("Scenario 5 -> IKE IP NOT CHANGED or oldTunnelExists is false");
					boolean tunnelExists = false;
					if (ipSecObj.isTunnelExistsInDb(ipSecTunnelId)) {
						tunnelExists = true;
					}
					if (ipSecObj.isTunnelValuesChanged()) {
						ipSecObj.updateIpsecTunnelValues(ipSecTunnelId);
					}
					ipSecObj.setIpsecTunnelId(ipSecTunnelId);
					ipSecObj.setDeviceId(deviceId);
					if (tunnelExists) {
						ipSecObj.setRequestType((short) VzbVoipEnum.IpsecProvRequestType.MOD);
					} else {
						ipSecObj.setRequestType((short) VzbVoipEnum.IpsecProvRequestType.ADD);
					}
					ipSecObj.setRequestBy(origSystem);
					if (!(getTableOrderDetailsParamByName(orderParam, "CustomerId") == null)) {
						ipSecObj.setEnterpriseId(getTableOrderDetailsParamByName(orderParam, "CustomerId").getParamValue());
						log.info("ipSecObj.getEnterpriseId()  " + ipSecObj.getEnterpriseId());
					}
					ipSecObj.setDeviceType(deviceType);
					if (getTableOrderDetailsParamByName(orderParam, "EnvOrderId") != null) {
						ipSecObj.setEnvOrderId(
								Long.valueOf(getTableOrderDetailsParamByName(orderParam, "EnvOrderId").getParamValue()));
					}
					ipSecObj.setRequestStatus((short) VzbVoipEnum.IpsecProvRequestStatus.PENDING);

					TableOrderDetailsParam deviceSbcDetail = getTableOrderDetailsParamByName(orderParam, deviceSbc);

					// List <TableOrderDetaisParam> provDetailsList =
					// orderParam.getByNameSearchList(deviceSbc);

					List<TableOrderDetailsParam> provDetailsList = deviceSbcDetail.getParamDetail();
					List<IpSecRequestDetailsBean> ipsecDetailsList = new ArrayList<IpSecRequestDetailsBean>();
					boolean ipsecDetailsChanged = false;
					for (TableOrderDetailsParam provParamList : provDetailsList) {
						if (getByNameSearchWithAction("SbcClli", "n", provParamList) != null
								&& getByNameSearchWithAction("SbcClli", "n", provParamList).getParamValue() != null) {
							IpSecRequestDetailsBean ipseqReqBean = new IpSecRequestDetailsBean();
							ipseqReqBean.setName(deviceSbcName);
							ipseqReqBean.setProvValue(
									getTableOrderDetailsParamByName(provParamList, "SbcClli").getParamValue());
							ipseqReqBean.setProvAction("n");
							ipsecDetailsList.add(ipseqReqBean);
							ipsecDetailsChanged = true;
						}
						if (getByNameSearchWithAction("SbcClli", "o", provParamList) != null
								&& getByNameSearchWithAction("SbcClli", "o", provParamList).getParamValue() != null) {
							IpSecRequestDetailsBean ipseqReqBean = new IpSecRequestDetailsBean();
							ipseqReqBean.setName(deviceSbcName);
							ipseqReqBean.setProvValue(
									getTableOrderDetailsParamByName(provParamList, "SbcClli").getParamValue());
							ipseqReqBean.setProvAction("o");
							ipsecDetailsList.add(ipseqReqBean);
							ipsecDetailsChanged = true;
						}
						if (getByNameSearchWithAction("SbcClli", "r", provParamList) != null
								&& getByNameSearchWithAction("SbcClli", "r", provParamList).getParamValue() != null) {
							IpSecRequestDetailsBean ipseqReqBean = new IpSecRequestDetailsBean();
							ipseqReqBean.setName(deviceSbcName);
							ipseqReqBean.setProvValue(
									getTableOrderDetailsParamByName(provParamList, "SbcClli").getParamValue());
							ipseqReqBean.setProvAction("r");
							ipsecDetailsList.add(ipseqReqBean);
						}
					}
					ipSecObj.setIpseqReqDetailsList(ipsecDetailsList);
					if (!tunnelExists) {
						ipSecObj.addToDBTblIpSecTunnel();
						log.info("New ipsecTunnel added");
					} else {
						if (ipsecIkeIpCheckVal != 0) {
							ipSecObj.updateDevicewithIpsecTunnel(deviceId, deviceType, ipSecTunnelId);
						}
						if (tunnelValChanged) {
							ipSecObj.updateIpsecTunnelValues(ipsecTunnelCheckReturn);
						}
						if (ipsecDetailsChanged) {
							ipSecObj.addToDBTblIpsecProvRequest();
						}
					}
					ipSecObj.updateDevicewithIpsecTunnel(deviceId, deviceType, ipSecTunnelId);
					log.info("ipsec request added");
				}
			} catch (Exception e) {
				// e.printStackTrace();
			}
		}
		
		
		public static int getSequenceValue(Connection connection, String name) throws Exception {
			PreparedStatement pstmt = null;
			ResultSet rs = null;
			String sqlQuery = "SELECT " + name + ".NEXTVAL FROM DUAL";
			int gatwayDeviceId = 0;
			try {
				pstmt = connection.prepareStatement(sqlQuery);
				rs = pstmt.executeQuery();
				while (rs.next()) {
					gatwayDeviceId = rs.getInt(1);
				}
			} catch (Exception exception) {
				exception.printStackTrace();
			} finally {
				if (pstmt != null)
					pstmt.close();
				if (rs != null)
					rs.close();
			}
			log.info("gatwayDeviceId  ===> " + gatwayDeviceId);
			return gatwayDeviceId;
		}
		
		public static IpSec getIpsecWIthTunnelValues(TableOrderDetailsParam orderParam, Connection connection) {
			IpSec ipSecObj = new IpSec(connection);
			String ikeIp = null;
			String oldIkeIp = null;
			String egwType = null;
			short sigHostMask = 0;
			String sigHostSubnet = null;
			boolean tunnelValChanged = false;
			try {
				if (getByNameSearchWithAction("EWGType", "n", orderParam) != null) {
					if (getByNameSearchWithAction("EWGType", "n", orderParam).getParamValue() != null) {
						egwType = getByNameSearchWithAction("EWGType", "n", orderParam).getParamValue();
						tunnelValChanged = true;
					}
				} else {
					if (getByNameSearchWithAction("EWGType", "r", orderParam) != null
							&& getByNameSearchWithAction("EWGType", "r", orderParam).getParamValue() != null) {
						egwType = getByNameSearchWithAction("EWGType", "r", orderParam).getParamValue();
					}
				}

				if (getByNameSearchWithAction("SigHostMask", "n", orderParam) != null) {
					if (getByNameSearchWithAction("SigHostMask", "n", orderParam).getParamValue() != null) {
						sigHostMask = Short
								.parseShort(getByNameSearchWithAction("SigHostMask", "n", orderParam).getParamValue());
						tunnelValChanged = true;
					}
				} else {
					if (getByNameSearchWithAction("SigHostMask", "r", orderParam) != null
							&& getByNameSearchWithAction("SigHostMask", "r", orderParam).getParamValue() != null) {
						sigHostMask = Short
								.parseShort(getByNameSearchWithAction("SigHostMask", "r", orderParam).getParamValue());
					}
				}

				if (getByNameSearchWithAction("SigHostSubnet", "n", orderParam) != null) {
					if (getByNameSearchWithAction("SigHostSubnet", "n", orderParam).getParamValue() != null) {
						sigHostSubnet = getByNameSearchWithAction("SigHostSubnet", "n", orderParam).getParamValue();
						tunnelValChanged = true;
					}
				} else {
					if (getByNameSearchWithAction("SigHostSubnet", "r", orderParam) != null
							&& getByNameSearchWithAction("SigHostSubnet", "r", orderParam).getParamValue() != null) {
						sigHostSubnet = getByNameSearchWithAction("SigHostSubnet", "r", orderParam).getParamValue();
					}
				}

				ipSecObj.setIkeIp(ikeIp);
				ipSecObj.setEgwType(egwType);
				ipSecObj.setHostSubMask(sigHostMask);
				ipSecObj.setHostSubIP(sigHostSubnet);
				ipSecObj.setTunnelValuesChanged(tunnelValChanged);

			} catch (Exception e) {
				e.printStackTrace();
			}

			return ipSecObj;
		}
*/


		/************************** INV_NOD_DEVICE **********************************/
		
		public static long getFirmWareIdByDevTypeIdAndVersion(String deviceTypeId, String firmVer, Connection connection)
				throws Exception {
			long firmVerId = 0;
			try {
				TblDeviceFirmwaresQuery devFirmQry = new TblDeviceFirmwaresQuery();
				devFirmQry.whereDeviceTypeIdEQ(Long.valueOf(deviceTypeId));
				TblFirmwareVersionQuery firmQry = new TblFirmwareVersionQuery();
				firmQry.whereFirmwareDescEQ(firmVer);
				firmQry.query(connection);
				if (firmQry.size() > 0)
					devFirmQry.whereFirmwareVersionIdEQ(firmQry.getDbBean(0).getFirmwareVersionId());
				else {
					log.info("Invalid firmware");
					return firmVerId;
				}
				devFirmQry.query(connection);
				if (devFirmQry.size() > 0) {
					firmVerId = devFirmQry.getDbBean(0).getDeviceFirmwaresId();
				}
			} catch (Exception e) {
				log.error("ERROR: Exception in getFirmWareIdByDevTypeIdAndVersion()", e);
				throw e;
			}
			return firmVerId;
		}
		
		public static boolean isValidGatewayDeviceName(String deviceName, String deviceType, String locationId,
				String enterpriseId, String gatewayDeviceId, Connection connection) {
			boolean returnCode = true;
			PreparedStatement pStmt = null;
			ResultSet rs = null;
			PreparedStatement pStmt1 = null;
			ResultSet rs1 = null;

			// For enterprise shared chk all devices.
			try {

				if (deviceType.equals("CPE_ENTPRISE_GTWY_SHARED")) {
					StringBuffer sql = new StringBuffer();
					sql.append(" select g.* from tbl_gateway_device_info g, tbl_device_map d");
					sql.append(" where d.enterprise_id = '" + enterpriseId + "'");
					sql.append(" and d.gateway_device_id = g.gateway_device_id and g.device_name = '" + deviceName + "'");
					if (gatewayDeviceId != null) {
						sql.append(" and d.gateway_device_id <> " + gatewayDeviceId);
					}
					log.info("Chk for CPE_ENTPRISE_GTWY_SHARED:sql:" + sql.toString());
					pStmt = connection.prepareStatement(sql.toString());
					if (null != pStmt)
						rs = pStmt.executeQuery();
					if (rs.next()) {
						returnCode = false;
					}
				} else {
					// Check the duplicate name at enterprise gtwy level
					StringBuffer sql1 = new StringBuffer();
					sql1.append(" select g.* from tbl_gateway_device_info g, tbl_device_map d, tbl_device_types dp");
					sql1.append(" where d.enterprise_id = '" + enterpriseId + "'");
					sql1.append(" and d.gateway_device_id = g.gateway_device_id and g.device_name = '" + deviceName + "'");
					sql1.append(" and g.device_type_id = dp.device_type_id and dp.device_realtype_id = 4 ");
					if (gatewayDeviceId != null) {
						sql1.append(" and d.gateway_device_id <> " + gatewayDeviceId);
					}
					log.info("Chk for NON SHared gtwy:sql:" + sql1.toString());
					pStmt = connection.prepareStatement(sql1.toString());
					if (null != pStmt)
						rs = pStmt.executeQuery();
					if (rs.next()) {
						returnCode = false;
					}
					if (returnCode == true) {
						// check the duplicate name at location level
						StringBuffer sql2 = new StringBuffer();
						sql2.append(" select g.* from tbl_gateway_device_info g, tbl_device_map d");
						sql2.append(" where d.enterprise_id = '" + enterpriseId + "'");
						sql2.append(
								" and d.gateway_device_id = g.gateway_device_id and g.device_name = '" + deviceName + "'");
						sql2.append(" and d.location_id = '" + locationId + "'");
						if (gatewayDeviceId != null) {
							sql2.append(" and d.gateway_device_id <> " + gatewayDeviceId);
						}

						log.info("Chk for Non Shared gtwy:sql2:" + sql2.toString());
						pStmt1 = connection.prepareStatement(sql2.toString());
						if (null != pStmt1)
							rs1 = pStmt1.executeQuery();
						if (rs1.next()) {
							returnCode = false;
						}
					}
				}
			} catch (Exception e) {
				log.error("ERROR: Exception in isValidGatewayDeviceName()", e);
			} finally {
				try {
					if (null != pStmt)
						pStmt.close();
					if (null != rs)
						rs.close();
					if (null != pStmt1)
						pStmt1.close();
					if (null != rs1)
						rs1.close();
				} catch (Exception e) {
					log.error("ERROR: Exception in isValidGatewayDeviceName>>>>>>>>()", e);
				}
			}

			return returnCode;
		}
		
		
		public static void generateIpsecTunnelReq(TableOrderDetailsParam orderParam, String enterpriseId, short deviceType,
				long deviceId, String origSystem, long envOrdId, Connection connection) throws Exception {
			boolean isIkeIpeChanged = false;
			boolean tunnelValChanged = false;
			String deviceSbc = "";
			String deviceSbcName = "";
			String ikeIp = null;
			String oldIkeIp = null;
			String egwType = null;
			short sigHostMask = 0;
			String sigHostSubnet = null;
			int tunnelCheckStatus = 0;
			long ipsecTunnelCheckReturn = -999;
			long ipsecIkeIpCheckVal = -999;
			long ipSecTunnelId = 0;
			long oldIpsecTunnelId = 0;
			try {
				if (deviceType == VzbVoipEnum.IpsecDeviceType.DEVICE) {
					deviceSbc = "GatewaySbc";
					deviceSbcName = "gwy";
				} else if (deviceType == VzbVoipEnum.IpsecDeviceType.EBI) {
					deviceSbc = "EbiSbc";
					deviceSbcName = "ebi";
				}
				if (getByNameSearchWithAction("IpSecTunnelId", "n", orderParam) != null) {
					if (getByNameSearchWithAction("IpSecTunnelId", "n", orderParam).getParamValue() != null) {
						ipSecTunnelId = Long
								.valueOf(getByNameSearchWithAction("IpSecTunnelId", "n", orderParam).getParamValue());
						if (ipSecTunnelId == 0) {
							if (getByNameSearchWithAction("IKEIP", "n", orderParam) != null) {
								if (getByNameSearchWithAction("IKEIP", "n", orderParam).getParamValue() != null) {
									ikeIp = getByNameSearchWithAction("IKEIP", "n", orderParam).getParamValue();
									ipSecTunnelId = IpSecUtil.checkIPSecTunnel(connection, null, ikeIp);
									log.info("IKEip exists in db ipsecTunnelId is :: " + ipSecTunnelId);
								}
							}
							if (ipSecTunnelId == 0) {
								log.info("New Ipsec Tunnel generate ipsec tunnel id");
								ipSecTunnelId = getSequenceValue(connection, "IPSEC_TUNNEL_ID_SEQ");
							}
						}
					}
				} else {
					if (getByNameSearchWithAction("IpSecTunnelId", "r", orderParam) != null
							&& getByNameSearchWithAction("IpSecTunnelId", "r", orderParam).getParamValue() != null) {
						ipSecTunnelId = Long
								.valueOf(getByNameSearchWithAction("IpSecTunnelId", "r", orderParam).getParamValue());
					} else if (ipSecTunnelId == 0) {
						log.info("IPSEC TUNNEL Param not populated in TOD ");
						if (getByNameSearchWithAction("IKEIP", "n", orderParam) != null) {
							if (getByNameSearchWithAction("IKEIP", "n", orderParam).getParamValue() != null) {
								ikeIp = getByNameSearchWithAction("IKEIP", "n", orderParam).getParamValue();
								ipSecTunnelId = IpSecUtil.checkIPSecTunnel(connection, null, ikeIp);
								log.info("IKEip exists in db ipsecTunnelId is :: " + ipSecTunnelId);
							}
						}
						if (ipSecTunnelId == 0) {
							log.info("New Ipsec Tunnel generate ipsec tunnel id");
							ipSecTunnelId = getSequenceValue(connection, "IPSEC_TUNNEL_ID_SEQ");
						}
					}
				}
				log.info("*** ipSecTunnelId ** " + ipSecTunnelId);
				if (ipSecTunnelId == 0) {
					log.info("No ipsec return");
					return;
				}
				if (getByNameSearchWithAction("IKEIP", "n", orderParam) != null) {
					if (getByNameSearchWithAction("IKEIP", "n", orderParam).getParamValue() != null) {
						isIkeIpeChanged = true;
						// getByNameSearchWithAction("IKEIP","n",orderParam).getParamValue();
						ikeIp = getByNameSearchWithAction("IKEIP", "n", orderParam).getParamValue();
					}
					if (getByNameSearchWithAction("IKEIP", "o", orderParam) != null
							&& getByNameSearchWithAction("IKEIP", "o", orderParam).getParamValue() != null) {
						oldIkeIp = getByNameSearchWithAction("IKEIP", "o", orderParam).getParamValue();
					}
					if (oldIkeIp != null && ikeIp != null) {
						log.info(" Old IKE IP and New IKE IP not null");
						ipsecTunnelCheckReturn = IpSecUtil.checkIPSecTunnel(connection, oldIkeIp, null);
						ipsecIkeIpCheckVal = IpSecUtil.checkIPSecTunnel(connection, null, ikeIp);
						log.info("ipsecTunnelCheckReturn " + ipsecTunnelCheckReturn + " ipsecIkeIpCheckVal "
								+ ipsecIkeIpCheckVal);
					}
				} else {
					if(getByNameSearchWithAction("IKEIP", "r", orderParam) != null){
						if (getByNameSearchWithAction("IKEIP", "r", orderParam).getParamValue() != null) {
							ikeIp = getByNameSearchWithAction("IKEIP", "r", orderParam).getParamValue();
						}
					}
				}

				IpSec ipSecObj = getIpsecWIthTunnelValues(orderParam, connection);
				ipSecObj.setIkeIp(ikeIp);
				if (isIkeIpeChanged && ipsecTunnelCheckReturn == 0 && ipsecIkeIpCheckVal == 0) { 
					log.info("Scenario 1 -> BOTH OLD AND NEW IKE IP NOT ASSOCIATED TO A DEVICE");
					// IPsec code here
					ipSecObj.createNewAndDeleteOldIpsecTunnel(deviceId, deviceType, envOrdId, true, enterpriseId,
							origSystem);

				} else if (isIkeIpeChanged && ipsecTunnelCheckReturn == 0 && ipsecIkeIpCheckVal > 0) { 
					log.info("Scenario 2 ->  OLD IKE IP NOT ASSOCIATED TO A DEV AND NEW IKE IP ASSOCIATED WITH A DEVICE");
					// IPsec code here
					ipSecObj.createIpseqDeleteRequest(deviceId, deviceType, envOrdId, true);
					ipSecObj.updateDevicewithIpsecTunnel(deviceId, deviceType, ipsecIkeIpCheckVal);
					if (ipSecObj.isTunnelValuesChanged()) {
						ipSecObj.updateIpsecTunnelValues(ipsecIkeIpCheckVal);
					}
				} else if (isIkeIpeChanged && ipsecTunnelCheckReturn == -1 && ipsecIkeIpCheckVal > 0) { 
					log.info("Scenario 3 -> BOTH OLD AND NEW IKE IP  ASSOCIATED TO A DEV ");
					ipSecObj.updateDevicewithIpsecTunnel(deviceId, deviceType, ipsecIkeIpCheckVal); 
					if (ipSecObj.isTunnelValuesChanged()) {
						ipSecObj.updateIpsecTunnelValues(ipsecIkeIpCheckVal); 
					}

				} else if (isIkeIpeChanged && ipsecTunnelCheckReturn == -1 && ipsecIkeIpCheckVal == 0) {
					log.info("Scenario 4 -> ONLY OLD IKE IP ASSOCIATED TO A DEV ");
					oldIpsecTunnelId = ipSecObj.getIpsecTunnelIdForDevice(deviceId, deviceType);
					log.info("oldIpsecTunnelId " + oldIpsecTunnelId);
					ipSecObj.addNewIpsecTunnelDetails(oldIpsecTunnelId, deviceId, deviceType, enterpriseId, origSystem,
							envOrdId);
				} else {
					log.info("Scenario 5 -> IKE IP NOT CHANGED or oldTunnelExists is false");
					boolean tunnelExists = false;
					if (ipSecObj.isTunnelExistsInDb(ipSecTunnelId)) {
						tunnelExists = true;
					}
					if (ipSecObj.isTunnelValuesChanged()) {
						ipSecObj.updateIpsecTunnelValues(ipSecTunnelId);
					}
					ipSecObj.setIpsecTunnelId(ipSecTunnelId);
					ipSecObj.setDeviceId(deviceId);
					if (tunnelExists) {
						ipSecObj.setRequestType((short) VzbVoipEnum.IpsecProvRequestType.MOD);
					} else {
						ipSecObj.setRequestType((short) VzbVoipEnum.IpsecProvRequestType.ADD);
					}
					ipSecObj.setRequestBy(origSystem);
					if (enterpriseId != null) {
						ipSecObj.setEnterpriseId(enterpriseId);
						log.info("ipSecObj.getEnterpriseId()  " + ipSecObj.getEnterpriseId());
					}
					ipSecObj.setDeviceType(deviceType);
				
					ipSecObj.setEnvOrderId(envOrdId);
					
					ipSecObj.setRequestStatus((short) VzbVoipEnum.IpsecProvRequestStatus.PENDING);
					List<TableOrderDetailsParam> provDetailsList = getChildByNameSearch(orderParam, deviceSbc);
					/*TableOrderDetailsParam deviceSbcDetail = getTableOrderDetailsParamByName(orderParam, deviceSbc);

					// List <TableOrderDetaisParam> provDetailsList =
					// orderParam.getByNameSearchList(deviceSbc);

					List<TableOrderDetailsParam> provDetailsList = deviceSbcDetail.getParamDetail();*/
					List<IpSecRequestDetailsBean> ipsecDetailsList = new ArrayList<IpSecRequestDetailsBean>();
					boolean ipsecDetailsChanged = false;
					for (TableOrderDetailsParam provParamList : provDetailsList) {
						if (getTableOrderDetailsParamByNameWithAction(provParamList,"SbcClli", "n") != null
								&& getTableOrderDetailsParamByNameWithAction(provParamList,"SbcClli", "n").getParamValue() != null) {
							IpSecRequestDetailsBean ipseqReqBean = new IpSecRequestDetailsBean();
							ipseqReqBean.setName(deviceSbcName);
							ipseqReqBean.setProvValue(
									getTableOrderDetailsParamByName(provParamList, "SbcClli").getParamValue());
							ipseqReqBean.setProvAction("n");
							ipsecDetailsList.add(ipseqReqBean);
							ipsecDetailsChanged = true;
						}
						if (getTableOrderDetailsParamByNameWithAction(provParamList,"SbcClli", "o") != null
								&& getTableOrderDetailsParamByNameWithAction(provParamList,"SbcClli", "o").getParamValue() != null) {
							IpSecRequestDetailsBean ipseqReqBean = new IpSecRequestDetailsBean();
							ipseqReqBean.setName(deviceSbcName);
							ipseqReqBean.setProvValue(
									getTableOrderDetailsParamByName(provParamList, "SbcClli").getParamValue());
							ipseqReqBean.setProvAction("o");
							ipsecDetailsList.add(ipseqReqBean);
							ipsecDetailsChanged = true;
						}
						if (getTableOrderDetailsParamByNameWithAction(provParamList,"SbcClli", "r") != null
								&& getTableOrderDetailsParamByNameWithAction(provParamList,"SbcClli", "r").getParamValue() != null) {
							IpSecRequestDetailsBean ipseqReqBean = new IpSecRequestDetailsBean();
							ipseqReqBean.setName(deviceSbcName);
							ipseqReqBean.setProvValue(
									getTableOrderDetailsParamByName(provParamList, "SbcClli").getParamValue());
							ipseqReqBean.setProvAction("r");
							ipsecDetailsList.add(ipseqReqBean);
						}
					}
					ipSecObj.setIpseqReqDetailsList(ipsecDetailsList);
					if (!tunnelExists) {
						ipSecObj.addToDBTblIpSecTunnel();
						log.info("New ipsecTunnel added");
					} else {
						if (ipsecIkeIpCheckVal != 0) {
							ipSecObj.updateDevicewithIpsecTunnel(deviceId, deviceType, ipSecTunnelId);
						}
						if (tunnelValChanged) {
							ipSecObj.updateIpsecTunnelValues(ipsecTunnelCheckReturn);
						}
						if (ipsecDetailsChanged) {
							ipSecObj.addToDBTblIpsecProvRequest();
						}
					}
					ipSecObj.updateDevicewithIpsecTunnel(deviceId, deviceType, ipSecTunnelId);
					log.info("ipsec request added");
				}
			} catch (Exception e) {
				log.error(" generateIpsecTunnelReq()  exception {} ", e);
			}
		}
		
		public static int getSequenceValue(Connection connection, String name) throws Exception {
			PreparedStatement pstmt = null;
			ResultSet rs = null;
			String sqlQuery = "SELECT " + name + ".NEXTVAL FROM DUAL";
			int gatwayDeviceId = 0;
			try {
				pstmt = connection.prepareStatement(sqlQuery);
				rs = pstmt.executeQuery();
				while (rs.next()) {
					gatwayDeviceId = rs.getInt(1);
				}
			} catch (Exception exception) {
				
				log.error(" getSequenceValue()  exception {} ", exception);
				
			} finally {
				if (pstmt != null)
					pstmt.close();
				if (rs != null)
					rs.close();
			}
			log.info("gatwayDeviceId  ===> " + gatwayDeviceId);
			return gatwayDeviceId;
		}

		
		public static IpSec getIpsecWIthTunnelValues(TableOrderDetailsParam orderParam, Connection connection) {
			IpSec ipSecObj = new IpSec(connection);
			String ikeIp = null;
			String oldIkeIp = null;
			String egwType = null;
			short sigHostMask = 0;
			String sigHostSubnet = null;
			boolean tunnelValChanged = false;
			try {
				if (getByNameSearchWithAction("EWGType", "n", orderParam) != null) {
					if (getByNameSearchWithAction("EWGType", "n", orderParam).getParamValue() != null) {
						egwType = getByNameSearchWithAction("EWGType", "n", orderParam).getParamValue();
						tunnelValChanged = true;
					}
				} else {
					if (getByNameSearchWithAction("EWGType", "r", orderParam) != null
							&& getByNameSearchWithAction("EWGType", "r", orderParam).getParamValue() != null) {
						egwType = getByNameSearchWithAction("EWGType", "r", orderParam).getParamValue();
					}
				}

				if (getByNameSearchWithAction("SigHostMask", "n", orderParam) != null) {
					if (getByNameSearchWithAction("SigHostMask", "n", orderParam).getParamValue() != null) {
						sigHostMask = Short
								.parseShort(getByNameSearchWithAction("SigHostMask", "n", orderParam).getParamValue());
						tunnelValChanged = true;
					}
				} else {
					if (getByNameSearchWithAction("SigHostMask", "r", orderParam) != null
							&& getByNameSearchWithAction("SigHostMask", "r", orderParam).getParamValue() != null) {
						sigHostMask = Short
								.parseShort(getByNameSearchWithAction("SigHostMask", "r", orderParam).getParamValue());
					}
				}

				if (getByNameSearchWithAction("SigHostSubnet", "n", orderParam) != null) {
					if (getByNameSearchWithAction("SigHostSubnet", "n", orderParam).getParamValue() != null) {
						sigHostSubnet = getByNameSearchWithAction("SigHostSubnet", "n", orderParam).getParamValue();
						tunnelValChanged = true;
					}
				} else {
					if (getByNameSearchWithAction("SigHostSubnet", "r", orderParam) != null
							&& getByNameSearchWithAction("SigHostSubnet", "r", orderParam).getParamValue() != null) {
						sigHostSubnet = getByNameSearchWithAction("SigHostSubnet", "r", orderParam).getParamValue();
					}
				}

				ipSecObj.setIkeIp(ikeIp);
				ipSecObj.setEgwType(egwType);
				ipSecObj.setHostSubMask(sigHostMask);
				ipSecObj.setHostSubIP(sigHostSubnet);
				ipSecObj.setTunnelValuesChanged(tunnelValChanged);

			} catch (Exception e) {
				log.error("ERROR: Exception in getIpsecWIthTunnelValues()", e);
			}

			return ipSecObj;
		}

		public static int getCodecId(String Codec, Connection connection) throws SQLException {
			int codec_id;
			log.info("Codec===>" + Codec);
			TblCodecTypeDbBean codecTypeDbBean = new TblCodecTypeDbBean();
			ArrayList<TblCodecTypeDbBean> resultList = null;
			try {
				TblCodecTypeQuery codecTypeQuery = new TblCodecTypeQuery();
				codecTypeQuery.whereCodecNameEQ(Codec);
				codecTypeQuery.query(connection);

				resultList = codecTypeQuery.getResultArrayList();
				if (resultList.size() > 0) {
					codecTypeDbBean = (TblCodecTypeDbBean) resultList.get(0);
					codec_id = codecTypeDbBean.getCodecId();
				} else
					return -1;

			} catch (SQLException e) {
				log.error(" getCodecId()  exception {} ", e);
				log.info("ERROR: Exception caught while trying to get codec_id from tbl_codec_type");
				return -1;
			}

			return codec_id;
		}
		
		
		public static int getEndPointCharId(String strDeviceCharId, Connection connection) throws SQLException {
			int END_POINT_CHAR_ID = -1;
			TblEndPointCharDbBean endPointCharDbBean = new TblEndPointCharDbBean();
			ArrayList<TblEndPointCharDbBean> resultList = null;
			try {
				TblEndPointCharQuery endPointCharQuery = new TblEndPointCharQuery();
				endPointCharQuery.whereCharacteristicEQ(strDeviceCharId);
				endPointCharQuery.query(connection);

				resultList = endPointCharQuery.getResultArrayList();
				if (resultList.size() > 0) {
					endPointCharDbBean = (TblEndPointCharDbBean) resultList.get(0);
					END_POINT_CHAR_ID = endPointCharDbBean.getEndPointCharId();
					log.info("END_POINT_CHAR_ID:" + END_POINT_CHAR_ID);
				} else {
					log.info("END_POINT_CHAR_ID:" + -1);
					return -1;
				}

			} catch (SQLException e) {
				log.error(" getEndPointCharId()  exception {} ", e);
				log.info("ERROR: Exception caught while trying to get EndPointCharId from TblEndPointChar");
				log.info("END_POINT_CHAR_ID:" + -1);
				return -1;
			}

			return END_POINT_CHAR_ID;
		}


		//Changes done by Praveen Kumar
		
				public static String getValueWithoutOAction(EntityData entityData, String element) {
					return getValueWithoutOAction(getTableOrderDetaisParam(entityData, element));
				}
				
				public static String getValueWithoutOAction(TableOrderDetailsParam param) {
					return getValueWithoutOActionDefault(param, null);
				}
				
				public static String getValueWithoutOActionDefault(TableOrderDetailsParam param, String defVal) {
					String retVal = defVal;

					/*if ((param.getAction() == null))
						param.setAction("n");

					if ((param.getParamValue() == null))
					param.setParamValue("");*/
						
					if (param != null && !(isEmpty(param.getParamValue()) && (!"o".equalsIgnoreCase(param.getAction())))) {
						retVal = param.getParamValue();
					}
					
					return retVal;
				}
						
				
				
				// Changes finish

}
