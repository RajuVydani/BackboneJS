package com.vz.fxo.inventory.enterprise.helper;

import org.springframework.stereotype.Component;

import com.vz.esap.api.model.InventoryServiceRequest;
import com.vz.fxo.inventory.enterprise.GenericActionFunction;


@Component
public class FxoServiceHelper {

	/**
	 * 
	 * @param bsRequestEntity
	 * @return
	 */
	public static boolean validateRequest(InventoryServiceRequest bsRequestEntity) {
		// TODO
		return true;
	}
	

	/**
	 * @param bsRequestEntity
	 * @param entityType 
	 * @param obj
	 */
	public static void setRequestAttributes(InventoryServiceRequest bsRequestEntity,
			GenericActionFunction genericExecutor, String entityType) {

		genericExecutor.setAsyncFlag(bsRequestEntity.getAsyncFlag());
		genericExecutor.setClliCode(bsRequestEntity.getClliCode());
		genericExecutor.setLoopBackOn(bsRequestEntity.getLoopBackOn());
		genericExecutor.setConnType(bsRequestEntity.getConnType());
		genericExecutor.setSftwrLoad(bsRequestEntity.getSftwrLoad());
		genericExecutor
				.setWorkOrderNumber(bsRequestEntity.getWorkOrderNumber());
		genericExecutor.setWorkOrderNumberVersion(bsRequestEntity
				.getWorkOrderNumberVersion());
		genericExecutor.setEnvOrderId(bsRequestEntity.getEnvOrderId());
		genericExecutor.setOrderType(bsRequestEntity.getOrderType());
		genericExecutor.setWfServiceName(bsRequestEntity.getService());
		
		String entityTypeInReq = bsRequestEntity.getEntityType();
		if (ActionFunctionHelper.isEmpty(entityTypeInReq)){
			entityTypeInReq = "ENTERPRISE";//removed location type here--LOCATION
		}
		genericExecutor.setEntityType(entityTypeInReq);
		
		genericExecutor.setTask(bsRequestEntity.getTask());
		if (bsRequestEntity.getSeqNo() != null
				&& !"".equalsIgnoreCase(bsRequestEntity.getSeqNo().trim()))
			genericExecutor
					.setSeqNo(Long.parseLong(bsRequestEntity.getSeqNo()));
		if (bsRequestEntity.getOrderNumber() != null
				&& !"".equalsIgnoreCase(bsRequestEntity.getOrderNumber().trim()))
			genericExecutor.setOrderNumber(Long.parseLong(bsRequestEntity
					.getOrderNumber()));
	}
	/**
	 * 
	 * @param bsRequestEntity
	 * @param genericExecutor
	 */
	public static void setRequestAttributes(InventoryServiceRequest bsRequestEntity,
			GenericActionFunction genericExecutor) {
		setRequestAttributes(bsRequestEntity,genericExecutor,"");
	}

}
