
package com.vz.esap.api.generated.pojo;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "orderDetailId",
    "orderId",
    "dataType",
    "seqNo",
    "paramType",
    "action",
    "paramName",
    "paramValue",
    "parentId",
    "flowStatus",
    "leaf"
})
public class ParamDetail {

    @JsonProperty("orderDetailId")
    private Long orderDetailId;
    @JsonProperty("orderId")
    private Long orderId;
    @JsonProperty("dataType")
    private Long dataType;
    @JsonProperty("seqNo")
    private Long seqNo;
    @JsonProperty("paramType")
    private String paramType;
    @JsonProperty("action")
    private String action;
    @JsonProperty("paramName")
    private String paramName;
    @JsonProperty("paramValue")
    private Object paramValue;
    @JsonProperty("parentId")
    private Long parentId;
    @JsonProperty("flowStatus")
    private Long flowStatus;
    @JsonProperty("leaf")
    private Long leaf;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("orderDetailId")
    public Long getOrderDetailId() {
        return orderDetailId;
    }

    @JsonProperty("orderDetailId")
    public void setOrderDetailId(Long orderDetailId) {
        this.orderDetailId = orderDetailId;
    }

    @JsonProperty("orderId")
    public Long getOrderId() {
        return orderId;
    }

    @JsonProperty("orderId")
    public void setOrderId(Long orderId) {
        this.orderId = orderId;
    }

    @JsonProperty("dataType")
    public Long getDataType() {
        return dataType;
    }

    @JsonProperty("dataType")
    public void setDataType(Long dataType) {
        this.dataType = dataType;
    }

    @JsonProperty("seqNo")
    public Long getSeqNo() {
        return seqNo;
    }

    @JsonProperty("seqNo")
    public void setSeqNo(Long seqNo) {
        this.seqNo = seqNo;
    }

    @JsonProperty("paramType")
    public String getParamType() {
        return paramType;
    }

    @JsonProperty("paramType")
    public void setParamType(String paramType) {
        this.paramType = paramType;
    }

    @JsonProperty("action")
    public String getAction() {
        return action;
    }

    @JsonProperty("action")
    public void setAction(String action) {
        this.action = action;
    }

    @JsonProperty("paramName")
    public String getParamName() {
        return paramName;
    }

    @JsonProperty("paramName")
    public void setParamName(String paramName) {
        this.paramName = paramName;
    }

    @JsonProperty("paramValue")
    public Object getParamValue() {
        return paramValue;
    }

    @JsonProperty("paramValue")
    public void setParamValue(Object paramValue) {
        this.paramValue = paramValue;
    }

    @JsonProperty("parentId")
    public Long getParentId() {
        return parentId;
    }

    @JsonProperty("parentId")
    public void setParentId(Long parentId) {
        this.parentId = parentId;
    }

    @JsonProperty("flowStatus")
    public Long getFlowStatus() {
        return flowStatus;
    }

    @JsonProperty("flowStatus")
    public void setFlowStatus(Long flowStatus) {
        this.flowStatus = flowStatus;
    }

    @JsonProperty("leaf")
    public Long getLeaf() {
        return leaf;
    }

    @JsonProperty("leaf")
    public void setLeaf(Long leaf) {
        this.leaf = leaf;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(orderDetailId).append(orderId).append(dataType).append(seqNo).append(paramType).append(action).append(paramName).append(paramValue).append(parentId).append(flowStatus).append(leaf).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof ParamDetail) == false) {
            return false;
        }
        ParamDetail rhs = ((ParamDetail) other);
        return new EqualsBuilder().append(orderDetailId, rhs.orderDetailId).append(orderId, rhs.orderId).append(dataType, rhs.dataType).append(seqNo, rhs.seqNo).append(paramType, rhs.paramType).append(action, rhs.action).append(paramName, rhs.paramName).append(paramValue, rhs.paramValue).append(parentId, rhs.parentId).append(flowStatus, rhs.flowStatus).append(leaf, rhs.leaf).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
