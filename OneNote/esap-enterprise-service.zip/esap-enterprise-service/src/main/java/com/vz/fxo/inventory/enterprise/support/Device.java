package com.vz.fxo.inventory.enterprise.support;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import EsapEnumPkg.InvEnum;
import EsapEnumPkg.VzbVoipEnum;
import esap.db.DBTblDeviceMap;
import esap.db.IpcomDeviceXrefDbBean;
import esap.db.IpcomGatewayInfoDbBean;
import esap.db.TblDeviceMapDbBean;
import esap.db.TblDeviceMapQuery;
import esap.db.TblGatewayDeviceInfoDbBean;
import esap.db.TblGatewayDeviceInfoQuery;
import esap.db.TblGroupQuery;
import esap.db.TblPublicTnPoolQuery;
import esap.db.TblSipDeviceInfoDbBean;
import esap.db.TblSipDeviceInfoQuery;
import esap.db.TblSubscriberDeviceQuery;



public class Device extends DeviceBean
{
	private static Logger log = LoggerFactory.getLogger(Device.class.toString());
    //members
    private Connection connection;
    InvErrorCode status = InvErrorCode.INTERNAL_ERROR;
    private boolean rollbackFlag;
    private static ESAPDataManagerProps props;
    protected Connection ssiConnection = null;    
  
    public Device(Connection con)
    {
     connection = con;
	this.rollbackFlag = false;
	try {
		props = new ESAPDataManagerProps();
		props.getSSIConnProperties(connection);
	} catch (Exception e) {
		e.printStackTrace();
	}
   }

    public Device(Connection con, DeviceBean devBean)
    {
        super(devBean);
        connection = con;
	this.rollbackFlag = false;
    }
    
    public Device( IpcomGatewayInfoDbBean gwInfoBean,IpcomDeviceXrefDbBean devXref,Connection con)
    {
        super(gwInfoBean,devXref);
        connection = con;
	this.rollbackFlag = false;
    }

    //getters - setters
    public boolean getRollbackFlag()
    {
        return rollbackFlag;
    }

    public void setRollbackFlag(boolean rollbackFlag)
    {
        this.rollbackFlag = rollbackFlag;
    }

    public Connection getConnection()
    {
        return connection;
    }

    public void setConnection(Connection connection)
    {
        this.connection = connection;
    }

    public int getStatusCode()
    {
        return status.getErrorCode();
    }

    public void setStatus(InvErrorCode status)
    {
        this.status = status;
    }

    public String getStatusDesc()
    {
        return status.getErrorDesc();
    }

	public Connection getSsiConnection() throws Exception {
		try {
			 if(null == ssiConnection || ssiConnection.isClosed()) {
				 Class.forName(props.getSqlServerDriver());
				  ssiConnection = DriverManager.getConnection(props.getSsiUrl(), props.getSsiDbUser(), props.getSsiDbPassword());
			 }
			 ssiConnection.setAutoCommit(true);
			 return ssiConnection;
		} catch (SQLException sqle) {
		  throw sqle;
		}
	 }
    public boolean getDeviceDetailsBySipDeviceId()
    {
        log.info("In getDeviceDetailsBySipDeviceId");
        try
        {
            TblDeviceMapQuery dvMapQry = new TblDeviceMapQuery();
            if (getSipDeviceId() <= 0)
            {
                setStatus(InvErrorCode.MISSING_SIP_DEVICE_ID);
                log.info(status.getErrorDesc());
                return false;
            }
            //Sabareesh - modify where clause
            String whereClause = new String("");
			if(getAll == false)
            	whereClause = "where sip_device_id ="+getSipDeviceId() + " and active_ind = 1";
			else
            	whereClause = "where sip_device_id ="+getSipDeviceId() + " and active_ind != 0";
            dvMapQry.queryByWhere(connection,whereClause);

            if (dvMapQry.size() <= 0)
            {
                setStatus(InvErrorCode.NOTFOUND_DEVICE_MAP_QRY);
                log.info(status.getErrorDesc());
                return false;
            }
            for (int i = 0; i < dvMapQry.size(); i++)
            {
                TblDeviceMapDbBean deviceMapBean = dvMapQry.getDbBean(i);
                if (deviceMapBean.getSipDeviceId() > 0)
                {
                    log.info("Get Sip Device");
                    long sipDeviceId = deviceMapBean.getSipDeviceId();
                    TblSipDeviceInfoQuery sipDvQry = new TblSipDeviceInfoQuery();
                    Long sipDvId = Long.valueOf(sipDeviceId);
                    //Sabareesh - modifying the where clause
                    whereClause = "where sip_device_id = "+ sipDvId.toString();
                    sipDvQry.queryByWhere(connection, whereClause);
                    if (sipDvQry.size() > 0)
                    {
                        TblSipDeviceInfoDbBean sipDvBean = sipDvQry.getDbBean(0);
                        SipDevice sipDevice = new SipDevice(connection);
                        sipDevice.setSipDeviceId(sipDvBean.getSipDeviceId());
                        sipDevice.setDeviceName(sipDvBean.getDeviceName());
                        sipDevice.setDeviceTypeId(sipDvBean.getDeviceTypeId());
                        sipDevice.setMacAddress(sipDvBean.getMacAddress());
                        sipDevice.setSerialNumber(sipDvBean.getSerialNumber());
                        sipDevice.setPortsAvailable(sipDvBean.getPortsAvailable());
                        sipDevice.setCpeUserName(sipDvBean.getCpeUsername());
                        sipDevice.setCpePassword(sipDvBean.getCpePassword());
                        sipDevice.setCodecId(sipDvBean.getCodecId());
                        sipDevice.setBusinessLocation(sipDvBean.getBusinessLocation());
                        sipDevice.setStationLocation(sipDvBean.getStationLocation());
                        sipDevice.setDeviceLocation(sipDvBean.getDeviceLocation());
                        sipDevice.setFirmwareVersionId(sipDvBean.getFirmwareVersionId());
                        sipDevice.setIsManaged(sipDvBean.getIsManaged());
                        sipDevice.setEnvOrderId(sipDvBean.getEnvOrderId()); 
                        sipDevice.setCreatedBy(sipDvBean.getCreatedBy());
                        sipDevice.setModifiedBy(sipDvBean.getModifiedBy());
                        sipDevice.setCreationDate(sipDvBean.getCreationDate());
                        sipDevice.setLastModifiedDate(sipDvBean.getLastModifiedDate());
                        sipDevice.setInternalAdmin(sipDvBean.getInternalAdmin());
                        sipDvObjList.add(sipDevice);
                        populateDeviceBean(deviceMapBean);
                        break;
                    }
                } else
                {
                    setStatus(InvErrorCode.NOTFOUND_SIP_DEVICE_ID);
                    log.info(status.getErrorDesc());
                    return false;
                }
            }
            if (sipDvObjList.size() <= 0)
            {
                setStatus(InvErrorCode.NOTFOUND_DEVICE_DETAIL_BY_SIP_DEVICE_ID);
                log.info(status.getErrorDesc());
                return false;
            }
        }
        catch (SQLException e)
        {
            setStatus(InvErrorCode.DB_EXCEPTION);
            e.printStackTrace();
            return false;
        }

        setStatus(InvErrorCode.SUCCESS);

        return true;
    }

    public boolean getDeviceDetailsByGwDeviceId()
    {
        log.info("In getDeviceDetailsByGwDeviceId");
        try
        {
            TblDeviceMapQuery dvMapQry = new TblDeviceMapQuery();
            if (getGwDeviceId() <= 0)
            {
                setStatus(InvErrorCode.MISSING_GW_DEVICE_ID);
                log.info(status.getErrorDesc());
                return false;
            }
            //Sabareesh - modifying where Clause
            String whereClause = new String("");
			if(getAll == false)
            	whereClause = " where gateway_device_id = "+getGwDeviceId()  + " and active_ind = 1";
			else
            	whereClause = " where gateway_device_id = "+getGwDeviceId()  + " and active_ind != 0";
            dvMapQry.queryByWhere(connection,whereClause);
            if (dvMapQry.size() <= 0)
            {
                setStatus(InvErrorCode.NOTFOUND_DEVICE_DETAIL_BY_GW_DEVICE_ID);
                log.info(status.getErrorDesc());
                return false;
            }
            for (int i = 0; i < dvMapQry.size(); i++)
            {
                TblDeviceMapDbBean deviceMapBean = dvMapQry.getDbBean(i);
                if (deviceMapBean.getGatewayDeviceId() > 0)
                {
                    log.info("Get Gw Device");
                    long gwId = deviceMapBean.getGatewayDeviceId();
                    TblGatewayDeviceInfoQuery gwDvQry = new TblGatewayDeviceInfoQuery();
                    Long gwDvId = Long.valueOf(gwId);
                    //Sabareesh - modifying the where clause
                    whereClause = " where gateway_device_id = "+ gwDvId.toString();
                    gwDvQry.queryByWhere(connection, whereClause);
                    if (gwDvQry.size() > 0)
                    {
                        TblGatewayDeviceInfoDbBean gwDvBean = gwDvQry.getDbBean(0);
                        GatewayDevice gwDevice = new GatewayDevice(connection);
                        gwDevice.setGatewayDeviceId(gwDvBean.getGatewayDeviceId());
                        gwDevice.setDeviceName(gwDvBean.getDeviceName());
                        gwDevice.setDeviceTypeId(gwDvBean.getDeviceTypeId());
                        gwDevice.setGatewayAddress(gwDvBean.getGatewayAddress());
                        gwDevice.setGatewaySecAddress(gwDvBean.getGatewaySecAddress());
                        gwDevice.setCallingPartyFormat(gwDvBean.getCallingPartyFormat());
                        gwDevice.setTermCallingInd(gwDvBean.getTermCallingInd());
                        //gwDevice.setBrixInd(gwDvBean.getBrixInd());
                        gwDevice.setEnvOrderId(gwDvBean.getEnvOrderId()); 
                        gwDevice.setCreatedBy(gwDvBean.getCreatedBy());
                        gwDevice.setModifiedBy(gwDvBean.getModifiedBy());
                        gwDevice.setCreationDate(gwDvBean.getCreationDate());
                        gwDevice.setLastModifiedDate(gwDvBean.getLastModifiedDate());
                        //IR #1365577 Inventory Returning NONE for ScreenedTN , We need Send Value , if Value not there we need to Send null  
						log.info(" gwDvBean.getStnPoolId() " + gwDvBean.getStnPoolId() );
                        gwDevice.setSTnPoolId(gwDvBean.getStnPoolId());
                        log.info(" gwDevice.setSTnPoolId " + gwDevice.getSTnPoolId()); 
						gwDevice.setSTn(getTnByTnPoolId(gwDevice.getSTnPoolId()));
						gwDevice.setInternalAdmin(gwDevice.getInternalAdmin());
						
						// Jan 2013 ipversion changes
						gwDevice.setIpVersion((short)gwDvBean.getIpVersion());
						gwDevice.setPqInstanceId(gwDvBean.getPqInstanceId());
						log.info(" gwDevice.setSTn " + gwDevice.getSTn());
                        gwDvObjList.add(gwDevice); 
                        populateDeviceBean(deviceMapBean);
                        break;
                    }
                } else
                {
                    setStatus(InvErrorCode.MISSING_GW_DEVICE_ID);
                    log.info(status.getErrorDesc());
                    return false;
                }
            }
            if (gwDvObjList.size() <= 0)
            {
                setStatus(InvErrorCode.NOTFOUND_DEVICE_DETAIL_BY_GW_DEVICE_ID);
                log.info(status.getErrorDesc());
                return false;
            }
        }
        catch (SQLException e)
        {
            setStatus(InvErrorCode.DB_EXCEPTION);
            e.printStackTrace();
            return false;
        }
        setStatus(InvErrorCode.SUCCESS);
        return true;
    }

    public void populateDeviceBean(TblDeviceMapDbBean deviceBean)
    {
        setDeviceMapId(deviceBean.getDeviceMapId());
        setEnterpriseId(deviceBean.getEnterpriseId());
        setLocationId(deviceBean.getLocationId());
        setDepartmentId(deviceBean.getDepartmentId());
        setGwDeviceId(deviceBean.getGatewayDeviceId());
        setSipDeviceId(deviceBean.getSipDeviceId());
        setActiveInd(deviceBean.getActiveInd());
        setEnvOrderId(deviceBean.getEnvOrderId()); 
        setCreatedBy(deviceBean.getCreatedBy());
        setModifiedBy(deviceBean.getModifiedBy());
        setCreationDate(deviceBean.getCreationDate());
        setLastModifiedDate(deviceBean.getLastModifiedDate());
        setDeviceNameId(deviceBean.getDeviceNameId());
        return;
    }

    public boolean getDeviceDetailsByDeviceMapId() 
    {
        log.info("Entering Device::getDeviceDetailsByDeviceMapId");

        try
        {
            TblDeviceMapQuery deviceQry = new TblDeviceMapQuery();
            //Sabareesh - modifying the whereClause
            String whereClause = new String("");
			if(getAll == false)
            	whereClause = "where device_map_id = "+getDeviceMapId()  + " and active_ind = 1";
			else
            	whereClause = "where device_map_id = "+getDeviceMapId()  + " and active_ind != 0";
            deviceQry.queryByWhere(connection,whereClause);
            if (deviceQry.size() <= 0)
            {
                log.info("Device Map Id not Found");
                setStatus(InvErrorCode.NOTFOUND_DEVICE_MAP_QRY);
                return false;
            }
            TblDeviceMapDbBean deviceBean = deviceQry.getDbBean(0);
            populateDeviceBean(deviceBean);

            getDeviceDetails();
        }
        catch (SQLException e)
        {
            setStatus(InvErrorCode.DB_EXCEPTION);
            e.printStackTrace();
            return false;
        }

        setStatus(InvErrorCode.SUCCESS);
        return true;
    }

    private boolean getDeviceDetails() 
    {
        log.info("Entering Device::getDeviceDetails");

        if (getGwDeviceId() > 0)
        {
            log.info("Retrieve Gateway Device");
            GatewayDevice gwDevice = new GatewayDevice(connection);
            gwDevice.setGatewayDeviceId(getGwDeviceId());
            if (gwDevice.getGwDeviceDetailsByGatewayDeviceId() != true)
            {
                log.info("Failed to Retrieve Gateway Device");
                setStatus(InvErrorCode.NOTFOUND_DEVICE_DETAIL_BY_GW_DEVICE_ID);
                return false;
            }
            gwDvObjList.add(gwDevice);
        }
        if (getSipDeviceId() > 0)
        {
            log.info("Retrieve Sip Device");
            Long sipId = Long.valueOf(getSipDeviceId());
            SipDevice sipDevice = new SipDevice(connection);
            sipDevice.setSipDeviceId(sipId.intValue());
            if (sipDevice.getSipDeviceDetailsBySipDeviceId() != true)
            {
                log.info("Failed to Retrieve Sip Device");
                setStatus(InvErrorCode.NOTFOUND_DEVICE_DETAIL_BY_SIP_DEVICE_ID);
                return false;
            }
            sipDvObjList.add(sipDevice);
        }

        setStatus(InvErrorCode.SUCCESS);
        return true;
    }

    public boolean getDeviceIdListByEnterpriseId()
    {
        log.info("Entering Device::getDeviceListByEnterpriseId");

        try
        {
            TblDeviceMapQuery deviceQry = new TblDeviceMapQuery();
            //Sabareesh - modifying where Clause
			String whereClause = new String("");
            if(getAll == false)
                whereClause = "where enterprise_id = "+getEnterpriseId()  + " and active_ind = 1";
            else
                whereClause = "where enterprise_id = "+getEnterpriseId()  + " and active_ind != 0";

            deviceQry.queryByWhere(connection,whereClause);
            if (deviceQry.size() <= 0)
            {
                setStatus(InvErrorCode.NOTFOUND_DEVICE_LIST_BY_ENTERPRISE_ID);
                log.info(status.getErrorDesc());
                return false;
            }
            for (int i = 0; i < deviceQry.size(); i++)
            {
                deviceIdList.add((deviceQry.getDbBean(i)).getDeviceMapId());
            }
        }
        catch (SQLException e)
        {
            setStatus(InvErrorCode.DB_EXCEPTION);
            e.printStackTrace();
            return false;
        }

        setStatus(InvErrorCode.SUCCESS);
        return true;
    }

    public boolean getGatewayDeviceIdByEnterpriseId() throws SQLException, Exception
    {
        log.info("Entering Device::getGatewayDeviceIdListByEnterpriseId");

       // try
        //{
			log.info("In Device:getGatewayDeviceIdByEnterpriseId():getEnterpriseId"+getEnterpriseId());
            TblDeviceMapQuery deviceQry = new TblDeviceMapQuery();
            //Sabareesh - modifying the where Clause
            String whereClause = new String("");
			if(getAll == false)
            	whereClause = "where enterprise_id = \'"+getEnterpriseId()+"\' and gateway_device_id > 0  and active_ind = 1";
			else
            	whereClause = "where enterprise_id = \'"+getEnterpriseId()+"\' and gateway_device_id > 0  and active_ind != 0";
			log.info("whereClause:"+whereClause);
            deviceQry.queryByWhere(connection,whereClause);

            if (deviceQry.size() <= 0)
            {
                log.info("Gateway Device not Found");
                setStatus(InvErrorCode.NOTFOUND_DEVICE_DETAIL_BY_GW_DEVICE_ID);
                return false;
            }
			log.info("In Device:getGatewayDeviceIdByEnterpriseId():deviceQry.size():"+deviceQry.size());
            for (int i = 0; i < deviceQry.size(); i++)
            {
                gwDeviceIdList.add((deviceQry.getDbBean(i)).getGatewayDeviceId());
            }
        /*}
        catch (SQLException e)
        {
            setStatus(InvErrorCode.DB_EXCEPTION);
            e.printStackTrace();
            return false;
        }*/
        setStatus(InvErrorCode.SUCCESS);
        return true;
    }

    public boolean getGatewayDeviceIdListByLocationId()
    {
        log.info("Entering Device::getGatewayDeviceIdListByLocationId");

        try
        {
            TblDeviceMapQuery deviceQry = new TblDeviceMapQuery();
            //Sabareesh - modifying the where clause
            String whereClause = new String("");
			if(getAll == false)
            	whereClause = "where location_id = "+getLocationId()+" and gateway_device_id > 0 and active_ind = 1";
			else
             	whereClause = "where location_id = "+getLocationId()+" and gateway_device_id > 0 and active_ind != 0";
            deviceQry.queryByWhere(connection,whereClause);
            if (deviceQry.size() <= 0)
            {
                log.info("Gateway Device not Found");
                setStatus(InvErrorCode.NOTFOUND_DEVICE_DETAIL_BY_GW_DEVICE_ID);
                return false;
            }
            for (int i = 0; i < deviceQry.size(); i++)
            {
                gwDeviceIdList.add((deviceQry.getDbBean(i)).getGatewayDeviceId());
            }
        }
        catch (SQLException e)
        {
            setStatus(InvErrorCode.DB_EXCEPTION);
            e.printStackTrace();
            return false;
        }
        setStatus(InvErrorCode.SUCCESS);
        return true;
    }

    public boolean validateDevice() // device type as argument
    {
        return true;
    }

    public boolean addDeviceMap() throws SQLException, Exception
    {
        log.info("Entering Device::addDevice");
        log.info("GtwyDeviceId = " + getGwDeviceId());

        //try
        //{
            DBTblDeviceMap deviceDB = new DBTblDeviceMap();
            if(getDeviceMapId() > 0)
            {
                deviceDB.setDeviceMapId(getDeviceMapId());
            }
            else
            {
                int deviceSeqId = deviceDB.getDeviceMapIdSeqNextVal(connection);
                deviceDB.setDeviceMapId(deviceSeqId);
                setDeviceMapId(deviceSeqId);
            }

            if (getEnterpriseId() != "")
                deviceDB.setEnterpriseId(getEnterpriseId());
            if (getLocationId() != "")
                deviceDB.setLocationId(getLocationId());
            /*if (getDepartmentId() != "")
                deviceDB.setDepartmentId(getDepartmentId());*/
            //IR #1457935 Migration Failure while trying to migrate 
            if( !"".equalsIgnoreCase(getDepartmentId()) && !"NONE".equalsIgnoreCase(getDepartmentId())){
            	deviceDB.setDepartmentId(getDepartmentId());
            }
 
            if (getGwDeviceId() > 0)
                deviceDB.setGatewayDeviceId(getGwDeviceId());
            if (getSipDeviceId() > 0)
                deviceDB.setSipDeviceId(getSipDeviceId());
            deviceDB.setActiveInd(getActiveInd());
            if(getEnvOrderId() > 0)
            	deviceDB.setEnvOrderId(getEnvOrderId()); 
	    else
            	deviceDB.setEnvOrderIdNull(); 
            if (getModifiedBy() != null && !getModifiedBy().trim().equalsIgnoreCase(""))
                deviceDB.setModifiedBy(getModifiedBy());
            else
                deviceDB.setModifiedBy("ESAP_INV");

            if(getCreatedBy() != null && !getCreatedBy().trim().equalsIgnoreCase(""))
                deviceDB.setCreatedBy(getCreatedBy());
            else
                deviceDB.setCreatedBy("ESAP_INV");

            deviceDB.setLastModifiedDate(new Timestamp(System.currentTimeMillis()));
            deviceDB.setCreationDate(new Timestamp(System.currentTimeMillis()));
            
            if (getDeviceNameId()!=null && !getDeviceNameId().equals(""))
                deviceDB.setDeviceNameId(getDeviceNameId());
            
            FkValidationUtil.isValidDeviceMap(connection, deviceDB);
            deviceDB.insert(connection);
        /*}
        catch (SQLException s)
        {
            setStatus(InvErrorCode.DB_EXCEPTION);
            s.printStackTrace();
            return false;
        }*/
        return true;
    }

    public boolean deleteDevice() throws SQLException, Exception

    {
        log.info("Entering Device::deleteDevice");

//        try
 //       {
            if(getDeviceMapId() <= 0)
            {
                setStatus(InvErrorCode.INVALID_INPUT);
                return false;
            }
		log.info("Device::deleteDevice getDeviceMapId():"+getDeviceMapId());
		
		TblDeviceMapQuery devMapQry = new TblDeviceMapQuery();
		devMapQry.whereDeviceMapIdEQ(getDeviceMapId());
		devMapQry.query(connection);
		if(devMapQry.size() > 0)
		{
            		DBTblDeviceMap deviceDB = new DBTblDeviceMap();

            		deviceDB.whereDeviceMapIdEQ(getDeviceMapId());
            		deviceDB.deleteByWhere(connection);
			if((devMapQry.getDbBean(0)).getGatewayDeviceId() > 0)
			{
				log.info("in Device deleteDevice, gw device id > 0" + (devMapQry.getDbBean(0)).getGatewayDeviceId());
				GatewayDevice gwDev = new GatewayDevice(connection);
				gwDev.setGatewayDeviceId((devMapQry.getDbBean(0)).getGatewayDeviceId());
				gwDev.setEnvOrderId(getEnvOrderId());
				gwDev.deleteGatewayDevice();
			}
			if((devMapQry.getDbBean(0)).getSipDeviceId() > 0)
			{
				log.info("in Device deleteDevice, Sip device id > 0" + (devMapQry.getDbBean(0)).getSipDeviceId());
				SipDevice sipDev = new SipDevice(connection);
				sipDev.setSipDeviceId((int)(devMapQry.getDbBean(0)).getSipDeviceId());
				sipDev.deleteSipDevice();
			}

		}		
		else
			log.info("no entry in device_map table for this device map id");
		setStatus(InvErrorCode.NOTFOUND_DEVICE_MAP_QRY);
        /*}
        catch (SQLException s)
        {
            s.printStackTrace();
            setStatus(InvErrorCode.ERROR_DELETING_DEVICE_MAP);
            return false;
        }*/
       return true;
    }

    public boolean updateDevice() throws Exception,SQLException
    {
        /*try
        {*/
            if ( getDeviceMapId() <= 0) {
                setStatus(InvErrorCode.NOTFOUND_DEVICE_MAP_ID);
                log.info("FAILURE in updatedevice. DeviceMapId missing.");
                return false;
            }

            DBTblDeviceMap deviceMapBean = getDeviceToUpdate();
            deviceMapBean.whereDeviceMapIdEQ(getDeviceMapId()); 
            FkValidationUtil.isValidDeviceMapForMod(connection,deviceMapBean);
            deviceMapBean.updateSpByWhere(connection);
            if (deviceMapBean.updateSpByWhere(connection) <=0 ){
            	return false;	
            }    
     /*} catch(SQLException s) {
	    s.printStackTrace();
            setStatus(InvErrorCode.DB_EXCEPTION);
            log.info("DB_FAILURE in updateDevice");
            return false;
        } catch(Exception e) {
        	e.printStackTrace();
        	 setStatus(InvErrorCode.DB_EXCEPTION);
        	 return false;
        }*/
        setStatus(InvErrorCode.SUCCESS);
        return true;
    }

    /**
     * The current Device details are extracted using getDetails()
     * and the new field values are updated over that. The method
     * will update the fields that are supplied on the current instance
     * iff they are different from the default values for the respective field.
     *
     * @return The Device to be updated.
     * @throws SQLException 
     */
    private DBTblDeviceMap getDeviceToUpdate() throws SQLException {
        DBTblDeviceMap deviceDbBean = new DBTblDeviceMap();

        /* Create a new instance of DeviceBean. The new instance
         * would hold default values for the all the  Device fields.*/
        DeviceBean defaultDeviceBean = new DeviceBean();

        Device inputDevice = this;

        /*Set the new fields if required.*/
        deviceDbBean.setDeviceMapId(getDeviceMapId());

        if ( inputDevice.getEnterpriseId() != null &&
                !inputDevice.getEnterpriseId().equals(defaultDeviceBean.getEnterpriseId())){
            deviceDbBean.setEnterpriseId(inputDevice.getEnterpriseId());
                }

        if ( inputDevice.getLocationId() != null &&
                !inputDevice.getLocationId().equals(defaultDeviceBean.getLocationId())){
            deviceDbBean.setLocationId(inputDevice.getLocationId());
                }

        if ( inputDevice.getDepartmentId() != null &&
                !inputDevice.getDepartmentId().equals(defaultDeviceBean.getDepartmentId()) ){
        	if ( "".equals(inputDevice.getDepartmentId())){
        		deviceDbBean.setDepartmentIdNull();
        	}else{
        		deviceDbBean.setDepartmentId(inputDevice.getDepartmentId());
        	}
        }

        if ( inputDevice.getGwDeviceId() != defaultDeviceBean.getGwDeviceId()){
            deviceDbBean.setGatewayDeviceId(inputDevice.getGwDeviceId());
        }

        if ( inputDevice.getSipDeviceId() != defaultDeviceBean.getSipDeviceId()) {
            deviceDbBean.setSipDeviceId(inputDevice.getSipDeviceId());
        }
        if ( inputDevice.getActiveInd() != defaultDeviceBean.getActiveInd()) {
            deviceDbBean.setActiveInd(inputDevice.getActiveInd());
        }


        if ( inputDevice.getDepartmentId() != null &&
                !inputDevice.getDepartmentId().equals(defaultDeviceBean.getDepartmentId()) ){
            deviceDbBean.setDepartmentId(inputDevice.getDepartmentId());
                }
        if ( inputDevice.getEnvOrderId() != defaultDeviceBean.getEnvOrderId()) {
            deviceDbBean.setEnvOrderId(inputDevice.getEnvOrderId());
        }
        if (inputDevice.getModifiedBy() != null
			&& !("".equalsIgnoreCase(inputDevice.getModifiedBy()))) {
       		deviceDbBean.setModifiedBy(inputDevice.getModifiedBy());
	} else {
		deviceDbBean.setModifiedBy("ESAP_INV");
	}
        if ( inputDevice.getDeviceNameId() != defaultDeviceBean.getDeviceNameId()) {
            deviceDbBean.setDeviceNameId(inputDevice.getDeviceNameId());
        }
        deviceDbBean.setLastModifiedDate(new Timestamp(System.currentTimeMillis()));

        return deviceDbBean;
    }

    /**
     * @Param getDetails
     * @description: 
     * @return boolean
     * @author Thejas
     * @throws SQLException 
     * @editedby
     */
    public boolean getDetails() throws SQLException
    {
        try
        {
            log.info("In Device getDetails; Device Map id="+getDeviceMapId());
            TblDeviceMapQuery deviceQry = new TblDeviceMapQuery();
            String whereClause = new String("");
			if(getAll == false)
            	whereClause = " where device_map_id = \'"+getDeviceMapId()+"\'" + " and active_ind = 1";
			else
            	whereClause = " where device_map_id = \'"+getDeviceMapId()+"\'" + " and active_ind != 0";
            deviceQry.queryByWhere(connection, whereClause);
            if(deviceQry.size() == 1){
                setEnterpriseId((deviceQry.getDbBean(0)).getEnterpriseId());
                setLocationId((deviceQry.getDbBean(0)).getLocationId());
                setDepartmentId((deviceQry.getDbBean(0)).getDepartmentId());
                setGwDeviceId((deviceQry.getDbBean(0)).getGatewayDeviceId());
                setSipDeviceId((deviceQry.getDbBean(0)).getSipDeviceId());
                setActiveInd((deviceQry.getDbBean(0)).getActiveInd());
                setEnvOrderId((deviceQry.getDbBean(0)).getEnvOrderId()); 
                setModifiedBy((deviceQry.getDbBean(0)).getModifiedBy());
                setCreatedBy((deviceQry.getDbBean(0)).getCreatedBy());
                setCreationDate((deviceQry.getDbBean(0)).getCreationDate());
                setDeviceNameId((deviceQry.getDbBean(0)).getDeviceNameId());
            }else
            {
                setStatus(InvErrorCode.NOTFOUND_DEVICE_MAP_QRY);
                return false;
            }

        }catch(SQLException s)
        {
	    s.printStackTrace();
            setStatus(InvErrorCode.DB_EXCEPTION);
            return false;
        }
        setStatus(InvErrorCode.SUCCESS);
        return true;
    }

    public List<Long> getICPDevices(String locationId) {
    	log.info("Inside getICPDevices method and locationId is "+locationId);
        List<Long> deviceList = null;
        Connection ssiConnection = null;
        PreparedStatement ssiPstmnt = null;
        ResultSet ssiRes = null;
        String query = "select intResourceID as deviceId from tacresourcehierarchy with (nolock) where intcategoryid = ? and intlocationorgid=? and intresourceid in (select intDeviceResourceId from tACPBXGroup with (nolock))";
        
        try {
         	ssiConnection = getSsiConnection();
        	//ssiPstmnt = ssiConnection.prepareStatement("select distinct intResourceID as deviceId from tacresourcehierarchy with (nolock) where intcategoryid = ? and intlocationorgid = ? ");
        	ssiPstmnt = ssiConnection.prepareStatement(query);
        	ssiPstmnt.setLong(1,1013);
            ssiPstmnt.setString(2,locationId);
            log.info("Query is  "+ query);
            log.info("Input 1 = 1013 ");
            log.info("Input 2 = "+ locationId);
            ssiRes = (ResultSet)ssiPstmnt.executeQuery();
            if(ssiRes!=null) {
            	deviceList = new ArrayList<Long>();
                while(ssiRes.next()) {
                	deviceList.add(ssiRes.getLong("deviceId"));
                }
                
            }
        }catch(Exception e) {
            e.printStackTrace();
        }
        finally {
				try {
					if (ssiRes != null)
						ssiRes.close();
					if (ssiPstmnt != null)
						ssiPstmnt.close();
					if (ssiConnection != null)
						ssiConnection.close();
					} catch (SQLException e) {
						e.printStackTrace();
					}
			}
		return deviceList;
    }

    
    public List<Long> getICPLocationsbyDeviceId(String deviceId) {
	log.info("Inside getICPLocationsbyDeviceId method and device id is "+deviceId);
    List<Long> deviceList = null;
    Connection ssiConnection = null;
    PreparedStatement ssiPstmnt = null;
    ResultSet ssiRes = null;
    String query = "select intlocationorgid as locationId from tacresourcehierarchy with (nolock) where intcategoryid = ? and intresourceid=?";
    try {
     	ssiConnection = getSsiConnection();
    	ssiPstmnt = ssiConnection.prepareStatement(query);
    	ssiPstmnt.setLong(1,1013);
        ssiPstmnt.setString(2,deviceId);
        log.info("Query is  "+ query);
        log.info("Input 1 = 1013 ");
        log.info("Input 2 = "+ deviceId);
        ssiRes = (ResultSet)ssiPstmnt.executeQuery();
        if(ssiRes!=null) {
        	deviceList = new ArrayList<Long>();
            while(ssiRes.next()) {
            	deviceList.add(ssiRes.getLong("locationId"));
            }
            
        }
    }catch(Exception e) {
        e.printStackTrace();
    }
    finally {
			try {
				if (ssiRes != null)
					ssiRes.close();
				if (ssiPstmnt != null)
					ssiPstmnt.close();
				if (ssiConnection != null)
					ssiConnection.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
		}
	return deviceList;
}

    
    public String getTnByTnPoolId(long tnPoolId)
    {
        log.info("Entering Location::getTnByTnPoolId");
        String tn = null;
        try
        {
            TblPublicTnPoolQuery tnQry = new TblPublicTnPoolQuery();
            tnQry.whereTnPoolIdEQ((int) tnPoolId);
            tnQry.query(connection);
            if (tnQry.size() <= 0)
            {
                log.info("TN [" + tn + "] Not Found");
                return tn;
            }
            tn = tnQry.getDbBean(0).getTn();
            log.info("Retrieved TN [" + tn + "] For TnId [" + tnPoolId + "]");
        }
        catch (SQLException e)
        {
            setStatus(InvErrorCode.DB_EXCEPTION);
            log.info("Failed to retrieve TN");
            e.printStackTrace();
            return tn;
        }
        setStatus(InvErrorCode.SUCCESS);
        log.info("Successfully retrived TN");
        return tn;
    }

	public boolean getSubIdOrGroupIdListByDeviceMapId()
    {
        log.info("Entering getSubIdOrGroupIdListByDeviceMapId");
        try
        {
			if(deviceMapId <= 0)
			{
				log.info("Invalid Device Map Id [" + deviceMapId + "]");
				return false;
			}

			TblGroupQuery gQry = new TblGroupQuery();
			gQry.whereDeviceMapIdEQ(deviceMapId);
			gQry.query(connection);	

            if (gQry.size() > 0)
			{
				log.info("Found [" + gQry.size() + "] Groups Associated to Device Map Id [" + deviceMapId + "]");
				groupIdList = new ArrayList<String>();
				for(int i=0; i<gQry.size(); i++)
				{
					log.info("Retrieved Group Id [" + gQry.getDbBean(i).getGroupId() + "]");
					groupIdList.add(Integer.toString(gQry.getDbBean(i).getGroupId()));
				}
			}
			else
                log.info("No Groups Found By Device Map Id ["+ deviceMapId + "]");
			
			TblSubscriberDeviceQuery sQry = new TblSubscriberDeviceQuery();
			sQry.whereDeviceMapIdEQ(deviceMapId);
			sQry.query(connection);

			if(sQry.size() > 0)
			{
				log.info("Found [" + sQry.size() + "] Subcsriber Associated to Device Map Id [" + deviceMapId + "]");
				subIdList = new ArrayList<String>();
				for(int i=0; i<sQry.size(); i++)
                    subIdList.add(sQry.getDbBean(i).getSubId());
			}
			else
                log.info("No Subscriber Found By Device Map Id ["+ deviceMapId + "]");
        }
        catch (SQLException e)
        {
            setStatus(InvErrorCode.DB_EXCEPTION);
            log.info("Failed to retrieve Device");
            e.printStackTrace();
            return false;
        }
        setStatus(InvErrorCode.SUCCESS);
        log.info("Successfully retrived Subscriber/Group By Device");
        return true;
    }
	
	
	 public int getSupportedIpVersionsOfDevicesByLocationId(String location_id) throws SQLException
	    {
	        log.info("Entering Device::getSupportedIpVersionsOfDevicesByLocationId for location " + location_id);	        

	        int ipversion_support = 0;
	        
	        boolean ipv4 = false;
	        boolean ipv6 = false;
	        
	        try
	        {
	            TblDeviceMapQuery deviceQry = new TblDeviceMapQuery();	          
	            String whereClause = new String("");
				whereClause = "where location_id = '"+location_id+"' and gateway_device_id > 0 and active_ind = 1";				
				log.info("whereClause :" + whereClause);				
	            deviceQry.queryByWhere(connection,whereClause);
	            	            
	            if (deviceQry.size() <= 0)
	            {
	                log.info("Gateway Device not Found in tbl_device_map.Hence returning zero.");
	                return ipversion_support;
	            }
	            
	            long gateway_device_id = 0;
	            for (int i = 0; i < deviceQry.size(); i++)
	            {
	            	gateway_device_id = deviceQry.getDbBean(i).getGatewayDeviceId();
	            	
	            	if (gateway_device_id > 0){
	                 	TblGatewayDeviceInfoQuery gatewayDeviceQuery = new TblGatewayDeviceInfoQuery();
	            	    gatewayDeviceQuery.whereGatewayDeviceIdEQ((int)gateway_device_id);
	            	    gatewayDeviceQuery.query(connection);
	            	
		            	 if (gatewayDeviceQuery.size() <= 0)
		 	            {
		 	                log.info("Gateway Device not Found in tbl_gateway_device_info for the gateway_device_id" + gateway_device_id);	 	                
		 	                throw new SQLException();
		 	            }else{	 	            	
		 	            	short ipversion = gatewayDeviceQuery.getDbBean(0).getIpVersion();
		 	            	if (ipversion == VzbVoipEnum.IPVersion.IPV4){
		 	            		ipv4 = true;		 	            			 	       
		 	            	}else if (ipversion == VzbVoipEnum.IPVersion.IPV6){
		 	            		ipv6 = true;		 	            		
		 	            	} 	            	
		 	            } 	            	 
	            	} 
	            }	            
	            if (ipv4 == true && ipv6 == true)
	            	ipversion_support = InvEnum.ipVERSION_SUPPORT.IPV4_AND_IPV6_SUPPORT;
            	else if(ipv4 == true && ipv6 == false)
            		ipversion_support = InvEnum.ipVERSION_SUPPORT.ONLY_IPV4_SUPPORT;
            	else if (ipv6 == true && ipv4 == false)
            		ipversion_support = InvEnum.ipVERSION_SUPPORT.ONLY_IPV6_SUPPORT; 
	        }
	        catch (SQLException e)
	        {
	        	 log.info("Unable to find the devices for the location");	 
	        	 return InvEnum.ipVERSION_SUPPORT.ONLY_IPV4_SUPPORT;
	        }
	        
	        log.info(" Returning ipversion_support =  " + ipversion_support);
	        return ipversion_support;
	    }
	
	//To get IPVersion for the device which are yet to provisioned in the INV DB, getting info based on ENV ORDER ID
	 public int getSupportedIpVersionsOfDevicesByEnvOrderId(String env_order_id) throws SQLException
	 {

       log.info("Entering Device::getSupportedIpVersionsOfDevicesByEnvOrderId for env_order_id " + env_order_id);
	        if(env_order_id == null  || "".equals(env_order_id)) {
				log.info("env_order_id is null");
				return -1;   
			}	
			
			StringBuffer sql = new StringBuffer();
	        PreparedStatement pStmt = null;
			ResultSet rs = null;
			
	        int ipversion_support = 0;
	        
	        boolean ipv4 = false;
	        boolean ipv6 = false;
	        
	        try
	        {
	        	sql.append ("Select param_value From Tbl_Order_Details Where Order_Id In (Select Order_Id From Tbl_Order Where Env_Order_Id = "+env_order_id+" And Upstream_Task_Id = '4') and PARAM_NAME = 'IPVersion'"); 
	        	log.info(" Sql  " + sql.toString() );
	        		        	
	        	pStmt = connection.prepareStatement(sql.toString());
	            if (pStmt != null){
		    
	            	rs = pStmt.executeQuery();
	  	            while ( rs.next()){		                    		
	  	              	if(rs.getString(1).equalsIgnoreCase("IPv4")) {
	  	               		ipv4 = true;
	  	               	} else {
	  	               		ipv6 = true;
	  	               	}			
	  	            }    
	  	        } else {
	  	        	log.info("There is no device associated to the env_order_id "+env_order_id+". Hence returning zero.");
	                return ipversion_support;
	  	        } 
	        	
	            if (ipv4 == true && ipv6 == true)
	            	ipversion_support = InvEnum.ipVERSION_SUPPORT.IPV4_AND_IPV6_SUPPORT;
	            else if(ipv4 == true && ipv6 == false)
	            	ipversion_support = InvEnum.ipVERSION_SUPPORT.ONLY_IPV4_SUPPORT;
	            else if (ipv6 == true && ipv4 == false)
	            	ipversion_support = InvEnum.ipVERSION_SUPPORT.ONLY_IPV6_SUPPORT; 	            
	          
	        }
	        catch (SQLException e)
	        {
	        	 log.info("Unable to find the devices for the env_order_id"+env_order_id);	 
	        	 return 0;
	        }finally{
	        	if(rs !=null){
	        		rs.close();
	        		rs = null;
	        	}
	        	if(pStmt != null){
	        		pStmt.close();
	        		pStmt = null;
	        	}
	        }
	        
	        log.info(" Returning ipversion_support =  " + ipversion_support);
	        return ipversion_support;
	    }		
}
