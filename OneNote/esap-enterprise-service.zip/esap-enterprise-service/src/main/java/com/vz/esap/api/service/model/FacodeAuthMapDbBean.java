package com.vz.esap.api.service.model;

import java.io.Serializable;

import esap.db.TblFacodeAuthMapDbBean;

public class FacodeAuthMapDbBean implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private int facodeAuthMapId;
	private long facodeFeatureId;
	private long authFeatureId;

	public String toString() {
		return "facodeAuthMapId=" + this.facodeAuthMapId + "\n" + "facodeFeatureId=" + this.facodeFeatureId + "\n"
				+ "authFeatureId=" + this.authFeatureId + "\n";
	}

	public void setFacodeAuthMapId(int facodeAuthMapId) {
		this.facodeAuthMapId = facodeAuthMapId;
	}

	public int getFacodeAuthMapId() {
		return this.facodeAuthMapId;
	}

	public void setFacodeFeatureId(long facodeFeatureId) {
		this.facodeFeatureId = facodeFeatureId;
	}

	public long getFacodeFeatureId() {
		return this.facodeFeatureId;
	}

	public void setAuthFeatureId(long authFeatureId) {
		this.authFeatureId = authFeatureId;
	}

	public long getAuthFeatureId() {
		return this.authFeatureId;
	}

	public void copyFrom(TblFacodeAuthMapDbBean obj) {
		setFacodeAuthMapId(obj.getFacodeAuthMapId());
		setFacodeFeatureId(obj.getFacodeFeatureId());
		setAuthFeatureId(obj.getAuthFeatureId());
	}
}
