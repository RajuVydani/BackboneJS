package com.vz.fxo.inventory.enterprise.actionfunction;

import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.vz.esap.api.model.ESAPEntityEnum;
import com.vz.esap.api.model.dto.OrderDomainServiceDTO;
import com.vz.esap.api.model.ordering.EntityBatch;
import com.vz.esap.api.model.ordering.EntityData;
import com.vz.esap.api.model.ordering.TableOrderDetailsParam;

import com.vz.fxo.inventory.enterprise.support.CallingPlan;
import com.vz.fxo.inventory.enterprise.support.DigitString;
import com.vz.fxo.inventory.enterprise.support.DigitStringBean;
import com.vz.fxo.inventory.enterprise.support.Enterprise;
import com.vz.fxo.inventory.enterprise.support.TblEntBillFeaturesBean;
import com.vz.fxo.inventory.enterprise.support.VzbInvException;
import com.vz.fxo.inventory.enterprise.GenericActionFunction;
import com.vz.fxo.inventory.enterprise.helper.ActionFunctionHelper;
import com.vz.fxo.inventory.enterprise.helper.EnterpriseHelper;

import EsapEnumPkg.VzbVoipEnum;
import esap.db.TblDepartmentQuery;

import static com.vz.fxo.inventory.enterprise.helper.ActionFunctionHelper.*;

import static com.vz.fxo.inventory.enterprise.helper.TNActionFunction.*;

import static com.vz.fxo.inventory.enterprise.helper.EnterpriseActionFunctionHelper.*;

public class VZB_INV_MOD_ENTERPRISE_FXO extends GenericActionFunction {

	private static Logger log = LoggerFactory.getLogger(VZB_INV_MOD_ENTERPRISE_FXO.class.toString());

	public int order_id = -1;
	private EnterpriseHelper enterpriseHelper = new EnterpriseHelper();
    Enterprise enterprise = null;
    Enterprise invEntObj = null;
	@Override
	public int go() {
		log.info("Task VZB_INV_MOD_ENTERPRISE Started WorkOrderNumber : {}", this.workOrderNumber);
		try {

			entityType = ESAPEntityEnum.ENTERPRISE;
			OrderDomainServiceDTO domainServiceDTO = getOrderDomainDetail(entityType);
			Map<String, EntityBatch> entityTypeMap = domainServiceDTO.getEntityTypeMap();
			EntityBatch entityBatch = entityTypeMap.get(entityType.toString());
			// cleanEntityBatchSetCommonFields(entityBatch, this.orderNumber);

			enterpriseId = getEnterpriseId(entityBatch);
			checkForNull("EnterpriseId", enterpriseId);

			Map<String, EntityData> entityMap = entityBatch.getEntity();
			EntityData entityData = entityMap.entrySet().iterator().next().getValue();

		//	Enterprise enterprise = new Enterprise(connection);
			enterprise = enterpriseHelper.getEnterprise(connection);
			//Enterprise invEntObj = new Enterprise(connection);
			invEntObj = enterpriseHelper.getEnterprise(connection);
			//
			
			enterprise.setDbCon(connection);
			// ParamDetail addParamList = getNewParamList();
			// ParamDetail addParamList = getAddParamList();
			String paramValue = "";
			TableOrderDetailsParam param = null;

			/*****************
			 * Information available on order will be set here
			 ******/
			/*********** ORDERING fields starts here ****/

			/*
			 * if (!( addParamList.getByNameSearch("CustomerId") == null ))
			 * enterprise.setEnterpriseId(addParamList.getByNameSearch(
			 * "CustomerId").getParamValue());
			 */

			if ((paramValue = getValueWithoutOAction(entityData, "CustomerId")) != null) {
				enterprise.setEnterpriseId(paramValue);
				enterprise.setCustomerId(paramValue);
				invEntObj.setEnterpriseId(paramValue);
			}

			/*
			 * if (!( addParamList.getByNameSearch("CustomerId") == null ))
			 * enterprise.setCustomerId(addParamList.getByNameSearch(
			 * "CustomerId").getParamValue());
			 */

			// invEntObj.setEnterpriseId(addParamList.getByNameSearch("CustomerId").getParamValue());
			invEntObj.getDetails();

			/*
			 * if (!( addParamList.getByNameSearchWithAction("BsAppServer", "n")
			 * == null)) {
			 * if(!(addParamList.getByNameSearchWithAction("BsAppServer",
			 * "n").getParamValue() == null) &&
			 * !addParamList.getByNameSearchWithAction("BsAppServer",
			 * "n").getParamValue().equals(""))
			 * enterprise.setAsId(Integer.parseInt(addParamList.
			 * getByNameSearchWithAction("BsAppServer", "n").getParamValue()));
			 * else enterprise.setAsId(0); }
			 */

			if ((param = getTableOrderDetaisParamWithAction(entityData, "BsAppServer", "n")) != null) {
				enterprise.setAsId(Integer.parseInt(getValueWithoutOActionDefault(param, "0")));
			}

			if ((param = getTableOrderDetaisParamWithAction(entityData, "CustomerName", "n")) != null) {
				enterprise.setAccountName(getValueWithoutOActionDefault(param, ""));
				enterprise.setCustomerName(getValueWithoutOActionDefault(param, ""));
			}

			/*
			 * if (!( addParamList.getByNameSearchWithAction("CustomerName",
			 * "n") == null )) {
			 * if(!(addParamList.getByNameSearchWithAction("CustomerName",
			 * "n").getParamValue() == null) &&
			 * !addParamList.getByNameSearchWithAction("CustomerName",
			 * "n").getParamValue().equals(""))
			 * enterprise.setAccountName(addParamList.getByNameSearchWithAction(
			 * "CustomerName", "n").getParamValue()); else
			 * enterprise.setAccountName(""); }
			 * 
			 * if (!( addParamList.getByNameSearchWithAction("CustomerName",
			 * "n") == null )) {
			 * if(!(addParamList.getByNameSearchWithAction("CustomerName",
			 * "n").getParamValue() == null) &&
			 * !addParamList.getByNameSearchWithAction("CustomerName",
			 * "n").getParamValue().equals(""))
			 * enterprise.setCustomerName(addParamList.getByNameSearchWithAction
			 * ("CustomerName", "n").getParamValue()); else
			 * enterprise.setCustomerName(""); }
			 */

			// Changed for IR #2423825 to avoid unnecessary updates
			/*
			 * if (!( addParamList.getByNameSearchWithAction("RegionType", "n")
			 * == null )) {
			 * enterprise.setRegionId(VzbVoipEnum.RegionType.valueByAcronym(
			 * addParamList.getByNameSearch("RegionType").getParamValue()));
			 * if(enterprise.getRegionId() == VzbVoipEnum.RegionType.EMEA)
			 * enterprise.setCustMarket(VzbVoipEnum.CustMarketType.EMEA); else
			 * enterprise.setCustMarket(VzbVoipEnum.CustMarketType.US);
			 * 
			 * }
			 */

			if ((param = getTableOrderDetaisParamWithAction(entityData, "RegionType", "n")) != null) {
				enterprise.setRegionId(
						VzbVoipEnum.RegionType.valueByAcronym(getValueWithoutOAction(entityData, "RegionType")));
				if (enterprise.getRegionId() == VzbVoipEnum.RegionType.EMEA)
					enterprise.setCustMarket(VzbVoipEnum.CustMarketType.EMEA);
				else
					enterprise.setCustMarket(VzbVoipEnum.CustMarketType.US);
			}

			// Jan 2011 Release Changes - For APAC MarKetType will be there.
			if ((param = getTableOrderDetaisParamWithAction(entityData, "MarKetType", "n")) != null) {
				enterprise.setCustMarket(Integer.parseInt(param.getParamValue()));
			}

			log.info(" Market Type " + enterprise.getCustMarket());

			/*
			 * if (!(
			 * addParamList.getByNameSearchWithAction("OriginatingSystem", "n")
			 * == null )) {
			 * if(!(addParamList.getByNameSearchWithAction("OriginatingSystem",
			 * "n").getParamValue() == null) &&
			 * !addParamList.getByNameSearchWithAction("OriginatingSystem",
			 * "n").getParamValue().equals(""))
			 * enterprise.setOrderSource(addParamList.getByNameSearchWithAction(
			 * "OriginatingSystem", "n").getParamValue()); else
			 * enterprise.setOrderSource(""); }
			 */

			if ((param = getTableOrderDetaisParamWithAction(entityData, "OriginatingSystem", "n")) != null) {

				// if ((paramValue =
				// getTableOrderDetaisParamValueWithAction(entityData,"OriginatingSystem",
				// "n")) != null && !isEmpty(paramValue)) {

				enterprise.setOrderSource(getValueWithoutOActionDefault(param, ""));
				enterprise.setCreatedBy(getValueWithoutOActionDefault(param, ""));
				enterprise.setModifiedBy(getValueWithoutOActionDefault(param, ""));
				// }

			} else {
				enterprise.setCreatedBy("SYSTEM");
				enterprise.setModifiedBy("SYSTEM");
			}

			/*
			 * if (!(
			 * addParamList.getByNameSearchWithAction("OriginatingSystem", "n")
			 * == null )) {
			 * if(!(addParamList.getByNameSearchWithAction("OriginatingSystem",
			 * "n").getParamValue() == null) &&
			 * !addParamList.getByNameSearchWithAction("OriginatingSystem",
			 * "n").getParamValue().equals("")) {
			 * enterprise.setCreatedBy(addParamList.getByNameSearchWithAction(
			 * "OriginatingSystem", "n").getParamValue());
			 * enterprise.setModifiedBy(addParamList.getByNameSearchWithAction(
			 * "OriginatingSystem", "n").getParamValue()); } else {
			 * enterprise.setCreatedBy(""); enterprise.setModifiedBy(""); } }
			 * else { enterprise.setCreatedBy("SYSTEM");
			 * enterprise.setModifiedBy("SYSTEM"); }
			 */

			// Mar 2013 Release - E2EI
			/*
			 * if (addParamList.getByNameSearchWithAction("LORID", "n") != null)
			 * { String lorId = addParamList.getByNameSearchWithAction("LORID",
			 * "n").getParamValue(); if (lorId != null && !"".equals(lorId)) {
			 * enterprise.setLorId(lorId); } } else if
			 * (addParamList.getByNameSearchWithAction("LorId", "n") != null) {
			 * String lorId = addParamList.getByNameSearchWithAction("LorId",
			 * "n").getParamValue(); if (lorId != null && !"".equals(lorId)) {
			 * enterprise.setLorId(lorId); } }
			 */
			if ((param = getTableOrderDetaisParamWithAction(entityData, "LORID", "n")) != null) {

				if ((paramValue = getTableOrderDetaisParamValueWithAction(entityData, "LORID", "n")) != null
						&& !isEmpty(paramValue)) {
					enterprise.setLorId(paramValue);
				}

			} else if ((param = getTableOrderDetaisParamWithAction(entityData, "LorId", "n")) != null) {

				if ((paramValue = getTableOrderDetaisParamValueWithAction(entityData, "LorId", "n")) != null
						&& !isEmpty(paramValue)) {
					enterprise.setLorId(paramValue);
				}
			}

			/*
			 * if (addParamList.getByNameSearchWithAction("Address", "n") !=
			 * null) { String val =
			 * addParamList.getByNameSearchWithAction("Address",
			 * "n").getParamValue(); if (val != null && !"".equals(val)) {
			 * enterprise.setAddress(val); } }
			 */

			if ((param = getTableOrderDetaisParamWithAction(entityData, "Address", "n")) != null) {

				if ((paramValue = getTableOrderDetaisParamValueWithAction(entityData, "Address", "n")) != null
						&& !isEmpty(paramValue)) {
					enterprise.setAddress(paramValue);
				}

			}

			if ((param = getTableOrderDetaisParamWithAction(entityData, "City", "n")) != null) {

				if ((paramValue = getTableOrderDetaisParamValueWithAction(entityData, "City", "n")) != null
						&& !isEmpty(paramValue)) {
					enterprise.setCity(paramValue);
				}

			}

			/*
			 * if (addParamList.getByNameSearchWithAction("City", "n") != null)
			 * { String val = addParamList.getByNameSearchWithAction("City",
			 * "n").getParamValue(); if (val != null && !"".equals(val)) {
			 * enterprise.setCity(val); } }
			 */

			/*
			 * if (addParamList.getByNameSearchWithAction("State", "n") != null)
			 * { String val = addParamList.getByNameSearchWithAction("State",
			 * "n").getParamValue(); if (val != null && !"".equals(val)) {
			 * enterprise.setState(val); } }
			 */

			if ((param = getTableOrderDetaisParamWithAction(entityData, "State", "n")) != null) {

				if ((paramValue = getTableOrderDetaisParamValueWithAction(entityData, "State", "n")) != null
						&& !isEmpty(paramValue)) {
					enterprise.setState(paramValue);
				}

			}

			/*
			 * if (addParamList.getByNameSearchWithAction("Zip", "n") != null) {
			 * String val = addParamList.getByNameSearchWithAction("Zip",
			 * "n").getParamValue(); if (val != null && !"".equals(val)) {
			 * enterprise.setZip(val); } }
			 */

			if ((param = getTableOrderDetaisParamWithAction(entityData, "Zip", "n")) != null) {

				if ((paramValue = getTableOrderDetaisParamValueWithAction(entityData, "Zip", "n")) != null
						&& !isEmpty(paramValue)) {
					enterprise.setZip(paramValue);
				}

			}

			/*
			 * if (addParamList.getByNameSearchWithAction("Country", "n") !=
			 * null) { String val =
			 * addParamList.getByNameSearchWithAction("Country",
			 * "n").getParamValue(); if (val != null && !"".equals(val)) {
			 * enterprise.setCountry(val); } }
			 */

			if ((param = getTableOrderDetaisParamWithAction(entityData, "Country", "n")) != null) {

				if ((paramValue = getTableOrderDetaisParamValueWithAction(entityData, "Country", "n")) != null
						&& !isEmpty(paramValue)) {
					enterprise.setCountry(paramValue);
				}

			}

			// IR #2579397
			/*
			 * if (addParamList.getByNameSearchWithAction("HybridService", "n")
			 * != null) { String val =
			 * addParamList.getByNameSearchWithAction("HybridService",
			 * "n").getParamValue(); if (val != null && !"".equals(val)) {
			 * enterprise.setHybridInd(Short.parseShort(val)); } }
			 */

			if ((param = getTableOrderDetaisParamWithAction(entityData, "HybridService", "n")) != null) {

				if ((paramValue = getTableOrderDetaisParamValueWithAction(entityData, "HybridService", "n")) != null
						&& !isEmpty(paramValue)) {
					enterprise.setHybridInd(Short.parseShort(paramValue));
				}

			}

			// Mar 2013 VoipTrunkingServiceOptimization IR #2573726

			// if("1".equals(enterprise.getSoEnabled())) {
			/*
			 * if(addParamList.getByNameSearch("SOEnabled").getParamValue() !=
			 * null) log.info(" SOENABLED =  "
			 * +addParamList.getByNameSearch("SOEnabled").getParamValue());
			 */

			if (((paramValue = getValueWithoutOAction(entityData, "SOEnabled")) != null)
					&& ("1".equalsIgnoreCase(paramValue))) {
				log.info("in side this");

				// If the region is US, have to modify only USLDAndLocalBestPool
				// and USLDOnlyBestPool
				// If the region is EMEA or APAC, have to modify only
				// EmeaApacBestPool
				long poolValues = 0;

				long plusPoolValues = 0;

				if (((paramValue = getValueWithoutOAction(entityData, "Region")) != null)
						&& ("US".equalsIgnoreCase(paramValue))) {
					log.info("in side US");
					if ((param = getTableOrderDetaisParamWithAction(entityData, "USLDAndLocalBestPool", "n")) != null) {
						log.info("in side USLDAndLocalBestPool ... ");

						enterprise.setUsLdAndLocalBestPool(Long.parseLong(getValueWithoutOActionDefault(param, "0")));
						poolValues = Long.parseLong(getValueWithoutOActionDefault(param, "0"));

					} else {
						poolValues = invEntObj.getUsLdAndLocalBestPool();
					}

					if ((param = getTableOrderDetaisParamWithAction(entityData, "USLDOnlyBestPool", "n")) != null) {
						log.info("in side USLD");

						enterprise.setUsLdOnlyBestPool(Long.parseLong(getValueWithoutOActionDefault(param, "0")));
						poolValues = poolValues + Long.parseLong(getValueWithoutOActionDefault(param, "0"));

					} else {
						poolValues = poolValues + invEntObj.getUsLdOnlyBestPool();
					}
					// enterprise.setEntTrunkCclSum(poolValues);

					// Starting Second if

					if ((param = getTableOrderDetaisParamWithAction(entityData, "USLDAndLocalBestPlusPool", "n")) != null) {
						log.info("in side USLDAndLocalBestPlusPool ... ");

						enterprise
								.setUsLdAndLocalBestPlusPool(Long.parseLong(getValueWithoutOActionDefault(param, "0")));
						plusPoolValues = Long.parseLong(getValueWithoutOActionDefault(param, "0"));

					} else {
						plusPoolValues = invEntObj.getUsLdAndLocalBestPool();
					}

					if ((param = getTableOrderDetaisParamWithAction(entityData, "USLDOnlyBestPlusPool", "n")) != null) {
						log.info("in side USLDOnlyBestPlusPool ... ");

						enterprise.setUsLdOnlyBestPlusPool(Long.parseLong(getValueWithoutOActionDefault(param, "0")));
						plusPoolValues = plusPoolValues + Long.parseLong(getValueWithoutOActionDefault(param, "0"));

					} else {
						plusPoolValues = plusPoolValues + invEntObj.getUsLdAndLocalBestPool();
					}

					// finishing second if
				} else {

					if ((param = getTableOrderDetaisParamWithAction(entityData, "EmeaApacBestPool", "n")) != null) {
						enterprise.setEmeaApacBestPool(Long.parseLong(getValueWithoutOActionDefault(param, "0")));
						poolValues = Long.parseLong(getValueWithoutOActionDefault(param, "0"));
					} else {
						log.info("EmeaApacBestPool : " + invEntObj.getEmeaApacBestPool());
						poolValues = invEntObj.getEmeaApacBestPool();
					}

					// Start second if condition

					if ((param = getTableOrderDetaisParamWithAction(entityData, "EmeaApacBestPlusPool", "n")) != null) {
						enterprise.setEmeaApacBestPlusPool(Long.parseLong(getValueWithoutOActionDefault(param, "0")));
						poolValues = Long.parseLong(getValueWithoutOActionDefault(param, "0"));
					} else {
						log.info("EmeaApacBestPlusPool : " + invEntObj.getEmeaApacBestPlusPool());
						poolValues = invEntObj.getEmeaApacBestPool();
					}

				}

				log.info("pool values Sum:::" + poolValues);

				/*
				 * This is duplicate if block condition Shifting contents above
				 * if block
				 * 
				 * if(!(addParamList.getByNameSearch("Region") == null) &&
				 * ("US".equalsIgnoreCase(addParamList.getByNameSearch("Region")
				 * .getParamValue()))) { log.info("in side US"); if
				 * (addParamList.getByNameSearchWithAction(
				 * "USLDAndLocalBestPlusPool", "n") != null) { String val =
				 * addParamList.getByNameSearchWithAction(
				 * "USLDAndLocalBestPlusPool", "n").getParamValue(); if (val !=
				 * null && !"".equals(val)) {
				 * enterprise.setUsLdAndLocalBestPlusPool(Long.parseLong(val));
				 * plusPoolValues = Long.parseLong(val); } else {
				 * enterprise.setUsLdAndLocalBestPlusPool(0); plusPoolValues =
				 * 0; } } else { plusPoolValues =
				 * invEntObj.getUsLdAndLocalBestPlusPool(); }
				 * 
				 * if (addParamList.getByNameSearchWithAction(
				 * "USLDOnlyBestPlusPool", "n") != null) { log.info(
				 * "in side USLD"); String val =
				 * addParamList.getByNameSearchWithAction(
				 * "USLDOnlyBestPlusPool", "n").getParamValue(); log.info("VAL "
				 * +val); if (val != null && !"".equals(val)) { log.info("VAL1 "
				 * +val);
				 * enterprise.setUsLdOnlyBestPlusPool(Long.parseLong(val));
				 * log.info("getting "+enterprise.getUsLdOnlyBestPlusPool());
				 * plusPoolValues = plusPoolValues + Long.parseLong(val); } else
				 * { enterprise.setUsLdOnlyBestPlusPool(0); plusPoolValues =
				 * plusPoolValues + 0; } } else { plusPoolValues =
				 * plusPoolValues + invEntObj.getUsLdOnlyBestPlusPool(); }
				 * //enterprise.setEntTrunkCclSum(poolValues); } else { if
				 * (addParamList.getByNameSearchWithAction(
				 * "EmeaApacBestPlusPool", "n") != null) { String val =
				 * addParamList.getByNameSearchWithAction(
				 * "EmeaApacBestPlusPool", "n").getParamValue(); if (val != null
				 * && !"".equals(val)) {
				 * enterprise.setEmeaApacBestPlusPool(Long.parseLong(val));
				 * plusPoolValues = Long.parseLong(val);
				 * //enterprise.setEntTrunkCclSum(poolValues); } else {
				 * plusPoolValues = 0; enterprise.setEmeaApacBestPlusPool(0); }
				 * 
				 * } else { plusPoolValues =
				 * invEntObj.getEmeaApacBestPlusPool(); } }
				 */

				enterprise.setEntTrunkCclSum(poolValues + plusPoolValues);
				log.info("EntTrunkCclSum ::::::::::::::" + (poolValues + plusPoolValues));
			}

			// Mar 2013 VoipTrunkingServiceOptimization
			/*
			 * if (addParamList.getByNameSearchWithAction("SOEnabled", "n") !=
			 * null) { String val =
			 * addParamList.getByNameSearchWithAction("SOEnabled",
			 * "n").getParamValue(); if (val != null && !"".equals(val)) {
			 * enterprise.setSoEnabled(Short.parseShort(val)); } } if
			 * (addParamList.getByNameSearchWithAction("USLDAndLocalBestPool",
			 * "n") != null) { String val =
			 * addParamList.getByNameSearchWithAction("USLDAndLocalBestPool",
			 * "n").getParamValue(); if (val != null && !"".equals(val)) {
			 * enterprise.setUsLdAndLocalBestPool(Long.parseLong(val)); } } if
			 * (addParamList.getByNameSearchWithAction("USLDOnlyBestPool", "n")
			 * != null) { String val =
			 * addParamList.getByNameSearchWithAction("USLDOnlyBestPool",
			 * "n").getParamValue(); if (val != null && !"".equals(val)) {
			 * enterprise.setUsLdOnlyBestPool(Long.parseLong(val)); } } if
			 * (addParamList.getByNameSearchWithAction("EmeaApacBestPool", "n")
			 * != null) { String val =
			 * addParamList.getByNameSearchWithAction("EmeaApacBestPool",
			 * "n").getParamValue(); if (val != null && !"".equals(val)) {
			 * enterprise.setEmeaApacBestPool(Long.parseLong(val)); } }
			 */

		/*	if (!(addParamList.getByNameSearchWithAction("BillContactPriPhone", "n") == null)) {
				if (!(addParamList.getByNameSearchWithAction("BillContactPriPhone", "n").getParamValue() == null)
						&& !addParamList.getByNameSearchWithAction("BillContactPriPhone", "n").getParamValue()
								.equals(""))
					enterprise.setBillContactPriPhone(
							addParamList.getByNameSearchWithAction("BillContactPriPhone", "n").getParamValue());
				else
					enterprise.setBillContactPriPhone("");
			}*/

			if ((param = getTableOrderDetaisParamWithAction(entityData, "BillContactPriPhone", "n")) != null) {
				enterprise.setBillContactPriPhone(getValueWithoutOActionDefault(param, ""));
				
			}
			
			/*if (!(addParamList.getByNameSearchWithAction("BillContactAltPhone", "n") == null)) {
				if (!(addParamList.getByNameSearchWithAction("BillContactAltPhone", "n").getParamValue() == null)
						&& !addParamList.getByNameSearchWithAction("BillContactAltPhone", "n").getParamValue()
								.equals(""))
					enterprise.setBillContactAltPhone(
							addParamList.getByNameSearchWithAction("BillContactAltPhone", "n").getParamValue());
				else
					enterprise.setBillContactAltPhone("");
			}*/

			
			if ((param = getTableOrderDetaisParamWithAction(entityData, "BillContactAltPhone", "n")) != null) {
				enterprise.setBillContactAltPhone(getValueWithoutOActionDefault(param, ""));
				
			}
			
			
			
			/*if (!(addParamList.getByNameSearchWithAction("BillContactCell", "n") == null)) {
				if (!(addParamList.getByNameSearchWithAction("BillContactCell", "n").getParamValue() == null)
						&& !addParamList.getByNameSearchWithAction("BillContactCell", "n").getParamValue().equals(""))
					enterprise.setBillContactCell(
							addParamList.getByNameSearchWithAction("BillContactCell", "n").getParamValue());
				else
					enterprise.setBillContactCell("");
			}*/

			if ((param = getTableOrderDetaisParamWithAction(entityData, "BillContactCell", "n")) != null) {
				enterprise.setBillContactCell(getValueWithoutOActionDefault(param, ""));
				
			}
			
			
			/*if (!(addParamList.getByNameSearchWithAction("BillContactPager", "n") == null)) {
				if (!(addParamList.getByNameSearchWithAction("BillContactPager", "n").getParamValue() == null)
						&& !addParamList.getByNameSearchWithAction("BillContactPager", "n").getParamValue().equals(""))
					enterprise.setBillContactPager(
							addParamList.getByNameSearchWithAction("BillContactPager", "n").getParamValue());
				else
					enterprise.setBillContactPager("");
			}*/
			
			if ((param = getTableOrderDetaisParamWithAction(entityData, "BillContactPager", "n")) != null) {
				enterprise.setBillContactPager(getValueWithoutOActionDefault(param, ""));
				
			}
			
/*
			if (!(addParamList.getByNameSearchWithAction("BillContactEmail", "n") == null)) {
				if (!(addParamList.getByNameSearchWithAction("BillContactEmail", "n").getParamValue() == null)
						&& !addParamList.getByNameSearchWithAction("BillContactEmail", "n").getParamValue().equals(""))
					enterprise.setBillContactEmail(
							addParamList.getByNameSearchWithAction("BillContactEmail", "n").getParamValue());
				else
					enterprise.setBillContactEmail("");
			}*/
			
			
			if ((param = getTableOrderDetaisParamWithAction(entityData, "BillContactEmail", "n")) != null) {
				enterprise.setBillContactEmail(getValueWithoutOActionDefault(param, ""));
				
			}
			
			/*if (!(addParamList.getByNameSearchWithAction("BillContactAddr1", "n") == null)) {
				if (!(addParamList.getByNameSearchWithAction("BillContactAddr1", "n").getParamValue() == null)
						&& !addParamList.getByNameSearchWithAction("BillContactAddr1", "n").getParamValue().equals(""))
					enterprise.setBillContactAddr1(
							addParamList.getByNameSearchWithAction("BillContactAddr1", "n").getParamValue());
				else
					enterprise.setBillContactAddr1("");
			}*/
			
			if ((param = getTableOrderDetaisParamWithAction(entityData, "BillContactAddr1", "n")) != null) {
				enterprise.setBillContactAddr1(getValueWithoutOActionDefault(param, ""));
				
			}
			

			/*if (!(addParamList.getByNameSearchWithAction("BillContactAddr2", "n") == null)) {
				if (!(addParamList.getByNameSearchWithAction("BillContactAddr2", "n").getParamValue() == null)
						&& !addParamList.getByNameSearchWithAction("BillContactAddr2", "n").getParamValue().equals(""))
					enterprise.setBillContactAddr2(
							addParamList.getByNameSearchWithAction("BillContactAddr2", "n").getParamValue());
				else
					enterprise.setBillContactAddr2("");
			}*/
			
			if ((param = getTableOrderDetaisParamWithAction(entityData, "BillContactAddr2", "n")) != null) {
				enterprise.setBillContactAddr2(getValueWithoutOActionDefault(param, ""));
				
			}

			/*if (!(addParamList.getByNameSearchWithAction("BillContactCity", "n") == null)) {
				if (!(addParamList.getByNameSearchWithAction("BillContactCity", "n").getParamValue() == null)
						&& !addParamList.getByNameSearchWithAction("BillContactCity", "n").getParamValue().equals(""))
					enterprise.setBillContactCity(
							addParamList.getByNameSearchWithAction("BillContactCity", "n").getParamValue());
				else
					enterprise.setBillContactCity("");
			}*/
			
			if ((param = getTableOrderDetaisParamWithAction(entityData, "BillContactCity", "n")) != null) {
				enterprise.setBillContactCity(getValueWithoutOActionDefault(param, ""));
				
			}
			
			
			/*if (!(addParamList.getByNameSearchWithAction("BillContactState", "n") == null)) {
				if (!(addParamList.getByNameSearchWithAction("BillContactState", "n").getParamValue() == null)
						&& !addParamList.getByNameSearchWithAction("BillContactState", "n").getParamValue().equals(""))
					enterprise.setBillContactState(
							addParamList.getByNameSearchWithAction("BillContactState", "n").getParamValue());
				else
					enterprise.setBillContactState("");
			}*/
			
			if ((param = getTableOrderDetaisParamWithAction(entityData, "BillContactState", "n")) != null) {
				enterprise.setBillContactState(getValueWithoutOActionDefault(param, ""));
				
			}
			

			/*if (!(addParamList.getByNameSearchWithAction("BillContactZip", "n") == null)) {
				if (!(addParamList.getByNameSearchWithAction("BillContactZip", "n").getParamValue() == null)
						&& !addParamList.getByNameSearchWithAction("BillContactZip", "n").getParamValue().equals(""))
					enterprise.setBillContactZip(
							addParamList.getByNameSearchWithAction("BillContactZip", "n").getParamValue());
				else
					enterprise.setBillContactZip("");
			}*/
			
			if ((param = getTableOrderDetaisParamWithAction(entityData, "BillContactZip", "n")) != null) {
				enterprise.setBillContactZip(getValueWithoutOActionDefault(param, ""));
				
			}
			
			/*if (!(addParamList.getByNameSearchWithAction("BillContactCountry", "n") == null)) {
				if (!(addParamList.getByNameSearchWithAction("BillContactCountry", "n").getParamValue() == null)
						&& !addParamList.getByNameSearchWithAction("BillContactCountry", "n").getParamValue()
								.equals(""))
					enterprise.setBillContactCountry(
							addParamList.getByNameSearchWithAction("BillContactCountry", "n").getParamValue());
				else
					enterprise.setBillContactCountry("");
			}*/

			if ((param = getTableOrderDetaisParamWithAction(entityData, "BillContactCountry", "n")) != null) {
				enterprise.setBillContactCountry(getValueWithoutOActionDefault(param, ""));
				
			}
			
			/*if (!(addParamList.getByNameSearchWithAction("VnetCorpId", "n") == null)) {
				if (!(addParamList.getByNameSearchWithAction("VnetCorpId", "n").getParamValue() == null)
						&& !addParamList.getByNameSearchWithAction("VnetCorpId", "n").getParamValue().equals(""))
					enterprise.setCustCorpId(addParamList.getByNameSearchWithAction("VnetCorpId", "n").getParamValue());
				else
					enterprise.setCustCorpId("");
			}*/
			
			if ((param = getTableOrderDetaisParamWithAction(entityData, "VnetCorpId", "n")) != null) {
				enterprise.setCustCorpId(getValueWithoutOActionDefault(param, ""));
				
			}
			
			
			/*if (!(addParamList.getByNameSearch("EnterpriseCclIndicator") == null)) {
				enterprise.setEntCclInd(VzbVoipEnum.YesNoType
						.valueByName(addParamList.getByNameSearch("EnterpriseCclIndicator").getParamValue()));
			}
*/
			
			if ((paramValue = getValueWithoutOAction(entityData, "EnterpriseCclIndicator")) != null) {
				
				enterprise.setEntCclInd(VzbVoipEnum.YesNoType.valueByName(paramValue));
			}
			
			
			/*if (!(addParamList.getByNameSearchWithAction("EnterpriseTrunkingType", "n") == null)) {
				enterprise.setEnterpriseTrunkingType(VzbVoipEnum.EnterpriseTrunkingType.valueByAcronym(
						addParamList.getByNameSearchWithAction("EnterpriseTrunkingType", "n").getParamValue()));
			}*/

			if ((param = getTableOrderDetaisParamWithAction(entityData, "EnterpriseTrunkingType", "n")) != null) {
				
				enterprise.setEnterpriseTrunkingType(VzbVoipEnum.EnterpriseTrunkingType.valueByAcronym(param.getParamValue()));
			}
			

			/*if (!(addParamList.getByNameSearchWithAction("SipDomain", "n") == null)) {
				if (!(addParamList.getByNameSearchWithAction("SipDomain", "n").getParamValue() == null)
						&& !addParamList.getByNameSearchWithAction("SipDomain", "n").getParamValue().equals(""))
					enterprise.setSipDomain(addParamList.getByNameSearchWithAction("SipDomain", "n").getParamValue());
				else
					enterprise.setSipDomain("");
			}*/
			
			if ((param = getTableOrderDetaisParamWithAction(entityData, "SipDomain", "n")) != null) {
				enterprise.setSipDomain(getValueWithoutOActionDefault(param, ""));
				
			}
			
/*
			if (!(addParamList.getByNameSearchWithAction("BillingSystem", "n") == null)) {

				if (!(addParamList.getByNameSearchWithAction("BillingSystem", "n").getParamValue() == null)
						&& !addParamList.getByNameSearchWithAction("BillingSystem", "n").getParamValue().equals("")) {
					if (enterprise.getRegionId() == VzbVoipEnum.RegionType.EMEA) {
						enterprise.setEmeaBillingSystem(VzbVoipEnum.BillingSystemType.valueByAcronym(
								orderParam.getByNameSearchWithAction("BillingSystem", "n").getParamValue()));
					} else if (enterprise.getRegionId() == VzbVoipEnum.RegionType.US) {
						enterprise.setBillingSystem(VzbVoipEnum.BillingSystemType.valueByAcronym(
								orderParam.getByNameSearchWithAction("BillingSystem", "n").getParamValue()));
					}
				} else {
					if (enterprise.getRegionId() == VzbVoipEnum.RegionType.EMEA) {
						enterprise.setEmeaBillingSystem(-1);
					} else if (enterprise.getRegionId() == VzbVoipEnum.RegionType.US) {
						enterprise.setBillingSystem(0);
					}
				}
			}*/
			
			if ((param = getTableOrderDetaisParamWithAction(entityData, "BillingSystem", "n")) != null ){
				
				if (enterprise.getRegionId() == VzbVoipEnum.RegionType.EMEA) {
						enterprise.setEmeaBillingSystem(getBillingSytemType(param, "-1"));
						
					} else if (enterprise.getRegionId() == VzbVoipEnum.RegionType.US) {
						enterprise.setBillingSystem(getBillingSytemType(param, "0"));
					}
				}

			// Changed for IR #2423825 to avoid unnecessary updates
			/*if (!(addParamList.getByNameSearchWithAction("ProductType", "n") == null))
				enterprise
						.setProductType(Integer.parseInt(addParamList.getByNameSearch("ProductType").getParamValue()));*/
			
			
			if ((param = getTableOrderDetaisParamWithAction(entityData, "ProductType", "n")) != null ){
				enterprise
				.setProductType(Integer.parseInt(param.getParamValue()));
				
			}
			

			/*if (!(addParamList.getByNameSearch("CentrexType") == null))
				enterprise.setPlatformIndicator(VzbVoipEnum.CentrexType
						.valueByAcronym(addParamList.getByNameSearch("CentrexType").getParamValue()));*/
			
			if ((param = getTableOrderDetaisParam(entityData, "CentrexType")) != null ){
				enterprise.setPlatformIndicator(VzbVoipEnum.CentrexType
						.valueByAcronym(param.getParamValue()));
				
			}
			

			/*if (!(addParamList.getByNameSearchWithAction("VmPartitionId", "n") == null)) {
				if (!(addParamList.getByNameSearchWithAction("VmPartitionId", "n").getParamValue() == null)
						&& !addParamList.getByNameSearchWithAction("VmPartitionId", "n").getParamValue().equals(""))
					enterprise.setVmPartitionId(
							addParamList.getByNameSearchWithAction("VmPartitionId", "n").getParamValue());
				else
					enterprise.setVmPartitionId("");
			}*/
			
			if ((param = getTableOrderDetaisParamWithAction(entityData, "VmPartitionId", "n")) != null) {
				enterprise.setVmPartitionId(getValueWithoutOActionDefault(param, ""));
				
			}
			
			// else
			// enterprise.setVmPartitionId(getVmPartitionIdSeqNextVal());
			/** Z562196 start code */
			/*if (!(addParamList.getByNameSearchWithAction("ContactFirstName", "n") == null)) {
				if (!(addParamList.getByNameSearchWithAction("ContactFirstName", "n").getParamValue() == null)
						&& !addParamList.getByNameSearchWithAction("ContactFirstName", "n").getParamValue().equals(""))
					enterprise.setContactFirstName(
							addParamList.getByNameSearchWithAction("ContactFirstName", "n").getParamValue());
				else
					enterprise.setContactFirstName("");
			}*/
			
			if ((param = getTableOrderDetaisParamWithAction(entityData, "ContactFirstName", "n")) != null) {
				enterprise.setContactFirstName(getValueWithoutOActionDefault(param, ""));
				
			}
			
			
			/*if (!(addParamList.getByNameSearchWithAction("ContactLastName", "n") == null)) {
				if (!(addParamList.getByNameSearchWithAction("ContactLastName", "n").getParamValue() == null)
						&& !addParamList.getByNameSearchWithAction("ContactLastName", "n").getParamValue().equals(""))
					enterprise.setContactLastName(
							addParamList.getByNameSearchWithAction("ContactLastName", "n").getParamValue());
				else
					enterprise.setContactLastName("");
			}*/
			
			if ((param = getTableOrderDetaisParamWithAction(entityData, "ContactLastName", "n")) != null) {
				enterprise.setContactLastName(getValueWithoutOActionDefault(param, ""));
				
			}
			
			
			/*if (!(addParamList.getByNameSearchWithAction("ContactFax", "n") == null)) {
				if (!(addParamList.getByNameSearchWithAction("ContactFax", "n").getParamValue() == null)
						&& !addParamList.getByNameSearchWithAction("ContactFax", "n").getParamValue().equals(""))
					enterprise.setContactFax(addParamList.getByNameSearchWithAction("ContactFax", "n").getParamValue());
				else
					enterprise.setContactFax("");
			}*/
			
			if ((param = getTableOrderDetaisParamWithAction(entityData, "ContactFax", "n")) != null) {
				enterprise.setContactFax(getValueWithoutOActionDefault(param, ""));
				
			}
			
			
			/** Z562196 end code */

			/*if (!(addParamList.getByNameSearchWithAction("ContactPhone1", "n") == null)) {
				if (!(addParamList.getByNameSearchWithAction("ContactPhone1", "n").getParamValue() == null)
						&& !addParamList.getByNameSearchWithAction("ContactPhone1", "n").getParamValue().equals(""))
					enterprise.setContactPrimaryPhone(
							addParamList.getByNameSearchWithAction("ContactPhone1", "n").getParamValue());
				else
					enterprise.setContactPrimaryPhone("");
			}*/

			
			if ((param = getTableOrderDetaisParamWithAction(entityData, "ContactPhone1", "n")) != null) {
				enterprise.setContactPrimaryPhone(getValueWithoutOActionDefault(param, ""));
				
			}
			
			
			/*if (!(addParamList.getByNameSearchWithAction("ContactPhone2", "n") == null)) {
				if (!(addParamList.getByNameSearchWithAction("ContactPhone2", "n").getParamValue() == null)
						&& !addParamList.getByNameSearchWithAction("ContactPhone2", "n").getParamValue().equals(""))
					enterprise.setContactAltPhone(
							addParamList.getByNameSearchWithAction("ContactPhone2", "n").getParamValue());
				else
					enterprise.setContactAltPhone("");
			}*/
			
			if ((param = getTableOrderDetaisParamWithAction(entityData, "ContactPhone2", "n")) != null) {
				enterprise.setContactAltPhone(getValueWithoutOActionDefault(param, ""));
				
			}
			

			/*if (!(addParamList.getByNameSearchWithAction("ContactMobile", "n") == null)) {
				if (!(addParamList.getByNameSearchWithAction("ContactMobile", "n").getParamValue() == null)
						&& !addParamList.getByNameSearchWithAction("ContactMobile", "n").getParamValue().equals(""))
					enterprise.setContactCell(
							addParamList.getByNameSearchWithAction("ContactMobile", "n").getParamValue());
				else
					enterprise.setContactCell("");
			}*/
			
			if ((param = getTableOrderDetaisParamWithAction(entityData, "ContactMobile", "n")) != null) {
				enterprise.setContactCell(getValueWithoutOActionDefault(param, ""));
				
			}

			/*if (!(addParamList.getByNameSearchWithAction("ContactPager", "n") == null)) {
				if (!(addParamList.getByNameSearchWithAction("ContactPager", "n").getParamValue() == null)
						&& !addParamList.getByNameSearchWithAction("ContactPager", "n").getParamValue().equals(""))
					enterprise.setContactPager(
							addParamList.getByNameSearchWithAction("ContactPager", "n").getParamValue());
				else
					enterprise.setContactPager("");
			}*/
			
			if ((param = getTableOrderDetaisParamWithAction(entityData, "ContactPager", "n")) != null) {
				enterprise.setContactPager(getValueWithoutOActionDefault(param, ""));
				
			}
			
			
			/*if (!(addParamList.getByNameSearchWithAction("ContactEmail", "n") == null)) {
				if (!(addParamList.getByNameSearchWithAction("ContactEmail", "n").getParamValue() == null)
						&& !addParamList.getByNameSearchWithAction("ContactEmail", "n").getParamValue().equals(""))
					enterprise.setContactEmail(
							addParamList.getByNameSearchWithAction("ContactEmail", "n").getParamValue());
				else
					enterprise.setContactEmail("");
			}*/
			
			if ((param = getTableOrderDetaisParamWithAction(entityData, "ContactEmail", "n")) != null) {
				enterprise.setContactEmail(getValueWithoutOActionDefault(param, ""));
				
			}
			
			
			/*if (!(addParamList.getByNameSearchWithAction("ContactAddress1", "n") == null)) {
				if (!(addParamList.getByNameSearchWithAction("ContactAddress1", "n").getParamValue() == null)
						&& !addParamList.getByNameSearchWithAction("ContactAddress1", "n").getParamValue().equals(""))
					enterprise.setContactAddr1(
							addParamList.getByNameSearchWithAction("ContactAddress1", "n").getParamValue());
				else
					enterprise.setContactAddr1("");
			}*/
			
			if ((param = getTableOrderDetaisParamWithAction(entityData, "ContactAddress1", "n")) != null) {
				enterprise.setContactAddr1(getValueWithoutOActionDefault(param, ""));
				
			}
			

			/*if (!(addParamList.getByNameSearchWithAction("ContactAddress2", "n") == null)) {
				if (!(addParamList.getByNameSearchWithAction("ContactAddress2", "n").getParamValue() == null)
						&& !addParamList.getByNameSearchWithAction("ContactAddress2", "n").getParamValue().equals(""))
					enterprise.setContactAddr2(
							addParamList.getByNameSearchWithAction("ContactAddress2", "n").getParamValue());
				else
					enterprise.setContactAddr2("");
			}*/

			if ((param = getTableOrderDetaisParamWithAction(entityData, "ContactAddress2", "n")) != null) {
				enterprise.setContactAddr2(getValueWithoutOActionDefault(param, ""));
				
			}
			
			
			/*if (!(addParamList.getByNameSearchWithAction("ContactCity", "n") == null)) {
				if (!(addParamList.getByNameSearchWithAction("ContactCity", "n").getParamValue() == null)
						&& !addParamList.getByNameSearchWithAction("ContactCity", "n").getParamValue().equals(""))
					enterprise
							.setContactCity(addParamList.getByNameSearchWithAction("ContactCity", "n").getParamValue());
				else
					enterprise.setContactCity("");
			}*/
			
			
			if ((param = getTableOrderDetaisParamWithAction(entityData, "ContactCity", "n")) != null) {
				enterprise.setContactCity(getValueWithoutOActionDefault(param, ""));
				
			}
			
			
			/*if (!(addParamList.getByNameSearchWithAction("ContactState", "n") == null)) {
				if (!(addParamList.getByNameSearchWithAction("ContactState", "n").getParamValue() == null)
						&& !addParamList.getByNameSearchWithAction("ContactState", "n").getParamValue().equals(""))
					enterprise.setContactState(
							addParamList.getByNameSearchWithAction("ContactState", "n").getParamValue());
				else
					enterprise.setContactState("");
			}*/
			
			
			if ((param = getTableOrderDetaisParamWithAction(entityData, "ContactState", "n")) != null) {
				enterprise.setContactState(getValueWithoutOActionDefault(param, ""));
				
			}
			
			
			/*if (!(addParamList.getByNameSearchWithAction("ContactZip", "n") == null)) {
				if (!(addParamList.getByNameSearchWithAction("ContactZip", "n").getParamValue() == null)
						&& !addParamList.getByNameSearchWithAction("ContactZip", "n").getParamValue().equals(""))
					enterprise.setContactZip(addParamList.getByNameSearchWithAction("ContactZip", "n").getParamValue());
				else
					enterprise.setContactZip("");
			}*/

			
			if ((param = getTableOrderDetaisParamWithAction(entityData, "ContactZip", "n")) != null) {
				enterprise.setContactZip(getValueWithoutOActionDefault(param, ""));
				
			}
			
			
			
			/*if (!(addParamList.getByNameSearchWithAction("ContactCountry", "n") == null)) {
				if (!(addParamList.getByNameSearchWithAction("ContactCountry", "n").getParamValue() == null)
						&& !addParamList.getByNameSearchWithAction("ContactCountry", "n").getParamValue().equals(""))
					enterprise.setContactCountry(
							addParamList.getByNameSearchWithAction("ContactCountry", "n").getParamValue());
				else
					enterprise.setContactCountry("");
			}*/
			
			if ((param = getTableOrderDetaisParamWithAction(entityData, "ContactCountry", "n")) != null) {
				enterprise.setContactCountry(getValueWithoutOActionDefault(param, ""));
				
			}
			
			/*if (!(addParamList.getByNameSearchWithAction("VnetCorpId", "n") == null)) {
				if (!(addParamList.getByNameSearchWithAction("VnetCorpId", "n").getParamValue() == null)
						&& !addParamList.getByNameSearchWithAction("VnetCorpId", "n").getParamValue().equals(""))
					enterprise.setVnetCorpId(addParamList.getByNameSearchWithAction("VnetCorpId", "n").getParamValue());
				else
					enterprise.setVnetCorpId("");
			}*/
			
			if ((param = getTableOrderDetaisParamWithAction(entityData, "VnetCorpId", "n")) != null) {
				enterprise.setVnetCorpId(getValueWithoutOActionDefault(param, ""));
				
			}

			/*if (!(addParamList.getByNameSearchWithAction("ContractInd", "n") == null)) {
				if (!(addParamList.getByNameSearchWithAction("ContractInd", "n").getParamValue() == null)
						&& !addParamList.getByNameSearchWithAction("ContractInd", "n").getParamValue().equals(""))
					enterprise
							.setContractInd(addParamList.getByNameSearchWithAction("ContractInd", "n").getParamValue());
				else
					enterprise.setContractInd("");
			}*/
			
			if ((param = getTableOrderDetaisParamWithAction(entityData, "ContractInd", "n")) != null) {
				enterprise.setContractInd(getValueWithoutOActionDefault(param, ""));
				
			}

			/*if (!(addParamList.getByNameSearchWithAction("ContactTitle", "n") == null)) {
				if (!(addParamList.getByNameSearchWithAction("ContactTitle", "n").getParamValue() == null)
						&& !addParamList.getByNameSearchWithAction("ContactTitle", "n").getParamValue().equals(""))
					enterprise.setContactTitle(
							addParamList.getByNameSearchWithAction("ContactTitle", "n").getParamValue());
				else
					enterprise.setContactTitle("");
			}*/
			
			if ((param = getTableOrderDetaisParamWithAction(entityData, "ContactTitle", "n")) != null) {
				enterprise.setContactTitle(getValueWithoutOActionDefault(param, ""));
				
			}

			/*if (!(addParamList.getByNameSearchWithAction("AgencyHierCode", "n") == null)) {
				if (!(addParamList.getByNameSearchWithAction("AgencyHierCode", "n").getParamValue() == null)
						&& !addParamList.getByNameSearchWithAction("AgencyHierCode", "n").getParamValue().equals(""))
					enterprise.setAgencyHierCode(
							addParamList.getByNameSearchWithAction("AgencyHierCode", "n").getParamValue());
				else
					enterprise.setAgencyHierCode("");
			}*/
			
			if ((param = getTableOrderDetaisParamWithAction(entityData, "AgencyHierCode", "n")) != null) {
				enterprise.setAgencyHierCode(getValueWithoutOActionDefault(param, ""));
				
			}
			
			// enterprise.setTntCclInd(1);
			
			/*if ((param = getTableOrderDetaisParamWithAction(entityData, "NaspId", "n")) != null && (!isEmpty(param.getParamValue()))){
				enterprise.setNaspId(param.getParamValue());
				
			}*/
			
			

			/*if (!(addParamList.getByNameSearch("AllowOnNet") == null))
				enterprise.setOnNetInterco(
						VzbVoipEnum.YesNoType.valueByName(addParamList.getByNameSearch("AllowOnNet").getParamValue()));*/
			
			if ((param = getTableOrderDetaisParam(entityData, "AllowOnNet")) != null ){
				VzbVoipEnum.YesNoType.valueByName(param.getParamValue());
				
			}
			

			/*if (!(addParamList.getByNameSearch("QosIndicator") == null))
				enterprise.setQosInd(VzbVoipEnum.QosIndicator
						.valueByAcronym(addParamList.getByNameSearch("QosIndicator").getParamValue()));*/
			
			if ((param = getTableOrderDetaisParam(entityData, "QosIndicator")) != null ){
				enterprise.setQosInd(VzbVoipEnum.QosIndicator
						.valueByAcronym(param.getParamValue()));
				
			}
			

			// Changed for IR #2423825 to avoid unnecessary updates
			/*if (!(addParamList.getByNameSearchWithAction("NonTrustedIPCalls", "n") == null))
				enterprise.setPubIp(VzbVoipEnum.YesNoType
						.valueByName(addParamList.getByNameSearch("NonTrustedIPCalls").getParamValue()));*/
			
			if ((param = getTableOrderDetaisParamWithAction(entityData, "NonTrustedIPCalls", "n")) != null ){
				enterprise.setPubIp(VzbVoipEnum.YesNoType
						.valueByName(param.getParamValue()));
				
			}
			

			// IR #4842933 Need to make sure ,
			// tbl_customer.CUST_SENSITIVITY_LEVEL is never updated
			// enterprise.setCustSensitivityLevel("1");

			/*if (!(addParamList.getByNameSearchWithAction("SalesRepName", "n") == null)) {
				if (!(addParamList.getByNameSearchWithAction("SalesRepName", "n").getParamValue() == null)
						&& !addParamList.getByNameSearchWithAction("SalesRepName", "n").getParamValue().equals(""))
					enterprise.setSalesRepName(
							addParamList.getByNameSearchWithAction("SalesRepName", "n").getParamValue());
				else
					enterprise.setSalesRepName("");
			} else if (!(addParamList.getByNameSearchWithAction("AccountTeamName", "n") == null)) {
				if (!(addParamList.getByNameSearchWithAction("AccountTeamName", "n").getParamValue() == null)
						&& !addParamList.getByNameSearchWithAction("AccountTeamName", "n").getParamValue().equals(""))
					enterprise.setSalesRepName(
							addParamList.getByNameSearchWithAction("AccountTeamName", "n").getParamValue());
				else
					enterprise.setSalesRepName("");
			}*/
			
			if ((param = getTableOrderDetaisParamWithAction(entityData, "SalesRepName", "n")) != null) {
				enterprise.setSalesRepName(getValueWithoutOActionDefault(param, ""));
				
			}else if ((param = getTableOrderDetaisParamWithAction(entityData, "AccountTeamName", "n")) != null) {
				enterprise.setSalesRepName(getValueWithoutOActionDefault(param, ""));
				
			}
			
			
			/*if (!(addParamList.getByNameSearchWithAction("SalesRepPhone", "n") == null)) {
				if (!(addParamList.getByNameSearchWithAction("SalesRepPhone", "n").getParamValue() == null)
						&& !addParamList.getByNameSearchWithAction("SalesRepPhone", "n").getParamValue().equals(""))
					enterprise.setSalesRepPhone(
							addParamList.getByNameSearchWithAction("SalesRepPhone", "n").getParamValue());
				else
					enterprise.setSalesRepPhone("");
			} else if (!(addParamList.getByNameSearchWithAction("AccountTeamPhone", "n") == null)) {
				if (!(addParamList.getByNameSearchWithAction("AccountTeamPhone", "n").getParamValue() == null)
						&& !addParamList.getByNameSearchWithAction("AccountTeamPhone", "n").getParamValue().equals(""))
					enterprise.setSalesRepPhone(
							addParamList.getByNameSearchWithAction("AccountTeamPhone", "n").getParamValue());
				else
					enterprise.setSalesRepPhone("");
			}*/

			
			if ((param = getTableOrderDetaisParamWithAction(entityData, "SalesRepPhone", "n")) != null) {
				enterprise.setSalesRepPhone(getValueWithoutOActionDefault(param, ""));
				
			}else if ((param = getTableOrderDetaisParamWithAction(entityData, "AccountTeamPhone", "n")) != null) {
				enterprise.setSalesRepPhone(getValueWithoutOActionDefault(param, ""));
				
			}
			
			
			/*if (!(addParamList.getByNameSearchWithAction("SalesRepEmail", "n") == null)) {
				if (!(addParamList.getByNameSearchWithAction("SalesRepEmail", "n").getParamValue() == null)
						&& !addParamList.getByNameSearchWithAction("SalesRepEmail", "n").getParamValue().equals(""))
					enterprise.setSalesRepEmail(
							addParamList.getByNameSearchWithAction("SalesRepEmail", "n").getParamValue());
				else
					enterprise.setSalesRepEmail("");
			} else if (!(addParamList.getByNameSearchWithAction("AccountTeamEmail", "n") == null)) {
				if (!(addParamList.getByNameSearchWithAction("AccountTeamEmail", "n").getParamValue() == null)
						&& !addParamList.getByNameSearchWithAction("AccountTeamEmail", "n").getParamValue().equals(""))
					enterprise.setSalesRepEmail(
							addParamList.getByNameSearchWithAction("AccountTeamEmail", "n").getParamValue());
				else
					enterprise.setSalesRepEmail("");
			}*/
			
			
			if ((param = getTableOrderDetaisParamWithAction(entityData, "SalesRepEmail", "n")) != null) {
				enterprise.setSalesRepEmail(getValueWithoutOActionDefault(param, ""));
				
			}else if ((param = getTableOrderDetaisParamWithAction(entityData, "AccountTeamEmail", "n")) != null) {
				enterprise.setSalesRepEmail(getValueWithoutOActionDefault(param, ""));
				
			}
			

			/*if (!(addParamList.getByNameSearchWithAction("SalesRepId", "n") == null)) {
				if (!(addParamList.getByNameSearchWithAction("SalesRepId", "n").getParamValue() == null)
						&& !addParamList.getByNameSearchWithAction("SalesRepId", "n").getParamValue().equals(""))
					enterprise.setSalesRepId(addParamList.getByNameSearchWithAction("SalesRepId", "n").getParamValue());
				else
					enterprise.setSalesRepId("");
			}*/
			
			if ((param = getTableOrderDetaisParamWithAction(entityData, "SalesRepId", "n")) != null) {
				enterprise.setSalesRepId(getValueWithoutOActionDefault(param, ""));
				
			}
			
			/*if (!(addParamList.getByNameSearchWithAction("SalesSegment", "n") == null)) {
				if (!(addParamList.getByNameSearchWithAction("SalesSegment", "n").getParamValue() == null)
						&& !addParamList.getByNameSearchWithAction("SalesSegment", "n").getParamValue().equals(""))
					enterprise.setSalesSegment(
							Long.valueOf(addParamList.getByNameSearchWithAction("SalesSegment", "n").getParamValue()));
				else
					enterprise.setSalesSegment(0);
			}*/
			
			if ((param = getTableOrderDetaisParamWithAction(entityData, "SalesSegment", "n")) != null) {
				enterprise.setSalesSegment(Long.valueOf(getValueWithoutOActionDefault(param, "0")));
				
			}
			
			/*
			if (!(addParamList.getByNameSearchWithAction("OrderVerification", "n") == null)) {
				if (!(addParamList.getByNameSearchWithAction("OrderVerification", "n").getParamValue() == null)
						&& !addParamList.getByNameSearchWithAction("OrderVerification", "n").getParamValue().equals(""))
					enterprise.setOrderVerification(Long
							.valueOf(addParamList.getByNameSearchWithAction("OrderVerification", "n").getParamValue()));
				else
					enterprise.setOrderVerification(0);
			}*/
			
			
			if ((param = getTableOrderDetaisParamWithAction(entityData, "OrderVerification", "n")) != null) {
				enterprise.setOrderVerification(Long.valueOf(getValueWithoutOActionDefault(param, "0")));
				
			}
			
			

			/*if (!(addParamList.getByNameSearchWithAction("XrefCustomerId", "n") == null)) {
				if (!(addParamList.getByNameSearchWithAction("XrefCustomerId", "n").getParamValue() == null)
						&& !addParamList.getByNameSearchWithAction("XrefCustomerId", "n").getParamValue().equals(""))
					enterprise.setXrefCustomerId(
							addParamList.getByNameSearchWithAction("XrefCustomerId", "n").getParamValue());
				else
					enterprise.setXrefCustomerId("");
			}
*/
			
			if ((param = getTableOrderDetaisParamWithAction(entityData, "XrefCustomerId", "n")) != null) {
				enterprise.setXrefCustomerId(getValueWithoutOActionDefault(param, ""));
				
			}
			
			
			
			/*if (!(addParamList.getByNameSearchWithAction("SupportName", "n") == null)) {
				if (!(addParamList.getByNameSearchWithAction("SupportName", "n").getParamValue() == null)
						&& !addParamList.getByNameSearchWithAction("SupportName", "n").getParamValue().equals(""))
					enterprise
							.setSupportName(addParamList.getByNameSearchWithAction("SupportName", "n").getParamValue());
				else
					enterprise.setSupportName("");
			}*/
			
			if ((param = getTableOrderDetaisParamWithAction(entityData, "SupportName", "n")) != null) {
				enterprise.setSupportName(getValueWithoutOActionDefault(param, ""));
				
			}
			
			
			
			/*if (!(addParamList.getByNameSearchWithAction("SupportPhone", "n") == null)) {
				if (!(addParamList.getByNameSearchWithAction("SupportPhone", "n").getParamValue() == null)
						&& !addParamList.getByNameSearchWithAction("SupportPhone", "n").getParamValue().equals(""))
					enterprise.setSupportPhone(
							addParamList.getByNameSearchWithAction("SupportPhone", "n").getParamValue());
				else
					enterprise.setSupportPhone("");
			}*/
			
			if ((param = getTableOrderDetaisParamWithAction(entityData, "SupportPhone", "n")) != null) {
				enterprise.setSupportPhone(getValueWithoutOActionDefault(param, ""));
				
			}
			
			log.info("SalesRepName:" + enterprise.getSalesRepName());
			log.info("SalesRepPhone:" + enterprise.getSalesRepPhone());
			log.info("SalesRepEMail:" + enterprise.getSalesRepEmail());
			log.info("SalesSegment:" + enterprise.getSalesSegment());
			log.info("of:" + enterprise.getOrderVerification());
			log.info("sn:" + enterprise.getSupportName());
			log.info("sp:" + enterprise.getSupportPhone());

			/*if (!(addParamList.getByNameSearchWithAction("IEANLength", "n") == null)) {
				if (!(addParamList.getByNameSearchWithAction("IEANLength", "n").getParamValue() == null)
						&& !addParamList.getByNameSearchWithAction("IEANLength", "n").getParamValue().equals(""))
					enterprise.setIeanLength(
							Long.valueOf(addParamList.getByNameSearchWithAction("IEANLength", "n").getParamValue()));
				else
					enterprise.setIeanLength(0);
			}*/
			
			
			if ((param = getTableOrderDetaisParamWithAction(entityData, "IEANLength", "n")) != null) {
				enterprise.setIeanLength(Long.valueOf(getValueWithoutOActionDefault(param, "0")));
				
			}
			
			

		/*	if (!(orderParam.getByNameSearch("EnvOrderId") == null))
				enterprise.setEnvOrderId(Long.valueOf(orderParam.getByNameSearch("EnvOrderId").getParamValue()));*/
			enterprise.setEnvOrderId(Long.valueOf(envOrderId));

			// New Fields added by Vj on 31-08-09

			/*if (!(addParamList.getByNameSearchWithAction("CommonCustomerId", "n") == null)) {
				if (!(addParamList.getByNameSearchWithAction("CommonCustomerId", "n").getParamValue() == null)
						&& !addParamList.getByNameSearchWithAction("CommonCustomerId", "n").getParamValue().equals(""))
					enterprise.setCommonCustomerId(
							addParamList.getByNameSearchWithAction("CommonCustomerId", "n").getParamValue());
				else
					enterprise.setCommonCustomerId("");
			}*/
			
			if ((param = getTableOrderDetaisParamWithAction(entityData, "CommonCustomerId", "n")) != null) {
				enterprise.setCommonCustomerId(getValueWithoutOActionDefault(param, ""));
				
			}

			/*if (!(addParamList.getByNameSearchWithAction("CommonCustomerName", "n") == null)) {
				if (!(addParamList.getByNameSearchWithAction("CommonCustomerName", "n").getParamValue() == null)
						&& !addParamList.getByNameSearchWithAction("CommonCustomerName", "n").getParamValue()
								.equals(""))
					enterprise.setCommonCustomerName(
							addParamList.getByNameSearchWithAction("CommonCustomerName", "n").getParamValue());
				else
					enterprise.setCommonCustomerName("");
			}*/
			
			if ((param = getTableOrderDetaisParamWithAction(entityData, "CommonCustomerName", "n")) != null) {
				enterprise.setCommonCustomerName(getValueWithoutOActionDefault(param, ""));
				
			}
			

			/*if (!(addParamList.getByNameSearchWithAction("VpnName", "n") == null)) {
				if (!(addParamList.getByNameSearchWithAction("VpnName", "n").getParamValue() == null)
						&& !addParamList.getByNameSearchWithAction("VpnName", "n").getParamValue().equals(""))
					enterprise.setVpnName(addParamList.getByNameSearchWithAction("VpnName", "n").getParamValue());
				else
					enterprise.setVpnName("");
			}*/
			
			if ((param = getTableOrderDetaisParamWithAction(entityData, "VpnName", "n")) != null) {
				enterprise.setVpnName(getValueWithoutOActionDefault(param, ""));
				
			}
			
			

			/*if (!(addParamList.getByNameSearchWithAction("GCHId", "n") == null)) {
				if (!(addParamList.getByNameSearchWithAction("GCHId", "n").getParamValue() == null)
						&& !addParamList.getByNameSearchWithAction("GCHId", "n").getParamValue().equals(""))
					enterprise.setGchId(addParamList.getByNameSearchWithAction("GCHId", "n").getParamValue());
				else
					enterprise.setGchId("");
			}*/

			if ((param = getTableOrderDetaisParamWithAction(entityData, "GCHId", "n")) != null) {
				enterprise.setGchId(getValueWithoutOActionDefault(param, ""));
				
			}
			
			/*if (!(addParamList.getByNameSearchWithAction("CustomerPriceBookId", "n") == null)) {
				if (!(addParamList.getByNameSearchWithAction("CustomerPriceBookId", "n").getParamValue() == null)
						&& !addParamList.getByNameSearchWithAction("CustomerPriceBookId", "n").getParamValue()
								.equals(""))
					enterprise.setCustPriceBookId(
							addParamList.getByNameSearchWithAction("CustomerPriceBookId", "n").getParamValue());
				else
					enterprise.setCustPriceBookId("");
			}*/
			
			if ((param = getTableOrderDetaisParamWithAction(entityData, "CustomerPriceBookId", "n")) != null) {
				enterprise.setCustPriceBookId(getValueWithoutOActionDefault(param, ""));
				
			}
			
			
			/*if (!(addParamList.getByNameSearchWithAction("ContractId", "n") == null)) {
				if (!(addParamList.getByNameSearchWithAction("ContractId", "n").getParamValue() == null)
						&& !addParamList.getByNameSearchWithAction("ContractId", "n").getParamValue().equals(""))
					enterprise.setContractId(addParamList.getByNameSearchWithAction("ContractId", "n").getParamValue());
				else
					enterprise.setContractId("");
			}*/

			if ((param = getTableOrderDetaisParamWithAction(entityData, "ContractId", "n")) != null) {
				enterprise.setContractId(getValueWithoutOActionDefault(param, ""));
				
			}
			
			/*if (!(addParamList.getByNameSearchWithAction("QuoteId", "n") == null)) {
				if (!(addParamList.getByNameSearchWithAction("QuoteId", "n").getParamValue() == null)
						&& !addParamList.getByNameSearchWithAction("QuoteId", "n").getParamValue().equals(""))
					enterprise.setQuoteId(addParamList.getByNameSearchWithAction("QuoteId", "n").getParamValue());
				else
					enterprise.setQuoteId("");
			}*/
			
			
			if ((param = getTableOrderDetaisParamWithAction(entityData, "QuoteId", "n")) != null) {
				enterprise.setQuoteId(getValueWithoutOActionDefault(param, ""));
				
			}

			/*if (!(addParamList.getByNameSearchWithAction("DesignId", "n") == null)) {
				if (!(addParamList.getByNameSearchWithAction("DesignId", "n").getParamValue() == null)
						&& !addParamList.getByNameSearchWithAction("DesignId", "n").getParamValue().equals(""))
					enterprise.setDesignId(
							Long.valueOf(addParamList.getByNameSearchWithAction("DesignId", "n").getParamValue()));
				else
					enterprise.setDesignId(0);
			}*/


			if ((param = getTableOrderDetaisParamWithAction(entityData, "DesignId", "n")) != null) {
				enterprise.setDesignId(Long.valueOf(getValueWithoutOActionDefault(param, "0")));
				
			}
			
			// jan 2011 Release changes
			/*if (addParamList.getByNameSearchWithAction("NaspId", "n") != null) {
				if (addParamList.getByNameSearchWithAction("NaspId", "n").getParamValue() != null
						&& !addParamList.getByNameSearchWithAction("NaspId", "n").getParamValue().equals("")) {
					enterprise.setNaspId(addParamList.getByNameSearchWithAction("NaspId", "n").getParamValue());
				}
			}
			*/
			
			if ((param = getTableOrderDetaisParamWithAction(entityData, "NaspId", "n")) != null && (!isEmpty(param.getParamValue()))){
				enterprise.setNaspId(param.getParamValue());
				
			}
			
			log.info(" Naspid in Mod Ente : " + enterprise.getNaspId());

			// 53938.AA Business Continuity Ph 1 - changes for july 2011
			/*if (!(addParamList.getByNameSearchWithAction("LOR", "n") == null)) {
				if (!(addParamList.getByNameSearchWithAction("LOR", "n").getParamValue() == null)
						&& !addParamList.getByNameSearchWithAction("LOR", "n").getParamValue().equals(""))
					enterprise.setLorFlag(addParamList.getByNameSearchWithAction("LOR", "n").getParamValue());
			}*/
			
			if ((param = getTableOrderDetaisParamWithAction(entityData, "LOR", "n")) != null && (!isEmpty(param.getParamValue()))){
				enterprise.setLorFlag(param.getParamValue());
				
			}
			

			// Jan 2011 Release Changes - APAC
			/*if (addParamList.getByNameSearchWithAction("MarKetType", "n") != null) {
				enterprise.setCustMarket(
						Integer.parseInt(addParamList.getByNameSearchWithAction("MarKetType", "n").getParamValue()));
			}*/
			
			if ((param = getTableOrderDetaisParamWithAction(entityData, "MarKetType", "n")) != null ){
				enterprise.setCustMarket(Integer.parseInt(param.getParamValue()));
				
			}
			
			log.info(" Market Type " + enterprise.getCustMarket());

			enterprise.setLastModifiedDate(new Timestamp(System.currentTimeMillis()));

			/*if (addParamList.getByNameSearchWithAction("CatalogueReferenceTime", "n") != null) {
				if (addParamList.getByNameSearchWithAction("CatalogueReferenceTime", "n").getParamValue() != null
						&& !addParamList.getByNameSearchWithAction("CatalogueReferenceTime", "n").getParamValue()
								.equals("")) {
					Timestamp ts = Timestamp.valueOf(
							addParamList.getByNameSearchWithAction("CatalogueReferenceTime", "n").getParamValue());
					enterprise.setCatalogueReferenceTime(ts);
				}
			}*/
			
			if ((param = getTableOrderDetaisParamWithAction(entityData, "CatalogueReferenceTime", "n")) != null && (!isEmpty(param.getParamValue()))){
				Timestamp ts = Timestamp.valueOf(param.getParamValue());
				enterprise.setCatalogueReferenceTime(ts);
				
			}

			/*if (addParamList.getByNameSearchWithAction("CummulativeCcl", "n") != null) {
				if (addParamList.getByNameSearchWithAction("CummulativeCcl", "n").getParamValue() != null) {
					long val = Long
							.parseLong(addParamList.getByNameSearchWithAction("CummulativeCcl", "n").getParamValue());
					enterprise.setEntCumCcl(val);
				} else {
					enterprise.setEntCumCcl(0);
				}

			}*/
			
			
			if ((param = getTableOrderDetaisParamWithAction(entityData, "CummulativeCcl", "n")) != null ){
				Timestamp ts = Timestamp.valueOf(param.getParamValue());
				enterprise.setEntCumCcl(Long.valueOf(getValueWithoutOActionDefault(param, "0")));
				
			}
			
			

			// enterprise.setActiveInd(1);
			/**************
			 * ORDERING fields ends here
			 **************************/

			/***********
			 * Fields populated during provisioning OR not coming on the order,
			 * will be left untouced
			 *****/
			/***********
			 * PROVISIONING fields OR fields not coming on the order, starts
			 * here
			 * 
			 * enterprise.setSalesSegment(addParamList.getByNameSearch(
			 * "ContactCountry").getParamValue());
			 * enterprise.setSalesRepId(addParamList.getByNameSearch(
			 * "ContactCountry").getParamValue());
			 * enterprise.setCustCorpId(addParamList.getByNameSearch(
			 * "ContactCountry").getParamValue());
			 * enterprise.setOrderVerification(addParamList.getByNameSearch(
			 * "ContactCountry").getParamValue());
			 * enterprise.setSupportName(addParamList.getByNameSearch(
			 * "ContactCountry").getParamValue());
			 * enterprise.setSupportPhone(addParamList.getByNameSearch(
			 * "ContactCountry").getParamValue());
			 * enterprise.setXrefCustomerId(addParamList.getByNameSearch(
			 * "ContactCountry").getParamValue());
			 * enterprise.setStatusCode(addParamList.getByNameSearch(
			 * "CustomerId").getParamValue()String statusCode)
			 * enterprise.setStatusDesc(addParamList.getByNameSearch(
			 * "CustomerId").getParamValue()String statusDesc)
			 * enterprise.setCustomerType(addParamList.getByNameSearch("DAP").
			 * getParamValue()String customerType)
			 * enterprise.setCustGarmStatus(addParamList.getByNameSearch("").
			 * getParamValue()String custGarmStatus) // Need Int Conversion
			 * enterprise.setEmeaServiceSupport(Integer.parseInt(addParamList.
			 * getByNameSearch("CustomerId").getParamValue()));
			 * enterprise.setBsAsId(Integer.parseInt(addParamList.
			 * getByNameSearch("CustomerId").getParamValue()));
			 * enterprise.setCallingPlanId(Integer.parseInt(addParamList.
			 * getByNameSearch("CustomerId").getParamValue()));
			 * enterprise.setAuthServicesId(Integer.parseInt(addParamList.
			 * getByNameSearch("CustomerId").getParamValue())); // Extinct
			 * enterprise.setUsBillingSystem(addParamList.getByNameSearch(
			 * "BillingSystemType").getParamValue()); // Extinct
			 * enterprise.setEmeaBillingSystem(addParamList.getByNameSearch(
			 * "BillingSystemType").getParamValue()); // Need Long Conversion
			 * enterprise.setCustActiveInd(long custActiveInd) ;
			 * enterprise.setEntActiveInd(long entActiveInd) ;
			 * 
			 * PROVISIONING fields OR fields not coming on the order, ends here
			 **************************/

			List<DigitStringBean> digitStringAddList;
			List<DigitStringBean> digitStringDelList;
			digitStringAddList = getDigitStringList(entityBatch,"n", -1,connection);
			digitStringDelList = getDigitStringList(entityBatch,"o", -1,connection);
			if (digitStringAddList != null || digitStringDelList != null) {
				ActionFunctionHelper.extractDigitStringAddAndDeleteList(entityData, digitStringAddList, digitStringDelList,connection,enterprise);
			}

			if (!modifyAuthServicesForEnterprise(enterprise,connection, order_id))
				throw new VzbInvException("ESP_VZB_INV_MOD_ENTERPRISE_FAILED", "ESP_VZB_INV_MOD_ENTERPRISE_FAILED");

			/** Modify EntBILLFeatures Record **/
			List<TableOrderDetailsParam> pricingInfoList = searchParamListNew(entityData, "PricingInfo");//orderParam.getByNameSearchList("PricingInfo");
			List<TblEntBillFeaturesBean> billFeaturesList = new ArrayList<TblEntBillFeaturesBean>();
			boolean tnBillFeatureModified = false;
			for (TableOrderDetailsParam tmp : pricingInfoList) {
				TblEntBillFeaturesBean tblEntBillFeaturesBean = new TblEntBillFeaturesBean();
				// Commented the not SO enabled condition as it is required for
				// all type of customers
				// if (orderParam.getByNameSearch("SOEnabled") != null &&
				// "0".equals(orderParam.getByNameSearch("SOEnabled").getParamValue()))
				// {
				log.info("Setting enterprise bill features that are to be updated in the inv");

				/*if (!(orderParam.getByNameSearch("CustomerId") == null))
					tblEntBillFeaturesBean.setEnterpriseId(orderParam.getByNameSearch("CustomerId").getParamValue());*/
				
				tblEntBillFeaturesBean.setEnterpriseId(enterprise.getCustomerId());
				log.info("EnterpriseId:" + tblEntBillFeaturesBean.getEnterpriseId());

				/*
				 * if (!( orderParam.getByNameSearch("FeatureInstanceId") ==
				 * null))
				 * tblEntBillFeaturesBean.setFeatureInstanceId(Long.parseLong(
				 * orderParam.getByNameSearch("FeatureInstanceId").getParamValue
				 * ()));
				 * 
				 * if (!( orderParam.getByNameSearch("FeatureCode") == null))
				 * tblEntBillFeaturesBean.setFeatureCode(orderParam.
				 * getByNameSearch("FeatureCode").getParamValue());
				 */

				/*if (!(tmp.getByNameSearch("FeatureInstanceId") == null))
					tblEntBillFeaturesBean.setFeatureInstanceId(
							Long.parseLong(tmp.getByNameSearch("FeatureInstanceId").getParamValue()));*/

				if( (param= getTableOrderDetailsParamByName(tmp, "FeatureInstanceId") )!= null)
				{
					tblEntBillFeaturesBean.setFeatureInstanceId(Long.parseLong(param.getParamValue()));
				}
					
					
					
				/*if (!(tmp.getByNameSearch("FeatureCode") == null))
					tblEntBillFeaturesBean.setFeatureCode(tmp.getByNameSearch("FeatureCode").getParamValue());*/
				
				
				if( (param= getTableOrderDetailsParamByName(tmp, "FeatureCode") )!= null)
				{
					tblEntBillFeaturesBean.setFeatureCode(param.getParamValue());
				}
				
/*
				if (!(tmp.getByNameSearchWithAction("PBLI", "n") == null)) {
					if (!(tmp.getByNameSearchWithAction("PBLI", "n").getParamValue() == null)
							&& !tmp.getByNameSearchWithAction("PBLI", "n").getParamValue().equals("")) {
						tblEntBillFeaturesBean.setPbli(tmp.getByNameSearchWithAction("PBLI", "n").getParamValue());
						tnBillFeatureModified = true;
					}
				}*/
				
				if( (param= getTableOrderDetailsParamByNameWithAction(tmp, "PBLI","n") )!= null && !isEmpty(param.getParamValue()))
				{
					tblEntBillFeaturesBean.setPbli(param.getParamValue());
					tnBillFeatureModified = true;
				}
				

				/*if (!(tmp.getByNameSearchWithAction("ChargeType", "n") == null)) {
					if (!(tmp.getByNameSearchWithAction("ChargeType", "n").getParamValue() == null)
							&& !tmp.getByNameSearchWithAction("ChargeType", "n").getParamValue().equals("")) {
						tblEntBillFeaturesBean
								.setChargeType(tmp.getByNameSearchWithAction("ChargeType", "n").getParamValue());
						tnBillFeatureModified = true;
					}
				}*/
				
				if( (param= getTableOrderDetailsParamByNameWithAction(tmp, "ChargeType","n") )!= null && !isEmpty(param.getParamValue()))
				{
					tblEntBillFeaturesBean.setChargeType(param.getParamValue());
					tnBillFeatureModified = true;
				}
				

				/*if (!(tmp.getByNameSearchWithAction("ChargeFrequency", "n") == null)) {
					if (!(tmp.getByNameSearchWithAction("ChargeFrequency", "n").getParamValue() == null)
							&& !tmp.getByNameSearchWithAction("ChargeFrequency", "n").getParamValue().equals("")) {
						tblEntBillFeaturesBean.setChargeFrequency(
								tmp.getByNameSearchWithAction("ChargeFrequency", "n").getParamValue());
						tnBillFeatureModified = true;
					}
				}*/

				if( (param= getTableOrderDetailsParamByNameWithAction(tmp, "ChargeFrequency","n") )!= null && !isEmpty(param.getParamValue()))
				{
					tblEntBillFeaturesBean.setChargeFrequency(param.getParamValue());
					tnBillFeatureModified = true;
				}
				
				/*
				if (!(tmp.getByNameSearchWithAction("UnitOfMeasure", "n") == null)) {
					if (!(tmp.getByNameSearchWithAction("UnitOfMeasure", "n").getParamValue() == null)
							&& !tmp.getByNameSearchWithAction("UnitOfMeasure", "n").getParamValue().equals("")) {
						tblEntBillFeaturesBean
								.setUnitOfMeasure(tmp.getByNameSearchWithAction("UnitOfMeasure", "n").getParamValue());
						tnBillFeatureModified = true;
					}
				}*/

				if( (param= getTableOrderDetailsParamByNameWithAction(tmp, "UnitOfMeasure","n") )!= null && !isEmpty(param.getParamValue()))
				{
					tblEntBillFeaturesBean.setUnitOfMeasure(param.getParamValue());
					tnBillFeatureModified = true;
				}
				
				/*if (!(tmp.getByNameSearchWithAction("BillTime", "n") == null)) {
					if (!(tmp.getByNameSearchWithAction("BillTime", "n").getParamValue() == null)
							&& !tmp.getByNameSearchWithAction("BillTime", "n").getParamValue().equals("")) {
						tblEntBillFeaturesBean
								.setBillTime(tmp.getByNameSearchWithAction("BillTime", "n").getParamValue());
						tnBillFeatureModified = true;
					}
				}*/

				if( (param= getTableOrderDetailsParamByNameWithAction(tmp, "BillTime","n") )!= null && !isEmpty(param.getParamValue()))
				{
					tblEntBillFeaturesBean.setBillTime(param.getParamValue());
					tnBillFeatureModified = true;
				}
				
				
				/*if (!(tmp.getByNameSearchWithAction("CatalogueReferenceTime", "n") == null)) {
					if (!(tmp.getByNameSearchWithAction("CatalogueReferenceTime", "n").getParamValue() == null) && !tmp
							.getByNameSearchWithAction("CatalogueReferenceTime", "n").getParamValue().equals("")) {
						Timestamp ts = Timestamp
								.valueOf(tmp.getByNameSearchWithAction("CatalogueReferenceTime", "n").getParamValue());
						tblEntBillFeaturesBean.setCatalogueReferenceTime(ts);
						tnBillFeatureModified = true;
					}
				}*/

				if( (param= getTableOrderDetailsParamByNameWithAction(tmp, "CatalogueReferenceTime","n") )!= null && !isEmpty(param.getParamValue()))
				{
					Timestamp ts = Timestamp.valueOf(param.getParamValue());
					tblEntBillFeaturesBean.setCatalogueReferenceTime(ts);
					tnBillFeatureModified = true;
				}
				
				
				/*if (!(tmp.getByNameSearchWithAction("ServicePlan", "n") == null)) {
					if (!(tmp.getByNameSearchWithAction("ServicePlan", "n").getParamValue() == null)
							&& !tmp.getByNameSearchWithAction("ServicePlan", "n").getParamValue().equals("")) {
						tblEntBillFeaturesBean.setFeatureType(VzbVoipEnum.ServiceLevel
								.valueByAcronym(tmp.getByNameSearchWithAction("ServicePlan", "n").getParamValue()));
						tnBillFeatureModified = true;
					}
				}*/
				
				if( (param= getTableOrderDetailsParamByNameWithAction(tmp, "ServicePlan","n") )!= null && !isEmpty(param.getParamValue()))
				{
					tblEntBillFeaturesBean.setFeatureType(VzbVoipEnum.ServiceLevel
							.valueByAcronym(param.getParamValue()));
					tnBillFeatureModified = true;
				}
				
				

				if (tnBillFeatureModified)
					billFeaturesList.add(tblEntBillFeaturesBean);
				/*
				 * if(tnBillFeatureModified)
				 * enterprise.setEntBillFeatBean(tblEntBillFeaturesBean); else{
				 * enterprise.setEntBillFeatBean(null); }
				 */
			}

			if (billFeaturesList.size() > 0) {
				enterprise.setEntBillFeatBeanList(billFeaturesList);
			}
			if (null != enterprise.getEntBillFeatBean())
				log.info("tblEntBillFeaturesBean :: " + enterprise.getEntBillFeatBean());

			//logTrailList.add("Updating Enterprise in ESAP inventory");
			if (enterprise.modifyInDB()) {
				//logTrailList.addAll(enterprise.getLogTrail());
				/***
				 * logTrailList = enterprise.getLogTrail(); Iterator it =
				 * logTrailList.iterator(); while (it.hasNext()) { String
				 * logTrailStr = it.next().toString();
				 * insertOrderLog(INV_SUCCESS, logTrailStr ); }
				 ***/
				// insertOrderLog(INV_SUCCESS, "Successfully updated Enterprise
				// in ESAP inventory");
				//logTrailList.add("Successfully updated Enterprise in ESAP inventory");
			} else {
				//logTrailList.addAll(enterprise.getLogTrail());
				//logTrailList.add("Inventory Base Returned Error ::" + enterprise.getStatusDesc() + "::");
				log.info("Inventory Base Returned Error <" + enterprise.getStatusDesc() + ">");
				connection.rollback();
				throw new VzbInvException("ESP_VZB_INV_MOD_ENTERPRISE_FAILED", "ESP_VZB_INV_MOD_ENTERPRISE_FAILED");

			}

			// At the end commit transactions
			connection.commit();

		} catch (VzbInvException e) {
			log.error("VZB_INV_MOD_ENTERPRISE: Exception occurred while MOD ENTERPRISE "+e.getMessage());
			try {
				connection.rollback();
			} catch (Exception e1) {
				log.error("VZB_INV_MOD_ENTERPRISE: Exception occurred while MOD ENTERPRISE "+e.getMessage());
			}
			insertOrderLogError("VZB_INV_MOD_ENTERPRISE_FXO:VzbInvException"+e.getMessage());
			insertOrderLog("VzbInvException "+ e.getMessage());
			// insertOrderLog(LOG_TYPE_FAIL,e.getMessage());
			// handleActionFunctionError("VZB_INV_ADD_SUBSCRIBER_FAILED",
			// e.getMessage());
			logFinalMessage = e.getMessage();
			logSucessFail = false;
			handleActionFunctionError(e.getMessage(), e.getMessage());
			return INV_FAILURE;
		} catch (SQLException e) {
			log.error("VZB_INV_MOD_ENTERPRISE: Exception occurred while MOD ENTERPRISE "+e.getMessage());
			try {
				connection.rollback();
			} catch (Exception e1) {
				log.error("VZB_INV_MOD_ENTERPRISE: Exception occurred while MOD ENTERPRISE "+e.getMessage());
			}
			insertOrderLogError("VZB_INV_MOD_ENTERPRISE_FXO:SQLException"+e.getMessage());
			insertOrderLog("SQLException "+ e.getMessage());
			logFinalMessage = e.getMessage();
			logSucessFail = false;
			log.info("In VZB_INV_MOD_ENTERPRISE e.getErrorCode():" + e.getErrorCode());
			if (e.getErrorCode() == -60)
				handleActionFunctionError("ESP_VZB_INV_DEADLOCK", e.getMessage());
			else
				handleActionFunctionError("ESP_VZB_INV_MOD_ENTERPRISE_FAILED", e.getMessage());
			return INV_FAILURE;
		}

		catch (Exception e) {
			log.error("VZB_INV_MOD_ENTERPRISE: Exception occurred while MOD ENTERPRISE "+e.getMessage());
			try {
				connection.rollback();
			} catch (Exception e1) {
				log.error("VZB_INV_MOD_ENTERPRISE: Exception occurred while MOD ENTERPRISE "+e.getMessage());
			}
			insertOrderLogError("VZB_INV_MOD_ENTERPRISE_FXO:Exception"+e.getMessage());
			insertOrderLog("Exception "+ e.getMessage());
			// insertOrderLog(LOG_TYPE_FAIL,e.getMessage());
			logFinalMessage = e.getMessage();
			logSucessFail = false;
			handleActionFunctionError("ESP_VZB_INV_MOD_ENTERPRISE_FAILED", e.getMessage());
			return INV_FAILURE;
		} finally {
			addLogMessageToDb();
			if (logSucessFail)
				insertOrderLog("Task - VZB_INV_MOD_ENTERPRISE  completed successfully");
			else
				insertOrderLog(logFinalMessage);
		}

		return INV_SUCCESS;
	}

	
	public int getBillingSytemType(TableOrderDetailsParam param, String value) {	
    	return VzbVoipEnum.BillingSystemType.valueByAcronym(getValueWithoutOActionDefault(param, value));
	}
}
