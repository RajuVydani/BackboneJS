
package com.vz.fxo.inventory.enterprise.support;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import EsapEnumPkg.VzbVoipEnum;
import esap.db.DBTblLocPackage;
import esap.db.DBTblPackage;
import esap.db.DBTblPkgFeatures;
import esap.db.DBTblVzbFeatures;
import esap.db.TblLocPackageQuery;
import esap.db.TblPackageQuery;
import esap.db.TblPkgFeaturesDbBean;
import esap.db.TblPkgFeaturesQuery;
import esap.db.TblVzbFeaturesQuery;

public class FeaturePackage  extends FeaturePackageBean
{
	
	private static Logger log = LoggerFactory.getLogger(PublicTnPool.class.toString());
	InvErrorCode statusCode;
	String statusDesc;
	Connection dbCon;

	public InvErrorCode getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(InvErrorCode statusCode) {
		this.statusCode = statusCode;
	}	
	public String getStatusDesc() {
		return statusDesc;
	}
	public void setStatusDesc(String statusDesc) {
		this.statusDesc = statusDesc;
	}
	public Connection getDbCon() {
		return dbCon;
	}
	public void setDbCon(Connection dbCon) {
		this.dbCon = dbCon;
	}

	public FeaturePackage(Connection dbCon)
	{
		this.dbCon = dbCon;
	}

	public FeaturePackage(FeaturePackageBean  featObj, Connection dbCon)
	{
		super(featObj);
		this.dbCon = dbCon;
	}
	public boolean setDeletePending() throws SQLException
        {
                 if(featurePackageId <= 0 )
                 {      
			setStatusCode(InvErrorCode.INVALID_INPUT);
                        return false;
                 }
				 else if(featurePackageId <= 8)
				 {
					log.info("featurePackageId cannot be moved to delete pending:"+featurePackageId);
					return true;
				 }
                 DBTblPackage pkgDB = new DBTblPackage();
                 pkgDB.wherePackageIdEQ(featurePackageId);
                 pkgDB.setActiveInd(VzbVoipEnum.ActiveInd.DELETE_PENDING);
                 pkgDB.updateSpByWhere(dbCon);
                 if(pkgDB.updateSpByWhere(dbCon) <= 0)
                	 return false;   
                return true;
        }



        public boolean getFeatureListByFeaturePackageName()
        {
                /*
                //first, using pkgname query the pkgid from TBL_PACKAGE

                //second, using the pkgid , query list of featureids from TBL_PKG_FEATURES

                //third, using list of featureids, for each featureid - get details from TBL_VZB_FEATURES

                try
                {
                        TblPackageQuery pkgQry = new TblPackageQuery();
                        String whereClause = " where package_name = '" + featurePackageName + "'";
                        log.info("Before pkgQry in getFeatureListByFeaturePackageName FeaturePackage");
                        pkgQry.queryByWhere(dbCon, whereClause);
                        log.info("Before pkgQry in getFeatureListByFeaturePackageName FeaturePackage");
                        if(pkgQry.size() == 1)
                        {
                                long pkgId = (pkgQry.getDbBean(0)).getAuthServicesId();
                                if(pkgId > 0)
                                {
                                        if(!getAuthFeaturesByAuthServicesId((int)pkgId))
                                        {
                                                setStatusCode("FAILURE");
                                                setStatusDesc("FAILURE in getFeatureListByFeaturePackageName FeaturePackage. No auth services for the given  auth services id.");
                                                log.info("FAILURE in getAuthDetails Enterprise. No auth services for the given  auth services id.");
                                                return false;
                                        }
                                }
                                else
                                {
                                        setStatusCode("FAILURE");
                                        setStatusDesc("FAILURE in getFeatureListByFeaturePackageNameetails FeaturePackage. Invalid auth services id for enterprise");
                                        log.info("FAILURE in getAuthDetails Enterprise. Invalid auth services id for enterprise");
                                        return false;
                                }
                        }
                        else
                        {
                                setStatusCode("FAILURE");
                                setStatusDesc("FAILURE in getFeatureListByFeaturePackageName FeaturePackage. Invalid package_id for the given package name");
                                log.info("FAILURE in getFeatureListByFeaturePackageName FeaturePackage. Invalid package_id for the given package name");
                                return false;
                        }
                }
                catch(Exception e)
                {
			e.printStackTrace();
                        setStatusCode("FAILURE");
                        setStatusDesc("DB FAILURE in getFeatureListByFeaturePackageName for FeaturePackage");
                        return false;
                }
                setStatusCode("SUCCESS");
                setStatusDesc("Successfully retrieved getFeatureListByFeaturePackageName for FeaturePackage from the DB");
                  */
                return true;


        }
	public boolean deletePkgFeature() throws SQLException, Exception
	{
	//	try
//		{
			if(getFeaturePackageId() <= 0)
                        {
                        setStatusCode(InvErrorCode.INVALID_INPUT);
                        return false;
                        }

			log.info("In deletePkgFeature");
			DBTblPkgFeatures pkgFeature = new DBTblPkgFeatures();		
			pkgFeature.wherePackageIdEQ(getFeaturePackageId());
			int packageFeatDeleted = pkgFeature.deleteByWhere(dbCon);
			log.info("Number of Package Feature deleted:"+packageFeatDeleted);
			if(packageFeatDeleted > 0)
			{
				DBTblLocPackage locPkg = new DBTblLocPackage();
				locPkg.wherePackageIdEQ(getFeaturePackageId());
				int locPkgDeleted = locPkg.deleteByWhere(dbCon);
				log.info("Number of Location Package deleted:"+locPkgDeleted);
					DBTblPackage pkg = new DBTblPackage();
					pkg.wherePackageIdEQ(getFeaturePackageId());
					int pkgDeleted = pkg.deleteByWhere(dbCon);
					log.info("Number of Package deleted:"+pkgDeleted);
		      }
		/*}
		catch(SQLException s)
		{
			s.printStackTrace();
			setStatusCode(InvErrorCode.DB_EXCEPTION);
			setStatusDesc("DB_FAILURE in deletePkgFeature");
			log.info("DB_FAILURE in deletePkgFeature");
			return false;
		}*/
		setStatusCode(InvErrorCode.SUCCESS);
		setStatusDesc("Successfully deleted Package Feature");
		return true;
	}	
	/**
	 * The method to modify the Feature Package record.
	 *
	 * Feature Package Id should be set before calling this method.
	 *
	 * @return	true	Record has been updated SUCCESSFULLY
	 * 			false	Feature Package Id missing / Record update Unsuccessful /
	 * 					Some Error occured.
	 */
	public boolean modifyFeaturePackageInDB() throws SQLException, Exception{
	//	try
	//	{
			if (getFeaturePackageId() <= 0) {
				setStatusCode(InvErrorCode.INVALID_INPUT);
				setStatusDesc("FAILURE in modifyPkgFeatureInDB PackageFeatures. FeaturePackageId missing.");
				log.info("FAILURE in modifyPkgFeatureInDB PackageFeatures. FeaturePackageId missing.");
				return false;
			}
			//if(featurePackageId <= 7)
		if(!isPkgCanModify(featurePackageId))	
        {
            log.info("modifyFeaturePackageInDB:FEATURE_PKG_TEMPLATE_CANNOT_BE_MODIFIED");
            setStatusCode(InvErrorCode.FEATURE_PKG_TEMPLATE_CANNOT_BE_MODIFIED);
            return false;
        }

			//update TBL_PACKAGE
			DBTblPackage pkgBean = getPackageToUpdate();
			pkgBean.wherePackageIdEQ(getFeaturePackageId());
			pkgBean.updateSpByWhere(dbCon);
		        if(pkgBean.updateSpByWhere(dbCon) <= 0)
					return false; 	
			/*ArrayList<DBTblPkgFeatures> pkgFeaturesDbBeanList = new ArrayList<DBTblPkgFeatures>();
			pkgFeaturesDbBeanList = getPackageFeaturesToUpdate(ArrayList<Integer> features);*/
			/*for (int i = 0; i < features.size(); i++) 
			{
				DBTblPkgFeatures pkgFeatureBean = getPackageFeaturesToUpdate(features.get(i));
				pkgFeatureBean.wherePackageIdEQ(getFeaturePackageId());		
				pkgFeatureBean.updateSpByWhere(dbCon);
			}
			
			//update TBL_LOC_PACKAGE
			DBTblLocPackage locPkgBean = getLocationPackageToUpdate();
			locPkgBean.whereLocPackageIdEQ(new Long(getLocPkgId()).intValue());
			locPkgBean.updateSpByWhere(dbCon);	
			*/

		/*} catch(SQLException s) {
			s.printStackTrace();
			setStatusCode(InvErrorCode.DB_EXCEPTION);
			setStatusDesc("DB_FAILURE in modifyPkgFeatureInDB PackageFeatures");
			log.info("DB_FAILURE in modifyPkgFeatureInDB PackageFeatures");
			return false;
		}*/
		setStatusCode(InvErrorCode.SUCCESS);
		setStatusDesc("Successfully UPDATED PackageFeatures into the DB");
	
		return true;
	}
	
	private boolean isPkgCanModify(long packageId) throws SQLException{
        TblPackageQuery pkgQry = new TblPackageQuery();
        String whereClause = " where package_id = " + packageId +
                        " and template_ind = 1";
        pkgQry.queryByWhere(dbCon, whereClause);
        if(pkgQry.size() >0)
	{
    		return false;
	}
        return true;
	}	
	/**
	 * The current Package details are extracted using getPackageDetails()
	 * and the new field values are updated over that. The method
	 * will update the fields that are supplied on the current instance
	 * if they are different from the default values for the respective field.
	 *
	 * @return The Package to be updated.
	 */
	@SuppressWarnings("unused")
	private DBTblPackage getPackageToUpdate() throws SQLException{
		DBTblPackage packageDbBean = new DBTblPackage();

		/* Create a new instance of DeviceBean. The new instance
		 * would hold default values for the all the  Device fields.*/
		FeaturePackageBean defaultPkgFeatureBean = new FeaturePackageBean();


		FeaturePackage inputPkgFeature = this;

		/*Set the new fields if required.*/
		packageDbBean.setPackageId(getFeaturePackageId());

		if ( inputPkgFeature.getFeaturePackageName() != null &&
				!inputPkgFeature.getFeaturePackageName().equals(defaultPkgFeatureBean.getFeaturePackageName())){
			packageDbBean.setPackageName(inputPkgFeature.getFeaturePackageName());
		}
		
		if ( inputPkgFeature.getFeaturePackageType() != defaultPkgFeatureBean.getFeaturePackageType()){
			packageDbBean.setPackageType(inputPkgFeature.getFeaturePackageType());
		}

		if ( inputPkgFeature.getTemplateInd() != defaultPkgFeatureBean.getTemplateInd()){
			if(inputPkgFeature.getTemplateInd() != -2 )	
				packageDbBean.setTemplateInd(inputPkgFeature.getTemplateInd());
			else
				packageDbBean.setTemplateIndNull();
		}

		if ( inputPkgFeature.getActiveInd() != defaultPkgFeatureBean.getActiveInd()) {
                        packageDbBean.setActiveInd(inputPkgFeature.getActiveInd());
                }
	    if ( inputPkgFeature.getEnvOrderId() != defaultPkgFeatureBean.getEnvOrderId()) {
	        	if(inputPkgFeature.getTemplateInd() != 0 )	
                        packageDbBean.setEnvOrderId(inputPkgFeature.getEnvOrderId());
	        	else
	        		packageDbBean.setEnvOrderIdNull();
		}	
		if(inputPkgFeature.getModifiedBy() != null &&
				!( "".equalsIgnoreCase(inputPkgFeature.getModifiedBy()) ) )
			packageDbBean.setModifiedBy(getModifiedBy());
	    	else
	       		packageDbBean.setModifiedBy("ESAP_INV");
		
		packageDbBean.setLastModifiedDate(new Timestamp(System.currentTimeMillis()));
		
		return packageDbBean;
		
	}
	public boolean getPackageDetails() throws SQLException
	{
		try
		{
			log.info("In getPackageDetails; Package id="+getFeaturePackageId());
			TblPackageQuery pkgQry = new TblPackageQuery();
			initilizeTODefault();
			String whereClause = new String("");
			if(getAll == false)
				whereClause = " where package_id = "+getFeaturePackageId()+" and active_ind = 1";
			else
				whereClause = " where package_id = "+getFeaturePackageId()+" and active_ind != 0";
			pkgQry.queryByWhere(dbCon, whereClause);
			if(pkgQry.size() == 1){
				setFeaturePackageId((int)(pkgQry.getDbBean(0)).getPackageId());
				setFeaturePackageName((pkgQry.getDbBean(0)).getPackageName());
				setFeaturePackageType((pkgQry.getDbBean(0)).getPackageType());
				setTemplateInd((pkgQry.getDbBean(0)).getTemplateInd());
				setActiveInd((pkgQry.getDbBean(0)).getActiveInd());
	                        setEnvOrderId(pkgQry.getDbBean(0).getEnvOrderId()); 	
                 		setModifiedBy((pkgQry.getDbBean(0)).getModifiedBy());
				setCreatedBy((pkgQry.getDbBean(0)).getCreatedBy());
				setCreatedDate((pkgQry.getDbBean(0)).getCreationDate());
				TblPkgFeaturesQuery pkgFeatQry = new TblPkgFeaturesQuery();
			String whereClause1 = " where package_id = "+getFeaturePackageId();

                    pkgFeatQry.queryByWhere(dbCon, whereClause1);
                    if (pkgFeatQry.size() > 0)
                    {
                        for (int j = 0; j < pkgFeatQry.size(); j++)
                        {

                            Object oPkgFeatBean = pkgFeatQry.getDbBean(j);

                            if (oPkgFeatBean != null)
                            {
                                TblPkgFeaturesDbBean pkgFeatBean = (TblPkgFeaturesDbBean) oPkgFeatBean;

                                long featId = Long.parseLong(pkgFeatBean.getFeatureId());

                                TblVzbFeaturesQuery vzbFeatQry = new TblVzbFeaturesQuery();
                                whereClause = " where feature_id = " + featId;

                                vzbFeatQry.queryByWhere(dbCon, whereClause);
                                if (vzbFeatQry.size() > 0)
                                {
					DBTblVzbFeatures vzbFeatObj = new DBTblVzbFeatures();
                    			vzbFeatObj.copyFromBean(vzbFeatQry.getDbBean(0));

                                        FeaturesBean featBean = new FeaturesBean();
                    			featBean.setFeaturesDbBean(vzbFeatObj);
                                        featBean.setIsSelected(pkgFeatBean.getIsSelected().equals("Y")? true : false);
                                        if (featureList == null)
                                            featureList = new ArrayList<FeaturesBean>();
                                        featureList.add(featBean); 
                                }

                            }

                        }

                    }
			TblLocPackageQuery locPkgQry = new TblLocPackageQuery();
			locPkgQry.wherePackageIdEQ(getFeaturePackageId());
			locPkgQry.query(dbCon);
			if(locPkgQry.size() > 0)
			{
				setLocationId(locPkgQry.getDbBean(0).getLocationId());
			}
		}else
			{
				setStatusCode(InvErrorCode.INTERNAL_ERROR);
				return false;
			}
			
		}catch(SQLException s)
		{
			s.printStackTrace();
			setStatusCode(InvErrorCode.DB_EXCEPTION);
           return false;
		}
		setStatusCode(InvErrorCode.SUCCESS);
		return true;
	}

	public boolean addFeaturesToPackage() throws SQLException, Exception

	{
	//	try
	//	{
		if(featurePackageId <= 0 || featureList == null || featureList.size() <= 0)
		{
			log.info("addFeaturesToPackage:INVALID_INPUT");
			setStatusCode(InvErrorCode.INVALID_INPUT);
			return false;
		}

		if(featurePackageId <= 7)
		{
			log.info("addFeaturesToPackage:FEATURE_PKG_TEMPLATE_CANNOT_BE_MODIFIED");
			setStatusCode(InvErrorCode.FEATURE_PKG_TEMPLATE_CANNOT_BE_MODIFIED);
			return false;
		}
		
		for(int i = 0; i < featureList.size(); i++)
		{
			DBTblVzbFeatures vzbFeatBean = featureList.get(i).getFeaturesDbBean();
			log.info("Adding features to pkg:"+vzbFeatBean.getFeatureId());
			DBTblPkgFeatures pkgFeatBean = new DBTblPkgFeatures();
			int pkgFeatId = pkgFeatBean.getPkgFeatureIdSeqNextVal(dbCon);
			pkgFeatBean.setPkgFeatureId(pkgFeatId);
			pkgFeatBean.setPackageId(featurePackageId);
			if(featureList.get(i).getIsSelected() == true)
				pkgFeatBean.setIsSelected("Y");
			else
				pkgFeatBean.setIsSelected("N");
			pkgFeatBean.setFeatureId(Integer.toString(vzbFeatBean.getFeatureId()));
	                if(getEnvOrderId() > 0)
				pkgFeatBean.setEnvOrderId(getEnvOrderId());		
			else
				pkgFeatBean.setEnvOrderIdNull();
                 	if( getModifiedBy() != null && !( "".equalsIgnoreCase(getModifiedBy()) ) ) {
                                pkgFeatBean.setModifiedBy(getModifiedBy());
                        } else {
                                pkgFeatBean.setModifiedBy("ESAP_INV");
                        }
                        if( getCreatedBy() != null && !( "".equalsIgnoreCase(getCreatedBy()) ) ) {
                                pkgFeatBean.setCreatedBy(getCreatedBy());
                        } else {
                                pkgFeatBean.setCreatedBy("ESAP_INV");
                        }
			pkgFeatBean.setCreationDate(new Timestamp(System.currentTimeMillis()));
                	pkgFeatBean.setLastModifiedDate(new Timestamp(System.currentTimeMillis()));
			pkgFeatBean.insert(dbCon);
		}
		/*}
		catch(SQLException s)
                {
			s.printStackTrace();
                        setStatusCode(InvErrorCode.DB_EXCEPTION);
           		return false;
                }*/

		return true;
	}

	public boolean updateFeaturesToPackage() throws SQLException, Exception
	{
		//try
		//{
			if(featurePackageId <= 0 || featureList == null || featureList.size() <= 0)
			{
				setStatusCode(InvErrorCode.INVALID_INPUT);
				return false;
			}
			if(featurePackageId <= 7)
        {
            log.info("updateFeaturesToPackage:FEATURE_PKG_TEMPLATE_CANNOT_BE_MODIFIED");
            setStatusCode(InvErrorCode.FEATURE_PKG_TEMPLATE_CANNOT_BE_MODIFIED);
            return false;
        }

			for(int i = 0; i < featureList.size(); i++)
			{
				DBTblVzbFeatures vzbFeatBean = featureList.get(i).getFeaturesDbBean();
				DBTblPkgFeatures pkgFeatBean = new DBTblPkgFeatures();
	
				if(featureList.get(i).getIsSelected() == true)
					pkgFeatBean.setIsSelected("Y");
				else
					pkgFeatBean.setIsSelected("N");
				//pkgFeatBean.setFeatureId(Integer.toString(vzbFeatBean.getFeatureId()));
                                if(getEnvOrderId() > 0)
					pkgFeatBean.setEnvOrderId(getEnvOrderId());       
				else
					pkgFeatBean.setEnvOrderIdNull();       

				if( getModifiedBy() != null && !( "".equalsIgnoreCase(getModifiedBy()) ) ) {
					pkgFeatBean.setModifiedBy(getModifiedBy());
				} else {
						pkgFeatBean.setModifiedBy("ESAP_INV");
				}
	            if( getCreatedBy() != null && !( "".equalsIgnoreCase(getCreatedBy()) ) ) {
	                    pkgFeatBean.setCreatedBy(getCreatedBy());
	            } else {
	                    pkgFeatBean.setCreatedBy("ESAP_INV");
	            }
	            //IR #1412805 should not override the creationdate for update calls

				//pkgFeatBean.setCreationDate(new Timestamp(System.currentTimeMillis()));
	        	pkgFeatBean.setLastModifiedDate(new Timestamp(System.currentTimeMillis()));
	        	pkgFeatBean.wherePackageIdEQ(featurePackageId);
				pkgFeatBean.whereFeatureIdEQ(Integer.toString(vzbFeatBean.getFeatureId()));
	        	
				//pkgFeatBean.insert(dbCon);
                        if(pkgFeatBean.updateSpByWhere(dbCon) <= 0)
	        		return false;      	
                       }
		/*}
		catch(SQLException s){
			s.printStackTrace();
			setStatusCode(InvErrorCode.DB_EXCEPTION);
            return false;
		}*/

		return true;
	}
	
	public boolean deleteFeaturesFromPackage() throws SQLException, Exception

        {
//                try
 //               {
                if(featurePackageId <= 0 || featureList == null || featureList.size() <= 0)
                {
                        setStatusCode(InvErrorCode.INVALID_INPUT);
                        return false;
                }
				if(featurePackageId <= 7)
        {
            log.info("deleteFeaturesFromPackage:FEATURE_PKG_TEMPLATE_CANNOT_BE_MODIFIED");
            setStatusCode(InvErrorCode.FEATURE_PKG_TEMPLATE_CANNOT_BE_MODIFIED);
            return false;
        }

                for(int i = 0; i < featureList.size(); i++)
                {
                        DBTblVzbFeatures vzbFeatBean = featureList.get(i).getFeaturesDbBean();
                        DBTblPkgFeatures pkgFeatBean = new DBTblPkgFeatures();
						pkgFeatBean.wherePackageIdEQ(featurePackageId);
						pkgFeatBean.whereFeatureIdEQ(Integer.toString(vzbFeatBean.getFeatureId()));
                       pkgFeatBean.deleteByWhere(dbCon);
               }
               /*}
                catch(SQLException s)
                {
                        s.printStackTrace();
                        setStatusCode(InvErrorCode.DB_EXCEPTION);
			return false;
                }*/

                return true;
        }


	
	/**
	 * The current PackageFeatures details are extracted using getPackageFeaturesDetails()
	 * and the new field values are updated over that. The method
	 * will update the fields that are supplied on the current instance
	 * if they are different from the default values for the respective field.
	 *
	 * @return The PackageFeatures to be updated.
	 */
	@SuppressWarnings("unused")
/*
	private  DBTblPkgFeatures getPackageFeaturesToUpdate(int feature) throws SQLException{
		//ArrayList<DBTblPkgFeatures> pkgFeaturesDbBeanList = new ArrayList<DBTblPkgFeatures>();
		//for (int i = 0; i < feats.size(); i++) {
		DBTblPkgFeatures pkgFeaturesDbBean = new DBTblPkgFeatures();
		/ * Create a new instance of DeviceBean. The new instance
		 * would hold default values for the all the  Device fields.* /
		FeaturePackageBean defaultPkgFeaturesBean = new FeaturePackageBean();



		FeaturePackage inputPkgFeatures = this;
		inputPkgFeatures.setFeatureId(Integer.toString(feature));
		/ *Set the new fields if required.* /
		pkgFeaturesDbBean.setPackageId(getFeaturePackageId());

		if ( inputPkgFeatures.getFeatureId() != defaultPkgFeaturesBean.getFeatureId()){
			pkgFeaturesDbBean.setFeatureId(inputPkgFeatures.getFeatureId());
		}

		if ( inputPkgFeatures.getIsSelected() != null &&
				!inputPkgFeatures.getIsSelected().equals(defaultPkgFeaturesBean.getIsSelected())){
			pkgFeaturesDbBean.setIsSelected(inputPkgFeatures.getIsSelected());
		}

		if(!getModifiedBy().equals(""))
			pkgFeaturesDbBean.setModifiedBy(getPkgFeatModifiedBy());
		else
			pkgFeaturesDbBean.setModifiedBy("ESAP_INV");

		pkgFeaturesDbBean.setLastModifiedDate(new Timestamp(System.currentTimeMillis()));
		return pkgFeaturesDbBean;

		//pkgFeaturesDbBeanList.add(pkgFeaturesDbBean);
		//}
		//log.info("In getPackageFeaturesToUpdate() pkgFeaturesDbBeanList Size : "+pkgFeaturesDbBeanList.size());
		//return pkgFeaturesDbBeanList;

	}
	public boolean getPackageFeaturesDetails() throws SQLException
	{
		try
		{
			log.info("In getPackageDetails; Package id="+getFeaturePackageId());
			TblPkgFeaturesQuery pkgFeaturesQry = new TblPkgFeaturesQuery();
			String whereClause = " where package_id = "+getFeaturePackageId();
			pkgFeaturesQry.queryByWhere(dbCon, whereClause);
			if(pkgFeaturesQry.size() == 1){
				setFeaturePackageId((pkgFeaturesQry.getDbBean(0)).getPackageId());
				setFeatureId((pkgFeaturesQry.getDbBean(0)).getFeatureId());
				setIsSelected((pkgFeaturesQry.getDbBean(0)).getIsSelected());
				setPkgFeatModifiedBy((pkgFeaturesQry.getDbBean(0)).getModifiedBy());
				setPkgFeatCreatedBy((pkgFeaturesQry.getDbBean(0)).getCreatedBy());
				setPkgFeatCreatedDate((pkgFeaturesQry.getDbBean(0)).getCreationDate());
			}else
			{
				setStatusCode(InvErrorCode.INTERNAL_ERROR);
				return false;
			}
			
		}catch(SQLException s)
		{
			s.printStackTrace();
			setStatusCode(InvErrorCode.DB_EXCEPTION);
           return false;
		}
		setStatusCode(InvErrorCode.SUCCESS);
		return true;
	}
	/ **
	 * The current PackageFeatures details are extracted using getLoactionPackageDetails()
	 * and the new field values are updated over that. The method
	 * will update the fields that are supplied on the current instance
	 * if they are different from the default values for the respective field.
	 *
	 * @return The Location Package to be updated.
	 * /
	@SuppressWarnings("unused")
	private  DBTblLocPackage getLocationPackageToUpdate() throws SQLException{
		DBTblLocPackage locPkgDbBean = new DBTblLocPackage();
		
		/ * Create a new instance of DeviceBean. The new instance
		 * would hold default values for the all the  Device fields.* /
		FeaturePackageBean defaultLocPkgBean = new FeaturePackageBean();


		FeaturePackage inputLocPkg = this;
		
		/ *Set the new fields if required.* /
		locPkgDbBean.setLocPackageId(new Long(getLocPkgId()).intValue());
		
		/ *locPkgDbBean.setLocationId(currentLocPkg.getLocationId());
		if ( inputLocPkg.getLocationId() != null &&
				!inputLocPkg.getLocationId().equals(defaultLocPkgBean.getLocationId())){
			locPkgDbBean.setLocationId(inputLocPkg.getLocationId());
		}* /
		
		if ( inputLocPkg.getPackageId() != defaultLocPkgBean.getPackageId()){
			locPkgDbBean.setPackageId(inputLocPkg.getPackageId());
		}

		if ( inputLocPkg.getIsDefault() != defaultLocPkgBean.getIsDefault()){
			locPkgDbBean.setIsDefault(inputLocPkg.getIsDefault());
		}
		
		if(getModifiedBy() != null && !getModifiedBy().equals(""))
			locPkgDbBean.setModifiedBy(getLocPkgModifiedBy());
		else
			locPkgDbBean.setModifiedBy("ESAP_INV");

		locPkgDbBean.setLastModifiedDate(new Timestamp(System.currentTimeMillis()));
		return locPkgDbBean;

		//pkgFeaturesDbBeanList.add(pkgFeaturesDbBean);
		//}
		//log.info("In getPackageFeaturesToUpdate() pkgFeaturesDbBeanList Size : "+pkgFeaturesDbBeanList.size());
		//return pkgFeaturesDbBeanList;

	}
	public boolean getLoactionPackageDetails() throws SQLException
	{
		try
		{
			log.info("In getPackageDetails; Package id="+getFeaturePackageId());
			TblLocPackageQuery LocPkgQry = new TblLocPackageQuery();
			String whereClause = " where loc_package_id = "+getLocPkgId();
			LocPkgQry.queryByWhere(dbCon, whereClause);
			if(LocPkgQry.size() == 1){
				setLocationId((LocPkgQry.getDbBean(0)).getLocationId());
				setFeaturePackageId((LocPkgQry.getDbBean(0)).getPackageId());
				setIsDefault((LocPkgQry.getDbBean(0)).getIsDefault());
				setLocPkgModifiedBy((LocPkgQry.getDbBean(0)).getModifiedBy());
				setLocPkgCreatedBy((LocPkgQry.getDbBean(0)).getCreatedBy());
				setLocPkgCreatedDate((LocPkgQry.getDbBean(0)).getCreationDate());
			}else
			{
				setStatusCode(InvErrorCode.INTERNAL_ERROR);
				return false;
			}
			
		}catch(SQLException s)
		{
			s.printStackTrace();
			setStatusCode(InvErrorCode.DB_EXCEPTION);
           return false;
		}
		setStatusCode(InvErrorCode.SUCCESS);
		return true;
	}
	*/
	public boolean addToDB() throws SQLException, Exception{
		long seqId = -1;
		log.info("FeaturePackage: addPackage()");
	//	try {
			DBTblPackage pkgDbBean = new DBTblPackage();
			setCreatedDate(new Timestamp(System.currentTimeMillis()));
			setModifiedDate(new Timestamp(System.currentTimeMillis()));
			if(getCreatedBy() != null && !getCreatedBy().equals(""))
				pkgDbBean.setCreatedBy(getCreatedBy());
		   	else
		    	pkgDbBean.setCreatedBy("ESAP_INV");
							
			if(getModifiedBy() != null && !getModifiedBy().equals(""))
				pkgDbBean.setModifiedBy(getModifiedBy());
		    	else
		    	pkgDbBean.setModifiedBy("ESAP_INV");
			if(getFeaturePackageId() <=  0)
			{
				featurePackageId =  (int)pkgDbBean.getPackageIdSeqNextVal(dbCon);
			}
		        pkgDbBean.setPackageId(getFeaturePackageId());
			pkgDbBean.setPackageType(getFeaturePackageType());
			pkgDbBean.setPackageName(getFeaturePackageName());
			if(getTemplateInd() != -1 )
			pkgDbBean.setTemplateInd(getTemplateInd());
			pkgDbBean.setCreationDate(getCreatedDate());
			pkgDbBean.setLastModifiedDate(getModifiedDate());
			pkgDbBean.setActiveInd(getActiveInd());
                        if(getEnvOrderId() > 0)
				pkgDbBean.setEnvOrderId(getEnvOrderId()); 
			else
				pkgDbBean.setEnvOrderIdNull(); 
			log.info("PackageId=" + getFeaturePackageId()
					+ ", PackageType= " + getFeaturePackageName() + ", TemplateInd"
					+ getTemplateInd());
			pkgDbBean.insert(dbCon);
			//Need to map features to this package

		/*} catch (SQLException s) {
			s.printStackTrace();
			setStatusCode(InvErrorCode.DB_EXCEPTION);
			setStatusDesc("DB_FAILURE in LocationFeaturePackage : " +
					"createPackage");
			log.info("DB_FAILURE in LocationFeaturePackage : " +
					"createPackage");
			return false;
		}*/
		/*

		log.info("LocationFeaturePackage: addPackageFeature() size"
				+ feats.size());
		for (int i = 0; i < feats.size(); i++) {
			try {
				DBTblPkgFeatures pkgFeatDbBean = new DBTblPkgFeatures();
				seqId = -1;
				seqId = pkgFeatDbBean.getPkgFeatureIdSeqNextVal(dbCon);
				log.info("LocationFeaturePackage: addPackageFeature() " +
						"seqId" + seqId);
				if (seqId > 0) {
					setPkgFeatureId(seqId);
                                        setPkgFeatCreatedBy("ESAP_INV");
					setPkgFeatModifiedBy("ESAP_INV");
					setPkgFeatCreatedDate(new Timestamp(System
							.currentTimeMillis()));
					setPkgFeatModifiedDate(new Timestamp(System
							.currentTimeMillis()));

					pkgFeatDbBean.setFeatureId(Integer.toString(feats.get(i)));
					pkgFeatDbBean.setPkgFeatureId(new Long(getPkgFeatureId())
							.intValue());
					pkgFeatDbBean.setPackageId(new Long(getFeaturePackageId())
							.intValue());
					pkgFeatDbBean.setIsSelected(getIsSelected());
					pkgFeatDbBean.setCreatedBy(getPkgFeatCreatedBy());
					pkgFeatDbBean.setCreationDate(getPkgFeatCreatedDate());
					pkgFeatDbBean.setModifiedBy(getPkgFeatModifiedBy());
					pkgFeatDbBean.setLastModifiedDate(getPkgFeatModifiedDate());
					log.info("PackageId=" + getFeaturePackageId()
							+ ", FeatureId " + feats.get(i)
							+ "PackageFeatureId= " + getPkgFeatureId()
							+ ", isSelected" + getIsSelected() + "createdBy"
							+ getPkgFeatCreatedBy() + "createdDate"
							+ getPkgFeatCreatedDate() + "modifiedBy"
							+ getPkgFeatModifiedBy() + " modifiedDate "
							+ getPkgFeatModifiedDate());
					pkgFeatDbBean.insert(dbCon);
				}
			} catch (SQLException s) {
				s.printStackTrace();
				setStatusCode(InvErrorCode.DB_EXCEPTION);
				setStatusDesc("DB_FAILURE in LocationFeaturePackage :" +
						"createPackageFeature");
				log.info("DB_FAILURE in LocationFeaturePackage :" +
						"createPackageFeature");
				return false;
			}
		}
		*/
		log.info("LocationFeaturePackage: addLocationPackage()");
		try {
			DBTblLocPackage locPkgDbBean = new DBTblLocPackage();
			seqId = -1;
			seqId = locPkgDbBean.getLocPackageIdSeqNextVal(dbCon);
			log.info("LocationFeaturePackage: addLocationPackage() " +
					"seqId"	+ seqId);
			if (seqId > 0) {

				locPkgDbBean.setLocationId(String.valueOf(seqId));
	                        if(getEnvOrderId() > 0)
			                locPkgDbBean.setEnvOrderId(getEnvOrderId()); 	
				else
			                locPkgDbBean.setEnvOrderIdNull(); 	
                 		setCreatedDate(new Timestamp(System.currentTimeMillis()));
				setModifiedDate(new Timestamp(System.currentTimeMillis()));
				if(getCreatedBy() != null && !getCreatedBy().equals(""))
					locPkgDbBean.setCreatedBy(getCreatedBy());
			   	else
			    	locPkgDbBean.setCreatedBy("ESAP_INV");
								
				if(getModifiedBy() != null && !getModifiedBy().equals(""))
					locPkgDbBean.setModifiedBy(getModifiedBy());
			    	else
			    	locPkgDbBean.setModifiedBy("ESAP_INV");

				locPkgDbBean.setLocationId(getLocationId());
				locPkgDbBean.setPackageId(new Long(getFeaturePackageId()).intValue());
				locPkgDbBean.setIsDefault(getIsDefault());
				locPkgDbBean.setCreationDate(getCreatedDate());
				locPkgDbBean.setLastModifiedDate(getModifiedDate());
				log.info("PackageId=" + getFeaturePackageId()
						+ ", LocationId= " + getLocationId() + ", isDefault"
						+ getIsDefault() + "createdBy" + getCreatedBy()
						+ "createdDate" + getCreatedDate() + "modifiedBy"
						+ getModifiedBy() + " modifiedDate "
						+ getModifiedDate());
				locPkgDbBean.insert(dbCon);
			}
		} catch (SQLException s) {
			s.printStackTrace();
			setStatusCode(InvErrorCode.DB_EXCEPTION);
			setStatusDesc("DB_FAILURE in LocationFeaturePackage : createLocationPackage ");
			log.info("DB_FAILURE in LocationFeaturePackage : createLocationPackage");
			return false;
		}
		//*/
		setStatusCode(InvErrorCode.SUCCESS);
		setStatusDesc("Successfully inserted location feature package into the DB");
		return true;
	}	
}

