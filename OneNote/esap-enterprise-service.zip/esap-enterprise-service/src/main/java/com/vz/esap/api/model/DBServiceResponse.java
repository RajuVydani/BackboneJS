package com.vz.esap.api.model;

import java.util.List;

public class DBServiceResponse {
	private Long numberOfRecords;
	private String dbOperation;
	private String tableName;
	private Long queryReferenceId;
	private List<TblRow> tableRows;
	
	public Long getNumberOfRecords() {
		return numberOfRecords;
	}

	public void setNumberOfRecords(Long numberOfRecords) {
		this.numberOfRecords = numberOfRecords;
	}

	public String getDbOperation() {
		return dbOperation;
	}

	public void setDbOperation(String dbOperation) {
		this.dbOperation = dbOperation;
	}

	public String getTableName() {
		return tableName;
	}

	public void setTableName(String tableName) {
		this.tableName = tableName;
	}

	public Long getQueryReferenceId() {
		return queryReferenceId;
	}

	public void setQueryReferenceId(Long queryReferenceId) {
		this.queryReferenceId = queryReferenceId;
	}

	public List<TblRow> getTableRows() {
		return tableRows;
	}

	public void setTableRows(List<TblRow> tableRows) {
		this.tableRows = tableRows;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("DBServiceResponse [numberOfRecords=");
		builder.append(numberOfRecords);
		builder.append(", dbOperation=");
		builder.append(dbOperation);
		builder.append(", tableName=");
		builder.append(tableName);
		builder.append(", queryReferenceId=");
		builder.append(queryReferenceId);
		builder.append(", tableRows=");
		builder.append(tableRows);
		builder.append("]");
		return builder.toString();
	}
	
	


	
	
}
