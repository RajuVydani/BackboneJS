package com.vz.esap.api.model.ordering;

import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.vz.fxo.inventory.enterprise.helper.ActionFunctionHelper;

public class TableOrderDetailsParam {
		
	private String orderDetailId;
	private String orderId;
	private String sequenceNo;
	private String paramType;
	private String action;
	private String paramName;
	private String paramValue;
	private String parentId;
	private Long flowStatus;
	private Long leaf;
	private List<TableOrderDetailsParam> paramDetail;
	private Vector<TableOrderDetailsParam>  _Params = null;
	
	
	public TableOrderDetailsParam(TableOrderDetailsParamBuilder tableOrderDetailsParamBuilder) {
		this.orderDetailId = tableOrderDetailsParamBuilder.orderDetailId;
		this.orderId = tableOrderDetailsParamBuilder.orderId;
		this.sequenceNo = tableOrderDetailsParamBuilder.sequenceNo;
		this.paramType = tableOrderDetailsParamBuilder.paramType;
		this.action = tableOrderDetailsParamBuilder.action;
		this.paramName = tableOrderDetailsParamBuilder.paramName;
		this.paramValue = tableOrderDetailsParamBuilder.paramValue;
		this.parentId = tableOrderDetailsParamBuilder.parentId;
		this.flowStatus = tableOrderDetailsParamBuilder.flowStatus;
		this.leaf = tableOrderDetailsParamBuilder.leaf;
		this.paramDetail = tableOrderDetailsParamBuilder.paramDetail;
	}
	
	public String getOrderDetailId() {
		return orderDetailId;
	}
	public void setOrderDetailId(String orderDetailId) {
		this.orderDetailId = orderDetailId;
	}
	public String getOrderId() {
		return orderId;
	}
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
	public String getSequenceNo() {
		return sequenceNo;
	}
	public void setSequenceNo(String sequenceNo) {
		this.sequenceNo = sequenceNo;
	}
	public String getParamType() {
		return paramType;
	}
	public void setParamType(String paramType) {
		this.paramType = paramType;
	}
	public String getAction() {
		return action;
	}
	public void setAction(String action) {
		this.action = action;
	}
	public String getParamName() {
		return paramName;
	}
	public void setParamName(String paramName) {
		this.paramName = paramName;
	}
	public String getParamValue() {
		return paramValue;
	}
	public void setParamValue(String paramValue) {
		this.paramValue = paramValue;
	}
	public String getParentId() {
		return parentId;
	}
	public void setParentId(String parentId) {
		this.parentId = parentId;
	}
	public Long getFlowStatus() {
		return flowStatus;
	}
	public void setFlowStatus(Long flowStatus) {
		this.flowStatus = flowStatus;
	}
	public Long getLeaf() {
		return leaf;
	}
	public void setLeaf(Long leaf) {
		this.leaf = leaf;
	}
	public List<TableOrderDetailsParam> getParamDetail() {
		return paramDetail;
	}
	public void setParamDetail(List<TableOrderDetailsParam> paramDetail) {
		this.paramDetail = paramDetail;
	}
	
	@Override
	public String toString() {
		Gson gson = new GsonBuilder().setPrettyPrinting().create();
		String json = gson.toJson(this);
		return json;
		
		/*StringBuilder builder = new StringBuilder();
		builder.append("\n TableOrderDetailsParam \n \t\t\t\t [orderDetailId=");
		builder.append(orderDetailId);
		builder.append(", orderId=");
		builder.append(orderId);
		builder.append(", sequenceNo=");
		builder.append(sequenceNo);
		builder.append(", paramType=");
		builder.append(paramType);
		builder.append(", action=");
		builder.append(action);
		builder.append(", paramName=");
		builder.append(paramName);
		builder.append(", paramValue=");
		builder.append(paramValue);
		builder.append(", parentId=");
		builder.append(parentId);
		builder.append(", flowStatus=");
		builder.append(flowStatus);
		builder.append(", leaf=");
		builder.append(leaf);
		builder.append(", paramDetail=");
		builder.append(paramDetail);
		builder.append("]");
		return builder.toString();*/
	}

	public static class TableOrderDetailsParamBuilder {
		private String orderDetailId;
		private String orderId;
		private String sequenceNo;
		private String paramType;
		private String action;
		private String paramName;
		private String paramValue;
		private String parentId;
		private Long flowStatus;
		private Long leaf;
		public List<TableOrderDetailsParam> paramDetail = new ArrayList<>();
		
		public TableOrderDetailsParamBuilder withOrderDetailId(String orderDetailId) {
			this.orderDetailId = orderDetailId;
			return this;
		}
		public TableOrderDetailsParamBuilder withOrderId(String orderId) {
			this.orderId = orderId;
			return this;
		}
		public TableOrderDetailsParamBuilder withSequenceNo(String sequenceNo) {
			this.sequenceNo = sequenceNo;
			return this;
		}
		public TableOrderDetailsParamBuilder withParamType(String paramType) {
			this.paramType = paramType;
			return this;
		}
		public TableOrderDetailsParamBuilder withAction(String action) {
			this.action = action;
			return this;
		}
		public TableOrderDetailsParamBuilder withParamName(String paramName) {
			this.paramName = paramName;
			return this;
		}
		public TableOrderDetailsParamBuilder withParamValue(String paramValue) {
			this.paramValue = paramValue;
			return this;
		}
		public TableOrderDetailsParamBuilder withParentId(String parentId) {
			this.parentId = parentId;
			return this;
		}
		public TableOrderDetailsParamBuilder withFlowStatus(Long flowStatus) {
			this.flowStatus = flowStatus;
			return this;
		}
		public TableOrderDetailsParamBuilder withLeaf(Long leaf) {
			this.leaf = leaf;
			return this;
		}
		public TableOrderDetailsParamBuilder addParamDetail(TableOrderDetailsParam paramDetail) {
			this.paramDetail.add(paramDetail);
			return this;
		}
		
		public TableOrderDetailsParam build() {
			return new TableOrderDetailsParam(this);
		}
	}
	
	// added by praveen
	
	 public boolean add(String paramName, String paramVal) throws Exception
	    {
	        if (orderDetailId == null)
	            return add("",orderId, "", "", "",paramName, paramVal, "",0L, 0L,null);
	        else
	        	return add(orderDetailId,orderId, "", "", "",paramName, paramVal, "",0L,0L,null);
	    }
	
	 
	 public boolean add(String OrderDetailId,  String OrderId, String SeqNo, String ParamType,String action,
		        String ParamName, String ParamValue, String ParentId,Long FlowStatus, Long Leaf,List<TableOrderDetailsParam> paramDetail) throws Exception
				{
				 if (ActionFunctionHelper.isEmpty(ParentId))
				 {
				     throw new Exception("Invalid parameter hierarchy");
				 }
				
				 boolean status = false;
				
				 if (ActionFunctionHelper.isEmpty(orderDetailId)) // this node is a place holder for children and will not be displayed
				 {
					 orderDetailId = ParentId;
				 }
				
				 TableOrderDetailsParam pd = null;
				
				 TableOrderDetailsParam.TableOrderDetailsParamBuilder paramBuilder = new TableOrderDetailsParam.TableOrderDetailsParamBuilder();
				 pd = new TableOrderDetailsParam(paramBuilder);
			     
			     //List<ParamDetail> paramDetaiList = entity.getParamDetails();
			
			     paramDetail = pd.getParamDetail();
				 
				 if (ParentId == orderDetailId)
				 {
				    
				     
				     pd.add(OrderDetailId, ParentId, OrderId, SeqNo, ParamType,action, ParamName, ParamValue,
				    		 FlowStatus, Leaf, paramDetail);
				     status = paramDetail.add(pd);
				 }
				 else
				 {
				     for (TableOrderDetailsParam tableOrderDetailsParam : paramDetail)
				     {
				    	 				
				         status = tableOrderDetailsParam.add(OrderDetailId, ParentId, OrderId, SeqNo, ParamType,action, ParamName,
				             ParamValue,FlowStatus, Leaf, paramDetail);				
				         if (status == true)
				             break;
				     }
				     //System.out.println("We should not come here unless the tree hierarchy is wrong");
				 }
				
				 return status;
				}

	 
	
	 public boolean add(String OrderDetailId,  String OrderId, String SeqNo, String ParamType,String action,
		        String ParamName, String ParamValue, String ParentId,Long FlowStatus, Long Leaf) throws Exception
		    { 
		        return add(OrderDetailId, OrderId, SeqNo, ParamType, action,ParamName, ParamValue,ParentId,
		            FlowStatus, Leaf);
		    }
	 
	 	//TODO Need to fix this method 
	    public List <TableOrderDetailsParam> getByNameSearchList(String name)
	    {
	    	List <TableOrderDetailsParam> pd = new ArrayList<TableOrderDetailsParam>();

	    	try
	        {
	    		TableOrderDetailsParam tmp = null;
	        	//System.out.println("_Params.size() " + _Params.size());

	            for (int i = 0; i < _Params.size(); i++)
	            {
	                tmp = _Params.get(i);
	                if(tmp.getParamName().equals(name))
	                {
	                	System.out.println("Found " + tmp.getParamName() + " with value " + tmp.getParamValue());
	                	pd.add(tmp);
	                }
	                tmp.getByNameSearchList(pd, name);
	            }
	    	}
	    	catch(Exception e)
	        {
	    		e.printStackTrace();
	    	}
	    	return pd;
	    }
	    
	    private void getByNameSearchList(List <TableOrderDetailsParam> pdList , String name)
	    {
	    	try
	        {
	    		TableOrderDetailsParam tmp = null;

	            for (int i = 0; i < _Params.size(); i++)
	            {
	                tmp = _Params.get(i);
	                if(tmp.getParamName().equals(name))
	                {
	                	System.out.println("getByNameSearchList(o) Found " + tmp.getParamName() + 
	                			" with value " + tmp.getParamValue());
	                	pdList.add(tmp);
	                }
	                tmp.getByNameSearchList(pdList, name);
	            }
	    	}
	    	catch(Exception e){
	    		e.printStackTrace();
	    	}
	    }
}
