package com.vz.fxo.inventory.reponsegenerator;

import com.vz.fxo.inventory.enterprise.enums.EsapEnum.MileStone;
import com.vz.fxo.inventory.enterprise.enums.EsapEnum.StatusCode;
import com.vz.fxo.inventory.enterprise.support.Enterprise;
import com.vz.fxo.inventory.enterprise.support.VzbInvException;
import com.vz.fxo.inventory.model.pc.VoipOrderResponse;



public interface VOIPResponseGenerator {


	/**
	 * 
	 * @param enterprise
	 * @param orderNumber
	 * @param workOrderNuStringmber
	 * @param workOrderNumberVersion
	 * @param milestone
	 * @param statusCode
	 * @return
	 * @throws VzbInvException
	 */
	VoipOrderResponse preparePCMilestone(Enterprise enterprise, Long orderNumber, String workOrderNuStringmber, String workOrderNumberVersion, MileStone milestone,
			StatusCode statusCode) throws VzbInvException;

}
