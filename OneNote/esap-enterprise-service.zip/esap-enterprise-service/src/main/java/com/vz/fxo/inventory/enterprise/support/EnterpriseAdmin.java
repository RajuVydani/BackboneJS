/**
 * 
 */
package com.vz.fxo.inventory.enterprise.support;

import java.sql.Connection;
import java.sql.SQLException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.vz.fxo.inventory.enterprise.support.EnterpriseAdminBean;
import com.vz.fxo.inventory.enterprise.support.InvErrorCode;

import esap.db.DBTblEnterpriseAdmin;
import esap.db.TblEnterpriseAdminDbBean;
import esap.db.TblEnterpriseAdminQuery;

/**
 * @author Vijaykumar Sriperambuduri(v034934)
 *
 */
public class EnterpriseAdmin extends EnterpriseAdminBean {

	private static Logger log = LoggerFactory.getLogger(EnterpriseAdmin.class
			.toString());
	private Connection connection;

	InvErrorCode status = InvErrorCode.INTERNAL_ERROR;

	public EnterpriseAdmin(Connection con) {
		this.connection = con;
	}

	//getters - setters

	public Connection getConnection() {
		return connection;
	}

	public void setConnection(Connection connection) {
		this.connection = connection;
	}

	public int getStatusCode() {
		return status.getErrorCode();
	}

	public void setStatus(InvErrorCode status) {
		this.status = status;
	}

	public String getStatusDesc() {
		return status.getErrorDesc();
	}

	public boolean validateSbc() {
		return true;
	}

	public EnterpriseAdmin(Connection con, EnterpriseAdminBean enterpriseAdminBean) {
		super(enterpriseAdminBean);
		this.connection = con;
	}

	public boolean addEnterpriseAdmin() {
		log.info("Entering EnterpriseAdmin::addEnterpriseAdmin");

		try {
			DBTblEnterpriseAdmin enterpriseAdminDb = new DBTblEnterpriseAdmin();
			enterpriseAdminDb.setEnterpriseId(getEnterpriseId());
			enterpriseAdminDb.setAdminEmail(getAdminEmail());
			enterpriseAdminDb.setAdminFirstName(getAdminFirstName());
			enterpriseAdminDb.setAdminLastName(getAdminLastName());
			enterpriseAdminDb.setAdminType(getAdminType());
			enterpriseAdminDb.setAdminWebLoginId(getAdminWebLoginId());
			enterpriseAdminDb.setRegionId(getRegionId());
			enterpriseAdminDb.setWebLang(getWebLang());
			enterpriseAdminDb.setPassword(getPassword());
			enterpriseAdminDb.insert(connection);
		} catch (SQLException s) {
			s.printStackTrace();
			setStatus(InvErrorCode.DB_EXCEPTION);
			return false;
		}
		setStatus(InvErrorCode.SUCCESS);
		return true;
	}

	public boolean getEnterpriseAdminDetailsById() {
		log.info("Entering EnterpriseAdmin::getEnterpriseAdminDetailsById");
		try {
			TblEnterpriseAdminQuery enterpriseAdminQry = new TblEnterpriseAdminQuery();
			log.info("Querying Enterprise Admin Details for id: "
					+ getEnterpriseId());
			enterpriseAdminQry.whereEnterpriseIdEQ(getEnterpriseId());
			if (enterpriseAdminQry.size() <= 0) {
				log.info("Failed to Retrieve Enterprise Admin");
				return false;
			}
			TblEnterpriseAdminDbBean enterpriseAdminDbBean = enterpriseAdminQry.getDbBean(0);
			setAdminEmail(enterpriseAdminDbBean.getAdminEmail());
			setAdminFirstName(enterpriseAdminDbBean.getAdminFirstName());
			setAdminLastName(enterpriseAdminDbBean.getAdminLastName());
			setAdminType(enterpriseAdminDbBean.getAdminType());
			setAdminWebLoginId(enterpriseAdminDbBean.getAdminWebLoginId());
			setRegionId(enterpriseAdminDbBean.getRegionId());
			setWebLang(enterpriseAdminDbBean.getWebLang());
			setPassword(enterpriseAdminDbBean.getPassword());
		} catch (Exception e) {
			e.printStackTrace();
			setStatus(InvErrorCode.DB_EXCEPTION);
			return false;
		}
		setStatus(InvErrorCode.SUCCESS);
		return true;
	}

	public boolean deleteEnterpriseAdmin() throws SQLException, Exception
 {
//		try {
			DBTblEnterpriseAdmin enterpriseAdminDb = new DBTblEnterpriseAdmin();
			enterpriseAdminDb.whereEnterpriseIdEQ(enterpriseId);
			enterpriseAdminDb.deleteByWhere(connection);
		/*} catch (SQLException s) {
			setStatus(InvErrorCode.DB_EXCEPTION);
			LogUtil.info("DB_FAILURE in deleteEnterpriseAdmin");
			s.printStackTrace();
			return false;
		}*/
		setStatus(InvErrorCode.SUCCESS);
		//setStatusDesc("Successfully DELETED Location into the DB");
		return true;
	}

	public boolean updateEnterpriseAdmin() {
		try {
			DBTblEnterpriseAdmin enterpriseAdminDb = getEnterpriseAdminInfoToUpdate();
			enterpriseAdminDb.whereEnterpriseIdEQ(getEnterpriseId());
			if (enterpriseAdminDb.updateSpByWhere(connection) <= 0)
				return false;
		} catch (SQLException s) {
			setStatus(InvErrorCode.DB_EXCEPTION);
			log.error("DB_FAILURE in updateFmcgDevice EnterpriseAdmin");
			s.printStackTrace();
			return false;
		}
		setStatus(InvErrorCode.SUCCESS);
		return true;
	}

	private DBTblEnterpriseAdmin getEnterpriseAdminInfoToUpdate() {
		DBTblEnterpriseAdmin enterpriseAdminDb = new DBTblEnterpriseAdmin();
		EnterpriseAdminBean defEnterpriseAdminBean = new EnterpriseAdminBean();
		EnterpriseAdmin inputEnterpriseAdmin = this;
		enterpriseAdminDb.setEnterpriseId(enterpriseId);

		if (inputEnterpriseAdmin.getAdminEmail() != null
				&& !inputEnterpriseAdmin.getAdminEmail().equals(
						defEnterpriseAdminBean.getAdminEmail())) {
			enterpriseAdminDb.setAdminEmail(inputEnterpriseAdmin.getAdminEmail());
		}
		if (inputEnterpriseAdmin.getAdminFirstName() != null
				&& !inputEnterpriseAdmin.getAdminFirstName().equals(
						defEnterpriseAdminBean.getAdminFirstName())) {
			enterpriseAdminDb.setAdminFirstName(inputEnterpriseAdmin.getAdminFirstName());
		}
		if (inputEnterpriseAdmin.getAdminLastName() != null
				&& !inputEnterpriseAdmin.getAdminLastName().equals(
						defEnterpriseAdminBean.getAdminLastName())) {
			enterpriseAdminDb.setAdminLastName(inputEnterpriseAdmin.getAdminLastName());
		}
		if (inputEnterpriseAdmin.getAdminWebLoginId() != null
				&& !inputEnterpriseAdmin.getAdminWebLoginId().equals(
						defEnterpriseAdminBean.getAdminWebLoginId())) {
			enterpriseAdminDb.setAdminWebLoginId(inputEnterpriseAdmin.getAdminWebLoginId());
		}
		if (inputEnterpriseAdmin.getAdminType() != defEnterpriseAdminBean.getAdminType()) {
			enterpriseAdminDb.setAdminType(inputEnterpriseAdmin.getAdminType());
		}
		if (inputEnterpriseAdmin.getRegionId() != defEnterpriseAdminBean.getRegionId()) {
			enterpriseAdminDb.setRegionId(inputEnterpriseAdmin.getRegionId());
		}
		if (inputEnterpriseAdmin.getWebLang() != defEnterpriseAdminBean.getWebLang()) {
			enterpriseAdminDb.setWebLang(inputEnterpriseAdmin.getWebLang());
		}
		if (inputEnterpriseAdmin.getPassword() != null
				&& !inputEnterpriseAdmin.getPassword().equals(
						defEnterpriseAdminBean.getPassword())) {
			enterpriseAdminDb.setPassword(inputEnterpriseAdmin.getPassword());
		}

		return enterpriseAdminDb;

	}
}
