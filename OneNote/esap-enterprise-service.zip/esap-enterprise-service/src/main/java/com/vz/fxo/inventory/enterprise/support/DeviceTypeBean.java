/*********************************************************
DeviceTypeBean will have rela device type and bs device ttype details.
Author: Pallavi Vankayalapati
**********************************************************/ 

package com.vz.fxo.inventory.enterprise.support;

import java.util.List;
import esap.db.DBTblFirmwareVersion;
import java.sql.Timestamp;
import java.util.ArrayList;
public class DeviceTypeBean
{
	//members
	protected String deviceTypeName;
	protected int deviceTypeId;
	protected long displayIndicator;
	//Real Device Type attributes
	protected long deviceRealtypeId;
	protected String deviceRealtypeName;
	protected long sharedInd;
	//Bs device type attributes
	protected long deviceBstypeId;
	protected String deviceBsname;
	protected long deviceBstype;
	protected long maxNumPorts;
	protected long isSharedCallEnabled;
	protected String deviceVendor;
	protected String deviceModel;
	protected long isCpeDevice;
	protected long isBlfDevice;
	protected long maxLineKeys;
	protected String protocol;
	protected long firmwareVersionId;
	protected String firmwareDesc;
	protected List<String> firmwareVersionList;
	protected List<DBTblFirmwareVersion> firmwareVersionObjList;
	
	protected String modifiedBy;
	protected java.sql.Timestamp lastModifiedDate;
	protected long envOrderId;
	protected long ipRequired;
	protected long portAllowed;
	protected String ueid;
	protected long deviceCharId;
	/**
	 * Default Constructor -- Initializes all fields to default values.
	 */
	public DeviceTypeBean() {
		this.firmwareVersionList = null;
		this.firmwareVersionObjList = null;
		this.deviceTypeName = new String("");
		this.deviceTypeId = 0;
		this.deviceRealtypeId = -1;
		this.deviceRealtypeName = new String("");
		this.sharedInd = -1;
		this.deviceBstypeId = -1;
		this.deviceBsname = new String("");
		this.deviceBstype = 0;
		this.maxNumPorts = 0;
		this.isSharedCallEnabled = -1;
		this.deviceVendor = new String("");
		this.deviceModel = new String("");
		this.isCpeDevice = -1;
		this.firmwareVersionId = 0;
		this.firmwareDesc = new String("");
		this.isBlfDevice = -1;
		this.portAllowed = -1;
		this.ipRequired = -1;
		this.maxLineKeys = 0;
		this.displayIndicator = -1;
		this.protocol = new String("");
		this.modifiedBy = new String("");
		this.lastModifiedDate = null;
		this.envOrderId = 0;
		this.firmwareVersionObjList=new ArrayList();
		this.ueid = null;
		this.deviceCharId = 0;
	}

	/**
	 * Constructor
	 * @param deviceTypeBean
	 */
	public DeviceTypeBean(DeviceTypeBean deviceTypeBean)
	{
		this.firmwareVersionList = deviceTypeBean.firmwareVersionList;
		this.firmwareVersionObjList = deviceTypeBean.firmwareVersionObjList;
		this.deviceTypeName = deviceTypeBean.deviceTypeName;
		this.deviceTypeId = deviceTypeBean.deviceTypeId;
		this.deviceRealtypeId = deviceTypeBean.deviceRealtypeId;
		this.deviceRealtypeName = deviceTypeBean.deviceRealtypeName;
		this.sharedInd = deviceTypeBean.sharedInd;
		this.deviceBstypeId = deviceTypeBean.deviceBstypeId;
		this.deviceBsname = deviceTypeBean.deviceBsname;
		this.deviceBstype = deviceTypeBean.deviceBstype;
		this.maxNumPorts = deviceTypeBean.maxNumPorts;
		this.isSharedCallEnabled = deviceTypeBean.isSharedCallEnabled;
		this.deviceVendor = deviceTypeBean.deviceVendor;
		this.deviceModel = deviceTypeBean.deviceModel;
		this.isCpeDevice = deviceTypeBean.isCpeDevice;
		this.firmwareVersionId = deviceTypeBean.firmwareVersionId;
		this.firmwareDesc = deviceTypeBean.firmwareDesc;
		this.isBlfDevice = deviceTypeBean.isBlfDevice;
		this.maxLineKeys = deviceTypeBean.maxLineKeys;
		this.displayIndicator = deviceTypeBean.displayIndicator;
		this.protocol = deviceTypeBean.protocol;
		this.modifiedBy = deviceTypeBean.modifiedBy;
		this.lastModifiedDate = deviceTypeBean.lastModifiedDate;
		this.envOrderId = deviceTypeBean.envOrderId;
		this.ueid = deviceTypeBean.ueid;
		this.deviceCharId = deviceTypeBean.deviceCharId;
	}

	public String getDeviceTypeName() {
		return deviceTypeName;
	}

	public void setDeviceTypeName(String deviceTypeName) {
		this.deviceTypeName = deviceTypeName;
	}
	public List<String> getFirmwareVersionList() {
                return firmwareVersionList;
        }

        public void setFirmwareVersionList(List<String> firmwareVersionList) {
                this.firmwareVersionList = firmwareVersionList;
        }
	public List<DBTblFirmwareVersion> getFirmwareVersionObjList() {
                return firmwareVersionObjList;
        }

        public void setFirmwareVersionObjList(List<DBTblFirmwareVersion> firmwareVersionObjList) {
                this.firmwareVersionObjList = firmwareVersionObjList;
        }

	public int getDeviceTypeId() {
		return deviceTypeId;
	}

	public void setDeviceTypeId(int deviceTypeId) {
		this.deviceTypeId = deviceTypeId;
	}

	public long getDeviceRealtypeId() {
		return deviceRealtypeId;
	}

	public void setDeviceRealtypeId(long deviceRealtypeId) {
		this.deviceRealtypeId = deviceRealtypeId;
	}


	public String getDeviceRealtypeName() {
		return this.deviceRealtypeName;
	}
	public void setDeviceRealtypeName(String deviceRealtypeName) {
		this.deviceRealtypeName = deviceRealtypeName;
	}
	public long getSharedInd() {
		return sharedInd;
	}

	public void setSharedInd(long sharedInd) {
		this.sharedInd = sharedInd;
	}

	public long getDeviceBstypeId() {
		return deviceBstypeId;
	}

	public void setDeviceBstypeId(long deviceBstypeId) {
		this.deviceBstypeId = deviceBstypeId;
	}

	public String getDeviceBsname() {
		return deviceBsname;
	}

	public void setDeviceBsname(String deviceBsName) {
		this.deviceBsname = deviceBsName;
	}

	public long getDeviceBstype() {
		return deviceBstype;
	}

	public void setDeviceBstype(long deviceBsType) {
		this.deviceBstype = deviceBsType;
	}

	public long getMaxNumPorts() {
		return maxNumPorts;
	}

	public void setMaxNumPorts(long maxNumPorts) {
		this.maxNumPorts = maxNumPorts;
	}

	public long getIsSharedCallEnabled() {
		return isSharedCallEnabled;
	}

	public void setIsSharedCallEnabled(long isSharedCallEnabled) {
		this.isSharedCallEnabled = isSharedCallEnabled;
	}

	public String getDeviceVendor() {
		return deviceVendor;
	}

	public void setDeviceVendor(String deviceVendor) {
		this.deviceVendor = deviceVendor;
	}

	public String getDeviceModel() {
		return deviceModel;
	}

	public void setDeviceModel(String deviceModel) {
		this.deviceModel = deviceModel;
	}

	public long getIsCpeDevice() {
		return isCpeDevice;
	}

	public void setIsCpeDevice(long isCpeDevice) {
		this.isCpeDevice = isCpeDevice;
	}

	public long getFirmwareVersionId() {
		return firmwareVersionId;
	}

	public void setFirmwareVersionId(long firmwareVersionId) {
		this.firmwareVersionId = firmwareVersionId;
	}

	public String getFirmwareDesc() {
		return firmwareDesc;
	}

	public void setFirmwareDesc(String firmwareDesc) {
		this.firmwareDesc = firmwareDesc;
	}

	public long getIsBlfDevice() {
		return isBlfDevice;
	}

	public void setIsBlfDevice(long isBlfDevice) {
		this.isBlfDevice = isBlfDevice;
	}

	public long getMaxLineKeys() {
                return maxLineKeys;
        }
                                                                                                                             
        public void setMaxLineKeys(long maxLineKeys) {
                this.maxLineKeys = maxLineKeys;
        }

	public long getDisplayIndicator() {
		return displayIndicator;
	}

	public void setDisplayIndicator(long displayIndicator) {
		this.displayIndicator = displayIndicator;
	}

	public String getProtocol() {
		return protocol;
	}

	public void setProtocol(String protocol) {
		this.protocol = protocol;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public java.sql.Timestamp getLastModifiedDate() {
		return lastModifiedDate;
	}

	public void setLastModifiedDate(java.sql.Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public long getEnvOrderId() {
		return envOrderId;
	}
	public void setEnvOrderId(long envOrderId) {
		this.envOrderId = envOrderId;
	}

	public long getIpRequired() {
        return ipRequired;
    }
                                                                                                                    
    public void setIpRequired(long ipr) {
        this.ipRequired= ipr;
    }

	public long getPortAllowed() {
        return portAllowed;
    }
                                                                                                                    
    public void setPortAllowed(long portAllowed) {
        this.portAllowed= portAllowed;
    }

	public String getUeid() {
		return ueid;
	}

	public void setUeid(String ueid) {
		this.ueid = ueid;
	}

	public long getDeviceCharId() {
		return deviceCharId;
	}

	public void setDeviceCharId(long deviceCharId) {
		this.deviceCharId = deviceCharId;
	}
    
}
