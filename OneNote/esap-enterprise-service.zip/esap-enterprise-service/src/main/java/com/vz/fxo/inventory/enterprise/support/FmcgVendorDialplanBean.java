package com.vz.fxo.inventory.enterprise.support;

import java.io.Serializable;
import java.sql.Timestamp;
/**
 * @author z987637
 * 
 */
public class FmcgVendorDialplanBean implements Serializable
{

    protected FmcgVendorBean fmcgVendor;
    protected KeyGroupBean group;
    protected LocationBean location;
    protected EnterpriseBean enterprise;
    protected int fmcgVendorId;
    protected int fmcgDialPlanId;
    protected String fmcgDialPlanName;
    protected long fmcgType;
    protected String enterpriseId;
    protected String locationId;
    protected long groupId;
    protected String createdBy;
    protected Timestamp creationDate;
    protected String modifiedBy;
    protected Timestamp lastModifiedDate;
    protected long activeInd;
    protected long defaultFlag;
    protected long envOrderId;

    public FmcgVendorDialplanBean(FmcgVendorDialplanBean fmcgVendorDialplanBean)
    {
        this.fmcgVendor = fmcgVendorDialplanBean.fmcgVendor;
        this.group = fmcgVendorDialplanBean.group;
        this.location = fmcgVendorDialplanBean.location;
        this.enterprise = fmcgVendorDialplanBean.enterprise;
        this.fmcgVendorId = fmcgVendorDialplanBean.fmcgVendorId;
        this.fmcgDialPlanId = fmcgVendorDialplanBean.fmcgDialPlanId;
        this.fmcgDialPlanName = fmcgVendorDialplanBean.fmcgDialPlanName;
        this.fmcgType = fmcgVendorDialplanBean.fmcgType;
        this.enterpriseId = fmcgVendorDialplanBean.enterpriseId;
        this.locationId = fmcgVendorDialplanBean.locationId;
        this.groupId = fmcgVendorDialplanBean.groupId;
        this.createdBy = fmcgVendorDialplanBean.createdBy;
        this.creationDate = fmcgVendorDialplanBean.creationDate;
        this.modifiedBy = fmcgVendorDialplanBean.modifiedBy;
        this.lastModifiedDate = fmcgVendorDialplanBean.lastModifiedDate;
        this.activeInd = fmcgVendorDialplanBean.activeInd;
        this.defaultFlag = fmcgVendorDialplanBean.defaultFlag;
        this.envOrderId = fmcgVendorDialplanBean.envOrderId;

    }

    public FmcgVendorBean getFmcgVendor()
    {
        return fmcgVendor;
    }

    public void setFmcgVendor(FmcgVendorBean fmcgVendor)
    {
        this.fmcgVendor = fmcgVendor;
    }

    public long getDefaultFlag()
    {
        return defaultFlag;
    }

    public void setDefaultFlag(long defaultFlag)
    {
        this.defaultFlag = defaultFlag;
    }

    /**
     * Default Constructor
     */
    public FmcgVendorDialplanBean()
    {
        this.fmcgVendor = new FmcgVendorBean();
        this.group = new KeyGroupBean();
        this.location = new LocationBean();
        this.enterprise = new EnterpriseBean();
        this.fmcgVendorId = 0;
        this.fmcgDialPlanId = 0;
        this.fmcgDialPlanName = new String("");
        this.fmcgType = 0;
        this.enterpriseId = new String("");
        this.locationId = new String("");
        this.groupId = 0;
        this.createdBy = new String("");
        this.creationDate = null;
        this.modifiedBy = new String("");
        this.lastModifiedDate = null;
        this.activeInd = 0;
        this.defaultFlag = 0;
        this.envOrderId = 0;
    }

    public KeyGroupBean getKeyGroup()
    {
        return group;
    }

    public void setKeyGroup(KeyGroupBean group)
    {
        this.group = group;
    }

    public LocationBean getLocation()
    {
        return location;
    }

    public void setLocation(LocationBean location)
    {
        this.location = location;
    }

    public EnterpriseBean getEnterPrise()
    {
        return enterprise;
    }

    public void setEnterPrise(EnterpriseBean enterprise)
    {
        this.enterprise = enterprise;
    }

    public long getEnvOrderId()
    {
        return envOrderId;
    }

    public void setEnvOrderId(long envOrderId)
    {
        this.envOrderId = envOrderId;
    }

    public int getFmcgVendorId()
    {
        return fmcgVendorId;
    }

    public void setFmcgVendorId(int fmcgVendorId)
    {
        this.fmcgVendorId = fmcgVendorId;
    }

    public String toString()
    {
        return "FmcgVendorDialplanBean [activeInd=" + activeInd + ", createdBy=" + createdBy + ", creationDate="
                + creationDate + ", defaultFlag=" + defaultFlag + ", enterpriseId=" + enterpriseId + ", envOrderId="
                + envOrderId + ", fmcgDialPlanId=" + fmcgDialPlanId + ", fmcgDialPlanName=" + fmcgDialPlanName
                + ", fmcgType=" + fmcgType + ", fmcgVendorId=" + fmcgVendorId + ", groupId=" + groupId
                + ", lastModifiedDate=" + lastModifiedDate + ", locationId=" + locationId + ", modifiedBy="
                + modifiedBy + "]";
    }

    public int getFmcgDialPlanId()
    {
        return fmcgDialPlanId;
    }

    public void setFmcgDialPlanId(int fmcgDialPlanId)
    {
        this.fmcgDialPlanId = fmcgDialPlanId;
    }

    public String getFmcgDialPlanName()
    {
        return fmcgDialPlanName;
    }

    public void setFmcgDialPlanName(String fmcgDialPlanName)
    {
        this.fmcgDialPlanName = fmcgDialPlanName;
    }

    public long getFmcgType()
    {
        return fmcgType;
    }

    public void setFmcgType(long fmcgType)
    {
        this.fmcgType = fmcgType;
    }

    public String getEnterpriseId()
    {
        return enterpriseId;
    }

    public void setEnterpriseId(String enterpriseId)
    {
        this.enterpriseId = enterpriseId;
    }

    public String getLocationId()
    {
        return locationId;
    }

    public void setLocationId(String locationId)
    {
        this.locationId = locationId;
    }

    public long getGroupId()
    {
        return groupId;
    }

    public void setGroupId(long groupId)
    {
        this.groupId = groupId;
    }

    public String getCreatedBy()
    {
        return createdBy;
    }

    public void setCreatedBy(String createdBy)
    {
        this.createdBy = createdBy;
    }

    public Timestamp getCreationDate()
    {
        return creationDate;
    }

    public void setCreationDate(Timestamp creationDate)
    {
        this.creationDate = creationDate;
    }

    public String getModifiedBy()
    {
        return modifiedBy;
    }

    public void setModifiedBy(String modifiedBy)
    {
        this.modifiedBy = modifiedBy;
    }

    public Timestamp getLastModifiedDate()
    {
        return lastModifiedDate;
    }

    public void setLastModifiedDate(Timestamp lastModifiedDate)
    {
        this.lastModifiedDate = lastModifiedDate;
    }

    public long getActiveInd()
    {
        return activeInd;
    }

    public void setActiveInd(long activeInd)
    {
        this.activeInd = activeInd;
    }
}
