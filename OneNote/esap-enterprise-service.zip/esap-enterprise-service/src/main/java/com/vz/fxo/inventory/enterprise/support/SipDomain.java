package com.vz.fxo.inventory.enterprise.support;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Timestamp;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import esap.db.DBTblSipDomain;
import esap.db.TblSipDomainDbBean;
import esap.db.TblSipDomainQuery;

public class SipDomain extends SipDomainBean{
	
	private static Logger log = LoggerFactory.getLogger(SipDomain.class.toString());
	
	Connection dbCon;
	//String statusCode;
	//String statusDesc;
	InvErrorCode status = InvErrorCode.INTERNAL_ERROR;
	public int getStatusCode() {
		return status.getErrorCode();
	}

	public void setStatus(InvErrorCode status) {
		this.status = status;
	}

	public String getStatusDesc() {
		return status.getErrorDesc();
	}

	public Connection getDbCon() {
		return dbCon;
	}
	public void setDbCon(Connection dbCon) {
		this.dbCon = dbCon;
	}
	public SipDomain(Connection dbCon)
	{
		this.dbCon = dbCon;
	}
	public SipDomain(SipDomainBean sipDomainBean, Connection dbCon)
	{
		super(sipDomainBean);
		this.dbCon = dbCon;
	}
	
	//Methods
	public boolean addSipDomain() throws SQLException, Exception

	{
//		try
//		{
			DBTblSipDomain sipDbBean = new DBTblSipDomain();
			//set sip domain db bean attributes
			sipDbBean.setSipDomainId(sipDbBean.getSipDomainIdSeqNextVal(dbCon));
			sipDbBean.setDialPlanId(getDialPlanId());
			sipDbBean.setDomainName(getDomainName());
			sipDbBean.setPpId(getPPId());

			log.info("EnvOrderId = <" + getEnvOrderId() + ">");
    	    		if(getEnvOrderId() > 0)
    	    			sipDbBean.setEnvOrderId(getEnvOrderId());
			else
    	    			sipDbBean.setEnvOrderIdNull();

			if(getCreatedBy() != null && !getCreatedBy().equals(""))
			sipDbBean.setCreatedBy(getCreatedBy());
			else
				sipDbBean.setCreatedBy("ESAP_INV");
			if(getModifiedBy() != null && !getModifiedBy().equals(""))
			sipDbBean.setModifiedBy(getModifiedBy());
			else
				sipDbBean.setModifiedBy("ESAP_INV");
			sipDbBean.setCreationDate(new Timestamp(System.currentTimeMillis()));
			sipDbBean.setLastModifiedDate(new Timestamp(System.currentTimeMillis()));
			sipDbBean.insertSpecific(dbCon);
/*		}
		catch(SQLException s)
		{
			s.printStackTrace();	
			setStatus(InvErrorCode.DB_EXCEPTION);
			log.info("DB_FAILURE in addSipDomain");
			return false;
		}*/
		setStatus(InvErrorCode.SUCCESS);
		return true;
	}
	
	public boolean deleteSipDomain()
	{
		try
		{
			if(getSipDomainId() <= 0)
			{
				setStatus(InvErrorCode.INVALID_SIP_DOMAIN_ID);
                                return false;
			}
			log.info("In deleteSipDomain");
			DBTblSipDomain sipDomainBean = new DBTblSipDomain();
			sipDomainBean.whereSipDomainIdEQ(getSipDomainId());
			int sipDomainsDeleted = sipDomainBean.deleteByWhere(dbCon);
			log.info("Number of sipDomains deleted:"+sipDomainsDeleted);
		}
		catch(SQLException s)
		{
			s.printStackTrace();	
			setStatus(InvErrorCode.DB_EXCEPTION);
			log.info("DB_FAILURE in deleteSipDomain");
			return false;
		}
		setStatus(InvErrorCode.SUCCESS);
		return true;
	}

	
	//sipdomainId will be set before calling this method. 
	public boolean getSipDomainBySipDomainId() {
		try {
			TblSipDomainQuery sipQry = new TblSipDomainQuery();
			// populate sip domain bean from inventory
			sipQry.whereSipDomainIdEQ(getSipDomainId());
			sipQry.query(dbCon);
			if (sipQry.size() <= 0) {
				setStatus(InvErrorCode.NO_SIP_DOMAIN_RECORD_FOUND);
				log.info("INV_FAILURE in getSipDomainBySipDomainId SipDomain. No Record found for given SipDomainId.");
				return false;
			} else {
				populateResult(sipQry);
			}
		}
		catch(SQLException e)
		{
			e.printStackTrace();	
			setStatus(InvErrorCode.DB_EXCEPTION);
			return false;
		}
		catch(Exception e)
		{
			e.printStackTrace();	
			setStatus(InvErrorCode.ERROR_GETTING_SIP_DOMAIN_DETAILS);
			return false;
		}
		setStatus(InvErrorCode.SUCCESS);
		return true;
	}
	
	private void populateResult(TblSipDomainQuery sipQry) 
	{
		TblSipDomainDbBean sipDbBean = sipQry.getDbBean(0);
		setSipDomainId(sipDbBean.getSipDomainId());
		setDialPlanId(sipDbBean.getDialPlanId());
		setDomainName(sipDbBean.getDomainName());
		setPPId(sipDbBean.getPpId());
		setCreatedBy(sipDbBean.getCreatedBy());
		setModifiedBy(sipDbBean.getModifiedBy());
		setLastModifiedDate(sipDbBean.getLastModifiedDate());
		setEnvOrderId(sipDbBean.getEnvOrderId());
	}
	
	//DialplanId will be set before calling this method. 
	public boolean getSipDomainByDialPlanId()
	{
		try {
			TblSipDomainQuery sipQry = new TblSipDomainQuery();
			// populate sip domain bean from inventory
			sipQry.whereDialPlanIdEQ(getDialPlanId());
			sipQry.query(dbCon);
			if (sipQry.size() <= 0) {
				setStatus(InvErrorCode.NO_SIP_DOMAIN_RECORD_FOUND);
				log.info("INV_FAILURE in getSipDomainBySipDomainId SipDomain. No Record found for given SipDomainId.");
				return false;
			} else {
				populateResult(sipQry);
			}   
		}
		catch(SQLException e)
		{
			e.printStackTrace();	
			setStatus(InvErrorCode.DB_EXCEPTION);
			return false;
		}
		catch(Exception e)
		{
			e.printStackTrace();	
			setStatus(InvErrorCode.ERROR_GETTING_SIP_DOMAIN_DETAILS);
			return false;
		}
		setStatus(InvErrorCode.SUCCESS);
		return true;
	}

	public boolean updateSipDomain()
    {
    	try
    	{
    		if(getSipDomainId()!=0){
    			setStatus(InvErrorCode.INVALID_SIP_DOMAIN_ID);
    			log.info("FAILURE in updateSipDomain . SipDomainId missing.");
    			return false;
    		}
    		DBTblSipDomain sipDomainBean = getSipDomainToUpdate();
    		sipDomainBean.whereSipDomainIdEQ(getSipDomainId());

    		if ( sipDomainBean.updateSpByWhere(dbCon) <= 0 ){
    			return false;
    		}

    	} catch(SQLException s) {
    	 	s.printStackTrace();	
    	 	setStatus(InvErrorCode.DB_EXCEPTION);
    		log.info("DB_FAILURE in updateFeatures");
    		return false;
    	}
    	setStatus(InvErrorCode.SUCCESS);
    	return true;
    }
	
	private DBTblSipDomain getSipDomainToUpdate() throws SQLException {
		DBTblSipDomain sipDomainBean = new DBTblSipDomain();
    	SipDomainBean defaultSipDomainBean = new SipDomainBean();

    	SipDomain inputSipDomain = this;

    	/*Set the new fields if required.*/
    	
    	sipDomainBean.setSipDomainId(getSipDomainId());

    	if(inputSipDomain.getDialPlanId() != defaultSipDomainBean.getDialPlanId()){
    		sipDomainBean.setDialPlanId(inputSipDomain.getDialPlanId());
    	}
    	
    	if (inputSipDomain.getDomainName() != null &&
    			!inputSipDomain.getDomainName().equals(defaultSipDomainBean.getDomainName())){
    		sipDomainBean.setDomainName(inputSipDomain.getDomainName());
    	}
    	
    	if(inputSipDomain.getPPId() != defaultSipDomainBean.getPPId()){
    		sipDomainBean.setPpId(inputSipDomain.getPPId());
    	}
    	
        if (inputSipDomain.getEnvOrderId() != defaultSipDomainBean.getEnvOrderId()) {
        	sipDomainBean.setEnvOrderId(inputSipDomain.getEnvOrderId());
        }

    	if( inputSipDomain.getModifiedBy() != null &&
	    !( "".equalsIgnoreCase(inputSipDomain.getModifiedBy()) ) )
    		sipDomainBean.setModifiedBy(getModifiedBy());
    	else
    		sipDomainBean.setModifiedBy("ESAP_INV");

    	sipDomainBean.setLastModifiedDate(new Timestamp(System.currentTimeMillis()));
    	return sipDomainBean;
    }

	   public boolean getDetails() throws SQLException
	    {
	    	try
	    	{
	    		log.info("In SipDomain getDetails; SipDomain id="+getSipDomainId());
	    		TblSipDomainQuery sipDomainQry = new TblSipDomainQuery();
	    		String whereClause = " where sip_domain_id ="+getSipDomainId();
	    		sipDomainQry.queryByWhere(dbCon, whereClause);
	    		if(sipDomainQry.size() == 1){
	    			
	    			setSipDomainId((sipDomainQry.getDbBean(0)).getSipDomainId());
	    			setDialPlanId((sipDomainQry.getDbBean(0)).getDialPlanId());
	    			setDomainName((sipDomainQry.getDbBean(0)).getDomainName());
	    			setPPId((sipDomainQry.getDbBean(0)).getPpId());
	    			setCreatedBy((sipDomainQry.getDbBean(0)).getCreatedBy());
	    			setCreationDate((sipDomainQry.getDbBean(0)).getCreationDate());
	    			setModifiedBy((sipDomainQry.getDbBean(0)).getModifiedBy());
	    			setLastModifiedDate((sipDomainQry.getDbBean(0)).getLastModifiedDate());
	    			
	    		}else
	    		{
	    			setStatus(InvErrorCode.NO_SIP_DOMAIN_RECORD_FOUND);
	    			return false;
	    		}		
	    	}catch(SQLException s)
	    	{
    	 		s.printStackTrace();	
    	 		setStatus(InvErrorCode.DB_EXCEPTION);
	    		return false;
	    	}
	    	setStatus(InvErrorCode.SUCCESS);
	    	return true;
	    } 


}
