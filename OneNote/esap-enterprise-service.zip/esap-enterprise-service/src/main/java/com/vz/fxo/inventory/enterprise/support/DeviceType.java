package com.vz.fxo.inventory.enterprise.support;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import esap.db.DBTblDeviceBstype;
import esap.db.DBTblDeviceFirmwares;
import esap.db.DBTblDeviceRealtype;
import esap.db.DBTblDeviceTypes;
import esap.db.DBTblFirmwareVersion;
import esap.db.TblDeviceBstypeQuery;
import esap.db.TblDeviceFirmwaresQuery;
import esap.db.TblDeviceRealtypeQuery;
import esap.db.TblDeviceTypesQuery;
//TODO tbl not there in db
import esap.db.TblFirmwareVersionQuery;

public class DeviceType extends DeviceTypeBean{
	
	private static Logger log = LoggerFactory.getLogger(DeviceType.class.toString());

        InvErrorCode status = InvErrorCode.INTERNAL_ERROR;	
        Connection dbCon;

	public DeviceType(Connection dbCon)
	{
		super();
		this.dbCon = dbCon;
	}

	public DeviceType(Connection dbCon, DeviceTypeBean devTypeBean)
	{
		super(devTypeBean);
		this.dbCon = dbCon;
	}

    public int getStatusCode()
    {
        return status.getErrorCode();
    }
 
    public void setStatus(InvErrorCode status)
    {
        this.status = status;
    }
 
    public String getStatusDesc()
    {
        return status.getErrorDesc();
    }
	
        public Connection getDbCon() {
		return dbCon;
	}
	public void setDbCon(Connection dbCon) {
		this.dbCon = dbCon;
	}
        //methods 
        public boolean addToDB() throws SQLException, Exception
	{
	//	try{
			DBTblDeviceTypes devTypesDBBean	 = new DBTblDeviceTypes();
			
			if(getDeviceTypeId()<=0) {
				setDeviceTypeId(devTypesDBBean.getDeviceTypeIdSeqNextVal(dbCon));
			}
			if(getDeviceRealtypeId() <=0 && getDeviceRealtypeName()!=null) {
				TblDeviceRealtypeQuery devRealTypeQry  = new TblDeviceRealtypeQuery();
				devRealTypeQry.whereDeviceRealtypeNameEQ(getDeviceRealtypeName());
				devRealTypeQry.query(dbCon);
				if(devRealTypeQry.size() == 1){
					setDeviceRealtypeId((devRealTypeQry.getDbBean(0)).getDeviceRealtypeId());
				}else{
					log.info("no real device info for this realdevice name:"+getDeviceRealtypeName());
				}
			}
			if(getDeviceBstypeId() <= 0 && getDeviceBsname()!=null) {
				TblDeviceBstypeQuery devBsQry = new TblDeviceBstypeQuery();
				devBsQry.whereDeviceBsnameEQ(getDeviceBsname());
				devBsQry.query(dbCon);
				if(devBsQry.size()==1) {
					setDeviceBstypeId(devBsQry.getDbBean(0).getDeviceBstypeId());
				}else{
					log.info("no real device info for this BSdevice name:"+getDeviceBsname());
				}
			}
			devTypesDBBean.setDeviceBstypeId(getDeviceBstypeId());
			devTypesDBBean.setDeviceRealtypeId(getDeviceRealtypeId());
			devTypesDBBean.setDeviceTypeId(getDeviceTypeId());
			devTypesDBBean.setDeviceTypeName(getDeviceTypeName());
			devTypesDBBean.setDisplayIndicator(getDisplayIndicator());
                	devTypesDBBean.setIsSharedCallEnabled(getIsSharedCallEnabled());
                	devTypesDBBean.setDeviceVendor(getDeviceVendor());
                	devTypesDBBean.setDeviceModel(getDeviceModel());
                	devTypesDBBean.setIsCpeDevice(getIsCpeDevice());
                	devTypesDBBean.setIsBlfDevice(getIsBlfDevice());
                	devTypesDBBean.setMaxLineKeys(getMaxLineKeys());
                	devTypesDBBean.setProtocol(getProtocol());
                	devTypesDBBean.setUeid(getUeid());
                	devTypesDBBean.setDeviceCharId(getDeviceCharId());
        		log.info("EnvOrderId = <" + getEnvOrderId() + ">");
    	    		if(getEnvOrderId() > 0)
                		devTypesDBBean.setEnvOrderId(getEnvOrderId());
			else
                		devTypesDBBean.setEnvOrderIdNull();

			if(getModifiedBy() != ""  && getModifiedBy() != null)
				devTypesDBBean.setModifiedBy(getModifiedBy());
		    else
		    	devTypesDBBean.setModifiedBy("ESAP_INV");
			devTypesDBBean.setLastModifiedDate((new Timestamp(System.currentTimeMillis())));
			
			FkValidationUtil.isValidDeviceTypes(dbCon,devTypesDBBean);
			devTypesDBBean.insert(dbCon);
		/*}
		catch(SQLException e)
		{
			setStatus(InvErrorCode.DB_EXCEPTION);
			e.printStackTrace();
			//setStatusDesc("DB_FAILURE in addToDB Device Type");
			return false;
		}*/
		 /**catch (Exception s){
			setStatus(InvErrorCode.NO_DEVICE_TYPE_ADDED);
			s.printStackTrace();
			//setStatusDesc("DB_FAILURE in addToDB Device Type");
			return false;
		}**/
		
		setStatus(InvErrorCode.SUCCESS);
		//setStatusDesc("Successfully device Type to db");
		
		//setStatusCode("SUCCESS");
		//setStatusDesc("Successfully device Type to db");
		return true;
	}
	public boolean addRealTypeToDB()
	{
		log.info("Entering DeviceType::addRealTypeToDB");
		try
		{
			DBTblDeviceRealtype deviceRealTypesDB = new DBTblDeviceRealtype();
            if(getDeviceRealtypeId() > 0)
            {
            	deviceRealTypesDB.setDeviceRealtypeId((int)getDeviceRealtypeId());
            }
            else
            {
           	 	int deviceSeqId = deviceRealTypesDB.getDeviceRealtypeIdSeqNextVal(dbCon);
           	 	deviceRealTypesDB.setDeviceRealtypeId(deviceSeqId);
            }
            if (getDeviceRealtypeName() != "")
            	deviceRealTypesDB.setDeviceRealtypeName(getDeviceRealtypeName());
            if (getSharedInd() > -1)
            	deviceRealTypesDB.setSharedInd(getSharedInd());
            if (getModifiedBy() != null && !getModifiedBy().equals(""))
            	deviceRealTypesDB.setModifiedBy(getModifiedBy());
            else
            	deviceRealTypesDB.setModifiedBy("ESAP_INV");
      
            deviceRealTypesDB.setLastModifiedDate(new Timestamp(System.currentTimeMillis()));
            deviceRealTypesDB.insert(dbCon);
		}
        catch(SQLException e)
        {
        	setStatus(InvErrorCode.DB_EXCEPTION);
        	e.printStackTrace();
        	return false;
        }
        setStatus(InvErrorCode.SUCCESS);
		
        return true;
	}
	public boolean addBsDeviceTypeToDB()
	{	
		log.info("Entering DeviceType::addBsDeviceTypeToDB");	
		try
		{
			DBTblDeviceBstype deviceBsTypesDB = new DBTblDeviceBstype();
            if(getDeviceBstypeId() > 0)
            {
            	deviceBsTypesDB.setDeviceBstypeId((int)getDeviceBstypeId());
            }
            else
            {
           	 	int deviceSeqId = deviceBsTypesDB.getDeviceBstypeIdSeqNextVal(dbCon);
           	 deviceBsTypesDB.setDeviceBstypeId(deviceSeqId);
            }
            if (getDeviceBsname() != null)
            	deviceBsTypesDB.setDeviceBsname(getDeviceBsname());
            if (getDeviceBstype() > 0)
            	deviceBsTypesDB.setDeviceBstype(getDeviceBstype());
			if (getIpRequired() == -1)
                deviceBsTypesDB.setIpRequired(0);
			else
                deviceBsTypesDB.setIpRequired(getIpRequired());
			if (getPortAllowed() == -1)
                deviceBsTypesDB.setPortAllowed(0);
			else
                deviceBsTypesDB.setPortAllowed(getPortAllowed());
            if (getMaxNumPorts() > 0)
            	deviceBsTypesDB.setMaxNumPorts(getMaxNumPorts());
            if (getModifiedBy() != null && !getModifiedBy().equals(""))
            	deviceBsTypesDB.setModifiedBy(getModifiedBy());
            else
            	deviceBsTypesDB.setModifiedBy("ESAP_INV");
      
            deviceBsTypesDB.setLastModifiedDate(new Timestamp(System.currentTimeMillis()));
            deviceBsTypesDB.insert(dbCon);			
			
			
		}
		catch(SQLException e)
		{
			setStatus(InvErrorCode.DB_EXCEPTION);
			e.printStackTrace();
			return false;
		
		}
		setStatus(InvErrorCode.SUCCESS);
					
		return true;
	}

	//set deviceTypeId and call this method
	public boolean getDetails() 
	{
		try
                {
			TblDeviceTypesQuery devTypesQry = new TblDeviceTypesQuery();
			devTypesQry.whereDeviceTypeIdEQ(getDeviceTypeId());
			devTypesQry.query(dbCon);
			if(devTypesQry.size() == 1)
			{
				setDeviceTypeName((devTypesQry.getDbBean(0)).getDeviceTypeName());
				setDeviceRealtypeId((devTypesQry.getDbBean(0)).getDeviceRealtypeId());
				setDeviceBstypeId((devTypesQry.getDbBean(0)).getDeviceBstypeId());
				setDisplayIndicator((devTypesQry.getDbBean(0)).getDisplayIndicator());
                                setIsSharedCallEnabled((devTypesQry.getDbBean(0)).getIsSharedCallEnabled());
                                setDeviceVendor((devTypesQry.getDbBean(0)).getDeviceVendor());
                                setDeviceModel((devTypesQry.getDbBean(0)).getDeviceModel());
                                setIsCpeDevice((devTypesQry.getDbBean(0)).getIsCpeDevice());
				setIsBlfDevice((devTypesQry.getDbBean(0)).getIsBlfDevice());
				setMaxLineKeys((devTypesQry.getDbBean(0)).getMaxLineKeys());
                                setProtocol((devTypesQry.getDbBean(0)).getProtocol());
				setEnvOrderId((devTypesQry.getDbBean(0)).getEnvOrderId());
				setUeid((devTypesQry.getDbBean(0)).getUeid());
				setDeviceCharId((devTypesQry.getDbBean(0)).getDeviceCharId());
				//real device type => 0 to 5
				if(getDeviceRealtypeId() >= 0 && getDeviceRealtypeId() < 6)
				{
					TblDeviceRealtypeQuery devRealQry = new TblDeviceRealtypeQuery();
					devRealQry.whereDeviceRealtypeIdEQ((int)getDeviceRealtypeId()); 	
					devRealQry.query(dbCon);
					if(devRealQry.size() == 1)
					{
						setDeviceRealtypeName((devRealQry.getDbBean(0)).getDeviceRealtypeName());
						setDeviceRealtypeId((devRealQry.getDbBean(0)).getDeviceRealtypeId());
						setSharedInd((devRealQry.getDbBean(0)).getSharedInd());
					}
					else
					{
						log.info("no real device info for this realdevice id:"+getDeviceRealtypeId());
					}
				}
				else
					log.info("real device type is  invalid");
				if(getDeviceBstypeId() > 0)
				{
					TblDeviceBstypeQuery devBsQry = new TblDeviceBstypeQuery();
                                        devBsQry.whereDeviceBstypeIdEQ((int)getDeviceBstypeId());
                                        devBsQry.query(dbCon);
                                        if(devBsQry.size() == 1)
                                        {
                                                setDeviceBsname((devBsQry.getDbBean(0)).getDeviceBsname());
                                                setDeviceBstype((devBsQry.getDbBean(0)).getDeviceBstype());
                                                setIpRequired((devBsQry.getDbBean(0)).getIpRequired());
                                                setPortAllowed((devBsQry.getDbBean(0)).getPortAllowed());
                                                setMaxNumPorts((devBsQry.getDbBean(0)).getMaxNumPorts());
						/*if(getFirmwareVersionId() > 0)
						{
							TblFirmwareVersionQuery firmwareQry = new TblFirmwareVersionQuery();
							firmwareQry.whereTblFirmwareVersionIdEQ(getFirmwareVersionId());
							firmwareQry.query(dbCon);
							if(firmwareQry.size() == 1)
							{
								setFirmwareDesc((firmwareQry.getDbBean(0)).getFirmwareDesc());
							}
						}*/
                                        }
                                        else
                                        {
                                                log.info("no real device info for this realdevice id:"+getDeviceRealtypeId());
                                        }
				}
				else
					log.info("bs device type is  invalid");
				TblDeviceFirmwaresQuery devfvQry = new TblDeviceFirmwaresQuery();
				devfvQry.whereDeviceTypeIdEQ(getDeviceTypeId());
				devfvQry.query(dbCon);
				log.info("TblDeviceFirmwaresQuery size is===> " +devfvQry.size());
				if(devfvQry.size() > 0)
				{
					firmwareVersionList = new ArrayList<String>();
					for(int i = 0; i < devfvQry.size(); i++)
					{
						TblFirmwareVersionQuery firmQry = new TblFirmwareVersionQuery();
						log.info("TblFirmwareVersionQuery value is===> " +(int)devfvQry.getDbBean(i).getFirmwareVersionId());
						firmQry.whereFirmwareVersionIdEQ((int)devfvQry.getDbBean(i).getFirmwareVersionId());
						firmQry.query(dbCon);
						log.info("TblFirmwareVersionQuery size is===> " +firmQry.size() );
						if(firmQry.size() > 0)
						{
							log.info("firmQry.getDbBean(0).getFirmwareDesc() " +firmQry.getDbBean(0).getFirmwareDesc());
							firmwareVersionList.add(firmQry.getDbBean(0).getFirmwareDesc());
							DBTblFirmwareVersion firmwareDbBean = new DBTblFirmwareVersion();
                    		firmwareDbBean.copyFromBean(firmQry.getDbBean(0));
							firmwareVersionObjList.add(firmwareDbBean);
						}
					}
				}
                                setModifiedBy((devTypesQry.getDbBean(0)).getModifiedBy());
                                setLastModifiedDate((devTypesQry.getDbBean(0)).getLastModifiedDate());
			}
			else
			{


                       setStatus(InvErrorCode.INTERNAL_ERROR);
                 //	setStatusDesc("INV_FAILURE in getDetails Device Type. No deviceTypes found for the given deviceTypeId");
	                return false; 	
                    }
                }
                catch(SQLException s)
                {
                        setStatus(InvErrorCode.DB_EXCEPTION);
                     //   setStatusDesc("DB_FAILURE n getDetails Device Type");
                        return false;
                }
                setStatus(InvErrorCode.SUCCESS);
              //  setStatusDesc("Successfully retrieved device Type from db");
                return true;
	}
	//set deviceTypesName and call this method
	public boolean getDetailsByDeviceTypeName()
        {
		try
                {
			if(getDeviceTypeName() == null || getDeviceTypeName() == "")
			{
                        	setStatus(InvErrorCode.INTERNAL_ERROR);
                   //     	setStatusDesc("INV_FAILURE in getDetails Device Type. deviceTypeName is not set for getDetailsbyDeviceTypeName");
				log.info("INV_FAILURE in getDetails Device Type. deviceTypeName is not set for getDetailsbyDeviceTypeName");
                        	return false;
			}
				
            TblDeviceTypesQuery devTypesQry = new TblDeviceTypesQuery();
		String whereClause = " where device_type_name = " + getDeviceTypeName(); 	
            devTypesQry.queryByWhere(dbCon, whereClause);
            if(devTypesQry.size() == 1)
            {
                setDeviceTypeId((devTypesQry.getDbBean(0)).getDeviceTypeId());
                setDeviceRealtypeId((devTypesQry.getDbBean(0)).getDeviceRealtypeId());
                setDeviceBstypeId((devTypesQry.getDbBean(0)).getDeviceBstypeId());
                setDisplayIndicator((devTypesQry.getDbBean(0)).getDisplayIndicator());
		setIsSharedCallEnabled((devTypesQry.getDbBean(0)).getIsSharedCallEnabled());
                setDeviceVendor((devTypesQry.getDbBean(0)).getDeviceVendor());
                setDeviceModel((devTypesQry.getDbBean(0)).getDeviceModel());
                setIsCpeDevice((devTypesQry.getDbBean(0)).getIsCpeDevice());
                setIsBlfDevice((devTypesQry.getDbBean(0)).getIsBlfDevice());
                setMaxLineKeys((devTypesQry.getDbBean(0)).getMaxLineKeys());
                setProtocol((devTypesQry.getDbBean(0)).getProtocol());
                setUeid((devTypesQry.getDbBean(0)).getUeid());
                setDeviceCharId((devTypesQry.getDbBean(0)).getDeviceCharId());
		setEnvOrderId((devTypesQry.getDbBean(0)).getEnvOrderId());

                if(getDeviceRealtypeId() > 0)
                {
                    TblDeviceRealtypeQuery devRealQry = new TblDeviceRealtypeQuery();
                    devRealQry.whereDeviceRealtypeIdEQ((int)getDeviceRealtypeId());
                    devRealQry.query(dbCon);
                    if(devRealQry.size() == 1)
                    {
                        setDeviceRealtypeName((devRealQry.getDbBean(0)).getDeviceRealtypeName());
                        setDeviceRealtypeId((devRealQry.getDbBean(0)).getDeviceRealtypeId());
                        setSharedInd((devRealQry.getDbBean(0)).getSharedInd());
                    }
                    else
                    {
                        log.info("no real device info for this realdevice id:"+getDeviceRealtypeId());
                    }

                }
                else
                    log.info("real device type is  invalid");
                if(getDeviceBstypeId() > 0)
                {
                    TblDeviceBstypeQuery devBsQry = new TblDeviceBstypeQuery();
                                        devBsQry.whereDeviceBstypeIdEQ((int)getDeviceBstypeId());
                                        devBsQry.query(dbCon);
                                        if(devBsQry.size() == 1)
                                        {
                                                setDeviceBsname((devBsQry.getDbBean(0)).getDeviceBsname());
                                                setDeviceBstype((devBsQry.getDbBean(0)).getDeviceBstype());
                                                setMaxNumPorts((devBsQry.getDbBean(0)).getMaxNumPorts());
					//setFirmwareVersionId((devBsQry.getDbBean(0)).getFirmwareVersionId());
                        /*if(getFirmwareVersionId() > 0)
                        {
                            TblFirmwareVersionQuery firmwareQry = new TblFirmwareVersionQuery();
                            firmwareQry.whereTblFirmwareVersionIdEQ(getFirmwareVersionId());
                            firmwareQry.query(dbCon);
                            if(firmwareQry.size() == 1)
                            {
                                setFirmwareDesc((firmwareQry.getDbBean(0)).getFirmwareDesc());
                            }
                        }*/
                                        }
                                        else
                                        {
                                                log.info("no real device info for this realdevice id:"+getDeviceRealtypeId());
                                        }
                }
                else
                    log.info("bs device type is  invalid");
                                setModifiedBy((devTypesQry.getDbBean(0)).getModifiedBy());
		TblDeviceFirmwaresQuery devfvQry = new TblDeviceFirmwaresQuery();
                                devfvQry.whereDeviceTypeIdEQ(getDeviceTypeId());
                                devfvQry.query(dbCon);
                                if(devfvQry.size() > 0)
                                {
                                        firmwareVersionList = new ArrayList<String>();
                                        for(int i = 0; i < devfvQry.size(); i++)
                                        {
										TblFirmwareVersionQuery firmQry = new TblFirmwareVersionQuery();
                        firmQry.whereFirmwareVersionIdEQ((int)devfvQry.getDbBean(i).getFirmwareVersionId());
                        firmQry.query(dbCon);
                        if(firmQry.size() > 0)
                        firmwareVersionList.add(firmQry.getDbBean(0).getFirmwareDesc());
                                        }
                                }

            }
            else
            {
                            setStatus(InvErrorCode.INTERNAL_ERROR);
                           // setStatusDesc("INV_FAILURE in getDetails Device Type. No deviceTypes found for the given deviceTypeId");
                log.info("INV_FAILURE in getDetails Device Type. No deviceTypes found for the given deviceTypesId");
                            return false;
            }
                }
                catch(SQLException s)
                {
                         setStatus(InvErrorCode.DB_EXCEPTION);
                   //     setStatusDesc("DB_FAILURE  getDetails Device Type");
                        return false;
                }
                setStatus(InvErrorCode.SUCCESS);
                // setStatusDesc("Successfully retrieved device Type from db");
                return true;

        }
	boolean getDeviceTypeIdByDeviceTypeName()
	{
		try
		{
			if(getDeviceTypeName() == null || getDeviceTypeName() == "")
			{
                        	setStatus(InvErrorCode.INTERNAL_ERROR);
                        //	setStatusDesc("INV_FAILURE in getDetails Device Type. deviceTypeName is not set for getDeviceTypeIdByDeviceTypeName");
				log.info("INV_FAILURE in getDetails Device Type. deviceTypeName is not set for getDeviceTypeIdByDeviceTypeName");
                        	return false;
			}
				
            TblDeviceTypesQuery devTypesQry = new TblDeviceTypesQuery();
		String whereClause = " where device_type_name = " + getDeviceTypeName(); 	
            devTypesQry.queryByWhere(dbCon, whereClause);
            	if(devTypesQry.size() == 1)
                	setDeviceTypeId((devTypesQry.getDbBean(0)).getDeviceTypeId());
		else {
    			return false;
    		}
                }
                catch(SQLException s)
                {
                        setStatus(InvErrorCode.DB_EXCEPTION);
                      //  setStatusDesc("DB_FAILURE  getDetails Device Type");
                        return false;
                }
                setStatus(InvErrorCode.SUCCESS);
       //         setStatusDesc("Successfully retrieved device Type from db");
                return true;
	}

public boolean deleteFromDB() throws SQLException, Exception
	{
		log.info("Entering DeviceType::deleteFromDB");
		//try {
			if(deviceTypeId > 0)
			{

            DBTblDeviceFirmwares devfirmver = new DBTblDeviceFirmwares();
            devfirmver.whereDeviceTypeIdEQ(deviceTypeId);
            devfirmver.deleteByWhere(dbCon);

			DBTblDeviceTypes deviceTypeDbBean = new DBTblDeviceTypes();
			deviceTypeDbBean.whereDeviceTypeIdEQ(deviceTypeId);
			deviceTypeDbBean.deleteByWhere(dbCon);
			}
		/*} catch (SQLException e) {
          	setStatus(InvErrorCode.DB_EXCEPTION);
        	e.printStackTrace();
			return false;
		} catch (Exception s){
			setStatus(InvErrorCode.NO_DEVICE_TYPE_DELETED);
			s.printStackTrace();
			return false;
		}*/
		setStatus(InvErrorCode.SUCCESS);
		//setStatusDesc("Successfully DELETED Location into the DB");
		return true;
	}
	public boolean deleteRealTypeFromDB()  throws SQLException, Exception
	{
		log.info("Entering DeviceType::deleteRealTypeFromDB");
		//try {
			if(deviceRealtypeId > 0)
			{
			// Todo Remove the child records of EnterPrise
			DBTblDeviceRealtype deviceTypeDbBean = new DBTblDeviceRealtype();
			deviceTypeDbBean.whereDeviceRealtypeIdEQ((int) deviceRealtypeId);
			//deviceTypeDbBean.setDeviceRealtypeId((int) deviceRealtypeId);
			deviceTypeDbBean.deleteByWhere(dbCon);
			}
		/*} catch (SQLException e) {
          	setStatus(InvErrorCode.DB_EXCEPTION);
        	e.printStackTrace();
			return false;
		}*/
		setStatus(InvErrorCode.SUCCESS);
		//setStatusDesc("Successfully DELETED Location into the DB");
		return true;
	}
	public boolean deleteBsDeviceTypeFromDB() throws SQLException, Exception
	{
		log.info("Entering DeviceType::deleteBsDeviceTypeFromDB");
	//	try {
			if(deviceBstypeId > 0)
			{
			// Todo Remove the child records of EnterPrise
			DBTblDeviceBstype deviceTypeDbBean = new DBTblDeviceBstype();
			deviceTypeDbBean.whereDeviceBstypeIdEQ((int) deviceBstypeId);
			//deviceTypeDbBean.setDeviceBstypeId((int) deviceBstypeId);
			deviceTypeDbBean.deleteByWhere(dbCon);
			}
	/*	} catch (SQLException e) {
          	setStatus(InvErrorCode.DB_EXCEPTION);
        	e.printStackTrace();
			return false;
		}*/
		setStatus(InvErrorCode.SUCCESS);
		//setStatusDesc("Successfully DELETED Location into the DB");
		return true;
	}
	public boolean modifyInDB() throws Exception, SQLException
	{
		log.info("Entering DeviceType::modifyInDB");
		//try {
		if ( getDeviceTypeId() <=0 ) {
                                setStatus(InvErrorCode.MISSING_DEVICE_TYPE_ID);
                                log.info("FAILURE in update DeviceType. DeviceTypeId missing.");
                                return false;
                        }
                	DBTblDeviceTypes deviceTypeDbBean = getDeviceTypesToUpdate();
			deviceTypeDbBean.whereDeviceTypeIdEQ(deviceTypeId);
			FkValidationUtil.isValidDeviceTypesForMod(dbCon,deviceTypeDbBean);
			if ( deviceTypeDbBean.updateSpByWhere(dbCon) <=0 ) {
				return false;	
			}
		/*} catch (SQLException e) {
        	setStatus(InvErrorCode.DB_EXCEPTION);
        	e.printStackTrace();
			return false;
		} catch (Exception s){
			setStatus(InvErrorCode.NO_DEVICE_TYPE_UPDATED);
			s.printStackTrace();
			return false;
		}*/
		setStatus(InvErrorCode.SUCCESS);
		return true;
	}
	public boolean modifyRealTypeInDB()  throws SQLException, Exception
	{
		log.info("Entering DeviceType::modifyRealTypeInDB");
	//	try {
			
			DBTblDeviceRealtype deviceRealTypeDbBean = getDeviceRealTypesToUpdate();
               		deviceRealTypeDbBean.whereDeviceRealtypeIdEQ((int)deviceRealtypeId);

       			if ( deviceRealTypeDbBean.updateSpByWhere(dbCon) <=0 ) {
				return false;	
			}
		/*} catch (SQLException e) {
        	setStatus(InvErrorCode.DB_EXCEPTION);
        	e.printStackTrace();
			return false;
		}*/
		setStatus(InvErrorCode.SUCCESS);
		return true;
	}
	public boolean modifyBsDeviceTypeInDB()  throws SQLException, Exception
	{
		log.info("Entering DeviceType::modifyBsDeviceTypeInDB");
		//try {
			
			DBTblDeviceBstype deviceBsTypeDbBean = getDeviceBsTypesToUpdate();
			deviceBsTypeDbBean.whereDeviceBstypeIdEQ((int)deviceBstypeId);
			deviceBsTypeDbBean.updateSpByWhere(dbCon);	
	
		/*} catch (SQLException e) {
        	setStatus(InvErrorCode.DB_EXCEPTION);
        	e.printStackTrace();
			return false;
		}*/
		setStatus(InvErrorCode.SUCCESS);
		return true;
	}
	
	private DBTblDeviceTypes getDeviceTypesToUpdate()
	{
		DBTblDeviceTypes deviceTypeDbBean = new DBTblDeviceTypes();
		
		DeviceTypeBean defDeviceTypeBean = new DeviceTypeBean();
		
		DeviceType inputDeviceType = this;
		deviceTypeDbBean.setDeviceTypeId(deviceTypeId);
		
		if (inputDeviceType.getDeviceTypeName() != null && 
				!inputDeviceType.getDeviceTypeName().equals(defDeviceTypeBean.getDeviceTypeName())) {
			deviceTypeDbBean.setDeviceTypeName(inputDeviceType.getDeviceTypeName());
		}

		if (inputDeviceType.getDeviceRealtypeId() != defDeviceTypeBean.getDeviceRealtypeId()) {
			deviceTypeDbBean.setDeviceRealtypeId(inputDeviceType.getDeviceRealtypeId());
		}

		if (inputDeviceType.getDisplayIndicator() != defDeviceTypeBean.getDisplayIndicator()) {
                        deviceTypeDbBean.setDisplayIndicator(inputDeviceType.getDisplayIndicator());
                }

		if (inputDeviceType.getDeviceBstypeId() != defDeviceTypeBean.getDeviceBstypeId()) {
			deviceTypeDbBean.setDeviceBstypeId(inputDeviceType.getDeviceBstypeId());
		}
		if (getDeviceBstypeId() > 0)
			deviceTypeDbBean.setDeviceBstypeId(getDeviceBstypeId());
		 if (inputDeviceType.getIsSharedCallEnabled() != defDeviceTypeBean.getIsSharedCallEnabled()) {
                        deviceTypeDbBean.setIsSharedCallEnabled(inputDeviceType.getIsSharedCallEnabled());
                }
                if (inputDeviceType.getDeviceVendor() != null &&
                                !inputDeviceType.getDeviceVendor().equals(defDeviceTypeBean.getDeviceVendor())) {
                        deviceTypeDbBean.setDeviceVendor(inputDeviceType.getDeviceVendor());
                }
                if (inputDeviceType.getDeviceModel() != null &&
                                !inputDeviceType.getDeviceModel().equals(defDeviceTypeBean.getDeviceModel())) {
                        deviceTypeDbBean.setDeviceModel(inputDeviceType.getDeviceModel());
                }
                if (inputDeviceType.getIsCpeDevice() != defDeviceTypeBean.getIsCpeDevice()) {
                        deviceTypeDbBean.setIsCpeDevice(inputDeviceType.getIsCpeDevice());
                }
                if (inputDeviceType.getIsBlfDevice() != defDeviceTypeBean.getIsBlfDevice()) {
                        deviceTypeDbBean.setIsBlfDevice(inputDeviceType.getIsBlfDevice());
                }
                if (inputDeviceType.getMaxLineKeys() != defDeviceTypeBean.getMaxLineKeys()) {
                        deviceTypeDbBean.setMaxLineKeys(inputDeviceType.getMaxLineKeys());
                }
                if (inputDeviceType.getProtocol() != null &&
                                !inputDeviceType.getProtocol().equals(defDeviceTypeBean.getProtocol())) {
                        deviceTypeDbBean.setProtocol(inputDeviceType.getProtocol());
                }
                //TODO for march release not in scope of jan 2013
                if (inputDeviceType.getUeid() != null &&
                        !inputDeviceType.getUeid().equals(defDeviceTypeBean.getUeid())) {
                	deviceTypeDbBean.setUeid(inputDeviceType.getUeid());
                }
                /*if (inputDeviceType.getDeviceCharId() != defDeviceTypeBean.getDeviceCharId()) {
                	deviceTypeDbBean.setDeviceCharId(inputDeviceType.getDeviceCharId());
                }*/


           	if (inputDeviceType.getEnvOrderId() != defDeviceTypeBean.getEnvOrderId()) {
           		deviceTypeDbBean.setEnvOrderId(inputDeviceType.getEnvOrderId());
           	}

		if( inputDeviceType.getModifiedBy() != null &&
				!( "".equalsIgnoreCase(inputDeviceType.getModifiedBy()) ) ) {
			deviceTypeDbBean.setModifiedBy(inputDeviceType.getModifiedBy());
		} else {
			deviceTypeDbBean.setModifiedBy("ESAP_INV");
	   	}
  		deviceTypeDbBean.setLastModifiedDate(new Timestamp(System.currentTimeMillis()));
			
		return deviceTypeDbBean;
		
	}
	private DBTblDeviceRealtype getDeviceRealTypesToUpdate()
	{
		DBTblDeviceRealtype deviceRealTypeDbBean = new DBTblDeviceRealtype();
		
		DeviceTypeBean defDeviceTypeBean = new DeviceTypeBean();
		
		DeviceType inputDeviceType = this;
				
		deviceRealTypeDbBean.setDeviceRealtypeId((int) deviceRealtypeId);
		
		if (inputDeviceType.getDeviceRealtypeName() != null && 
				!inputDeviceType.getDeviceRealtypeName().equals(defDeviceTypeBean.getDeviceRealtypeName())) {
			deviceRealTypeDbBean.setDeviceRealtypeName(inputDeviceType.getDeviceRealtypeName());
		}
		if (inputDeviceType.getSharedInd() != defDeviceTypeBean.getSharedInd()) {
			deviceRealTypeDbBean.setSharedInd(inputDeviceType.getSharedInd());
		}
		deviceRealTypeDbBean.setModifiedBy("ESAP_INV");
		deviceRealTypeDbBean.setLastModifiedDate(new Timestamp(System.currentTimeMillis()));
		return deviceRealTypeDbBean;
		
	}
	private DBTblDeviceBstype getDeviceBsTypesToUpdate() throws SQLException, Exception
	{
		DBTblDeviceBstype deviceBsTypeDbBean = new DBTblDeviceBstype();
		
		DeviceTypeBean defDeviceTypeBean = new DeviceTypeBean();
		
		DeviceType curDeviceType = new DeviceType(dbCon);
		
		curDeviceType.setDeviceTypeId(deviceTypeId);
		curDeviceType.getDetails();
				
		DeviceType inputDeviceType = this;
		
		deviceBsTypeDbBean.setDeviceBstypeId((int)deviceBstypeId);
		
		if (inputDeviceType.getDeviceBsname() != null && 
				!inputDeviceType.getDeviceBsname().equals(defDeviceTypeBean.getDeviceBsname())) {
			deviceBsTypeDbBean.setDeviceBsname(inputDeviceType.getDeviceBsname());
		}
		if (inputDeviceType.getDeviceBstype() != defDeviceTypeBean.getDeviceBstype()) {
			deviceBsTypeDbBean.setDeviceBstype(inputDeviceType.getDeviceBstype());
		}
		if (inputDeviceType.getMaxNumPorts() != defDeviceTypeBean.getMaxNumPorts()) {
			deviceBsTypeDbBean.setMaxNumPorts(inputDeviceType.getMaxNumPorts());
		}
		deviceBsTypeDbBean.setModifiedBy("ESAP_INV");
		deviceBsTypeDbBean.setLastModifiedDate(new Timestamp(System.currentTimeMillis()));
		return deviceBsTypeDbBean;
		
	}

}
