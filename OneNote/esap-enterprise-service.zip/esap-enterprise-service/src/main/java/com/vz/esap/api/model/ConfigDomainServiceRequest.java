/**
 * 
 */
package com.vz.esap.api.model;

/**
 * @author Deepak Kumar
 * 
 */
public class ConfigDomainServiceRequest {

	private String configParamsId;
	private String description;
	private String paramGroup;
	private String paramName;
	private String paramValue;
	private String processName;
	private String status;

	/**
	 * @return the configParamsId
	 */
	public String getConfigParamsId() {
		return configParamsId;
	}

	/**
	 * @param configParamsId
	 *            the configParamsId to set
	 */
	public void setConfigParamsId(String configParamsId) {
		this.configParamsId = configParamsId;
	}

	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @param description
	 *            the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * @return the paramGroup
	 */
	public String getParamGroup() {
		return paramGroup;
	}

	/**
	 * @param paramGroup
	 *            the paramGroup to set
	 */
	public void setParamGroup(String paramGroup) {
		this.paramGroup = paramGroup;
	}

	/**
	 * @return the paramValue
	 */
	public String getParamValue() {
		return paramValue;
	}

	/**
	 * @param paramValue
	 *            the paramValue to set
	 */
	public void setParamValue(String paramValue) {
		this.paramValue = paramValue;
	}

	/**
	 * @return the processName
	 */
	public String getProcessName() {
		return processName;
	}

	/**
	 * @param processName
	 *            the processName to set
	 */
	public void setProcessName(String processName) {
		this.processName = processName;
	}

	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * @param status
	 *            the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * @return the paramName
	 */
	public String getParamName() {
		return paramName;
	}

	/**
	 * @param paramName the paramName to set
	 */
	public void setParamName(String paramName) {
		this.paramName = paramName;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "ConfigDomainServiceRequest [configParamsId=" + configParamsId
				+ ", description=" + description + ", paramGroup=" + paramGroup
				+ ", paramName=" + paramName + ", paramValue=" + paramValue
				+ ", processName=" + processName + ", status=" + status + "]";
	}

}
