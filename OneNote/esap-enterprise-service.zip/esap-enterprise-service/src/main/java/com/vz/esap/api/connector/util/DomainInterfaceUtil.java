package com.vz.esap.api.connector.util;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.vz.esap.api.generated.pojo.ColumnMetaData;
import com.vz.esap.api.generated.pojo.ColumnMetaData_;
import com.vz.esap.api.generated.pojo.DBOperationResponse;
import com.vz.esap.api.generated.pojo.DatabaseServiceResponse;
import com.vz.esap.api.generated.pojo.Entity;
import com.vz.esap.api.generated.pojo.EntityGroupInfo;
import com.vz.esap.api.generated.pojo.EntitySearchInfo;
import com.vz.esap.api.generated.pojo.OrderRequest;
import com.vz.esap.api.generated.pojo.OrderResponse;
import com.vz.esap.api.generated.pojo.ParamDetail;
import com.vz.esap.api.generated.pojo.ParamInfo;
import com.vz.esap.api.generated.pojo.RowDataList;
import com.vz.esap.api.generated.pojo.RowDataList_;
import com.vz.esap.api.generated.pojo.TblFailEntityInfo;
import com.vz.esap.api.model.DBServiceResponse;
import com.vz.esap.api.model.FailEntityInfo;
import com.vz.esap.api.model.OrderDomainServiceRequest;
import com.vz.esap.api.model.TblCell;
import com.vz.esap.api.model.TblRow;
import com.vz.esap.api.model.dto.OrderDomainServiceDTO;
import com.vz.esap.api.model.ordering.EntityBatch;
import com.vz.esap.api.model.ordering.EntityData;
import com.vz.esap.api.model.ordering.OrderHeader;
import com.vz.esap.api.model.ordering.OrderSearchFilter;
import com.vz.esap.api.model.ordering.TableOrderDetailsParam;
import com.vz.esap.api.model.ordering.TableOrderDetailsParam.TableOrderDetailsParamBuilder;


import ma.glasnost.orika.MapperFacade;
import ma.glasnost.orika.MapperFactory;
import ma.glasnost.orika.impl.DefaultMapperFactory;

public class DomainInterfaceUtil {
	
	
	final static MapperFactory MAPPER_FACTORY = new DefaultMapperFactory.Builder().build();
	private static DomainInterfaceUtil domainInterfaceUtil = null;
	private static MapperFacade mapper = null;;
	private static final Logger logger = LoggerFactory.getLogger(DomainInterfaceUtil.class);
	
	public static DomainInterfaceUtil getDomainInterfaceUtil(){
		if (domainInterfaceUtil == null){
			domainInterfaceUtil = new DomainInterfaceUtil();
			MAPPER_FACTORY.classMap(OrderHeader.class, com.vz.esap.api.generated.pojo.OrderHeader.class)
			.field("unoServiceId", "UNOServiceId")
			.field("voipLocationId", "VOIPLocationId")
			.field("gchId", "GCHId")
			.field("naspId", "NASPId").byDefault().register();
			
			MAPPER_FACTORY.classMap(OrderSearchFilter.class, com.vz.esap.api.generated.pojo.EntitySearchInfo.class)
			.field("startIndex", "searchFilter.startIndex")
			.field("endIndex", "searchFilter.endIndex")
			.field("paramNameList", "searchFilter.paramNameList")
			.byDefault().register();
			
			MAPPER_FACTORY.classMap(FailEntityInfo.class, com.vz.esap.api.generated.pojo.TblFailEntityInfo.class)
			.field("errorCode", "errorCodes")
			.field("errorDesc", "errorDescp")
			.byDefault().register();
			
			mapper = MAPPER_FACTORY.getMapperFacade();
		}
		return domainInterfaceUtil;
	}
	private DomainInterfaceUtil(){
		
	}

	
	/**
	 * @param sourceView
	 * @param isParamDetailMapView
	 * use false for ListView (when multiple params of same name possible in TOD at same level). paramName needs to be iterated
	 * use true for other cases. Can do direct look up paramName.
	 * @return
	 */
	public  OrderDomainServiceDTO transformResponseViewToDTO(OrderResponse sourceView, boolean isParamDetailMapView) {
		logger.info("Entering transformResponseViewToDTO(): ");
		logger.debug("transformResponseViewToDTO(): Input Object: {} ", sourceView);

		OrderHeader orderHeader = new OrderHeader.OrderHeaderBuilder()
				.withEnterpriseId(sourceView.getOrderHeader().getEnterpriseId())
				.withEnvOrderId(String.valueOf(sourceView.getOrderHeader().getEnvOrderId()))
				.withFunctionCode(sourceView.getOrderHeader().getFunctionCode())
				.withGchId(sourceView.getOrderHeader().getGCHId()).withNaspId(sourceView.getOrderHeader().getNASPId())
				.withOrderType(sourceView.getOrderHeader().getOrderType()).withResponseType("")
				.withTransactionID(sourceView.getOrderHeader().getTransactionID())
				.withUnoServiceId(sourceView.getOrderHeader().getUNOServiceId())
				.withVoipLocationId(sourceView.getOrderHeader().getVOIPLocationId())
				.withWorkOrderId(sourceView.getOrderHeader().getWorkOrderNumber())
				.withWorkOrderNumber(sourceView.getOrderHeader().getWorkOrderNumber())
				.withWorkOrderVersion(sourceView.getOrderHeader().getWorkOrderVersion()).build();

		OrderDomainServiceDTO.OrderDomainServiceDTOBuilder orderDomainServiceDTOBuilder = new OrderDomainServiceDTO.OrderDomainServiceDTOBuilder();
		orderDomainServiceDTOBuilder.withOrderHeader(orderHeader);

		Map<String, EntityBatch.EntityBatchBuilder> entityBatchMap = new HashMap<>();
		EntityBatch.EntityBatchBuilder entityBatchBuilder = null;

		for (EntityGroupInfo entityGroupInfo : sourceView.getEntityGroupInfo()) {
			String entityBatchType = entityGroupInfo.getEntityType();
			entityBatchBuilder = entityBatchMap.get(entityBatchType);
			if (entityBatchBuilder == null) {
				entityBatchBuilder = new EntityBatch.EntityBatchBuilder();
				entityBatchMap.put(entityBatchType, entityBatchBuilder);
			}
			if (entityGroupInfo.getAdditionalInfo() != null && entityGroupInfo.getAdditionalInfo().getParamInfo() != null){
				for (ParamInfo p : entityGroupInfo.getAdditionalInfo().getParamInfo()) {
					if ("startIndex".equalsIgnoreCase(p.getParamName()))
						entityBatchBuilder.withStartIndex(Long.parseLong(p.getParamValue()));
					if ("endIndex".equalsIgnoreCase(p.getParamName()))
						entityBatchBuilder.withEndIndex(Long.parseLong(p.getParamValue()));
					if ("maxIndex".equalsIgnoreCase(p.getParamName()))
						entityBatchBuilder.withMaxIndex(Long.parseLong(p.getParamValue()));
				}
			}
			entityBatchBuilder.withEntityType(entityBatchType);

			for (Entity entity : entityGroupInfo.getEntity()) {
				if (entity == null){
					//There are some cases when order domain is return null entity object 
					continue;
				}
				EntityData entityDataObj = null;
				EntityData.EntityDataBuilder entityDataBuilder = new EntityData.EntityDataBuilder();

				entityDataBuilder.withEntityKey(entity.getEntityValue());
				entityDataBuilder.withEntityValue(entity.getEntityValue());
				entityDataBuilder.withEntityType(entityBatchType);

				// HashMap<String,TableOrderDetailsParam.TableOrderDetailsParamBuilder>
				// parentParamMap = new HashMap<>();

				HashMap<Long, ParamDetail> referenceMap = new HashMap<>();
				List<ParamDetail> paramDetaiList = entity.getParamDetails();

				for (ParamDetail paramDetail : paramDetaiList) {
					referenceMap.put(paramDetail.getOrderDetailId(), paramDetail);
				}

				
				// Preparing two structures - One List of elements that have no parents
				// Second - HashMap with Key as ParentId and Value as List<ChildId>
				
				List<Long> roots = new ArrayList<Long>();
				Map<Long, ArrayList<Long>> tree = new HashMap<Long, ArrayList<Long>>();
				
				for (ParamDetail n : paramDetaiList) {
					if (n.getParentId() == null || n.getParentId() == 0)
						roots.add(n.getOrderDetailId());// list of roots
					else {
						if (!tree.containsKey(n.getParentId()))
							tree.put(n.getParentId(), new ArrayList<Long>());
						tree.get(n.getParentId()).add(n.getOrderDetailId());// parent to PD mapping
					}
				}
				
				// Traverse root elements - that have no parent
				// For each root element, find if key exists in tree and has childIds

				for (Long rootParamId : roots) {
					ParamDetail paramDetail = referenceMap.get(rootParamId);// fetching ParamDetail for every orderDetail ID

					TableOrderDetailsParam.TableOrderDetailsParamBuilder levelZeroParamBuilder = prepareTableOrderDetailParamBuilder(
							paramDetail);
					
					TableOrderDetailsParam childParamDetail = prepareChildParamBuilder(tree, rootParamId,referenceMap,levelZeroParamBuilder);
					
					/*if (childParamDetail != null)
					levelZeroParamBuilder.addParamDetail(childParamDetail);

					paramObj = levelZeroParamBuilder.build();*/
					if (childParamDetail != null) {
						if (isParamDetailMapView){
							entityDataBuilder.putParamDetail(childParamDetail);
							//TODO need to check memory usages 
							entityDataBuilder.putParamDetailOnOrderId(childParamDetail);// adding Param detail based on OrderId
						}else
							entityDataBuilder.addParamDetail(childParamDetail);
					}

				}

				entityDataObj = entityDataBuilder.build();
				entityBatchBuilder.putEntityData(entityDataObj);
			}
		}
		for (Map.Entry<String, EntityBatch.EntityBatchBuilder> entry : entityBatchMap.entrySet()) {
			orderDomainServiceDTOBuilder.putEntityBatch(entry.getValue().build());
		}

		OrderDomainServiceDTO orderDomainServiceDTO = orderDomainServiceDTOBuilder.build();

		logger.debug("transformResponseViewToDTO(): Transformed orderDomainServiceDTO : {}", orderDomainServiceDTO);
		logger.info("Exiting transformResponseViewToDTO(): ");
		return orderDomainServiceDTO;
	}

	private  TableOrderDetailsParam prepareChildParamBuilder(Map<Long, ArrayList<Long>> tree, Long rootParamId, HashMap<Long, ParamDetail> referenceMap, TableOrderDetailsParamBuilder parentBuilder) {
		TableOrderDetailsParam rootObj = null;
		if (childExists(tree, rootParamId)) {
			//TableOrderDetailsParamBuilder rootBuilder = prepareTableOrderDetailParamBuilder(referenceMap.get(rootParamId));
			for (Long childId : tree.get(rootParamId)) {
				TableOrderDetailsParamBuilder childBuilder = prepareTableOrderDetailParamBuilder(referenceMap.get(childId));
				TableOrderDetailsParam buildObj = prepareChildParamBuilder(tree,childId, referenceMap,childBuilder);
				//TableOrderDetailsParam buildObj = prepareTableOrderDetailParamBuilder(referenceMap.get(childId)).build();
				parentBuilder.addParamDetail(buildObj);
			}
		}
		rootObj = parentBuilder.build();
		return rootObj;
	}

	private  boolean childExists(Map<Long, ArrayList<Long>> tree, Long rootParamId) {
		return tree.get(rootParamId) != null && !tree.get(rootParamId).isEmpty();
	}

	private  TableOrderDetailsParam.TableOrderDetailsParamBuilder prepareTableOrderDetailParamBuilder(
			ParamDetail paramDetail) {
		TableOrderDetailsParam.TableOrderDetailsParamBuilder paramBuilder = new TableOrderDetailsParam.TableOrderDetailsParamBuilder();
		paramBuilder.withAction(paramDetail.getAction());
		if (paramDetail.getFlowStatus() != null)
			paramBuilder.withFlowStatus(Long.valueOf(paramDetail.getFlowStatus()));
		if (paramDetail.getLeaf() != null)
			paramBuilder.withLeaf(Long.valueOf(paramDetail.getLeaf()));
		if (paramDetail.getOrderDetailId() != null)
			paramBuilder.withOrderDetailId(paramDetail.getOrderDetailId().toString());
		if (paramDetail.getOrderId() != null)
			paramBuilder.withOrderId(paramDetail.getOrderId().toString());
		paramBuilder.withParamName(paramDetail.getParamName());
		paramBuilder.withParamType(paramDetail.getParamType());
		if (paramDetail.getParamValue() != null)
			paramBuilder.withParamValue(paramDetail.getParamValue().toString());
		if (paramDetail.getParentId() != null)
			paramBuilder.withParentId(paramDetail.getParentId().toString());
		if (paramDetail.getSeqNo() != null)
			paramBuilder.withSequenceNo(paramDetail.getSeqNo().toString());
		return paramBuilder;
	}

	// Only for Testing purpose
	public  static OrderDomainServiceDTO prepareResponseFromInputJsonFile(File jsonFile) {
		ObjectMapper objectMapper = new ObjectMapper();
		DomainInterfaceUtil domainInterfaceUtil = DomainInterfaceUtil.getDomainInterfaceUtil();
		OrderResponse response;
		OrderDomainServiceDTO dto = null;
		try {
			response = objectMapper.readValue(jsonFile, OrderResponse.class);

			dto = domainInterfaceUtil.transformResponseViewToDTO(response, true);

		} catch (JsonParseException e) {
			e.printStackTrace();
		} catch (JsonMappingException e) {
			e.printStackTrace();
		} catch (IOException e) {
			logger.error("Exception while preparing response from Input Json File", e);
		}
		return dto;
	}

	public  OrderRequest transformRequestDTOToView(OrderDomainServiceRequest requestDTO) {
		OrderRequest orderRequest = new OrderRequest();
		
/*		MAPPER_FACTORY.classMap(OrderHeader.class, com.vz.esap.api.generated.pojo.OrderHeader.class)
		.field("unoServiceId", "UNOServiceId")
		.field("voipLocationId", "VOIPLocationId")
		.field("gchId", "GCHId")
		.field("naspId", "NASPId").byDefault().register();
		
		MAPPER_FACTORY.classMap(OrderSearchFilter.class, com.vz.esap.api.generated.pojo.EntitySearchInfo.class)
		.field("startIndex", "searchFilter.startIndex")
		.field("endIndex", "searchFilter.endIndex")
		.field("paramNameList", "searchFilter.paramNameList")
		.byDefault().register();
		
		MapperFacade mapper = MAPPER_FACTORY.getMapperFacade();*/
		
		OrderHeader orderHeader = requestDTO.getOrderHeader();
		com.vz.esap.api.generated.pojo.OrderHeader orderHeaderGen = mapper.map(orderHeader,com.vz.esap.api.generated.pojo.OrderHeader.class);
		
		orderRequest.setOrderHeader(orderHeaderGen);
		
		List<EntitySearchInfo> entitySearchInfoList = new ArrayList<> ();
		for (OrderSearchFilter orderSearchFilter : requestDTO.getSearchFilter()) {
			com.vz.esap.api.generated.pojo.SearchFilter searchFilter = mapper.map(orderSearchFilter, com.vz.esap.api.generated.pojo.SearchFilter.class);
			com.vz.esap.api.generated.pojo.EntitySearchInfo entitySearchInfo = new EntitySearchInfo();
			entitySearchInfo.setSearchFilter(searchFilter);
			entitySearchInfo.setEntityType(orderSearchFilter.getEntityType().toString());
			entitySearchInfoList.add(entitySearchInfo);
		}		
		
		orderRequest.setEntitySearchInfo(entitySearchInfoList);
		return orderRequest;
	}
	
	public  DBServiceResponse convertDBResponseToTblData(
			DBOperationResponse dbOperationResponse) {

		DBServiceResponse responseData = new DBServiceResponse();
		responseData.setNumberOfRecords(dbOperationResponse.getNumberOfRecords());
		responseData.setQueryReferenceId(dbOperationResponse.getQueryReferenceId());
		responseData.setDbOperation(dbOperationResponse.getDbOperation());
		responseData.setTableName(dbOperationResponse.getTableName());

		ColumnMetaData_ columnMetaDataResponse = dbOperationResponse.getColumnMetaData();

		logger.info("columnMetaDataResponse {}" , columnMetaDataResponse);

		if (columnMetaDataResponse != null) {
			List<String> columnNameList = columnMetaDataResponse.getColumnName();
			List<String> columnTypeList = columnMetaDataResponse.getDataType();

			List<RowDataList_> rowDataListResponse = dbOperationResponse.getRowDataList();
			logger.info("rowDataListResponse Size: {}" , rowDataListResponse.size());

			List<TblRow> tblRowList = new ArrayList<>();
			for (RowDataList_ rowDataList : rowDataListResponse) {
				TblRow tblRow = new TblRow();
				Map<String, TblCell> rowData = new TreeMap<>(String.CASE_INSENSITIVE_ORDER);
				List<String> columnValuesResponse = rowDataList.getColumnValues();
				for (int i = 0; i < columnValuesResponse.size(); i++) {
					String columnValue = columnValuesResponse.get(i);
					TblCell tblCellData = new TblCell();
					tblCellData.setName(columnNameList.get(i));
					tblCellData.setValue(columnValue);
					tblCellData.setDataType(columnTypeList.get(i));
					rowData.put(columnNameList.get(i), tblCellData);
				}
				tblRow.setTblRow(rowData);
				tblRowList.add(tblRow);
			}
			logger.info("Row Size: {}" , tblRowList.size());
			responseData.setTableRows(tblRowList);
		}else{
			List<TblRow> tblRowList = new ArrayList<>();
			responseData.setTableRows(tblRowList);
		}
		return responseData;

	}
	
	public  DBServiceResponse convertDBResponseToTblData(
			DatabaseServiceResponse dbServiceResponse) {

		DBServiceResponse responseData = new DBServiceResponse();
		ColumnMetaData columnMetaDataResponse = dbServiceResponse.getColumnMetaData();

		logger.info("columnMetaDataResponse {}" , columnMetaDataResponse);

		if (columnMetaDataResponse == null) {
			throw new RuntimeException("Column Metadata Missing");
		}

		List<String> columnNameList = columnMetaDataResponse.getColumnName();
		List<String> columnTypeList = columnMetaDataResponse.getDataType();

		List<RowDataList> rowDataListResponse = dbServiceResponse.getRowDataList();
		logger.info("rowDataListResponse Size: {}" , rowDataListResponse.size());

		List<TblRow> tblRowList = new ArrayList<>();
		for (RowDataList rowDataList : rowDataListResponse) {
			TblRow tblRow = new TblRow();
			Map<String, TblCell> rowData = new TreeMap<>(String.CASE_INSENSITIVE_ORDER);
			List<String> columnValuesResponse = rowDataList.getColumnValues();
			for (int i = 0; i < columnValuesResponse.size(); i++) {
				String columnValue = columnValuesResponse.get(i);
				TblCell tblCellData = new TblCell();
				tblCellData.setName(columnNameList.get(i));
				tblCellData.setValue(columnValue);
				tblCellData.setDataType(columnTypeList.get(i));
				rowData.put(columnNameList.get(i).toUpperCase(), tblCellData);
			}
			tblRow.setTblRow(rowData);
			tblRowList.add(tblRow);
		}
		logger.info("Row Size: {}" , tblRowList.size());
		responseData.setTableRows(tblRowList);
		responseData.setNumberOfRecords(dbServiceResponse.getNumberOfRecords());
		responseData.setTableName(dbServiceResponse.getTableName());
		return responseData;

	}

	public  List<TblFailEntityInfo> transformRequestDTOToView(List<FailEntityInfo> failEntityInfoList) {
		/*MAPPER_FACTORY.classMap(FailEntityInfo.class, com.vz.esap.api.generated.pojo.TblFailEntityInfo.class)
		.field("errorCode", "errorCodes")
		.field("errorDesc", "errorDescp")
		.byDefault().register();
		
		MapperFacade mapper = MAPPER_FACTORY.getMapperFacade();*/
		
		List<com.vz.esap.api.generated.pojo.TblFailEntityInfo> responseList = new ArrayList<>();
		com.vz.esap.api.generated.pojo.TblFailEntityInfo tblFailEntityInfo = null;
		
		for (FailEntityInfo failEntityInfo : failEntityInfoList) {
			tblFailEntityInfo = mapper.map(failEntityInfo,com.vz.esap.api.generated.pojo.TblFailEntityInfo.class);
			responseList.add(tblFailEntityInfo);
		}
		return responseList;
		
	}

	public  List<String> transformOrderFaillOutEntityInfoResponseViewToDTO(
			List<LinkedHashMap> orderFalloutServiceResponse) {
		logger.info("transformOrderFaillOutEntityInfoResponseViewToDTO ");
		List<String> responseList = new ArrayList<String>();
		if ((orderFalloutServiceResponse == null) || (orderFalloutServiceResponse.isEmpty())) {
			return responseList;
		}
		logger.info("transformOrderFaillOutEntityInfoResponseViewToDTO Total records exist :{}",
				orderFalloutServiceResponse.size());
		for (int i = 0; i < orderFalloutServiceResponse.size(); i++) {
			LinkedHashMap<String, String> map = orderFalloutServiceResponse.get(i);
			String tn = String.valueOf(map.get("tn"));
			responseList.add(tn);
		}
		return responseList;

	}

}