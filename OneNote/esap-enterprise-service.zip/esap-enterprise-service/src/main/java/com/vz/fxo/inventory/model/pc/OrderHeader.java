package com.vz.fxo.inventory.model.pc;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

@XmlAccessorType(XmlAccessType.FIELD)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
public class OrderHeader {
	@XmlElement(name = "ContractInd")
	@JsonProperty(value = "ContractInd")
	private String contractInd;

	@XmlElement(name = "MinorOrderType")
	@JsonProperty(value = "MinorOrderType")
	private String minorOrderType;

	@XmlElement(name="NASPId")
	@JsonProperty(value = "NASPId")
	private String naspId;

	@XmlElement(name = "MsgSegmentNo")
	@JsonProperty(value = "MsgSegmentNo")
	private String msgSegmentNo;

	@XmlElement(name = "SuppType")
	@JsonProperty(value = "SuppType")
	private String suppType;

	@XmlElement(name = "DueDate")
	@JsonProperty(value = "DueDate")
	private String dueDate;

	@XmlElement(name = "WorkOrderNumber")
	@JsonProperty(value = "WorkOrderNumber")
	private String workOrderNumber;

	@XmlElement(name = "LastSegment")
	@JsonProperty(value = "LastSegment")
	private String lastSegment;

	@XmlElement(name = "DueDateType")
	@JsonProperty(value = "DueDateType")
	private String dueDateType;

	@XmlElement(name = "UNOServiceId")
	@JsonProperty(value = "UNOServiceId")
	private String unoServiceId;

	@XmlElement(name = "FunctionCode")
	@JsonProperty(value = "FunctionCode")
	private String functionCode;

	@XmlElement(name = "TransactionID")
	@JsonProperty(value = "TransactionID")
	private String transactionID;

	@XmlElement(name = "BulkOrder")
	@JsonProperty(value = "BulkOrder")
	private String bulkOrder;

	@XmlElement(name = "WorkOrderVersion")
	@JsonProperty(value = "WorkOrderVersion")
	private String workOrderVersion;

	@XmlElement(name = "EnterpriseId")
	@JsonProperty(value = "EnterpriseId")
	private String enterpriseId;

	// @XmlElement(name="VOIPLocationId")
	@XmlElement(name = "VOIPLocationId")
	@JsonProperty(value = "VOIPLocationId")
	private String voipLocationId;

	@XmlElement(name = "OrderType")
	@JsonProperty(value = "OrderType")
	private String orderType;

	// @XmlElement(name="GCHId")
	@XmlElement(name = "GCHId")
	@JsonProperty(value = "GCHId")
	private String gchId;

	@XmlElement(name = "OriginatingSystem")
	@JsonProperty(value = "OriginatingSystem")
	private String originatingSystem;
	
	@XmlElement(name = "ResponseType")
	@JsonProperty(value = "ResponseType")
	private String responseType;

	@XmlElement(name = "PCOrderId")
	@JsonProperty(value = "PCOrderId")
	private String pcOrderId;
	
	
	public String getContractInd() {
		return contractInd;
	}

	public void setContractInd(String contractInd) {
		this.contractInd = contractInd;
	}

	public String getMinorOrderType() {
		return minorOrderType;
	}

	public void setMinorOrderType(String minorOrderType) {
		this.minorOrderType = minorOrderType;
	}

	public String getNaspId() {
		return naspId;
	}

	public void setNaspId(String naspId) {
		this.naspId = naspId;
	}

	public String getMsgSegmentNo() {
		return msgSegmentNo;
	}

	public void setMsgSegmentNo(String msgSegmentNo) {
		this.msgSegmentNo = msgSegmentNo;
	}

	public String getSuppType() {
		return suppType;
	}

	public void setSuppType(String suppType) {
		this.suppType = suppType;
	}

	public String getDueDate() {
		return dueDate;
	}

	public void setDueDate(String dueDate) {
		this.dueDate = dueDate;
	}

	public String getWorkOrderNumber() {
		return workOrderNumber;
	}

	public void setWorkOrderNumber(String workOrderNumber) {
		this.workOrderNumber = workOrderNumber;
	}

	public String getLastSegment() {
		return lastSegment;
	}

	public void setLastSegment(String lastSegment) {
		this.lastSegment = lastSegment;
	}

	public String getDueDateType() {
		return dueDateType;
	}

	public void setDueDateType(String dueDateType) {
		this.dueDateType = dueDateType;
	}

	public String getUnoServiceId() {
		return unoServiceId;
	}

	public void setUnoServiceId(String unoServiceId) {
		this.unoServiceId = unoServiceId;
	}

	public String getFunctionCode() {
		return functionCode;
	}

	public void setFunctionCode(String functionCode) {
		this.functionCode = functionCode;
	}

	public String getTransactionID() {
		return transactionID;
	}

	public void setTransactionID(String transactionID) {
		this.transactionID = transactionID;
	}

	public String getBulkOrder() {
		return bulkOrder;
	}

	public void setBulkOrder(String bulkOrder) {
		this.bulkOrder = bulkOrder;
	}

	public String getWorkOrderVersion() {
		return workOrderVersion;
	}

	public void setWorkOrderVersion(String workOrderVersion) {
		this.workOrderVersion = workOrderVersion;
	}

	public String getEnterpriseId() {
		return enterpriseId;
	}

	public void setEnterpriseId(String enterpriseId) {
		this.enterpriseId = enterpriseId;
	}

	public String getVoipLocationId() {
		return voipLocationId;
	}

	public void setVoipLocationId(String voipLocationId) {
		this.voipLocationId = voipLocationId;
	}

	public String getOrderType() {
		return orderType;
	}

	public void setOrderType(String orderType) {
		this.orderType = orderType;
	}

	public String getGchId() {
		return gchId;
	}

	public void setGchId(String gchId) {
		this.gchId = gchId;
	}

	public String getOriginatingSystem() {
		return originatingSystem;
	}

	public void setOriginatingSystem(String originatingSystem) {
		this.originatingSystem = originatingSystem;
	}

	public String getResponseType() {
		return responseType;
	}

	public void setResponseType(String responseType) {
		this.responseType = responseType;
	}

	/**
	 * @return the pcOrderId
	 */
	public String getPcOrderId() {
		return pcOrderId;
	}

	/**
	 * @param pcOrderId the pcOrderId to set
	 */
	public void setPcOrderId(String pcOrderId) {
		this.pcOrderId = pcOrderId;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "OrderHeader [contractInd=" + contractInd + ", minorOrderType="
				+ minorOrderType + ", naspId=" + naspId + ", msgSegmentNo="
				+ msgSegmentNo + ", suppType=" + suppType + ", dueDate="
				+ dueDate + ", workOrderNumber=" + workOrderNumber
				+ ", lastSegment=" + lastSegment + ", dueDateType="
				+ dueDateType + ", unoServiceId=" + unoServiceId
				+ ", functionCode=" + functionCode + ", transactionID="
				+ transactionID + ", bulkOrder=" + bulkOrder
				+ ", workOrderVersion=" + workOrderVersion + ", enterpriseId="
				+ enterpriseId + ", voipLocationId=" + voipLocationId
				+ ", orderType=" + orderType + ", gchId=" + gchId
				+ ", originatingSystem=" + originatingSystem
				+ ", responseType=" + responseType + ", pcOrderId=" + pcOrderId
				+ "]";
	}

}
