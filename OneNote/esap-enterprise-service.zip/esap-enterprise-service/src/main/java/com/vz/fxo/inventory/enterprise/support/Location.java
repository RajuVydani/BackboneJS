
package com.vz.fxo.inventory.enterprise.support;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.vz.esap.api.generated.pojo.ParamDetail;
import com.vz.fxo.inventory.enterprise.support.Enterprise;
//import com.vz.fxo.inventory.enterprise.support.KeyGroup;
import com.vz.fxo.inventory.enterprise.support.PBXGroup;
import com.vz.fxo.inventory.enterprise.support.TwoWayGroup;
//import com.vz.fxo.inventory.enterprise.KeyGroupTn;

import EsapEnumPkg.InvEnum;
import EsapEnumPkg.VzbVoipEnum;
import esap.db.DBTblBsAs;
import esap.db.DBTblCallingPlans;
import esap.db.DBTblDeviceMap;
import esap.db.DBTblEntBillFeatures;
import esap.db.DBTblEnterprise;
import esap.db.DBTblGatewayDeviceInfo;
import esap.db.DBTblGroupFeatures;
import esap.db.DBTblLocPackage;
import esap.db.DBTblLocation;
import esap.db.DBTblLocationFeatures;
import esap.db.DBTblPackage;
import esap.db.DBTblPkgFeatures;
import esap.db.DBTblPoliciesService;
import esap.db.DBTblPublicTnPool;
import esap.db.DBTblSubFeature;
import esap.db.DBTblTerminatingRouting;
import esap.db.DBTblVzbFeatures;
import esap.db.DBTblVzbStateGatewayMap;
import esap.db.IpcomLocationDbBean;
import esap.db.TblAccessTypeQuery;
import esap.db.TblAcctAuthCodesQuery;
import esap.db.TblBsAsQuery;
import esap.db.TblCallingPlansQuery;
import esap.db.TblConfigParamsDbBean;
import esap.db.TblConfigParamsQuery;
import esap.db.TblCustomerDbBean;
import esap.db.TblCustomerQuery;
import esap.db.TblDaylightSavingRegionsQuery;
import esap.db.TblDeviceMapQuery;
import esap.db.TblDialPlanQuery;
import esap.db.TblEntBillFeaturesQuery;
import esap.db.TblEnterpriseDbBean;
import esap.db.TblEnterpriseQuery;
import esap.db.TblGatewayDeviceInfoQuery;
import esap.db.TblGroupExcldFeaturesQuery;
import esap.db.TblGroupFeaturesQuery;
import esap.db.TblGroupQuery;
import esap.db.TblGroupTnExcldFeaturesQuery;
import esap.db.TblGroupTnQuery;
import esap.db.TblLocPackageDbBean;
import esap.db.TblLocPackageQuery;
import esap.db.TblLocationDbBean;
import esap.db.TblLocationFeaturesQuery;
import esap.db.TblLocationQuery;
import esap.db.TblPackageQuery;
import esap.db.TblPkgFeaturesDbBean;
import esap.db.TblPkgFeaturesQuery;
import esap.db.TblPoliciesDbBean;
import esap.db.TblPoliciesQuery;
import esap.db.TblPrefixRoutingQuery;
import esap.db.TblPublicTnPoolDbBean;
import esap.db.TblPublicTnPoolQuery;
import esap.db.TblSbcOrderQuery;
import esap.db.TblSipDomainQuery;
import esap.db.TblSubFeatureQuery;
import esap.db.TblSubscriberQuery;
import esap.db.TblTerminatingRoutingDbBean;
import esap.db.TblTerminatingRoutingQuery;
import esap.db.TblTsoEnterpriseTrunkQuery;
import esap.db.TblTsoEtTnDbBean;
import esap.db.TblTsoEtTnExcldFeaturesQuery;
import esap.db.TblTsoEtTnQuery;
import esap.db.TblVmAccessDbBean;
import esap.db.TblVmAccessQuery;
import esap.db.TblVzbEmerCodeQuery;
import esap.db.TblVzbFeaturesDbBean;
import esap.db.TblVzbFeaturesQuery;
import esap.db.TblVzbPrefixPlanQuery;
import esap.db.TblVzbStateGatewayMapDbBean;
import esap.db.TblVzbStateGatewayMapQuery;

public class Location extends LocationBean {
	
	private static Logger log = LoggerFactory.getLogger(Location.class.toString());
	
	private InvErrorCode status;
	Connection dbCon;
	boolean rollbackFlag;
	boolean migration;
	boolean shellMigration;
	String sipClient;
	String productType;
	String sbcAccessType;
	//added by z658915: starts  
	boolean isVarrsChanged;
	
	public void setIsVarrsChanged(boolean isVarrsChanged) {
		this.isVarrsChanged = isVarrsChanged;
	}
	public boolean getIsVarrsChanged() {
		return isVarrsChanged;
	}
	//added by z658915: ends


	/**
	 * @return the sbcAccessType
	 */
	public String getSbcAccessType() {
		return sbcAccessType;
	}

	/**
	 * @param sbcAccessType
	 *            the sbcAccessType to set
	 */
	public void setSbcAccessType(String sbcAccessType) {
		this.sbcAccessType = sbcAccessType;
	}

	/**
	 * @return the productType
	 */
	public String getProductType() {
		return productType;
	}

	/**
	 * @param productType
	 *            the productType to set
	 */
	public void setProductType(String productType) {
		this.productType = productType;
	}

	boolean sharedGatewayMove;

	public boolean isSharedGatewayMove() {
		return sharedGatewayMove;
	}

	public void setSharedGatewayMove(boolean sharedGatewayMove) {
		this.sharedGatewayMove = sharedGatewayMove;
	}

	public static final String DATE_FORMAT_NOW = "yyyy-MM-dd HH:mm:ss";
	private static final ParamDetail orderParam = null;

	public Location(Connection dbCon) {
		this.dbCon = dbCon;
		this.rollbackFlag = false;
		this.migration = false;
		this.shellMigration = false;
		this.sharedGatewayMove = false;
		this.productType = "";
		this.sbcAccessType = "";
	}

	public Location(LocationBean locBean, Connection dbCon) {
		super(locBean);
		this.dbCon = dbCon;
		this.rollbackFlag = false;
		this.migration = false;
		this.shellMigration = false;
		this.sharedGatewayMove = false;
		this.productType = "";
		this.sbcAccessType = "";
	}

	public Location(IpcomLocationDbBean iasaLocBean, Connection dbCon) {
		super(iasaLocBean);

		Connection iasa_connection = null;
		try {
			//iasa_connection = IASAConnectionHelper.getIASAConnection(dbCon);
			if (iasa_connection == null)
				throw new Exception("Unable to get Iasa DB Connection");

/*			SBCMigration sbcMigHandler = new SBCMigration(dbCon,
					iasa_connection);
			// get the SIPCLIENT using getSipclientFromSbcLocation() cap call
			// set the SIPCLIENT class variable
			String tmpSipClient = sbcMigHandler.getSipclientFromSbcLocation(
					Long.parseLong(this.locationId), this.enterpriseId);
			if (tmpSipClient != null) {
				// If sbc_location.sipclient = 1 setSipEnabled(1)
				// If sbc_location.sipclient = 0 setSipEnabled(0)
				// setSipClient(tmpSipClient);
				if (tmpSipClient.equalsIgnoreCase("1")) {
					this.sipEnabled = 1;
				} else if (tmpSipClient.equalsIgnoreCase("0")) {
					this.sipEnabled = 0;
				}
			} else {
				this.sipEnabled = 0;
			}*/
			this.dbCon = dbCon;
			this.rollbackFlag = false;
			this.migration = false;
			this.shellMigration = false;
			this.sharedGatewayMove = false;
			this.productType = "";
			this.sbcAccessType = "";

		} catch (Exception e) {
			setStatus(InvErrorCode.DB_EXCEPTION);
			log.info("DB_FAILURE in getLocationFromIasa Location");
			e.printStackTrace();
			// throw new Exception(e);
		} finally {

			if (iasa_connection != null) {
				try {
					iasa_connection.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
				iasa_connection = null;
			}

		}
	}

	public int getStatusCode() {
		return status.getErrorCode();
	}

	public void setStatus(InvErrorCode status) {
		this.status = status;
	}

	public String getStatusDesc() {
		return status.getErrorDesc();
	}

	public Connection getDbCon() {
		return dbCon;
	}

	public void setDbCon(Connection dbCon) {
		this.dbCon = dbCon;
	}

	public boolean getRollbackFlag() {
		return rollbackFlag;
	}

	public void setRollbackFlag(boolean rollbackFlag) {
		this.rollbackFlag = rollbackFlag;
	}

	public boolean getMigration() {
		return migration;
	}

	public void setMigration(boolean migration) {
		this.migration = migration;
	}

	public boolean getShellMigration() {
		return shellMigration;
	}

	public void setShellMigration(boolean shellMigration) {
		this.shellMigration = shellMigration;
	}

	public String getSipClient() {
		return sipClient;
	}

	public void setSipClient(String sipClient) {
		this.sipClient = sipClient;
	}
	//KR
	//KR-start add for xo PolicyService changes
		public int getPolicyServiceSeqNextVal(Connection connection)
				throws SQLException {
			int policyServiceId = 0;
			PreparedStatement ps = null;
			ResultSet rs = null;
			try {

				ps = connection
						.prepareStatement("SELECT TBL_POLICIES_SERVICE_SEQ.NEXTVAL FROM DUAL");

				rs = ps.executeQuery();
				if (rs.next()) {
					policyServiceId = rs.getInt(1);
				}

			} catch (SQLException e) {
				// log_msg(logging_level, "ERROR: SELECT auth_service_id_seq.NEXTVAL
				// FROM DUAL");
				e.printStackTrace();
				return 0;
			} finally {
				if (null != rs)
					rs.close();
				if (null != ps)
					ps.close();
			}
			return policyServiceId;
	}
	private int addDefaultPolicyFeatures(String[] policyType)
			throws SQLException, Exception { 
		int policySerId = 0;
		TblPoliciesQuery policyQry=new  TblPoliciesQuery();
		policyQry.wherePolicyTypeIn(policyType);
		log.info("Before policyQry in addToDB");
		policyQry.query(dbCon);
		log.info("After policyQry in addToDB");

		if (policyQry.size() > 0) {				
			policySerId = getPolicyServiceSeqNextVal(dbCon);			
			setPolicyServicesId(policySerId);
			for (int i = 0; i < policyQry.size(); i++) {
				DBTblPoliciesService policyServicesBean=new DBTblPoliciesService();		
				TblPoliciesDbBean policiesDbBean=policyQry.getDbBean(i);
				policyServicesBean.setPoliciesServiceId(policySerId);
				policyServicesBean.setPolicyId(policiesDbBean.getPolicyId());
				policyServicesBean.setAccesslevel("Full");//TODO check this value from tod
				if (getEnvOrderId() > 0)
					policyServicesBean.setEnvOrderId((int)getEnvOrderId());  
				else
					policyServicesBean.setEnvOrderId(0);
				if (createdBy != null && !createdBy.trim().equals(""))
					policyServicesBean.setCreatedBy(createdBy);
				else
					policyServicesBean.setCreatedBy("ESAP_INV");
				if (modifiedBy != null && !modifiedBy.trim().equals(""))
					policyServicesBean.setModifiedBy(modifiedBy);
				else
					policyServicesBean.setModifiedBy("ESAP_INV");
				policyServicesBean.setCreationDate(new Timestamp(System
						.currentTimeMillis()));
				policyServicesBean.setLastModifiedDate(new Timestamp(System
						.currentTimeMillis()));				
				policyServicesBean.insert(dbCon);
			}
		}
		return policySerId;
		
	}
	//End
	// methods
	public boolean addToDB() throws SQLException, Exception {
		// try
		// {
		//String policyType=getPolicyType();
		//String[] policyTypeArray= {}
		//if(policyType==null || "".equalsIgnoreCase(policyType))
			//policyType="GAP";
		String[] policyTypeArray= new String[]  {"GAP","GP"};
		int policySerId = addDefaultPolicyFeatures(policyTypeArray);
		
		
		DBTblLocation locationDbBean = new DBTblLocation();
		locationDbBean.setLocationId(locationId);
		locationDbBean.setEnterpriseId(enterpriseId);
		if (orderSource != null && !orderSource.equals("NONE"))
			locationDbBean.setOrderSource(orderSource);
		if (locationName != null && !locationName.equals("NONE"))
			locationDbBean.setLocationName(locationName.trim());
		if (locAddress != null && !locAddress.equals("NONE"))
			locationDbBean.setLocAddress(locAddress);
		if (locCity != null && !locCity.equals("NONE"))
			locationDbBean.setLocCity(locCity);
		if (locState != null && !locState.equals("NONE"))
			locationDbBean.setLocState(locState);
		if (locZip != null && !locZip.equals("NONE"))
			locationDbBean.setLocZip(locZip);
		if (locCountry != null && !locCountry.equals("NONE"))
			locationDbBean.setLocCountry(locCountry);
		if (npaNxx != null && !npaNxx.equals("NONE"))
			locationDbBean.setNpanxx(npaNxx);
		//Xo changes
		if(policySerId>0)
			locationDbBean.setPolicyServiceId(policySerId);
		locationDbBean.setRedundency(redundency);
		locationDbBean.setRedundencyid(redundencyId);
		//locationDbBean.setresetRedundencyPriorityType(groupUserLimit);
		locationDbBean.setEslid(eslId);
		locationDbBean.setLocGroupId(locGroupId);
		locationDbBean.setBroadworksportalnumber(broadworksPortalNumber);
		locationDbBean.setGroupuserlimit(groupUserLimit);
		locationDbBean.setBillingtn(billingTN);

		//maxActiveCalls changes
		locationDbBean.setXoMaxActiveCalls(maxActiveCalls);
		locationDbBean.setXoMaxActiveIncomingCalls(maxActiveIncomingCalls);
		locationDbBean.setXoMaxActiveOutgoingCalls(maxActiveOutgoingCalls);
		
		//End
		// JAN 2013 Release E2EI
		if (physicalLocationId != null && !physicalLocationId.equals("NONE"))
			locationDbBean.setPhysicalLocationId(physicalLocationId);
		if (physicalLocationName != null
				&& !physicalLocationName.equals("NONE"))
			locationDbBean.setPhysicalLocationName(physicalLocationName);
		if (dialingCountryCode != null && !dialingCountryCode.equals("NONE"))
			locationDbBean.setDialingCountryCode(dialingCountryCode);
		if (callFwdPlanName != null && !callFwdPlanName.equals("NONE"))
			locationDbBean.setCallFwdPlanName(callFwdPlanName);
		if (lorId != null && !lorId.equals("NONE")) {
			locationDbBean.setLorId(lorId);
		}
		locationDbBean.setSbcMigInd(sbcMigInd);
		if (subAgencyHierCode != null && !subAgencyHierCode.equals("NONE"))
			locationDbBean.setSubAgencyHierCode(subAgencyHierCode);

		// May 2011 - 2CLI changes
		locationDbBean.setAlternetCallerId(alternativeCallerIdInd);

		// 53938.AA Business Continuity Ph 1 - changes for july 2011
		locationDbBean.setVarrsFlag(varrsFlag);
		// locationDbBean.setIsrDesignId(isrDesignId);

		if (e911Service > -1) {
			locationDbBean.setE911Service((short) e911Service);
		} else {
			locationDbBean.setE911Service((short) VzbVoipEnum.YesNoType.N);
		}

		if (rivLocation > -1)
			locationDbBean.setRivLocation(rivLocation);
		else
			locationDbBean.setRivLocation(1);
		
		if(addressId != null && !addressId.equals("NONE")){
			locationDbBean.setAddressId(addressId);
		}
		
		log.info(" afterHoursInstallFlag " + afterHoursInstallFlag);
		if (afterHoursInstallFlag > -1) {
			locationDbBean.setAfterHoursInstallFlag(afterHoursInstallFlag);
		}
		log.info(" locationDbBean.getAfterHoursInstallFlag() "
				+ locationDbBean.getAfterHoursInstallFlag());
		log.info(" highVolumeInstallFlag " + highVolumeInstallFlag);
		if (highVolumeInstallFlag > -1) {
			locationDbBean.setHighVolumeInstallFlag(highVolumeInstallFlag);
		}
		log.info(" locationDbBean.getHighVolumeInstallFlag() "
				+ locationDbBean.getHighVolumeInstallFlag());
		log.info(" expedite " + expedite);
		if (expedite > -1) {
			locationDbBean.setExpedite(expedite);
		}
		log.info(" locationDbBean.getExpedite() "
				+ locationDbBean.getExpedite());

		if (locCclInd > -1) {
			locationDbBean.setLocCclInd((short) locCclInd);
		} else {
			locationDbBean.setLocCclInd((short) VzbVoipEnum.YesNoType.N);
		}
		log.info(" locationDbBean.getLocCclInd() "
				+ locationDbBean.getLocCclInd());

		if (billingActivated > -1) {
			locationDbBean.setBillingActivated((short) billingActivated);
		} else {
			locationDbBean.setBillingActivated((short) VzbVoipEnum.YesNoType.N);
		}
		log.info(" locationDbBean.getBillingActivated() "
				+ locationDbBean.getBillingActivated());

		log.info(" activeDate " + activeDate);
		if (activeDate != null) {
			log.info(" activeDate if " + activeDate);
			locationDbBean.setActiveDate(activeDate);
		}

		if (configAllowed > -1)
			locationDbBean.setConfigAllowed((short) configAllowed);

		if (!productIdentifier.equals(""))
			locationDbBean.setProductIdentifier(productIdentifier);

		if (callingNameInd > -1) {
			locationDbBean.setCallingNameInd(callingNameInd);
		} else {
			locationDbBean.setCallingNameInd(VzbVoipEnum.YesNoType.N);
		}
		log.info(" locationDbBean.getCallingNameInd() "
				+ locationDbBean.getCallingNameInd());

		if (enhancedAniInd > -1) {
			locationDbBean.setEnhancedAniInd(enhancedAniInd);
		} else {
			locationDbBean.setEnhancedAniInd(VzbVoipEnum.YesNoType.N);
		}
		log.info(" locationDbBean.getEnhancedAniInd() "
				+ locationDbBean.getEnhancedAniInd());

		// Jan 2011 Release changes
		if (billAccountNumber != null
				&& !billAccountNumber.equalsIgnoreCase("")
				&& !billAccountNumber.equalsIgnoreCase("NONE")) {
			locationDbBean.setBillAcctNum(billAccountNumber);
		}
		log.info(" locationDbBean.getBillAcctNum() "
				+ locationDbBean.getBillAcctNum());

		if (locTerritory != null && !locTerritory.equalsIgnoreCase("")
				&& !locTerritory.equalsIgnoreCase("NONE")) {
			locationDbBean.setLocTerritory(locTerritory);
		}
		log.info(" locationDbBean.getLocTerritory() "
				+ locationDbBean.getLocTerritory());

		if (locRegion != null && !locRegion.equalsIgnoreCase("")
				&& !locRegion.equalsIgnoreCase("NONE")) {
			locationDbBean.setLocRegion(locRegion);
		}

		log.info(" locationDbBean.getLocRegion() "
				+ locationDbBean.getLocRegion());

		if (billingSystem > -1) {
			locationDbBean.setBillingSystem(billingSystem);
		}

		log.info(" locationDbBean.getBillingSystem() "
				+ locationDbBean.getBillingSystem());

		if (timeZone != null && !timeZone.equalsIgnoreCase("")
				&& !timeZone.equalsIgnoreCase("NONE"))
			locationDbBean.setTimeZone(Integer.parseInt(timeZone));
		if (useDaylightSaving == -1)
			locationDbBean.setUseDaylightSavings(0);
		else
			locationDbBean.setUseDaylightSavings(useDaylightSaving);
		if (dayLightSavingsRegion != null
				&& !dayLightSavingsRegion.equalsIgnoreCase("")
				&& !dayLightSavingsRegion.equalsIgnoreCase("NONE"))
			locationDbBean.setDaylightSavingsRegion(Long
					.parseLong(dayLightSavingsRegion));
		if (webLang == -1)
			locationDbBean.setWebLang(VzbVoipEnum.Language.NO_PREFERENCE);
		else
			locationDbBean.setWebLang(webLang);
		if (enterpriseTrunkId > 0)
			locationDbBean.setEnterpriseTrunkId(enterpriseTrunkId);
		if (tsoMigLock > -1) {
			locationDbBean.setTsoMigLock(tsoMigLock);
		} else {
			locationDbBean.setTsoMigLock((short) 0);
		}

		if (pqInstanceId > 0)
			locationDbBean.setPqInstanceId(pqInstanceId);

		if (uiProvFlag != -1)
			locationDbBean.setUiProvFlag((short) uiProvFlag);

		if (isrDesignId > 0)
			locationDbBean.setIsrDesignId(isrDesignId);

		if (ixPlusId > -1)
			locationDbBean.setIxplusId(ixPlusId);
		else
			locationDbBean.setIxplusId(0);
		if (ixPlusEnvId != null && !ixPlusEnvId.equals("NONE"))
			locationDbBean.setIxplusEnvId(ixPlusEnvId);
		if (billType > -1)
			locationDbBean.setBillType(billType);
		else
			locationDbBean.setBillType(0);

		if (netcomServiceId != null && !"NONE".equals(netcomServiceId)) {
			locationDbBean.setNetcomServiceId(netcomServiceId);
		}
		if (clin != null && !clin.equals("NONE"))
			locationDbBean.setClin(clin);
		if (cv2Service > -1)
			locationDbBean.setCv2Service(cv2Service);
		else
			locationDbBean.setCv2Service(0);
		if (locationDbBean.getManagedService() > -1) {
			locationDbBean.setManagedService(managedService);
		} else
			locationDbBean.setManagedService(0);
		if (serviceTypeOffering > -1)
			locationDbBean.setServiceTypeOffering(serviceTypeOffering);
		else
			locationDbBean.setServiceTypeOffering(0);
		if (hybridServiceType > -1)
			locationDbBean.setHybridServiceType(hybridServiceType);
		else
			locationDbBean.setHybridServiceType(0);
		if (voipServiceType > -1)
			locationDbBean.setVoipServiceType(voipServiceType);
		else
			locationDbBean.setVoipServiceType(0);
		if (pubIp > -1)
			locationDbBean.setPubIp(pubIp);
		else
			locationDbBean.setPubIp(0);

		if (accessType > -1)
			locationDbBean.setAccessType(accessType);

		// if(circuitId != null && !circuitId.equals("NONE"))
		// locationDbBean.setCircuitId(circuitId);
		if (uunetSiteId != null && !uunetSiteId.equals("NONE"))
			locationDbBean.setUunetSiteId(uunetSiteId);
		if (sipDomain != null && !sipDomain.equals("NONE"))
			locationDbBean.setSipDomain(sipDomain);
		log.info("Trunk Value is =====> " + trunk);
		if (trunk != null && !"NONE".equals(trunk) && !"".equals(trunk))
			locationDbBean.setTrunk(trunk);

		if (sbcInd == -1)
			locationDbBean.setSbcInd(0);
		else
			locationDbBean.setSbcInd(sbcInd);
		if (sipEnabled == -1)
			locationDbBean.setSipEnabled(0);
		else
			locationDbBean.setSipEnabled(sipEnabled);

		if (sbcId > 0)
			locationDbBean.setSbcId(sbcId);
		else
			locationDbBean.setSbcIdNull();
		log.info("EnvOrderId = <" + getEnvOrderId() + ">");
		if (getEnvOrderId() > 0)
			locationDbBean.setEnvOrderId(getEnvOrderId());
		else
			locationDbBean.setEnvOrderIdNull();
		if (getPublicGtwyDpid() == -1)
			locationDbBean.setPublicGtwyDpid(0);
		else
			locationDbBean.setPublicGtwyDpid(publicGtwyDpid);
		if (getDefaultGtwyDpid() == -1)
			locationDbBean.setDefaultGtwyDpid(0);
		else
			locationDbBean.setDefaultGtwyDpid(defaultGtwyDpid);

		log.info("Trunk Type Value is =====> " + getTrunkType());
		if (migration && getTrunkType() != -1)
			locationDbBean.setTrunkType(getTrunkType());
		else
			locationDbBean.setTrunkType(VzbVoipEnum.TrunkType.US_SHARED);
		if (voipClub > -1)
			locationDbBean.setVoipClub(voipClub);
		if (voipClub == VzbVoipEnum.YesNoType.Y) {
			locationDbBean.setPubIp(voipClub);
		} else {
			locationDbBean.setPubIp(pubIp);
		}
		if (locationDbBean.getVoipClub() == -1)
			locationDbBean.setVoipClub(0);
		if (locationDbBean.getPubIp() == -1)
			locationDbBean.setPubIp(0);

		if (serviceLevel > -1)
			locationDbBean.setServiceLevel(serviceLevel);
		else
			locationDbBean.setServiceLevel(0);
		if (locMarket > -1)
			locationDbBean.setLocMarket(locMarket);
		else
			locationDbBean.setLocMarket(0);
		if (maxExtLength > -1)
			locationDbBean.setMaxExtLength(maxExtLength);
		else
			locationDbBean.setMaxExtLength(0);
		if (extLength > -1)
			locationDbBean.setExtLength(extLength);
		else
			locationDbBean.setExtLength(0);
		if (privateNumLength > -1)
			locationDbBean.setPrivateNumLength(privateNumLength);
		else
			locationDbBean.setPrivateNumLength(0);
		if (linePortLength > -1)
			locationDbBean.setLinePortLength(linePortLength);
		else
			locationDbBean.setLinePortLength(0);
		if (abbrDialingCode != null && !abbrDialingCode.equals("NONE"))
			locationDbBean.setAbbrDialingCode(abbrDialingCode);
		if (enableCallPark > -1)
			locationDbBean.setEnableCallPark(enableCallPark);
		else
			locationDbBean.setEnableCallPark(0);
		if (overrideCidNum != -1)
			locationDbBean.setOverrideCidNum(overrideCidNum);
		else
			locationDbBean.setOverrideCidNum(0);
		if (overrideCidName != -1)
			locationDbBean.setOverrideCidName(overrideCidName);
		else
			locationDbBean.setOverrideCidName(0);
		if (overrideSubPrivate != -1)
			locationDbBean.setOverrideSubPrivate(overrideSubPrivate);
		else
			locationDbBean.setOverrideSubPrivate(0);
		if (enableAccountCode != -1)
			locationDbBean.setEnableAccountCode(enableAccountCode);
		else
			locationDbBean.setEnableAccountCode(0);
		if (enableAuthCode != null && !enableAuthCode.equals("NONE"))
			locationDbBean.setEnableAuthCode(enableAuthCode);
		if (migration) {
			if (getLocalDirAssistance() != null
					&& !getLocalDirAssistance().equals("NONE"))
				locationDbBean.setLocalDirAssistance(getLocalDirAssistance());
			if (getNatDirAssistance() != null
					&& !getNatDirAssistance().equals("NONE"))
				locationDbBean.setNatDirAssistance(getNatDirAssistance());
		} else {
			locationDbBean.setLocalDirAssistance(Integer.toString(0));
			locationDbBean.setNatDirAssistance(Integer.toString(2));
		}
		if (concCallStat > -1)
			locationDbBean.setConccallStat(concCallStat);
		else
			locationDbBean.setConccallStat(0);
		if (maxConcurrentCalls > -1)
			locationDbBean.setMaxConcurrentCalls(maxConcurrentCalls);
		else
			locationDbBean.setMaxConcurrentCalls(0);
		if (maxConcurrentOffnet > -1)
			locationDbBean.setMaxConcurrentOffnet(maxConcurrentOffnet);
		else
			locationDbBean.setMaxConcurrentOffnet(0);
		if (maxInbound > -1)
			locationDbBean.setMaxInbound(maxInbound);
		else
			locationDbBean.setMaxInbound(0);
		if (maxSlg > -1)
			locationDbBean.setMaxSlg(maxSlg);
		else
			locationDbBean.setMaxSlg(0);
		if (maxNg > -1)
			locationDbBean.setMaxNg(maxNg);
		else
			locationDbBean.setMaxNg(0);
		if (maxSubscribers > -1)
			locationDbBean.setMaxSubscribers(maxSubscribers);
		else
			locationDbBean.setMaxSubscribers(0);
		if (maxPublicTn > -1)
			locationDbBean.setMaxPublicTn(maxPublicTn);
		else
			locationDbBean.setMaxPublicTn(0);
		if (blockAllCalls > -1)
			locationDbBean.setBlockAllCalls(blockAllCalls);
		else
			locationDbBean.setBlockAllCalls(0);

		if (rpid != null && !rpid.equals("NONE"))
			locationDbBean.setRpid(rpid);
		if (pendingRpid != null && !pendingRpid.equals("NONE"))
			locationDbBean.setPendingRpid(pendingRpid);
		if (rpidPriv != -1)
			locationDbBean.setRpidPriv(rpidPriv);
		else
			locationDbBean.setRpidPriv(1);
		if (hicrService > -1)
			locationDbBean.setHicrService(hicrService);
		else
			locationDbBean.setHicrService(0);
		if (vmLang == -1)
			locationDbBean.setVmLang(0);
		else
			locationDbBean.setVmLang(vmLang);
		if (maxVmBox > -1)
			locationDbBean.setMaxVmBox(maxVmBox);
		else
			locationDbBean.setMaxVmBox(0);
		if (activeInd > -1)
			locationDbBean.setActiveInd(activeInd);

		log.info(" locationDbBean.getActiveInd "
				+ locationDbBean.getActiveInd());

		if (productionIndicator == -1)
			locationDbBean.setProductionIndicator(1);
		else
			locationDbBean.setProductionIndicator(productionIndicator);

		log.info(" locationDbBean.getProductionIndicator "
				+ locationDbBean.getProductionIndicator());

		if (vmType > 0)
			locationDbBean.setVmType(vmType);
		else
			locationDbBean.setVmType(VzbVoipEnum.LocationVmType.HOSTED);

		if (switchClli != null && !switchClli.equals("NONE"))
			locationDbBean.setSwitchClli(switchClli);
		if (vmCpeIpAddress != null && !vmCpeIpAddress.equals("NONE"))
			locationDbBean.setVmCpeIpAddress(vmCpeIpAddress);
		if (contactPhone != null && !contactPhone.equals("NONE"))
			locationDbBean.setContactPhone(contactPhone);
		if (contactName != null && !contactName.equals("NONE"))
			locationDbBean.setContactName(contactName);
		if (contactEmail != null && !contactEmail.equals("NONE"))
			locationDbBean.setContactEmail(contactEmail);
		if (actTeamPhone != null && !actTeamPhone.equals("NONE"))
			locationDbBean.setActTeamPhone(actTeamPhone);
		if (actTeamName != null && !actTeamName.equals("NONE"))
			locationDbBean.setActTeamName(actTeamName);
		if (actTeamEmail != null && !actTeamEmail.equals("NONE"))
			locationDbBean.setActTeamEmail(actTeamEmail);
		if (emerPoolId > 0)
			locationDbBean.setEmerPoolId(emerPoolId);
		if (emerLocationCode != null && !emerLocationCode.equals("NONE"))
			locationDbBean.setEmerLocationCode(emerLocationCode);
		log.info("Received Location Type [" + locationType + "]");
		if (locationType > -1)
			locationDbBean.setLocationType(locationType);
		else
			locationDbBean.setLocationType(VzbVoipEnum.LocationType.STANDARD);
		if (fmcgLocationType == -1)
			locationDbBean
					.setFmcgLocationType(VzbVoipEnum.FmcgLocationType.NONE);
		else
			locationDbBean.setFmcgLocationType(fmcgLocationType);

		if (circuitId != null && !circuitId.equals("NONE"))
			locationDbBean.setCircuitId(circuitId);

		if (restrictedAccess >= 0) {
			locationDbBean.setRestrictedAccess(restrictedAccess);
		}
		if (hybridAssigned > -1)
			locationDbBean.setHybridAssigned(hybridAssigned);
		else
			locationDbBean.setHybridAssigned((short) 0);

		if (e2eimigflag > -1)
			locationDbBean.setE2eiMigFlag(e2eimigflag);
		else
			locationDbBean.setE2eiMigFlag((short) 0);

		if(calnetSubContractId != 0){
			locationDbBean.setCalnetSubContractId(calnetSubContractId);
		}else{
			locationDbBean.setCalnetSubContractId((short)2);
		}
		
		if (hubLocationId != null && !hubLocationId.equals("NONE")
				&& !hubLocationId.equals("")) {
			if (locationType != VzbVoipEnum.LocationType.HUB
					&& locationId != hubLocationId) {
				locationDbBean.setHubLocationId(hubLocationId);
				TblLocationQuery hubLocQry = new TblLocationQuery();
				hubLocQry.whereHubLocationIdEQ(hubLocationId);
				hubLocQry.query(dbCon);
				if (hubLocQry.size() > 0) {
					locationDbBean.setVpnName(hubLocQry.getDbBean(0)
							.getVpnName());
					locationDbBean.setCircuitId(hubLocQry.getDbBean(0)
							.getCircuitId());
				}
			} else
				System.out
						.println("HubLocationId and LocationId cannot be the same");
		}
		
		if (vce != null && !vce.equals("NONE")){
			locationDbBean.setVceEnabled(vce);
		}
			

		// Our Changes
		if (vpnName != null && !vpnName.equals("NONE")) {
			locationDbBean.setVpnName(vpnName);
			log.info("In side vpn != null");
			if (vpnName.equals(enterpriseId)) {
				log.info("vpn name and entid are same");
				if (getProductType() != "" && "7".equals(getProductType())
						&& getSbcAccessType() != ""
						&& "S".equals(getSbcAccessType())) {
					log.info("setting vpn name null");
					locationDbBean.setVpnName(null);
				}
			} else
				locationDbBean.setVpnName(vpnName);
		}

		if (hubGatewayDeviceId != -1)
			locationDbBean.setHubGatewayDeviceId(hubGatewayDeviceId);
		else
			locationDbBean.setHubGatewayDeviceIdNull();
		if (locationMask > -1)
			locationDbBean.setLocationMask(locationMask);
		else
			locationDbBean.setLocationMask(0);
		if (aNumMask > -1)
			locationDbBean.setANumMask(aNumMask);
		else
			locationDbBean.setANumMask(0);
		if (bNumMask > -1)
			locationDbBean.setBNumMask(bNumMask);
		else
			locationDbBean.setBNumMask(0);
		if (getQosInd() == -1)
			locationDbBean.setQosInd(0);
		else
			locationDbBean.setQosInd(qosInd);
		TblDialPlanQuery dialPlan = new TblDialPlanQuery();
		String whereCls = " where enterprise_id = \'" + enterpriseId + "\'";
		dialPlan.queryByWhere(dbCon, whereCls);
		if (dialPlan.size() > 0) {
			locationDbBean.setDialPlanId((dialPlan.getDbBean(0))
					.getDialPlanId());
			if (locRegion.equals("APAC")) {
				DialPlan dpObj = new DialPlan(dbCon);
				dpObj.setDialPlanId((dialPlan.getDbBean(0)).getDialPlanId());
				dpObj.setApacInd(1);
				if (locCountry.equals("AU"))
					dpObj.setLiInd(1);
				dpObj.modifyInDB();
			}
			TblSipDomainQuery sipDomainQry = new TblSipDomainQuery();
			sipDomainQry.whereDialPlanIdEQ((dialPlan.getDbBean(0))
					.getDialPlanId());
			sipDomainQry.query(dbCon);
			boolean sipDomainExists = false;
			for (int i = 0; i < sipDomainQry.size(); i++) {
				if (((sipDomainQry.getDbBean(i)).getDomainName())
						.equals(sipDomain)) {
					sipDomainExists = true;
					setLogTrail("SipDomain already added while adding enterprise."
							+ sipDomain);
					break;
				}
			}
			if (!sipDomainExists) {
				/*SipDomain sipDomainBean = new SipDomain(dbCon);
				sipDomainBean.setDialPlanId((dialPlan.getDbBean(0))
						.getDialPlanId());
				sipDomainBean.setDomainName(sipDomain);
				sipDomainBean.setEnvOrderId(getEnvOrderId());
				if (getModifiedBy() != null
						&& !("".equalsIgnoreCase(getModifiedBy()))) {
					sipDomainBean.setModifiedBy(getModifiedBy());
				} else {
					sipDomainBean.setModifiedBy("ESAP_INV");
				}
				if (getCreatedBy() != null
						&& !("".equalsIgnoreCase(getCreatedBy()))) {
					sipDomainBean.setCreatedBy(getCreatedBy());
				} else {
					sipDomainBean.setCreatedBy("ESAP_INV");
				}
				sipDomainBean.addSipDomain();
				setLogTrail("SipDomain added for Location." + sipDomain);*/
			}
		}
		if (getModifiedBy() != null && !("".equalsIgnoreCase(getModifiedBy()))) {
			locationDbBean.setModifiedBy(getModifiedBy());
		} else {
			locationDbBean.setModifiedBy("ESAP_INV");
		}
		if (getCreatedBy() != null && !("".equalsIgnoreCase(getCreatedBy()))) {
			locationDbBean.setCreatedBy(getCreatedBy());
		} else {
			locationDbBean.setCreatedBy("ESAP_INV");
		}
		if (rivLocation != VzbVoipEnum.YesNoType.N) {
			int callPlanId = 0;
			if (serviceTypeOffering == VzbVoipEnum.Platform.IASA) {
				callPlanId = 0;
			}
			if (serviceTypeOffering == VzbVoipEnum.Platform.ICP) {
				callPlanId = 1;
			}
			TblCallingPlansQuery callPlanQry = new TblCallingPlansQuery();
			callPlanQry.whereCallingPlanIdEQ(callPlanId);
			callPlanQry.query(dbCon);
			if (callPlanQry.size() > 0) {
				DBTblCallingPlans callingPlanDbBean = new DBTblCallingPlans();
				callingPlanDbBean.copyFromBean(callPlanQry.getDbBean(0));
				callPlanId = callingPlanDbBean
						.getCallingPlanIdSeqNextVal(dbCon);
				callingPlanDbBean.setDefaultInd(1);
				callingPlanDbBean.setCallingPlanId(callPlanId);
				if (getLocationName() != null && !getLocationName().equals("")) {
					String tmpCallingPlanName = getLocationName()
							+ "_Calling Plan";
					callingPlanDbBean.setCallingPlanName(tmpCallingPlanName);
				}

				if (getEnvOrderId() > 0)
					callingPlanDbBean.setEnvOrderId(getEnvOrderId());
				else
					callingPlanDbBean.setEnvOrderIdNull();
				if (getModifiedBy() != null
						&& !("".equalsIgnoreCase(getModifiedBy()))) {
					callingPlanDbBean.setModifiedBy(getModifiedBy());
				} else {
					callingPlanDbBean.setModifiedBy("ESAP_INV");
				}
				if (getCreatedBy() != null
						&& !("".equalsIgnoreCase(getCreatedBy()))) {
					callingPlanDbBean.setCreatedBy(getCreatedBy());
				} else {
					callingPlanDbBean.setCreatedBy("ESAP_INV");
				}
				// callingPlanDbBean.setCreationDate(new
				// Timestamp(System.currentTimeMillis()));
				callingPlanDbBean.setLastModifiedDate(new Timestamp(System
						.currentTimeMillis()));
				callingPlanDbBean.insert(dbCon);
			}
			locationDbBean.setCallingPlanId(callPlanId);
			setLogTrail("Callingplan mapped for Location.");
			DigitString digitStringObj = new DigitString(dbCon);
			if (digitStringObj.addDigitStringsForCallingPlanByEnterpriseId(
					callPlanId, getEnterpriseId(), getCreatedBy()))
				setLogTrail("digitStrings mapped for CallingPlan if any.");
			else {
				setLogTrail("Failed to map digitStrings for CallingPlan.");
				setStatus(InvErrorCode.ERROR_MAPPING_DIGITSTRINGS_TO_CALLINGPLAN);
				System.out
						.println("Failed to map digitStrings for CallingPlan.");
				return false;
			}
		}

		locationDbBean.setLastModifiedDate(new Timestamp(System
				.currentTimeMillis()));
		locationDbBean
				.setCreationDate(new Timestamp(System.currentTimeMillis()));
		// Added as new fileds got added in the tbl_location table
		// if(vpnName != null && !vpnName.equals("NONE"))
		// locationDbBean.setVpnName(vpnName);
		if (tblVpnIdMappingId > -1)
			locationDbBean.setTblVpnIdMappingId(tblVpnIdMappingId);
		if (sbcProvMethod > -1)
			locationDbBean.setSbcProvMethod(sbcProvMethod);
		//FkValidationUtil.isValidLocation(dbCon, locationDbBean);//kr DELETE ONCE TESTING
		TblLocationQuery locQry = new TblLocationQuery();
		locQry.whereLocationIdEQ(locationId);
		locQry.query(dbCon);

		if (locQry.size() > 0 && migration) {
			if (locQry.getDbBean(0).getRivLocation() == VzbVoipEnum.YesNoType.N) {
				locationDbBean.whereLocationIdEQ(locationId);
				locationDbBean.updateSpByWhere(dbCon);
			} else {
				setStatus(InvErrorCode.FOUND_LOCATION);
				return false;
			}
		} else {
			locationDbBean.insert(dbCon);
		}

		boolean soEnabled = false;
		long entTrunkcclsum = 0;
		TblEnterpriseQuery entQry = new TblEnterpriseQuery();
		entQry.whereEnterpriseIdEQ(enterpriseId);
		entQry.query(dbCon);
		if (entQry.size() > 0) {
			TblEnterpriseDbBean entBean = entQry.getDbBean(0);
			if (entBean.getSoEnabled() == 1) {
				soEnabled = true;
			}
			entTrunkcclsum = entBean.getEntTrunkCclSum();
		}
		if (rivLocation != VzbVoipEnum.YesNoType.N) {
			if (voipServiceType > 0) {
				int defaultPackageId = 0;
				int noOfPkgs = 3;
				long pkgId = 0;
				Enterprise enterprise = new Enterprise(dbCon);

				enterprise.setEnterpriseId(getEnterpriseId());
				enterprise.getDetails();
				String contractInd = enterprise.getContractInd();
				log.info("ContractInd = " + contractInd);

				if (serviceTypeOffering == VzbVoipEnum.Platform.IASA) {
					defaultPackageId = 0;
					noOfPkgs = 1;
				} else if (serviceTypeOffering == VzbVoipEnum.Platform.ICP) {
					if (voipServiceType == VzbVoipEnum.VoipServiceType.HIPC) {
						if ("C".equalsIgnoreCase(contractInd)) {
							defaultPackageId = 9; // For CALNET insert 9, 10, 11
							noOfPkgs = 3;
						} else {
							defaultPackageId = 2;
							// ICP-IU Decom --> For HIPC location, advanced
							// feature pkg (pkgId = 4) is no longer applicable.
							// Hence noOfPkgs reduced from 3 to 2.
							noOfPkgs = 2;
						}
					}
					if (voipServiceType == VzbVoipEnum.VoipServiceType.IP_INTEGRATED_ACCESS_PBX
							|| voipServiceType == VzbVoipEnum.VoipServiceType.IP_TRUNKING) {
						defaultPackageId = 5;
						noOfPkgs = 1;
					}
					if (voipServiceType == VzbVoipEnum.VoipServiceType.IP_INTEGRATED_ACCESS_KEY
							|| voipServiceType == VzbVoipEnum.VoipServiceType.IP_FLEXIBLE_T1) {
						defaultPackageId = 6;
						noOfPkgs = 1;
					}
					if (voipServiceType == VzbVoipEnum.VoipServiceType.IP_INTEGRATED_ACCESS_ET
							|| voipServiceType == VzbVoipEnum.VoipServiceType.IP_TRUNKING_ET) {
						defaultPackageId = 13;
						noOfPkgs = 1;
					}
				}
				log.info("Received Location Type ["
						+ getFmcgLocationType() + "]");
				if (getFmcgLocationType() != VzbVoipEnum.FmcgLocationType.FMCG_ONLY) {
					setLogTrail("Location default Feature Packagers mapped to Location.Number of packages:"
							+ noOfPkgs);
					if (!addDefaultFeaturePackage(defaultPackageId, noOfPkgs)) {
						return false;
					}
					// check if E2EI
					boolean e2eiCustomer = false;

					TblCustomerQuery qry = new TblCustomerQuery();
					qry.whereCustomerIdEQ(enterpriseId);
					qry.query(dbCon);
					if (qry.size() > 0) {
						TblCustomerDbBean bean = qry.getDbBean(0);
						if (bean.getOrderPlatform() == 3) {
							e2eiCustomer = true;
						}
					}
					// add E2EI_INTERMEDIATE
					if (e2eiCustomer && !soEnabled) {
						if (!addDefaultFeaturePackage(12 /* defaultPackageId */,
								1 /* noOfPkgs */)) {
							return false;
						}
					}
				}

				if (getFmcgLocationType() == VzbVoipEnum.FmcgLocationType.VOIP_FMCG
						&& (voipServiceType == VzbVoipEnum.VoipServiceType.IP_INTEGRATED_ACCESS_PBX || voipServiceType == VzbVoipEnum.VoipServiceType.IP_TRUNKING)) {
					// FMCG_PBX
					pkgId = 8;
					log.info("Adding FMCG_PBX");
					if (addLocPackage(pkgId) != true) {
						System.out
								.println("Failed to Add Loc Package. Package Id ["
										+ pkgId + "]");
					}
				}
				if (getFmcgLocationType() == VzbVoipEnum.FmcgLocationType.VOIP_FMCG
						|| getFmcgLocationType() == VzbVoipEnum.FmcgLocationType.FMCG_ONLY) {
					log.info("Adding FMCG");
					pkgId = 7;
					if (addLocPackage(pkgId) != true) {
						System.out
								.println("Failed to Add Loc Package. Package Id ["
										+ pkgId + "]");
					}
				}

				if (voipServiceType == VzbVoipEnum.VoipServiceType.HIPC
						&& (hybridServiceType == VzbVoipEnum.HybridServiceType.IP_INTEGRATED_ACCESS_PBX || hybridServiceType == VzbVoipEnum.HybridServiceType.IP_TRUNKING)) {
					log.info("Adding PBX pkg for hybrid location");
					pkgId = 5;
					if (addLocPackage(pkgId) != true) {
						System.out
								.println("Failed to Add Loc Package. Package Id ["
										+ pkgId + "]");
					}

					if (getFmcgLocationType() == VzbVoipEnum.FmcgLocationType.VOIP_FMCG) {
						pkgId = 8;
						log.info("Adding FMCG_PBX");
						if (addLocPackage(pkgId) != true) {
							System.out
									.println("Failed to Add Loc Package. Package Id ["
											+ pkgId + "]");
						}

					}

				}

				if (voipServiceType == VzbVoipEnum.VoipServiceType.HIPC
						&& hybridServiceType == VzbVoipEnum.HybridServiceType.IP_INTEGRATED_ACCESS_KEY) {
					log.info("Adding Key pkg for hybrid location");
					pkgId = 6;
					if (addLocPackage(pkgId) != true) {
						System.out
								.println("Failed to Add Loc Package. Package Id ["
										+ pkgId + "]");
					}

				}
			}// If voipServiceType > 0

			DBTblLocation locUpdateBean = new DBTblLocation();
			locUpdateBean.whereLocationIdEQ(locationId);
			boolean updateNeeded = false;
			if (rpidTn != null && !(rpidTn.trim()).equalsIgnoreCase("")
					&& !(rpidTn.trim()).equalsIgnoreCase("NONE")) {
				rpidPoolId = addToPublicPool(rpidTn,
						VzbVoipEnum.TnStatus.AVAILABLE, VzbVoipEnum.TnType.RES,
						VzbVoipEnum.YesNoType.N);
				if (rpidPoolId > 0) {
					locUpdateBean.setRpidPoolId(rpidPoolId);
					updateNeeded = true;
					setLogTrail("Added Calling Party Number to DB:" + rpidTn);
				} else {
					setLogTrail("Failed to Add Calling Party Number to DB:"
							+ rpidTn);
					log.info("Failed to Add RPID Tn");
					setStatus(InvErrorCode.FAILED_ADD_CALLING_PARTY);
					return false;
				}
			}
			
			if (billTn != null && !(billTn.trim()).equalsIgnoreCase("")
					&& !(billTn.trim()).equalsIgnoreCase("NONE")) {
				billTnPoolId = addToPublicPool(billTn,
						VzbVoipEnum.TnStatus.AVAILABLE, VzbVoipEnum.TnType.RES,
						VzbVoipEnum.YesNoType.N);
				if (billTnPoolId > 0) {
					locUpdateBean.setBtnPoolId(billTnPoolId);
					locUpdateBean.setEmerPoolId((int) billTnPoolId);
					updateNeeded = true;
					setLogTrail("Added  Billing Tn/EmergencyCallLine to DB:"
							+ billTn);
				} else {
					log.info("Failed to Add Bill Tn");
					setLogTrail("Failed to Add Billing Tn/EmergencyCallLine to DB:"
							+ billTn);
					setStatus(InvErrorCode.FAILED_ADD_BILL_TN);
					return false;
				}
			}
			// STN Code here
			log.info(" STN check " + sTn);
			if (sTn != null && !(sTn.trim()).equalsIgnoreCase("")
					&& !(sTn.trim()).equalsIgnoreCase("NONE")) {
				log.info(" STN ind " + VzbVoipEnum.YesNoType.Y);
				sTnPoolId = addToPublicPool(sTn,
						VzbVoipEnum.TnStatus.AVAILABLE, VzbVoipEnum.TnType.RES,
						VzbVoipEnum.YesNoType.Y);
				log.info("sTnPoolId: Creating new from DB "
						+ sTnPoolId);
				if (sTnPoolId > 0) {
					locUpdateBean.setStnPoolId(sTnPoolId);
					updateNeeded = true;
					setLogTrail("Added Screened TN to DB:" + sTn);
				} else {
					log.info("Failed to Add Screened TN");
					setLogTrail("Failed to Add Screened TN to  to DB:" + sTn);
					setStatus(InvErrorCode.FAILED_ADD_SCREENED_TN);
					return false;
				}

			}
			for (int i = 0; i < vmAccessList.size(); i++) {
				/*VmAccess vma = new VmAccess(vmAccessList.get(i), dbCon);
				if (vma.getPublicNumber() == null
						|| (vma.getPublicNumber().trim()).equalsIgnoreCase("")
						|| vma.getPublicNumber().equals("NONE")) {
					System.out
							.println("InvalidInput for VMA. Failed to Add VM Access Public Tn");
					setStatus(InvErrorCode.INVALID_INPUT);
					return false;
				}
				long poolId = addToPublicPool(vma.getPublicNumber(),
						VzbVoipEnum.TnStatus.ASSIGNED, VzbVoipEnum.TnType.VMA,
						VzbVoipEnum.YesNoType.N);
				if (poolId <= 0) {
					setLogTrail("Failed to Add Public tn pool entry for VM Access");
					log.info("Failed to Add VM Access Public Tn");
					setStatus(InvErrorCode.ERROR_ADDING_PUBLICTNPOOL_TO_VMA);
					return false;
				}
				vma.setPublicPoolId(poolId);*/
				/*if (getModifiedBy() != null
						&& !("".equalsIgnoreCase(getModifiedBy()))) {
					vma.setModifiedBy(getModifiedBy());
				} else {
					vma.setModifiedBy("ESAP_INV");
				}
				if (getCreatedBy() != null
						&& !("".equalsIgnoreCase(getCreatedBy()))) {
					vma.setCreatedBy(getCreatedBy());
				} else {
					vma.setCreatedBy("ESAP_INV");
				}
				vma.setEnvOrderId(getEnvOrderId());
				if (vma.addVmAccess() != true) {
					log.info("Failed to Add VM Access");
					setLogTrail("Failed to Add VM Access");
					setStatus(InvErrorCode.ERROR_ADDING_VMACCESS_TO_LOCATION);
					return false;*/
				//}
/*				setLogTrail("VMA Record added to DB.VMA:"
						+ vma.getPublicNumber());*/
			}
			for (int i = 0; i < authCodesList.size(); i++) {
				/*AcctAuthCodes authCode = new AcctAuthCodes(
						authCodesList.get(i), dbCon);*/
				//authCode.setEnvOrderId(getEnvOrderId());
/*				if (authCode.addToDB() != true) {
					log.info("Failed to Add Auth Codes");
					setStatus(InvErrorCode.ERROR_ADDING_ACCTAUTHCODES_TO_LOCATION);
					return false;
				}*/
			}
/*			if (!migration && addDefaultPrefixPlan() != true) {
				setStatus(InvErrorCode.ERROR_ADDING_DEFAULT_PREFIX_PLAN);
				return false;
			}*/
			if (getEmerLocationCode() != null
					&& !"NONE".equals(getEmerLocationCode())
					&& !"".equals(getEmerLocationCode())) {
				log.info("Update Location Emer Code ["
						+ getEmerLocationCode() + "]");
				updateNeeded = true;
				locUpdateBean.setEmerLocationCode(getEmerLocationCode());
			}

			if (updateNeeded) {
				FkValidationUtil.isValidLocationForMod(dbCon, locUpdateBean);
				locUpdateBean.updateSpByWhere(dbCon);
			}
			addLocationFeaturesToLocation();
		}// Happens only for Riv customers
		/*
		 * } catch (SQLException s) { s.printStackTrace();
		 * setStatus(InvErrorCode.DB_EXCEPTION);
		 * log.info("DB_FAILURE in addToDB Location " + s); return
		 * false; }
		 */

		// if(entBillFeatBeanList != null){
		if (entBillFeatBeanList.size() > 0) {
			for (int i = 0; i < entBillFeatBeanList.size(); i++) {
				TblEntBillFeaturesBean entBillFeatBean = entBillFeatBeanList
						.get(i);
				TblEntBillFeatures entBillFeat = new TblEntBillFeatures(dbCon);
				if (entBillFeatBean.getFeatureInstanceId() != null)
					entBillFeat.setFeatureInstanceId(entBillFeatBean
							.getFeatureInstanceId());
				if (entBillFeatBean.getEnterpriseId() != null)
					entBillFeat.setEnterpriseId(entBillFeatBean
							.getEnterpriseId());
				if (entBillFeatBean.getLocationId() != null)
					entBillFeat.setLocationId(entBillFeatBean.getLocationId());
				if (entBillFeatBean.getFeatureCode() != null)
					entBillFeat
							.setFeatureCode(entBillFeatBean.getFeatureCode());
				if (entBillFeatBean.getPbli() != null)
					entBillFeat.setPbli(entBillFeatBean.getPbli());
				if (entBillFeatBean.getChargeType() != null)
					entBillFeat.setChargeType(entBillFeatBean.getChargeType());
				if (entBillFeatBean.getChargeFrequency() != null)
					entBillFeat.setChargeFrequency(entBillFeatBean
							.getChargeFrequency());
				if (entBillFeatBean.getUnitOfMeasure() != null)
					entBillFeat.setUnitOfMeasure(entBillFeatBean
							.getUnitOfMeasure());
				if (entBillFeatBean.getBillTime() != null)
					entBillFeat.setBillTime(entBillFeatBean.getBillTime());
				if (entBillFeatBean.getCatalogueReferenceTime() != null)
					entBillFeat.setCatalogueReferenceTime(entBillFeatBean.getCatalogueReferenceTime());
				if (entBillFeatBean.getFeatureType() != 0)
					entBillFeat.setFeatureType(entBillFeatBean.getFeatureType());
				if (entBillFeat.addToDB()) {
					setLogTrail("TblEntBillFeature Record added to DB");
				} else {
					setLogTrail("Failed to add Record to TblEntBillFeatures");
					return false;
				}
			}
		}

		if (soEnabled && getMaxConcurrentOffnet() > 0) {
			long locCclSum = getMaxConcurrentOffnet() > getMaxConcurrentCalls() ? getMaxConcurrentOffnet()
					: getMaxConcurrentCalls();
			updateEntAndLocCcl(getEnterpriseId(), getLocationId(),
					entTrunkcclsum + locCclSum, locCclSum);
		}

		setStatus(InvErrorCode.SUCCESS);
		return true;
	}

	public String getConfigParamValue(String processName, String paramName)
			throws SQLException {
		String paramValue = "";

		TblConfigParamsQuery paramsQ = new TblConfigParamsQuery();
		if (processName != null)
			paramsQ.whereProcessNameEQ(processName);
		if (paramName != null)
			paramsQ.whereParamNameEQ(paramName);
		paramsQ.query(dbCon);

		if (paramsQ.size() <= 0) {
			log.info("No Config Entry Found by ProcessName ["
					+ processName + "] and ParamName [" + paramName + "]");
			return paramValue;
		}

		TblConfigParamsDbBean cpBean = paramsQ.getDbBean(0);
		paramValue = cpBean.getParamValue();
		log.info("Successfully Retrieved Param Value [" + paramValue
				+ "]");
		return paramValue;
	}

	public boolean isAPAC() throws SQLException, Exception {
		log.info("Entering isAPAC");
		String cParam = getConfigParamValue("RIV_INV", "APAC_COUNTRIES");
		if (cParam == null || (cParam != null && "".equals(cParam))) {
			System.out
					.println("Missing Config Param for APAC Countries - Skip Adding Default Prefix Plan");
			return false;
		}
		if (cParam.indexOf(getLocCountry()) <= 0) {
			System.out
					.println("Not APAC Location. Skip Adding Default Prefix Plan");
			return false;
		}
		log.info("Location in APAC");
		return true;
	}

	public boolean deletePrefixPlanForAPAC() throws SQLException, Exception {
		log.info("Entering deletePrefixPlanForAPAC");

		if (isAPAC() != true)
			return true;

		TblVzbPrefixPlanQuery vppQry = new TblVzbPrefixPlanQuery();
		vppQry.whereLocationIdEQ(getLocationId());
		vppQry.query(dbCon);
		if (vppQry.size() <= 0) {
			log.info("Prefix Plan for Location Id ["
					+ getLocationId() + "] Not Found");
			return false;
		}
		log.info("Retrieved Prefix Plan Id ["
				+ vppQry.getDbBean(0).getPrefixPlanId() + "]");

/*		PPRules ppru = new PPRules(dbCon);
		ppru.setPrefixPlanId(vppQry.getDbBean(0).getPrefixPlanId());
		if (ppru.deletePPRules() != true) {
			log.info("Failed to Delete Prefix Rules In Location");
			return false;
		}

		PPRange ppra = new PPRange(dbCon);
		ppra.setPrefixPlanId(vppQry.getDbBean(0).getPrefixPlanId());
		if (ppra.deletePPRange() != true) {
			log.info("Failed to Delete Prefix Range In Location");
			return false;
		}

		VzbPrefixPlan vpp = new VzbPrefixPlan(dbCon);
		vpp.setPrefixPlanId(vppQry.getDbBean(0).getPrefixPlanId());
		if (vpp.deleteVzbPrefixPlan() != true) {
			log.info("Failed to Delete Prefix Plan In Location");
			return false;
		}*/

		System.out
				.println("Successfully Deleted Prefix Plan, Rules & Ranges for APAC Location");
		return true;
	}

/*	public boolean addDefaultPrefixPlan() throws SQLException, Exception {
		log.info("Entering addDefaultPrefixPlan");

		if (isAPAC() != true)
			return true;

		PrefixPlanTplt ppt = new PrefixPlanTplt(dbCon);
		ppt.setCountryCode(getLocCountry());
		if (ppt.getPrefixPlanTpltByCountryCode() != true) {
			System.out
					.println("Failed to retrieve Default Prefix Plan by Countr ["
							+ getLocCountry() + "]");
			return false;
		}

		VzbPrefixPlan vpp = new VzbPrefixPlan(dbCon);
		if (getDefaultPpId() > 0)
			vpp.setPrefixPlanId(getDefaultPpId());
		vpp.setLocationId(getLocationId());
		vpp.setCustomerId(getEnterpriseId());
		vpp.setPrefixName(ppt.getPrefixName());
		vpp.setMobile(ppt.getMobile());

		if (vpp.addVzbPrefixPlan() != true) {
			log.info("Failed to Add Prefix Plan For Location Id ["
					+ getLocationId() + "]");
			return false;
		}
		log.info("Successfully Added Default Prefix Plan");

		VzbPprangeTplt vpt = new VzbPprangeTplt(dbCon);
		vpt.setCntryCode(getLocCountry());
		vpt.setPlatformIndicator((short) VzbVoipEnum.Platform.ICP);
		if (vpt.getVzbPprTpltListByCntryCdAndPltfrmInd() != true) {
			System.out
					.println("Failed to retrieve Default Prefix Plan Range Template by Countr ["
							+ getLocCountry() + "]");
			return false;
		}

		// IR #1659601 APAC add location order is failing in prod as
		// tbl_vzb_pprange_tplt is empty in production for APAC
		// if(vpt.getVzbPprangeTpltBeanList() == null)
		// {
		// log.info("Failed to retrieve Default Prefix Plan Range by Countr ["
		// + getLocCountry() + "]");
		// return false;
		// }

		if (vpt.getVzbPprangeTpltBeanList() != null) {
			List<VzbPprangeTpltBean> vptList = vpt.getVzbPprangeTpltBeanList();
			log.info("Retrieved [" + vptList.size()
					+ "] PP Range for Country [" + getLocCountry() + "]");
			for (int i = 0; i < vptList.size(); i++) {
				PPRange ppr = new PPRange(dbCon);
				ppr.setPrefixPlanId(vpp.getPrefixPlanId());
				ppr.setRangeStart(vptList.get(i).getRangeStart());
				ppr.setRangeEnd(vptList.get(i).getRangeEnd());
				ppr.setNumstrip(vptList.get(i).getNumstrip());
				ppr.setAddPrefix(vptList.get(i).getAddPrefix());
				ppr.setNoa(vptList.get(i).getNoa());
				ppr.setBlkstat(vptList.get(i).getBlkstat());

				if (ppr.addPPRange() != true) {
					System.out
							.println("Failed to Add Prefix Plan Range For Location Id ["
									+ getLocationId() + "]");
					return false;
				}
			}
		} else {
			System.out
					.println("No record found in tbl_vzb_pprange_tplt table.");
		}

		VzbPprulesTplt vptr = new VzbPprulesTplt(dbCon);
		vptr.setCntryCode(getLocCountry());
		vptr.setPlatformIndicator((short) VzbVoipEnum.Platform.ICP);
		if (vptr.getVzbPprTpltListByCntryCdAndPltfrmInd() != true) {
			System.out
					.println("Failed to retrieve Default Prefix Plan Rules Template by Countr ["
							+ getLocCountry() + "]");
			return false;
		}
		if (vptr.getVzbPprulesTpltBeanList() == null) {
			System.out
					.println("Failed to retrieve Default Prefix Plan Rules by Countr ["
							+ getLocCountry() + "]");
			return false;
		}
		List<VzbPprulesTpltBean> vptrList = vptr.getVzbPprulesTpltBeanList();
		log.info("Retrieved [" + vptrList.size()
				+ "] PP Rules for Country [" + getLocCountry() + "]");
		for (int i = 0; i < vptrList.size(); i++) {
			PPRules ppr = new PPRules(dbCon);
			ppr.setPrefixPlanId(vpp.getPrefixPlanId());
			ppr.setPrefix(vptrList.get(i).getPrefix());
			ppr.setNumstrip(vptrList.get(i).getNumstrip());
			ppr.setAddPrefix(vptrList.get(i).getAddPrefix());
			ppr.setNoa(vptrList.get(i).getNoa());
			ppr.setBlkstat(vptrList.get(i).getBlkstat());

			if (ppr.addPPRules() != true) {
				System.out
						.println("Failed to Add Prefix Plan Rules For Location Id ["
								+ getLocationId() + "]");
				return false;
			}
		}

		TblVzbEmerCodeQuery eQry = new TblVzbEmerCodeQuery();
		eQry.whereCntryCodeEQ(getLocCountry());
		// eQry.whereTerritoryEQ(getLocTerritory());
		eQry.query(dbCon);

		if (eQry.size() <= 0) {
			log.info("No Emer Code Found by Country Code ["
					+ getLocCountry() + "] And Region [" + getLocTerritory()
					+ "]");
			// return false;
		}

		for (int i = 0; i < eQry.size(); i++) {
			if (!getLocTerritory().equalsIgnoreCase(
					eQry.getDbBean(i).getTerritory()))
				continue;
			setEmerLocationCode(Long.toString(eQry.getDbBean(i)
					.getEmerLocCodeId()));
			PPRules ppr = new PPRules(dbCon);
			ppr.setPrefixPlanId(vpp.getPrefixPlanId());
			ppr.setPrefix(eQry.getDbBean(i).getPrefixDigits());
			ppr.setNumstrip(eQry.getDbBean(i).getNumstrip());
			ppr.setAddPrefix(eQry.getDbBean(i).getAddPrefix());
			ppr.setNoa(1);
			ppr.setBlkstat(3);

			// if pprules already exists for prefixdigits, update existing
			// records
			if (doesPPRulesExist(vpp.getPrefixPlanId(), eQry.getDbBean(i)
					.getPrefixDigits())) {
				System.out
						.println("Prefix Plan by Emer Code Already Exists. Update PPRules");
				if (ppr.updatePPRules() != true) {
					System.out
							.println("Failed to Update Prefix Plan Rules By Emer Code For Location Id ["
									+ getLocationId() + "]");
					return false;
				}
			} else if (ppr.addPPRules() != true) {
				System.out
						.println("Failed to Add Prefix Plan Rules By Emer Code For Location Id ["
								+ getLocationId() + "]");
				return false;
			}
		}

		System.out
				.println("Successfully Added Default Prefix Plan Range & Rules Template ");
		return true;
	}*/

	private boolean doesPPRulesExist(long prefixPlanId, String prefixDigits)
			throws SQLException, Exception {
		log.info("Entering doesPPRulesExist");
		//PPRules pprQry = new PPRules(dbCon);
/*		pprQry.setPrefixPlanId(prefixPlanId);
		pprQry.setPrefix(prefixDigits);
		if (pprQry.getPPRulesDetails() != true) {
			log.info("Prefix Plan Rules Not Found");
			return false;
		}*/
		log.info("Prefix Plan Rules Found");
		return true;
	}

	public boolean addRivLocation() throws VzbInvFkException {
		DBTblLocation locationDbBean = new DBTblLocation();
		log.info("Adding addRivLocation to Inventory");

		try {
			locationDbBean.setLocationId(locationId);
			locationDbBean.setEnterpriseId(enterpriseId);
			if (orderSource != null && !orderSource.equals("NONE"))
				locationDbBean.setOrderSource(orderSource);
			if (locationName != null && !locationName.equals("NONE"))
				locationDbBean.setLocationName(locationName.trim());
			if (locAddress != null && !locAddress.equals("NONE"))
				locationDbBean.setLocAddress(locAddress);
			if (locCity != null && !locCity.equals("NONE"))
				locationDbBean.setLocCity(locCity);
			if (locState != null && !locState.equals("NONE"))
				locationDbBean.setLocState(locState);
			if (locZip != null && !locZip.equals("NONE"))
				locationDbBean.setLocZip(locZip);
			if (locCountry != null && !locCountry.equals("NONE"))
				locationDbBean.setLocCountry(locCountry);
			if (npaNxx != null && !npaNxx.equals("NONE"))
				locationDbBean.setNpanxx(npaNxx);
			if (timeZone != null && !timeZone.equalsIgnoreCase("")
					&& !timeZone.equalsIgnoreCase("NONE"))
				locationDbBean.setTimeZone(Integer.parseInt(timeZone));
			if (useDaylightSaving == -1)
				locationDbBean.setUseDaylightSavings(0);
			else
				locationDbBean.setUseDaylightSavings(useDaylightSaving);
			if (afterHoursInstallFlag > -1) {
				locationDbBean.setAfterHoursInstallFlag(afterHoursInstallFlag);
			}
			if (highVolumeInstallFlag > -1) {
				locationDbBean.setHighVolumeInstallFlag(highVolumeInstallFlag);
			}
			if (expedite > -1) {
				locationDbBean.setExpedite(expedite);
			}

			if (locCclInd > -1) {
				locationDbBean.setLocCclInd((short) locCclInd);
			} else {
				locationDbBean.setLocCclInd((short) VzbVoipEnum.YesNoType.N);
			}

			log.info(" locationDbBean.getLocCclInd "
					+ locationDbBean.getLocCclInd());

			if (billingActivated > -1) {
				locationDbBean.setBillingActivated((short) billingActivated);
			} else {
				locationDbBean
						.setBillingActivated((short) VzbVoipEnum.YesNoType.N);
			}
			log.info(" locationDbBean.getBillingActivated() "
					+ locationDbBean.getBillingActivated());

			if (configAllowed > -1)
				locationDbBean.setConfigAllowed((short) configAllowed);

			if (!productIdentifier.equals(""))
				locationDbBean.setProductIdentifier(productIdentifier);

			if (callingNameInd > -1) {
				locationDbBean.setCallingNameInd(callingNameInd);
			} else {
				locationDbBean.setCallingNameInd(VzbVoipEnum.YesNoType.N);
			}

			log.info(" locationDbBean.getCallingNameInd() "
					+ locationDbBean.getCallingNameInd());

			if (e911Service > -1) {
				locationDbBean.setE911Service((short) e911Service);
			} else {
				locationDbBean.setE911Service((short) VzbVoipEnum.YesNoType.N);
			}

			if (enhancedAniInd > -1) {
				locationDbBean.setEnhancedAniInd(enhancedAniInd);
			} else {
				locationDbBean.setEnhancedAniInd(VzbVoipEnum.YesNoType.N);
			}
			log.info(" locationDbBean.getEnhancedAniInd() "
					+ locationDbBean.getEnhancedAniInd());

			// Jan 2011 Release changes
			if (billAccountNumber != null
					&& !billAccountNumber.equalsIgnoreCase("")
					&& !billAccountNumber.equalsIgnoreCase("NONE")) {
				locationDbBean.setBillAcctNum(billAccountNumber);
			}
			log.info(" locationDbBean.getBillAcctNum() "
					+ locationDbBean.getBillAcctNum());

			if (locTerritory != null && !locTerritory.equalsIgnoreCase("")
					&& !locTerritory.equalsIgnoreCase("NONE")) {
				locationDbBean.setLocTerritory(locTerritory);
			}
			log.info(" locationDbBean.getLocTerritory() "
					+ locationDbBean.getLocTerritory());

			if (locRegion != null && !locRegion.equalsIgnoreCase("")
					&& !locRegion.equalsIgnoreCase("NONE")) {
				locationDbBean.setLocRegion(locRegion);
			}
			// 53938.AA Business Continuity Ph 1 - changes for july 2011
			if (varrsFlag != null && !varrsFlag.equalsIgnoreCase("")) {
				locationDbBean.setVarrsFlag(varrsFlag);
			}
			if (subAgencyHierCode != null && !subAgencyHierCode.equals("NONE"))
				locationDbBean.setSubAgencyHierCode(subAgencyHierCode);

			/*
			 * if (isrDesignId > -1 ){
			 * locationDbBean.setIsrDesignId(isrDesignId); }
			 */

			log.info(" locationDbBean.getLocRegion() "
					+ locationDbBean.getLocRegion());

			if (billingSystem > -1) {
				locationDbBean.setBillingSystem(billingSystem);
			}

			log.info(" locationDbBean.getBillingSystem() "
					+ locationDbBean.getBillingSystem());

			if (dayLightSavingsRegion != null
					&& !dayLightSavingsRegion.equalsIgnoreCase("")
					&& !dayLightSavingsRegion.equalsIgnoreCase("NONE"))
				locationDbBean.setDaylightSavingsRegion(Long
						.parseLong(dayLightSavingsRegion));
			if (webLang == -1)
				locationDbBean.setWebLang(VzbVoipEnum.Language.NO_PREFERENCE);
			else
				locationDbBean.setWebLang(webLang);

			if (enterpriseTrunkId > 0)
				locationDbBean.setEnterpriseTrunkId(enterpriseTrunkId);
			if (tsoMigLock > -1)
				locationDbBean.setTsoMigLock(tsoMigLock);
			if (pqInstanceId > 0)
				locationDbBean.setPqInstanceId(pqInstanceId);
			if (uiProvFlag != -1)
				locationDbBean.setUiProvFlag((short) uiProvFlag);

			if (isrDesignId > 0)
				locationDbBean.setIsrDesignId(isrDesignId);
			locationDbBean.setAccessType(accessType);
			locationDbBean.setSbcMigInd(1);
			if (ixPlusId > -1)
				locationDbBean.setIxplusId(ixPlusId);
			else
				locationDbBean.setIxplusId(0);
			if (ixPlusEnvId != null && !ixPlusEnvId.equals("NONE"))
				locationDbBean.setIxplusEnvId(ixPlusEnvId);
			if (billType > -1)
				locationDbBean.setBillType(billType);
			else
				locationDbBean.setBillType(0);

			if (netcomServiceId != null && !"NONE".equals(netcomServiceId)) {
				locationDbBean.setNetcomServiceId(netcomServiceId);
			}
			if (cv2Service > -1)
				locationDbBean.setCv2Service(cv2Service);
			else
				locationDbBean.setCv2Service(0);
			if (locationDbBean.getManagedService() > -1) {
				locationDbBean.setManagedService(managedService);
			} else
				locationDbBean.setManagedService(0);
			if (serviceTypeOffering > -1)
				locationDbBean.setServiceTypeOffering(serviceTypeOffering);
			else
				locationDbBean.setServiceTypeOffering(0);
			if (hybridServiceType > -1)
				locationDbBean.setHybridServiceType(hybridServiceType);
			else
				locationDbBean.setHybridServiceType(0);
			if (voipServiceType > -1)
				locationDbBean.setVoipServiceType(voipServiceType);
			else
				locationDbBean.setVoipServiceType(0);
			if (pubIp > -1)
				locationDbBean.setPubIp(pubIp);
			else
				locationDbBean.setPubIp(0);

			if (accessType > -1)
				locationDbBean.setAccessType(accessType);

			if (circuitId != null && !circuitId.equals("NONE"))
				locationDbBean.setCircuitId(circuitId);
			if (uunetSiteId != null && !uunetSiteId.equals("NONE"))
				locationDbBean.setUunetSiteId(uunetSiteId);
			log.info("Trunk Value is =====> " + trunk);
			if (trunk != null && !"NONE".equals(trunk) && !"".equals(trunk))
				locationDbBean.setTrunk(trunk);

			if (sbcInd == -1)
				locationDbBean.setSbcInd(0);
			else
				locationDbBean.setSbcInd(sbcInd);
			if (sipEnabled == 1)
				locationDbBean.setSipEnabled(sipEnabled);

			if (sbcId > 0)
				locationDbBean.setSbcId(sbcId);
			else
				locationDbBean.setSbcIdNull();
			if (sbcProvMethod > 0)
				locationDbBean.setSbcProvMethod(sbcProvMethod);
			else
				locationDbBean.setSbcProvMethod(0); // -1 0r 0 := Unknown

			log.info("EnvOrderId = <" + getEnvOrderId() + ">");
			if (getEnvOrderId() > 0)
				locationDbBean.setEnvOrderId(getEnvOrderId());
			else
				locationDbBean.setEnvOrderIdNull();
			if (getPublicGtwyDpid() == -1)
				locationDbBean.setPublicGtwyDpid(0);
			else
				locationDbBean.setPublicGtwyDpid(publicGtwyDpid);
			if (sipDomain != null && !sipDomain.equals("NONE")) {
				locationDbBean.setSipDomain(sipDomain);
				TblEnterpriseQuery entQry = new TblEnterpriseQuery();
				entQry.whereEnterpriseIdEQ(enterpriseId);
				entQry.query(dbCon);
				if (entQry.size() > 0) {
					if (entQry.getDbBean(0).getSipDomain() == null
							|| entQry.getDbBean(0).getSipDomain()
									.equalsIgnoreCase("")) {
						DBTblEnterprise entObj = new DBTblEnterprise();
						entObj.setSipDomain(sipDomain);
						entObj.whereEnterpriseIdEQ(enterpriseId);
						entObj.updateSpByWhere(dbCon);
					}
				}
			}
			if (getDefaultGtwyDpid() == -1)
				locationDbBean.setDefaultGtwyDpid(0);
			else
				locationDbBean.setDefaultGtwyDpid(defaultGtwyDpid);

			log.info("Trunk Type Value is =====> " + getTrunkType());
			if (migration && getTrunkType() != -1)
				locationDbBean.setTrunkType(getTrunkType());
			else
				locationDbBean.setTrunkType(VzbVoipEnum.TrunkType.US_SHARED);
			if (voipClub > -1)
				locationDbBean.setVoipClub(voipClub);
			if (voipClub == VzbVoipEnum.YesNoType.Y) {
				locationDbBean.setPubIp(voipClub);
			} else {
				locationDbBean.setPubIp(pubIp);
			}
			if (locationDbBean.getVoipClub() == -1)
				locationDbBean.setVoipClub(0);
			if (locationDbBean.getPubIp() == -1)
				locationDbBean.setPubIp(0);

			if (serviceLevel > -1)
				locationDbBean.setServiceLevel(serviceLevel);
			else
				locationDbBean.setServiceLevel(0);
			if (locMarket > -1)
				locationDbBean.setLocMarket(locMarket);
			else
				locationDbBean.setLocMarket(0);
			if (maxExtLength > -1)
				locationDbBean.setMaxExtLength(maxExtLength);
			else
				locationDbBean.setMaxExtLength(0);
			if (extLength > -1)
				locationDbBean.setExtLength(extLength);
			else
				locationDbBean.setExtLength(0);
			if (privateNumLength > -1)
				locationDbBean.setPrivateNumLength(privateNumLength);
			else
				locationDbBean.setPrivateNumLength(0);
			if (linePortLength > -1)
				locationDbBean.setLinePortLength(linePortLength);
			else
				locationDbBean.setLinePortLength(0);
			if (clin != null && !clin.equals("NONE"))
				locationDbBean.setClin(clin);
			if (abbrDialingCode != null && !abbrDialingCode.equals("NONE"))
				locationDbBean.setAbbrDialingCode(abbrDialingCode);
			if (enableCallPark > -1)
				locationDbBean.setEnableCallPark(enableCallPark);
			else
				locationDbBean.setEnableCallPark(0);
			if (overrideCidNum != -1)
				locationDbBean.setOverrideCidNum(overrideCidNum);
			else
				locationDbBean.setOverrideCidNum(0);
			if (overrideCidName != -1)
				locationDbBean.setOverrideCidName(overrideCidName);
			else
				locationDbBean.setOverrideCidName(0);
			if (overrideSubPrivate != -1)
				locationDbBean.setOverrideSubPrivate(overrideSubPrivate);
			else
				locationDbBean.setOverrideSubPrivate(0);
			if (enableAccountCode != -1)
				locationDbBean.setEnableAccountCode(enableAccountCode);
			else
				locationDbBean.setEnableAccountCode(0);
			if (enableAuthCode != null && !enableAuthCode.equals("NONE"))
				locationDbBean.setEnableAuthCode(enableAuthCode);
			locationDbBean.setLocalDirAssistance(Integer.toString(0));
			locationDbBean.setNatDirAssistance(Integer.toString(2));
			if (concCallStat > -1)
				locationDbBean.setConccallStat(concCallStat);
			else
				locationDbBean.setConccallStat(0);
			if (maxConcurrentCalls > -1)
				locationDbBean.setMaxConcurrentCalls(maxConcurrentCalls);
			else
				locationDbBean.setMaxConcurrentCalls(0);
			if (maxConcurrentOffnet > -1)
				locationDbBean.setMaxConcurrentOffnet(maxConcurrentOffnet);
			else
				locationDbBean.setMaxConcurrentOffnet(0);
			if (maxInbound > -1)
				locationDbBean.setMaxInbound(maxInbound);
			else
				locationDbBean.setMaxInbound(0);
			if (maxSlg > -1)
				locationDbBean.setMaxSlg(maxSlg);
			else
				locationDbBean.setMaxSlg(0);
			if (maxNg > -1)
				locationDbBean.setMaxNg(maxNg);
			else
				locationDbBean.setMaxNg(0);
			if (maxSubscribers > -1)
				locationDbBean.setMaxSubscribers(maxSubscribers);
			else
				locationDbBean.setMaxSubscribers(0);
			if (maxPublicTn > -1)
				locationDbBean.setMaxPublicTn(maxPublicTn);
			else
				locationDbBean.setMaxPublicTn(0);
			if (blockAllCalls > -1)
				locationDbBean.setBlockAllCalls(blockAllCalls);
			else
				locationDbBean.setBlockAllCalls(0);
			if (rpid != null && !rpid.equals("NONE"))
				locationDbBean.setRpid(rpid);
			if (pendingRpid != null && !pendingRpid.equals("NONE"))
				locationDbBean.setPendingRpid(pendingRpid);
			if (rpidPriv != -1)
				locationDbBean.setRpidPriv(rpidPriv);
			else
				locationDbBean.setRpidPriv(1);
			if (hicrService > -1)
				locationDbBean.setHicrService(hicrService);
			else
				locationDbBean.setHicrService(0);
			if (vmLang == -1)
				locationDbBean.setVmLang(0);
			else
				locationDbBean.setVmLang(vmLang);
			if (maxVmBox > -1)
				locationDbBean.setMaxVmBox(maxVmBox);
			else
				locationDbBean.setMaxVmBox(0);
			if (activeInd > -1)
				locationDbBean.setActiveInd(activeInd);
			if (productionIndicator == -1)
				locationDbBean.setProductionIndicator(1);
			else
				locationDbBean.setProductionIndicator(productionIndicator);
			if (vmType > 0)
				locationDbBean.setVmType(vmType);
			else
				locationDbBean.setVmType(VzbVoipEnum.LocationVmType.HOSTED);

			if (switchClli != null && !switchClli.equals("NONE"))
				locationDbBean.setSwitchClli(switchClli);
			if (vmCpeIpAddress != null && !vmCpeIpAddress.equals("NONE"))
				locationDbBean.setVmCpeIpAddress(vmCpeIpAddress);
			if (contactPhone != null && !contactPhone.equals("NONE"))
				locationDbBean.setContactPhone(contactPhone);
			if (contactName != null && !contactName.equals("NONE"))
				locationDbBean.setContactName(contactName);
			if (contactEmail != null && !contactEmail.equals("NONE"))
				locationDbBean.setContactEmail(contactEmail);
			if (actTeamPhone != null && !actTeamPhone.equals("NONE"))
				locationDbBean.setActTeamPhone(actTeamPhone);
			if (actTeamName != null && !actTeamName.equals("NONE"))
				locationDbBean.setActTeamName(actTeamName);
			if (actTeamEmail != null && !actTeamEmail.equals("NONE"))
				locationDbBean.setActTeamEmail(actTeamEmail);
			if (emerPoolId > 0)
				locationDbBean.setEmerPoolId(emerPoolId);
			if (emerLocationCode != null && !emerLocationCode.equals("NONE"))
				locationDbBean.setEmerLocationCode(emerLocationCode);
			log.info("Received Location Type [" + locationType + "]");
			if (locationType > -1)
				locationDbBean.setLocationType(locationType);
			else
				locationDbBean
						.setLocationType(VzbVoipEnum.LocationType.STANDARD);
			if (fmcgLocationType == -1)
				locationDbBean
						.setFmcgLocationType(VzbVoipEnum.FmcgLocationType.NONE);
			else
				locationDbBean.setFmcgLocationType(fmcgLocationType);
			if (hubLocationId != null && !hubLocationId.equals("NONE")
					&& !hubLocationId.equals("")) {
				if (locationType != VzbVoipEnum.LocationType.HUB
						&& locationId != hubLocationId) {
					locationDbBean.setHubLocationId(hubLocationId);
				} else
					System.out
							.println("HubLocationId and LocationId cannot be the same");
			}
			if (hubGatewayDeviceId != -1)
				locationDbBean.setHubGatewayDeviceId(hubGatewayDeviceId);
			else
				locationDbBean.setHubGatewayDeviceIdNull();
			if (locationMask > -1)
				locationDbBean.setLocationMask(locationMask);
			else
				locationDbBean.setLocationMask(0);
			if (aNumMask > -1)
				locationDbBean.setANumMask(aNumMask);
			else
				locationDbBean.setANumMask(0);
			if (bNumMask > -1)
				locationDbBean.setBNumMask(bNumMask);
			else
				locationDbBean.setBNumMask(0);
			if (getQosInd() == -1)
				locationDbBean.setQosInd(0);
			else
				locationDbBean.setQosInd(qosInd);
			if (getModifiedBy() != null
					&& !("".equalsIgnoreCase(getModifiedBy()))) {
				locationDbBean.setModifiedBy(getModifiedBy());
			} else {
				locationDbBean.setModifiedBy("SBC_MIG");
			}
			locationDbBean.setLastModifiedDate(new Timestamp(System
					.currentTimeMillis()));

			if (rivLocation > -1)
				locationDbBean.setRivLocation(rivLocation);
			else
				locationDbBean.setRivLocation(VzbVoipEnum.YesNoType.N);

			// STN Code here
			log.info(" STN check " + sTn);
			if (sTn != null && !(sTn.trim()).equalsIgnoreCase("")
					&& !(sTn.trim()).equalsIgnoreCase("NONE")) {
				log.info(" STN ind " + VzbVoipEnum.YesNoType.Y);
				sTnPoolId = addToPublicPool(sTn,
						VzbVoipEnum.TnStatus.AVAILABLE, VzbVoipEnum.TnType.RES,
						VzbVoipEnum.YesNoType.Y);
				log.info("sTnPoolId: Creating new from DB "
						+ sTnPoolId);
				if (sTnPoolId > 0) {
					locationDbBean.setStnPoolId(sTnPoolId);
					// updateNeeded = true;
					setLogTrail("Added Screened TN in addRivLocation to DB:"
							+ sTn);
				} else {
					System.out
							.println("Failed to Add Screened TN in addRivLocation");
					setLogTrail("Failed to Add Screened TN in addRivLocation to DB:"
							+ sTn);
					setStatus(InvErrorCode.FAILED_ADD_SCREENED_TN);
					return false;
				}

			}

			TblLocationQuery locQry = new TblLocationQuery();
			locQry.whereLocationIdEQ(locationId);
			locQry.query(dbCon);
			log.info("locQry.size()====>" + locQry.size());
			if (locQry.size() > 0) {
				log.info("locQry.getDbBean(0).getRivLocation()====>"
						+ locQry.getDbBean(0).getRivLocation());
				DBTblLocation locUpdObj = new DBTblLocation();
				/*
				 * SBC PROV if TOD is sbcProvMethod == ESAP - then anyway set it
				 * if TOD is sbcProvMethod == IASA && ESAP has NO entry - then
				 * set it if TOD is sbcProvMethod == IASA && ESAP already has
				 * entry - then do not touch it
				 */

				if (sbcProvMethod == VzbVoipEnum.SbcProvMethodType.IASA
						&& locQry.size() > 0) {
					// if TOD is sbcProvMethod == IASA && ESAP already has entry
					// - then do not touch it
					locationDbBean.setSbcProvMethod(locQry.getDbBean(0)
							.getSbcProvMethod());
					locUpdObj.setSbcProvMethod(locQry.getDbBean(0)
							.getSbcProvMethod()); // update with old value =>do
													// no touch
				} else if (sbcProvMethod == VzbVoipEnum.SbcProvMethodType.ESAP
						&& locQry.size() > 0) {
					// if TOD id sbcProvMethod == ESAP && ESAP already has entry
					// - then set it as ESAP
					locationDbBean.setSbcProvMethod(sbcProvMethod); // update
																	// with TOD
																	// Value
					locUpdObj
							.setSbcProvMethod(VzbVoipEnum.SbcProvMethodType.ESAP);
				}

				/*
				 * SBC IND if IASA/TOD has SBC_IND == 1 and ESAP has no entry -
				 * then set set the SBC IND if IASA/TOD has SBC IND = 0 && ESAP
				 * has no entry - then set it if IASA/TOD has SBC IND = 0 &&
				 * ESAP has entry with SBC IND = 1 - then do not touch it if
				 * IASA/TOD has SBC IND = 1 && ESAP has entry with or without
				 * SBC_IND = o OR 1 - set it to 1
				 */

				// if IASA/TOD has SBC IND = 0 && ESAP has entry with SBC IND =
				// 1 - then do not touch it
				// if IASA/TOD has SBC IND = 1 && ESAP has entry with or without
				// SBC_IND = o OR 1 - set it to 1
				if (locationDbBean.getSbcInd() == 0
						&& locQry.getDbBean(0).getSbcInd() == 1) {
					locationDbBean.setSbcInd(locQry.getDbBean(0).getSbcInd());
					locUpdObj.setSbcInd(locQry.getDbBean(0).getSbcInd()); // update
																			// with
																			// old
																			// value
																			// =>do
																			// no
																			// touch
				} else if (locationDbBean.getSbcInd() == 1 && locQry.size() > 0) {
					locationDbBean.setSbcInd(1);
					locUpdObj.setSbcInd(1);
				}

				if (locQry.getDbBean(0).getRivLocation() == VzbVoipEnum.YesNoType.N) {
					locationDbBean.whereLocationIdEQ(locationId);
					locationDbBean.updateSpByWhere(dbCon);
				} else if (locQry.getDbBean(0).getRivLocation() == VzbVoipEnum.YesNoType.Y) {

					if (getModifiedBy() != null
							&& !("".equalsIgnoreCase(getModifiedBy()))) {
						locUpdObj.setModifiedBy(getModifiedBy());
					} else {
						locUpdObj.setModifiedBy("SBC_MIG");
					}

					if (getEnvOrderId() > 0)
						locUpdObj.setEnvOrderId(getEnvOrderId());

					if (sipEnabled == 1)
						locUpdObj.setSipEnabled(sipEnabled);

					locUpdObj.setSbcMigInd(1);
					locUpdObj.whereLocationIdEQ(locationId);
					locUpdObj.updateSpByWhere(dbCon);
				}
			} else {
				if (getCreatedBy() != null
						&& !("".equalsIgnoreCase(getCreatedBy()))) {
					locationDbBean.setCreatedBy(getCreatedBy());
				} else {
					locationDbBean.setCreatedBy("SBC_MIG");
				}
				locationDbBean.setCreationDate(new Timestamp(System
						.currentTimeMillis()));

				// Avoid Shell creation for RIV locations, these are the
				// inflight locations - Anand
				if (locationDbBean.getRivLocation() != VzbVoipEnum.YesNoType.Y)
					locationDbBean.insert(dbCon);
			}

		} catch (SQLException s) {
			s.printStackTrace();
			setStatus(InvErrorCode.DB_EXCEPTION);
			log.info("DB_FAILURE in addToDB Location " + s);
			return false;
		}
		setStatus(InvErrorCode.SUCCESS);
		return true;
	}

	/*** Z562196 Code end ****/
	private boolean addLocPackage(long pkgId) throws SQLException {
		log.info("Entering addLocPackage: pkgId" + pkgId);
		try {
			if (getFmcgLocationType() == VzbVoipEnum.FmcgLocationType.FMCG_ONLY
					&& pkgId < 7) {
				log.info("FMCG Only Location - Skip Package Id ["
						+ pkgId + "]");
				return true;
			}
			DBTblLocPackage locPkgDbBean = new DBTblLocPackage();
			int locPkgId = locPkgDbBean.getLocPackageIdSeqNextVal(dbCon);
			locPkgDbBean.setLocPackageId(locPkgId);
			locPkgDbBean.setLocationId(getLocationId());
			locPkgDbBean.setPackageId(pkgId);
			locPkgDbBean.setIsDefault(0);
			if (getEnvOrderId() > 0)
				locPkgDbBean.setEnvOrderId(getEnvOrderId());
			else
				locPkgDbBean.setEnvOrderIdNull();
			if (getModifiedBy() != null
					&& !("".equalsIgnoreCase(getModifiedBy()))) {
				locPkgDbBean.setModifiedBy(getModifiedBy());
			} else {
				locPkgDbBean.setModifiedBy("ESAP_INV");
			}
			if (getCreatedBy() != null
					&& !("".equalsIgnoreCase(getCreatedBy()))) {
				locPkgDbBean.setCreatedBy(getCreatedBy());
			} else {
				locPkgDbBean.setCreatedBy("ESAP_INV");
			}
			locPkgDbBean.setLastModifiedDate(new Timestamp(System
					.currentTimeMillis()));
			locPkgDbBean.setCreationDate(new Timestamp(System
					.currentTimeMillis()));
			log.info("locPakcgeId,locId,packageId:"
					+ locPkgDbBean.getLocPackageId() + ","
					+ locPkgDbBean.getLocationId() + ","
					+ locPkgDbBean.getPackageId());
			locPkgDbBean.insert(dbCon);
		} catch (Exception e) {
			setStatus(InvErrorCode.ERROR_ADDING_LOCPACKAGE_TO_LOCATION);
			setLogTrail("Location::addLocationFeaturesToLocation FAILURE in addLocPackage.");
			e.printStackTrace();
			return false;
		}
		setLogTrail("Location::addLocationFeaturesToLocation Successfully added LocationPackage.");
		setStatus(InvErrorCode.SUCCESS);
		return true;

	}

	/**
	 * The wrapper method to Add LocationFeatures To Location.
	 * 
	 * @return true Operation Successful false Operation UnSuccessful
	 * 
	 * @author banala
	 */
	public boolean addLocationFeaturesToLocation() throws SQLException,
			Exception {
		if (locationId == null) {
			setLogTrail("Location::addLocationFeaturesToLocation Location Id not found.");
			setStatus(InvErrorCode.INVALID_INPUT);
			return false;
		}
		// try {
		if (locationFeatures.size() > 0) {
			for (int i = 0; i < locationFeatures.size(); i++) {
				DBTblLocationFeatures locFeatures = new DBTblLocationFeatures();
				locFeatures.setLocationId(getLocationId());
				int iFeatureId = locationFeatures.get(i).getFeaturesDbBean()
						.getFeatureId();
				if (iFeatureId == 0) {
					String strFeatureName = locationFeatures.get(i)
							.getFeaturesDbBean().getName();
					if (strFeatureName != null) {
						TblVzbFeaturesQuery vzbFaQuery = new TblVzbFeaturesQuery();
						vzbFaQuery.whereNameEQ(strFeatureName);
						vzbFaQuery.queryByWhere(dbCon, " where Name = '"
								+ strFeatureName + "'");
						if (vzbFaQuery.size() > 0) {
							iFeatureId = vzbFaQuery.getDbBean(0).getFeatureId();
						}
					}
				}
				locFeatures.setFeatureId(iFeatureId);
				isLocationFeatureIdExist(locFeatures);
				boolean isInsertUpdate = true;
				if (!isLocationFeatureIdExist(locFeatures)) {
					locFeatures.setLocationFeaturesId(locFeatures
							.getLocationFeaturesIdSeqNextVal(dbCon));
					locFeatures.setFeatureCount(locationFeatures.get(i)
							.getFeatureCount());
					isInsertUpdate = true;
				} else {
					locFeatures.setFeatureCount(locationFeatures.get(i)
							.getFeatureCount() + locFeatures.getFeatureCount());
					isInsertUpdate = false;
				}
				if (getModifiedBy() != null
						&& !("".equalsIgnoreCase(getModifiedBy()))) {
					locFeatures.setModifiedBy(getModifiedBy());
				} else {
					locFeatures.setModifiedBy("ESAP_INV");
				}
				if (getCreatedBy() != null
						&& !("".equalsIgnoreCase(getCreatedBy()))) {
					locFeatures.setCreatedBy(getCreatedBy());
				} else {
					locFeatures.setCreatedBy("ESAP_INV");
				}
				locFeatures.setLastModifiedDate(new Timestamp(System
						.currentTimeMillis()));
				locFeatures.setCreationDate(new Timestamp(System
						.currentTimeMillis()));
				if (isInsertUpdate) {
					locFeatures.insert(dbCon);
				} else {
					locFeatures.whereLocationFeaturesIdEQ(locFeatures
							.getLocationFeaturesId());
					locFeatures.updateSpByWhere(dbCon);
				}

			}
		}
		/*
		 * } catch (Exception e) {
		 * setStatus(InvErrorCode.ERROR_ADDING_LOCATIONFEATURES_TO_LOCATION);
		 * setLogTrail(
		 * "Location::addLocationFeaturesToLocation FAILURE in addLocationFeaturesToLocation."
		 * ); e.printStackTrace(); return false; }
		 */
		setLogTrail("Location::addLocationFeaturesToLocation Successfully added LocationFeatures.");
		setStatus(InvErrorCode.SUCCESS);
		return true;
	}

	public boolean isLocationFeatureIdExist(DBTblLocationFeatures locFeatures)
			throws Exception {

		TblLocationFeaturesQuery locFeatureDbQry = new TblLocationFeaturesQuery();
		locFeatureDbQry.whereLocationIdEQ(locFeatures.getLocationId());
		locFeatureDbQry.whereFeatureIdEQ((int) locFeatures.getFeatureId());
		locFeatureDbQry.query(dbCon);
		if (locFeatureDbQry.size() > 0) {
			locFeatures.setLocationFeaturesId((locFeatureDbQry.getDbBean(0))
					.getLocationFeaturesId());
			locFeatures.setFeatureCount((locFeatureDbQry.getDbBean(0))
					.getFeatureCount());

			return true;
		}
		return false;
	}

	/**
	 * The method to delete the Location and corresponding Child records.
	 * 
	 * @return true Delete Operation Successful false Delete Operation
	 *         UnSuccessful
	 */
	public boolean deleteFromDB() throws Exception, SQLException {
		/*
		 * try {
		 */
		if (locationId == null) {
			setStatus(InvErrorCode.NOTFOUND_LOCATION);
			log.info("FAILURE in deleteFromDB Location. Location Id missing.");
			return false;
		}
		setGetAll(true);
		getDetails();
		/*kr if (shellMigration && getRivLocation() == VzbVoipEnum.YesNoType.Y) {
			System.out
					.println("Delete came as part of sbc migration, but location is already riv location, so bypassing the delete location");
			setStatus(InvErrorCode.SUCCESS);
			return true;
		}*/

		if (deleteCCPortalTn(locationId) == false) {
			log.info("Error deleting deleteCCPortalTn for location");
			setStatus(InvErrorCode.ERROR_DELETING_CC_PORTAL_FOR_LOCATION);
			log.info("Error deleting deleteCCPortalTn for location");
			return false;
		}
		if (deletePrefixRoutingForLocation() == false) {
			log.info("Error deleting prefixrouting for location");
			setStatus(InvErrorCode.ERROR_DELETING_PREFIXROUTING_TO_LOCATION);
			return false;
		}
		log.info("Successfully deleted prefixrouting for location");
		if (deleteVmAccessByLocationId() == false) {
			setStatus(InvErrorCode.ERROR_DELETING_VMACCESS_TO_LOCATION);
			log.info("Error deleting vm access for location");
			return false;
		}
		log.info("Successfully deleted vm access for location");
		if (deleteAuthCodesForLocation() == false) {
			setStatus(InvErrorCode.ERROR_DELETING_AUTHCODES_FOR_LOCATION);
			log.info("Error deleting Authcodes for location");
			return false;
		}
		log.info("Successfully deleted Authcodes for location");

		// IR #1404029 - Delete the Group and Group Tns first and then
		// Subscriber.
		// For Hybrid, tbl_group_tn refers Subscriber table.
		if (deleteGroupForLocation() == false) {
			setStatus(InvErrorCode.ERROR_DELETING_GROUP_FROM_LOCATION);
			log.info("Error deleting Group for location");
			return false;
		}
		log.info("Succssfully deleted Group for location");
		
	  /*	if (getEnterpriseTrunkId() > 0 && deleteETTnFeatForLocation()==false ) { // commented because xo not using tbl_tso_et_tn_features and tbl_tso_et_Tn tables.
			setStatus(InvErrorCode.ERROR_DELETING_ETTN_FEATURES_FROM_LOCATION);
			log.info("Error deleting ETTN FEATURES for location");
			return false;
		}
           
		if (getEnterpriseTrunkId() > 0  && deleteETTnForLocation() == false) {// commented because xo not using tbl_tso_et_tn 
			setStatus(InvErrorCode.ERROR_DELETING_ETTN_FROM_LOCATION);
			log.info("Error deleting ETTN for location");
			return false;
		}*/


	/*	if (deleteSubscriberForLocation() == false) {
			setStatus(InvErrorCode.ERROR_DELETING_SUBSCRIBER_FOR_LOCATION);
			log.info("Error deleting Subscriber for location");
			return false;
		}*/
		log.info("Successfully deleted Subscriber for location");

		// Update Location Id of Shared Gateways to null
		// Commented it for IR 1918374
		// if (getRollbackFlag() == false)

		// August 2012 Voip local sync sreq - 34 change start
		log.info("checking if this is a shared_gateway_device move");
		// if (!(getRegion(getLocationId()) == VzbVoipEnum.RegionType.APAC &&
		// getRollbackFlag() == true)) -- commented this condition as this
		// delete is common for all US/EMEA/APAC regions now.
		if (isSharedGatewayMove()) {
			log.info("This is a shared gateway device move");
			updateSharedGwLocation();
		}
		// August 2012 Voip local sync sreq - 34 change end

		if (deleteDevicesForLocation() == false) {
			setStatus(InvErrorCode.ERROR_DELETING_DEVICE_FROM_LOCATION);
			log.info("Error deleting device for location");
			return false;
		}
		log.info("Successfully deleted gw device for location");
		if (deleteFeaturePkgForLocation() == false) {
			setStatus(InvErrorCode.ERROR_DELETING_FEATURE_PACKAGE_TO_LOCATION);
			log.info("Error deleting FeaturePkg for location");
			return false;
		}
		log.info("Successfully deleted FeaturePkg for location");
		if (deleteLocationFeatures() == false) {
			setStatus(InvErrorCode.ERROR_DELETING_LOCATIONFEATURES_FROM_LOCATION);
			log.info("Error deleting LocationFeatures for location");
			return false;
		}
		System.out
				.println("Successfully deleted LocationFeatures for location");
		// to delete the foreign key of the public tn pool table for location
		if (deleteTnPortingInfo(locationId) == false) {
			setStatus(InvErrorCode.ERROR_DELETING_TNPOOLID_FROM_TBLTNPORTINGINFO_FOR_LOCATION);
			log.info("Error deleting tn_pool_id from tbl_tn_porting_info for location");
			return false;
		}
		System.out
				.println("Successfully deleted tn_pool_id from tbl_tn_portin_info");
		// IR #2388628 added the non-riv check as NON-RIV location doesn;t have
		// TN
		if (getRivLocation() == VzbVoipEnum.YesNoType.Y) {
			if (deletePublicTnPoolForLocation() == false) {
				setStatus(InvErrorCode.ERROR_DELETING_PUBLICTNPOOL_TO_LOCATION);
				log.info("Error deleting Public Tn Pool for location");
				return false;
			}
			log.info("Successfully deleted TN from Public Tn Pool and TRI");
		} else {
			log.info("Bypassing TN from Public Tn Pool deletion as Location is NON-RIV");
		}
		// IR #2388628 end
		// IR #2392798 DEL Location failing as Prefix plan doen't exist for APAC
		// location
		if (getRivLocation() == VzbVoipEnum.YesNoType.Y) {
			if (deletePrefixPlanForAPAC() != true) {
				log.info("Failed to Delete APAC Prefix Plan");
				return false;
			}
			log.info("Successfully deleted APAC Prefix Plan");
		} else {
			log.info("Bypassing APAC Prefix Plan deletion as Location is NON-RIV");
		}

		/** Delete Record from TblEntBillFeatures , if any, for this enterprise **/
	/*kr	DBTblEntBillFeatures entBillFeatures = new DBTblEntBillFeatures();
		entBillFeatures.whereLocationIdEQ(locationId);
		entBillFeatures.deleteByWhere(dbCon);
		setLogTrail("Deleted TblEntBillFeatures record for this locationId:"
				+ locationId);*/

		// IR #2392798 end
		DBTblLocation locationDbBean = new DBTblLocation();
		locationDbBean.whereLocationIdEQ(locationId);
		if (migration && sbcMigInd == 1) {
			log.info("Leaving shell account back in esap");
			locationDbBean.setCallingPlanIdNull();
			locationDbBean.setActiveInd(1);
			locationDbBean.setDialPlanIdNull();
			locationDbBean.setRpidPoolIdNull();
			locationDbBean.setBtnPoolIdNull();
			locationDbBean.setRivLocation(VzbVoipEnum.YesNoType.N);
			if (locationDbBean.updateSpByWhere(dbCon) <= 0) {
				setStatus(InvErrorCode.NO_LOCATION_UPDATED);
				return false;
			}
			log.info("after making location inactive");
		} else {
			log.info("Before deleting the location");
			if (locationDbBean.deleteByWhere(dbCon) <= 0) {
				setStatus(InvErrorCode.NO_LOCATION_DELETED);
				return false;
			}
		}

		if (getLocCountry().equals("AU")) {
			TblLocationQuery lQry = new TblLocationQuery();
			lQry.whereEnterpriseIdEQ(getEnterpriseId());
			lQry.whereLocCountryEQ("AU");
			lQry.query(dbCon);

			// If No other AU location found, turn OFF LI Indicator
			if (lQry.size() <= 0) {
				DialPlan dpObj = new DialPlan(dbCon);
				dpObj.setDialPlanId((int) getDialPlanId());
				dpObj.setLiInd(0);
				dpObj.modifyInDB();
			}
		}

		deleteCallingPlanBeanForLocation();
		log.info("Successfully deleted Calling Plan for location");
		/*
		 * } catch(SQLException s) { s.printStackTrace();
		 * setStatus(InvErrorCode.DB_EXCEPTION);
		 * log.info("DB_FAILURE in deleteFromDB Location"); return
		 * false; } catch(Exception s) { s.printStackTrace();
		 * setStatus(InvErrorCode.ERROR_DELETING_LOCATION);
		 * log.info("FAILURE in deleteFromDB Location"); return false;
		 * }
		 */
		setStatus(InvErrorCode.SUCCESS);
		log.info("Successfully DELETED Location from the DB");
		return true;
	}

	/**
	 * The method to delete Location Features for a given Location
	 * 
	 * @throws SQLException
	 *             If any DB Error occurs.
	 */
	private boolean deleteCCPortalTn(String locationId) throws Exception,
			SQLException {
		log.info("Enter deleteCCPortalTn Method===>" + locationId);
		PreparedStatement pstmt = null;
		String sqlQuery = "DELETE FROM  Tbl_cc_portal_tn where LOCATION_ID =?";
		try {
			pstmt = dbCon.prepareStatement(sqlQuery);
			pstmt.setString(1, locationId);
			pstmt.executeUpdate();
		}/*
		 * catch(Exception e){ e.printStackTrace();
		 * log.info("Exception in deleteCCPortalTn method==>"
		 * +e.getMessage()); return false; }
		 */finally { // #IR1440263 closing statement and results set
			if (pstmt != null) {
				pstmt.close();
			}
		}
		log.info("Enter deleteCCPortalTn Method===>");
		return true;
	}

	/**
	 * The method to delete Location Features for a given Location
	 * 
	 * @throws SQLException
	 *             If any DB Error occurs.
	 */
	private boolean deleteLocationFeatures() throws SQLException {
		DBTblLocationFeatures locFeaturesDbBean = new DBTblLocationFeatures();
		locFeaturesDbBean.whereLocationIdEQ(locationId);
		int noOfRowsDeleted = locFeaturesDbBean.deleteByWhere(dbCon);
		/*
		 * if ( noOfRowsDeleted <= 0 ) { return false; }
		 */
		setLogTrail("Location::deleteLocationFeaturesForLocation Successfully Deleted"
				+ noOfRowsDeleted + " Location Feature.");
		return true;
	}

	/**
	 * The wrapper method to Delete LocationFeatures from Location.
	 * 
	 * @return true Operation Successful false Operation UnSuccessful
	 * 
	 */
	public boolean deleteLocationFeaturesForLocation() throws Exception,
			SQLException {
		log.info("Entering deleteLocationFeaturesForLocation()");
		if (locationId == null) {
			setLogTrail("Location::deleteLocationFeaturesForLocation Location Id not found.");
			setStatus(InvErrorCode.INVALID_INPUT);
			return false;
		}
		// try {

		if (locationFeatures.size() > 0) {
			for (int i = 0; i < locationFeatures.size(); i++) {
				DBTblLocationFeatures locFeatDbBean = new DBTblLocationFeatures();
				FeaturesBean featBean = locationFeatures.get(i);
				int iFeatureId = featBean.getFeaturesDbBean().getFeatureId();
				if (iFeatureId <= 0) {
					String strFeatureName = featBean.getFeaturesDbBean()
							.getName();
					if (strFeatureName != null) {
						TblVzbFeaturesQuery vzbFaQuery = new TblVzbFeaturesQuery();
						vzbFaQuery.whereNameEQ(strFeatureName);
						vzbFaQuery.queryByWhere(dbCon, " where Name = '"
								+ strFeatureName + "'");
						if (vzbFaQuery.size() > 0) {
							iFeatureId = vzbFaQuery.getDbBean(0).getFeatureId();
						}
					}
				}
				if (iFeatureId > 0) {
					// locFeatDbBean.whereFeatureIdEQ(iFeatureId);
					// locFeatDbBean.whereLocationIdEQ(locationId);
					locFeatDbBean.setLocationId(locationId);
					locFeatDbBean.setFeatureId(iFeatureId);
					if (isLocationFeatureIdExist(locFeatDbBean)) {
						if (locationFeatures.get(i).getFeatureCount() < locFeatDbBean
								.getFeatureCount()) {
							int diff = (int) locFeatDbBean.getFeatureCount()
									- locationFeatures.get(i).getFeatureCount();
							locFeatDbBean.setFeatureCount(diff);
							locFeatDbBean
									.whereLocationFeaturesIdEQ(locFeatDbBean
											.getLocationFeaturesId());
							locFeatDbBean.updateSpByWhere(dbCon);

						} else if (locationFeatures.get(i).getFeatureCount() > locFeatDbBean
								.getFeatureCount()) {
							throw new Exception(
									"FeatureCount in db is less than input");
						} else if (locationFeatures.get(i).getFeatureCount() == locFeatDbBean
								.getFeatureCount()) {
							locFeatDbBean
									.whereLocationFeaturesIdEQ(locFeatDbBean
											.getLocationFeaturesId());
							locFeatDbBean.deleteByWhere(dbCon);
						}
					}

				}
			}
		}
		/*
		 * } catch (Exception e) {
		 * setStatus(InvErrorCode.ERROR_DELETING_LOCATIONFEATURES_FROM_LOCATION
		 * ); setLogTrail(
		 * "Location::deleteLocationFeaturesForLocation FAILURE in deleteLocationFeaturesForLocation."
		 * ); e.printStackTrace(); return false; }
		 */
		setLogTrail("Location::deleteLocationFeaturesForLocation Successfully deleted LocationFeatures.");
		setStatus(InvErrorCode.SUCCESS);
		return true;
	}

	/**
	 * The method to delete Subscribers in the given Location
	 * 
	 * @author banala
	 * @throws SQLException
	 *             If any DB Error occurs.
	 */
	private boolean deleteSubscriberForLocation() throws SQLException,
			Exception {
		TblSubscriberQuery subscriberQry = new TblSubscriberQuery();
		String whereClause = "where location_id = '" + getLocationId() + "'";
		subscriberQry.queryByWhere(dbCon, whereClause);
		if (subscriberQry.size() > 0) {
			// Call Delete on all Subscribers
			Subscriber subscriberToBeDeleted = new Subscriber(dbCon);
			for (int i = 0; i < subscriberQry.size(); i++) {
				log.info("Subscrber to be deleted:"
						+ subscriberQry.getDbBean(i).getSubId()
						+ "rollbackFlag" + rollbackFlag);
				subscriberToBeDeleted.setSubId(subscriberQry.getDbBean(i)
						.getSubId());
				subscriberToBeDeleted.setRollbackFlag(rollbackFlag);
				if (subscriberToBeDeleted.delSubscriber() == false) {
					return false;
				}
			}
		}
		return true;
	}

	private boolean deleteETTnForLocation() throws SQLException, Exception {
		log.info(" Executing deleteETTnForLocation() ");
		PreparedStatement pstmt = null;
		String query = "delete from  tbl_tso_et_tn where tn_pool_id in ( select tn_pool_id from tbl_public_tn_pool where location_id = ?)";
		try {
			String locationId = getLocationId();
			pstmt = dbCon.prepareStatement(query);
			pstmt.setString(1, locationId);
			pstmt.executeUpdate();
		}/*
		 * catch(Exception e){ e.printStackTrace();
		 * log.info("Exception in deleteETTnForLocation method==>"
		 * +e.getMessage()); return false; }
		 */finally { // #IR1440263 closing statement and results set
			if (pstmt != null) {
				pstmt.close();
			}
		}
		setLogTrail("Deleted details related to location: " + getLocationId()
				+ " from tbl_tso_et_tn");
		log.info("Deleted details related to location: "
				+ getLocationId() + " from tbl_tso_et_tn");
		return true;
	}
	
	private boolean deleteGroupForLocation() throws SQLException, Exception {
		log.info(" deleteGroupForLocation start"); 
		String CCLConfig = getConfigParamValue("ENT_CCL", "ENT_NON_TSO_CCL");
		boolean lbCCLDisable = false;
                if (CCLConfig != null && CCLConfig.equals("Y")) {
                        lbCCLDisable = true;
                }
		//Enterprise enterprise = new Enterprise(dbCon);
		long entCclSum = 0L;
	/*	if (!lbCCLDisable) {
		 entCclSum = enterprise
				.getEntTrunkCclSumByEnterpriseIdForUpd(getEnterpriseId());
		} else {
		entCclSum = enterprise.getEntTrunkCclSumByEnterpriseId(getEnterpriseId());
		}*/

		log.info(" entCclSum before update  for location : " + getLocationId() + " :: "  + entCclSum ); 
		long locCclsum = getLocTrunkCclSumByLocationId(getLocationId());
		boolean updateCheck = false;

		TblGroupQuery groupQry = new TblGroupQuery();
		String whereClause = "where location_id = '" + getLocationId() + "'";
		groupQry.queryByWhere(dbCon, whereClause);

		if (groupQry.size() > 0) {
			// Call Delete on all Groups
			TwoWayGroup pbxGroupToBeDeleted = new TwoWayGroup(dbCon);
			//PBXGroup pbxGroupToBeDeleted = new PBXGroup(dbCon);
			//TwoWayGroup pbxGroupToBeDeleted = new KeyGroup(dbCon);
			for (int i = 0; i < groupQry.size(); i++) {
				long groupType = groupQry.getDbBean(i).getGroupType();
				log.info("groupType"+ groupType);
				log.info("getGroupId"+ groupQry.getDbBean(i).getGroupId());
				log.info("getRollbackFlag"+ getRollbackFlag());
				//if (VzbVoipEnum.TrunkGroupType.PBX == (int) groupType) {
					if (entCclSum > 0 && locCclsum > 0
							&& groupQry.getDbBean(i).getPbxMaxCclLimit() > 0) {
						entCclSum = entCclSum
								- groupQry.getDbBean(i).getPbxMaxCclLimit();
						locCclsum = locCclsum
								- groupQry.getDbBean(i).getPbxMaxCclLimit();
						updateCheck = true;
					}
					pbxGroupToBeDeleted.setGroupId(groupQry.getDbBean(i)
							.getGroupId());
					pbxGroupToBeDeleted.setRollbackFlag(getRollbackFlag());
					if (pbxGroupToBeDeleted.deleteFromDB() == false) {
						log.info("## TwoWayGroupToBeDeleted.deleteFromDB() ::is failed" );
						return false;
					}
				/*} else if (VzbVoipEnum.TrunkGroupType.KEY == (int) groupType) {
					keyGroupToBeDeleted.setGroupId(groupQry.getDbBean(i)
							.getGroupId());
					keyGroupToBeDeleted.setRollbackFlag(getRollbackFlag());
					if (keyGroupToBeDeleted.deleteFromDB() == false) {
						return false;
					}
				}*/
			}
		}
		//if (updateCheck)
		/*if(!lbCCLDisable) {
			log.info("Calling updateEntAndLocCclNew");
			updateEntAndLocCCLNew(getEnterpriseId(), getLocationId(), entCclSum,
					locCclsum);
		} else {
			log.info(" BAU updateEntAndLocCcl " ); 
			updateEntAndLocCcl(getEnterpriseId(), getLocationId(), entCclSum,
					locCclsum);
		}*/
		log.info(" deleteGroupForLocation End"); 
		return true;
	}


	public void updateEntAndLocCcl(String enterpriseId, String locationId,
			long entCclSum, long locCclSum) {

		log.info("Entering updateEntAndLocCcl : Start");
		try {
			DBTblLocation locDbObj = new DBTblLocation();
			DBTblEnterprise entDbObj = new DBTblEnterprise();
			log.info("  Enterprise TrunkCcl Sum [" + entCclSum
					+ "] and Location Trunk CCL Sum [" + locCclSum + "]");
			entDbObj.setEntTrunkCclSum(entCclSum);
			locDbObj.setLocTrunkCclSum(locCclSum);

			entDbObj.whereEnterpriseIdEQ(enterpriseId);
			entDbObj.updateSpByWhere(dbCon);

			locDbObj.whereLocationIdEQ(locationId);
			locDbObj.updateSpByWhere(dbCon);
			log.info("Entering updateEntAndLocCcl End");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	/**
	 * The method to delete Calling Plan for a given Location iff Calling Plan
	 * is not default.
	 * 
	 * Logic: 1) Get the Calling Plan Id of current Location 2) If the Calling
	 * Plan Id is not Default (DEFAULT_IND column <> 1) then delete the
	 * corresponding Calling Plan.
	 * 
	 * @author banala
	 * @throws SQLException
	 *             If any DB Error occurs.
	 */
	private boolean deleteCallingPlanBeanForLocation() throws SQLException,
			Exception {
		log.info("test1");
		TblCallingPlansQuery callingPlansQuery = new TblCallingPlansQuery();
		log.info("test2 callingPlan in DB:" + getCallingPlanId());
		String whereLocClause = " where CALLING_PLAN_ID > 1 and CALLING_PLAN_ID = "
				+ getCallingPlanId();

		log.info("test3");
		callingPlansQuery.queryByWhere(dbCon, whereLocClause);
		log.info("test4");
		for (int i = 0; i < callingPlansQuery.size(); i++) {
			CallingPlan callingPlanObj = new CallingPlan(dbCon);
			callingPlanObj.setCallingPlanId((int) getCallingPlanId());
			if (callingPlanObj.deleteCallingPlan())
				return false;
			log.info("test8");
		}
		return true;
	}

	private boolean deleteTerminatingRoutingForLocation() throws SQLException {
		DBTblTerminatingRouting dbTblTermRouting = new DBTblTerminatingRouting();
		System.out
				.println("deleteTerminatingRoutingForLocation():getDialPlanId():"
						+ getDialPlanId());
		dbTblTermRouting.whereDialPlanIdEQ(getDialPlanId());
		dbTblTermRouting.deleteByWhere(dbCon);
		return true;
	}

	// IR #1416316 - TRI delete for given dialplan id. Instead of deleting one
	// by one
	// deleteTri based on dialplanid will improve performance for Migration
	public boolean deleteTribyDpid(String locationId) throws SQLException {
		if (locationId == null || "".equals(locationId)) {
			log.info(" Please pass Location Id");
			return false;
		}

		TblLocationQuery tblLocationQuery = new TblLocationQuery();
		tblLocationQuery.whereLocationIdEQ(locationId);
		tblLocationQuery.query(dbCon);

		if (tblLocationQuery.size() > 0) {
			long dpid = tblLocationQuery.getDbBean(0).getDialPlanId();
			log.info(" Dial Plan Id " + dpid);
			if (dpid > 0) {
				DBTblTerminatingRouting dbTblTermRouting = new DBTblTerminatingRouting();
				System.out
						.println("deleteTerminatingRoutingForLocation():getDialPlanId():"
								+ dpid);
				dbTblTermRouting.whereDialPlanIdEQ(dpid);
				dbTblTermRouting.deleteByWhere(dbCon);
				return true;
			} else {
				log.info(" Dial Plan Id is null for the Location "
						+ locationId);
				return false;
			}
		} else {
			log.info("Location Id " + locationId + "is not found.");
			return false;
		}
	}

	/**
	 * The method to delete Dial Plan for a given Location Logic: 1) Get the
	 * dial Plan Id of current Location then delete the corresponding dial Plan.
	 * 
	 * @throws SQLException
	 *             If any DB Error occurs.
	 */
	private boolean deleteDialPlanBeanForLocation() throws SQLException,
			Exception {
		log.info("test1");
		TblDialPlanQuery dialPlanQuery = new TblDialPlanQuery();
		log.info("test2 dialPlan in DB:" + getDialPlanId());
		String whereLocClause = " where DIAL_PLAN_ID > 1 and DIAL_PLAN_ID = "
				+ getDialPlanId();
		log.info("test3");
		dialPlanQuery.queryByWhere(dbCon, whereLocClause);
		log.info("test4");
		for (int i = 0; i < dialPlanQuery.size(); i++) {
			DialPlan dialPlan = new DialPlan(dbCon);
			dialPlan.setDialPlanId(dialPlanQuery.getDbBean(i).getDialPlanId());
			dialPlan.setRollbackFlag(rollbackFlag);
			if (dialPlan.deleteDialPlan() == false) {
				return false;
			}
		}
		return true;
	}

	/**
	 * The method to delete Authcodes for a given Location
	 * 
	 * @throws SQLException
	 *             If any DB Error occurs.
	 */
	private boolean deleteAuthCodesForLocation() throws Exception, SQLException {
		TblAcctAuthCodesQuery tblAcctAuthCodesQuery = new TblAcctAuthCodesQuery();
		String whereLocClause = " where LOCATION_ID = \'" + locationId + "\'";
		tblAcctAuthCodesQuery.queryByWhere(dbCon, whereLocClause);
/*		if (tblAcctAuthCodesQuery.size() > 0) {
			AcctAuthCodes acctAuthCodes = new AcctAuthCodes(dbCon);
			for (int i = 0; i < tblAcctAuthCodesQuery.size(); i++) {
				acctAuthCodes.setIntAcctAuthCodesId(tblAcctAuthCodesQuery
						.getDbBean(i).getAcctAuthCodesId());
				if (acctAuthCodes.deleteFromDB() == false) {
					return false;
				}
			}
		}*/
		return true;
	}

	/**
	 * The method to delete VmAccess for a given Location
	 * 
	 * @throws SQLException
	 *             If any DB Error occurs.
	 */
	private boolean deleteVmAccessByLocationId() throws SQLException, Exception {
		TblVmAccessQuery tblVmAccessQuery = new TblVmAccessQuery();
		String whereLocClause = " where LOCATION_ID = \'" + locationId + "\'";
		tblVmAccessQuery.queryByWhere(dbCon, whereLocClause);
/*		if (tblVmAccessQuery.size() > 0) {
			VmAccess vmAccess = new VmAccess(dbCon);
			for (int i = 0; i < tblVmAccessQuery.size(); i++) {
				vmAccess.setVmAccessId(tblVmAccessQuery.getDbBean(i)
						.getVmAccessId());
				if (vmAccess.deleteFromDB() == false) {
					return false;
				}
			}
		}*/
		return true;
	}

	/**
	 * The method to delete GatewayDevice Map for a given Location
	 * 
	 * Logic: 1) Get all the Device Map entries for the current Location where
	 * GATEWAY_DEVICE_ID > 0, since we want to delete only Gateway Devices for
	 * the Location and not Sip Devices. 2) Delete all the Device Maps retrieved
	 * from Step 1.
	 * 
	 * @author banala
	 * @throws SQLException
	 *             If any DB Error occurs.
	 */
	private boolean deleteDevicesForLocation() throws SQLException, Exception {
		TblDeviceMapQuery tblDeviceMapQuery = new TblDeviceMapQuery();
		String whereLocClause = " where LOCATION_ID = \'" + locationId + "\' ";
		// " and GATEWAY_DEVICE_ID > 0";
		tblDeviceMapQuery.queryByWhere(dbCon, whereLocClause);
		if (tblDeviceMapQuery.size() > 0) {
			Device device = new Device(dbCon);
			for (int i = 0; i < tblDeviceMapQuery.size(); i++) {
				boolean sbcMigratedDevice = false;
				if (migration) {
					if (tblDeviceMapQuery.getDbBean(i).getGatewayDeviceId() > 0) {
						TblGatewayDeviceInfoQuery gtwQry = new TblGatewayDeviceInfoQuery();
						gtwQry.whereGatewayDeviceIdEQ(tblDeviceMapQuery
								.getDbBean(i).getGatewayDeviceId());
						gtwQry.query(dbCon);
						if (gtwQry.size() > 0) {
							if (gtwQry.getDbBean(0).getSbcMigInd() == 1)
								sbcMigratedDevice = true;
						}
					}
				}
				if (sbcMigratedDevice) {
					log.info("Delete device = <"
							+ tblDeviceMapQuery.getDbBean(i).getDeviceMapId()
							+ "> is bypassed because it is SbcMigrated");
				} else {
					device.setDeviceMapId(tblDeviceMapQuery.getDbBean(i)
							.getDeviceMapId());
					log.info("Delete device map id = <"
							+ device.getDeviceMapId() + ">");
					device.setRollbackFlag(getRollbackFlag());
					device.setEnvOrderId(getEnvOrderId());
/*					if (device.deleteDevice() == false) {
						return false;
					}*/
				}
			}
		}
		return true;
	}

	/**
	 * The method to delete Feature Pkg for a given Location
	 * 
	 * @throws SQLException
	 *             If any DB Error occurs.
	 */
	private boolean deleteFeaturePkgForLocation() throws Exception,
			SQLException {
		String whereLocClause = " where LOCATION_ID = \'" + locationId + "\'";
		TblLocPackageQuery locPkgQry = new TblLocPackageQuery();
		locPkgQry.setOrderBy("package_id");
		locPkgQry.queryByWhere(dbCon, whereLocClause);
		long lastPkgId = -1;
		for (int k = 0; k < locPkgQry.size(); k++) {
			DBTblLocPackage locPkgDbBean = new DBTblLocPackage();
			locPkgDbBean.whereLocPackageIdEQ(locPkgQry.getDbBean(k)
					.getLocPackageId());
			locPkgDbBean.deleteByWhere(dbCon);
			long currentPkgId = locPkgQry.getDbBean(k).getPackageId();
			if (lastPkgId != currentPkgId) {
				lastPkgId = currentPkgId;
				if (isPkgDeletable(currentPkgId)) {
					if (deletePkgFeatures(currentPkgId) == false) {
						return false;
					}
					if (deletePackage(currentPkgId) == false) {
						return false;
					}
				}
			}
		}
		return true;
	}

	/**
	 * The method to deletes given loc pkg mapping
	 * 
	 * @throws SQLException
	 *             If any DB Error occurs.
	 */
	private boolean deleteLocPkg(long pkgId) throws SQLException {
		if (pkgId <= 0 || locationId == null || locationId.equals(""))
			return false;
		DBTblLocPackage locPkgDbBean = new DBTblLocPackage();
		locPkgDbBean.wherePackageIdEQ(pkgId);
		locPkgDbBean.whereLocationIdEQ(locationId);
		locPkgDbBean.deleteByWhere(dbCon);
		if (isPkgDeletable(pkgId)) {
			if (deletePkgFeatures(pkgId) == false) {
				return false;
			}
			if (deletePackage(pkgId) == false) {
				return false;
			}
		}
		return true;
	}

	/**
	 * For deleting Pkg features, need not check for default package since
	 * features are added new for each location afresh, even when pkg is
	 * default.
	 * 
	 * @param packageId
	 *            The Package Id
	 * @throws SQLException
	 *             If any DB Error occurs.
	 */
	private boolean deletePkgFeatures(long packageId) throws SQLException {
		DBTblPkgFeatures pkgFeatDbBean = new DBTblPkgFeatures();
		pkgFeatDbBean.wherePackageIdEQ(packageId);
		if (pkgFeatDbBean.deleteByWhere(dbCon) <= 0) {
			return false;
		}
		return true;
	}

	/**
	 * The method to delete Package iff its not default.
	 * 
	 * @param packageId
	 *            The Package Id
	 * @throws SQLException
	 *             If any DB Error occurs.
	 */
	private boolean deletePackage(long packageId) throws SQLException {
		DBTblPackage packageDbBean = new DBTblPackage();
		packageDbBean.wherePackageIdEQ(packageId);
		if (packageDbBean.deleteByWhere(dbCon) <= 0) {
			return false;
		}
		return true;
	}

	private boolean isPkgDeletable(long packageId) throws SQLException {
		TblPackageQuery pkgQry = new TblPackageQuery();
		String whereClause = " where package_id = " + packageId
				+ " and template_ind = 1";
		pkgQry.queryByWhere(dbCon, whereClause);
		if (pkgQry.size() > 0) {
			return false;
		}
		return true;
	}

	/**
	 * The method to delete Prefix Routing for a given Location
	 * 
	 * @throws SQLException
	 *             If any DB Error occurs.
	 */
	private boolean deletePrefixRoutingForLocation() throws Exception,
			SQLException {
		TblPrefixRoutingQuery tblPrefixRoutingQuery = new TblPrefixRoutingQuery();
		String whereLocClause = " where LOCATION_ID = \'" + locationId + "\'";
		tblPrefixRoutingQuery.queryByWhere(dbCon, whereLocClause);
/*		if (tblPrefixRoutingQuery.size() > 0) {
			PrefixRouting prefixRouting = new PrefixRouting(dbCon);
			for (int i = 0; i < tblPrefixRoutingQuery.size(); i++) {
				prefixRouting.setPrefixId(tblPrefixRoutingQuery.getDbBean(i)
						.getPrefixRoutingId());
				if (prefixRouting.deletePrefixRouting() == false) {
					return false;
				}
			}
		}*/
		return true;
	}

	/**
	 * The method to delete Public Tn Pool for a given Location
	 * 
	 * @throws SQLException
	 *             If any DB Error occurs.
	 */
	private boolean deletePublicTnPoolForLocation() throws Exception {
		// Get all TN from PNP for the location and then delete the TRI rec
		log.info("Start:: deletePublicTnPoolForLocation ");
		List<String> tnList = new ArrayList<String>();
		getAllTnRecFromPnp(tnList);
		long tmpEnvOrderId = 0;
		if (getEnvOrderId() > 0)
			tmpEnvOrderId = getEnvOrderId();
		deleteTriForTnList(tnList, locationId, Long.toString(tmpEnvOrderId));
		setLogTrail("Successfully deleted TRI record. Total TN removed = "
				+ tnList.size());
		System.out
				.println("Successfully deleted TRI record. Total TN removed = "
						+ tnList.size());

		// Check the reference of STN Pool Id in the location table and update
		// with null.
		DBTblLocation tblLocation = new DBTblLocation();
		tblLocation.setStnPoolIdNull();
		tblLocation.whereLocationIdEQ(locationId);
		int locationRecCountUpdated = tblLocation.updateSpByWhere(dbCon);
		setLogTrail("Successfully Location Updated STNPOOLID to NULL"
				+ locationRecCountUpdated);
		log.info("Successfully Location Updated STNPOOLID to NULL "
				+ locationRecCountUpdated);

		// TRI is gone, not delete PNP for the location
		DBTblPublicTnPool dbTblPnp = new DBTblPublicTnPool();
		dbTblPnp.whereLocationIdEQ(locationId);

		int pnpRecCountDeleted = dbTblPnp.deleteByWhere(dbCon);
		if (pnpRecCountDeleted < 0) {
			return false;
		}
		setLogTrail("Successfully deleted PNP record " + pnpRecCountDeleted);
		log.info("Successfully deleted PNP record "
				+ pnpRecCountDeleted);
		log.info("End:: deletePublicTnPoolForLocation ");
		return true;
	}

	private void getAllTnRecFromPnp(List<String> tnList) throws SQLException {
		String whereLocClause = " where LOCATION_ID = \'" + locationId + "\'";
		TblPublicTnPoolQuery tblPublicTnPoolQuery = new TblPublicTnPoolQuery();
		tblPublicTnPoolQuery.queryByWhere(dbCon, whereLocClause);
		tblPublicTnPoolQuery.setLimitQry(false);
		if (tblPublicTnPoolQuery.size() > 0) {
			for (int i = 0; i < tblPublicTnPoolQuery.size(); i++) {
				tnList.add(tblPublicTnPoolQuery.getDbBean(i).getTn());
			}
			// log.info("Calling getAllTnRecFromPnp() recursively to make sure there is no rec left in db.");
			// getAllTnRecFromPnp(tnList);
		}
	}

	/*
	 * private boolean deletePublicTnPoolForLocation() throws
	 * Exception,SQLException { String whereLocClause =
	 * " where LOCATION_ID = \'" + locationId + "\'"; TblPublicTnPoolQuery
	 * tblPublicTnPoolQuery = new TblPublicTnPoolQuery();
	 * tblPublicTnPoolQuery.queryByWhere(dbCon, whereLocClause); if
	 * (tblPublicTnPoolQuery.size() > 0) { PublicTnPool publicTnPool = new
	 * PublicTnPool(dbCon); for (int i = 0; i < tblPublicTnPoolQuery.size();
	 * i++) {
	 * publicTnPool.setTnPoolId(tblPublicTnPoolQuery.getDbBean(i).getTnPoolId
	 * ()); publicTnPool.deletePublicTnPool(); //DBTblTerminatingRouting
	 * trDbBean = new DBTblTerminatingRouting(); //trDbBean.whereRangeStartEQ(""
	 * + publicTnPool.getTn()); //trDbBean.whereRangeEndEQ("" +
	 * publicTnPool.getTn());
	 * //log.info("Deleting Terminating Routing by TN [" +
	 * publicTnPool.getTn() + "]"); //trDbBean.deleteByWhere(dbCon);
	 * log.info
	 * ("TRI delete for tn :"+tblPublicTnPoolQuery.getDbBean(i).getTn());
	 * TerminatingRouting termObj = new TerminatingRouting(dbCon);
	 * termObj.setRangeStart(tblPublicTnPoolQuery.getDbBean(i).getTn());
	 * termObj.setRangeEnd(tblPublicTnPoolQuery.getDbBean(i).getTn());
	 * termObj.setDialPlanId(getDialPlanId());
	 * termObj.setEnvOrderId(getEnvOrderId());
	 * TerminatingRouting.splitTerminatingRoutingForDP(termObj, dbCon); } }
	 * return true; }
	 */
	/**
	 * The method to modify the Location record.
	 * 
	 * Location Id should be set before calling this method.
	 * 
	 * @return true Record has been updated SUCCESSFULLY false Location Id
	 *         missing / Record update Unsuccessful / Some Error occured.
	 */
	public boolean modifyInDB() throws SQLException, Exception {
		// try
		// {
		if (locationId == null || "".equalsIgnoreCase(locationId)) {
			setStatus(InvErrorCode.MISSING_LOCATION_ID);
			System.out
					.println("FAILURE in modifyInDB Location. Location Id missing.");
			return false;
		}
		DBTblLocation locationDbBean = getLocationToUpdate();
		log.info("Got Location Details to Update for locationId:"
				+ locationId);
		locationDbBean.whereLocationIdEQ(locationId);
		log.info("Going to Update Location in DB");
		FkValidationUtil.isValidLocationForMod(dbCon, locationDbBean);
		if (locationDbBean.updateSpByWhere(dbCon) <= 0) {
			log.info("No Location updated");
			setStatus(InvErrorCode.NO_LOCATION_UPDATED);
			return false;
		}
		log.info("Successfully updated Location");
		/*
		 * } catch (SQLException s) { s.printStackTrace();
		 * setStatus(InvErrorCode.DB_EXCEPTION);
		 * log.info("DB_FAILURE in modifyInDB Location: " +
		 * s.getMessage()); return false; } catch(Exception e) {
		 * e.printStackTrace(); setStatus(InvErrorCode.DB_EXCEPTION);
		 * log.info("Exception in modifyInDB Location: "+ e.toString()
		 * ); return false; }
		 */

		if (entBillFeatBeanList != null) {
			log.info("Sizeof list = " + entBillFeatBeanList.size());
			for (int i = 0; i < entBillFeatBeanList.size(); i++) {
				TblEntBillFeaturesBean entBillFeatBean = entBillFeatBeanList
						.get(i);
				TblEntBillFeatures entBillFeat = new TblEntBillFeatures(dbCon);
				entBillFeat.setFeatureInstanceId(entBillFeatBean
						.getFeatureInstanceId());
				if (entBillFeatBean.getEnterpriseId() != null)
					entBillFeat.setEnterpriseId(entBillFeatBean
							.getEnterpriseId());
				if (entBillFeatBean.getLocationId() != null)
					entBillFeat.setLocationId(entBillFeatBean.getLocationId());
				if (entBillFeatBean.getFeatureCode() != null)
					entBillFeat
							.setFeatureCode(entBillFeatBean.getFeatureCode());
				if (entBillFeatBean.getPbli() != null)
					entBillFeat.setPbli(entBillFeatBean.getPbli());
				if (entBillFeatBean.getChargeType() != null)
					entBillFeat.setChargeType(entBillFeatBean.getChargeType());
				if (entBillFeatBean.getChargeFrequency() != null)
					entBillFeat.setChargeFrequency(entBillFeatBean
							.getChargeFrequency());
				if (entBillFeatBean.getUnitOfMeasure() != null)
					entBillFeat.setUnitOfMeasure(entBillFeatBean
							.getUnitOfMeasure());
				if (entBillFeatBean.getBillTime() != null)
					entBillFeat.setBillTime(entBillFeatBean.getBillTime());
				if (entBillFeatBean.getCatalogueReferenceTime() != null)
					entBillFeat.setCatalogueReferenceTime(entBillFeatBean.getCatalogueReferenceTime());
				if (entBillFeatBean.getFeatureType() != 0)
					entBillFeat.setFeatureType(entBillFeatBean.getFeatureType());
				TblEntBillFeaturesQuery locBillQry = new TblEntBillFeaturesQuery();
				locBillQry.whereFeatureInstanceIdEQ(entBillFeatBean
						.getFeatureInstanceId());
				locBillQry.query(dbCon);
				if (locBillQry.size() == 1) {
					if (entBillFeat.modifyInDB()) {
						setLogTrail("TblEntBillFeature Record updated to DB");
					} else {
						setLogTrail("Failed to update Record to TblEntBillFeatures");
						return false;
					}
				} else {
					if (entBillFeat.addToDB()) {
						setLogTrail("TblEntBillFeature Record inserted into DB");
					} else {
						setLogTrail("Failed to insert Record to TblEntBillFeatures");
						return false;
					}
				}
			}
		}
		setStatus(InvErrorCode.SUCCESS);
		log.info("Successfully UPDATED Location into the DB");
		return true;
	}

	/**
	 * The current Location details are extracted using getDetails() and the new
	 * field values are updated over that. The method will update the fields
	 * that are supplied on the current instance iff they are different from the
	 * default values for the respective field.
	 * 
	 * @return The Location to be updated.
	 */
	private DBTblLocation getLocationToUpdate() throws SQLException {
		DBTblLocation locationDbBean = new DBTblLocation();
		/*
		 * Create a new instance of LocationBean. The new instance would hold
		 * default values for the all the Location fields.
		 */
		LocationBean defaultLocationBean = new LocationBean();
		Location inputLocation = this;
		locationDbBean.setLocationId(locationId);
		TblLocationQuery locQry = new TblLocationQuery();
		locQry.whereLocationIdEQ(inputLocation.getLocationId());
		locQry.query(dbCon);

		if (inputLocation.getEnterpriseId() != null
				&& !inputLocation.getEnterpriseId().equals(
						defaultLocationBean.getEnterpriseId())) {
			locationDbBean.setEnterpriseId(inputLocation.getEnterpriseId());
		}
		if (inputLocation.getOrderSource() != null
				&& !inputLocation.getOrderSource().equals(
						defaultLocationBean.getOrderSource())) {
			if (inputLocation.getOrderSource().equals(""))
				locationDbBean.setOrderSourceNull();
			else
				locationDbBean.setOrderSource(inputLocation.getOrderSource());
		}
		if (inputLocation.getLocationName() != null
				&& !inputLocation.getLocationName().equals(
						defaultLocationBean.getLocationName())) {
			locationDbBean.setLocationName(inputLocation.getLocationName()
					.trim());
		}
		if (inputLocation.getLocAddress() != null
				&& !inputLocation.getLocAddress().equals(
						defaultLocationBean.getLocAddress())) {
			if (inputLocation.getLocAddress().equals(""))
				locationDbBean.setLocAddressNull();
			else
				locationDbBean.setLocAddress(inputLocation.getLocAddress());
		}
		if (inputLocation.getLocCity() != null
				&& !inputLocation.getLocCity().equals(
						defaultLocationBean.getLocCity())) {
			if (inputLocation.getLocCity().equals(""))
				locationDbBean.setLocCityNull();
			else
				locationDbBean.setLocCity(inputLocation.getLocCity());
		}
		if (inputLocation.getLocState() != null
				&& !inputLocation.getLocState().equals(
						defaultLocationBean.getLocState())) {
			if (inputLocation.getLocState().equals(""))
				locationDbBean.setLocStateNull();
			else
				locationDbBean.setLocState(inputLocation.getLocState());
		}
		if (inputLocation.getLocZip() != null
				&& !inputLocation.getLocZip().equals(
						defaultLocationBean.getLocZip())) {
			if (inputLocation.getLocZip().equals(""))
				locationDbBean.setOrderSourceNull();
			else
				locationDbBean.setLocZip(inputLocation.getLocZip());
		}
		if (inputLocation.getLocCountry() != null
				&& !inputLocation.getLocCountry().equals(
						defaultLocationBean.getLocCountry())) {
			locationDbBean.setLocCountry(inputLocation.getLocCountry());
		}
		if (inputLocation.getNpaNxx() != null
				&& !inputLocation.getNpaNxx().equals(
						defaultLocationBean.getNpaNxx())) {
			if (inputLocation.getNpaNxx().equals(""))
				locationDbBean.setNpanxxNull();
			else
				locationDbBean.setNpanxx(inputLocation.getNpaNxx());
		}
		// JAN 2013 Release - E2EI
		if (inputLocation.getPhysicalLocationId() != null
				&& !inputLocation.getPhysicalLocationId().equals(
						defaultLocationBean.getPhysicalLocationId())) {
			if (inputLocation.getPhysicalLocationId().equals(""))
				locationDbBean.setPhysicalLocationIdNull();
			else
				locationDbBean.setPhysicalLocationId(inputLocation
						.getPhysicalLocationId());
		}
		log.info("Successfully set PhysicalLocationId: "
				+ locationDbBean.getPhysicalLocationId());
		if (inputLocation.getPhysicalLocationName() != null
				&& !inputLocation.getPhysicalLocationName().equals(
						defaultLocationBean.getPhysicalLocationName())) {
			if (inputLocation.getPhysicalLocationName().equals(""))
				locationDbBean.setPhysicalLocationNameNull();
			else
				locationDbBean.setPhysicalLocationName(inputLocation
						.getPhysicalLocationName());
		}
		log.info("Successfully set PhysicalLocationName: "
				+ locationDbBean.getPhysicalLocationName());
		if (inputLocation.getDialingCountryCode() != null
				&& !inputLocation.getDialingCountryCode().equals(
						defaultLocationBean.getDialingCountryCode())) {
			if (inputLocation.getDialingCountryCode().equals(""))
				locationDbBean.setDialingCountryCodeNull();
			else
				locationDbBean.setDialingCountryCode(inputLocation
						.getDialingCountryCode());
		}
		log.info("Successfully set DialingCountryCode: "
				+ locationDbBean.getDialingCountryCode());

		if (inputLocation.getCallFwdPlanName() != null
				&& !inputLocation.getCallFwdPlanName().equals(
						defaultLocationBean.getCallFwdPlanName())) {
			if (inputLocation.getCallFwdPlanName().equals("")) {
				log.info("CallFwdPlanNameNull");
				locationDbBean.setCallFwdPlanNameNull();
			} else
				locationDbBean.setCallFwdPlanName(inputLocation
						.getCallFwdPlanName());
		}
		log.info("inputLocation.getCallFwdPlanName() "
				+ inputLocation.getCallFwdPlanName());
		log.info("Successfully set current Timezone: "
				+ locationDbBean.getTimeZone());
		if (inputLocation.getTimeZone() != null
				&& !inputLocation.getTimeZone().equals(
						defaultLocationBean.getTimeZone())) {
			if (inputLocation.getTimeZone().equals(""))
				locationDbBean.setTimeZoneNull();
			else
				locationDbBean
						.setTimeZone(new Long(inputLocation.getTimeZone()));
			log.info("Setting time zone: "
					+ inputLocation.getTimeZone());
		}
		log.info("Successfully set Timezone: "
				+ locationDbBean.getTimeZone());
		if (inputLocation.getUseDaylightSaving() != defaultLocationBean
				.getUseDaylightSaving()) {
			locationDbBean.setUseDaylightSavings(inputLocation
					.getUseDaylightSaving());
		}
		if (inputLocation.getWebLang() != defaultLocationBean.getWebLang()) {
			locationDbBean.setWebLang(inputLocation.getWebLang());
		}
		if (inputLocation.getEnterpriseTrunkId() != defaultLocationBean
				.getEnterpriseTrunkId()) {
			locationDbBean.setEnterpriseTrunkId(inputLocation
					.getEnterpriseTrunkId());
		}
		if (inputLocation.getTsoMigLock() != defaultLocationBean
				.getTsoMigLock()) {
			locationDbBean.setTsoMigLock(inputLocation.getTsoMigLock());
		}

		log.info("Successfully set EnterpriseTrunkId: "
				+ locationDbBean.getEnterpriseTrunkId());

		if (inputLocation.getPqInstanceId() != defaultLocationBean
				.getPqInstanceId()) {
			locationDbBean.setPqInstanceId(inputLocation.getPqInstanceId());
		}

		// added by z658915 starts
		if (inputLocation.getUiProvFlag() != defaultLocationBean.getUiProvFlag()) {
			locationDbBean.setUiProvFlag(inputLocation.getUiProvFlag());
		}
		// added by z658915 ends

		// added by z658915 starts for calnet changes
		if (inputLocation.getCalnetSubContractId() != defaultLocationBean.getCalnetSubContractId()) {
			locationDbBean.setCalnetSubContractId(inputLocation.getCalnetSubContractId());
		}
		// added by z658915 ends for calnet changes

		if (inputLocation.getIsrDesignId() != defaultLocationBean
				.getIsrDesignId()) {
			locationDbBean.setIsrDesignId(inputLocation.getIsrDesignId());
		}

		if (inputLocation.getVmLang() != defaultLocationBean.getVmLang()) {
			log.info("InputLocation: " + inputLocation.getVmLang());
			locationDbBean.setVmLang(inputLocation.getVmLang());
		}
		log.info("Set VMLang: " + locationDbBean.getVmLang());
		if (inputLocation.getVmType() != defaultLocationBean.getVmType()) {
			log.info("InputLocation: " + inputLocation.getVmType());
			if (inputLocation.getVmType() > 0)
				locationDbBean.setVmType(inputLocation.getVmType());
			else
				locationDbBean.setVmTypeNull();
		}
		log.info("Set VMType: " + locationDbBean.getVmType());
		if (inputLocation.getVmSmdiAuthToggle() != defaultLocationBean
				.getVmSmdiAuthToggle()) {
			log.info("InputLocation: "
					+ inputLocation.getVmSmdiAuthToggle());

			if (inputLocation.getVmSmdiAuthToggle() > 0)
				locationDbBean.setVmSmdiAuthToggle(inputLocation
						.getVmSmdiAuthToggle());
			else
				locationDbBean.setVmSmdiAuthToggleNull();
		}
		log.info("Set VM SMDI Auth Toggle: "
				+ locationDbBean.getVmSmdiAuthToggle());
		if (inputLocation.getVmCpeIpAddress() != null
				&& !inputLocation.getVmCpeIpAddress().equals(
						defaultLocationBean.getVmCpeIpAddress())) {
			log.info("InputLocation: "
					+ inputLocation.getVmCpeIpAddress());
			if (inputLocation.getVmCpeIpAddress().equals(""))
				locationDbBean.setVmCpeIpAddressNull();
			else

				locationDbBean.setVmCpeIpAddress(inputLocation
						.getVmCpeIpAddress());
		}
		System.out
				.println("Set VMCPEIP: " + locationDbBean.getVmCpeIpAddress());

		if (inputLocation.getIxPlusId() != defaultLocationBean.getIxPlusId()) {
			locationDbBean.setIxplusId(inputLocation.getIxPlusId());
		}
		if (inputLocation.getIxPlusEnvId() != null
				&& !inputLocation.getIxPlusEnvId().equals(
						defaultLocationBean.getIxPlusEnvId())) {
			if (inputLocation.getIxPlusEnvId().equals(""))
				locationDbBean.setIxplusEnvIdNull();
			else
				locationDbBean.setIxplusEnvId(inputLocation.getIxPlusEnvId());
		}
		// IR#1430572 for NonRivLocation
		// For NovRivLocation, shell account will be created only on
		// tbl_enterprise,tbl_location
		log.info(" RivLocation " + inputLocation.getRivLocation());
		if (inputLocation.getRivLocation() != VzbVoipEnum.YesNoType.N) {
			if (inputLocation.getBillTnPoolId() > 0) {
				locationDbBean.setBtnPoolId(inputLocation.getBillTnPoolId());
				locationDbBean.setEmerPoolId((int) inputLocation
						.getBillTnPoolId());
			} else if (inputLocation.getBillTn() != null
					&& !inputLocation.getBillTn().trim()
							.equals(defaultLocationBean.getBillTn())) {
				if (inputLocation.getBillTn().trim().equals("")) {
					locationDbBean.setBtnPoolIdNull();
					locationDbBean.setEmerPoolIdNull();
				} else {
					// Check if the pool entry is already there for this tn.
					long billTnPoolId = getTnPoolIdByTn(getBillTn());
					if (billTnPoolId > 0) {
						locationDbBean.setBtnPoolId(billTnPoolId);
						locationDbBean.setEmerPoolId((int) billTnPoolId);

					} else {
						billTnPoolId = addToPublicPool(billTn,
								VzbVoipEnum.TnStatus.AVAILABLE,
								VzbVoipEnum.TnType.RES, VzbVoipEnum.YesNoType.N);
						if (billTnPoolId > 0) {
							locationDbBean.setBtnPoolId(billTnPoolId);
							locationDbBean.setEmerPoolId((int) billTnPoolId);
							setLogTrail("Added  Billing Tn/EmergencyCallLine to DB:"
									+ billTn);
						} else {
							log.info("Failed to Add Bill Tn");
							setLogTrail("Failed to Add Billing Tn/EmergencyCallLine to DB:"
									+ billTn);
						}
					}
				}
			}

			// STN Code here
			log.info("inputLocation.getSTnPoolId():"
					+ inputLocation.getSTnPoolId());
			if (inputLocation.getSTnPoolId() > 0) {
				locationDbBean.setStnPoolId(inputLocation.getSTnPoolId());
				// locationDbBean.setEmerPoolId((int)inputLocation.getSTnPoolId());
				DBTblPublicTnPool dbPnp = new DBTblPublicTnPool();
				dbPnp.whereTnPoolIdEQ((int) inputLocation.getSTnPoolId());
				dbPnp.setStnInd(VzbVoipEnum.YesNoType.Y);
				dbPnp.updateSpByWhere(dbCon);
				setLogTrail("Successfully set stn_ind to: Y for new STN.");
				
			} else if (inputLocation.getSTn() != null
					&& !inputLocation.getSTn().trim()
							.equals(defaultLocationBean.getSTn())) {
				log.info("inputLocation.getSTn():"
						+ inputLocation.getSTn());
				log.info(" Screened Tn:" + sTn);

				if (inputLocation.getSTn().trim().equals("")) {

					locationDbBean.setStnPoolIdNull();
					System.out
							.println(" inputLocation.getSTnPoolId() : setting null "
									+ inputLocation.getSTnPoolId());

				} else {
					// Check if the pool entry is already there for this tn.
					long sTnPoolId = getTnPoolIdByTn(getSTn());
					log.info("sTnPoolId : Getting from DB "
							+ sTnPoolId);
					if (sTnPoolId > 0) {
						locationDbBean.setStnPoolId(sTnPoolId);
						// need to set the stn_ind=Y in PNP
						DBTblPublicTnPool dbPnp = new DBTblPublicTnPool();
						dbPnp.whereTnPoolIdEQ((int) sTnPoolId);
						dbPnp.setStnInd(VzbVoipEnum.YesNoType.Y);
						dbPnp.updateSpByWhere(dbCon);
						setLogTrail("Successfully set stn_ind to: Y for new STN.");
						System.out
								.println("Successfully set stn_ind to: Y for new STN.");

					} else {
						sTnPoolId = addToPublicPool(sTn,
								VzbVoipEnum.TnStatus.AVAILABLE,
								VzbVoipEnum.TnType.RES, VzbVoipEnum.YesNoType.Y);
						log.info("sTnPoolId: Creating new from DB "
								+ sTnPoolId);
						if (sTnPoolId > 0) {
							locationDbBean.setStnPoolId(sTnPoolId);
							// locationDbBean.setEmerPoolId((int)billTnPoolId);
							setLogTrail("Added  Screened Tn to DB:" + sTn);
						} else {
							log.info("Failed to Add Screened Tn");
							setLogTrail("Failed to Add Screened Tn to DB:"
									+ sTn);
						}
					}
				}
				// In the MOD, STN with action (n) is taken careof, now takecare
				// old STN if exist
				if (locQry.size() > 0) {
					long oldStnPoolId = locQry.getDbBean(0).getStnPoolId();
					if (oldStnPoolId > 0) {
						// old STN exist, takecare of that
						DBTblPublicTnPool dbPnp = new DBTblPublicTnPool();
						dbPnp.whereTnPoolIdEQ((int) oldStnPoolId);
						dbPnp.setStnInd(VzbVoipEnum.YesNoType.N);
						dbPnp.updateSpByWhere(dbCon);
						setLogTrail("Successfully set stn_ind to: N for old STN.");
						System.out
								.println("Successfully set stn_ind to: N for old STN.");
					} else {
						log.info("No old STN found.");
					}
				}
			}
		}
		if (inputLocation.getBillType() != defaultLocationBean.getBillType()) {
			locationDbBean.setBillType(inputLocation.getBillType());
		}

		log.info("inputLocation.getNetcomServiceId()====>"
				+ inputLocation.getNetcomServiceId());
		log.info("defaultLocationBean.getNetcomServiceId()====>"
				+ defaultLocationBean.getNetcomServiceId());

		if (inputLocation.getNetcomServiceId() != null
				&& !inputLocation.getNetcomServiceId().equals(
						defaultLocationBean.getNetcomServiceId())) {
			if (inputLocation.getNetcomServiceId().equals(""))
				locationDbBean.setNetcomServiceIdNull();
			else
				locationDbBean.setNetcomServiceId(inputLocation
						.getNetcomServiceId());
		}
		if (inputLocation.getCv2Service() != defaultLocationBean
				.getCv2Service()) {
			locationDbBean.setCv2Service(inputLocation.getCv2Service());
		}
		log.info(" ######################################### ");
		log.info("inputLocation.getManagedService()   "
				+ inputLocation.getManagedService());
		log.info("defaultLocationBean.getManagedService()  "
				+ defaultLocationBean.getManagedService());
		log.info(" ######################################### ");

		if (inputLocation.getManagedService() != defaultLocationBean
				.getManagedService()) {
			locationDbBean.setManagedService(inputLocation.getManagedService());
		}
		if (inputLocation.getServiceTypeOffering() != defaultLocationBean
				.getServiceTypeOffering()) {
			locationDbBean.setServiceTypeOffering(inputLocation
					.getServiceTypeOffering());
		}
		if (inputLocation.getHybridServiceType() != defaultLocationBean
				.getHybridServiceType()) {
			if (inputLocation.getHybridServiceType() > 0)
				locationDbBean.setHybridServiceType(inputLocation
						.getHybridServiceType());
			else
				locationDbBean.setHybridServiceTypeNull();
			// Determine what packages need to be added/deleted to/from loc
			// package
			// IR#1430572 for NonRivLocation
			// For NovRivLocation, shell account will be created only on
			// tbl_enterprise,tbl_location
			if (inputLocation.getRivLocation() != VzbVoipEnum.YesNoType.N) {
				long pkgId = 0;
				if (inputLocation.getHybridServiceType() == VzbVoipEnum.HybridServiceType.IP_INTEGRATED_ACCESS_PBX
						|| inputLocation.getHybridServiceType() == VzbVoipEnum.HybridServiceType.IP_TRUNKING) {
					if (locQry.size() > 0) {
						if (locQry.getDbBean(0).getHybridServiceType() != VzbVoipEnum.HybridServiceType.IP_INTEGRATED_ACCESS_PBX
								&& locQry.getDbBean(0).getHybridServiceType() != VzbVoipEnum.HybridServiceType.IP_TRUNKING) {
							// Add Pbx
							System.out
									.println("Adding PBX pkg for hybrid location");
							pkgId = 5;
							if (addLocPackage(pkgId) != true) {
								System.out
										.println("Failed to Add Loc Package. Package Id ["
												+ pkgId + "]");
							}
							if (locQry.getDbBean(0).getFmcgLocationType() == VzbVoipEnum.FmcgLocationType.VOIP_FMCG
									|| inputLocation.getFmcgLocationType() == VzbVoipEnum.FmcgLocationType.VOIP_FMCG) {
								System.out
										.println("Adding FMCG PBX pkg for hybrid location");
								pkgId = 8;
								if (addLocPackage(pkgId) != true) {
									System.out
											.println("Failed to Add Loc Package. Package Id ["
													+ pkgId + "]");
								}
							}

						}
						if (locQry.getDbBean(0).getHybridServiceType() == VzbVoipEnum.HybridServiceType.IP_INTEGRATED_ACCESS_KEY) {
							// delete Key
							pkgId = 6;
							if (deleteLocPkg(pkgId) != true) {
								System.out
										.println("Failed to delete Loc Package. Package Id ["
												+ pkgId + "]");
							}
						}
					}
				}
				if (inputLocation.getHybridServiceType() == VzbVoipEnum.HybridServiceType.IP_INTEGRATED_ACCESS_KEY) {
					if (locQry.size() > 0) {
						if (locQry.getDbBean(0).getHybridServiceType() != VzbVoipEnum.HybridServiceType.IP_INTEGRATED_ACCESS_KEY) {
							// Add Key
							pkgId = 6;
							if (addLocPackage(pkgId) != true) {
								System.out
										.println("Failed to Add Loc Package. Package Id ["
												+ pkgId + "]");
							}

						}
						if (locQry.getDbBean(0).getHybridServiceType() == VzbVoipEnum.HybridServiceType.IP_INTEGRATED_ACCESS_PBX
								|| locQry.getDbBean(0).getHybridServiceType() == VzbVoipEnum.HybridServiceType.IP_TRUNKING) {
							// delete Pbx
							pkgId = 5;
							if (deleteLocPkg(pkgId) != true) {
								System.out
										.println("Failed to delete Loc Package. Package Id ["
												+ pkgId + "]");
							}
							if (locQry.getDbBean(0).getFmcgLocationType() == VzbVoipEnum.FmcgLocationType.VOIP_FMCG) {
								pkgId = 8;
								if (deleteLocPkg(pkgId) != true) {
									System.out
											.println("Failed to delete Loc Package. Package Id ["
													+ pkgId + "]");
								}
							}
						}
					}
				}
				if (inputLocation.getHybridServiceType() <= 0) {
					if (locQry.size() > 0) {
						if (locQry.getDbBean(0).getHybridServiceType() == VzbVoipEnum.HybridServiceType.IP_INTEGRATED_ACCESS_KEY) {
							// delete Key
							pkgId = 6;
							if (deleteLocPkg(pkgId) != true) {
								System.out
										.println("Failed to delete Loc Package. Package Id ["
												+ pkgId + "]");
							}
						}
						if (locQry.getDbBean(0).getHybridServiceType() == VzbVoipEnum.HybridServiceType.IP_INTEGRATED_ACCESS_PBX
								|| locQry.getDbBean(0).getHybridServiceType() == VzbVoipEnum.HybridServiceType.IP_TRUNKING) {
							// delete Pbx
							pkgId = 5;
							if (deleteLocPkg(pkgId) != true) {
								System.out
										.println("Failed to delete Loc Package. Package Id ["
												+ pkgId + "]");
							}
							if (locQry.getDbBean(0).getFmcgLocationType() == VzbVoipEnum.FmcgLocationType.VOIP_FMCG) {
								pkgId = 8;
								if (deleteLocPkg(pkgId) != true) {
									System.out
											.println("Failed to delete Loc Package. Package Id ["
													+ pkgId + "]");
								}
							}
						}
					}
				}

			}
		}
		if (inputLocation.getVoipServiceType() != defaultLocationBean
				.getVoipServiceType()) {
			if (inputLocation.getVoipServiceType() > 0)
				locationDbBean.setVoipServiceType(inputLocation
						.getVoipServiceType());
			else
				locationDbBean.setVoipServiceTypeNull();
		}
		if (inputLocation.getAccessType() != defaultLocationBean
				.getAccessType()) {
			locationDbBean.setAccessType(inputLocation.getAccessType());
		}
		if (inputLocation.getCircuitId() != null
				&& !inputLocation.getCircuitId().equals(
						defaultLocationBean.getCircuitId())) {
			if (inputLocation.getCircuitId().equals(""))
				locationDbBean.setCircuitIdNull();
			else
				locationDbBean.setCircuitId(inputLocation.getCircuitId());
		}
		if (inputLocation.getUunetSiteId() != null
				&& !inputLocation.getUunetSiteId().equals(
						defaultLocationBean.getUunetSiteId())) {
			if (inputLocation.getUunetSiteId().equals(""))
				locationDbBean.setUunetSiteIdNull();
			else
				locationDbBean.setUunetSiteId(inputLocation.getUunetSiteId());
		}
		if (inputLocation.getSipDomain() != null
				&& !inputLocation.getSipDomain().equals(
						defaultLocationBean.getSipDomain())) {
			if (inputLocation.getSipDomain().equals(""))
				locationDbBean.setSipDomainNull();
			else
				locationDbBean.setSipDomain(inputLocation.getSipDomain());
		}
		if (inputLocation.getSipEnabled() != defaultLocationBean
				.getSipEnabled()) {
			locationDbBean.setSipEnabled(inputLocation.getSipEnabled());
		}
		if (inputLocation.getSbcInd() != defaultLocationBean.getSbcInd()) {
			locationDbBean.setSbcInd(inputLocation.getSbcInd());
		}
		if (inputLocation.getSbcId() != defaultLocationBean.getSbcId()) {
			if (inputLocation.getSbcId() > 0)
				locationDbBean.setSbcId(inputLocation.getSbcId());
			else
				locationDbBean.setSbcIdNull();
		}
		if (inputLocation.getDefaultGtwyDpid() != defaultLocationBean
				.getDefaultGtwyDpid()) {
			locationDbBean.setDefaultGtwyDpid(inputLocation
					.getDefaultGtwyDpid());
		}
		if (inputLocation.getPublicGtwyDpid() != defaultLocationBean
				.getPublicGtwyDpid()) {
			locationDbBean.setPublicGtwyDpid(inputLocation.getPublicGtwyDpid());
		}

		// May 2011 - 2CLI changes- start
		if (inputLocation.getAlternativeCallerIdInd() != defaultLocationBean
				.getAlternativeCallerIdInd()) {
			locationDbBean.setAlternetCallerId(inputLocation
					.getAlternativeCallerIdInd());
		}
		// May 2011 - 2CLI changes- end

		// 53938.AA Business Continuity Ph 1 - changes for july 2011
		if (inputLocation.getVarrsFlag() != defaultLocationBean.getVarrsFlag()) {
			locationDbBean.setVarrsFlag(inputLocation.getVarrsFlag());
		}

		if (inputLocation.getRestrictedAccess() != defaultLocationBean
				.getRestrictedAccess()) {
			locationDbBean.setRestrictedAccess(inputLocation
					.getRestrictedAccess());
		}

		if (inputLocation.getE911Service() != defaultLocationBean
				.getE911Service()) {
			locationDbBean.setE911Service((short) inputLocation
					.getE911Service());
		}

		log.info("#######In the Modify Method######");
		log.info("inputLocation.getTrunkType() ====== > "
				+ inputLocation.getTrunkType());
		log.info("defaultLocationBean.getTrunkType() ====== > "
				+ defaultLocationBean.getTrunkType());
		if (inputLocation.getTrunkType() != defaultLocationBean.getTrunkType()) {
			// 0 is a valid value
			locationDbBean.setTrunkType(inputLocation.getTrunkType());
		}
		if (inputLocation.getVoipClub() != defaultLocationBean.getVoipClub()) {
			locationDbBean.setVoipClub(inputLocation.getVoipClub());
			if (inputLocation.getVoipClub() == VzbVoipEnum.YesNoType.Y) {
				locationDbBean.setPubIp(voipClub);
			}
		}
		if ((inputLocation.getVoipClub() != VzbVoipEnum.YesNoType.Y)
				&& (inputLocation.getPubIp() != defaultLocationBean.getPubIp())) {
			locationDbBean.setPubIp(inputLocation.getPubIp());
		}
		if (inputLocation.getServiceLevel() != defaultLocationBean
				.getServiceLevel()) {
			if (inputLocation.getServiceLevel() > 0)
				locationDbBean.setServiceLevel(inputLocation.getServiceLevel());
		}
		if (inputLocation.getLocMarket() != defaultLocationBean.getLocMarket()) {
			if (inputLocation.getLocMarket() > 0)
				locationDbBean.setLocMarket(inputLocation.getLocMarket());
			else
				locationDbBean.setLocMarketNull();
		}
		if (inputLocation.getMaxExtLength() != defaultLocationBean
				.getMaxExtLength()) {
			locationDbBean.setMaxExtLength(inputLocation.getMaxExtLength());
		}
		if (inputLocation.getExtLength() != defaultLocationBean.getExtLength()) {
			locationDbBean.setExtLength(inputLocation.getExtLength());
		}
		if (inputLocation.getPrivateNumLength() != defaultLocationBean
				.getPrivateNumLength()) {
			locationDbBean.setPrivateNumLength(inputLocation
					.getPrivateNumLength());
		}
		if (inputLocation.getLinePortLength() != defaultLocationBean
				.getLinePortLength()) {
			locationDbBean.setLinePortLength(inputLocation.getLinePortLength());
		}
		//CLIN Changes -start
		if (inputLocation.getClin() != null
				&& !inputLocation.getClin().equals(
						defaultLocationBean.getClin())) {
			if (inputLocation.getClin().equals(""))
				locationDbBean.setClinNull();
			else
				locationDbBean.setClin(inputLocation
						.getClin());
		}
		log.info("Set CLIN: "
				+ locationDbBean.getClin());
		//CLIN Changes -end
		if (inputLocation.getAbbrDialingCode() != null
				&& !inputLocation.getAbbrDialingCode().equals(
						defaultLocationBean.getAbbrDialingCode())) {
			if (inputLocation.getAbbrDialingCode().equals(""))
				locationDbBean.setAbbrDialingCodeNull();
			else
				locationDbBean.setAbbrDialingCode(inputLocation
						.getAbbrDialingCode());
		}
		log.info("Set abbr Dialing: "
				+ locationDbBean.getAbbrDialingCode());
		// TODO
		// locationDbBean.setEnableCallPark(enableCallPark);
		if (inputLocation.getEnableCallPark() != defaultLocationBean
				.getEnableCallPark()) {
			locationDbBean.setEnableCallPark(inputLocation.getEnableCallPark());
		}

		log.info("Changed Value getOverrideCidNum ====>"
				+ inputLocation.getOverrideCidNum());
		if (inputLocation.getOverrideCidNum() != defaultLocationBean
				.getOverrideCidNum()) {
			locationDbBean.setOverrideCidNum(inputLocation.getOverrideCidNum());
		}
		log.info("Changed Value getOverrideCidName ====>"
				+ inputLocation.getOverrideCidName());
		if (inputLocation.getOverrideCidName() != defaultLocationBean
				.getOverrideCidName()) {
			locationDbBean.setOverrideCidName(inputLocation
					.getOverrideCidName());
		}
		log.info("Changed Value getOverrideSubPrivate ====>"
				+ inputLocation.getOverrideSubPrivate());
		if (inputLocation.getOverrideSubPrivate() != defaultLocationBean
				.getOverrideSubPrivate()) {
			locationDbBean.setOverrideSubPrivate(inputLocation
					.getOverrideSubPrivate());
		}

		// TODO
		// locationDbBean.setCidTn(cidTn);
		if (inputLocation.getContactPhone() != null
				&& !inputLocation.getContactPhone().equals(
						defaultLocationBean.getContactPhone())) {
			if (inputLocation.getContactPhone().equals(""))
				locationDbBean.setContactPhoneNull();
			else
				locationDbBean.setContactPhone(inputLocation.getContactPhone());
		}
		log.info("Set contact phone: "
				+ locationDbBean.getContactPhone());
		if (inputLocation.getContactName() != null
				&& !inputLocation.getContactName().equals(
						defaultLocationBean.getContactName())) {
			if (inputLocation.getContactName().equals(""))
				locationDbBean.setContactNameNull();
			else
				locationDbBean.setContactName(inputLocation.getContactName());
		}
		log.info("Set contact Name: "
				+ locationDbBean.getContactName());
		if (inputLocation.getContactEmail() != null
				&& !inputLocation.getContactEmail().equals(
						defaultLocationBean.getContactEmail())) {
			if (inputLocation.getContactEmail().equals(""))
				locationDbBean.setContactEmailNull();
			else
				locationDbBean.setContactEmail(inputLocation.getContactEmail());
		}
		log.info("Set contact Email: "
				+ locationDbBean.getContactEmail());
		if (inputLocation.getActTeamPhone() != null
				&& !inputLocation.getActTeamPhone().equals(
						defaultLocationBean.getActTeamPhone())) {
			if (inputLocation.getActTeamPhone().equals(""))
				locationDbBean.setActTeamPhoneNull();
			else
				locationDbBean.setActTeamPhone(inputLocation.getActTeamPhone());
		}
		log.info("Set ActTeamPhone: "
				+ locationDbBean.getActTeamPhone());
		if (inputLocation.getActTeamName() != null
				&& !inputLocation.getActTeamName().equals(
						defaultLocationBean.getActTeamName())) {
			if (inputLocation.getActTeamName().equals(""))
				locationDbBean.setActTeamNameNull();
			else
				locationDbBean.setActTeamName(inputLocation.getActTeamName());
		}
		log.info("Set ActTeamName : "
				+ locationDbBean.getActTeamName());
		if (inputLocation.getActTeamEmail() != null
				&& !inputLocation.getActTeamEmail().equals(
						defaultLocationBean.getActTeamEmail())) {
			if (inputLocation.getActTeamEmail().equals(""))
				locationDbBean.setActTeamEmailNull();
			else
				locationDbBean.setActTeamEmail(inputLocation.getActTeamEmail());
		}
		log.info("Set ActTeamEmail: "
				+ locationDbBean.getActTeamEmail());
		log.info("defaultLocationBean.getEnableAccountCode()====>"
				+ defaultLocationBean.getEnableAccountCode());
		log.info("inputLocation.getEnableAccountCode()====>"
				+ inputLocation.getEnableAccountCode());
		if (inputLocation.getEnableAccountCode() != defaultLocationBean
				.getEnableAccountCode()) {
			locationDbBean.setEnableAccountCode(inputLocation
					.getEnableAccountCode());
		}
		if (inputLocation.getEnableAuthCode() != null
				&& !inputLocation.getEnableAuthCode().equals(
						defaultLocationBean.getEnableAuthCode())) {
			if (inputLocation.getEnableAuthCode().equals(""))
				locationDbBean.setEnableAuthCodeNull();
			else
				locationDbBean.setEnableAuthCode(inputLocation
						.getEnableAuthCode());
		}
		if (inputLocation.getLocalDirAssistance() != null
				&& !inputLocation.getLocalDirAssistance().equals(
						defaultLocationBean.getLocalDirAssistance())) {
			if (inputLocation.getLocalDirAssistance().equals(""))
				locationDbBean.setLocalDirAssistanceNull();
			else
				locationDbBean.setLocalDirAssistance(inputLocation
						.getLocalDirAssistance());
		}
		if (inputLocation.getNatDirAssistance() != null
				&& !inputLocation.getNatDirAssistance().equals(
						defaultLocationBean.getNatDirAssistance())) {
			if (inputLocation.getNatDirAssistance().equals(""))
				locationDbBean.setNatDirAssistanceNull();
			else
				locationDbBean.setNatDirAssistance(inputLocation
						.getNatDirAssistance());
		}
		if (inputLocation.getConcCallStat() != defaultLocationBean
				.getConcCallStat()) {
			locationDbBean.setConccallStat(inputLocation.getConcCallStat());
		}
		if (inputLocation.getMaxConcurrentCalls() != defaultLocationBean
				.getMaxConcurrentCalls()) {
			locationDbBean.setMaxConcurrentCalls(inputLocation
					.getMaxConcurrentCalls());
		}
		if (inputLocation.getMaxConcurrentOffnet() != defaultLocationBean
				.getMaxConcurrentOffnet()) {
			locationDbBean.setMaxConcurrentOffnet(inputLocation
					.getMaxConcurrentOffnet());
		}
		if (inputLocation.getMaxInbound() != defaultLocationBean
				.getMaxInbound()) {
			locationDbBean.setMaxInbound(inputLocation.getMaxInbound());
		}
		if (inputLocation.getMaxSlg() != defaultLocationBean.getMaxSlg()) {
			locationDbBean.setMaxSlg(inputLocation.getMaxSlg());
		}
		if (inputLocation.getMaxNg() != defaultLocationBean.getMaxNg()) {
			locationDbBean.setMaxNg(inputLocation.getMaxNg());
		}
		if (inputLocation.getMaxSubscribers() != defaultLocationBean
				.getMaxSubscribers()) {
			locationDbBean.setMaxSubscribers(inputLocation.getMaxSubscribers());
		}
		if (inputLocation.getMaxPublicTn() != defaultLocationBean
				.getMaxPublicTn()) {
			locationDbBean.setMaxPublicTn(inputLocation.getMaxPublicTn());
		}
		if (inputLocation.getBlockAllCalls() != defaultLocationBean
				.getBlockAllCalls()) {
			locationDbBean.setBlockAllCalls(inputLocation.getBlockAllCalls());
		}
		if (inputLocation.getRpid() != null
				&& !inputLocation.getRpid().equals(
						defaultLocationBean.getRpid())) {
			if (inputLocation.getRpid().equals(""))
				locationDbBean.setRpidNull();
			else
				locationDbBean.setRpid(inputLocation.getRpid());
		}
		if (inputLocation.getPendingRpid() != null
				&& !inputLocation.getPendingRpid().equals(
						defaultLocationBean.getPendingRpid())) {
			if (inputLocation.getPendingRpid().equals(""))
				locationDbBean.setPendingRpidNull();
			else
				locationDbBean.setPendingRpid(inputLocation.getPendingRpid());
		}
		log.info("Inpur RpidPriv: " + inputLocation.getRpidPriv());
		if (inputLocation.getRpidPriv() != defaultLocationBean.getRpidPriv()) {
			locationDbBean.setRpidPriv(inputLocation.getRpidPriv());
		}
		log.info("Inpur RpidTn: " + inputLocation.getRpidTn());

		// IR#1430572 for NonRivLocation
		// For NovRivLocation, shell account will be created only on
		// tbl_enterprise,tbl_location
		if (inputLocation.getRivLocation() != VzbVoipEnum.YesNoType.N) {
			if (inputLocation.getRpidPoolId() > 0) {
				locationDbBean.setRpidPoolId(inputLocation.getRpidPoolId());
			} else if (inputLocation.getRpidTn() != null
					&& !inputLocation.getRpidTn().trim()
							.equals(defaultLocationBean.getRpidTn())) {
				log.info("In loc modify rpidTn not null");
				if (inputLocation.getRpidTn().trim().equals(""))
					locationDbBean.setRpidPoolIdNull();
				else {
					// Check if the pool entry is already there for this tn.
					long rpidTnPoolId = getTnPoolIdByTn(getRpidTn());
					if (rpidTnPoolId > 0)
						locationDbBean.setRpidPoolId(rpidTnPoolId);
					else {
						rpidTnPoolId = addToPublicPool(rpidTn,
								VzbVoipEnum.TnStatus.AVAILABLE,
								VzbVoipEnum.TnType.RES, VzbVoipEnum.YesNoType.N);
						if (rpidTnPoolId > 0) {
							locationDbBean.setRpidPoolId(rpidTnPoolId);
							setLogTrail("Added  CallingPartyNumber to DB:"
									+ rpidTn);
						} else {
							log.info("Failed to Add rpid Tn");
							setLogTrail("Failed to Add CallingPartyNumber to DB:"
									+ rpidTn);
						}
					}
				}
			}
		}
		if (inputLocation.getHicrService() != defaultLocationBean
				.getHicrService()) {
			locationDbBean.setHicrService(inputLocation.getHicrService());
		}
		// locationDbBean.setPremiseVm(premiseVm);
		// locationDbBean.setVmLang(vmLang);
		if (inputLocation.getMaxVmBox() != defaultLocationBean.getMaxVmBox()) {
			locationDbBean.setMaxVmBox(inputLocation.getMaxVmBox());
		}
		if (inputLocation.getActiveInd() > -1) {
			locationDbBean.setActiveInd(inputLocation.getActiveInd());
		}
		log.info(" locationDbBean.getActiveInd "
				+ locationDbBean.getActiveInd());
		if (inputLocation.getProductionIndicator() != defaultLocationBean
				.getProductionIndicator()) {
			locationDbBean.setProductionIndicator(inputLocation
					.getProductionIndicator());
		}
		log.info(" locationDbBean.getProductionIndicator "
				+ locationDbBean.getProductionIndicator());
		if (inputLocation.getBlockAllCalls() != defaultLocationBean
				.getBlockAllCalls()) {
			locationDbBean.setBlockAllCalls(inputLocation.getBlockAllCalls());
		}
		if (inputLocation.getEnvOrderId() != defaultLocationBean
				.getEnvOrderId()) {
			locationDbBean.setEnvOrderId(inputLocation.getEnvOrderId());
		}
		if (inputLocation.getModifiedBy() != null
				&& !("".equalsIgnoreCase(inputLocation.getModifiedBy()))) {
			locationDbBean.setModifiedBy(inputLocation.getModifiedBy());
		}
		if (inputLocation.getTrunk() != null
				&& !defaultLocationBean.getTrunk().equalsIgnoreCase(
						inputLocation.getTrunk())) {
			if (inputLocation.getTrunk().equals(""))
				locationDbBean.setTrunkNull();
			else

				locationDbBean.setTrunk(inputLocation.getTrunk());
		}
		if (inputLocation.getSwitchClli() != null
				&& !defaultLocationBean.getSwitchClli().equalsIgnoreCase(
						inputLocation.getSwitchClli())) {
			if (inputLocation.getSwitchClli().equals(""))
				locationDbBean.setSwitchClliNull();
			else
				locationDbBean.setSwitchClli(inputLocation.getSwitchClli());
		}
		if (inputLocation.getEmerPoolId() != defaultLocationBean
				.getEmerPoolId()) {
			if (inputLocation.getEmerPoolId() > 0)
				locationDbBean.setEmerPoolId(inputLocation.getEmerPoolId());
			else
				locationDbBean.setEmerPoolIdNull();
		}
		if (inputLocation.getEmerLocationCode() != null
				&& !(defaultLocationBean.getEmerLocationCode()
						.equalsIgnoreCase(inputLocation.getEmerLocationCode()))) {
			if (inputLocation.getEmerLocationCode().equals(""))
				locationDbBean.setEmerLocationCodeNull();
			else
				locationDbBean.setEmerLocationCode(inputLocation
						.getEmerLocationCode());
		}
		log.info("inputLocation.getLocationType()====>"
				+ inputLocation.getLocationType());
		log.info("defaultLocationBean.getLocationType()====>"
				+ defaultLocationBean.getLocationType());

		if (inputLocation.getLocationType() != defaultLocationBean
				.getLocationType()) {
			locationDbBean.setLocationType(inputLocation.getLocationType());
		}
		log.info("inputLocation.getFmcgLocationType()====>"
				+ inputLocation.getFmcgLocationType());
		log.info("defaultLocationBean.getLocationType()====>"
				+ defaultLocationBean.getFmcgLocationType());

		// IR#1430572 for NonRivLocation
		// For NovRivLocation, shell account will be created only on
		// tbl_enterprise,tbl_location
		if (inputLocation.getRivLocation() != VzbVoipEnum.YesNoType.N) {
			if (inputLocation.getFmcgLocationType() != defaultLocationBean
					.getFmcgLocationType()) {
				locationDbBean.setFmcgLocationType(inputLocation
						.getFmcgLocationType());
				long pkgId = 0;
				locationDbBean.setFmcgLocationType(inputLocation
						.getFmcgLocationType());
				if (locQry.size() > 0) {
					long voipServType = locQry.getDbBean(0)
							.getVoipServiceType();
					log.info("inputLocation.getFmcgLocationType():"
							+ inputLocation.getFmcgLocationType());
					if (inputLocation.getFmcgLocationType() == VzbVoipEnum.FmcgLocationType.VOIP_FMCG
							&& (voipServType == VzbVoipEnum.VoipServiceType.IP_INTEGRATED_ACCESS_PBX || voipServType == VzbVoipEnum.VoipServiceType.IP_TRUNKING)) {
						// FMCG_PBX
						pkgId = 8;
						log.info("Adding FMCG_PBX");
						if (addLocPackage(pkgId) != true) {
							System.out
									.println("Failed to Add Loc Package. Package Id ["
											+ pkgId + "]");
						}
					}
					if ((inputLocation.getFmcgLocationType() == VzbVoipEnum.FmcgLocationType.VOIP_FMCG && !(locQry
							.getDbBean(0).getFmcgLocationType() == VzbVoipEnum.FmcgLocationType.FMCG_ONLY))
							|| inputLocation.getFmcgLocationType() == VzbVoipEnum.FmcgLocationType.FMCG_ONLY) {
						log.info("Adding FMCG");
						pkgId = 7;
						if (addLocPackage(pkgId) != true) {
							System.out
									.println("Failed to Add Loc Package. Package Id ["
											+ pkgId + "]");
						}
					}
					if (inputLocation.getFmcgLocationType() == VzbVoipEnum.FmcgLocationType.NONE
							&& (locQry.getDbBean(0).getFmcgLocationType() == VzbVoipEnum.FmcgLocationType.FMCG_ONLY || locQry
									.getDbBean(0).getFmcgLocationType() == VzbVoipEnum.FmcgLocationType.VOIP_FMCG)) {
						log.info("IN down grade block:deleting pkgs");
						DBTblLocPackage locPkgDbBean = new DBTblLocPackage();
						locPkgDbBean.wherePackageIdEQ(7);
						locPkgDbBean.whereLocationIdEQ(locationId);
						int i = locPkgDbBean.deleteByWhere(dbCon);
						System.out
								.println("IN down grade block:deleting pkg 7:"
										+ i);

						DBTblLocPackage locPkgDbBean1 = new DBTblLocPackage();
						locPkgDbBean1.wherePackageIdEQ(8);
						locPkgDbBean1.whereLocationIdEQ(locationId);
						i = locPkgDbBean1.deleteByWhere(dbCon);
						System.out
								.println("IN down grade block:deleting pkg 8:"
										+ i);
					}
					if ((inputLocation.getFmcgLocationType() == VzbVoipEnum.FmcgLocationType.NONE || inputLocation
							.getFmcgLocationType() == VzbVoipEnum.FmcgLocationType.VOIP_FMCG)
							&& locQry.getDbBean(0).getFmcgLocationType() == VzbVoipEnum.FmcgLocationType.FMCG_ONLY) {
						System.out
								.println("IN down grade block frm FMCG_ONLY to NONE adding 2,3,4");
						for (int j = 2; j < 5; j++) {
							pkgId = j;
							if (addLocPackage(pkgId) != true) {
								System.out
										.println("Failed to Add Loc Package. Package Id ["
												+ pkgId + "]");
							}
						}
					}

				}
			}
		}
		// FMCg Phase II Changes
		System.out
				.println("getLocationToUpdate :: Getting TeleworkerFQDN information");
		if (inputLocation.getTeleworkerFqdn() != null
				&& !inputLocation.getTeleworkerFqdn().equals(
						defaultLocationBean.getTeleworkerFqdn())) {
			log.info("getLocationToUpdate :: Adding TeleworkerFQDN");
			if (inputLocation.getTeleworkerFqdn().equals(""))
				locationDbBean.setTwFqdnNull();
			else
				locationDbBean.setTwFqdn(inputLocation.getTeleworkerFqdn());
		}

		if (inputLocation.getTwSbcId() != defaultLocationBean.getTwSbcId()) {
			locationDbBean.setTwSbcId(inputLocation.getTwSbcId());
		}

		if (inputLocation.getHubLocationId() != null
				&& !defaultLocationBean.getHubLocationId().equalsIgnoreCase(
						inputLocation.getHubLocationId())) {
			if (inputLocation.getHubLocationId().equals("")) {
				locationDbBean.setHubLocationIdNull();
			} else {
				if (locQry.getDbBean(0).getLocationType() != VzbVoipEnum.LocationType.HUB
						&& inputLocation.getHubLocationId() != inputLocation
								.getLocationId())
					locationDbBean.setHubLocationId(inputLocation
							.getHubLocationId());
				else
					System.out
							.println("Hub Location Id and Location Id cannot be the same");
			}
		}
		if (inputLocation.getHubGatewayDeviceId() > 0)
			locationDbBean.setHubGatewayDeviceId(inputLocation
					.getHubGatewayDeviceId());
		else
			locationDbBean.setHubGatewayDeviceIdNull();

		if (inputLocation.getLocationMask() != defaultLocationBean
				.getLocationMask()) {
			if (inputLocation.getLocationMask() > 0)
				locationDbBean.setLocationMask(inputLocation.getLocationMask());
		}
		if (inputLocation.getANumMask() != defaultLocationBean.getANumMask()) {
			if (inputLocation.getANumMask() > 0)
				locationDbBean.setANumMask(inputLocation.getANumMask());
			else
				locationDbBean.setANumMaskNull();
		}
		if (inputLocation.getBNumMask() != defaultLocationBean.getBNumMask()) {
			if (inputLocation.getBNumMask() > 0)
				locationDbBean.setBNumMask(inputLocation.getBNumMask());
			else
				locationDbBean.setBNumMaskNull();
		}

		// locationDbBean.setServicePackage(0);
		/**********
		 * During MOD, the Calling Plan ID will not change if
		 * (inputLocation.getCallingPlanId() !=
		 * defaultLocationBean.getCallingPlanId()) { if
		 * (inputLocation.getCallingPlanId() > 1) {
		 * locationDbBean.setCallingPlanId(inputLocation.getCallingPlanId()); }
		 * else { if (serviceTypeOffering == VzbVoipEnum.Platform.IASA) {
		 * locationDbBean.setCallingPlanId(0); } if (serviceTypeOffering ==
		 * VzbVoipEnum.Platform.ICP) { locationDbBean.setCallingPlanId(1); } } }
		 **********************/
		log.info("In Base: OverrideCidNum():"
				+ locationDbBean.getOverrideCidNum());
		log.info("In Base: OverrideCidName():"
				+ locationDbBean.getOverrideCidName());
		log.info("In Base: OverrideSubPrivate():"
				+ locationDbBean.getOverrideSubPrivate());
		log.info("In Base: RpidPriv():"
				+ locationDbBean.getRpidPriv());
		log.info("In Base: RpidPoolId():"
				+ locationDbBean.getRpidPoolId());
		log.info("In Base: Rpid():" + locationDbBean.getRpid());
		log.info("In Base: pendingRpid() :"
				+ locationDbBean.getPendingRpid());

		locationDbBean.setLastModifiedDate(new Timestamp(System
				.currentTimeMillis()));
		log.info("Done setting everything on locationDbBean");

		// Added as per D/b changes
		if (inputLocation.getVpnName() != null
				&& !defaultLocationBean.getVpnName().equalsIgnoreCase(
						inputLocation.getVpnName())) {
			if (inputLocation.getVpnName().equals(""))
				locationDbBean.setVpnNameNull();
			else
				locationDbBean.setVpnName(inputLocation.getVpnName());
		}
		if (inputLocation.getTblVpnIdMappingId() != defaultLocationBean
				.getTblVpnIdMappingId()) {
			locationDbBean.setTblVpnIdMappingId(inputLocation
					.getTblVpnIdMappingId());
		}
		if (inputLocation.getSbcProvMethod() != defaultLocationBean
				.getSbcProvMethod()) {
			locationDbBean.setSbcProvMethod(inputLocation.getSbcProvMethod());
		}

		if (inputLocation.getQosInd() != defaultLocationBean.getQosInd()) {
			locationDbBean.setQosInd(inputLocation.getQosInd());
		}
		if (inputLocation.getAfterHoursInstallFlag() != defaultLocationBean
				.getAfterHoursInstallFlag()) {
			locationDbBean.setAfterHoursInstallFlag(inputLocation
					.getAfterHoursInstallFlag());
		}

		if (inputLocation.getHighVolumeInstallFlag() != defaultLocationBean
				.getHighVolumeInstallFlag()) {
			locationDbBean.setHighVolumeInstallFlag(inputLocation
					.getHighVolumeInstallFlag());
		}

		if (inputLocation.getExpedite() != defaultLocationBean.getExpedite()) {
			locationDbBean.setExpedite(inputLocation.getExpedite());
		}

		if (inputLocation.getLocCclInd() != defaultLocationBean.getLocCclInd()) {
			locationDbBean.setLocCclInd((short) inputLocation.getLocCclInd());
		}
		log.info(" locationDbBean.getLocCclInd "
				+ locationDbBean.getLocCclInd());

		if (inputLocation.getBillingActivated() != defaultLocationBean
				.getBillingActivated()) {
			locationDbBean.setBillingActivated((short) inputLocation
					.getBillingActivated());
		}
		log.info(" locationDbBean.getBillingActivated "
				+ locationDbBean.getBillingActivated());

		if (inputLocation.getConfigAllowed() != defaultLocationBean
				.getConfigAllowed())
			locationDbBean.setConfigAllowed((short) inputLocation
					.getConfigAllowed());

		if (inputLocation.getProductIdentifier() != defaultLocationBean
				.getProductIdentifier())
			locationDbBean.setProductIdentifier(inputLocation
					.getProductIdentifier());

		if (inputLocation.getCallingNameInd() != defaultLocationBean
				.getCallingNameInd()) {
			locationDbBean.setCallingNameInd(inputLocation.getCallingNameInd());
		}
		log.info(" locationDbBean.getCallingNameInd "
				+ locationDbBean.getCallingNameInd());

		if (inputLocation.getEnhancedAniInd() != defaultLocationBean
				.getEnhancedAniInd()) {
			locationDbBean.setEnhancedAniInd(inputLocation.getEnhancedAniInd());
		}
		log.info(" locationDbBean.getEnhancedAniInd "
				+ locationDbBean.getEnhancedAniInd());

		// Jan 2011 Release changes

		if (inputLocation.getBillAccountNumber() != null
				&& !inputLocation.getBillAccountNumber().equals(
						defaultLocationBean.getBillAccountNumber())) {
			locationDbBean.setBillAcctNum(inputLocation.getBillAccountNumber());
		}
		log.info(" locationDbBean.getBillAcctNum() "
				+ locationDbBean.getBillAcctNum());

		if (inputLocation.getLocTerritory() != null
				&& !inputLocation.getLocTerritory().equals(
						defaultLocationBean.getLocTerritory())) {
			locationDbBean.setLocTerritory(inputLocation.getLocTerritory());
		}
		log.info(" locationDbBean.getLocTerritory() "
				+ locationDbBean.getLocTerritory());

		if (inputLocation.getLocRegion() != null
				&& !inputLocation.getLocRegion().equals(
						defaultLocationBean.getLocRegion())) {
			locationDbBean.setLocRegion(inputLocation.getLocRegion());
		}

		log.info(" locationDbBean.getLocRegion() "
				+ locationDbBean.getLocRegion());

		if (inputLocation.getBillingSystem() != defaultLocationBean
				.getBillingSystem()) {
			locationDbBean.setBillingSystem(inputLocation.getBillingSystem());
		}
		if (inputLocation.getSubAgencyHierCode() != defaultLocationBean
				.getSubAgencyHierCode())
			locationDbBean.setSubAgencyHierCode(subAgencyHierCode);

		if (inputLocation.getActiveDate() != null
				&& !inputLocation.getActiveDate().equals(
						defaultLocationBean.getActiveDate())) {
			log.info(" inputLocation.getActiveDate() "
					+ inputLocation.getActiveDate());
			locationDbBean.setActiveDate(inputLocation.getActiveDate());
		}

		log.info(" locationDbBean.getBillingSystem() "
				+ locationDbBean.getBillingSystem());

		if (inputLocation.getHybridAssigned() != defaultLocationBean
				.getHybridAssigned()) {
			locationDbBean.setHybridAssigned(inputLocation.getHybridAssigned());
		}

		if (inputLocation.getE2eimigflag() != defaultLocationBean
				.getE2eimigflag()) {
			locationDbBean.setE2eiMigFlag(inputLocation.getE2eimigflag());
		}

		if (inputLocation.getAddressId() != defaultLocationBean
				.getAddressId()) {
			locationDbBean.setAddressId(inputLocation.getAddressId());
		}
		
		if (inputLocation.getVce() != defaultLocationBean
				.getVce()) {
			locationDbBean.setVceEnabled(inputLocation.getVce());
		}
		
		return locationDbBean;
	}

	public boolean validate() {
		return true;
	}

	// set LocationId member
	public boolean getDetails() {
		try {
			if (locationId == null || "".equals(locationId)) {
				setStatus(InvErrorCode.MISSING_LOCATION_ID);
				System.out
						.println("FAILURE in getDetails Location. Location Id missing.");
				return false;
			}
			clearLocation();
			log.info("In Location getDetails; locationID="
					+ locationId);
			TblLocationQuery locQry = new TblLocationQuery();
			locQry.whereLocationIdEQ(locationId);
			if (getAll == false)
				locQry.whereActiveIndEQ(1);
			else
				locQry.whereActiveIndNE(0);
			locQry.query(dbCon);
			if (locQry.size() == 1) {
				log.info("In getDetails loc1");
				TblLocationDbBean locDbBean = locQry.getDbBean(0);
				setLocationId(locDbBean.getLocationId());
				setEnterpriseId(locDbBean.getEnterpriseId());
				setDialPlanId(locDbBean.getDialPlanId());
				setOrderSource(locDbBean.getOrderSource());
				setLocationName(locDbBean.getLocationName());
				setLocAddress(locDbBean.getLocAddress());
				setLocCity(locDbBean.getLocCity());
				setLocState(locDbBean.getLocState());
				setLocZip(locDbBean.getLocZip());
				setLocCountry(locDbBean.getLocCountry());
				setNpaNxx(locDbBean.getNpanxx());

				// Jan 2013 Release - E2EI
				setPhysicalLocationId(locDbBean.getPhysicalLocationId());
				setPhysicalLocationName(locDbBean.getPhysicalLocationName());
				setDialingCountryCode(locDbBean.getDialingCountryCode());
				setCallFwdPlanName(locDbBean.getCallFwdPlanName());
				setSbcId(locDbBean.getSbcId());
				setSbcInd(locDbBean.getSbcInd());
				setSbcMigInd(locDbBean.getSbcMigInd());
				setSipEnabled(locDbBean.getSipEnabled());
				System.out
						.println("getDetails() - SipEnabled returned  by INV = "
								+ locDbBean.getSipEnabled());
				log.info("In getDetails loc2");
				if (locDbBean.getTimeZone() > 0) {
					setTimeZoneId((int) locDbBean.getTimeZone());
					setTimeZone(VzbVoipEnum.TimeZone.name((int) locDbBean
							.getTimeZone()));
					log.info("In getDetails " + getTimeZone());
				}
				log.info("In getDetails loc5");
				setUseDaylightSaving(locDbBean.getUseDaylightSavings());
				if (locDbBean.getDaylightSavingsRegion() > 0) {
					TblDaylightSavingRegionsQuery dsrQry = new TblDaylightSavingRegionsQuery();
					dsrQry.whereDaylightSavingRegionsIdEQ((int) locDbBean
							.getDaylightSavingsRegion());
					dsrQry.query(dbCon);
					if (dsrQry.size() > 0) {
						String dsr = dsrQry.getDbBean(0).getDescription();
						setDayLightSavingsRegion(dsr);
					} else
						System.out
								.println("Daylight Savings Region Not Found by Id [ "
										+ locDbBean.getDaylightSavingsRegion()
										+ "]");
				}
				if (locDbBean.getWebLang() > 0) {
					setWebLangStr(VzbVoipEnum.Language.acronym((int) locDbBean
							.getWebLang()));
					log.info("In getDetails loc6");
					/*
					 * TblLanguageQuery tblLanguageQry = new TblLanguageQuery();
					 * tblLanguageQry.whereLangCodeEQ((int)
					 * locDbBean.getWebLang()); tblLanguageQry.query(dbCon);
					 * ArrayList langResultList =
					 * tblLanguageQry.getResultArrayList(); if
					 * (langResultList.size() > 0) { TblLanguageDbBean
					 * languageDbBean = (TblLanguageDbBean)
					 * langResultList.get(0);
					 * setWebLangStr(languageDbBean.getLangName());
					 * log.info("In getDetails loc7"); }
					 */
				}
				setWebLang(locDbBean.getWebLang());
				setEnterpriseTrunkId(locDbBean.getEnterpriseTrunkId());
				setTsoMigLock(locDbBean.getTsoMigLock());
				setPqInstanceId(locDbBean.getPqInstanceId());

				setUiProvFlag(locDbBean.getUiProvFlag()); // added by z658915
				setCalnetSubContractId(locDbBean.getCalnetSubContractId()); // added  by z658915

				setIsrDesignId(locDbBean.getIsrDesignId());
				setIxPlusId(locDbBean.getIxplusId());
				setIxPlusEnvId(locDbBean.getIxplusEnvId());
				setBillTnPoolId(locDbBean.getBtnPoolId());
				setBillTn(getTnByTnPoolId(locDbBean.getBtnPoolId()));
				setBillType((int) locDbBean.getBillType());
				// STN Code Here
				setSTnPoolId(locDbBean.getStnPoolId());
				setSTn(getTnByTnPoolId(locDbBean.getStnPoolId()));
				setNetcomServiceId(locDbBean.getNetcomServiceId());
				setCv2Service(locDbBean.getCv2Service());
				setManagedService(locDbBean.getManagedService());
				setServiceTypeOffering(locDbBean.getServiceTypeOffering());
				setVoipServiceType(locDbBean.getVoipServiceType());
				setHybridServiceType(locDbBean.getHybridServiceType());
				setPubIp(locDbBean.getPubIp());
				setCircuitId(locDbBean.getCircuitId());
				setUunetSiteId(locDbBean.getUunetSiteId());
				setSipDomain(locDbBean.getSipDomain());
				setPublicGtwyDpid(locDbBean.getPublicGtwyDpid());
				setDefaultGtwyDpid(locDbBean.getDefaultGtwyDpid());
				setTrunkType(locDbBean.getTrunkType());
				setVoipClub(locDbBean.getVoipClub());
				setServiceLevel(locDbBean.getServiceLevel());
				setLocMarket(locDbBean.getLocMarket());
				setMaxExtLength(locDbBean.getMaxExtLength());
				setExtLength(locDbBean.getExtLength());
				setPrivateNumLength(locDbBean.getPrivateNumLength());
				setLinePortLength(locDbBean.getLinePortLength());
				setClin(locDbBean.getClin());
				setAbbrDialingCode(locDbBean.getAbbrDialingCode());
				setEnableCallPark(locDbBean.getEnableCallPark());
				setOverrideCidNum(locDbBean.getOverrideCidNum());
				setOverrideCidName(locDbBean.getOverrideCidName());
				setEnableAccountCode(locDbBean.getEnableAccountCode());
				setEnableAuthCode(locDbBean.getEnableAuthCode());
				setLocalDirAssistance(locDbBean.getLocalDirAssistance());
				setNatDirAssistance(locDbBean.getNatDirAssistance());
				setConcCallStat(locDbBean.getConccallStat());
				setMaxConcurrentCalls(locDbBean.getMaxConcurrentCalls());
				setMaxConcurrentOffnet(locDbBean.getMaxConcurrentOffnet());
				setMaxInbound(locDbBean.getMaxInbound());
				setMaxSlg(locDbBean.getMaxSlg());
				setMaxNg(locDbBean.getMaxNg());
				setMaxSubscribers(locDbBean.getMaxSubscribers());
				setMaxPublicTn(locDbBean.getMaxPublicTn());
				setBlockAllCalls(locDbBean.getBlockAllCalls());
				setRpid(locDbBean.getRpid());
				setRpidPriv(locDbBean.getRpidPriv());
				setRpidPoolId(locDbBean.getRpidPoolId());
				setPendingRpid(locDbBean.getPendingRpid());
				setRpidTn(getTnByTnPoolId(locDbBean.getRpidPoolId()));
				setHicrService(locDbBean.getHicrService());
				// setPremiseVm(locDbBean.getPremiseVm());
				setCallingPlanId(locDbBean.getCallingPlanId());
				setVmLang(locDbBean.getVmLang());
				setTrunk(locDbBean.getTrunk());
				setSubAgencyHierCode(locDbBean.getSubAgencyHierCode());
				if (locDbBean.getVmLang() > 0) {
					log.info("In getDetails Vm");
					setVmLangStr(VzbVoipEnum.Language.acronym((int) locDbBean
							.getVmLang()));
					/*
					 * TblLanguageQuery tblLanguageQry = new TblLanguageQuery();
					 * tblLanguageQry.whereLangCodeEQ((int)
					 * locDbBean.getVmLang()); tblLanguageQry.query(dbCon);
					 * ArrayList langResultList =
					 * tblLanguageQry.getResultArrayList(); if
					 * (langResultList.size() > 0) { TblLanguageDbBean
					 * languageDbBean = (TblLanguageDbBean)
					 * langResultList.get(0);
					 * setVmLangStr(languageDbBean.getLangName());
					 * log.info("In getDetails Vm"); }
					 */
				}
				setMaxVmBox(locDbBean.getMaxVmBox());
				setActiveInd(locDbBean.getActiveInd());
				setProductionIndicator(locDbBean.getProductionIndicator());
				setVmType(locDbBean.getVmType());
				setOverrideSubPrivate(locDbBean.getOverrideSubPrivate());
				setSwitchClli(locDbBean.getSwitchClli());
				setVmCpeIpAddress(locDbBean.getVmCpeIpAddress());
				setContactName(locDbBean.getContactName());
				setContactEmail(locDbBean.getContactEmail());
				setContactPhone(locDbBean.getContactPhone());
				setActTeamName(locDbBean.getActTeamName());
				setActTeamEmail(locDbBean.getActTeamEmail());
				setActTeamPhone(locDbBean.getActTeamPhone());
				setAccessType(locDbBean.getAccessType());
				setVmSmdiAuthToggle(locDbBean.getVmSmdiAuthToggle());
				setActiveDate(locDbBean.getActiveDate());
				setCreatedBy(locDbBean.getCreatedBy());
				setModifiedBy(locDbBean.getModifiedBy());
				setCreationDate(locDbBean.getCreationDate());
				setLastModifiedDate(locDbBean.getLastModifiedDate());
				setEnvOrderId(locDbBean.getEnvOrderId());
				setEmerPoolId(locDbBean.getEmerPoolId());
				setHybridAssigned(locDbBean.getHybridAssigned());
				setAddressId(locDbBean.getAddressId());
				setE2eimigflag(locDbBean.getE2eiMigFlag());
				if (getRegion(locDbBean.getLocationId()) == VzbVoipEnum.RegionType.APAC) {
					TblVzbEmerCodeQuery tblVzbEmerCodeQuery = new TblVzbEmerCodeQuery();
					String whereClause = " where cntry_code = \'"
							+ locDbBean.getLocCountry() + "\'";
					if (locDbBean.getLocTerritory() != null) {
						log.info(" Territory Included in the Query "
								+ locDbBean.getLocTerritory());
						whereClause += " and upper(territory) = upper(\'"
								+ locDbBean.getLocTerritory() + "\')";
					}
					if (locDbBean.getEmerLocationCode() != null
							&& Integer
									.parseInt(locDbBean.getEmerLocationCode()) > -1) {
						whereClause += " and emer_loc_code_id = "
								+ locDbBean.getEmerLocationCode() + " ";
						tblVzbEmerCodeQuery.queryByWhere(dbCon, whereClause);
						if (tblVzbEmerCodeQuery.size() > 0) {
							setEmerLocationCode(tblVzbEmerCodeQuery
									.getDbBean(0).getEmerLocCode());
						}
					}
				} else
					setEmerLocationCode(locDbBean.getEmerLocationCode());

				setLocationType(locDbBean.getLocationType());
				setFmcgLocationType(locDbBean.getFmcgLocationType());
				setHubLocationId(locDbBean.getHubLocationId());
				setHubGatewayDeviceId(locDbBean.getHubGatewayDeviceId());
				// setBaPortalPoolId(locDbBean.getBaPortalPoolId());
				//getLocationFeaturesForLocation();
				setLocationMask(locDbBean.getLocationMask());
				setANumMask(locDbBean.getANumMask());
				setBNumMask(locDbBean.getBNumMask());
				getVmAccessListByLocationId();

				log.info("GettingDetails createdBy: "
						+ locDbBean.getCreatedBy());
				log.info("In getDetails loc8");

				// Added as per d/b changes
				setSbcProvMethod(locDbBean.getSbcProvMethod());
				setTblVpnIdMappingId(locDbBean.getTblVpnIdMappingId());
				setVpnName(locDbBean.getVpnName());
				setQosInd(locDbBean.getQosInd());
				setAfterHoursInstallFlag(locDbBean.getAfterHoursInstallFlag());
				setHighVolumeInstallFlag(locDbBean.getHighVolumeInstallFlag());
				setExpedite(locDbBean.getExpedite());
				setTsoMigLock(locDbBean.getTsoMigLock());
				setLocCclInd(locDbBean.getLocCclInd());
				setBillingActivated(locDbBean.getBillingActivated());
				setConfigAllowed(locDbBean.getConfigAllowed());
				setProductIdentifier(locDbBean.getProductIdentifier());
				setEnhancedAniInd(locDbBean.getEnhancedAniInd());
				setCallingNameInd(locDbBean.getCallingNameInd());
				setRivLocation(locDbBean.getRivLocation());
				setTeleworkerFqdn(locDbBean.getTwFqdn()); // FMCg Phase II
				setTwSbcId(locDbBean.getTwSbcId()); // FMCg Phase II
				// Jan 2011 Release changes
				setBillAccountNumber(locDbBean.getBillAcctNum());
				setLocTerritory(locDbBean.getLocTerritory());
				setLocRegion(locDbBean.getLocRegion());
				setBillingSystem(locDbBean.getBillingSystem());
				// May 2011 - 2CLI changes
				setAlternativeCallerIdInd(locDbBean.getAlternetCallerId());
				// 53938.AA Business Continuity Ph 1 - changes for july 2011
				setVarrsFlag(locDbBean.getVarrsFlag());
				setRestrictedAccess(locDbBean.getRestrictedAccess());
				setCnamUpdateStatus(locDbBean.getCnamUpdateStatus());
				setCnamUpdateDate(locDbBean.getCnamUpdateDate());
				setE911Service(locDbBean.getE911Service());
				setVce(locDbBean.getVceEnabled());				
			} else {
				setStatus(InvErrorCode.NO_LOCATION_FOUND_FOR_LOC_ID);
				System.out
						.println("FAILURE in getDetails Location.Couldn't find any Location with the given LocationId");
				return false;
			}
		} catch (SQLException s) {
			s.printStackTrace();
			setStatus(InvErrorCode.DB_EXCEPTION);
			log.info("DB_FAILURE in getDetails Location");
			return false;
		}
		setStatus(InvErrorCode.SUCCESS);
		log.info("Successfully retrieved location from db");
		return true;
	}

	// set LocationId member
	public boolean getDBRawDetails() {
		try {
			if (locationId == null || "".equals(locationId)) {
				setStatus(InvErrorCode.MISSING_LOCATION_ID);
				System.out
						.println("FAILURE in getDetails Location. Location Id missing.");
				return false;
			}
			clearLocation();
			log.info("In Location getDBRawDetails; locationID="
					+ locationId);
			TblLocationQuery locQry = new TblLocationQuery();
			locQry.whereLocationIdEQ(locationId);
			if (getAll == false)
				locQry.whereActiveIndEQ(1);
			else
				locQry.whereActiveIndNE(0);
			locQry.query(dbCon);
			if (locQry.size() == 1) {
				TblLocationDbBean locDbBean = locQry.getDbBean(0);
				setLocationId(locDbBean.getLocationId());
				setEnterpriseId(locDbBean.getEnterpriseId());
				setDialPlanId(locDbBean.getDialPlanId());
				setOrderSource(locDbBean.getOrderSource());
				setLocationName(locDbBean.getLocationName());
				setLocAddress(locDbBean.getLocAddress());
				setLocCity(locDbBean.getLocCity());
				setLocState(locDbBean.getLocState());
				setLocZip(locDbBean.getLocZip());
				setLocCountry(locDbBean.getLocCountry());
				setNpaNxx(locDbBean.getNpanxx());
				// Jan 2013 Release - E2EI
				setPhysicalLocationId(locDbBean.getPhysicalLocationId());
				setPhysicalLocationName(locDbBean.getPhysicalLocationName());
				setDialingCountryCode(locDbBean.getDialingCountryCode());
				System.out
						.println((new StringBuilder())
								.append("locDbBean.getPhysicalLocationId() set in raw details :: ")
								.append(locDbBean.getPhysicalLocationId())
								.toString());
				setCallFwdPlanName(locDbBean.getCallFwdPlanName());
				setSbcId(locDbBean.getSbcId());
				setSbcInd(locDbBean.getSbcInd());
				setSipEnabled(locDbBean.getSipEnabled());
				setSubAgencyHierCode(locDbBean.getSubAgencyHierCode());

				if (locDbBean.getTimeZone() > 0) {
					setTimeZoneId((int) locDbBean.getTimeZone());
					setTimeZone(Long.toString(locDbBean.getTimeZone()));
					log.info("In getDetails " + getTimeZone());
				}

				setUseDaylightSaving(locDbBean.getUseDaylightSavings());
				setWebLang(locDbBean.getWebLang());
				setEnterpriseTrunkId(locDbBean.getEnterpriseTrunkId());
				setTsoMigLock(locDbBean.getTsoMigLock());
				setPqInstanceId(locDbBean.getPqInstanceId());
				setIsrDesignId(locDbBean.getIsrDesignId());
				setIxPlusId(locDbBean.getIxplusId());
				setIxPlusEnvId(locDbBean.getIxplusEnvId());
				setBillTnPoolId(locDbBean.getBtnPoolId());
				setBillTn(getTnByTnPoolId(locDbBean.getBtnPoolId()));
				setBillType((int) locDbBean.getBillType());
				// STN Code here
				setSTnPoolId(locDbBean.getStnPoolId());
				setSTn(getTnByTnPoolId(locDbBean.getStnPoolId()));
				setNetcomServiceId(locDbBean.getNetcomServiceId());
				setCv2Service(locDbBean.getCv2Service());
				setManagedService(locDbBean.getManagedService());
				setServiceTypeOffering(locDbBean.getServiceTypeOffering());
				setVoipServiceType(locDbBean.getVoipServiceType());
				setHybridServiceType(locDbBean.getHybridServiceType());
				setPubIp(locDbBean.getPubIp());
				setCircuitId(locDbBean.getCircuitId());
				setUunetSiteId(locDbBean.getUunetSiteId());
				setSipDomain(locDbBean.getSipDomain());
				setPublicGtwyDpid(locDbBean.getPublicGtwyDpid());
				setDefaultGtwyDpid(locDbBean.getDefaultGtwyDpid());
				setTrunkType(locDbBean.getTrunkType());
				setVoipClub(locDbBean.getVoipClub());
				setServiceLevel(locDbBean.getServiceLevel());
				setLocMarket(locDbBean.getLocMarket());
				setMaxExtLength(locDbBean.getMaxExtLength());
				setExtLength(locDbBean.getExtLength());
				setPrivateNumLength(locDbBean.getPrivateNumLength());
				setLinePortLength(locDbBean.getLinePortLength());
				setClin(locDbBean.getClin());
				setAbbrDialingCode(locDbBean.getAbbrDialingCode());
				setEnableCallPark(locDbBean.getEnableCallPark());
				setOverrideCidNum(locDbBean.getOverrideCidNum());
				setOverrideCidName(locDbBean.getOverrideCidName());
				setEnableAccountCode(locDbBean.getEnableAccountCode());
				setEnableAuthCode(locDbBean.getEnableAuthCode());
				setLocalDirAssistance(locDbBean.getLocalDirAssistance());
				setNatDirAssistance(locDbBean.getNatDirAssistance());
				setConcCallStat(locDbBean.getConccallStat());
				setMaxConcurrentCalls(locDbBean.getMaxConcurrentCalls());
				setMaxConcurrentOffnet(locDbBean.getMaxConcurrentOffnet());
				setMaxInbound(locDbBean.getMaxInbound());
				setMaxSlg(locDbBean.getMaxSlg());
				setMaxNg(locDbBean.getMaxNg());
				setMaxSubscribers(locDbBean.getMaxSubscribers());
				setMaxPublicTn(locDbBean.getMaxPublicTn());
				setBlockAllCalls(locDbBean.getBlockAllCalls());
				setRpid(locDbBean.getRpid());
				setRpidPriv(locDbBean.getRpidPriv());
				setRpidPoolId(locDbBean.getRpidPoolId());
				setPendingRpid(locDbBean.getPendingRpid());
				setRpidTn(getTnByTnPoolId(locDbBean.getRpidPoolId()));
				setHicrService(locDbBean.getHicrService());
				// setPremiseVm(locDbBean.getPremiseVm());
				setCallingPlanId(locDbBean.getCallingPlanId());
				setVmLang(locDbBean.getVmLang());
				setTrunk(locDbBean.getTrunk());
				setMaxVmBox(locDbBean.getMaxVmBox());
				setActiveInd(locDbBean.getActiveInd());
				setProductionIndicator(locDbBean.getProductionIndicator());
				setVmType(locDbBean.getVmType());
				setOverrideSubPrivate(locDbBean.getOverrideSubPrivate());
				setSwitchClli(locDbBean.getSwitchClli());
				setVmCpeIpAddress(locDbBean.getVmCpeIpAddress());
				setContactName(locDbBean.getContactName());
				setContactEmail(locDbBean.getContactEmail());
				setContactPhone(locDbBean.getContactPhone());
				setActTeamName(locDbBean.getActTeamName());
				setActTeamEmail(locDbBean.getActTeamEmail());
				setActTeamPhone(locDbBean.getActTeamPhone());
				setAccessType(locDbBean.getAccessType());
				setVmSmdiAuthToggle(locDbBean.getVmSmdiAuthToggle());
				setCreatedBy(locDbBean.getCreatedBy());
				setModifiedBy(locDbBean.getModifiedBy());
				setCreationDate(locDbBean.getCreationDate());
				setLastModifiedDate(locDbBean.getLastModifiedDate());
				setEnvOrderId(locDbBean.getEnvOrderId());
				setEmerPoolId(locDbBean.getEmerPoolId());
				setEmerLocationCode(locDbBean.getEmerLocationCode());
				setLocationType(locDbBean.getLocationType());
				setFmcgLocationType(locDbBean.getFmcgLocationType());
				setHubLocationId(locDbBean.getHubLocationId());
				setHubGatewayDeviceId(locDbBean.getHubGatewayDeviceId());
				// setBaPortalPoolId(locDbBean.getBaPortalPoolId());
				setLocationMask(locDbBean.getLocationMask());
				setANumMask(locDbBean.getANumMask());
				setBNumMask(locDbBean.getBNumMask());
				setSipEnabled(locDbBean.getSipEnabled());

				getVmAccessListByLocationId();

				log.info("GettingDetails createdBy: "
						+ locDbBean.getCreatedBy());
				log.info("In getDetails loc8");

				// Added as per d/b changes
				setSbcProvMethod(locDbBean.getSbcProvMethod());
				setTblVpnIdMappingId(locDbBean.getTblVpnIdMappingId());
				setVpnName(locDbBean.getVpnName());
				setQosInd(locDbBean.getQosInd());
				setLocCclInd(locDbBean.getLocCclInd());
				setBillingActivated(locDbBean.getBillingActivated());
				setConfigAllowed(locDbBean.getConfigAllowed());
				setProductIdentifier(locDbBean.getProductIdentifier());
				setEnhancedAniInd(locDbBean.getEnhancedAniInd());
				setCallingNameInd(locDbBean.getCallingNameInd());
				setActiveDate(locDbBean.getActiveDate());
				setAfterHoursInstallFlag(locDbBean.getAfterHoursInstallFlag());
				setDayLightSavingsRegion(Long.toString(locDbBean
						.getDaylightSavingsRegion()));
				setExpedite(locDbBean.getExpedite());
				setHighVolumeInstallFlag(locDbBean.getHighVolumeInstallFlag());
				setRivLocation(locDbBean.getRivLocation());
				setSbcMigInd(locDbBean.getSbcMigInd());
				setVmLangStr(VzbVoipEnum.Language.acronym((int) locDbBean
						.getVmLang()));
				setWebLangStr(VzbVoipEnum.Language.acronym((int) locDbBean
						.getWebLang()));
				// Jan 2011 Release changes
				setBillAccountNumber(locDbBean.getBillAcctNum());
				setLocTerritory(locDbBean.getLocTerritory());
				setLocRegion(locDbBean.getLocRegion());
				setBillingSystem(locDbBean.getBillingSystem());
				// May 2011 - 2CLI changes
				setAlternativeCallerIdInd(locDbBean.getAlternetCallerId());
				// 53938.AA Business Continuity Ph 1 - changes for july 2011
				setVarrsFlag(locDbBean.getVarrsFlag());
				setRestrictedAccess(locDbBean.getRestrictedAccess());
				setHybridAssigned(locDbBean.getHybridAssigned());
				setE2eimigflag(locDbBean.getE2eiMigFlag());
				setAddressId(locDbBean.getAddressId());
				setE911Service(locDbBean.getE911Service());
				setVce(locDbBean.getVceEnabled());
			} else {
				setStatus(InvErrorCode.NO_LOCATION_FOUND_FOR_LOC_ID);
				System.out
						.println("FAILURE in getDetails Location.Couldn't find any Location with the given LocationId");
				return false;
			}
		} catch (SQLException s) {
			s.printStackTrace();
			setStatus(InvErrorCode.DB_EXCEPTION);
			log.info("DB_FAILURE in getDetails Location");
			return false;
		}
		setStatus(InvErrorCode.SUCCESS);
		log.info("Successfully retrieved location from db");
		return true;
	}

	// set LocationId member , gives the list of feature packages for that
	// location
	public boolean getFeaturePackagesForLocation() {
		try {
			if (locationId == null || "".equalsIgnoreCase(locationId)) {
				setStatus(InvErrorCode.MISSING_LOCATION_ID);
				System.out
						.println("DB_FAILURE in getDetails Location.Location id cannot be null");
				return false;
			}
			String whereLocClause = " where location_id = \'" + locationId
					+ "\'";
			TblLocPackageQuery locPkgQry = new TblLocPackageQuery();
			locPkgQry.queryByWhere(dbCon, whereLocClause);
			log.info("in icp, locpkgQry.size:" + locPkgQry.size());
			if (locPkgQry.size() <= 0) {
				setStatus(InvErrorCode.NO_LOCATION_PKG_FOR_LOCATION);
				System.out
						.println("DB_FAILURE in getFeaturePackageForLocation.no Loc packages found");
				return false;
			}
			for (int k = 0; k < locPkgQry.size(); k++) {
				TblPackageQuery pkgQry = new TblPackageQuery();
				pkgQry.wherePackageIdEQ((locPkgQry.getDbBean(k)).getPackageId());
				pkgQry.query(dbCon);
				log.info("pkgQry size:" + pkgQry.size());
				if (pkgQry.size() == 1)
					log.info("pkg name in the db"
							+ (pkgQry.getDbBean(0)).getPackageName());
				if (pkgQry.size() == 1) {
					FeaturePackageBean featPkgBean = new FeaturePackageBean();
					featPkgBean.setFeaturePackageType((pkgQry.getDbBean(0))
							.getPackageType());
					featPkgBean.setFeaturePackageName((pkgQry.getDbBean(0))
							.getPackageName());
					Long fpId = new Long((pkgQry.getDbBean(0)).getPackageId());
					featPkgBean.setFeaturePackageId(fpId.intValue());
					featPkgBean.setIsDefault((locPkgQry.getDbBean(k))
							.getIsDefault());
					featPkgBean.setTemplateInd((pkgQry.getDbBean(0))
							.getTemplateInd());
					featPkgBean.setLocationId((locPkgQry.getDbBean(k))
							.getLocationId());
					featPkgBean.setFeatureList(getPackageFeaturesList(fpId));
					featPkgBean.setCreatedBy((locPkgQry.getDbBean(k))
							.getCreatedBy());
					featPkgBean.setModifiedBy(locPkgQry.getDbBean(k)
							.getModifiedBy());
					featPkgBean.setCreatedDate(locPkgQry.getDbBean(k)
							.getCreationDate());
					featPkgBean.setModifiedDate(locPkgQry.getDbBean(k)
							.getLastModifiedDate());
					featPkgBean.setEnvOrderId(locPkgQry.getDbBean(k)
							.getEnvOrderId());
					featurePkgList.add(featPkgBean);
				} else {
					setStatus(InvErrorCode.INVALID_PKG_ID);
					System.out
							.println("DB_FAILURE in getfeaturePakcage Location.Invalid Package for the given packageId"
									+ (locPkgQry.getDbBean(k)).getPackageId());
					return false;
				}
			}
		} catch (SQLException s) {
			s.printStackTrace();
			setStatus(InvErrorCode.DB_EXCEPTION);
			log.info("DB_FAILURE in getfeaturePakcage Location");
			return false;
		}
		setStatus(InvErrorCode.SUCCESS);
		log.info("Successfully retrieved feature pkg from db");
		return true;
	}

	public boolean getFeaturePackagesForLocationAndPackage(long packageId) {
		try {
			if (locationId == null || "".equalsIgnoreCase(locationId)) {
				setStatus(InvErrorCode.MISSING_LOCATION_ID);
				System.out
						.println("DB_FAILURE in getDetails Location.Location id cannot be null");
				return false;
			}
			String whereLocClause = " where location_id = \'" + locationId
					+ "\'" + " and package_id = \'" + packageId + "\'";
			TblLocPackageQuery locPkgQry = new TblLocPackageQuery();
			locPkgQry.queryByWhere(dbCon, whereLocClause);
			log.info("in icp, locpkgQry.size:" + locPkgQry.size());
			if (locPkgQry.size() <= 0) {
				setStatus(InvErrorCode.NO_LOCATION_PKG_FOR_LOCATION);
				System.out
						.println("DB_FAILURE in getFeaturePackageForLocation.no Loc packages found");
				return false;
			}
			TblPackageQuery pkgQry = new TblPackageQuery();
			pkgQry.wherePackageIdEQ(packageId);
			pkgQry.query(dbCon);
			log.info("pkgQry size:" + pkgQry.size());
			if (pkgQry.size() == 1)
				log.info("pkg name in the db"
						+ (pkgQry.getDbBean(0)).getPackageName());
			if (pkgQry.size() == 1) {
				FeaturePackageBean featPkgBean = new FeaturePackageBean();
				featPkgBean.setFeaturePackageType((pkgQry.getDbBean(0))
						.getPackageType());
				featPkgBean.setFeaturePackageName((pkgQry.getDbBean(0))
						.getPackageName());
				featPkgBean.setTemplateInd((pkgQry.getDbBean(0))
						.getTemplateInd());
				Long fpId = new Long((pkgQry.getDbBean(0)).getPackageId());
				featPkgBean.setFeaturePackageId(fpId.intValue());
				featPkgBean.setIsDefault((locPkgQry.getDbBean(0))
						.getIsDefault());
				featPkgBean.setLocationId((locPkgQry.getDbBean(0))
						.getLocationId());
				featPkgBean.setFeatureList(getPackageFeaturesList(fpId));
				featPkgBean.setCreatedBy((locPkgQry.getDbBean(0))
						.getCreatedBy());
				featPkgBean.setModifiedBy(locPkgQry.getDbBean(0)
						.getModifiedBy());
				featPkgBean.setCreatedDate(locPkgQry.getDbBean(0)
						.getCreationDate());
				featPkgBean.setModifiedDate(locPkgQry.getDbBean(0)
						.getLastModifiedDate());
				featPkgBean.setEnvOrderId(locPkgQry.getDbBean(0)
						.getEnvOrderId());
				featurePkgList.add(featPkgBean);
				log.info("Is DEFAULT   :  "
						+ (locPkgQry.getDbBean(0)).getIsDefault());
				log.info("Template Ind : "
						+ (pkgQry.getDbBean(0)).getTemplateInd());
			} else {
				setStatus(InvErrorCode.INVALID_PKG_ID);
				System.out
						.println("DB_FAILURE in getfeaturePakcage Location.Invalid Package for the given packageId"
								+ (locPkgQry.getDbBean(0)).getPackageId());
				return false;
			}
		} catch (SQLException s) {
			s.printStackTrace();
			setStatus(InvErrorCode.DB_EXCEPTION);
			log.info("DB_FAILURE in getfeaturePakcage Location");
			return false;
		}
		setStatus(InvErrorCode.SUCCESS);
		log.info("Successfully retrieved feature pkg from db");
		return true;
	}

	/**
	 * The method to get the list of features for a specified package.
	 * 
	 * @param packageId
	 *            The Package Id.
	 * @return The list of Features
	 * @throws SQLException
	 *             Thrown if some DB error occurs.
	 */
	private List<FeaturesBean> getPackageFeaturesList(Long packageId)
			throws SQLException {
		ArrayList<FeaturesBean> featList = new ArrayList<FeaturesBean>();
		// query list of featureids for the given pkgid.
		TblPkgFeaturesQuery pkgFeatQry = new TblPkgFeaturesQuery();
		String whereClause = " where package_id = " + packageId;
		pkgFeatQry.queryByWhere(dbCon, whereClause);
		// Inner IF Four
		if (pkgFeatQry.size() > 0) { // for each result featureid, query details
										// from TBL_VZB_FEATURES
			ArrayList result2 = pkgFeatQry.getResultArrayList();
			for (int j = 0; j < pkgFeatQry.size(); j++) { // Inner FOR One
				TblPkgFeaturesDbBean pkgFeatBean = (TblPkgFeaturesDbBean) result2
						.get(j);
				if (pkgFeatBean != null) { // Inner IF Three
					long featId = Long.parseLong(pkgFeatBean.getFeatureId());
					// for the featureid, get the details from TBL_VZB_FEATURES
					// and collect in a list.
					TblVzbFeaturesQuery vzbFeatQry = new TblVzbFeaturesQuery();
					whereClause = " where feature_id = " + featId;
					vzbFeatQry.queryByWhere(dbCon, whereClause);
					if (vzbFeatQry.size() > 0) { // Inner IF Two
						DBTblVzbFeatures vzbFeatBean = new DBTblVzbFeatures();
						vzbFeatBean.copyFromBean(vzbFeatQry.getDbBean(0));
						if (vzbFeatBean != null) { // Inner IF One
							FeaturesBean featBean = new FeaturesBean();
							featBean.setFeaturesDbBean(vzbFeatBean);
							featBean.setIsSelected((pkgFeatBean.getIsSelected())
									.equals("Y") ? true : false);
							featList.add(featBean);
						} // End of Inner IF One
					}// End of Inner IF Two
				}// End of Inner IF Three
			}// End of Inner FOR One
		}// Inner IF Four
		return featList;
	}

	/* returns prefixPlans for a given LocationID */
	public boolean getPrefixPlansForLocation() {
		//IIASAInventoryInterface iasaHandler = new IASAInventory();
		Connection iasa_connection = null;
		try {
			//iasa_connection = IASAConnectionHelper.getIASAConnection(dbCon);
			if (iasa_connection == null)
				throw new Exception("Unable to get Iasa DB Connection");
			/*HashMap<String, String> prefixPlanMap = iasaHandler
					.getAllPrefixPlanByLocId(iasa_connection, locationId);*/
/*			for (Iterator itrPrefixPlan = prefixPlanMap.keySet().iterator(); itrPrefixPlan
					.hasNext();) {
				String sPPIdKey = (String) itrPrefixPlan.next();
				String sPrefixPlanName = (String) prefixPlanMap.get(sPPIdKey);
				log.info("sPPIdKey=" + sPPIdKey
						+ ":: sPrefixPlanName = " + sPrefixPlanName);
				boolean isDefault = (sPrefixPlanName.toLowerCase())
						.contains("default");
				int nDefault = 0;
				if (isDefault) {
					nDefault = 1;
				} else {
					nDefault = 0;
				}
				PrefixPlanBean prefixPlanBean = new PrefixPlanBean(sPPIdKey,
						locationId, sPrefixPlanName, nDefault);
				this.prefixPlanList.add(prefixPlanBean);
			}*/
		} catch (Exception e) {
			setStatus(InvErrorCode.DB_EXCEPTION);
			System.out
					.println("DB_FAILURE in getPrefixPlansForLocation Location");
			e.printStackTrace();
			return false;
		} finally {
			if (iasa_connection != null) {
				try {
					iasa_connection.close();
				} catch (SQLException ex) {
					System.out
							.println("DB_FAILURE in getPrefixPlansForLocation Location, while closing iasa connection.");
					ex.printStackTrace();
				}
				iasa_connection = null;
			}
		}
		setStatus(InvErrorCode.SUCCESS);
		log.info("Successfully getPrefixPlansForLocation from db");
		return true;
	}

	/* returns prefixPlans for a given PrefixPlanID */
	// /*
	public PrefixPlanBean getPrefixPlanByPrefixPlanId() {
		System.out
				.println("invoked getPrefixPlanByPrefixPlanId for location id "
						+ this.getLocationId());
		Connection iasaConnection = null;
		PrefixPlanBean pPBean = null;
		try {
			Statement stmt = null;
			ResultSet rs = null;
			try {
				String query = "select distinct param_name, param_value "
						+ "from tbl_route_info r, tbl_device_info d "
						+ "where  r.device = d.device and param_name like '%iasa%'";
				stmt = dbCon.createStatement();
				rs = stmt.executeQuery(query);
				Properties iasaProperty = new Properties();
				iasaProperty.put("driver", "oracle.jdbc.driver.OracleDriver");
				iasaProperty
						.put("iasa_url",
								":oracle:thin:@(DESCRIPTION = (ADDRESS = (PROTOCOL = TCP)(HOST = ashgrid19vip.vzbi.com)(PORT = 1800)) (ADDRESS = (PROTOCOL = TCP)(HOST = ashgrid20vip.vzbi.com)(PORT = 1800)) (LOAD_BALANCE = yes) (CONNECT_DATA = (SERVER = DEDICATED) (SERVICE_NAME = DEV5) (FAILOVER_MODE = (TYPE = SELECT) (METHOD = BASIC) (RETRIES = 180) (DELAY = 5))))");
				iasaProperty.put("iasa_user", "esapadm");
				iasaProperty.put("iasa_password", "esapadm");
				String paramName = null;
				String paramValue = null;
				while (rs.next()) {
					paramName = rs.getString("PARAM_NAME");
					paramValue = rs.getString("PARAM_VALUE");
					if ("iasa_url".equals(paramName))
						paramValue = paramValue.replaceAll(":oci:", ":thin:");
					log.info("IASA Props: " + paramName + "\t:"
							+ paramValue);
					iasaProperty.put(paramName, paramValue);
				}
				Class.forName(iasaProperty.getProperty("driver"));
				iasaConnection = DriverManager.getConnection(
						iasaProperty.getProperty("iasa_url"),
						iasaProperty.getProperty("iasa_user"),
						iasaProperty.getProperty("iasa_password"));
			} catch (Exception e) {
				e.printStackTrace();
				log.info("ERROR getting IASA DB Connection : " + e);
			} finally {
				if (rs != null)
					rs.close();
				if (stmt != null)
					stmt.close();
			}
			// iasaConnection =
			// IASAConnectionFactory.getFactory().getConnection();
			if (iasaConnection == null)
				throw new Exception("Could not get DB connection for iasa");
			//PrefixPlan prefixPlan = new PrefixPlan(iasaConnection);
			// location id is stored as plan id
/*			HashMap<String, String> prefixPlanDetails = prefixPlan
					.getAllPrefixPlanByPlanId(iasaConnection,
							this.getLocationId());*/
/*			log.info("getPrefixPlanByPrefixPlanId HashMap size "
					+ prefixPlanDetails.size());
			if (prefixPlanDetails != null && prefixPlanDetails.size() > 0) {
				pPBean = new PrefixPlanBean();
				Iterator<String> itr = prefixPlanDetails.keySet().iterator();
				String ppID = itr.next();
				pPBean.setPPId(ppID);
				pPBean.setPlanName(prefixPlanDetails.get(ppID));
			}*/
		} catch (Exception e) {
			log.info("Error in getPrefixPlanByPrefixPlanId : "
					+ e.getMessage());
			e.printStackTrace(System.out);
		} finally {
			try {
				if (iasaConnection != null)
					iasaConnection.close();
			} catch (Exception sqle) {
				sqle.printStackTrace();
				// do nothing.
			}
		}
		return pPBean;
	}

	// */

	/**
	 * get list of features for a given locationId,packageId(mandatory inputs)
	 * locationId - mandatory input packageName - mandatory input featureType -
	 * optional input - u can pass in specific feature type like U or G , or
	 * pass in Empty string/null to get all featureTypes.
	 * 
	 * This method invokes getFeaturePackagesForLocationByPackageIdAndLocationId
	 * with an additional argument in the end, that indicates that the check for
	 * the existence of package in the location is enforced, in which case if
	 * the package is not found in the location, it will return false.
	 */
	public boolean getFeaturePackagesForLocationByPackageIdAndLocationId(
			long packageId, String locationId, String featureType,
			String enterpriseId) {
		return getFeaturePackagesForLocationByPackageIdAndLocationId(packageId,
				locationId, featureType, enterpriseId, true);
	}

	/**
	 * get list of features for a given locationId,packageId(mandatory inputs)
	 * locationId - mandatory input packageName - mandatory input featureType -
	 * optional input - u can pass in specific feature type like U or G , or
	 * pass in Empty string/null to get all featureTypes.
	 * 
	 * The last param, locationCheck; if it is true, this method enforces that
	 * the method returns false if the package is not associated to the
	 * Location. If this flag is set to false, then it relaxes the rule; ie;
	 * even if the package is not available at the location, it will still pick
	 * up the feature for the package and return them
	 */
	public boolean getFeaturePackagesForLocationByPackageIdAndLocationId(
			long packageId, String locationId, String featureType,
			String enterpriseId, boolean locationCheck) {
		boolean foundMatchingPkgId = false;
		boolean foundAtLeastOneFeature = false;
		boolean isCSSOPRequest = false;
		FeaturePackageBean resultFeatPkgBean = new FeaturePackageBean();
		ArrayList<FeaturePackageBean> featPkgList = new ArrayList<FeaturePackageBean>();
		ArrayList<FeaturesBean> featList = new ArrayList<FeaturesBean>();
		try {

			// if enterpriseId is null , get from locationId
			if ((enterpriseId == null) || (enterpriseId == "")) {
				isCSSOPRequest = true; // for CSSOP req, enterprise id not sent.
										// and required for is-selected filter
				System.out
						.println("EnterpriseId is null, getting from tbl_location");
				TblLocationQuery locQry = new TblLocationQuery();
				locQry.whereLocationIdEQ(locationId);
				locQry.query(dbCon);
				if (locQry.size() == 1) {
					TblLocationDbBean locDbBean = locQry.getDbBean(0);
					enterpriseId = locDbBean.getEnterpriseId();

				}

			}

			System.out
					.println("Inputs to getFeaturePackagesForLocationByPackageIdAndLocationId");
			log.info("locationId = " + locationId);
			log.info("enterpriseId = " + enterpriseId);
			log.info("featureType = " + featureType);
			log.info("packageId = " + packageId);
			// get the list of Ent auth features, to later verify if the pkg
			// features are all authorized
			setEnterpriseId(enterpriseId);
			List<String> entAuthFeatureIdList;
			if (isCSSOPRequest)
				entAuthFeatureIdList = getEntAuthFeatureIdList(enterpriseId);
			else
				entAuthFeatureIdList = getEntAuthFeatureIdList(enterpriseId,
						featureType);
			log.info("No. of Authorized features: "
					+ entAuthFeatureIdList.size());

			if (entAuthFeatureIdList == null || entAuthFeatureIdList.size() < 1) {
				setStatus(InvErrorCode.NOTFOUND_ENT_AUTH_FEATURES_FOR_ENTERPRISE_ID);
				System.out
						.println("FAILURE in getFeaturePackagesForLocationByPackageIdAndLocationId. Enterprise auth feature list is null or empty List.");
				return false;
			}
			setLocationId(locationId);

			// If loction check is enabled, query for the package id in
			// tbl_loc_package
			//
			boolean packageFoundAtLocation = false;
			long isDefaultPackage = 0;
			if (locationCheck == true) {
				TblLocPackageQuery locQry = new TblLocPackageQuery();
				String whereClause = " where location_id = '" + locationId
						+ "'" + " and package_id =" + packageId;
				locQry.queryByWhere(dbCon, whereClause);
				if ((locQry.size() > 0)) {
					packageFoundAtLocation = true;
					isDefaultPackage = (locQry.getDbBean(0)).getIsDefault();
				}
			}

			// Start of Outer IF
			// We can go ahead if locationCheck is disabled or if we really
			// found the package at the location
			if ((locationCheck == false) || (packageFoundAtLocation == true)) {
				TblPackageQuery pkgQry = new TblPackageQuery();
				String whereClause = " where package_id = " + packageId;
				pkgQry.queryByWhere(dbCon, whereClause);
				// Inner IF Five
				if (pkgQry.size() == 1) {
					resultFeatPkgBean.setFeaturePackageType((pkgQry
							.getDbBean(0)).getPackageType());
					resultFeatPkgBean.setFeaturePackageName((pkgQry
							.getDbBean(0)).getPackageName());
					resultFeatPkgBean.setIsDefault(isDefaultPackage);
					resultFeatPkgBean.setTemplateInd((pkgQry.getDbBean(0))
							.getTemplateInd());

					foundMatchingPkgId = true;
					// query list of featureids for the given pkgid.
					TblPkgFeaturesQuery pkgFeatQry = new TblPkgFeaturesQuery();
					if (isCSSOPRequest)
						whereClause = " where package_id = " + packageId; // CSSOP
																			// requires
																			// both
																			// on/off
																			// features
					else
						whereClause = " where package_id = " + packageId
								+ " and is_selected='Y'";

					pkgFeatQry.queryByWhere(dbCon, whereClause);
					// Inner IF Four
					if (pkgFeatQry.size() > 0) {
						// for each result featureid, query details from
						// TBL_VZB_FEATURES
						ArrayList result2 = pkgFeatQry.getResultArrayList();
						// Inner FOR One
						for (int j = 0; j < pkgFeatQry.size(); j++) {
							Object oPkgFeatBean = result2.get(j);
							// Inner IF Three
							if (oPkgFeatBean != null) {
								TblPkgFeaturesDbBean pkgFeatBean = (TblPkgFeaturesDbBean) oPkgFeatBean;
								long featId = Long.parseLong(pkgFeatBean
										.getFeatureId());
								// check if the feature id is in the list of Ent
								// auth features.
								if (entAuthFeatureIdList.contains("" + featId)) {
									// for the featureid, get the details from
									// TBL_VZB_FEATURES and collect in a list.
									TblVzbFeaturesQuery vzbFeatQry = new TblVzbFeaturesQuery();
									whereClause = " where feature_id = "
											+ featId;
									// optional search for featureType
									if (featureType != null
											&& featureType.trim().length() > 0)
										whereClause += " and feature_type = '"
												+ featureType + "'";
									vzbFeatQry.queryByWhere(dbCon, whereClause);
									// Inner IF Two
									if (vzbFeatQry.size() > 0) {
										foundAtLeastOneFeature = true;
										DBTblVzbFeatures vzbFeatBean = new DBTblVzbFeatures();
										vzbFeatBean.copyFromBean(vzbFeatQry
												.getDbBean(0));
										// Inner IF One
										if (vzbFeatBean != null) {
											FeaturesBean featBean = new FeaturesBean();
											featBean.setFeaturesDbBean(vzbFeatBean);
											featBean.setIsSelected((pkgFeatBean
													.getIsSelected())
													.equals("Y") ? true : false);
											featList.add(featBean);
										}// End of Inner IF One
									}// End of Inner IF Two
								} else {
									System.out
											.println("	FeatureId = "
													+ featId
													+ " is not authorized for the Ent, hence not included in the assign feature list");
								}
							}// End of Inner IF Three
						}// End of Inner FOR One
					}// Inner IF Four
					else {
						setStatus(InvErrorCode.NO_PKG_FEATURES_FOR_LOCATION);
						System.out
								.println("FAILURE :Pkg features not found for the given location id and package name");
						return false;
					}
				}// Inner IF Five
				if (!foundMatchingPkgId) {
					setStatus(InvErrorCode.NO_PKG_ID_FOR_LOCATION_ID);
					System.out
							.println("FAILURE :Package id not found for the given location id and package name");
					return false;
				}
				if (!foundAtLeastOneFeature) {
					setStatus(InvErrorCode.NO_FEATURES_FOR_LOCATION_ID_PKG_NAME);
					System.out
							.println("FAILURE :No features where found for the given location id and package name");
					return false;
				}
			}// End of Outer One
			else {
				setStatus(InvErrorCode.INVALID_LOC_ID_FOR_PKG_NAME);
				System.out
						.println("FAILURE :Invalid location_id for the given package name");
				return false;
			}
		} catch (SQLException e) {
			e.printStackTrace();
			setStatus(InvErrorCode.DB_EXCEPTION);
			System.out
					.println("DB FAILURE in getFeatureListByFeaturePackageId for FeaturePackage");
			return false;
		}
		// set the results for output
		resultFeatPkgBean.setFeatureList(featList);
		featPkgList.add(resultFeatPkgBean);
		this.featurePkgList = featPkgList;
		setStatus(InvErrorCode.SUCCESS);
		System.out
				.println("Successfully retrieved getFeatureListByFeaturePackageId for FeaturePackage from the DB");
		return true;
	}

	/**
	 * get list of features for a given locationId, packageName (mandatory
	 * inputs) locationId - mandatory input packageName - mandatory input
	 * featureType - optional input - u can pass in specific feature type like U
	 * or G , or pass in Empty string/null to get all featureTypes.
	 */
	public boolean getFeaturePackagesForLocationByPackageNameAndLocationId(
			String packageName, String locationId, String featureType,
			String enterpriseId) {
		// first, using pkgname query the pkgid from TBL_PACKAGE
		// second, using the pkgid , query list of featureids from
		// TBL_PKG_FEATURES
		// third, using list of featureids, for each featureid - get details
		// from TBL_VZB_FEATURES
		boolean foundMatchingPkgId = false;
		boolean foundAtLeastOneFeature = false;
		FeaturePackageBean resultFeatPkgBean = new FeaturePackageBean();
		ArrayList<FeaturePackageBean> featPkgList = new ArrayList<FeaturePackageBean>();
		ArrayList<FeaturesBean> featList = new ArrayList<FeaturesBean>();
		try {
			System.out
					.println("Inputs to getFeaturePackagesForLocationByPackageNameAndLocationId");
			log.info("locationId = " + locationId);
			log.info("enterpriseId = " + enterpriseId);
			log.info("featureType = " + featureType);
			log.info("packageName = " + packageName);
			// get the list of Ent auth features, to later verify if the pkg
			// features are all authorized
			setEnterpriseId(enterpriseId);
			List<String> entAuthFeatureIdList = getEntAuthFeatureIdList(
					enterpriseId, featureType);
			if (entAuthFeatureIdList == null || entAuthFeatureIdList.size() < 1) {
				setStatus(InvErrorCode.NOTFOUND_ENT_AUTH_FEATURES_FOR_ENTERPRISE_ID);
				System.out
						.println("FAILURE in getFeaturePackagesForLocationByPackageNameAndLocationId. Enterprise auth feature list is null or empty List.");
				return false;
			}
			setLocationId(locationId);
			TblLocPackageQuery locQry = new TblLocPackageQuery();
			String whereClause = " where location_id = '" + locationId + "'";
			System.out
					.println("Before locQry in getFeaturePackagesForLocationByPackageNameAndLocationId Location");
			locQry.queryByWhere(dbCon, whereClause);
			System.out
					.println("After locQry in getFeaturePackagesForLocationByPackageNameAndLocationId Location");
			if (locQry.size() > 0) {
				// for each result from locpkgquery, query tbl_package and match
				// pkgid/name with input args
				ArrayList result = locQry.getResultArrayList();
				System.out
						.println("Looping thro locQry results in getFeaturePackagesForLocationByPackageNameAndLocationId Location");
				for (int i = 0; i < locQry.size(); i++) {
					Object oLocBean = result.get(i);
					if (oLocBean != null) {
						TblLocPackageDbBean locBean = (TblLocPackageDbBean) oLocBean;
						long pkgId = locBean.getPackageId();
						TblPackageQuery pkgQry = new TblPackageQuery();
						whereClause = " where package_id = " + pkgId
								+ " and package_name = '" + packageName + "'";
						System.out
								.println("Before pkgQry in getFeaturePackagesForLocationByPackageNameAndLocationId Location");
						pkgQry.queryByWhere(dbCon, whereClause);
						System.out
								.println("After pkgQry in getFeaturePackagesForLocationByPackageNameAndLocationId Location");
						if (pkgQry.size() == 1) {
							foundMatchingPkgId = true;
							// query list of featureids for the given pkgid.
							TblPkgFeaturesQuery pkgFeatQry = new TblPkgFeaturesQuery();
							whereClause = " where package_id = " + pkgId
									+ " and is_selected='Y'";
							System.out
									.println("Before pkgFeatQry in getFeaturePackagesForLocationByPackageNameAndLocationId Location");
							pkgFeatQry.queryByWhere(dbCon, whereClause);
							System.out
									.println("After pkgFeatQry in getFeaturePackagesForLocationByPackageNameAndLocationId Location");
							if (pkgFeatQry.size() > 0) {
								// for each result featureid, query details from
								// TBL_VZB_FEATURES
								ArrayList result2 = pkgFeatQry
										.getResultArrayList();
								System.out
										.println("Looping thro pkgFeatQry results in getFeaturePackagesForLocationByPackageNameAndLocationId Location");
								for (int j = 0; j < pkgFeatQry.size(); j++) {
									Object oPkgFeatBean = result2.get(j);
									if (oPkgFeatBean != null) {
										TblPkgFeaturesDbBean pkgFeatBean = (TblPkgFeaturesDbBean) oPkgFeatBean;
										long featId = Long
												.parseLong(pkgFeatBean
														.getFeatureId());
										// check if the feature id is in the
										// list of Ent auth features.
										if (entAuthFeatureIdList.contains(""
												+ featId)) {
											// for the featureid, get the
											// details from TBL_VZB_FEATURES and
											// collect in a list.
											TblVzbFeaturesQuery vzbFeatQry = new TblVzbFeaturesQuery();
											whereClause = " where feature_id = "
													+ featId;
											// optional search for featureType
											if (featureType != null
													&& featureType.trim()
															.length() > 0)
												whereClause += " and feature_type = '"
														+ featureType + "'";
											System.out
													.println("Before vzbFeatQry in getFeaturePackagesForLocationByPackageNameAndLocationId Location");
											vzbFeatQry.queryByWhere(dbCon,
													whereClause);
											System.out
													.println("After vzbFeatQry in getFeaturePackagesForLocationByPackageNameAndLocationId Location");
											if (vzbFeatQry.size() > 0) {
												foundAtLeastOneFeature = true;
												DBTblVzbFeatures vzbFeatBean = new DBTblVzbFeatures();
												vzbFeatBean
														.copyFromBean(vzbFeatQry
																.getDbBean(0));
												if (vzbFeatBean != null) {
													FeaturesBean featBean = new FeaturesBean();
													featBean.setFeaturesDbBean(vzbFeatBean);
													featBean.setIsSelected((pkgFeatBean
															.getIsSelected())
															.equals("Y") ? true
															: false);
													// put into features
													// arraylist
													featList.add(featBean);
												}
											}
										} else {
											System.out
													.println("	FeatureId = "
															+ featId
															+ " is not authorized for the Ent, hence not included in the assign feature list");
										}
									}
								}
							} else {
								setStatus(InvErrorCode.NO_PKG_FEATURES_FOR_LOCATION);
								System.out
										.println("FAILURE in getFeaturePackagesForLocationByPackageNameAndLocationId Location. Pkg features not found for the given location id and package name");
								return false;
							}
							break;
						} else {
							continue;
						}
					} // if locbean is not null
				}// locpkg for loop
				if (!foundMatchingPkgId) {
					setStatus(InvErrorCode.NO_PKG_ID_FOR_LOCATION_ID);
					System.out
							.println("FAILURE in getFeaturePackagesForLocationByPackageNameAndLocationId Location. Package id not found for the given location id and package name");
					return false;
				}
				if (!foundAtLeastOneFeature) {
					setStatus(InvErrorCode.NO_FEATURES_FOR_LOCATION_ID_PKG_NAME);
					System.out
							.println("FAILURE in getFeaturePackagesForLocationByPackageNameAndLocationId Location. No features where found for the given location id and package name");
					return false;
				}
				/*
				 * long pkgId = (pkgQry.getDbBean(0)).getAuthServicesId();
				 * if(pkgId > 0) {
				 * if(!getAuthFeaturesByAuthServicesId((int)pkgId)) {
				 * setStatusCode("FAILURE"); setStatusDesc(
				 * "FAILURE in getFeatureListByFeaturePackageName FeaturePackage. No auth services for the given  auth services id."
				 * ); log.info(
				 * "FAILURE in getAuthDetails Enterprise. No auth services for the given  auth services id."
				 * ); return false; } } else { setStatusCode("FAILURE");
				 * setStatusDesc(
				 * "FAILURE in getFeatureListByFeaturePackageNameetails FeaturePackage. Invalid auth services id for enterprise"
				 * ); log.info(
				 * "FAILURE in getAuthDetails Enterprise. Invalid auth services id for enterprise"
				 * ); return false; }
				 */
			} else {
				setStatus(InvErrorCode.INVALID_LOC_ID_FOR_PKG_NAME);
				System.out
						.println("FAILURE in getFeaturePackagesForLocationByPackageNameAndLocationId Location. Invalid location_id for the given package name");
				return false;
			}
		} catch (Exception e) {
			e.printStackTrace();
			setStatus(InvErrorCode.DB_EXCEPTION);
			System.out
					.println("DB FAILURE in getFeatureListByFeaturePackageName for FeaturePackage");
			return false;
		}
		// set the results for output
		resultFeatPkgBean.setFeatureList(featList);
		featPkgList.add(resultFeatPkgBean);
		this.featurePkgList = featPkgList;
		setStatus(InvErrorCode.SUCCESS);
		System.out
				.println("Successfully retrieved getFeatureListByFeaturePackageName for FeaturePackage from the DB");
		return true;
	}

	public boolean getNetFeaturesBySubIdOrTn(String subId, boolean subIdIsTn,
			String featureType) {
		String locationIdLocal = null;
		String entIdLocal = null;
		long pkgIdLocal = 0;
		long groupTnId = 0;
		long groupId = 0;
		long fmcgPkgId = 0;
		boolean foundMatchingPkgId = false;
		boolean foundAtLeastOneFeature = false;
		FeaturePackageBean resultFeatPkgBean = new FeaturePackageBean();
		ArrayList<FeaturePackageBean> featPkgList = new ArrayList<FeaturePackageBean>();
		ArrayList<FeaturesBean> featList = new ArrayList<FeaturesBean>();
		try {
			if (subId != null && !subId.equalsIgnoreCase("")) {
				if (subIdIsTn) {
					long tnPoolId = getTnPoolIdByTn(subId);
					TblGroupTnQuery grpTnQry = new TblGroupTnQuery();
					grpTnQry.whereTnPoolIdEQ(tnPoolId);
					grpTnQry.query(dbCon);
					if (grpTnQry.size() > 0) {
						groupTnId = grpTnQry.getDbBean(0).getGroupTnId();
						groupId = grpTnQry.getDbBean(0).getGroupId();
						if (grpTnQry.getDbBean(0).getSubId() != null
								&& !grpTnQry.getDbBean(0).getSubId()
										.equalsIgnoreCase("")) {
							subId = grpTnQry.getDbBean(0).getSubId();
							TblSubscriberQuery subQry = new TblSubscriberQuery();
							String subWhereCls = " where sub_id = \'" + subId
									+ "\'";
							subQry.queryByWhere(dbCon, subWhereCls);
							if (subQry.size() > 0) {
								fmcgPkgId = subQry.getDbBean(0)
										.getFeaturePkgId();
							}
						}

						TblGroupQuery grpQry = new TblGroupQuery();
						grpQry.whereGroupIdEQ((int) groupId);
						grpQry.query(dbCon);
						if (grpQry.size() > 0) {
							locationIdLocal = grpQry.getDbBean(0)
									.getLocationId();
							pkgIdLocal = grpQry.getDbBean(0).getPackageId();
							TblLocationQuery locationQry = new TblLocationQuery();
							String locWhereCls = " where location_id = \'"
									+ locationIdLocal + "\'";
							locationQry.queryByWhere(dbCon, locWhereCls);
							if (locationQry.size() > 0) {
								entIdLocal = locationQry.getDbBean(0)
										.getEnterpriseId();
							} else {
								setStatus(InvErrorCode.INVALID_INPUT);
								System.out
										.println("Unable to retrieve enterprise for this tn ");
								return false;
							}
						} else {
							setStatus(InvErrorCode.INVALID_INPUT);
							System.out
									.println("tn is not part of valid group in ESAP. ");
							return false;
						}
					} else {
						setStatus(InvErrorCode.INVALID_INPUT);
						System.out
								.println("SubId is not valid in ESAP. No Group Tn entries found for this Tn");
						return false;
					}
				} else {
					TblSubscriberQuery subQry = new TblSubscriberQuery();
					String subWhereCls = " where sub_id = \'" + subId + "\'";
					subQry.queryByWhere(dbCon, subWhereCls);
					if (subQry.size() > 0) {
						locationIdLocal = subQry.getDbBean(0).getLocationId();
						pkgIdLocal = subQry.getDbBean(0).getFeaturePkgId();
						TblLocationQuery locationQry = new TblLocationQuery();
						String locWhereCls = " where location_id = \'"
								+ locationIdLocal + "\'";
						locationQry.queryByWhere(dbCon, locWhereCls);
						if (locationQry.size() > 0) {
							entIdLocal = locationQry.getDbBean(0)
									.getEnterpriseId();
						} else {
							setStatus(InvErrorCode.INVALID_INPUT);
							System.out
									.println("Unable to retrieve enterprise for this tn ");
							return false;
						}
					} else {
						setStatus(InvErrorCode.INVALID_INPUT);
						log.info("SubId is not valid in ESAP");
						return false;
					}
				}
			} else {
				setStatus(InvErrorCode.INVALID_INPUT);
				log.info("SubId is not set");
				return false;
			}
			log.info("locationId = " + locationIdLocal);
			log.info("enterpriseId = " + entIdLocal);
			log.info("featureType = " + featureType);
			log.info("packageId = " + pkgIdLocal);
			// get the list of Ent auth features, to later verify if the pkg
			// features are all authorized
			setEnterpriseId(enterpriseId);
			List<String> entAuthFeatureIdList = getEntAuthFeatureIdList(
					entIdLocal, featureType);
			List<String> disabledFeatureIdList = null;
			if (groupTnId > 0 || groupId > 0) {
				disabledFeatureIdList = getDisabledFeatureIdList(groupTnId,
						groupId);
			}
			List<String> featureIdList = new ArrayList<String>();
			if (entAuthFeatureIdList == null || entAuthFeatureIdList.size() < 1) {
				setStatus(InvErrorCode.NOTFOUND_ENT_AUTH_FEATURES_FOR_ENTERPRISE_ID);
				System.out
						.println("FAILURE in getFeaturePackagesForLocationByPackageIdAndLocationId. Enterprise auth feature list is null or empty List.");
				return false;
			}
			setLocationId(locationIdLocal);
			int numberOfPkgs = 1;
			if (fmcgPkgId > 0) {
				numberOfPkgs = 2;
			}
			for (int i = 0; i < numberOfPkgs; i++) {
				// NOTE: this means we have fmcg Pkg Id.
				if (i == 1) {
					pkgIdLocal = fmcgPkgId;
				}
				TblPackageQuery pkgQry = new TblPackageQuery();
				String whereClause = " where package_id = " + pkgIdLocal;
				pkgQry.queryByWhere(dbCon, whereClause);
				// Inner IF Five
				if (pkgQry.size() == 1) {
					foundMatchingPkgId = true;
					// query list of featureids for the given pkgid.
					TblPkgFeaturesQuery pkgFeatQry = new TblPkgFeaturesQuery();
					whereClause = " where package_id = " + pkgIdLocal
							+ " and is_selected=\'Y\'";
					pkgFeatQry.queryByWhere(dbCon, whereClause);
					// Inner IF Four
					if (pkgFeatQry.size() > 0) {
						// for each result featureid, query details from
						// TBL_VZB_FEATURES
						ArrayList result2 = pkgFeatQry.getResultArrayList();
						// Inner FOR One
						for (int j = 0; j < pkgFeatQry.size(); j++) {
							Object oPkgFeatBean = result2.get(j);
							// Inner IF Three
							if (oPkgFeatBean != null) {
								TblPkgFeaturesDbBean pkgFeatBean = (TblPkgFeaturesDbBean) oPkgFeatBean;
								long featId = Long.parseLong(pkgFeatBean
										.getFeatureId());
								// check if the feature id is in the list of Ent
								// auth features.
								if (entAuthFeatureIdList.contains("" + featId)) {
									// ignore if its part of disabled list
									if (disabledFeatureIdList == null
											|| !disabledFeatureIdList
													.contains("" + featId)) {
										// for the featureid, get the details
										// from TBL_VZB_FEATURES and collect in
										// a list.
										TblVzbFeaturesQuery vzbFeatQry = new TblVzbFeaturesQuery();
										whereClause = " where feature_id = "
												+ featId;
										// optional search for featureType
										if (featureType != null
												&& featureType.trim().length() > 0) {
											whereClause += " and feature_type = \'"
													+ featureType + "\'";
										}
										vzbFeatQry.queryByWhere(dbCon,
												whereClause);
										// Inner IF Two
										if (vzbFeatQry.size() > 0) {
											foundAtLeastOneFeature = true;
											DBTblVzbFeatures vzbFeatBean = new DBTblVzbFeatures();
											vzbFeatBean.copyFromBean(vzbFeatQry
													.getDbBean(0));
											// Inner IF One
											if (vzbFeatBean != null) {
												FeaturesBean featBean = new FeaturesBean();
												featBean.setFeaturesDbBean(vzbFeatBean);
												featBean.setIsSelected((pkgFeatBean
														.getIsSelected())
														.equals("Y") ? true
														: false);
												featList.add(featBean);
											}// End of Inner IF One
										}// End of Inner IF Two
									} else {
										System.out
												.println("        FeatureId = "
														+ featId
														+ " is in the disable feature list, hence not included in the assign feature list");
									}
								} else {
									System.out
											.println("        FeatureId = "
													+ featId
													+ " is not authorized for the Ent, hence not included in the assign feature list");
								}
							}// End of Inner IF Three
						}// End of Inner FOR One
					}// Inner IF Four
					else {
						setStatus(InvErrorCode.NO_PKG_FEATURES_FOR_LOCATION);
						System.out
								.println("FAILURE :Pkg features not found for the given location id and package name");
						return false;
					}
				}// Inner IF Five
			}
			if (!foundMatchingPkgId) {
				setStatus(InvErrorCode.NO_PKG_ID_FOR_LOCATION_ID);
				System.out
						.println("FAILURE :Package id not found for the given location id and package name");
				return false;
			}
			// getBillable features for subId
			if (!subIdIsTn || fmcgPkgId > 0) {
				TblSubFeatureQuery subFeatQuery = new TblSubFeatureQuery();
				String subFeatWhereCls = " where sub_id = \'" + subId
						+ "\' and is_selected = \'Y\'";
				subFeatQuery.queryByWhere(dbCon, subFeatWhereCls);
				if (subFeatQuery.size() > 0) {
					for (int k = 0; k < subFeatQuery.size(); k++) {
						DBTblSubFeature subFeatBean = new DBTblSubFeature();
						subFeatBean.copyFromBean(subFeatQuery.getDbBean(k));
						if (entAuthFeatureIdList.contains(""
								+ subFeatBean.getFeatureId())) {
							TblVzbFeaturesQuery vzbFeatQry = new TblVzbFeaturesQuery();
							String whereClause = " where feature_id = "
									+ subFeatBean.getFeatureId();
							if (featureType != null
									&& featureType.trim().length() > 0) {
								whereClause += " and feature_type = \'"
										+ featureType + "\'";
							}
							vzbFeatQry.queryByWhere(dbCon, whereClause);
							if (vzbFeatQry.size() > 0) {
								foundAtLeastOneFeature = true;
								DBTblVzbFeatures vzbFeatBean = new DBTblVzbFeatures();
								vzbFeatBean.copyFromBean(vzbFeatQry
										.getDbBean(0));
								if (vzbFeatBean != null) {
									FeaturesBean featBean = new FeaturesBean();
									featBean.setFeaturesDbBean(vzbFeatBean);
									featBean.setIsSelected((subFeatBean
											.getIsSelected()).equals("Y") ? true
											: false);
									featList.add(featBean);
								}
							}
						}
					}
				}
			}
			if (subIdIsTn && groupId > 0) {

				TblGroupFeaturesQuery grpFeatQuery = new TblGroupFeaturesQuery();
				grpFeatQuery.whereGroupIdEQ(groupId);
				grpFeatQuery.query(dbCon);
				if (grpFeatQuery.size() > 0) {
					for (int k = 0; k < grpFeatQuery.size(); k++) {
						DBTblGroupFeatures grpFeatBean = new DBTblGroupFeatures();
						grpFeatBean.copyFromBean(grpFeatQuery.getDbBean(k));
						if (entAuthFeatureIdList.contains(""
								+ grpFeatBean.getFeatureId())) {
							TblVzbFeaturesQuery vzbFeatQry = new TblVzbFeaturesQuery();
							String whereClause = " where feature_id = "
									+ grpFeatBean.getFeatureId();
							if (featureType != null
									&& featureType.trim().length() > 0) {
								whereClause += " and feature_type = \'"
										+ featureType + "\'";
							}
							vzbFeatQry.queryByWhere(dbCon, whereClause);
							if (vzbFeatQry.size() > 0) {
								foundAtLeastOneFeature = true;
								DBTblVzbFeatures vzbFeatBean = new DBTblVzbFeatures();
								vzbFeatBean.copyFromBean(vzbFeatQry
										.getDbBean(0));
								if (vzbFeatBean != null) {
									FeaturesBean featBean = new FeaturesBean();
									featBean.setFeaturesDbBean(vzbFeatBean);
									featList.add(featBean);
								}
							}
						}
					}
				}
			}
			if (!foundAtLeastOneFeature) {
				setStatus(InvErrorCode.NO_FEATURES_FOR_LOCATION_ID_PKG_NAME);
				System.out
						.println("No features where found for the given location id and package name");
				return true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
			setStatus(InvErrorCode.DB_EXCEPTION);
			System.out
					.println("DB FAILURE in Location::getNetFeaturesBySubIdOrTn");
			return false;
		}
		// set the results for output
		resultFeatPkgBean.setFeatureList(featList);
		featPkgList.add(resultFeatPkgBean);
		this.featurePkgList = featPkgList;
		setStatus(InvErrorCode.SUCCESS);
		System.out
				.println("Successfully retrieved getFeatureListByFeaturePackageId for FeaturePackage from the DB");
		return true;
	}

	public List<String> getDisabledFeatureIdList(long groupTnId, long groupId)
			throws SQLException {
		List<String> disabledFeatureIdList = new ArrayList<String>();
		TblGroupTnExcldFeaturesQuery grpTnExcldFeatQry = new TblGroupTnExcldFeaturesQuery();
		grpTnExcldFeatQry.whereGroupTnIdEQ(groupTnId);
		grpTnExcldFeatQry.query(dbCon);
		if (grpTnExcldFeatQry.size() > 0) {
			for (int i = 0; i < grpTnExcldFeatQry.size(); i++) {
				disabledFeatureIdList.add(""
						+ (grpTnExcldFeatQry.getDbBean(i)).getFeatureId());
			}
		}
		TblGroupExcldFeaturesQuery grpExcldFeatQry = new TblGroupExcldFeaturesQuery();
		grpExcldFeatQry.whereGroupIdEQ(groupId);
		grpExcldFeatQry.query(dbCon);
		if (grpExcldFeatQry.size() > 0) {
			for (int i = 0; i < grpExcldFeatQry.size(); i++) {
				disabledFeatureIdList.add(""
						+ (grpExcldFeatQry.getDbBean(i)).getFeatureId());
			}
		}
		return disabledFeatureIdList;
	}

	public List<String> getEtTnFeaturesByEtTn(long etTnId) {
		List<String> featPackageList = new ArrayList<String>();
		try {
			if (getEtTnFeaturesByIdOrTn(etTnId + "", false, null)) {
				if (this.featurePkgList != null
						&& this.featurePkgList.size() > 0) {
					FeaturePackageBean featPkgBean = (FeaturePackageBean) featurePkgList
							.get(0);
					for (int i = 0; i < featPkgBean.getFeatureList().size(); i++) {
						FeaturesBean fb = (FeaturesBean) featPkgBean
								.getFeatureList().get(i);
						featPackageList.add(fb.getFeaturesDbBean().getName());
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			setStatus(InvErrorCode.DB_EXCEPTION);
			System.out
					.println("getEtTnFeaturesByEtTn :: DB FAILURE in Location");
		}
		return featPackageList;
	}

	public boolean getEtTnFeaturesByIdOrTn(String id, boolean idIsTn,
			String featureType) {

		TblTsoEtTnDbBean etTn;
		try {
			if (id != null && !id.isEmpty()) {
				TblTsoEtTnQuery query = new TblTsoEtTnQuery();
				if (idIsTn) {
					query.whereTnPoolIdEQ(getTnPoolIdByTn(id));
				} else {
					query.whereEtTnIdEQ(Long.parseLong(id));
				}
				query.query(dbCon);
				if (query.size() > 0) {
					etTn = query.getDbBean(0);
				} else {
					setStatus(InvErrorCode.INVALID_INPUT);
					System.out
							.println("getEtTnFeaturesByIdOrTn :: No ET TN found for this ID/TN: "
									+ id);
					return false;
				}
			} else {
				setStatus(InvErrorCode.INVALID_INPUT);
				System.out
						.println("getEtTnFeaturesByIdOrTn :: Id cannot be empty");
				return false;
			}

			String entId;
			TblTsoEnterpriseTrunkQuery etQuery = new TblTsoEnterpriseTrunkQuery();
			etQuery.whereEnterpriseTrunkIdEQ(etTn.getEnterpriseTrunkId());
			etQuery.query(dbCon);
			if (etQuery.size() > 0) {
				entId = etQuery.getDbBean(0).getEnterpriseId();
			} else {
				setStatus(InvErrorCode.INVALID_INPUT);
				System.out
						.println("getEtTnFeaturesByIdOrTn :: Enterprise Id wasn't found");
				return false;
			}

			String locId;
			TblPublicTnPoolQuery poolQuery = new TblPublicTnPoolQuery();
			poolQuery.whereTnPoolIdEQ((int) etTn.getTnPoolId());
			poolQuery.query(dbCon);
			if (poolQuery.size() > 0) {
				locId = poolQuery.getDbBean(0).getLocationId();
			} else {
				setStatus(InvErrorCode.INVALID_INPUT);
				System.out
						.println("getEtTnFeaturesByIdOrTn :: Location Id wasn't found");
				return false;
			}

			long pkgId;
			TblLocPackageQuery locPkgQuery = new TblLocPackageQuery();
			locPkgQuery.whereLocationIdEQ(locId);
			locPkgQuery.query(dbCon);
			if (locPkgQuery.size() > 0) {
				pkgId = locPkgQuery.getDbBean(0).getPackageId();
			} else {
				setStatus(InvErrorCode.INVALID_INPUT);
				System.out
						.println("getEtTnFeaturesByIdOrTn :: Package Id wasn't found");
				return false;
			}

			log.info("getEtTnFeaturesByIdOrTn :: locationId = "
					+ locId);
			log.info("getEtTnFeaturesByIdOrTn :: enterpriseId = "
					+ entId);
			log.info("getEtTnFeaturesByIdOrTn :: featureType = "
					+ featureType);
			log.info("getEtTnFeaturesByIdOrTn :: packageId = "
					+ pkgId);

			List<String> entAuthFeatureIdList = getEntAuthFeatureIdList(entId,
					featureType);
			if (entAuthFeatureIdList == null || entAuthFeatureIdList.size() < 1) {
				setStatus(InvErrorCode.NOTFOUND_ENT_AUTH_FEATURES_FOR_ENTERPRISE_ID);
				System.out
						.println("FAILURE in getEtTnFeaturesByIdOrTn() - Enterprise auth feature list is null or empty List");
				return false;
			}

			List<String> disabledFeatureIdList = getEtTnDisabledFeatureIdList(etTn
					.getEtTnId());

			TblPackageQuery pkgQry = new TblPackageQuery();
			pkgQry.wherePackageIdEQ(pkgId);
			pkgQry.query(dbCon);

			boolean foundAtLeastOneFeature = false;
			ArrayList<FeaturesBean> featList = new ArrayList<FeaturesBean>();
			if (pkgQry.size() == 1) {
				TblPkgFeaturesQuery pkgFeatQry = new TblPkgFeaturesQuery();
				pkgFeatQry.wherePackageIdEQ(pkgId);
				pkgFeatQry.whereIsSelectedEQ("Y");
				pkgFeatQry.query(dbCon);

				if (pkgFeatQry.size() > 0) {
					// for each result featureid, query details from
					// TBL_VZB_FEATURES
					ArrayList featureList = pkgFeatQry.getResultArrayList();
					for (int j = 0; j < pkgFeatQry.size(); j++) {
						Object oPkgFeatBean = featureList.get(j);
						if (oPkgFeatBean != null) {
							TblPkgFeaturesDbBean pkgFeatBean = (TblPkgFeaturesDbBean) oPkgFeatBean;
							long featId = Long.parseLong(pkgFeatBean
									.getFeatureId());
							// check if the feature id is in the list of Ent
							// auth features
							if (entAuthFeatureIdList.contains("" + featId)) {
								// ignore if its part of disabled list
								if (disabledFeatureIdList == null
										|| !disabledFeatureIdList.contains(""
												+ featId)) {
									// for the featureid, get the details from
									// TBL_VZB_FEATURES and collect in a list
									TblVzbFeaturesQuery vzbFeatQry = new TblVzbFeaturesQuery();
									vzbFeatQry.whereFeatureIdEQ((int) featId);
									// optional search for featureType
									if (featureType != null
											&& featureType.trim().length() > 0) {
										vzbFeatQry
												.whereFeatureTypeEQ(featureType);
									}
									vzbFeatQry.query(dbCon);
									if (vzbFeatQry.size() > 0) {
										foundAtLeastOneFeature = true;
										DBTblVzbFeatures vzbFeatBean = new DBTblVzbFeatures();
										vzbFeatBean.copyFromBean(vzbFeatQry
												.getDbBean(0));
										if (vzbFeatBean != null) {
											FeaturesBean featBean = new FeaturesBean();
											featBean.setFeaturesDbBean(vzbFeatBean);
											featBean.setIsSelected((pkgFeatBean
													.getIsSelected())
													.equals("Y"));
											featList.add(featBean);
										}
									}
								} else {
									System.out
											.println("        FeatureId = "
													+ featId
													+ " is in the disable feature list, hence not included in the assign feature list");
								}
							} else {
								System.out
										.println("        FeatureId = "
												+ featId
												+ " is not authorized for the Ent, hence not included in the assign feature list");
							}
						}
					}
				} else {
					setStatus(InvErrorCode.NO_PKG_FEATURES_FOR_LOCATION);
					System.out
							.println("FAILURE :: Package features not found for the given location id and package name");
					return false;
				}
			} else {
				setStatus(InvErrorCode.NO_PKG_ID_FOR_LOCATION_ID);
				System.out
						.println("FAILURE :: Package id not found for the given location id and package name");
				return false;
			}

			if (!foundAtLeastOneFeature) {
				setStatus(InvErrorCode.NO_FEATURES_FOR_LOCATION_ID_PKG_NAME);
				System.out
						.println("getEtTnFeaturesByIdOrTn :: No features where found for the given location id and package name");
				return false;
			}

			// set the results for output
			FeaturePackageBean resultFeatPkgBean = new FeaturePackageBean();
			ArrayList<FeaturePackageBean> featPkgList = new ArrayList<FeaturePackageBean>();

			resultFeatPkgBean.setFeatureList(featList);
			featPkgList.add(resultFeatPkgBean);

			// fulfill location object
			this.enterpriseId = entId;
			this.locationId = locId;
			this.featurePkgList = featPkgList;

			setStatus(InvErrorCode.SUCCESS);

			System.out
					.println("Successfully retrieved getFeatureListByFeaturePackageId for FeaturePackage from the DB");

		} catch (SQLException e) {
			e.printStackTrace();
			setStatus(InvErrorCode.DB_EXCEPTION);
			System.out
					.println("getEtTnFeaturesByIdOrTn :: DB FAILURE in Location");
			return false;
		}

		return true;
	}

	public List<String> getEtTnDisabledFeatureIdList(long etTnId)
			throws SQLException {
		List<String> list = new ArrayList<String>();
		TblTsoEtTnExcldFeaturesQuery qry = new TblTsoEtTnExcldFeaturesQuery();
		qry.whereEtTnIdEQ(etTnId);
		qry.query(dbCon);
		if (qry.size() > 0) {
			for (int i = 0; i < qry.size(); i++) {
				list.add("" + (qry.getDbBean(i)).getFeatureId());
			}
		}
		return list;
	}

	public List<String> getEntAuthFeatureIdList(String enterpriseId) {

		// get a list of Enterprise Auth features
		log.info("Enterprise Id, in getEntAuthFeatureIdList is : "
				+ enterpriseId);
		List<String> entAuthFeatureIdList = new ArrayList<String>();
		Enterprise entObj = new Enterprise(dbCon);
		entObj.setEnterpriseId(enterpriseId);
		if (entObj.getAuthDetailsForEnterprise()) {
			List<FeaturesBean> invFeatureList = entObj.getAuthFeaturesList();

			if (invFeatureList != null && invFeatureList.size() > 0) {
				Iterator iter = invFeatureList.iterator();
				while (iter.hasNext()) {
					FeaturesBean feat = (FeaturesBean) iter.next();
					DBTblVzbFeatures tblVzbFeatures = feat.getFeaturesDbBean();
					String dbFeatureName = tblVzbFeatures.getName();

					if (feat.getIsAuthorized()) {
						log.info("Ent Auth feature id is "
								+ tblVzbFeatures.getFeatureId());
						entAuthFeatureIdList.add(""
								+ tblVzbFeatures.getFeatureId());
					} else {
						System.out
								.println("    The following feature is not authorized in Ent Auth Query = "
										+ dbFeatureName);
					}
				}
			}
		}

		return entAuthFeatureIdList;

	}

	public List<String> getEntAuthFeatureIdList(String enterpriseId,
			String featureType) {
		// get a list of Enterprise Auth features
		System.out
				.println("Enterprise Id, FeatureType in getEntAuthFeatureIdList is : "
						+ enterpriseId + ", " + featureType);
		List<String> entAuthFeatureIdList = new ArrayList<String>();
		Enterprise entObj = new Enterprise(dbCon);
		entObj.setEnterpriseId(enterpriseId);
		if (entObj.getAuthDetailsForEnterprise()) {
			List<FeaturesBean> invFeatureList = entObj.getAuthFeaturesList();
			if (invFeatureList != null && invFeatureList.size() > 0) {
				Iterator iter = invFeatureList.iterator();
				while (iter.hasNext()) {
					// log.info("Taking ent auth feature values from inventory");
					FeaturesBean feat = (FeaturesBean) iter.next();
					DBTblVzbFeatures tblVzbFeatures = feat.getFeaturesDbBean();
					String dbFeatureName = tblVzbFeatures.getName();
					String dbFeatureType = tblVzbFeatures.getFeatureType();
					if (feat.getIsAuthorized()) {
						if (featureType != null && featureType.length() > 0
								&& dbFeatureType.equals(featureType)) {
							// featureList.add(dbFeatureName);
							System.out
									.println("Ent Auth feature id for featuretype = "
											+ featureType
											+ " is "
											+ tblVzbFeatures.getFeatureId());
							entAuthFeatureIdList.add(""
									+ tblVzbFeatures.getFeatureId());
						} // IR #1397798 53122.AA - SCRUM - UCC Toolbar - UCC
							// Soft Phone or UCC Toolbar not dispalying
							// Removing the check condition of G and U
						else if (featureType == null
								|| featureType.length() <= 0)
						// && (dbFeatureType.equalsIgnoreCase("G") ||
						// dbFeatureType.equalsIgnoreCase("U")))
						{
							System.out
									.println("Ent Auth feature id for featuretype = "
											+ featureType
											+ " is "
											+ tblVzbFeatures.getFeatureId());
							entAuthFeatureIdList.add(""
									+ tblVzbFeatures.getFeatureId());
						}
					} else {
						System.out
								.println("	The following feature is not authorized in Ent Auth Query = "
										+ dbFeatureName);
					}
				}
			}
		}
		return entAuthFeatureIdList;
	}

	public boolean getCallingPlanForLocation() {
		try {
			// retrieve location details to get the callingPlanId
			boolean ret = getDetails();
			if (!ret) {
				setStatus(InvErrorCode.NO_LOCATION_FOUND_FOR_LOC_ID);
				System.out
						.println("FAILURE in getDetails Location. Location.getDetails returned false in getCallingPlanForLocation");
				return false;
			}
			System.out
					.println("In the Inventry, the Calling plan Id for Location = "
							+ locationId + " is -> " + callingPlanId);
			// if callingPlanId is valid, query the CallingPlan class for
			// details.
			CallingPlan cp = new CallingPlan(dbCon);
			cp.setCallingPlanId((int) callingPlanId);
			ret = cp.getDetails();
			if (!ret) {
				setStatus(InvErrorCode.NOTFOUND_CALLING_PLAN);
				System.out
						.println("FAILURE in CallingPlan.getDetails . CallingPlan.getDetails returned false in getCallingPlanForLocation");
				return false;
			}
			setCallingPlanBean((CallingPlanBean) cp);
		}
		/*
		 * catch(SQLException e) { setStatusCode("FAILURE");
		 * setStatusDesc("DB_FAILURE in getDetails CallingPlan"); return false;
		 * }
		 */
		catch (Exception e) {
			e.printStackTrace();
			setStatus(InvErrorCode.DB_EXCEPTION);
			log.info("FAILURE in getDetails CallingPlan");
			return false;
		}
		setStatus(InvErrorCode.SUCCESS);
		log.info("Successfully retrieved CallingPlan from the DB");
		return true;
	}

	// added by z658915 for calnet changes starts
	public List<String> getSubIDListByLocationId() {
		List<String> subIDList = new ArrayList<String>();

		PreparedStatement pStmnt = null;
		ResultSet rs = null;

		log.info("Entering Location::getSubscriberListByLocationId()");

		try {
			if (locationId == null || "".equalsIgnoreCase(locationId)) {
				setStatus(InvErrorCode.MISSING_LOCATION_ID);
				log.info("FAILURE in getSubscriberListByLocationId Location. Location Id missing.");
				throw new Exception("ESP_VZB_INV_LOCATION_NOT_FOUND");

			}
			String sql = "SELECT SUB_ID FROM TBL_SUBSCRIBER WHERE LOCATION_ID = ?";
			pStmnt = dbCon.prepareStatement(sql);
			pStmnt.setString(1, locationId);
			rs = pStmnt.executeQuery();
			while (rs.next()) {
				subIDList.add(rs.getString(1));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (pStmnt != null)
					pStmnt.close();
				if (rs != null)
					rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return subIDList;
	}
	// added by z658915 for calnet changes ends


	public boolean getGatewayDeviceListByLocationId() throws SQLException,
			Exception {
		System.out
				.println("Entering Location::getGatewayDeviceListByLocationId");
		if (locationId == null || "".equalsIgnoreCase(locationId)) {
			setStatus(InvErrorCode.MISSING_LOCATION_ID);
			System.out
					.println("FAILURE in getGatewayDeviceListByLocationId Location. Location Id missing.");
			return false;
		}
		Device devObj = new Device(dbCon);
		devObj.setLocationId(locationId);
		if (devObj.getGatewayDeviceIdListByLocationId()) {
			List<Long> gwDevIdList = devObj.getGwDeviceIdList();
			if (gwDevIdList.size() > 0) {
				for (int i = 0; i < gwDevIdList.size(); i++) {
					GatewayDevice gtwDev = new GatewayDevice(dbCon);
					gtwDev.setGatewayDeviceId((gwDevIdList.get(i)).longValue());
/*					if (gtwDev.getGwDeviceDetailsByGatewayDeviceId()) {
						GatewayDeviceBean gtwDevBean = gtwDev;
						deviceList.add(gtwDevBean);
					}*/
				}
				if (deviceList.size() <= 0) {
					log.info("No Gateway Device Found");
					setStatus(InvErrorCode.NO_GATEWAY_DEVICE_FOR_LOCATION_ID);
					return false;
				}
			} else {
				log.info("No Devices Found By Location Id["
						+ locationId + "]");
				setStatus(InvErrorCode.NO_GATEWAY_DEVICE_FOR_LOCATION_ID);
				return false;
			}
		} else {
			setStatus(InvErrorCode.NO_GATEWAY_DEVICE_FOR_LOCATION_ID);
			log.info("Failed to Retrieve Devices By LocationId ["
					+ locationId + "]");
			return false;
		}
		log.info("Sucessfully Retrieved [" + deviceList.size()
				+ "] Gateway Devices");
		return true;
	}

	/**
	 * @return
	 */
	public boolean getPublicTnPoolForLocation() {
		try {
			ArrayList<PublicTnPoolBean> ptnPoolList = new ArrayList<PublicTnPoolBean>();
			// retrieve location details to get the enterpriseId
			if (locationId == null || "".equalsIgnoreCase(locationId)) {
				setStatus(InvErrorCode.INVALID_LOC_ID);
				System.out
						.println("FAILURE in getPublicTnPoolForLocation Location. locationId in Location is not valid");
				return false;
			}
			setLocationId(locationId);
			TblPublicTnPoolQuery ptnPoolQry = new TblPublicTnPoolQuery();
			String whereClause = " where location_id = \'" + locationId + "\'";
			System.out
					.println("Before ptnPoolQry in getPublicTnPoolDetailsByLocation Location");
			ptnPoolQry.queryByWhere(dbCon, whereClause);
			System.out
					.println("After ptnPoolQry in getPublicTnPoolDetailsByLocation Location");
			if (ptnPoolQry.size() > 0) {
				for (int i = 0; i < ptnPoolQry.size(); i++) {
					TblPublicTnPoolDbBean tnDbBean = ptnPoolQry.getDbBean(i);
					PublicTnPoolBean ptnPool = new PublicTnPoolBean();
					ptnPool.setTnPoolId(tnDbBean.getTnPoolId());
					ptnPool.setLocationId(tnDbBean.getLocationId());
					ptnPool.setDepartmentId(tnDbBean.getDepartmentId());
					ptnPool.setTn(tnDbBean.getTn());
					ptnPool.setTnStatus(tnDbBean.getTnStatus());
					ptnPool.setPortedStatus(tnDbBean.getPortedStatus());
					ptnPool.setNpaSplitStatus(tnDbBean.getNpaSplitStatus());
					ptnPool.setCreatedBy(tnDbBean.getCreatedBy());
					ptnPool.setModifiedBy(tnDbBean.getModifiedBy());
					ptnPool.setEnvOrderId(tnDbBean.getEnvOrderId());
					ptnPoolList.add(ptnPool);
				}
			} else {
				setStatus(InvErrorCode.NO_PUBLICTNPOOL_FOR_LOC_ID);
				System.out
						.println("FAILURE in getPublicTnPoolDetailsByLocation Location. Public Tn Pool not found for the given location id ");
				return false;
			}
			setPublicTnPool(ptnPoolList);
		} catch (SQLException e) {
			e.printStackTrace();
			setStatus(InvErrorCode.DB_EXCEPTION);
			return false;
		}
		setStatus(InvErrorCode.SUCCESS);
		log.info("Successfully retrieved PublicTnPool from the DB");
		return true;
	}

	public boolean getDialPlanForLocation() {
		return true;
	}

/*	public static List<LocationSummary> getSummary(Connection connection,
			Criteria criteria) {
		return null;
	}

	public static List<FeaturePackageSummary> getFeaturePackageSummary(
			Connection connection) {
		return null;
	}*/

/*	public List<LocationSummary> getSummary(Connection dbCon,
			String LocationName, String CustomerName) {
		List<LocationSummary> resultList = new ArrayList<LocationSummary>();
		LocationSummary locSum = new LocationSummary();
		TblLocationQuery locQry = new TblLocationQuery();
		TblCustomerQuery cusQry = new TblCustomerQuery();
		try {
			if (LocationName != null && CustomerName == null) {
				String whereClause = " where location_name = \'" + LocationName
						+ "\'";
				locQry.queryByWhere(dbCon, whereClause);
				if (locQry.size() == 1) {
					locSum.setLocationId(locQry.getDbBean(0).getLocationId());
					locSum.setLocationName(locQry.getDbBean(0)
							.getLocationName());
				}
				String customerId = locQry.getDbBean(0).getEnterpriseId();
				whereClause = "";
				whereClause = " where customer_id = \'" + customerId + "\'";
				cusQry.queryByWhere(dbCon, whereClause);
				if (cusQry.size() == 1) {
					locSum.setCustomerName(cusQry.getDbBean(0)
							.getCustomerName());
				}
				resultList.add(locSum);
			} else if (CustomerName != null && LocationName == null) {
				String whereClause = " where customer_name = \'" + CustomerName
						+ "\'";
				cusQry.queryByWhere(dbCon, whereClause);
				String customerId = new String("");
				if (cusQry.size() == 1) {
					locSum.setCustomerName(cusQry.getDbBean(0)
							.getCustomerName());
					customerId = cusQry.getDbBean(0).getCustomerId();
				}
				whereClause = "";
				whereClause = " where enterprise_id = \'" + customerId + "\'";
				locQry.queryByWhere(dbCon, whereClause);
				if (locQry.size() == 1) {
					locSum.setLocationId(locQry.getDbBean(0).getLocationId());
					locSum.setLocationName(locQry.getDbBean(0)
							.getLocationName());
				}
				resultList.add(locSum);
			} else if (CustomerName != null && LocationName != null) {
				String whereClause = " where customer_name = \'" + CustomerName
						+ "\'";
				cusQry.queryByWhere(dbCon, whereClause);
				String customerId = new String("");
				if (cusQry.size() == 1) {
					locSum.setCustomerName(cusQry.getDbBean(0)
							.getCustomerName());
					customerId = cusQry.getDbBean(0).getCustomerId();
				}
				whereClause = "";
				whereClause = " where enterprise_id = \'" + customerId + "\'";
				whereClause = whereClause + " and location_name = \'"
						+ LocationName + "\'";
				locQry.queryByWhere(dbCon, whereClause);
				if (locQry.size() == 1) {
					locSum.setLocationId(locQry.getDbBean(0).getLocationId());
					locSum.setLocationName(locQry.getDbBean(0)
							.getLocationName());
				}
				resultList.add(locSum);
			}
			if (CustomerName == null && LocationName == null) {
				cusQry.query(dbCon);
				if (cusQry.size() > 0) {
					for (int i = 0; i < cusQry.size() && i < 1000; i++) {
						TblCustomerDbBean cusDbBean = cusQry.getDbBean(i);
						locSum.setCustomerName(cusDbBean.getCustomerName());
						String customerId = cusDbBean.getCustomerId();
						String whereClause = " where enterprise_id = \'"
								+ customerId + "\'";
						locQry.queryByWhere(dbCon, whereClause);
						if (locQry.size() == 1) {
							locSum.setLocationId(locQry.getDbBean(0)
									.getLocationId());
							locSum.setLocationName(locQry.getDbBean(0)
									.getLocationName());
						}
						resultList.add(locSum);
					}
				}
			}
		} catch (Exception e) {
			setStatus(InvErrorCode.DB_EXCEPTION);
			log.info("DB_FAILURE in getSummary in Location ");
			e.printStackTrace();
		}
		return resultList;
	}*/

	// Before calling this method set enterpriseId
	public boolean getBsAsforLocation() {
		TblEnterpriseQuery entQry = new TblEnterpriseQuery();
		TblBsAsQuery bsAsQry = new TblBsAsQuery();
		DBTblBsAs bsAsBean = new DBTblBsAs();
		boolean result = false;
		String whereClause = " where enterprise_id = \'" + enterpriseId + "\'";
		try {
			entQry.queryByWhere(dbCon, whereClause);
			long asId = 0;
			if (entQry.size() == 1) {
				asId = entQry.getDbBean(0).getAsId();
			}
			if (asId > 0) {
				result = true;
				String whrClause = null;
				whrClause = " where bs_as_id = " + asId;
				bsAsQry.queryByWhere(dbCon, whrClause);
				if (bsAsQry.size() == 1) {
					bsAsBean.setBsAsId(bsAsQry.getDbBean(0).getBsAsId());
					bsAsBean.setAsName(bsAsQry.getDbBean(0).getAsName());
					bsAsBean.setAsClli(bsAsQry.getDbBean(0).getAsClli());
					bsAsBean.setAsIpAddress(bsAsQry.getDbBean(0)
							.getAsIpAddress());
					bsAsBean.setAsPort(bsAsQry.getDbBean(0).getAsPort());
					bsAsBean.setAsGroupWebLink(bsAsQry.getDbBean(0)
							.getAsGroupWebLink());
					bsAsBean.setAsGlobalWebLink(bsAsQry.getDbBean(0)
							.getAsGlobalWebLink());
					bsAsBean.setVersion(bsAsQry.getDbBean(0).getVersion());
					bsAsBean.setAsProfile(bsAsQry.getDbBean(0).getAsProfile());
					bsAsBean.setProxyClusterId(bsAsQry.getDbBean(0)
							.getProxyClusterId());
					// bsAsBean.setSystemAccessUid(bsAsQry.getDbBean(0).getSystemAccessUid());
					// bsAsBean.setSystemAccessPwd(bsAsQry.getDbBean(0).getSystemAccessPwd());
					// bsAsBean.setSystemViewUid(bsAsQry.getDbBean(0).getSystemViewUid());
					// bsAsBean.setSystemViewPwd(bsAsQry.getDbBean(0).getSystemViewPwd());
					bsAsBean.setCappedFlag(bsAsQry.getDbBean(0).getCappedFlag());
					bsAsBean.setOverrideCappedFlag(bsAsQry.getDbBean(0)
							.getOverrideCappedFlag());
					bsAsBean.setDisplayIndicator(bsAsQry.getDbBean(0)
							.getDisplayIndicator());
					bsAsBean.setActiveIndicator(bsAsQry.getDbBean(0)
							.getActiveIndicator());
					bsAsBean.setModifiedBy(bsAsQry.getDbBean(0).getModifiedBy());
					bsAsBean.setLastModifiedDate(bsAsQry.getDbBean(0)
							.getLastModifiedDate());
				}
				setBsAsDbBean(bsAsBean);
			}
		} catch (SQLException e) {
			setStatus(InvErrorCode.DB_EXCEPTION);
			log.info("DB_FAILURE in BsAs Location");
			e.printStackTrace();
			return result;
		}
		setStatus(InvErrorCode.SUCCESS);
		log.info("Successfully retrived for BsAs");
		return result;
	}

	public long getTnPoolIdByTn(String tn) {
		log.info("Entering Location::getTnPoolIdByTn");
		log.info("!! Tn " + tn);
		log.info("!! AFter printing");
		long tnPoolId = 0;
		if (tn == null || tn.trim().equals("")) {
			tn = "0";
		}
		try {
			TblPublicTnPoolQuery tnQry = new TblPublicTnPoolQuery();
			tnQry.whereTnEQ(tn);
			tnQry.query(dbCon);
			if (tnQry.size() <= 0) {
				log.info("TN [" + tn + "] Not Found");
				return tnPoolId;
			}
			tnPoolId = tnQry.getDbBean(0).getTnPoolId();
			log.info("Retrieved TN Id [" + tnPoolId + "] For Tn ["
					+ tn + "]");
		} catch (SQLException e) {
			setStatus(InvErrorCode.DB_EXCEPTION);
			log.info("Failed to retrieve TN Id");
			e.printStackTrace();
			return tnPoolId;
		}
		setStatus(InvErrorCode.SUCCESS);
		log.info("Successfully retrived TN Id");
		return tnPoolId;
	}

	public String getTnByTnPoolId(long tnPoolId) {
		log.info("Entering Location::getTnByTnPoolId");
		String tn = "";
		try {
			TblPublicTnPoolQuery tnQry = new TblPublicTnPoolQuery();
			tnQry.whereTnPoolIdEQ((int) tnPoolId);
			tnQry.query(dbCon);
			if (tnQry.size() <= 0) {
				log.info("TN [" + tn + "] Not Found");
				return tn;
			}
			tn = tnQry.getDbBean(0).getTn();
			log.info("Retrieved TN [" + tn + "] For TnId ["
					+ tnPoolId + "]");
		} catch (SQLException e) {
			setStatus(InvErrorCode.DB_EXCEPTION);
			log.info("Failed to retrieve TN");
			e.printStackTrace();
			return tn;
		}
		setStatus(InvErrorCode.SUCCESS);
		log.info("Successfully retrived TN");
		return tn;
	}

	public boolean getVmAccessListByLocationId() {
		log.info("Entering Location::getVmAccessListByLocationId");
		try {
			if (locationId == null || "".equalsIgnoreCase(locationId)) {
				setStatus(InvErrorCode.INVALID_LOC_ID);
				System.out
						.println("FAILURE in getVmAccessListByLocationId Location. locationId in Location is not valid");
				return false;
			}
			TblVmAccessQuery vmQry = new TblVmAccessQuery();
			String whereCls = " where location_id =\'" + locationId + "\'";
			// vmQry.whereLocationIdEQ(locationId);
			vmQry.queryByWhere(dbCon, whereCls);
			if (vmQry.size() <= 0) {
				log.info("Location Id not Found");
				setStatus(InvErrorCode.NO_VM_ACCESS_FOR_LOCATION);
				return false;
			}
			for (int i = 0; i < vmQry.size(); i++) {
				TblVmAccessDbBean vmDbBean = vmQry.getDbBean(i);
				/*VmAccess vma = new VmAccess(dbCon);
				vma.setEnterpriseId(vmDbBean.getEnterpriseId());
				vma.setLocationId(vmDbBean.getLocationId());
				vma.setPublicPoolId(vmDbBean.getPublicPoolId());
				String tn = getTnByTnPoolId(vmDbBean.getPublicPoolId());
				vma.setPublicNumber(tn);
				vma.setPrivateNumber(vmDbBean.getPrivateNumber());
				vma.setNpaSplitStatus(vmDbBean.getNpaSplitStatus());
				vma.setCreatedBy(vmDbBean.getCreatedBy());
				vma.setModifiedBy(vmDbBean.getModifiedBy());
				vma.setCreationDate(vmDbBean.getCreationDate());
				vma.setLastModifiedDate(vmDbBean.getLastModifiedDate());
				vma.setEnvOrderId(vmDbBean.getEnvOrderId());
				vmAccessList.add(vma);*/
			}
		} catch (SQLException e) {
			setStatus(InvErrorCode.DB_EXCEPTION);
			log.info("DB_FAILURE in getVmAccessDetailsByVmAccessId");
			e.printStackTrace();
			return false;
		}
		setStatus(InvErrorCode.SUCCESS);
		log.info("Successfully retrieved VM Access from DB");
		return true;
	}

	public boolean getAuthCodeListByLocationId() {
		log.info("Entering Location::getAuthCodeListByLocationId");
		try {
			if (locationId == null || "".equalsIgnoreCase(locationId)) {
				setStatus(InvErrorCode.INVALID_LOC_ID);
				System.out
						.println("FAILURE in getAuthCodeListByLocationId Location. locationId in Location is not valid");
				return false;
			}
			TblAcctAuthCodesQuery authQry = new TblAcctAuthCodesQuery();
			// authQry.whereLocationIdEQ(locationId);
			// authQry.query(dbCon);
			String whereCls = " where location_id =\'" + locationId + "\'";
			authQry.queryByWhere(dbCon, whereCls);
			if (authQry.size() <= 0) {
				log.info("Auth code not Found");
				setStatus(InvErrorCode.NO_AUTH_CODE_FOR_LOCATION_ID);
				return false;
			}
			for (int i = 0; i < authQry.size(); i++) {
				//AcctAuthCodes authCode = new AcctAuthCodes(dbCon);
/*				TblAcctAuthCodesDbBean authDbBean = authQry.getDbBean(0);
				authCode.setStrLocationId(authDbBean.getLocationId());
				authCode.setStrAcctAuthCode(authDbBean.getAcctAuthCode());
				authCode.setStrAcctAuthDesc(authDbBean.getAcctAuthDesc());
				authCode.setLongCodeType(authDbBean.getCodeType());
				authCode.setStrCreatedBy(authDbBean.getCreatedBy());
				authCode.setStrModifiedBy(authDbBean.getModifiedBy());
				authCode.setStrCreationDate(authDbBean.getCreationDate());
				authCode.setStrLastModifiedDate(authDbBean
						.getLastModifiedDate());
				authCode.setEnvOrderId(authDbBean.getEnvOrderId());
				authCodesList.add(authCode);*/
			}
		} catch (SQLException e) {
			setStatus(InvErrorCode.DB_EXCEPTION);
			log.info("DB_FAILURE in getAuthCodeListByLocationId");
			e.printStackTrace();
			return false;
		}
		setStatus(InvErrorCode.SUCCESS);
		log.info("Successfully retrieved Auth Codes from DB");
		return true;
	}

	public long addToPublicPool(String tn, int tnStatus, long tnType,
			long stnInd) {
		log.info("Entering Location::addToPublicPool");
		long tnId = 0;
		try {
			/*
			 * DBTblPublicTnPool pubTnPoolDbBean = new DBTblPublicTnPool(); int
			 * tnPoolId = pubTnPoolDbBean.getTnPoolIdSeqNextVal(dbCon);
			 * pubTnPoolDbBean.setLocationId(locationId);
			 * pubTnPoolDbBean.setTn(tn); pubTnPoolDbBean.setTnStatus(tnStatus);
			 * if(getEnvOrderId() > 0)
			 * pubTnPoolDbBean.setEnvOrderId(getEnvOrderId()); else
			 * pubTnPoolDbBean.setEnvOrderIdNull();
			 * pubTnPoolDbBean.setPortedStatus("" +
			 * VzbVoipEnum.PortStatus.NATIVE);
			 * pubTnPoolDbBean.setModifiedBy("ESAP_INV");
			 * pubTnPoolDbBean.setCreatedBy("ESAP_INV");
			 * pubTnPoolDbBean.setLastModifiedDate(new
			 * Timestamp(System.currentTimeMillis()));
			 * pubTnPoolDbBean.setCreationDate(new
			 * Timestamp(System.currentTimeMillis()));
			 * pubTnPoolDbBean.insert(dbCon);
			 */
			PublicTnPool pubTnPoolObj = new PublicTnPool(dbCon);
			pubTnPoolObj.setLocationId(locationId);
			pubTnPoolObj.setTn(tn);
			pubTnPoolObj.setTnStatus(tnStatus);
			pubTnPoolObj.setTnType(tnType);
			pubTnPoolObj.setPortedStatus("" + VzbVoipEnum.PortStatus.NATIVE);
			pubTnPoolObj.setModifiedBy("ESAP_INV");
			pubTnPoolObj.setCreatedBy("ESAP_INV");
			pubTnPoolObj.setLastModifiedDate(new Timestamp(System
					.currentTimeMillis()));
			pubTnPoolObj.setCreationDate(new Timestamp(System
					.currentTimeMillis()));
			pubTnPoolObj.setEnvOrderId(getEnvOrderId());
			// STN Code here
			log.info(" stnInd " + stnInd);
			pubTnPoolObj.setStnInd(stnInd);
			pubTnPoolObj.addPublicTnPool();
			tnId = pubTnPoolObj.getTnPoolId();
			log.info(" tnId in addpublicpool " + tnId);
		} catch (Exception e) {
			setStatus(InvErrorCode.DB_EXCEPTION);
			log.info("DB_FAILURE in addToPublicPool");
			e.printStackTrace();
			return tnId;
		}
		setStatus(InvErrorCode.SUCCESS);
		log.info("Successfully inserted Tn");
		return tnId;
	}

	/*
	 * The following are the wrapper add, modify delete methods for all the
	 * complex types (found in Bean class).
	 * 
	 * protected List<FeaturePackageBean> featurePkgList; //protected
	 * List<DBTblPublicTnPool> publicTnPoolList; protected
	 * List<GatewayDeviceBean> deviceList; protected List<VmAccess>
	 * vmAccessList; protected List<AcctAuthCodes> authCodesList; protected
	 * List<PrefixPlanBean> prefixPlanList; protected DBTblBsAs bsAsDbBean;
	 * protected CallingPlanBean callingPlanBean; protected List <PrefixRouting>
	 * prefixRouting; protected List <PublicTnPool> publicTnPool;
	 */
	/**
	 * The wrapper method to Add FeaturePackage To Location.
	 * 
	 * @return true Operation Successful false Operation UnSuccessful
	 * 
	 * @author banala
	 */
	public boolean addFeaturePackageToLocation() {
		try {
			/*
			 * Iterate on the feature packages and perform following steps 1)
			 * Check if the Package Id exists. First by Package Id.. if not
			 * found with Package Name 2) If Package does not exists then Add
			 * the record in TBL_PACKAGE and for all features add records
			 * inTBL_PACKAGE_FEATURES 3) Add an entry in Loc Package to map
			 * Location Id with the new Package.
			 */
			if (featurePkgList.size() > 0) {
				for (int i = 0; i < featurePkgList.size(); i++) {
					FeaturePackageBean featurePackageBean = featurePkgList
							.get(i);
					// 1) Check if the Package Id exists. First by Package Id..
					// if not found with Package Name
					long pkgId = featurePackageBean.getFeaturePackageId();
					if (isPackageExisting(featurePackageBean
							.getFeaturePackageId()) == false) {
						if (isPackageExisting(featurePackageBean
								.getFeaturePackageName()) == false) {
							if (areFeaturesValid(featurePackageBean) == true) {
								pkgId = addPackageAndFeatures(featurePackageBean);
							} else {
								setStatus(InvErrorCode.INVALID_VZB_FEATURE);
								return false;
							}
						}
					}
					addLocationPackage(pkgId);
				}
			} else {
				setStatus(InvErrorCode.SUCCESS);
				log.info("No FeaturePackages to Add");
				return true;
			}
		} catch (Exception e) {
			setStatus(InvErrorCode.ERROR_ADDING_FEATURE_PACKAGE_TO_LOCATION);
			log.info("FAILURE in addFeaturePackageToLocation.");
			e.printStackTrace();
			return false;
		}
		setStatus(InvErrorCode.SUCCESS);
		log.info("Successfully added Feature Package to Location");
		return true;
	}

	/**
	 * The method to check if the input features are all valid.
	 * 
	 * @param featurePackageBean
	 * @return true Features Valid false Features InValid
	 * @throws SQLException
	 */
	private boolean areFeaturesValid(FeaturePackageBean featurePackageBean)
			throws SQLException {
		List<FeaturesBean> featList = featurePackageBean.getFeatureList();
		if (featList.size() > 0) {
			String whereClause;
			TblVzbFeaturesQuery vzbFeatQry = new TblVzbFeaturesQuery();
			for (int i = 0; i < featList.size(); i++) {
				whereClause = "where FEATURE_ID = "
						+ featList.get(i).getFeaturesDbBean().getFeatureId();
				vzbFeatQry.queryByWhere(dbCon, whereClause);
				if (vzbFeatQry.size() <= 0) {
					whereClause = "where NAME = "
							+ featList.get(i).getFeaturesDbBean().getName();
					vzbFeatQry.queryByWhere(dbCon, whereClause);
					if (vzbFeatQry.size() <= 0) {
						return false;
					}
					featList.get(i)
							.getFeaturesDbBean()
							.setFeatureId(
									vzbFeatQry.getDbBean(0).getFeatureId());
				}
			}
		} else {
			return false;
		}
		return true;
	}

	/**
	 * The method to check if a package exists with specified Package Id
	 * 
	 * @param pkgId
	 *            The Package Id
	 * @return true Package Exists false Package Doesnot Exists
	 * @throws SQLException
	 */
	private boolean isPackageExisting(long pkgId) throws SQLException {
		TblPackageQuery pkgQry = new TblPackageQuery();
		pkgQry.wherePackageIdEQ(pkgId);
		pkgQry.query(dbCon);
		if (pkgQry.size() <= 0) {
			return false;
		}
		return true;
	}

	/**
	 * The method to check if a package exists with specified Package Name
	 * 
	 * @param pkgName
	 *            The Package Name
	 * @return true Package Exists false Package Doesnot Exists
	 * @throws SQLException
	 */
	private boolean isPackageExisting(String pkgName) throws SQLException {
		TblPackageQuery pkgQry = new TblPackageQuery();
		pkgQry.wherePackageNameEQ(pkgName);
		pkgQry.query(dbCon);
		if (pkgQry.size() <= 0) {
			return false;
		}
		return true;
	}

	/**
	 * The method to Add Package and Features entries
	 * 
	 * @param featurePackageBean
	 *            The datastructure holding Package and Feature details to be
	 *            added
	 * @return The Package Id
	 * @throws SQLException
	 */
	private long addPackageAndFeatures(FeaturePackageBean featurePackageBean)
			throws SQLException {
		DBTblPackage packageDbBean = new DBTblPackage();
		long pkgId = packageDbBean.getPackageIdSeqNextVal(dbCon);
		packageDbBean.setPackageId(pkgId);
		packageDbBean
				.setPackageType(featurePackageBean.getFeaturePackageType());
		packageDbBean
				.setPackageName(featurePackageBean.getFeaturePackageName());
		packageDbBean.setTemplateInd(0);
		if (featurePackageBean.getCreatedBy() != null
				&& !featurePackageBean.getCreatedBy().equals(""))
			packageDbBean.setCreatedBy(featurePackageBean.getCreatedBy());
		else
			packageDbBean.setCreatedBy("ESAP_INV");
		packageDbBean
				.setCreationDate(new Timestamp(System.currentTimeMillis()));
		if (featurePackageBean.getModifiedBy() != null
				&& !featurePackageBean.getModifiedBy().equals(""))
			packageDbBean.setModifiedBy(featurePackageBean.getModifiedBy());
		else
			packageDbBean.setModifiedBy("ESAP_INV");
		packageDbBean.setLastModifiedDate(new Timestamp(System
				.currentTimeMillis()));
		packageDbBean.insert(dbCon);
		List<FeaturesBean> featList = featurePackageBean.getFeatureList();
		if (featList.size() > 0) {
			for (int i = 0; i < featList.size(); i++) {
				DBTblPkgFeatures pkgFeatDbBean = new DBTblPkgFeatures();
				long pkgFeatId = pkgFeatDbBean.getPkgFeatureIdSeqNextVal(dbCon);
				pkgFeatDbBean.setPkgFeatureId((int) pkgFeatId);
				pkgFeatDbBean.setPackageId(pkgId);
				pkgFeatDbBean.setFeatureId(featList.get(i).getFeaturesDbBean()
						.getFeatureId()
						+ "");
				pkgFeatDbBean.setIsSelected(Boolean.toString(featList.get(i)
						.getIsSelected()));
				if (featurePackageBean.getCreatedBy() != null
						&& !featurePackageBean.getCreatedBy().equals(""))
					pkgFeatDbBean.setCreatedBy(featurePackageBean
							.getCreatedBy());
				else
					pkgFeatDbBean.setCreatedBy("ESAP_INV");
				pkgFeatDbBean.setCreationDate(featurePackageBean
						.getCreatedDate());
				if (featurePackageBean.getModifiedBy() != null
						&& !featurePackageBean.getModifiedBy().equals(""))
					pkgFeatDbBean.setModifiedBy(featurePackageBean
							.getModifiedBy());
				else
					pkgFeatDbBean.setModifiedBy("ESAP_INV");
				pkgFeatDbBean.setLastModifiedDate(featurePackageBean
						.getModifiedDate());
				log.info("PackageId=" + pkgId + ", pkgFeatId= "
						+ pkgFeatId + "");
				pkgFeatDbBean.insert(dbCon);
			}
		}
		return pkgId;
	}

	/**
	 * @param pkgId
	 * @throws SQLException
	 */
	private void addLocationPackage(long pkgId) throws SQLException {
		DBTblLocPackage locPkgDbBean = new DBTblLocPackage();
		int locPkgId = locPkgDbBean.getLocPackageIdSeqNextVal(dbCon);
		locPkgDbBean.setLocationId(getLocationId());
		locPkgDbBean.setPackageId(pkgId);
		locPkgDbBean.setIsDefault(0);
		if (getModifiedBy() != null && !("".equalsIgnoreCase(getModifiedBy()))) {
			locPkgDbBean.setModifiedBy(getModifiedBy());
		} else {
			locPkgDbBean.setModifiedBy("ESAP_INV");
		}
		if (getCreatedBy() != null && !("".equalsIgnoreCase(getCreatedBy()))) {
			locPkgDbBean.setCreatedBy(getCreatedBy());
		} else {
			locPkgDbBean.setCreatedBy("ESAP_INV");
		}
		locPkgDbBean.setLastModifiedDate(new Timestamp(System
				.currentTimeMillis()));
		locPkgDbBean.setCreationDate(new Timestamp(System.currentTimeMillis()));
		locPkgDbBean.insert(dbCon);
	}

	/**
	 * The wrapper method to Delete FeaturePackage from Location.
	 * 
	 * @return true Operation Successful false Operation UnSuccessful
	 * 
	 * @author banala
	 */
	public boolean deleteFeaturePackageOfLocation() {
		try {
			if (featurePkgList.size() > 0) {
				for (int i = 0; i < featurePkgList.size(); i++) {
					FeaturePackageBean featurePackageBean = featurePkgList
							.get(i);
					FeaturePackage featurePackage = new FeaturePackage(
							featurePackageBean, dbCon);
					if (!featurePackage.deletePkgFeature()) {
						setStatus(InvErrorCode.ERROR_DELETING_FEATURE_PACKAGE_TO_LOCATION);
						log.info(featurePackage.getStatusDesc());
						return false;
					}
				}
			} else {
				setStatus(InvErrorCode.SUCCESS);
				log.info("No FeaturePackages to Delete");
				return true;
			}
		} catch (Exception e) {
			setStatus(InvErrorCode.ERROR_DELETING_FEATURE_PACKAGE_TO_LOCATION);
			log.info("FAILURE in deleteFeaturePackageOfLocation.");
			e.printStackTrace();
			return false;
		}
		setStatus(InvErrorCode.SUCCESS);
		System.out
				.println("Successfully deleted Feature Package from Location");
		return true;
	}

	/**
	 * The wrapper method to Add GatewayDevice To Location.
	 * 
	 * @return true Operation Successful false Operation UnSuccessful
	 * 
	 * @author banala
	 */
	public boolean addGatewayDeviceToLocation() {
		try {
			if (deviceList.size() > 0) {
				for (int i = 0; i < deviceList.size(); i++) {
					GatewayDeviceBean gatewayDeviceBean = deviceList.get(i);
					GatewayDevice gatewayDevice = new GatewayDevice(
							gatewayDeviceBean, dbCon);
					if (!gatewayDevice.addGatewayDevice()) {
						setStatus(InvErrorCode.ERROR_ADDING_GATEWAY_DEVICE_TO_LOCATION);
						log.info(gatewayDevice.getStatusDesc());
						return false;
					}
					Device device = new Device(dbCon);
					device.setLocationId(locationId);
					device.setGwDeviceId(gatewayDevice.getGatewayDeviceId());
					device.addDeviceMap();
				}
			} else {
				setStatus(InvErrorCode.SUCCESS);
				log.info("No GatewayDevices to Add");
				return true;
			}
		} catch (Exception e) {
			setStatus(InvErrorCode.ERROR_ADDING_GATEWAY_DEVICE_TO_LOCATION);
			log.info("FAILURE in addGatewayDeviceToLocation.");
			e.printStackTrace();
			return false;
		}
		setStatus(InvErrorCode.SUCCESS);
		log.info("Successfully added GatewayDevice to Location");
		return true;
	}

	/**
	 * The wrapper method to Delete GatewayDevice from Location.
	 * 
	 * @return true Operation Successful false Operation UnSuccessful
	 * 
	 * @author banala
	 */
	public boolean deleteGatewayDeviceToLocation() {
		try {
			if (deviceList.size() > 0) {
				for (int i = 0; i < deviceList.size(); i++) {
					GatewayDeviceBean gatewayDeviceBean = deviceList.get(i);
					GatewayDevice gatewayDevice = new GatewayDevice(
							gatewayDeviceBean, dbCon);
/*					if (!gatewayDevice.deleteGatewayDevice()) {
						setStatus(InvErrorCode.ERROR_DELETING_GATEWAY_DEVICE_TO_LOCATION);
						log.info(gatewayDevice.getStatusDesc());
						return false;
					}*/
				}
			} else {
				setStatus(InvErrorCode.SUCCESS);
				log.info("No GatewayDevices to Delete");
				return true;
			}
		} catch (Exception e) {
			setStatus(InvErrorCode.ERROR_DELETING_GATEWAY_DEVICE_TO_LOCATION);
			log.info("FAILURE in deleteGatewayDeviceToLocation.");
			e.printStackTrace();
			return false;
		}
		setStatus(InvErrorCode.SUCCESS);
		log.info("Successfully deleted GatewayDevice to Location");
		return true;
	}

	/**
	 * The wrapper method to Add VmAccess To Location.
	 * 
	 * @return true Operation Successful false Operation UnSuccessful
	 * 
	 * @author banala
	 */
	public boolean addVmAccessToLocation() {
		try {
			if (vmAccessList.size() > 0) {
				for (int i = 0; i < vmAccessList.size(); i++) {
					VmAccessBean vmAccessBean = vmAccessList.get(i);
					/*VmAccess vmAccess = new VmAccess(vmAccessBean, dbCon);
					if (!vmAccess.addVmAccess()) {
						setStatus(InvErrorCode.ERROR_ADDING_VMACCESS_TO_LOCATION);
						log.info(vmAccess.getStatusDesc());
						return false;
					}*/
				}
			} else {
				setStatus(InvErrorCode.SUCCESS);
				log.info("No VmAccesss to Add");
				return true;
			}
		} catch (Exception e) {
			setStatus(InvErrorCode.ERROR_ADDING_VMACCESS_TO_LOCATION);
			log.info("FAILURE in addVmAccessToLocation.");
			e.printStackTrace();
			return false;
		}
		setStatus(InvErrorCode.SUCCESS);
		log.info("Successfully added VmAccess to Location");
		return true;
	}

	/**
	 * The wrapper method to Delete VmAccess from Location.
	 * 
	 * @return true Operation Successful false Operation UnSuccessful
	 * 
	 * @author banala
	 */
	public boolean deleteVmAccessToLocation() {
		try {
			if (vmAccessList.size() > 0) {
				for (int i = 0; i < vmAccessList.size(); i++) {
					VmAccessBean vmAccessBean = vmAccessList.get(i);
					/*VmAccess vmAccess = new VmAccess(vmAccessBean, dbCon);
					if (!vmAccess.deleteFromDB()) {
						setStatus(InvErrorCode.ERROR_DELETING_VMACCESS_TO_LOCATION);
						log.info(vmAccess.getStatusDesc());
						return false;
					}*/
				}
			} else {
				setStatus(InvErrorCode.SUCCESS);
				log.info("No VmAccesss to Delete");
				return true;
			}
		} catch (Exception e) {
			setStatus(InvErrorCode.ERROR_DELETING_VMACCESS_TO_LOCATION);
			log.info("FAILURE in deleteVmAccessToLocation.");
			e.printStackTrace();
			return false;
		}
		setStatus(InvErrorCode.SUCCESS);
		log.info("Successfully deleted VmAccess to Location");
		return true;
	}

	/******** Z562196 Code Start *************/
	public boolean addAcountAuthCodesToLocation() throws Exception,
			SQLException {
		log.info("inside addition");
		for (int i = 0; i < authCodesList.size(); i++) {
			/*AcctAuthCodes authCode = new AcctAuthCodes(authCodesList.get(i),
					dbCon);
			authCode.setEnvOrderId(getEnvOrderId());
			if (authCode.addToDB() != true) {
				log.info("Failed to Add Auth Codes");
				setStatus(InvErrorCode.ERROR_ADDING_ACCTAUTHCODES_TO_LOCATION);
				return false;
			}*/
		}
		return true;
	}

	public boolean deleteAccountAuthCodesByAcctAuthCodeAndLocation()
			throws Exception, SQLException {
		log.info("inside delete");
		for (int i = 0; i < authCodesList.size(); i++) {
/*			AcctAuthCodes authCode = new AcctAuthCodes(authCodesList.get(i),
					dbCon);
			if (authCode.deleteFromDBByLocationANDAuthCode() != true) {
				log.info("Failed to delete Auth Codes");
				setStatus(InvErrorCode.ERROR_DELETING_ACCTAUTHCODES_TO_LOCATION);
				return false;
			}*/
		}
		return true;

	}

	public boolean modifyAccountAuthCodesByAcctAuthCodeAndLocation()
			throws Exception, SQLException {

		log.info("inside modify");
		for (int i = 0; i < authCodesList.size(); i++) {
/*			AcctAuthCodes authCode = new AcctAuthCodes(authCodesList.get(i),
					dbCon);
			if (authCode.modifyInDBByLocationANDAuthCode() != true) {
				log.info("Failed to modify  Auth Codes");
				setStatus(InvErrorCode.ERROR_MODIFYING_ACCTAUTHCODES_TO_LOCATION);
				return false;
			}*/
		}
		return true;

	}

	/******** Z562196 Code End *************/
	/**
	 * The wrapper method to Add AcctAuthCodes To Location.
	 * 
	 * @return true Operation Successful false Operation UnSuccessful
	 * 
	 * @author banala
	 */
	public boolean addAcctAuthCodesToLocation() {
		try {
			if (authCodesList.size() > 0) {
				for (int i = 0; i < authCodesList.size(); i++) {
					AcctAuthCodesBean acctAuthCodesBean = authCodesList.get(i);
					/*AcctAuthCodes acctAuthCodes = new AcctAuthCodes(
							acctAuthCodesBean, dbCon);
					if (!acctAuthCodes.addToDB()) {
						setStatus(InvErrorCode.ERROR_ADDING_ACCTAUTHCODES_TO_LOCATION);
						log.info(acctAuthCodes.getStatusDesc());
						return false;
					}*/
				}
			} else {
				setStatus(InvErrorCode.SUCCESS);
				log.info("No AcctAuthCodess to Add");
				return true;
			}
		} catch (Exception e) {
			setStatus(InvErrorCode.ERROR_ADDING_ACCTAUTHCODES_TO_LOCATION);
			log.info("FAILURE in addAcctAuthCodesToLocation.");
			e.printStackTrace();
			return false;
		}
		setStatus(InvErrorCode.SUCCESS);
		log.info("Successfully added AcctAuthCodes to Location");
		return true;
	}

	/**
	 * The wrapper method to Delete AcctAuthCodes from Location.
	 * 
	 * @return true Operation Successful false Operation UnSuccessful
	 * 
	 * @author banala
	 */
	public boolean deleteAcctAuthCodesToLocation() {
		try {
			if (authCodesList.size() > 0) {
				for (int i = 0; i < authCodesList.size(); i++) {
					AcctAuthCodesBean acctAuthCodesBean = authCodesList.get(i);
					/*AcctAuthCodes acctAuthCodes = new AcctAuthCodes(
							acctAuthCodesBean, dbCon);
					if (!acctAuthCodes.deleteFromDB()) {
						setStatus(InvErrorCode.ERROR_DELETING_ACCTAUTHCODES_TO_LOCATION);
						log.info(acctAuthCodes.getStatusDesc());
						return false;
					}*/
				}
			} else {
				setStatus(InvErrorCode.SUCCESS);
				log.info("No AcctAuthCodess to Delete");
				return true;
			}
		} catch (Exception e) {
			setStatus(InvErrorCode.ERROR_DELETING_ACCTAUTHCODES_TO_LOCATION);
			log.info("FAILURE in modifyAcctAuthCodesToLocation.");
			e.printStackTrace();
			return false;
		}
		setStatus(InvErrorCode.SUCCESS);
		log.info("Successfully deleted AcctAuthCodes to Location");
		return true;
	}

	/**
	 * The wrapper method to Add PrefixRouting To Location.
	 * 
	 * @return true Operation Successful false Operation UnSuccessful
	 * 
	 * @author banala
	 */
	public boolean addPrefixRoutingToLocation() {
		try {
			if (prefixRouting.size() > 0) {
				for (int i = 0; i < prefixRouting.size(); i++) {
					PrefixRoutingBean prefixRoutingBean = prefixRouting.get(i);
					/*PrefixRouting prefixRouting = new PrefixRouting(
							prefixRoutingBean, dbCon);
					if (!prefixRouting.addPrefixRouting()) {
						setStatus(InvErrorCode.ERROR_ADDING_PREFIXROUTING_TO_LOCATION);
						log.info(prefixRouting.getStatusDesc());
						return false;
					}*/
				}
			} else {
				setStatus(InvErrorCode.SUCCESS);
				log.info("No PrefixRoutings to Add");
				return true;
			}
		} catch (Exception e) {
			setStatus(InvErrorCode.ERROR_ADDING_PREFIXROUTING_TO_LOCATION);
			log.info("FAILURE in addPrefixRoutingToLocation.");
			e.printStackTrace();
			return false;
		}
		setStatus(InvErrorCode.SUCCESS);
		log.info("Successfully added PrefixRouting to Location");
		return true;
	}

	/**
	 * The wrapper method to Modify PrefixRouting To Location.
	 * 
	 * @return true Operation Successful false Operation UnSuccessful
	 * 
	 * @author banala
	 */
	public boolean modifyPrefixRoutingToLocation() {
		try {
			if (prefixRouting.size() > 0) {
				for (int i = 0; i < prefixRouting.size(); i++) {
					PrefixRoutingBean prefixRoutingBean = prefixRouting.get(i);
					/*PrefixRouting prefixRouting = new PrefixRouting(
							prefixRoutingBean, dbCon);
					if (!prefixRouting.updatePrefixRouting()) {
						setStatus(InvErrorCode.ERROR_MODIFYING_PREFIXROUTING_TO_LOCATION);
						// setStatusDesc(PrefixRouting.getStatusDesc());
						log.info(prefixRouting.getStatusDesc());
						return false;
					}*/
				}
			} else {
				setStatus(InvErrorCode.SUCCESS);
				log.info("No PrefixRoutings to Modify");
				return true;
			}
		} catch (Exception e) {
			setStatus(InvErrorCode.ERROR_MODIFYING_PREFIXROUTING_TO_LOCATION);
			log.info("FAILURE in modifyPrefixRoutingToLocation.");
			e.printStackTrace();
			return false;
		}
		setStatus(InvErrorCode.SUCCESS);
		log.info("Successfully modified PrefixRouting to Location");
		return true;
	}

	/**
	 * The wrapper method to Delete PrefixRouting from Location.
	 * 
	 * @return true Operation Successful false Operation UnSuccessful
	 * 
	 * @author banala
	 */
	public boolean deletePrefixRoutingToLocation() {
		try {
			if (prefixRouting.size() > 0) {
				for (int i = 0; i < prefixRouting.size(); i++) {
					PrefixRoutingBean prefixRoutingBean = prefixRouting.get(i);
					/*PrefixRouting prefixRouting = new PrefixRouting(
							prefixRoutingBean, dbCon);
					if (!prefixRouting.deletePrefixRouting()) {
						setStatus(InvErrorCode.ERROR_DELETING_PREFIXROUTING_TO_LOCATION);
						// setStatusDesc(PrefixRouting.getStatusDesc());
						log.info(prefixRouting.getStatusDesc());
						return false;
					}*/
				}
			} else {
				setStatus(InvErrorCode.SUCCESS);
				log.info("No PrefixRoutings to Delete");
				return true;
			}
		} catch (Exception e) {
			setStatus(InvErrorCode.ERROR_DELETING_PREFIXROUTING_TO_LOCATION);
			log.info("FAILURE in modifyPrefixRoutingToLocation.");
			e.printStackTrace();
			return false;
		}
		setStatus(InvErrorCode.SUCCESS);
		log.info("Successfully deleted PrefixRouting to Location");
		return true;
	}

	/**
	 * The wrapper method to Add PublicTnPool To Location.
	 * 
	 * @return true Operation Successful false Operation UnSuccessful
	 * 
	 * @author banala
	 */
	public boolean addPublicTnPoolToLocation() {
		try {
			if (publicTnPool.size() > 0) {
				for (int i = 0; i < publicTnPool.size(); i++) {
					PublicTnPoolBean publicTnPoolBean = publicTnPool.get(i);
					PublicTnPool publicTnPool = new PublicTnPool(dbCon,
							publicTnPoolBean);
					if (!publicTnPool.addPublicTnPool()) {
						setStatus(InvErrorCode.ERROR_ADDING_PUBLICTNPOOL_TO_LOCATION);
						// setStatusDesc(PublicTnPool.getStatusDesc());
						log.info(publicTnPool.getStatusDesc());
						return false;
					}
				}
			} else {
				setStatus(InvErrorCode.SUCCESS);
				log.info("No PublicTnPools to Add");
				return true;
			}
		} catch (Exception e) {
			setStatus(InvErrorCode.ERROR_ADDING_PUBLICTNPOOL_TO_LOCATION);
			log.info("FAILURE in addPublicTnPoolToLocation.");
			e.printStackTrace();
			return false;
		}
		setStatus(InvErrorCode.SUCCESS);
		log.info("Successfully added PublicTnPool to Location");
		return true;
	}

	/**
	 * The wrapper method to Delete PublicTnPool from Location.
	 * 
	 * @return true Operation Successful false Operation UnSuccessful
	 * 
	 * @author banala
	 */
	public boolean deletePublicTnPoolToLocation() {
		try {
			if (publicTnPool.size() > 0) {
				for (int i = 0; i < publicTnPool.size(); i++) {
					PublicTnPoolBean publicTnPoolBean = publicTnPool.get(i);
					PublicTnPool publicTnPool = new PublicTnPool(dbCon,
							publicTnPoolBean);
					if (!publicTnPool.deletePublicTnPool()) {
						setStatus(InvErrorCode.ERROR_DELETING_PUBLICTNPOOL_TO_LOCATION);
						// setStatusDesc(PublicTnPool.getStatusDesc());
						log.info(publicTnPool.getStatusDesc());
						return false;
					}
				}
			} else {
				setStatus(InvErrorCode.SUCCESS);
				log.info("No PublicTnPools to Modify");
				return true;
			}
		} catch (Exception e) {
			setStatus(InvErrorCode.ERROR_DELETING_PUBLICTNPOOL_TO_LOCATION);
			log.info("FAILURE in deletePublicTnPoolToLocation.");
			e.printStackTrace();
			return false;
		}
		setStatus(InvErrorCode.SUCCESS);
		log.info("Successfully deleted PublicTnPool to Location");
		return true;
	}

	/**
	 * The wrapper method to Add CallingPlan To Location.
	 * 
	 * @return true Operation Successful false Operation UnSuccessful
	 * 
	 * @author banala
	 */
	public boolean addCallingPlanToLocation() {
		try {
			CallingPlan callingPlan = new CallingPlan(callingPlanBean, dbCon);
			// Check if the Calling Plan is already present....check with cp id
			// first and then with name...
			if (!callingPlan.getDetails()) { // try to get calling plan details
												// by calling plan id
				if (!callingPlan.getDetailsByName()) { // try to get calling
														// plan details by
														// calling plan name
					if (!callingPlan.addToDB()) { // Add the new calling plan
						setStatus(InvErrorCode.ERROR_ADDING_CALLINGPLAN_TO_LOCATION);
						log.info(callingPlan.getStatusDesc());
						return false;
					}
				}
			}
			if (getCallingPlanForLocation()) {
				// if input Calling Plan is same as current Calling Plan then no
				// change required... hence return true.
				if (getCallingPlanBean().getCallingPlanId() == callingPlan
						.getCallingPlanId()) {
					return true;
				}
				// Delete the current Calling Plan of Location iff its not
				// default.
				if (getCallingPlanBean().getCallingPlanId() != 0
						&& getCallingPlanBean().getCallingPlanId() != 1) {
					CallingPlan currentLocationCallingPlan = new CallingPlan(
							getCallingPlanBean(), dbCon);
					if (!currentLocationCallingPlan.deleteCallingPlan()) {
						setStatus(InvErrorCode.ERROR_DELETING_CALLINGPLAN_TO_LOCATION);
						log.info(callingPlan.getStatusDesc());
						return false;
					}
				}
			}
			// update new calling plan id in location table...
			Location locToBeUpdated = new Location(dbCon);
			locToBeUpdated.setLocationId(locationId);
			locToBeUpdated.setCallingPlanId(callingPlan.getCallingPlanId());
			if (!locToBeUpdated.modifyInDB()) {
				setStatus(InvErrorCode.ERROR_MODIFYING_CALLINGPLAN_TO_LOCATION);
				log.info(callingPlan.getStatusDesc());
				return false;
			}
		} catch (Exception e) {
			setStatus(InvErrorCode.ERROR_ADDING_CALLINGPLAN_TO_LOCATION);
			log.info("FAILURE in addCallingPlanToLocation.");
			e.printStackTrace();
			return false;
		}
		setStatus(InvErrorCode.SUCCESS);
		log.info("Successfully added CallingPlan to Location");
		return true;
	}

	/**
	 * The wrapper method to Add BsAs To Location.
	 * 
	 * @return true Operation Successful false Operation UnSuccessful
	 * 
	 * @author banala
	 */
	public boolean addBsAsToLocation() {
		try {
			bsAsDbBean.insert(dbCon);
		} catch (Exception e) {
			setStatus(InvErrorCode.ERROR_ADDING_BSAS_TO_LOCATION);
			log.info("FAILURE in addBsAsToLocation.");
			e.printStackTrace();
			return false;
		}
		setStatus(InvErrorCode.SUCCESS);
		log.info("Successfully added BsAs to Location");
		return true;
	}

	/**
	 * The wrapper method to Modify BsAs To Location.
	 * 
	 * @return true Operation Successful false Operation UnSuccessful
	 * 
	 * @author banala
	 */
	public boolean modifyBsAsToLocation() {
		try {
			bsAsDbBean.update(dbCon);
		} catch (Exception e) {
			setStatus(InvErrorCode.ERROR_MODIFYING_BSAS_TO_LOCATION);
			log.info("FAILURE in modifyBsAsToLocation.");
			e.printStackTrace();
			return false;
		}
		setStatus(InvErrorCode.SUCCESS);
		log.info("Successfully modified BsAs to Location");
		return true;
	}

	/**
	 * The wrapper method to Delete BsAs from Location.
	 * 
	 * @return true Operation Successful false Operation UnSuccessful
	 * 
	 * @author banala
	 */
	public boolean deleteBsAsToLocation() {
		try {
			bsAsDbBean.delete(dbCon);
		} catch (Exception e) {
			setStatus(InvErrorCode.ERROR_DELETING_BSAS_TO_LOCATION);
			log.info("FAILURE in deleteBsAsToLocation.");
			e.printStackTrace();
			return false;
		}
		setStatus(InvErrorCode.SUCCESS);
		log.info("Successfully deleted BsAs to Location");
		return true;
	}

	/**
	 * The wrapper method to Add DialPlan To Location.
	 * 
	 * @return true Operation Successful false Operation UnSuccessful
	 * 
	 * @author banala
	 */
	public boolean addDialPlanToLocation() {
		try {
			if (dialPlanList.size() > 0) {
				for (int i = 0; i < dialPlanList.size(); i++) {
					DialPlanBean dialPlanBean = dialPlanList.get(i);
					DialPlan dialPlan = new DialPlan(dialPlanBean, dbCon);
					if (!dialPlan.addDialPlan()) {
						setStatus(InvErrorCode.ERROR_ADDING_DIALPLAN_TO_LOCATION);
						log.info(dialPlan.getStatusDesc());
						return false;
					}
				}
			} else {
				setStatus(InvErrorCode.SUCCESS);
				log.info("No DialPlans to Add");
				return true;
			}
		} catch (Exception e) {
			setStatus(InvErrorCode.ERROR_ADDING_DIALPLAN_TO_LOCATION);
			log.info("FAILURE in addDialPlanToLocation.");
			e.printStackTrace();
			return false;
		}
		setStatus(InvErrorCode.SUCCESS);
		log.info("Successfully added DialPlan to Location");
		return true;
	}

	/**
	 * The wrapper method to Delete DialPlan from Location.
	 * 
	 * @return true Operation Successful false Operation UnSuccessful
	 * 
	 * @author banala
	 */
	public boolean deleteDialPlanToLocation() {
		try {
			if (dialPlanList.size() > 0) {
				for (int i = 0; i < dialPlanList.size(); i++) {
					DialPlanBean dialPlanBean = dialPlanList.get(i);
					DialPlan dialPlan = new DialPlan(dialPlanBean, dbCon);
					if (!dialPlan.deleteDialPlan()) {
						setStatus(InvErrorCode.ERROR_DELETING_DIALPLAN_TO_LOCATION);
						log.info(dialPlan.getStatusDesc());
						return false;
					}
				}
			} else {
				setStatus(InvErrorCode.SUCCESS);
				log.info("No DialPlans to Delete");
				return true;
			}
		} catch (Exception e) {
			setStatus(InvErrorCode.ERROR_DELETING_DIALPLAN_TO_LOCATION);
			log.info("FAILURE in deleteDialPlanToLocation.");
			e.printStackTrace();
			return false;
		}
		setStatus(InvErrorCode.SUCCESS);
		log.info("Successfully deleted DialPlan to Location");
		return true;
	}

/*	public List<PortPendingTnSummary> getPortPendingTnsByLocation() {
		List<PortPendingTnSummary> portPendingTnList = new ArrayList<PortPendingTnSummary>();
		try {
			if (locationId == null || "".equalsIgnoreCase(locationId)) {
				setStatus(InvErrorCode.INVALID_INPUT);
				System.out
						.println("FAILURE in getPortPendingTNsByLocation Location. Location Id missing.");
				return null;
			}
			TblPublicTnPoolQuery tnPoolQry = new TblPublicTnPoolQuery();
			String tnWhereCls = " where location_id = \'" + locationId
					+ "\' and ported_status = "
					+ VzbVoipEnum.PortStatus.PORT_PENDING;
			log.info("tnWhereCls" + tnWhereCls);
			tnPoolQry.queryByWhere(dbCon, tnWhereCls);
			if (tnPoolQry.size() > 0) {
				TblLocationQuery locQry = new TblLocationQuery();
				String locWhereCls = " where location_id = \'" + locationId
						+ "\'";
				log.info("locWhereCls" + locWhereCls);
				locQry.queryByWhere(dbCon, locWhereCls);
				if (locQry.size() != 1) {
					setStatus(InvErrorCode.NOTFOUND_LOCATION);
					System.out
							.println("FAILURE in getPortPendingTNsByLocation Location. Location missing in DB.");
					return null;
				}
				for (int i = 0; i < tnPoolQry.size(); i++) {
					PortPendingTnSummary portTnObj = new PortPendingTnSummary();
					portTnObj.setTn(tnPoolQry.getDbBean(i).getTn());
					portTnObj.setTnStatus(tnPoolQry.getDbBean(i).getTnStatus());
					portTnObj.setLinePortLength(locQry.getDbBean(0)
							.getLinePortLength());
					if (tnPoolQry.getDbBean(i).getTnStatus() == VzbVoipEnum.TnStatus.ASSIGNED) {
						TblGroupTnQuery grpTnQry = new TblGroupTnQuery();
						grpTnQry.whereTnPoolIdEQ(tnPoolQry.getDbBean(i)
								.getTnPoolId());
						grpTnQry.query(dbCon);
						if (grpTnQry.size() > 0) {
							portTnObj.setGroupId(grpTnQry.getDbBean(0)
									.getGroupId());
							portTnObj.setExtension(grpTnQry.getDbBean(0)
									.getExtension());
							TblGroupQuery grpQry = new TblGroupQuery();
							grpQry.whereGroupIdEQ((int) grpTnQry.getDbBean(0)
									.getGroupId());
							grpQry.query(dbCon);
							if (grpQry.size() > 0) {
								portTnObj.setGroupName(grpQry.getDbBean(0)
										.getGroupName());
								if (grpQry.getDbBean(0).getGroupType() == VzbVoipEnum.TrunkGroupType.PBX)
									portTnObj
											.setServiceType(VzbVoipEnum.ServiceType.PBX);
								if (grpQry.getDbBean(0).getGroupType() == VzbVoipEnum.TrunkGroupType.KEY)
									portTnObj
											.setServiceType(VzbVoipEnum.ServiceType.KEY);
							}
						} else // Otherwise it should be HIPC tn
						{
							TblSubscriberTnQuery subTnQry = new TblSubscriberTnQuery();
							subTnQry.whereUserIdEQ(tnPoolQry.getDbBean(i)
									.getTn());
							subTnQry.query(dbCon);
							if (subTnQry.size() > 0) {
								String subId = subTnQry.getDbBean(0).getSubId();
								portTnObj
										.setServiceType(VzbVoipEnum.ServiceType.HIPC);
								portTnObj.setSubId(subId);
								if (subId != null
										&& !subId.trim().equalsIgnoreCase("")) {
									TblSubscriberQuery subQry = new TblSubscriberQuery();
									String subWhereCls = " where sub_id = "
											+ subId;
									subQry.queryByWhere(dbCon, subWhereCls);
									if (subQry.size() > 0) {
										portTnObj.setExtension(subQry
												.getDbBean(0).getExtension());
									}
								}
							}
						}
					}
					// Not gone into above if then its reserved tn.
					portPendingTnList.add(portTnObj);
				}
			}
		} catch (Exception e) {
			setStatus(InvErrorCode.NO_PUBLICTNPOOL_FOR_LOC_ID);
			log.info("FAILURE in gettingPortPendingTns from Db");
			e.printStackTrace();
			return portPendingTnList;
		}
		return portPendingTnList;
	}

	*//**
	 * The method to retrieve the Location Features for the specified Location.
	 * Please set the Location Id, before invoking this method.
	 * 
	 * @return true Operation Successful false Operation UnSuccessful
	 *//*
	public boolean getLocationFeaturesForLocation() {
		log.info("Entering Location::getLocationFeaturesForLocation");
		try {
			if (locationId == null || "".equalsIgnoreCase(locationId)) {
				setStatus(InvErrorCode.MISSING_LOCATION_ID);
				setLogTrail("Location:getLocationFeaturesForLocation. Location id cannot be null");
				return false;
			}
			String whereLocClause = " where location_id = \'" + locationId
					+ "\'";
			TblLocationFeaturesQuery locPkgQry = new TblLocationFeaturesQuery();
			locPkgQry.queryByWhere(dbCon, whereLocClause);
			log.info("iLocation Features size:" + locPkgQry.size());
			if (locPkgQry.size() <= 0) {
				setStatus(InvErrorCode.NO_LOCATION_FEATURES_FOR_LOCATION);
				setLogTrail("Location:getLocationFeaturesForLocation. No Location Features Found.");
				return false;
			}
			for (int k = 0; k < locPkgQry.size(); k++) {
				TblVzbFeaturesQuery vzbFeaturesQry = new TblVzbFeaturesQuery();
				vzbFeaturesQry.whereFeatureIdEQ((int) (locPkgQry.getDbBean(k))
						.getFeatureId());
				vzbFeaturesQry.query(dbCon);
				if (vzbFeaturesQry.size() == 1) {
					FeaturesBean featPkgBean = new FeaturesBean();
					DBTblVzbFeatures dBTblVzbFeatures = new DBTblVzbFeatures();
					featPkgBean.setFeaturesDbBean(dBTblVzbFeatures);
					dBTblVzbFeatures.copyFromBean(vzbFeaturesQry.getDbBean(0));
					// featPkgBean.setAuthServiceId(vzbFeaturesQry.getDbBean(0).getIsAuthorized());
					// featPkgBean.setIsAuthorized(pkgQry.getDbBean(0).getIsAuthorized());
					// featPkgBean.setIsSelected(pkgQry.getDbBean(0).getAuthorized());
					featPkgBean.setFeatureCount((int) locPkgQry.getDbBean(k)
							.getFeatureCount());
					locationFeatures.add(featPkgBean);
				} else {
					setStatus(InvErrorCode.INVALID_PKG_ID);
					setLogTrail("Location:getLocationFeaturesForLocation DB_FAILURE. No Feature found for Id: "
							+ (locPkgQry.getDbBean(k)).getFeatureId());
					return false;
				}
			}
		} catch (SQLException s) {
			s.printStackTrace();
			setStatus(InvErrorCode.DB_EXCEPTION);
			setLogTrail("Location:getLocationFeaturesForLocation DB_FAILURE occured");
			return false;
		}
		setStatus(InvErrorCode.SUCCESS);
		setLogTrail("Location:getLocationFeaturesForLocation Successfully retrieved LocationFeatures.");
		return true;
	}*/

	public long createLocPackage(ArrayList<Long> fIdList, int pkgType,
			String locationId) throws SQLException, Exception {
		long pkgId = 0;
		FeaturePackage featPkg = new FeaturePackage(dbCon);
		featPkg.setFeaturePackageType(pkgType);
		featPkg.setFeaturePackageName("ICPPKG"); // TODO ask Sunil
		featPkg.setTemplateInd(0);
		featPkg.setIsDefault(0);
		featPkg.setLocationId(locationId);
		if (!featPkg.addToDB()) {
			log.info("Failed to add Pkg to DB");
			return pkgId;
		}
		ArrayList<FeaturesBean> featBeanList = new ArrayList<FeaturesBean>();
		for (int i = 0; i < fIdList.size(); i++) {
			FeaturesBean featBean = new FeaturesBean();
			featBean.getFeaturesDbBean()
					.setFeatureId(fIdList.get(i).intValue());
			featBean.setIsSelected(true);
			featBeanList.add(featBean);
		}
		featPkg.setFeatureList(featBeanList);
		if (!featPkg.addFeaturesToPackage()) {
			log.info("Failed to add features to Pkg");
			return pkgId;
		}
		/*
		 * DBTblLocPackage locPkgDbBean = new DBTblLocPackage(); int locPkgId =
		 * locPkgDbBean.getLocPackageIdSeqNextVal(dbCon);
		 * locPkgDbBean.setLocationId(locationId);
		 * locPkgDbBean.setPackageId(featPkg.getFeaturePackageId());
		 * locPkgDbBean.setIsDefault(0); locPkgDbBean.setModifiedBy("ESAP_MIG");
		 * locPkgDbBean.setCreatedBy("ESAP_MIG");
		 * locPkgDbBean.setLastModifiedDate(new
		 * Timestamp(System.currentTimeMillis()));
		 * locPkgDbBean.setCreationDate(new
		 * Timestamp(System.currentTimeMillis())); locPkgDbBean.insert(dbCon);
		 */
		pkgId = featPkg.getFeaturePackageId();
		return pkgId;
	}

	public long getFeaturePackageForLocationByFeatureIdList(int featPkgType,
			String locationId, ArrayList<Long> inputFIdList)
			throws SQLException, Exception {
		long finalPkgId = 0;
		if (locationId == null || locationId.equalsIgnoreCase("")
				|| inputFIdList == null || inputFIdList.size() <= 0) {
			System.out
					.println("Invalid input for getFeaturePackageForLocationByFeatureList");
			return finalPkgId;
		}
		int noOfInputFeats = inputFIdList.size();
		log.info("noOfInputFeats:" + noOfInputFeats);
		ArrayList<Long> locPkgIdList = new ArrayList<Long>();
		ArrayList<Long> finalLocPkgIdList = new ArrayList<Long>();
		String locPkgStmt = "select l.package_id from tbl_loc_package l ,tbl_package p where l.package_id = p.package_id and p.package_type =";
		locPkgStmt += featPkgType;
		locPkgStmt += " and location_id = \'";
		locPkgStmt += locationId;
		locPkgStmt += "\'";
		log.info("locPkgStmt:" + locPkgStmt);
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			ps = dbCon.prepareStatement(locPkgStmt);
			rs = ps.executeQuery();
			if (rs.next()) {
				locPkgIdList.add(rs.getLong(1));
			}
		} finally {
			if (rs != null)
				rs.close();
			if (ps != null)
				ps.close();
		}
		log.info("No of loc pkgs:" + locPkgIdList.size());
		if (locPkgIdList.size() > 0) {
			String pkgFeatStmt = "select package_id from tbl_pkg_features where package_id in (";
			for (int i = 0; i < locPkgIdList.size(); i++) {
				if (i != 0) {
					pkgFeatStmt += ",";
				}
				pkgFeatStmt += locPkgIdList.get(i);
			}
			pkgFeatStmt += ") group by package_id having count(*) =";
			pkgFeatStmt += noOfInputFeats;
			log.info("pkgFeatStmt:" + pkgFeatStmt);
			ps = null;
			rs = null;
			try {
				ps = dbCon.prepareStatement(pkgFeatStmt);
				rs = ps.executeQuery();
				if (rs.next()) {
					finalLocPkgIdList.add(rs.getLong(1));
				}
			} finally {
				if (rs != null)
					rs.close();
				if (ps != null)
					ps.close();
			}
			if (finalLocPkgIdList.size() <= 0) {
				System.out
						.println("Creating new pkg bcos finallocPkgIdList is < 0");
				// No existing pkgs for location so just add a new pkg with the
				// input features.
				finalPkgId = createLocPackage(inputFIdList, featPkgType,
						locationId);
			} else {
				// Now populate features for all the loc pkgs.
				HashMap<Long, ArrayList<String>> pkgIdFeatListMap = new HashMap<Long, ArrayList<String>>();
				for (int j = 0; j < finalLocPkgIdList.size(); j++) {
					ArrayList<String> tempFeatureIdList = new ArrayList<String>();
					TblPkgFeaturesQuery pkgFeatQuery = new TblPkgFeaturesQuery();
					pkgFeatQuery.wherePackageIdEQ(finalLocPkgIdList.get(j)
							.longValue());
					pkgFeatQuery.query(dbCon);
					if (pkgFeatQuery.size() > 0) {
						for (int k = 0; k < pkgFeatQuery.size(); k++) {
							tempFeatureIdList.add(""
									+ pkgFeatQuery.getDbBean(k).getFeatureId());
						}
						Collections.sort(tempFeatureIdList);
						pkgIdFeatListMap.put(finalLocPkgIdList.get(j)
								.longValue(), tempFeatureIdList);
					}
				}
				// At this point I have a sorted input feature List and map of
				// Location pkgId to Sorted List of featureids.
				// For each featureId in the input List I have to chk if that
				// feature Id is present in each of location pkg featureid list.
				// If any location does not contain any input feature then we
				// drop that location pkg.
				// At the end we will have loc pkgs whose features exactly match
				// with input features or nothing in loc pkg list.
				// If any loc pkgs remain in the list, pick the first pkg_id and
				// return..hurray!!
				// If loc pkg list is empty then insert a new loc pkg.--may be a
				// new method.
				if (pkgIdFeatListMap.size() > 0) {
					for (int p = 0; p < inputFIdList.size(); p++) {
						long inputFeatId = inputFIdList.get(p).longValue();
						HashMap<Long, ArrayList<String>> tmpPkgIdFeatListMap = new HashMap<Long, ArrayList<String>>();
						for (Iterator iter = pkgIdFeatListMap.entrySet()
								.iterator(); iter.hasNext();) {
							Map.Entry entry = (Map.Entry) iter.next();
							ArrayList<String> locFIdList = (ArrayList<String>) entry
									.getValue();
							long tmpPkgId = ((Long) entry.getKey()).longValue();
							if (locFIdList.contains("" + inputFeatId)) {
								tmpPkgIdFeatListMap.put(tmpPkgId, locFIdList);
							}
						}
						pkgIdFeatListMap = tmpPkgIdFeatListMap;
						if (pkgIdFeatListMap.size() <= 0)
							break;
					}
					if (pkgIdFeatListMap.size() <= 0) {
						System.out
								.println("Creating new pkg bcos pkgIdFeatListMap.size is < 0. After matching. Meaning nothing has matched.");
						// No existing pkgs for location so just add a new pkg
						// with the input features.
						finalPkgId = createLocPackage(inputFIdList,
								featPkgType, locationId);
					} else {
						// Means i have some loc pkgs which is/are matching with
						// our input feature list.
						// lets get packageId and get out of this mess
						for (Iterator iter = pkgIdFeatListMap.entrySet()
								.iterator(); iter.hasNext();) {
							Map.Entry entry = (Map.Entry) iter.next();
							long tmpPkgId = ((Long) entry.getKey()).longValue();
							finalPkgId = tmpPkgId;
						}
					}
				} else {
					System.out
							.println("Creating new pkg bcos pkgIdFeatListMap.size is < 0");
					// No existing pkgs for location so just add a new pkg with
					// the input features.
					finalPkgId = createLocPackage(inputFIdList, featPkgType,
							locationId);
				}
			}
		} else {
			log.info("Creating new pkg bcos locPkgIdList is < 0");
			// No existing pkgs for location so just add a new pkg with the
			// input features.
			finalPkgId = createLocPackage(inputFIdList, featPkgType, locationId);
		}
		return finalPkgId;
	}

	public List<String> getVmBoxNumberListByLocationId() throws SQLException {
		ArrayList<String> vmBoxNumList = new ArrayList<String>();
		TblSubscriberQuery subQuery = new TblSubscriberQuery();
		subQuery.whereLocationIdEQ(getLocationId());
		subQuery.query(dbCon);
		if (subQuery.size() > 0) {
			for (int i = 0; i < subQuery.size(); i++) {
				if (subQuery.getDbBean(i).getVmBoxNum() != null
						&& !subQuery.getDbBean(i).getVmBoxNum()
								.equalsIgnoreCase(""))
					vmBoxNumList.add(subQuery.getDbBean(i).getVmBoxNum());
			}
		}
		TblGroupQuery grpQuery = new TblGroupQuery();
		grpQuery.whereLocationIdEQ(getLocationId());
		grpQuery.query(dbCon);
		if (grpQuery.size() > 0) {
			for (int j = 0; j < grpQuery.size(); j++) {
				TblGroupTnQuery grpTnQry = new TblGroupTnQuery();
				grpTnQry.whereGroupIdEQ(grpQuery.getDbBean(j).getGroupId());
				grpTnQry.query(dbCon);
				if (grpTnQry.size() > 0) {
					for (int k = 0; k < grpTnQry.size(); k++) {
						if (grpTnQry.getDbBean(k).getVmBoxNum() != null
								&& !grpTnQry.getDbBean(k).getVmBoxNum()
										.equalsIgnoreCase(""))
							vmBoxNumList.add(grpTnQry.getDbBean(k)
									.getVmBoxNum());
					}
				}
			}
		}
		return vmBoxNumList;
	}

	public Location getLocationDetailFromIasa(long locationId) throws Exception {
		Location iasaLocation = null;

		Connection iasa_connection = null;
		try {
			//iasa_connection = IASAConnectionHelper.getIASAConnection(dbCon);
			if (iasa_connection == null)
				throw new Exception("Unable to get Iasa DB Connection");

			/*IASAIpcomLocation ipcomLocHandler = new IASAIpcomLocation(
					iasa_connection);*/

			/*IpcomLocationDbBean ipcomLocation = ipcomLocHandler
					.getLocationDetail(locationId);
*/
			/*if (ipcomLocation != null) {
				iasaLocation = new Location(ipcomLocation, dbCon);
			}*/

		} catch (Exception e) {
			setStatus(InvErrorCode.DB_EXCEPTION);
			log.info("DB_FAILURE in getLocationFromIasa Location");
			e.printStackTrace();
			throw new Exception(e);
		} finally {
			if (iasa_connection != null) {
				iasa_connection.close();
				iasa_connection = null;
			}

		}
		return iasaLocation;
	}

	public List<Location> getLocationDetailFromIasa(String locationId,
			String locationName) throws Exception {
		List<Location> iasaLocationList = new ArrayList<Location>();

		Connection iasa_connection = null;
		try {
			//iasa_connection = IASAConnectionHelper.getIASAConnection(dbCon);
			if (iasa_connection == null)
				throw new Exception("Unable to get Iasa DB Connection");

			/*IASAIpcomLocation ipcomLocHandler = new IASAIpcomLocation(
					iasa_connection);*/

			/*ArrayList<IpcomLocationDbBean> ipcomLocationList = ipcomLocHandler
					.getLocationDetail(locationId, locationName);
			if (ipcomLocationList != null) {
				Iterator ipcomLocationItr = ipcomLocationList.iterator();

				while (ipcomLocationItr.hasNext()) {
					IpcomLocationDbBean ipcomLocation = (IpcomLocationDbBean) ipcomLocationItr
							.next();
					if (ipcomLocation != null) {
						Location iasaLocation = new Location(ipcomLocation,
								dbCon);
						iasaLocationList.add(iasaLocation);
					}
				}
			}*/

		} catch (Exception e) {
			setStatus(InvErrorCode.DB_EXCEPTION);
			log.info("DB_FAILURE in getLocationFromIasa Location");
			e.printStackTrace();
			throw new Exception(e);
		} finally {
			if (iasa_connection != null) {
				iasa_connection.close();
				iasa_connection = null;
			}

		}
		return iasaLocationList;
	}

	/*
	 * This API used by OM and GUI GUI pass sbcMicroNode as NULL, It expects the
	 * SBC_PROV as in IASA DB OM pass sbcMicroNode as SiteName, It expect The
	 * SBC_PROV as ESAP for all the Location which are using that MicroNode
	 */

	public List<Location> getLocationFromIasa(String customerId,
			String sbcMicroNode) throws Exception {
		log.info("Inside getLocationFromIasa(customerId="
				+ customerId + ",sbcMicroNode=" + sbcMicroNode);
		List<Location> listOfActiveLocOfCustomer = new ArrayList<Location>();
		HashMap<String, String> sbcLocationIdList = null;
		Connection iasa_connection = null;
		try {
			//iasa_connection = IASAConnectionHelper.getIASAConnection(dbCon);
			if (iasa_connection == null)
				throw new Exception("Unable to get Iasa DB Connection");

			/*IASAIpcomCustomer ipcomCustomerHandler = new IASAIpcomCustomer(
					iasa_connection);
			IpcomCustomerDbBean ipcomCustomer = ipcomCustomerHandler
					.getCustomerDetail(customerId);
			String freezFlag = ipcomCustomer.getUiProvFlag();
			int isRIVCustomer = -1;
			if (freezFlag != null) {
				if (Long.parseLong(freezFlag) == EsapMigrationEnum.FreezeFlag.NON_LEGACY) {
					isRIVCustomer = VzbVoipEnum.YesNoType.Y;
				} else {
					isRIVCustomer = VzbVoipEnum.YesNoType.N;
				}
			}

			IASAIpcomLocation ipcomLocHandler = new IASAIpcomLocation(
					iasa_connection);
			IIASASbc iasaSbc = new IASASbcImpl();
			ArrayList<IpcomLocationDbBean> activeIasaLocList = ipcomLocHandler
					.getAllActiveLocationForCustomer(customerId);

			SBCMigration sbcMigHandler = new SBCMigration(dbCon,
					iasa_connection);

			if (sbcMicroNode != null) {

				HashMap<String, String> accessTypeAndIasaDcGrIdMap = sbcMigHandler
						.getAccessTypeAndIasaDatacenterGroupId(sbcMicroNode);
				String accessType = accessTypeAndIasaDcGrIdMap
						.get("AccessCategoryId");
				String iasaDatacenterGrid = accessTypeAndIasaDcGrIdMap
						.get("IasaDatacenterGroupId");
				sbcLocationIdList = iasaSbc
						.getAllLocationIdBySbcMicroNodeAndCustomer(
								iasa_connection, iasaDatacenterGrid,
								accessType, customerId);
				log.info("sbcLocationIdList = " + sbcLocationIdList);
			}*/

			/*if (activeIasaLocList != null) {
				Iterator activeIasaLocListItr = activeIasaLocList.iterator();
				while (activeIasaLocListItr.hasNext()) {
					IpcomLocationDbBean activeIasaLoc = (IpcomLocationDbBean) activeIasaLocListItr
							.next();

					if (activeIasaLoc != null) {
						Location esapLocation = new Location(activeIasaLoc,
								dbCon);
						log.info("activeIasaLoc.getLocid()="
								+ activeIasaLoc.getLocid());

						if (sbcMicroNode != null) {
							// Derive the SBC_PROV for OM
							if (sbcLocationIdList.containsKey(Long
									.toString(activeIasaLoc.getLocid()))) {
								// it's SBC_PROV = ESAP
								esapLocation
										.setSbcProvMethod(VzbVoipEnum.SbcProvMethodType.ESAP);
								log.info(" it's SBC_PROV = ESAP "
										+ VzbVoipEnum.SbcProvMethodType.ESAP);
							} else {
								// it's SBC_PROV = IASA
								esapLocation
										.setSbcProvMethod(VzbVoipEnum.SbcProvMethodType.IASA);
								log.info(" it's SBC_PROV = IASA "
										+ VzbVoipEnum.SbcProvMethodType.IASA);
							}
						} else {
							// No Need to Derive the SBC_PROV for GUI
						}

						// get the SIPCLIENT using getSipclientFromSbcLocation()
						// cap call
						// set the SIPCLIENT class variable
						String tmpSipClient = sbcMigHandler
								.getSipclientFromSbcLocation(
										activeIasaLoc.getLocid(), customerId);
						if (tmpSipClient != null) {
							// If sbc_location.sipclient = 1 setSipEnabled(1)
							// If sbc_location.sipclient = 0 setSipEnabled(0)
							// setSipClient(tmpSipClient);
							if (tmpSipClient.equalsIgnoreCase("1")) {
								esapLocation.setSipEnabled(1);
							} else if (tmpSipClient.equalsIgnoreCase("0")) {
								esapLocation.setSipEnabled(0);
							}
						}

						log.info(" isRIVCustomer:" + isRIVCustomer);
						esapLocation.setRivLocation(isRIVCustomer);
						listOfActiveLocOfCustomer.add(esapLocation);
					}
				}
			}*/

		} catch (Exception e) {
			setStatus(InvErrorCode.DB_EXCEPTION);
			log.info("DB_FAILURE in getLocationFromIasa Location");
			e.printStackTrace();
			throw new Exception(e);
		} finally {
			if (iasa_connection != null) {
				iasa_connection.close();
				iasa_connection = null;
			}

		}

		return listOfActiveLocOfCustomer;
	}

	public boolean setDeletePending() throws SQLException, Exception {
		if (locationId == null || locationId.trim().equalsIgnoreCase("")) {
			setStatus(InvErrorCode.INVALID_INPUT);
			return false;
		}
		DBTblLocation locationDb = new DBTblLocation();
		locationDb.whereLocationIdEQ(locationId);
		locationDb.setActiveInd(VzbVoipEnum.ActiveInd.DELETE_PENDING);
		locationDb.updateSpByWhere(dbCon);
		return true;
	}

	// IR# 1364019 9999 - Regression Aug - M/-I is being Trigger in ESAP when
	// order is in CO address
	public void updateSbcProvMethodType(String locationId,
			long sbcProvMethodType) throws Exception {

		log.info(" Executing updateSbcProvMethodType ");
		StringBuffer sql = new StringBuffer();
		PreparedStatement pStmt = null;
		// ResultSet rs = null;

		// long sbcprovmethod = sbcProvMethodType;

		log.info(" LocationId value :: " + locationId);
		log.info(" sbcProvMethodType value :: " + sbcProvMethodType);

		sql.append(" update tbl_gateway_device_info set sbc_prov_method = '"
				+ sbcProvMethodType + "'");
		sql.append(" where gateway_device_id in (");
		sql.append(" select gateway_device_id  from tbl_device_map where location_id = ?)");

		log.info("SQL = [" + sql.toString() + "]");
		try {
			pStmt = dbCon.prepareStatement(sql.toString());
			pStmt.setString(1, locationId);
			pStmt.executeUpdate();

			System.out
					.println("The tbl_gateway_device_info has been updated to ["
							+ sbcProvMethodType
							+ "] for the locationid "
							+ "["
							+ locationId + "]");

		} catch (SQLException e) {
			e.printStackTrace();
			throw e;
		} finally {
			if (pStmt != null)
				pStmt.close();
		}

	}

	/*******************************************************************************************/

	/****************************************************************/
	public boolean deleteTriForTnList(List<String> deletedPnpList,
			String locationId, String envOrderId) throws SQLException,
			Exception {
		log.info("START TIME : " + now());

		List<String> tnRangeList = new ArrayList<String>();
		ArrayList<TblTerminatingRoutingDbBean> removeTriList = new ArrayList<TblTerminatingRoutingDbBean>();

		TblLocationDbBean locationDbBean = getLocationForLocationId(locationId);
		DBTblVzbStateGatewayMap gatewayMap = new DBTblVzbStateGatewayMap();

		// IR #1480374: VDSI QA APAC Testing - Disconnect Deactivate order
		// failing in inventory (ESAP Enterprise Softswitch Activation Platform)
log.info("LocCounty in deleteTriForTnList:"+locationDbBean.getLocCountry());
		log.info("LocState in deleteTriForTnList:"+locationDbBean.getLocState());

		if (locationDbBean.getLocCountry() != null
				&& !locationDbBean.getLocCountry().equals("US")
				&& !locationDbBean.getLocCountry().equals("USA")
				&& !locationDbBean.getLocCountry().equals("CA")) {
			if (getRegion(locationDbBean.getLocationId()) == VzbVoipEnum.RegionType.APAC) {
				gatewayMap = getVzbGatewayId(locationDbBean.getLocCountry(),
						VzbVoipEnum.RegionType
								.name(VzbVoipEnum.RegionType.APAC),
						locationDbBean.getEnterpriseId());
			} else if(getRegion(locationDbBean.getLocationId()) == VzbVoipEnum.RegionType.EMEA) {
				gatewayMap = getVzbGatewayId(locationDbBean.getLocCountry(),
						VzbVoipEnum.RegionType
								.name(VzbVoipEnum.RegionType.EMEA),
						locationDbBean.getEnterpriseId());
			}else{
				gatewayMap = getVzbGatewayId(locationDbBean.getLocState(),
						VzbVoipEnum.RegionType.name(VzbVoipEnum.RegionType.US),
						locationDbBean.getEnterpriseId());
			}
		} else {
			gatewayMap = getVzbGatewayId(locationDbBean.getLocState(),
					VzbVoipEnum.RegionType.name(VzbVoipEnum.RegionType.US),
					locationDbBean.getEnterpriseId());
		}

		String P1URL = "" + gatewayMap.getPrimaryGatewayid();
		String A1URL = "" + gatewayMap.getSecondaryGatewayid();

		ArrayList<TblTerminatingRoutingDbBean> dbTriList = getExistingTermRoutingList(locationDbBean
				.getDialPlanId());
		log.info("getExistingTermRoutingList :" + dbTriList);

		List<String> tnList = explodeRangeToTnList(dbTriList, P1URL, A1URL);
		log.info("explodeRangeToTnList :" + tnList);

		// remove deleted PNP TN's from the tnList
		List<String> tnRemainingList = removeDeletedPnpTns(tnList,
				deletedPnpList);
		log.info("removeDeletedPnpTns :" + tnRemainingList);

		tnRangeList = getRange(tnRemainingList, 99999);
		log.info("tnRangeList :" + tnRangeList);
		// compare new range with existing range, remove matched ranges from new
		// + existing range

		for (TblTerminatingRoutingDbBean triBean : dbTriList) {
			// if(!(triBean.getP1url().equals(P1URL) &&
			// triBean.getA1url().equals(A1URL)))
			if (triBean.getP1url() != null && !triBean.getP1url().equals(P1URL))
				continue;

			// IR #1476939: RIV PROD : INV TRI Update Logic Change
			if (triBean.getA1url() != null && !triBean.getA1url().equals(A1URL))
				continue;

			String existingRange = triBean.getRangeStart() + "-"
					+ triBean.getRangeEnd();
			// IR #1416296 Null Check to be done here ...tnRangeList will come
			// as null.
			if (tnRangeList != null && tnRangeList.contains(existingRange)) {
				tnRangeList.remove(existingRange);
				log.info("existingRange matched with newRange:"
						+ existingRange);
			} else {
				removeTriList.add(triBean);
			}
		}

		// remove TRI entries based on the removeTriList
		for (TblTerminatingRoutingDbBean triBean : removeTriList) {
			log.info("Removing Existing Range "
					+ triBean.getRangeStart() + "-" + triBean.getRangeEnd());
			delTerminatingRouting(locationDbBean.getDialPlanId(),
					triBean.getRangeStart(), triBean.getRangeEnd());
		}

		// add TRI entries based on the tnRangeList
		if (tnRangeList != null && tnRangeList.size() > 0) {
			Iterator iter = tnRangeList.iterator();
			while (iter.hasNext()) {
				String tnRange = (String) (iter.next());
				String tnStart = getTNStart(tnRange);
				String tnEnd = getTNEnd(tnRange);
				log.info("Adding new Range " + tnStart + "-" + tnEnd);
				addTermRouting(locationDbBean, tnStart, tnEnd, P1URL, A1URL,
						envOrderId);

			}
		}

		return true;
	}

	/****************************************************************/

	/*********************************************************************/
	public static String now() {
		Calendar cal = Calendar.getInstance();
		SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT_NOW);
		return sdf.format(cal.getTime());
	}

	/*********************************************************************/
	ArrayList<TblTerminatingRoutingDbBean> getExistingTermRoutingList(
			long dialPlanId) throws SQLException, Exception {

		/* Test code */
		DBTblTerminatingRouting termDb = new DBTblTerminatingRouting();
		termDb.setDialPlanId(dialPlanId);
		termDb.whereDialPlanIdEQ(dialPlanId);
		termDb.updateSpByWhere(dbCon);
		/* Test code */

		ArrayList<TblTerminatingRoutingDbBean> dbTriList = new ArrayList<TblTerminatingRoutingDbBean>();
		TblTerminatingRoutingQuery dbTermQry = new TblTerminatingRoutingQuery();
		dbTermQry.whereDialPlanIdEQ(dialPlanId);
		dbTermQry.whereNoaEQ(1);
		// dbTermQry.whereNoaEQ(noa);
		dbTermQry.setOrderBy("RANGE_START");
		dbTermQry.query(dbCon);
		if (dbTermQry.size() > 0) {
			for (int i = 0; i < dbTermQry.size(); i++) {
				dbTriList.add(dbTermQry.getDbBean(i));
			}
		}
		return dbTriList;
	}

	/*********************************************************************/
	boolean addTermRouting(TblLocationDbBean locationDbBean, String rangeStart,
			String rangeEnd, String P1URL, String A1URL, String envOrderId)
			throws Exception {
		// PublicTnPool pubTnBeanObj = new PublicTnPool(dbCon);
		TerminatingRouting termRoutObj = new TerminatingRouting(dbCon);
		// pubTnBeanObj.setLocationId(locationDbBean.getLocationId());
		termRoutObj.setEnvOrderId(Long.valueOf(envOrderId));
		termRoutObj.setDialPlanId(locationDbBean.getDialPlanId());
		termRoutObj.setNoa(1);
		termRoutObj.setRangeStart(rangeStart);
		termRoutObj.setRangeEnd(rangeEnd);
		termRoutObj.setP1URL(P1URL);
		termRoutObj.setA1URL(A1URL);

		termRoutObj.setPringTime("252");
		termRoutObj.setPtrId("");
		termRoutObj.setPSuffixNum(32);
		termRoutObj.setA1RingTime("252");
		termRoutObj.setA1TRId("");
		termRoutObj.setA1PrefixDgts("");
		termRoutObj.setA1SuffixNum(32);

		termRoutObj.setA2RingTime("");
		termRoutObj.setA2TRId("");
		termRoutObj.setA2PrefixDgts("");
		termRoutObj.setA2SuffixNum(32);

		termRoutObj.setPPrefixDgts("");
		termRoutObj.setA2URL("");
		termRoutObj.setNoa(1);

		termRoutObj.setCreatedBy("ESAPADM");
		termRoutObj.setModifiedBy("ESAPADM");
		termRoutObj.addTerminatingRouting();

		log.info("Start and end tn added to Term routing: "
				+ rangeStart + "," + rangeEnd);

		return true;
	}

	/*********************************************************************/

	public boolean delTerminatingRouting(long dialPlanId, String rangeStart,
			String rangeEnd) throws SQLException, Exception

	{
		boolean retValue = true;

		log.info("Entering delTerminatingRouting");

		// try
		// {
		DBTblTerminatingRouting trDbBean = new DBTblTerminatingRouting();
		trDbBean.whereRangeStartEQ(rangeStart);
		trDbBean.whereRangeEndEQ(rangeEnd);
		trDbBean.whereDialPlanIdEQ(dialPlanId);
		trDbBean.deleteByWhere(dbCon);
		/*
		 * } catch(SQLException s) {
		 * log.info("DB_FAILURE in deleteTerminatingRouting");
		 * retValue = false; }
		 */

		return retValue;
	}

	/*********************************************************************/

	public List<String> getRange(List<String> tns, int rangeLimit) {
		// int rangeLimit = 9999;

		if (null == tns || tns.size() == 0)
			return null;
		List<String> rangesList = new ArrayList<String>();

		tns = removeDuplicate(tns);
		// log.info("tns(removeDuplicate)="+tns);

		Collections.sort(tns);
		// log.info("tns(sort)="+tns);

		if (null != tns && tns.size() == 1) {
			String tn = tns.get(0);
			rangesList.add(tn + "-" + tn);
			return rangesList;
		}

		long start = Long.parseLong(tns.get(0));
		long pos = Long.parseLong(tns.get(0));
		long end;
		for (int i = 1; i < tns.size(); i++) {
			end = Long.parseLong(tns.get(i));
			log.info("start" + start);
			log.info("pos" + pos);
			log.info("end" + end);

			if (pos == (end - 1)) {
				log.info("if");

				if ((end - start) >= rangeLimit) {
					log.info("if-range");

					rangesList.add(start + "-" + pos);
					start = end;
					pos = end;
					// continue;
				}
				pos = end;
				if ((i + 1) == tns.size()) {
					rangesList.add(start + "-" + end);
				}
				log.info("before cont...");
				continue;
			} else {
				log.info("else");

				rangesList.add(start + "-" + pos);
				start = end;
				pos = end;
			}
			if (i == tns.size() - 1 && start == end) {
				rangesList.add(start + "-" + end);
			}
		}
		return rangesList;
	}

	/*********************************************************************/
	public List removeDuplicate(List<String> arlList) {
		if (null != arlList) {
			HashSet h = new HashSet(arlList);
			arlList.clear();
			arlList.addAll(h);
		}
		return arlList;
	}

	/*********************************************************************/

	public List removeDeletedPnpTns(List<String> arlList,
			List<String> deletedPnpLis) {
		if (null != arlList) {
			for (int i = 0; i < deletedPnpLis.size(); i++) {
				String removedTn = deletedPnpLis.get(i);
				arlList.remove(removedTn);
			}
		}
		return arlList;
	}

	/*********************************************************************/

	public String getTNStart(String tnRange) {
		String tnStart = null;
		if (null != tnRange && tnRange.trim().length() > 0
				&& tnRange.indexOf("-") != -1) {
			tnStart = tnRange.substring(0, tnRange.indexOf("-"));
		}
		return tnStart;
	}

	/*********************************************************************/

	public String getTNEnd(String tnRange) {
		String tnEnd = null;
		if (null != tnRange && tnRange.trim().length() > 0
				&& tnRange.indexOf("-") != -1) {
			tnEnd = tnRange.substring(tnRange.indexOf("-") + 1,
					tnRange.length());
		}
		return tnEnd;
	}

	/*********************************************************************/

	public List<String> explodeRangeToTnList(
			ArrayList<TblTerminatingRoutingDbBean> dbTriList, String P1URL,
			String A1URL) {
		ArrayList<String> tnList = new ArrayList<String>();

		for (TblTerminatingRoutingDbBean triBean : dbTriList) {
			// if(!(triBean.getP1url().equals(P1URL) &&
			// triBean.getA1url().equals(A1URL)))
			// if((triBean.getP1url() !=null && triBean.getA1url() != null ) &&
			// !(triBean.getP1url().equals(P1URL) &&
			// triBean.getA1url().equals(A1URL)))
			if (triBean.getP1url() != null && !triBean.getP1url().equals(P1URL))
				continue;

			// IR #1476939: RIV PROD : INV TRI Update Logic Change
			if (triBean.getA1url() != null && !triBean.getA1url().equals(A1URL))
				continue;

			long startRange = Long.parseLong(triBean.getRangeStart());
			long endRange = Long.parseLong(triBean.getRangeEnd());
			for (long tn = startRange; tn <= endRange; tn++)
				tnList.add(String.valueOf(tn));
		}
		return tnList;
	}

	public TblLocationDbBean getLocationForLocationId(String locationId)
			throws SQLException {
		TblLocationDbBean locationDbBean = new TblLocationDbBean();
		ArrayList<TblLocationDbBean> resultList = null;
		try {
			TblLocationQuery locationQuery = new TblLocationQuery();
			locationQuery.whereLocationIdEQ(locationId);
			locationQuery.query(dbCon);

			resultList = locationQuery.getResultArrayList();
			if (resultList.size() > 0) {
				locationDbBean = (TblLocationDbBean) resultList.get(0);
			}
		} catch (SQLException e) {
			e.printStackTrace();
			System.out
					.println("ERROR: Exception caught while trying to get rpid from tbl_location");
		}
		return locationDbBean;

	}

	public DBTblVzbStateGatewayMap getVzbGatewayId(String locState,
			String regionType, String enterpriseId) throws Exception {

		int row = 0;
		DBTblVzbStateGatewayMap gatewayMap = new DBTblVzbStateGatewayMap();

		try {

			log.info(" getVzbGatewayId method");
			StringBuffer sql = new StringBuffer();
			PreparedStatement pStmt = null;
			ResultSet rs = null;
			sql.append(" select * from tbl_vzb_bs_as_ns_mapping where bs_as_id = ");
			sql.append(" ( select as_id from tbl_enterprise where enterprise_id = ?)");

			log.info(" Sql  " + sql.toString());
			log.info(" Enterprise Id  " + enterpriseId);
			try {
				pStmt = dbCon.prepareStatement(sql.toString());
				pStmt.setString(1, enterpriseId);
				if (pStmt != null) {
					rs = pStmt.executeQuery();
					if (rs.next()) {
						gatewayMap.setNsClli(rs.getString(2));
						gatewayMap.setPrimaryGatewayid(rs.getString(3));
						gatewayMap.setPrimaryGatewayname(rs.getString(4));
						gatewayMap.setSecondaryGatewayid(rs.getString(5));
						gatewayMap.setSecondaryGatewayname(rs.getString(6));

						System.out
								.println("Successfully retrieved BsAsNsMapping from db");
						log.info(" NSCLLI :: "
								+ gatewayMap.getNsClli());
						log.info(" PrimaryGatewayId "
								+ gatewayMap.getPrimaryGatewayid()
								+ " PrimaryGatewayName "
								+ gatewayMap.getPrimaryGatewayname());
						log.info(" SecondaryGatewayId "
								+ gatewayMap.getSecondaryGatewayid()
								+ " SecondaryGatewayName "
								+ gatewayMap.getSecondaryGatewayname());

						return gatewayMap;
					}
				}

			} catch (SQLException e) {
				e.printStackTrace();
				// setStatus(InvErrorCode.DB_EXCEPTION);
				log.info("DB_FAILURE in getVzbGatewayId");
				// return regionId;
				throw e;
			} finally {
				if (pStmt != null) {
					pStmt.close();
				}

				if (rs != null) {
					rs.close();
				}
			}

			log.info(" LocState :: " + locState + " regionType  :: "
					+ regionType);
			TblVzbStateGatewayMapQuery gatewayMapQuery = new TblVzbStateGatewayMapQuery();
			gatewayMapQuery.whereStateMnemonicEQ(locState);
			// gatewayMapQuery.whereStateNameEQ(locState);
			gatewayMapQuery.whereRegionEQ(regionType);
			gatewayMapQuery.query(dbCon);

			ArrayList resultList = gatewayMapQuery.getResultArrayList();
			Iterator iter = resultList.iterator();
			if (iter.hasNext()) {
				TblVzbStateGatewayMapDbBean gatewayMapBean = (TblVzbStateGatewayMapDbBean) (iter
						.next());

				gatewayMap.setNsClli(gatewayMapBean.getNsClli());
				gatewayMap.setStateMnemonic(gatewayMapBean.getStateMnemonic());
				gatewayMap.setStateName(gatewayMapBean.getStateName());
				gatewayMap.setMissisippiRiverSide(gatewayMapBean
						.getMissisippiRiverSide());
				gatewayMap.setPrimaryGatewayid(gatewayMapBean
						.getPrimaryGatewayid());
				gatewayMap.setPrimaryGatewayname(gatewayMapBean
						.getPrimaryGatewayname());
				gatewayMap.setSecondaryGatewayid(gatewayMapBean
						.getSecondaryGatewayid());
				gatewayMap.setSecondaryGatewayname(gatewayMapBean
						.getSecondaryGatewayname());

			} else {
				/**
				 * gatewayMapQuery = new TblVzbStateGatewayMapQuery();
				 * gatewayMapQuery.whereStateMnemonicEQ(locState);
				 * gatewayMapQuery.query(connection); resultList =
				 * gatewayMapQuery.getResultArrayList(); iter =
				 * resultList.iterator(); if (iter.hasNext()) {
				 * TblVzbStateGatewayMapDbBean gatewayMapBean =
				 * (TblVzbStateGatewayMapDbBean) (iter.next());
				 * 
				 * gatewayMap.setStateMnemonic(gatewayMapBean.getStateMnemonic()
				 * ); gatewayMap.setStateName(gatewayMapBean.getStateName());
				 * gatewayMap.setMissisippiRiverSide(gatewayMapBean.
				 * getMissisippiRiverSide());
				 * gatewayMap.setPrimaryGatewayid(gatewayMapBean
				 * .getPrimaryGatewayid());
				 * gatewayMap.setPrimaryGatewayname(gatewayMapBean
				 * .getPrimaryGatewayname());
				 * gatewayMap.setSecondaryGatewayid(gatewayMapBean
				 * .getSecondaryGatewayid());
				 * gatewayMap.setSecondaryGatewayname(
				 * gatewayMapBean.getSecondaryGatewayname());
				 * 
				 * } else { //IR #1135999 throw new
				 * Exception("No matching records were found"); }
				 ***/
				throw new Exception("No matching records were found");
			}

			log.info("getVzbGatewayId() - has  returned  rows ["
					+ resultList.size() + "]");
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception(
					"Execption caught while trying to get tbl_vzb_state_gateway_map entries");
		}

		log.info(" NSCLLI :: " + gatewayMap.getNsClli());
		log.info(" PrimaryGatewayId "
				+ gatewayMap.getPrimaryGatewayid() + " PrimaryGatewayName "
				+ gatewayMap.getPrimaryGatewayname());
		log.info(" SecondaryGatewayId "
				+ gatewayMap.getSecondaryGatewayid() + " SecondaryGatewayName "
				+ gatewayMap.getSecondaryGatewayname());

		return gatewayMap;
	}

	public int getFeatureId(String featureName) throws Exception {

		int featureId = 0;
		TblVzbFeaturesQuery vzbFeats = new TblVzbFeaturesQuery();
		vzbFeats.whereNameLike(featureName);
		vzbFeats.query(dbCon);
		ArrayList<?> resultSet = vzbFeats.getResultArrayList();

		log.info("vzbfeatures for featurename:<" + featureName
				+ "> size <" + vzbFeats.size());

		if (vzbFeats.size() > 0) {
			TblVzbFeaturesDbBean vzbFeatDbBean = (TblVzbFeaturesDbBean) resultSet
					.get(0);
			featureId = vzbFeatDbBean.getFeatureId();
			log.info("FeatureID <" + featureId
					+ "> in tbl_vzb_features");

		} else {
			log.info("Feature: " + featureName + " not found in DB.");
			// Need to throw exception.
			return 0;
		}
		return featureId;
	}

	public void processCNAM(String cnamInd, String subId, long groupId)
			throws Exception {

		log.info(" Entering ProcessCNAM ");
		log.info(" CNAM " + cnamInd);
		log.info(" SubId " + subId);
		log.info(" groupId " + groupId);

		int cnamFeatureId = getFeatureId("Calling Name Retrieval");

		// For HIPC Subscribers
		if (subId != null) {

			// Check whether the record is present there in the TblSubfeature.
			// if present , update to Cnam ind
			// else create a record with cnam value.
			TblSubFeatureQuery tblSubFeatureQuery = new TblSubFeatureQuery();
			tblSubFeatureQuery.whereSubIdEQ(subId);
			tblSubFeatureQuery.whereFeatureIdEQ(cnamFeatureId);
			tblSubFeatureQuery.query(dbCon);
			int subFeatureSize = tblSubFeatureQuery.getResultArrayList().size();

			SubFeatures subFeature = new SubFeatures(dbCon);
			subFeature.setSelected(cnamInd);
			subFeature.setSubId(subId);
			subFeature.setModifiedBy(getModifiedBy());

			// To Make it Consistent with normal BAU flow, we are deleting the
			// CallingNameRetrival feature in the subfeature table
			// when they turn off CNAM in location.
			if (subFeatureSize > 0) {
				log.info(" getSubFeatureId "
						+ tblSubFeatureQuery.getDbBean(0).getSubFeatureId());
				subFeature.setSubFeatureId(tblSubFeatureQuery.getDbBean(0)
						.getSubFeatureId());
				subFeature.updateSubFeature();
				setLogTrail(" Updating CNAM " + cnamInd + " for the SubId "
						+ subId + " SubFeature Id "
						+ subFeature.getSubFeatureId());
				log.info(" Updating CNAM " + cnamInd
						+ " for the SubId " + subId + " SubFeature Id "
						+ subFeature.getSubFeatureId());
			} else {
				subFeature.setCreatedBy(getCreatedBy());
				subFeature.setFeatureId(cnamFeatureId);
				subFeature.addSubFeatures();
				setLogTrail(" Inserted CNAM " + cnamInd + " for the SubId "
						+ subId + " SubFeature Id "
						+ subFeature.getSubFeatureId());
				log.info(" Inserted CNAM " + cnamInd
						+ " for the SubId " + subId + " SubFeature Id "
						+ subFeature.getSubFeatureId());
			}

		}

		// for Pbx/Key Customers
		if (groupId > 0) {
			// Check whether the record is present there in the TblGroupfeature.
			// if CNAM IND is "N" then delete it
			// if CNAM IND is "Y" then create a record in tblGroupFeature
			TblGroupFeaturesQuery tblGroupFeatureQuery = new TblGroupFeaturesQuery();
			tblGroupFeatureQuery.whereGroupIdEQ(groupId);
			tblGroupFeatureQuery.whereFeatureIdEQ(cnamFeatureId);
			tblGroupFeatureQuery.query(dbCon);
			int GroupFeatureSize = tblGroupFeatureQuery.getResultArrayList()
					.size();

			DBTblGroupFeatures tblGroupFeature = new DBTblGroupFeatures();
			tblGroupFeature.setGroupId(groupId);
			tblGroupFeature.setFeatureId(cnamFeatureId);

			if (GroupFeatureSize > 0) {
				if ("N".equals(cnamInd)) {
					log.info(" GroupFeatureId "
							+ tblGroupFeatureQuery.getDbBean(0)
									.getGroupFeatureId());
					tblGroupFeature.setGroupFeatureId(tblGroupFeatureQuery
							.getDbBean(0).getGroupFeatureId());
					tblGroupFeature.delete(dbCon);
					setLogTrail(" Deleted Group Feature for group " + groupId
							+ " for the change of CNAM  " + cnamInd);
					log.info(" Deleted Group Feature for group "
							+ groupId + " for the change of CNAM  " + cnamInd);
				}
			} else {
				if ("Y".equals(cnamInd)) {

					int grpFeatureSeqid = tblGroupFeature
							.getGroupFeatureIdSeqNextVal(dbCon);
					tblGroupFeature.setGroupFeatureId(grpFeatureSeqid);
					tblGroupFeature.setCreatedBy(getCreatedBy());
					tblGroupFeature.setModifiedBy(getModifiedBy());
					tblGroupFeature.setCreationDate(new Timestamp(System
							.currentTimeMillis()));
					tblGroupFeature.setLastModifiedDate(new Timestamp(System
							.currentTimeMillis()));
					tblGroupFeature.setEnvOrderId(getEnvOrderId());
					tblGroupFeature.insert(dbCon);

					setLogTrail(" Inserted Group Feature for group " + groupId
							+ " for the change of CNAM  " + cnamInd);
					log.info(" Inserted Group Feature for group "
							+ groupId + " for the change of CNAM  " + cnamInd);
				}
			}
		}

		log.info(" Exit ProcessCNAM ");

	}

	public boolean processCNAM() throws Exception {

		log.info(" Entering ProcessCNAM ");

		String cnamInd = null;
		String subId = null;
		long groupId = 0;
		Location inputLocation = this;

		if (inputLocation.getLocationId() == null
				|| "".equalsIgnoreCase(inputLocation.getLocationId())) {
			setStatus(InvErrorCode.MISSING_LOCATION_ID);
			log.info("FAILURE in process CNAM. Location Id missing.");
			return false;
		}

		log.info(" inputLocation.getCallingNameInd "
				+ inputLocation.getCallingNameInd());

		cnamInd = VzbVoipEnum.YesNoType.acronym((int) inputLocation
				.getCallingNameInd());
		log.info(" CNAM " + cnamInd);

		// For HIPC Subscribers
		TblSubscriberQuery subQry = new TblSubscriberQuery();
		subQry.whereLocationIdEQ(inputLocation.getLocationId());
		subQry.query(dbCon);

		int subCount = subQry.getResultArrayList().size();

		for (int i = 0; i < subCount; i++) {
			subId = subQry.getDbBean(i).getSubId();
			if (subId != null) {
				processCNAM(cnamInd, subId, groupId);
			}
		}

		// for Pbx/Key Customers
		TblGroupQuery groupQry = new TblGroupQuery();
		groupQry.whereLocationIdEQ(inputLocation.getLocationId());
		groupQry.query(dbCon);

		int groupCount = groupQry.getResultArrayList().size();

		for (int i = 0; i < groupCount; i++) {
			groupId = groupQry.getDbBean(i).getGroupId();

			if (groupId > 0) {
				processCNAM(cnamInd, subId, groupId);
			}
		}

		log.info(" Exit ProcessCNAM ");
		setStatus(InvErrorCode.SUCCESS);
		log.info("Successfully UPDATED CNAM CHANGES into the DB");
		return true;
	}

	public boolean isValidCCL() throws Exception {

		boolean returnCode = true;
		TblLocationQuery locQry = new TblLocationQuery();
		locQry.whereLocationIdEQ(getLocationId());
		locQry.query(dbCon);
		if (locQry.size() > 0) {
			List<Long> locCclList = new ArrayList();

			if (getMaxConcurrentCalls() > -1) {
				locCclList.add(getMaxConcurrentCalls());
				log.info(" Taking MaxConcurrentCalls from input "
						+ getMaxConcurrentCalls());
			} else {
				locCclList.add(locQry.getDbBean(0).getMaxConcurrentCalls());
				log.info(" Taking MaxConcurrentCalls from DB "
						+ locQry.getDbBean(0).getMaxConcurrentCalls());
			}

			if (getMaxConcurrentOffnet() > -1) {
				locCclList.add(getMaxConcurrentOffnet());
				log.info(" Taking MaxConcurrentOffnet from input "
						+ getMaxConcurrentOffnet());
			} else {
				locCclList.add(locQry.getDbBean(0).getMaxConcurrentOffnet());
				log.info(" Taking MaxConcurrentOffnet from DB "
						+ locQry.getDbBean(0).getMaxConcurrentOffnet());
			}

			if (getMaxInbound() > -1) {
				locCclList.add(getMaxInbound());
				log.info(" Taking getMaxInbound from input "
						+ getMaxInbound());
			} else {
				locCclList.add(locQry.getDbBean(0).getMaxInbound());
				log.info(" Taking getMaxInbound from DB "
						+ locQry.getDbBean(0).getMaxInbound());
			}

			if (getMaxSlg() > -1) {
				locCclList.add(getMaxSlg());
				log.info(" Taking getMaxSlg from input "
						+ getMaxSlg());
			} else {
				locCclList.add(locQry.getDbBean(0).getMaxSlg());
				log.info(" Taking getMaxSlg from DB "
						+ locQry.getDbBean(0).getMaxSlg());
			}

			if (getMaxNg() > -1) {
				locCclList.add(getMaxNg());
				log.info(" Taking getMaxNg from input " + getMaxNg());
			} else {
				locCclList.add(locQry.getDbBean(0).getMaxNg());
				log.info(" Taking getMaxNg from DB "
						+ locQry.getDbBean(0).getMaxNg());
			}

			Long maxCcl = Collections.max(locCclList);
			long locMaxCcl = maxCcl.longValue();
			log.info("MaxCcl of location:" + locMaxCcl);

			long sumOfGrpCcl = 0;

			TblGroupQuery grpQry = new TblGroupQuery();
			grpQry.whereLocationIdEQ(getLocationId());
			// IR #1457636 OM Seq issue for Drop One PBX Grp1 and Adding PBX
			// Grp2 in the SUPP Pass
			grpQry.whereActiveIndEQ(VzbVoipEnum.YesNoType.Y);
			grpQry.query(dbCon);

			if (grpQry.size() > 0) {
				for (int i = 0; i < grpQry.size(); i++) {
					// if(grpQry.getDbBean(i).getGroupId() != getGroupId())
					sumOfGrpCcl += grpQry.getDbBean(i).getPbxMaxCclLimit();
				}
			}

			log.info("SumOfGrpCcl " + sumOfGrpCcl);

			if (sumOfGrpCcl > locMaxCcl)
				returnCode = false;
		}
		return returnCode;

	}

	public ArrayList getAssignedLines(String locationId) throws Exception {
		ArrayList<String> arrayList = new ArrayList<String>();

		PreparedStatement pStmt = null;
		ResultSet rs = null;
		StringBuffer sql = new StringBuffer();
		sql.append("select ts.BS_SUB_ID as LOCATION_LINE from tbl_subscriber ts, tbl_subscriber_tn tst, tbl_public_tn_pool pnp");
		sql.append(" where ts.location_id = ? and ts.active_ind = 1 and tst.sub_id = ts.sub_id and pnp.TN = tst.user_id");
		sql.append(" and pnp.active_ind = 1 and pnp.tn_status = 1 UNION");
		sql.append(" select pnp.tn as LOCATION_LINE from tbl_group_tn tgt, tbl_public_tn_pool pnp, tbl_group tg");
		sql.append(" where tg.location_id = ?");
		sql.append(" and tgt.group_id = tg.group_id and tgt.active_ind = 1");
		sql.append(" and pnp.tn_pool_id = tgt.tn_pool_id and pnp.PORTED_STATUS != 1 and pnp.active_ind = 1 and pnp.tn_status = 1");
		sql.append(" UNION select ts.BS_SUB_ID as LOCATION_LINE from tbl_subscriber ts, tbl_subscriber_tn tst");
		sql.append(" where ts.active_ind = 1 and ts.location_id=?");
		sql.append(" and tst.sub_id = ts.sub_id and tst.nat_user_id = 0");
		sql.append(" and tst.sub_id not in (select sub_id from tbl_subscriber_tn where nat_user_id = 1 and sub_id = ts.sub_id)");
		sql.append(" UNION select ts.BS_SUB_ID as LOCATION_LINE from tbl_subscriber ts");
		sql.append(" where ts.active_ind = 1 and ts.location_id=?");
		sql.append(" and ts.sub_id not in (select sub_id from tbl_subscriber_tn where sub_id = ts.sub_id )");

		log.info("sql=" + sql);
		try {
			pStmt = dbCon.prepareStatement(sql.toString());
			pStmt.setString(1, locationId);
			pStmt.setString(2, locationId);
			pStmt.setString(3, locationId);
			pStmt.setString(4, locationId);
			if (null != pStmt)

				rs = pStmt.executeQuery();

			while (rs.next()) {
				// log.info(" AssignedLines " + rs.getString(1));
				arrayList.add(rs.getString(1));
			}
			log.info(" Assigned Lines  " + arrayList);
		} catch (SQLException e) {
			throw e;
		} finally {
			try {

				if (rs != null)
					rs.close();

			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				pStmt.close();
			}
		}

		return arrayList;
	}

	// IR #1446242 Issue with HUB/Remote Cancel/delete - Provide API for OM
	public HashMap<String, String> validateLocId(String locationId)
			throws Exception {

		log.info(" Method validateLocId ");
		log.info(" LocationId " + locationId);

		PreparedStatement pstmt = null;
		ResultSet rs = null;
		StringBuffer sql = new StringBuffer();
		ArrayList<String> locIdList = null;
		String status = "true";
		String message = null;
		HashMap<String, String> hashMap = new HashMap<String, String>();
		sql.append(" select location_id from tbl_group where device_map_id in");
		sql.append(" ( select device_map_id from tbl_device_map where location_id=? )");
		sql.append(" and location_id != ?");

		hashMap.put("Status", status);
		hashMap.put("Message", message);
		log.info(" sql " + sql.toString());
		try {
			pstmt = dbCon.prepareStatement(sql.toString());
			pstmt.setString(1, locationId);
			pstmt.setString(2, locationId);
			rs = pstmt.executeQuery();

			if (rs.next()) {
				locIdList = new ArrayList<String>();
				locIdList.add(rs.getString(1));
				while (rs.next()) {
					locIdList.add(rs.getString(1));
				}
				status = "false";
				log.info(" Location List " + locIdList);

				message = "Location "
						+ locationId
						+ " cannot be deleted. Devices are shared by other locations "
						+ locIdList;
				hashMap.put("Status", status);
				hashMap.put("Message", message);
			}
			log.info(" Message " + message);

		} catch (Exception e) {
			e.printStackTrace();
			System.out
					.println("ERROR: Exception caught while trying to retrieve from DB");
			throw e;
		} finally {
			if (rs != null) {
				rs.close();
			}

			if (pstmt != null) {
				pstmt.close();
			}

		}

		return hashMap;
	}

	public int getRegion(String locationId) throws SQLException {
		log.info(" getRegion method");
		StringBuffer sql = new StringBuffer();
		PreparedStatement pStmt = null;
		ResultSet rs = null;
		sql.append(" select region_id from tbl_customer where customer_id = ");
		sql.append(" ( select enterprise_id from tbl_location where location_id= ?)");
		int regionId = 0;
		log.info(" Sql  " + sql.toString());
		log.info(" location id " + locationId);
		try {
			pStmt = dbCon.prepareStatement(sql.toString());
			pStmt.setString(1, locationId);
			if (pStmt != null) {
				rs = pStmt.executeQuery();
				if (rs.next()) {
					regionId = rs.getInt(1);
					log.info(" Region Id " + regionId);
				}
			}

		} catch (SQLException e) {
			e.printStackTrace();
			// setStatus(InvErrorCode.DB_EXCEPTION);
			log.info("DB_FAILURE in getRegion");
			// return regionId;
			throw e;
		} finally {
			if (pStmt != null) {
				pStmt.close();
			}

			if (rs != null) {
				rs.close();
			}
		}
		// setStatus(InvErrorCode.SUCCESS);
		log.info("Successfully retrieved getRegion from db");
		log.info(" Region Id " + regionId);
		return regionId;
	}

	public boolean isSbc() throws SQLException, Exception {
		log.info("Entering isSbc");
		TblSbcOrderQuery sQry = new TblSbcOrderQuery();
		sQry.whereLocationIdEQ(getLocationId());
		sQry.query(dbCon);

		if (sQry.size() <= 0) {
			log.info("Location Not Found in SBC Order");
			return false;
		}

		log.info("Found Location in SBC Order");
		return true;
	}

	public boolean validAccessType() throws SQLException, Exception {
		// Check for SBC Access Type != "D"
		log.info("Entering validAccessType");
		TblAccessTypeQuery tQry = new TblAccessTypeQuery();
		tQry.whereAccessTypeIdEQ((int) getAccessType());
		tQry.whereSbcAccessTypeNE("D");
		tQry.query(dbCon);

		if (tQry.size() <= 0) {
			log.info("Not Valid Type to Update VpnName");
			return false;
		}

		log.info("Found Valid Access Type to Update VpnName");
		return true;
	}

	public boolean isTnPortPendingOrDeactivated() throws SQLException,
			Exception {
		// Update DIal Plan's OnNetStat only when there is no port pending or
		// deactivated tn in the enterprise.
		log.info("Entering isTnPortPendingOrDeactivated");
		TblLocationQuery lQry = new TblLocationQuery();
		lQry.whereEnterpriseIdEQ(getEnterpriseId());
		lQry.query(dbCon);

		for (int i = 0; i < lQry.size(); i++) {
			log.info("Check Location Id ["
					+ lQry.getDbBean(i).getLocationId() + "]");
			TblPublicTnPoolQuery tQry = new TblPublicTnPoolQuery();
			tQry.whereLocationIdEQ(lQry.getDbBean(i).getLocationId());
			tQry.whereTnStatusEQ(VzbVoipEnum.TnStatus.ASSIGNED);
			tQry.whereActDeactEQ((short) VzbVoipEnum.ActDeact.DEACTIVATED);
			tQry.query(dbCon);

			if (tQry.size() > 0) {
				log.info("Found Deactivated Tn");
				return true;
			}

			/*
			 * TblPublicTnPoolQuery tnQry = new TblPublicTnPoolQuery();
			 * tnQry.whereLocationIdEQ(lQry.getDbBean(i).getLocationId());
			 * tnQry.
			 * wherePortedStatusEQ(""+VzbVoipEnum.PortStatus.PORT_PENDING);
			 * tnQry.query(dbCon);
			 * 
			 * if(tnQry.size() > 0) {
			 * log.info("Found Port Pending Tn"); return true; }
			 */
		}

		log.info("No Tns found Deactivated or Port Pending");
		return false;
	}

	public boolean isAuLocation() throws SQLException, Exception {
		log.info("Entering isAuLocation");
		TblLocationQuery lQry = new TblLocationQuery();
		lQry.whereLocationIdEQ(getLocationId());
		lQry.query(dbCon);

		if (lQry.size() <= 0) {
			log.info("Location Id [" + getLocationId()
					+ "] Not Found");
			return false;
		}

		if (lQry.getDbBean(0).getLocCountry().equals("AU")) {
			log.info("AU Location");
			return true;
		}

		log.info("Not AU Location");
		return false;
	}

	public String getRegionByLocationId(String locationId) throws SQLException,
			Exception {
		log.info("Entering getRegionByLocationId");
		String region = "";
		StringBuffer sql = new StringBuffer();
		PreparedStatement pStmt = null;
		ResultSet rs = null;
		sql.append("select c.cust_market from tbl_enterprise c, tbl_location l where c.enterprise_id = l.enterprise_id and l.location_id= ?");
		log.info(" Sql  " + sql.toString());
		log.info("LocationId [" + locationId + "]");
		try {
			pStmt = dbCon.prepareStatement(sql.toString());
			pStmt.setString(1, locationId);
			if (pStmt != null) {
				rs = pStmt.executeQuery();
				if (rs.next())
					region = VzbVoipEnum.CustMarketType.acronym(rs.getInt(1));
			}
			log.info("Retrieved Region as [" + region + "]");
		} finally {
			// IR #1638603
			if (rs != null)
				rs.close(); // Result set closed
			if (pStmt != null) {// Prepared statement closed.
				pStmt.close();
			}
		}
		return region;
	}

	public boolean updateSharedGwLocation() throws SQLException, Exception {
		// Update Shared Gateway Location to Null before deleting the location
		log.info("Entering updateSharedGwLocation");
		StringBuffer sql = new StringBuffer();
		PreparedStatement pStmt = null;
		ResultSet rs = null;
		sql.append("select d.gateway_device_id, d.location_id  from tbl_device_map d, tbl_gateway_device_info g, tbl_device_types t ");
		sql.append("where g.gateway_device_id = d.gateway_device_id and g.device_type_id = t.device_type_id");
		sql.append(" and t.device_realtype_id in (4,5) and d.location_id = ?");

		log.info(" Sql  " + sql.toString());
		log.info("LocationId [" + getLocationId() + "]");
		try {
			pStmt = dbCon.prepareStatement(sql.toString());
			pStmt.setString(1, getLocationId());
			if (pStmt != null) {
				rs = pStmt.executeQuery();
				while (rs.next()) {
					if (isSTNBelongtoDifferentLocation(rs.getString(1),
							getLocationId()) != true) {
						DBTblGatewayDeviceInfo gwDb = new DBTblGatewayDeviceInfo();
						gwDb.whereGatewayDeviceIdEQ(rs.getInt(1));
						gwDb.setStnPoolIdNull();
						gwDb.setStnLinePortNull();
						gwDb.updateSpByWhere(dbCon);
						log.info("Updated STN for Shared Gateway ["
								+ rs.getLong(1) + "] to Null");
					} else
						log.info("STN of Shared Gateway ["
								+ rs.getLong(1)
								+ "] Not Mapped to the Location ["
								+ getLocationId() + "] being deleted");

					// There could be shared gateways not mapped to any
					// location, but STN might be mapped to the location being
					// deleted
					ArrayList<Long> shGwList = getSharedGwyIdsWithStnbyLocId(getLocationId());
					if (shGwList != null) {
						for (int i = 0; i < shGwList.size(); i++) {
							log.info("STN found in Gateway ["
									+ shGwList.get(i).intValue()
									+ "] mapped to the location being deleted");
							DBTblGatewayDeviceInfo gw = new DBTblGatewayDeviceInfo();
							gw.whereGatewayDeviceIdEQ(shGwList.get(i)
									.intValue());
							gw.setStnPoolIdNull();
							gw.setStnLinePortNull();
							gw.updateSpByWhere(dbCon);
						}
					}
					DBTblDeviceMap gwUpd = new DBTblDeviceMap();
					gwUpd.whereGatewayDeviceIdEQ(rs.getLong(1));
					gwUpd.setLocationIdNull();
					gwUpd.updateSpByWhere(dbCon);
					System.out
							.println("Updated Location Id to Null for GatewayDeviceId ["
									+ rs.getLong(1) + "]");
				}

			}
		} finally {
			if (rs != null)
				rs.close();
			if (pStmt != null)
				pStmt.close();
		}
		log.info("Successfully Updated Location Shared Gateway");
		return true;
	}

	public ArrayList<Long> getSharedGwyIdsWithStnbyLocId(String locId)
			throws SQLException, Exception {
		// Get Shared Gateway with STN mapped to the Location
		log.info("Entering getSharedGwyIdsWithStn");
		ArrayList<Long> gwList = null;
		StringBuffer sql = new StringBuffer();
		PreparedStatement pStmt = null;
		ResultSet rs = null;
		sql.append("select dm.gateway_device_id");
		sql.append(" from tbl_device_map dm, tbl_gateway_device_info gdi, tbl_public_tn_pool pnp, tbl_device_types tdt");
		sql.append(" where  pnp.location_id = ?");
		sql.append(" and gdi.gateway_device_id = dm.gateway_device_id");
		sql.append(" and tdt.device_type_id = gdi.device_type_id");
		sql.append(" and tdt.device_realtype_id =4");
		sql.append(" and pnp.tn_pool_id = gdi.stn_pool_id");
		try {
			log.info(" Sql  " + sql.toString());
			log.info("LocationId [" + locId + "]");
			pStmt = dbCon.prepareStatement(sql.toString());
			pStmt.setString(1, locId);
			if (pStmt != null) {
				rs = pStmt.executeQuery();
				if (rs != null) {
					gwList = new ArrayList<Long>();
					while (rs.next()) {
						log.info("Retrieved Shared Gateway Id ["
								+ rs.getLong(1) + "]");
						gwList.add(rs.getLong(1));
					}
				}
			}
		} finally {
			if (rs != null)
				rs.close();
			if (pStmt != null)
				pStmt.close();
		}
		if (gwList != null)
			log.info("Retrieved [" + gwList.size()
					+ "] Shared Gateways");
		else
			log.info("No Shared Gateways Found by Location [" + locId
					+ "]");
		return gwList;
	}

	// March 2011 Changes Start
	/**
	 * IR #1611477 This API is to find whether STN belongs to same location or
	 * differnet location.
	 * 
	 * @param String
	 *            sharedGwyDeviceMapId- shared GWY device_map_id
	 * @param String
	 *            hubLocationId- hub location_id of the shared gwy and stn line
	 *            port
	 * @return boolean true- STN is mapped to different location false- STN is
	 *         mapped to same location
	 */
	public boolean isSTNBelongtoDifferentLocation(String sharedGwyDeviceMapId,
			String hubLocationId) throws Exception {

		PreparedStatement pStmt = null;
		ResultSet rs = null;
		StringBuffer sql = new StringBuffer();
		sql.append("select dm.device_map_id, dm.location_id, gdi.stn_pool_id, gdi.stn_line_port, pnp.tn, pnp.location_id");
		sql.append(" from tbl_device_map dm, tbl_gateway_device_info gdi, tbl_public_tn_pool pnp, tbl_device_types tdt");
		sql.append(" where dm.device_map_id = ?");
		sql.append(" and dm.location_id = ?");
		sql.append(" and gdi.gateway_device_id = dm.gateway_device_id");
		sql.append(" and tdt.device_type_id = gdi.device_type_id");
		sql.append(" and tdt.device_realtype_id = 4");
		sql.append(" and pnp.tn_pool_id = gdi.stn_pool_id");
		sql.append(" and dm.location_id != pnp.location_id");
		log.info("sql=" + sql);
		try {
			pStmt = dbCon.prepareStatement(sql.toString());
			pStmt.setString(1, sharedGwyDeviceMapId);
			pStmt.setString(2, hubLocationId);
			if (null != pStmt)
				rs = pStmt.executeQuery();
			if (rs.next())
				return true;
			else
				return false;
		} catch (SQLException e) {
			throw e;
		} finally {
			try {
				if (rs != null)
					rs.close();
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				pStmt.close();
			}
		}
	}

	// March 2011 Changes Ends

	public long getLocTrunkCclSumByLocationId(String locationId) {
		log.info("Entering getLocTrunkCclSumByLocationId");
		long cclSum = 0;
		try {
			TblLocationQuery locQry = new TblLocationQuery();
			locQry.whereLocationIdEQ(locationId);
			locQry.query(dbCon);
			if (locQry.size() > 0) {
				cclSum = locQry.getDbBean(0).getLocTrunkCclSum();
				log.info("Retrieved LocTrunkCclSum [" + cclSum
						+ "] by LocationId [" + locationId + "]");
			} else
				log.info("LocationId [" + locationId + "] Not Found");
		} catch (SQLException e) {
			setStatus(InvErrorCode.DB_EXCEPTION);
			e.printStackTrace();
			return cclSum;
		} catch (Exception e) {
			e.printStackTrace();
			setStatus(InvErrorCode.INTERNAL_ERROR);
			return cclSum;
		}
		setStatus(InvErrorCode.SUCCESS);
		return cclSum;
	}

	// to delete tbl_tn_porting_info entry with the matchin tn_pool_id from
	// tbl_public_tn_pool table
	private boolean deleteTnPortingInfo(String locationId) throws Exception,
			SQLException {
		log.info("Enter deleteTnPortingInfo Method===>" + locationId);
		PreparedStatement pstmt = null;
		String sqlQuery = "delete from tbl_tn_porting_info where tn_pool_id in (select tn_pool_id from tbl_public_tn_pool where location_id = ? ) ";
		try {
			pstmt = dbCon.prepareStatement(sqlQuery);
			pstmt.setString(1, locationId);
			pstmt.executeUpdate();
		}/*
		 * catch(Exception e){ e.printStackTrace();
		 * log.info("Exception in deleteTnPortingInfo method==>"
		 * +e.getMessage()); return false; }
		 */finally { // #IR1440263 closing statement and results set
			if (pstmt != null) {
				pstmt.close();
			}
		}

		return true;

	}

	/*
	 * Rules: 1. If the Product is LD, the Dialplan = Wholesale. 2. If the
	 * Shared Trunk = Ghost Trunk, then DialPlan = Wholesale. (A Ghost Trunk is
	 * defined by any trunk starting with a V) 3. If the Shared Trunk = 5400
	 * Trunk, then DialPlan = Global Dial Plan (A 5400 Trunk is defined by any
	 * trunk NOT starting with a V). IR #1836992 INV AF should not change
	 * GatewayDpid or DefaultDpid to zero if clli/trunk is null in pnp
	 */
	public HashMap<String, String> deriveGtwyDpid(String locationId)
			throws Exception {

		String usPublicGtwyDpid = null;
		String usDefaultGtwyDpid = null;
		HashMap<String, String> pubDefGtwyDpid = new HashMap<String, String>();

		if (locationId != null
				&& getRegion(locationId) == VzbVoipEnum.RegionType.US) {

			usPublicGtwyDpid = getConfigParamValue("RIV_INV",
					"UsPublicGtwyDpid");
			usDefaultGtwyDpid = getConfigParamValue("RIV_INV",
					"UsDefaultGtwyDpid");

			if ((usPublicGtwyDpid == null || (usPublicGtwyDpid != null && ""
					.equals(usPublicGtwyDpid)))
					|| (usDefaultGtwyDpid == null || (usDefaultGtwyDpid != null && ""
							.equals(usDefaultGtwyDpid)))) {
				throw new Exception(
						"Missing Config Param usPublicGtwyDpid or usDefaultGtwyDpid.");
			}

			TblLocationDbBean locationDbBean = getLocationForLocationId(locationId);
			if (locationDbBean != null
					&& (locationDbBean.getServiceLevel() == VzbVoipEnum.ServiceLevel.LD_AND_ON_NET)) {

				pubDefGtwyDpid.put("PublicGtwyDpid", usPublicGtwyDpid);
				pubDefGtwyDpid.put("DefaultGtwyDpid", usDefaultGtwyDpid);

				System.out
						.println(" ServiceLevel is LD_AND_ON_NET. Setting PublicGtwyDpid ="
								+ usPublicGtwyDpid
								+ " DefaultGtwyDpid ="
								+ usDefaultGtwyDpid);

			} else {
				String trunk = getSingleValidTrunkFromPnp(locationId);

				if (trunk != null
						&& (trunk.startsWith("v") || trunk.startsWith("V"))) {

					pubDefGtwyDpid.put("PublicGtwyDpid", usPublicGtwyDpid);
					pubDefGtwyDpid.put("DefaultGtwyDpid", usDefaultGtwyDpid);

					log.info("For Ghost Trunk PublicGtwyDpid ="
							+ usPublicGtwyDpid + " DefaultGtwyDpid ="
							+ usDefaultGtwyDpid);

				}/*
				 * else { pubDefGtwyDpid.put("PublicGtwyDpid","0");
				 * pubDefGtwyDpid.put("DefaultGtwyDpid","0"); }
				 */
			}

		} else {
			log.info("Non US order not setting PublicGtwyDpid.");
		}

		return pubDefGtwyDpid;
	}

	public String getSingleValidTrunkFromPnp(String locationId)
			throws Exception {
		String trunk = null;
		try {
			TblPublicTnPoolQuery publicTnPoolQuery = new TblPublicTnPoolQuery();
			publicTnPoolQuery.whereLocationIdEQ(locationId);
			publicTnPoolQuery.whereTrunkIsNotNull();
			publicTnPoolQuery.query(dbCon);
			if (publicTnPoolQuery.size() > 0) {
				trunk = publicTnPoolQuery.getDbBean(0).getTrunk();
				log.info("Retrieved Trunk [" + trunk
						+ "] from PNP for LocationId [" + locationId + "]");
			}

		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception(
					"Exception caught while trying to get records from tbl_public_pool_tn");
		}
		return trunk;
	}

	// venkata c - author
	// compare the stn with rpid, etn,btn and return true if it matches with any
	// one of them else false
	public short isSTN_RPID_ETN_BTN(String locationId, String stn)
			throws Exception {

		short returnResult = (short) InvEnum.isSTN_RPID_ETN_BTN.STN_NOT_MATCHING_ETN_BTN_RPID;

		StringBuffer sql = new StringBuffer();

		ResultSet rs = null;
		long emerPoolId = -1;
		long btnPoolId = -1;
		long rpidPoolId = -1;
		long stnPoolId = -1;
		long inputSTNPOOLID = -1;

		if (stn != null && !stn.trim().equals("")) {
			TblPublicTnPoolQuery poolQry = new TblPublicTnPoolQuery();
			poolQry.whereTnEQ(stn);
			// String whereCls = " where tn = \'" +stn +"\'";
			log.info("===================TESTING :");
			poolQry.query(dbCon);

			if (poolQry.size() < 0) {
				returnResult = (short) InvEnum.isSTN_RPID_ETN_BTN.INPUT_STN_COULD_NOT_BE_LOCATED_IN_DB;
				return returnResult;
			} else {
				inputSTNPOOLID = poolQry.getDbBean(0).getTnPoolId();
			}
		}
		if (locationId == null && locationId.trim().equals("")) {
			throw new Exception("INPUT LOCATION ID CANNNOT BE EMPTY OR NULL.");
		}

		TblLocationQuery locationQry = new TblLocationQuery();
		String locWhereCls = " where location_id = \'" + locationId + "\'";

		locationQry.queryByWhere(dbCon, locWhereCls);
		if (locationQry.size() > 0) {
			if (locationQry.getDbBean(0).getLocationType() == VzbVoipEnum.LocationType.REMOTE)// Remote
			{

				emerPoolId = locationQry.getDbBean(0).getEmerPoolId();
				btnPoolId = locationQry.getDbBean(0).getBtnPoolId();
				rpidPoolId = locationQry.getDbBean(0).getRpidPoolId();
				stnPoolId = locationQry.getDbBean(0).getStnPoolId();

				if (stnPoolId == emerPoolId) {
					returnResult = (short) InvEnum.isSTN_RPID_ETN_BTN.STN_MATCHES_ETN;

				} else if (stnPoolId == btnPoolId) {
					returnResult = (short) InvEnum.isSTN_RPID_ETN_BTN.STN_MATCHES_BTN;

				} else if (stnPoolId == rpidPoolId) {
					returnResult = (short) InvEnum.isSTN_RPID_ETN_BTN.STN_MATCHES_RPID;
				} else if ((stn != null && !stn.trim().equals(""))
						&& (stnPoolId == inputSTNPOOLID)) {
					returnResult = (short) InvEnum.isSTN_RPID_ETN_BTN.INPUT_STN_DOESNT_MATCH_LOCATION_STN;

				} else {
					returnResult = (short) InvEnum.isSTN_RPID_ETN_BTN.STN_NOT_MATCHING_ETN_BTN_RPID;

				}

			}

			if (locationQry.getDbBean(0).getLocationType() != VzbVoipEnum.LocationType.REMOTE)// HUB
			{

				PreparedStatement pstmt = null;

				sql.append(" select stn_pool_id from tbl_gateway_device_info tgdi, tbl_device_map tdm");
				sql.append(" where tgdi.gateway_device_id = tdm.gateway_device_id  and tdm.location_id = ? and stn_pool_id is not null");
				if (inputSTNPOOLID != -1)
					sql.append(" and stn_pool_id = ?");
				try {
					pstmt = dbCon.prepareStatement(sql.toString());
					pstmt.setString(1, locationId);
					if (inputSTNPOOLID != -1)
						pstmt.setLong(2, inputSTNPOOLID);
					rs = pstmt.executeQuery();
					boolean inputSTNMatchesStnInPool = false;
					while (rs.next()) {

						stnPoolId = rs.getLong(1);

						if (stnPoolId == emerPoolId) {
							returnResult = (short) InvEnum.isSTN_RPID_ETN_BTN.STN_MATCHES_ETN;
							break;

						} else if (stnPoolId == btnPoolId) {
							returnResult = (short) InvEnum.isSTN_RPID_ETN_BTN.STN_MATCHES_BTN;
							break;
						} else if (stnPoolId == rpidPoolId) {
							returnResult = (short) InvEnum.isSTN_RPID_ETN_BTN.STN_MATCHES_RPID;
							break;
						} else if ((stn != null && !stn.trim().equals(""))
								&& (stnPoolId == inputSTNPOOLID)) {
							inputSTNMatchesStnInPool = true;
							break;
						} else {
							returnResult = (short) InvEnum.isSTN_RPID_ETN_BTN.STN_NOT_MATCHING_ETN_BTN_RPID;
							break;
						}
					}
					if ((stn != null && !stn.trim().equals(""))
							&& (inputSTNMatchesStnInPool == false)) {
						returnResult = (short) InvEnum.isSTN_RPID_ETN_BTN.INPUT_STN_DOESNT_MATCH_GTWY_DEVICE_STN;

					}

				} catch (SQLException e) {
					e.printStackTrace();

					log.info("DB_FAILURE in isSTN_RPID_ETN_BTN(). ");

					throw e;

				} finally {
					if (pstmt != null) {
						pstmt.close();
					}

					if (rs != null) {
						rs.close();
					}

				}

			}// if end
		}// main if location query size() > 0
		else {
			returnResult = (short) InvEnum.isSTN_RPID_ETN_BTN.INPUT_STN_COULD_NOT_BE_LOCATED_IN_DB;

		}
		return returnResult;
	}

	public boolean validateDupLocNameforEnt(String locName, String enterpriseId)
			throws SQLException {
		log.info("Entering validateDupLocNameforEnt");
		return validateDupLocNameforAPAC(locName, enterpriseId);
	}

	public boolean validateDupLocNameforAPAC(String locName, String enterpriseId)
			throws SQLException {

		log.info("Location.java :: In validateDupLocNameforAPAC()");
		locName = locName.replace("'", "''");

		log.info(" locName " + locName);
		log.info(" enterpriseId " + enterpriseId);

		boolean isExists = true;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		StringBuffer sql = new StringBuffer();

		sql.append(" select count(*) from tbl_location where");
		sql.append(" upper(replace(location_name,'''','')) = upper(replace(?,'''','')) ");
		sql.append(" and enterprise_id=?");

		log.info(" sql " + sql.toString());
		try {
			pstmt = dbCon.prepareStatement(sql.toString());
			pstmt.setString(1, locName);
			pstmt.setString(2, enterpriseId);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				if (rs.getInt(1) >= 1)
					isExists = false;

			}

		} catch (Exception e) {
			e.printStackTrace();
			System.out
					.println("ERROR: Exception caught while trying to get Customer_Name from tbl_customer");
			// log_msg(logging_level,"ERROR: Exception caught while trying to get Customer_Name from tbl_customer");
		} finally {
			if (rs != null) {
				rs.close();
			}

			if (pstmt != null) {
				pstmt.close();
			}
		}
		return isExists;
	}

	public boolean validateDupLocNameForModLoc(String locName,
			String enterpriseId, String locId) throws SQLException {

		log.info("Location.java :: In validateDupLocNameForModLoc()");
		locName = locName.replace("'", "''");

		log.info(" locName " + locName);
		log.info(" enterpriseId " + enterpriseId);
		log.info(" locId " + locId);

		boolean isExists = true;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		StringBuffer sql = new StringBuffer();

		sql.append(" select count(*) from tbl_location where");
		sql.append(" upper(replace(location_name,'''','')) = upper(replace(?,'''','')) ");
		sql.append(" and enterprise_id=?");
		sql.append(" and location_id!=?");

		log.info(" sql " + sql.toString());
		try {

			pstmt = dbCon.prepareStatement(sql.toString());
			pstmt.setString(1, locName);
			pstmt.setString(2, enterpriseId);
			pstmt.setString(3, locId);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				if (rs.getInt(1) >= 1)
					isExists = false;

			}
			log.info("Setting Exists as " + isExists);

		} catch (Exception e) {
			e.printStackTrace();
			System.out
					.println("ERROR: Exception caught while trying to get Customer_Name from tbl_customer");
			// log_msg(logging_level,"ERROR: Exception caught while trying to get Customer_Name from tbl_customer");
		} finally {
			if (rs != null) {
				rs.close();
			}

			if (pstmt != null) {
				pstmt.close();
			}
		}
		return isExists;
	}

	private boolean addDefaultFeaturePackage(int defaultPackageId, int noOfPkgs)
			throws SQLException {
		for (int j = 0; j < noOfPkgs; j++) {
			long pkgId = defaultPackageId;
			TblPackageQuery pkgQry = new TblPackageQuery();
			pkgQry.wherePackageIdEQ(defaultPackageId);
			pkgQry.query(dbCon);
			if (pkgQry.size() > 0) {
				if (serviceTypeOffering == VzbVoipEnum.Platform.IASA) {
					DBTblPackage packageDbBean = new DBTblPackage();
					pkgId = packageDbBean.getPackageIdSeqNextVal(dbCon);
					String pkgNames = "";
					for (int i = 0; i < pkgQry.size(); i++) {
						packageDbBean.copyFromBean(pkgQry.getDbBean(i));
						packageDbBean.setPackageId(pkgId);
						packageDbBean.setModifiedBy("SYSTEM");
						packageDbBean.setLastModifiedDate(new Timestamp(System
								.currentTimeMillis()));
						packageDbBean.setCreationDate(new Timestamp(System
								.currentTimeMillis()));
						if (getEnvOrderId() > 0) {
							packageDbBean.setEnvOrderId(getEnvOrderId());
						} else {
							packageDbBean.setEnvOrderIdNull();
						}
						packageDbBean.insert(dbCon);
						pkgNames = pkgNames + packageDbBean.getPackageName()
								+ " ,";
					}
					setLogTrail("IASA default Feature Package  mapped to Location:"
							+ pkgNames);
					TblPkgFeaturesQuery pkgFeatQry = new TblPkgFeaturesQuery();
					pkgFeatQry.wherePackageIdEQ(defaultPackageId);
					pkgFeatQry.query(dbCon);
					if (pkgFeatQry.size() > 0) {
						for (int i = 0; i < pkgFeatQry.size(); i++) {
							DBTblPkgFeatures pkgFeatDbBean = new DBTblPkgFeatures();
							pkgFeatDbBean.copyFromBean(pkgFeatQry.getDbBean(i));
							long pkgFeatId = pkgFeatDbBean
									.getPkgFeatureIdSeqNextVal(dbCon);
							pkgFeatDbBean.setPackageId(pkgId);
							pkgFeatDbBean.setModifiedBy("ESAP_INV");
							pkgFeatDbBean.setLastModifiedDate(new Timestamp(
									System.currentTimeMillis()));
							pkgFeatDbBean.setCreationDate(new Timestamp(System
									.currentTimeMillis()));
							if (getEnvOrderId() > 0) {
								pkgFeatDbBean.setEnvOrderId(getEnvOrderId());
							} else {
								pkgFeatDbBean.setEnvOrderIdNull();
							}
							log.info("PackageId=" + pkgId
									+ ", pkgFeatId= " + pkgFeatId + "");
							pkgFeatDbBean.insert(dbCon);
						}
					} else {
						setStatus(InvErrorCode.NO_FEATURES_IN_DEFAULT_PKG);
						log.info("NO_FEATURES_IN_DEFAULT_PKG");
						return false;
					}
				}
				if (addLocPackage(pkgId) != true) {
					System.out
							.println("Failed to Add Loc Package. Package Id ["
									+ pkgId + "]");
				}
			} else {
				setStatus(InvErrorCode.NO_DEFAULT_PKG);
				log.info("NO_DEFAULT_PKG");
				return false;
			}
			defaultPackageId = defaultPackageId + 1;
		}
		return true;
	}

	// main class for testing purpose only
	public static void main(String[] args) {
		String proj_etc = "/sbx/esap-may/etc";

		String configParFileName = proj_etc + "/config.par";
		String esapPropFileName = proj_etc + "/esap.properties";
		log.info("configParFileName=" + configParFileName);
		log.info("esapPropFileName=" + esapPropFileName);

		Connection conn;
		try {
			/*esap.server.logical.esaputils.ConfigPar.init("af_manager",
					configParFileName);
			esap.server.apps.afmanager.AFConfig.init(esapPropFileName);
			esap.server.apps.afmanager.AFRunner afRunner = new esap.server.apps.afmanager.AFRunner();*/
			//conn = afRunner.getJDBCConnection();

/*			if (conn != null) {
				log.info("Successfully Connected to ESAP DB");
				conn.setAutoCommit(false);
				// call API
				Location locObj = new Location(conn);
				log.info("----------------------------------");
				if (!locObj.getEtTnFeaturesByIdOrTn("18172394463", true, "U")) {
					// if (!locObj.getEtTnFeaturesByIdOrTn("55", false, "U") ) {
					throw new Exception(
							"Inventory returned false for getEtTnFeaturesByIdOrTn()");
				} else {
					log.info("Inventory returned: "
							+ locObj.getFeaturePkgList().size() + " packages");
					for (FeaturePackageBean bean : locObj.getFeaturePkgList()) {
						for (FeaturesBean feat : bean.getFeatureList()) {
							log.info(feat.getFeaturesDbBean()
									.getDescription());
						}
					}
				}
			} else {
				log.info("No connection - TRY AGAIN");
			}*/
		} catch (Exception e) {
			log.info(e.getMessage());
		}
	}

	//
	public boolean updateTsoVampEntityMigForLoc(String NewLocationId,
			String OldLocationId, String LocationReferenceId) throws Exception {
		boolean new_loc = true;
		PreparedStatement ps = null;
		StringBuffer sql = new StringBuffer();
		sql.append("update tbl_vamp_entity_reference set tso_location_id = "
				+ "'" + NewLocationId + "'" + " where location_id =" + "'"
				+ OldLocationId + "'" + " and vamp_ref_id =" + "'"
				+ LocationReferenceId + "'");
		try {
			ps = dbCon.prepareStatement(sql.toString());
			if (null != ps)
				ps.executeUpdate();
		} catch (Exception e) {
			new_loc = false;
			throw e;
		} finally {
			try {
				if (null != ps)
					ps.close();
			} catch (Exception e) {
				e.printStackTrace();
				new_loc = false;
			}
		}
		return new_loc;
	}

	public boolean updateTblTsoEntityMigForLoc(String NewLocationId,
			String OldLocationId) throws Exception {
		boolean new_tso_loc = true;
		PreparedStatement ps = null;
		StringBuffer sql = new StringBuffer();
		sql.append("update tbl_tso_entity_migration set tso_location_id = "
				+ "'" + NewLocationId + "'" + ", migration_status = " + "'"
				+ VzbVoipEnum.TsoMigrationStatus.SHELL_ORDER + "'"
				+ ", migr_start_date = sysdate where location_id =" + "'"
				+ OldLocationId + "'");
		try {
			ps = dbCon.prepareStatement(sql.toString());
			if (null != ps)
				ps.executeUpdate();
		} catch (Exception e) {
			new_tso_loc = false;
			throw e;
		} finally {
			try {
				if (null != ps)
					ps.close();
			} catch (Exception e) {
				e.printStackTrace();
				new_tso_loc = false;
			}
		}
		return new_tso_loc;
	}

	public boolean unfreezeLocation(String locId) throws Exception {
		boolean updated = true;
		PreparedStatement ps = null;
		StringBuffer sql = new StringBuffer();
		sql.append("update tbl_location set tso_mig_lock = "
				+ VzbVoipEnum.LocationLockStatus.UNFREEZE
				+ " where location_id =" + "'" + locId + "'");
		try {
			ps = dbCon.prepareStatement(sql.toString());
			if (null != ps)
				ps.executeUpdate();
		} catch (Exception e) {
			updated = false;
			throw e;
		} finally {
			try {
				if (null != ps)
					ps.close();
			} catch (Exception e) {
				e.printStackTrace();
				updated = false;
			}
		}
		return updated;
	}
	   //z658915 changes
	   //IR #4507274: PROD: VARRS Billing Issues : starts
	   //part 1
	   public int updateTblLocationWithVarrs(String locationId,String varrs) {
	       PreparedStatement pStmnt = null;
	       int res = -1;
	       try {
	           String updateQuery = "UPDATE TBL_LOCATION SET varrs_flag = ? WHERE hub_location_id = ?";
	           pStmnt = dbCon.prepareStatement(updateQuery);
	           pStmnt.setString(1,varrs);
	           pStmnt.setString(2,locationId);
	           res = pStmnt.executeUpdate();
	       } catch(SQLException e) {
	           e.printStackTrace();
	       } catch(Exception e) {
	           e.printStackTrace();
	       } finally {
	           try {
	               if(pStmnt!=null)
	                   pStmnt.close();
	           } catch(SQLException e) {
	               e.printStackTrace();
	           }
	       }
	       return res;
	   }
	   //z658915 changes
	   //IR #4507274: PROD: VARRS Billing Issues : ends
	   //part 1

	// added by z658915 for calnet changes starts
	public int updateCalnetSubContractId(short calnetSubContractId) {
		int locationRecCountUpdated = 0;

		DBTblLocation tblLocation = new DBTblLocation();
		tblLocation.setCalnetSubContractId((short) 3);
		tblLocation.whereLocationIdEQ(locationId);

		try {
			locationRecCountUpdated = tblLocation.updateSpByWhere(dbCon);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return locationRecCountUpdated;
	}
	// added by z658915 for calnet changes ends

	// added by z658915 for calnet changes starts
	public int updateCalnetSubContractIdForEnterpriseWithLocationId(short calnetSubContractId) {
		PreparedStatement pStmnt = null;
		ResultSet rSet = null;
		int entRecCountUpdated = 0;
		TblLocationQuery locQry = new TblLocationQuery();
		locQry.whereLocationIdEQ(getLocationId());
		try {
			locQry.query(dbCon);
			if(locQry.size() > 0) {
				if(locQry.getDbBean(0).getEnterpriseId() == null) {
					throw new Exception("Enterprise ID Not Found");
				}
				String enterpriseId = locQry.getDbBean(0).getEnterpriseId();
				String sql = null;

				sql = "SELECT COUNT(*) FROM TBL_LOCATION WHERE ENTERPRISE_ID = ? AND (CALNET_SUB_CONTRACT_ID is null or  CALNET_SUB_CONTRACT_ID = 2)";
				pStmnt = dbCon.prepareStatement(sql);
				pStmnt.setString(1, enterpriseId);
				rSet = pStmnt.executeQuery();
				while(rSet.next()){
					if(rSet.getInt(1) == 0) {
						Enterprise enterprise = new Enterprise(dbCon);
						enterprise.setCustomerId(enterpriseId);
						entRecCountUpdated = enterprise.updateCalnetSubContractId((short)3);
						enterprise.updateContractInd("C");
					}
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if(pStmnt != null)
					pStmnt.close();
				if(rSet != null)
					rSet.close();
			} catch(SQLException e) {
				e.printStackTrace();
			}
		}
		return entRecCountUpdated;
	}
	// added by z658915 for calnet changes ends
	
	public int getCountOfCalnet2Loc(String customerId) {
		PreparedStatement pStmnt = null;
		ResultSet rSet = null;
		int calnet2Cnt = 0;
		try {
			String sql = null;
			sql = "SELECT COUNT(*) FROM TBL_LOCATION WHERE ENTERPRISE_ID = ? AND (CALNET_SUB_CONTRACT_ID is null or  CALNET_SUB_CONTRACT_ID = 2)";
			pStmnt = dbCon.prepareStatement(sql);
			pStmnt.setString(1, customerId);
			rSet = pStmnt.executeQuery();
			while(rSet.next()){
				calnet2Cnt =rSet.getInt(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if(pStmnt != null)
					pStmnt.close();
				if(rSet != null)
					rSet.close();
			} catch(SQLException e) {
				e.printStackTrace();
			}
		}
		return calnet2Cnt;
	}
	
	public short getCalnetIndFromEnterprise(String custId) {
		short calnetInd = 0;
		try {
			TblCustomerQuery custQry = new TblCustomerQuery();
			custQry.whereCustomerIdEQ(custId);
			custQry.query(dbCon);
			if (custQry.size() > 0) {
				calnetInd = custQry.getDbBean(0).getCalnetSubContractId();
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return calnetInd;
	}
	
	public List<String> getAllExtnOnlySubscribers(String locId) throws Exception{
		PreparedStatement pStmnt = null;
		ResultSet rs = null;
		List<String> extnOnlySub = new ArrayList<String>();
		log.info("Entering Location::getAllExtnOnlySubscribers()");
		try {
			String sql = "SELECT distinct sub.sub_id FROM tbl_subscriber sub, TBL_SUBSCRIBER_TN tn " +
					"WHERE  0=(select count(tn.sub_id) from tbl_subscriber_tn tn " +
					"where tn.sub_id=sub.sub_id AND tn.nat_user_id=1) and sub.location_id = ?";
			pStmnt = dbCon.prepareStatement(sql);
			pStmnt.setString(1, locId);
			rs = pStmnt.executeQuery();
			String subId = null;
			while (rs.next()) {
				subId = rs.getString(1);
					extnOnlySub.add(subId);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw e;
		}finally{
			if(rs != null){
				rs.close();
			}
			if(pStmnt != null){
				pStmnt.close();
			}
		}
		return extnOnlySub;
	}
	
	public List<String> getAllTnSubscribers(String locId)  throws Exception{
		PreparedStatement pStmnt = null;
		ResultSet rs = null;
		List<String> tnSub = new ArrayList<String>();
		log.info("Entering Location::getAllTnSubscribers()");
		try {
			String sql = "SELECT sub.SUB_ID FROM TBL_SUBSCRIBER sub, TBL_SUBSCRIBER_TN stn WHERE " +
					"sub.sub_id = stn.sub_id and stn.nat_user_id = 1 and sub.LOCATION_ID = ?";
			pStmnt = dbCon.prepareStatement(sql);
			pStmnt.setString(1, locId);
			rs = pStmnt.executeQuery();
			while (rs.next()) {
				tnSub.add(rs.getString(1));
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw e;
		}finally{
			if(rs != null){
				rs.close();
			}
			if(pStmnt != null){
				pStmnt.close();
			}
		}
		return tnSub;
	}
	
	public List<String> getAllAltTnSubscribers(String locId)  throws Exception{
		PreparedStatement pStmnt = null;
		ResultSet rs = null;
		List<String> tnSub = new ArrayList<String>();
		log.info("Entering Location::getAllAltTnSubscribers()");
		try {
			String sql = "SELECT distinct sub.SUB_ID FROM TBL_SUBSCRIBER sub, TBL_SUBSCRIBER_TN stn WHERE " +
					"sub.sub_id = stn.sub_id and stn.nat_user_id = 5 and stn.USER_ID != '0' and sub.LOCATION_ID = ?";
			pStmnt = dbCon.prepareStatement(sql);
			pStmnt.setString(1, locId);
			rs = pStmnt.executeQuery();
			while (rs.next()) {
				tnSub.add(rs.getString(1));
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw e;
		}finally{
			if(rs != null){
				rs.close();
			}
			if(pStmnt != null){
				pStmnt.close();
			}
		}
		return tnSub;
	}
	
	public short getCalnetIndFromLocation(String locationId) {
		short calnetInd = 0;
		try {
			TblLocationQuery locQry = new TblLocationQuery();
			locQry.whereLocationIdEQ(locationId);
			locQry.query(dbCon);
			if (locQry.size() > 0) {
				calnetInd = locQry.getDbBean(0).getCalnetSubContractId();
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return calnetInd;
	}
	
	public boolean getPbxUnreachebleAssigned(long tnPoolId){
		boolean featureAssigned = false;
		PreparedStatement pStmnt = null;
		ResultSet rs = null;
		int cnt = 0;
		try{
			String sql = "select count(*) from tbl_group_features gf, tbl_group_tn gtn, tbl_public_tn_pool p," +
					" tbl_vzb_features vf where p.tn_pool_id = gtn.tn_pool_id and gtn.group_id = gf.group_id " +
					"and vf.feature_id = gf.feature_id and vf.name = 'Trunk Group Unreachable' and gtn.tn_pool_id = ?";
			pStmnt = dbCon.prepareStatement(sql);
			pStmnt.setLong(1, tnPoolId);
			rs = pStmnt.executeQuery();
			if (rs.next()) {
				cnt = rs.getInt(1);
			}
			featureAssigned = (cnt == 0)?false:true;
		}catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        finally{
                 try{
                      if(rs!=null)
                         rs.close();
                     if(pStmnt!=null)
                        pStmnt.close();
                        } 
                    catch(SQLException e){ 
                     e.printStackTrace();
                    }
                 }
		return featureAssigned;
	}
	
	public String getIcpSubId(long tnPoolId){
		PreparedStatement pStmnt = null;
		ResultSet rs = null;
		String icpSubId = null;
		try{
			String sql = "select distinct(gtn.icp_sub_id) from tbl_group_tn gtn, " +
					"tbl_public_tn_pool p where p.tn_pool_id = gtn.tn_pool_id " +
					"and gtn.tn_pool_id = ?";
			pStmnt = dbCon.prepareStatement(sql);
			pStmnt.setLong(1, tnPoolId);
			rs = pStmnt.executeQuery();
			while (rs.next()) {
				icpSubId = rs.getString(1);
			}
		}catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	finally{	
              try{
                 if(rs!=null)
                   rs.close();
                if(pStmnt!=null)
                  pStmnt.close();
                 }
               catch(SQLException e){
                 e.printStackTrace();
                 }
            }

		return icpSubId;
	}
	
	public boolean getAllTrunkingTnsForLocation(String locId) {
		PreparedStatement pStmnt = null;
		ResultSet rs = null;
		long tnPoolId = 0;
		try {
			ArrayList<PublicTnPoolBean> ptnPoolList = new ArrayList<PublicTnPoolBean>();
			if (locId == null || "".equalsIgnoreCase(locId)) {
				setStatus(InvErrorCode.INVALID_LOC_ID);
				System.out
				.println("FAILURE in getAllTrunkingTnsForLocation Location. locationId in Location is not valid");
				return false;
			}

			String sql = "select gtn.tn_pool_id from  tbl_group_tn gtn, " +
					"tbl_public_tn_pool p where p.tn_pool_id = gtn.tn_pool_id and "+
					" p.location_id = ?";
			pStmnt = dbCon.prepareStatement(sql);
			pStmnt.setString(1, locId);
			rs = pStmnt.executeQuery();
			while (rs.next()) {
				tnPoolId = rs.getLong(1);
				TblPublicTnPoolQuery ptnPoolQry = new TblPublicTnPoolQuery();
				String whereClause = " where tn_pool_id = \'" + tnPoolId + "\'";
				ptnPoolQry.queryByWhere(dbCon, whereClause);
				if (ptnPoolQry.size() > 0) {
					TblPublicTnPoolDbBean tnDbBean = ptnPoolQry.getDbBean(0);
					PublicTnPoolBean ptnPool = new PublicTnPoolBean();
					ptnPool.setTnPoolId(tnDbBean.getTnPoolId());
					ptnPool.setLocationId(tnDbBean.getLocationId());
					ptnPool.setDepartmentId(tnDbBean.getDepartmentId());
					ptnPool.setTn(tnDbBean.getTn());
					ptnPool.setTnStatus(tnDbBean.getTnStatus());
					ptnPool.setPortedStatus(tnDbBean.getPortedStatus());
					ptnPool.setNpaSplitStatus(tnDbBean.getNpaSplitStatus());
					ptnPool.setCreatedBy(tnDbBean.getCreatedBy());
					ptnPool.setModifiedBy(tnDbBean.getModifiedBy());
					ptnPool.setEnvOrderId(tnDbBean.getEnvOrderId());
					ptnPoolList.add(ptnPool);
				} 
			}
			log.info("ptnPoolList size :: " +ptnPoolList.size());
			setPublicTnPool(ptnPoolList);
		} catch (SQLException e) {
			e.printStackTrace();
			setStatus(InvErrorCode.DB_EXCEPTION);
			return false;
		}
         finally{
                  try{
                       if(rs!=null)
                         rs.close();
                       if(pStmnt!=null)
                             pStmnt.close();
                      }
                   catch(SQLException e)
                   {
                      e.printStackTrace();
                    }
                }
		setStatus(InvErrorCode.SUCCESS);
		log.info("Successfully retrieved PublicTnPool from the DB");
		return true;
	}
	public ArrayList<String> getETUserId (String locId) throws Exception {
		log.info("In getETUserId " + locId);
		ArrayList<String> etTnList = new ArrayList<String> ();
		PreparedStatement prepStmt = null;
		ResultSet res = null;
		String EtTn = null;
		StringBuffer etQry = new StringBuffer ();
		etQry.append("SELECT PTN.TN FROM TBL_PUBLIC_TN_POOL PTN, TBL_TSO_ET_TN ET WHERE PTN.TN_POOL_ID = ET.TN_POOL_ID and PTN.LOCATION_ID = ?");
		try
		{
			prepStmt = dbCon.prepareStatement(etQry.toString());
			prepStmt.setString(1, locId);
			res = prepStmt.executeQuery();
			while (res.next())
			{
				EtTn = res.getString(1);
				log.info(" EtTn " + EtTn);
				etTnList.add(EtTn);
			}
			log.info(" etTnList " +etTnList.size());
		}catch(Exception e){
			e.printStackTrace();
			throw e;
		}finally {
			if(prepStmt!= null)
			prepStmt.close();
			if(res != null)
			res.close();
		}
		return etTnList;
		
	}
	
/*	public List<SubscriberVO> getExtnVMSubsWithoutBilling(String locId) throws Exception{
		 StringBuffer deviceTypeSql = new StringBuffer();
		 ResultSet rs = null;
		 PreparedStatement pStmt = null;
		 List<SubscriberVO> addSubList = new ArrayList<SubscriberVO>();
		 try{
			 deviceTypeSql.append("SELECT distinct sub.sub_id,sub.extension,sub.VM_BOX_NUM,sub.VM_MAXSIZE FROM tbl_subscriber sub, TBL_SUBSCRIBER_TN tn " +
					 "WHERE  0=(select count(tn.sub_id) from tbl_subscriber_tn tn " +
					 "where tn.sub_id=sub.sub_id AND tn.nat_user_id=1) " +
					 "and sub.location_id = ? and (sub.billing_type = 0 or sub.billing_type is null) and sub.VM_BOX_NUM is not null and sub.VM_MAXSIZE >0");
			 pStmt = dbCon.prepareStatement(deviceTypeSql.toString());
			 pStmt.setString(1, locId);
			 if (null != pStmt)
				 rs = pStmt.executeQuery();
			 while(rs.next()){
				 SubscriberVO subObj = new SubscriberVO();
				 subObj.setSubId(rs.getString(1));
				 subObj.setExtension(rs.getString(2));
				 subObj.setVmBoxNum(rs.getString(3));
				 subObj.setVmMaxSize(rs.getLong(4));
				 addSubList.add(subObj);
			 }
			 log.info("getExtnVMSubsWithBilling :: "+addSubList.size());
		 }catch(Exception e){
			 e.printStackTrace();
		 }finally{
			 if(rs != null){
				 rs.close();
			 }
			 if(pStmt != null){
				 pStmt.close();
			 }
		 }
		 return addSubList;
	 }*/
	
	public int updateTblLocationwithCktId (String locationId, String cktId) throws Exception {
		log.info("In updateTblLocationwithCktId " + locationId + " cktId " + cktId);
		int val = -1;
		PreparedStatement pst = null;
		String locUpdStmt = "UPDATE TBL_LOCATION SET CIRCUIT_ID = ? WHERE LOCATION_ID = ?";
		try
		{
			pst = dbCon.prepareStatement(locUpdStmt);
			pst.setString(1, cktId);
			pst.setString(2, locationId);	
			val = pst.executeUpdate();
			
		}catch (Exception e)
		{
			e.printStackTrace();
			throw e;
		}finally {
			if (pst != null)
				pst.close();
		}
		return val;
	}


	public boolean deleteETTnFeatForLocation() throws SQLException, Exception {
		PreparedStatement pstmt = null;
		
		//String query = "delete from tbl_tso_et_tn_features where et_tn_id in (select et_tn_id from tbl_tso_et_Tn where tn_pool_id in (select tn_pool_id from tbl_public_tn_pool where location_id=?))";

		//String query = "delete from tbl_tso_et_tn_features where et_tn_id in (select et_tn_id from tbl_tso_et_Tn et ,tbl_public_tn_pool tn  where et.tn_pool_id=tn.tn_pool_id and tn.location_id=?)";
		String query = "delete from tbl_tso_et_tn_features where et_tn_id in (select et_tn_id from tbl_tso_et_Tn et ,tbl_public_tn_pool tn  where et.tn_pool_id=tn.tn_pool_id and tn.location_id=?)";
		try {
			String locationId = getLocationId();
			pstmt = dbCon.prepareStatement(query);
			pstmt.setString(1, locationId);
			pstmt.executeUpdate();
		}/*
		 * catch(Exception e){ e.printStackTrace();
		 * log.info("Exception in deleteETTnForLocation method==>"
		 * +e.getMessage()); return false; }
		 */finally { // #IR1440263 closing statement and results set
			if (pstmt != null) {
				pstmt.close();
			}
		}
		setLogTrail("Deleted details related to location: " + getLocationId()
				+ " from tbl_tso_et_tn_features");
		
		return true;
	}

} // EOF

