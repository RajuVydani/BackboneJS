package com.vz.fxo.inventory.enterprise.helper;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.vz.esap.api.model.ordering.EntityData;
import com.vz.esap.api.model.ordering.TableOrderDetailsParam;
import com.vz.fxo.inventory.enterprise.support.DigitStringBean;
import com.vz.fxo.inventory.enterprise.support.Enterprise;

import esap.db.DBTblAuthServices;
import esap.db.DBTblDigitStrings;
import esap.db.DBTblPkgFeatures;
import esap.db.DBTblSubFeature;
import esap.db.TblAuthServicesQuery;
import esap.db.TblDigitStringsQuery;
import esap.db.TblEnterpriseDbBean;
import esap.db.TblVzbFeaturesDbBean;
import esap.db.TblVzbFeaturesQuery;

import static com.vz.fxo.inventory.enterprise.helper.ActionFunctionHelper.*;

public class EnterpriseActionFunctionHelper {

	private static Logger log = LoggerFactory.getLogger(EnterpriseActionFunctionHelper.class.toString());
	
	
	public static boolean handleEntDigitStringActivate(EntityData entityData,
			List<DigitStringBean> digitStringAddList, String enterpriseId,Connection connection)
	throws Exception {
		if (digitStringAddList != null)
			for (int i = 0; i < digitStringAddList.size(); i++) {
				DigitStringBean digitStringBean = digitStringAddList.get(i);
				TblDigitStringsQuery digitStringsQry = new TblDigitStringsQuery();
				digitStringsQry.whereDigitStringEQ(digitStringBean
						.getDigitString());
				digitStringsQry.whereEnterpriseIdEQ(enterpriseId);
				digitStringsQry.query(connection);
				if (digitStringsQry.size() > 0) {
					log.info("Digit String entry already there in tbl_digit_Strings:"
							+ digitStringBean.getDigitString()
							+ "enterpriseId:" + enterpriseId);
					DBTblDigitStrings digitStringDbBean = new DBTblDigitStrings();
					digitStringDbBean.whereDigitStringIdEQ(digitStringBean
							.getDigitStringId());
					digitStringDbBean.setActiveInd(1);
					digitStringDbBean.updateSpByWhere(connection);
				} else {
					//TODO Make a method in base class for this
					DBTblDigitStrings digitStringDbBean = new DBTblDigitStrings();
					digitStringDbBean.setDigitStringId(digitStringBean
							.getDigitStringId());
					digitStringDbBean.setEnterpriseId(enterpriseId);
					digitStringDbBean.setDigitString(digitStringBean
							.getDigitString());
					digitStringDbBean.setActiveInd(1);
					/*if (!(orderParam.getByNameSearch("OriginatingSystem") == null)) {
						digitStringDbBean.setCreatedBy(orderParam
								.getByNameSearch("OriginatingSystem")
								.getParamValue());
						digitStringDbBean.setModifiedBy(orderParam
								.getByNameSearch("OriginatingSystem")
								.getParamValue());
					} else {
						digitStringDbBean.setModifiedBy("SYSTEM");
						digitStringDbBean.setCreatedBy("SYSTEM");
					}*/
					
					TableOrderDetailsParam param = null;
					if ((param = getTableOrderDetaisParam(entityData, "OriginatingSystem")) != null) {
						digitStringDbBean.setCreatedBy(param.getParamValue());
						digitStringDbBean.setModifiedBy(param.getParamValue());
					} else {
						digitStringDbBean.setModifiedBy("SYSTEM");
						digitStringDbBean.setCreatedBy("SYSTEM");
					}
					
					digitStringDbBean.setLastModifiedDate(new Timestamp(System
							.currentTimeMillis()));
					digitStringDbBean.setCreationDate(new Timestamp(System
							.currentTimeMillis()));

					digitStringDbBean.insert(connection);
				}

			}
		return true;
	}
	
	
	
	public static boolean modifyAuthServicesForEnterprise(Enterprise enterprise, Connection connection,int orderId )
			throws Exception {
				boolean retValue = true;
				PreparedStatement pstmt = null;
				ResultSet rs = null;
				StringBuffer sql = new StringBuffer();
				TblAuthServicesQuery authQry;
				DBTblAuthServices authServicesDbBean = new DBTblAuthServices();

				sql.append(" select dp.param_name, dp.param_value feature_name, ");
				sql
				.append(" DECODE(dp1.param_value, 'false', 'N', 'true', 'Y', 'N', 'N', 'Y', 'Y') is_allow,  ");
				sql.append(" f.feature_id, a.is_authorized, d.action authservice_action from tbl_order_details d, ");
				sql
				.append(" tbl_order_details dp, tbl_order_details dp1, tbl_vzb_features f, tbl_auth_services a ");
				sql.append(" where d.order_id = ? and d.param_name = 'AuthService' ");
				sql.append(" and dp.parent_id = d.order_detail_id ");
				sql.append(" and dp.param_name = 'Name' ");
				sql.append(" and f.name = dp.param_value ");
				sql.append(" and dp1.parent_id = d.order_detail_id ");
				sql.append(" and dp1.param_name = 'Authorised' ");
				sql.append(" and a.feature_id = f.feature_id ");
				sql.append(" and a.auth_service_id = ? ");

				try {
					TblEnterpriseDbBean enterpriseDbBean = getEnterpriseForEnterpriseId(connection,enterprise.getEnterpriseId());
					pstmt = connection.prepareStatement(sql.toString());
					pstmt.setLong(1, orderId);
					pstmt.setLong(2, enterpriseDbBean.getAuthServicesId());
					rs = pstmt.executeQuery();
					while (rs.next()) {
						String featureName = rs.getString(2);
						String isAllow = rs.getString(3);


						// if AuthService (parent node) has action = o, we need to set isAllow=N
						// When AuthService just vanished from XML, OM will persist it as follows:
						// AuthService: null(o)
						//    Name: Trunk Group Unreachable (o)
						//	  Authorised: Y(o)
						String authServiceAction = rs.getString(6);
						log.info( "AuthService has action = " + authServiceAction + " and isAllow = " + isAllow + 
								" with featureName="+ featureName + ".");

						if(isAllow.equals("Y") && authServiceAction.equals("o")) {
							log.info( "AuthService has action = (o)," + " with featureName=" + featureName + " setting isAllow=N.");
							isAllow = "N";
						}	
						Long featureId = rs.getLong(4);
						String isAuthorized = rs.getString(5);

						if (!isAllow.equals(isAuthorized)) {
							authQry = new TblAuthServicesQuery();
							authQry.whereAuthServiceIdEQ((int) enterpriseDbBean
									.getAuthServicesId());
							authQry.whereFeatureIdEQ(featureId);
							authQry.query(connection);
							if (authQry.size() > 0) {
								authServicesDbBean.copyFromBean(authQry.getDbBean(0));
								authServicesDbBean.setIsAuthorized(isAllow);
								authServicesDbBean.setModifiedBy(enterprise
										.getModifiedBy());
								authServicesDbBean.setLastModifiedDate(enterprise
										.getLastModifiedDate());
								authServicesDbBean.setEnvOrderId(enterprise
										.getEnvOrderId());
								authServicesDbBean.update(connection);
								log.info( "Feature <" + featureName
										+ "> updated from <" + isAuthorized + "> to <"
										+ isAllow + ">");
								//TODO Need to Unselect all the custom feature pkgs
								if(isAllow.equals("N"))
								{
									PreparedStatement stmt = null;
									ResultSet rs1 = null;
									StringBuffer sql1 = new StringBuffer();
									try{
										sql1.append("select lp.package_id from  tbl_location l, tbl_loc_package lp, tbl_pkg_features pf, tbl_package p");
										sql1.append(" where l.enterprise_id = ? and l.location_id = lp.location_id ");
										sql1.append(" and lp.package_id = pf.package_id and p.package_id = pf.package_id and template_ind<>1 ");
										sql1.append(" and pf.feature_id = ? and pf.is_selected = 'Y'");

										stmt = connection.prepareStatement(sql1.toString());
										stmt.setString(1, enterprise.getEnterpriseId());
										stmt.setLong(2, featureId);
										rs1 = stmt.executeQuery();
										while (rs1.next()) {
											long packageId = rs1.getLong(1);
											DBTblPkgFeatures pkgFeatDbBean =  new DBTblPkgFeatures();
											pkgFeatDbBean.wherePackageIdEQ(packageId);
											pkgFeatDbBean.whereFeatureIdEQ(Long.toString(featureId));
											pkgFeatDbBean.setIsSelected("N");
											pkgFeatDbBean.updateSpByWhere(connection);
											log.info( "Feature <" + featureName + "> PackageId:"+packageId+" updated to is_selected N"); 
										}
									}finally{
										//IR #1638603  
										if (stmt != null){
											stmt.close();
										}
										if (rs1 != null){
											rs1.close();
										}
									}
									

									long icpConfFeatId = getVzbFeatureId("ICP Conferencing",connection);

									if(icpConfFeatId > 0 && featureId == icpConfFeatId)
									{

										PreparedStatement stmt2 = null;
										ResultSet rs2 = null;
										try{
											StringBuffer sql2 = new StringBuffer();
											sql2.append("select sf.sub_id, sf.sub_feature_id from  tbl_location l, tbl_subscriber s,tbl_sub_feature sf");
											sql2.append(" where l.enterprise_id = ? and l.location_id = s.location_id ");
											sql2.append("  and sf.sub_id = s.sub_id and sf.feature_id = ? ");
											log.info("Icp conferencing is being unauthorized, cascading it to subscriber:"+sql2.toString());

											stmt2 = connection.prepareStatement(sql2.toString());
											stmt2.setString(1, enterprise.getEnterpriseId());
											stmt2.setLong(2, featureId);
											rs2 = stmt2.executeQuery();
											while (rs2.next()) {
												String subscId = rs2.getString(1);
												int subFeatId = rs2.getInt(2);
												log.info("SubFeatureId being deleted:"+subFeatId+"SubId:"+subscId+"FeatureId:"+featureId);
												DBTblSubFeature subFeatDbBean = new DBTblSubFeature();
												subFeatDbBean.whereSubFeatureIdEQ(subFeatId);
												subFeatDbBean.deleteByWhere(connection);

											}
										}finally{
											//IR #1638603  
											if (stmt2 != null){
												stmt2.close();
											}
											if (rs2 != null){
												rs2.close();
											}
										}
										
									}
								}//isAllow.equals("N")
							}
						}
					}

				} catch (Exception e) {
					e.printStackTrace();
					retValue = false;
				} finally {
		            try {
		                if (rs != null) {
		                    rs.close();
		                }
		                if (pstmt != null) {
		                    pstmt.close();
		                }
		            } catch (SQLException e) {
		                throw new Exception(
		                "Exception caught while closing result set/prepared statement");
		            }
				}
				return retValue;

			}

	public static long getVzbFeatureId(String featureName,Connection connection) {
		long featureId = 0;
		log.info( "getVzbFeatureId for  Feature Name <" + featureName + ">");

		try {

			TblVzbFeaturesQuery vzbFeats = new TblVzbFeaturesQuery();
			vzbFeats.whereNameLike(featureName);
			vzbFeats.query(connection);
			ArrayList<?> resultSet = vzbFeats.getResultArrayList();
			log.info( "vzbfeatures for featurename:<" + featureName
					+ "> size <" + vzbFeats.size());

			if (vzbFeats.size() > 0) {
				TblVzbFeaturesDbBean vzbFeatDbBean = (TblVzbFeaturesDbBean) resultSet
				.get(0);
				featureId = vzbFeatDbBean.getFeatureId();
				log.info( "FeatureID <" + featureId + "> in tbl_vzb_features");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return featureId;
	}
}
