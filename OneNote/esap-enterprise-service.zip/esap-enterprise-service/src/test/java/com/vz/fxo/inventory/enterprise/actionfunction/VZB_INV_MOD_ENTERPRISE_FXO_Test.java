package com.vz.fxo.inventory.enterprise.actionfunction;
import static org.junit.Assert.assertEquals;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.io.File;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.jdbc.support.SQLErrorCodes;

import com.vz.esap.api.connector.service.impl.ConfigDomainDataServiceImpl;
import com.vz.esap.api.connector.service.impl.InventoryDomainDataServiceImpl;
import com.vz.esap.api.connector.service.impl.OrderDomainDataServiceImpl;
import com.vz.esap.api.connector.service.impl.OrderLogServiceImpl;
import com.vz.esap.api.connector.util.DomainInterfaceUtil;
import com.vz.esap.api.model.ESAPEntityEnum;
import com.vz.esap.api.model.InventoryServiceRequest;
import com.vz.esap.api.model.OrderDomainServiceRequest;
import com.vz.esap.api.model.dto.OrderDomainServiceDTO;
import com.vz.esap.api.model.ordering.EntityBatch;
import com.vz.esap.api.model.ordering.EntityData;
import com.vz.esap.api.model.ordering.TableOrderDetailsParam;
import com.vz.fxo.inventory.enterprise.helper.ActionFunctionHelper;
import com.vz.fxo.inventory.enterprise.helper.EnterpriseActionFunctionHelper;
import com.vz.fxo.inventory.enterprise.helper.EnterpriseHelper;
import com.vz.fxo.inventory.enterprise.helper.FxoInventoryErrorEntityMgmtHelper;
import com.vz.fxo.inventory.enterprise.helper.FxoServiceHelper;
import com.vz.fxo.inventory.enterprise.helper.TNActionFunction;
import com.vz.fxo.inventory.enterprise.support.CallingPlan;
import com.vz.fxo.inventory.enterprise.support.DigitString;
import com.vz.fxo.inventory.enterprise.support.DigitStringBean;
import com.vz.fxo.inventory.enterprise.support.Enterprise;
import com.vz.fxo.inventory.enterprise.support.TblEntBillFeaturesBean;

import EsapEnumPkg.VzbVoipEnum;
import esap.db.TblDepartmentDbBean;
import esap.db.TblDepartmentQuery;
import esap.db.TblEnvOrderDbBean;
import esap.db.TblEnvOrderQuery;

@RunWith(PowerMockRunner.class)
@PrepareForTest({EnterpriseActionFunctionHelper.class,TNActionFunction.class, ActionFunctionHelper.class})
public class VZB_INV_MOD_ENTERPRISE_FXO_Test {
	
	InventoryServiceRequest bsServiceRequest;
	Connection connection;
	ConfigDomainDataServiceImpl configDomainDataService;
	OrderDomainDataServiceImpl orderDomainDataService;
	InventoryDomainDataServiceImpl inventoryDomainDataService;
	FxoInventoryErrorEntityMgmtHelper bsErrorEntityMgmtHelper;
	OrderLogServiceImpl orderLogService;
	
	Map<String, EntityData> entityMap;
	
	@Mock
	PreparedStatement pstmt;
	
	@Mock
	Statement selStmt;
	
	@Mock
	ResultSet rs;
	
	@Mock
	Enterprise enterprise;
	
	@Mock
	ActionFunctionHelper actionFunctionHelper;
	
	@Mock 
	Exception exception;
	
	@Mock
	SQLException sqlException;
	
	SQLErrorCodes error;
	
	Timestamp ts;
	@Mock
	TblEnvOrderQuery tblEnvOrderQuery;
	
	@Mock
	TblEntBillFeaturesBean  tblEntBillFeaturesBean; 
	@Mock
	TblEnvOrderDbBean  tblEnvOrderDbBean;
	
	@Mock
	EnterpriseHelper enterpriseHelper;
	
	@Mock
	TblDepartmentQuery departmentQry;
	
	@Mock
	TblDepartmentDbBean tblDepartmentDbBean;
	Timestamp timestamp;
	@Spy
	@InjectMocks
	VZB_INV_MOD_ENTERPRISE_FXO obj = new VZB_INV_MOD_ENTERPRISE_FXO();

	
	
@Before
public void setUp() throws Exception {
	bsServiceRequest = new InventoryServiceRequest();
	bsServiceRequest.setEntityType(ESAPEntityEnum.ENTERPRISE.toString());
	connection = mock(Connection.class);
	configDomainDataService = mock(ConfigDomainDataServiceImpl.class);
	orderDomainDataService = mock(OrderDomainDataServiceImpl.class);
	inventoryDomainDataService = mock(InventoryDomainDataServiceImpl.class);
	bsErrorEntityMgmtHelper = mock(FxoInventoryErrorEntityMgmtHelper.class);
	orderLogService = mock(OrderLogServiceImpl.class);

	obj.setConnection(connection);
	obj.setConfigDomainDataService(configDomainDataService);
	obj.setOrderDomainDataService(orderDomainDataService);
	obj.setInventoryDomainDataService(inventoryDomainDataService);
	obj.setBsErrorEntityMgmtHelper(bsErrorEntityMgmtHelper);
	obj.setOrderLogService(orderLogService);
	obj.setOrderNumber(5859008l);
	obj.setEnvOrderId("123");
	FxoServiceHelper.setRequestAttributes(bsServiceRequest, obj);
	
}

//Added for deptQry  block condition
@Test
public void testdeptQry() throws Exception {
	File fileObj = new File(
			"src/test/resources/com/vz/fxo/enterprise/actionfunction/VZB_INV_MOD_ENTERPRISE/test_VZB_INV_MOD_ENT_EmeaApacBestPool_else_block.json");
	OrderDomainServiceDTO dto = DomainInterfaceUtil.prepareResponseFromInputJsonFile(fileObj);
	when(enterpriseHelper.getEnterprise(connection)).thenReturn(enterprise);
	when(orderDomainDataService.getOrderDomainData(any(OrderDomainServiceRequest.class))).thenReturn(dto);
	when(enterpriseHelper.getEnterprise(connection)).thenReturn(enterprise);
	when(enterprise.getRegionId()).thenReturn(Long.valueOf(VzbVoipEnum.RegionType.EMEA));
	when(enterprise.addToDB()).thenReturn(Boolean.TRUE);
	when(connection.createStatement()).thenReturn(selStmt);
	when(selStmt.executeUpdate(any(String.class))).thenReturn(1);
	when(selStmt.executeQuery(any(String.class))).thenReturn(rs); 
	when(connection.prepareStatement(any(String.class))).thenReturn(pstmt);
	when(pstmt.executeQuery()).thenReturn(rs);
	PowerMockito.whenNew(TblEnvOrderQuery.class).withNoArguments().thenReturn(tblEnvOrderQuery);
	when(enterprise.updateTsoVampEntityMigForEnt(any(String.class), any(String.class), any(String.class))).thenReturn(Boolean.TRUE);
	when(enterprise.updateTblTsoEntityMigForEnt(any(String.class), any(String.class))).thenReturn(Boolean.TRUE);
	 when(tblEnvOrderQuery.size()).thenReturn(1);
		
	 obj.setEnvOrderId("1396815");
	int result = obj.go();
	assertEquals(result,2);
}


//Added for EmeaApacBestPool else block condition
@Test
public void testEmeaApacBestPool_else() throws Exception {
	File fileObj = new File(
			"src/test/resources/com/vz/fxo/enterprise/actionfunction/VZB_INV_MOD_ENTERPRISE/test_VZB_INV_MOD_ENT_EmeaApacBestPool_else_block.json");
	OrderDomainServiceDTO dto = DomainInterfaceUtil.prepareResponseFromInputJsonFile(fileObj);
	when(enterpriseHelper.getEnterprise(connection)).thenReturn(enterprise);
	when(orderDomainDataService.getOrderDomainData(any(OrderDomainServiceRequest.class))).thenReturn(dto);
	when(enterpriseHelper.getEnterprise(connection)).thenReturn(enterprise);
	when(enterprise.getRegionId()).thenReturn(Long.valueOf(VzbVoipEnum.RegionType.EMEA));
	when(enterprise.addToDB()).thenReturn(Boolean.TRUE);
	when(connection.createStatement()).thenReturn(selStmt);
	when(selStmt.executeUpdate(any(String.class))).thenReturn(1);
	when(selStmt.executeQuery(any(String.class))).thenReturn(rs); 
	when(connection.prepareStatement(any(String.class))).thenReturn(pstmt);
	when(pstmt.executeQuery()).thenReturn(rs);
	PowerMockito.whenNew(TblEnvOrderQuery.class).withNoArguments().thenReturn(tblEnvOrderQuery);
	when(enterprise.updateTsoVampEntityMigForEnt(any(String.class), any(String.class), any(String.class))).thenReturn(Boolean.TRUE);
	when(enterprise.updateTblTsoEntityMigForEnt(any(String.class), any(String.class))).thenReturn(Boolean.TRUE);
	 when(tblEnvOrderQuery.size()).thenReturn(1);
		
	 obj.setEnvOrderId("1396815");
	int result = obj.go();
	assertEquals(result,2);
}

	@Test
	public void testGoSuccess() throws Exception {
		File fileObj = new File(
				"src/test/resources/com/vz/fxo/enterprise/actionfunction/VZB_INV_MOD_ENTERPRISE/test_VZB_INV_MOD_ENT.json");
		OrderDomainServiceDTO dto = DomainInterfaceUtil.prepareResponseFromInputJsonFile(fileObj);
		when(enterpriseHelper.getEnterprise(connection)).thenReturn(enterprise);
		when(orderDomainDataService.getOrderDomainData(any(OrderDomainServiceRequest.class))).thenReturn(dto);
		when(enterpriseHelper.getEnterprise(connection)).thenReturn(enterprise);
		when(enterprise.getRegionId()).thenReturn(Long.valueOf(VzbVoipEnum.RegionType.EMEA));
		when(enterprise.addToDB()).thenReturn(Boolean.TRUE);
		when(connection.createStatement()).thenReturn(selStmt);
		when(selStmt.executeUpdate(any(String.class))).thenReturn(1);
		when(selStmt.executeQuery(any(String.class))).thenReturn(rs); 
		when(connection.prepareStatement(any(String.class))).thenReturn(pstmt);
		when(pstmt.executeQuery()).thenReturn(rs);
		PowerMockito.whenNew(TblEnvOrderQuery.class).withNoArguments().thenReturn(tblEnvOrderQuery);
		when(enterprise.updateTsoVampEntityMigForEnt(any(String.class), any(String.class), any(String.class))).thenReturn(Boolean.TRUE);
		when(enterprise.updateTblTsoEntityMigForEnt(any(String.class), any(String.class))).thenReturn(Boolean.TRUE);
		 when(tblEnvOrderQuery.size()).thenReturn(1);
			
		 obj.setEnvOrderId("1396815");
		int result = obj.go();
		assertEquals(result,2);
	}
	/*testcase to cover yellow lines by adding null param value in json*/
	@Test
	public void testGoSuccess_NullParamValue() throws Exception {
		File fileObj = new File(
				"src/test/resources/com/vz/fxo/enterprise/actionfunction/VZB_INV_MOD_ENTERPRISE/test_VZB_INV_MOD_ENT_NullParamValue.json");
		OrderDomainServiceDTO dto = DomainInterfaceUtil.prepareResponseFromInputJsonFile(fileObj);
		when(enterpriseHelper.getEnterprise(connection)).thenReturn(enterprise);
		when(orderDomainDataService.getOrderDomainData(any(OrderDomainServiceRequest.class))).thenReturn(dto);
		when(enterpriseHelper.getEnterprise(connection)).thenReturn(enterprise);
		when(enterprise.getRegionId()).thenReturn(Long.valueOf(VzbVoipEnum.RegionType.EMEA));
		when(enterprise.addToDB()).thenReturn(Boolean.TRUE);
		when(connection.createStatement()).thenReturn(selStmt);
		when(selStmt.executeUpdate(any(String.class))).thenReturn(1);
		when(selStmt.executeQuery(any(String.class))).thenReturn(rs); 
		when(connection.prepareStatement(any(String.class))).thenReturn(pstmt);
		when(pstmt.executeQuery()).thenReturn(rs);
		PowerMockito.whenNew(TblEnvOrderQuery.class).withNoArguments().thenReturn(tblEnvOrderQuery);
		when(enterprise.updateTsoVampEntityMigForEnt(any(String.class), any(String.class), any(String.class))).thenReturn(Boolean.TRUE);
		when(enterprise.updateTblTsoEntityMigForEnt(any(String.class), any(String.class))).thenReturn(Boolean.TRUE);
		 when(tblEnvOrderQuery.size()).thenReturn(1);
			
		 obj.setEnvOrderId("1396815");
		int result = obj.go();
		assertEquals(result,2);
	}
	/*testcase for yellow line coverage by adding empty param value*/
	@Test
	public void testGoSuccess_EmptyParamValue() throws Exception {
		File fileObj = new File(
				"src/test/resources/com/vz/fxo/enterprise/actionfunction/VZB_INV_MOD_ENTERPRISE/test_VZB_INV_MOD_ENT_EmptyParamValue.json");
		OrderDomainServiceDTO dto = DomainInterfaceUtil.prepareResponseFromInputJsonFile(fileObj);
		when(enterpriseHelper.getEnterprise(connection)).thenReturn(enterprise);
		when(orderDomainDataService.getOrderDomainData(any(OrderDomainServiceRequest.class))).thenReturn(dto);
		when(enterpriseHelper.getEnterprise(connection)).thenReturn(enterprise);
		when(enterprise.getRegionId()).thenReturn(Long.valueOf(VzbVoipEnum.RegionType.EMEA));
		when(enterprise.addToDB()).thenReturn(Boolean.TRUE);
		when(connection.createStatement()).thenReturn(selStmt);
		when(selStmt.executeUpdate(any(String.class))).thenReturn(1);
		when(selStmt.executeQuery(any(String.class))).thenReturn(rs); 
		when(connection.prepareStatement(any(String.class))).thenReturn(pstmt);
		when(pstmt.executeQuery()).thenReturn(rs);
		PowerMockito.whenNew(TblEnvOrderQuery.class).withNoArguments().thenReturn(tblEnvOrderQuery);
		when(enterprise.updateTsoVampEntityMigForEnt(any(String.class), any(String.class), any(String.class))).thenReturn(Boolean.TRUE);
		when(enterprise.updateTblTsoEntityMigForEnt(any(String.class), any(String.class))).thenReturn(Boolean.TRUE);
		 when(tblEnvOrderQuery.size()).thenReturn(1);
			
		 obj.setEnvOrderId("1396815");
		int result = obj.go();
		assertEquals(result,2);
	}
	/*testcase to by adding SoEnabled value to 1*/
	@Test
	public void testGoSuccess_EmptyParamValueWithSOEnabled1() throws Exception {
		File fileObj = new File(
				"src/test/resources/com/vz/fxo/enterprise/actionfunction/VZB_INV_MOD_ENTERPRISE/test_VZB_INV_MOD_ENT_EmptyParamValueSoEnabled.json");
		OrderDomainServiceDTO dto = DomainInterfaceUtil.prepareResponseFromInputJsonFile(fileObj);
		when(enterpriseHelper.getEnterprise(connection)).thenReturn(enterprise);
		when(orderDomainDataService.getOrderDomainData(any(OrderDomainServiceRequest.class))).thenReturn(dto);
		when(enterpriseHelper.getEnterprise(connection)).thenReturn(enterprise);
		when(enterprise.getRegionId()).thenReturn(Long.valueOf(VzbVoipEnum.RegionType.EMEA));
		when(enterprise.addToDB()).thenReturn(Boolean.TRUE);
		when(connection.createStatement()).thenReturn(selStmt);
		when(selStmt.executeUpdate(any(String.class))).thenReturn(1);
		when(selStmt.executeQuery(any(String.class))).thenReturn(rs); 
		when(connection.prepareStatement(any(String.class))).thenReturn(pstmt);
		when(pstmt.executeQuery()).thenReturn(rs);
		PowerMockito.whenNew(TblEnvOrderQuery.class).withNoArguments().thenReturn(tblEnvOrderQuery);
		when(enterprise.updateTsoVampEntityMigForEnt(any(String.class), any(String.class), any(String.class))).thenReturn(Boolean.TRUE);
		when(enterprise.updateTblTsoEntityMigForEnt(any(String.class), any(String.class))).thenReturn(Boolean.TRUE);
		 when(tblEnvOrderQuery.size()).thenReturn(1);
			
		 obj.setEnvOrderId("1396815");
		int result = obj.go();
		assertEquals(result,2);
	}
	
	@Test
	public void testGoSuccessAccountTeamName() throws Exception {
		File fileObj = new File(
				"src/test/resources/com/vz/fxo/enterprise/actionfunction/VZB_INV_MOD_ENTERPRISE/test_VZB_INV_MOD_ENT_AccountTeam.json");
		OrderDomainServiceDTO dto = DomainInterfaceUtil.prepareResponseFromInputJsonFile(fileObj);
		when(enterpriseHelper.getEnterprise(connection)).thenReturn(enterprise);
		when(orderDomainDataService.getOrderDomainData(any(OrderDomainServiceRequest.class))).thenReturn(dto);
		when(enterpriseHelper.getEnterprise(connection)).thenReturn(enterprise);
		when(enterprise.getRegionId()).thenReturn(Long.valueOf(VzbVoipEnum.RegionType.EMEA));
		when(enterprise.addToDB()).thenReturn(Boolean.TRUE);
		when(connection.createStatement()).thenReturn(selStmt);
		when(selStmt.executeUpdate(any(String.class))).thenReturn(1);
		when(selStmt.executeQuery(any(String.class))).thenReturn(rs); 
		when(connection.prepareStatement(any(String.class))).thenReturn(pstmt);
		when(pstmt.executeQuery()).thenReturn(rs);
		PowerMockito.whenNew(TblEnvOrderQuery.class).withNoArguments().thenReturn(tblEnvOrderQuery);
		when(enterprise.updateTsoVampEntityMigForEnt(any(String.class), any(String.class), any(String.class))).thenReturn(Boolean.TRUE);
		when(enterprise.updateTblTsoEntityMigForEnt(any(String.class), any(String.class))).thenReturn(Boolean.TRUE);
		 when(tblEnvOrderQuery.size()).thenReturn(1);
			
		 obj.setEnvOrderId("1396815");
		int result = obj.go();
		assertEquals(result,2);
	}
	/*testcase to cover BillingSystem condition*/
	@Test
	public void testGoSuccessAccountTeamNameBillingSystem() throws Exception {
		File fileObj = new File(
				"src/test/resources/com/vz/fxo/enterprise/actionfunction/VZB_INV_MOD_ENTERPRISE/test_VZB_INV_MOD_ENT_BillingSystem.json");
		OrderDomainServiceDTO dto = DomainInterfaceUtil.prepareResponseFromInputJsonFile(fileObj);
		when(enterpriseHelper.getEnterprise(connection)).thenReturn(enterprise);
		when(orderDomainDataService.getOrderDomainData(any(OrderDomainServiceRequest.class))).thenReturn(dto);
		when(enterpriseHelper.getEnterprise(connection)).thenReturn(enterprise);
		
		when(enterprise.getRegionId()).thenReturn(Long.valueOf(VzbVoipEnum.RegionType.EMEA));
		
		//enterprise.setBillingSystem(getBillingSytemType(param, "0"));		
		when(obj.getBillingSytemType(Matchers.any(TableOrderDetailsParam.class),Matchers.any(String.class))).thenReturn(3434);
		
		when(enterprise.addToDB()).thenReturn(Boolean.TRUE);
	/*	when(connection.createStatement()).thenReturn(selStmt);
		when(selStmt.executeUpdate(any(String.class))).thenReturn(1);
		when(selStmt.executeQuery(any(String.class))).thenReturn(rs); 
		when(connection.prepareStatement(any(String.class))).thenReturn(pstmt);
		when(pstmt.executeQuery()).thenReturn(rs);*/
		PowerMockito.whenNew(TblEnvOrderQuery.class).withNoArguments().thenReturn(tblEnvOrderQuery);
		when(enterprise.updateTsoVampEntityMigForEnt(any(String.class), any(String.class), any(String.class))).thenReturn(Boolean.TRUE);
		when(enterprise.updateTblTsoEntityMigForEnt(any(String.class), any(String.class))).thenReturn(Boolean.TRUE);
		 when(tblEnvOrderQuery.size()).thenReturn(1);
			
		 obj.setEnvOrderId("1396815");
		int result = obj.go();
		assertEquals(result,2);
	}
	/*testcase for coverage of condition of Region other than US*/
	@Test
	public void testGoSuccessRegionNotUS() throws Exception {
		File fileObj = new File(
				"src/test/resources/com/vz/fxo/enterprise/actionfunction/VZB_INV_MOD_ENTERPRISE/test_VZB_INV_MOD_ENT_RegionNotUS.json");
		OrderDomainServiceDTO dto = DomainInterfaceUtil.prepareResponseFromInputJsonFile(fileObj);

		when(orderDomainDataService.getOrderDomainData(any(OrderDomainServiceRequest.class))).thenReturn(dto);
		when(enterpriseHelper.getEnterprise(connection)).thenReturn(enterprise);
		when(enterprise.getRegionId()).thenReturn(Long.valueOf(VzbVoipEnum.RegionType.EMEA));
		when(enterprise.addToDB()).thenReturn(Boolean.TRUE);
		when(connection.createStatement()).thenReturn(selStmt);
		when(selStmt.executeUpdate(any(String.class))).thenReturn(1);
		when(selStmt.executeQuery(any(String.class))).thenReturn(rs); 
		when(connection.prepareStatement(any(String.class))).thenReturn(pstmt);
		when(pstmt.executeQuery()).thenReturn(rs);
		PowerMockito.whenNew(TblEnvOrderQuery.class).withNoArguments().thenReturn(tblEnvOrderQuery);
		when(enterprise.updateTsoVampEntityMigForEnt(any(String.class), any(String.class), any(String.class))).thenReturn(Boolean.TRUE);
		when(enterprise.updateTblTsoEntityMigForEnt(any(String.class), any(String.class))).thenReturn(Boolean.TRUE);
		 when(tblEnvOrderQuery.size()).thenReturn(1);
			
		 obj.setEnvOrderId("1396815");
		int result = obj.go();
		assertEquals(result,2);
	}
	/*testcase to cover else block for region other than US*/
	@Test
	public void testGoSuccessRegionNotUSElseBlock() throws Exception {
		File fileObj = new File(
				"src/test/resources/com/vz/fxo/enterprise/actionfunction/VZB_INV_MOD_ENTERPRISE/test_VZB_INV_MOD_ENT_RegionNotUSElseBlock.json");
		OrderDomainServiceDTO dto = DomainInterfaceUtil.prepareResponseFromInputJsonFile(fileObj);

		when(orderDomainDataService.getOrderDomainData(any(OrderDomainServiceRequest.class))).thenReturn(dto);
		when(enterpriseHelper.getEnterprise(connection)).thenReturn(enterprise);
		when(enterprise.getRegionId()).thenReturn(Long.valueOf(VzbVoipEnum.RegionType.EMEA));
		when(enterprise.addToDB()).thenReturn(Boolean.TRUE);
		when(connection.createStatement()).thenReturn(selStmt);
		when(selStmt.executeUpdate(any(String.class))).thenReturn(1);
		when(selStmt.executeQuery(any(String.class))).thenReturn(rs); 
		when(connection.prepareStatement(any(String.class))).thenReturn(pstmt);
		when(pstmt.executeQuery()).thenReturn(rs);
		PowerMockito.whenNew(TblEnvOrderQuery.class).withNoArguments().thenReturn(tblEnvOrderQuery);
		when(enterprise.updateTsoVampEntityMigForEnt(any(String.class), any(String.class), any(String.class))).thenReturn(Boolean.TRUE);
		when(enterprise.updateTblTsoEntityMigForEnt(any(String.class), any(String.class))).thenReturn(Boolean.TRUE);
		 when(tblEnvOrderQuery.size()).thenReturn(1);
			
		 obj.setEnvOrderId("1396815");
		int result = obj.go();
		assertEquals(result,2);
	}
	@Test
	public void testGoSuccess1() throws Exception {
		File fileObj = new File(
				"src/test/resources/com/vz/fxo/enterprise/actionfunction/VZB_INV_MOD_ENTERPRISE/test_VZB_INV_MOD_ENT.json");
		OrderDomainServiceDTO dto = DomainInterfaceUtil.prepareResponseFromInputJsonFile(fileObj);

		when(orderDomainDataService.getOrderDomainData(any(OrderDomainServiceRequest.class))).thenReturn(dto);
		when(enterpriseHelper.getEnterprise(connection)).thenReturn(enterprise);
		when(enterprise.getRegionId()).thenReturn(Long.valueOf(VzbVoipEnum.RegionType.US));
		when(obj.getBillingSytemType(Matchers.any(TableOrderDetailsParam.class),Matchers.any(String.class))).thenReturn(3434);
		when(enterprise.addToDB()).thenReturn(Boolean.TRUE);
		when(connection.createStatement()).thenReturn(selStmt);
		when(selStmt.executeUpdate(any(String.class))).thenReturn(1);
		when(selStmt.executeQuery(any(String.class))).thenReturn(rs); 
		when(connection.prepareStatement(any(String.class))).thenReturn(pstmt);
		when(pstmt.executeQuery()).thenReturn(rs);
		PowerMockito.whenNew(TblEnvOrderQuery.class).withNoArguments().thenReturn(tblEnvOrderQuery);
		when(enterprise.updateTsoVampEntityMigForEnt(any(String.class), any(String.class), any(String.class))).thenReturn(Boolean.TRUE);
		when(enterprise.updateTblTsoEntityMigForEnt(any(String.class), any(String.class))).thenReturn(Boolean.TRUE);
		
		PowerMockito.whenNew(TblEnvOrderQuery.class).withNoArguments().thenReturn(tblEnvOrderQuery);
		obj.setEnvOrderId("1396815");
		
		int result = obj.go();
		assertEquals(result,2);
	}
	@Test
	public void testGoSuccessNoParentEntID() throws Exception {
		File fileObj = new File(
				"src/test/resources/com/vz/fxo/enterprise/actionfunction/VZB_INV_MOD_ENTERPRISE/test_VZB_INV_MOD_ENT2.json");
		OrderDomainServiceDTO dto = DomainInterfaceUtil.prepareResponseFromInputJsonFile(fileObj);

		when(orderDomainDataService.getOrderDomainData(any(OrderDomainServiceRequest.class))).thenReturn(dto);
		when(enterpriseHelper.getEnterprise(connection)).thenReturn(enterprise);
		when(enterprise.getRegionId()).thenReturn(Long.valueOf(VzbVoipEnum.RegionType.US));
		when(enterprise.addToDB()).thenReturn(Boolean.TRUE);
		when(connection.createStatement()).thenReturn(selStmt);
		when(selStmt.executeUpdate(any(String.class))).thenReturn(1);
		when(selStmt.executeQuery(any(String.class))).thenReturn(rs); 
		when(connection.prepareStatement(any(String.class))).thenReturn(pstmt);
		when(pstmt.executeQuery()).thenReturn(rs);
		PowerMockito.whenNew(TblEnvOrderQuery.class).withNoArguments().thenReturn(tblEnvOrderQuery);
		when(enterprise.updateTsoVampEntityMigForEnt(any(String.class), any(String.class), any(String.class))).thenReturn(Boolean.TRUE);
		when(enterprise.updateTblTsoEntityMigForEnt(any(String.class), any(String.class))).thenReturn(Boolean.TRUE);
		// when(tblEnvOrderQuery.size()).thenReturn(1);
		PowerMockito.whenNew(TblEnvOrderQuery.class).withNoArguments().thenReturn(tblEnvOrderQuery);
		obj.setEnvOrderId("1396815");
		
		int result = obj.go();
		assertEquals(result,2);
	}
	@Test
	public void testGoSuccess3() throws Exception {
		File fileObj = new File(
				"src/test/resources/com/vz/fxo/enterprise/actionfunction/VZB_INV_MOD_ENTERPRISE/test_VZB_INV_MOD_ENT3.json");
		OrderDomainServiceDTO dto = DomainInterfaceUtil.prepareResponseFromInputJsonFile(fileObj);

		when(orderDomainDataService.getOrderDomainData(any(OrderDomainServiceRequest.class))).thenReturn(dto);
		when(enterpriseHelper.getEnterprise(connection)).thenReturn(enterprise);
		when(enterprise.getRegionId()).thenReturn(Long.valueOf(VzbVoipEnum.RegionType.US));
		when(enterprise.addToDB()).thenReturn(Boolean.TRUE);
		when(connection.createStatement()).thenReturn(selStmt);
		when(selStmt.executeUpdate(any(String.class))).thenReturn(1);
		when(selStmt.executeQuery(any(String.class))).thenReturn(rs); 
		when(connection.prepareStatement(any(String.class))).thenReturn(pstmt);
		when(pstmt.executeQuery()).thenReturn(rs);
		PowerMockito.whenNew(TblEnvOrderQuery.class).withNoArguments().thenReturn(tblEnvOrderQuery);
		when(enterprise.updateTsoVampEntityMigForEnt(any(String.class), any(String.class), any(String.class))).thenReturn(Boolean.TRUE);
		when(enterprise.updateTblTsoEntityMigForEnt(any(String.class), any(String.class))).thenReturn(Boolean.TRUE);
		obj.setEnvOrderId("1396815");
		
		int result = obj.go();
		assertEquals(result,2);
	}
	@Test
	public void testGoSuccess3ModifyAuthServicesForEnterprise() throws Exception {
		File fileObj = new File(
				"src/test/resources/com/vz/fxo/enterprise/actionfunction/VZB_INV_MOD_ENTERPRISE/test_VZB_INV_MOD_ENT3.json");
		OrderDomainServiceDTO dto = DomainInterfaceUtil.prepareResponseFromInputJsonFile(fileObj);

		when(orderDomainDataService.getOrderDomainData(any(OrderDomainServiceRequest.class))).thenReturn(dto);
	//	when(enterpriseHelper.getEnterprise(connection)).thenReturn(enterprise);
		when(enterprise.getRegionId()).thenReturn(Long.valueOf(VzbVoipEnum.RegionType.US));
		when(enterprise.addToDB()).thenReturn(Boolean.TRUE);
		when(connection.createStatement()).thenReturn(selStmt);
		when(selStmt.executeUpdate(any(String.class))).thenReturn(1);
		when(selStmt.executeQuery(any(String.class))).thenReturn(rs); 
		when(connection.prepareStatement(any(String.class))).thenReturn(pstmt);
		when(pstmt.executeQuery()).thenReturn(rs);
		PowerMockito.whenNew(TblEnvOrderQuery.class).withNoArguments().thenReturn(tblEnvOrderQuery);
		when(enterprise.updateTsoVampEntityMigForEnt(any(String.class), any(String.class), any(String.class))).thenReturn(Boolean.TRUE);
		when(enterprise.updateTblTsoEntityMigForEnt(any(String.class), any(String.class))).thenReturn(Boolean.TRUE);
		obj.setEnvOrderId("1396815");
		
		PowerMockito.mockStatic(EnterpriseActionFunctionHelper.class);
		PowerMockito.when(EnterpriseActionFunctionHelper.modifyAuthServicesForEnterprise(Matchers.any(Enterprise.class),Matchers.any(Connection.class),Matchers.anyInt())).thenReturn(Boolean.TRUE);
		
		int result = obj.go();
		assertEquals(result,2);
	}
	/*Testcase with Null entery for covering yellow lines*/
	@Test
	public void testGoSuccess3ModifyAuthServicesForEnterpriseWithNullEntry() throws Exception {
		File fileObj = new File(
				"src/test/resources/com/vz/fxo/enterprise/actionfunction/VZB_INV_MOD_ENTERPRISE/test_VZB_INV_MOD_ENT3_NullEntry.json");
		OrderDomainServiceDTO dto = DomainInterfaceUtil.prepareResponseFromInputJsonFile(fileObj);

		when(orderDomainDataService.getOrderDomainData(any(OrderDomainServiceRequest.class))).thenReturn(dto);
	//	when(enterpriseHelper.getEnterprise(connection)).thenReturn(enterprise);
		when(enterprise.getRegionId()).thenReturn(Long.valueOf(VzbVoipEnum.RegionType.US));
		when(enterprise.addToDB()).thenReturn(Boolean.TRUE);
		when(connection.createStatement()).thenReturn(selStmt);
		when(selStmt.executeUpdate(any(String.class))).thenReturn(1);
		when(selStmt.executeQuery(any(String.class))).thenReturn(rs); 
		when(connection.prepareStatement(any(String.class))).thenReturn(pstmt);
		when(pstmt.executeQuery()).thenReturn(rs);
		PowerMockito.whenNew(TblEnvOrderQuery.class).withNoArguments().thenReturn(tblEnvOrderQuery);
		when(enterprise.updateTsoVampEntityMigForEnt(any(String.class), any(String.class), any(String.class))).thenReturn(Boolean.TRUE);
		when(enterprise.updateTblTsoEntityMigForEnt(any(String.class), any(String.class))).thenReturn(Boolean.TRUE);
		obj.setEnvOrderId("1396815");
		
		PowerMockito.mockStatic(EnterpriseActionFunctionHelper.class);
		PowerMockito.when(EnterpriseActionFunctionHelper.modifyAuthServicesForEnterprise(Matchers.any(Enterprise.class),Matchers.any(Connection.class),Matchers.anyInt())).thenReturn(Boolean.TRUE);
		
		int result = obj.go();
		assertEquals(result,2);
	}
	/*testcase to cover tellow lines with Empty param value*/
	@Test
	public void testGoSuccess3ModifyAuthServicesForEnterpriseWithEmptyParamValue() throws Exception {
		File fileObj = new File(
				"src/test/resources/com/vz/fxo/enterprise/actionfunction/VZB_INV_MOD_ENTERPRISE/test_VZB_INV_MOD_ENT3_EmpyParamValue.json");
		OrderDomainServiceDTO dto = DomainInterfaceUtil.prepareResponseFromInputJsonFile(fileObj);

		when(orderDomainDataService.getOrderDomainData(any(OrderDomainServiceRequest.class))).thenReturn(dto);
	//	when(enterpriseHelper.getEnterprise(connection)).thenReturn(enterprise);
		when(enterprise.getRegionId()).thenReturn(Long.valueOf(VzbVoipEnum.RegionType.US));
		when(enterprise.addToDB()).thenReturn(Boolean.TRUE);
		when(connection.createStatement()).thenReturn(selStmt);
		when(selStmt.executeUpdate(any(String.class))).thenReturn(1);
		when(selStmt.executeQuery(any(String.class))).thenReturn(rs); 
		when(connection.prepareStatement(any(String.class))).thenReturn(pstmt);
		when(pstmt.executeQuery()).thenReturn(rs);
		PowerMockito.whenNew(TblEnvOrderQuery.class).withNoArguments().thenReturn(tblEnvOrderQuery);
		when(enterprise.updateTsoVampEntityMigForEnt(any(String.class), any(String.class), any(String.class))).thenReturn(Boolean.TRUE);
		when(enterprise.updateTblTsoEntityMigForEnt(any(String.class), any(String.class))).thenReturn(Boolean.TRUE);
		obj.setEnvOrderId("1396815");
		
		PowerMockito.mockStatic(EnterpriseActionFunctionHelper.class);
		PowerMockito.when(EnterpriseActionFunctionHelper.modifyAuthServicesForEnterprise(Matchers.any(Enterprise.class),Matchers.any(Connection.class),Matchers.anyInt())).thenReturn(Boolean.TRUE);
		
		int result = obj.go();
		assertEquals(result,2);
	}
	@Test
	public void testGoSuccess3ModifyAuthServicesForEnterprise2() throws Exception {
		File fileObj = new File(
				"src/test/resources/com/vz/fxo/enterprise/actionfunction/VZB_INV_MOD_ENTERPRISE/test_VZB_INV_MOD_ENT3.json");
		OrderDomainServiceDTO dto = DomainInterfaceUtil.prepareResponseFromInputJsonFile(fileObj);

		when(orderDomainDataService.getOrderDomainData(any(OrderDomainServiceRequest.class))).thenReturn(dto);
		when(enterpriseHelper.getEnterprise(connection)).thenReturn(enterprise);
		when(enterprise.getRegionId()).thenReturn(Long.valueOf(VzbVoipEnum.RegionType.US));
		when(enterprise.addToDB()).thenReturn(Boolean.TRUE);
		when(connection.createStatement()).thenReturn(selStmt);
		when(selStmt.executeUpdate(any(String.class))).thenReturn(1);
		when(selStmt.executeQuery(any(String.class))).thenReturn(rs); 
		when(connection.prepareStatement(any(String.class))).thenReturn(pstmt);
		when(pstmt.executeQuery()).thenReturn(rs);
		PowerMockito.whenNew(TblEnvOrderQuery.class).withNoArguments().thenReturn(tblEnvOrderQuery);
		when(enterprise.updateTsoVampEntityMigForEnt(any(String.class), any(String.class), any(String.class))).thenReturn(Boolean.TRUE);
		when(enterprise.updateTblTsoEntityMigForEnt(any(String.class), any(String.class))).thenReturn(Boolean.TRUE);
		obj.setEnvOrderId("1396815");
		
		PowerMockito.whenNew(TblDepartmentQuery.class).withNoArguments().thenReturn(departmentQry);
		doNothing().when(departmentQry).query(any(Connection.class));
		
		when(departmentQry.size()).thenReturn(2);
		
		//	CallingPlan callingPlanObj = new CallingPlan(connection);
		CallingPlan callingPlanObj =mock(CallingPlan.class);
		PowerMockito.whenNew(CallingPlan.class).withAnyArguments().thenReturn(callingPlanObj);
		
		//deptQry.getDbBean(i).getCallingPlanId();
		
		
		PowerMockito.mockStatic(EnterpriseActionFunctionHelper.class);
		PowerMockito.when(EnterpriseActionFunctionHelper.modifyAuthServicesForEnterprise(Matchers.any(Enterprise.class),Matchers.any(Connection.class),Matchers.anyInt())).thenReturn(Boolean.TRUE);
		
		int result = obj.go();
		assertEquals(result,2);
	}
	@Test
	public void testGoSuccess4() throws Exception {
		File fileObj = new File(
				"src/test/resources/com/vz/fxo/enterprise/actionfunction/VZB_INV_MOD_ENTERPRISE/test_VZB_INV_MOD_ENT4.json");
		OrderDomainServiceDTO dto = DomainInterfaceUtil.prepareResponseFromInputJsonFile(fileObj);

		when(orderDomainDataService.getOrderDomainData(any(OrderDomainServiceRequest.class))).thenReturn(dto);
		when(enterpriseHelper.getEnterprise(connection)).thenReturn(enterprise);
		when(enterprise.getRegionId()).thenReturn(Long.valueOf(VzbVoipEnum.RegionType.US));
		when(enterprise.addToDB()).thenReturn(Boolean.TRUE);
		when(connection.createStatement()).thenReturn(selStmt);
		when(selStmt.executeUpdate(any(String.class))).thenReturn(1);
		when(selStmt.executeQuery(any(String.class))).thenReturn(rs); 
		when(connection.prepareStatement(any(String.class))).thenReturn(pstmt);
		when(pstmt.executeQuery()).thenReturn(rs);
		PowerMockito.whenNew(TblEnvOrderQuery.class).withNoArguments().thenReturn(tblEnvOrderQuery);
		when(enterprise.updateTsoVampEntityMigForEnt(any(String.class), any(String.class), any(String.class))).thenReturn(Boolean.TRUE);
		when(enterprise.updateTblTsoEntityMigForEnt(any(String.class), any(String.class))).thenReturn(Boolean.TRUE);
		obj.setEnvOrderId("1396815");
		
		int result = obj.go();
		assertEquals(result,2);
	}
	@Test
	public void testGoSuccess4Exception() throws Exception {
		File fileObj = new File(
				"src/test/resources/com/vz/fxo/enterprise/actionfunction/VZB_INV_MOD_ENTERPRISE/test_VZB_INV_MOD_ENT4.json");
		OrderDomainServiceDTO dto = DomainInterfaceUtil.prepareResponseFromInputJsonFile(fileObj);

		when(orderDomainDataService.getOrderDomainData(any(OrderDomainServiceRequest.class))).thenReturn(dto);
		when(enterpriseHelper.getEnterprise(connection)).thenReturn(enterprise);
		when(enterprise.getRegionId()).thenReturn(Long.valueOf(VzbVoipEnum.RegionType.US));
		when(enterprise.addToDB()).thenReturn(Boolean.TRUE);
		when(connection.createStatement()).thenReturn(selStmt);
		when(selStmt.executeUpdate(any(String.class))).thenReturn(1);
		when(selStmt.executeQuery(any(String.class))).thenReturn(rs); 
		when(connection.prepareStatement(any(String.class))).thenReturn(pstmt);
		when(pstmt.executeQuery()).thenReturn(rs);
		PowerMockito.whenNew(TblEnvOrderQuery.class).withNoArguments().thenReturn(tblEnvOrderQuery);
		when(enterprise.updateTsoVampEntityMigForEnt(any(String.class), any(String.class), any(String.class))).thenReturn(Boolean.TRUE);
		when(enterprise.updateTblTsoEntityMigForEnt(any(String.class), any(String.class))).thenReturn(Boolean.TRUE);
		doThrow(new SQLException("Exception")).when(connection).rollback();
		obj.setEnvOrderId("1396815");
		
		int result = obj.go();
		assertEquals(result,2);
	}
	@Test
	public void testGoSuccess5() throws Exception {
		File fileObj = new File(
				"src/test/resources/com/vz/fxo/enterprise/actionfunction/VZB_INV_MOD_ENTERPRISE/test_VZB_INV_MOD_ENT5.json");
		OrderDomainServiceDTO dto = DomainInterfaceUtil.prepareResponseFromInputJsonFile(fileObj);

		when(orderDomainDataService.getOrderDomainData(any(OrderDomainServiceRequest.class))).thenReturn(dto);
		when(enterpriseHelper.getEnterprise(connection)).thenReturn(enterprise);
		when(enterprise.getRegionId()).thenReturn(Long.valueOf(VzbVoipEnum.RegionType.EMEA));
		when(enterprise.addToDB()).thenReturn(Boolean.TRUE);
		when(connection.createStatement()).thenReturn(selStmt);
		when(selStmt.executeUpdate(any(String.class))).thenReturn(1);
		when(selStmt.executeQuery(any(String.class))).thenReturn(rs); 
		PowerMockito.whenNew(TblEnvOrderQuery.class).withNoArguments().thenReturn(tblEnvOrderQuery);
		when(enterprise.updateTsoVampEntityMigForEnt(any(String.class), any(String.class), any(String.class))).thenReturn(Boolean.TRUE);
		when(enterprise.updateTblTsoEntityMigForEnt(any(String.class), any(String.class))).thenReturn(Boolean.TRUE);
		obj.setEnvOrderId("1396815");
		
		int result = obj.go();
		assertEquals(result,2);
	}
	@Test
	@Ignore
	public void testGoSuccess6() throws Exception {
		File fileObj = new File(
				"src/test/resources/com/vz/fxo/enterprise/actionfunction/VZB_INV_MOD_ENTERPRISE/test_VZB_INV_MOD_ENT6.json");
		OrderDomainServiceDTO dto = DomainInterfaceUtil.prepareResponseFromInputJsonFile(fileObj);

		when(orderDomainDataService.getOrderDomainData(any(OrderDomainServiceRequest.class))).thenReturn(dto);
		when(enterpriseHelper.getEnterprise(connection)).thenReturn(enterprise);
		when(enterprise.getRegionId()).thenReturn(Long.valueOf(VzbVoipEnum.RegionType.EMEA));
		when(enterprise.addToDB()).thenReturn(Boolean.TRUE);
		when(connection.createStatement()).thenReturn(selStmt);
		when(selStmt.executeUpdate(any(String.class))).thenReturn(1);
		when(selStmt.executeQuery(any(String.class))).thenReturn(rs); 
		when(connection.prepareStatement(any(String.class))).thenReturn(pstmt);
		when(pstmt.executeQuery()).thenReturn(rs);
		when(rs.next()).thenReturn(Boolean.TRUE);
		PowerMockito.whenNew(TblEnvOrderQuery.class).withNoArguments().thenReturn(tblEnvOrderQuery);
		when(enterprise.updateTsoVampEntityMigForEnt(any(String.class), any(String.class), any(String.class))).thenReturn(Boolean.TRUE);
		when(enterprise.updateTblTsoEntityMigForEnt(any(String.class), any(String.class))).thenReturn(Boolean.TRUE);
		doNothing().when(enterprise).setVmPartitionId(any(String.class));
		doNothing().when(enterprise).setProductType(7);
	//	doReturn(Boolean.TRUE).when(tblEnvOrderQuery.query(connection));
		PowerMockito.whenNew(Timestamp.class).withAnyArguments().thenReturn(timestamp);
	//	when(enterprise).setCatalogueReferenceTime(Timestamp.class);
		PowerMockito.whenNew(TblEnvOrderQuery.class).withNoArguments().thenReturn(tblEnvOrderQuery);
		obj.setEnvOrderId("1396815");
		
		int result = obj.go();
		assertEquals(result,1);
	}
	@Test
	public void testGoSuccess7() throws Exception {
		File fileObj = new File(
				"src/test/resources/com/vz/fxo/enterprise/actionfunction/VZB_INV_MOD_ENTERPRISE/test_VZB_INV_MOD_ENT6.json");
		OrderDomainServiceDTO dto = DomainInterfaceUtil.prepareResponseFromInputJsonFile(fileObj);

		when(orderDomainDataService.getOrderDomainData(any(OrderDomainServiceRequest.class))).thenReturn(dto);
		when(enterpriseHelper.getEnterprise(connection)).thenReturn(enterprise);
		when(enterprise.getRegionId()).thenReturn(Long.valueOf(VzbVoipEnum.RegionType.US));
		when(enterprise.addToDB()).thenReturn(Boolean.TRUE);
		when(connection.createStatement()).thenReturn(selStmt);
		when(selStmt.executeUpdate(any(String.class))).thenReturn(1);
		when(selStmt.executeQuery(any(String.class))).thenReturn(rs); 
		when(connection.prepareStatement(any(String.class))).thenReturn(pstmt);
		when(pstmt.executeQuery()).thenReturn(rs);
		when(rs.getInt(any(String.class))).thenReturn(123);
		PowerMockito.whenNew(TblEnvOrderQuery.class).withNoArguments().thenReturn(tblEnvOrderQuery);
		when(enterprise.updateTsoVampEntityMigForEnt(any(String.class), any(String.class), any(String.class))).thenReturn(Boolean.TRUE);
		when(enterprise.updateTblTsoEntityMigForEnt(any(String.class), any(String.class))).thenReturn(Boolean.TRUE);
		doNothing().when(enterprise).setVmPartitionId(any(String.class));
		doNothing().when(enterprise).setProductType(7);
	//	doReturn(Boolean.TRUE).when(tblEnvOrderQuery.query(connection));
		PowerMockito.whenNew(Timestamp.class).withAnyArguments().thenReturn(timestamp);
	//	when(enterprise).setCatalogueReferenceTime(Timestamp.class);
		PowerMockito.whenNew(TblEnvOrderDbBean.class).withAnyArguments().thenReturn(tblEnvOrderDbBean);
		PowerMockito.whenNew(TblEnvOrderQuery.class).withNoArguments().thenReturn(tblEnvOrderQuery);
		when(tblEnvOrderQuery.size()).thenReturn(1);
		when(tblEnvOrderQuery.getDbBean(any(int.class))).thenReturn(tblEnvOrderDbBean);
		when(tblEnvOrderDbBean.getE2eiSensitivityLevel()).thenReturn("1234");
		obj.setEnvOrderId("1396815");
		
		int result = obj.go();
		assertEquals(result,2);
	}
	@Test
	public void testGoSuccess8() throws Exception {
		File fileObj = new File(
				"src/test/resources/com/vz/fxo/enterprise/actionfunction/VZB_INV_MOD_ENTERPRISE/test_VZB_INV_MOD_ENT6.json");
		OrderDomainServiceDTO dto = DomainInterfaceUtil.prepareResponseFromInputJsonFile(fileObj);

		when(orderDomainDataService.getOrderDomainData(any(OrderDomainServiceRequest.class))).thenReturn(dto);
		when(enterpriseHelper.getEnterprise(connection)).thenReturn(enterprise);
		when(enterprise.getRegionId()).thenReturn(Long.valueOf(VzbVoipEnum.RegionType.US));
		when(enterprise.addToDB()).thenReturn(Boolean.TRUE);
		when(connection.createStatement()).thenReturn(selStmt);
		when(selStmt.executeUpdate(any(String.class))).thenReturn(1);
		when(selStmt.executeQuery(any(String.class))).thenReturn(rs); 
		when(connection.prepareStatement(any(String.class))).thenReturn(pstmt);
		when(pstmt.executeQuery()).thenReturn(rs);
		when(rs.getInt(any(String.class))).thenReturn(123);
		PowerMockito.whenNew(TblEnvOrderQuery.class).withNoArguments().thenReturn(tblEnvOrderQuery);
		when(enterprise.updateTsoVampEntityMigForEnt(any(String.class), any(String.class), any(String.class))).thenReturn(Boolean.TRUE);
		when(enterprise.updateTblTsoEntityMigForEnt(any(String.class), any(String.class))).thenReturn(Boolean.TRUE);
		doNothing().when(enterprise).setVmPartitionId(any(String.class));
		doNothing().when(enterprise).setProductType(7);
	//	doReturn(Boolean.TRUE).when(tblEnvOrderQuery.query(connection));
		PowerMockito.whenNew(Timestamp.class).withAnyArguments().thenReturn(timestamp);
	//	when(enterprise).setCatalogueReferenceTime(Timestamp.class);
		PowerMockito.whenNew(TblEnvOrderQuery.class).withNoArguments().thenReturn(tblEnvOrderQuery);
		obj.setEnvOrderId("1396815");
		
		int result = obj.go();
		assertEquals(result,2);
	}
	@Test
	public void testGoSuccessNullData() throws Exception {
		File fileObj = new File(
				"src/test/resources/com/vz/fxo/enterprise/actionfunction/VZB_INV_MOD_ENTERPRISE/test_VZB_INV_MOD_ENT_NullData.json");
		OrderDomainServiceDTO dto = DomainInterfaceUtil.prepareResponseFromInputJsonFile(fileObj);

		when(orderDomainDataService.getOrderDomainData(any(OrderDomainServiceRequest.class))).thenReturn(dto);
		when(enterpriseHelper.getEnterprise(connection)).thenReturn(enterprise);
		when(enterprise.getRegionId()).thenReturn(Long.valueOf(VzbVoipEnum.RegionType.US));
		when(enterprise.addToDB()).thenReturn(Boolean.TRUE);
		when(connection.createStatement()).thenReturn(selStmt);
		when(selStmt.executeUpdate(any(String.class))).thenReturn(1);
		when(selStmt.executeQuery(any(String.class))).thenReturn(rs); 
		when(connection.prepareStatement(any(String.class))).thenReturn(pstmt);
		when(pstmt.executeQuery()).thenReturn(rs);
		when(rs.getInt(any(String.class))).thenReturn(123);
		PowerMockito.whenNew(TblEnvOrderQuery.class).withNoArguments().thenReturn(tblEnvOrderQuery);
		when(enterprise.updateTsoVampEntityMigForEnt(any(String.class), any(String.class), any(String.class))).thenReturn(Boolean.TRUE);
		when(enterprise.updateTblTsoEntityMigForEnt(any(String.class), any(String.class))).thenReturn(Boolean.TRUE);
		doNothing().when(enterprise).setVmPartitionId(any(String.class));
		doNothing().when(enterprise).setProductType(7);
	//	doReturn(Boolean.TRUE).when(tblEnvOrderQuery.query(connection));
		PowerMockito.whenNew(Timestamp.class).withAnyArguments().thenReturn(timestamp);
	//	when(enterprise).setCatalogueReferenceTime(Timestamp.class);
		PowerMockito.whenNew(TblEnvOrderQuery.class).withNoArguments().thenReturn(tblEnvOrderQuery);
		obj.setEnvOrderId("1396815");
		
		int result = obj.go();
		assertEquals(result,2);
	}
	@Test
	public void testGoSuccessNullData2() throws Exception {
		File fileObj = new File(
				"src/test/resources/com/vz/fxo/enterprise/actionfunction/VZB_INV_MOD_ENTERPRISE/test_VZB_INV_MOD_ENT_NullData2.json");
		OrderDomainServiceDTO dto = DomainInterfaceUtil.prepareResponseFromInputJsonFile(fileObj);

		when(orderDomainDataService.getOrderDomainData(any(OrderDomainServiceRequest.class))).thenReturn(dto);
		when(enterpriseHelper.getEnterprise(connection)).thenReturn(enterprise);
		when(enterprise.getRegionId()).thenReturn(Long.valueOf(VzbVoipEnum.RegionType.US));
		when(enterprise.addToDB()).thenReturn(Boolean.TRUE);
		when(connection.createStatement()).thenReturn(selStmt);
		when(selStmt.executeUpdate(any(String.class))).thenReturn(1);
		when(selStmt.executeQuery(any(String.class))).thenReturn(rs); 
		when(connection.prepareStatement(any(String.class))).thenReturn(pstmt);
		when(pstmt.executeQuery()).thenReturn(rs);
		when(rs.getInt(any(String.class))).thenReturn(123);
		PowerMockito.whenNew(TblEnvOrderQuery.class).withNoArguments().thenReturn(tblEnvOrderQuery);
		when(enterprise.updateTsoVampEntityMigForEnt(any(String.class), any(String.class), any(String.class))).thenReturn(Boolean.TRUE);
		when(enterprise.updateTblTsoEntityMigForEnt(any(String.class), any(String.class))).thenReturn(Boolean.TRUE);
		doNothing().when(enterprise).setVmPartitionId(any(String.class));
		doNothing().when(enterprise).setProductType(7);
	//	doReturn(Boolean.TRUE).when(tblEnvOrderQuery.query(connection));
		PowerMockito.whenNew(Timestamp.class).withAnyArguments().thenReturn(timestamp);
	//	when(enterprise).setCatalogueReferenceTime(Timestamp.class);
		PowerMockito.whenNew(TblEnvOrderQuery.class).withNoArguments().thenReturn(tblEnvOrderQuery);
		obj.setEnvOrderId("1396815");
		
		int result = obj.go();
		assertEquals(result,2);
	}
	@Test
	public void testGoSuccessNullData3() throws Exception {
		File fileObj = new File(
				"src/test/resources/com/vz/fxo/enterprise/actionfunction/VZB_INV_MOD_ENTERPRISE/test_VZB_INV_MOD_ENT_NullData3.json");
		OrderDomainServiceDTO dto = DomainInterfaceUtil.prepareResponseFromInputJsonFile(fileObj);

		when(orderDomainDataService.getOrderDomainData(any(OrderDomainServiceRequest.class))).thenReturn(dto);
		when(enterpriseHelper.getEnterprise(connection)).thenReturn(enterprise);
		when(enterprise.getRegionId()).thenReturn(Long.valueOf(VzbVoipEnum.RegionType.US));
		when(enterprise.addToDB()).thenReturn(Boolean.TRUE);
		when(connection.createStatement()).thenReturn(selStmt);
		when(selStmt.executeUpdate(any(String.class))).thenReturn(1);
		when(selStmt.executeQuery(any(String.class))).thenReturn(rs); 
		when(connection.prepareStatement(any(String.class))).thenReturn(pstmt);
		when(pstmt.executeQuery()).thenReturn(rs);
		when(rs.getInt(any(String.class))).thenReturn(123);
		PowerMockito.whenNew(TblEnvOrderQuery.class).withNoArguments().thenReturn(tblEnvOrderQuery);
		when(enterprise.updateTsoVampEntityMigForEnt(any(String.class), any(String.class), any(String.class))).thenReturn(Boolean.TRUE);
		when(enterprise.updateTblTsoEntityMigForEnt(any(String.class), any(String.class))).thenReturn(Boolean.TRUE);
		doNothing().when(enterprise).setVmPartitionId(any(String.class));
		doNothing().when(enterprise).setProductType(7);
	//	doReturn(Boolean.TRUE).when(tblEnvOrderQuery.query(connection));
		PowerMockito.whenNew(Timestamp.class).withAnyArguments().thenReturn(timestamp);
	//	when(enterprise).setCatalogueReferenceTime(Timestamp.class);
		PowerMockito.whenNew(TblEnvOrderQuery.class).withNoArguments().thenReturn(tblEnvOrderQuery);
		obj.setEnvOrderId("1396815");
		
		int result = obj.go();
		assertEquals(result,2);
	}
	@Test
	public void testGoSuccessNullData4() throws Exception {
		File fileObj = new File(
				"src/test/resources/com/vz/fxo/enterprise/actionfunction/VZB_INV_MOD_ENTERPRISE/test_VZB_INV_MOD_ENT_NullData4.json");
		OrderDomainServiceDTO dto = DomainInterfaceUtil.prepareResponseFromInputJsonFile(fileObj);

		when(orderDomainDataService.getOrderDomainData(any(OrderDomainServiceRequest.class))).thenReturn(dto);
		when(enterpriseHelper.getEnterprise(connection)).thenReturn(enterprise);
		when(enterprise.getRegionId()).thenReturn(Long.valueOf(VzbVoipEnum.RegionType.US));
		when(enterprise.addToDB()).thenReturn(Boolean.TRUE);
		when(connection.createStatement()).thenReturn(selStmt);
		when(selStmt.executeUpdate(any(String.class))).thenReturn(1);
		when(selStmt.executeQuery(any(String.class))).thenReturn(rs); 
		when(connection.prepareStatement(any(String.class))).thenReturn(pstmt);
		when(pstmt.executeQuery()).thenReturn(rs);
		when(rs.getInt(any(String.class))).thenReturn(123);
		PowerMockito.whenNew(TblEnvOrderQuery.class).withNoArguments().thenReturn(tblEnvOrderQuery);
		when(enterprise.updateTsoVampEntityMigForEnt(any(String.class), any(String.class), any(String.class))).thenReturn(Boolean.TRUE);
		when(enterprise.updateTblTsoEntityMigForEnt(any(String.class), any(String.class))).thenReturn(Boolean.TRUE);
		doNothing().when(enterprise).setVmPartitionId(any(String.class));
		doNothing().when(enterprise).setProductType(7);
	//	doReturn(Boolean.TRUE).when(tblEnvOrderQuery.query(connection));
		PowerMockito.whenNew(Timestamp.class).withAnyArguments().thenReturn(timestamp);
	//	when(enterprise).setCatalogueReferenceTime(Timestamp.class);
		PowerMockito.whenNew(TblEnvOrderQuery.class).withNoArguments().thenReturn(tblEnvOrderQuery);
		obj.setEnvOrderId("1396815");
		
		int result = obj.go();
		assertEquals(result,2);
	}
	public void testGoSuccessNullData5() throws Exception {
		File fileObj = new File(
				"src/test/resources/com/vz/fxo/enterprise/actionfunction/VZB_INV_MOD_ENTERPRISE/test_VZB_INV_MOD_ENT_NullData4.json");
		OrderDomainServiceDTO dto = DomainInterfaceUtil.prepareResponseFromInputJsonFile(fileObj);

		when(orderDomainDataService.getOrderDomainData(any(OrderDomainServiceRequest.class))).thenReturn(dto);
		when(enterpriseHelper.getEnterprise(connection)).thenReturn(enterprise);
		when(enterprise.getRegionId()).thenReturn(Long.valueOf(VzbVoipEnum.RegionType.EMEA));
		when(enterprise.addToDB()).thenReturn(Boolean.TRUE);
		when(connection.createStatement()).thenReturn(selStmt);
		when(selStmt.executeUpdate(any(String.class))).thenReturn(1);
		when(selStmt.executeQuery(any(String.class))).thenReturn(rs); 
		when(connection.prepareStatement(any(String.class))).thenReturn(pstmt);
		when(pstmt.executeQuery()).thenReturn(rs);
		when(rs.getInt(any(String.class))).thenReturn(123);
		PowerMockito.whenNew(TblEnvOrderQuery.class).withNoArguments().thenReturn(tblEnvOrderQuery);
		when(enterprise.updateTsoVampEntityMigForEnt(any(String.class), any(String.class), any(String.class))).thenReturn(Boolean.TRUE);
		when(enterprise.updateTblTsoEntityMigForEnt(any(String.class), any(String.class))).thenReturn(Boolean.TRUE);
		doNothing().when(enterprise).setVmPartitionId(any(String.class));
		doNothing().when(enterprise).setProductType(7);
	//	doReturn(Boolean.TRUE).when(tblEnvOrderQuery.query(connection));
		PowerMockito.whenNew(Timestamp.class).withAnyArguments().thenReturn(timestamp);
	//	when(enterprise).setCatalogueReferenceTime(Timestamp.class);
		PowerMockito.whenNew(TblEnvOrderQuery.class).withNoArguments().thenReturn(tblEnvOrderQuery);
		obj.setEnvOrderId("1396815");
		
		int result = obj.go();
		assertEquals(result,2);
	}
	@Test
	public void testGoFailureNullEnterpriseReferenceId() throws Exception {
		File fileObj = new File(
				"src/test/resources/com/vz/fxo/enterprise/actionfunction/VZB_INV_MOD_ENTERPRISE/test_VZB_INV_MOD_ENT_NullEnterpriseReferenceId.json");
		OrderDomainServiceDTO dto = DomainInterfaceUtil.prepareResponseFromInputJsonFile(fileObj);

		when(orderDomainDataService.getOrderDomainData(any(OrderDomainServiceRequest.class))).thenReturn(dto);
		when(enterpriseHelper.getEnterprise(connection)).thenReturn(enterprise);
		when(enterprise.getRegionId()).thenReturn(Long.valueOf(VzbVoipEnum.RegionType.EMEA));
		when(enterprise.addToDB()).thenReturn(Boolean.TRUE);
		when(connection.createStatement()).thenReturn(selStmt);
		when(selStmt.executeUpdate(any(String.class))).thenReturn(1);
		when(selStmt.executeQuery(any(String.class))).thenReturn(rs); 
		when(connection.prepareStatement(any(String.class))).thenReturn(null);
		when(pstmt.executeQuery()).thenReturn(rs);
		when(rs.getInt(any(String.class))).thenReturn(123);
		PowerMockito.whenNew(TblEnvOrderQuery.class).withNoArguments().thenReturn(tblEnvOrderQuery);
		when(enterprise.updateTsoVampEntityMigForEnt(any(String.class), any(String.class), any(String.class))).thenReturn(Boolean.FALSE);
		when(enterprise.updateTblTsoEntityMigForEnt(any(String.class), any(String.class))).thenReturn(Boolean.TRUE);
		doNothing().when(enterprise).setVmPartitionId(any(String.class));
		doNothing().when(enterprise).setProductType(7);
	//	doReturn(Boolean.TRUE).when(tblEnvOrderQuery.query(connection));
		PowerMockito.whenNew(Timestamp.class).withAnyArguments().thenReturn(timestamp);
	//	when(enterprise).setCatalogueReferenceTime(Timestamp.class);
		PowerMockito.whenNew(TblEnvOrderQuery.class).withNoArguments().thenReturn(tblEnvOrderQuery);
		obj.setEnvOrderId("1396815");
		
		int result = obj.go();
		assertEquals(result,2);
	}
	@Test
	public void testGoFailureNullOldEnterpriseId() throws Exception {
		File fileObj = new File(
				"src/test/resources/com/vz/fxo/enterprise/actionfunction/VZB_INV_MOD_ENTERPRISE/test_VZB_INV_MOD_ENT_NullOldEnterpriseId.json");
		OrderDomainServiceDTO dto = DomainInterfaceUtil.prepareResponseFromInputJsonFile(fileObj);

		when(orderDomainDataService.getOrderDomainData(any(OrderDomainServiceRequest.class))).thenReturn(dto);
		when(enterpriseHelper.getEnterprise(connection)).thenReturn(enterprise);
		when(enterprise.getRegionId()).thenReturn(Long.valueOf(VzbVoipEnum.RegionType.EMEA));
		when(enterprise.addToDB()).thenReturn(Boolean.TRUE);
		when(connection.createStatement()).thenReturn(selStmt);
		when(selStmt.executeUpdate(any(String.class))).thenReturn(1);
		when(selStmt.executeQuery(any(String.class))).thenReturn(rs); 
		when(connection.prepareStatement(any(String.class))).thenReturn(pstmt);
		when(pstmt.executeQuery()).thenReturn(rs);
		when(rs.getInt(any(String.class))).thenReturn(123);
		PowerMockito.whenNew(TblEnvOrderQuery.class).withNoArguments().thenReturn(tblEnvOrderQuery);
		when(enterprise.updateTsoVampEntityMigForEnt(any(String.class), any(String.class), any(String.class))).thenReturn(Boolean.TRUE);
		when(enterprise.updateTblTsoEntityMigForEnt(any(String.class), any(String.class))).thenReturn(Boolean.FALSE);
		doNothing().when(enterprise).setVmPartitionId(any(String.class));
		doNothing().when(enterprise).setProductType(7);
		//doThrow(new Exception()).when(pstmt).close();
	//	doReturn(Boolean.TRUE).when(tblEnvOrderQuery.query(connection));
		PowerMockito.whenNew(Timestamp.class).withAnyArguments().thenReturn(timestamp);
	//	when(enterprise).setCatalogueReferenceTime(Timestamp.class);
		PowerMockito.whenNew(TblEnvOrderQuery.class).withNoArguments().thenReturn(tblEnvOrderQuery);
		obj.setEnvOrderId("1396815");
		
		int result = obj.go();
		assertEquals(result,2);
	}
	@Test
	public void testGoFailure() throws Exception {
		File fileObj = new File(
				"src/test/resources/com/vz/fxo/enterprise/actionfunction/VZB_INV_MOD_ENTERPRISE/test_VZB_INV_MOD_ENT6.json");
		OrderDomainServiceDTO dto = DomainInterfaceUtil.prepareResponseFromInputJsonFile(fileObj);

		when(orderDomainDataService.getOrderDomainData(any(OrderDomainServiceRequest.class))).thenReturn(dto);
		when(enterpriseHelper.getEnterprise(connection)).thenReturn(enterprise);
		when(enterprise.getRegionId()).thenReturn(Long.valueOf(VzbVoipEnum.RegionType.US));
		when(enterprise.addToDB()).thenReturn(Boolean.TRUE);
		when(connection.createStatement()).thenReturn(selStmt);
		when(selStmt.executeUpdate(any(String.class))).thenReturn(1);
		when(selStmt.executeQuery(any(String.class))).thenReturn(rs); 
		when(connection.prepareStatement(any(String.class))).thenThrow(new SQLException("SQLException","", -60));
		when(pstmt.executeQuery()).thenReturn(rs);
		//when(pstmt.executeQuery()).thenThrow(new SQLException());
		PowerMockito.whenNew(TblEnvOrderQuery.class).withNoArguments().thenReturn(tblEnvOrderQuery);
		when(enterprise.updateTsoVampEntityMigForEnt(any(String.class), any(String.class), any(String.class))).thenReturn(Boolean.TRUE);
		when(enterprise.updateTblTsoEntityMigForEnt(any(String.class), any(String.class))).thenReturn(Boolean.TRUE);
		doNothing().when(enterprise).setVmPartitionId(any(String.class));
		doNothing().when(enterprise).setProductType(7);
	//	doReturn(Boolean.TRUE).when(tblEnvOrderQuery.query(connection));
		PowerMockito.whenNew(Timestamp.class).withAnyArguments().thenReturn(timestamp);
	//	when(enterprise).setCatalogueReferenceTime(Timestamp.class);
		PowerMockito.whenNew(TblEnvOrderQuery.class).withNoArguments().thenReturn(tblEnvOrderQuery);
		Mockito.doThrow(Exception.class).when(connection).rollback();
		obj.setEnvOrderId("1396815");
		
		int result = obj.go();
		assertEquals(result,2);
	}
	@Test
	public void testGoFailureErroeCode() throws Exception {
		File fileObj = new File(
				"src/test/resources/com/vz/fxo/enterprise/actionfunction/VZB_INV_MOD_ENTERPRISE/test_VZB_INV_MOD_ENT6.json");
		OrderDomainServiceDTO dto = DomainInterfaceUtil.prepareResponseFromInputJsonFile(fileObj);

		when(orderDomainDataService.getOrderDomainData(any(OrderDomainServiceRequest.class))).thenReturn(dto);
		when(enterpriseHelper.getEnterprise(connection)).thenReturn(enterprise);
		when(enterprise.getRegionId()).thenReturn(Long.valueOf(VzbVoipEnum.RegionType.US));
		when(enterprise.addToDB()).thenReturn(Boolean.TRUE);
		when(connection.createStatement()).thenReturn(selStmt);
		when(selStmt.executeUpdate(any(String.class))).thenReturn(1);
		when(selStmt.executeQuery(any(String.class))).thenReturn(rs); 
		when(connection.prepareStatement(any(String.class))).thenThrow(new SQLException("SQLException","", -70));
		when(pstmt.executeQuery()).thenReturn(rs);
		//when(pstmt.executeQuery()).thenThrow(new SQLException());
		PowerMockito.whenNew(TblEnvOrderQuery.class).withNoArguments().thenReturn(tblEnvOrderQuery);
		when(enterprise.updateTsoVampEntityMigForEnt(any(String.class), any(String.class), any(String.class))).thenReturn(Boolean.TRUE);
		when(enterprise.updateTblTsoEntityMigForEnt(any(String.class), any(String.class))).thenReturn(Boolean.TRUE);
		doNothing().when(enterprise).setVmPartitionId(any(String.class));
		doNothing().when(enterprise).setProductType(7);
	//	doReturn(Boolean.TRUE).when(tblEnvOrderQuery.query(connection));
		PowerMockito.whenNew(Timestamp.class).withAnyArguments().thenReturn(timestamp);
	//	when(enterprise).setCatalogueReferenceTime(Timestamp.class);
		PowerMockito.whenNew(TblEnvOrderQuery.class).withNoArguments().thenReturn(tblEnvOrderQuery);
		Mockito.doThrow(Exception.class).when(connection).rollback();
		obj.setEnvOrderId("1396815");
		
		int result = obj.go();
		assertEquals(result,2);
	}
	@Test
	public void testGoAddDBFalse() throws Exception {
		File fileObj = new File(
				"src/test/resources/com/vz/fxo/enterprise/actionfunction/VZB_INV_MOD_ENTERPRISE/test_VZB_INV_MOD_ENT3.json");
		OrderDomainServiceDTO dto = DomainInterfaceUtil.prepareResponseFromInputJsonFile(fileObj);

		when(orderDomainDataService.getOrderDomainData(any(OrderDomainServiceRequest.class))).thenReturn(dto);
		when(enterpriseHelper.getEnterprise(connection)).thenReturn(enterprise);
		when(enterprise.getRegionId()).thenReturn(Long.valueOf(VzbVoipEnum.RegionType.US));
		when(enterprise.addToDB()).thenReturn(Boolean.FALSE);
		when(connection.createStatement()).thenReturn(selStmt);
		when(selStmt.executeUpdate(any(String.class))).thenReturn(1);
		when(connection.prepareStatement(any(String.class))).thenReturn(pstmt);
		when(pstmt.executeQuery()).thenReturn(rs);
		 
		PowerMockito.whenNew(TblEnvOrderQuery.class).withNoArguments().thenReturn(tblEnvOrderQuery);
		PowerMockito.whenNew(TblEntBillFeaturesBean.class).withAnyArguments().thenReturn(tblEntBillFeaturesBean);
		
		obj.setEnvOrderId("1396815");
		
		int result = obj.go();
		assertEquals(result,2);
	}
	
	@Test
	public void testGoSQLException1() throws Exception {
		
		File fileObj = new File(
				"src/test/resources/com/vz/fxo/enterprise/actionfunction/VZB_INV_MOD_ENTERPRISE/test_VZB_INV_MOD_ENT6.json");
		OrderDomainServiceDTO dto = DomainInterfaceUtil.prepareResponseFromInputJsonFile(fileObj);

		when(orderDomainDataService.getOrderDomainData(any(OrderDomainServiceRequest.class))).thenReturn(dto);
		when(enterpriseHelper.getEnterprise(connection)).thenReturn(enterprise);
		when(enterprise.getRegionId()).thenReturn(Long.valueOf(VzbVoipEnum.RegionType.EMEA));
		when(enterprise.addToDB()).thenReturn(Boolean.TRUE);
		when(connection.createStatement()).thenReturn(selStmt);
		when(selStmt.executeUpdate(any(String.class))).thenReturn(1);
		when(selStmt.executeQuery(any(String.class))).thenReturn(rs); 
		PowerMockito.whenNew(TblEnvOrderQuery.class).withNoArguments().thenReturn(tblEnvOrderQuery);
		when(enterprise.updateTsoVampEntityMigForEnt(any(String.class), any(String.class), any(String.class))).thenReturn(Boolean.TRUE);
		when(enterprise.updateTblTsoEntityMigForEnt(any(String.class), any(String.class))).thenReturn(Boolean.TRUE);
		doNothing().when(enterprise).setVmPartitionId(any(String.class));
	//	doReturn(Boolean.TRUE).when(tblEnvOrderQuery.query(connection));
		PowerMockito.whenNew(Timestamp.class).withAnyArguments().thenReturn(timestamp);
	//	when(enterprise).setCatalogueReferenceTime(Timestamp.class);
		PowerMockito.whenNew(TblEnvOrderQuery.class).withNoArguments().thenReturn(tblEnvOrderQuery);
		//doNothing().when(enterprise).setEnvOrderId(any(Long.class));
			doThrow(new SQLException("SQLException","",-60)).when(connection).commit();
			doNothing().when(connection).rollback();
			obj.setEnvOrderId("1396815");
		int status = obj.go();
	assertEquals(status, 2);
	}
	@Test
	public void testGoSQLException2() throws Exception {
		
		File fileObj = new File(
				"src/test/resources/com/vz/fxo/enterprise/actionfunction/VZB_INV_MOD_ENTERPRISE/test_VZB_INV_MOD_ENT6.json");
		OrderDomainServiceDTO dto = DomainInterfaceUtil.prepareResponseFromInputJsonFile(fileObj);

		when(orderDomainDataService.getOrderDomainData(any(OrderDomainServiceRequest.class))).thenReturn(dto);
		when(enterpriseHelper.getEnterprise(connection)).thenReturn(enterprise);
		when(enterprise.getRegionId()).thenReturn(Long.valueOf(VzbVoipEnum.RegionType.EMEA));
		when(enterprise.addToDB()).thenReturn(Boolean.TRUE);
		when(connection.createStatement()).thenReturn(selStmt);
		when(selStmt.executeUpdate(any(String.class))).thenReturn(1);
		when(selStmt.executeQuery(any(String.class))).thenReturn(rs); 
		PowerMockito.whenNew(TblEnvOrderQuery.class).withNoArguments().thenReturn(tblEnvOrderQuery);
		when(enterprise.updateTsoVampEntityMigForEnt(any(String.class), any(String.class), any(String.class))).thenReturn(Boolean.TRUE);
		when(enterprise.updateTblTsoEntityMigForEnt(any(String.class), any(String.class))).thenReturn(Boolean.TRUE);
		doNothing().when(enterprise).setVmPartitionId(any(String.class));
	//	doReturn(Boolean.TRUE).when(tblEnvOrderQuery.query(connection));
		PowerMockito.whenNew(Timestamp.class).withAnyArguments().thenReturn(timestamp);
	//	when(enterprise).setCatalogueReferenceTime(Timestamp.class);
		PowerMockito.whenNew(TblEnvOrderQuery.class).withNoArguments().thenReturn(tblEnvOrderQuery);
		//doNothing().when(enterprise).setEnvOrderId(any(Long.class));
		
			doThrow(new SQLException("SQLException")).when(connection).commit();
			doThrow(new SQLException("SQLException")).when(connection).rollback();
			obj.setEnvOrderId("1396815");
		int status = obj.go();
	assertEquals(status, 2);
	}
	@Test
	public void testGoVZBException1() throws Exception {
		File fileObj = new File(
				"src/test/resources/com/vz/fxo/enterprise/actionfunction/VZB_INV_MOD_ENTERPRISE/test_VZB_INV_MOD_ENT2.json");
		OrderDomainServiceDTO dto = DomainInterfaceUtil.prepareResponseFromInputJsonFile(fileObj);

		when(orderDomainDataService.getOrderDomainData(any(OrderDomainServiceRequest.class))).thenReturn(dto);
		when(enterpriseHelper.getEnterprise(connection)).thenReturn(enterprise);
		when(enterprise.getRegionId()).thenReturn(Long.valueOf(VzbVoipEnum.RegionType.US));
		when(enterprise.addToDB()).thenReturn(Boolean.TRUE);
		when(connection.createStatement()).thenReturn(selStmt);
		when(selStmt.executeUpdate(any(String.class))).thenReturn(1);
		when(selStmt.executeQuery(any(String.class))).thenReturn(rs); 
		PowerMockito.whenNew(TblEnvOrderQuery.class).withNoArguments().thenReturn(tblEnvOrderQuery);
		when(enterprise.updateTsoVampEntityMigForEnt(any(String.class), any(String.class), any(String.class))).thenReturn(Boolean.FALSE);
		//when(enterprise.updateTblTsoEntityMigForEnt(any(String.class), any(String.class))).thenReturn(Boolean.TRUE);
		// when(tblEnvOrderQuery.size()).thenReturn(1);
		PowerMockito.whenNew(TblEnvOrderQuery.class).withNoArguments().thenReturn(tblEnvOrderQuery);
		obj.setEnvOrderId("1396815");
		
		int result = obj.go();
		assertEquals(result,2);
	}@Test
	public void testGoVZBException2() throws Exception {
		File fileObj = new File(
				"src/test/resources/com/vz/fxo/enterprise/actionfunction/VZB_INV_MOD_ENTERPRISE/test_VZB_INV_MOD_ENT2.json");
		OrderDomainServiceDTO dto = DomainInterfaceUtil.prepareResponseFromInputJsonFile(fileObj);

		when(orderDomainDataService.getOrderDomainData(any(OrderDomainServiceRequest.class))).thenReturn(dto);
		when(enterpriseHelper.getEnterprise(connection)).thenReturn(enterprise);
		when(enterprise.getRegionId()).thenReturn(Long.valueOf(VzbVoipEnum.RegionType.US));
		when(enterprise.addToDB()).thenReturn(Boolean.TRUE);
		when(connection.createStatement()).thenReturn(selStmt);
		when(selStmt.executeUpdate(any(String.class))).thenReturn(1);
		when(selStmt.executeQuery(any(String.class))).thenReturn(rs); 
		PowerMockito.whenNew(TblEnvOrderQuery.class).withNoArguments().thenReturn(tblEnvOrderQuery);
		when(enterprise.updateTsoVampEntityMigForEnt(any(String.class), any(String.class), any(String.class))).thenReturn(Boolean.TRUE);
		when(enterprise.updateTblTsoEntityMigForEnt(any(String.class), any(String.class))).thenReturn(Boolean.FALSE);
		// when(tblEnvOrderQuery.size()).thenReturn(1);
		PowerMockito.whenNew(TblEnvOrderQuery.class).withNoArguments().thenReturn(tblEnvOrderQuery);
		obj.setEnvOrderId("1396815");
		
		int result = obj.go();
		assertEquals(result,2);
	}
	@Test
	public void testGoException() throws Exception {
		File fileObj = new File(
				"src/test/resources/com/vz/fxo/enterprise/actionfunction/VZB_INV_MOD_ENTERPRISE/test_VZB_INV_MOD_ENT3.json");
		OrderDomainServiceDTO dto = DomainInterfaceUtil.prepareResponseFromInputJsonFile(fileObj);

		when(orderDomainDataService.getOrderDomainData(any(OrderDomainServiceRequest.class))).thenReturn(dto);
		when(enterpriseHelper.getEnterprise(connection)).thenReturn(enterprise);
		when(enterprise.getRegionId()).thenReturn(Long.valueOf(VzbVoipEnum.RegionType.US));
		when(enterprise.addToDB()).thenReturn(Boolean.TRUE);
		when(connection.createStatement()).thenReturn(selStmt);
		when(selStmt.executeUpdate(any(String.class))).thenReturn(1);
		when(selStmt.executeQuery(any(String.class))).thenReturn(rs); 
		when(connection.prepareStatement(any(String.class))).thenReturn(pstmt);
		when(pstmt.executeQuery()).thenReturn(rs);
		PowerMockito.whenNew(TblEnvOrderQuery.class).withNoArguments().thenReturn(tblEnvOrderQuery);
		doThrow(new Exception("DummyException")).when(enterprise).updateTsoVampEntityMigForEnt(any(String.class), any(String.class), any(String.class));
		doThrow(new SQLException("DummyException")).when(connection).rollback();
		//when(enterprise.updateTblTsoEntityMigForEnt(any(String.class), any(String.class))).thenReturn(Boolean.TRUE);
		obj.setEnvOrderId("1396815");
		
		int result = obj.go();
		assertEquals(result,2);
	}
	
	@Test
	public void testGoSuccess3DeptQuery() throws Exception {
		File fileObj = new File(
				"src/test/resources/com/vz/fxo/enterprise/actionfunction/VZB_INV_MOD_ENTERPRISE/test_VZB_INV_MOD_ENT3.json");
		OrderDomainServiceDTO dto = DomainInterfaceUtil.prepareResponseFromInputJsonFile(fileObj);

		when(orderDomainDataService.getOrderDomainData(any(OrderDomainServiceRequest.class))).thenReturn(dto);
		when(enterpriseHelper.getEnterprise(connection)).thenReturn(enterprise);
		when(enterprise.getRegionId()).thenReturn(Long.valueOf(VzbVoipEnum.RegionType.US));
		when(enterprise.addToDB()).thenReturn(Boolean.TRUE);
		when(connection.createStatement()).thenReturn(selStmt);
		when(selStmt.executeUpdate(any(String.class))).thenReturn(1);
		when(selStmt.executeQuery(any(String.class))).thenReturn(rs); 
		when(connection.prepareStatement(any(String.class))).thenReturn(pstmt);
		when(pstmt.executeQuery()).thenReturn(rs);
		PowerMockito.whenNew(TblEnvOrderQuery.class).withNoArguments().thenReturn(tblEnvOrderQuery);
		when(enterprise.updateTsoVampEntityMigForEnt(any(String.class), any(String.class), any(String.class))).thenReturn(Boolean.TRUE);
		when(enterprise.updateTblTsoEntityMigForEnt(any(String.class), any(String.class))).thenReturn(Boolean.TRUE);
		obj.setEnvOrderId("1396815");
		/*when(enterpriseHelper.getTblDepartmentQuery()).thenReturn(departmentQry);
		Mockito.doReturn(1).when(departmentQry).size();
		tblDepartmentDbBean.setCallingPlanId(100l);
		when(departmentQry.getDbBean(any(Integer.class))).thenReturn(tblDepartmentDbBean);*/
		PowerMockito.whenNew(TblDepartmentQuery.class).withNoArguments().thenReturn(departmentQry);
		when(departmentQry.size()).thenReturn(1);
		tblDepartmentDbBean.setCallingPlanId(100l);
		when(departmentQry.getDbBean(any(Integer.class))).thenReturn(tblDepartmentDbBean);
		
		CallingPlan callingPlanObj =mock(CallingPlan.class);
		PowerMockito.whenNew(CallingPlan.class).withAnyArguments().thenReturn(callingPlanObj);
		when(callingPlanObj.addDigitStringListToDb()).thenReturn(Boolean.TRUE);
		when(callingPlanObj.delDigitStringListFromDb()).thenReturn(Boolean.TRUE);
		
	//	digitStringDelList = getDigitStringList(entityBatch,"o", -1,connection);
		List<DigitStringBean> digitStringDelList= new ArrayList<DigitStringBean>();
		DigitStringBean digitStringBean = new DigitStringBean();
		digitStringBean.setDigitString("test");
		digitStringDelList.add(digitStringBean);
		PowerMockito.mockStatic(TNActionFunction.class);
		PowerMockito.when(TNActionFunction.getDigitStringList(Matchers.any(EntityBatch.class),Matchers.any(String.class),Matchers.any(Integer.class),Matchers.any(Connection.class))).thenReturn(digitStringDelList);
		
	//	DigitString digitStringObj = new DigitString(digitStringDelList.get(i), connection);
	//	digitStringObj.deleteDigitStringByDigitStringId()
		DigitString digitString = mock(DigitString.class);
		PowerMockito.whenNew(DigitString.class).withAnyArguments().thenReturn(digitString);
		when(digitString.deleteDigitStringByDigitStringId()).thenReturn(Boolean.TRUE);
		
		PowerMockito.mockStatic(EnterpriseActionFunctionHelper.class);
		PowerMockito.when(EnterpriseActionFunctionHelper.modifyAuthServicesForEnterprise(Matchers.any(Enterprise.class),Matchers.any(Connection.class),Matchers.anyInt())).thenReturn(Boolean.TRUE);
		
		int result = obj.go();
		assertEquals(result,2);
	}
	/*@Test
	public void testPopulateParentBestPoolValues(){
		try {
			when(connection.createStatement()).thenReturn(selStmt);
			when(connection.prepareStatement(any(String.class))).thenReturn(pstmt);
			when(selStmt.executeQuery(Matchers.any(String.class))).thenReturn(rs);
			
//			when(pstmt.executeQuery()).thenReturn(rs);
			when(rs.next()).thenReturn(true);
			obj.populateParentBestPoolValues(connection, "DUMMY", 1, 1);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}*/
	
	/*@Test
	public void testPopulateParentBestPoolValuesExc() throws SQLException {
		doThrow(new SQLException("DummyException")).when(connection).createStatement();
		obj.populateParentBestPoolValues(connection, "DUMMY", 1, 1);
	}
	
	@Test
	public void testPopulateTblEntParentMap() {
		try {
			when(connection.createStatement()).thenReturn(selStmt);
			when(selStmt.executeUpdate(any(String.class))).thenReturn(1);
			obj.populateTblEntParentMap(connection, "DUMMY","DUMMY", 1, 1);
			
			when(connection.createStatement()).thenReturn(selStmt);
			when(selStmt.executeUpdate(any(String.class))).thenReturn(0);
			obj.populateTblEntParentMap(connection, "DUMMY","DUMMY", 1, 1);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void testPopulateTblEntParentMapExc() throws SQLException {
		doThrow(new SQLException("DummyException")).when(connection).createStatement();
		obj.populateTblEntParentMap(connection, "DUMMY","DUMMY", 1, 1);
	}*/
	
/*	@Test
	public void testGoFailure() throws Exception {
		File fileObj = new File(
				"src/test/resources/com/vz/esap/inventory/enterprise/actionfunction/VZB_INV_DEL_ENTERPRISE/test_VZB_INV_DEL_ENT.json");
		OrderDomainServiceDTO dto = DomainInterfaceUtil.prepareResponseFromInputJsonFile(fileObj);

		when(orderDomainDataService.getOrderDomainData(any(OrderDomainServiceRequest.class))).thenReturn(dto);
		when(enterpriseHelper.getEnterprise(connection)).thenReturn(enterprise);
		doNothing().when(enterprise).setEnterpriseId(any(String.class));
		doNothing().when(enterprise).setCustomerId(any(String.class));
		doNothing().when(enterprise).setRollbackFlag(true);
		doNothing().when(enterprise).setEnvOrderId(any(Long.class));
		when(enterprise.deleteFromDB()).thenReturn(Boolean.FALSE);
		when(connection.prepareStatement(any(String.class))).thenReturn(pstmt);
		when(pstmt.executeQuery()).thenReturn(rs);
		
		obj.setEnvOrderId("123");
		
		int result = obj.go();
		assertEquals(result,-1);
	}
	
	@Test
	public void testGoException1() throws Exception {
		
		File fileObj = new File(
				"src/test/resources/com/vz/esap/inventory/enterprise/actionfunction/VZB_INV_DEL_ENTERPRISE/test_VZB_INV_DEL_ENT.json");
		OrderDomainServiceDTO dto = DomainInterfaceUtil.prepareResponseFromInputJsonFile(fileObj);
		when(orderDomainDataService.getOrderDomainData(any(OrderDomainServiceRequest.class))).thenReturn(dto);
		doNothing().when(connection).rollback();
		obj.setEnvOrderId("123");
		int status = obj.go();
	assertEquals(status, 2);
	}
	@Test
	public void testGoException2() throws Exception {
		
		File fileObj = new File(
				"src/test/resources/com/vz/esap/inventory/enterprise/actionfunction/VZB_INV_DEL_ENTERPRISE/test_VZB_INV_DEL_ENT.json");
		OrderDomainServiceDTO dto = DomainInterfaceUtil.prepareResponseFromInputJsonFile(fileObj);
		when(orderDomainDataService.getOrderDomainData(any(OrderDomainServiceRequest.class))).thenReturn(dto);
		doThrow(new SQLException("Exception")).when(connection).rollback();
		obj.setEnvOrderId("123");
		int status = obj.go();
	assertEquals(status, 2);
	}
	@Test
	public void testGoVZBException() throws Exception {
		
		File fileObj = new File(
				"src/test/resources/com/vz/esap/inventory/enterprise/actionfunction/VZB_INV_DEL_ENTERPRISE/test_VZB_INV_DEL_ENT.json");
		OrderDomainServiceDTO dto = DomainInterfaceUtil.prepareResponseFromInputJsonFile(fileObj);

		when(orderDomainDataService.getOrderDomainData(any(OrderDomainServiceRequest.class))).thenReturn(dto);
		when(enterpriseHelper.getEnterprise(connection)).thenReturn(enterprise);
		doNothing().when(enterprise).setEnterpriseId(any(String.class));
		doNothing().when(enterprise).setCustomerId(any(String.class));
		doNothing().when(enterprise).setRollbackFlag(true);
		doNothing().when(enterprise).setEnvOrderId(any(Long.class));
		when(enterprise.deleteFromDB()).thenReturn(Boolean.FALSE);
		when(connection.prepareStatement(any(String.class))).thenReturn(pstmt);
		when(pstmt.executeQuery()).thenReturn(rs);
		
		obj.setEnvOrderId("123");
			doThrow(new SQLException("SQLException")).when(connection).rollback();
						
		int status = obj.go();
	assertEquals(status, 2);
	}
	@Test
	public void testGoSQLException1() throws Exception {
		
		File fileObj = new File(
				"src/test/resources/com/vz/esap/inventory/enterprise/actionfunction/VZB_INV_DEL_ENTERPRISE/test_VZB_INV_DEL_ENT.json");
		OrderDomainServiceDTO dto = DomainInterfaceUtil.prepareResponseFromInputJsonFile(fileObj);

		when(orderDomainDataService.getOrderDomainData(any(OrderDomainServiceRequest.class))).thenReturn(dto);
		when(enterpriseHelper.getEnterprise(connection)).thenReturn(enterprise);
		doNothing().when(enterprise).setEnterpriseId(any(String.class));
		doNothing().when(enterprise).setCustomerId(any(String.class));
		doNothing().when(enterprise).setRollbackFlag(true);
		doNothing().when(enterprise).setEnvOrderId(any(Long.class));
		when(enterprise.deleteFromDB()).thenReturn(Boolean.TRUE);
		when(connection.prepareStatement(any(String.class))).thenReturn(pstmt);
		when(pstmt.executeQuery()).thenReturn(rs);
		
		
		obj.setEnvOrderId("123");
			doThrow(new SQLException("SQLException","",-60)).when(connection).commit();
			doNothing().when(connection).rollback();
		int status = obj.go();
	assertEquals(status, 2);
	}
	@Test
	public void testGoSQLException2() throws Exception {
		
		File fileObj = new File(
				"src/test/resources/com/vz/esap/inventory/enterprise/actionfunction/VZB_INV_DEL_ENTERPRISE/test_VZB_INV_DEL_ENT.json");
		OrderDomainServiceDTO dto = DomainInterfaceUtil.prepareResponseFromInputJsonFile(fileObj);

		when(orderDomainDataService.getOrderDomainData(any(OrderDomainServiceRequest.class))).thenReturn(dto);
		when(enterpriseHelper.getEnterprise(connection)).thenReturn(enterprise);
		doNothing().when(enterprise).setEnterpriseId(any(String.class));
		doNothing().when(enterprise).setCustomerId(any(String.class));
		doNothing().when(enterprise).setRollbackFlag(true);
		doNothing().when(enterprise).setEnvOrderId(any(Long.class));
		when(enterprise.deleteFromDB()).thenReturn(Boolean.TRUE);
		when(connection.prepareStatement(any(String.class))).thenReturn(pstmt);
		when(pstmt.executeQuery()).thenReturn(rs);
		
		
		obj.setEnvOrderId("123");
			doThrow(new SQLException("SQLException")).when(connection).commit();
			doThrow(new SQLException("SQLException")).when(connection).rollback();
		int status = obj.go();
	assertEquals(status, 2);
	}
	@Test
	public void testGoException3() throws Exception {
		File fileObj = new File(
				"src/test/resources/com/vz/esap/inventory/enterprise/actionfunction/VZB_INV_DEL_ENTERPRISE/test_VZB_INV_DEL_ENT.json");
		OrderDomainServiceDTO dto = DomainInterfaceUtil.prepareResponseFromInputJsonFile(fileObj);

		when(orderDomainDataService.getOrderDomainData(any(OrderDomainServiceRequest.class))).thenReturn(dto);
		when(enterpriseHelper.getEnterprise(connection)).thenReturn(enterprise);
		doNothing().when(enterprise).setEnterpriseId(any(String.class));
		doNothing().when(enterprise).setCustomerId(any(String.class));
		doNothing().when(enterprise).setRollbackFlag(true);
		doNothing().when(enterprise).setEnvOrderId(any(Long.class));
		when(enterprise.deleteFromDB()).thenReturn(Boolean.FALSE);
		when(connection.prepareStatement(any(String.class))).thenReturn(pstmt);
		when(pstmt.executeQuery()).thenReturn(rs);
	
		doNothing().when(connection).rollback();
		obj.setEnvOrderId("123");
		int result = obj.go();
		assertEquals(result,2);
	}
	@Test
	public void testGoSuccessNew() throws Exception {
		File fileObj = new File(
				"src/test/resources/com/vz/esap/inventory/enterprise/actionfunction/VZB_INV_DEL_ENTERPRISE/test_VZB_INV_DEL_ENT.json");
		OrderDomainServiceDTO dto = DomainInterfaceUtil.prepareResponseFromInputJsonFile(fileObj);

		when(orderDomainDataService.getOrderDomainData(any(OrderDomainServiceRequest.class))).thenReturn(dto);
		when(enterpriseHelper.getEnterprise(connection)).thenReturn(enterprise);
	
		when(enterprise.deleteFromDB()).thenReturn(Boolean.TRUE);
		
		
		obj.setEnvOrderId("123");
		
		int result = obj.go();
		assertEquals(result,-1);
	}
	@Test
	public void testGoSuccessNewException() throws Exception {
		File fileObj = new File(
				"src/test/resources/com/vz/esap/inventory/enterprise/actionfunction/VZB_INV_DEL_ENTERPRISE/test_VZB_INV_DEL_ENT.json");
		OrderDomainServiceDTO dto = DomainInterfaceUtil.prepareResponseFromInputJsonFile(fileObj);

		when(orderDomainDataService.getOrderDomainData(any(OrderDomainServiceRequest.class))).thenReturn(dto);
		when(enterpriseHelper.getEnterprise(connection)).thenReturn(enterprise);
	
		when(enterprise.deleteFromDB()).thenReturn(Boolean.TRUE);
		doThrow(new SQLException("SQLException")).when(connection).rollback();
		
		obj.setEnvOrderId("123");
		
		int result = obj.go();
		assertEquals(result,-1);
	}*/
}
