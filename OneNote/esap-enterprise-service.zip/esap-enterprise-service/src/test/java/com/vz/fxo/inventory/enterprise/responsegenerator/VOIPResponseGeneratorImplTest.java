package com.vz.fxo.inventory.enterprise.responsegenerator;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.beans.factory.annotation.Autowired;

import com.vz.fxo.inventory.enterprise.enums.EsapEnum.MileStone;
import com.vz.fxo.inventory.enterprise.enums.EsapEnum.StatusCode;
import com.vz.fxo.inventory.enterprise.support.Enterprise;
import com.vz.fxo.inventory.model.pc.VoipOrderResponse;
import com.vz.fxo.inventory.reponsegenerator.VOIPResponseGeneratorImpl;



@RunWith(PowerMockRunner.class)
@PowerMockIgnore("javax.management.*")
public class VOIPResponseGeneratorImplTest {
	
	@InjectMocks
	private VOIPResponseGeneratorImpl voipResponseGeneratorImpl;
	
	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);

	}
	
	@Test
	public void testpreparePCMilestoneSuccess() throws Exception {
		Enterprise enterprise = new Enterprise(null);
		
		MileStone milestone = MileStone.ENTERPRISE_INFO;
		StatusCode statusCode = StatusCode.ESP_SUCCESS;
		VoipOrderResponse success = voipResponseGeneratorImpl.preparePCMilestone(enterprise,123131313L,"242424","0", milestone, statusCode);
		assertEquals(statusCode.toString(), success.getOrderStatus().getStatusCode());
	}
	
	@Test
	public void testpreparePCMilestoneFailure() {
		Enterprise enterprise = null;
				
		MileStone milestone = MileStone.ENTERPRISE_INFO;
		StatusCode statusCode = StatusCode.ESP_FAILURE;
		try {
			VoipOrderResponse success = voipResponseGeneratorImpl.preparePCMilestone(enterprise,123131313L,"242424","0", milestone, statusCode);
		} catch(Exception ge) {
			//Expected
		}
		
	}

}
