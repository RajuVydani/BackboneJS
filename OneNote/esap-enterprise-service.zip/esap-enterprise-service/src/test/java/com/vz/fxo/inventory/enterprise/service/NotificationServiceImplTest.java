package com.vz.fxo.inventory.enterprise.service;

import static org.junit.Assert.assertEquals;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.IntegrationTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.web.WebAppConfiguration;

import com.vz.esap.api.model.ResponseObject;
import com.vz.fxo.inventory.enterprise.rest.RestClientImpl;
import com.vz.fxo.inventory.enterprise.support.VzbInvException;
import com.vz.fxo.inventory.model.pc.OrderHeader;
import com.vz.fxo.inventory.model.pc.VoipOrderResponse;



@RunWith(PowerMockRunner.class)
@PowerMockIgnore("javax.management.*")
public class NotificationServiceImplTest {
		
	@Mock
	RestClientImpl restClient;
	
	
	@InjectMocks
	private NotificationServiceImpl notificationServiceImpl;
	
	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);

	}
	
	@Test
	public void testnotifyFailures() throws Exception {
		OrderHeader orderHeader = new OrderHeader();
		orderHeader.setFunctionCode("VALI");
		
		VoipOrderResponse voipOrderResponse = new VoipOrderResponse();
		voipOrderResponse.setOrderHeader(orderHeader);
		
		ResponseObject resobj = new ResponseObject();
		resobj.setStatusCode(1);
		
		when(restClient.invokeService(
				any(Object.class),
				any(String.class),
				any(String.class),
				any(String.class),
				any(Class.class))).thenReturn(resobj);
		
		ResponseObject responseObj = notificationServiceImpl.notifyFailures(voipOrderResponse);
		assertEquals(1, responseObj.getStatusCode());
	}
	
	@Test
	public void testnotifyFailures2() throws Exception {
		OrderHeader orderHeader = new OrderHeader();
		orderHeader.setFunctionCode("VALIDATE");
		
		VoipOrderResponse voipOrderResponse = new VoipOrderResponse();
		voipOrderResponse.setOrderHeader(orderHeader);
		
		ResponseObject resobj = new ResponseObject();
		resobj.setStatusCode(1);
		
		when(restClient.invokeService(
				Matchers.any(Object.class),
				Matchers.any(String.class),
				Matchers.any(String.class),
				Matchers.any(String.class),
				Matchers.any(Class.class))).thenReturn(resobj);
		
		ResponseObject responseObj = notificationServiceImpl.notifyFailures(voipOrderResponse);
		assertEquals(1, responseObj.getStatusCode());
	}
	
	@Test
	public void testnotifyFailures3() throws Exception {
		
		
		VoipOrderResponse voipOrderResponse = new VoipOrderResponse();
		
		ResponseObject resobj = new ResponseObject();
		resobj.setStatusCode(1);
		
		when(restClient.invokeService(
				Matchers.any(Object.class),
				Matchers.any(String.class),
				Matchers.any(String.class),
				Matchers.any(String.class),
				Matchers.any(Class.class))).thenReturn(resobj);
		
		ResponseObject responseObj = notificationServiceImpl.notifyFailures(voipOrderResponse);
		assertEquals(1, responseObj.getStatusCode());
	}
	
	@SuppressWarnings("unchecked")
	@Test
	public void testnotifyFailuresFailure() {
		
		
		VoipOrderResponse voipOrderResponse = new VoipOrderResponse();
		
		ResponseObject resobj = new ResponseObject();
		resobj.setStatusCode(1);
		
		try {
			when(restClient.invokeService(
					Matchers.any(Object.class),
					Matchers.any(String.class),
					Matchers.any(String.class),
					Matchers.any(String.class),
					Matchers.any(Class.class))).thenThrow(VzbInvException.class);
		notificationServiceImpl.notifyFailures(voipOrderResponse);
		} catch(Exception e) {
			//Do Nothing
		}
		
	}
	
	@Test
	public void testnotifySuccess() throws Exception {
		OrderHeader orderHeader = new OrderHeader();
		orderHeader.setFunctionCode("REL");
		
		VoipOrderResponse voipOrderResponse = new VoipOrderResponse();
		voipOrderResponse.setOrderHeader(orderHeader);
		
		ResponseObject resobj = new ResponseObject();
		resobj.setStatusCode(1);
		
		when(restClient.invokeService(
				Matchers.any(Object.class),
				Matchers.any(String.class),
				Matchers.any(String.class),
				Matchers.any(String.class),
				Matchers.any(Class.class))).thenReturn(resobj);
		
		ResponseObject responseObj = notificationServiceImpl.notifySuccess(voipOrderResponse);
		assertEquals(1, responseObj.getStatusCode());
	}
	
	@Test
	public void testnotifySuccess2() throws Exception {
		OrderHeader orderHeader = new OrderHeader();
		orderHeader.setFunctionCode("RELEASE");
		
		VoipOrderResponse voipOrderResponse = new VoipOrderResponse();
		voipOrderResponse.setOrderHeader(orderHeader);
		
		ResponseObject resobj = new ResponseObject();
		resobj.setStatusCode(1);
		
		when(restClient.invokeService(
				Matchers.any(Object.class),
				Matchers.any(String.class),
				Matchers.any(String.class),
				Matchers.any(String.class),
				Matchers.any(Class.class))).thenReturn(resobj);
		
		ResponseObject responseObj = notificationServiceImpl.notifySuccess(voipOrderResponse);
		assertEquals(1, responseObj.getStatusCode());
	}
	
	@Test
	public void testnotifySuccess3() throws Exception {
		
		
		VoipOrderResponse voipOrderResponse = new VoipOrderResponse();
		
		ResponseObject resobj = new ResponseObject();
		resobj.setStatusCode(1);
		
		when(restClient.invokeService(
				Matchers.any(Object.class),
				Matchers.any(String.class),
				Matchers.any(String.class),
				Matchers.any(String.class),
				Matchers.any(Class.class))).thenReturn(resobj);
		
		ResponseObject responseObj = notificationServiceImpl.notifySuccess(voipOrderResponse);
		assertEquals(1, responseObj.getStatusCode());
	}
	
	@SuppressWarnings("unchecked")
	@Test
	public void testnotifySuccessFailure() {
		
		
		VoipOrderResponse voipOrderResponse = new VoipOrderResponse();
		
		ResponseObject resobj = new ResponseObject();
		resobj.setStatusCode(1);
		
		try {
			when(restClient.invokeService(
					Matchers.any(Object.class),
					Matchers.any(String.class),
					Matchers.any(String.class),
					Matchers.any(String.class),
					Matchers.any(Class.class))).thenThrow(VzbInvException.class);
		notificationServiceImpl.notifySuccess(voipOrderResponse);
		} catch(Exception e) {
			//Do Nothing
		}
		
	}

}
