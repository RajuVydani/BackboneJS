package com.vz.fxo;

public class INVENTORYConstants {
	
	/*** begin common constants **/
	public static final String WORK_ORDER_NUMBER = "USE2EIPBX00007603081339";
	public static final String CLLI_CODE = "RIVDITBSF01";
	public static final String WORK_ORDER_NUMBER_VERSION = "0";
	public static final String LOOP_BACK_ON = "2";
	public static final String ENV_ORDER_ID = "12345";
	/*** end common constants **/

}
