package com.vz.fxo.inventory.enterprise.controller;

import static org.junit.Assert.assertEquals;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.setup.MockMvcBuilders.webAppContextSetup;

import java.io.IOException;
import java.nio.charset.Charset;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.IntegrationTest;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.web.context.WebApplicationContext;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.vz.esap.api.model.InventoryServiceRequest;
import com.vz.fxo.INVENTORYConstants;
import com.vz.fxo.inventory.enterprise.model.ResponseObject;
import com.vz.fxo.inventory.enterprise.service.InventoryFxoEnterpriseServiceImpl;


import org.powermock.modules.junit4.PowerMockRunner;

//@ActiveProfiles("development")
//@RunWith(SpringJUnit4ClassRunner.class)
//@SpringApplicationConfiguration(classes = InventoryTNActivationServiceApplication.class)
//@WebAppConfiguration
//@IntegrationTest("server.port:0")
@RunWith(PowerMockRunner.class)
public class InventoryFxoEnterpriseServiceControllerTest {
	
	/*@Autowired
	private WebApplicationContext webApplicationContext;*/

	private MediaType contentType = new MediaType(MediaType.APPLICATION_JSON.getType(),
			MediaType.APPLICATION_JSON.getSubtype(), Charset.forName("utf8"));

	private MockMvc mockMvc;
	
	@Mock
	InventoryFxoEnterpriseServiceImpl inventoryFxoEnterpriseServiceImpl;
	
	@Mock
	ResponseObject responseObject;
	
	@InjectMocks
	InventoryFxoEnterpriseServiceController inventoryFxoEnterpriseServiceController;
	
	@Before
	public void setUp() throws Exception {
		 MockitoAnnotations.initMocks(this);		
	}

	@Test
	public void testAddEnt() throws IOException, Exception {

		//this.mockMvc = webAppContextSetup(webApplicationContext).build();
		InventoryServiceRequest bsServiceRequest = new InventoryServiceRequest();
		bsServiceRequest.setEnvOrderId(INVENTORYConstants.ENV_ORDER_ID);
		bsServiceRequest.setWorkOrderNumber(INVENTORYConstants.WORK_ORDER_NUMBER);
		bsServiceRequest.setWorkOrderNumberVersion(INVENTORYConstants.WORK_ORDER_NUMBER_VERSION);
		bsServiceRequest.setClliCode(INVENTORYConstants.CLLI_CODE);
//		bsServiceRequest.setOrderNumber(INVENTORYConstants.ORDER_NUMBER);

		bsServiceRequest.setLoopBackOn(INVENTORYConstants.LOOP_BACK_ON);

	/*	mockMvc.perform(post("/inventory/fxo/enterprise/addEnt").content(this.json(bsServiceRequest)).contentType(contentType))
				.andExpect(status().isOk());*/
		Mockito.when(inventoryFxoEnterpriseServiceImpl.addEnt(bsServiceRequest)).thenReturn(ResponseObject.SUCCESS);
		ResponseObject object = inventoryFxoEnterpriseServiceController.addEnt(bsServiceRequest);
		assertEquals(ResponseObject.SUCCESS, object.getStatusCode());
		
		Mockito.when(inventoryFxoEnterpriseServiceImpl.addEnt(bsServiceRequest)).thenReturn(ResponseObject.FAILURE);
		object = inventoryFxoEnterpriseServiceController.addEnt(bsServiceRequest);
		assertEquals(ResponseObject.FAILURE, object.getStatusCode());
	}
	
	@Test
	public void testModify() throws IOException, Exception {

		//this.mockMvc = webAppContextSetup(webApplicationContext).build();
		InventoryServiceRequest bsServiceRequest = new InventoryServiceRequest();
		bsServiceRequest.setEnvOrderId(INVENTORYConstants.ENV_ORDER_ID);
		bsServiceRequest.setWorkOrderNumber(INVENTORYConstants.WORK_ORDER_NUMBER);
		bsServiceRequest.setWorkOrderNumberVersion(INVENTORYConstants.WORK_ORDER_NUMBER_VERSION);
		bsServiceRequest.setClliCode(INVENTORYConstants.CLLI_CODE);		

		bsServiceRequest.setLoopBackOn(INVENTORYConstants.LOOP_BACK_ON);
		Mockito.when(inventoryFxoEnterpriseServiceImpl.modify(bsServiceRequest)).thenReturn(ResponseObject.SUCCESS);
		inventoryFxoEnterpriseServiceController.modify(bsServiceRequest);
		Mockito.when(inventoryFxoEnterpriseServiceImpl.modify(bsServiceRequest)).thenReturn(ResponseObject.FAILURE);
		inventoryFxoEnterpriseServiceController.modify(bsServiceRequest);
	}
	

	
	@Test
	public void testDelEnterprise() throws IOException, Exception {

		//this.mockMvc = webAppContextSetup(webApplicationContext).build();
		InventoryServiceRequest bsServiceRequest = new InventoryServiceRequest();
		bsServiceRequest.setEnvOrderId(INVENTORYConstants.ENV_ORDER_ID);
		bsServiceRequest.setWorkOrderNumber(INVENTORYConstants.WORK_ORDER_NUMBER);
		bsServiceRequest.setWorkOrderNumberVersion(INVENTORYConstants.WORK_ORDER_NUMBER_VERSION);
		bsServiceRequest.setClliCode(INVENTORYConstants.CLLI_CODE);		

		bsServiceRequest.setLoopBackOn(INVENTORYConstants.LOOP_BACK_ON);

		Mockito.when(inventoryFxoEnterpriseServiceImpl.del(bsServiceRequest)).thenReturn(ResponseObject.SUCCESS);
		inventoryFxoEnterpriseServiceController.delEnterprise(bsServiceRequest);
		Mockito.when(inventoryFxoEnterpriseServiceImpl.del(bsServiceRequest)).thenReturn(ResponseObject.FAILURE);
		inventoryFxoEnterpriseServiceController.delEnterprise(bsServiceRequest);
	}
	
	@SuppressWarnings("unchecked")
	protected String json(Object o) throws IOException {
		ObjectMapper mapper = new ObjectMapper();
		String jsonInString = mapper.writeValueAsString(o);
		return jsonInString;
	}
}

