package com.vz.fxo.inventory.enterprise.service;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
//import org.powermock.modules.agent.PowerMockAgent;
import org.powermock.modules.junit4.PowerMockRunner;
//import org.powermock.modules.junit4.rule.PowerMockRule;

import com.mchange.v2.c3p0.ComboPooledDataSource;
import com.vz.esap.api.connector.service.impl.ConfigDomainDataServiceImpl;
import com.vz.esap.api.connector.service.impl.InventoryDomainDataServiceImpl;
import com.vz.esap.api.connector.service.impl.OrderDomainDataServiceImpl;
import com.vz.esap.api.connector.service.impl.OrderLogServiceImpl;
import com.vz.esap.api.model.InventoryServiceRequest;
import com.vz.fxo.INVENTORYConstants;
import com.vz.fxo.inventory.enterprise.model.ResponseObject;
//import com.vz.fxo.inventory.enterprise.actionfunction.VZB_INV_MOD_ENTERPRISE_FXO;
import com.vz.fxo.inventory.enterprise.support.Enterprise;
import com.vz.fxo.inventory.enterprise.actionfunction.VZB_INV_ADD_ENTERPRISE_FXO;
import com.vz.fxo.inventory.enterprise.actionfunction.VZB_INV_DEL_ENTERPRISE_FXO;
import com.vz.fxo.inventory.enterprise.actionfunction.VZB_INV_MOD_ENTERPRISE_FXO;
//import com.vz.fxo.inventory.enterprise.actionfunction.VZB_INV_DEL_ENTERPRISE_FXO;
import com.vz.fxo.inventory.enterprise.service.ActionFunctionHelper;
import com.vz.fxo.inventory.enterprise.service.InventoryFxoEnterpriseServiceImpl;
import com.vz.fxo.inventory.enterprise.GenericActionFunction;
import com.vz.fxo.inventory.enterprise.helper.FxoInventoryErrorEntityMgmtHelper;
import com.vz.fxo.inventory.enterprise.helper.FxoServiceHelper;

import esap.db.TblEnvOrderQuery;

@RunWith(PowerMockRunner.class)
@PrepareForTest({ComboPooledDataSource.class, GenericActionFunction.class})
@PowerMockIgnore("javax.management.*")
public class InventoryFxoEnterpriseServiceImplTest {
	
@Mock
Connection connection;
@Mock
ComboPooledDataSource comboPooledDataSource;
@Mock
OrderDomainDataServiceImpl orderDomainDataService;
@Mock
ConfigDomainDataServiceImpl configDomainDataServiceImpl;
@Mock
FxoInventoryErrorEntityMgmtHelper FxoInventoryErrorEntityMgmtHelper;
@Mock
OrderLogServiceImpl OrderLogServiceImpl;
@Mock
InventoryDomainDataServiceImpl inventoryDomainDataService;
@Mock
FxoServiceHelper fxoServiceHelper;

@Mock
PreparedStatement pstmt;

@Mock
Statement selStmt;

@Mock
ResultSet rs;

@Mock
Enterprise enterprise;

@Mock
TblEnvOrderQuery tblEnvOrderQuery;

@Mock
GenericActionFunction obj;

@Mock
ActionFunctionHelper afHelper;

@InjectMocks
InventoryFxoEnterpriseServiceImpl inventoryFxoEnterpriseServiceImpl = new InventoryFxoEnterpriseServiceImpl();

@Mock
VZB_INV_MOD_ENTERPRISE_FXO obj1;

@Mock
VZB_INV_ADD_ENTERPRISE_FXO obj2;

@Mock
VZB_INV_DEL_ENTERPRISE_FXO obj3;



	@Before
	public void initializeTests() {	
		MockitoAnnotations.initMocks(this);
	}
	
	private InventoryServiceRequest prepareRequest() {
		InventoryServiceRequest inventoryServiceRequest = new InventoryServiceRequest();
		inventoryServiceRequest.setEnvOrderId(INVENTORYConstants.ENV_ORDER_ID);
		inventoryServiceRequest.setWorkOrderNumber(INVENTORYConstants.WORK_ORDER_NUMBER);
		inventoryServiceRequest.setWorkOrderNumberVersion(INVENTORYConstants.WORK_ORDER_NUMBER_VERSION);
		inventoryServiceRequest.setClliCode(INVENTORYConstants.CLLI_CODE);
		return inventoryServiceRequest;
	}
	
	@Test
	public void testAddEnt() throws Exception{
	 when(obj.doTask(true)).thenReturn(ResponseObject.SUCCESS);
	 when(obj2.getConnection()).thenReturn(connection);	 
	 int result = inventoryFxoEnterpriseServiceImpl.addEnt(prepareRequest());
	 
	}
	
	@Test
	public void testAddEntSQLException() throws Exception{
	try {
		 InventoryFxoEnterpriseServiceImpl spyInventoryFxoEnterpriseServiceImpl = Mockito.spy(inventoryFxoEnterpriseServiceImpl);
		 Mockito.doReturn(obj).when(spyInventoryFxoEnterpriseServiceImpl).getActionFunctionImpl(Matchers.anyObject(), Matchers.any(InventoryServiceRequest.class));
		 Mockito.doThrow(SQLException.class).when(obj).doTask(true);
		 when(obj.getConnection()).thenReturn(connection);
		 spyInventoryFxoEnterpriseServiceImpl.addEnt(prepareRequest());
	} catch(Exception e) {
	  e.printStackTrace();
	}
	}
	
	@Test
	public void testAddEntSQLExceptionFinally() throws Exception{
	try {
		 InventoryFxoEnterpriseServiceImpl spyInventoryFxoEnterpriseServiceImpl = Mockito.spy(inventoryFxoEnterpriseServiceImpl);
		 Mockito.doReturn(obj).when(spyInventoryFxoEnterpriseServiceImpl).getActionFunctionImpl(Matchers.anyObject(), Matchers.any(InventoryServiceRequest.class));
		 Mockito.doThrow(SQLException.class).when(obj).doTask(true);
		 when(obj.getConnection()).thenReturn(connection);
		 Mockito.doThrow(SQLException.class).when(connection).close();
		 spyInventoryFxoEnterpriseServiceImpl.addEnt(prepareRequest());
	} catch(Exception e) {
	  e.printStackTrace();
	}
	}
	
	
	@Test
	public void testModify() throws Exception{
	 when(obj.doTask(true)).thenReturn(ResponseObject.SUCCESS);
	 when(obj2.getConnection()).thenReturn(connection);	 
	 int result = inventoryFxoEnterpriseServiceImpl.modify(prepareRequest());
	 
	}
	
	@Test
	public void testModifySQLException() throws Exception{
	try {
		 InventoryFxoEnterpriseServiceImpl spyInventoryFxoEnterpriseServiceImpl = Mockito.spy(inventoryFxoEnterpriseServiceImpl);
		 Mockito.doReturn(obj).when(spyInventoryFxoEnterpriseServiceImpl).getActionFunctionImpl(Matchers.anyObject(), Matchers.any(InventoryServiceRequest.class));
		 Mockito.doThrow(SQLException.class).when(obj).doTask(true);
		 when(obj.getConnection()).thenReturn(connection);
		 spyInventoryFxoEnterpriseServiceImpl.modify(prepareRequest());
	} catch(Exception e) {
	  e.printStackTrace();
	}
	}
	
	@Test
	public void testModifySQLExceptionFinally() throws Exception{
	try {
		 InventoryFxoEnterpriseServiceImpl spyInventoryFxoEnterpriseServiceImpl = Mockito.spy(inventoryFxoEnterpriseServiceImpl);
		 Mockito.doReturn(obj).when(spyInventoryFxoEnterpriseServiceImpl).getActionFunctionImpl(Matchers.anyObject(), Matchers.any(InventoryServiceRequest.class));
		 Mockito.doThrow(SQLException.class).when(obj).doTask(true);
		 when(obj.getConnection()).thenReturn(connection);
		 Mockito.doThrow(SQLException.class).when(connection).close();
		 spyInventoryFxoEnterpriseServiceImpl.modify(prepareRequest());
	} catch(Exception e) {
	  e.printStackTrace();
	}
	}
	
	@Test
	public void testDel() throws Exception{
	 when(obj.doTask(true)).thenReturn(ResponseObject.SUCCESS);
	 when(obj2.getConnection()).thenReturn(connection);	 
	 int result = inventoryFxoEnterpriseServiceImpl.del(prepareRequest());
	 
	}
	
	@Test
	public void testDelSQLException() throws Exception{
	try {
		 InventoryFxoEnterpriseServiceImpl spyInventoryFxoEnterpriseServiceImpl = Mockito.spy(inventoryFxoEnterpriseServiceImpl);
		 Mockito.doReturn(obj).when(spyInventoryFxoEnterpriseServiceImpl).getActionFunctionImpl(Matchers.anyObject(), Matchers.any(InventoryServiceRequest.class));
		 Mockito.doThrow(SQLException.class).when(obj).doTask(true);
		 when(obj.getConnection()).thenReturn(connection);
		 spyInventoryFxoEnterpriseServiceImpl.del(prepareRequest());
	} catch(Exception e) {
	  e.printStackTrace();
	}
	}
	
	@Test
	public void testDelSQLExceptionFinally() throws Exception{
	try {
		 InventoryFxoEnterpriseServiceImpl spyInventoryFxoEnterpriseServiceImpl = Mockito.spy(inventoryFxoEnterpriseServiceImpl);
		 Mockito.doReturn(obj).when(spyInventoryFxoEnterpriseServiceImpl).getActionFunctionImpl(Matchers.anyObject(), Matchers.any(InventoryServiceRequest.class));
		 Mockito.doThrow(SQLException.class).when(obj).doTask(true);
		 when(obj.getConnection()).thenReturn(connection);
		 Mockito.doThrow(SQLException.class).when(connection).close();
		 spyInventoryFxoEnterpriseServiceImpl.del(prepareRequest());
	} catch(Exception e) {
	  e.printStackTrace();
	}
	}
	
	@Test
	public void testAddEntSQLExceptionFinallyNullObj() throws Exception{
	try {
		 InventoryFxoEnterpriseServiceImpl spyInventoryFxoEnterpriseServiceImpl = Mockito.spy(inventoryFxoEnterpriseServiceImpl);
		 Mockito.doReturn(null).when(spyInventoryFxoEnterpriseServiceImpl).getActionFunctionImpl(Matchers.anyObject(), Matchers.any(InventoryServiceRequest.class));
		 Mockito.doThrow(SQLException.class).when(obj).doTask(true);
		 when(obj.getConnection()).thenReturn(connection);
		 Mockito.doThrow(SQLException.class).when(connection).close();
		 spyInventoryFxoEnterpriseServiceImpl.addEnt(prepareRequest());
	} catch(Exception e) {
	  e.printStackTrace();
	}
	}
	
	@Test
	public void testModifySQLExceptionFinallyNullObj() throws Exception{
	try {
		 InventoryFxoEnterpriseServiceImpl spyInventoryFxoEnterpriseServiceImpl = Mockito.spy(inventoryFxoEnterpriseServiceImpl);
		 Mockito.doReturn(null).when(spyInventoryFxoEnterpriseServiceImpl).getActionFunctionImpl(Matchers.anyObject(), Matchers.any(InventoryServiceRequest.class));
		 Mockito.doThrow(SQLException.class).when(obj).doTask(true);
		 when(obj.getConnection()).thenReturn(connection);
		 Mockito.doThrow(SQLException.class).when(connection).close();
		 spyInventoryFxoEnterpriseServiceImpl.modify(prepareRequest());
	} catch(Exception e) {
	  e.printStackTrace();
	}
	}
	
	@Test
	public void testDelSQLExceptionFinallyNullObj() throws Exception{
	try {
		 InventoryFxoEnterpriseServiceImpl spyInventoryFxoEnterpriseServiceImpl = Mockito.spy(inventoryFxoEnterpriseServiceImpl);
		 Mockito.doReturn(null).when(spyInventoryFxoEnterpriseServiceImpl).getActionFunctionImpl(Matchers.anyObject(), Matchers.any(InventoryServiceRequest.class));
		 Mockito.doThrow(SQLException.class).when(obj).doTask(true);
		 when(obj.getConnection()).thenReturn(connection);
		 Mockito.doThrow(SQLException.class).when(connection).close();
		 spyInventoryFxoEnterpriseServiceImpl.del(prepareRequest());
	} catch(Exception e) {
	  e.printStackTrace();
	}
	}
}

