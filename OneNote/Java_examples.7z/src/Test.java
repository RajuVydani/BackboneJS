import java.util.Arrays;

public class Test {

	public static void main(String[] args) {
		
		String [] data = {"one", "two"};
		
		System.out.println("size before::" + data.length);
		data = Arrays.copyOf(data, data.length + 2);
		System.out.println("size after::" + data.length);
		
		data[data.length-2] = "three";
		data[data.length-1] = "four";
		
		Arrays.stream(data).forEach(str -> System.out.println("Data::" + str));
		
		
	}

}
