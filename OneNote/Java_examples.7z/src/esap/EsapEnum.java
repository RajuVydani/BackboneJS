package esap;

import java.util.HashMap;
import java.util.Map;

public abstract class EsapEnum {

	public enum StatusCode {
		ESP_FAILURE("ESP_FAILURE"), ESP_SUCCESS("ESP_SUCCESS"), UNKNOWN("UNKNOWN"), 
		ESP_MILESTONE_SUCCESS("ESP_MILESTONE_SUCCESS"), ESP_MILESTONE_FAILURE("ESP_MILESTONE_FAILURE"),
		LOC_ACTIVE("LOC_ACTIVE"), LOC_INACTIVE("LOC_INACTIVE"), LOC_PENDING("LOC_PENDING");

		private String statusCode;

		StatusCode(String statusCode) {
			this.statusCode = statusCode;
		}

		public String getValue() {
			return statusCode;
		}

		public String toString() {
			return statusCode;
		}

		public static StatusCode getStatusCode(String statusCode) {
			for (StatusCode value : StatusCode.values()) {
				if (value.toString().equals(statusCode))
					return value;
			}

			return null;
		}
	}

	public static enum MileStone {
		ESAP_MISSING_REQUIRED_DATA("ESAP_MISSING_REQUIRED_DATA"), ESAP_DATA_ALREADY_EXISTS(
				"ESAP_DATA_ALREADY_EXISTS"), UNKNOWN("UNKNOWN"), WO_COMPLETE("COMPLETE")
		, VALIDATE_ORDER_WITH_ESAP("VALIDATE_ORDER"), RELEASE_ORDER_WITH_ESAP("ORDER_RELEASE")
		, IP_VLAN_INFO_WITH_LOGICAL("IP_VLAN_ACK"); 
		// Add more Status from WorkOrderEnum.data

		private String mileStone;

		MileStone(String mileStone) {
			this.mileStone = mileStone;
		}

		public String getValue() {
			return mileStone;
		}

		public String toString() {
			return mileStone;
		}

		public static MileStone getMileStone(String mileStone) {
			for (MileStone value : MileStone.values()) {
				if (value.toString().equals(mileStone))
					return value;
			}

			return null;
		}

	}

	public static class OrderType {
		private static HashMap<String, String> orderTypeMap = new HashMap<String, String>();
		private static HashMap<String, String> orderTypeReverseMap = new HashMap<String, String>();
		static {
			orderTypeMap.put("I", "IN");
			orderTypeMap.put("O", "OUT");
			orderTypeMap.put("C", "CHANGE");
			orderTypeMap.put("S", "SUSPEND");
			orderTypeMap.put("R", "RELEASE");
			
			orderTypeReverseMap.put("IN", "I");
			orderTypeReverseMap.put("OUT", "O");
			orderTypeReverseMap.put("CHANGE", "C");
			orderTypeReverseMap.put("SUSPEND", "S");
			orderTypeReverseMap.put("RELEASE", "R");
			orderTypeReverseMap.put("DISCONNECT", "D");
		}

		public static String getValue(char key) {
			return orderTypeMap.get(key + "") != null ? orderTypeMap.get(key + "") : "UNKNOWN";
		}
		public static String getValueReverse(String key) {
			return orderTypeReverseMap.get(key + "") != null ? orderTypeReverseMap.get(key + "") : "UNKNOWN";
		}
	}

	public static class ClliType {
		private static HashMap<String, String> clliTypeMap = new HashMap<String, String>();
		static {
			clliTypeMap.put("VZB_INV_VALIDATE_E2EI_ORDER", "INV_CLLI");
			clliTypeMap.put("VZB_CSSOP_VEC_VALIDATE", "CSSOP_CLLI");
			clliTypeMap.put("VZB_IASA_VALIDATE_E2EI_ORDER", "IASA_CLLI");			
			clliTypeMap.put("VZB_VPLAN_QRY_DESIGN_INFO_FXO", 	"VPLAN_CLLI");
			clliTypeMap.put("VZB_INV_ADD_ENTERPRISE_FXO", 	"INV_CLLI");
			clliTypeMap.put("VZB_BS_ADD_ENTERPRISE_FXO", 	"BS_CLLI");
			clliTypeMap.put("VZB_NS_ADD_ENTERPRISE_CONFIG_FXO", 	"BS_CLLI");
			clliTypeMap.put("VZB_IPRO_QRY_LOC_TRUNK_CLLI_FXO", 	"IPRO_CLLI");
			clliTypeMap.put("VZB_INV_ADD_LOCATION_FXO", 	"INV_CLLI");
			clliTypeMap.put("VZB_BS_ADD_LOCATION_FXO", 	"BS_CLLI");
			clliTypeMap.put("VZB_VM_ADD_LOC_MAILBOXES_FXO", 	"BS_CLLI");
			clliTypeMap.put("VZB_INV_ADD_2W_DEVICE_FXO", 	"INV_CLLI");
			clliTypeMap.put("VZB_BS_CREATE_DEVICE_2W_20",	"BS_CLLI");
			clliTypeMap.put("VZB_INV_ADD_IB_DEVICE_FXO", 	"INV_CLLI");
			clliTypeMap.put("VZB_BS_CREATE_DEVICE_IB_20",	"BS_CLLI");
			clliTypeMap.put("VZB_INV_ADD_2W_GROUP_FXO", 	"INV_CLLI");
			clliTypeMap.put("VZB_BS_ADD_2W_GROUP_FXO", 	"BS_CLLI");
			clliTypeMap.put("VZB_INV_ADD_IB_GROUP_FXO", 	"INV_CLLI");
			clliTypeMap.put("VZB_BS_ADD_IB_GROUP_FXO", 	"BS_CLLI");
			clliTypeMap.put("VZB_INV_ADD_ENTERPRISE_TRUNK_2W_FXO", 	"INV_CLLI");
			clliTypeMap.put("VZB_BS_ADD_ENTERPRISE_TRUNK_2W_FXO", 	"BS_CLLI");
			clliTypeMap.put("VZB_INV_ADD_ENTERPRISE_TRUNK_IB_FXO", 	"INV_CLLI");
			clliTypeMap.put("VZB_BS_ADD_ENTERPRISE_TRUNK_IB_FXO", 	"BS_CLLI");
			clliTypeMap.put("VZB_ESAP_INPUT_NBS_DATA",	"ESAP_CLLI");
			clliTypeMap.put("VZB_INV_ADD_SONUS_NBS_2W_FXO", 	"INV_CLLI");
			clliTypeMap.put("VZB_SONUS_GSX_ADD_2W_GROUP_FXO", 	"INV_CLLI");
			clliTypeMap.put("VZB_SONUS_PSX_ADD_2W_GROUP_FXO", 	"INV_CLLI");
			clliTypeMap.put("VZB_INV_ADD_SONUS_NBS_IB_FXO", 	"INV_CLLI");
			clliTypeMap.put("VZB_SONUS_GSX_ADD_IB_GROUP_FXO", 	"INV_CLLI");
			clliTypeMap.put("VZB_SONUS_PSX_ADD_IB_GROUP_FXO", 	"INV_CLLI");
			clliTypeMap.put("VZB_FXOPORTAL_ADD_ESL", 	"CSSOP_CLLI");	
			clliTypeMap.put("VZB_IPRO_QRY_TRUNK_CLLI", 	"IPRO_CLLI");
			clliTypeMap.put("VZB_INV_ADD_ET_TN", 	"INV_CLLI");
			clliTypeMap.put("VZB_VM_ADD_MAILBOX", 	"VM_CLLI");
			clliTypeMap.put("VZB_BS_ADD_ET_TN", 	"BS_CLLI");
			clliTypeMap.put("VZB_DMS_ADD_TN", 	"DMS_CLLI");
			clliTypeMap.put("VZB_IASA_ADD_ET_TN", 	"IASA_CLLI");
			clliTypeMap.put("VZB_CSSOP_TSO_MIG_TN", 	"CSSOP_CLLI");
			clliTypeMap.put("VZB_GCM_ADD_ET_TN", 	"GCM_CLLI");
			clliTypeMap.put("VZB_PC_COMPLETE_MIGRATION", 	"PC_CLLI");
			clliTypeMap.put("VZB_ESAP_AUTO_TASK_2W_TN_FXO", 	"ESAP_CLLI");
			clliTypeMap.put("VZB_ESAP_AUTO_TASK_IB_TN_FXO", 	"ESAP_CLLI");			
			clliTypeMap.put("VZB_INV_ADD_SYSTEM_UPDATE_2W_TN_FXO", 	"INV_CLLI");
			clliTypeMap.put("VZB_BS_BULK_ADD_2W_TN_SYSTEM_UPDATE_20", 	"BS_CLLI");
			clliTypeMap.put("VZB_BS_CHAIN_ADD_2W_TN_SYSTEM_UPDATE_20", 	"BS_CLLI");
			clliTypeMap.put("VZB_BS_ACT_2W_TN_SYSTEM_UPDATE_20", 	"BS_CLLI");			
			clliTypeMap.put("VZB_INV_ADD_SYSTEM_UPDATE_IB_TN_FXO", 	"INV_CLLI");
			clliTypeMap.put("VZB_BS_BULK_ADD_IB_TN_SYSTEM_UPDATE_20", 	"BS_CLLI");
			clliTypeMap.put("VZB_BS_CHAIN_ADD_IB_TN_SYSTEM_UPDATE_20", 	"BS_CLLI");
			clliTypeMap.put("VZB_BS_ACT_IB_TN_SYSTEM_UPDATE_20", 	"BS_CLLI");			
			clliTypeMap.put("VZB_ESAP_LOGICAL_INPUT_SIP_DATA", 	"INV_CLLI");
			clliTypeMap.put("VZB_INV_ADD_SIP_DEVICE_FXO", 	"INV_CLLI");
			clliTypeMap.put("VZB_INV_SET_GWY_TIER_SIP_FXO", 	"INV_CLLI");
			clliTypeMap.put("VZB_BS_CREATE_DEVICE_SIP_20", 	"BS_CLLI");
			clliTypeMap.put("VZB_CSSOP_ADD_DEVICE_SIP_FXO", 	"CSSOP_CLLI");
			clliTypeMap.put("VZB_GCM_ADD_DEVICE_SIP_FXO", 	"GCM_CLLI");			
			clliTypeMap.put("VZB_ESAP_LOGICAL_INPUT_MGCP_DATA", 	"INV_CLLI");
			clliTypeMap.put("VZB_INV_ADD_MGCP_DEVICE_FXO", 	"INV_CLLI");
			clliTypeMap.put("VZB_INV_SET_GWY_TIER_MGCP_FXO", 	"INV_CLLI");
			clliTypeMap.put("VZB_BS_CREATE_DEVICE_MGCP_20", 	"BS_CLLI");
			clliTypeMap.put("VZB_CSSOP_ADD_DEVICE_MGCP_FXO", 	"CSSOP_CLLI");
			clliTypeMap.put("VZB_GCM_ADD_DEVICE_MGCP_FXO", 	"GCM_CLLI");
			clliTypeMap.put("VZB_ESAP_LOGICAL_INPUT_2W_DATA", 	"INV_CLLI");
			clliTypeMap.put("VZB_ESAP_LOGICAL_INPUT_IB_DATA", 	"INV_CLLI");			
			clliTypeMap.put("VZB_INV_ADD_DID_GROUP_FXO", 	"INV_CLLI");
			clliTypeMap.put("VZB_INV_ADD_LINE_GROUP_FXO", 	"INV_CLLI");			
			clliTypeMap.put("VZB_BS_ADD_LOCATION_INST_FXO", 	"BS_CLLI");			
			clliTypeMap.put("VZB_IASA_ADD_E2EI_ENTERPRISE_FXO", 	"IASA_CLLI");
			clliTypeMap.put("VZB_IASA_ADD_E2EI_LOCATION_FXO", 	"IASA_CLLI");
			clliTypeMap.put("VZB_IASA_ADD_2W_GROUP_FXO", 	"IASA_CLLI");
			clliTypeMap.put("VZB_IASA_ADD_IB_GROUP_FXO", 	"IASA_CLLI");
			clliTypeMap.put("VZB_IASA_ADD_2W_TN_SYSTEM_UPDATE_FXO", 	"IASA_CLLI");
			clliTypeMap.put("VZB_IASA_SYSTEM_UPDATE_FXO", 	"IASA_CLLI");			
			clliTypeMap.put("VZB_IASA_ADD_IB_TN_SYSTEM_UPDATE_FXO", 	"IASA_CLLI");
			clliTypeMap.put("VZB_IASA_SYSTEM_UPDATE_FXO", 	"IASA_CLLI");			
			clliTypeMap.put("VZB_INV_DEL_ENTERPRISE_FXO", 	"INV_CLLI");
			clliTypeMap.put("VZB_BS_DEL_ENTERPRISE_FXO", 	"BS_CLLI");	
			clliTypeMap.put("VZB_IASA_DEL_E2EI_ENTERPRISE_FXO", 	"IASA_CLLI");
			clliTypeMap.put("VZB_CSSOP_DEL_ENTERPRISE_FXO", 	"CSSOP_CLLI");			
			clliTypeMap.put("VZB_INV_DEL_LOCATION_FXO", 	"INV_CLLI");
			clliTypeMap.put("VZB_BS_DEL_LOCATION_FXO", 	"BS_CLLI");
			clliTypeMap.put("VZB_IASA_DEL_E2EI_LOCATION_FXO", 	"IASA_CLLI");
			clliTypeMap.put("VZB_CSSOP_DEL_LOCATION_FXO", 	"CSSOP_CLLI");
			clliTypeMap.put("VZB_ESAP_AUTO_TASK_DID_TN_FXO", 	"ESAP_CLLI");
			clliTypeMap.put("VZB_INV_ADD_SYSTEM_UPDATE_DID_TN_FXO", 	"INV_CLLI");
			clliTypeMap.put("VZB_BS_BULK_ADD_DID_TN_SYSTEM_UPDATE_20", 	"BS_CLLI");
			clliTypeMap.put("VZB_BS_CHAIN_ADD_DID_TN_SYSTEM_UPDATE_20", 	"BS_CLLI");
			clliTypeMap.put("VZB_BS_ACT_DID_TN_SYSTEM_UPDATE_20", 	"BS_CLLI");
			clliTypeMap.put("VZB_IASA_ADD_DID_TN_SYSTEM_UPDATE_FXO", 	"IASA_CLLI");
			clliTypeMap.put("VZB_CSSOP_MIG_DID_TN_SYSTEM_UPDATE_FXO", 	"CSSOP_CLLI");			
			clliTypeMap.put("VZB_ESAP_AUTO_TASK_LINE_TN_FXO", 	"ESAP_CLLI");
			clliTypeMap.put("VZB_INV_ADD_SYSTEM_UPDATE_LINE_TN_FXO", 	"INV_CLLI");
			clliTypeMap.put("VZB_BS_BULK_ADD_LINE_TN_SYSTEM_UPDATE_20", 	"BS_CLLI");
			clliTypeMap.put("VZB_BS_CHAIN_ADD_LINE_TN_SYS_UPDATE_20", 	"BS_CLLI");
			clliTypeMap.put("VZB_BS_ACT_LINE_TN_SYSTEM_UPDATE_20", 	"BS_CLLI");
			clliTypeMap.put("VZB_IASA_ADD_LINE_TN_SYSTEM_UPDATE_FXO", 	"IASA_CLLI");
			clliTypeMap.put("VZB_CSSOP_MIG_LINE_TN_SYSTEM_UPDATE_FXO", 	"CSSOP_CLLI");
			clliTypeMap.put("VZB_INV_DEL_2W_GROUP_FXO", 	"INV_CLLI");
			clliTypeMap.put("VZB_BS_DEL_2W_GROUP_FXO", 	"BS_CLLI");
			clliTypeMap.put("VZB_BS_DEL_IB_GROUP_FXO", 	"BS_CLLI");
			clliTypeMap.put("VZB_IASA_DEL_IB_GROUP_FXO", 	"IASA_CLLI");
			clliTypeMap.put("VZB_INV_DEL_SYSTEM_UPDATE_2W_TN_FXO", 	"INV_CLLI");
			clliTypeMap.put("VZB_INV_DEL_ENTERPRISE_TRUNK_2W_FXO", 	"INV_CLLI");
			clliTypeMap.put("VZB_BS_DEL_ENTERPRISE_TRUNK_2W_FXO", 	"BS_CLLI");
			clliTypeMap.put("VZB_BS_DEL_DEVICE_IB_FXO", 	"BS_CLLI");
			clliTypeMap.put("VZB_INV_DEL_ENTERPRISE_FXO", 	"INV_CLLI");
			clliTypeMap.put("VZB_BS_BULK_DEL_IB_TN_SYSTEM_UPDATE_20", 	"BS_CLLI");
			clliTypeMap.put("VZB_BS_DEACT_IB_TN_SYSTEM_UPDATE_20", 	"BS_CLLI");
			clliTypeMap.put("VZB_CSSOP_ROLLBACK_IB_TN_SYS_UPDATE", 	"CSSOP_CLLI");
			clliTypeMap.put("VZB_SONUS_PSX_DEL_IB_GROUP_FXO", 	"INV_CLLI");
			clliTypeMap.put("VZB_BS_DEACT_2W_TN_SYSTEM_UPDATE_20", 	"BS_CLLI");
			clliTypeMap.put("VZB_INV_DEL_ENTERPRISE_FXO", 	"INV_CLLI");
			clliTypeMap.put("VZB_IASA_DEL_2W_TN_SYSTEM_UPDATE_FXO", 	"IASA_CLLI");
			clliTypeMap.put("VZB_CSSOP_ROLLBACK_2W_TN_SYS_UPDATE", 	"CSSOP_CLLI");			
			clliTypeMap.put("VZB_CSSOP_DEL_LOCATION_FXO", 	"CSSOP_CLLI");
			clliTypeMap.put("VZB_CSSOP_DEL_DEVICE", 	"CSSOP_CLLI");
			clliTypeMap.put("VZB_IASA_DEL_E2EI_ENTERPRISE_FXO", 	"IASA_CLLI");
			clliTypeMap.put("VZB_CSSOP_DEL_ENTERPRISE_FXO", 	"CSSOP_CLLI");
			clliTypeMap.put("VZB_CSSOP_DEL_2W_GROUP_FXO", 	"CSSOP_CLLI");
			clliTypeMap.put("VZB_INV_DEL_IB_GROUP_FXO", 	"INV_CLLI");
			clliTypeMap.put("VZB_BS_BULK_DEL_2W_TN_SYSTEM_UPDATE_20", 	"BS_CLLI");
			clliTypeMap.put("VZB_SONUS_GSX_DEL_2W_GROUP_FXO", 	"INV_CLLI");
			clliTypeMap.put("VZB_INV_DEL_IB_DEVICE_FXO", 	"INV_CLLI");
			clliTypeMap.put("VZB_BS_DEL_DEVICE_2W_FXO", 	"BS_CLLI");
			clliTypeMap.put("VZB_IASA_DEL_2W_GROUP_FXO", 	"IASA_CLLI");
			clliTypeMap.put("VZB_INV_DEL_SYSTEM_UPDATE_IB_TN_FXO", 	"INV_CLLI");
			clliTypeMap.put("VZB_IASA_DEL_E2EI_LOCATION_FXO", 	"IASA_CLLI");
			clliTypeMap.put("VZB_IASA_DEL_IB_TN_SYSTEM_UPDATE_FXO", 	"CSSOP_CLLI");
			clliTypeMap.put("VZB_INV_DEL_SONUS_NBS_2W_FXO", 	"INV_CLLI");
			clliTypeMap.put("VZB_INV_DEL_SONUS_NBS_IB_FXO", 	"INV_CLLI");
			clliTypeMap.put("VZB_CSSOP_DEL_ENTERPRISE_TRUNK_IB_FXO", 	"CSSOP_CLLI");
			clliTypeMap.put("VZB_BS_DEL_ENTERPRISE_FXO", 	"BS_CLLI");
			clliTypeMap.put("VZB_SONUS_PSX_DEL_2W_GROUP_FXO", 	"INV_CLLI");
			clliTypeMap.put("VZB_SONUS_GSX_DEL_IB_GROUP_FXO", 	"INV_CLLI");
			clliTypeMap.put("VZB_BS_DEL_ENTERPRISE_TRUNK_IB_FXO", 	"BS_CLLI");
			clliTypeMap.put("VZB_CSSOP_DEL_ENTERPRISE_TRUNK_2W_FXO", 	"CSSOP_CLLI");
			clliTypeMap.put("VZB_INV_DEL_LOCATION_FXO", 	"INV_CLLI");
			clliTypeMap.put("VZB_ESAP_LOGICAL_REL_IB_DATA", 	"INV_CLLI");
			clliTypeMap.put("VZB_INV_DEL_2W_DEVICE_FXO", 	"INV_CLLI");
			clliTypeMap.put("VZB_CSSOP_DEL_IB_GROUP_FXO", 	"CSSOP_CLLI");
			clliTypeMap.put("VZB_INV_DEL_ENTERPRISE_TRUNK_IB_FXO", 	"INV_CLLI");
			clliTypeMap.put("VZB_BS_DEL_LOCATION_FXO", 	"BS_CLLI");
			clliTypeMap.put("VZB_ESAP_LOGICAL_REL_2W_DATA", 	"INV_CLLI");			
			clliTypeMap.put("VZB_ESAP_LOGICAL_MOD_2W_DATA", 	"INV_CLLI");
			clliTypeMap.put("VZB_INV_MOD_IB_DEVICE_FXO", 	"INV_CLLI");
			clliTypeMap.put("VZB_IASA_MOD_2W_GROUP_FXO", 	"IASA_CLLI");
			clliTypeMap.put("VZB_INV_MOD_SYSTEM_UPDATE_IB_TN_FXO", 	"INV_CLLI");
			clliTypeMap.put("VZB_IASA_MOD_LOCATION_BILLING_FXO", 	"IASA_CLLI");
			clliTypeMap.put("VZB_ESAP_LOGICAL_MOD_IB_DATA", 	"INV_CLLI");
			clliTypeMap.put("VZB_SONUS_PSX_MOD_IB_GROUP_FXO", 	"INV_CLLI");
			clliTypeMap.put("VZB_CSSOP_MOD_DEVICE_2W_FXO", 	"CSSOP_CLLI");
			clliTypeMap.put("VZB_IASA_MOD_DEVICE_IB_FXO", 	"IASA_CLLI");
			clliTypeMap.put("VZB_IASA_MOD_IB_GROUP_FXO", 	"IASA_CLLI");
			clliTypeMap.put("VZB_CSSOP_MOD_ENTERPRISE_TRUNK_2W_FXO", 	"CSSOP_CLLI");
			clliTypeMap.put("VZB_INV_MOD_SONUS_NBS_2W_FXO", 	"INV_CLLI");
			clliTypeMap.put("VZB_SONUS_GSX_MOD_2W_GROUP_FXO", 	"INV_CLLI");
			clliTypeMap.put("VZB_IASA_MOD_E2EI_ENTERPRISE_FXO", 	"IASA_CLLI");
			clliTypeMap.put("VZB_CSSOP_MOD_2W_GROUP_FXO", 	"CSSOP_CLLI");
			clliTypeMap.put("VZB_INV_MOD_ENTERPRISE_TRUNK_IB_FXO", 	"INV_CLLI");
			clliTypeMap.put("VZB_CSSOP_MOD_ENTERPRISE_TRUNK_IB_FXO", 	"CSSOP_CLLI");
			clliTypeMap.put("VZB_INV_MOD_SYSTEM_UPDATE_2W_TN_FXO", 	"INV_CLLI");
			clliTypeMap.put("VZB_IASA_MOD_2W_TN_SYSTEM_UPDATE_FXO", 	"IASA_CLLI");
			clliTypeMap.put("VZB_IASA_MOD_IB_TN_SYSTEM_UPDATE_FXO", 	"IASA_CLLI");
			clliTypeMap.put("VZB_CSSOP_MOD_ENTERPRISE_FXO", 	"CSSOP_CLLI");
			clliTypeMap.put("VZB_CSSOP_MOD_LOCATION_FXO", 	"CSSOP_CLLI");
			clliTypeMap.put("VZB_BS_MOD_DEVICE_IB_FXO", 	"BS_CLLI");
			clliTypeMap.put("VZB_INV_MOD_2W_GROUP_FXO", 	"INV_CLLI");
			clliTypeMap.put("VZB_BS_MOD_2W_GROUP_FXO", 	"BS_CLLI");
			clliTypeMap.put("VZB_INV_MOD_IB_GROUP_FXO", 	"INV_CLLI");
			clliTypeMap.put("VZB_CSSOP_MOD_IB_GROUP_FXO", 	"CSSOP_CLLI");
			clliTypeMap.put("VZB_INV_MOD_ENTERPRISE_TRUNK_2W_FXO", 	"INV_CLLI");
			clliTypeMap.put("VZB_CSSOP_MOD_2W_TN_SYS_UPDATE", 	"CSSOP_CLLI");
			clliTypeMap.put("VZB_INV_MOD_SONUS_NBS_IB_FXO", 	"INV_CLLI");
			clliTypeMap.put("VZB_SONUS_GSX_MOD_IB_GROUP_FXO", 	"INV_CLLI");
			clliTypeMap.put("VZB_BS_MOD_ENTERPRISE_FXO", 	"BS_CLLI");
			clliTypeMap.put("VZB_INV_MOD_2W_DEVICE_FXO", 	"INV_CLLI");
			clliTypeMap.put("VZB_BS_MOD_DEVICE_2W_FXO", 	"BS_CLLI");
			clliTypeMap.put("VZB_IASA_MOD_DEVICE_2W_FXO", 	"IASA_CLLI");
			clliTypeMap.put("VZB_CSSOP_MOD_DEVICE_IB_FXO", 	"CSSOP_CLLI");
			clliTypeMap.put("VZB_BS_MOD_ENTERPRISE_TRUNK_2W_FXO", 	"BS_CLLI");
			clliTypeMap.put("VZB_BS_BULK_MOD_2W_TN_SYSTEM_UPDATE_20", 	"BS_CLLI");
			clliTypeMap.put("VZB_CSSOP_MOD_IB_TN_SYS_UPDATE", 	"CSSOP_CLLI");
			clliTypeMap.put("VZB_SONUS_PSX_MOD_2W_GROUP_FXO", 	"INV_CLLI");
			clliTypeMap.put("VZB_BS_MOD_LOCATION_FXO", 	"BS_CLLI");
			clliTypeMap.put("VZB_BS_MOD_IB_GROUP_FXO", 	"BS_CLLI");
			clliTypeMap.put("VZB_BS_MOD_ENTERPRISE_TRUNK_IB_FXO", 	"BS_CLLI");
			clliTypeMap.put("VZB_BS_BULK_MOD_IB_TN_SYSTEM_UPDATE_20", 	"BS_CLLI");
			clliTypeMap.put("VZB_INV_MOD_ENTERPRISE_FXO", 	"INV_CLLI");
			clliTypeMap.put("VZB_INV_MOD_LOCATION_FXO", 	"INV_CLLI");
			clliTypeMap.put("VZB_IASA_MOD_E2EI_LOCATION_FXO", 	"IASA_CLLI");
			clliTypeMap.put("VZB_INV_DEL_SYSTEM_UPDATE_LINE_TN_FXO", 	"INV_CLLI");
			clliTypeMap.put("VZB_INV_DEL_SYSTEM_UPDATE_DID_TN_FXO", 	"INV_CLLI");
			clliTypeMap.put("VZB_BS_BULK_DEL_LINE_TN_SYSTEM_UPDATE_20", 	"BS_CLLI");
			clliTypeMap.put("VZB_BS_BULK_DEL_DID_TN_SYSTEM_UPDATE_20", 	"BS_CLLI");
			clliTypeMap.put("VZB_BS_DEACT_DID_TN_SYSTEM_UPDATE_20", 	"BS_CLLI");
			clliTypeMap.put("VZB_IASA_DEL_DID_TN_SYSTEM_UPDATE_FXO", 	"IASA_CLLI");
			clliTypeMap.put("VZB_CSSOP_ROLLBACK_DID_TN_SYS_UPDATE", 	"CSSOP_CLLI");			
			clliTypeMap.put("VZB_INV_DEL_DID_GROUP_FXO", 	"INV_CLLI");
			clliTypeMap.put("VZB_IASA_DEL_DID_GROUP_FXO", 	"IASA_CLLI");
			clliTypeMap.put("VZB_CSSOP_DEL_DID_GROUP_FXO", 	"CSSOP_CLLI");			
			clliTypeMap.put("VZB_ESAP_LOGICAL_REL_SIP_DATA", 	"INV_CLLI");
			clliTypeMap.put("VZB_INV_DEL_SIP_DEVICE_FXO", 	"INV_CLLI");
			clliTypeMap.put("VZB_BS_DEL_DEVICE_SIP_FXO", 	"BS_CLLI");
			clliTypeMap.put("VZB_CSSOP_DEL_DEVICE_SIP_FXO", 	"CSSOP_CLLI");			
			clliTypeMap.put("VZB_ESAP_LOGICAL_REL_MGCP_DATA", 	"INV_CLLI");
			clliTypeMap.put("VZB_INV_DEL_MGCP_DEVICE_FXO", 	"INV_CLLI");
			clliTypeMap.put("VZB_BS_DEL_DEVICE_MGCP_FXO", 	"BS_CLLI");
			clliTypeMap.put("VZB_CSSOP_DEL_DEVICE_MGCP_FXO", 	"CSSOP_CLLI");			
			clliTypeMap.put("VZB_INV_DEL_LINE_GROUP_FXO", 	"INV_CLLI");
			clliTypeMap.put("VZB_IASA_DEL_LINE_GROUP_FXO", 	"IASA_CLLI");
			clliTypeMap.put("VZB_CSSOP_DEL_LINE_GROUP_FXO", 	"CSSOP_CLLI");			
			clliTypeMap.put("VZB_INV_DEL_SUSPEND_LOCATION_FXO", 	"INV_CLLI");
			clliTypeMap.put("VZB_IASA_DEL_SUSPEND_LOCATION_FXO", 	"IASA_CLLI");
			clliTypeMap.put("VZB_CSSOP_ROLLBACK_LINE_TN_SYS_UPDATE", 	"CSSOP_CLLI");
			clliTypeMap.put("VZB_BS_DEACT_LINE_TN_SYSTEM_UPDATE_20", 	"BS_CLLI");
			clliTypeMap.put("VZB_IASA_DEL_LINE_TN_SYSTEM_UPDATE_FXO", 	"IASA_CLLI");			
			clliTypeMap.put("VZB_INV_DEL_LOCATION_FXO", 	"INV_CLLI");
			clliTypeMap.put("VZB_IASA_DEL_E2EI_LOCATION_FXO", 	"IASA_CLLI");
			clliTypeMap.put("VZB_CSSOP_DEL_LOCATION_FXO", 	"CSSOP_CLLI");
			clliTypeMap.put("VZB_BS_DEL_LOCATION_FXO", 	"BS_CLLI");			
			clliTypeMap.put("VZB_IASA_ADD_DID_GROUP_FXO", 	"IASA_CLLI");
			clliTypeMap.put("VZB_IASA_ADD_LINE_GROUP_FXO", 	"IASA_CLLI");
			clliTypeMap.put("VZB_INV_SYSTEM_UPDATE_FXO", 		"INV_CLLI");
			clliTypeMap.put("VZB_INV_ACT_SYSTEM_UPD_2W_TN_FXO", "INV_CLLI");
			clliTypeMap.put("VZB_IASA_ACT_2W_TN_SYSTEM_UPD_FXO", 	"IASA_CLLI");			
			clliTypeMap.put("VZB_INV_VALIDATE_E2EI_CHANGE_ORDER", "INV_CLLI");			
			clliTypeMap.put("VZB_BS_ADD_INST_DID_TN_FXO", 	"BS_CLLI");
			clliTypeMap.put("VZB_BS_ADD_INST_LINE_TN_FXO", 	"BS_CLLI");
			clliTypeMap.put("VZB_BS_ADD_INST_INBOUND_TN_FXO", 	"BS_CLLI");
			clliTypeMap.put("VZB_BS_ADD_INST_TWO_WAY_TN_FXO", 	"BS_CLLI");			
			clliTypeMap.put("VZB_INV_ACT_SYSTEM_UPD_IB_TN_FXO", "INV_CLLI");
			clliTypeMap.put("VZB_INV_ACT_SYSTEM_UPD_LINE_TN_FXO", "INV_CLLI");
			clliTypeMap.put("VZB_INV_ACT_SYSTEM_UPD_DID_TN_FXO", "INV_CLLI");
			clliTypeMap.put("VZB_INV_SYSTEM_UPDATE_FXO", "INV_CLLI");			
			clliTypeMap.put("VZB_IASA_ACT_IB_TN_SYSTEM_UPD_FXO", 	"IASA_CLLI");
			clliTypeMap.put("VZB_IASA_ACT_LINE_TN_SYSTEM_UPD_FXO", 	"IASA_CLLI");
			clliTypeMap.put("VZB_IASA_ACT_DID_TN_SYSTEM_UPD_FXO", 	"IASA_CLLI");			
			clliTypeMap.put("VZB_CSSOP_ROLLBACK_DID_TN_SYS_UPDATE",  "CSSOP_CLLI");
			clliTypeMap.put("VZB_CSSOP_ROLLBACK_IB_TN_SYS_UPDATE",  "CSSOP_CLLI");
			clliTypeMap.put("VZB_CSSOP_ROLLBACK_2W_TN_SYS_UPDATE",  "CSSOP_CLLI");
			clliTypeMap.put("VZB_CSSOP_DEL_LOCATION_PUSH_FXO",  "CSSOP_CLLI");
			clliTypeMap.put("VZB_CSSOP_ROLLBACK_LINE_TN_SYS_UPDATE",  "CSSOP_CLLI");
			clliTypeMap.put("VZB_CSSOP_DEL_ENTERPRISE_PUSH_FXO",  "CSSOP_CLLI");
			clliTypeMap.put("VZB_CSSOP_VEC_VALIDATE",  "CSSOP_CLLI");
			clliTypeMap.put("VZB_CSSOP_ADD_ET_PUSH_2W_FXO",  "CSSOP_CLLI");
			clliTypeMap.put("VZB_CSSOP_ADD_ET_PUSH_IB_FXO",  "CSSOP_CLLI");
			clliTypeMap.put("VZB_CSSOP_ADD_DID_GROUP_PUSH_FXO",  "CSSOP_CLLI");
			clliTypeMap.put("VZB_CSSOP_MOD_ET_PUSH_2W_FXO",  "CSSOP_CLLI");
			clliTypeMap.put("VZB_CSSOP_ADD_LINE_GROUP_PUSH_FXO",  "CSSOP_CLLI");
			clliTypeMap.put("VZB_CSSOP_ADD_IB_GROUP_PUSH_FXO",  "CSSOP_CLLI");
			clliTypeMap.put("VZB_CSSOP_ADD_2W_GROUP_PUSH_FXO",  "CSSOP_CLLI");
			clliTypeMap.put("VZB_CSSOP_MOD_2W_TN_SYS_UPDATE",  "CSSOP_CLLI");
			clliTypeMap.put("VZB_CSSOP_MOD_2W_TN_SYS_UPDATE",  "CSSOP_CLLI");
			clliTypeMap.put("VZB_CSSOP_MOD_DID_GROUP_PUSH_FXO",  "CSSOP_CLLI");
			clliTypeMap.put("VZB_CSSOP_MOD_LINE_GROUP_PUSH_FXO",  "CSSOP_CLLI");
			clliTypeMap.put("VZB_CSSOP_MOD_2W_TN_SYS_UPDATE",  "CSSOP_CLLI");
			clliTypeMap.put("VZB_CSSOP_MOD_IB_GROUP_PUSH_FXO",  "CSSOP_CLLI");
			clliTypeMap.put("VZB_CSSOP_MOD_2W_GROUP_PUSH_FXO",  "CSSOP_CLLI");
			clliTypeMap.put("VZB_CSSOP_MOD_ENTERPRISE_PUSH_FXO",  "CSSOP_CLLI");
			clliTypeMap.put("VZB_CSSOP_MOD_DEVICE_SIP_FXO",  "CSSOP_CLLI");
			clliTypeMap.put("VZB_CSSOP_MOD_DEVICE_2W_FXO",  "CSSOP_CLLI");
			clliTypeMap.put("VZB_CSSOP_MOD_LOCATION_PUSH_FXO",  "CSSOP_CLLI");
			clliTypeMap.put("VZB_CSSOP_MOD_DEVICE_MGCP_FXO",  "CSSOP_CLLI");
			clliTypeMap.put("VZB_CSSOP_MOD_ET_PUSH_IB_FXO",  "CSSOP_CLLI");
			clliTypeMap.put("VZB_CSSOP_ADD_ENTERPRISE_PUSH_FXO",  "CSSOP_CLLI");
			clliTypeMap.put("VZB_CSSOP_ADD_DEVICE_SIP_FXO",  "CSSOP_CLLI");
			clliTypeMap.put("VZB_CSSOP_ADD_DEVICE_IB_FXO",  "CSSOP_CLLI");
			clliTypeMap.put("VZB_CSSOP_ADD_DEVICE_2W_FXO",  "CSSOP_CLLI");
			clliTypeMap.put("VZB_CSSOP_ADD_DEVICE_MGCP_FXO",  "CSSOP_CLLI");
			clliTypeMap.put("VZB_CSSOP_ADD_LOCATION_PUSH_FXO",  "CSSOP_CLLI");
			clliTypeMap.put("VZB_CSSOP_TSO_MIG_2W_TN_FXO",  "CSSOP_CLLI");
			clliTypeMap.put("VZB_CSSOP_MIG_IB_TN_SYSTEM_UPDATE_FXO",  "CSSOP_CLLI");
			clliTypeMap.put("VZB_CSSOP_MIG_2W_TN_SYSTEM_UPDATE_FXO",  "CSSOP_CLLI");
			clliTypeMap.put("VZB_CSSOP_MIG_LINE_TN_SYSTEM_UPDATE_FXO",  "CSSOP_CLLI");
			clliTypeMap.put("VZB_CSSOP_MIG_DID_TN_SYSTEM_UPDATE_FXO",  "CSSOP_CLLI");
			clliTypeMap.put("VZB_CSSOP_MOD_IB_TN_SYS_UPDATE",  "CSSOP_CLLI");
			clliTypeMap.put("VZB_CSSOP_TSO_MIG_LINE_TN_FXO",  "CSSOP_CLLI");
			clliTypeMap.put("VZB_CSSOP_TSO_MIG_DID_TN_FXO",  "CSSOP_CLLI");
			clliTypeMap.put("VZB_CSSOP_TSO_MIG_IB_TN_FXO",  "CSSOP_CLLI");
			clliTypeMap.put("VZB_CSSOP_MOD_DEVICE_IB_FXO",  "CSSOP_CLLI");
			
			clliTypeMap.put("VZB_BS_MOD_2W_DEVICE_IP_FXO", 	"BS_CLLI");			
			clliTypeMap.put("VZB_INV_MOD_2W_DEVICE_IP_FXO", "INV_CLLI");
			clliTypeMap.put("VZB_BS_MOD_IB_DEVICE_IP_FXO", 	"BS_CLLI");			
			clliTypeMap.put("VZB_INV_MOD_IB_DEVICE_IP_FXO", "INV_CLLI");

			
		}

		public static String getValue(String key) {
			return clliTypeMap.get(key + "") != null ? clliTypeMap.get(key + "") : "UNKNOWN";
		}
	}

	public static enum OrderAction {
		DELETE("O"), ADD("I"), MODIFY("C"), VALIDATE("V"), NONE("N"), I("I"), DISCONNECT("D");

		protected String orderAction = null;

		OrderAction(String orderAction) {
			this.orderAction = orderAction;
		}

		public String toString() {
			return orderAction;
		}

		public static OrderAction reverse(OrderAction orderAction) {
			if (orderAction.equals(ADD))
				return DELETE;
			else if (orderAction.equals(DELETE))
				return ADD;
			else
				return orderAction;
		}

		public static OrderAction getAction(String orderAction) {
			for (OrderAction action : OrderAction.values()) {
				if (action.toString().equals(orderAction))
					return action;
			}

			return null;
		}

		public String getValue() {
			return orderAction;
		}

	}

	public static enum Service {
		BS, CCRS, CS2K, CSSOP, CUCM, ESAP, FMC, IASA, ICP, INV, IPSM, IXPLUS, NS, RS, SBC, TWSBC, FMCGREPORT, SSI, VM, ISR, CPE, DMS, IPRO, SCM, PC, VPLAN, GCM, OPRO, VESDW, PQ, SONUS_NBS;
	};

	public static enum FlowPath {
		// Note: Should maitain correct sequence for these enum values
		// It is used to determine the sequence of orders
		R, D, F;
	};

	public static enum OrderPass {

		RELEASE, VALIDATE, REL_SUSPEND, REL_DEACTIVATE, LNP_ACTIVATE;
	};
	
	public static enum FunctionCode {

		RELEASE, VALIDATE, NBS_PROV_CONFIG, CIRCUIT_INFO, GET_LOC_INFO, REL_SUSPEND, REL_DEACTIVATE, LNP_ACTIVATE, PIT, LOC_ACTIVATE_COMPLETE;
	};

	public static enum RedundancyType {

		NONE, PRIORITY, LOADSHARING;
	};

	public static enum RedundancyPriorityType {

		PRIMARY, SECONDARY;
	};

	public static enum SignalingDirection {

		TWO_WAY("2W"), INBOUND("IB");
		
		private String signalingDirection;
		
		SignalingDirection(String signalingDirection) {
			this.signalingDirection = signalingDirection;
		}
		
		public String getValue() {
			return signalingDirection;
		}
	}

	public static enum TrunkGroupType {

		//PBX, KEY, TWO_WAY, INBOUND, PRI_DID, LINE, NON_PRI_DID;
		PBX, KEY, TWO_WAY, INBOUND, LINE, PRI_DID, NON_PRI_DID;
		public int getIndex() { return ordinal() + 1; }
	};

	public static enum OrderEntity {
		//TODO725- understand
		GUI, ENTERPRISE, DEPARTMENT, LOCATION, DEVICE, PBX, KEY, PBX_TN, KEY_TN, SUBSCRIBER, RES_TN, CALLING_PLAN, FEATURE_PKG, VALIDATION, DIAL_PLAN, DEVICE_TYPE, BSAS, PUBLIC_ROUTING, TERM_ROUTING, BA_PORTAL_TN, FMC_DIALPLAN, FMC_DEVICE, SBC, SYSTEM_UPDATE, TN, IPAC_CUSTOMER, IPAC_HA_PAIR, IPAC_CONF_TN, BSAS_MAP, IPAC_DEVICE, SBC_REGION_MAP, MICRONODE, TWSBC, FMCGREPORT, PREFIX_PLAN_RULE, PREFIX_PLAN, EMERGENCY_CODE, CORP_SETTING, CS2K, SBC_CONFIG, PIT, SBC_LOAD_SHARING, FRAUD_BLOCK, ENTERPRISE_TRUNK, VPN_SBC_INFO, TSO_SBC, EBI, ET_TN, ROUTING_GROUP, ET_EBI, TSOMGRNRPRT, R2R_TRANSITION, IPTERM, VILO_TN, IPCC_SBC, IPSEC, VRDMGRNRPRT, ET_GROUP, PC_CKT_QUERY, BMT, BMT_USER, BMT_EBI, BMT_TRUNK_GROUP, BMT_ENTERPRISE_TRUNK, TWO_WAY, INBOUND, SONUS_NBS, TWO_WAY_TN, INBOUND_TN, LINE, PRI_DID, LINE_TN, DID_TN, NON_PRI_DID;
		public int getIndex() { return ordinal() + 1; }
	};

	public static enum SolutionType {

		ESIP_ESL, ESIP_EBL, IPFLEX, SL_IP_FLEX, SL_ESIP, PR_XO_HPBX, HPBX;
	};
	
	public static enum NbsType {
		TWO_WAY, INBOUND, BOTH;
	}
	
	public static enum RoutingEnd {
		ESL_I_VAL, ESL_I_REL, EBL_I_VAL, EBL_I_REL, NBS_PROV_CONFIG, CIRCUIT_INFO, IPFLEX_I_VAL, IPFLEX_I_REL, EMPTY, SUP_CANCEL,
		ESL_C_VAL, ESL_C_REL, EBL_C_VAL, EBL_C_REL, IPFLEX_C_VAL, IPFLEX_C_REL, HPBX_I_VAL, HPBX_I_REL, HPBX_C_VAL, HPBX_C_REL, ESL_D_REL_SUSPEND, ESL_D_REL_DEACTIVATE, EBL_D_REL_SUSPEND, EBL_D_REL_DEACTIVATE,
		HPBX_D_REL_DEACTIVATE, HPBX_D_REL_SUSPEND, IPFELX_D_REL_DEACTIVATE, IPFLEX_D_REL_SUSPEND, ESIP_GET_LOC_INFO, LNP_ACTIVATE, ESL_PIT, LOC_ACTIVATE;
	}
	
	public static enum TransportProtocol {
		UDP("UDP"), SIP_2("SIP 2.0"), TCP("TCP");
		
		private String transportProtocol;
		
		TransportProtocol(String transportProtocol) {
			this.transportProtocol = transportProtocol;
		}
		
		public String getValue() {
			return transportProtocol;
		}
	}
	
	public static enum ServiceType {
		ESIP_ESL_INSTAL("ESIP_ESL,NBS"), ESIP_EBL_INSTAL("ESIP_EBL"), IPFLEX_INSTAL("IPFLEX"), IPFLEX_STANDALONE_INSTAL("IPFLEX_STANDALONE"), IPFLEX_BUNDLE_INSTAL("IPFLEX_BUNDLE"), HPBX_INSTAL("HPBX"),		
		ESIP_ESL_DISC("ESIP_ESL,NBS"), ESIP_EBL_DISC("ESIP_EBL"), IPFLEX_DISC("IPFLEX"), IPFLEX_STANDALONE_DISC("IPFLEX_STANDALONE"), IPFLEX_BUNDLE_DISC("IPFLEX_BUNDLE"), HPBX_DISC("HPBX")
		;
		
		private String serviceType;
		
		ServiceType(String serviceType) {
			this.serviceType = serviceType;
		}
		
		public String getValue() {
			return serviceType;
		}
	}
	
	public static enum OrderCategory {
		ESIP_ESL("ESIP_ESL"), ESIP_EBL("ESIP_EBL"), IPFLEX("IPFLEX"), HPBX("HPBX");
		
		private String orderCategory;
		
		OrderCategory(String orderCategory) {
			this.orderCategory = orderCategory;
		}
		
		public String getValue() {
			return orderCategory;
		}
	}
	
	public static class SkipEblWf {
		private static HashMap<String, String> wfSkipMap = new HashMap<String, String>();
		static {
			wfSkipMap.put("VZB_INV_VALIDATE_E2EI_ORDER", "INV_CLLI");
			wfSkipMap.put("VZB_CSSOP_VEC_VALIDATE", "EBL_SKIP");
			wfSkipMap.put("VZB_IASA_VALIDATE_E2EI_ORDER", "EBL_SKIP");			
			wfSkipMap.put("VZB_VPLAN_QRY_DESIGN_INFO_FXO", 	"EBL_SKIP");
			wfSkipMap.put("VZB_INV_ADD_ENTERPRISE_FXO", 	"EBL_SKIP");
			wfSkipMap.put("VZB_BS_ADD_ENTERPRISE_FXO", 	"EBL_SKIP");
			wfSkipMap.put("VZB_NS_ADD_ENTERPRISE_CONFIG_FXO", 	"EBL_SKIP");
			wfSkipMap.put("VZB_IPRO_QRY_LOC_TRUNK_CLLI_FXO", 	"EBL_SKIP");
			wfSkipMap.put("VZB_INV_ADD_LOCATION_FXO", 	"INV_CLLI");
			wfSkipMap.put("VZB_BS_ADD_LOCATION_FXO", 	"EBL_SKIP");
			wfSkipMap.put("VZB_VM_ADD_LOC_MAILBOXES_FXO", 	"EBL_SKIP");
			wfSkipMap.put("VZB_INV_ADD_2W_DEVICE_FXO", 	"EBL_SKIP");
			wfSkipMap.put("VZB_BS_CREATE_DEVICE_2W_20",	"EBL_SKIP");
			wfSkipMap.put("VZB_INV_ADD_IB_DEVICE_FXO", 	"EBL_SKIP");
			wfSkipMap.put("VZB_BS_CREATE_DEVICE_IB_20",	"EBL_SKIP");
			wfSkipMap.put("VZB_INV_ADD_2W_GROUP_FXO", 	"INV_CLLI");
			wfSkipMap.put("VZB_BS_ADD_2W_GROUP_FXO", 	"EBL_SKIP");
			wfSkipMap.put("VZB_INV_ADD_IB_GROUP_FXO", 	"INV_CLLI");
			wfSkipMap.put("VZB_BS_ADD_IB_GROUP_FXO", 	"EBL_SKIP");
			wfSkipMap.put("VZB_INV_ADD_ENTERPRISE_TRUNK_2W_FXO", 	"EBL_SKIP");
			wfSkipMap.put("VZB_BS_ADD_ENTERPRISE_TRUNK_2W_FXO", 	"EBL_SKIP");
			wfSkipMap.put("VZB_INV_ADD_ENTERPRISE_TRUNK_IB_FXO", 	"EBL_SKIP");
			wfSkipMap.put("VZB_BS_ADD_ENTERPRISE_TRUNK_IB_FXO", 	"EBL_SKIP");
			wfSkipMap.put("VZB_ESAP_INPUT_NBS_DATA",	"EBL_SKIP");
			wfSkipMap.put("VZB_INV_ADD_SONUS_NBS_2W_FXO", 	"EBL_SKIP");
			wfSkipMap.put("VZB_SONUS_GSX_ADD_2W_GROUP_FXO", 	"EBL_SKIP");
			wfSkipMap.put("VZB_SONUS_PSX_ADD_2W_GROUP_FXO", 	"EBL_SKIP");
			wfSkipMap.put("VZB_INV_ADD_SONUS_NBS_IB_FXO", 	"EBL_SKIP");
			wfSkipMap.put("VZB_SONUS_GSX_ADD_IB_GROUP_FXO", 	"EBL_SKIP");
			wfSkipMap.put("VZB_SONUS_PSX_ADD_IB_GROUP_FXO", 	"EBL_SKIP");
			wfSkipMap.put("VZB_FXOPORTAL_ADD_ESL", 	"EBL_SKIP");
			wfSkipMap.put("VZB_CSSOP_TSO_MIG_TN", 	"EBL_SKIP");
			wfSkipMap.put("VZB_BS_ADD_LOCATION_INST_FXO", 	"EBL_SKIP");
			wfSkipMap.put("VZB_ESAP_LOGICAL_INPUT_2W_DATA", "EBL_SKIP");
			wfSkipMap.put("VZB_ESAP_LOGICAL_INPUT_IB_DATA", "EBL_SKIP");			
			wfSkipMap.put("VZB_IASA_ADD_E2EI_ENTERPRISE_FXO", 	"EBL_SKIP");
		//	wfSkipMap.put("VZB_IASA_ADD_E2EI_LOCATION_FXO", 	"EBL_SKIP");
		//	wfSkipMap.put("VZB_IASA_ADD_2W_GROUP_FXO", 	"EBL_SKIP");
		//	wfSkipMap.put("VZB_IASA_ADD_IB_GROUP_FXO", 	"EBL_SKIP");			
			wfSkipMap.put("VZB_INV_MOD_ENTERPRISE_FXO", "EBL_SKIP");
			wfSkipMap.put("VZB_BS_MOD_LOCATION_FXO", "EBL_SKIP");			
			wfSkipMap.put("VZB_INV_MOD_2W_DEVICE_FXO", 	"EBL_SKIP");
			wfSkipMap.put("VZB_BS_MOD_DEVICE_2W_FXO", 	"EBL_SKIP");
			wfSkipMap.put("VZB_INV_MOD_IB_DEVICE_FXO", 	"EBL_SKIP");
			wfSkipMap.put("VZB_BS_MOD_DEVICE_IB_FXO", 	"EBL_SKIP");
			wfSkipMap.put("VZB_BS_MOD_2W_GROUP_FXO", 	"EBL_SKIP");
			wfSkipMap.put("VZB_BS_MOD_IB_GROUP_FXO", 	"EBL_SKIP");			
			wfSkipMap.put("VZB_INV_MOD_ENTERPRISE_TRUNK_2W_FXO", "EBL_SKIP");
			wfSkipMap.put("VZB_BS_MOD_ENTERPRISE_TRUNK_2W_FXO", "EBL_SKIP");			
			wfSkipMap.put("VZB_INV_MOD_ENTERPRISE_TRUNK_IB_FXO", 	"EBL_SKIP");
			wfSkipMap.put("VZB_BS_MOD_ENTERPRISE_TRUNK_IB_FXO", 	"EBL_SKIP");			
			wfSkipMap.put("VZB_INV_MOD_SONUS_NBS_2W_FXO", "EBL_SKIP");
			wfSkipMap.put("VZB_SONUS_GSX_MOD_2W_GROUP_FXO", "EBL_SKIP");			
			wfSkipMap.put("VZB_SONUS_PSX_MOD_2W_GROUP_FXO", 	"EBL_SKIP");			
			wfSkipMap.put("VZB_INV_MOD_SONUS_NBS_IB_FXO", 	"EBL_SKIP");
			wfSkipMap.put("VZB_SONUS_GSX_MOD_IB_GROUP_FXO", "EBL_SKIP");			
			wfSkipMap.put("VZB_SONUS_PSX_MOD_IB_GROUP_FXO", 	"EBL_SKIP");
			wfSkipMap.put("VZB_BS_DEL_LOCATION_FXO", "EBL_SKIP"); //EBL Disconnect fix
			
			wfSkipMap.put("VZB_INV_VALIDATE_E2EI_CHANGE_ORDER", "INV_CLLI");
		}
		
		

		public static String getValue(String key) {
			return wfSkipMap.get(key + "") != null ? wfSkipMap.get(key + "") : "UNKNOWN";
		}
	}
	
	
	public static class MilestoneSkip {
		private static HashMap<String, String> milestoneSkip = new HashMap<String, String>();
		static {
			milestoneSkip.put("HPBX", "VZB_BS_ADD_ENTERPRISE_TRUNK_2W_FXO");
		}

		public static String getValue(String key) {
			return milestoneSkip.get(key + "") != null ? milestoneSkip.get(key + "") : "UNKNOWN";
		}
	}
	

	public static class SkipEslWf {
		private static HashMap<String, String> wfSkipMap = new HashMap<String, String>();
		static {
			wfSkipMap.put("VZB_INV_VALIDATE_E2EI_ORDER", "RIVISTINV01");
			wfSkipMap.put("VZB_CSSOP_VEC_VALIDATE", "VAL_SKIP");
			wfSkipMap.put("VZB_IASA_VALIDATE_E2EI_ORDER", "VAL_SKIP");
			/*wfSkipMap.put("VZB_VM_ADD_LOC_MAILBOXES_FXO", "ESL_SKIP");*/
			wfSkipMap.put("VZB_BS_ADD_LOCATION_INST_FXO", "ESL_SKIP");
			
			wfSkipMap.put("VZB_INV_VALIDATE_E2EI_CHANGE_ORDER", "RIVISTINV01");
			wfSkipMap.put("VZB_INV_MOD_2W_DEVICE_IP_FXO", "ESL_SKIP");
			wfSkipMap.put("VZB_BS_MOD_2W_DEVICE_IP_FXO", "ESL_SKIP");
			wfSkipMap.put("VZB_INV_MOD_IB_DEVICE_IP_FXO", "ESL_SKIP");
			wfSkipMap.put("VZB_BS_MOD_IB_DEVICE_IP_FXO", "ESL_SKIP");
		}

		public static String getValue(String key) {
			return wfSkipMap.get(key + "") != null ? wfSkipMap.get(key + "") : "UNKNOWN";
		}
	}
	
	/* 
	Commented out TnType
	public static enum TnType {
		RES,VMA,HIPC,PBX,KEY,BA_PORTAL,AUTO_ATTENDANT,PBX_PILOT_TN,HUNT_GROUP,VOICE_PORTAL,ALTERNATE_TN,ET,VILO,TWO_WAY_TN, INBOUND_TN, DID_TN, LINE_TN;
		public int getIndex() { return ordinal() + 1; }
	};
	*/
	
	/*
	 * Modified TnType as per legacy code
	 * No type is at Index 9 :: Dummy
	 * DID_TN and LINE_TN indexs are swapped
	 */
	public static enum TnType {
		RES, VMA, HIPC, PBX, KEY, BA_PORTAL, AUTO_ATTENDANT, PBX_PILOT_TN, NO_TYPE_IS_AT_9, HUNT_GROUP, VOICE_PORTAL, ALTERNATE_TN, ET, VILO, TWO_WAY_TN, INBOUND_TN, LINE_TN, DID_TN;
		public int getIndex() { return ordinal() + 1; }
	};
	
	public static enum DeviceType {
		SIP_DEVICE("SIP_DEVICE"), ENTPRISE_GTWY("ENTPRISE_GTWY"),  EST_STATIC_DEVGW_01("EST-STATIC-DEVGW-01"), CPE_LOCAL_GTWY("CPE_LOCAL_GTWY"), CPE_ENTPRISE_GTWY_SHARED("CPE_ENTPRISE_GTWY_SHARED");
		public int getIndex() { return ordinal() + 1; }
		
		private String deviceType;
		
		DeviceType(String deviceType) {
			this.deviceType = deviceType;
		}
		
		public String getValue() {
			return deviceType;
		}
	}
	
	public static enum VoipServiceType {
		IP_FLEXIBLE_T1("IP_FLEXIBLE_T1"),
		IP_INTEGRATED_ACCESS_PBX("IP_INTEGRATED_ACCESS_PBX"),
		IP_INTEGRATED_ACCESS_KEY("IP_INTEGRATED_ACCESS_KEY"), 
		IP_TRUNKING("IP_TRUNKING"), 
		HIPC("HIPC"), 
		IP_INTEGRATED_ACCESS_ET("IP_INTEGRATED_ACCESS_ET"), 
		IP_TRUNKING_ET("IP_TRUNKING_ET"), 
		ENTERPRISE_SIP("ENTERPRISE_SIP"), 
		//ESIP_EBL("ENTERPRISE_SIP"), 
		IP_FLEX("IP_FLEX"), 
		HOSTED_PBX("HOSTED_PBX");
		public int getIndex() { return ordinal() + 1; }
		
		private String voipServiceType;
		
		VoipServiceType(String voipServiceType) {
			this.voipServiceType = voipServiceType;
		}
		
		public String getValue() {
			return voipServiceType;
		}
		
	}
	
	public static enum Language {
		NO_PREFERENCE,US_ENGLISH,UK_ENGLISH,GERMAN,FRENCH,DUTCH,ITALIAN,SPANISH;
		public int getIndex() { return ordinal() + 1; }
	}
	
	public static class SkipSystemUpdateTnWf {
		private static HashMap<String, String> wfSkipMap = new HashMap<String, String>();
		static {
			wfSkipMap.put("VZB_BS_BULK_ADD_2W_TN_SYSTEM_UPDATE_20", "SYSTEM_BULK_UPDATE_SKIP");
			wfSkipMap.put("VZB_BS_BULK_ADD_IB_TN_SYSTEM_UPDATE_20", "SYSTEM_BULK_UPDATE_SKIP");
			wfSkipMap.put("VZB_BS_CHAIN_ADD_2W_TN_SYSTEM_UPDATE_20", "SYSTEM_CHAIN_UPDATE_SKIP");
			wfSkipMap.put("VZB_BS_CHAIN_ADD_IB_TN_SYSTEM_UPDATE_20", "SYSTEM_CHAIN_UPDATE_SKIP");
		}
		public static String getValue(String key) {
			return wfSkipMap.get(key + "") != null ? wfSkipMap.get(key + "") : "UNKNOWN";
		}
	}
	
	public static class SkipFlexDidWf {
		private static HashMap<String, String> wfSkipMap = new HashMap<String, String>();
		static {
			wfSkipMap.put("VZB_INV_VALIDATE_E2EI_ORDER", "RIVISTINV01");
			wfSkipMap.put("VZB_CSSOP_VEC_VALIDATE", "VAL_SKIP");
			wfSkipMap.put("VZB_IASA_VALIDATE_E2EI_ORDER", "VAL_SKIP");
			//wfSkipMap.put("VZB_VM_ADD_LOC_MAILBOXES_FXO", "FLEX_DID_SKIP");
			
			wfSkipMap.put("VZB_INV_VALIDATE_E2EI_CHANGE_ORDER", "RIVISTINV01");
		}

		public static String getValue(String key) {
			return wfSkipMap.get(key + "") != null ? wfSkipMap.get(key + "") : "UNKNOWN";
		}
	}
	
	public static enum AuthFeatureType {

		FET_ESIP, FET_DID, FET_LINE, FET_DID_LINE, FET_HPBX;
	}
	
	public static enum OrderMilestone {
		MANUAL_TRUNK_GROUP_VFY, MANUAL_VFY_COMPLETION, BS_COMPLETE, VM_COMPLETE, IASA_UPDATE_COMPLETE,
		ICP_UPDATE_COMPLETE, CSSOP_UPDATE_COMPLETE, MANUAL_UPDATE_COMPLETE, ACTIVATION_COMPLETE, 
		FMC_COMPLETE, ASR_COMPLETE, CUCM_COMPLETE, SBC_SD_INPUT, SBC_ASSIGNMENT, SBC_COMPLETE, VALIDATION,
		SHELL_ACCT_COMPLETE, TWFQDN_SBC_SD_INPUT, TWFQDN_SBC_COMPLETE, BS_ASSIGNMENT_INPUT, 
		BS_ASSIGNMENT_COMPLETE, RS_PROV_COMPLETE, CS2K_COMPLETE, DISC_SUSP_COMPLETE, IPAC_SBC_COMPLETE, 
		MANUAL_TASK, TRUNK_CLLI_COMPLETE, HOMING_TAB_PULL_COMPLETE, ORDER_ACCEPTANCE, NSRS_UPDATE_COMPLETE, 
		NETWORK_ASSIGNMENT, VPLAN_QUERY, ROUTER_PROVISIONING, MIGRATION_COMPLETE, VILO_ACTIVATION_COMPLETE, 
		NBS_START, NBS_PROV, NBS_COMPLETE;
		public int getIndex() { return ordinal() + 1; }
	}
	
	public static enum PcMilestone {
		ORDER_ACCEPTANCE("Send-Order-Release-To-ESAP"), NBS_PROV("Receive-NBS-Prov-Trigger-From-ESAP"),
		ACTIVATION_COMPLETE("Validate-Order-With-ESAP"), CIRCUIT_INFO_ACCEPTANCE("Send-CircuitID-And-VPN-To-ESAP"), PIT_COMPLETE("PIT_COMPLETE"), LOCATION_COMPLETE("LOCATION_COMPLETE"), VALIDATE_DEACT("VALIDATE_DEACT");
		public int getIndex() { return ordinal() + 1; }
		
		private String pcMilestone;
		
		PcMilestone(String pcMilestone) {
			this.pcMilestone = pcMilestone;
		}
		
		public String getValue() {
			return pcMilestone;
		}
	}
	
	public static enum OrderRequestType {

		REQUEST_ORDER, INTERNAL_ORDER, INDEPENDENT_INTERNAL_ORDER;
	}
	
	public static enum RollbackReason {
        FAILED,
        ENTITY_DROPPED,
        TN_PORTING_OFF,
        AUTO_ROLLBACK,
        NO_CHANGE;
    }
	
	public static enum InternalOrderStatus {
		PENDING,
		COMPLETE,
		PARTIALLY_COMPLETE;
    }
	

	public static enum OrderOrigin {
		OPro, GUI, CSSOP, IASA, UPI, IORDER, ICP, UNO, AM, VPLAN, ESAP;
	}

		
	public static enum PcResponseType {
		ORDER("ORDER"), VALIDATION("VALIDATION");
		public int getIndex() { return ordinal() + 1; }
		
		private String pcResponseType;
		
		PcResponseType(String pcResponseType) {
			this.pcResponseType = pcResponseType;
		}
		
		public String getValue() {
			return pcResponseType;
		}
	}
	
	public static enum ChangeType {
		CHANGED;
    }
	
	
	public static enum LocationType {
		HUB("HUB"), REMOTE("REMOTE"), STANDARD("STANDARD"), HUB_AND_STANDARD("HUB_AND_STANDARD"), 
		ESIP_ESL("ESIP_ESL"), ESIP_EBL("ESIP_EBL"), HPBX_ECH("HPBX_ECH"), HPBX_EBL("HPBX_EBL"), IPFLEX("IPFLEX") ;
		
		public int getIndex() { return ordinal() + 1; }
		
		private String locationType;
		
		LocationType(String locationType) {
			this.locationType = locationType;
		}
		
		public String getValue() {
			return locationType;
		}
		
	}
	
	
	public static class SkipHpbxPreConfigEntitiesWf {
		private static HashMap<String, String> wfSkipMap = new HashMap<String, String>();
		static {


			wfSkipMap.put("VZB_CSSOP_VEC_VALIDATE", "HPBX_PRE_CONFIG_SKIP");
			wfSkipMap.put("VZB_IASA_VALIDATE_E2EI_ORDER", "HPBX_PRE_CONFIG_SKIP");			
			wfSkipMap.put("VZB_VPLAN_QRY_DESIGN_INFO_FXO", 	"HPBX_PRE_CONFIG_SKIP");
			wfSkipMap.put("VZB_BS_ADD_ENTERPRISE_FXO", 	"HPBX_PRE_CONFIG_SKIP");
			wfSkipMap.put("VZB_NS_ADD_ENTERPRISE_CONFIG_FXO", 	"HPBX_PRE_CONFIG_SKIP");
			wfSkipMap.put("VZB_IPRO_QRY_LOC_TRUNK_CLLI_FXO", 	"HPBX_PRE_CONFIG_SKIP");
			wfSkipMap.put("VZB_BS_ADD_ENTERPRISE_FXO", 	"HPBX_PRE_CONFIG_SKIP");
			wfSkipMap.put("VZB_BS_ADD_LOCATION_FXO", 	"HPBX_PRE_CONFIG_SKIP");
			wfSkipMap.put("VZB_VM_ADD_LOC_MAILBOXES_FXO", 	"HPBX_PRE_CONFIG_SKIP");
			wfSkipMap.put("VZB_BS_CREATE_DEVICE_2W_20",	"HPBX_PRE_CONFIG_SKIP");
			wfSkipMap.put("VZB_BS_CREATE_DEVICE_IB_20",	"HPBX_PRE_CONFIG_SKIP");
			wfSkipMap.put("VZB_BS_ADD_2W_GROUP_FXO", 	"HPBX_PRE_CONFIG_SKIP");
			wfSkipMap.put("VZB_BS_ADD_IB_GROUP_FXO", 	"HPBX_PRE_CONFIG_SKIP");
			wfSkipMap.put("VZB_BS_ADD_ENTERPRISE_TRUNK_2W_FXO", 	"HPBX_PRE_CONFIG_SKIP");
			wfSkipMap.put("VZB_BS_ADD_ENTERPRISE_TRUNK_IB_FXO", 	"HPBX_PRE_CONFIG_SKIP");
			wfSkipMap.put("VZB_ESAP_INPUT_NBS_DATA",	"HPBX_PRE_CONFIG_SKIP");
			wfSkipMap.put("VZB_FXOPORTAL_ADD_ESL", 	"HPBX_PRE_CONFIG_SKIP");
			wfSkipMap.put("VZB_CSSOP_TSO_MIG_TN", 	"HPBX_PRE_CONFIG_SKIP");
			wfSkipMap.put("VZB_BS_ADD_LOCATION_INST_FXO", 	"HPBX_PRE_CONFIG_SKIP");
			wfSkipMap.put("VZB_ESAP_LOGICAL_INPUT_2W_DATA", "HPBX_PRE_CONFIG_SKIP");
			wfSkipMap.put("VZB_ESAP_LOGICAL_INPUT_IB_DATA", "HPBX_PRE_CONFIG_SKIP");			
			/*wfSkipMap.put("VZB_IASA_ADD_E2EI_ENTERPRISE_FXO", 	"HPBX_PRE_CONFIG_SKIP");
			wfSkipMap.put("VZB_IASA_ADD_E2EI_LOCATION_FXO", 	"HPBX_PRE_CONFIG_SKIP");
			wfSkipMap.put("VZB_IASA_ADD_2W_GROUP_FXO", 	"HPBX_PRE_CONFIG_SKIP");
			wfSkipMap.put("VZB_IASA_ADD_IB_GROUP_FXO", 	"HPBX_PRE_CONFIG_SKIP");	*/		
			wfSkipMap.put("VZB_BS_MOD_LOCATION_FXO", "HPBX_PRE_CONFIG_SKIP");			
			wfSkipMap.put("VZB_BS_MOD_DEVICE_2W_FXO", 	"HPBX_PRE_CONFIG_SKIP");
			wfSkipMap.put("VZB_BS_MOD_DEVICE_IB_FXO", 	"HPBX_PRE_CONFIG_SKIP");
			wfSkipMap.put("VZB_BS_MOD_2W_GROUP_FXO", 	"HPBX_PRE_CONFIG_SKIP");
			wfSkipMap.put("VZB_BS_MOD_IB_GROUP_FXO", 	"HPBX_PRE_CONFIG_SKIP");			
			wfSkipMap.put("VZB_BS_MOD_ENTERPRISE_TRUNK_2W_FXO", "HPBX_PRE_CONFIG_SKIP");			
			wfSkipMap.put("VZB_BS_MOD_ENTERPRISE_TRUNK_IB_FXO", 	"HPBX_PRE_CONFIG_SKIP");
			wfSkipMap.put("VZB_BS_CREATE_DEVICE_2W_20", 	"HPBX_PRE_CONFIG_SKIP");
			wfSkipMap.put("VZB_BS_ADD_2W_GROUP_FXO", 	"HPBX_PRE_CONFIG_SKIP");
			wfSkipMap.put("VZB_BS_ADD_ENTERPRISE_TRUNK_2W_FXO", 	"HPBX_PRE_CONFIG_SKIP");			
			wfSkipMap.put("VZB_ESAP_LOGICAL_INPUT_2W_DATA", 	"HPBX_PRE_CONFIG_SKIP");
			wfSkipMap.put("VZB_BS_CREATE_DEVICE_2W_20", 	"HPBX_PRE_CONFIG_SKIP");
		
		}

		public static String getValue(String key) {
			return wfSkipMap.get(key + "") != null ? wfSkipMap.get(key + "") : "UNKNOWN";
		}
	}
	
	public static enum MinorOrderType {
		INSTALL, LOC_ADD, OUT, IN, ACTIVATION, SBC_GROOMING, ADD_SECOND, CHANGE, PRESTAGE;
		
	}
	
	public enum ResourceVerb {
		GET_LOC_INFO;		
	}
	
	
	public static class FxoCpeUeid {
		private static Map<String, String> fxoCpeUeidMap = new HashMap<>();
		static {


			fxoCpeUeidMap.put("Cisco-4331-UUID", "Cisco-4331-UUID_FXO");
			fxoCpeUeidMap.put("CISCO1941/K9-UUID", "CISCO1941/K9-UUID_FXO");			
			fxoCpeUeidMap.put("Cisco-IOS-Trunk-UUID", 	"Cisco-IOS-Trunk-UUID_FXO");
			fxoCpeUeidMap.put("4243924F2-ADAL", 	"4243924F2-ADAL_FXO");
			fxoCpeUeidMap.put("ISR4321-V/K9-CISS", 	"ISR4321-V/K9-CISS_FXO");
			fxoCpeUeidMap.put("ISR4331/K9-CISS", 	"ISR4331/K9-CISS_FXO");
			fxoCpeUeidMap.put("CISCO1941/K9-CISS", 	"CISCO1941/K9-CISS_FXO");
			fxoCpeUeidMap.put("ISR4351-V/K9-CISS", 	"ISR4351-V/K9-CISS_FXO");
		
		}

		public static String getValue(String key) {
			return fxoCpeUeidMap.get(key + "") != null ? fxoCpeUeidMap.get(key + "") : "UNKNOWN";
		}
	}
	
	
	public static class SkipFlexWf {
		private static HashMap<String, String> wfSkipMap = new HashMap<String, String>();
		static {
			wfSkipMap.put("VZB_VM_ADD_LOC_MAILBOXES_FXO", "FLEX_SKIP");
		}
		public static String getValue(String key) {
			return wfSkipMap.get(key + "") != null ? wfSkipMap.get(key + "") : "UNKNOWN";
		}
	}
	
	public static class SkipHpbxWf {
		private static HashMap<String, String> wfSkipMap = new HashMap<String, String>();
		static {
			wfSkipMap.put("VZB_VM_ADD_LOC_MAILBOXES_FXO", "HPBX_SKIP");
			wfSkipMap.put("VZB_CSSOP_MOD_DID_GROUP_PUSH_FXO", "HPBX_SKIP");
			wfSkipMap.put("VZB_CSSOP_MOD_LINE_GROUP_PUSH_FXO", "HPBX_SKIP");
			wfSkipMap.put("VZB_CSSOP_MOD_DEVICE_SIP_FXO", "HPBX_SKIP");
			wfSkipMap.put("VZB_CSSOP_MOD_DEVICE_MGCP_FXO", "HPBX_SKIP");
			wfSkipMap.put("VZB_CSSOP_MOD_2W_TN_SYS_UPDATE", "HPBX_SKIP");
			wfSkipMap.put("VZB_CSSOP_MOD_2W_TN_SYS_UPDATE", "HPBX_SKIP");
			wfSkipMap.put("VZB_CSSOP_DEL_ENTERPRISE_PUSH_FXO", "HPBX_SKIP");
			wfSkipMap.put("VZB_CSSOP_DEL_LOCATION_PUSH_FXO", "HPBX_SKIP");
			wfSkipMap.put("VZB_CSSOP_ROLLBACK_2W_TN_SYS_UPDATE", "HPBX_SKIP");
			wfSkipMap.put("VZB_CSSOP_ROLLBACK_IB_TN_SYS_UPDATE", "HPBX_SKIP");
			wfSkipMap.put("VZB_CSSOP_ROLLBACK_DID_TN_SYS_UPDATE", "HPBX_SKIP");
			wfSkipMap.put("VZB_CSSOP_ROLLBACK_LINE_TN_SYS_UPDATE", "HPBX_SKIP");
			wfSkipMap.put("VZB_CSSOP_ADD_DEVICE_IB_FXO", "HPBX_SKIP");
			wfSkipMap.put("VZB_CSSOP_ADD_DEVICE_2W_FXO", "HPBX_SKIP");
			wfSkipMap.put("VZB_CSSOP_ADD_ENTERPRISE_PUSH_FXO", "HPBX_SKIP");
			wfSkipMap.put("VZB_CSSOP_ADD_2W_GROUP_PUSH_FXO", "HPBX_SKIP");
			wfSkipMap.put("VZB_CSSOP_ADD_IB_GROUP_PUSH_FXO", "HPBX_SKIP");
			wfSkipMap.put("VZB_CSSOP_VEC_VALIDATE", "HPBX_SKIP");
			wfSkipMap.put("VZB_CSSOP_TSO_MIG_IB_TN_FXO", "HPBX_SKIP");
			wfSkipMap.put("VZB_CSSOP_TSO_MIG_2W_TN_FXO", "HPBX_SKIP");
			wfSkipMap.put("VZB_CSSOP_ADD_ET_PUSH_IB_FXO", "HPBX_SKIP");
			wfSkipMap.put("VZB_CSSOP_ADD_ET_PUSH_2W_FXO", "HPBX_SKIP");
			wfSkipMap.put("VZB_CSSOP_ADD_LOCATION_PUSH_FXO", "HPBX_SKIP");
			wfSkipMap.put("VZB_CSSOP_ADD_DEVICE_SIP_FXO", "HPBX_SKIP");
			wfSkipMap.put("VZB_CSSOP_ADD_DEVICE_MGCP_FXO", "HPBX_SKIP");
			wfSkipMap.put("VZB_CSSOP_ADD_DID_GROUP_PUSH_FXO", "HPBX_SKIP");
			wfSkipMap.put("VZB_CSSOP_TSO_MIG_DID_TN_FXO", "HPBX_SKIP");
			wfSkipMap.put("VZB_CSSOP_ADD_LINE_GROUP_PUSH_FXO", "HPBX_SKIP");
			wfSkipMap.put("VZB_CSSOP_TSO_MIG_LINE_TN_FXO", "HPBX_SKIP");
			wfSkipMap.put("VZB_CSSOP_MOD_ENTERPRISE_PUSH_FXO", "HPBX_SKIP");
			wfSkipMap.put("VZB_CSSOP_MOD_LOCATION_PUSH_FXO", "HPBX_SKIP");
			wfSkipMap.put("VZB_CSSOP_MOD_DEVICE_2W_FXO", "HPBX_SKIP");
			wfSkipMap.put("VZB_CSSOP_MOD_DEVICE_IB_FXO", "HPBX_SKIP");
			wfSkipMap.put("VZB_CSSOP_MOD_2W_GROUP_PUSH_FXO", "HPBX_SKIP");
			wfSkipMap.put("VZB_CSSOP_MOD_IB_GROUP_PUSH_FXO", "HPBX_SKIP");
			wfSkipMap.put("VZB_CSSOP_MOD_ET_PUSH_2W_FXO", "HPBX_SKIP");
			wfSkipMap.put("VZB_CSSOP_MOD_ET_PUSH_IB_FXO", "HPBX_SKIP");
			wfSkipMap.put("VZB_CSSOP_MOD_2W_TN_SYS_UPDATE", "HPBX_SKIP");
			wfSkipMap.put("VZB_CSSOP_MOD_IB_TN_SYS_UPDATE", "HPBX_SKIP");
			wfSkipMap.put("VZB_CSSOP_MIG_DID_TN_SYSTEM_UPDATE_FXO", "HPBX_SKIP");
			wfSkipMap.put("VZB_CSSOP_MIG_LINE_TN_SYSTEM_UPDATE_FXO", "HPBX_SKIP");
			wfSkipMap.put("VZB_CSSOP_MIG_IB_TN_SYSTEM_UPDATE_FXO", "HPBX_SKIP");
			wfSkipMap.put("VZB_CSSOP_MIG_2W_TN_SYSTEM_UPDATE_FXO", "HPBX_SKIP"); 
			wfSkipMap.put("VZB_CSSOP_DEL_2W_GROUP_PUSH_FXO", "HPBX_SKIP");
			wfSkipMap.put("VZB_CSSOP_DEL_IB_GROUP_PUSH_FXO", "HPBX_SKIP");
			wfSkipMap.put("VZB_CSSOP_DEL_DID_GROUP_PUSH_FXO", "HPBX_SKIP");
			wfSkipMap.put("VZB_CSSOP_DEL_LINE_GROUP_PUSH_FXO", "HPBX_SKIP");
			
		}
		
		public static String getValue(String key) {
			return wfSkipMap.get(key + "") != null ? wfSkipMap.get(key + "") : "UNKNOWN";
		}
	}
	
	public static enum SubscriberTnType {
		PRIVATE("PRIVATE"), E164("E164"), SIDTG("SIDTG"), LOCAL("LOCAL"), IP_SIP("IP_SIP"), ALTERNATE(
				"ALTERNATE"), ALT_EXTN("ALT_EXTN"), HUNT_GROUP("HUNT_GROUP"), CALL_CENTER(
						"CALL_CENTER"), AUTO_ATTENDANT("AUTO_ATTENDANT"), VOICE_PORTAL("VOICE_PORTAL");
		public int getIndex() {
			return ordinal() + 1;
		}

		private String subscriberTnType;

		SubscriberTnType(String subscriberTnType) {
			this.subscriberTnType = subscriberTnType;
		}

		public String getValue() {
			return subscriberTnType;
		}

	}
}
