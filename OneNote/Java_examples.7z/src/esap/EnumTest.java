package esap;

import esap.EsapEnum.OrderEntity;

public class EnumTest {

	public static void main(String[] args) {
		
		for (OrderEntity orderEntity : OrderEntity.values()) {
			if(orderEntity.getIndex() - 1 == 3) {
				System.out.println("Entity::" + orderEntity.toString());
			}
		}
	}

}
