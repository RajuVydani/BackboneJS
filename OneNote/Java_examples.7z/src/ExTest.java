
public class ExTest {
	
	@FunctionalInterface
	interface Customer {
		void test();
		default void test1(){
			System.out.println("concrete method");
		}
		static void test2(){
			System.out.println("concrete method");
		}
	}

	public static void main(String[] args) {
		Customer lamdaVar = () -> System.out.println("Lambda example");
		
		lamdaVar.test();
		Customer c1 = null;
		c1.test1();
		System.out.println();
		
		Thread myThread = new Thread(new Runnable() {

			@Override
			public void run() {
				System.out.println("raju");				
			}
			
		});
	}

}
