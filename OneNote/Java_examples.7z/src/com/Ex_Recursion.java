package com;

public class Ex_Recursion {

	public static void main(String[] args) {
		System.out.println("----" + recurse(3));
	}

	private static int recurse(int num) {
		
		if(num == 0) {
			return 0;
		} else {
			num = num + recurse(num-1);			
			return num;
		}
	}

}
