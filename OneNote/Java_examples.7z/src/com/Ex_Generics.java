package com;

import java.util.Arrays;
import java.util.List;

public class Ex_Generics {

	public static void main(String[] args) {
		String [] data = {"one", "two"};
		List<String> values = Arrays.asList(data);
		printData(values);
		
		Integer [] num = {1, 2};
		List<Integer> numbers = Arrays.asList(num);
		getData(numbers);
	}
	
	public static void getData(List<?> data) {
		data.forEach(System.out::println);
	}
	
	public static <T> void printData(List<T> data) {
		data.forEach(System.out::println);
	}

}
