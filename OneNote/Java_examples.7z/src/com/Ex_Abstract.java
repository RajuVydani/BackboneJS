package com;

public class Ex_Abstract {
	{
		System.out.println("Test");
	}
	
	public static void main(String args[]) {
		new Ex_Abstract();
		new C().doStuff();
	}
}

interface A {
	default void doStuff() {
		System.out.println("A stuff");
	}
}

interface B {
	default void doStuff() {
		System.out.println("B stuff");
	}
}

class C implements A,B {
	//To avoid ambiguity, explicitly call required implementation
	@Override
	public void doStuff() { 
		B.super.doStuff();
	}
}
