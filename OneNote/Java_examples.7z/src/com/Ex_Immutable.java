package com;

import java.util.HashMap;
import java.util.Map;

public class Ex_Immutable {

	public static void main(String[] args) {
		
		String s1 = new String("Raju");
		String s2 = "Raju";
		String s3 = new String("Raju");
		String s4 = "Raju";
		
		System.out.println(s1 == s3);
		System.out.println(s2 == s4);
		
		Map<String, Integer> data = new HashMap<>();
		data.put(s1, 1);
		data.put(s3, 3);
		
		System.out.println("Before::" + data);		
		s1 = new String("Prasad");		
		System.out.println("After::" + data);
		
		Immutable I1 = new Immutable("one");
		Map<Immutable, Integer> Idata = new HashMap<>();
		Idata.put(I1, 1);
		
		System.out.println("Before::" + Idata);		
		I1.setName("Two");		
		System.out.println("After::" + Idata);
	}

}

final class Immutable {
	private String name;
	
	public Immutable(String name) {
		this.name = name;
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}

	@Override
	public String toString() {
		return "Immutable [name=" + name + "]";
	}
	
	
}
