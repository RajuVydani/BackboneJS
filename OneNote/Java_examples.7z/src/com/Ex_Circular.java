package com;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.Future;
import java.util.stream.Collectors;

public class Ex_Circular {

	public static void main(String[] args) {
		String word = "abc";
		String circularWord = "bca";
		
		StringBuilder sb = new StringBuilder();
		sb.append(word);
		sb.append(word);
		
		System.out.println(sb);
		
		System.out.println(sb.indexOf(circularWord) != -1 ? "Circular" : "No");
		
		//
		char [] letters = {'a', 'b', 'c'};
		for(int i=0; i < letters.length; i++) {
			System.out.println(letters[i]);
		}
		
		System.out.println("=========================");
		
		for(int i = letters.length-1; i >= 0; i--) {
			System.out.println(letters[i]);
		}
		
		System.out.println(3%10);
		System.out.println("div-" + 6/10);
		
		int mat[][] = { { 4, 0, 0, 0 }, 
                { 0, 7, 0, 0 }, 
                { 0, 0, 5, 0 }, 
                { 0, 0, 0, 1 } }; 
		
		System.out.println(mat.length);
		
		int n = 0;
		while(n<5) {
			System.out.println("---" + n);
			n++;
		}

	}


}
