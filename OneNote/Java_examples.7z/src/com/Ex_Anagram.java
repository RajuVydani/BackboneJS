package com;

import java.util.Arrays;

public class Ex_Anagram {

	public static void main(String[] args) {
		String str1 = "LISTEN";
		String str2 = "SILENT";
		
		char [] str3 = str1.toCharArray();
		char [] str4 = str2.toCharArray();	
		
		Arrays.sort(str3);
		Arrays.sort(str4);
		
		Arrays.asList(str3).stream().forEach(letter -> System.out.print(letter));
		System.out.println();
		Arrays.asList(str4).stream().forEach(letter -> System.out.println(letter));
		
		System.out.println(String.valueOf(str3).equals(String.valueOf(str4)));
		
		//StringBuilder
		StringBuilder sb = new StringBuilder();
		Arrays.asList(str3).stream().forEach(letter -> sb.append(letter));
		System.out.println(sb);
		//
		System.out.println(Arrays.toString(str3));
	}

}
