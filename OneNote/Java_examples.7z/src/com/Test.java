package com;

import java.util.HashMap;
import java.util.Hashtable;
import java.util.function.Consumer;

public class Test {

	public static void main(String[] args) {
		Human human = new Human();
		human.test();
		
		Consumer<Integer> display = a -> System.out.println(a);
		display.accept(2);

	}

}

interface Person {
	static final String name = "ssss";
	public abstract int test();
}

@FunctionalInterface
interface Student {
	public int test();
	public default int test2() {
		return 2;
	}
}

class Human implements Person,Student {

	public int test() {
		System.out.println("test2" + name);
		return 2;
	}

	
}