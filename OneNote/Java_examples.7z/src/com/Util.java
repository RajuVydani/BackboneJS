package com;

import java.util.ArrayList;
import java.util.List;

public class Util {
	
	public static List<Customer> getCustomers() {
		List<Customer> customers = new ArrayList<>();
		Customer customer1 = new Customer(1, "Prasad", "HYD");
		Customer customer2 = new Customer(2, "Raju", "BNG");
		Customer customer3 = new Customer(3, "Ajay", "GUG");
		customers.add(customer1);
		customers.add(customer2);
		customers.add(customer3);
		return customers;
	}

}
