package com;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Ex_Lambda {
	public static void main(String [] args) {
		 sample();
	}
	
	public static void sample() {
		String [] values = {"bbb", "aaa"};
		List<String> data = Arrays.asList(values);
		
		List<Customer> customers = Util.getCustomers();
		System.out.println("Before::" + customers);
		customers.sort((Customer c1, Customer c2) -> c1.getName().compareTo(c2.getName()));
		System.out.println("After::" + customers);
		
		Map<String, Integer> locFeatures = new HashMap<>();
		locFeatures.put("Worktime Feature-Smart Phone", 0);
		locFeatures.put("Worktime Feature-PC", 10);
		locFeatures.put("Worktime Feature-Visual Msg", 1);
		
		List<String> names = new ArrayList<>();
		locFeatures.forEach((featureName, deltaCount) -> {
			names.add(featureName);			
		});
		
		System.out.println(names);
		
		String featureName = "feature/022";
		System.out.println(featureName.split("/")[0]);
		
	}
}
