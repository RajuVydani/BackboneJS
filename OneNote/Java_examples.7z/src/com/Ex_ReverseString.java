package com;

public class Ex_ReverseString {

	public static void main(String[] args) {
		String word = "enterprise";
		StringBuffer corWord = new StringBuffer();
		StringBuffer revWord = new StringBuffer();
		char [] letters = word.toCharArray();
		
		/*
		 * for(Character chars : word.toCharArray()) { revWord.app }
		 */
		System.out.println(letters.length);
		System.out.println(letters[9]);
		for(int i=letters.length ; i>0; i--) {
			revWord.append(letters[i]);
		}
		System.out.println(revWord);
		
		for(int i=0 ; i<letters.length; i++) {
			corWord.append(letters[i]);
		}
		System.out.println(corWord);
	}

}
