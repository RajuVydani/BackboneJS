package com;

public class ExConstructor {

	public static void main(String[] args) {
		Animal animal = new Animal("raju");
		animal.add(2D);
		System.out.println("End");
	}

}

class Animal {
	Animal() {
		
	}
	
	Animal(String name) {
		
	}
	
	public short add(short x) {
		System.out.println("short");
		return x;
	}
	
	public int add(int x) {
		System.out.println("int");
		return x;
	}
	
	public long add(long x) {
		System.out.println("long");
		return x;
	}
	
	public double add(double x) {
		System.out.println("long");
		return x;
	}
}

class panda {
	
}
