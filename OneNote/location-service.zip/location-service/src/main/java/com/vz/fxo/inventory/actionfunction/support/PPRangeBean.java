package com.vz.fxo.inventory.actionfunction.support;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

public class PPRangeBean {


	protected long prefixPlanId;
	protected String rangeStart;
	protected String rangeEnd;
	protected long numstrip;
	protected String addPrefix;
	protected long noa;
	protected long blkstat;
	protected String createdBy;
	protected Timestamp creationDate;
	protected Timestamp lastModifiedDate;
	protected String modifiedBy;
	protected List<String> logTrail;
	protected List<PPRangeBean> pPRangeBeanList;
	
	public PPRangeBean() {
		this.prefixPlanId = 0;
		this.rangeStart = new String("");
		this.rangeEnd = new String("");
		this.numstrip = -1;
		this.addPrefix = new String("NONE");
		this.noa = -1;
		this.blkstat = -1;
		this.creationDate = null;
		this.lastModifiedDate = null;
		this.logTrail = new ArrayList<String>();
		this.pPRangeBeanList = null;
	}

	public PPRangeBean(PPRangeBean pPRange) {
		this.prefixPlanId = pPRange.getPrefixPlanId();
        this.rangeStart = pPRange.getRangeStart();
        this.rangeEnd = pPRange.getRangeEnd();
        this.numstrip = pPRange.getNumstrip();
        this.addPrefix = pPRange.getAddPrefix();
        this.noa = pPRange.getNoa();
        this.blkstat = pPRange.getBlkstat();
		this.createdBy= pPRange.getCreatedBy();
		this.modifiedBy = pPRange.getModifiedBy();
		this.creationDate = pPRange.getCreationDate();
		this.lastModifiedDate = pPRange.getLastModifiedDate();
		this.pPRangeBeanList = pPRange.getPPRangeBeanList();
	}

	public long getPrefixPlanId() {
        return prefixPlanId;
    }
    public void setPrefixPlanId(long prefixPlanId) {
        this.prefixPlanId = prefixPlanId;
    }

	public String getRangeStart() {
		return rangeStart;
	}
	public void setRangeStart(String rangeStart) {
		this.rangeStart = rangeStart;
	}
	
	public String getRangeEnd() {
        return rangeEnd;
    }
    public void setRangeEnd(String rangeEnd) {
        this.rangeEnd = rangeEnd;
    }
	
	public long getNumstrip() {
		return numstrip;
	}
	public void setNumstrip(long numstrip) {
		this.numstrip = numstrip;
	}

	public String getAddPrefix() {
		return addPrefix;
	}
	public void setAddPrefix(String addPrefix) {
		this.addPrefix= addPrefix;
	}
	
	public long getNoa() {
        return noa;
    }
    public void setNoa(long noa) {
        this.noa= noa;
    }

	public long getBlkstat() {
        return blkstat;
    }
    public void setBlkstat(long blkstat) {
        this.blkstat = blkstat;
    }

	public void setCreationDate(Timestamp creationDate) {
		this.creationDate = creationDate;
	}

	public Timestamp getCreationDate() {
		return creationDate;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}	

	public Timestamp getLastModifiedDate() {
		return lastModifiedDate;
	}	

	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	
    public void setLogTrail(String logStr) {
		logTrail.add(logStr);
	}

	public List<String> getLogTrail() {
		return logTrail;
	}

	public void setPPRangeBeanList(List<PPRangeBean> pprBeanList) {
        this.pPRangeBeanList = pprBeanList;
    }

    public List<PPRangeBean> getPPRangeBeanList() {
        return pPRangeBeanList;
    }


}
