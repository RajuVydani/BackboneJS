package com.vz.fxo.inventory.actionfunction.support;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Timestamp;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import esap.db.DBTblAuthServices;
import esap.db.DBTblVzbFeatures;
import esap.db.TblAuthServicesQuery;
import esap.db.TblVzbFeaturesDbBean;
import esap.db.TblVzbFeaturesQuery;

public class Features extends FeaturesBean
{
	private static Logger log = LoggerFactory.getLogger(Features.class.toString());
	
	Connection dbCon;
    String statusDesc;
    InvErrorCode statusCode = InvErrorCode.INTERNAL_ERROR;

	public int getStatusCode() {
		return statusCode.getErrorCode();
	}
	public void setStatusCode(InvErrorCode statusCode) {
		this.statusCode = statusCode;
	}
    public String getStatusDesc()
    {
        return statusDesc;
    }

    public void setStatusDesc(String statusDesc)
    {
        this.statusDesc = statusDesc;
    }

    public Connection getDbCon()
    {
        return dbCon;
    }

    public void setDbCon(Connection dbCon)
    {
        this.dbCon = dbCon;
    }

    public Features(Connection dbCon)
    {
        this.dbCon = dbCon;
    }

    public Features(FeaturesBean featsBean, Connection dbCon)
    {
        super(featsBean);
        this.dbCon = dbCon;
    }

	public boolean addAuthServices()
	{
		log.info("Entering Features : addAuthServices()");
		try
		{
			DBTblAuthServices authDbBean = new DBTblAuthServices();
			authDbBean.setAuthServiceId(getAuthServiceId());
			log.info("AuthServiceId is {}" , getAuthServiceId());
			authDbBean.setFeatureId(getFeaturesDbBean().getFeatureId());
			if(getIsAuthorized() == true)
                        authDbBean.setIsAuthorized("Y");
			else
                        authDbBean.setIsAuthorized("N");
                        if(getEnvOrderId() > 0)
				authDbBean.setEnvOrderId(getEnvOrderId());	
			else
				authDbBean.setEnvOrderIdNull();	
                        if(getCreatedBy() != null && !getCreatedBy().equals("") )
				authDbBean.setCreatedBy(getCreatedBy());
			else
				authDbBean.setCreatedBy("ESAP_INV");
			if(getModifiedBy() != null && !getModifiedBy().equals(""))
				authDbBean.setModifiedBy(getModifiedBy());
			else
				authDbBean.setModifiedBy("ESAP_INV");

            authDbBean.setCreationDate(new Timestamp(System.currentTimeMillis()));
            authDbBean.setLastModifiedDate(new Timestamp(System.currentTimeMillis()));

            log.info("Feature ID is {}" , authDbBean.getFeatureId());

			authDbBean.insert(dbCon);
		}
		catch(SQLException s)
		{
			s.printStackTrace();
			setStatusCode(InvErrorCode.DB_EXCEPTION);
			setStatusDesc("DB_FAILURE in addAuthServices");
			log.info("DB_FAILURE in addAuthServices");
			return false;
		}
		setStatusCode(InvErrorCode.SUCCESS);
		setStatusDesc("Successfully inserted Auth Services");
		return true;
	}

    public boolean getFeatureByFeatureNameAndType(String featureName, String featureType)
    {
    	log.info("Entering Features : getFeatureByFeatureName(), arg= {}, {}",featureName,featureType);
        try
        {
            TblVzbFeaturesQuery featQry = new TblVzbFeaturesQuery();
            String whereClause = " where name='"+featureName+"' and feature_type='"+featureType+"'";
            featQry.queryByWhere(dbCon, whereClause);

            if (featQry.size() <= 0)
            {
                setStatusCode(InvErrorCode.NOTFOUND_VZB_FEATURE);
                log.info("Feature not Found in TblVzbFeatures matching the inputs");
                return false;
            }

            TblVzbFeaturesDbBean featBean = featQry.getDbBean(0);

            featuresDbBean.setName(featBean.getName());
            featuresDbBean.setFeatureId(featBean.getFeatureId());
            featuresDbBean.setFeatureType(featBean.getFeatureType());
        }
        catch (SQLException e)
        {
            e.printStackTrace();
            setStatusCode(InvErrorCode.DB_EXCEPTION);
            setStatusDesc("DB_FAILURE in getFeatureByFeatureId");
            return false;
        }
        catch (Exception e)
        {
            e.printStackTrace();
            setStatusCode(InvErrorCode.DB_EXCEPTION);
            setStatusDesc("FAILURE in getFeatureByFeatureId");
            return false;
        }

        setStatusCode(InvErrorCode.SUCCESS);
        setStatusDesc("Successfully retrieved Features");
        return true;
    }

    //EnterpriseId will be set before calling this method.
    /*public boolean getFeatureByEnterpriseId()
    {
        try
        {
            TblVzbFeaturesQuery featQry = new TblVzbFeaturesQuery();

            featQry.query(dbCon);
            if (featQry.size() <= 0)
            {
                LogUtil.info("Feature Id not Found");
            }
            TblVzbFeaturesDbBean featBean = featQry.getDbBean(0);

            setLastModifiedDate(featBean.getLastModifiedDate());
            // setBroadsoftHidden(featBean.getIsBroadsoftHidden());//TODO getIsBroadsoftHidden is undefined for type TblVzbFeaturesDbBean
            setModifiedBy(featBean.getModifiedBy());
            setFeatureType(featBean.getFeatureType());
            setFeatureId(featBean.getFeatureId());
              if(featBean.getIsBillable() == 1)
            	  setIsBillable(true);
              else
            	  setIsBillable(false);
              if(featBean.getIsAuthorized() == 1)
            	  setIsAuthorized(true);
              else
            	  setIsAuthorized(false);
            setIcpId(featBean.getIcpId());
            setIasaId(featBean.getIasaId());
            setPlatformIndicator(featBean.getPlatformIndicator());
            setDescription(featBean.getDescription());
            setName(featBean.getName());

        }
        catch (SQLException e)
        {
            e.printStackTrace();
            setStatusCode(InvErrorCode.DB_EXCEPTION);
            setStatusDesc("DB_FAILURE in getFeatureByEnterpriseId");
            return false;
        }
        catch (Exception e)
        {
            e.printStackTrace();
            setStatusCode(InvErrorCode.DB_EXCEPTION);
            setStatusDesc("FAILURE in getFeatureByEnterpriseId");
            return false;
        }

        setStatusCode(InvErrorCode.SUCCESS);
        setStatusDesc("Successfully retrieved feature");
        return true;
    }*/

    public boolean deleteAuthServices() throws SQLException, Exception
	{
    	log.info("Entering ::deleteAuthServices");

	//	try
	//	{
			if(getAuthServiceId() <= 0)
                        {
                        setStatusCode(InvErrorCode.INVALID_INPUT);
                        return false;
                        }

			DBTblAuthServices authDbBean = new DBTblAuthServices();
			authDbBean.whereAuthServiceIdEQ(getAuthServiceId());
			authDbBean.deleteByWhere(dbCon);
		/*}
		catch (SQLException s)
		{
			s.printStackTrace();
			setStatusCode(InvErrorCode.DB_EXCEPTION);
			setStatusDesc("DB_FAILURE in delete AuthServices");
			return false;
		}*/
		setStatusCode(InvErrorCode.SUCCESS);
		setStatusDesc("Successfully deleted AuthServices ");
		return true;
	}

    public boolean updateAuthServices()
	{
		try
		{
			if(getAuthServiceId() <= 0){
				setStatusCode(InvErrorCode.INTERNAL_ERROR);
				log.info("FAILURE in updateAuthServices. AuthServiceId missing.");
				return false;
			}
			DBTblAuthServices authDbBean = getAuthServicesToUpdate();
			authDbBean.whereAuthServiceIdEQ(getAuthServiceId());
                        if(authDbBean.updateSpByWhere(dbCon) <= 0)
				return false; 

		} catch(SQLException s) {
            		s.printStackTrace();
			setStatusCode(InvErrorCode.DB_EXCEPTION);
			log.info("DB_FAILURE in updateAuthServices");
			return false;
		}
		setStatusCode(InvErrorCode.SUCCESS);
		setStatusDesc("Successfully update AuthServices");
		return true;
	}
        private DBTblAuthServices getAuthServicesToUpdate() throws SQLException {
		DBTblAuthServices authDbBean = new DBTblAuthServices();
		FeaturesBean defaultFeatureBean = new FeaturesBean();


		Features inputFeatures = this;

		/*Set the new fields if required.*/

		authDbBean.setAuthServiceId(getAuthServiceId());

		if((inputFeatures.getFeaturesDbBean()).getFeatureId() != (defaultFeatureBean.getFeaturesDbBean()).getFeatureId()){
			authDbBean.setFeatureId((inputFeatures.getFeaturesDbBean()).getFeatureId());
		}

		if ( Boolean.toString(inputFeatures.getIsAuthorized()) != null &&
				(inputFeatures.getIsAuthorized() == defaultFeatureBean.getIsAuthorized()) ){
			if(inputFeatures.getIsAuthorized() == true)
				authDbBean.setIsAuthorized("Y");
			else
				authDbBean.setIsAuthorized("N");
		}
               if(inputFeatures.getEnvOrderId() != defaultFeatureBean.getEnvOrderId()){
			authDbBean.setEnvOrderId(inputFeatures.getEnvOrderId());
		} 
		if(inputFeatures.getModifiedBy() != null &&
				!( "".equalsIgnoreCase(inputFeatures.getModifiedBy()) ))
			authDbBean.setModifiedBy(getModifiedBy());
		else
			authDbBean.setModifiedBy("ESAP_INV");

		authDbBean.setLastModifiedDate(new Timestamp(System.currentTimeMillis()));
		return authDbBean;
	}

	public boolean getAuthServicesDetails() throws SQLException
	{
		try
		{
			log.info("In Features getDetails; AuthService id="+getAuthServiceId());
			TblAuthServicesQuery authServiceQry = new TblAuthServicesQuery();
			String whereClause = " where auth_service_id = \'"+getAuthServiceId()+"\'";
			authServiceQry.queryByWhere(dbCon, whereClause);
			if(authServiceQry.size() == 1){

				setAuthServiceId((authServiceQry.getDbBean(0)).getAuthServiceId());
				//setFeatureId((authServiceQry.getDbBean(0)).getFeatureId());
				TblVzbFeaturesQuery vzbFeatQry = new TblVzbFeaturesQuery();
				vzbFeatQry.whereFeatureIdEQ((int)(authServiceQry.getDbBean(0)).getFeatureId());
				vzbFeatQry.query(dbCon);
				if(vzbFeatQry.size() >  0)
				{
					DBTblVzbFeatures vzbFeatDbBean = new DBTblVzbFeatures();
					vzbFeatDbBean.copyFromBean(vzbFeatQry.getDbBean(0));
					setFeaturesDbBean(vzbFeatDbBean);
				}
				if((authServiceQry.getDbBean(0)).getIsAuthorized().equalsIgnoreCase("Y"))
                                 setIsAuthorized(true);
				else
                                 setIsAuthorized(false);
	                        setEnvOrderId((authServiceQry.getDbBean(0)).getEnvOrderId());		
                         	setCreatedBy((authServiceQry.getDbBean(0)).getCreatedBy());
				setModifiedBy((authServiceQry.getDbBean(0)).getModifiedBy());

			}else
			{
				setStatusCode(InvErrorCode.DB_EXCEPTION);
				setStatusDesc("FAILURE in getAuthServicesDetails .Couldn't find any entry with the given AuthServiceId");
				return false;
			}
		}catch(SQLException s)
		{
            		s.printStackTrace();
			setStatusCode(InvErrorCode.DB_EXCEPTION);
			setStatusDesc("DB_FAILURE in getAuthServicesDetails");
			return false;
		}
		setStatusCode(InvErrorCode.SUCCESS);
		setStatusDesc("Successfully retrieved Auth Services from db");
		return true;
	}

}
