package com.vz.fxo.inventory.actionfunction.support;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

public class PrefixPlanTpltBean {
	

	protected String countryCode;
	protected short platformIndicator;
	protected String prefixName;
	protected long mobile;
	protected String createdBy;
	protected Timestamp creationDate;
	protected Timestamp lastModifiedDate;
	protected String modifiedBy;
	protected List<String> logTrail;
	
	public PrefixPlanTpltBean() {
		this.countryCode = new String("");
		this.platformIndicator = 0;
		this.prefixName = new String("");
		this.mobile = 0;
		this.creationDate = null;
		this.lastModifiedDate = null;
		this.logTrail = new ArrayList<String>();
	}

	public PrefixPlanTpltBean(PrefixPlanTpltBean pPlanTplt) {
		this.countryCode = pPlanTplt.getCountryCode();
        this.platformIndicator = pPlanTplt.getPlatformIndicator();
        this.prefixName = pPlanTplt.getPrefixName();
        this.mobile = pPlanTplt.getMobile();
		this.createdBy= pPlanTplt.getCreatedBy();
		this.modifiedBy = pPlanTplt.getModifiedBy();
		this.creationDate = pPlanTplt.getCreationDate();
		this.lastModifiedDate = pPlanTplt.getLastModifiedDate();
		this.logTrail = pPlanTplt.logTrail;
	}

	public String getCountryCode() {
		return countryCode;
	}
	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}
	
	public short getPlatformIndicator() {
		return platformIndicator;
	}
	public void setPlatformIndicator(short platformIndicator) {
		this.platformIndicator = platformIndicator;
	}

	public String getPrefixName() {
		return prefixName;
	}
	public void setPrefixName(String prefixName) {
		this.prefixName = prefixName;
	}
	
	public long getMobile() {
		return mobile;
	}
	public void setMobile(long mobile) {
		this.mobile = mobile;
	}

	public void setCreationDate(Timestamp creationDate) {
		this.creationDate = creationDate;
	}

	public Timestamp getCreationDate() {
		return creationDate;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}	

	public Timestamp getLastModifiedDate() {
		return lastModifiedDate;
	}	

	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	
    public void setLogTrail(String logStr) {
		logTrail.add(logStr);
	}

	public List<String> getLogTrail() {
		return logTrail;
	}

	public String toString() {
		return "PrefixPlanTpltBean=[" + "countryCode=" + countryCode + ", "
				+ "platformIndicator=" + platformIndicator + ", " + "prefixName="
				+ prefixName + ", " + "mobile=" + mobile + ", " 
				+"createdBy=" + createdBy + ", " + "creationDate="
				+ creationDate + ", " + "lastModifiedDate=" + lastModifiedDate + ","
				+ "modifiedBy=" + modifiedBy +"]";
	}



}
