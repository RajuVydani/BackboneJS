package com.vz.fxo.inventory.actionfunction.support;

import java.sql.Connection;
import java.sql.SQLException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import esap.db.DBTblTsoRoutingGroup;
import esap.db.DBTblTsoTrunkGroup;
import esap.db.TblTsoRoutingGroupQuery;
import esap.db.TblTsoTrunkGroupQuery;

public class TsoTrunkGroup extends TsoTrunkGroupBean {
	
	private static Logger log = LoggerFactory.getLogger(TsoTrunkGroup.class.toString());
	
	private InvErrorCode status;
    Connection dbCon;
    String statusDesc;
    
	public InvErrorCode getStatus() {
		return status;
	}
	public void setStatus(InvErrorCode status) {
		this.status = status;
	}
	public Connection getDbCon() {
		return dbCon;
	}
	public void setDbCon(Connection dbCon) {
		this.dbCon = dbCon;
	}
	public String getStatusDesc() {
		return statusDesc;
	}
	public void setStatusDesc(String statusDesc) {
		this.statusDesc = statusDesc;
	}
	
	public boolean addToDB() throws SQLException,Exception{
			    
		DBTblTsoTrunkGroup  tsoTrunkGroupDbBean=new DBTblTsoTrunkGroup();
			    
		tsoTrunkGroupDbBean.setTrunkGroupId(trunkGroupId);
		if (trunkGroupName != null)	
		{
		trunkGroupName = trunkGroupName.replaceAll(" ", "_");
		log.info(" trunkGroupName " + trunkGroupName);
		}
		tsoTrunkGroupDbBean.setTrunkGroupName(trunkGroupName);
    	tsoTrunkGroupDbBean.setTgrpId(tgrpId);
    	tsoTrunkGroupDbBean.setRoutingGroupId(routingGroupId);
    	tsoTrunkGroupDbBean.setPilotUserUserId(pilotUserUserId);
    	tsoTrunkGroupDbBean.setPilotExtension(pilotExtension);
    	tsoTrunkGroupDbBean.setNwkNodeDeviceId(nwkNodeDeviceId);
    	tsoTrunkGroupDbBean.setEbiId(ebiId);
    	tsoTrunkGroupDbBean.setDeviceId(deviceId);
    	tsoTrunkGroupDbBean.setBsDeviceType(bsDeviceType);
    	tsoTrunkGroupDbBean.setDeviceFqdn(deviceFqdn);
    	tsoTrunkGroupDbBean.setLinePort(linePort);
    	tsoTrunkGroupDbBean.setCreatedBy(createdBy);
    	tsoTrunkGroupDbBean.setModifiedBy(modifiedBy);
    	tsoTrunkGroupDbBean.setCreationDate(creationDate);
    	tsoTrunkGroupDbBean.setLastModifiedDate(lastModifiedDate);
		
	return true;
  }
	
	public boolean modifyInDB() throws SQLException, Exception {
		
        if (trunkGroupId == 0)
        {
            //setStatus(InvErrorCode.MISSING_LOCATION_ID);
            log.info("FAILURE in modifyInDB trunkGroup. trunkGroup Id missing.");
            return false;
        }
        DBTblTsoTrunkGroup  tsoTrunkGroupDbBean = getTsoTrunkGroupToUpdate();
        log.info("Got TsoTrunkGroup Details to Update for trunkGroupId:" + trunkGroupId);
        tsoTrunkGroupDbBean.whereTrunkGroupIdEQ(trunkGroupId);
        log.info("Going to Update TsoTrunkGroup in DB");
        //FkValidationUtil.isValidLocationForMod(dbCon,tsoEnterpriseDbBean);
        
        if ( tsoTrunkGroupDbBean.updateSpByWhere(dbCon) <= 0 ) {
        	log.info("No TsoTrunkGroup updated");
        	//setStatus(InvErrorCode.NO_LOCATION_UPDATED);
          return false;
        }
        log.info("Successfully updated TsoTrunkGroup");
        setStatus(InvErrorCode.SUCCESS);
        log.info("Successfully UPDATED TsoTrunkGroup into the DB");
     return true;
}
	private DBTblTsoTrunkGroup getTsoTrunkGroupToUpdate() throws SQLException {
		
		DBTblTsoTrunkGroup  tsoTrunkGroupDbBean=new DBTblTsoTrunkGroup();
		
  	    /* Create a new instance of tsoTrunkGroupDbBean. The new instance
	         * would hold default values for the all the tsoTrunkGroupDbBean fields.*/
		
		  TsoTrunkGroupBean defaultTsoTrunkGroupBean = new TsoTrunkGroupBean();
		  TsoTrunkGroup inputTsoTrunkGroup = this;
		  tsoTrunkGroupDbBean.setTrunkGroupId(trunkGroupId);
		  TblTsoTrunkGroupQuery  tsotrnkQry=new TblTsoTrunkGroupQuery();
		  tsotrnkQry.whereTrunkGroupIdEQ(inputTsoTrunkGroup.getTrunkGroupId());
		  tsotrnkQry.query(dbCon);
		  
		  if (inputTsoTrunkGroup.getTrunkGroupName() != null
	                && !inputTsoTrunkGroup.getTrunkGroupName().equals(defaultTsoTrunkGroupBean.getTrunkGroupName())){
				if (inputTsoTrunkGroup.getTrunkGroupName() != null)	
				{
					String trunkGroupName =  inputTsoTrunkGroup.getTrunkGroupName().replace(" ", "_");
					inputTsoTrunkGroup.setTrunkGroupName(trunkGroupName);
				}
			  tsoTrunkGroupDbBean.setTrunkGroupName(inputTsoTrunkGroup.getTrunkGroupName());
	        }
		  if (inputTsoTrunkGroup.getTgrpId()!= null
	                && !inputTsoTrunkGroup.getTgrpId().equals(defaultTsoTrunkGroupBean.getTgrpId())){
			  tsoTrunkGroupDbBean.setTgrpId(inputTsoTrunkGroup.getTgrpId());
		  }
		  if (inputTsoTrunkGroup.getRoutingGroupId()!= null
	                && inputTsoTrunkGroup.getRoutingGroupId().equals(defaultTsoTrunkGroupBean.getRoutingGroupId())){
			  tsoTrunkGroupDbBean.setRoutingGroupId(inputTsoTrunkGroup.getRoutingGroupId());
		  }
		  if (inputTsoTrunkGroup.getPilotUserUserId() != null
	                && !inputTsoTrunkGroup.getPilotUserUserId().equals(defaultTsoTrunkGroupBean.getPilotUserUserId())){
			  tsoTrunkGroupDbBean.setPilotUserUserId(inputTsoTrunkGroup.getPilotUserUserId());
	        }
		  if (inputTsoTrunkGroup.getNwkNodeDeviceId() !=0
	                && inputTsoTrunkGroup.getNwkNodeDeviceId()!=defaultTsoTrunkGroupBean.getNwkNodeDeviceId()){
			  tsoTrunkGroupDbBean.setNwkNodeDeviceId(inputTsoTrunkGroup.getNwkNodeDeviceId());
	        }
		  if (inputTsoTrunkGroup.getEbiId() != 0
	                && inputTsoTrunkGroup.getEbiId()!=defaultTsoTrunkGroupBean.getEbiId()){
			  tsoTrunkGroupDbBean.setEbiId(inputTsoTrunkGroup.getEbiId());
	        }
		  if (inputTsoTrunkGroup.getDeviceId() != 0
	                && inputTsoTrunkGroup.getDeviceId()!=defaultTsoTrunkGroupBean.getDeviceId()){
			  tsoTrunkGroupDbBean.setDeviceId(inputTsoTrunkGroup.getDeviceId());
	        }
		  if (inputTsoTrunkGroup.getBsDeviceType() != null
	                && !inputTsoTrunkGroup.getBsDeviceType().equals(defaultTsoTrunkGroupBean.getBsDeviceType())){
      	     tsoTrunkGroupDbBean.setBsDeviceType(inputTsoTrunkGroup.getBsDeviceType());
		  }
		  if (inputTsoTrunkGroup.getDeviceFqdn() != null
	                && !inputTsoTrunkGroup.getDeviceFqdn().equals(defaultTsoTrunkGroupBean.getDeviceFqdn())){
    	     tsoTrunkGroupDbBean.setDeviceFqdn(inputTsoTrunkGroup.getDeviceFqdn());
		  }
		  if (inputTsoTrunkGroup.getLinePort() != null
	                && !inputTsoTrunkGroup.getLinePort().equals(defaultTsoTrunkGroupBean.getLinePort())){
    	     tsoTrunkGroupDbBean.setLinePort(inputTsoTrunkGroup.getLinePort());
		  }
		  if (inputTsoTrunkGroup.getModifiedBy() != null
	                && !inputTsoTrunkGroup.getModifiedBy().equals(defaultTsoTrunkGroupBean.getModifiedBy())){
			  tsoTrunkGroupDbBean.setModifiedBy(inputTsoTrunkGroup.getModifiedBy());
		  }
		  if (inputTsoTrunkGroup.getLastModifiedDate()!= null
	                && !inputTsoTrunkGroup.getLastModifiedDate().equals(defaultTsoTrunkGroupBean.getLastModifiedDate())){
			  tsoTrunkGroupDbBean.setLastModifiedDate(inputTsoTrunkGroup.getLastModifiedDate());
		  }

	     return tsoTrunkGroupDbBean;
	   }
	
	 public boolean deleteFromDB() throws SQLException, Exception {
			
			if(getTrunkGroupId() == 0){
							log.info("Invalid Input");
							setStatus(InvErrorCode.INVALID_INPUT);
							return false;
			}
						
			DBTblTsoTrunkGroup  tsoTrunkGroupDbBean=new DBTblTsoTrunkGroup();
			tsoTrunkGroupDbBean.whereTrunkGroupIdEQ(getTrunkGroupId());
			tsoTrunkGroupDbBean.deleteByWhere(dbCon);
			
			log.info("Successfully deleted TsoTrunkGroup");
			setStatusDesc("Successfully deleted TsoTrunkGroup");
			
			return true;
		  }
	 
	 public boolean deleteFromDBbyEbiId() throws SQLException, Exception {
			
			if(getEbiId() == 0){
							log.info("Invalid Input");
							setStatus(InvErrorCode.INVALID_INPUT);
							return false;
			}
						
			DBTblTsoTrunkGroup  tsoTrunkGroupDbBean=new DBTblTsoTrunkGroup();
			tsoTrunkGroupDbBean.whereEbiIdEQ(getEbiId());
			tsoTrunkGroupDbBean.deleteByWhere(dbCon);
			
			log.info("Successfully deleted TsoTrunkGroup");
			setStatusDesc("Successfully deleted TsoTrunkGroup");
			
			return true;
		  }
    

}
