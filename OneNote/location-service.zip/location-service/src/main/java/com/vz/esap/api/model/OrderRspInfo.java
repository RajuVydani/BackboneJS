package com.vz.esap.api.model;

public class OrderRspInfo {
	
	
	  /*{
	    "action": "string",
	    "flowStatus": 0,
	    "leaf": 0,
	    "orderId": 0,
	    "paramName": "string",
	    "paramType": "string",
	    "paramValue": "string",
	    "parentId": 0,
	    "rspId": 0,
	    "seqNo": 0
	  }*/
	

	private Long rspId;
	private Long parentId;
	private Long orderId;
	private Long seqNo;
	private String action;
	private String paramType;
	private String paramName;
	private String paramValue;
	private Long flowStatus;
	private Long leaf;
	public Long getRspId() {
		return rspId;
	}
	public void setRspId(Long rspId) {
		this.rspId = rspId;
	}
	public Long getParentId() {
		return parentId;
	}
	public void setParentId(Long parentId) {
		this.parentId = parentId;
	}
	public Long getOrderId() {
		return orderId;
	}
	public void setOrderId(Long orderId) {
		this.orderId = orderId;
	}
	public Long getSeqNo() {
		return seqNo;
	}
	public void setSeqNo(Long seqNo) {
		this.seqNo = seqNo;
	}
	public String getAction() {
		return action;
	}
	public void setAction(String action) {
		this.action = action;
	}
	public String getParamType() {
		return paramType;
	}
	public void setParamType(String paramType) {
		this.paramType = paramType;
	}
	public String getParamName() {
		return paramName;
	}
	public void setParamName(String paramName) {
		this.paramName = paramName;
	}
	public String getParamValue() {
		return paramValue;
	}
	public void setParamValue(String paramValue) {
		this.paramValue = paramValue;
	}
	public Long getFlowStatus() {
		return flowStatus;
	}
	public void setFlowStatus(Long flowStatus) {
		this.flowStatus = flowStatus;
	}
	public Long getLeaf() {
		return leaf;
	}
	public void setLeaf(Long leaf) {
		this.leaf = leaf;
	}
	
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("OrderRspInfo [rspId=");
		builder.append(rspId);
		builder.append(", parentId=");
		builder.append(parentId);
		builder.append(", orderId=");
		builder.append(orderId);
		builder.append(", seqNo=");
		builder.append(seqNo);
		builder.append(", action=");
		builder.append(action);
		builder.append(", paramType=");
		builder.append(paramType);
		builder.append(", paramName=");
		builder.append(paramName);
		builder.append(", paramValue=");
		builder.append(paramValue);
		builder.append(", flowStatus=");
		builder.append(flowStatus);
		builder.append(", leaf=");
		builder.append(leaf);
		builder.append("]");
		return builder.toString();
	}
	
	

}
