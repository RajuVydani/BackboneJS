package com.vz.fxo.inventory.actionfunction.support; 

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import EsapEnumPkg.VzbVoipEnum;
import esap.db.DBTblDeviceMap;
import esap.db.DBTblLocPackage;
import esap.db.DBTblPackage;
import esap.db.DBTblPkgFeatures;
import esap.db.DBTblPublicTnPool;
import esap.db.DBTblSubscriber;
import esap.db.DBTblSubscriberTn;
import esap.db.TblDeviceTypesQuery;
import esap.db.TblLocPackageQuery;
import esap.db.TblLocationQuery;
import esap.db.TblPackageQuery;
import esap.db.TblSubFeatureDbBean;
import esap.db.TblSubFeatureQuery;
import esap.db.TblSubscriberDbBean;
import esap.db.TblSubscriberDeviceDbBean;
import esap.db.TblSubscriberDeviceQuery;
import esap.db.TblSubscriberQuery;
import esap.db.TblSubscriberTnDbBean;
import esap.db.TblSubscriberTnQuery;
import esap.db.TblVmBoxSizeQuery;
import esap.db.TblVzbFeaturesQuery;

public class Subscriber extends SubscriberBean
{
	
	private static Logger log = LoggerFactory.getLogger(Subscriber.class
			.toString());
    //members
    private Connection connection;
    InvErrorCode status = InvErrorCode.INTERNAL_ERROR;
    boolean rollbackFlag;
    boolean deleteCallingPlan;
    boolean deleteFeatPkg;
	private  boolean isExistingTn;
	boolean tnRemoveFlag;


    public Subscriber(Connection con)
    {
        this.connection = con;
        this.rollbackFlag = false;
		this.isExistingTn = false;
		this.deleteCallingPlan = true;
		this.deleteFeatPkg = true;
		this.tnRemoveFlag = false;
    }

    public Subscriber()
    {
        super();
        this.rollbackFlag = false;
		this.isExistingTn = false;
		this.deleteCallingPlan = true;
		this.deleteFeatPkg = true;
		this.tnRemoveFlag= false;
    }

	public boolean isTnRemoveFlag() {
		return tnRemoveFlag;
	}

	public void setTnRemoveFlag(boolean tnRemoveFlag) {
		this.tnRemoveFlag = tnRemoveFlag;
	}

	 public boolean getIsExistingTn()
        {
            return isExistingTn;
        }

        public void setIsExistingTn(boolean isExistingTn)
        {
            this.isExistingTn = isExistingTn;
        }


    public boolean getRollbackFlag()
    {
        return rollbackFlag;
    }

    public void setRollbackFlag(boolean rollbackFlag)
    {
        this.rollbackFlag = rollbackFlag;
    }

	public boolean getDeleteCallingPlan()
    {
        return deleteCallingPlan;
    }
         
    public void setDeleteCallingPlan(boolean deleteCallingPlan)
    {
        this.deleteCallingPlan = deleteCallingPlan;
    }
	public boolean getDeleteFeatPkg()
    {
        return deleteFeatPkg;
    }
         
    public void setDeleteFeatPkg(boolean deleteFeatPkg)
    {
        this.deleteFeatPkg = deleteFeatPkg;
    }


    public Connection getConnection()
    {
        return connection;
    }

    public void setConnection(Connection connection)
    {
        this.connection = connection;
    }

    public int getStatusCode()
    {
        return status.getErrorCode();
    }

    public void setStatus(InvErrorCode status)
    {
        this.status = status;
    }

    public String getStatusDesc()
    {
        return status.getErrorDesc();
    }

    public boolean validateSubscriber()
    {
        return true;
    }

    public boolean setDeletePending() throws SQLException,Exception 
    {
        if (subId == null || subId.trim().equalsIgnoreCase(""))
        {
            setStatus(InvErrorCode.INVALID_INPUT);
            return false;
        }
        DBTblSubscriber subDB = new DBTblSubscriber();
        subDB.whereSubIdEQ(subId);
        subDB.setActiveInd(VzbVoipEnum.ActiveInd.DELETE_PENDING);
        FkValidationUtil.isValidSubscriberObjForMod(connection,subDB);
        subDB.updateSpByWhere(connection);
        TblSubscriberTnQuery subTnQry = new TblSubscriberTnQuery();
        String subTnWhereCls = " where sub_id = \'" + subId + "\'";
        subTnQry.queryByWhere(connection, subTnWhereCls);
        long longTn;
        if (subTnQry.size() > 0)
        {
            String tn = subTnQry.getDbBean(0).getUserId();
            if (tn != null && !tn.equalsIgnoreCase(""))
            {
                DBTblPublicTnPool pubTnPool = new DBTblPublicTnPool();
                pubTnPool.whereTnEQ(tn);
                pubTnPool.setActiveInd(VzbVoipEnum.ActiveInd.DELETE_PENDING);
                FkValidationUtil.isValidPublicTNPoolForMod(connection,pubTnPool);
                pubTnPool.updateSpByWhere(connection);
            }
        }

		/* IR #1441163 Delete subscriber is removing custom package to Delete Pending
		 * tbl_package should not be put to delete pending if sub is removed.
        TblSubscriberQuery subQry = new TblSubscriberQuery();
        String subWhereCls = " where sub_id = \'" + subId + "\'";
        subQry.queryByWhere(connection, subWhereCls);
        if (subQry.size() > 0)
        {
            long packageId = subQry.getDbBean(0).getFeaturePkgId();
			if(packageId  > 8)
			{
            DBTblPackage pkgDb = new DBTblPackage();
            pkgDb.setActiveInd(VzbVoipEnum.ActiveInd.DELETE_PENDING);
            pkgDb.wherePackageIdEQ((int) packageId);
            pkgDb.updateSpByWhere(connection);
			}
        }
		*/
        return true;
    }

    public boolean addSubscriber() throws SQLException, Exception
    {
        log.debug("Entering Subscriber::addSubscriber");

        //try
        //{
            DBTblSubscriber subDB = new DBTblSubscriber();

            subDB.setSubId(getSubId());
            subDB.setBsSubId(getBsSubId());
            subDB.setLocationId(getLocationId());
            if(!"NONE".equals(getDepartmentId()) && !"".equals(getDepartmentId()))
            	subDB.setDepartmentId(getDepartmentId());
            subDB.setPpId(getPpId());
            if(!"NONE".equals(getLastName()) && !"".equals(getLastName()))
            	subDB.setLastName(getLastName());
            if(!"NONE".equals(getFirstName()) && !"".equals(getFirstName()))
            	subDB.setFirstName(getFirstName());
            if(!"NONE".equals(getMiddleInitial()) && !"".equals(getMiddleInitial()))
            	subDB.setMiddleInitial(getMiddleInitial());
            if(!"NONE".equals(getCompanyName()) && !"".equals(getCompanyName()))
            	subDB.setCompanyName(getCompanyName());
            if(!"NONE".equals(getEmail()) && !"".equals(getEmail()))
            	subDB.setEmail(getEmail());
            if(!"NONE".equals(getHomePhone()) && !"".equals(getHomePhone()))
            	subDB.setHomePhone(getHomePhone());
            if(!"NONE".equals(getWorkPhone()) && !"".equals(getWorkPhone()))
            	subDB.setWorkPhone(getWorkPhone());

            if(!"NONE".equals(getMobilePhone()) && !"".equals(getMobilePhone()))
            	subDB.setMobilePhone(getMobilePhone());

            if(!"NONE".equals(getTimeZone()) && !"".equals(getTimeZone()))
            	subDB.setTimeZone(getTimeZone());
			if(getWebLang() == -1)
   				subDB.setWebLang(0);
   			else
            	subDB.setWebLang(getWebLang());
			if(getAccessLevel()  != -1 )
				subDB.setAccessLevel(getAccessLevel());
			if(!"NONE".equals(getWebLoginId()) && !"".equals(getWebLoginId()))
				subDB.setWebLoginId(getWebLoginId());
            log.info("Sub id is===> "+getSubId() +" and password is==>" + getWebPassword());
            if(!"NONE".equals(getWebPassword()) && !"".equals(getWebPassword()))
            	subDB.setWebPassword(getWebPassword());
            if(!"NONE".equals(getSipUsername()) && !"".equals(getSipUsername()))
            	subDB.setSipUsername(getSipUsername());
            if(!"NONE".equals(getSipPassword()) && !"".equals(getSipPassword()))
            	subDB.setSipPassword(getSipPassword());
            if(!"NONE".equals(getSipAddress()) && !"".equals(getSipAddress()))
            	subDB.setSipAddress(getSipAddress());
            if(getMobileUser()  != -1 )
            	subDB.setMobileUser(getMobileUser());
            if(getPkgFeatureId()  != -1 )
            	subDB.setFeaturePkgId(getPkgFeatureId());
            //derive pkgfeatureId based on pkgFeatureStr
			TblLocationQuery locQry = new TblLocationQuery();
            if (getPkgFeatureStr() != null)
            {
                log.info("In getPkgFeatStr" + getPkgFeatureStr());
                long platform = 1;//IASA
           //     TblLocationQuery locQry = new TblLocationQuery();
                String whereLocClause = " where location_id = \'" + locationId + "\'";
                locQry.queryByWhere(connection, whereLocClause);
                if (locQry.size() == 1)
                {
                    platform = (locQry.getDbBean(0)).getServiceTypeOffering();
                }
                log.info("platform" + platform);
                if (platform == VzbVoipEnum.Platform.IASA)
                {
                    TblLocPackageQuery locPkgQry = new TblLocPackageQuery();
                    locPkgQry.queryByWhere(connection, whereLocClause);
                    log.info("platform" + platform);
                    if (locPkgQry.size() == 1)
                    {
                        log.info("pkg id for iasa:" + (locPkgQry.getDbBean(0)).getPackageId());
                        subDB.setFeaturePkgId((locPkgQry.getDbBean(0)).getPackageId());
                    }
                } else if (platform == VzbVoipEnum.Platform.ICP)
                {
                    //pkgFeatureStr will be used to derive the pkgFeatureId
                    TblLocPackageQuery locPkgQry = new TblLocPackageQuery();
                    locPkgQry.queryByWhere(connection, whereLocClause);
                    log.info("in icp, locpkgQry.size:" + locPkgQry.size());
                    for (int k = 0; k < locPkgQry.size(); k++)
                    {
                        TblPackageQuery pkgQry = new TblPackageQuery();
                        pkgQry.wherePackageIdEQ((locPkgQry.getDbBean(k)).getPackageId());
                        pkgQry.query(connection);
                        log.info("pkgQry sixze:" + pkgQry.size());
                        if (pkgQry.size() == 1)
                            log.info("pkg name in the db" + (pkgQry.getDbBean(0)).getPackageName());
                        if (pkgQry.size() == 1 && ((pkgQry.getDbBean(0)).getPackageName()).equals(getPkgFeatureStr()))
                        {
                            log.info("icp pkg id" + (pkgQry.getDbBean(0)).getPackageId());
                            subDB.setFeaturePkgId((pkgQry.getDbBean(0)).getPackageId());
                        }
                    }
                    log.info("after k for loop");
                }
                log.info("after if icp asa");

            } else
                log.info("featurepkgstr is null!!!!");

            if(!"NONE".equals(getCallerIdFirstName()) && !"".equals(getCallerIdFirstName()))
            	subDB.setCidFirstName(getCallerIdFirstName());
            if(!"NONE".equals(getCallerIdLastName()) && !"".equals(getCallerIdLastName()))
            	subDB.setCidLastName(getCallerIdLastName());
			if(getVmLang() == -1)
   				subDB.setVmLang(0);
   			else
   				subDB.setVmLang(getVmLang());
			
			log.debug("getVmMaxSizeId===>"+getVmMaxSizeId());
			if(getVmMaxSizeId() != -1 ) {
				if(getVmMaxSizeId() < 0)
					subDB.setVmMaxsizeNull();
				else
					subDB.setVmMaxsize(getVmMaxSizeId());
			}	
			if(!"NONE".equals(getVmBoxNum()) && !"".equals(getVmBoxNum()))
				subDB.setVmBoxNum(getVmBoxNum());
			if(!"NONE".equals(getVmRouteNum()) && !"".equals(getVmRouteNum()))
				subDB.setVmRouteNum(getVmRouteNum());
			if(!"NONE".equals(getVmPasscode()) && !"".equals(getVmPasscode()))
				subDB.setVmPasscode(getVmPasscode());
			if(!"NONE".equals(getVmPin()) && !"".equals(getVmPin()))
				subDB.setVmPin(getVmPin());
			if(getVmStatus() != -1)
				subDB.setVmStatus(getVmStatus());
            subDB.setVmActiveDate(getVmActiveDate());
            if(getVmTermDate() != -1)
            	subDB.setVmTermDate(getVmTermDate());
            if(getVmChangeDate() != -1)
            subDB.setVmChangeDate(getVmChangeDate());
            if(getSubAddrId() != -1)
            subDB.setSubAddrId(getSubAddrId());
            if(!"NONE".equals(getRpId()) && !"".equals(getRpId()))
            subDB.setRpid(getRpId());
            subDB.setRpidPriv(getRpidPriv());
            if(!"NONE".equals(getExtension()) && !"".equals(getExtension()))
            subDB.setExtension(getExtension());
			//subDB.setPubIp(getPubIp());
            if(locQry.size() == 1)
            {
                subDB.setPubIp(locQry.getDbBean(0).getPubIp());
            }
            subDB.setRegistrationType(getRegistrationType());
            subDB.setRegistrationStatus(getRegistrationStatus());
            if(!"NONE".equals(getRegistrationKey()) && !"".equals(getRegistrationKey()))
            	subDB.setRegistrationKey(getRegistrationKey());
            if(!"NONE".equals(getAdminSecretQuestion()) && !"".equals(getAdminSecretQuestion()))
            	subDB.setAdminSecretQuestion(getAdminSecretQuestion());
            if(!"NONE".equals(getAdminSecretAnswer()) && !"".equals(getAdminSecretAnswer()))
            	subDB.setAdminSecretAnswer(getAdminSecretAnswer());
            if(!"NONE".equals(getSecretQuestion()) && !"".equals(getSecretQuestion()))
            	subDB.setSecretQuestion(getSecretQuestion());
            if(!"NONE".equals(getSecretAnswer()) && !"".equals(getSecretAnswer()))
            	subDB.setSecretAnswer(getSecretAnswer());
            if(!"NONE".equals(getSearchOption()) && !"".equals(getSearchOption()))
            	subDB.setSearchOption(getSearchOption());
            if(getAllowUserSearch() != -1)
            	subDB.setAllowUserSearch(getAllowUserSearch());
            if(getCallingPlanId() != -1 ) {
			if(getCallingPlanId() > 0)
                subDB.setCallingPlanId(getCallingPlanId());
            else
                subDB.setCallingPlanIdNull();
            }
            subDB.setSubscriberType(getSubscriberType());
            if(getBrixInd() != -1 )
            	subDB.setBrixInd(getBrixInd());
			if(getUserType() != -1 )
            	subDB.setUserType(getUserType());
			else
            	subDB.setUserType(VzbVoipEnum.UserType.NORMALUSER);
	
            if(!"NONE".equals(getAuthSeed()) && !"".equals(getAuthSeed()))
            	subDB.setAuthSeed(getAuthSeed());
            if(!"NONE".equals(getAuthUserName()) && !"".equals(getAuthUserName()))
            	subDB.setAuthUserName(getAuthUserName());
            if(!"NONE".equals(getAuthPassword()) && !"".equals(getAuthPassword()))
            	subDB.setAuthPassword(getAuthPassword());
            if(!"NONE".equals(getSipRegistrarDomain()) && !"".equals(getSipRegistrarDomain()))
            	subDB.setSipRegistrarDomain(getSipRegistrarDomain());
            if(getSipRegistrationInterval() != -1 )
            	subDB.setSipRegistrationInterval(getSipRegistrationInterval());
            log.info("EnvOrderId = <" + getEnvOrderId() + ">");
			if(getFmcgSubId() <= 0)
            	subDB.setFmcgSubIdNull();
			else
            	subDB.setFmcgSubId(getFmcgSubId());
			if(getEnvOrderId()!= -1 ) {
		    if(getEnvOrderId() > 0)
		    	subDB.setEnvOrderId(getEnvOrderId()); 
		    else
		    	subDB.setEnvOrderIdNull(); 
			}

            subDB.setActiveInd(1);
            if (createdBy != null && !createdBy.trim().equals(""))
                subDB.setCreatedBy(createdBy);
            else
                subDB.setCreatedBy("ESAP_INV");
            if (modifiedBy != null && !modifiedBy.trim().equals(""))
                subDB.setModifiedBy(getModifiedBy());
            else
                subDB.setModifiedBy("ESAP_INV");


			//Adding receptionistType
            if ( receptionistType > -1){
            	subDB.setReceptionistType((short)receptionistType);
            }
            
            //Jan 2011 Release changes
            if(!"NONE".equals(getDeviceLoginId()) && !"".equals(getDeviceLoginId()))
				subDB.setDeviceLoginId(getDeviceLoginId());
            
            log.info("subDB.getDeviceLoginId ===> "+ subDB.getDeviceLoginId() );
            
            if(!"NONE".equals(getDevicePassword()) && !"".equals(getDevicePassword()))
            	subDB.setDevicePassword(getDevicePassword());
            
            log.info("subDB.getDevicePassword ===> "+ subDB.getDevicePassword() );
            
            //53266.AM APAC VOIP LNP - changes for july 2011
            subDB.setEmernoa(getEmerNoA());
            subDB.setEmergoverride(getEmergencyOverride());
                 
            subDB.setCreationDate(new Timestamp(System.currentTimeMillis()));
            subDB.setLastModifiedDate(new Timestamp(System.currentTimeMillis()));
            
            //subDB.setBillingType(billingType);								//added by z658915
            
            printSubDbObj(subDB);
            FkValidationUtil.isValidSubscriberObj(connection,subDB);
            subDB.insert(connection);
        /*}
        catch (SQLException s)
        {
            log.info("Inside addSubscriber catch block");
            setStatus(InvErrorCode.DB_EXCEPTION);
            s.printStackTrace();
            log.info("Inside cathc####");
            log.info("Status  for Subscriber::::::" + getStatusCode());
            log.info("Status decription for Subscriber::::::" + getStatusDesc());
            //setStatusDesc("DB_FAILURE in addSubscriber");
            return false;
        }*/
        setStatus(InvErrorCode.SUCCESS);
        return true;
    }

    public boolean addSubscriberEntities() throws Exception
    {
        log.info("Entering Subscriber::addSubscriberEntities");

        log.info("Add Subscriber");
        if (addSubscriber() != true)
        {
            log.info("Failed to Add Subscriber");
            return false;
        }
        setLogTrail("Added Subscriber record to DB");
        if (addSubDevBeanList() != true)
        {
            log.info("Failed to Add Sub Device");
            return false;
        }
        setLogTrail("Added Subscriber device to DB");
        log.info("Native TN. Add to Pub TN Pool, Terminating Routing and Sub Tn");
        if (addToPublicTnPool() != true)
        {
            log.info("Failed to Add to Public Tn Pool");
            return false;
        }
        setLogTrail("Added Public Tn record to DB");
        log.info("Add SubscriberTn");
        if (addSubTn() != true)
        {
            log.info("Failed to Add SubTn");
            return false;
        }
        setLogTrail("Added Subscriber Tn record to DB");
        if (addSubFeatBeanList() != true)
        {
            log.info("Failed to Add Sub Features");
            return false;
        }
        setLogTrail("Added Subscriber Features to DB");

        return true;
    }

    public boolean addToPublicTnPool() throws Exception
    {
        log.info("Entering Subscriber::addToPublicTnPool");

        if (getPubTnBeanObj().getTn().equals(""))
        {
            log.info("No Public Tn Found. Skip Add Pub Tn");
            return true;
        }

        if (getPubTnBeanObj().getTnPoolId() > 0)
        {
			PublicTnPool pubTnObj = new PublicTnPool(connection, getPubTnBeanObj());
			pubTnObj.setTnStatus(VzbVoipEnum.TnStatus.ASSIGNED);
			
			//APAC LNP sep 2011
	        try
	        {
	        	PublicTnPool pubTnObjToGetPorting = (PublicTnPool) getPubTnBeanObj();
	        	pubTnObj.setTnPorting(pubTnObjToGetPorting.getTnPorting());
	        	log.info("Subscriber::addToPublicTnPool() : tn porting object is set");
	        }
	        catch(ClassCastException cce)
	        {
	        	log.info("Exception while casting PublicTnPoolBean into PublicTnPool.");
	        	throw cce;
	        }
	        
			if ( pubTnObj.updatePublicTnPool() == false ) 
			{
            	log.info("Unable to update Public Tn Pool for Subscriber Tn as Assigned.");
				return false;
            }
            log.info("TnPool Id found. Skip Tn Pool Insert");
            return true;
        }
        /*	
        PublicTnPool pubTnObj = new PublicTnPool(connection);
        pubTnObj.setLocationId(getLocationId());
        pubTnObj.setDepartmentId(getDepartmentId());
        pubTnObj.setTn(getPubTnBeanObj().getTn());
        pubTnObj.setTnStatus(getPubTnBeanObj().getTnStatus());
        pubTnObj.setPortedStatus(getPubTnBeanObj().getPortedStatus());
        pubTnObj.setNpaSplitStatus(getPubTnBeanObj().getNpaSplitStatus());
         if (createdBy != null && !createdBy.trim().equals(""))
        	 pubTnObj.setCreatedBy(createdBy);
        else
        	pubTnObj.setCreatedBy("ESAP_INV");
        if (modifiedBy != null && !modifiedBy.trim().equals(""))
           	pubTnObj.setModifiedBy(getModifiedBy());
        else
           	pubTnObj.setModifiedBy("ESAP_INV");
        if(pubTnObj.addPublicTnPool() != true)		
        {
        	log.info("Failed to Add Tn to Public Tn Pool");
        	return false;
        }
        getPubTnBeanObj().setTnPoolId(pubTnObj.getTnPoolId());
        */
        PublicTnPool pubTnObj = new PublicTnPool(connection, getPubTnBeanObj());
        //if (!pubTnObj.addToPubTnPoolAndTermRouting())
        //added to update porting info fix
        PublicTnPool pubTnObjToGetPorting = (PublicTnPool) getPubTnBeanObj();
    	pubTnObj.setTnPorting(pubTnObjToGetPorting.getTnPorting());
        
        if (!pubTnObj.addPublicTnPool())
        {
            log.info("Failed to Add Tn to Public Tn Pool");
            return false;
        }
        getPubTnBeanObj().setTnPoolId(pubTnObj.getTnPoolId());
        log.info("Successfully inserted Public TN Pool and term routing");

        return true;
    }

    public boolean addSubDevBeanList() throws SQLException, Exception
    {
        log.info("Entering Subscriber::addSubDevBeanList");

        if (subDevBeanList == null || subDevBeanList.size() <= 0)
        {
            log.info("No Subscriber Device Found. Skip Add SubDevice");
            return true;
        }

        for (int i = 0; i < subDevBeanList.size(); i++)
        {
            SubscriberDevice subDev = new SubscriberDevice(connection, subDevBeanList.get(i));
            if (subDev.addSubscriberDevice())
            {
                log.info("Successfully Added Sub Device");
            } else
            {
                log.info("Failed while Adding Sub Device");
                setStatus(InvErrorCode.INV_FAILURE);
                //setStatusDesc("FAILURE. failed to add Sub Device" );
                return (false);
            }
        }

        return true;
    }
    private boolean dummyFunction() throws SQLException,Exception {
			DBTblSubscriber subDbBean = new DBTblSubscriber();
			subDbBean.whereSubIdEQ(subId);
			try
			{	
			if(rollbackFlag)
                        {
                                log.info("Before deleting the Subscriber");
                                subDbBean.deleteByWhere(connection);
                        }
                        else
                        { 
						subDbBean.setActiveInd(0);
						subDbBean.setFeaturePkgIdNull();
						FkValidationUtil.isValidSubscriberObjForMod(connection,subDbBean);
		               if( subDbBean.updateSpByWhere(connection) <= 0)
                                	return false;	
                        }
			deleteFeaturePackageForSubscriber();
		} catch (SQLException s) {
			s.printStackTrace();
			setStatus(InvErrorCode.DB_EXCEPTION);
			//setStatusDesc("DB_FAILURE in deleteFromDB Enterprise");
			log.info("DB_FAILURE in deleteFromDB Enterprise");
			return false;
		}
		setStatus(InvErrorCode.SUCCESS);
		//setStatusDesc("Successfully DELETED Location into the DB");
		return true;
	}
	private void deleteFeaturePackageForSubscriber() throws SQLException, Exception {
        TblSubscriberQuery subQry = new TblSubscriberQuery();
		subQry.whereSubIdEQ(subId);
        subQry.query(connection);
		if(subQry.size() > 0)
		{
		long currentPkgId = subQry.getDbBean(0).getFeaturePkgId();
                if(isPkgDeletable(currentPkgId))
                {
					DBTblLocPackage locPkgDbBean = new DBTblLocPackage();
            		locPkgDbBean.wherePackageIdEQ(currentPkgId);
            		locPkgDbBean.deleteByWhere(connection);

                    deletePkgFeatures(currentPkgId);
                    deletePackage(currentPkgId);
                }
		}
    }
	private void deletePkgFeatures(long packageId) throws SQLException, Exception {
        DBTblPkgFeatures pkgFeatDbBean = new DBTblPkgFeatures();
        pkgFeatDbBean.wherePackageIdEQ(packageId);
        pkgFeatDbBean.deleteByWhere(connection);
    }
    /**
     * The method to delete Package iff its not default.
     *
     * @param packageId     The Package Id
     * @throws SQLException If any DB Error occurs.
     */
    private void deletePackage(long packageId) throws SQLException, Exception {
                DBTblPackage packageDbBean = new DBTblPackage();
                packageDbBean.wherePackageIdEQ(packageId);
                packageDbBean.deleteByWhere(connection);
    }
    private boolean isPkgDeletable(long packageId) throws SQLException {
                TblPackageQuery pkgQry = new TblPackageQuery();
                String whereClause = " where package_id = " + packageId +
                                " and template_ind = 1";
                pkgQry.queryByWhere(connection, whereClause);
                if(pkgQry.size() >0)
            {
				log.info("Feat Pkg is template so cannot be deleted");
                    return false;
            }
			TblSubscriberQuery subQry = new TblSubscriberQuery();
			subQry.whereFeaturePkgIdEQ(packageId);
			subQry.query(connection);
			if(subQry.size() > 0)
			{
				log.info("Feat Pkg is used by other subscriber so cannot be deleted");
				log.info("SubId:"+subQry.getDbBean(0).getFeaturePkgId());
				return false;
			}
			//TODO chk in tbl_group also.

        return true;
    }


        public boolean delPublicTnPool() throws SQLException, Exception
	{
		log.info("Entering Subscriber::delPublicTnPool");
		PublicTnPool pubTnObj = new PublicTnPool(connection);
		pubTnObj.setTnPoolId(getPubTnBeanObj().getTnPoolId());
		if(rollbackFlag) 
		{
			if(pubTnObj.deletePublicTnPool() != true)
			{
				log.info("Failed to delete PublicTnPool in Subscriber ");
				return false;
			}
		}
		else
		{
			pubTnObj.setTnStatus(VzbVoipEnum.TnStatus.AVAILABLE);
			if(pubTnObj.updatePublicTnPool() != true)
			{
				log.info("Failed to delete PublicTnPool in Subscriber ");
				return false;
			}
		}
		log.info("Successfully deleted PublicTnPool in Subscriber");
		setStatus(InvErrorCode.SUCCESS);
		return true;
	}
	
	public boolean delSubDevBeanList() throws SQLException, Exception

	{
		log.info("Entering Subscriber::delSubDevBeanList");
		if(subDevBeanList.size() <= 0)
		{
			log.info("No Subscriber Device Found. Skip delete SubDevice");
			return true;
		}
		for(int i=0; i< subDevBeanList.size(); i++)
		{
			SubscriberDevice subDev = new SubscriberDevice(connection, subDevBeanList.get(i));
						
			if(subDev.deleteSubscriberDevice())
			{
				log.info("Successfully Added delete Device");
			}
			else
			{
				log.info("Failed while deleting Sub Device");
				setStatus(InvErrorCode.INTERNAL_ERROR);
				//setStatusDesc("FAILURE. failed to add Sub Device" );
				return(false);
			}
		}
		setStatus(InvErrorCode.SUCCESS);
		//setStatusDesc("Successfully DELETED Location into the DB");
		return true;
	}
    public boolean addSubFeatBeanList()
    {
        log.info("Entering Subscriber::addSubFeatBeanList");
        if (subFeatBeanList == null || subFeatBeanList.size() <= 0)
        {
            log.info("No Subscriber Feat Found. Skip Add SubFeature");
            return true;
        }
        for (int i = 0; i < subFeatBeanList.size(); i++)
        {
            SubFeatures subFeat = new SubFeatures(connection, subFeatBeanList.get(i));
            if (subFeat.addSubFeatures())
            {
                log.info("Successfully Added Sub Feature");
            } else
            {
                log.info("Failed while Adding Sub Feature");
                setStatus(InvErrorCode.INV_FAILURE);
                return (false);
            }
        }
        return true;
    }

    public boolean addSubTn() throws SQLException, Exception
    {
        log.info("Entering Subscriber::addSubTn");

        if (subTnObj.getUserId() == null || (subTnObj.getUserId().trim()).equalsIgnoreCase(""))
        {
            log.info("No Subscriber Tn Found. Skip Add SubscriberTn");
            return true;
        }

        SubscriberTn subTn = new SubscriberTn(connection, subTnObj);
        if (subTn.addSubscriberTn() != true)
        {
            log.info("Failed to Add Subscriber Tn");
            return false;
        }
        setSubscriberTnId(subTn.getSubscriberTnId());
        log.info("Successfully Added Subscriber Tn");

        return true;
    }

    public boolean delSubscriber() throws SQLException, Exception
    {
       // try
       // 
            if (subId == null || subId.trim().equalsIgnoreCase(""))
            {
                setStatus(InvErrorCode.INVALID_INPUT);
                return false;
            }
            log.info("In delSubscriber method:" + subId);

            int subTnId = 0;
            TblSubscriberTnQuery subTnQry = new TblSubscriberTnQuery();
            subTnQry.whereSubIdEQ(subId);
            subTnQry.query(connection);
            if (subTnQry.size() > 0)
            {
                for (int i = 0; i < subTnQry.size(); i++)
                {
                    subTnId = (subTnQry.getDbBean(i)).getSubscriberTnId();
                    if (subTnId > 0)
                    {
                        SubscriberTn subTn = new SubscriberTn(connection);
                        subTn.setSubscriberTnId(subTnId);
                        subTn.setRollbackFlag(rollbackFlag);
                        subTn.setIsExistingTn(isExistingTn);
						subTn.setTnRemoveFlag(tnRemoveFlag);
						if(getEnvOrderId() > 0)
                			subTn.setEnvOrderId(getEnvOrderId());
                        subTn.deleteSubscriberTn();
                        log.info("deleting subscriber tn with subtnId:" + subTnId);
                    }
                }
            }
            TblSubscriberDeviceQuery subDevQry = new TblSubscriberDeviceQuery();
            subDevQry.whereSubIdEQ(subId);
            subDevQry.query(connection);
            if (subDevQry.size() > 0)
            {
                for (int i = 0; i < subDevQry.size(); i++)
                {
                    int subDevId = (subDevQry.getDbBean(i)).getSubDeviceId();
                    if (subDevId > 0)
                    {
                        SubscriberDevice subDev = new SubscriberDevice(connection);
                        subDev.setSubDeviceId(subDevId);
                        // subDev.setRollbackFlag(rollbackFlag);
                        subDev.deleteSubscriberDevice();
                        log.info("deleting subscriber dev with subdevId:" + subDevId);
                    }
                }
            }
            TblSubFeatureQuery subFeatQry = new TblSubFeatureQuery();
            subFeatQry.whereSubIdEQ(subId);
            subFeatQry.query(connection);
            if (subFeatQry.size() > 0)
            {
                for (int i = 0; i < subFeatQry.size(); i++)
                {
                    int subFeatId = (subFeatQry.getDbBean(i)).getSubFeatureId();
                    if (subFeatId > 0)
                    {
                        SubFeatures subFeat = new SubFeatures(connection);
                        subFeat.setSubFeatureId(subFeatId);
                        subFeat.deleteSubFeatures();
                        log.info("deleting subscriber feat with subFeatId:" + subFeatId);
                    }
                }
            }
			//deleteFeaturePackageForSubscriber();
        	long currentPkgId = 0;
				long fmcgSubId = 0;
			long callPlanId = 0;

			TblSubscriberQuery subQry = new TblSubscriberQuery();
			subQry.whereSubIdEQ(subId);
			subQry.query(connection);
			if (subQry.size() > 0)
			{
				fmcgSubId = subQry.getDbBean(0).getFmcgSubId();
				currentPkgId = subQry.getDbBean(0).getFeaturePkgId();
				callPlanId = subQry.getDbBean(0).getCallingPlanId();
                log.info("Susbriber Call plan Id:"+callPlanId);
			}
            DBTblSubscriber subDbBean = new DBTblSubscriber();
            subDbBean.whereSubIdEQ(subId);
            //if (rollbackFlag)
            //{
                log.info("Before deleting the Subscriber"+subId);
                subDbBean.deleteByWhere(connection);
            /*} else
            {
                subDbBean.setActiveInd(0);
                subDbBean.setFeaturePkgIdNull();
                subDbBean.setFmcgSubIdNull();
                subDbBean.updateSpByWhere(connection);
            }*/
                log.info("After deleting the Subscriber");
		if(fmcgSubId > 0)
		{
				FmcgSubscriber fmcgSub = new FmcgSubscriber(connection);
				fmcgSub.setFmcgSubId((int)fmcgSubId);
				fmcgSub.deleteFromDB();
		}
			
			if(deleteFeatPkg && isPkgDeletable(currentPkgId))
                {
                log.info("Feature pkg is deletable:"+currentPkgId);
                    DBTblLocPackage locPkgDbBean = new DBTblLocPackage();
                    locPkgDbBean.wherePackageIdEQ(currentPkgId);
                    locPkgDbBean.deleteByWhere(connection);
                    
                    deletePkgFeatures(currentPkgId);
                    deletePackage(currentPkgId);
                }
				//If its rollback then Om is creating seperate calling plan delete order.
				if(callPlanId > 0 && deleteCallingPlan)
				{
				CallingPlan callingPlanObj = new CallingPlan(connection);
				callingPlanObj.setCallingPlanId((int)callPlanId);
				callingPlanObj.deleteCallingPlan();
				}

        /*}
        catch (SQLException s)
        {
            s.printStackTrace();
            setStatus(InvErrorCode.DB_EXCEPTION);
            //setStatusDesc("DB_FAILURE in deleteFromDB Enterprise");
            log.info("DB_FAILURE in deleteFromDB Enterprise");
            return false;
        }*/
        setStatus(InvErrorCode.SUCCESS);
        //setStatusDesc("Successfully DELETED Location into the DB");
        return true;
    }

    /* public boolean delPublicTnPool()
    {
        log.info("Entering Subscriber::delPublicTnPool");
        PublicTnPool pubTnObj = new PublicTnPool(connection);
        pubTnObj.setTnPoolId(getPubTnBeanObj().getTnPoolId());
        if (rollbackFlag)
        {
            if (pubTnObj.deletePublicTnPool() != true)
			{
                log.info("Failed to delete PublicTnPool in Subscriber ");
                return false;
            }
        } else
        {
            pubTnObj.setTnStatus(VzbVoipEnum.TnStatus.AVAILABLE);
            if (pubTnObj.updatePublicTnPool() != true)
            {
                log.info("Failed to delete PublicTnPool in Subscriber ");
                return false;
            }
        }
        log.info("Successfully deleted PublicTnPool in Subscriber");
        setStatus(InvErrorCode.SUCCESS);
        return true;
    }
*/
/*
    public boolean delSubDevBeanList()
    {
        log.info("Entering Subscriber::delSubDevBeanList");
        if (subDevBeanList.size() <= 0)
        {
            log.info("No Subscriber Device Found. Skip delete SubDevice");
            return true;
        }
        for (int i = 0; i < subDevBeanList.size(); i++)
        {
            SubscriberDevice subDev = new SubscriberDevice(connection, subDevBeanList.get(i));

            if (subDev.deleteSubscriberDevice())
            {
                log.info("Successfully Added delete Device");
            } else
            {
                log.info("Failed while deleting Sub Device");
                setStatus(InvErrorCode.INTERNAL_ERROR);
                //setStatusDesc("FAILURE. failed to add Sub Device" );
                return (false);
            }
        }
        setStatus(InvErrorCode.SUCCESS);
        //setStatusDesc("Successfully DELETED Location into the DB");
        return true;
    }
	*/

    public boolean delSubFeatBeanList()
    {
        log.info("Entering Subscriber::delSubFeatBeanList");
        if (subFeatBeanList.size() <= 0)
        {
            log.info("No Subscriber feature Found. Skip delete Subfeature");
            return true;
        }
        for (int i = 0; i < subFeatBeanList.size(); i++)
        {
            SubFeatures subFeat = new SubFeatures(connection, subFeatBeanList.get(i));
            if (subFeat.deleteSubFeatures())
            {
                log.info("Successfully deleted subFeature");
            } else
            {
                log.info("Failed while deleting subFeature");
                setStatus(InvErrorCode.INTERNAL_ERROR);
                return (false);
            }
        }
        setStatus(InvErrorCode.SUCCESS);
        return true;
    }

    public boolean delSipDeviceBeanList() throws SQLException, Exception
    {
        log.info("Entering Subscriber::delSipDeviceBeanList");

        if (sipDeviceBeanList.size() <= 0)
        {
            log.info("No Subscriber Sip Device Found. Skip delete Sip Device");
            return true;
        }
        for (int i = 0; i < sipDeviceBeanList.size(); i++)
        {
            SipDevice sipDev = new SipDevice(connection, sipDeviceBeanList.get(i));
            if (sipDev.deleteSipDevice())
            {
                log.info("Successfully delete Sip Device");
            } else
            {
                log.info("Failed while deleting Sip Device");
                setStatus(InvErrorCode.INTERNAL_ERROR);
                //setStatusDesc("FAILURE. failed to add Sub Device" );
                return (false);
            }
        }
        return true;
    }

    public boolean delSubTn()
    {
        try
        {
            //delete SunscriberTn 
            DBTblSubscriberTn subTnDbBean = new DBTblSubscriberTn();
            subTnDbBean.setSubscriberTnId(subscriberTnId);
            subTnDbBean.whereSubscriberTnIdEQ(getSubscriberTnId());
            subTnDbBean.deleteByWhere(connection);

        }
        catch (SQLException s)
        {
            s.printStackTrace();
            setStatus(InvErrorCode.DB_EXCEPTION);
            //setStatusDesc("DB_FAILURE in deleteFromDB Enterprise");
            log.info("DB_FAILURE in delSubTn Subscriber");
            return false;
        }
        setStatus(InvErrorCode.SUCCESS);
        //setStatusDesc("Successfully DELETED Location into the DB");
        return true;
    }

    public boolean modifySubscriber() throws Exception,SQLException
    {
        /*try
        {*/
            if (subId == null)
            {
                setStatus(InvErrorCode.INTERNAL_ERROR);
                //setStatusDesc("FAILURE in modifyInDB Enterprise. enterprise Id missing.");
                log.info("FAILURE in modifySubscriber Subscriber. subscriber Id missing.");
                return false;
            }
            DBTblSubscriber subscruberDbBean = getSubscriberToUpdate();
            subscruberDbBean.whereSubIdEQ(subId);
            FkValidationUtil.isValidSubscriberObjForMod(connection,subscruberDbBean);
            if (subscruberDbBean.updateSpByWhere(connection) <= 0)
            {
                    log.info("Failed to Update Subscriber");
                    setLogTrail("Update Subscriber failed in Inv");
                return false;
            }
			setLogTrail("updated Subscriber in DB");
                if(!addSubTn())
                {
                    log.info("in modifySubscriber() 0 SubTn rows updated");
                    setLogTrail("Add SubTn failed in INV");
                    return false;
                }
                if(!addToPublicTnPool())
                {
                    log.info("in modifySubscriber() 0 pubTn rows updated");
                    setLogTrail("add PublicTnPool failed in INV");
                    return false;
                }
                if(addSubDevBeanList() != true)
                {
                    log.info("Failed to Add Sub Device");
                    setLogTrail("Add Subscriber Device failed in Inv");
                    return false;
                }
        /*}
        catch (SQLException s)
        {
            s.printStackTrace();
            setStatus(InvErrorCode.DB_EXCEPTION);
            //setStatusDesc("DB_FAILURE in modifyInDB Enterprise");
            log.info("DB_FAILURE in modifyInDB Enterprise");
            return false;
        }*/
        setStatus(InvErrorCode.SUCCESS);
        //setStatusDesc("Successfully UPDATED Location into the DB");
        return true;
    }

    private DBTblSubscriber getSubscriberToUpdate()
    {
        DBTblSubscriber subsDbBean = new DBTblSubscriber();

        /* Create a new instance of DialPlanBean. The new instance would hold
         * default values for the all the DialPlan fields.
         */
        SubscriberBean defSubBean = new SubscriberBean();
        Subscriber inputSub = this;
        subsDbBean.setSubId(subId);

        if (inputSub.getBsSubId() != null && !inputSub.getBsSubId().equals(defSubBean.getBsSubId()))
        {
            subsDbBean.setBsSubId(inputSub.getBsSubId());
        }
        if (inputSub.getLocationId() != null && !inputSub.getLocationId().equals(defSubBean.getLocationId()))
        {
            subsDbBean.setLocationId(inputSub.getLocationId());
        }
        if (inputSub.getDepartmentId() != null && !inputSub.getDepartmentId().equals(defSubBean.getDepartmentId()))
        {
        	if(! "".equals(inputSub.getDepartmentId()))
        		subsDbBean.setDepartmentId(inputSub.getDepartmentId());
        	else
        		subsDbBean.setDepartmentIdNull();
        }
        if (inputSub.getPpId() != defSubBean.getPpId())
        {
            subsDbBean.setPpId(inputSub.getPpId());
        }
        if (inputSub.getFirstName() != null && !inputSub.getFirstName().equals(defSubBean.getFirstName()))
        {
        	if(! "".equals(inputSub.getFirstName()))
        		subsDbBean.setFirstName(inputSub.getFirstName());
        	else
        		subsDbBean.setFirstNameNull();
        }
        if (inputSub.getLastName() != null && !inputSub.getLastName().equals(defSubBean.getLastName()))
        {
        	if(! "".equals(inputSub.getLastName()))
        		subsDbBean.setLastName(inputSub.getLastName());
        	else
        		subsDbBean.setLastNameNull();
        }
        if (inputSub.getMiddleInitial() != null && !inputSub.getMiddleInitial().equals(defSubBean.getMiddleInitial()))
        {
        	if(! "".equals(inputSub.getMiddleInitial()))
        		subsDbBean.setMiddleInitial(inputSub.getMiddleInitial());
        	else
        		subsDbBean.setMiddleInitialNull();
        }
        if (inputSub.getCompanyName() != null && !inputSub.getCompanyName().equals(defSubBean.getCompanyName()))
        {
        	if(! "".equals(inputSub.getCompanyName()))
        		subsDbBean.setCompanyName(inputSub.getCompanyName());
        	else
        		subsDbBean.setCompanyNameNull();
        }
        if (inputSub.getEmail() != null && !inputSub.getEmail().equals(defSubBean.getEmail()))
        {
        	if(! "".equals(inputSub.getEmail()))
        		subsDbBean.setEmail(inputSub.getEmail());
        	else
        		subsDbBean.setEmailNull();
        }
        if (inputSub.getHomePhone() != null && !inputSub.getHomePhone().equals(defSubBean.getHomePhone()))
        {
        	if(! "".equals(inputSub.getHomePhone()))
        		subsDbBean.setHomePhone(inputSub.getHomePhone());
        	else
        		subsDbBean.setHomePhoneNull();
        }
        if (inputSub.getWorkPhone() != null && !inputSub.getWorkPhone().equals(defSubBean.getWorkPhone()))
        {
        	if(! "".equals(inputSub.getWorkPhone()))
        		subsDbBean.setWorkPhone(inputSub.getWorkPhone());
        	else
        		subsDbBean.setWorkPhoneNull();
        }
        if (inputSub.getMobilePhone() != null && !inputSub.getMobilePhone().equals(defSubBean.getMobilePhone()))
        {
        	if(! "".equals(inputSub.getMobilePhone()))
        		subsDbBean.setMobilePhone(inputSub.getMobilePhone());
        	else
        		subsDbBean.setMobilePhoneNull();
        }
        if (inputSub.getTimeZone() != null && !inputSub.getTimeZone().equals(defSubBean.getTimeZone()))
        {
        	if(! "".equals(inputSub.getTimeZone()))
        		subsDbBean.setTimeZone(inputSub.getTimeZone());
        	else
        		subsDbBean.setTimeZoneNull();
        }
        if (inputSub.getWebLang() != defSubBean.getWebLang())
        {
            subsDbBean.setWebLang(inputSub.getWebLang());
        }
        if (inputSub.getAccessLevel() != defSubBean.getAccessLevel())
        {
        	if(inputSub.getAccessLevel() != 0)
        		subsDbBean.setAccessLevel(inputSub.getAccessLevel());
        	else
        		subsDbBean.setAccessLevelNull();
        }
        if (inputSub.getWebLoginId() != null && !inputSub.getWebLoginId().equals(defSubBean.getWebLoginId()))
        {
        	if(! "".equals(inputSub.getWebLoginId()))
        		subsDbBean.setWebLoginId(inputSub.getWebLoginId());
        	else
        		subsDbBean.setWebLoginIdNull();
        }
        if (inputSub.getWebPassword() != null && !inputSub.getWebPassword().equals(defSubBean.getWebPassword()))
        {
        	if(! "".equals(inputSub.getWebPassword()))
        		subsDbBean.setWebPassword(inputSub.getWebPassword());
        	else
        		subsDbBean.setWebPasswordNull();
        }
        if (inputSub.getSecretQuestion() != null
                && !inputSub.getSecretQuestion().equals(defSubBean.getSecretQuestion()))
        {
        	if(! "".equals(inputSub.getSecretQuestion()))
        		subsDbBean.setSecretQuestion(inputSub.getSecretQuestion());
        	else
        		subsDbBean.setSecretQuestionNull();
        }
        if (inputSub.getSecretAnswer() != null && !inputSub.getSecretAnswer().equals(defSubBean.getSecretAnswer()))
        {
        	if(! "".equals(inputSub.getSecretAnswer()))
        		subsDbBean.setSecretAnswer(inputSub.getSecretAnswer());
        	else
        		subsDbBean.setSecretAnswerNull();
        }
        if (inputSub.getSipUsername() != null && !inputSub.getSipUsername().equals(defSubBean.getSipUsername()))
        {
        	if(! "".equals(inputSub.getSipUsername()))
        		subsDbBean.setSipUsername(inputSub.getSipUsername());
        	else
        		subsDbBean.setSipUsernameNull();
        }
        if (inputSub.getSipPassword() != null && !inputSub.getSipPassword().equals(defSubBean.getSipPassword()))
        {
        	if(! "".equals(inputSub.getSipPassword()))
        		subsDbBean.setSipPassword(inputSub.getSipPassword());
        	else
        		subsDbBean.setSipPasswordNull();
        }
        if (inputSub.getSipAddress() != null && !inputSub.getSipAddress().equals(defSubBean.getSipAddress()))
        {
        	if(! "".equals(inputSub.getSipAddress()))
        		subsDbBean.setSipAddress(inputSub.getSipAddress());
        	else
        		subsDbBean.setSipAddressNull();
        }
        if (inputSub.getMobileUser() != defSubBean.getMobileUser())
        {
           if(inputSub.getMobileUser() != -2 )
        	   subsDbBean.setMobileUser(inputSub.getMobileUser());
           else
        	   subsDbBean.setMobileUserNull(); 
        }
        if (inputSub.getPkgFeatureId() != defSubBean.getPkgFeatureId())
        {
        	  if(inputSub.getPkgFeatureId() != 0 )
        		  subsDbBean.setFeaturePkgId(inputSub.getPkgFeatureId());
        	  else
        		  subsDbBean.setFeaturePkgIdNull(); 
        }
        //	if (inputSub.getPkgFeatureStr() != null 
        //			&& !inputSub.getPkgFeatureStr().equals(defSubBean.getPkgFeatureStr())) {
        //		subsDbBean.setPkgFeatureStr(inputSub.getPkgFeatureStr());
        //	}
        if (inputSub.getCallerIdFirstName() != null
                && !inputSub.getCallerIdFirstName().equals(defSubBean.getCallerIdFirstName()))
        {
        	if(! "".equals(inputSub.getCallerIdFirstName()))
        		subsDbBean.setCidFirstName(inputSub.getCallerIdFirstName());
        	else
        		subsDbBean.setCidFirstNameNull();
        }
        if (inputSub.getCallerIdLastName() != null
                && !inputSub.getCallerIdLastName().equals(defSubBean.getCallerIdLastName()))
        {
        	if(! "".equals(inputSub.getCallerIdLastName()))
        		subsDbBean.setCidLastName(inputSub.getCallerIdLastName());
        	else
        		subsDbBean.setCidLastNameNull();
        }
        
	//Added to modify the SUbscriber Type
        log.info("INput Sub type is===" +inputSub.getSubscriberType() );
        //IR #1089902 
        if (inputSub.getSubscriberType()!=defSubBean.getSubscriberType())
        {
        	if(inputSub.getSubscriberType() != 0 )
        		subsDbBean.setSubscriberType(inputSub.getSubscriberType());
        	else
        		subsDbBean.setSubscriberType(3);
        }
        
        //End of subscriber type.
        
        if (inputSub.getVmLang() != defSubBean.getVmLang())
        {
            subsDbBean.setVmLang(inputSub.getVmLang());
        }
        if (inputSub.getVmBoxNum() != null && !inputSub.getVmBoxNum().equals(defSubBean.getVmBoxNum()))
        {
        	if(! "".equals(inputSub.getVmBoxNum()))
        		subsDbBean.setVmBoxNum(inputSub.getVmBoxNum());
        	else
        		subsDbBean.setVmBoxNumNull();
        }
		if (inputSub.getVmMaxSizeId() != defSubBean.getVmMaxSizeId()) {
            subsDbBean.setVmMaxsize(inputSub.getVmMaxSizeId());
            if(inputSub.getVmMaxSizeId() == 0)
                subsDbBean.setVmBoxNumNull();
        }
        if (inputSub.getVmPasscode() != null && !inputSub.getVmPasscode().equals(defSubBean.getVmPasscode()))
        {
        	if(! "".equals(inputSub.getVmPasscode()))
        		subsDbBean.setVmPasscode(inputSub.getVmPasscode());
        	else
        		subsDbBean.setVmPasscodeNull();
        }
        if (inputSub.getVmPin() != null && !inputSub.getVmPin().equals(defSubBean.getVmPin()))
        {
        	if(! "".equals(inputSub.getVmPin()))
        		subsDbBean.setVmPin(inputSub.getVmPin());
        	else
        		subsDbBean.setVmPinNull();
        }
        if (inputSub.getVmStatus() != defSubBean.getVmStatus())
        {
        	if(inputSub.getVmStatus() != 0 )
        		subsDbBean.setVmStatus(inputSub.getVmStatus());
        	else
        		subsDbBean.setVmStatusNull();
        }
        if (inputSub.getVmActiveDate() != defSubBean.getVmActiveDate())
        {
        	if(inputSub.getVmActiveDate() != 0 )
        		subsDbBean.setVmActiveDate(inputSub.getVmActiveDate());
        	else
        		subsDbBean.setVmActiveDateNull();
        }
        if (inputSub.getVmTermDate() != defSubBean.getVmTermDate())
        {
        	if(inputSub.getVmTermDate() != 0 )
        		subsDbBean.setVmTermDate(inputSub.getVmTermDate());
        	else
        		subsDbBean.setVmTermDateNull();
        }
        if (inputSub.getVmChangeDate() != defSubBean.getVmChangeDate())
        {
        	if(inputSub.getVmTermDate() != 0 )
        		subsDbBean.setVmChangeDate(inputSub.getVmChangeDate());
        	else
        		subsDbBean.setVmChangeDateNull();
        }
        if (inputSub.getSubAddrId() != defSubBean.getSubAddrId())
        {
        	if(inputSub.getSubAddrId() != 0 )
        		subsDbBean.setSubAddrId(inputSub.getSubAddrId());
        	else
        		subsDbBean.setSubAddrIdNull();
        }
        if (inputSub.getRpId() != null && !inputSub.getRpId().equals(defSubBean.getRpId()))
        {
        	if(! "".equals(inputSub.getRpId()))
        		subsDbBean.setRpid(inputSub.getRpId());
        	else
        		subsDbBean.setRpidNull();
        }
        if (inputSub.getRpidPriv() != defSubBean.getRpidPriv())
        {
            subsDbBean.setRpidPriv(inputSub.getRpidPriv());
        }
        if (inputSub.getRpIdPoolId() != defSubBean.getRpIdPoolId())
        {
            if(inputSub.getRpIdPoolId() != 0 )
            	subsDbBean.setRpidPoolid(inputSub.getRpIdPoolId());
            else
            	subsDbBean.setRpidPoolidNull();
        }
        if (inputSub.getExtension() != null && !inputSub.getExtension().equals(defSubBean.getExtension()))
        {
        	if(! "".equals(inputSub.getExtension()))
        		subsDbBean.setExtension(inputSub.getExtension());
        	else
        		subsDbBean.setExtensionNull();
        }
        if (inputSub.getPubIp() != defSubBean.getPubIp())
        {
            subsDbBean.setPubIp(inputSub.getPubIp());
        }
        if (inputSub.getCallingPlanId() != defSubBean.getCallingPlanId())
        {
            if (inputSub.getCallingPlanId() > 0)
                subsDbBean.setCallingPlanId(inputSub.getCallingPlanId());
            else
                subsDbBean.setCallingPlanIdNull();
        }
        if (inputSub.getRegistrationType() != defSubBean.getRegistrationType())
        {
            subsDbBean.setRegistrationType(inputSub.getRegistrationType());
	    if(inputSub.getRegistrationType() == VzbVoipEnum.RegistrationType.SELF)
	    {  
		subsDbBean.setWebLoginIdNull();
   		subsDbBean.setWebPasswordNull();
   		subsDbBean.setSecretQuestionNull();
   		subsDbBean.setSecretAnswerNull();
	    }
        }
        log.info("inputSub.getRegistrationStatus()===> " +inputSub.getRegistrationStatus());
        log.info("defSubBean.getRegistrationStatus()===> " +defSubBean.getRegistrationStatus());
        if (inputSub.getRegistrationStatus() != defSubBean.getRegistrationStatus())
        {
            subsDbBean.setRegistrationStatus(inputSub.getRegistrationStatus());
        }
        if (inputSub.getRegistrationKey() != null
                && !inputSub.getRegistrationKey().equals(defSubBean.getRegistrationKey()))
        {
        	if(! "".equals(inputSub.getRegistrationKey()))
        		subsDbBean.setRegistrationKey(inputSub.getRegistrationKey());
        	else
        		subsDbBean.setRegistrationKeyNull();
        }

        if (inputSub.getAdminSecretQuestion() != null
                && !inputSub.getAdminSecretQuestion().equals(defSubBean.getAdminSecretQuestion()))
        {
        	if(! "".equals(inputSub.getAdminSecretQuestion()))
        		subsDbBean.setAdminSecretQuestion(inputSub.getAdminSecretQuestion());
        	else
        		subsDbBean.setAdminSecretQuestionNull();
        }
        if (inputSub.getAdminSecretAnswer() != null
                && !inputSub.getAdminSecretAnswer().equals(defSubBean.getAdminSecretAnswer()))
        {
        	if(! "".equals(inputSub.getAdminSecretAnswer()))
        		subsDbBean.setAdminSecretAnswer(inputSub.getAdminSecretAnswer());
        	else
        		subsDbBean.setAdminSecretAnswerNull();
        }
		if (inputSub.getAuthUserName() != null
                && !inputSub.getAuthUserName().equals(defSubBean.getAuthUserName()))
        {
			if(! "".equals(inputSub.getAuthUserName()))
				subsDbBean.setAuthUserName(inputSub.getAuthUserName());
			else
				subsDbBean.setAuthUserNameNull();
        }
		if (inputSub.getAuthPassword() != null
                && !inputSub.getAuthPassword().equals(defSubBean.getAuthPassword()))
        {
			if(! "".equals(inputSub.getAuthPassword()))
				subsDbBean.setAuthPassword(inputSub.getAuthPassword());
			else
				subsDbBean.setAuthPasswordNull();
        }
		if (inputSub.getSipRegistrarDomain() != null
                && !inputSub.getSipRegistrarDomain().equals(defSubBean.getSipRegistrarDomain()))
        {
			if(! "".equals(inputSub.getSipRegistrarDomain()))
				subsDbBean.setSipRegistrarDomain(inputSub.getSipRegistrarDomain());
			else
				subsDbBean.setSipRegistrarDomainNull();	
        }

        if (inputSub.getSearchOption() != defSubBean.getSearchOption())
        {
        	if(inputSub.getSearchOption() != 0 )
        		subsDbBean.setSearchOption(inputSub.getSearchOption());
        	else
        		subsDbBean.setSearchOptionNull();
        }
        if (inputSub.getAllowUserSearch() != defSubBean.getAllowUserSearch())
        {
        	if(inputSub.getAllowUserSearch() != 0 )
        		subsDbBean.setAllowUserSearch(inputSub.getAllowUserSearch());
        	else
        		subsDbBean.setAllowUserSearchNull();
        }
        if (inputSub.getEnvOrderId() != defSubBean.getEnvOrderId())
        {
        	if(inputSub.getEnvOrderId() != 0)
        		subsDbBean.setEnvOrderId(inputSub.getEnvOrderId());
        	else
        		subsDbBean.setEnvOrderIdNull();
        }
		if (inputSub.getBrixInd() != defSubBean.getBrixInd())
        {
			if(inputSub.getBrixInd() != 0 )
				subsDbBean.setBrixInd(inputSub.getBrixInd());
			else
				subsDbBean.setBrixIndNull();
        }
		if (inputSub.getUserType() != defSubBean.getUserType())
        {
			if(inputSub.getUserType() != 0 )
				subsDbBean.setUserType(inputSub.getUserType());
			else
				subsDbBean.setUserTypeNull();
        }
		if (inputSub.getSipRegistrationInterval() != defSubBean.getSipRegistrationInterval())
        {
			if(inputSub.getSipRegistrationInterval() != 0)
				subsDbBean.setSipRegistrationInterval(inputSub.getSipRegistrationInterval());
			else
				subsDbBean.setSipRegistrationIntervalNull();
        }

        if (inputSub.getFmcgSubId() != defSubBean.getFmcgSubId())
        {
            if (inputSub.getFmcgSubId() > 0)
                subsDbBean.setFmcgSubId(inputSub.getFmcgSubId());
            else
                subsDbBean.setFmcgSubIdNull();
        }
        
        
		if (inputSub.getAuthSeed() != null
                && !inputSub.getAuthSeed().equals(defSubBean.getAuthSeed()))
        {
			if(! "".equals(inputSub.getAuthSeed()))
				subsDbBean.setAuthSeed(inputSub.getAuthSeed());
			else
				subsDbBean.setAuthSeedNull();
        }
        if (inputSub.getActiveInd() != defSubBean.getActiveInd())
        {
        	if(inputSub.getActiveInd() !=0 )
        		subsDbBean.setActiveInd(inputSub.getActiveInd());
        	else
        		subsDbBean.setActiveIndNull();
        }
        if (inputSub.getModifiedBy() != null && !"".equalsIgnoreCase(inputSub.getModifiedBy()))
            subsDbBean.setModifiedBy(inputSub.getModifiedBy());
        else
            subsDbBean.setModifiedBy("ESAP_INV");
        subsDbBean.setLastModifiedDate(new Timestamp(System.currentTimeMillis()));


		//Adding receptionistType
        if ( inputSub.getReceptionistType() != defSubBean.getReceptionistType()){
        	subsDbBean.setReceptionistType((short)inputSub.getReceptionistType());
        }
        
        //Jan 2011 Release changes
        if( inputSub.getDeviceLoginId() != null && !inputSub.getDeviceLoginId().equals(defSubBean.getDeviceLoginId())) {
        	subsDbBean.setDeviceLoginId(inputSub.getDeviceLoginId());
        }

        log.info("subDB.getDeviceLoginId ===> "+ subsDbBean.getDeviceLoginId() );
        
        if ( inputSub.getDevicePassword() != null && !inputSub.getDevicePassword().equals(defSubBean.getDevicePassword())){
        	subsDbBean.setDevicePassword(inputSub.getDevicePassword());
        }
        
        log.info("subDB.getDevicePassword ===> "+ subsDbBean.getDevicePassword() );
        
		// added by z658915 starts for calnet changes
		if (inputSub.getBillingType() != defSubBean.getBillingType()) {
			subsDbBean.setBillingType(inputSub.getBillingType());
		}
		// added by z658915 ends for calnet changes
        

        return subsDbBean;
    }

    private DBTblSubscriberTn getSubscriberTnToUpdate()
    {
        DBTblSubscriberTn subsTnDbBean = new DBTblSubscriberTn();

        /* Create a new instance of DialPlanBean. The new instance would hold
         * default values for the all the DialPlan fields.
         */
        SubscriberBean defSubBean = new SubscriberBean();
        Subscriber inputSub = this;
        subsTnDbBean.setSubId(subId);
        subsTnDbBean.setSubscriberTnId(subscriberTnId);

        if (inputSub.getNatUserId() != defSubBean.getNatUserId())
        {
            subsTnDbBean.setNatUserId(inputSub.getNatUserId());
        }
        if (inputSub.getNpaSplitStatus() != defSubBean.getNpaSplitStatus())
        {
            if(inputSub.getNpaSplitStatus() !=0 )
            	subsTnDbBean.setNpaSplitStatus(inputSub.getNpaSplitStatus());
            else
            	subsTnDbBean.setNpaSplitStatusNull();
        }
        if (inputSub.getUserId() != null && !inputSub.getUserId().equals(defSubBean.getUserId()))
        {
            subsTnDbBean.setUserId(inputSub.getUserId());
        }
        if (inputSub.getEnvOrderId() > 0 && inputSub.getEnvOrderId() != defSubBean.getEnvOrderId())
        {
            subsTnDbBean.setEnvOrderId(inputSub.getEnvOrderId());
        }
        if (inputSub.getModifiedBy() != null && inputSub.getModifiedBy().trim().equalsIgnoreCase(""))
            subsTnDbBean.setModifiedBy(inputSub.getModifiedBy());
        else
            subsTnDbBean.setModifiedBy("ESAP_INV");
        subsTnDbBean.setLastModifiedDate(new Timestamp(System.currentTimeMillis()));

        return subsTnDbBean;
    }

    public boolean modifyPublicTnPool() throws SQLException, Exception 
    {
        log.info("Entering Subscriber::modifyPublicTnPool");
        PublicTnPool pubTnObj = new PublicTnPool(connection);
        pubTnObj.setTnPoolId(getPubTnBeanObj().getTnPoolId());
        if (pubTnObj.updatePublicTnPool() != true)
        {
            log.info("Failed to modify PublicTnPool in Subscriber ");
            return false;
        }
        log.info("Successfully modify PublicTnPool in Subscriber");
        setStatus(InvErrorCode.SUCCESS);
        //setStatusDesc("Successfully DELETED Location into the DB");
        return true;
    }

    public boolean modifySubDevBeanList()
    {
        log.info("Entering Subscriber::modifySubDevBeanList");
        if (subDevBeanList.size() <= 0)
        {
            log.info("No Subscriber Device Found. Skip modify SubDevice");
            return true;
        }
        for (int i = 0; i < subDevBeanList.size(); i++)
        {
            SubscriberDevice subDev = new SubscriberDevice(connection, subDevBeanList.get(i));

            if (subDev.modifySubscriberDevice())
            {
                log.info("Successfully modify Sub Device");
            } else
            {
                log.info("Failed while mofing Sub Device");
                setStatus(InvErrorCode.INTERNAL_ERROR);
                //setStatusDesc("FAILURE. failed to add Sub Device" );
                return (false);
            }
        }
        setStatus(InvErrorCode.SUCCESS);
        //setStatusDesc("Successfully DELETED Location into the DB");
        return true;
    }

    public boolean modifySipDeviceBeanList() throws Exception
    {
        log.info("Entering Subscriber::modifySipDeviceBeanList");

        if (sipDeviceBeanList.size() <= 0)
        {
            log.info("No Subscriber Sip Device Found. Skip modified Sip Device");
            return true;
        }
        for (int i = 0; i < sipDeviceBeanList.size(); i++)
        {
            SipDevice sipDev = new SipDevice(connection, sipDeviceBeanList.get(i));
            if (sipDev.updateSipDevice())
            {
                log.info("Successfully modified Sip Device");
            } else
            {
                log.info("Failed while mofifing Sip Device");
                setStatus(InvErrorCode.INTERNAL_ERROR);
                //setStatusDesc("FAILURE. failed to add Sub Device" );
                return (false);
            }
        }
        return true;
    }

    public boolean modifySubTn()
    {
        try
        {
            if (subscriberTnId < 0)
            {
                setStatus(InvErrorCode.INTERNAL_ERROR);
                //setStatusDesc("FAILURE in modifyInDB Enterprise. enterprise Id missing.");
                log.info("FAILURE in modifySubTn Subscriber. subscriber Tn Id missing.");
                return false;
            }
            DBTblSubscriberTn subscruberTnDbBean = getSubscriberTnToUpdate();
            subscruberTnDbBean.whereSubscriberTnIdEQ(subscriberTnId);
            subscruberTnDbBean.updateSpByWhere(connection);

        }
        catch (SQLException s)
        {
            s.printStackTrace();
            setStatus(InvErrorCode.DB_EXCEPTION);
            //setStatusDesc("DB_FAILURE in deleteFromDB Enterprise");
            log.info("DB_FAILURE in modifySubTn Subscriber");
            return false;
        }
        setStatus(InvErrorCode.SUCCESS);
        //setStatusDesc("Successfully DELETED Location into the DB");
        return true;
    }

    public boolean getSubscriberDetailsBySubId()
    {
        log.info("Entering Subscriber::getSubscriberDetailsBySubId");

        try
        {
            TblSubscriberQuery subQry = new TblSubscriberQuery();
            initilizeTODefault();
            String whereClause = new String("");
            if (getAll == false)
                whereClause = " where sub_id = \'" + getSubId() + "\' and active_ind = 1";
            else
                whereClause = " where sub_id = \'" + getSubId() + "\' and active_ind != 0";

            subQry.queryByWhere(connection, whereClause);
            if (subQry.size() <= 0)
            {
                log.info("Subscriber Id [" + getSubId() + "] not Found");
                return false;
            }
            TblSubscriberDbBean subBean = subQry.getDbBean(0);
            setBsSubId(subBean.getBsSubId());
            setLocationId(subBean.getLocationId());
            setDepartmentId(subBean.getDepartmentId());
            if(subBean.getCallingPlanId() >0)
            	setCallingPlanId(subBean.getCallingPlanId());
            setPpId(subBean.getPpId());
            //setRegRingTime(subBean.getRegRingTime());
            setLastName(subBean.getLastName());
            setFirstName(subBean.getFirstName());
            setMiddleInitial(subBean.getMiddleInitial());
            setCompanyName(subBean.getCompanyName());
            setEmail(subBean.getEmail());
            setHomePhone(subBean.getHomePhone());
            setWorkPhone(subBean.getWorkPhone());
            setMobilePhone(subBean.getMobilePhone());
            setTimeZone(subBean.getTimeZone());
            setWebLang(subBean.getWebLang());
            setAccessLevel(subBean.getAccessLevel());
            setWebLoginId(subBean.getWebLoginId());
            setWebPassword(subBean.getWebPassword());
            setSipUsername(subBean.getSipUsername());
            setSipPassword(subBean.getSipPassword());
            setSipAddress(subBean.getSipAddress());
            setMobileUser(subBean.getMobileUser());
            setPkgFeatureId(subBean.getFeaturePkgId());
            setCallerIdFirstName(subBean.getCidFirstName());
            setCallerIdLastName(subBean.getCidLastName());
            setVmLang(subBean.getVmLang());
            setVmMaxSizeId(subBean.getVmMaxsize());
            TblVmBoxSizeQuery vmBoxQry = new TblVmBoxSizeQuery();
            vmBoxQry.whereVmBoxSizeIdEQ((int) getVmMaxSizeId());
            vmBoxQry.query(connection);
            if (vmBoxQry.size() > 0)
                setVmMaxSize(vmBoxQry.getDbBean(0).getMessages());
            setVmBoxNum(subBean.getVmBoxNum());
            setVmRouteNum(subBean.getVmRouteNum());
            setVmPasscode(subBean.getVmPasscode());
            setVmPin(subBean.getVmPin());
            setVmStatus(subBean.getVmStatus());
            setVmActiveDate(subBean.getVmActiveDate());
            setVmTermDate(subBean.getVmTermDate());
            setVmChangeDate(subBean.getVmChangeDate());
            //setSipActiveDate(subBean.getSipActiveDate());
            //setSipTermDate(subBean.getSipTermDate());
            //setDeviceType(subBean.getDeviceType());
            setSubAddrId(subBean.getSubAddrId());
            //setMwiDeviceId(subBean.getMwiDeviceId());
            setRpId(subBean.getRpid());
            setRpidPriv(subBean.getRpidPriv());
            setRpIdPoolId(subBean.getRpidPoolid());
            //setLinePort(subBean.getLinePort());
            setExtension(subBean.getExtension());
            setPubIp(subBean.getPubIp());
            setRegistrationType(subBean.getRegistrationType());
            setRegistrationStatus(subBean.getRegistrationStatus());
            setRegistrationKey(subBean.getRegistrationKey());
            setAdminSecretQuestion(subBean.getAdminSecretQuestion());
            setAdminSecretAnswer(subBean.getAdminSecretAnswer());
            setSecretQuestion(subBean.getSecretQuestion());
            setSecretAnswer(subBean.getSecretAnswer());
            setSearchOption(subBean.getSearchOption());
            setAllowUserSearch(subBean.getAllowUserSearch());
            setCreatedBy(subBean.getCreatedBy());
            setModifiedBy(subBean.getModifiedBy());
            setCreationDate(subBean.getCreationDate());
            setLastModifiedDate(subBean.getLastModifiedDate());
            setEnvOrderId(subBean.getEnvOrderId());
            setFmcgSubId(subBean.getFmcgSubId());
            setSubscriberType(subBean.getSubscriberType());
            setBrixInd(subBean.getBrixInd());
			setUserType(subBean.getUserType());
            setAuthUserName(subBean.getAuthUserName());
            setAuthPassword(subBean.getAuthPassword());
            setSipRegistrarDomain(subBean.getSipRegistrarDomain());
            setSipRegistrationInterval(subBean.getSipRegistrationInterval());
            setAuthSeed(subBean.getAuthSeed());
			setReceptionistType(subBean.getReceptionistType());
			//Jan 2011 Release changes
			setDeviceLoginId(subBean.getDeviceLoginId());
			setDevicePassword(subBean.getDevicePassword());
			//53266.AM APAC VOIP LNP - changes for july 2011
			setEmerNoA(subBean.getEmernoa());
			setEmergencyOverride(subBean.getEmergoverride());
			
			this.setBillingType(subBean.getBillingType());				//added by z658915

            /*TblSubscriberTnQuery subTnQry = new TblSubscriberTnQuery();
            String whereClauseTn = " where sub_id = \'" + getSubId() + "\'";
            subTnQry.queryByWhere(connection, whereClauseTn);
            if (subTnQry.size() > 0)
            {
            	List<SubscriberTnBean> subTnList  = new ArrayList<SubscriberTnBean>();
            	for (int size = 0; size < subTnQry.size(); size++) {
            		  TblSubscriberTnDbBean subTnBean = subTnQry.getDbBean(size);
            		  subTnList.add(new SubscriberTnBean(subTnBean));
            	}
            	setSubTnBeanList(subTnList);
            } else
                log.info("Subscriber Tn not Found With Subscriber Id [" + getSubId() + "]");*/
			
			//IR #1353501  - For CSSOP TN_ON_OFF Needs to check
			String[] subIds = new String[1];
			subIds[0] = subId;
			getSubscriberTNWithONOFF(new String[]{subId});
			Map<String, String> userIdDomainMap = getCANMDetails(getSubId());
				log.info("Getting the CNAM Values for SubScriber from Map CnamUpdateStatus ************** = " +userIdDomainMap.get("CnamUpdateStatus"));
				log.info("Getting the CNAM Values for SubScriber from Map CnamUpdateDate ************** = " +userIdDomainMap.get("CnamUpdateDate"));
				if(userIdDomainMap.get("CnamUpdateStatus") != null && !"null".equalsIgnoreCase(userIdDomainMap.get("CnamUpdateStatus"))){
					setCnamUpdateStatus(Long.valueOf(userIdDomainMap.get("CnamUpdateStatus")));
				}
				if(userIdDomainMap.get("CnamUpdateDate") != null && !"null".equalsIgnoreCase(userIdDomainMap.get("CnamUpdateDate"))){
					setCnamUpdateDate(Timestamp.valueOf(userIdDomainMap.get("CnamUpdateDate")));
				}
			getSubDeviceBeanListBySubId();
            getSubFeatBeanListBySubId();

        }
        catch (SQLException e)
        {
            setStatus(InvErrorCode.DB_EXCEPTION);
            e.printStackTrace();
            //setStatusDesc("DB_FAILURE in getSubscriberDetailsBySubId");
            return false;
        }
        setStatus(InvErrorCode.SUCCESS);
        //setStatusDesc("Successfully retrieved Subscriber from DB");
        return true;
    }
 
   public ArrayList<Object> getSubscriberDetailsBySubIds(String[] psubIds) {
      log.info("Entering Subscriber::getSubscriberDetailsBySubIds");

      ArrayList<Object> _collection = new ArrayList<>();

      PreparedStatement ps = null;
      ResultSet rs = null;
      try {
         // get messages
         long vmMaxSizeLocal = 0;

         String sql = "select messages from tbl_vm_box_size where vm_box_size_id = ?";
         ps = connection.prepareStatement(sql);
         ps.setLong(1, this.getVmMaxSizeId());
         rs = ps.executeQuery();
         if(rs.next()) {
            vmMaxSizeLocal = rs.getLong(1);
         }

         rs.close();
         ps.close();

         // get question marks for sub ids
         final String questionMarks = generateQsForIn(psubIds.length);
                 
         // get features
         sql =     " select sf.*,f.*,sf.modified_by sfmb, sf.created_by sfcb "
                 + "    from tbl_sub_feature sf, tbl_vzb_features f "
                 + " where "
                 + "     sf.sub_id in (" + questionMarks + ") "
                 + " and sf.feature_id = f.feature_id(+) "
                 + " order by sf.sub_id, sf.sub_feature_id "
                 ;

         ps = connection.prepareStatement(sql);
         for (int i = 0; i < psubIds.length; i++) {
            String string = psubIds[i];
            ps.setString(i+1, psubIds[i]);
         } 
         rs = ps.executeQuery();

         Map<String,Map<Integer,SubFeaturesBean>> subFeatMap = new HashMap<>();
         while(rs.next()) {
            String currSubId = rs.getString("SUB_ID");
            Map<Integer,SubFeaturesBean> featMap = null;
            if (!subFeatMap.containsKey(currSubId)) {
               featMap = new HashMap<>();
            } else {
               featMap = subFeatMap.get(currSubId);
            }
            SubFeaturesBean sf = createFeatureFromResultSet(rs);
            featMap.put(sf.getSubFeatureId(), sf);
            subFeatMap.put(currSubId, featMap);
         }

         rs.close();
         ps.close();

         // get subscribers and devices and features
         sql =     " select s.*,sd.*,sd.modified_by sdmb "
                 + "    from tbl_subscriber s, tbl_subscriber_device sd "
                 + " where "
                 + "     s.sub_id in (" + questionMarks + ") "
                 + " and s.sub_id = sd.sub_id(+) "
                 + " order by s.sub_id, sd.sub_device_id "
                 ;

         ps = connection.prepareStatement(sql);
         for (int i = 0; i < psubIds.length; i++) {
            String string = psubIds[i];
            ps.setString(i+1, psubIds[i]);
         } 
         rs = ps.executeQuery();

         ArrayList<Subscriber> subList = new ArrayList<>();
         String lastId = "";
         Subscriber sb = null;
         Map<Integer,SubscriberDeviceBean> devMap = new HashMap<>();
         while(rs.next()) {
            String currId = rs.getString("SUB_ID");
            if (!lastId.equals(currId)) {
               lastId = currId;
               // add sub to return list
               if (sb != null) {
                  sb.setSubDevBeanList(new ArrayList<>(devMap.values()));
                  Map<Integer,SubFeaturesBean> featMap = subFeatMap.containsKey(sb.getSubId()) ? subFeatMap.get(sb.getSubId()) : new HashMap<Integer,SubFeaturesBean>();
                  sb.setSubFeatBeanList(new ArrayList<>(featMap.values()));
                  devMap.clear();
                  subList.add(sb);
               }
               // create sub
               sb = createSubscriberFromResultSet(rs);
               sb.setVmMaxSize(vmMaxSizeLocal);
            } 
            // get device
            SubscriberDeviceBean sd = createDeviceFromResultSet(rs);
            devMap.put(sd.getSubDeviceId(), sd);
         }
         // add last element
         if (sb != null) {
            sb.setSubDevBeanList(new ArrayList<>(devMap.values()));
            Map<Integer,SubFeaturesBean> featMap = subFeatMap.containsKey(sb.getSubId()) ? subFeatMap.get(sb.getSubId()) : new HashMap<Integer,SubFeaturesBean>();
            sb.setSubFeatBeanList(new ArrayList<>(featMap.values()));
            subList.add(sb);
         }
         
         //0th pos - SubDetValobj
         //1st pos - _multipleSubs -- REMOVED because not used
         _collection.add(subList);
//         _collection.add(_multipleSubs);

      } catch (SQLException e) {
         setStatus(InvErrorCode.DB_EXCEPTION);
         e.printStackTrace();
         return null;
      } finally {
         try {
            if (rs != null) {
               rs.close();
            }
            if (null != ps) {
               ps.close();
            }
         } catch (SQLException ex) {
            log.info(ex.getMessage());
         }
      }

      setStatus(InvErrorCode.SUCCESS);
      return _collection;
   }

   private Subscriber createSubscriberFromResultSet(ResultSet rs) throws SQLException {
      Subscriber sb = new Subscriber();
      
      sb.setSubId(rs.getString("SUB_ID"));
      sb.setBsSubId(rs.getString("BS_SUB_ID"));
      sb.setLocationId(rs.getString("LOCATION_ID"));
      sb.setDepartmentId(rs.getString("DEPARTMENT_ID"));
      sb.setCallingPlanId(rs.getLong("CALLING_PLAN_ID"));
      sb.setPpId(rs.getLong("PP_ID"));
      sb.setLastName(rs.getString("LAST_NAME"));
      sb.setFirstName(rs.getString("FIRST_NAME"));
      sb.setMiddleInitial(rs.getString("MIDDLE_INITIAL"));
      sb.setCompanyName(rs.getString("COMPANY_NAME"));
      sb.setEmail(rs.getString("EMAIL"));
      sb.setHomePhone(rs.getString("HOME_PHONE"));
      sb.setWorkPhone(rs.getString("WORK_PHONE"));
      sb.setMobilePhone(rs.getString("MOBILE_PHONE"));
      sb.setTimeZone(rs.getString("TIME_ZONE"));
      sb.setWebLang(rs.getLong("WEB_LANG"));
      sb.setAccessLevel(rs.getLong("ACCESS_LEVEL"));
      sb.setWebLoginId(rs.getString("WEB_LOGIN_ID"));
      sb.setWebPassword(rs.getString("WEB_PASSWORD"));
      sb.setSipUsername(rs.getString("SIP_USERNAME"));
      sb.setSipPassword(rs.getString("SIP_PASSWORD"));
      sb.setSipAddress(rs.getString("SIP_ADDRESS"));
      sb.setMobileUser(rs.getLong("MOBILE_USER"));
      sb.setPkgFeatureId(rs.getLong("FEATURE_PKG_ID"));
      sb.setCallerIdFirstName(rs.getString("CID_FIRST_NAME"));
      sb.setCallerIdLastName(rs.getString("CID_LAST_NAME"));
      sb.setVmLang(rs.getLong("VM_LANG"));
      sb.setVmMaxSizeId(rs.getLong("VM_MAXSIZE"));
//      sb.setVmMaxSize(vmMaxSize);
      sb.setVmBoxNum(rs.getString("VM_BOX_NUM"));
      sb.setVmRouteNum(rs.getString("VM_ROUTE_NUM"));
      sb.setVmPasscode(rs.getString("VM_PASSCODE"));
      sb.setVmPin(rs.getString("VM_PIN"));
      sb.setVmStatus(rs.getLong("VM_STATUS"));
      sb.setVmActiveDate(rs.getLong("VM_ACTIVE_DATE"));
      sb.setVmTermDate(rs.getLong("VM_TERM_DATE"));
      sb.setVmChangeDate(rs.getLong("VM_CHANGE_DATE"));
      sb.setSubAddrId(rs.getLong("SUB_ADDR_ID"));
      sb.setRpId(rs.getString("RPID"));
      sb.setRpidPriv(rs.getLong("RPID_PRIV"));
      sb.setRpIdPoolId(rs.getLong("RPID_POOLID"));
      sb.setExtension(rs.getString("EXTENSION"));
      sb.setPubIp(rs.getLong("PUB_IP"));
      sb.setRegistrationType(rs.getLong("REGISTRATION_TYPE"));
      sb.setRegistrationStatus(rs.getLong("REGISTRATION_STATUS"));
      sb.setRegistrationKey(rs.getString("REGISTRATION_KEY"));
      sb.setAdminSecretQuestion(rs.getString("ADMIN_SECRET_QUESTION"));
      sb.setAdminSecretAnswer(rs.getString("ADMIN_SECRET_ANSWER"));
      sb.setSecretQuestion(rs.getString("SECRET_QUESTION"));
      sb.setSecretAnswer(rs.getString("SECRET_ANSWER"));
      sb.setSearchOption(rs.getLong("SEARCH_OPTION"));
      sb.setAllowUserSearch(rs.getLong("ALLOW_USER_SEARCH"));
      sb.setCreatedBy(rs.getString("CREATED_BY"));
      sb.setModifiedBy(rs.getString("MODIFIED_BY"));
      sb.setCreationDate(rs.getTimestamp("CREATION_DATE"));
      sb.setLastModifiedDate(rs.getTimestamp("LAST_MODIFIED_DATE"));
      sb.setEnvOrderId(rs.getLong("ENV_ORDER_ID"));
      sb.setFmcgSubId(rs.getLong("FMCG_SUB_ID"));
      sb.setSubscriberType(rs.getLong("SUBSCRIBER_TYPE"));
      sb.setBrixInd(rs.getLong("BRIX_IND"));
      sb.setUserType(rs.getLong("USER_TYPE"));
      sb.setAuthUserName(rs.getString("AUTH_USER_NAME"));
      sb.setAuthPassword(rs.getString("AUTH_PASSWORD"));
      sb.setSipRegistrarDomain(rs.getString("SIP_REGISTRAR_DOMAIN"));
      sb.setSipRegistrationInterval(rs.getLong("SIP_REGISTRATION_INTERVAL"));
      sb.setAuthSeed(rs.getString("AUTH_SEED"));
      sb.setReceptionistType(rs.getLong("RECEPTIONIST_TYPE"));
      sb.setDeviceLoginId(rs.getString("DEVICE_LOGIN_ID"));
      sb.setDevicePassword(rs.getString("DEVICE_PASSWORD"));
      sb.setEmerNoA(rs.getShort("EMERNOA"));
      sb.setEmergencyOverride(rs.getString("EMERGOVERRIDE"));
      
      return sb;
   }
   
   private SubscriberDeviceBean createDeviceFromResultSet(ResultSet rs) throws SQLException {
      SubscriberDeviceBean sd = new SubscriberDeviceBean();
      
      sd.setSubDeviceId(rs.getInt("SUB_DEVICE_ID"));
      sd.setSubId(rs.getString("SUB_ID"));
      sd.setDeviceMapId(rs.getLong("DEVICE_MAP_ID"));
      sd.setLinePort(rs.getString("LINE_PORT"));
      sd.setLineKey(rs.getLong("LINE_KEY"));
      sd.setCallsPerLine(rs.getLong("CALLS_PER_LINE"));
      sd.setPortNum(rs.getLong("PORT_NUM"));
      sd.setScaLineLabel(rs.getString("SCA_LINE_LABEL"));
      sd.setScaType(rs.getString("SCA_TYPE"));
      sd.setScaAuthUserid(rs.getString("SCA_AUTH_USERID"));
      sd.setBlfAttdntRegline(rs.getLong("BLF_ATTDNT_REGLINE"));
      sd.setBlfUrl(rs.getString("BLF_URL"));
      sd.setModifiedBy(rs.getString("SDMB"));

      if (null != sd.getScaLineLabel() && (sd.getScaLineLabel().equalsIgnoreCase("Xten Soft Device") || sd.getScaLineLabel().equalsIgnoreCase("Fmcg Device"))) {
         sd.setsoftPhone("Yes");
      } else {
         sd.setsoftPhone("No");
      }
      if (null != sd.getScaLineLabel()) {
         sd.setShared("Yes");
      } else {
         sd.setShared("No");
      }

      return sd;
   }

   private SubFeaturesBean createFeatureFromResultSet(ResultSet rs) throws SQLException {
      SubFeaturesBean sf = new SubFeaturesBean();
      sf.setSubFeatureId(rs.getInt("SUB_FEATURE_ID"));
      sf.setFeatureId(rs.getLong("FEATURE_ID"));
      sf.setFeatureName(rs.getString("NAME"));
      sf.setFeatureDesc(rs.getString("DESCRIPTION"));
      sf.setIsBillable(rs.getLong("IS_BILLABLE"));
      sf.setSubId(rs.getString("SUB_ID"));
      sf.setSelected(rs.getString("IS_SELECTED"));
      sf.setCreatedBy(rs.getString("SFCB"));
      sf.setModifiedBy(rs.getString("SFMB"));
      return sf;
   }
      
   
    //is this required?
    public long getSubAddressBySubscriber()
    {
        //select sub_addr_id from sub_address where sub_id = ?
        return 0;
    }

    public boolean getSubscriberTnsBySubscriber()
    {
        //select * from subscirber_tn
        return true;
    }

    public void printSubDbObj(DBTblSubscriber subDbObj)
    {
        StringBuffer buffer = new StringBuffer();
        buffer.append("SubId=").append(subDbObj.getSubId()).append("\n");
        buffer.append("BsSubId=").append(subDbObj.getBsSubId()).append("\n");
        buffer.append("LocationId=").append(subDbObj.getLocationId()).append("\n");
        buffer.append("DepartmentId=").append(subDbObj.getDepartmentId()).append("\n");
        buffer.append("Ppid=").append(subDbObj.getPpId()).append("\n");
        //buffer.append("RegRingTime=").append(subDbObj.getRegRingTime()).append("\n");
        buffer.append("LastName=").append(subDbObj.getLastName()).append("\n");
        buffer.append("FirstName=").append(subDbObj.getFirstName()).append("\n");
        buffer.append("MiddleInitial=").append(subDbObj.getMiddleInitial()).append("\n");
        buffer.append("CompanyName=").append(subDbObj.getCompanyName()).append("\n");
        buffer.append("Email=").append(subDbObj.getEmail()).append("\n");
        buffer.append("HomePhone=").append(subDbObj.getHomePhone()).append("\n");
        buffer.append("WorkPhone=").append(subDbObj.getWorkPhone()).append("\n");
        buffer.append("MobilePhone=").append(subDbObj.getMobilePhone()).append("\n");
        buffer.append("TimeZone=").append(subDbObj.getTimeZone()).append("\n");
        buffer.append("WebLang=").append(subDbObj.getWebLang()).append("\n");
        buffer.append("AccessLevel=").append(subDbObj.getAccessLevel()).append("\n");
        buffer.append("PkgFeatureId=").append(subDbObj.getFeaturePkgId()).append("\n");
        //buffer.append("CallerIdFirstNm=").append(subDbObj.getCallerIdFirstNm()).append("\n");
        //buffer.append("CallerIdLastNm=").append(subDbObj.getCallerIdLastNm()).append("\n");
        buffer.append("VmLang=").append(subDbObj.getVmLang()).append("\n");
        buffer.append("VmMaxsize=").append(subDbObj.getVmMaxsize()).append("\n");
        buffer.append("VmBoxNum=").append(subDbObj.getVmBoxNum()).append("\n");
        buffer.append("VmRouteNum=").append(subDbObj.getVmRouteNum()).append("\n");
        buffer.append("VmPasscode=").append(subDbObj.getVmPasscode()).append("\n");
        buffer.append("VmPin=").append(subDbObj.getVmPin()).append("\n");
        buffer.append("VmStatus=").append(subDbObj.getVmStatus()).append("\n");
        buffer.append("VmActiveDate=").append(subDbObj.getVmActiveDate()).append("\n");
        buffer.append("VmTermDate=").append(subDbObj.getVmTermDate()).append("\n");
        buffer.append("VmChangeDate=").append(subDbObj.getVmChangeDate()).append("\n");
        //buffer.append("SipActiveDate=").append(subDbObj.getSipActiveDate()).append("\n");
        //buffer.append("SipTermDate=").append(subDbObj.getSipTermDate()).append("\n");
        //buffer.append("DeviceType=").append(subDbObj.getDeviceType()).append("\n");
        buffer.append("SubAddrId=").append(subDbObj.getSubAddrId()).append("\n");
        //buffer.append("MwiDeviceId=").append(subDbObj.getMwiDeviceId()).append("\n");
        buffer.append("Rpid=").append(subDbObj.getRpid()).append("\n");
        buffer.append("Rpidpriv=").append(subDbObj.getRpidPriv()).append("\n");
        buffer.append("RpidPoolid=").append(subDbObj.getRpidPoolid()).append("\n");
        //buffer.append("LinePort=").append(subDbObj.getLinePort()).append("\n");
        buffer.append("Extension=").append(subDbObj.getExtension()).append("\n");
        buffer.append("Pubip=").append(subDbObj.getPubIp()).append("\n");
        buffer.append("CallingPlanId=").append(subDbObj.getCallingPlanId()).append("\n");
        buffer.append("ActiveInd=").append(subDbObj.getActiveInd()).append("\n");
        buffer.append("CreatedBy=").append(subDbObj.getCreatedBy()).append("\n");
        buffer.append("ModifiedBy=").append(subDbObj.getModifiedBy()).append("\n");
        buffer.append("LastModifiedDate=").append(subDbObj.getLastModifiedDate()).append("\n");
        buffer.append("EnvOrderId=").append(subDbObj.getEnvOrderId()).append("\n");
        buffer.append("FmcgSubId=").append(subDbObj.getFmcgSubId()).append("\n");
        buffer.append("subscriberType=").append(subDbObj.getSubscriberType()).append("\n");
        log.info(buffer.toString());
    }

    public boolean getSubDeviceBeanListBySubId()
    {
        log.info("Entering Subscriber::getSubDeviceBeanListBySubId");

        try
        {
            TblSubscriberDeviceQuery subDevQry = new TblSubscriberDeviceQuery();
            subDevQry.whereSubIdEQ(getSubId());
            subDevQry.query(connection);
            if (subDevQry.size() <= 0)
            {
                log.info("getSubDeviceBeanListBySubId: subDeviceBean not found for given subID=" + getSubId());
                setStatus(InvErrorCode.INVALID_INPUT);
                return false;
            }
            ArrayList<SubscriberDeviceBean> subDeviceBeanList = new ArrayList<SubscriberDeviceBean>();
            for (int i = 0; i < subDevQry.size(); i++)
            {
                TblSubscriberDeviceDbBean sdBeanDB = subDevQry.getDbBean(i);
                SubscriberDeviceBean sdBean = new SubscriberDeviceBean();
                sdBean.beanCopy(sdBeanDB);
                 if(null != sdBean.getScaLineLabel() && (sdBean.getScaLineLabel().equalsIgnoreCase("Xten Soft Device") || sdBean.getScaLineLabel().equalsIgnoreCase("Fmcg Device"))){              
                	sdBean.setsoftPhone("Yes");
                	}
                else{
                	sdBean.setsoftPhone("No");
                }                
                if(null != sdBean.getScaLineLabel()){
                	sdBean.setShared("Yes");
                }
                else{
                	sdBean.setShared("No");
                } 
                subDeviceBeanList.add(sdBean);
            }
            setSubDevBeanList(subDeviceBeanList);
        }
        catch (SQLException e)
        {
            e.printStackTrace();
            setStatus(InvErrorCode.INV_FAILURE);
            return false;
        }
        setStatus(InvErrorCode.SUCCESS);
        return true;
    }

    public boolean getSubDeviceBeanListBySubIds(String[] psubIds,ArrayList<Subscriber> _subscribers)
    {
        log.info("Entering Subscriber::getSubDeviceBeanListBySubId");

        try
        {
            TblSubscriberDeviceQuery subDevQry = new TblSubscriberDeviceQuery();
            subDevQry.whereSubIdIn(psubIds);
            subDevQry.query(connection);
            
            if (subDevQry.size() <= 0)
            {
                log.info("getSubDeviceBeanListBySubId: subDeviceBean not found for given subID=" + getSubId());
                setStatus(InvErrorCode.INVALID_INPUT);
                return false;
            }
            List<SubscriberDeviceBean> subDeviceBeanList = null;
            Subscriber _currntSubscrbr = null;
            for (int i = 0; i < subDevQry.size(); i++)
            {
            		TblSubscriberDeviceDbBean sdBeanDB = subDevQry.getDbBean(i);
            		SubscriberDeviceBean sdBean = new SubscriberDeviceBean();
                	      sdBean.beanCopy(sdBeanDB);
            	       if(null != sdBean.getScaLineLabel() && (sdBean.getScaLineLabel().equalsIgnoreCase("Xten Soft Device") || sdBean.getScaLineLabel().equalsIgnoreCase("Fmcg Device"))){              
                	sdBean.setsoftPhone("Yes");
                	}
                else{
                	sdBean.setsoftPhone("No");
                }                
                if(null != sdBean.getScaLineLabel()){
                	sdBean.setShared("Yes");
                }
                else{
                	sdBean.setShared("No");
                }	
                    for(int j=0;j<_subscribers.size();j++)
            		{
            			log.info(" Sub Id From SdBEAN:: "+sdBean.getSubId());
            			log.info(" Sub Id From Subscriber:: "+_subscribers.get(j).getSubId());
            			log.info(" Sub Ids Are Equal::"+_subscribers.get(j).getSubId().equalsIgnoreCase(sdBean.getSubId()));
            			log.info(" Current Devices::"+subDeviceBeanList);
            			
            			if(null!=_subscribers.get(j).getSubId() 
            					&& _subscribers.get(j).getSubId().equalsIgnoreCase(sdBean.getSubId()))
            			{
            				_currntSubscrbr = _subscribers.get(j);
            				if(null==_currntSubscrbr.getSubDevBeanList() || 0==_currntSubscrbr.getSubDevBeanList().size())
            				{
            					log.info("IF Sub Id::"+ _subscribers.get(j).getSubId());
            					subDeviceBeanList = new ArrayList<SubscriberDeviceBean>();
            					subDeviceBeanList.add(sdBean);
            					_currntSubscrbr.setSubDevBeanList(subDeviceBeanList);	
            				}
            				else
            				{
            					log.info("ELSE Sub Id::"+ _subscribers.get(j).getSubId());
            					subDeviceBeanList = _currntSubscrbr.getSubDevBeanList();
            					log.info("Before Adding:::"+subDeviceBeanList);
            					subDeviceBeanList.add(sdBean);
            					_currntSubscrbr.setSubDevBeanList(subDeviceBeanList);
            					log.info("After Adding:::"+subDeviceBeanList);
            				}
            			}
            			if(null!=_currntSubscrbr)
            			{
            				log.info("Subscriber Id::::"+_currntSubscrbr.getSubId()+" Devices List::: "+_currntSubscrbr.getSubDevBeanList());
            			}
            			
            		}
             }
            
            //setSubDevBeanList(subDeviceBeanList);
        }
        catch (SQLException e)
        {
            e.printStackTrace();
            setStatus(InvErrorCode.INV_FAILURE);
            return false;
        }
        setStatus(InvErrorCode.SUCCESS);
        return true;
    }

    
    
    public boolean getSubFeatBeanListBySubId()
    {
        log.info("Entering Subscriber::getSubFeatBeanListBySubId");
        try
        {
            TblSubFeatureQuery subFeatQry = new TblSubFeatureQuery();
            subFeatQry.whereSubIdEQ(getSubId());
            subFeatQry.query(connection);
            if (subFeatQry.size() <= 0)
            {
                log.info("getSubFeatBeanListBySubId: subFeatBean not found for given subID=" + getSubId());
                setStatus(InvErrorCode.INVALID_INPUT);
                return false;
            }
            for (int i = 0; i < subFeatQry.size(); i++)
            {
                SubFeaturesBean sfBean = new SubFeaturesBean();
                TblSubFeatureDbBean subFeatBean = subFeatQry.getDbBean(i);
                sfBean.setSubFeatureId(subFeatBean.getSubFeatureId());
                sfBean.setFeatureId(subFeatBean.getFeatureId());
                if (sfBean.getFeatureId() > 0)
                {
                    TblVzbFeaturesQuery featQry = new TblVzbFeaturesQuery();
                    featQry.whereFeatureIdEQ((int) sfBean.getFeatureId());
                    featQry.query(connection);
                    if (featQry.size() > 0)
                    {
                        sfBean.setFeatureName(featQry.getDbBean(0).getName());
                        sfBean.setFeatureDesc(featQry.getDbBean(0).getDescription());
                        sfBean.setIsBillable(featQry.getDbBean(0).getIsBillable());
                    }
                }
                sfBean.setSubId(subFeatBean.getSubId());
                sfBean.setSelected(subFeatBean.getIsSelected());
                sfBean.setCreatedBy(subFeatBean.getCreatedBy());
                sfBean.setModifiedBy(subFeatBean.getModifiedBy());
                subFeatBeanList.add(sfBean);
            }
        }
        catch (SQLException e)
        {
            e.printStackTrace();
            setStatus(InvErrorCode.INV_FAILURE);
            return false;
        }
        setStatus(InvErrorCode.SUCCESS);
        return true;
    }
    public boolean getSubFeatBeanListBySubIds(String[] psubIds,ArrayList<Subscriber> _subscribers )
    {
        log.info("Entering Subscriber::getSubFeatBeanListBySubId");
        try
        {
            TblSubFeatureQuery subFeatQry = new TblSubFeatureQuery();
            subFeatQry.whereSubIdIn(psubIds);
            subFeatQry.query(connection);
            if (subFeatQry.size() <= 0)
            {
                log.info("getSubFeatBeanListBySubId: subFeatBean not found for given subID=" + getSubId());
                setStatus(InvErrorCode.INVALID_INPUT);
                return false;
            }
            List<SubFeaturesBean> _subFeatBeanList = null; 
            for (int i = 0; i < subFeatQry.size(); i++)
            {
                SubFeaturesBean sfBean = new SubFeaturesBean();
                TblSubFeatureDbBean subFeatBean = subFeatQry.getDbBean(i);
                sfBean.setSubFeatureId(subFeatBean.getSubFeatureId());
                sfBean.setFeatureId(subFeatBean.getFeatureId());
                if (sfBean.getFeatureId() > 0)
                {
                    TblVzbFeaturesQuery featQry = new TblVzbFeaturesQuery();
                    featQry.whereFeatureIdEQ((int) sfBean.getFeatureId());
                    featQry.query(connection);
                    if (featQry.size() > 0)
                    {
                        sfBean.setFeatureName(featQry.getDbBean(0).getName());
                        sfBean.setFeatureDesc(featQry.getDbBean(0).getDescription());
                        sfBean.setIsBillable(featQry.getDbBean(0).getIsBillable());
                    }
                }
                sfBean.setSubId(subFeatBean.getSubId());
                sfBean.setSelected(subFeatBean.getIsSelected());
                sfBean.setCreatedBy(subFeatBean.getCreatedBy());
                sfBean.setModifiedBy(subFeatBean.getModifiedBy());
                
                for(int j=0;j<_subscribers.size();j++)
        		{
        			if(null!=_subscribers.get(j).getSubId() 
        					&& _subscribers.get(j).getSubId().equalsIgnoreCase(sfBean.getSubId()))
        			{
        				Subscriber _currntSubscrbr = _subscribers.get(j);
        				if(null==_currntSubscrbr.getSubFeatBeanList() || 0==_currntSubscrbr.getSubFeatBeanList().size())
        				{
        					_subFeatBeanList = new ArrayList<SubFeaturesBean>();
        					_subFeatBeanList.add(sfBean);
        					_currntSubscrbr.setSubFeatBeanList(_subFeatBeanList);	
        				}
        				else
        				{
        					 _subFeatBeanList = _currntSubscrbr.getSubFeatBeanList();
        					 _subFeatBeanList.add(sfBean);
        					
        					_currntSubscrbr.setSubFeatBeanList(_subFeatBeanList);
        				}
        			}
        		}
             }
        }
        catch (SQLException e)
        {
            e.printStackTrace();
            setStatus(InvErrorCode.INV_FAILURE);
            return false;
        }
        setStatus(InvErrorCode.SUCCESS);
        return true;
    }

    public Map<String, String> getUserIdByLocationAndExtension(String extn, String locId)
    {
        HashMap<String, String> userIdDomainMap = new HashMap<String, String>();
        try
        {
            TblSubscriberQuery subQry = new TblSubscriberQuery();
            subQry.whereExtensionEQ(extn);
            subQry.whereLocationIdEQ(locId);
            subQry.query(connection);
            if (subQry.size() == 1)
            {
                String subscriberId = subQry.getDbBean(0).getSubId();
                TblLocationQuery locQry = new TblLocationQuery();
                locQry.whereLocationIdEQ(locId);
                locQry.query(connection);
                if (locQry.size() == 1)
                {
                    userIdDomainMap.put(subscriberId, locQry.getDbBean(0).getSipDomain());
                } else
                    log.info("In getUserIdByLocationAndExtension,locations found not equal to 1 for extension,location"
                            + extn + "," + locId);
            } else
                log.info("In getUserIdByLocationAndExtension,subscriber found not equal to 1 for extension,location"
                        + extn + "," + locId);
        }
        catch (SQLException e)
        {
            e.printStackTrace();
            setStatus(InvErrorCode.INV_FAILURE);
        }
        return userIdDomainMap;
    }

	public boolean isExtnOnlySub()
    {
		boolean xtnOnly = false;
        try
        {
            TblSubscriberTnQuery subQry = new TblSubscriberTnQuery();
            subQry.whereSubIdEQ(subId);
            subQry.query(connection);
			if (subQry.size() <= 0)
			{
				log.info("Subscriber Not Found");
				return false;
			}
			boolean xtnType = false;
			boolean tnType = false;
			for(int i=0; i<subQry.size(); i++)
			{
				if(subQry.getDbBean(i).getNatUserId() == 0)
					xtnType = true;	
				//Any subscriber with natuserid 1,2,3,4,5,6 is a reg Sub
				if(subQry.getDbBean(i).getNatUserId() >= 1)
					tnType = true;
			}
			if(xtnType == true && tnType == false)
			{
				xtnOnly = true;
				log.info("Extension Only Subscriber");
			}
			else
				xtnOnly = false;
        }
        catch (SQLException e)
        {
            e.printStackTrace();
            setStatus(InvErrorCode.INV_FAILURE);
        }
		log.info("Retruning XtnOnlySub as [" + xtnOnly + "]");
        return xtnOnly;
    }
	
	public boolean isSubExtnOnly(String subId) throws Exception{
		PreparedStatement cntPstmt = null;
		ResultSet cntRs = null;

		StringBuffer extnSubCntSql = new StringBuffer();
		try{
			extnSubCntSql.append("select count(*) from tbl_subscriber sub, tbl_subscriber_tn stn where " +
					"sub.sub_id = stn.sub_id and stn.nat_user_id = 1 and stn.sub_id = ?");
			cntPstmt = connection.prepareStatement(extnSubCntSql.toString());
			cntPstmt.setString(1, subId);
			if (null != cntPstmt)
				cntRs = cntPstmt.executeQuery();
			if(cntRs.next()){
				if(cntRs.getInt(1) == 0){
					log.info("cnt is 0 so extn only subscriber :: "+subId);
					return true;
				}
			}
		}catch (SQLException e) {
			e.printStackTrace();
		}catch (Exception e) {
			e.printStackTrace();
		}finally{
			if(cntRs != null){
				cntRs.close();
			}
			if(cntPstmt != null){
				cntPstmt.close();
			}
		}
		return false;
	}
	
	public boolean isBilledExtensionSub(String subId) throws Exception{
		PreparedStatement cntPstmt = null;
		ResultSet cntRs = null;
		PreparedStatement billPstmt = null;
		ResultSet billRs = null;
		StringBuffer extnSubCntSql = new StringBuffer();
		StringBuffer billSubSql = new StringBuffer();
		try{
			extnSubCntSql.append("select count(*) from tbl_subscriber sub, tbl_subscriber_tn stn where " +
					"sub.sub_id = stn.sub_id and stn.nat_user_id = 1 and stn.sub_id = ? ");
			cntPstmt = connection.prepareStatement(extnSubCntSql.toString());
			cntPstmt.setString(1, subId);
			if (null != cntPstmt)
				cntRs = cntPstmt.executeQuery();
			if(cntRs.next()){
				if(cntRs.getInt(1) == 0){
					log.info("cnt is 0 so extn only subscriber :: "+subId);
					billSubSql.append("select count(*) from tbl_subscriber sub where sub_id = ? and billing_type = ?");
					billPstmt = connection.prepareStatement(billSubSql.toString());
					billPstmt.setString(1, subId);
					billPstmt.setLong(2, VzbVoipEnum.SubscriberBillingType.EXTN);
					if (null != billPstmt)
						billRs = billPstmt.executeQuery();
					if(billRs.next()){
						if(billRs.getInt(1) == 1){
							return true;
						}
					}
				}
			}
		}catch (SQLException e) {
			e.printStackTrace();
		}catch (Exception e) {
			e.printStackTrace();
		}finally{
			if(cntRs != null){
				cntRs.close();
			}
			if(cntPstmt != null){
				cntPstmt.close();
			}
			if(billRs != null){
				billRs.close();
			}
			if(billPstmt != null){
				billPstmt.close();
			}
		}
		return false;
	}

    /**
     * This method is for fetching Fmcg Subscriber for Subscriber
     * 
     * @return
     */
    public boolean getFmcgSubscriberForSubscriber()
    {
        try
        {
            //retrieve FmcgSubscriber details to get the FeaturePackageId(FEATURE_PKG_ID)
            boolean ret = getSubscriberDetailsBySubId();
            if (!ret)
            {
                setStatus(InvErrorCode.INV_FAILURE);
                log.info("FAILURE in getSubscriberDetailsBySubId subId. Subscriber.getSubscriberDetailsBySubId returned false in getFmcgSubscriberForSubscriber");
                return false;
            }
            log.info("In the Inventry, the FmcgSubscriber Id for Subscriber = " + subId + " is -> "
                    + fmcgSubId);
            //if PublicTnPoolId is valid, query the PublicTnPool class for details.
            FmcgSubscriber fmcgSubscriberObj = new FmcgSubscriber(connection);
            fmcgSubscriberObj.setFmcgSubId(new Long(fmcgSubId).intValue());
            ret = fmcgSubscriberObj.getFmcgSubscriberDetailsById();
            if (!ret)
            {
                setStatus(InvErrorCode.INV_FAILURE);
                log.info("FAILURE in fmcgSubscriberObj.getFmcgSubscriberDetailsById() returned false in getFmcgSubscriberForSubscriber");
                return false;
            }
            setFmcgSubscriberObj((FmcgSubscriber) fmcgSubscriberObj);
        }
        catch (Exception e)
        {
            e.printStackTrace();
            setStatus(InvErrorCode.DB_EXCEPTION);
            log.info("FAILURE in getDetails FmcgSubscriber");
            return false;
        }
        setStatus(InvErrorCode.SUCCESS);
        log.info("Successfully retrieved Fmcg Subscriber from the DB");
        return true;
    }
    
   /* public boolean getSoftPhoneByDeviceId(long deviceId){
    	try {
    		
    		TblSipDeviceInfoQuery sipDevQry = new TblSipDeviceInfoQuery();
    		sipDevQry.whereSipDeviceIdEQ((int)deviceId);
    		sipDevQry.query(connection);
    		 if (sipDevQry.size() <= 0)
             {
                 log.info("getSoftPhoneByDeviceId:deviceType Id  not found for given DeviceMapId=" + deviceId);
                 return false;
             }
    		 int deviceTypeId = (int)sipDevQry.getDbBean(0).getDeviceTypeId();
    		 TblDeviceTypesQuery devTypeQry = new TblDeviceTypesQuery();
    		 devTypeQry.whereDeviceTypeIdEQ(deviceTypeId);
    		 devTypeQry.query(connection);
    		 if(devTypeQry.size() <= 0)
    		 {
                 log.info("getSoftPhoneByDeviceId:deviceTypeName not found for given DeviceTypeId=" + deviceTypeId);
                 return false;
             } 
    		 String devTypeName = devTypeQry.getDbBean(0).getDeviceTypeName();
    		 if(null != devTypeName && devTypeName.trim().length()>0){
    			 if(devTypeName.equalsIgnoreCase("Fmcg Sip Device")||devTypeName.equalsIgnoreCase("Xten Soft Device"))
    	    			return true; 
    		 }	 
    		
    	}
    	catch (Exception e)
        {
            e.printStackTrace();            
            log.info("FAILURE in getSoftPhoneByDeviceId()");
            return false;
        }  	
    	
    	return false;
    }
    
    public boolean getSharedByDeviceId(long deviceId){
        try {
        	TblSipDeviceInfoQuery sipDevQry = new TblSipDeviceInfoQuery();
    		sipDevQry.whereSipDeviceIdEQ((int)deviceId);
    		sipDevQry.query(connection);
    		 if (sipDevQry.size() <= 0)
             {
                 log.info("getSharedByDeviceId:deviceType Id  not found for given DeviceMapId=" + deviceId);
                 return false;
             }
    		 int deviceTypeId = (int)sipDevQry.getDbBean(0).getDeviceTypeId();
    		 TblDeviceTypesQuery devTypeQry = new TblDeviceTypesQuery();
    		 devTypeQry.whereDeviceTypeIdEQ(deviceTypeId);
    		 devTypeQry.query(connection);
    		 if(devTypeQry.size() <= 0)
    		 {
                 log.info("getSharedByDeviceId:deviceTypeName not found for given DeviceTypeId=" + deviceTypeId);
                 return false;
             } 
    		 long devRealTypeId = devTypeQry.getDbBean(0).getDeviceRealtypeId();
    		 if(devRealTypeId > 0){
    			 TblDeviceRealtypeQuery devRealTypeQry = new TblDeviceRealtypeQuery();
    			 devRealTypeQry.whereDeviceRealtypeIdEQ((int)devRealTypeId);
    			 devRealTypeQry.query(connection);
    			 if (devRealTypeQry.size() <= 0)
                 {
                     log.info("getSharedByDeviceId:deviceRealTypeName not found for given DeviceRealTypeId=" + devRealTypeId);
                     return false;
                 }
    			 String devRealTypeName = devRealTypeQry.getDbBean(0).getDeviceRealtypeName();
    			 if(null != devRealTypeName && devRealTypeName.endsWith("Shared"))
    	    			return true; 
    		 }    		
    		
    	}
    	catch (Exception e)
        {
            e.printStackTrace();            
            log.info("FAILURE in getSharedByDeviceId");
            return false;
        }    	
    	
    	return false;
     }
   */ 
public boolean addXtenSoftDeviceToSubscriber(String customerId)
    {
        try
        {
			if(subId.equalsIgnoreCase("") || locationId.equalsIgnoreCase("") || customerId.equalsIgnoreCase(""))
			{
            setStatus(InvErrorCode.INVALID_INPUT);
            log.info("Failure in AddXtenSoftDev for Sub");
            return false;
			}
			String bsSubId = new String("");
			TblSubscriberQuery subQry = new TblSubscriberQuery();
			subQry.whereSubIdEQ(subId);
			subQry.query(connection);
			if(subQry.size() <= 0 )
			{
            setStatus(InvErrorCode.INV_FAILURE);
            log.info("Failure in getting the Subscriber for soft Dev");
            return false;
			}
			bsSubId = subQry.getDbBean(0).getBsSubId();
			SipDevice sipDeviceObj = new SipDevice(connection);
       Device deviceMapObj = new Device(connection);
			TblDeviceTypesQuery devTypeQry = new TblDeviceTypesQuery();
			DBTblDeviceMap devmap = new DBTblDeviceMap();
			int devMapId = devmap.getDeviceMapIdSeqNextVal(connection);
			devTypeQry.whereDeviceTypeNameEQ("Xten Soft Device");
			devTypeQry.query(connection);
			if(devTypeQry.size() <= 0)
			{
            setStatus(InvErrorCode.INV_FAILURE);
            log.info("Failure in getting the device type for soft Dev");
            return false;
			}
			long devTypeId = devTypeQry.getDbBean(0).getDeviceTypeId();
			sipDeviceObj.setSipDeviceId(devMapId);
			sipDeviceObj.setDeviceTypeId(devTypeId);
			sipDeviceObj.setDeviceName(bsSubId+"_xten");
			sipDeviceObj.setBsDeviceId(bsSubId+"_xten");
			sipDeviceObj.setCreatedBy("ESAP_MIG");
			sipDeviceObj.setModifiedBy("ESAP_MIG");
			if (!sipDeviceObj.addSipDevice()) {
            setStatus(InvErrorCode.INV_FAILURE);
            log.info("Failure in Adding sip Device for soft Dev");
            return false;
			}
			deviceMapObj.setEnterpriseId(customerId);
            log.info("Department id in Add Xten Deviuce ="+departmentId);
			if(!departmentId.equalsIgnoreCase("") && !departmentId.equalsIgnoreCase("NONE"))
				deviceMapObj.setDepartmentId(departmentId);
			deviceMapObj.setLocationId(locationId);
			deviceMapObj.setSipDeviceId(devMapId);
			deviceMapObj.setDeviceMapId(devMapId);
			deviceMapObj.setCreatedBy("ESAP_MIG");
			deviceMapObj.setModifiedBy("ESAP_MIG");
			if (!deviceMapObj.addDeviceMap()) {
            setStatus(InvErrorCode.NOT_ABLE_ADD_DEVICES);
            log.info("Failure in Adding Device map for soft Dev");
            return false;
			}
			SubscriberDevice subscriberDeviceObj = new SubscriberDevice(connection);	
			subscriberDeviceObj.setSubId(subId);
			subscriberDeviceObj.setDeviceMapId(devMapId);
			subscriberDeviceObj.setSipDeviceId(devMapId);
			subscriberDeviceObj.setCreatedBy("ESAP_MIG");
			subscriberDeviceObj.setLinePort(bsSubId + "_xten"+bsSubId);
				subscriberDeviceObj.setScaLineLabel("Xten Soft Device");
			subscriberDeviceObj.setModifiedBy("ESAP_MIG");
			log.info("Calling addXtenSoftDeviceToSubscriber:addSubDevBeanList");
			if (subscriberDeviceObj.addSubscriberDevice() != true)
        	{
            	log.info("Failed to Add Sub Device");
            	return false;
        	}
			log.info("Called addXtenSoftDeviceToSubscriber:addSubDevBeanList");

		 }
        catch (Exception e)
        {
            e.printStackTrace();
            setStatus(InvErrorCode.DB_EXCEPTION);
            log.info("FAILURE in getDetails FmcgSubscriber");
            return false;
        }
        setStatus(InvErrorCode.SUCCESS);
        log.info("Successfully retrieved Fmcg Subscriber from the DB")
;
        return true;
	}
    
	//IR #1353501  - For CSSOP TN_ON_OFF Needs to check
    public boolean getSubscriberTNWithONOFF(String[] subId){

    	log.info(" Entering getSubscriberTNWithONOFF");
    	PreparedStatement pstmt = null;
        ResultSet rs = null;
    	try {
    	 
         
         log.info("subId ===> " + Arrays.toString(subId));
         
         if ( subId != null){
	         StringBuffer sql = new StringBuffer();
	         
	         String q4in = generateQsForIn(subId.length);
	         
	         sql.append("select TSN.NAT_USER_ID, TSN.USER_ID, TSN.SUB_ID, TSN.NPA_SPLIT_STATUS, TPT.TN_ON_OFF, TPT.ACT_DEACT");
	         sql.append(" FROM TBL_SUBSCRIBER_TN TSN, TBL_PUBLIC_TN_POOL TPT");
	         sql.append(" WHERE TSN.USER_ID = TPT.TN AND ");
	         sql.append(" TSN.SUB_ID in (" + q4in + ") ");
	         
	         log.info("SQL [" + sql.toString() + "]");
	         
	         SubscriberTnBean subTnBean = null;
	         pstmt = connection.prepareStatement(sql.toString());
	         int i = 1; 
	         for (String item : subId) {
        		 pstmt.setString(i++, item); 
	         } 
	         rs = pstmt.executeQuery();
	
	         if ( rs != null ){
	        	 List<SubscriberTnBean> subTnList  = new ArrayList<SubscriberTnBean>();
		         while (rs.next())
		         {
		            subTnBean = new SubscriberTnBean();
		            subTnBean.setNatUserId(rs.getLong(1) );
		            subTnBean.setUserId(rs.getString(2));
		            subTnBean.setSubId(rs.getString(3));
		            subTnBean.setNpaSplitStatus(rs.getLong(4));
		            subTnBean.setTnOnOff(rs.getLong(5));
		            log.info(" TN " + subTnBean.getUserId() + " TnOnOff -> " + subTnBean.getTnOnOff());
		            subTnBean.setActDeact(rs.getShort(6));
		            subTnList.add(subTnBean);
		         }
		         log.info(" adding subTnList " + subTnList );
		         setSubTnBeanList(subTnList);
	         }else{
	        	 return false;
	         }
	         
         }else{
        	 log.info(" Subscriber Tn not Found With Subscriber Id "+ Arrays.toString(subId));
        	 return false;
         }
    	}catch(Exception e){
    		e.printStackTrace();
    		return false;
    	}finally{ //#IR1440263 closing statement and results set
		   try{
			   if ( pstmt != null) {
				   pstmt.close();
			   }
			   if ( rs != null ){
				   rs.close();
			   }
		   }catch(Exception e){
			   e.printStackTrace();
	    	   return false;
			   //log.info(" Closing Resouces Exception " + e);
		   }
		}
    	return true;
    	
    }
    
    private String generateQsForIn(int numQs) { 
    	log.info(" Entering generateQsForIn");
        String items = ""; 
        for (int i = 0; i < numQs; i++) { 
            items += "?"; 
            if (i < numQs - 1) { 
                items += ", "; 
            } 
        } 
        return items; 
    } 
   
    public ArrayList<TblSubscriberDbBean> getGroupbyGatewayDeviceId(String pDeviceMapId) throws Exception{
		
		log.info(" Entering getGroupbyGatewayDeviceId  querying");
		ArrayList<TblSubscriberDbBean> resultList = null;
		TblSubscriberDbBean tblSubscriberDbBean = null;
		PreparedStatement pStmt = null;
		ResultSet rs = null;
		StringBuffer sql = new StringBuffer();
		sql.append("select * from tbl_subscriber");
		sql.append(" where sub_id in (select sub_id from tbl_subscriber_device where");
		sql.append(" device_map_id in (select device_map_id from tbl_device_map where device_map_id = ? and gateway_device_id in(");
		sql.append(" select gateway_device_id from tbl_gateway_device_info");
		sql.append(" where device_type_id in (select device_type_id from tbl_device_types where device_realtype_id = 4))))");
		
		
		log.info("getGroupbyGatewayDeviceId sql string :  "+sql.toString());
		
		try {
			pStmt = connection.prepareStatement(sql.toString());
			pStmt.setString(1, pDeviceMapId);
			//pStmt.setString(2, pDeviceMapId);
			
			if (null != pStmt)
				rs = pStmt.executeQuery();
			if ( rs != null ){
				resultList = new ArrayList<TblSubscriberDbBean>();
				
				while (rs.next()) {
					tblSubscriberDbBean = new TblSubscriberDbBean();
					tblSubscriberDbBean.setSubId(rs.getString(1));
					tblSubscriberDbBean.setBsSubId(rs.getString(2));
					tblSubscriberDbBean.setLocationId(rs.getString(3));
					tblSubscriberDbBean.setDepartmentId(rs.getString(4));
					tblSubscriberDbBean.setPpId(rs.getLong(5));
					tblSubscriberDbBean.setLastName(rs.getString(6));
					tblSubscriberDbBean.setFirstName(rs.getString(7));
					tblSubscriberDbBean.setMiddleInitial(rs.getString(8));
					tblSubscriberDbBean.setCompanyName(rs.getString(9));
					tblSubscriberDbBean.setEmail(rs.getString(10));
					tblSubscriberDbBean.setHomePhone(rs.getString(11));
					tblSubscriberDbBean.setWorkPhone(rs.getString(12));
					tblSubscriberDbBean.setMobilePhone(rs.getString(13));
					tblSubscriberDbBean.setTimeZone(rs.getString(14));
					tblSubscriberDbBean.setWebLang(rs.getLong(15));
					tblSubscriberDbBean.setAccessLevel(rs.getLong(16));
					tblSubscriberDbBean.setWebLoginId(rs.getString(17));
					tblSubscriberDbBean.setWebPassword(rs.getString(18));
					tblSubscriberDbBean.setSipUsername(rs.getString(19));
					tblSubscriberDbBean.setSipPassword(rs.getString(20));
					tblSubscriberDbBean.setSipAddress(rs.getString(21));
					tblSubscriberDbBean.setMobileUser(rs.getLong(22));
					tblSubscriberDbBean.setFeaturePkgId(rs.getLong(23));
					tblSubscriberDbBean.setCidFirstName(rs.getString(24));
					tblSubscriberDbBean.setCidLastName(rs.getString(25));
					tblSubscriberDbBean.setVmLang(rs.getLong(26));
					tblSubscriberDbBean.setVmMaxsize(rs.getLong(27));
					tblSubscriberDbBean.setVmBoxNum(rs.getString(28));
					tblSubscriberDbBean.setVmRouteNum(rs.getString(29));
					tblSubscriberDbBean.setVmPasscode(rs.getString(30));
					tblSubscriberDbBean.setVmPin(rs.getString(31));
					tblSubscriberDbBean.setVmStatus(rs.getLong(32));
					tblSubscriberDbBean.setVmActiveDate(rs.getLong(33));
					tblSubscriberDbBean.setVmTermDate(rs.getLong(34));
					tblSubscriberDbBean.setVmChangeDate(rs.getLong(35));
					tblSubscriberDbBean.setSubAddrId(rs.getLong(36));
					tblSubscriberDbBean.setRpid(rs.getString(37));
					tblSubscriberDbBean.setRpidPriv(rs.getLong(38));
					tblSubscriberDbBean.setRpidPoolid(rs.getLong(39));
					tblSubscriberDbBean.setExtension(rs.getString(40));
					tblSubscriberDbBean.setPubIp(rs.getLong(41));
					tblSubscriberDbBean.setCallingPlanId(rs.getLong(42));
					tblSubscriberDbBean.setRegistrationType(rs.getLong(43));
					tblSubscriberDbBean.setRegistrationStatus(rs.getLong(44));
					tblSubscriberDbBean.setRegistrationKey(rs.getString(45));
					tblSubscriberDbBean.setAdminSecretQuestion(rs.getString(46));
					tblSubscriberDbBean.setAdminSecretAnswer(rs.getString(47));
					tblSubscriberDbBean.setSecretQuestion(rs.getString(48));
					tblSubscriberDbBean.setSecretAnswer(rs.getString(49));
					tblSubscriberDbBean.setSearchOption(rs.getLong(50));
					tblSubscriberDbBean.setAllowUserSearch(rs.getLong(51));
					tblSubscriberDbBean.setCreatedBy(rs.getString(52));
					//log.info(" rs.getDate(53)).getTime() " + rs.getString("CREATION_DATE") );
					//tblSubscriberDbBean.setCreationDate((rs.getDate(53)).getTime());
					tblSubscriberDbBean.setModifiedBy(rs.getString(54));
					//tblSubscriberDbBean.setLastModifiedDate(rs.getTimestamp(55));
					tblSubscriberDbBean.setEnvOrderId(Long.valueOf(rs.getString("ENV_ORDER_ID")));
					tblSubscriberDbBean.setFmcgSubId(rs.getLong(57));
					tblSubscriberDbBean.setSubscriberType(rs.getLong(58));
					tblSubscriberDbBean.setAuthUserName(rs.getString(59));
					tblSubscriberDbBean.setAuthPassword(rs.getString(60));
					tblSubscriberDbBean.setSipRegistrarDomain(rs.getString(61));
					tblSubscriberDbBean.setSipRegistrationInterval(rs.getLong(62));
					tblSubscriberDbBean.setBrixInd(rs.getLong(63));
					tblSubscriberDbBean.setAuthSeed(rs.getString(64));
					tblSubscriberDbBean.setUserType(rs.getLong(65));
					tblSubscriberDbBean.setReceptionistType((short)rs.getLong(66));
					//Jan 2011 Release changes
					tblSubscriberDbBean.setDeviceLoginId(rs.getString(67));
					tblSubscriberDbBean.setDevicePassword(rs.getString(68));
					resultList.add(tblSubscriberDbBean);
				}
				
				log.info(" Entering getGroupbyGatewayDeviceId  Result size " + resultList.size());
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw e;
		} finally {
			try {
				if (null != pStmt)
					pStmt.close();
				if (null != rs)
					rs.close();
			} catch (Exception e) {
				e.printStackTrace();
				throw e;
			}
		}
		
		return resultList;
		
	}
    
    // 53266.AM APAC VOIP LNP - changes for july 2011
	/**
	 * @param subId is tbl_susbcriber.subid
	 * @param roamingStatus 
	 * @return boolean returns true if update successful
	 */
	public boolean ValidateCustomerForEmergencyUpdate(String subId, int roamingStatus ) throws Exception
	{
		log.info("Entered into method ValidateCustomerForEmergencyUpdate");
		
		// DB realted variables declaration	
		PreparedStatement pStmt = null;
		ResultSet rs = null;
		StringBuffer tblSubscriberSql = new StringBuffer();
		StringBuffer updateTblSubscriberSql = new StringBuffer();
		
		// Local variable declaration 
		int activeIndicator = 0;
		String location_id = null;
		String country = null;
		
		//return flag
		boolean ret_code = false;
	
		
		if(subId == null && (subId.trim().equals("")))
		{
            log.info("subId = Null; No need to update anything");
            return ret_code;
		}
		
		// query construction - to get the active indicator from tbl_subscriber and country from tbl_location using the given subId 
		tblSubscriberSql.append("select s.active_ind , s.location_id , l.loc_country from tbl_subscriber s ,tbl_location l ");
		tblSubscriberSql.append(" where s.location_id = l.location_id and s.sub_id = ?");
		
		try 
		{
			pStmt = connection.prepareStatement(tblSubscriberSql.toString());
			pStmt.setString(1, subId);
			
			if (null != pStmt)
				rs = pStmt.executeQuery();
			if ( rs != null )
			{
				while (rs.next()) 
				{
					activeIndicator = rs.getInt(1); // get the active indicator
					location_id = rs.getString(2); // get the location id
					country = rs.getString(3); // get the country
					break;
				}
			}
			else
			{
				log.info("does not find the record for the sub id " + subId + "provided");
	            return ret_code;
			}
			
			pStmt = null;
			rs = null;
			
			// EMERGOVERRIDE should be updated only when the customer is from HK and active
			if(country != null && country.equalsIgnoreCase("HK"))
			{
				if(activeIndicator == 1)
				{
					updateTblSubscriberSql.append("UPDATE tbl_subscriber SET ");
					if ( roamingStatus > 1 )
					{
						updateTblSubscriberSql.append(" EMERGOVERRIDE = '" + roamingStatus + "',");
					}
					else
					{
						updateTblSubscriberSql.append(" EMERGOVERRIDE = null ,");
					}
					
					updateTblSubscriberSql.append(" Modified_by = '" + "ICP" + "',");
					updateTblSubscriberSql.append(" LAST_MODIFIED_DATE = SYSDATE ");
					updateTblSubscriberSql.append(" WHERE sub_id ='" + subId + "'");
					
					pStmt = connection.prepareStatement(updateTblSubscriberSql.toString());
					
					log.info("Update query : " + updateTblSubscriberSql.toString());
					
					if (null != pStmt)
					{
						pStmt.executeUpdate();
					}
					log.info("EMERGOVERRIDE updated sucessfully for the " + subId);
					ret_code = true;
				}
				else
				{
				   log.info(subId + "subscriber is not active");
		           ret_code = false;
				}
			}
			else
			{
				log.info(subId + "subscriber is not from HK");
				ret_code = false;
			}
			
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
			throw e;
		}
		finally
		{
			try
			{
				if (null != pStmt)
					pStmt.close();
				if (null != rs)
					rs.close();
			} 
			catch (Exception e) 
			{
				e.printStackTrace();
				throw e;
			}
		}
		
		return ret_code;
		
		
	}
	
	 public String getSubscriberIdForTn(String tn) throws Exception{
		 
		   String subscriberId= null;
		   
		   log.info(" inside getSubscriberIdForTn()... ");
		   
		   if(tn == null || "".equals(tn) ){			   
             log.info("FAILURE in getSubscriberIdForTn() in FraudBlock, TN is missing.");
             throw new Exception();
		   }
		   
		   TblSubscriberTnQuery queryforSubscriber = new TblSubscriberTnQuery();
		   queryforSubscriber.whereUserIdEQ(tn);
		   queryforSubscriber.query(connection);
		   
		   if(queryforSubscriber.size() == 1){
			   TblSubscriberTnDbBean subTnDbBean = queryforSubscriber.getDbBean(0);
			   subscriberId = subTnDbBean.getSubId();
			   
		   }else{
			   log.info(" Found 0 or more than one Subscriber for the Given tn");
			   throw new Exception();
		   }
		   return subscriberId;
	 } 

	// added by z658915 for calnet changes starts
	 
	public int updateBillingType(short billingType) {
		int subscriberRecCountUpdated = 0;

		DBTblSubscriber tblSubscriber = new DBTblSubscriber();
		tblSubscriber.setBillingType(billingType);
		tblSubscriber.whereSubIdEQ(subId);
		try {
			subscriberRecCountUpdated = tblSubscriber.updateSpByWhere(connection);
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return subscriberRecCountUpdated;
	}
	// added by z658915 for calnet changes ends

	public String getTnforSubId(String subId) throws Exception{
		String tn = null;
		StringBuffer tnSubscriberSql = new StringBuffer();
		PreparedStatement ps = null;
		ResultSet rs = null;
		try{
			tnSubscriberSql.append("select stn.user_id from  tbl_subscriber sub , tbl_subscriber_tn stn " +
					"where  stn.sub_id= sub.sub_id and stn.nat_user_id = 1 and " +
					"sub.sub_id = ?");
			ps = connection.prepareStatement(tnSubscriberSql.toString());
			ps.setString(1, subId);
			if (null != ps)
				rs = ps.executeQuery();
			if ( rs != null && rs.next())
			{
				tn = rs.getString(1);
			}
		}catch (SQLException e) {
			e.printStackTrace();
		}finally{
			if(rs != null){
				rs.close();
			}
			if(ps != null){
				ps.close();
			}
		}
		return tn;
	}
	
	public String getExtnforSubId(String subId) throws Exception{
		String extn = null;
		StringBuffer tnSubscriberSql = new StringBuffer();
		PreparedStatement ps = null;
		ResultSet rs = null;
		try{
			tnSubscriberSql.append("select sub.extension from  tbl_subscriber sub where sub.sub_id = ?");
			ps = connection.prepareStatement(tnSubscriberSql.toString());
			ps.setString(1, subId);
			if (null != ps)
				rs = ps.executeQuery();
			if ( rs != null && rs.next())
			{
				extn = rs.getString(1);
			}
		}catch (SQLException e) {
			e.printStackTrace();
		}finally{
			if(rs != null){
				rs.close();
			}
			if(ps != null){
				ps.close();
			}
		}
		return extn;
	}
	
	
	public long getDeviceforSubId(String subId) throws Exception{
		long deviceId = 0;
		StringBuffer tnSubscriberSql = new StringBuffer();
		PreparedStatement ps = null;
		ResultSet rs = null;
		try{
			tnSubscriberSql.append("select dmap.sip_device_id from  tbl_subscriber sub, tbl_subscriber_device sd, tbl_device_map dmap " +
					"where sd.sub_id = sub.sub_id and dmap.device_map_id = sd.device_map_id and sd.sca_line_label is null and " +
					"sub.sub_id = ?");
			ps = connection.prepareStatement(tnSubscriberSql.toString());
			ps.setString(1, subId);
			if (null != ps)
				rs = ps.executeQuery();
			if ( rs != null && rs.next())
			{
				deviceId = rs.getLong(1);
			}
		}catch (SQLException e) {
			e.printStackTrace();
		}finally{
			if(rs != null){
				rs.close();
			}
			if(ps != null){
				ps.close();
			}
		}
		return deviceId;
	}
	
	

    
    
    private Map<String, String> getCANMDetails(String subId) throws SQLException
    {
        HashMap<String, String> userIdDomainMap = new HashMap<String, String>();
        PreparedStatement ps = null;
		ResultSet rs = null;
        try
        {
        	String sql = "select CNAM_UPDATE_STATUS, CNAM_UPDATE_DATE from tbl_public_tn_pool t,Tbl_Subscriber_tn l where l.USER_ID = t.tn and t.ACTIVE_IND=1 and l.SUB_ID = "+"'"+subId+"'";
        	log.info("Query For SubScriber CNAM Details = " +sql);
        	ps = connection.prepareStatement(sql);
	        rs = ps.executeQuery();
	         if(rs.next()) {
	        	 userIdDomainMap.put("CnamUpdateStatus", String.valueOf(rs.getLong("CNAM_UPDATE_STATUS")));
	        	 userIdDomainMap.put("CnamUpdateDate", String.valueOf(rs.getTimestamp("CNAM_UPDATE_DATE")));
		     }
        }
        catch (SQLException e)
        {
            e.printStackTrace();
            setStatus(InvErrorCode.INV_FAILURE);
        }
        finally{
        	if(rs != null){
        		rs.close();
        	}
        	if(ps != null){
        		ps.close();
        	}
        }
        log.info("Query For SubScriber CNAM Details userIdDomainMap ============== " +userIdDomainMap);
        return userIdDomainMap;
    }
    
   

}
