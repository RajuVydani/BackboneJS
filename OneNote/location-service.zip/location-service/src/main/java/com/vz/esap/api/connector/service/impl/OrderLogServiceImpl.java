/**
 * 
 */
package com.vz.esap.api.connector.service.impl;

import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.vz.esap.api.model.OrderErrorLogInfo;
import com.vz.esap.api.model.OrderLogInfo;
import com.vz.esap.api.model.OrderRspInfo;
import com.vz.esap.api.model.ResponseObject;
import com.vz.esap.api.model.TaskCompletionLogInfo;

/**
 * @author aricent
 * 
 */
@Component
public class OrderLogServiceImpl {

	private static final Logger logger = LoggerFactory
			.getLogger(OrderLogServiceImpl.class);

	private final ScheduledExecutorService scheduler = Executors
			.newScheduledThreadPool(1);

	/*@Autowired
	private RestTemplate restTemplate;*/
	private RestTemplate restTemplate = new RestTemplate();
	@Value("${orderDomain.loggingService}")
	private String loggingServiceBaseURL;

	private Set<OrderLogInfo> orderLogInfoList = new LinkedHashSet <OrderLogInfo>();

	private Set<OrderErrorLogInfo> orderErrorLogList = new LinkedHashSet<OrderErrorLogInfo>();

	private Set<OrderRspInfo> orderRspLogList = new LinkedHashSet<OrderRspInfo>();

	private Set<TaskCompletionLogInfo> taskCompletionLogList = new LinkedHashSet<TaskCompletionLogInfo>();

	private FlushLogHandler flushLogHandler = new FlushLogHandler();

	final ScheduledFuture<?> flushLogScheduler = scheduler.scheduleAtFixedRate(
			flushLogHandler, 60, 20, TimeUnit.SECONDS);

	// private String loggingServiceBaseURL =
	// "http://pbxomzstd03.vzbi.com:40041/logging";

	
	public void insertOrderLog(OrderLogInfo logRequestObj) {

		// final String insertTblOrderLogURL = loggingServiceBaseURL
		// .concat("/insertTblOrderLog");

		logger.trace("insertOrderLog(): Request Message: {}", logRequestObj);
		orderLogInfoList.add(logRequestObj);

		/*
		 * try {
		 * 
		 * logger.debug("insertOrderLog(): Request Message: {}", logRequestObj);
		 * 
		 * orderLogInfoList.add(logRequestObj);
		 * 
		 * // System.out.println("JSON:\n" + json);
		 * 
		 * long startTime = System.currentTimeMillis(); logger.info(
		 * "insertOrderLog(): Making HTTP POST Request for workOrderNumber:{} at time:{}"
		 * , "", startTime); logger.info("insertOrderLog(): Service URL: {}",
		 * insertTblOrderLogURL);
		 * logger.info("insertOrderLog(): Service restTemplate: {}",
		 * restTemplate);
		 * 
		 * ResponseObject orderLogServiceResponse = restTemplate
		 * .postForObject(insertTblOrderLogURL, logRequestObj,
		 * ResponseObject.class);
		 * 
		 * long endTime = System.currentTimeMillis();
		 * 
		 * // System.out.println("OrderLogServiceResponse:" + //
		 * orderLogServiceResponse);
		 * 
		 * logger.info(
		 * "insertOrderLog(): Time taken for Response for tableName:{} is:{} ms"
		 * , "", (endTime - startTime));
		 * logger.debug("insertOrderLog(): Response from OrderLogService: {}",
		 * orderLogServiceResponse); logger.info("Exiting insertOrderLog() ");
		 * 
		 * } catch (HttpStatusCodeException e) {
		 * logger.error("Exception received from OrderLogService : {} ",
		 * insertTblOrderLogURL); logger.error(
		 * "Execption during insertOrderLog execution code:{} , text:{}",
		 * e.getStatusCode(), e.getResponseBodyAsString()); } catch
		 * (RestClientException e) {
		 * logger.error("Exception received from OrderLogService : {} ",
		 * insertTblOrderLogURL);
		 * logger.error("Exception received from OrderLogService : {} ", e); }
		 */

	}

	
	public void insertOrderLog(List<OrderLogInfo> logRequestObjList) {

		/*
		 * final String insertBulkTblOrderLogURL = loggingServiceBaseURL
		 * .concat("/insertBulkTblOrderLog");
		 */

		logger.trace("insertOrderLog()");

		if (logRequestObjList == null || logRequestObjList.isEmpty()) {
			// throw new RuntimeException("Empty or Null List");
			return;
		}

		orderLogInfoList.addAll(logRequestObjList);

		/*
		 * try {
		 * 
		 * if (logRequestObjList == null || logRequestObjList.isEmpty()) { //
		 * throw new RuntimeException("Empty or Null List"); return; }
		 * 
		 * orderLogInfoList.addAll(logRequestObjList);
		 * 
		 * 
		 * logger.info("insertOrderLog(): No. of logs to be written :{}", "",
		 * logRequestObjList.size()); // Gson gson = new
		 * GsonBuilder().setPrettyPrinting().create(); // String json =
		 * gson.toJson(logRequestObjList);
		 * 
		 * // System.out.println("JSON:\n" + json);
		 * 
		 * long startTime = System.currentTimeMillis(); logger.info(
		 * "insertOrderLog(): Making HTTP POST Request for workOrderNumber:{} at time:{}"
		 * , "", startTime); logger.info("insertOrderLog(): Service URL: {}",
		 * insertBulkTblOrderLogURL);
		 * logger.info("insertOrderLog(): Service restTemplate: {}",
		 * restTemplate);
		 * 
		 * ResponseObject orderLogServiceResponse = restTemplate
		 * .postForObject(insertBulkTblOrderLogURL, logRequestObjList,
		 * ResponseObject.class);
		 * 
		 * long endTime = System.currentTimeMillis();
		 * 
		 * // System.out.println("OrderLogServiceResponse:" + //
		 * orderLogServiceResponse);
		 * 
		 * logger.info(
		 * "insertOrderLog(): Time taken for Response for tableName:{} is:{} ms"
		 * , "", (endTime - startTime));
		 * logger.debug("insertOrderLog(): Response from OrderLogService: {}",
		 * orderLogServiceResponse); logger.info("Exiting insertOrderLog() ");
		 * 
		 * } catch (HttpStatusCodeException e) {
		 * logger.error("Exception received from OrderLogService : {} ",
		 * insertBulkTblOrderLogURL); logger.error(
		 * "Execption during insertOrderLog execution code:{} , text:{}",
		 * e.getStatusCode(), e.getResponseBodyAsString()); } catch
		 * (RestClientException e) {
		 * logger.error("Exception received from OrderLogService : {} ",
		 * insertBulkTblOrderLogURL);
		 * logger.error("Exception received from OrderLogService : {} ", e); }
		 */
	}

	
	public void insertOrderLogError(List<OrderErrorLogInfo> logRequestObjList) {

		logger.trace("insertOrderLogError()");

		/*
		 * final String insertBulkTblOrderVarErrorsURL = loggingServiceBaseURL
		 * .concat("/insertBulkTblEnvOrderValErrors");
		 */

		if (logRequestObjList == null || logRequestObjList.isEmpty()) {
			// throw new RuntimeException("Empty or Null List");
		}
		orderErrorLogList.addAll(logRequestObjList);

		/*
		 * try {
		 * 
		 * if (logRequestObjList == null || logRequestObjList.isEmpty()) {
		 * //throw new RuntimeException("Empty or Null List"); }
		 * 
		 * logger.info("insertOrderLogError(): No. of logs to be written :{}",
		 * "", logRequestObjList.size()); // Gson gson = new
		 * GsonBuilder().setPrettyPrinting().create(); // String json =
		 * gson.toJson(logRequestObjList);
		 * 
		 * // System.out.println("JSON:\n" + json);
		 * 
		 * long startTime = System.currentTimeMillis(); logger.info(
		 * "insertOrderLogError(): Making HTTP POST Request for workOrderNumber:{} at time:{}"
		 * , "", startTime);
		 * logger.info("insertOrderLogError(): Service URL: {}",
		 * insertBulkTblOrderVarErrorsURL);
		 * logger.info("insertOrderLogError(): Service restTemplate: {}",
		 * restTemplate);
		 * 
		 * ResponseObject orderLogServiceResponse = restTemplate
		 * .postForObject(insertBulkTblOrderVarErrorsURL, logRequestObjList,
		 * ResponseObject.class);
		 * 
		 * long endTime = System.currentTimeMillis();
		 * 
		 * // System.out.println("OrderLogServiceResponse:" + //
		 * orderLogServiceResponse);
		 * 
		 * logger.info(
		 * "insertOrderLogError(): Time taken for Response for tableName:{} is:{} ms"
		 * , "", (endTime - startTime)); logger.debug(
		 * "insertOrderLogError(): Response from OrderLogService: {}",
		 * orderLogServiceResponse);
		 * logger.info("Exiting insertOrderLogError() ");
		 * 
		 * } catch (HttpStatusCodeException e) {
		 * logger.error("Exception received from OrderLogService : {} ",
		 * insertBulkTblOrderVarErrorsURL); logger.error(
		 * "Execption during insertOrderLogError execution code:{} , text:{}",
		 * e.getStatusCode(), e.getResponseBodyAsString()); } catch
		 * (RestClientException e) {
		 * logger.error("Exception received from OrderLogService : {} ",
		 * insertBulkTblOrderVarErrorsURL);
		 * logger.error("Exception received from OrderLogService : {} ", e); }
		 */
	}

	
	public void insertOrderRsp(List<OrderRspInfo> orderRspInfoList) {
		/*
		 * final String insertBulkTblOrderRspURL = loggingServiceBaseURL
		 * .concat("/insertBulkTblOrderRsp");
		 */

		logger.trace("insertOrderRsp()");

		if (orderRspInfoList == null || orderRspInfoList.isEmpty()) {
			// throw new RuntimeException("Empty or Null List");
			return;
		}
		orderRspLogList.addAll(orderRspInfoList);

		/*
		 * try {
		 * 
		 * if (orderRspInfoList == null || orderRspInfoList.isEmpty()) { throw
		 * new RuntimeException("Empty or Null List"); }
		 * logger.info("insertOrderRsp(): No. of logs to be written :{}",
		 * orderRspInfoList.size());
		 * 
		 * Gson gson = new GsonBuilder().setPrettyPrinting().create(); String
		 * json = gson.toJson(orderRspInfoList);
		 * 
		 * 
		 * // System.out.println("JSON:\n" + json);
		 * 
		 * long startTime = System.currentTimeMillis(); logger.info(
		 * "insertOrderRsp(): Making HTTP POST Request for workOrderNumber:{} at time:{}"
		 * , "", startTime); logger.info("insertOrderRsp(): Service URL: {}",
		 * insertBulkTblOrderRspURL);
		 * 
		 * ResponseObject orderLogServiceResponse = restTemplate
		 * .postForObject(insertBulkTblOrderRspURL, orderRspInfoList,
		 * ResponseObject.class);
		 * 
		 * long endTime = System.currentTimeMillis();
		 * 
		 * // //System.out.println("OrderLogServiceResponse:" + //
		 * orderLogServiceResponse);
		 * 
		 * logger.info(
		 * "insertOrderRsp(): Time taken for Response for tableName:{} is:{} ms"
		 * , "", (endTime - startTime));
		 * logger.debug("insertOrderRsp(): Response from OrderLogService: {}",
		 * orderLogServiceResponse); logger.info("Exiting insertOrderRsp() ");
		 * 
		 * } catch (HttpStatusCodeException e) {
		 * logger.error("Exception received from OrderLogService : {} ",
		 * insertBulkTblOrderRspURL); logger.error(
		 * "Execption during insertOrderRsp execution code:{} , text:{}",
		 * e.getStatusCode(), e.getResponseBodyAsString()); } catch
		 * (RestClientException e) {
		 * logger.error("Exception received from OrderLogService : {} ",
		 * insertBulkTblOrderRspURL);
		 * logger.error("Exception received from OrderLogService : {} ", e); }
		 */
	}

	
	public void insertTaskCompletionLog(
			List<TaskCompletionLogInfo> taskCompletionLogInfoList) {
		/*
		 * final String insertBulkTaskCompletionLogURL = loggingServiceBaseURL
		 * .concat("/insertBulkTblTaskCompletionLog");
		 */

		if (taskCompletionLogInfoList == null
				|| taskCompletionLogInfoList.isEmpty()) {
			// throw new RuntimeException("Empty or Null List");
			return;
		}

		taskCompletionLogList.addAll(taskCompletionLogInfoList);

		/*
		 * try {
		 * 
		 * if (taskCompletionLogInfoList == null ||
		 * taskCompletionLogInfoList.isEmpty()) { throw new
		 * RuntimeException("Empty or Null List"); }
		 * logger.info("insertOrderRsp(): No. of logs to be written :{}",
		 * taskCompletionLogInfoList.size());
		 * 
		 * Gson gson = new GsonBuilder().setPrettyPrinting().create(); String
		 * json = gson.toJson(taskCompletionLogInfoList);
		 * 
		 * 
		 * // System.out.println("JSON:\n" + json);
		 * 
		 * long startTime = System.currentTimeMillis(); logger.info(
		 * "insertTaskCompletionLog(): Making HTTP POST Request for workOrderNumber:{} at time:{}"
		 * , "", startTime);
		 * logger.info("insertTaskCompletionLog(): Service URL: {}",
		 * insertBulkTaskCompletionLogURL);
		 * 
		 * ResponseObject orderLogServiceResponse = restTemplate
		 * .postForObject(insertBulkTaskCompletionLogURL,
		 * taskCompletionLogInfoList, ResponseObject.class);
		 * 
		 * long endTime = System.currentTimeMillis();
		 * 
		 * // System.out.println("OrderLogServiceResponse:" + //
		 * orderLogServiceResponse);
		 * 
		 * logger.info(
		 * "insertTaskCompletionLog(): Time taken for Response for tableName:{} is:{} ms"
		 * , "", (endTime - startTime));
		 * logger.debug("insertOrderRsp(): Response from OrderLogService: {}",
		 * orderLogServiceResponse);
		 * logger.info("Exiting insertTaskCompletionLog() ");
		 * 
		 * } catch (HttpStatusCodeException e) {
		 * logger.error("Exception received from OrderLogService : {} ",
		 * insertBulkTaskCompletionLogURL); logger.error(
		 * "Execption during insertOrderRsp execution code:{} , text:{}",
		 * e.getStatusCode(), e.getResponseBodyAsString()); } catch
		 * (RestClientException e) {
		 * logger.error("Exception received from OrderLogService : {} ",
		 * insertBulkTaskCompletionLogURL);
		 * logger.error("Exception received from OrderLogService : {} ", e); }
		 */

	}

	/**
	 * This method is responsible to flush all insert order logs
	 * 
	 */
	public void flushInsertOrderLog() {

		logger.trace("flushInsertOrderLog()");

		final String insertBulkTblOrderLogURL = loggingServiceBaseURL
				.concat("/insertBulkTblOrderLog");

		try {

			if (orderLogInfoList == null || orderLogInfoList.isEmpty()) {
				// throw new RuntimeException("Empty or Null List");
				return;
			}

			logger.info("insertOrderLog(): No. of logs to be written :{}", "",
					orderLogInfoList.size());
			// Gson gson = new GsonBuilder().setPrettyPrinting().create();
			// String json = gson.toJson(logRequestObjList);

			// System.out.println("JSON:\n" + json);

			long startTime = System.currentTimeMillis();
			logger.info(
					"insertOrderLog(): Making HTTP POST Request for workOrderNumber:{} at time:{}",
					"", startTime);
			logger.info("insertOrderLog(): Service URL: {}",
					insertBulkTblOrderLogURL);
			logger.info("insertOrderLog(): Service restTemplate: {}",
					restTemplate);

			ResponseObject orderLogServiceResponse = restTemplate
					.postForObject(insertBulkTblOrderLogURL, orderLogInfoList,
							ResponseObject.class);

			long endTime = System.currentTimeMillis();

			// System.out.println("OrderLogServiceResponse:" +
			// orderLogServiceResponse);

			logger.info(
					"insertOrderLog(): Time taken for Response for tableName:{} is:{} ms",
					"", (endTime - startTime));
			logger.debug("insertOrderLog(): Response from OrderLogService: {}",
					orderLogServiceResponse);
			logger.info("Exiting insertOrderLog() ");
			/* clear the orderLogInfoList once logs are successfully flushed */
			synchronized (orderLogInfoList) {
				orderLogInfoList.clear();
			}

		} catch (HttpStatusCodeException e) {
			logger.error("Exception received from OrderLogService : {} ",
					insertBulkTblOrderLogURL);
			logger.error(
					"Execption during insertOrderLog execution code:{} , text:{}",
					e.getStatusCode(), e.getResponseBodyAsString());
		} catch (RestClientException e) {
			logger.error("Exception received from OrderLogService : {} ",
					insertBulkTblOrderLogURL);
			logger.error("Exception received from OrderLogService : {} ", e);
		}

	}

	/**
	 * This method is responsible to flush all order error logs
	 * 
	 */

	public void flushOrderLogError() {

		logger.trace("flushOrderLogError()");

		final String insertBulkTblOrderVarErrorsURL = loggingServiceBaseURL
				.concat("/insertBulkTblEnvOrderValErrors");

		try {

			if (orderErrorLogList == null || orderErrorLogList.isEmpty()) {
				// throw new RuntimeException("Empty or Null List");
				return;
			}

			logger.info("insertOrderLogError(): No. of logs to be written :{}",
					"", orderErrorLogList.size());
			// Gson gson = new GsonBuilder().setPrettyPrinting().create();
			// String json = gson.toJson(logRequestObjList);

			// System.out.println("JSON:\n" + json);

			long startTime = System.currentTimeMillis();
			logger.info(
					"insertOrderLogError(): Making HTTP POST Request for workOrderNumber:{} at time:{}",
					"", startTime);
			logger.info("insertOrderLogError(): Service URL: {}",
					insertBulkTblOrderVarErrorsURL);
			logger.info("insertOrderLogError(): Service restTemplate: {}",
					restTemplate);

			ResponseObject orderLogServiceResponse = restTemplate
					.postForObject(insertBulkTblOrderVarErrorsURL,
							orderErrorLogList, ResponseObject.class);

			long endTime = System.currentTimeMillis();

			// System.out.println("OrderLogServiceResponse:" +
			// orderLogServiceResponse);

			logger.info(
					"insertOrderLogError(): Time taken for Response for tableName:{} is:{} ms",
					"", (endTime - startTime));
			logger.debug(
					"insertOrderLogError(): Response from OrderLogService: {}",
					orderLogServiceResponse);
			logger.info("Exiting insertOrderLogError() ");
			
			synchronized (orderErrorLogList) {
				orderErrorLogList.clear();
			}

		} catch (HttpStatusCodeException e) {
			logger.error("Exception received from OrderLogService : {} ",
					insertBulkTblOrderVarErrorsURL);
			logger.error(
					"Execption during insertOrderLogError execution code:{} , text:{}",
					e.getStatusCode(), e.getResponseBodyAsString());
		} catch (RestClientException e) {
			logger.error("Exception received from OrderLogService : {} ",
					insertBulkTblOrderVarErrorsURL);
			logger.error("Exception received from OrderLogService : {} ", e);
		}
	}

	/**
	 * this method flushes all Rsp logs
	 */
	public void flushOrderRsp() {

		logger.trace("flushOrderRsp()");

		final String insertBulkTblOrderRspURL = loggingServiceBaseURL
				.concat("/insertBulkTblOrderRsp");
		try {

			if (orderRspLogList == null || orderRspLogList.isEmpty()) {
				return;
			}
			logger.info("insertOrderRsp(): No. of logs to be written :{}",
					orderRspLogList.size());
			/*
			 * Gson gson = new GsonBuilder().setPrettyPrinting().create();
			 * String json = gson.toJson(orderRspInfoList);
			 */

			// System.out.println("JSON:\n" + json);

			long startTime = System.currentTimeMillis();
			logger.info(
					"insertOrderRsp(): Making HTTP POST Request for workOrderNumber:{} at time:{}",
					"", startTime);
			logger.info("insertOrderRsp(): Service URL: {}",
					insertBulkTblOrderRspURL);

			ResponseObject orderLogServiceResponse = restTemplate
					.postForObject(insertBulkTblOrderRspURL, orderRspLogList,
							ResponseObject.class);

			long endTime = System.currentTimeMillis();

			// //System.out.println("OrderLogServiceResponse:" +
			// orderLogServiceResponse);

			logger.info(
					"insertOrderRsp(): Time taken for Response for tableName:{} is:{} ms",
					"", (endTime - startTime));
			logger.debug("insertOrderRsp(): Response from OrderLogService: {}",
					orderLogServiceResponse);
			logger.info("Exiting insertOrderRsp() ");

			synchronized (orderRspLogList) {
				orderRspLogList.clear();
			}
		} catch (HttpStatusCodeException e) {
			logger.error("Exception received from OrderLogService : {} ",
					insertBulkTblOrderRspURL);
			logger.error(
					"Execption during insertOrderRsp execution code:{} , text:{}",
					e.getStatusCode(), e.getResponseBodyAsString());
		} catch (RestClientException e) {
			logger.error("Exception received from OrderLogService : {} ",
					insertBulkTblOrderRspURL);
			logger.error("Exception received from OrderLogService : {} ", e);
		}

	}

	/**
	 * this method flushes all task completion logs
	 */
	public void flushTaskCompletionLog() {

		logger.trace("flushTaskCompletionLog()");

		final String insertBulkTaskCompletionLogURL = loggingServiceBaseURL
				.concat("/insertBulkTblTaskCompletionLog");

		try {

			if (taskCompletionLogList == null
					|| taskCompletionLogList.isEmpty()) {
				return;
			}
			logger.info("insertOrderRsp(): No. of logs to be written :{}",
					taskCompletionLogList.size());
			/*
			 * Gson gson = new GsonBuilder().setPrettyPrinting().create();
			 * String json = gson.toJson(taskCompletionLogInfoList);
			 */

			// System.out.println("JSON:\n" + json);

			long startTime = System.currentTimeMillis();
			logger.info(
					"insertTaskCompletionLog(): Making HTTP POST Request for workOrderNumber:{} at time:{}",
					"", startTime);
			logger.info("insertTaskCompletionLog(): Service URL: {}",
					insertBulkTaskCompletionLogURL);

			ResponseObject orderLogServiceResponse = restTemplate
					.postForObject(insertBulkTaskCompletionLogURL,
							taskCompletionLogList, ResponseObject.class);

			long endTime = System.currentTimeMillis();

			// System.out.println("OrderLogServiceResponse:" +
			// orderLogServiceResponse);

			logger.info(
					"insertTaskCompletionLog(): Time taken for Response for tableName:{} is:{} ms",
					"", (endTime - startTime));
			logger.debug("insertOrderRsp(): Response from OrderLogService: {}",
					orderLogServiceResponse);
			logger.info("Exiting insertTaskCompletionLog() ");
			
			synchronized (taskCompletionLogList) {
				taskCompletionLogList.clear();
			}

		} catch (HttpStatusCodeException e) {
			logger.error("Exception received from OrderLogService : {} ",
					insertBulkTaskCompletionLogURL);
			logger.error(
					"Execption during insertOrderRsp execution code:{} , text:{}",
					e.getStatusCode(), e.getResponseBodyAsString());
		} catch (RestClientException e) {
			logger.error("Exception received from OrderLogService : {} ",
					insertBulkTaskCompletionLogURL);
			logger.error("Exception received from OrderLogService : {} ", e);
		}

	}

	/**
	 * This class is responsible to flush order log , error log and rsp log at
	 * regular interval
	 * 
	 * @author Aricent
	 * 
	 */
	class FlushLogHandler implements Runnable {

		
		public void run() {
			try {
				
				logger.info("Flushing logs..................");
				
				logger.debug("FlushLogHandler() Flushing Order logs");
				flushInsertOrderLog();
				logger.debug("FlushLogHandler() Flushing Error logs");
				flushOrderLogError();
				logger.debug("FlushLogHandler() Flushing RSP logs");
				flushOrderRsp();
				logger.debug("FlushLogHandler() Flushing TaskCompletion log");
				flushTaskCompletionLog();
			} catch (Exception e) {
				logger.error("Error while flushing logs ", e);
			}

		}

	}
}
