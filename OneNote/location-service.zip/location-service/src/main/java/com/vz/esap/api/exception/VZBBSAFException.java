/**
 * File: VZBBSAFException.java
 *
 * Author: Naveen Murthy
 *
 */
package com.vz.esap.api.exception;

public class VZBBSAFException extends Exception
{

  /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

// Constructor receives some kind of message that is saved in an instance variable.
  public VZBBSAFException(String err)
  {
    super(err);     // call super class constructor

  }

}

