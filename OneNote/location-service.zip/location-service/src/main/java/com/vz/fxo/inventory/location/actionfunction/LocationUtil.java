package com.vz.fxo.inventory.location.actionfunction;

import java.sql.Connection;

import com.vz.fxo.inventory.actionfunction.support.Location;

public class LocationUtil {
	
	private Connection connection;
	
	public Location getLocation() {
		
		return new Location(connection);
		
	}

}
