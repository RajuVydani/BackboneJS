package com.vz.fxo.inventory.actionfunction.support;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import esap.db.TblVzbPprulesTpltQuery;

public class VzbPprulesTplt extends VzbPprulesTpltBean{


	private static Logger log = LoggerFactory.getLogger(VzbPprulesTplt.class.toString());
	private InvErrorCode status = InvErrorCode.INTERNAL_ERROR;;
    Connection connection;
    boolean rollbackFlag;
    boolean migration;
	boolean shellMigration;
	
    
    public VzbPprulesTplt(Connection dbCon)
    {
    	super();
        this.connection = dbCon;
        this.rollbackFlag = false;
        this.migration = false;
		this.shellMigration = false;
    }
    
    public VzbPprulesTplt(VzbPprulesTpltBean vzbPprulesTpltBean, Connection dbCon)
    {
        super(vzbPprulesTpltBean);
        this.connection = dbCon;
		this.rollbackFlag = false;
		this.migration = false;
		this.shellMigration = false;

    }
        
    public int getStatusCode() {
		return status.getErrorCode();
	}
 
	public String getStatusDesc() {
		return status.getErrorDesc();
	}

	public void setStatus(InvErrorCode status) {
		this.status = status;
	}

	public Connection getDbCon() {
		return connection;
	}

	public void setDbCon(Connection dbCon) {
		this.connection = dbCon;
	}

	public boolean isRollbackFlag() {
		return rollbackFlag;
	}

	public void setRollbackFlag(boolean rollbackFlag) {
		this.rollbackFlag = rollbackFlag;
	}

	public boolean isMigration() {
		return migration;
	}

	public void setMigration(boolean migration) {
		this.migration = migration;
	}

	public boolean isShellMigration() {
		return shellMigration;
	}

	public void setShellMigration(boolean shellMigration) {
		this.shellMigration = shellMigration;
	}
	
	public boolean getVzbPprTpltListByCntryCdAndPltfrmInd() throws SQLException
    {
		log.info(" getVzbPprTpltListByCntryCdAndPltfrmInd getDetails method");
		VzbPprulesTpltBean vzbPprulesTpltBean = null;
		ArrayList<VzbPprulesTpltBean> vzbPprulesTpltBeanList = null;
		try{
			TblVzbPprulesTpltQuery tblVzbPprulesTpltQuery = new  TblVzbPprulesTpltQuery();
			tblVzbPprulesTpltQuery.whereCntryCodeEQ(cntryCode);
			tblVzbPprulesTpltQuery.wherePlatformIndicatorEQ(platformIndicator);
			tblVzbPprulesTpltQuery.query(connection);
			
			if ( tblVzbPprulesTpltQuery.size() > 0){
				vzbPprulesTpltBeanList = new ArrayList<VzbPprulesTpltBean>();
				for ( int i=0 ; i < tblVzbPprulesTpltQuery.size() ; i++){
					vzbPprulesTpltBean = new VzbPprulesTpltBean();
					vzbPprulesTpltBean.setCntryCode(tblVzbPprulesTpltQuery.getDbBean(i).getCntryCode());
					vzbPprulesTpltBean.setRegion(tblVzbPprulesTpltQuery.getDbBean(i).getRegion());
					vzbPprulesTpltBean.setPlatformIndicator(tblVzbPprulesTpltQuery.getDbBean(i).getPlatformIndicator());
					vzbPprulesTpltBean.setPrefixName(tblVzbPprulesTpltQuery.getDbBean(i).getPrefixName());
					vzbPprulesTpltBean.setPrefix(tblVzbPprulesTpltQuery.getDbBean(i).getPrefix());
					vzbPprulesTpltBean.setNumstrip(tblVzbPprulesTpltQuery.getDbBean(i).getNumstrip());
					vzbPprulesTpltBean.setAddPrefix(tblVzbPprulesTpltQuery.getDbBean(i).getAddPrefix());
					vzbPprulesTpltBean.setNoa(tblVzbPprulesTpltQuery.getDbBean(i).getNoa());
					vzbPprulesTpltBean.setBlkstat(tblVzbPprulesTpltQuery.getDbBean(i).getBlkstat());
					vzbPprulesTpltBean.setCreatedBy(tblVzbPprulesTpltQuery.getDbBean(i).getCreatedBy());
					vzbPprulesTpltBean.setCreationDate(tblVzbPprulesTpltQuery.getDbBean(i).getCreationDate());
					vzbPprulesTpltBean.setModifiedBy(tblVzbPprulesTpltQuery.getDbBean(i).getModifiedBy());
					vzbPprulesTpltBean.setLastModifiedDate(tblVzbPprulesTpltQuery.getDbBean(i).getLastModifiedDate());
					vzbPprulesTpltBeanList.add(vzbPprulesTpltBean);
				}
				this.setVzbPprulesTpltBeanList(vzbPprulesTpltBeanList);
			}else{
				log.info("VzbPprulesTplt - No Record Found. ");
				setStatus(InvErrorCode.NOT_FOUND_VZB_PPRULES_TPLT);
                return false;
			}
		
	    }catch(SQLException s)
	    {
	    	s.printStackTrace();
	        setStatus(InvErrorCode.DB_EXCEPTION);
	        return false;
	    }
		
		setStatus(InvErrorCode.SUCCESS);
	    log.info("Successfully retrieved CS2K from db");
		return true;
    }

}
