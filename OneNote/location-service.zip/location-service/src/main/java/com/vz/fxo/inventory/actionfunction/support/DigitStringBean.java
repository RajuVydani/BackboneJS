package com.vz.fxo.inventory.actionfunction.support;
import java.io.Serializable;
import java.util.List;
import java.util.ArrayList;
public class DigitStringBean implements Serializable 
{
	protected int digitStringId;
	protected String enterpriseId;
	protected String digitString;
	protected int callingPlanId;
	protected long iAllow;
	protected long oAllow;
	protected long fAllow;
	protected long bAllow;
    protected List<String> logTrail;
	protected long activeInd;
	protected String createdBy;
    protected String modifiedBy;
    protected java.sql.Timestamp lastModifiedDate;
    protected java.sql.Timestamp creationDate;

    	/**
   	 * Default Constructor -- Initializes all fields to default values.
   	 */
    	public DigitStringBean() {
		this.digitStringId = -1;
		this.enterpriseId = new String("NONE");
		this.digitString = new String("NONE");
		this.callingPlanId = -1;
		this.iAllow = -1;
		this.oAllow = -1;
		this.fAllow = -1;
		this.bAllow = -1;
		this.activeInd = -1;
		this.createdBy = new String("NONE");
		this.modifiedBy = new String("NONE");
		this.lastModifiedDate = null;
		this.creationDate = null;
    	this.logTrail = new ArrayList<String>();
	}
	public void clearDigitStringBean() {
		this.enterpriseId = "";
		this.digitString = "";
		this.createdBy = "";
		this.modifiedBy = "";
	}
	
	public DigitStringBean(DigitStringBean digitStringBean)
   	{
		this.digitStringId = digitStringBean.digitStringId;
        this.enterpriseId = digitStringBean.enterpriseId;
        this.digitString = digitStringBean.digitString;
        this.callingPlanId = digitStringBean.callingPlanId;
        this.iAllow = digitStringBean.iAllow;
        this.oAllow = digitStringBean.oAllow;
        this.fAllow = digitStringBean.fAllow;
        this.bAllow = digitStringBean.bAllow;
        this.activeInd = digitStringBean.activeInd;
        this.createdBy = digitStringBean.createdBy;
        this.modifiedBy = digitStringBean.modifiedBy;
        this.lastModifiedDate = digitStringBean.lastModifiedDate;
        this.creationDate = digitStringBean.creationDate;
        this.logTrail = new ArrayList<String>();
   	}
	public void setDigitStringId(int digitStringId)
    {
		this.digitStringId = digitStringId;
    }
    public int getDigitStringId()
    {
        return digitStringId;
    }

	public String getEnterpriseId() {
        return enterpriseId;
    }
    public void setEnterpriseId(String enterpriseId) {
            this.enterpriseId = enterpriseId;
    }

	public String getDigitString() {
        return digitString;
    }
    public void setDigitString(String digitString) {
            this.digitString = digitString;
    }
	public void setCallingPlanId(int callingPlanId)
    {
        this.callingPlanId = callingPlanId;
    }
    public int getCallingPlanId()
    {
        return callingPlanId;
    }
	public void setIAllow(long iAllow)
    {
        this.iAllow = iAllow;
    }
    public long getIAllow()
    {
        return iAllow;
    }
	public void setOAllow(long oAllow)
    {
        this.oAllow = oAllow;
    }
    public long getOAllow()
    {
        return oAllow;
    }
	public void setFAllow(long fAllow)
    {
        this.fAllow = fAllow;
    }
    public long getFAllow()
    {
        return fAllow;
    }
	public void setBAllow(long bAllow)
    {
        this.bAllow = bAllow;
    }
    public long getBAllow()
    {
        return bAllow;
    }
	public void setLogTrail(String logStr)
    {
        logTrail.add(logStr);
    }
    public List<String> getLogTrail()
    {
        return logTrail;
    }
	public void setLogTrail(List<String> logTrail) {
		this.logTrail = logTrail;
	}
	public long getActiveInd() {
		return activeInd;
	}
	public void setActiveInd(long activeInd) {
		this.activeInd = activeInd;
	}
	public String getModifiedBy() {
        return modifiedBy;
   	}
   	public void setModifiedBy(String modifiedBy) {
        	this.modifiedBy = modifiedBy;
   	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public java.sql.Timestamp getLastModifiedDate() {
		return lastModifiedDate;
	}
	public void setLastModifiedDate(java.sql.Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}
	public java.sql.Timestamp getCreationDate() {
		return creationDate;
	}
	public void setCreationDate(java.sql.Timestamp creationDate) {
		this.creationDate = creationDate;
	}
	
}

