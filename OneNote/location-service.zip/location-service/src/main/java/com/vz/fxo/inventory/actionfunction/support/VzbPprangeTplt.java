package com.vz.fxo.inventory.actionfunction.support;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import esap.db.TblVzbPprangeTpltQuery;

public class VzbPprangeTplt extends VzbPprangeTpltBean{

	private static Logger log = LoggerFactory.getLogger(VzbPprangeTplt.class.toString());

	private InvErrorCode status = InvErrorCode.INTERNAL_ERROR;;
    Connection connection;
    boolean rollbackFlag;
    boolean migration;
	boolean shellMigration;
	
    
    public VzbPprangeTplt(Connection dbCon)
    {
    	super();
        this.connection = dbCon;
        this.rollbackFlag = false;
        this.migration = false;
		this.shellMigration = false;
    }
    
    public VzbPprangeTplt(VzbPprangeTpltBean vzbPprangeTpltBean, Connection dbCon)
    {
        super(vzbPprangeTpltBean);
        this.connection = dbCon;
		this.rollbackFlag = false;
		this.migration = false;
		this.shellMigration = false;

    }
        
    public int getStatusCode() {
		return status.getErrorCode();
	}
 
	public String getStatusDesc() {
		return status.getErrorDesc();
	}

	public void setStatus(InvErrorCode status) {
		this.status = status;
	}

	public Connection getDbCon() {
		return connection;
	}

	public void setDbCon(Connection dbCon) {
		this.connection = dbCon;
	}

	public boolean isRollbackFlag() {
		return rollbackFlag;
	}

	public void setRollbackFlag(boolean rollbackFlag) {
		this.rollbackFlag = rollbackFlag;
	}

	public boolean isMigration() {
		return migration;
	}

	public void setMigration(boolean migration) {
		this.migration = migration;
	}

	public boolean isShellMigration() {
		return shellMigration;
	}

	public void setShellMigration(boolean shellMigration) {
		this.shellMigration = shellMigration;
	}
	
	public boolean getVzbPprTpltListByCntryCdAndPltfrmInd() throws SQLException
    {
		log.info(" getVzbPprTpltListByCntryCdAndPltfrmInd getDetails method");
		VzbPprangeTpltBean vzbPprangeTpltBean = null;
		ArrayList<VzbPprangeTpltBean> vzbPprangeTpltBeanList = null;
		try{
			TblVzbPprangeTpltQuery tblVzbPprangeTpltQuery = new  TblVzbPprangeTpltQuery();
			tblVzbPprangeTpltQuery.whereCntryCodeEQ(cntryCode);
			tblVzbPprangeTpltQuery.wherePlatformIndicatorEQ(platformIndicator);
			tblVzbPprangeTpltQuery.query(connection);
			
			if ( tblVzbPprangeTpltQuery.size() > 0){
				vzbPprangeTpltBeanList = new ArrayList<VzbPprangeTpltBean>();
				for ( int i=0 ; i < tblVzbPprangeTpltQuery.size() ; i++){
					vzbPprangeTpltBean = new VzbPprangeTpltBean();
					vzbPprangeTpltBean.setCntryCode(tblVzbPprangeTpltQuery.getDbBean(i).getCntryCode());
					vzbPprangeTpltBean.setRegion(tblVzbPprangeTpltQuery.getDbBean(i).getRegion());
					vzbPprangeTpltBean.setPlatformIndicator(tblVzbPprangeTpltQuery.getDbBean(i).getPlatformIndicator());
					vzbPprangeTpltBean.setPrefixName(tblVzbPprangeTpltQuery.getDbBean(i).getPrefixName());
					vzbPprangeTpltBean.setRangeStart(tblVzbPprangeTpltQuery.getDbBean(i).getRangeStart());
					vzbPprangeTpltBean.setRangeEnd(tblVzbPprangeTpltQuery.getDbBean(i).getRangeEnd());
					vzbPprangeTpltBean.setNumstrip(tblVzbPprangeTpltQuery.getDbBean(i).getNumstrip());
					vzbPprangeTpltBean.setAddPrefix(tblVzbPprangeTpltQuery.getDbBean(i).getAddPrefix());
					vzbPprangeTpltBean.setNoa(tblVzbPprangeTpltQuery.getDbBean(i).getNoa());
					vzbPprangeTpltBean.setBlkstat(tblVzbPprangeTpltQuery.getDbBean(i).getBlkstat());
					vzbPprangeTpltBean.setCreatedBy(tblVzbPprangeTpltQuery.getDbBean(i).getCreatedBy());
					vzbPprangeTpltBean.setCreationDate(tblVzbPprangeTpltQuery.getDbBean(i).getCreationDate());
					vzbPprangeTpltBean.setModifiedBy(tblVzbPprangeTpltQuery.getDbBean(i).getModifiedBy());
					vzbPprangeTpltBean.setLastModifiedDate(tblVzbPprangeTpltQuery.getDbBean(i).getLastModifiedDate());
					vzbPprangeTpltBeanList.add(vzbPprangeTpltBean);
				}
				this.setVzbPprangeTpltBeanList(vzbPprangeTpltBeanList);
			}else{
				log.info("VzbPprangeTplt - No Record Found. ");
				//IR #1659601 APAC add location order is failing in prod as tbl_vzb_pprange_tplt is empty in production for APAC
				//setStatus(InvErrorCode.NOT_FOUND_VZB_PPRANGE_TPLT);
                //return false;
			}
		
	    }catch(SQLException s)
	    {
	    	s.printStackTrace();
	        setStatus(InvErrorCode.DB_EXCEPTION);
	        return false;
	    }
		
		setStatus(InvErrorCode.SUCCESS);
	    log.info("Successfully retrieved CS2K from db");
		return true;
    }

}
