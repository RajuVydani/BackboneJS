/**
 * 
 */
package com.vz.esap.api.model;

/**
 * This ESAP Enum class represents all entities types available in ESAP
 * 
 * @author Deepak Kumar
 * 
 */
public enum ESAPEntityEnum {

	// Enums sorted alphabetically
	DEVICE("DEVICE"),	
	EBI("EBI"), 
	ENTERPRISE("ENTERPRISE"), 
	ENTERPRISE_TRUNK("ENTERPRISE_TRUNK"), 
	ET_EBI("ET_EBI"), 
	LOCATION("LOCATION"), 
	PBX("PBX"), 
	ET_TN("ET_TN"),
	PBX_TN("PBX_TN"),
	RES_TN("RES_TN"),
	KEY_TN("KEY_TN"),
	BA_PORTAL_TN("BA_PORTAL_TN"),
	IPAC_CONF_TN("IPAC_CONF_TN"),
	VILO_TN("VILO_TN"), TN("TN"),
	KEY("KEY");

	/*
    public static final int GUI = 0;
    public static final int ENTERPRISE = 1;
    public static final int DEPARTMENT = 2;
    public static final int LOCATION = 3;
    public static final int DEVICE = 4;
    public static final int PBX = 5;
    public static final int KEY = 6;
    public static final int PBX_TN = 7;
    public static final int KEY_TN = 8;
    public static final int SUBSCRIBER = 9;
    public static final int RES_TN = 10;
    public static final int CALLING_PLAN = 11;
    public static final int FEATURE_PKG = 12;
    public static final int VALIDATION = 13;
    public static final int DIAL_PLAN = 14;
    public static final int DEVICE_TYPE = 15;
    public static final int BSAS = 16;
    public static final int PUBLIC_ROUTING = 17;
    public static final int TERM_ROUTING = 18;
    public static final int BA_PORTAL_TN = 19;
    public static final int FMC_DIALPLAN = 20;
    public static final int FMC_DEVICE = 21;
    public static final int SBC = 22;
    public static final int SYSTEM_UPDATE = 23;
    public static final int TN = 24;
    public static final int IPAC_CUSTOMER = 25;
    public static final int IPAC_HA_PAIR = 26;
    public static final int IPAC_CONF_TN = 27;
    public static final int BSAS_MAP = 28;
    public static final int IPAC_DEVICE = 29;
    public static final int SBC_REGION_MAP = 30;
    public static final int MICRONODE = 31;
    public static final int TWSBC = 32;
    public static final int FMCGREPORT = 33;
    public static final int PREFIX_PLAN_RULE = 34;
    public static final int PREFIX_PLAN = 35;
    public static final int EMERGENCY_CODE = 36;
    public static final int CORP_SETTING = 37;
    public static final int CS2K = 38;
    public static final int SBC_CONFIG = 39;
    public static final int PIT = 40;
    public static final int SBC_LOAD_SHARING = 41;
    public static final int FRAUD_BLOCK = 42;
    public static final int ENTERPRISE_TRUNK = 43;
    public static final int VPN_SBC_INFO = 44;
    public static final int TSO_SBC = 45;
    public static final int EBI = 46;
    public static final int ET_TN = 47;
    public static final int ROUTING_GROUP = 48;
    public static final int ET_EBI = 49;
    public static final int TSOMGRNRPRT = 50;
    public static final int R2R_TRANSITION = 51;
    public static final int IPTERM = 52;
    public static final int VILO_TN = 53;
    public static final int IPCC_SBC = 54;
    public static final int IPSEC = 55;
    public static final int VRDMGRNRPRT = 56;
    public static final int ET_GROUP = 57;
	*/
    
	String entityType;

	ESAPEntityEnum(String entity) {
		this.entityType = entity;
	}
}
