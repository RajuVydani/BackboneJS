package com.vz.esap.api.exception;

public class ApplicationInterfaceException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7894284007591953781L;

	

	public ApplicationInterfaceException(String errorMessage) {
		super(errorMessage);
	}

}
