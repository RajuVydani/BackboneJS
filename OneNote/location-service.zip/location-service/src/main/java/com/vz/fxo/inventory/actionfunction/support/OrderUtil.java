package com.vz.fxo.inventory.actionfunction.support;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;

import org.owasp.esapi.ESAPI;
import org.owasp.esapi.codecs.Codec;
import org.owasp.esapi.codecs.OracleCodec;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.vz.esap.api.connector.service.impl.OrderDomainDataServiceImpl;
import com.vz.esap.api.model.DBServiceResponse;

import esap.db.TblEnvOrderQuery;

public class OrderUtil {
	
	private static Logger log = LoggerFactory.getLogger(OrderUtil.class.toString());
	
	static final Codec ORACLE_CODEC = new OracleCodec();
	
	public static void updTblLocationWithCnamPending(Connection dbcon,
			String locationId, int cnamFlag) {

		log.info("In updTblLocationWithCnamPending");
		StringBuffer sql = new StringBuffer();
		sql.append("update tbl_location set cnam_update_status = ?, ");
		sql.append("cnam_update_Date= ? ");
		sql.append("where location_id = ?");

		log.info("upd sql query :" , sql.toString());

		PreparedStatement pStmt = null;
		try {
			pStmt = dbcon.prepareStatement(sql.toString());
			pStmt.setInt(1, cnamFlag);
			pStmt.setTimestamp(2,
					new java.sql.Timestamp(System.currentTimeMillis()));
			pStmt.setString(3, locationId);

			int updated = pStmt.executeUpdate();
			log.info("In updTblLocationWithCnamPending:" + updated
					+ " rows updated.");
		} catch (SQLException e) {
			log.error("Exception during updTblLocationWithCnamPending",e.getMessage());
		} finally {
			try {
				if (null != pStmt) {
					pStmt.close();
				}
			} catch (Exception e) {
				log.error("Exception in closing DB connection updTblLocationWithCnamPending",e.getMessage());;
			}
		}

		return;
	}
	
	public String getEntIdOfCNAM(Connection dbcon, String locationId) {

		log.info("Enter OrderUtil::getEntIdOfCNAM with orderNo ==> "
				+ locationId);
		Statement st = null;
		ResultSet rs = null;
		String enterpriseId = null;
		try {
			st = dbcon.createStatement();
			String sql = "select enterprise_id from tbl_location where location_id= '"
					+ ESAPI.encoder().encodeForSQL(ORACLE_CODEC, locationId)
					+ "'";
			rs = st.executeQuery(sql);
			while (rs.next()) {
				enterpriseId = rs.getString("enterprise_id");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (st != null)
					st.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		log.info("Exit OrderUtil::getEntIdOfCNAM returning enterpriseId ==> {}"
				, enterpriseId);
		return enterpriseId;
	}
	
	public HashMap<String, String> getSensitivityLvl(Connection dbcon,
			String enterpriseId) {

		log.info("Enter OrderUtil::getSensitivityLvl with enterpriseId ==> {}"
				, enterpriseId);
		HashMap<String, String> sensLvl = new HashMap<String, String>();
		Statement st = null;
		ResultSet rs = null;
		try {
			st = dbcon.createStatement();
			String sql = "select e2ei_sensitivity_level,cust_sensitivity_level from tbl_customer where customer_id= '"
					+ ESAPI.encoder().encodeForSQL(ORACLE_CODEC, enterpriseId)
					+ "'";
			log.info("Enter OrderUtil::getSensitivityLvl SQL is ==>{}" , sql);
			rs = st.executeQuery(sql);
			while (rs.next()) {
				sensLvl.put(rs.getString("e2ei_sensitivity_level"),
						rs.getString("cust_sensitivity_level"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (st != null)
					st.close();
			} catch (SQLException e) {
				log.error("Exception during getSensitivityLvl",e.getMessage());
			}
		}
		log.info("Exit OrderUtil::getSensitivityLvl returning sensLvl ==> {}"
				, sensLvl);
		return sensLvl;
	}
	
	public long insertIntoEnvOrderRespForCNAM(OrderDomainDataServiceImpl orderDomainDataServiceImpl,
			String orderNumber, String xmlResponse, String respErrorCode, long env_order_id, long sequence_no)
			throws Exception {

		final java.sql.Timestamp resp_date = new java.sql.Timestamp(
				System.currentTimeMillis());

		long tbl_env_order_resp_id = orderDomainDataServiceImpl.getTblEnvOrderRespIdSeqNextVal(); 
		
		orderDomainDataServiceImpl.insertIntoEnvOrderResp(env_order_id, sequence_no, tbl_env_order_resp_id, resp_date, xmlResponse, "ESP_SUCCESS", "LOCAL_SYS_UPDATE");

		return tbl_env_order_resp_id;
	}
}
