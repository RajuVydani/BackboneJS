package com.vz.fxo.inventory.actionfunction.support;

import java.sql.Date;

public class IpSecTemplateBean {

	public IpSecTemplateBean(){}
	
	public String ikeIp;
	public String custName;
	public String deviceName;
	public String ebiName;
	public String city;
	public String state;
	public String requestBy;
	public Date requestInstallDate;
	public String status;
    public int ipsecTunnelId; 
	public String hostSubIP;
	public int hostSubMask;
	public String preSharedKey;
	public String proResource;
	public int ipsecReqId;
	public short requestType;
	public String orderNumber;
	public long envOrdId; 
	public String extranetDevice;
	public String comments;
	public long ipsecProvReqId;
	
	
	public String getIkeIp() {
		return ikeIp;
	}
	public void setIkeIp(String ikeIp) {
		this.ikeIp = ikeIp;
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public String getDeviceName() {
		return deviceName;
	}
	public void setDeviceName(String deviceName) {
		this.deviceName = deviceName;
	}
	public String getEbiName() {
		return ebiName;
	}
	public void setEbiName(String ebiName) {
		this.ebiName = ebiName;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getRequestBy() {
		return requestBy;
	}
	public void setRequestBy(String requestBy) {
		this.requestBy = requestBy;
	}
	public Date getRequestInstallDate() {
		return requestInstallDate;
	}
	public void setRequestInstallDate(Date requestInstallDate) {
		this.requestInstallDate = requestInstallDate;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
   public int getIpsecTunnelId() {
		return ipsecTunnelId;
	}
	public void setIpsecTunnelId(int ipsecTunnelId) {
		this.ipsecTunnelId = ipsecTunnelId;
	}
	public String getHostSubIP() {
		return hostSubIP;
	}
	public void setHostSubIP(String hostSubIP) {
		this.hostSubIP = hostSubIP;
	}
	public int getHostSubMask() {
		return hostSubMask;
	}
	public void setHostSubMask(int hostSubMask) {
		this.hostSubMask = hostSubMask;
	}
	public String getPreSharedKey() {
		return preSharedKey;
	}
	public void setPreSharedKey(String preSharedKey) {
		this.preSharedKey = preSharedKey;
	}
	public String getProResource() {
		return proResource;
	}
	public void setProResource(String proResource) {
		this.proResource = proResource;
	}
	public int getIpsecReqId() {
		return ipsecReqId;
	}
	public void setIpsecReqId(int ipsecReqId) {
		this.ipsecReqId = ipsecReqId;
	}
	public short getRequestType() {
		return requestType;
	}
	public void setRequestType(short requestType) {
		this.requestType = requestType;
	}
	public String getOrderNumber() {
		return orderNumber;
	}
	public void setOrderNumber(String orderNumber) {
		this.orderNumber = orderNumber;
	}
	public long getEnvOrdId() {
		return envOrdId;
	}
	public void setEnvOrdId(long envOrdId) {
		this.envOrdId = envOrdId;
	}
	public String getExtranetDevice() {
		return extranetDevice;
	}
	public void setExtranetDevice(String extranetDevice) {
		this.extranetDevice = extranetDevice;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	public long getIpsecProvReqId() {
		return ipsecProvReqId;
	}
	public void setIpsecProvReqId(long ipsecProvReqId) {
		this.ipsecProvReqId = ipsecProvReqId;
	}
	
}
