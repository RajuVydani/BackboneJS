package com.vz.fxo.inventory.actionfunction.support;

//import esap.db.DBTblVzbCallingPlan;
import java.util.ArrayList;
import java.util.List;

public class CallingPlanBean
{
        protected int callingPlanId;
        protected String callingPlanName;
        protected long defaultInd;
        protected long iIntraLocation=-1;
        protected long iInterLocation=-1;
        protected long iCollectCalls=-1;
        protected long oIntraLocation=-1;
        protected long oLocal=-1;
        protected long oTollFree=-1;
        protected long oToll=-1;
        protected long oInternational=-1;
        protected long oCasual=-1;
        protected long oOperatorAssisted=-1;
        protected long oChargedDirAssist=-1;
        protected long oSplServices1=-1;
        protected long oSplServices2=-1;
        protected long oPrmServices1=-1;
        protected long oPrmServices2=-1;
        protected long oUrlDialing=-1;
        protected long oUnknown=-1;
        protected long fIntraLocation=-1;
        protected long fLocal=-1;
        protected long fTollFree=-1;
        protected long fToll=-1;
        protected long fInternational=-1;
        protected long fCasual=-1;
        protected long fOperatorAssisted=-1;
        protected long fChargedDirAssist=-1;
        protected long fSplServices1=-1;
        protected long fSplServices2=-1;
        protected long fPrmServices1=-1;
        protected long fPrmServices2=-1;
        protected long fUrlDialing=-1;
        protected long fUnknown=-1;
        protected long bInterLocation=-1;
        protected String telephone1="NONE";
        protected String telephone2="NONE";
        protected String telephone3="NONE";
        protected long envOrderId; 
        protected String createdBy;
        protected String modifiedBy;
        protected java.sql.Timestamp creationDate;
        protected java.sql.Timestamp lastModifiedDate;
	protected List<String> logTrail;
	protected List<DigitStringBean> digitStringList;

	public CallingPlanBean()
	{
		this.logTrail = new ArrayList<String>();
		this.digitStringList = new ArrayList<DigitStringBean>();
		callingPlanName = new String("");
		defaultInd = -1;
		telephone1 = new String("");
		telephone2 = new String("");
		telephone3 = new String("");
                envOrderId = 0;	
		createdBy = new String("");
		modifiedBy = new String("");
		this.creationDate = null;
        	this.lastModifiedDate = null;
	}

	public CallingPlanBean(CallingPlanBean cpBean)
	{
		this.callingPlanId=cpBean.callingPlanId;
		this.callingPlanName=cpBean.callingPlanName;
		this.defaultInd=cpBean.defaultInd;
		this.iIntraLocation=cpBean.iIntraLocation;
		this.iInterLocation=cpBean.iInterLocation;
		this.iCollectCalls=cpBean.iCollectCalls;
		this.oIntraLocation=cpBean.oIntraLocation;
		this.oLocal=cpBean.oLocal;
		this.oTollFree=cpBean.oTollFree;
		this.oToll=cpBean.oToll;
		this.oInternational=cpBean.oInternational;
		this.oCasual=cpBean.oCasual;
		this.oOperatorAssisted=cpBean.oOperatorAssisted;
		this.oChargedDirAssist=cpBean.oChargedDirAssist;
		this.oSplServices1=cpBean.oSplServices1;
		this.oSplServices2=cpBean.oSplServices2;
		this.oPrmServices1=cpBean.oPrmServices1;
		this.oPrmServices2=cpBean.oPrmServices2;
		this.oUrlDialing=cpBean.oUrlDialing;
		this.oUnknown=cpBean.oUnknown;
		this.fIntraLocation=cpBean.fIntraLocation;
		this.fLocal=cpBean.fLocal;
		this.fTollFree=cpBean.fTollFree;
		this.fToll=cpBean.fToll;
		this.fInternational=cpBean.fInternational;
		this.fCasual=cpBean.fCasual;
		this.fOperatorAssisted=cpBean.fOperatorAssisted;
		this.fChargedDirAssist=cpBean.fChargedDirAssist;
		this.fSplServices1=cpBean.fSplServices1;
		this.fSplServices2=cpBean.fSplServices2;
		this.fPrmServices1=cpBean.fPrmServices1;
		this.fPrmServices2=cpBean.fPrmServices2;
		this.fUrlDialing=cpBean.fUrlDialing;
		this.fUnknown=cpBean.fUnknown;
		this.bInterLocation=cpBean.bInterLocation;
		this.telephone1=cpBean.telephone1;
		this.telephone2=cpBean.telephone2;
		this.telephone3=cpBean.telephone3;
                this.envOrderId = cpBean.envOrderId;	
         	this.createdBy=cpBean.createdBy;
		this.modifiedBy=cpBean.modifiedBy;
		this.lastModifiedDate=cpBean.lastModifiedDate;
		this.digitStringList = cpBean.digitStringList;
		this.logTrail = cpBean.logTrail;
		this.creationDate = cpBean.creationDate;
	}

	public int getCallingPlanId() {
		return callingPlanId;
	}

	public void setCallingPlanId(int callingPlanId) {
		this.callingPlanId = callingPlanId;
	}

	public String getCallingPlanName() {
		return callingPlanName;
	}

	public void setCallingPlanName(String callingPlanName) {
		this.callingPlanName = callingPlanName;
	}

	public long getDefaultInd() {
		return defaultInd;
	}

	public void setDefaultInd(long defaultInd) {
		this.defaultInd = defaultInd;
	}

	public long getIIntraLocation() {
		return iIntraLocation;
	}

	public void setIIntraLocation(long intraLocation) {
		iIntraLocation = intraLocation;
	}

	public long getIInterLocation() {
		return iInterLocation;
	}

	public void setIInterLocation(long interLocation) {
		iInterLocation = interLocation;
	}

	public long getICollectCalls() {
		return iCollectCalls;
	}

	public void setICollectCalls(long collectCalls) {
		iCollectCalls = collectCalls;
	}

	public long getOIntraLocation() {
		return oIntraLocation;
	}

	public void setOIntraLocation(long intraLocation) {
		oIntraLocation = intraLocation;
	}

	public long getOLocal() {
		return oLocal;
	}

	public void setOLocal(long local) {
		oLocal = local;
	}

	public long getOTollFree() {
		return oTollFree;
	}

	public void setOTollFree(long tollFree) {
		oTollFree = tollFree;
	}

	public long getOToll() {
		return oToll;
	}

	public void setOToll(long toll) {
		oToll = toll;
	}

	public long getOInternational() {
		return oInternational;
	}

	public void setOInternational(long international) {
		oInternational = international;
	}

	public long getOCasual() {
		return oCasual;
	}

	public void setOCasual(long casual) {
		oCasual = casual;
	}

	public long getOOperatorAssisted() {
		return oOperatorAssisted;
	}

	public void setOOperatorAssisted(long operatorAssisted) {
		oOperatorAssisted = operatorAssisted;
	}

	public long getOChargedDirAssist() {
		return oChargedDirAssist;
	}

	public void setOChargedDirAssist(long chargedDirAssist) {
		oChargedDirAssist = chargedDirAssist;
	}

	public long getOSplServices1() {
		return oSplServices1;
	}

	public void setOSplServices1(long splServices1) {
		oSplServices1 = splServices1;
	}

	public long getOSplServices2() {
		return oSplServices2;
	}

	public void setOSplServices2(long splServices2) {
		oSplServices2 = splServices2;
	}

	public long getOPrmServices1() {
		return oPrmServices1;
	}

	public void setOPrmServices1(long prmServices1) {
		oPrmServices1 = prmServices1;
	}

	public long getOPrmServices2() {
		return oPrmServices2;
	}

	public void setOPrmServices2(long prmServices2) {
		oPrmServices2 = prmServices2;
	}

	public long getOUrlDialing() {
		return oUrlDialing;
	}

	public void setOUrlDialing(long urlDialing) {
		oUrlDialing = urlDialing;
	}

	public long getOUnknown() {
		return oUnknown;
	}

	public void setOUnknown(long unknown) {
		oUnknown = unknown;
	}

	public long getFIntraLocation() {
		return fIntraLocation;
	}

	public void setFIntraLocation(long intraLocation) {
		fIntraLocation = intraLocation;
	}

	public long getFLocal() {
		return fLocal;
	}

	public void setFLocal(long local) {
		fLocal = local;
	}

	public long getFTollFree() {
		return fTollFree;
	}

	public void setFTollFree(long tollFree) {
		fTollFree = tollFree;
	}

	public long getFToll() {
		return fToll;
	}

	public void setFToll(long toll) {
		fToll = toll;
	}

	public long getFInternational() {
		return fInternational;
	}

	public void setFInternational(long international) {
		fInternational = international;
	}

	public long getFCasual() {
		return fCasual;
	}

	public void setFCasual(long casual) {
		fCasual = casual;
	}

	public long getFOperatorAssisted() {
		return fOperatorAssisted;
	}

	public void setFOperatorAssisted(long operatorAssisted) {
		fOperatorAssisted = operatorAssisted;
	}

	public long getFChargedDirAssist() {
		return fChargedDirAssist;
	}

	public void setFChargedDirAssist(long chargedDirAssist) {
		fChargedDirAssist = chargedDirAssist;
	}

	public long getFSplServices1() {
		return fSplServices1;
	}

	public void setFSplServices1(long splServices1) {
		fSplServices1 = splServices1;
	}

	public long getFSplServices2() {
		return fSplServices2;
	}

	public void setFSplServices2(long splServices2) {
		fSplServices2 = splServices2;
	}

	public long getFPrmServices1() {
		return fPrmServices1;
	}

	public void setFPrmServices1(long prmServices1) {
		fPrmServices1 = prmServices1;
	}

	public long getFPrmServices2() {
		return fPrmServices2;
	}

	public void setFPrmServices2(long prmServices2) {
		fPrmServices2 = prmServices2;
	}

	public long getFUrlDialing() {
		return fUrlDialing;
	}

	public void setFUrlDialing(long urlDialing) {
		fUrlDialing = urlDialing;
	}

	public long getFUnknown() {
		return fUnknown;
	}

	public void setFUnknown(long unknown) {
		fUnknown = unknown;
	}

	public long getBInterLocation() {
		return bInterLocation;
	}

	public void setBInterLocation(long interLocation) {
		bInterLocation = interLocation;
	}

	public String getTelephone1() {
		return telephone1;
	}

	public void setTelephone1(String telephone1) {
		this.telephone1 = telephone1;
	}

	public String getTelephone2() {
		return telephone2;
	}

	public void setTelephone2(String telephone2) {
		this.telephone2 = telephone2;
	}

	public String getTelephone3() {
		return telephone3;
	}

	public void setTelephone3(String telephone3) {
		this.telephone3 = telephone3;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public java.sql.Timestamp getLastModifiedDate() {
		return lastModifiedDate;
	}

	public void setLastModifiedDate(java.sql.Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}
	public java.sql.Timestamp getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(java.sql.Timestamp creationDate) {
		this.creationDate = creationDate;
	}
	
	public void setLogTrail(String logStr) {
		logTrail.add(logStr);
	}

	public List<String> getLogTrail() {
		return logTrail;
	}

	public void setDigitStringList(DigitStringBean digitStringBean) {
        digitStringList.add(digitStringBean);
    }
	public void setDigitStringList(List<DigitStringBean> digitStringList) {
        this.digitStringList  = digitStringList;
    }

                                                                                                                             
    public List<DigitStringBean> getDigitStringList() {
        return digitStringList;
    }

        public long getEnvOrderId() {
		return envOrderId;
	}
	public void setEnvOrderId(long envOrderId) {
		this.envOrderId = envOrderId;
	}  
}
