package com.vz.fxo.inventory.actionfunction.support;

import EsapEnumPkg.TaskExitEnum;

public class InventoryConstants {
	public static final int INV_SUCCESS = 1;
	public static final int INV_FAILURE = 2;
	public static final int LOG_TYPE_FAIL = 2;
	public static final int LOG_TYPE_SUCCESS = 7;
	public static final int LOG_TYPE_INFO = 1;
	
	public final static int SUCCESS = TaskExitEnum.ErrorType.SUCCEED;
	public final static int FAILURE = TaskExitEnum.ErrorType.FAIL;
}
