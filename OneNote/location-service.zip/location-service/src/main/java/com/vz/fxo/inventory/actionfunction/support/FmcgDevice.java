/*
 * 
 */
package com.vz.fxo.inventory.actionfunction.support;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Timestamp;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import esap.db.DBTblFmcgDevice;
import esap.db.DBTblFmcgDeviceVendorMap;
import esap.db.TblFmcgDeviceDbBean;
import esap.db.TblFmcgDeviceQuery;

/**
 * @author Vijaykumar Sriperambuduri(v034934)
 * 
 */
public class FmcgDevice extends FmcgDeviceBean
{

	private static Logger log = LoggerFactory.getLogger(PublicTnPool.class.toString());
    private Connection connection;

    InvErrorCode status = InvErrorCode.INTERNAL_ERROR;

    public FmcgDevice(Connection con)
    {
        this.connection = con;
    }

    //getters - setters

    public Connection getConnection()
    {
        return connection;
    }

    public void setConnection(Connection connection)
    {
        this.connection = connection;
    }

    public int getStatusCode()
    {
        return status.getErrorCode();
    }

    public void setStatus(InvErrorCode status)
    {
        this.status = status;
    }

    public String getStatusDesc()
    {
        return status.getErrorDesc();
    }

    public boolean validateSbc()
    {
        return true;
    }

    public FmcgDevice(Connection con, FmcgDeviceBean fmcgDeviceBean)
    {
        super(fmcgDeviceBean);
        this.connection = con;
    }

    public boolean addFmcgDevice() throws SQLException, Exception

    {
        log.info("Entering FmcgDevice::addFmcgDevice");
        int fmcgDeviceSeqId;
//        try
 //       {
            DBTblFmcgDevice fmcgDeviceDb = new DBTblFmcgDevice();
            if (getFmcgDeviceId() > 0)
            {
                fmcgDeviceSeqId = getFmcgDeviceId();
                fmcgDeviceDb.setFmcgDeviceId(fmcgDeviceSeqId);
            } else
            {
                fmcgDeviceSeqId = fmcgDeviceDb.getFmcgDeviceIdSeqNextVal(connection);
                fmcgDeviceDb.setFmcgDeviceId(fmcgDeviceSeqId);
            }
            fmcgDeviceDb.setBrand(getBrand());
            fmcgDeviceDb.setFmcgType(getFmcgType());
            fmcgDeviceDb.setModel(getModel());
            fmcgDeviceDb.setBesSupport(getBesSupport());

            if (!getCreatedBy().equals(""))
                fmcgDeviceDb.setCreatedBy(getCreatedBy());
            else
                fmcgDeviceDb.setCreatedBy("ESAP_INV");

            if (!getModifiedBy().equals(""))
                fmcgDeviceDb.setModifiedBy(getModifiedBy());
            else
                fmcgDeviceDb.setModifiedBy("ESAP_INV");

            fmcgDeviceDb.setLastModifiedDate(new Timestamp(System.currentTimeMillis()));
            fmcgDeviceDb.setCreationDate(new Timestamp(System.currentTimeMillis()));
            fmcgDeviceDb.insert(connection);

            boolean flag = addFmcgDeviceVendorMap(fmcgDeviceSeqId);

            if (!flag)
            {
                connection.rollback();
                return false;
            }
  /*      }
        catch (SQLException s)
        {
            s.printStackTrace();
            setStatus(InvErrorCode.DB_EXCEPTION);
            return false;

        }*/
        setStatus(InvErrorCode.SUCCESS);
        return true;
    }

    public boolean getFmcgDeviceDetailsById()
    {
        log.info("Entering FmcgDevice::getFmcgDeviceDetailsById");
        try
        {
            TblFmcgDeviceQuery fmcgDeviceQry = new TblFmcgDeviceQuery();
            log.info("Querying Fmcg Device Details for id: " + getFmcgDeviceId());
            fmcgDeviceQry.whereFmcgDeviceIdEQ(getFmcgDeviceId());
			fmcgDeviceQry.query(connection);
            if (fmcgDeviceQry.size() <= 0)
            {
                log.info("Failed to Retrieve FmcfDevice");
                return false;
            }
            TblFmcgDeviceDbBean fmcgDeviceBean = fmcgDeviceQry.getDbBean(0);
            setBrand(fmcgDeviceBean.getBrand());
            setModel(fmcgDeviceBean.getModel());
            setBesSupport(fmcgDeviceBean.getBesSupport());
            setFmcgType(fmcgDeviceBean.getFmcgType());
            setCreatedBy(fmcgDeviceBean.getCreatedBy());
            setModifiedBy(fmcgDeviceBean.getModifiedBy());
            setCreationDate(fmcgDeviceBean.getCreationDate());
            setLastModifiedDate(fmcgDeviceBean.getLastModifiedDate());
        }
        catch (Exception e)
        {
            e.printStackTrace();
            setStatus(InvErrorCode.DB_EXCEPTION);
            return false;
        }
        setStatus(InvErrorCode.SUCCESS);
        return true;
    }

    public boolean deleteFmcgDevice() throws SQLException, Exception
    {
       // try
        //{
            if (getFmcgDeviceId() <= 0)
            {
                setStatus(InvErrorCode.INVALID_INPUT);
                return false;
            }
            deleteFmcgDeviceVendorMap();
            DBTblFmcgDevice fmcgDeviceDb = new DBTblFmcgDevice();
            fmcgDeviceDb.whereFmcgDeviceIdEQ(fmcgDeviceId);
            fmcgDeviceDb.deleteByWhere(connection);
            setStatus(InvErrorCode.DB_EXCEPTION);
            log.info("DB_FAILURE in deleteFmcgDevice");
        /*}
        catch (SQLException s)
        {
            setStatus(InvErrorCode.DB_EXCEPTION);
            log.info("DB_FAILURE in deleteFmcgDevice");
            s.printStackTrace();
            return false;
        }*/
        setStatus(InvErrorCode.SUCCESS);
        //setStatusDesc("Successfully DELETED Location into the DB");
        return true;
    }

    public boolean updateFmcgDevice()  throws SQLException, Exception
    {
       // try
        //{
            if (fmcgDeviceId < 0)
            {
                setStatus(InvErrorCode.INTERNAL_ERROR);
                log.info("FAILURE in updateFmcgDevice fmcgDeviceId missing.");
                return false;
            }
            DBTblFmcgDevice fmcgDeviceDb = getFmcgDeviceInfoToUpdate();
            fmcgDeviceDb.whereFmcgDeviceIdEQ(getFmcgDeviceId());
            if (fmcgDeviceDb.updateSpByWhere(connection) <= 0)
                return false;
        /*}
        catch (SQLException s)
        {
            setStatus(InvErrorCode.DB_EXCEPTION);
            log.info("DB_FAILURE in updateFmcgDevice FmcgDevice");
            s.printStackTrace();
            return false;
        }*/
        setStatus(InvErrorCode.SUCCESS);
        return true;
    }

    private DBTblFmcgDevice getFmcgDeviceInfoToUpdate()
    {
        DBTblFmcgDevice fmcgDeviceDb = new DBTblFmcgDevice();
        FmcgDeviceBean defFmcgDeviceBean = new FmcgDeviceBean();
        FmcgDevice inputFmcgDevice = this;
        fmcgDeviceDb.setFmcgDeviceId(fmcgDeviceId);

        if (inputFmcgDevice.getBrand() != null && !inputFmcgDevice.getBrand().equals(defFmcgDeviceBean.getBrand()))
        {
            fmcgDeviceDb.setBrand(inputFmcgDevice.getBrand());
        }
        if (inputFmcgDevice.getFmcgType() != defFmcgDeviceBean.getFmcgType())
        {
            fmcgDeviceDb.setFmcgType(inputFmcgDevice.getFmcgType());
        }
        if (inputFmcgDevice.getModel() != null && !inputFmcgDevice.getModel().equals(defFmcgDeviceBean.getModel()))
        {
            fmcgDeviceDb.setModel(inputFmcgDevice.getModel());
        }
        if (inputFmcgDevice.getBesSupport() != null && !inputFmcgDevice.getBesSupport().equalsIgnoreCase(defFmcgDeviceBean.getBesSupport()))
        {
            fmcgDeviceDb.setBesSupport(inputFmcgDevice.getBesSupport());
        }
        if (inputFmcgDevice.getCreatedBy() != null && !("".equalsIgnoreCase(inputFmcgDevice.getCreatedBy())))
            fmcgDeviceDb.setCreatedBy(getCreatedBy());
        else
            fmcgDeviceDb.setCreatedBy("ESAP_INV");

        if (inputFmcgDevice.getModifiedBy() != null && !("".equalsIgnoreCase(inputFmcgDevice.getModifiedBy())))
            fmcgDeviceDb.setModifiedBy(getModifiedBy());
        else
            fmcgDeviceDb.setModifiedBy("ESAP_INV");

        fmcgDeviceDb.setLastModifiedDate(new Timestamp(System.currentTimeMillis()));

        return fmcgDeviceDb;

    }

    /**
     * This method is for deleting record from FmcgDeviceVendorMap
     * 
     * @return
     */
    public boolean deleteFmcgDeviceVendorMap() throws SQLException, Exception
    {
        //try
        //{
            if (getFmcgDeviceId() <= 0)
            {
                setStatus(InvErrorCode.INVALID_INPUT);
                return false;
            }
            DBTblFmcgDeviceVendorMap fmcgDeviceVendorMapDb = new DBTblFmcgDeviceVendorMap();
            fmcgDeviceVendorMapDb.whereFmcgDeviceIdEQ(fmcgDeviceId);
            fmcgDeviceVendorMapDb.deleteByWhere(connection);
        /*}
        catch (SQLException s)
        {
            setStatus(InvErrorCode.DB_EXCEPTION);
            log.info("DB_FAILURE in deleteFmcgDeviceVendorMap");
            throw s;
        }*/
        setStatus(InvErrorCode.SUCCESS);
        log.info("Successfully DELETED Fmcg Device Vendor Map from the DB");
        return true;
    }

    /**
     * This method is for adding record into FmcgDeviceVendorMap
     * 
     * @return
     */
    public boolean addFmcgDeviceVendorMap(int fmcgDeviceSeqId)
    {
        log.info("Entering FmcgDevice::FmcgDeviceVendorMap");

        try
        {
            DBTblFmcgDeviceVendorMap fmcgDeviceVendorMapDb = new DBTblFmcgDeviceVendorMap();
            fmcgDeviceVendorMapDb.setFmcgDeviceId(fmcgDeviceSeqId);
            fmcgDeviceVendorMapDb.setFmcgVendorId(getFmcgVendorId());
            fmcgDeviceVendorMapDb.insert(connection);

        }
        catch (SQLException s)
        {
            s.printStackTrace();
            log.info("DB_FAILURE in addFmcgDeviceVendorMap");
            setStatus(InvErrorCode.DB_EXCEPTION);
            return false;
        }
        setStatus(InvErrorCode.SUCCESS);
        return true;
    }
    

    public boolean modifyFmcgDeviceVendorMap() throws SQLException, Exception
    {
        //try
        //{
            if (fmcgDeviceId < 0)
            {
                setStatus(InvErrorCode.INTERNAL_ERROR);
                log.info("FAILURE in updateFmcgDevice fmcgDeviceId missing.");
                return false;
            }
            
            DBTblFmcgDeviceVendorMap fmcgDeviceVendorMapDb = new DBTblFmcgDeviceVendorMap();
            fmcgDeviceVendorMapDb.setFmcgVendorId(getFmcgVendorId());
            fmcgDeviceVendorMapDb.whereFmcgDeviceIdEQ(fmcgDeviceId);
            if (fmcgDeviceVendorMapDb.updateSpByWhere(connection) <= 0)
                return false;
        /*}
        catch (SQLException s)
        {
            setStatus(InvErrorCode.DB_EXCEPTION);
            log.info("DB_FAILURE in modifyFmcgDeviceVendorMap FmcgDeviceVendorMap");
            s.printStackTrace();
            return false;
        }*/
        setStatus(InvErrorCode.SUCCESS);
        return true;
    }
    
    
}
