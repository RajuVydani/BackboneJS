package com.vz.fxo.inventory.actionfunction.support;
import EsapEnumPkg.VzbVoipEnum;
import esap.db.IpcomDeviceXrefDbBean;
import esap.db.IpcomGatewayInfoDbBean;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

public class GatewayDeviceBean
{
	
	//members
	protected long gatewayDeviceId;
	protected String deviceName;
	protected long deviceTypeId;
	protected DeviceTypeBean deviceTypeBean;
	protected String gatewayAddress;
	protected String gatewaySecAddress;
	protected long callingPartyFormat;
	protected long portsAssigned;
	protected long termCallingInd;
	protected long sbcId;
	protected long secSbcId;
	protected SbcBean sbcBean;
	protected long brixInd;
    protected long envOrderId;
	protected String modifiedBy;
	protected String createdBy;
	protected java.sql.Timestamp creationDate;
	protected java.sql.Timestamp lastModifiedDate;
	protected long deviceCarrInd;
	protected long transport;
	protected long stripCcInd;
	protected long deviceCharId;
	protected List<String> logTrail;
    protected String gatewayHunt;
    protected long iasaGatewayDeviceId;
    protected long deviceRealTypeId;
    protected long sbcProvmethod;
	protected long sbcMigInd;//YesNoType
	protected String fqdn;
	protected String customerId;
	protected String locationId;
	protected long sTnPoolId;
	protected String sTn; //screened TN from the order
	protected String sTnLinePort;
	protected short internalAdmin;
	//SBC Capacity Allocation code
	protected long aggregateOffnetCcl;	
	protected BigDecimal signalingTierLookupValue;
	protected long tierOverrideFlag;
	protected short ipVersion;
	protected long pqInstanceId;
	protected short tsoMigLock;
	protected long ipsecTunnelId;
	protected String updateComment;
	/**
	 * Default Constructor -- Initializes all fields to default values.
	 */
	public GatewayDeviceBean() {
		
		this.gatewayDeviceId = 0;
		this.deviceName = new String("");
		this.deviceTypeId = 0;
		this.deviceTypeBean = new DeviceTypeBean();// Pls Verify
		//this.sbcBean = new SbcBean();// Pls Verify
		this.gatewayAddress = new String("NONE");
		this.gatewaySecAddress = new String("NONE");
		this.fqdn = new String("NONE");

		this.portsAssigned = -1;
		this.callingPartyFormat = -1;
		this.termCallingInd = 0;
		this.sbcId = -1;
		this.secSbcId = -1;
		this.brixInd = 0;
		this.sbcProvmethod = -1;
		this.sbcMigInd = 0;
                this.envOrderId = 0;
		this.modifiedBy = new String("");
		this.createdBy = new String("");
		this.creationDate = null;
		this.lastModifiedDate = null;
		this.deviceCarrInd = 0;
		this.transport = 0;
		this.stripCcInd = 0;
		this.deviceCharId =-1;
		this.logTrail = null;
		logTrail = new ArrayList<String>();
        this.gatewayHunt = null;
        this.deviceRealTypeId = 0;
        this.sTn = new String("NONE");
        this.sTnPoolId = 0;
        this.sTnLinePort = "NONE";
        this.internalAdmin = -1;
        this.aggregateOffnetCcl = -1;
        this.signalingTierLookupValue = new BigDecimal(0.0);
        this.tierOverrideFlag = -1;    
        this.ipVersion = 1;
        this.pqInstanceId = -1;
		this.tsoMigLock = -1;
		this.ipsecTunnelId = 0;
		this.updateComment = null;
	}
	/**
	 * Constructor
	 * @param gwDevBean
	 */
	public GatewayDeviceBean(GatewayDeviceBean gwDevBean)
	{
		this.gatewayDeviceId = gwDevBean.gatewayDeviceId;
		this.deviceName = gwDevBean.deviceName;
		this.deviceTypeId = gwDevBean.deviceTypeId;
		this.deviceTypeBean = gwDevBean.deviceTypeBean;
		this.gatewayAddress = gwDevBean.gatewayAddress;
		this.gatewaySecAddress = gwDevBean.gatewaySecAddress;
		this.callingPartyFormat = gwDevBean.callingPartyFormat;
		this.termCallingInd = gwDevBean.termCallingInd;
		this.sbcId = gwDevBean.sbcId;
		this.secSbcId = gwDevBean.secSbcId;
		this.fqdn = gwDevBean.fqdn;
		this.brixInd = gwDevBean.brixInd;
                this.envOrderId = gwDevBean.envOrderId;       
		this.modifiedBy = gwDevBean.modifiedBy;
		this.sbcProvmethod = gwDevBean.sbcProvmethod;
		this.sbcMigInd = gwDevBean.sbcMigInd;

		this.createdBy = gwDevBean.createdBy;
		this.creationDate = gwDevBean.creationDate;
		this.lastModifiedDate = gwDevBean.lastModifiedDate;
		this.deviceCarrInd = gwDevBean.deviceCarrInd;
		this.transport = gwDevBean.transport;
		this.stripCcInd = gwDevBean.stripCcInd;
		this.deviceCharId = gwDevBean.deviceCharId;
		this.logTrail = gwDevBean.logTrail;
        this.gatewayHunt = gwDevBean.gatewayHunt;
        this.portsAssigned=gwDevBean.portsAssigned;
        this.deviceRealTypeId=gwDevBean.deviceRealTypeId;
        this.iasaGatewayDeviceId = gwDevBean.iasaGatewayDeviceId;
        this.sTn = gwDevBean.sTn;
        this.sTnPoolId = gwDevBean.sTnPoolId;
        this.sTnLinePort = gwDevBean.sTnLinePort;
        this.internalAdmin = gwDevBean.internalAdmin;
        this.aggregateOffnetCcl = gwDevBean.aggregateOffnetCcl;
        this.signalingTierLookupValue = gwDevBean.signalingTierLookupValue;
        this.tierOverrideFlag = gwDevBean.tierOverrideFlag;
        this.ipVersion = gwDevBean.ipVersion;
        this.pqInstanceId = gwDevBean.pqInstanceId;
		this.tsoMigLock = gwDevBean.tsoMigLock;
		this.ipsecTunnelId = gwDevBean.ipsecTunnelId;
		this.updateComment = gwDevBean.updateComment;
	}
	
	public GatewayDeviceBean(IpcomGatewayInfoDbBean gwInfoBean,IpcomDeviceXrefDbBean devXref)
	{
		logTrail = new ArrayList<String>();
		if ( (gwInfoBean != null) && (devXref != null) ){
			// out of scope : ENTPRISE_LOCAL_GTWY
			// out of scope : ENTPRISE_LOCAL_GTWY_SHARED
		}else if ( (gwInfoBean != null) && (devXref == null) ){
			// CPE_LOCAL_GTWY
		}else if ( (gwInfoBean == null) && (devXref != null))
		{
			// CPE_ENTPRISE_GTWY_SHARED
			// ENTPRISE_GTWY
		}
		
		if ( gwInfoBean != null ){
			this.gatewayDeviceId = (long) gwInfoBean.getGatewayDevid();
			this.deviceName = gwInfoBean.getGatewayname();
			this.gatewayAddress = gwInfoBean.getGatewayid();
			this.callingPartyFormat = gwInfoBean.getStripccind();
			this.stripCcInd = gwInfoBean.getStripccind();
			this.termCallingInd = gwInfoBean.getTermcallingind();
			//this.sbcId = gwInfoBean.getSbcInd();
			this.modifiedBy = "SBC_MIG";
			this.createdBy = "SBC_MIG";
			//this.sbcProvmethod = gwInfoBean.sbcProvmethod;

			
			this.stripCcInd = gwInfoBean.getStripccind();
			this.iasaGatewayDeviceId = gwInfoBean.getGatewayDevid();
			this.deviceRealTypeId=VzbVoipEnum.DeviceType.CPE_LOCAL_GTWY;
			this.transport = 2;
			this.customerId = gwInfoBean.getCustId();
			
			if ( gwInfoBean.getLocid() == 0){
				this.locationId = null;
			}else{
				this.locationId = Long.toString(gwInfoBean.getLocid());
			}
			
		}
		
		if ( devXref != null ){
			this.deviceTypeId = devXref.getDevid();
			this.gatewayDeviceId = (long)devXref.getLocDevid();
			this.deviceName = devXref.getName();
			this.gatewayAddress = devXref.getHost();
			
			if (  devXref.getSecHost() != null ){
				if ( devXref.getSecHost().equals("_NONE_")){
					this.gatewaySecAddress = null;
				}else{		
					this.gatewaySecAddress = devXref.getSecHost();
				}
			}else{
				this.gatewaySecAddress = null;
			}
			this.brixInd = devXref.getBrixInd();
			this.stripCcInd = devXref.getStripccind();
			this.callingPartyFormat = devXref.getStripccind();
			this.modifiedBy = "SBC_MIG";
			this.createdBy = "SBC_MIG";
			this.iasaGatewayDeviceId = devXref.getLocDevid();
			this.deviceRealTypeId = -1; // this need to get it by iasa query
			this.transport = 2;
			this.termCallingInd = 0;
			this.customerId = devXref.getCustId();
			
			
			if ( devXref.getLocid() == 0){
				this.locationId = null;
			}else{
				this.locationId = Long.toString(devXref.getLocid());
			}
			
			if ( devXref.getScreenedTn() == 0){
				this.sTn = null;
			}else{
				this.sTn = Long.toString(devXref.getScreenedTn());
			}
			
         if (devXref.getStnLinePort() == null || devXref.getStnLinePort().trim().length() == 0) {
            this.sTnLinePort = null;
         } else {
            this.sTnLinePort = devXref.getStnLinePort();
         }
			
		}		      
		
		this.creationDate = getCreationDate();
		this.lastModifiedDate = getLastModifiedDate();
		
		//this.deviceTypeBean = gwDevBean.deviceTypeBean;
        //this.envOrderId = gwDevBean.envOrderId; 
		//this.deviceCarrInd = gwDevBean.;
		//this.transport = gwDevBean.transport;
		
		//this.deviceCharId = gwDevBean.deviceCharId;
		//this.logTrail = gwDevBean.logTrail;
        //this.gatewayHunt = gwDevBean.gatewayHunt;
        //this.portsAssigned=gwDevBean.portsAssigned;
	}
	
	
	
	/* not used in VZB_INV_ET_TN
	//getters - setters
	public SbcBean getSbcBean() {
                return sbcBean;
        }
        public void setSbcBean(SbcBean sbcBean) {
                this.sbcBean = sbcBean;
        }
      */  
        public String getFqdn() {
    		return fqdn;
    	}
    	public void setFqdn(String fqdn) {
    		this.fqdn = fqdn;
    	}   
        

	
	public long getGatewayDeviceId() {
		return gatewayDeviceId;
	}
	public void setDeviceTypeId(long deviceTypeId) {
		this.deviceTypeId = deviceTypeId;
	}
	public String getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public void setGatewayDeviceId(long gatewayDeviceId) {
		this.gatewayDeviceId = gatewayDeviceId;
	}
	public String getDeviceName() {
		return deviceName;
	}
	public void setDeviceName(String deviceName) {
		this.deviceName = deviceName;
	}
	public long getDeviceTypeId() {
		return deviceTypeId;
	}
	public DeviceTypeBean getDeviceTypeBean() {
                return deviceTypeBean;
        }
        public void setDeviceTypeBean(DeviceTypeBean deviceTypeBean) {
                this.deviceTypeBean = deviceTypeBean;
        }
	public String getGatewayAddress() {
		return gatewayAddress;
	}
	public void setGatewayAddress(String gatewayAddress) {
		this.gatewayAddress = gatewayAddress;
	}
	public String getGatewaySecAddress() {
		return gatewaySecAddress;
	}
	public void setGatewaySecAddress(String gatewaySecAddress) {
		this.gatewaySecAddress = gatewaySecAddress;
	}
	public long getCallingPartyFormat() {
		return callingPartyFormat;
	}
	public void setCallingPartyFormat(long callingPartyFormat) {
		this.callingPartyFormat = callingPartyFormat;
	}
	public long getTermCallingInd() {
		return termCallingInd;
	}
	public void setTermCallingInd(long termCallingInd) {
		this.termCallingInd = termCallingInd;
	}
	public long getSbcId() {
		return sbcId;
	}
	public void setSbcId(long sbcId) {
		this.sbcId = sbcId;
	}
	public long getSecSbcId() {
        return secSbcId;
    }
    public void setSecSbcId(long secSbcId) {
        this.secSbcId = secSbcId;
    }
	public long getBrixInd() {
		return brixInd;
	}
	public void setBrixInd(long brixInd) {
		this.brixInd = brixInd;
	}
	public Timestamp getCreationDate() {
		return this.creationDate;
	}
	public void setCreationDate(Timestamp creationDate) {
		this.creationDate = creationDate;
	}
	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}
	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}
	

	
	/**
	 * @return Returns the device_carr_ind.
	 */
	public long getDeviceCarrInd() {
		return deviceCarrInd;
	}
	/**
	 * @param device_carr_ind The device_carr_ind to set.
	 */
	public void setDeviceCarrInd(long device_carr_ind) {
		this.deviceCarrInd = device_carr_ind;
	}
	/**
	 * @return Returns the stripccind.
	 */
	public long getStripCcInd() {
		return stripCcInd;
	}
	/**
	 * @param stripccind The stripccind to set.
	 */
	public void setStripCcInd(long stripccind) {
		this.stripCcInd = stripccind;
	}
	/**
	 * @return Returns the transport.
	 */
	public long getTransport() {
		return transport;
	}
	/**
	 * @param transport The transport to set.
	 */
	public void setTransport(long transport) {
		this.transport = transport;
        }
	public long getEnvOrderId() {
		return envOrderId;
	}
	public void setEnvOrderId(long envOrderId) {
		this.envOrderId = envOrderId;
        }

	public long getDeviceCharId() {
		return deviceCharId;
	}

	public void setDeviceCharId(long deviceCharId) {
		this.deviceCharId = deviceCharId;
	}
	public void setLogTrail(String logStr)
    {
            logTrail.add(logStr);
    }
    public List<String> getLogTrail()
    {
            return logTrail;
    }
    public String getGatewayHunt() {
        return gatewayHunt;
    }
    public void setGatewayHunt(String gatewayHunt){
        this.gatewayHunt = gatewayHunt;
    }
	public long getPortsAssigned() {
		return portsAssigned;
	}

	public void setPortsAssigned(long portsAssigned) {
		this.portsAssigned = portsAssigned;
	}	
		
	public long getIasaGatewayDeviceId() {
		return iasaGatewayDeviceId;
	}
	public void setIasaGatewayDeviceId(long iasaGatewayDeviceId) {
		this.iasaGatewayDeviceId = iasaGatewayDeviceId;
	}
	public long getDeviceRealTypeId() {
		return deviceRealTypeId;
	}
	public void setDeviceRealTypeId(long deviceRealTypeId) {
		this.deviceRealTypeId = deviceRealTypeId;
	}
	
	
	public long getSbcProvMethod() {
		return sbcProvmethod;
	}
	/**
	 * @param device_carr_ind The device_carr_ind to set.
	 */
	public void setSbcProvMethod(long sbcProvmethod) {
		this.sbcProvmethod = sbcProvmethod;
	}

	public long getSbcMigInd() {
        return sbcMigInd;
    }
    public void setSbcMigInd(long sbcMigInd) {
        this.sbcMigInd = sbcMigInd;
    }

	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	public String getLocationId() {
		return locationId;
	}
	public void setLocationId(String locationId) {
		this.locationId = locationId;
	}
	public long getSTnPoolId() {
		return sTnPoolId;
	}
	public void setSTnPoolId(long stnPoolId) {
		this.sTnPoolId = stnPoolId;
	}
	public short getInternalAdmin() {
        return internalAdmin;
    }
    public void setInternalAdmin(short internalAdmin) {
        this.internalAdmin = internalAdmin;
    }
	public String getSTn() {
		return sTn;
	}
	public void setSTn(String tn) {
		sTn = tn;
	}
	/**
	 * @return the sTnLinePort
	 */
	public String getSTnLinePort() {
		return sTnLinePort;
	}
	/**
	 * @param tnLinePort the sTnLinePort to set
	 */
	public void setSTnLinePort(String tnLinePort) {
		sTnLinePort = tnLinePort;
	}
	public long getAggregateOffnetCcl() {
		return aggregateOffnetCcl;
	}
	public void setAggregateOffnetCcl(long aggregateOffnetCcl) {
		this.aggregateOffnetCcl = aggregateOffnetCcl;
	}
	public BigDecimal getSignalingTierLookupValue() {
		return signalingTierLookupValue;
	}
	public void setSignalingTierLookupValue(BigDecimal signalingTierLookupValue) {
		this.signalingTierLookupValue = signalingTierLookupValue;
	}
	public long getTierOverrideFlag() {
		return tierOverrideFlag;
	}
	public void setTierOverrideFlag(long tierOverrideFlag) {
		this.tierOverrideFlag = tierOverrideFlag;
	}
	public short getIpVersion() {
		return ipVersion;
	}
	public void setIpVersion(short ipVersion) {
		this.ipVersion = ipVersion;
	}
	public long getPqInstanceId() {
		return pqInstanceId;
	}
	public void setPqInstanceId(long pqInstanceId) {
		this.pqInstanceId = pqInstanceId;
	}
	public short getTsoMigLock() {
		return tsoMigLock;
	}
	public void setTsoMigLock(short tsoMigLock) {
		this.tsoMigLock = tsoMigLock;
	}
	public long getIpsecTunnelId() {
		return ipsecTunnelId;
	}
	public void setIpsecTunnelId(long ipsecTunnelId) {
		this.ipsecTunnelId = ipsecTunnelId;
	}
	public String getUpdateComment() {
		return updateComment;
	}
	public void setUpdateComment(String updateComment) {
		this.updateComment = updateComment;
	}
	
}

