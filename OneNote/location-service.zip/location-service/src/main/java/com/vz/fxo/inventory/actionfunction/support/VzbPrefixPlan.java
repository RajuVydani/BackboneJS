package com.vz.fxo.inventory.actionfunction.support;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import esap.db.DBTblVzbPprange;
import esap.db.DBTblVzbPrefixPlan;
import esap.db.TblLocationQuery;
import esap.db.TblVzbPrefixPlanDbBean;
import esap.db.TblVzbPrefixPlanQuery;

public class VzbPrefixPlan extends VzbPrefixPlanBean{
	
	private static Logger log = LoggerFactory.getLogger(VzbPrefixPlan.class.toString());

	Connection dbCon;
	InvErrorCode status = InvErrorCode.INTERNAL_ERROR;

	public int getStatusCode() {
		return status.getErrorCode();
	}

	public void setStatus(InvErrorCode status) {
		this.status = status;
	}

	public String getStatusDesc() {
		return status.getErrorDesc();
	}

	public Connection getDbCon() {
		return dbCon;
	}
	public void setDbCon(Connection dbCon) {
		this.dbCon = dbCon;
	}
	public VzbPrefixPlan(Connection dbCon)
	{
		this.dbCon = dbCon;
	}
	public VzbPrefixPlan(VzbPrefixPlanBean vppBean, Connection dbCon)
	{
		super(vppBean);
		this.dbCon = dbCon;
	}
	

	public boolean addVzbPrefixPlan() throws SQLException, Exception
	{
		log.info("Entering addVzbPrefixPlan");
		try
		{
			DBTblVzbPrefixPlan vppDbBean = new DBTblVzbPrefixPlan();
			if(getPrefixPlanId() > 0)
				vppDbBean.setPrefixPlanId(getPrefixPlanId());
			else
				vppDbBean.setPrefixPlanId(vppDbBean.getPrefixPlanIdSeqNextVal(dbCon));
			vppDbBean.setLocationId(getLocationId());
			vppDbBean.setCustomerId(getCustomerId());
			if(getPrefixName() == null || (getPrefixName()!= null && "".equals(getPrefixName())))
				vppDbBean.setPrefixName("Default Prefix Plan");
			else
				vppDbBean.setPrefixName(getPrefixName());
			vppDbBean.setMobile(getMobile());

			if(getCreatedBy() != null && !getCreatedBy().equals(""))
				vppDbBean.setCreatedBy(getCreatedBy());
			else
				vppDbBean.setCreatedBy("ESAP_INV");

			if(getModifiedBy() != null && !getModifiedBy().equals(""))
				vppDbBean.setModifiedBy(getModifiedBy());
			else
				vppDbBean.setModifiedBy("ESAP_INV");

			vppDbBean.setCreationDate(new Timestamp(System.currentTimeMillis()));
			vppDbBean.setLastModifiedDate(new Timestamp(System.currentTimeMillis()));
			vppDbBean.insertSpecific(dbCon);
		}
		catch(SQLException s)
		{
			log.info("SQL Exception in addVzbPrefixPlan");
			throw s;
		}

		setStatus(InvErrorCode.SUCCESS);
		log.info("Successfully Inserted Prefix Plan");
		return true;
	}
	
	public boolean deleteVzbPrefixPlan()
	{
		log.info("Entering deleteVzbPrefixPlan");
		try
		{
			if(getPrefixPlanId() <= 0)
			{
				setStatus(InvErrorCode.PREFIX_PLAN_NOT_FOUND);
                return false;
			}
		
			//Delete the child table first.
			DBTblVzbPprange tblVzbPpRange = new DBTblVzbPprange();
			tblVzbPpRange.wherePrefixPlanIdEQ(getPrefixPlanId());
			int ppRangeDeleted = tblVzbPpRange.deleteByWhere(dbCon);
			log.info("Deleted [" + ppRangeDeleted + "] Prefix Plan Range");
			
			DBTblVzbPrefixPlan vppDbBean = new DBTblVzbPrefixPlan();
			vppDbBean.wherePrefixPlanIdEQ(getPrefixPlanId());
			int pptDeleted = vppDbBean.deleteByWhere(dbCon);
			log.info("Deleted [" + pptDeleted + "] Prefix Plan");
		}
		catch(SQLException s)
		{
			s.printStackTrace();	
			setStatus(InvErrorCode.DB_EXCEPTION);
			log.info("DB_FAILURE in deleteVzbPrefixPlanTplt");
			return false;
		}
		setStatus(InvErrorCode.SUCCESS);
		log.info("Successfully Deleted Prefix Plan");
		return true;
	}

	public ArrayList<VzbPrefixPlan> getVzbPrefixPlanByNameAndLocId()
    {
        log.info("Entering getVzbPrefixPlanByNameAndLocId");
		ArrayList<VzbPrefixPlan> ppList = null;
        try
        {
			if((getPrefixName() == null || (getPrefixName() != null && "".equals(getPrefixName())))
				|| (getLocationId() == null || (getLocationId() != null && "".equals(getLocationId()))))
			{
				setStatus(InvErrorCode.PREFIX_PLAN_NOT_FOUND);
                log.info("Invalid Location Is [" + getLocationId() + "] Or Prefix Name [" + getPrefixName() + "]");
                return ppList;
			}
            TblVzbPrefixPlanQuery pptQry = new TblVzbPrefixPlanQuery();
			pptQry.wherePrefixNameEQ(getPrefixName());
            pptQry.whereLocationIdEQ(getLocationId());
            pptQry.query(dbCon);

            if (pptQry.size() <= 0)
            {
                setStatus(InvErrorCode.PREFIX_PLAN_NOT_FOUND);
                log.info("Prefix Plan Id Not Found for Location Id [" + getLocationId() + "]");
                return ppList;
            }
			for(int i=0; i<pptQry.size(); i++)
			{
            	TblVzbPrefixPlanDbBean pptBean = pptQry.getDbBean(i);
				VzbPrefixPlan ppObj = loadPrefixPlanObj(pptBean);
				ppList.add(ppObj);
			}
        }
        catch(SQLException e)
        {
            e.printStackTrace();
            setStatus(InvErrorCode.DB_EXCEPTION);
            return ppList;
        }
        catch(Exception e)
        {
            e.printStackTrace();
            setStatus(InvErrorCode.PREFIX_PLAN_NOT_FOUND);
            return ppList;
        }
        setStatus(InvErrorCode.SUCCESS);
        log.info("Successfuly Retrieved Prefix Plan");
        return ppList;
    }

	private VzbPrefixPlan loadPrefixPlanObj(TblVzbPrefixPlanDbBean pptBean)
	{
		log.info("Entering loadPrefixPlanObj");

		VzbPrefixPlan ppObj = new VzbPrefixPlan(dbCon);
		ppObj.setLocationId(pptBean.getLocationId());
        ppObj.setPrefixPlanId(pptBean.getPrefixPlanId());
        ppObj.setCustomerId(pptBean.getCustomerId());
        ppObj.setPrefixName(pptBean.getPrefixName());
        ppObj.setMobile(pptBean.getMobile());
        ppObj.setCreatedBy(pptBean.getCreatedBy());
        ppObj.setCreationDate(pptBean.getCreationDate());
        ppObj.setModifiedBy(pptBean.getModifiedBy());
        ppObj.setLastModifiedDate(pptBean.getLastModifiedDate());
		
		return ppObj;	
	}

	public ArrayList<VzbPrefixPlan> getVzbPrefixPlanDetails()
    {
        log.info("Entering getVzbPrefixPlanDetails");
        ArrayList<VzbPrefixPlan> ppList = null;
        try
        {
			TblVzbPrefixPlanQuery pptQry = new TblVzbPrefixPlanQuery();
            if(getPrefixPlanId() > 0)
                pptQry.wherePrefixPlanIdEQ(getPrefixPlanId());
            if(getLocationId() != null && !"".equals(getLocationId()))
                pptQry.whereLocationIdEQ(getLocationId());
            if(getPrefixName() != null && !"".equals(getPrefixName()))
                pptQry.wherePrefixNameEQ(getPrefixName());
            if(getCustomerId() != null && !"".equals(getCustomerId()))
                pptQry.whereCustomerIdEQ(getCustomerId());
            pptQry.query(dbCon);

            if (pptQry.size() <= 0)
            {
                setStatus(InvErrorCode.PREFIX_PLAN_NOT_FOUND);
                log.info("Prefix Plan Not Found");
                return ppList;
            }else
            	ppList = new ArrayList<VzbPrefixPlan>();
            
            for(int i=0; i<pptQry.size(); i++)
            {
                TblVzbPrefixPlanDbBean pptBean = pptQry.getDbBean(i);
				VzbPrefixPlan ppObj = loadPrefixPlanObj(pptBean);
                ppList.add(ppObj);
            }
        }
        catch(SQLException e)
        {
            e.printStackTrace();
            setStatus(InvErrorCode.DB_EXCEPTION);
            return ppList;
        }
        catch(Exception e)
        {
            e.printStackTrace();
            setStatus(InvErrorCode.PREFIX_PLAN_NOT_FOUND);
            return ppList;
        }
        setStatus(InvErrorCode.SUCCESS);
        log.info("Successfuly Retrieved Prefix Plan");
        return ppList;
	}

	public List<VzbPrefixPlan> getAllPrefixPlansByEmerLocCodeId(String emerLocCodeId)
    {
        log.info("Entering getAllPrefixPlansByEmerLocCodeId");
        List<VzbPrefixPlan> ppList = null;
        try
        {
			TblLocationQuery locQry = new TblLocationQuery();
			locQry.whereEmerLocationCodeEQ(emerLocCodeId);
			locQry.query(dbCon);

			if(locQry.size() <= 0)
			{
				log.info("No Location Found by Emer Loc Code Id [" + emerLocCodeId + "]");
				setStatus(InvErrorCode.PREFIX_PLAN_NOT_FOUND);
				return ppList;
			}
            ppList = new  ArrayList<VzbPrefixPlan>();
			for(int i=0; i<locQry.size(); i++)
			{
				TblVzbPrefixPlanQuery ppQry = new TblVzbPrefixPlanQuery();
				ppQry.whereLocationIdEQ((locQry.getDbBean(i)).getLocationId());
                ppQry.query(dbCon);
				if(ppQry.size() <= 0)
				{
					log.info("No Prefix Plan Found By Location Id [" + (locQry.getDbBean(i)).getLocationId() + "]");
					setStatus(InvErrorCode.PREFIX_PLAN_NOT_FOUND);
                	return ppList;
				}
				for(int k=0; k<ppQry.size(); k++)
                {
                	TblVzbPrefixPlanDbBean ppBean = ppQry.getDbBean(k);
                    VzbPrefixPlan ppObj = loadPrefixPlanObj(ppBean);
                    ppList.add(ppObj);
                }
			}
			if(ppList != null) 
				log.info("Retrieved [" + ppList.size() + "] Prefix Plans");
			else
				log.info("No Prefix Plan Found");
        }
        catch(SQLException e)
        {
            e.printStackTrace();
            setStatus(InvErrorCode.DB_EXCEPTION);
            return ppList;
        }
        catch(Exception e)
        {
            e.printStackTrace();
            setStatus(InvErrorCode.PREFIX_PLAN_NOT_FOUND);
            return ppList;
        }
        setStatus(InvErrorCode.SUCCESS);
        return ppList;
    }
	

}
