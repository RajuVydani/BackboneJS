package com.vz.fxo.inventory.actionfunction.support;


public class ResponseObject {
	
	public final static int SUCCESS = 0;
	public final static int FAILURE = 1;
	public final static int SUCCESS_SKIP = 21;

	int statusCode;
	String statusDescription;

	public int getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(int statusCode) {
		this.statusCode = statusCode;
	}

	public String getStatusDescription() {
		return statusDescription;
	}

	public void setStatusDescription(String statusDescription) {
		this.statusDescription = statusDescription;
	}

	/*public static void main(String args[]) throws JsonProcessingException {

		ObjectMapper mapper = new ObjectMapper();
		ResponseObject obj = new ResponseObject();

		// Object to JSON in file
		// mapper.writeValue(new File("c:\\file.json"), obj);

		// Object to JSON in String
		obj.setStatusCode(1);
		obj.setStatusDescription("Activation Job is successful for TN");
		

		String jsonInString = mapper.writeValueAsString(obj);
		
		System.out.println("JSON Object ==>" + jsonInString);

	}*/
}
