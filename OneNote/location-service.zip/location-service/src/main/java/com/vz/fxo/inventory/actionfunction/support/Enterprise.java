package com.vz.fxo.inventory.actionfunction.support;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.vz.fxo.inventory.enterprise.support.Department;
import com.vz.fxo.inventory.enterprise.support.EnterpriseAdmin;
import com.vz.fxo.inventory.enterprise.support.TsoRoutingGroup;

import EsapEnumPkg.VzbVoipEnum;
import esap.db.DBTblAuthServices;
import esap.db.DBTblCustomer;
import esap.db.DBTblEntBillFeatures;
import esap.db.DBTblEnterprise;
import esap.db.DBTblEnterpriseLorSbcMap;
import esap.db.DBTblGuiAuthServices;
import esap.db.DBTblGuiCallingPlans;
import esap.db.DBTblGuiCustomer;
import esap.db.DBTblGuiDialPlan;
import esap.db.DBTblGuiPrefixRouting;
import esap.db.DBTblGuiSipDomain;
import esap.db.DBTblGuiTerminatingRouting;
import esap.db.DBTblIpccIpTerm;
import esap.db.DBTblIpccIptermSbcMap;
import esap.db.DBTblIpccLoadsharing;
import esap.db.DBTblIpccSbcMap;
import esap.db.DBTblLocation;
import esap.db.DBTblPoliciesService;
import esap.db.DBTblPublicTnPool;
import esap.db.DBTblServicepackService;
import esap.db.DBTblTsoEnterpriseSbcMap;
import esap.db.DBTblVzbFeatures;
import esap.db.TblAuthServicesDbBean;
import esap.db.TblAuthServicesQuery;
import esap.db.TblBsAsQuery;
import esap.db.TblConfigParamsDbBean;
import esap.db.TblConfigParamsQuery;
import esap.db.TblCustomerDbBean;
import esap.db.TblCustomerQuery;
import esap.db.TblDepartmentDbBean;
import esap.db.TblDepartmentQuery;
import esap.db.TblDeviceMapQuery;
import esap.db.TblDialPlanQuery;
import esap.db.TblDigitStringsDbBean;
import esap.db.TblDigitStringsQuery;
import esap.db.TblEntBillFeaturesQuery;
import esap.db.TblEnterpriseAdminDbBean;
import esap.db.TblEnterpriseAdminQuery;
import esap.db.TblEnterpriseDbBean;
import esap.db.TblEnterpriseQuery;
import esap.db.TblLocationDbBean;
import esap.db.TblLocationQuery;
import esap.db.TblPoliciesDbBean;
import esap.db.TblPoliciesQuery;
import esap.db.TblPoliciesServiceQuery;
import esap.db.TblPrefixRoutingDbBean;
import esap.db.TblPrefixRoutingQuery;
import esap.db.TblServicepackDbBean;
import esap.db.TblServicepackQuery;
import esap.db.TblServicepackServiceQuery;
import esap.db.TblSipDomainQuery;
import esap.db.TblTsoEbiQuery;
import esap.db.TblTsoEnterpriseTrunkQuery;
import esap.db.TblTsoRoutingGroupQuery;
import esap.db.TblVzbFeaturesDbBean;
import esap.db.TblVzbFeaturesQuery;
import esap.db.TblVzbStateGatewayMapDbBean;
import esap.db.TblVzbStateGatewayMapQuery;

public class Enterprise extends EnterpriseBean {
	
	private static Logger log = LoggerFactory.getLogger(Enterprise.class
			.toString());


	InvErrorCode status = InvErrorCode.INTERNAL_ERROR;
	Connection dbCon;
	boolean rollbackFlag;
	boolean migration;
	boolean shellMigration;

	// Constructor
	public Enterprise(Connection connection) {
		super();
		this.dbCon = connection;
		this.rollbackFlag = false;
		this.migration = false;
		this.shellMigration = false;
	}

	public Enterprise(EnterpriseBean entBean, Connection connection) {
		super(entBean);
		this.dbCon = connection;
		this.rollbackFlag = false;
		this.migration = false;
		this.shellMigration = false;
	}

	

	public boolean getShellMigration() {
		return shellMigration;
	}

	public void setShellMigration(boolean shellMigration) {
		this.shellMigration = shellMigration;
	}

	public boolean getRollbackFlag() {
		return rollbackFlag;
	}

	public void setRollbackFlag(boolean rollbackFlag) {
		this.rollbackFlag = rollbackFlag;
	}

	public boolean getMigration() {
		return migration;
	}

	public void setMigration(boolean migration) {
		this.migration = migration;
	}

	public int getStatusCode() {
		return status.getErrorCode();
	}

	public void setStatus(InvErrorCode status) {
		this.status = status;
	}

	public String getStatusDesc() {
		return status.getErrorDesc();
	}

	public Connection getDbCon() {
		return dbCon;
	}

	public void setDbCon(Connection dbCon) {
		this.dbCon = dbCon;
	}
   //KR-start added policy features for xo changes 
	private int addDefaultPolicyFeatures(String policyType)
			throws SQLException, Exception { 
		int policySerId = 0;
		TblPoliciesQuery policyQry=new  TblPoliciesQuery();
		policyQry.wherePolicyTypeEQ(policyType);
		log.info("Before policyQry in addToDB");
		policyQry.query(dbCon);
		log.info("After policyQry in addToDB");

		if (policyQry.size() > 0) {				
			policySerId = getPolicyServiceSeqNextVal(dbCon);			
			setPolicyServicesId(policySerId);
			for (int i = 0; i < policyQry.size(); i++) {
				DBTblPoliciesService policyServicesBean=new DBTblPoliciesService();		
				TblPoliciesDbBean policiesDbBean=policyQry.getDbBean(i);
				policyServicesBean.setPoliciesServiceId(policySerId);
				policyServicesBean.setPolicyId(policiesDbBean.getPolicyId());
				policyServicesBean.setAccesslevel("Full");//TODO check this value from tod
				if (getEnvOrderId() > 0)
					policyServicesBean.setEnvOrderId((int)getEnvOrderId());  
				else
					policyServicesBean.setEnvOrderId(0);
				if (createdBy != null && !createdBy.trim().equals(""))
					policyServicesBean.setCreatedBy(createdBy);
				else
					policyServicesBean.setCreatedBy("ESAP_INV");
				if (modifiedBy != null && !modifiedBy.trim().equals(""))
					policyServicesBean.setModifiedBy(modifiedBy);
				else
					policyServicesBean.setModifiedBy("ESAP_INV");
				policyServicesBean.setCreationDate(new Timestamp(System
						.currentTimeMillis()));
				policyServicesBean.setLastModifiedDate(new Timestamp(System
						.currentTimeMillis()));				
				policyServicesBean.insert(dbCon);
			}
		}
		return policySerId;
		
	}
	
	private int addDefaultServicePackFeatures(String  packType)
			throws SQLException, Exception {
		int servicepackSerId = 0;
		TblServicepackQuery ServicepackQry = new TblServicepackQuery();
		ServicepackQry.whereServicepackTypeEQ(packType);
		log.info("Before authQry in addToDB");
		ServicepackQry.query(dbCon);
		log.info("After authQry in addToDB");

		if (ServicepackQry.size() > 0) {
			servicepackSerId = getServicePackServiceSeqNextVal(dbCon);			
			setServicePackServicesId((long)servicepackSerId);
				for (int i = 0; i < ServicepackQry.size(); i++) {
					DBTblServicepackService servicepackServicesBean=new DBTblServicepackService();		
					TblServicepackDbBean policiesDbBean=ServicepackQry.getDbBean(i);
					servicepackServicesBean.setServicepackServiceId(servicepackSerId);
					servicepackServicesBean.setServicepackId(policiesDbBean.getServicepackId());
					//servicepackServicesBean.setAccesslevel("Full");//TODO check this value from tod
					if (getEnvOrderId() > 0)
						servicepackServicesBean.setEnvOrderId((int)getEnvOrderId());  
					else
						servicepackServicesBean.setEnvOrderId(0);
					if (createdBy != null && !createdBy.trim().equals(""))
						servicepackServicesBean.setCreatedBy(createdBy);
					else
						servicepackServicesBean.setCreatedBy("ESAP_INV");
					if (modifiedBy != null && !modifiedBy.trim().equals(""))
						servicepackServicesBean.setModifiedBy(modifiedBy);
					else
						servicepackServicesBean.setModifiedBy("ESAP_INV");
					servicepackServicesBean.setCreationDate(new Timestamp(System
							.currentTimeMillis()));
					servicepackServicesBean.setLastModifiedDate(new Timestamp(System
							.currentTimeMillis()));				
					servicepackServicesBean.insert(dbCon);
				}
			}
		return servicepackSerId;
	}

   //KR-end	
	
	private int addDefaultAuthFeatures(int defaultAuthSerId)
			throws SQLException, Exception {
		int authSerId = 0;
		TblAuthServicesQuery authQry = new TblAuthServicesQuery();
		authQry.whereAuthServiceIdEQ(defaultAuthSerId);
		log.info("Before authQry in addToDB");
		authQry.query(dbCon);
		log.info("After authQry in addToDB");

		if (authQry.size() > 0) {
			DBTblAuthServices authServicesDbBean = new DBTblAuthServices();
			authSerId = getAuthServiceIdSeqNextVal(dbCon);
			setAuthServicesId(authSerId);
			for (int i = 0; i < authQry.size(); i++) {
				authServicesDbBean.copyFromBean(authQry.getDbBean(i));//authServicesDbBean =  select * from tbl_auth_services where auth_service_id='4'
				authServicesDbBean.setAuthServiceId(authSerId);
				// Add the Auth feature Route_Exhaust only for VTSO
				if (authServicesDbBean.getFeatureId() == 96 && soEnabled != 1) {
					continue;
				}
				long featureId = 0;
				boolean isFeatureIdMatched = false;
				for (int ii = 0; ii < authFeaturesList.size(); ii++) {
					FeaturesBean featureDbBean = authFeaturesList.get(ii);
					if (featureDbBean.getFeaturesDbBean().getFeatureId() == authServicesDbBean
							.getFeatureId()) {
						isFeatureIdMatched = true;
						log.info("**** Feature Id is <"
								+ featureDbBean.getFeaturesDbBean()
										.getFeatureId() + ">");
					}
				}

				if (isFeatureIdMatched)
					continue;
				if (getEnvOrderId() > 0)
					authServicesDbBean.setEnvOrderId(getEnvOrderId());
				else
					authServicesDbBean.setEnvOrderIdNull();
				if (createdBy != null && !createdBy.trim().equals(""))
					authServicesDbBean.setCreatedBy(createdBy);
				else
					authServicesDbBean.setCreatedBy("ESAP_INV");
				if (modifiedBy != null && !modifiedBy.trim().equals(""))
					authServicesDbBean.setModifiedBy(modifiedBy);
				else
					authServicesDbBean.setModifiedBy("ESAP_INV");
				authServicesDbBean.setCreationDate(new Timestamp(System
						.currentTimeMillis()));
				authServicesDbBean.setLastModifiedDate(new Timestamp(System
						.currentTimeMillis()));
				// printAuthServicesDbBean(authServicesDbBean);
				authServicesDbBean.insert(dbCon);
			}
		}
		return authSerId;
	}

	

	public boolean addTermRoutingForMwi(int dialPlanId, String sipDomain)
			throws SQLException, Exception {
		// Term Routing Added for MWI with Static Values
		log.info("Entering addTermRoutingForMwi");
		TerminatingRouting tr = new TerminatingRouting(dbCon);
		tr.setDialPlanId(dialPlanId);
		tr.setNoa(0);
		tr.setRangeStart("0000000");
		tr.setRangeEnd("9999999");
		tr.setP1URL(sipDomain);
		tr.setPringTime("252");
		tr.setPtrId(null);
		tr.setPPrefixDgts(null);
		tr.setPSuffixNum(32);
		tr.setA1URL(null);
		tr.setA1RingTime(null);
		tr.setA1TRId(null);
		tr.setA1PrefixDgts(null);
		tr.setA1SuffixNum(0);
		tr.setA2URL(null);
		tr.setA2RingTime(null);
		tr.setA2TRId(null);
		tr.setA2PrefixDgts(null);
		tr.setA2SuffixNum(0);
		if (createdBy != null && !createdBy.trim().equals(""))
			tr.setCreatedBy(createdBy);
		else
			tr.setCreatedBy("ESAP_INV");
		if (modifiedBy != null && !modifiedBy.trim().equals(""))
			tr.setModifiedBy(modifiedBy);
		else
			tr.setModifiedBy("ESAP_INV");
		tr.setCreationDate(new Timestamp(System.currentTimeMillis()));
		tr.setLastModifiedDate(new Timestamp(System.currentTimeMillis()));

		if (tr.addTerminatingRouting() != true) {
			setLogTrail("Failed to Add TermRouting For MWI");
			log.info("Failed to Add TermRouting For MWI");
			return false;
		}
		log.info("Successfully added Term Routing For MWI");
		return true;
	}

	public boolean addRIVCustomerToDB() {
		DBTblEnterprise entDbObj = new DBTblEnterprise();
		DBTblCustomer custDbObj = new DBTblCustomer();
		log.info("Adding addRIVCustomerToDB to Inventory");

		try {
			entDbObj.setAsId(asId);
			entDbObj.setSbcActivationSystem(sbcActivationSystem);

			custDbObj.setCustomerId(customerId);
			if (!"NONE".equals(customerName) && !"".equals(customerName))
				custDbObj.setCustomerName(customerName.trim());
			custDbObj.setAccountName(accountName);
			if (regionId != 0)
				custDbObj.setRegionId(regionId);
			else
				custDbObj.setRegionId(VzbVoipEnum.RegionType.US);
			custDbObj.setSbcMigInd(1);
			custDbObj.setProductType(productType);
			if (isRIVCustomer == -1)
				custDbObj.setRivCustomer(VzbVoipEnum.YesNoType.N);
			else
				custDbObj.setRivCustomer(isRIVCustomer);

			if (billingSystem > 0)
				custDbObj.setUsBillingSystem(billingSystem);
			if (emeaBillingSystem != -1)
				custDbObj.setEmeaBillingSystem(emeaBillingSystem);
			if (!"NONE".equals(orderSource) && !"".equals(orderSource))
				custDbObj.setOrderSource(orderSource);
			if (!"NONE".equals(contactFirstName)
					&& !"".equals(contactFirstName))
				custDbObj.setContactFirstName(contactFirstName);
			if (!"NONE".equals(contactLastName) && !"".equals(contactLastName))
				custDbObj.setContactLastName(contactLastName);
			if (!"NONE".equals(contactTitle) && !"".equals(contactTitle))
				custDbObj.setContactTitle(contactTitle);
			if (!"NONE".equals(contactPrimaryPhone)
					&& !"".equals(contactPrimaryPhone))
				custDbObj.setContactPriPhone(contactPrimaryPhone);
			if (!"NONE".equals(contactAltPhone) && !"".equals(contactAltPhone))
				custDbObj.setContactAltPhone(contactAltPhone);
			if (!"NONE".equals(contactFax) && !"".equals(contactFax))
				custDbObj.setContactFax(contactFax);
			if (!"NONE".equals(contactCell) && !"".equals(contactCell))
				custDbObj.setContactCell(contactCell);
			if (!"NONE".equals(contactPager) && !"".equals(contactPager))
				custDbObj.setContactPager(contactPager);
			if (!"NONE".equals(contactEmail) && !"".equals(contactEmail))
				custDbObj.setContactEmail(contactEmail);
			if (!"NONE".equals(contactAddr1) && !"".equals(contactAddr1))
				custDbObj.setContactAddr1(contactAddr1);
			if (!"NONE".equals(contactAddr2) && !"".equals(contactAddr2))
				custDbObj.setContactAddr2(contactAddr2);
			if (!"NONE".equals(contactCity) && !"".equals(contactCity))
				custDbObj.setContactCity(contactCity);
			if (!"NONE".equals(contactState) && !"".equals(contactState))
				custDbObj.setContactState(contactState);
			if (!"NONE".equals(contactZip) && !"".equals(contactZip))
				custDbObj.setContactZip(contactZip);
			if (!"NONE".equals(contactCountry) && !"".equals(contactCountry))
				custDbObj.setContactCountry(contactCountry);
			if (!"NONE".equals(billContactPriPhone)
					&& !"".equals(billContactPriPhone))
				custDbObj.setBillContactPriPhone(billContactPriPhone);
			if (!"NONE".equals(billContactAltPhone)
					&& !"".equals(billContactAltPhone))
				custDbObj.setBillContactAltPhone(billContactAltPhone);
			if (!"NONE".equals(billContactCell) && !"".equals(billContactCell))
				custDbObj.setBillContactCell(billContactCell);
			if (!"NONE".equals(billContactPager)
					&& !"".equals(billContactPager))
				custDbObj.setBillContactPager(billContactPager);
			if (!"NONE".equals(billContactEmail)
					&& !"".equals(billContactEmail))
				custDbObj.setBillContactEmail(billContactEmail);
			if (!"NONE".equals(billContactAddr1)
					&& !"".equals(billContactAddr1))
				custDbObj.setBillContactAddr1(billContactAddr1);
			if (!"NONE".equals(billContactAddr2)
					&& !"".equals(billContactAddr2))
				custDbObj.setBillContactAddr2(billContactAddr2);
			if (!"NONE".equals(billContactCity) && !"".equals(billContactCity))
				custDbObj.setBillContactCity(billContactCity);
			if (!"NONE".equals(billContactState)
					&& !"".equals(billContactState))
				custDbObj.setBillContactState(billContactState);
			if (!"NONE".equals(billContactZip) && !"".equals(billContactZip))
				custDbObj.setBillContactZip(billContactZip);
			if (!"NONE".equals(billContactCountry)
					&& !"".equals(billContactCountry))
				custDbObj.setBillContactCountry(billContactCountry);
			if (salesSegment == -1)
				custDbObj.setSalesSegment(0);
			else
				custDbObj.setSalesSegment(salesSegment);
			if (!"NONE".equals(salesRepId) && !"".equals(salesRepId))
				custDbObj.setSalesRepId(salesRepId);
			if (!"NONE".equals(salesRepName) && !"".equals(salesRepName))
				custDbObj.setSalesRepName(salesRepName);
			if (!"NONE".equals(salesRepPhone) && !"".equals(salesRepPhone))
				custDbObj.setSalesRepPhone(salesRepPhone);
			if (!"NONE".equals(salesRepEmail) && !"".equals(salesRepEmail))
				custDbObj.setSalesRepEmail(salesRepEmail);
			if (!"NONE".equals(custCorpId) && !"".equals(custCorpId))
				custDbObj.setCustCorpId(custCorpId);
			if (orderVerification == -1)
				custDbObj.setOrderVerification(0);
			else
				custDbObj.setOrderVerification(orderVerification);
			if (!"NONE".equals(supportName) && !"".equals(supportName))
				custDbObj.setSupportName(supportName);
			if (!"NONE".equals(supportPhone) && !"".equals(supportPhone))
				custDbObj.setSupportPhone(supportPhone);
			if (emeaServiceSupport > 0)
				custDbObj.setEmeaServiceSupport(emeaServiceSupport);
			if (custSensitivityLevel != null
					&& !custSensitivityLevel.equalsIgnoreCase(""))
				custDbObj.setCustSensitivityLevel(custSensitivityLevel);
			else
				custDbObj.setCustSensitivityLevel("1");
			if (custGarmStatus > 0)
				custDbObj.setCustGarmStatus(custGarmStatus);
			if (custActiveInd > 0)
				custDbObj.setActiveInd(custActiveInd);

			/* Newly added by Vijaykumar.S on (24-08-09) */
			log.info("commonCustomerId:" + commonCustomerId);
			if (!"NONE".equals(commonCustomerId)
					&& !"".equals(commonCustomerId))
				custDbObj.setCommonCustomerId(commonCustomerId);
			log.info("vpnName:" + vpnName);
			if (!"NONE".equals(vpnName) && !"".equals(vpnName))
				custDbObj.setVpnName(vpnName);

			// Jan 2011 Release changes

			if (!"NONE".equals(naspId) && !"".equals(naspId))
				custDbObj.setNaspId(naspId);

			log.info(" naspId :: " + naspId
					+ " custDbObj.getNaspId() :: " + custDbObj.getNaspId());
			
			custDbObj.setCalnetSubContractId(calnetSubContractId);							//added by z658915
			log.info(" calnetSubContractId :: " + calnetSubContractId
					+ " custDbObj.getCalnetSubContractId() :: " + custDbObj.getCalnetSubContractId());


			if (!"NONE".equals(commonCustomerName)
					&& !"".equals(commonCustomerName))
				custDbObj.setCommonCustomerName(commonCustomerName);

			if (getEnvOrderId() > 0)
				custDbObj.setEnvOrderId(getEnvOrderId());
			else
				custDbObj.setEnvOrderIdNull();
			/*
			 * if (createdBy != null && !createdBy.trim().equals(""))
			 * custDbObj.setCreatedBy(createdBy); else
			 * custDbObj.setCreatedBy("SBC_MIG");
			 */

			if (modifiedBy != null && !modifiedBy.trim().equals(""))
				custDbObj.setModifiedBy(modifiedBy);
			else
				custDbObj.setModifiedBy("SBC_MIG");
			// custDbObj.setCreationDate(new
			// Timestamp(System.currentTimeMillis()));
			custDbObj.setLastModifiedDate(new Timestamp(System
					.currentTimeMillis()));

			if (modifiedBy != null && !modifiedBy.trim().equals(""))
				custDbObj.setModifiedBy(modifiedBy);
			else
				custDbObj.setModifiedBy("SBC_MIG");
			if (custActiveInd > 0)
				custDbObj.setActiveInd(custActiveInd);
			printCustDbObj(custDbObj);

			TblCustomerQuery custQry = new TblCustomerQuery();
			custQry.whereCustomerIdEQ(getCustomerId());
			custQry.query(dbCon);
			log.info("custQry.size()====> " + custQry.size());
			if (custQry.size() > 0) {
				if (custQry.getDbBean(0).getRivCustomer() == VzbVoipEnum.YesNoType.N) {
					custDbObj.whereCustomerIdEQ(getCustomerId());
					custDbObj.updateSpByWhere(dbCon);
				} else if (custQry.getDbBean(0).getRivCustomer() == VzbVoipEnum.YesNoType.Y) {
					DBTblCustomer custDbUpdObj = new DBTblCustomer();
					if (modifiedBy != null && !modifiedBy.trim().equals(""))
						custDbUpdObj.setModifiedBy(modifiedBy);
					else
						custDbUpdObj.setModifiedBy("SBC_MIG");
					custDbUpdObj.setLastModifiedDate(new Timestamp(System
							.currentTimeMillis()));
					if (envOrderId > 0)
						custDbUpdObj.setEnvOrderId(envOrderId);

					custDbUpdObj.setSbcMigInd(1);
					custDbUpdObj.whereCustomerIdEQ(getCustomerId());
					custDbUpdObj.updateSpByWhere(dbCon);
				}
			} else {
				custDbObj.setCreationDate(new Timestamp(System
						.currentTimeMillis()));
				if (createdBy != null && !createdBy.trim().equals(""))
					custDbObj.setCreatedBy(createdBy);
				else
					custDbObj.setCreatedBy("SBC_MIG");
				custDbObj.insert(dbCon);
			}
			log.info("Customer Record added to DB.");

			setLogTrail("Customer Record added to DB.");

			entDbObj.setEnterpriseId(customerId);
			entDbObj.setSbcMigInd(1);
			if (customerType > 0)
				entDbObj.setCustType(customerType);
			if (custMarket != 0)
				entDbObj.setCustMarket(custMarket);
			else
				entDbObj.setCustMarket(VzbVoipEnum.CustMarketType.US);

			log.info(" custMarket in Enterprise during Add "
					+ entDbObj.getCustMarket());

			if (isRIVCustomer == -1)
				entDbObj.setRivCustomer(VzbVoipEnum.YesNoType.N);
			else
				entDbObj.setRivCustomer(isRIVCustomer);

			entDbObj.setPlatformIndicator(platformIndicator);
			// entDbObj.setPlatformIndicator(VzbVoipEnum.PlatformIndicator.IASA);
			if (!"NONE".equals(vmPartitionId) && !"".equals(vmPartitionId))
				entDbObj.setVmPartitionId(vmPartitionId);
			if (pubIp == -1)
				entDbObj.setPubip(0);
			else
				entDbObj.setPubip(pubIp);
			entDbObj.setOnNetInterco(onNetInterco);
			if (!"NONE".equals(sipDomain) && !"".equals(sipDomain))
				entDbObj.setSipDomain(sipDomain);
			if (asId > 0)
				entDbObj.setAsId(asId);
			entDbObj.setEntcclInd(entCclInd);
			entDbObj.setQosInd(qosInd);
			if (ieanLength > 0)
				entDbObj.setIeanLength(ieanLength);
			if (!"NONE".equals(vnetCorpId) && !"".equals(vnetCorpId))
				entDbObj.setVnetCorpId(vnetCorpId);
			if (!"NONE".equals(contractInd) && !"".equals(contractInd))
				entDbObj.setContractInd(contractInd);
			if (!"NONE".equals(agencyHierCode) && !"".equals(agencyHierCode))
				entDbObj.setAgencyHierCode(agencyHierCode);
			if (!"NONE".equals(xrefCustomerId) && !"".equals(xrefCustomerId))
				entDbObj.setXrefCustomerId(xrefCustomerId);
			if (platformIndicator == VzbVoipEnum.Platform.IASA) {
				entDbObj.setCallingPlanId(0);
				setLogTrail("CallingPlan:0 mapped to enterprise.");
			}
			if (platformIndicator == VzbVoipEnum.Platform.ICP) {
				entDbObj.setCallingPlanId(1);
				setLogTrail("CallingPlan:1 mapped to enterprise.");
			}
			entDbObj.setActiveInd(entActiveInd);
			entDbObj.setBsBlockInd(bsBlockInd);

			if (!"NONE".equals(sbcActivationSystem)
					&& !"".equals(sbcActivationSystem))
				entDbObj.setSbcActivationSystem(sbcActivationSystem);
			if (getEnvOrderId() > 0)
				entDbObj.setEnvOrderId(getEnvOrderId());
			else
				entDbObj.setEnvOrderIdNull();

			// 53938.AA Business Continuity Ph 1 - changes for july 2011
			entDbObj.setLorFlag(lorFlag);

			/*
			 * if (createdBy != null && !createdBy.trim().equals(""))
			 * entDbObj.setCreatedBy(createdBy); else
			 * entDbObj.setCreatedBy("SBC_MIG");
			 */
			if (modifiedBy != null && !modifiedBy.trim().equals(""))
				entDbObj.setModifiedBy(modifiedBy);
			else
				entDbObj.setModifiedBy("SBC_MIG");
			// entDbObj.setCreationDate(new
			// Timestamp(System.currentTimeMillis()));
			entDbObj.setLastModifiedDate(new Timestamp(System
					.currentTimeMillis()));
			printEntDbObj(entDbObj);

			TblEnterpriseQuery entQry = new TblEnterpriseQuery();
			entQry.whereEnterpriseIdEQ(getCustomerId());
			entQry.query(dbCon);
			log.info("custQry.size()====> " + entQry.size());

			if (entQry.size() > 0) {
				if (entQry.getDbBean(0).getRivCustomer() == VzbVoipEnum.YesNoType.N) {
					if (entQry.getDbBean(0).getSbcActivationSystem()
							.equals("ESAP"))
						entDbObj.setSbcActivationSystem("ESAP");
					entDbObj.whereEnterpriseIdEQ(getCustomerId());
					entDbObj.updateSpByWhere(dbCon);
				} else if (entQry.getDbBean(0).getRivCustomer() == VzbVoipEnum.YesNoType.Y) {
					DBTblEnterprise entDbUpdObj = new DBTblEnterprise();
					entDbUpdObj.setSbcMigInd(1);
					entDbUpdObj.setLastModifiedDate(new Timestamp(System
							.currentTimeMillis()));
					if (envOrderId > 0)
						entDbUpdObj.setEnvOrderId(envOrderId);
					entDbUpdObj.whereEnterpriseIdEQ(getCustomerId());
					entDbUpdObj.updateSpByWhere(dbCon);
				}
			} else {
				entDbObj.setCreationDate(new Timestamp(System
						.currentTimeMillis()));
				if (createdBy != null && !createdBy.trim().equals(""))
					entDbObj.setCreatedBy(createdBy);
				else
					entDbObj.setCreatedBy("SBC_MIG");
				entDbObj.insert(dbCon);
			}

			setLogTrail("Enterprise Record added to DB.");

		} catch (SQLException s) {
			setStatus(InvErrorCode.DB_EXCEPTION);
			s.printStackTrace();
			return false;
		}
		setStatus(InvErrorCode.SUCCESS);
		return true;

	}

	public String getCustIdSeqNextVal() throws SQLException {
		log.info("Entering getCustIdSeqNextVal");
		String custId = "0";

		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			ps = dbCon
					.prepareStatement("SELECT CUSTOMER_ID_SEQ.NEXTVAL FROM DUAL");
			rs = ps.executeQuery();
			if (rs.next())
				custId = rs.getString(1);
		} catch (SQLException e) {
			throw e;
		} finally {
			try {
				if (null != rs)
					rs.close();
				if (null != ps)
					ps.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return custId;
	}

	public boolean addShellCustomersforAPAC() throws Exception {
		try {
			DBTblCustomer custDbObj = new DBTblCustomer();
			// Get the SequenceId before the insert statement.
			// custDbObj.setCustomerId(customerId);
			custDbObj.setRegionId(regionId);
			custDbObj.setCustSensitivityLevel(custSensitivityLevel);
			custDbObj.setActiveInd(custActiveInd);

			if (!"NONE".equals(customerName) && !"".equals(customerName)) {

				if (!isEnterpriseNameExists(customerName)) {
					throw new Exception("Customer Name Already Exists "
							+ accountName);
				}
				custDbObj.setCustomerName(customerName);
			} else {
				throw new Exception("Customer Name Not Found");
			}

			if (!"NONE".equals(accountName) && !"".equals(accountName)) {
				custDbObj.setAccountName(accountName.trim());
			}

			custDbObj.setRivCustomer(isRIVCustomer);

			if (!"NONE".equals(contactFirstName)
					&& !"".equals(contactFirstName))
				custDbObj.setContactFirstName(contactFirstName);
			if (!"NONE".equals(contactLastName) && !"".equals(contactLastName))
				custDbObj.setContactLastName(contactLastName);
			if (!"NONE".equals(contactTitle) && !"".equals(contactTitle))
				custDbObj.setContactTitle(contactTitle);
			if (!"NONE".equals(contactPrimaryPhone)
					&& !"".equals(contactPrimaryPhone))
				custDbObj.setContactPriPhone(contactPrimaryPhone);
			if (!"NONE".equals(contactAltPhone) && !"".equals(contactAltPhone))
				custDbObj.setContactAltPhone(contactAltPhone);
			if (!"NONE".equals(contactFax) && !"".equals(contactFax))
				custDbObj.setContactFax(contactFax);
			if (!"NONE".equals(contactCell) && !"".equals(contactCell))
				custDbObj.setContactCell(contactCell);
			if (!"NONE".equals(contactPager) && !"".equals(contactPager))
				custDbObj.setContactPager(contactPager);
			if (!"NONE".equals(contactEmail) && !"".equals(contactEmail))
				custDbObj.setContactEmail(contactEmail);
			if (!"NONE".equals(contactAddr1) && !"".equals(contactAddr1))
				custDbObj.setContactAddr1(contactAddr1);
			if (!"NONE".equals(contactAddr2) && !"".equals(contactAddr2))
				custDbObj.setContactAddr2(contactAddr2);
			if (!"NONE".equals(contactCity) && !"".equals(contactCity))
				custDbObj.setContactCity(contactCity);
			if (!"NONE".equals(contactState) && !"".equals(contactState))
				custDbObj.setContactState(contactState);
			if (!"NONE".equals(contactZip) && !"".equals(contactZip))
				custDbObj.setContactZip(contactZip);
			if (!"NONE".equals(contactCountry) && !"".equals(contactCountry))
				custDbObj.setContactCountry(contactCountry);
			if (!"NONE".equals(billContactPriPhone)
					&& !"".equals(billContactPriPhone))
				custDbObj.setBillContactPriPhone(billContactPriPhone);
			if (!"NONE".equals(billContactAltPhone)
					&& !"".equals(billContactAltPhone))
				custDbObj.setBillContactAltPhone(billContactAltPhone);
			if (!"NONE".equals(billContactCell) && !"".equals(billContactCell))
				custDbObj.setBillContactCell(billContactCell);
			if (!"NONE".equals(billContactPager)
					&& !"".equals(billContactPager))
				custDbObj.setBillContactPager(billContactPager);
			if (!"NONE".equals(billContactEmail)
					&& !"".equals(billContactEmail))
				custDbObj.setBillContactEmail(billContactEmail);
			if (!"NONE".equals(billContactAddr1)
					&& !"".equals(billContactAddr1))
				custDbObj.setBillContactAddr1(billContactAddr1);
			if (!"NONE".equals(billContactAddr2)
					&& !"".equals(billContactAddr2))
				custDbObj.setBillContactAddr2(billContactAddr2);
			if (!"NONE".equals(billContactCity) && !"".equals(billContactCity))
				custDbObj.setBillContactCity(billContactCity);
			if (!"NONE".equals(billContactState)
					&& !"".equals(billContactState))
				custDbObj.setBillContactState(billContactState);
			if (!"NONE".equals(billContactZip) && !"".equals(billContactZip))
				custDbObj.setBillContactZip(billContactZip);
			if (!"NONE".equals(billContactCountry)
					&& !"".equals(billContactCountry))
				custDbObj.setBillContactCountry(billContactCountry);
			if (salesSegment == -1)
				custDbObj.setSalesSegment(0);
			else
				custDbObj.setSalesSegment(salesSegment);
			if (!"NONE".equals(salesRepId) && !"".equals(salesRepId))
				custDbObj.setSalesRepId(salesRepId);
			if (!"NONE".equals(salesRepName) && !"".equals(salesRepName))
				custDbObj.setSalesRepName(salesRepName);
			if (!"NONE".equals(salesRepPhone) && !"".equals(salesRepPhone))
				custDbObj.setSalesRepPhone(salesRepPhone);
			if (!"NONE".equals(salesRepEmail) && !"".equals(salesRepEmail))
				custDbObj.setSalesRepEmail(salesRepEmail);
			if (!"NONE".equals(naspId) && !"".equals(naspId))
				custDbObj.setNaspId(naspId);
			if (!"NONE".equals(supportName) && !"".equals(supportName))
				custDbObj.setSupportName(supportName);
			if (!"NONE".equals(supportPhone) && !"".equals(supportPhone))
				custDbObj.setSupportPhone(supportPhone);

			custDbObj.setModifiedBy("Opro");
			if (getEnvOrderId() > 0)
				custDbObj.setEnvOrderId(getEnvOrderId());
			else
				custDbObj.setEnvOrderIdNull();
			if (createdBy != null && !"".equals(createdBy))
				custDbObj.setCreatedBy(createdBy);
			else
				custDbObj.setCreatedBy("ESAP_INV");
			if (modifiedBy != null && !"".equals(modifiedBy))
				custDbObj.setModifiedBy(modifiedBy);
			else
				custDbObj.setModifiedBy("ESAP_INV");
			custDbObj.setLastModifiedDate(new Timestamp(System
					.currentTimeMillis()));
			custDbObj
					.setCreationDate(new Timestamp(System.currentTimeMillis()));

			setCustomerId(getCustIdSeqNextVal());
			custDbObj.setCustomerId(getCustomerId());
			

			custDbObj.insert(dbCon);
		} catch (SQLException s) {
			setStatus(InvErrorCode.DB_EXCEPTION);
			s.printStackTrace();
			// setStatusDesc("DB_FAILURE in addCustomer Enterprise");
			return false;
		}
		setStatus(InvErrorCode.SUCCESS);
		// setStatusDesc("Successfully inserted customer into the DB");
		return true;
	}

	// IR #1479823 throws Exception
	public boolean createApacShellCustomer() throws Exception {
		log.info("Entering createApacShellCustomer");
		try {
			// setCustomerId(getCustIdSeqNextVal());
			setRegionId(VzbVoipEnum.RegionType.APAC);
			setCustSensitivityLevel("1");
			setCustActiveInd(VzbVoipEnum.ActiveInd.APAC);
			setIsRIVCustomer(VzbVoipEnum.YesNoType.Y);
			if (addShellCustomersforAPAC() != true) {
				log.info("Failed to Created Shell Customer For APAC");
				return false;
			} else
				log.info("Created Shell Customer Id ["
						+ getCustomerId() + "] for APAC");
		} catch (SQLException s) {
			setStatus(InvErrorCode.DB_EXCEPTION);
			s.printStackTrace();
			// return false;
			throw s;
		} catch (Exception e) {

			e.printStackTrace();
			setStatus(InvErrorCode.ERROR_GET_ENTERPRISE);
			log.info(" Message " + e.getMessage());
			if (e.getMessage().indexOf("Customer Name Already Exists") != -1) {
				setStatus(InvErrorCode.CUSTOMER_NAME_ALREADY_EXISTS);
			} else if (e.getMessage().indexOf("Customer Name Not Found") != -1) {
				setStatus(InvErrorCode.CUSTOMER_NAME_NOT_FOUND);
			}
			// return false;
			throw e;
		}
		setLogTrail("Successfully created Shell Customer Id ["
				+ getCustomerId() + "] for APAC");
		return true;
	}

	public boolean addCustomer() {
		try {
			DBTblCustomer custDbObj = new DBTblCustomer();
			custDbObj.setCustomerId(customerId);
			custDbObj.setCustomerName(customerName.trim());
			custDbObj.setAccountName(accountName);
			custDbObj.setRegionId(regionId);
			custDbObj.setProductType(productType);
			custDbObj.setUsBillingSystem(billingSystem);
			custDbObj.setEmeaBillingSystem(emeaBillingSystem);
			custDbObj.setOrderSource(orderSource);
			custDbObj.setContactFirstName(contactFirstName);
			custDbObj.setContactLastName(contactLastName);
			custDbObj.setContactTitle(contactTitle);
			custDbObj.setContactPriPhone(contactPrimaryPhone);
			custDbObj.setContactAltPhone(contactAltPhone);
			custDbObj.setContactFax(contactFax);
			custDbObj.setContactCell(contactCell);
			custDbObj.setContactPager(contactPager);
			custDbObj.setContactEmail(contactEmail);
			custDbObj.setContactAddr1(contactAddr1);
			custDbObj.setContactAddr2(contactAddr2);
			custDbObj.setContactCity(contactCity);
			custDbObj.setContactState(contactState);
			custDbObj.setContactZip(contactZip);
			custDbObj.setContactCountry(contactCountry);
			custDbObj.setBillContactPriPhone(billContactPriPhone);
			custDbObj.setBillContactAltPhone(billContactAltPhone);
			custDbObj.setBillContactCell(billContactCell);
			custDbObj.setBillContactPager(billContactPager);
			custDbObj.setBillContactEmail(billContactEmail);
			custDbObj.setBillContactAddr1(billContactAddr1);
			custDbObj.setBillContactAddr2(billContactAddr2);
			custDbObj.setBillContactCity(billContactCity);
			custDbObj.setBillContactState(billContactState);
			custDbObj.setBillContactZip(billContactZip);
			custDbObj.setBillContactCountry(billContactCountry);
			custDbObj.setSalesSegment(salesSegment);
			custDbObj.setSalesRepId(salesRepId);
			custDbObj.setSalesRepName(salesRepName);
			custDbObj.setSalesRepPhone(salesRepPhone);
			custDbObj.setSalesRepEmail(salesRepEmail);
			custDbObj.setCustCorpId(custCorpId);
			custDbObj.setOrderVerification(orderVerification);
			custDbObj.setSupportName(supportName);
			custDbObj.setSupportPhone(supportPhone);
			custDbObj.setEmeaServiceSupport(emeaServiceSupport);
			custDbObj.setCustSensitivityLevel(custSensitivityLevel);
			custDbObj.setCustGarmStatus(custGarmStatus);
			custDbObj.setEnterpriseTrunkingType(enterpriseTrunkingType);
			custDbObj.setE2eiSensitivityLevel(e2eiSensitvityLevel);
			custDbObj.setActiveInd(custActiveInd);
			/* Newly added by Vijaykumar.S on (24-08-09) */
			custDbObj.setCommonCustomerId(commonCustomerId);
			custDbObj.setVpnName(vpnName);
			// Jan 2011 Release changes
			custDbObj.setNaspId(naspId);
			custDbObj.setCommonCustomerName(commonCustomerName);

			// custDbObj.setCreatedBy("Opro");
			// custDbObj.setModifiedBy("Opro");
			if (getEnvOrderId() > 0)
				custDbObj.setEnvOrderId(getEnvOrderId());
			else
				custDbObj.setEnvOrderIdNull();
			if (createdBy != null && !"".equals(createdBy))
				custDbObj.setCreatedBy(createdBy);
			else
				custDbObj.setCreatedBy("ESAP_INV");
			if (modifiedBy != null && !"".equals(modifiedBy))
				custDbObj.setModifiedBy(modifiedBy);
			else
				custDbObj.setModifiedBy("ESAP_INV");
			custDbObj.setLastModifiedDate(new Timestamp(System
					.currentTimeMillis()));
			custDbObj
					.setCreationDate(new Timestamp(System.currentTimeMillis()));
			custDbObj.insert(dbCon);
		} catch (SQLException s) {
			setStatus(InvErrorCode.DB_EXCEPTION);
			s.printStackTrace();
			// setStatusDesc("DB_FAILURE in addCustomer Enterprise");
			return false;
		}
		setStatus(InvErrorCode.SUCCESS);
		// setStatusDesc("Successfully inserted customer into the DB");
		return true;
	}

	public boolean addEnterprise() {
		try {
			int defaultAuthSerId = 0;
			int authSerId = 0;
			if (platformIndicator == VzbVoipEnum.Platform.IASA)
				defaultAuthSerId = 0;
			else if (platformIndicator == VzbVoipEnum.Platform.ICP)
				defaultAuthSerId = 1;
			TblAuthServicesQuery authQry = new TblAuthServicesQuery();
			authQry.whereAuthServiceIdEQ(defaultAuthSerId);
			log.info("Before authQry addEnterprise");
			authQry.query(dbCon);
			log.info("Before authQry addEnterprise");
			if (authQry.size() > 0) {
				DBTblAuthServices authServicesDbBean = new DBTblAuthServices();
				authSerId = getAuthServiceIdSeqNextVal(dbCon);
				for (int i = 0; i < authQry.size(); i++) {
					authServicesDbBean.copyFromBean(authQry.getDbBean(i));
					authServicesDbBean.setAuthServiceId(authSerId);
					// authServicesDbBean.setModifiedBy("Opro");
					if (getEnvOrderId() > 0)
						authServicesDbBean.setEnvOrderId(getEnvOrderId());
					else
						authServicesDbBean.setEnvOrderIdNull();
					if (createdBy != null && !"".equals(createdBy))
						authServicesDbBean.setCreatedBy(createdBy);
					else
						authServicesDbBean.setCreatedBy("ESAP_INV");
					if (modifiedBy != null && !"".equals(modifiedBy))
						authServicesDbBean.setModifiedBy(modifiedBy);
					else
						authServicesDbBean.setModifiedBy("ESAP_INV");
					authServicesDbBean.setCreationDate(new Timestamp(System
							.currentTimeMillis()));
					authServicesDbBean.setLastModifiedDate(new Timestamp(System
							.currentTimeMillis()));
					authServicesDbBean.insert(dbCon);
				}
			}
			DBTblEnterprise entDbObj = new DBTblEnterprise();
			entDbObj.setEnterpriseId(customerId);
			entDbObj.setCustType(customerType);
			entDbObj.setCustMarket(custMarket);
			entDbObj.setPlatformIndicator(platformIndicator);
			entDbObj.setVmPartitionId(vmPartitionId);
			entDbObj.setPubip(pubIp);
			entDbObj.setOnNetInterco(onNetInterco);
			entDbObj.setSipDomain(sipDomain);
			entDbObj.setAsId(asId);
			entDbObj.setEntcclInd(entCclInd);
			entDbObj.setQosInd(qosInd);
			entDbObj.setIeanLength(ieanLength);
			entDbObj.setVnetCorpId(vnetCorpId);
			entDbObj.setContractInd(contractInd);
			entDbObj.setAgencyHierCode(agencyHierCode);
			entDbObj.setXrefCustomerId(xrefCustomerId);
			entDbObj.setApprovedCcl(approvedCcl);
			entDbObj.setEntTrunkCclSum(entTrunkCclSum);
			entDbObj.setCustPriceBookId(custPriceBookId);
			entDbObj.setContractId(contractId);
			entDbObj.setQuoteId(quoteId);
			entDbObj.setCatalogueReferenceTime(catalogueReferenceTime);
			entDbObj.setDesignId(designId);
			entDbObj.setEntCumCcl(entCumCcl);
			// TODO table missing in schema
			if (callingPlanId > 0)
				entDbObj.setCallingPlanId(callingPlanId);
			else
				entDbObj.setCallingPlanIdNull();

			entDbObj.setAuthServicesId(authSerId);
			entDbObj.setActiveInd(entActiveInd);
			entDbObj.setBsBlockInd(bsBlockInd);
			// entDbObj.setCreatedBy("Opro");
			// entDbObj.setModifiedBy("Opro");

			if (getEnvOrderId() > 0)
				entDbObj.setEnvOrderId(getEnvOrderId());
			else
				entDbObj.setEnvOrderIdNull();
			if (createdBy != null && !createdBy.trim().equals(""))
				entDbObj.setCreatedBy(createdBy);
			else
				entDbObj.setCreatedBy("ESAP_INV");
			if (modifiedBy != null && !modifiedBy.trim().equals(""))
				entDbObj.setModifiedBy(modifiedBy);
			else
				entDbObj.setModifiedBy("ESAP_INV");
			entDbObj.setCreationDate(new Timestamp(System.currentTimeMillis()));
			entDbObj.setLastModifiedDate(new Timestamp(System
					.currentTimeMillis()));
			entDbObj.insert(dbCon);
		} catch (SQLException s) {
			setStatus(InvErrorCode.DB_EXCEPTION);
			s.printStackTrace();
			// setStatusDesc("DB_FAILURE in addToDB Enterprise");
			return false;
		}
		setStatus(InvErrorCode.SUCCESS);
		// setStatusDesc("Successfully inserted enterprise into the DB");
		return true;
	}

	public boolean deleteGUITempDataFromDB() throws SQLException, Exception {
		// try {
		if (getCustomerId() == null || getCustomerId().equalsIgnoreCase("")) {
			log.info("Invalid Input");
			setStatus(InvErrorCode.INVALID_INPUT);
			return false;
		}

		DBTblGuiCustomer customerDb = new DBTblGuiCustomer();
		customerDb.whereGuiCustomerIdEQ(getCustomerId());
		customerDb.deleteByWhere(dbCon);

		DBTblGuiAuthServices authDb = new DBTblGuiAuthServices();
		authDb.whereEnterpriseIdEQ(getCustomerId());
		authDb.deleteByWhere(dbCon);

		DBTblGuiDialPlan dialPlanDb = new DBTblGuiDialPlan();
		dialPlanDb.whereEnterpriseIdEQ(getCustomerId());
		dialPlanDb.deleteByWhere(dbCon);

		DBTblGuiSipDomain sipDomainDb = new DBTblGuiSipDomain();
		sipDomainDb.whereEnterpriseIdEQ(getCustomerId());
		sipDomainDb.deleteByWhere(dbCon);

		DBTblGuiTerminatingRouting termDb = new DBTblGuiTerminatingRouting();
		termDb.whereEnterpriseIdEQ(getCustomerId());
		termDb.deleteByWhere(dbCon);

		DBTblGuiPrefixRouting preDb = new DBTblGuiPrefixRouting();
		preDb.whereEnterpriseIdEQ(getCustomerId());
		preDb.deleteByWhere(dbCon);

		DBTblGuiCallingPlans callDb = new DBTblGuiCallingPlans();
		callDb.whereEnterpriseIdEQ(getCustomerId());
		callDb.deleteByWhere(dbCon);

		// TODO if ( getDevicesForEnterprise() == true )
		// Deleting Enterprise Admin Entry - Added by Vijaykumar S
		// TblEnterpriseAdminQuery entAdminQry = new TblEnterpriseAdminQuery();
		// Delete department
		// DigitString digitStringObj = new DigitString(dbCon);

		/*
		 * } catch (SQLException s) { s.printStackTrace();
		 * setStatus(InvErrorCode.DB_EXCEPTION);
		 * log.info("DB_FAILURE in deleteFromDB Enterprise"); return
		 * false; }
		 */
		setStatus(InvErrorCode.SUCCESS);
		return true;

	}

	

	/**
	 * The method to check if there is any Location associated to the
	 * Enterprise.
	 * 
	 * @return true Location associated to the Enterprise. false No Location
	 *         associated to the Enterprise.
	 * @throws SQLException
	 *             Any DB Error occurs
	 * @author banala
	 */
	private boolean isLocationAssociatedToEnterprise() throws SQLException {
		TblLocationQuery locQry = new TblLocationQuery();

		String whereClause = "where enterprise_id =\'" + getEnterpriseId()
				+ "\' and active_ind != 0";
		locQry.queryByWhere(dbCon, whereClause);

		if (locQry.size() > 0) {
			return true;
		}
		return false;
	}

	

	private DBTblEnterprise getEnterpriseToUpdate() {
		DBTblEnterprise entrepriseDbBean = new DBTblEnterprise();
		/*
		 * Create a new instance of LocationBean. The new instance would hold
		 * default values for the all the Location fields.
		 */
		EnterpriseBean defaultEnterpriseBean = new EnterpriseBean();
		Enterprise inputEnterprise = this;
		entrepriseDbBean.setEnterpriseId(customerId);
		if (inputEnterprise.getCustomerType() != defaultEnterpriseBean
				.getCustomerType()) {
			if (!"".equals(inputEnterprise.getCustomerType()))
				entrepriseDbBean.setCustType(inputEnterprise.getCustomerType());
			else
				entrepriseDbBean.setCustTypeNull();
		}

		if (inputEnterprise.getUsLdAndLocalBestPool() != defaultEnterpriseBean
				.getUsLdAndLocalBestPool()) {
			entrepriseDbBean.setUsLdAndLocalBestPool(inputEnterprise
					.getUsLdAndLocalBestPool());
			log.info("US AD LOCAL "
					+ entrepriseDbBean.getUsLdAndLocalBestPool());
		}

		if (inputEnterprise.getUsLdOnlyBestPool() != defaultEnterpriseBean
				.getUsLdOnlyBestPool()) {
			entrepriseDbBean.setUsLdOnlyBestPool(inputEnterprise
					.getUsLdOnlyBestPool());
			log.info("US ld only "
					+ entrepriseDbBean.getUsLdOnlyBestPool());
		}

		if (inputEnterprise.getEmeaApacBestPool() != defaultEnterpriseBean
				.getEmeaApacBestPool()) {
			entrepriseDbBean.setEmeaApacBestPool(inputEnterprise
					.getEmeaApacBestPool());
			log.info("emea ld only "
					+ entrepriseDbBean.getEmeaApacBestPool());
		}

		if (inputEnterprise.getUsLdAndLocalBestPlusPool() != defaultEnterpriseBean
				.getUsLdAndLocalBestPlusPool()) {
			entrepriseDbBean.setUsLdAndLocalBestPlusPool(inputEnterprise
					.getUsLdAndLocalBestPlusPool());
			log.info("US AD LOCAL "
					+ entrepriseDbBean.getUsLdAndLocalBestPlusPool());
		}

		if (inputEnterprise.getUsLdOnlyBestPlusPool() != defaultEnterpriseBean
				.getUsLdOnlyBestPlusPool()) {
			entrepriseDbBean.setUsLdOnlyBestPlusPool(inputEnterprise
					.getUsLdOnlyBestPlusPool());
			log.info("US ld only "
					+ entrepriseDbBean.getUsLdOnlyBestPlusPool());
		}

		if (inputEnterprise.getEmeaApacBestPlusPool() != defaultEnterpriseBean
				.getEmeaApacBestPlusPool()) {
			entrepriseDbBean.setEmeaApacBestPlusPool(inputEnterprise
					.getEmeaApacBestPlusPool());
			log.info("emea ld only "
					+ entrepriseDbBean.getEmeaApacBestPlusPool());
		}

		if (inputEnterprise.getEntTrunkCclSum() != defaultEnterpriseBean
				.getEntTrunkCclSum()) {
			entrepriseDbBean.setEntTrunkCclSum(inputEnterprise
					.getEntTrunkCclSum());
			log.info("EntTrunkCclSum "
					+ entrepriseDbBean.getEntTrunkCclSum());
		}

		if (inputEnterprise.getApprovedCcl() != defaultEnterpriseBean
				.getApprovedCcl()) {
			entrepriseDbBean.setApprovedCcl(inputEnterprise.getApprovedCcl());
			log.info("Approved Ccl = "
					+ entrepriseDbBean.getApprovedCcl());
		}

		if (inputEnterprise.getCustMarket() != defaultEnterpriseBean
				.getCustMarket()) {
			entrepriseDbBean.setCustMarket(inputEnterprise.getCustMarket());
		}
		log.info(" entrepriseDbBean.getCustMarket "
				+ entrepriseDbBean.getCustMarket());
		if (inputEnterprise.getIeanLength() != defaultEnterpriseBean
				.getIeanLength()) {
			entrepriseDbBean.setIeanLength(inputEnterprise.getIeanLength());
		}

		if (inputEnterprise.getPlatformIndicator() != defaultEnterpriseBean
				.getPlatformIndicator()) {
			entrepriseDbBean.setPlatformIndicator(inputEnterprise
					.getPlatformIndicator());
		}

		if (inputEnterprise.getVmPartitionId() != null
				&& !inputEnterprise.getVmPartitionId().equals(
						defaultEnterpriseBean.getVmPartitionId())) {
			if (!"".equals(inputEnterprise.getCustomerType()))
				entrepriseDbBean.setVmPartitionId(inputEnterprise
						.getVmPartitionId());
			else
				entrepriseDbBean.setVmPartitionIdNull();
		}
		if (inputEnterprise.getPubIp() != defaultEnterpriseBean.getPubIp()) {
			entrepriseDbBean.setPubip(inputEnterprise.getPubIp());
		}

		if (inputEnterprise.getOnNetInterco() != defaultEnterpriseBean
				.getOnNetInterco()) {
			entrepriseDbBean.setOnNetInterco(inputEnterprise.getOnNetInterco());
		}

		log.info("inputEnterprise.getSbcActivationSystem()---> "
				+ inputEnterprise.getSbcActivationSystem());
		System.out
				.println("defaultEnterpriseBean.getSbcActivationSystem()---> "
						+ defaultEnterpriseBean.getSbcActivationSystem());

		if (inputEnterprise.getSbcActivationSystem() != null
				&& !inputEnterprise.getSbcActivationSystem().equals(
						defaultEnterpriseBean.getSbcActivationSystem())) {
			entrepriseDbBean.setSbcActivationSystem(inputEnterprise
					.getSbcActivationSystem());
		}

		// 53938.AA Business Continuity Ph 1 - changes for july 2011
		// IR #2247486 start
		// INV not getting updated with LOR Status to N even after getting it
		// disabled
		// if (inputEnterprise.getLorFlag() != null){
		if (inputEnterprise.getLorFlag() != null
				&& !inputEnterprise.getLorFlag().equals(
						defaultEnterpriseBean.getLorFlag())) {
			entrepriseDbBean.setLorFlag(inputEnterprise.getLorFlag());
		}
		if (inputEnterprise.getLorId() != null
				&& !inputEnterprise.getLorId().equals(
						defaultEnterpriseBean.getLorId())) {
			entrepriseDbBean.setLorId(inputEnterprise.getLorId());
		}
		// IR #2247486 end

		if (inputEnterprise.getSipDomain() != null
				&& !inputEnterprise.getSipDomain().equals(
						defaultEnterpriseBean.getSipDomain())) {
			if (!"".equals(inputEnterprise.getSipDomain()))
				entrepriseDbBean.setSipDomain(inputEnterprise.getSipDomain());
			else
				entrepriseDbBean.setSipDomainNull();
		}

		if (inputEnterprise.getAsId() != defaultEnterpriseBean.getAsId()) {
			if (inputEnterprise.getAsId() != 0)
				entrepriseDbBean.setAsId(inputEnterprise.getAsId());
			else
				entrepriseDbBean.setAsIdNull();
		}

		if (inputEnterprise.getEntCclInd() != defaultEnterpriseBean
				.getEntCclInd()) {
			entrepriseDbBean.setEntcclInd(inputEnterprise.getEntCclInd());
		}

		if (inputEnterprise.getQosInd() != defaultEnterpriseBean.getQosInd()) {
			entrepriseDbBean.setQosInd(inputEnterprise.getQosInd());
		}

		if (inputEnterprise.getVnetCorpId() != null
				&& !inputEnterprise.getVnetCorpId().equals(
						defaultEnterpriseBean.getVnetCorpId())) {
			if (!"".equals(inputEnterprise.getVnetCorpId()))
				entrepriseDbBean.setVnetCorpId(inputEnterprise.getVnetCorpId());
			else
				entrepriseDbBean.setVnetCorpIdNull();
		}

		if (inputEnterprise.getContractInd() != null
				&& !inputEnterprise.getContractInd().equals(
						defaultEnterpriseBean.getContractInd())) {
			if (!"".equals(inputEnterprise.getContractInd()))
				entrepriseDbBean.setContractInd(inputEnterprise
						.getContractInd());
			else
				entrepriseDbBean.setContractIndNull();
		}

		if (inputEnterprise.getAgencyHierCode() != null
				&& !inputEnterprise.getAgencyHierCode().equals(
						defaultEnterpriseBean.getAgencyHierCode())) {
			if (!"".equals(inputEnterprise.getAgencyHierCode()))
				entrepriseDbBean.setAgencyHierCode(inputEnterprise
						.getAgencyHierCode());
			else
				entrepriseDbBean.setAgencyHierCodeNull();
		}

		if (inputEnterprise.getXrefCustomerId() != null
				&& !inputEnterprise.getXrefCustomerId().equals(
						defaultEnterpriseBean.getXrefCustomerId())) {
			if (!"".equals(inputEnterprise.getXrefCustomerId()))
				entrepriseDbBean.setXrefCustomerId(inputEnterprise
						.getXrefCustomerId());
			else
				entrepriseDbBean.setXrefCustomerIdNull();
		}

		if (inputEnterprise.getCallingPlanId() != defaultEnterpriseBean
				.getCallingPlanId()) {
			if (inputEnterprise.getCallingPlanId() != 0)
				entrepriseDbBean.setCallingPlanId(inputEnterprise
						.getCallingPlanId());
			else
				entrepriseDbBean.setCallingPlanIdNull();

		}

		if (inputEnterprise.getAuthServicesId() != defaultEnterpriseBean
				.getAuthServicesId()) {
			if (inputEnterprise.getAuthServicesId() != 0)
				entrepriseDbBean.setAuthServicesId(inputEnterprise
						.getAuthServicesId());
			else
				entrepriseDbBean.setAuthServicesIdNull();
		}

		if (inputEnterprise.getEntActiveInd() != defaultEnterpriseBean
				.getEntActiveInd()) {
			if (inputEnterprise.getEntActiveInd() != 0)
				entrepriseDbBean
						.setActiveInd(inputEnterprise.getEntActiveInd());
			else
				entrepriseDbBean.setActiveIndNull();
		}

		if (inputEnterprise.getBsBlockInd() != defaultEnterpriseBean
				.getBsBlockInd()) {
			entrepriseDbBean.setBsBlockInd(inputEnterprise.getBsBlockInd());
		}
		if (inputEnterprise.getEnvOrderId() != defaultEnterpriseBean
				.getEnvOrderId()) {
			entrepriseDbBean.setEnvOrderId(inputEnterprise.getEnvOrderId());
		}
		if (inputEnterprise.getModifiedBy() != null
				&& inputEnterprise.getModifiedBy().trim() != "")
			entrepriseDbBean.setModifiedBy(inputEnterprise.getModifiedBy());
		else
			entrepriseDbBean.setModifiedBy("ESAP_INV");
		entrepriseDbBean.setLastModifiedDate(new Timestamp(System
				.currentTimeMillis()));

		if (inputEnterprise.getHybridInd() != defaultEnterpriseBean
				.getHybridInd()) {
			entrepriseDbBean.setHybridInd(inputEnterprise.getHybridInd());
		}

		if (inputEnterprise.getCustPriceBookId() != null
				&& !inputEnterprise.getCustPriceBookId().equals(
						defaultEnterpriseBean.getCustPriceBookId())) {
			if (!"".equals(inputEnterprise.getCustPriceBookId()))
				entrepriseDbBean.setCustPriceBookId(inputEnterprise
						.getCustPriceBookId());
			else
				entrepriseDbBean.setCustPriceBookIdNull();
		}

		if (inputEnterprise.getContractId() != null
				&& !inputEnterprise.getContractId().equals(
						defaultEnterpriseBean.getContractId())) {
			if (!"".equals(inputEnterprise.getContractId()))
				entrepriseDbBean.setContractId(inputEnterprise.getContractId());
			else
				entrepriseDbBean.setContractIdNull();
		}

		if (inputEnterprise.getQuoteId() != null
				&& !inputEnterprise.getQuoteId().equals(
						defaultEnterpriseBean.getQuoteId())) {
			if (!"".equals(inputEnterprise.getQuoteId()))
				entrepriseDbBean.setQuoteId(inputEnterprise.getQuoteId());
			else
				entrepriseDbBean.setQuoteIdNull();
		}
		if (inputEnterprise.getCatalogueReferenceTime() != null
				&& !inputEnterprise.getCatalogueReferenceTime().equals(
						defaultEnterpriseBean.getCatalogueReferenceTime())) {
			if (!"".equals(inputEnterprise.getCatalogueReferenceTime()))
				entrepriseDbBean.setCatalogueReferenceTime(inputEnterprise
						.getCatalogueReferenceTime());
			else
				entrepriseDbBean.setCatalogueReferenceTimeNull();
		}
		if (inputEnterprise.getDesignId() != defaultEnterpriseBean
				.getDesignId()) {
			entrepriseDbBean.setDesignId(inputEnterprise.getDesignId());
		}
		
		if (inputEnterprise.getEntCumCcl() != defaultEnterpriseBean
				.getEntCumCcl()) {
			entrepriseDbBean.setEntCumCcl(inputEnterprise
					.getEntCumCcl());
			log.info("EntCumCclSum "
					+ entrepriseDbBean.getEntCumCcl());
		}
		
		return entrepriseDbBean;
	}

	private DBTblCustomer getCustomerToUpdate() {
		DBTblCustomer customerDbBean = new DBTblCustomer();
		/*
		 * Create a new instance of LocationBean. The new instance would hold
		 * default values for the all the Location fields.
		 */
		EnterpriseBean defaultEnterpriseBean = new EnterpriseBean();
		Enterprise inputCustomer = this;
		customerDbBean.setCustomerId(customerId);
		if (inputCustomer.getAccountName() != null
				&& !inputCustomer.getAccountName().equals(
						defaultEnterpriseBean.getAccountName())) {
			customerDbBean.setAccountName(inputCustomer.getAccountName());
		}
		if (inputCustomer.getCustomerName() != null
				&& !inputCustomer.getCustomerName().equals(
						defaultEnterpriseBean.getCustomerName())) {
			if (!"".equals(inputCustomer.getCustomerName())) {
				customerDbBean.setCustomerName(inputCustomer.getCustomerName()
						.trim());
			} else {
				customerDbBean.setCustomerNameNull();
			}

		}
		if (inputCustomer.getRegionId() != defaultEnterpriseBean.getRegionId()) {
			customerDbBean.setRegionId(inputCustomer.getRegionId());
		}

		if (inputCustomer.getCustIcpMigrated() != defaultEnterpriseBean
				.getCustIcpMigrated()) {
			customerDbBean.setIcpMigrated(inputCustomer.getCustIcpMigrated());
		}

		if (inputCustomer.getProductType() != defaultEnterpriseBean
				.getProductType()) {
			if (inputCustomer.getProductType() != 0)
				customerDbBean.setProductType(inputCustomer.getProductType());
			else
				customerDbBean.setProductTypeNull();
		}
		if (inputCustomer.getEnterpriseTrunkingType() != defaultEnterpriseBean
				.getEnterpriseTrunkingType()) {
			if (inputCustomer.getEnterpriseTrunkingType() != -1)
				customerDbBean.setEnterpriseTrunkingType(inputCustomer
						.getEnterpriseTrunkingType());
			else
				customerDbBean.setEnterpriseTrunkingTypeNull();
		}
		if (inputCustomer.getBillingSystem() != defaultEnterpriseBean
				.getBillingSystem()) {
			if (inputCustomer.getBillingSystem() != 0)
				customerDbBean.setUsBillingSystem(inputCustomer
						.getBillingSystem());
			else
				customerDbBean.setUsBillingSystemNull();
		}
		if (inputCustomer.getEmeaBillingSystem() != defaultEnterpriseBean
				.getEmeaBillingSystem()) {
			if (inputCustomer.getEmeaBillingSystem() != -1)
				customerDbBean.setEmeaBillingSystem(inputCustomer
						.getEmeaBillingSystem());
			else
				customerDbBean.setEmeaBillingSystemNull();
		}
		if (inputCustomer.getOrderSource() != null
				&& !inputCustomer.getOrderSource().equals(
						defaultEnterpriseBean.getOrderSource())) {
			if (!"".equals(inputCustomer.getOrderSource()))
				customerDbBean.setOrderSource(inputCustomer.getOrderSource());
			else
				customerDbBean.setOrderSourceNull();

		}
		if (inputCustomer.getContactFirstName() != null
				&& !inputCustomer.getContactFirstName().equals(
						defaultEnterpriseBean.getContactFirstName())) {
			if (!"".equals(inputCustomer.getContactFirstName()))
				customerDbBean.setContactFirstName(inputCustomer
						.getContactFirstName());
			else
				customerDbBean.setContactFirstNameNull();
		}
		if (inputCustomer.getContactLastName() != null
				&& !inputCustomer.getContactLastName().equals(
						defaultEnterpriseBean.getContactLastName())) {
			if (!"".equals(inputCustomer.getContactLastName()))
				customerDbBean.setContactLastName(inputCustomer
						.getContactLastName());
			else
				customerDbBean.setContactLastNameNull();
		}
		if (inputCustomer.getContactTitle() != null
				&& !inputCustomer.getContactTitle().equals(
						defaultEnterpriseBean.getContactTitle())) {
			if (!"".equals(inputCustomer.getContactTitle()))
				customerDbBean.setContactTitle(inputCustomer.getContactTitle());
			else
				customerDbBean.setContactTitleNull();
		}
		if (inputCustomer.getContactPrimaryPhone() != null
				&& !inputCustomer.getContactPrimaryPhone().equals(
						defaultEnterpriseBean.getContactPrimaryPhone())) {
			if (!"".equals(inputCustomer.getContactPrimaryPhone()))
				customerDbBean.setContactPriPhone(inputCustomer
						.getContactPrimaryPhone());
			else
				customerDbBean.setContactPriPhoneNull();
		}
		if (inputCustomer.getContactAltPhone() != null
				&& !inputCustomer.getContactAltPhone().equals(
						defaultEnterpriseBean.getContactAltPhone())) {
			if (!"".equals(inputCustomer.getContactAltPhone()))
				customerDbBean.setContactAltPhone(inputCustomer
						.getContactAltPhone());
			else
				customerDbBean.setContactAltPhoneNull();
		}
		if (inputCustomer.getContactFax() != null
				&& !inputCustomer.getContactFax().equals(
						defaultEnterpriseBean.getContactFax())) {
			if (!"".equals(inputCustomer.getContactFax()))
				customerDbBean.setContactFax(inputCustomer.getContactFax());
			else
				customerDbBean.setContactFaxNull();
		}
		if (inputCustomer.getContactCell() != null
				&& !inputCustomer.getContactCell().equals(
						defaultEnterpriseBean.getContactCell())) {
			if (!"".equals(inputCustomer.getContactCell()))
				customerDbBean.setContactCell(inputCustomer.getContactCell());
			else
				customerDbBean.setContactCellNull();
		}
		if (inputCustomer.getContactPager() != null
				&& !inputCustomer.getContactPager().equals(
						defaultEnterpriseBean.getContactPager())) {
			if (!"".equals(inputCustomer.getContactPager()))
				customerDbBean.setContactPager(inputCustomer.getContactPager());
			else
				customerDbBean.setContactPagerNull();
		}
		if (inputCustomer.getContactEmail() != null
				&& !inputCustomer.getContactEmail().equals(
						defaultEnterpriseBean.getContactEmail())) {
			if (!"".equals(inputCustomer.getContactEmail()))
				customerDbBean.setContactEmail(inputCustomer.getContactEmail());
			else
				customerDbBean.setContactEmailNull();
		}
		if (inputCustomer.getContactAddr1() != null
				&& !inputCustomer.getContactAddr1().equals(
						defaultEnterpriseBean.getContactAddr1())) {
			if (!"".equals(inputCustomer.getContactAddr1()))
				customerDbBean.setContactAddr1(inputCustomer.getContactAddr1());
			else
				customerDbBean.setContactAddr1Null();
		}
		if (inputCustomer.getContactAddr2() != null
				&& !inputCustomer.getContactAddr2().equals(
						defaultEnterpriseBean.getContactAddr2())) {
			if (!"".equals(inputCustomer.getContactAddr2()))
				customerDbBean.setContactAddr2(inputCustomer.getContactAddr2());
			else
				customerDbBean.setContactAddr2Null();
		}
		if (inputCustomer.getContactCity() != null
				&& !inputCustomer.getContactCity().equals(
						defaultEnterpriseBean.getContactCity())) {
			if (!"".equals(inputCustomer.getContactCity()))
				customerDbBean.setContactCity(inputCustomer.getContactCity());
			else
				customerDbBean.setContactCityNull();
		}
		if (inputCustomer.getContactState() != null
				&& !inputCustomer.getContactState().equals(
						defaultEnterpriseBean.getContactState())) {
			if (!"".equals(inputCustomer.getContactState()))
				customerDbBean.setContactState(inputCustomer.getContactState());
			else
				customerDbBean.setContactStateNull();
		}
		if (inputCustomer.getContactZip() != null
				&& !inputCustomer.getContactZip().equals(
						defaultEnterpriseBean.getContactZip())) {
			if (!"".equals(inputCustomer.getContactZip()))
				customerDbBean.setContactZip(inputCustomer.getContactZip());
			else
				customerDbBean.setContactZipNull();
		}
		if (inputCustomer.getContactCountry() != null
				&& !inputCustomer.getContactCountry().equals(
						defaultEnterpriseBean.getContactCountry())) {
			if (!"".equals(inputCustomer.getContactCountry()))
				customerDbBean.setContactCountry(inputCustomer
						.getContactCountry());
			else
				customerDbBean.setContactCountryNull();
		}
		if (inputCustomer.getBillContactPriPhone() != null
				&& !inputCustomer.getBillContactPriPhone().equals(
						defaultEnterpriseBean.getBillContactPriPhone())) {
			if (!"".equals(inputCustomer.getBillContactPriPhone()))
				customerDbBean.setBillContactPriPhone(inputCustomer
						.getBillContactPriPhone());
			else
				customerDbBean.setBillContactPriPhoneNull();
		}
		if (inputCustomer.getBillContactAltPhone() != null
				&& !inputCustomer.getBillContactAltPhone().equals(
						defaultEnterpriseBean.getBillContactAltPhone())) {
			if (!"".equals(inputCustomer.getBillContactAltPhone()))
				customerDbBean.setBillContactAltPhone(inputCustomer
						.getBillContactAltPhone());
			else
				customerDbBean.setBillContactAltPhoneNull();
		}
		if (inputCustomer.getBillContactCell() != null
				&& !inputCustomer.getBillContactCell().equals(
						defaultEnterpriseBean.getBillContactCell())) {
			if (!"".equals(inputCustomer.getBillContactCell()))
				customerDbBean.setBillContactCell(inputCustomer
						.getBillContactCell());
			else
				customerDbBean.setBillContactCellNull();
		}
		if (inputCustomer.getBillContactPager() != null
				&& !inputCustomer.getBillContactPager().equals(
						defaultEnterpriseBean.getBillContactPager())) {
			if (!"".equals(inputCustomer.getBillContactPager()))
				customerDbBean.setBillContactPager(inputCustomer
						.getBillContactPager());
			else
				customerDbBean.setBillContactPagerNull();
		}
		if (inputCustomer.getBillContactEmail() != null
				&& !inputCustomer.getBillContactEmail().equals(
						defaultEnterpriseBean.getBillContactEmail())) {
			if (!"".equals(inputCustomer.getBillContactEmail()))
				customerDbBean.setBillContactEmail(inputCustomer
						.getBillContactEmail());
			else
				customerDbBean.setBillContactEmailNull();
		}
		if (inputCustomer.getBillContactAddr1() != null
				&& !inputCustomer.getBillContactAddr1().equals(
						defaultEnterpriseBean.getBillContactAddr1())) {
			if (!"".equals(inputCustomer.getBillContactAddr1()))
				customerDbBean.setBillContactAddr1(inputCustomer
						.getBillContactAddr1());
			else
				customerDbBean.setBillContactAddr1Null();
		}
		if (inputCustomer.getBillContactAddr2() != null
				&& !inputCustomer.getBillContactAddr2().equals(
						defaultEnterpriseBean.getBillContactAddr2())) {
			if (!"".equals(inputCustomer.getBillContactAddr2()))
				customerDbBean.setBillContactAddr2(inputCustomer
						.getBillContactAddr2());
			else
				customerDbBean.setBillContactAddr2Null();
		}
		if (inputCustomer.getBillContactCity() != null
				&& !inputCustomer.getBillContactCity().equals(
						defaultEnterpriseBean.getBillContactCity())) {
			if (!"".equals(inputCustomer.getBillContactCity()))
				customerDbBean.setBillContactCity(inputCustomer
						.getBillContactCity());
			else
				customerDbBean.setBillContactCityNull();
		}
		if (inputCustomer.getBillContactState() != null
				&& !inputCustomer.getBillContactState().equals(
						defaultEnterpriseBean.getBillContactState())) {
			if (!"".equals(inputCustomer.getBillContactState()))
				customerDbBean.setBillContactState(inputCustomer
						.getBillContactState());
			else
				customerDbBean.setBillContactStateNull();
		}
		if (inputCustomer.getBillContactZip() != null
				&& !inputCustomer.getBillContactZip().equals(
						defaultEnterpriseBean.getBillContactZip())) {
			if (!"".equals(inputCustomer.getBillContactZip()))
				customerDbBean.setBillContactZip(inputCustomer
						.getBillContactZip());
			else
				customerDbBean.setBillContactZipNull();
		}
		if (inputCustomer.getBillContactCountry() != null
				&& !inputCustomer.getBillContactCountry().equals(
						defaultEnterpriseBean.getBillContactCountry())) {
			if (!"".equals(inputCustomer.getBillContactCountry()))
				customerDbBean.setBillContactCountry(inputCustomer
						.getBillContactCountry());
			else
				customerDbBean.setBillContactCountryNull();
		}
		if (inputCustomer.getSalesSegment() != defaultEnterpriseBean
				.getSalesSegment()) {
			if (inputCustomer.getSalesSegment() != 0)
				customerDbBean.setSalesSegment(inputCustomer.getSalesSegment());
			else
				customerDbBean.setSalesSegmentNull();
		}
		if (inputCustomer.getSalesRepId() != null
				&& !inputCustomer.getSalesRepId().equals(
						defaultEnterpriseBean.getSalesRepId())) {
			if (!"".equals(inputCustomer.getSalesRepId()))
				customerDbBean.setSalesRepId(inputCustomer.getSalesRepId());
			else
				customerDbBean.setSalesRepIdNull();
		}
		if (inputCustomer.getSalesRepName() != null
				&& !inputCustomer.getSalesRepName().equals(
						defaultEnterpriseBean.getSalesRepName())) {
			if (!"".equals(inputCustomer.getSalesRepName()))
				customerDbBean.setSalesRepName(inputCustomer.getSalesRepName());
			else
				customerDbBean.setSalesRepNameNull();
		}
		if (inputCustomer.getSalesRepPhone() != null
				&& !inputCustomer.getSalesRepPhone().equals(
						defaultEnterpriseBean.getSalesRepPhone())) {
			if (!"".equals(inputCustomer.getSalesRepPhone()))
				customerDbBean.setSalesRepPhone(inputCustomer
						.getSalesRepPhone());
			else
				customerDbBean.setSalesRepPhoneNull();
		}
		if (inputCustomer.getSalesRepEmail() != null
				&& !inputCustomer.getSalesRepEmail().equals(
						defaultEnterpriseBean.getSalesRepEmail())) {
			if (!"".equals(inputCustomer.getSalesRepEmail()))
				customerDbBean.setSalesRepEmail(inputCustomer
						.getSalesRepEmail());
			else
				customerDbBean.setSalesRepEmailNull();
		}
		if (inputCustomer.getCustCorpId() != null
				&& !inputCustomer.getCustCorpId().equals(
						defaultEnterpriseBean.getCustCorpId())) {
			if (!"".equals(inputCustomer.getCustCorpId()))
				customerDbBean.setCustCorpId(inputCustomer.getCustCorpId());
			else
				customerDbBean.setCustCorpIdNull();
		}
		if (inputCustomer.getOrderVerification() != defaultEnterpriseBean
				.getOrderVerification()) {
			if (inputCustomer.getOrderVerification() != 0)
				customerDbBean.setOrderVerification(inputCustomer
						.getOrderVerification());
			else
				customerDbBean.setOrderVerificationNull();
		}
		if (inputCustomer.getSupportName() != null
				&& !inputCustomer.getSupportName().equals(
						defaultEnterpriseBean.getSupportName())) {
			if (!"".equals(inputCustomer.getSupportName()))
				customerDbBean.setSupportName(inputCustomer.getSupportName());
			else
				customerDbBean.setSupportNameNull();
		}
		if (inputCustomer.getSupportPhone() != null
				&& !inputCustomer.getSupportPhone().equals(
						defaultEnterpriseBean.getSupportPhone())) {
			if (!"".equals(inputCustomer.getSupportPhone()))
				customerDbBean.setSupportPhone(inputCustomer.getSupportPhone());
			else
				customerDbBean.setSupportPhoneNull();
		}
		if (inputCustomer.getEmeaServiceSupport() != defaultEnterpriseBean
				.getEmeaServiceSupport()) {
			customerDbBean.setEmeaServiceSupport(inputCustomer
					.getEmeaServiceSupport());
		}
		
		 // IR #4842933 Need to make sure , tbl_customer.CUST_SENSITIVITY_LEVEL is never updated  
		/*if (inputCustomer.getCustSensitivityLevel() != null
				&& !inputCustomer.getCustSensitivityLevel().equals(
						defaultEnterpriseBean.getCustSensitivityLevel())) {
			customerDbBean.setCustSensitivityLevel(inputCustomer
					.getCustSensitivityLevel());
		}*/
		if (inputCustomer.getCustGarmStatus() != defaultEnterpriseBean
				.getCustGarmStatus()) {
			if (!"".equals(inputCustomer.getCustGarmStatus()))
				customerDbBean.setCustGarmStatus(inputCustomer
						.getCustGarmStatus());
			else
				customerDbBean.setCustGarmStatusNull();
		}
		if (inputCustomer.getCustActiveInd() != defaultEnterpriseBean
				.getCustActiveInd()) {
			if (inputCustomer.getCustActiveInd() != 0)
				customerDbBean.setActiveInd(inputCustomer.getCustActiveInd());
			else
				customerDbBean.setActiveIndNull();
		}
		// Newly Added
		if (inputCustomer.getCommonCustomerId() != null
				&& !inputCustomer.getCommonCustomerId().equals(
						defaultEnterpriseBean.getCommonCustomerId())) {
			if (!"".equals(inputCustomer.getCommonCustomerId()))
				customerDbBean.setCommonCustomerId(inputCustomer
						.getCommonCustomerId());
			else
				customerDbBean.setCommonCustomerIdNull();
		}
		if (inputCustomer.getVpnName() != null
				&& !inputCustomer.getVpnName().equals(
						defaultEnterpriseBean.getVpnName())) {
			if (!"".equals(inputCustomer.getVpnName()))
				customerDbBean.setVpnName(inputCustomer.getVpnName());
			else
				customerDbBean.setVpnNameNull();
		}

		// Jan 2011 Release changes

		if (inputCustomer.getNaspId() != null
				&& !inputCustomer.getNaspId().equals(
						defaultEnterpriseBean.getNaspId())) {
			customerDbBean.setNaspId(inputCustomer.getNaspId());
		}

		log.info(" customerDbBean.setNaspId "
				+ customerDbBean.getNaspId());

		if (inputCustomer.getCommonCustomerName() != null
				&& !inputCustomer.getCommonCustomerName().equals(
						defaultEnterpriseBean.getCommonCustomerName())) {
			if (!"".equals(inputCustomer.getCommonCustomerName()))
				customerDbBean.setCommonCustomerName(inputCustomer
						.getCommonCustomerName());
			else
				customerDbBean.setCommonCustomerNameNull();
		}

		if (inputCustomer.getRegionId() != defaultEnterpriseBean.getRegionId()) {
			customerDbBean.setRegionId(inputCustomer.getRegionId());
		}
		if (inputCustomer.getEnvOrderId() != defaultEnterpriseBean
				.getEnvOrderId()) {
			customerDbBean.setEnvOrderId(inputCustomer.getEnvOrderId());
		}
		if (inputCustomer.getModifiedBy() != null
				&& !inputCustomer.getModifiedBy().trim().equals(""))
			customerDbBean.setModifiedBy(inputCustomer.getModifiedBy());
		else
			customerDbBean.setModifiedBy("ESAP_INV");
		customerDbBean.setLastModifiedDate(new Timestamp(System
				.currentTimeMillis()));
		
		// added by z658915 starts for calnet changes
		if (inputCustomer.getCalnetSubContractId() != defaultEnterpriseBean.getCalnetSubContractId()) {
			customerDbBean.setCalnetSubContractId(inputCustomer.getCalnetSubContractId());
		}
		// added by z658915 ends for calnet changes

		return customerDbBean;
	}

	

	public boolean validate() {
		return true;
	}

	// set customerId member
	public boolean getDetails() {
		try {
			TblEnterpriseQuery entQry = new TblEnterpriseQuery();
			initilizeTODefault();
			// entQry.whereEnterpriseIdEQ(customerId);
			String whereClause = new String("");
			if (getAll == false)
				whereClause = " where enterprise_id = \'" + customerId
						+ "\' and active_ind = 1";
			else
				whereClause = " where enterprise_id = \'" + customerId
						+ "\' and active_ind != 0";
			log.info("Before entQry in getDetails:" + whereClause);
			entQry.queryByWhere(dbCon, whereClause);
			log.info("after entQry in getDetails");
			if (entQry.size() == 1) {
				setEnterpriseId((entQry.getDbBean(0)).getEnterpriseId());
				setCustomerType((entQry.getDbBean(0)).getCustType());
				setCustMarket((entQry.getDbBean(0)).getCustMarket());
				setPlatformIndicator((entQry.getDbBean(0))
						.getPlatformIndicator());
				setVmPartitionId((entQry.getDbBean(0)).getVmPartitionId());
				setPubIp((entQry.getDbBean(0)).getPubip());
				setOnNetInterco((entQry.getDbBean(0)).getOnNetInterco());
				setSipDomain((entQry.getDbBean(0)).getSipDomain());
				setEntCclInd((entQry.getDbBean(0)).getEntcclInd());
				setQosInd((entQry.getDbBean(0)).getQosInd());
				setIeanLength((entQry.getDbBean(0)).getIeanLength());
				setVnetCorpId((entQry.getDbBean(0)).getVnetCorpId());
				// log.info("ContractInd :"+(entQry.getDbBean(0)).getContractInd());
				setContractInd((entQry.getDbBean(0)).getContractInd());
				log.info("ContractInd :" + getContractInd());
				setAgencyHierCode((entQry.getDbBean(0)).getAgencyHierCode());
				setXrefCustomerId((entQry.getDbBean(0)).getXrefCustomerId());
				setCallingPlanId((entQry.getDbBean(0)).getCallingPlanId());
				setIsRIVCustomer((entQry.getDbBean(0)).getRivCustomer());
				setAuthServicesId((entQry.getDbBean(0)).getAuthServicesId());
				setEntSbcMigInd((entQry.getDbBean(0)).getSbcMigInd());
				setEnvOrderId((entQry.getDbBean(0)).getEnvOrderId());
				setCreatedBy((entQry.getDbBean(0)).getCreatedBy());
				setModifiedBy((entQry.getDbBean(0)).getModifiedBy());
				setCreationDate((entQry.getDbBean(0)).getCreationDate());
				setLastModifiedDate((entQry.getDbBean(0)).getLastModifiedDate());
				// 53938.AA Business Continuity Ph 1 - changes for july 2011
				setLorFlag((entQry.getDbBean(0)).getLorFlag());

				if (getAuthServicesId() > 0
						&& !getAuthFeaturesByAuthServicesId((int) getAuthServicesId())) {
					setAuthServicesId(0);
				}
				setAsId((entQry.getDbBean(0)).getAsId());
				if (getAsId() > 0 && !getAsBsByAsId(getAsId())) {
					setAsId(0);
				}
				setEntActiveInd((entQry.getDbBean(0)).getActiveInd());
				setBsBlockInd((entQry.getDbBean(0)).getBsBlockInd());
				setLoadSharing((entQry.getDbBean(0)).getLoadSharing());

				setLorId((entQry.getDbBean(0)).getLorId());
				setAddress((entQry.getDbBean(0)).getAddress());
				setCity((entQry.getDbBean(0)).getCity());
				setState((entQry.getDbBean(0)).getState());
				setZip((entQry.getDbBean(0)).getZip());
				setCountry((entQry.getDbBean(0)).getCountry());
				setSoEnabled((entQry.getDbBean(0)).getSoEnabled());
				setUsLdAndLocalBestPool((entQry.getDbBean(0))
						.getUsLdAndLocalBestPool());
				setUsLdOnlyBestPool((entQry.getDbBean(0)).getUsLdOnlyBestPool());
				setEmeaApacBestPool((entQry.getDbBean(0)).getEmeaApacBestPool());
				setUsLdAndLocalBestPlusPool((entQry.getDbBean(0))
						.getUsLdAndLocalBestPlusPool());
				setUsLdOnlyBestPlusPool((entQry.getDbBean(0))
						.getUsLdOnlyBestPlusPool());
				setEmeaApacBestPlusPool((entQry.getDbBean(0))
						.getEmeaApacBestPlusPool());
				setHybridInd((entQry.getDbBean(0)).getHybridInd());
				setApprovedCcl((entQry.getDbBean(0)).getApprovedCcl());
				setEntTrunkCclSum((entQry.getDbBean(0)).getEntTrunkCclSum());
				setCustPriceBookId((entQry.getDbBean(0)).getCustPriceBookId());
				setContractId((entQry.getDbBean(0)).getContractId());
				setQuoteId((entQry.getDbBean(0)).getQuoteId());
				setCatalogueReferenceTime((entQry.getDbBean(0))
						.getCatalogueReferenceTime());
				setDesignId((entQry.getDbBean(0)).getDesignId());
				setEntCumCcl((entQry.getDbBean(0)).getEntCumCcl());
			} else {
				setStatus(InvErrorCode.DATA_NOTFOUND);
				// setStatusDesc("Couldn't find any Enterprise with the given EnterpriseId");
				return false;
			}

			log.info(" customerId " + customerId);
			// IR #1484223: Enterprise getDetails API do not return OnNetStat
			// parameter
			TblDialPlanQuery dialPlanQuery = new TblDialPlanQuery();
			dialPlanQuery.whereEnterpriseIdEQ(customerId);
			dialPlanQuery.whereDefaultFlagEQ(1);
			dialPlanQuery.query(dbCon);

			if (dialPlanQuery.size() > 0) {
				log.info(" OnNetSat "
						+ dialPlanQuery.getDbBean(0).getOnNetStat());
				setOnNetStat(dialPlanQuery.getDbBean(0).getOnNetStat());
			}
			log.info(" GetOnNetStat " + getOnNetStat());

			TblCustomerQuery custQry = new TblCustomerQuery();
			// custQry.whereCustomerIdEQ(customerId);

			String whereClauseCust = new String("");
			if (getAll == false)
				whereClauseCust = " where customer_id = \'" + customerId
						+ "\' and active_ind = 1";
			else
				whereClauseCust = " where customer_id = \'" + customerId
						+ "\' and active_ind != 0";

			log.info("before custQry");
			custQry.queryByWhere(dbCon, whereClauseCust);
			log.info("after custQry");
			if (custQry.size() == 1) {
				setCustomerId((custQry.getDbBean(0)).getCustomerId());
				setCustomerName((custQry.getDbBean(0)).getCustomerName());
				setAccountName((custQry.getDbBean(0)).getAccountName());
				setRegionId((custQry.getDbBean(0)).getRegionId());
				setProductType((custQry.getDbBean(0)).getProductType());
				if ((custQry.getDbBean(0)).getUsBillingSystem() != 0)
					setBillingSystem((custQry.getDbBean(0))
							.getUsBillingSystem());
				else
					setBillingSystem((custQry.getDbBean(0))
							.getEmeaBillingSystem());
				setEmeaBillingSystem((custQry.getDbBean(0))
						.getEmeaBillingSystem());
				setOrderSource((custQry.getDbBean(0)).getOrderSource());
				setContactFirstName((custQry.getDbBean(0))
						.getContactFirstName());
				setContactLastName((custQry.getDbBean(0)).getContactLastName());
				setContactTitle((custQry.getDbBean(0)).getContactTitle());
				setContactPrimaryPhone((custQry.getDbBean(0))
						.getContactPriPhone());
				setContactAltPhone((custQry.getDbBean(0)).getContactAltPhone());
				setContactFax((custQry.getDbBean(0)).getContactFax());
				setContactCell((custQry.getDbBean(0)).getContactCell());
				setContactPager((custQry.getDbBean(0)).getContactPager());
				setContactEmail((custQry.getDbBean(0)).getContactEmail());
				setContactAddr1((custQry.getDbBean(0)).getContactAddr1());
				setContactAddr2((custQry.getDbBean(0)).getContactAddr2());
				setContactCity((custQry.getDbBean(0)).getContactCity());
				setContactState((custQry.getDbBean(0)).getContactState());
				setContactZip((custQry.getDbBean(0)).getContactZip());
				setContactCountry((custQry.getDbBean(0)).getContactCountry());
				setBillContactPriPhone((custQry.getDbBean(0))
						.getBillContactPriPhone());
				setBillContactAltPhone((custQry.getDbBean(0))
						.getBillContactAltPhone());
				setBillContactCell((custQry.getDbBean(0)).getBillContactCell());
				setBillContactPager((custQry.getDbBean(0))
						.getBillContactPager());
				setBillContactEmail((custQry.getDbBean(0))
						.getBillContactEmail());
				setBillContactAddr1((custQry.getDbBean(0))
						.getBillContactAddr1());
				setBillContactAddr2((custQry.getDbBean(0))
						.getBillContactAddr2());
				setBillContactCity((custQry.getDbBean(0)).getBillContactCity());
				setBillContactState((custQry.getDbBean(0))
						.getBillContactState());
				setBillContactZip((custQry.getDbBean(0)).getBillContactZip());
				setBillContactCountry((custQry.getDbBean(0))
						.getBillContactCountry());
				setSalesSegment((custQry.getDbBean(0)).getSalesSegment());
				setSalesRepId((custQry.getDbBean(0)).getSalesRepId());
				setSalesRepName((custQry.getDbBean(0)).getSalesRepName());
				setSalesRepPhone((custQry.getDbBean(0)).getSalesRepPhone());
				setSalesRepEmail((custQry.getDbBean(0)).getSalesRepEmail());
				setCustCorpId((custQry.getDbBean(0)).getCustCorpId());
				setOrderVerification((custQry.getDbBean(0))
						.getOrderVerification());
				setSupportName((custQry.getDbBean(0)).getSupportName());
				setSupportPhone((custQry.getDbBean(0)).getSupportPhone());
				setEmeaServiceSupport((custQry.getDbBean(0))
						.getEmeaServiceSupport());
				setCustSensitivityLevel((custQry.getDbBean(0))
						.getCustSensitivityLevel());
				setCustGarmStatus((custQry.getDbBean(0)).getCustGarmStatus());
				setCustSbcMigInd((custQry.getDbBean(0)).getSbcMigInd());
				setCustIcpMigrated((custQry.getDbBean(0)).getIcpMigrated());
				// log.info("Common CustomerId :"+(custQry.getDbBean(0)).getCommonCustomerId());
				setCommonCustomerId((custQry.getDbBean(0))
						.getCommonCustomerId());
				log.info("Common CustomerId :"
						+ getCommonCustomerId());
				setVpnName((custQry.getDbBean(0)).getVpnName());
				// Jan 2011 Release changes
				setNaspId((custQry.getDbBean(0)).getNaspId());
				// log.info("Common Customer Name :"+(custQry.getDbBean(0)).getCommonCustomerName());
				setCommonCustomerName((custQry.getDbBean(0))
						.getCommonCustomerName());
				log.info("Common Customer Name :"
						+ getCommonCustomerName());
				setCustActiveInd((custQry.getDbBean(0)).getActiveInd());
				setEnvOrderId((custQry.getDbBean(0)).getEnvOrderId());
				setOrderPlatform((custQry.getDbBean(0)).getOrderPlatform());
				setRestrictedAccess((custQry.getDbBean(0))
						.getRestrictedAccess());
				setEnterpriseTrunkingType((custQry.getDbBean(0))
						.getEnterpriseTrunkingType());
				setE2eiSensitivityLevel((custQry.getDbBean(0))
						.getE2eiSensitivityLevel());
				setGchId((custQry.getDbBean(0)).getGchId());
				setE2eiMigStatus((custQry.getDbBean(0)).getE2eiMigFlag());
				setE2eiMigLock((custQry.getDbBean(0)).getE2eiMigLock());
				setE2eiMigDate((custQry.getDbBean(0)).getE2eiMigDate());
				setCalnetSubContractId((custQry.getDbBean(0)).getCalnetSubContractId());		//added by z658915
			}

			getDigitStringsByEnterpriseId();

		} catch (SQLException e) {
			setStatus(InvErrorCode.DB_EXCEPTION);
			e.printStackTrace();
			// setStatusDesc("DB_FAILURE in getDetails Enterprise");
			return false;
		} catch (Exception e) {
			e.printStackTrace();
			setStatus(InvErrorCode.ERROR_GET_ENTERPRISE);
			// setStatusDesc("FAILURE in getDetails Enterprise");
			return false;
		}
		setStatus(InvErrorCode.SUCCESS);
		// setStatusDesc("Successfully retrieved enterprise from the DB");
		return true;
	}

	// set customerId member
	public boolean getAuthDetailsForEnterprise() {
		try {
			TblEnterpriseQuery entQry = new TblEnterpriseQuery();
			String whereClause = new String("");
			if (getAll == false)
				whereClause = " where enterprise_id = \'" + customerId
						+ "\' and active_ind = 1";
			else
				whereClause = " where enterprise_id = \'" + customerId
						+ "\' and active_ind != 0";
			log.info("Before entQry in getauthDetails" + whereClause);
			entQry.queryByWhere(dbCon, whereClause);
			log.info("Before entQry in getAuthDetails");
			if (entQry.size() == 1) {
				long authSerId = (entQry.getDbBean(0)).getAuthServicesId();
				if (authSerId > 0) {
					if (!getAuthFeaturesByAuthServicesId((int) authSerId)) {
						setStatus(InvErrorCode.INTERNAL_ERROR);
						// setStatusDesc("FAILURE in getAuthDetails Enterprise. No auth services for the given  auth services id.");
						System.out
								.println("FAILURE in getAuthDetails Enterprise. No auth services for the given  auth services id.");
						return false;
					}
				} else {
					setStatus(InvErrorCode.INTERNAL_ERROR);
					// setStatusDesc("FAILURE in getAuthDetails Enterprise. Invalid auth services id for enterprise");
					System.out
							.println("FAILURE in getAuthDetails Enterprise. Invalid auth services id for enterprise");
					return false;
				}
			} else {
				setStatus(InvErrorCode.NOTFOUND_ENT_AUTH_FEATURES_FOR_ENTERPRISE_ID);
				// setStatusDesc("FAILURE in getAuthDetails Enterprise. Invalid enterprise for the given enterprise id");
				System.out
						.println("FAILURE in getAuthDetails Enterprise. Invalid enterprise for the given enterprise id");
				return false;
			}
		} catch (Exception e) {
			e.printStackTrace();
			setStatus(InvErrorCode.DB_EXCEPTION);
			// setStatusDesc("DB FAILURE in getAuthDetails for Enterprise");
			return false;
		}
		setStatus(InvErrorCode.SUCCESS);
		// setStatusDesc("Successfully retrieved auth details for enterprise from the DB");
		return true;
	}

	public boolean getAsBsForEnterprise() {
		return true;
	}

	public boolean getCallingPlanForEnterprise() {
		return true;
	}

	

	public boolean getAccountDetailsForCustomer() {
		return true;
	}

	

	boolean getAsBsByAsId(long appServerId) throws SQLException {
		TblBsAsQuery bsAsQry = new TblBsAsQuery();
		bsAsQry.whereBsAsIdEQ((int) appServerId);
		log.info("before bsAsQry");
		bsAsQry.query(dbCon);
		log.info("after bsAsQry");
		if (bsAsQry.size() == 1) {
			bsAsDbBean.copyFromBean(bsAsQry.getDbBean(0));
		} else
			return false;
		return true;
	}

	public void getDigitStringsByEnterpriseId() throws SQLException, Exception {
		TblDigitStringsQuery digitStringQry = new TblDigitStringsQuery();
		digitStringQry.whereEnterpriseIdEQ(customerId);
		digitStringQry.whereActiveIndEQ(1);
		log.info("before digitStringQry" + customerId);
		digitStringQry.query(dbCon);
		log.info("after digitStringQry");
		digitStringList = new ArrayList<TblDigitStringsDbBean>();
		if (digitStringQry.size() > 0) {

			for (int i = 0; i < digitStringQry.size(); i++) {
				digitStringList.add(digitStringQry.getDbBean(i));
			}
		} else {
			System.out
					.println("No digitString were not found in db for enterprise id");
		}
	}

	boolean getAuthFeaturesByAuthServicesId(int authServId) throws Exception {
		TblAuthServicesQuery authQry = new TblAuthServicesQuery();
		authQry.whereAuthServiceIdEQ(authServId);
		log.info("before authFeaturesQry");
		authQry.query(dbCon);
		log.info("after authFeaturesQry");
		if (authQry.size() > 0) {
			for (int i = 0; i < authQry.size(); i++) {
				FeaturesBean featObj = new FeaturesBean();
				if ((authQry.getDbBean(i)).getIsAuthorized() != null
						&& (((authQry.getDbBean(i)).getIsAuthorized())
								.equalsIgnoreCase("Y"))) {
					featObj.setIsAuthorized(true);
				} else
					featObj.setIsAuthorized(false);
				if (authQry.getDbBean(i).getEnvOrderId() > 0)
					featObj.setEnvOrderId(authQry.getDbBean(i).getEnvOrderId());
				TblVzbFeaturesQuery vzbFeatQry = new TblVzbFeaturesQuery();
				vzbFeatQry.whereFeatureIdEQ((int) (authQry.getDbBean(i))
						.getFeatureId());
				vzbFeatQry.query(dbCon);
				if (vzbFeatQry.size() == 1) {
					DBTblVzbFeatures vzbFeatObj = new DBTblVzbFeatures();
					vzbFeatObj.copyFromBean(vzbFeatQry.getDbBean(0));
					featObj.setFeaturesDbBean(vzbFeatObj);
					authFeaturesList.add(featObj);
				}
			}
			if (authFeaturesList.size() <= 0) {
				log.info("authFeatures list size is 0");
				return false;
			}
			log.info("auth featrues list size:"
					+ authFeaturesList.size());
		} else {
			System.out
					.println("No auth services entry in db with this auth services id");
			return false;
		}
		return true;
	}

	public int getAuthServiceIdSeqNextVal(Connection connection)
			throws SQLException {
		int authServiceId = 0;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {

			ps = connection
					.prepareStatement("SELECT auth_service_id_seq.NEXTVAL FROM DUAL");

			rs = ps.executeQuery();
			if (rs.next()) {
				authServiceId = rs.getInt(1);
			}

		} catch (SQLException e) {
			// log_msg(logging_level, "ERROR: SELECT auth_service_id_seq.NEXTVAL
			// FROM DUAL");
			e.printStackTrace();
			return 0;
		} finally {
			if (null != rs)
				rs.close();
			if (null != ps)
				ps.close();
		}
		return authServiceId;
	}
	//KR-start add for xo PolicyService changes
	public int getPolicyServiceSeqNextVal(Connection connection)
			throws SQLException {
		int policyServiceId = 0;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {

			ps = connection
					.prepareStatement("SELECT TBL_POLICIES_SERVICE_SEQ.NEXTVAL FROM DUAL");

			rs = ps.executeQuery();
			if (rs.next()) {
				policyServiceId = rs.getInt(1);
			}

		} catch (SQLException e) {
			// log_msg(logging_level, "ERROR: SELECT auth_service_id_seq.NEXTVAL
			// FROM DUAL");
			e.printStackTrace();
			return 0;
		} finally {
			if (null != rs)
				rs.close();
			if (null != ps)
				ps.close();
		}
		return policyServiceId;
	}
	public int getServicePackServiceSeqNextVal(Connection connection)
			throws SQLException {
		int servicepackServiceId = 0;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {

			ps = connection
					.prepareStatement("SELECT Tbl_ServicePack_service_SEQ.NEXTVAL FROM DUAL");

			rs = ps.executeQuery();
			if (rs.next()) {
				servicepackServiceId = rs.getInt(1);
			}

		} catch (SQLException e) {
			// log_msg(logging_level, "ERROR: SELECT auth_service_id_seq.NEXTVAL
			// FROM DUAL");
			e.printStackTrace();
			return 0;
		} finally {
			if (null != rs)
				rs.close();
			if (null != ps)
				ps.close();
		}
		return servicepackServiceId;
	}
	
	//KR --end

	
	public void printCustDbObj(DBTblCustomer custDbObj) {
		StringBuffer buffer = new StringBuffer();
		buffer.append("CustomerId=").append(custDbObj.getCustomerId())
				.append("\n");
		buffer.append("CustomerName=").append(custDbObj.getCustomerName())
				.append("\n");
		buffer.append("AccountName=").append(custDbObj.getAccountName())
				.append("\n");
		buffer.append("RegionId=").append(custDbObj.getRegionId()).append("\n");
		buffer.append("ProductType=").append(custDbObj.getProductType())
				.append("\n");
		buffer.append("UsBillingSystem=")
				.append(custDbObj.getUsBillingSystem()).append("\n");
		buffer.append("EmeaBillingSystem=")
				.append(custDbObj.getEmeaBillingSystem()).append("\n");
		buffer.append("OrderSource=").append(custDbObj.getOrderSource())
				.append("\n");
		buffer.append("ContactFirstName=")
				.append(custDbObj.getContactFirstName()).append("\n");
		buffer.append("ContactLastName=")
				.append(custDbObj.getContactLastName()).append("\n");
		buffer.append("ContactTitle=").append(custDbObj.getContactTitle())
				.append("\n");
		buffer.append("ContactPriPhone=")
				.append(custDbObj.getContactPriPhone()).append("\n");
		buffer.append("ContactAltPhone=")
				.append(custDbObj.getContactAltPhone()).append("\n");
		buffer.append("ContactFax=").append(custDbObj.getContactFax())
				.append("\n");
		buffer.append("ContactCell=").append(custDbObj.getContactCell())
				.append("\n");
		buffer.append("ContactPager=").append(custDbObj.getContactPager())
				.append("\n");
		buffer.append("ContactEmail=").append(custDbObj.getContactEmail())
				.append("\n");
		buffer.append("ContactAddr1=").append(custDbObj.getContactAddr1())
				.append("\n");
		buffer.append("ContactAddr2=").append(custDbObj.getContactAddr2())
				.append("\n");
		buffer.append("ContactCity=").append(custDbObj.getContactCity())
				.append("\n");
		buffer.append("ContactState=").append(custDbObj.getContactState())
				.append("\n");
		buffer.append("ContactZip=").append(custDbObj.getContactZip())
				.append("\n");
		buffer.append("ContactCountry=").append(custDbObj.getContactCountry())
				.append("\n");
		buffer.append("BillContactPriPhone=")
				.append(custDbObj.getBillContactPriPhone()).append("\n");
		buffer.append("BillContactAltPhone=")
				.append(custDbObj.getBillContactAltPhone()).append("\n");
		buffer.append("BillContactCell=")
				.append(custDbObj.getBillContactCell()).append("\n");
		buffer.append("BillContactPager=")
				.append(custDbObj.getBillContactPager()).append("\n");
		buffer.append("BillContactEmail=")
				.append(custDbObj.getBillContactEmail()).append("\n");
		buffer.append("BillContactAddr1=")
				.append(custDbObj.getBillContactAddr1()).append("\n");
		buffer.append("BillContactAddr2=")
				.append(custDbObj.getBillContactAddr2()).append("\n");
		buffer.append("BillContactCity=")
				.append(custDbObj.getBillContactCity()).append("\n");
		buffer.append("BillContactState=")
				.append(custDbObj.getBillContactState()).append("\n");
		buffer.append("BillContactZip=").append(custDbObj.getBillContactZip())
				.append("\n");
		buffer.append("BillContactCountry=")
				.append(custDbObj.getBillContactCountry()).append("\n");
		buffer.append("SalesSegment=").append(custDbObj.getSalesSegment())
				.append("\n");
		buffer.append("SalesRepId=").append(custDbObj.getSalesRepId())
				.append("\n");
		buffer.append("SalesRepName=").append(custDbObj.getSalesRepName())
				.append("\n");
		buffer.append("SalesRepPhone=").append(custDbObj.getSalesRepPhone())
				.append("\n");
		buffer.append("SalesRepEmail=").append(custDbObj.getSalesRepEmail())
				.append("\n");
		buffer.append("CustCorpId=").append(custDbObj.getCustCorpId())
				.append("\n");
		buffer.append("OrderVerification=")
				.append(custDbObj.getOrderVerification()).append("\n");
		buffer.append("SupportName=").append(custDbObj.getSupportName())
				.append("\n");
		buffer.append("SupportPhone=").append(custDbObj.getSupportPhone())
				.append("\n");
		buffer.append("EmeaServiceSupport=")
				.append(custDbObj.getEmeaServiceSupport()).append("\n");
		buffer.append("CustSensitivityLevel=")
				.append(custDbObj.getCustSensitivityLevel()).append("\n");
		buffer.append("CustGarmStatus=").append(custDbObj.getCustGarmStatus())
				.append("\n");
		buffer.append("ActiveInd=").append(custDbObj.getActiveInd())
				.append("\n");
		buffer.append("CreatedBy=").append(custDbObj.getCreatedBy())
				.append("\n");
		buffer.append("ModifiedBy=").append(custDbObj.getModifiedBy())
				.append("\n");
		buffer.append("LastModifiedDate=")
				.append(custDbObj.getLastModifiedDate()).append("\n");
		buffer.append("CustomerId=").append(custDbObj.getCustomerId())
				.append("\n");
		buffer.append("CustomerName=").append(custDbObj.getCustomerName())
				.append("\n");
		buffer.append("AccountName=").append(custDbObj.getAccountName())
				.append("\n");
		buffer.append("RegionId=").append(custDbObj.getRegionId()).append("\n");
		buffer.append("ProductType=").append(custDbObj.getProductType())
				.append("\n");
		buffer.append("UsBillingSystem=")
				.append(custDbObj.getUsBillingSystem()).append("\n");
		buffer.append("EmeaBillingSystem=")
				.append(custDbObj.getEmeaBillingSystem()).append("\n");
		buffer.append("OrderSource=").append(custDbObj.getOrderSource())
				.append("\n");
		buffer.append("ContactFirstName=")
				.append(custDbObj.getContactFirstName()).append("\n");
		buffer.append("ContactLastName=")
				.append(custDbObj.getContactLastName()).append("\n");
		buffer.append("ContactTitle=").append(custDbObj.getContactTitle())
				.append("\n");
		buffer.append("ContactPriPhone=")
				.append(custDbObj.getContactPriPhone()).append("\n");
		buffer.append("ContactAltPhone=")
				.append(custDbObj.getContactAltPhone()).append("\n");
		buffer.append("ContactFax=").append(custDbObj.getContactFax())
				.append("\n");
		buffer.append("ContactCell=").append(custDbObj.getContactCell())
				.append("\n");
		buffer.append("ContactPager=").append(custDbObj.getContactPager())
				.append("\n");
		buffer.append("ContactEmail=").append(custDbObj.getContactEmail())
				.append("\n");
		buffer.append("ContactAddr1=").append(custDbObj.getContactAddr1())
				.append("\n");
		buffer.append("ContactAddr2=").append(custDbObj.getContactAddr2())
				.append("\n");
		buffer.append("ContactCity=").append(custDbObj.getContactCity())
				.append("\n");
		buffer.append("ContactState=").append(custDbObj.getContactState())
				.append("\n");
		buffer.append("ContactZip=").append(custDbObj.getContactZip())
				.append("\n");
		buffer.append("ContactCountry=").append(custDbObj.getContactCountry())
				.append("\n");
		buffer.append("BillContactPriPhone=")
				.append(custDbObj.getBillContactPriPhone()).append("\n");
		buffer.append("BillContactAltPhone=")
				.append(custDbObj.getBillContactAltPhone()).append("\n");
		buffer.append("BillContactCell=")
				.append(custDbObj.getBillContactCell()).append("\n");
		buffer.append("BillContactPager=")
				.append(custDbObj.getBillContactPager()).append("\n");
		buffer.append("BillContactEmail=")
				.append(custDbObj.getBillContactEmail()).append("\n");
		buffer.append("BillContactAddr1=")
				.append(custDbObj.getBillContactAddr1()).append("\n");
		buffer.append("BillContactAddr2=")
				.append(custDbObj.getBillContactAddr2()).append("\n");
		buffer.append("BillContactCity=")
				.append(custDbObj.getBillContactCity()).append("\n");
		buffer.append("BillContactState=")
				.append(custDbObj.getBillContactState()).append("\n");
		buffer.append("BillContactZip=").append(custDbObj.getBillContactZip())
				.append("\n");
		buffer.append("BillContactCountry=")
				.append(custDbObj.getBillContactCountry()).append("\n");
		buffer.append("SalesSegment=").append(custDbObj.getSalesSegment())
				.append("\n");
		buffer.append("SalesRepId=").append(custDbObj.getSalesRepId())
				.append("\n");
		buffer.append("SalesRepName=").append(custDbObj.getSalesRepName())
				.append("\n");
		buffer.append("SalesRepPhone=").append(custDbObj.getSalesRepPhone())
				.append("\n");
		buffer.append("SalesRepEmail=").append(custDbObj.getSalesRepEmail())
				.append("\n");
		buffer.append("CustCorpId=").append(custDbObj.getCustCorpId())
				.append("\n");
		buffer.append("OrderVerification=")
				.append(custDbObj.getOrderVerification()).append("\n");
		buffer.append("SupportName=").append(custDbObj.getSupportName())
				.append("\n");
		buffer.append("SupportPhone=").append(custDbObj.getSupportPhone())
				.append("\n");
		buffer.append("CommonCustomerId=")
				.append(custDbObj.getCommonCustomerId()).append("\n");
		buffer.append("VpnName=").append(custDbObj.getVpnName()).append("\n");
		buffer.append("NaspId=").append(custDbObj.getNaspId()).append("\n");
		buffer.append("CommonCustomerName=")
				.append(custDbObj.getCommonCustomerName()).append("\n");
		buffer.append("OrderPlatform=").append(custDbObj.getOrderPlatform())
				.append("\n");
		buffer.append("RestrictedAccess=")
				.append(custDbObj.getRestrictedAccess()).append("\n");
		buffer.append("EnterpriseTrunkingType=")
				.append(custDbObj.getEnterpriseTrunkingType()).append("\n");
		buffer.append("E2eiSensitivityLevel=")
				.append(custDbObj.getE2eiSensitivityLevel()).append("\n");
		buffer.append("gchid=").append(custDbObj.getGchId()).append("\n");
		buffer.append("EmeaServiceSupport=")
				.append(custDbObj.getEmeaServiceSupport()).append("\n");
		buffer.append("CustSensitivityLevel=")
				.append(custDbObj.getCustSensitivityLevel()).append("\n");
		buffer.append("CustGarmStatus=").append(custDbObj.getCustGarmStatus())
				.append("\n");
		buffer.append("ActiveInd=").append(custDbObj.getActiveInd())
				.append("\n");
		buffer.append("EnvOrderId=").append(custDbObj.getEnvOrderId())
				.append("\n");
		buffer.append("CreatedBy=").append(custDbObj.getCreatedBy())
				.append("\n");
		buffer.append("ModifiedBy=").append(custDbObj.getModifiedBy())
				.append("\n");
		buffer.append("LastModifiedDate=")
				.append(custDbObj.getLastModifiedDate()).append("\n");
		
		buffer.append("CalnetSubContractId=").append(custDbObj.getCalnetSubContractId()).append("\n");		//added by z658915
		
		log.info(buffer.toString());
	}

	public void printEntDbObj(DBTblEnterprise entDbObj) {
		StringBuffer buffer = new StringBuffer();
		buffer.append("EnterpriseId=").append(entDbObj.getEnterpriseId())
				.append("\n");
		buffer.append("CustType=").append(entDbObj.getCustType()).append("\n");
		buffer.append("CustMarket=").append(entDbObj.getCustMarket())
				.append("\n");
		buffer.append("PlatformIndicator=")
				.append(entDbObj.getPlatformIndicator()).append("\n");
		buffer.append("VmPartitionId=").append(entDbObj.getVmPartitionId())
				.append("\n");
		buffer.append("Pubip=").append(entDbObj.getPubip()).append("\n");
		buffer.append("OnNetInterco=").append(entDbObj.getOnNetInterco())
				.append("\n");
		buffer.append("SipDomain=").append(entDbObj.getSipDomain())
				.append("\n");
		buffer.append("AsId=").append(entDbObj.getAsId()).append("\n");
		buffer.append("EntcclInd=").append(entDbObj.getEntcclInd())
				.append("\n");
		buffer.append("QosInd=").append(entDbObj.getQosInd()).append("\n");
		buffer.append("VnetCorpId=").append(entDbObj.getVnetCorpId())
				.append("\n");
		buffer.append("ContractInd=").append(entDbObj.getContractInd())
				.append("\n");
		buffer.append("AgencyHierCode=").append(entDbObj.getAgencyHierCode())
				.append("\n");
		buffer.append("XrefCustomerId=").append(entDbObj.getXrefCustomerId())
				.append("\n");
		buffer.append("CallingPlanId=").append(entDbObj.getCallingPlanId())
				.append("\n");
		buffer.append("AuthServicesId=").append(entDbObj.getAuthServicesId())
				.append("\n");
		buffer.append("ActiveInd=").append(entDbObj.getActiveInd())
				.append("\n");
		buffer.append("CreatedBy=").append(entDbObj.getCreatedBy())
				.append("\n");
		buffer.append("ModifiedBy=").append(entDbObj.getModifiedBy())
				.append("\n");
		buffer.append("LastModifiedDate=")
				.append(entDbObj.getLastModifiedDate()).append("\n");
		buffer.append("EnterpriseId=").append(entDbObj.getEnterpriseId())
				.append("\n");
		buffer.append("CustType=").append(entDbObj.getCustType()).append("\n");
		buffer.append("CustMarket=").append(entDbObj.getCustMarket())
				.append("\n");
		buffer.append("PlatformIndicator=")
				.append(entDbObj.getPlatformIndicator()).append("\n");
		buffer.append("VmPartitionId=").append(entDbObj.getVmPartitionId())
				.append("\n");
		buffer.append("Pubip=").append(entDbObj.getPubip()).append("\n");
		buffer.append("OnNetInterco=").append(entDbObj.getOnNetInterco())
				.append("\n");
		buffer.append("SipDomain=").append(entDbObj.getSipDomain())
				.append("\n");
		buffer.append("AsId=").append(entDbObj.getAsId()).append("\n");
		buffer.append("EntcclInd=").append(entDbObj.getEntcclInd())
				.append("\n");
		buffer.append("QosInd=").append(entDbObj.getQosInd()).append("\n");
		buffer.append("VnetCorpId=").append(entDbObj.getVnetCorpId())
				.append("\n");
		buffer.append("ContractInd=").append(entDbObj.getContractInd())
				.append("\n");
		buffer.append("AgencyHierCode=").append(entDbObj.getAgencyHierCode())
				.append("\n");
		buffer.append("XrefCustomerId=").append(entDbObj.getXrefCustomerId())
				.append("\n");
		buffer.append("CallingPlanId=").append(entDbObj.getCallingPlanId())
				.append("\n");
		buffer.append("AuthServicesId=").append(entDbObj.getAuthServicesId())
				.append("\n");
		buffer.append("ActiveInd=").append(entDbObj.getActiveInd())
				.append("\n");
		buffer.append("EnvOrderId=").append(entDbObj.getEnvOrderId())
				.append("\n");
		// 53938.AA Business Continuity Ph 1 - changes for july 2011
		buffer.append("LorFlag=").append(entDbObj.getLorFlag()).append("\n");

		buffer.append("CreatedBy=").append(entDbObj.getCreatedBy())
				.append("\n");
		buffer.append("ModifiedBy=").append(entDbObj.getModifiedBy())
				.append("\n");
		buffer.append("LastModifiedDate=")
				.append(entDbObj.getLastModifiedDate()).append("\n");

		buffer.append("lorId=").append(entDbObj.getLorId()).append("\n");
		buffer.append("address=").append(entDbObj.getAddress()).append("\n");
		buffer.append("city=").append(entDbObj.getCity()).append("\n");
		buffer.append("state=").append(entDbObj.getState()).append("\n");
		buffer.append("zip=").append(entDbObj.getZip()).append("\n");
		buffer.append("country=").append(entDbObj.getCountry()).append("\n");
		buffer.append("soEnabled=").append(entDbObj.getSoEnabled())
				.append("\n");
		buffer.append("usLdAndLocalBestPool=")
				.append(entDbObj.getUsLdAndLocalBestPool()).append("\n");
		buffer.append("usLdOnlyBestPool=")
				.append(entDbObj.getUsLdOnlyBestPool()).append("\n");
		buffer.append("emeaApacBestPool=")
				.append(entDbObj.getEmeaApacBestPool()).append("\n");
		buffer.append("usLdAndLocalBestPlusPool=")
				.append(entDbObj.getUsLdAndLocalBestPlusPool()).append("\n");
		buffer.append("usLdOnlyBestPlusPool=")
				.append(entDbObj.getUsLdOnlyBestPlusPool()).append("\n");
		buffer.append("emeaApacBestPlusPool=")
				.append(entDbObj.getEmeaApacBestPlusPool()).append("\n");
		buffer.append("approvedCcl=").append(entDbObj.getApprovedCcl())
				.append("\n");
		buffer.append("entTrunkCCLSum=").append(entDbObj.getEntTrunkCclSum())
				.append("\n");
		buffer.append("custPriceBookId=").append(entDbObj.getCustPriceBookId())
				.append("\n");
		buffer.append("contractId=").append(entDbObj.getContractId())
				.append("\n");
		buffer.append("quoteId=").append(entDbObj.getQuoteId()).append("\n");
		buffer.append("CatalogueReferenceTime=")
				.append(entDbObj.getCatalogueReferenceTime()).append("\n");
		buffer.append("designId=").append(entDbObj.getDesignId()).append("\n");
		buffer.append("entcumccl=").append(entDbObj.getEntCumCcl()).append("\n");
		log.info(buffer.toString());
	}

	// EnterpriseId will be set before calling this method.
	public boolean getDialPlanByEnterpriseId() {
		try {
			TblDialPlanQuery dpQry = new TblDialPlanQuery();
			// populate dial plan bean from inventory
			if (getEnterpriseId() == null) {
				setStatus(InvErrorCode.INTERNAL_ERROR);
				return false;
			} else {
				String whereClause = new String("");
				if (getAll == false)
					whereClause = " where enterprise_id = \'" + customerId
							+ "\' and active_ind = 1";
				else
					whereClause = " where enterprise_id = \'" + customerId
							+ "\' and active_ind != 0";
				log.info("Before entQry in getDetails:whereCls"
						+ whereClause);
				dpQry.queryByWhere(dbCon, whereClause);
				log.info("Before entQry in getDetails");
				if (dpQry.size() > 0) {
					DialPlanBean dialPlanBean;
					dialPlanList = new ArrayList<DialPlanBean>();
					for (int i = 0; i < dpQry.size(); i++) {
						dialPlanBean = new DialPlanBean();
						dialPlanBean.copyFrom(dpQry.getDbBean(i));
						dialPlanList.add(dialPlanBean);
					}
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
			setStatus(InvErrorCode.DB_EXCEPTION);
			// setStatusDesc("DB_FAILURE in getDialPlanByEnterpriseId");
			return false;
		} catch (Exception e) {
			e.printStackTrace();
			setStatus(InvErrorCode.INTERNAL_ERROR);
			// setStatusDesc("FAILURE in getDialPlanByEnterpriseId");
			return false;
		}
		setStatus(InvErrorCode.SUCCESS);
		// setStatusDesc("Successfully retrieved DialPlan for the EnterpriseId"+
		// getEnterpriseId());
		return true;
	}

	public boolean addDialPlanToEnterprise() {
		try {
			if (dialPlanList.size() > 0) {
				for (int i = 0; i < dialPlanList.size(); i++) {
					DialPlanBean dialPlanBean = dialPlanList.get(i);
					DialPlan dialPlan = new DialPlan(dialPlanBean, dbCon);
					if (!dialPlan.addDialPlan()) {
						setStatus(InvErrorCode.INTERNAL_ERROR);
						// setStatusDesc(dialPlan.getStatusDesc());
						log.info(dialPlan.getStatusDesc());
						return false;
					}
				}
			} else {
				setStatus(InvErrorCode.SUCCESS);
				// setStatusDesc("No DialPlans to Add");
				log.info("No DialPlans to Add");
				return true;
			}
		} catch (Exception e) {
			e.printStackTrace();
			setStatus(InvErrorCode.ERROR_ADDING_DIALPLAN_TO_ENTERPRISE);
			// setStatusDesc("FAILURE in addDialPlanToEnterprise.");
			log.info("FAILURE in addDialPlanToEnterprise.");
			return false;
		}
		setStatus(InvErrorCode.SUCCESS);
		// setStatusDesc("Successfully added DialPlan to Enterprise");
		log.info("Successfully added DialPlan to Enterprise");
		return true;
	}

	public boolean deleteDialPlanFromEnterprise() {
		try {
			if (dialPlanList.size() > 0) {
				for (int i = 0; i < dialPlanList.size(); i++) {
					DialPlanBean dialPlanBean = dialPlanList.get(i);
					DialPlan dialPlan = new DialPlan(dialPlanBean, dbCon);
					if (!dialPlan.deleteDialPlan()) {
						setStatus(InvErrorCode.INTERNAL_ERROR);
						// setStatusDesc(dialPlan.getStatusDesc());
						log.info(dialPlan.getStatusDesc());
						return false;
					}
				}
			} else {
				setStatus(InvErrorCode.SUCCESS);
				// setStatusDesc("No Dial Plan to delete");
				log.info("No dial plan to delete");
				return true;
			}
		} catch (Exception e) {
			e.printStackTrace();
			setStatus(InvErrorCode.ERROR_DELETING_DIALPLAN_TO_ENTERPRISE);
			// setStatusDesc("FAILURE in deleteDialPlanFromEnterprise.");
			log.info("FAILURE in deleteDialPlanFromEnterprise.");
			return false;
		}
		setStatus(InvErrorCode.SUCCESS);
		// setStatusDesc("Successfully deleted dialp plan ");
		return true;
	}

	// NEWELY ADDED
	public boolean updateDialplanFromEnterprise() {
		try {
			if (dialPlanList.size() > 0) {
				for (int i = 0; i < dialPlanList.size(); i++) {
					DialPlanBean dialPlanBean = dialPlanList.get(i);
					DialPlan dialPlan = new DialPlan(dialPlanBean, dbCon);
					if (!dialPlan.modifyInDB()) {
						setStatus(InvErrorCode.INTERNAL_ERROR);
						// setStatusDesc(dialPlan.getStatusDesc());
						log.info(dialPlan.getStatusDesc());
						return false;
					}
				}
			} else {
				setStatus(InvErrorCode.SUCCESS);
				// setStatusDesc("No dial plan to Update");
				log.info("No Dial Plan to add");
				return true;
			}
		} catch (Exception e) {
			e.printStackTrace();
			setStatus(InvErrorCode.INTERNAL_ERROR);
			// setStatusDesc("FAILURE in updateDialplanFromEnterprise.");
			log.info("FAILURE in updateDialplanFromEnterprise.");
			return false;
		}
		setStatus(InvErrorCode.SUCCESS);
		// setStatusDesc("Successfully updated Dial Plan to Enterprise");
		return true;
	}

	public boolean addCallingPlanToEnterprise() {
		try {
			CallingPlan callingPlan = new CallingPlan(callingPlanBean, dbCon);
			if (!callingPlan.addToDB()) {
				setStatus(InvErrorCode.INTERNAL_ERROR);
				// setStatusDesc(callingPlan.getStatusDesc());
				log.info(callingPlan.getStatusDesc());
				return false;
			}

			DBTblEnterprise enterpriseDbBean = new DBTblEnterprise();
			enterpriseDbBean.setCallingPlanId(callingPlanBean
					.getCallingPlanId());
			if (callingPlanBean.getModifiedBy() != null
					&& !"".equals(callingPlanBean.getModifiedBy()))
				enterpriseDbBean.setModifiedBy(callingPlanBean.getModifiedBy());
			else
				enterpriseDbBean.setModifiedBy("ESAP_INV");
			enterpriseDbBean.setLastModifiedDate(new Timestamp(System
					.currentTimeMillis()));
			enterpriseDbBean.whereEnterpriseIdEQ(customerId);
			enterpriseDbBean.updateSpByWhere(dbCon);
		} catch (Exception e) {
			e.printStackTrace();
			setStatus(InvErrorCode.INTERNAL_ERROR);
			// setStatusDesc("FAILURE in addCallingPlanToEnterprise.");
			log.info("FAILURE in addCallingPlanToEnterprise.");
			return false;
		}
		setStatus(InvErrorCode.SUCCESS);
		// setStatusDesc("Successfully added CallingPlan to Enterprise");
		return true;
	}

	// NEWELY ADDED
	public boolean deleteCallingPlanfromEnterprise() {
		try {
			CallingPlan callingPlan = new CallingPlan(callingPlanBean, dbCon);
			if (!callingPlan.deleteCallingPlan()) {
				setStatus(InvErrorCode.INTERNAL_ERROR);
				// setStatusDesc(callingPlan.getStatusDesc());
				log.info(callingPlan.getStatusDesc());
				return false;
			}
		} catch (Exception e) {
			e.printStackTrace();
			setStatus(InvErrorCode.ERROR_DELETING_CALLINGPLAN_FROM_ENTERPRISE);
			// setStatusDesc("FAILURE in deleteCallingPlanfromEnterprise.");
			log.info("FAILURE in deleteCallingPlanfromEnterprise.");
			return false;
		}
		setStatus(InvErrorCode.SUCCESS);
		// setStatusDesc("Successfully deleted CallingPlan to Enterprise");
		return true;
	}

	// NEWELY ADDED. SHOULD CHECK!!!
	public boolean updateCallingPlanFromEnterprise() {
		try {
			CallingPlan callingPlan = new CallingPlan(callingPlanBean, dbCon);
			if (!callingPlan.modifyInDB()) {
				setStatus(InvErrorCode.INTERNAL_ERROR);
				// setStatusDesc(callingPlan.getStatusDesc());
				log.info(callingPlan.getStatusDesc());
				return false;
			}
		} catch (Exception e) {
			e.printStackTrace();
			setStatus(InvErrorCode.INTERNAL_ERROR);
			// setStatusDesc("FAILURE in updateCallingPlanfromEnterprise.");
			log.info("FAILURE in updateCallingPlanfromEnterprise.");
			return false;
		}
		setStatus(InvErrorCode.SUCCESS);
		// setStatusDesc("Successfully updated CallingPlan to Enterprise");
		return true;
	}

	public boolean addDeviceToEnterprise() {
		try {
			if (deviceList.size() > 0) {
				for (int i = 0; i < deviceList.size(); i++) {
					GatewayDeviceBean gwDevBean = deviceList.get(i);
					GatewayDevice gwDev = new GatewayDevice(gwDevBean, dbCon);
					if (!gwDev.addGatewayDevice()) {
						setStatus(InvErrorCode.INTERNAL_ERROR);
						// setStatusDesc(gwDev.getStatusDesc());
						log.info(gwDev.getStatusDesc());
						return false;
					}

					Device device = new Device(dbCon);
					device.setEnterpriseId(customerId);
					device.setGwDeviceId(gwDev.getGatewayDeviceId());
					device.addDeviceMap();
				}
			} else {
				setStatus(InvErrorCode.SUCCESS);
				// setStatusDesc("No gateway Devices to Add");
				log.info("No gateway Devices to Add");
				return true;
			}
		} catch (Exception e) {
			e.printStackTrace();
			setStatus(InvErrorCode.NOT_ABLE_ADD_DEVICES);
			// setStatusDesc("FAILURE in adddeviceToEnterprise.");
			log.info("FAILURE in addDeviceToEnterprise.");
			return false;
		}
		setStatus(InvErrorCode.SUCCESS);
		// setStatusDesc("Successfully added Device to Enterprise");
		return true;
	}

	

	// NEWELY ADDED
	public boolean updateDeviceFromEnterprise() {
		try {
			if (deviceList.size() > 0) {
				for (int i = 0; i < deviceList.size(); i++) {
					GatewayDeviceBean gwDevBean = deviceList.get(i);
					GatewayDevice gwDev = new GatewayDevice(gwDevBean, dbCon);
					if (!gwDev.updateGatewayDevice()) {
						setStatus(InvErrorCode.INTERNAL_ERROR);
						// setStatusDesc(gwDev.getStatusDesc());
						log.info(gwDev.getStatusDesc());
						return false;
					}
				}
			} else {
				setStatus(InvErrorCode.SUCCESS);
				// setStatusDesc("No gateway Devices to Update");
				log.info("No gateway Devices to update");
				return true;
			}
		} catch (Exception e) {
			e.printStackTrace();
			setStatus(InvErrorCode.ERROR_MODIFYING_DEVICE_FROM_ENTERPRISE);
			// setStatusDesc("FAILURE in updateDeviceFromEnterprise.");
			log.info("FAILURE in updateDeviceFromEnterprise.");
			return false;
		}
		setStatus(InvErrorCode.SUCCESS);
		// setStatusDesc("Successfully updated Device to Enterprise");
		return true;
	}

	

	

	

	

	

	

	public boolean updateBsAsToEnterprise() {
		try {
			int bsAsId = bsAsDbBean.getBsAsId();
			bsAsDbBean.whereBsAsIdEQ(bsAsId);
			if (!(bsAsDbBean.updateSpByWhere(dbCon) > 0)) {
				setStatus(InvErrorCode.INTERNAL_ERROR);
				return false;
			}
		} catch (Exception e) {
			e.printStackTrace();
			setStatus(InvErrorCode.INTERNAL_ERROR);
			// setStatusDesc("FAILURE in addBsAsToEnterprise.");
			log.info("FAILURE in addBsAsToEnterprise.");
			return false;
		}
		setStatus(InvErrorCode.SUCCESS);
		// setStatusDesc("Successfully updated BsAs to Enterprise");
		return true;
	}

	


	

	// Added by Vijaykumar S on 02-09-09
	public boolean getEnterpriseAdminList() {
		log.info("Entering Enterprise::getEnterpriseAdminList");
		try {
			TblEnterpriseAdminQuery entAdminQry = new TblEnterpriseAdminQuery();
			String whereClause = " where enterprise_id = " + customerId;
			entAdminQry.queryByWhere(dbCon, whereClause);
			if (entAdminQry.size() <= 0) {
				log.info("No Records Found in Enterprise Admin");
				return false;
			}
			for (int i = 0; i < entAdminQry.size(); i++) {
				TblEnterpriseAdminDbBean entAdminDbBean = entAdminQry
						.getDbBean(i);
				EnterpriseAdminBean entAdminBean = new EnterpriseAdminBean();
				entAdminBean.setEnterpriseId(entAdminDbBean.getEnterpriseId());
				entAdminBean.setAdminEmail(entAdminDbBean.getAdminEmail());
				entAdminBean.setAdminFirstName(entAdminDbBean
						.getAdminFirstName());
				entAdminBean
						.setAdminLastName(entAdminDbBean.getAdminLastName());
				entAdminBean.setAdminType(entAdminDbBean.getAdminType());
				entAdminBean.setAdminWebLoginId(entAdminDbBean
						.getAdminWebLoginId());

				entAdminBean.setRegionId(entAdminDbBean.getRegionId());
				entAdminBean.setWebLang(entAdminDbBean.getWebLang());
				entAdminBean.setPassword(entAdminDbBean.getPassword());
				entAdminList.add(entAdminBean);
			}
		} catch (SQLException e) {
			e.printStackTrace();
			setStatus(InvErrorCode.DB_EXCEPTION);
			return false;
		} catch (Exception e) {
			e.printStackTrace();
			setStatus(InvErrorCode.INTERNAL_ERROR);
			log.info("FAILURE in getEnterpriseAdminList");
			return false;
		}
		setStatus(InvErrorCode.SUCCESS);
		return true;
	}

	public List<EnterpriseAdminBean> getEntAdminList() {
		return entAdminList;
	}

	public boolean getPublicRoutingList() {
		log.info("Entering Enterprise::getPublicRoutingList");
		try {
			TblPrefixRoutingQuery prQry = new TblPrefixRoutingQuery();
			String whereClause = " where enterprise_id = " + customerId;
			prQry.queryByWhere(dbCon, whereClause);
			if (prQry.size() <= 0) {
				log.info("No Records Found in PrefixRouting");
				return false;
			}
			for (int i = 0; i <= prQry.size(); i++) {
				TblPrefixRoutingDbBean prDbBean = prQry.getDbBean(i);
				PrefixRoutingBean prBean = new PrefixRoutingBean();
				prBean.setEnterpriseId(prDbBean.getEnterpriseId());
				prBean.setLocationId(prDbBean.getLocationId());
				prBean.setPrefixType(prDbBean.getPrefixType());
				prBean.setInterLocationPrefix(prDbBean.getInterLocationPrefix());
				prBean.setInterLocationExtLength(prDbBean
						.getInterLocationExtLength());
				prBean.setInterLocationPrefixAdd(prDbBean
						.getInterLocationPrefixAdd());
				prBean.setInterLocationDigitStrip(prDbBean
						.getInterLocationDigitsStrip());
				prBean.setEnvOrderId(prDbBean.getEnvOrderId());
				prBean.setCreatedBy(prDbBean.getCreatedBy());
				prBean.setModifiedBy(prDbBean.getModifiedBy());
				prBean.setLastModifiedDate(prDbBean.getLastModifiedDate());
				prefixRoutingList.add(prBean);
			}
		} catch (SQLException e) {
			e.printStackTrace();
			setStatus(InvErrorCode.DB_EXCEPTION);
			// setStatusDesc("DB_FAILURE in getPublicRoutingList");
			return false;
		} catch (Exception e) {
			e.printStackTrace();
			setStatus(InvErrorCode.INTERNAL_ERROR);
			// setStatusDesc("FAILURE in getPublicRoutingList.");
			log.info("FAILURE in getPublicRoutingList.");
			return false;
		}
		setStatus(InvErrorCode.SUCCESS);
		// setStatusDesc("Successfully Retrieved PublicRoutingList");
		return true;
	}

	// Fetch Third Party Device from TBL_VZB_STATE_GATEWAY_MAP. Get Unique
	// records by State
	public boolean getThirdPartyDevices() {
		log.info("Entering Enterprise::getThirdPartyDevice");
		try {
			TblVzbStateGatewayMapQuery vzbgwQry = new TblVzbStateGatewayMapQuery();
			String whereClause;
			if (contactState != null && !contactState.equalsIgnoreCase(""))
				whereClause = " where state_name = " + contactState;
			else
				whereClause = " where 1=1 ";

			log.info("Before vzbgwQry in getDetails");
			vzbgwQry.queryByWhere(dbCon, whereClause);

			if (vzbgwQry.size() <= 0) {
				log.info("No Records Found in Vzb State Gateway Map");
				return false;
			}
			log.info("No Records Found in Vzb State Gateway Map"
					+ vzbgwQry.size());
			thirdPartyDeviceList = new ArrayList<TblVzbStateGatewayMapDbBean>();
			for (int i = 0; i < vzbgwQry.size(); i++) {
				TblVzbStateGatewayMapDbBean vzbgwDb = new TblVzbStateGatewayMapDbBean();
				vzbgwDb.copyFrom(vzbgwQry.getDbBean(i));
				thirdPartyDeviceList.add(vzbgwDb);
			}
		} catch (SQLException e) {
			setStatus(InvErrorCode.DB_EXCEPTION);
			// setStatusDesc("DB_FAILURE in getThirdPartyDevices");
			e.printStackTrace();
			return false;
		} catch (Exception e) {
			setStatus(InvErrorCode.INTERNAL_ERROR);
			// setStatusDesc("FAILURE in getThirdPartyDevices.");
			log.info("FAILURE in getThirdPartyDevices.");
			e.printStackTrace();
			return false;
		}
		setStatus(InvErrorCode.SUCCESS);
		// setStatusDesc("Successfully Retrieved Third Party Devices");
		return true;
	}

	public List<String> getLocationIdListByEnterpriseId() throws SQLException {
		TblLocationQuery locQry = new TblLocationQuery();
		List<String> locationIdList = null;
		if (getEnterpriseId() == null
				|| getEnterpriseId().trim().equalsIgnoreCase("")) {
			System.out
					.println("In Enterprise:getLocationIdListByEnterpriseId. Invalid EnterpriseId input");
			return null;
		}
		String whereClause = new String("");
		if (getAll == false)
			whereClause = "where enterprise_id ='" + getEnterpriseId()
					+ "' and active_ind =" + VzbVoipEnum.ActiveInd.ACTIVE;
		else
			whereClause = "where enterprise_id ='" + getEnterpriseId()
					+ "' and active_ind !=" + VzbVoipEnum.ActiveInd.INACTIVE;
		locQry.queryByWhere(dbCon, whereClause);

		if (locQry.size() <= 0) {
			System.out
					.println("In Enterprise:getLocationIdListByEnterpriseId. No Locations with this Enterprise"
							+ getEnterpriseId());
			return null;
		} else {
			locationIdList = new ArrayList();
			for (int i = 0; i < locQry.size(); i++) {
				locationIdList.add(locQry.getDbBean(i).getLocationId());
			}
		}
		return locationIdList;
	}

	public boolean getDepartmentListByEnterpriseId() throws Exception {
		if (getEnterpriseId() == null
				|| getEnterpriseId().trim().equalsIgnoreCase("")) {
			System.out
					.println("In Enterprise:getDepartmentListByEnterpriseId. Invalid EnterpriseId input");
			return false;
		}
		TblDepartmentQuery depQry = new TblDepartmentQuery();

		String whereClause = "where enterprise_id =\'" + getEnterpriseId()
				+ "\'";
		depQry.queryByWhere(dbCon, whereClause);

		if (depQry.size() <= 0) {
			System.out
					.println("In Enterprise:getDepartmentListByEnterpriseId. No Departments with this Enterprise"
							+ getEnterpriseId());
			return false;
		} else {
			departmentList = new ArrayList<DepartmentBean>();
			for (int i = 0; i < depQry.size(); i++) {
				TblDepartmentDbBean depBean = depQry.getDbBean(i);
				DepartmentBean invDepBean = new DepartmentBean();
				invDepBean.setDepartmentId(depBean.getDepartmentId());
				invDepBean.setEnterpriseId(depBean.getEnterpriseId());
				invDepBean.setParentDeptId(depBean.getParentDeptId());
				invDepBean.setDepartmentName(depBean.getDepartmentName());
				invDepBean.setContactNumber(depBean.getContactNumber());
				invDepBean.setContactName(depBean.getContactName());
				invDepBean.setCallingPlanId(depBean.getCallingPlanId());
				invDepBean.setActiveInd(depBean.getActiveInd());
				invDepBean.setEnvOrderId(depBean.getEnvOrderId());
				invDepBean.setCreatedBy(depBean.getCreatedBy());
				invDepBean.setModifiedBy(depBean.getModifiedBy());
				invDepBean.setCreationDate(depBean.getCreationDate());
				invDepBean.setLastModifiedDate(depBean.getLastModifiedDate());
				departmentList.add(invDepBean);
			}
		}
		return true;
	}

	public List<String> getSipDomainListByEnterpriseId() throws SQLException {
		ArrayList<String> sipDomainList = new ArrayList<String>();
		if (getEnterpriseId() != null && !"".equals(getEnterpriseId())) {
			TblDialPlanQuery dialPlanQry = new TblDialPlanQuery();
			dialPlanQry.whereEnterpriseIdEQ(getEnterpriseId());
			dialPlanQry.query(dbCon);
			if (dialPlanQry.size() > 0) {
				for (int i = 0; i < dialPlanQry.size(); i++) {
					TblSipDomainQuery sipDomQry = new TblSipDomainQuery();
					sipDomQry.whereDialPlanIdEQ(dialPlanQry.getDbBean(i)
							.getDialPlanId());
					sipDomQry.query(dbCon);
					if (sipDomQry.size() > 0) {
						for (int j = 0; j < sipDomQry.size(); j++) {
							sipDomainList.add(sipDomQry.getDbBean(j)
									.getDomainName());
						}
					}
				}
			}
			return sipDomainList;
		} else {
			System.out
					.println("Invalid input for getSipDomainListByEnterpriseId, need to set EnterpriseId");
			return sipDomainList;
		}
	}

	/*** Ports available & ports used ***/

	public boolean updatePortsByEnterpriseId(String enterpriseID)
			throws SQLException {
		if (enterpriseID == null || enterpriseID.trim().equalsIgnoreCase("")) {
			System.out
					.println("In Enterprise:getDepartmentListByEnterpriseId. Invalid EnterpriseId input");
			return false;
		}
		updateSipDevicePortsByEnterpriseID(enterpriseID);
		updateGateWayDevicePortsByEnterpriseID(enterpriseID);
		return true;

	}

	private void updateSipDevicePortsByEnterpriseID(String enterpriseID)
			throws SQLException {

		PreparedStatement pStmt = null;
		ResultSet rs = null;

		String sipDevicesql = " update tbl_sip_device_info updSipdevice set (updSipdevice.ports_assigned,   updSipdevice.ports_available) = ( select updResult.pusage,decode(updResult.maxPorts,99999999999,'', updResult.availPorts) from "
				+ " (select aa.sip_device_id,aa.portusage pusage,maxPorts maxPorts,(  maxPorts - aa.portusage)  availPorts from (select a.device_map_id sip_device_id,count(*) portusage from tbl_device_map a,tbl_subscriber_device b "
				+ " where a.enterprise_id= ? and "
				+ " a.device_map_id = b.device_map_id  group by a.device_map_id order by a.device_map_id)  aa, "
				+ " (select sip.sip_device_id sip_device_id, nvl(dBsType.max_num_ports,99999999999) maxPorts from tbl_sip_device_info sip,tbl_DEVICE_TYPES dType, tbl_device_bstype dBsType where sip.device_type_id = dType.device_type_id "
				+ " and dType.device_bstype_id = dBsType.device_bstype_id) bb "
				+ " where aa.sip_device_id = bb.sip_device_id)   updResult where updSipdevice.sip_device_id = updResult.sip_device_id ) "
				+ " where exists ( "
				+ " select updResult.pusage,updResult.availPorts from "
				+ " (select aa.sip_device_id,aa.portusage pusage,maxPorts maxPorts,(  maxPorts - aa.portusage)  availPorts from (select a.device_map_id sip_device_id,count(*) portusage from tbl_device_map a,tbl_subscriber_device b "
				+ " where a.enterprise_id= ?  and "
				+ " a.device_map_id = b.device_map_id  group by a.device_map_id order by a.device_map_id)  aa, "
				+ " (select sip.sip_device_id sip_device_id, nvl(dBsType.max_num_ports,99999999999) maxPorts from tbl_sip_device_info sip,tbl_DEVICE_TYPES dType, tbl_device_bstype dBsType where sip.device_type_id = dType.device_type_id "
				+ " and dType.device_bstype_id = dBsType.device_bstype_id) bb "
				+ " where aa.sip_device_id = bb.sip_device_id)   updResult where updSipdevice.sip_device_id = updResult.sip_device_id) ";

		try {
			pStmt = dbCon.prepareStatement(sipDevicesql);
			log.info("EnterPriseId" + enterpriseID);
			log.info("SqlStatment" + sipDevicesql);
			if (pStmt != null) {
				pStmt.setString(1, enterpriseID);
				pStmt.setString(2, enterpriseID);
				pStmt.executeUpdate();
			}

		} catch (SQLException e) {
			e.printStackTrace();
			throw e;
		} finally {
			releaseResource(pStmt, rs);
		}
	}

	private void updateGateWayDevicePortsByEnterpriseID(String enterpriseID)
			throws SQLException {

		PreparedStatement pStmt = null;
		ResultSet rs = null;

		String gateWayDevicesql = " update tbl_gateway_device_info updGtwdevice set (updGtwdevice.ports_assigned,   updGtwdevice.ports_available) = (  select updResult.portUsage,decode(updResult.maxPorts,99999999999,'', updResult.availPorts) from "
				+ " (  select gtwdeviceUsgCount.device_map_id,gtwdeviceUsgCount.portUsage,gtwdeviceDetail.maxPorts, (gtwdeviceDetail.maxPorts - gtwdeviceUsgCount.portUsage) availPorts from  "
				+ " (  select aa.device_map_id  device_map_id,count(*) portUsage from "
				+ " ( "
				+ "  select  device_map_id  from tbl_subscriber_device tGroup  where device_map_id in (select gateway_device_id from tbl_device_map where gateway_device_id is not null and enterprise_id= ? ) "
				+ "  union all "
				+ "  select  tGroup.device_map_id device_map_id from tbl_group tGroup, tbl_group_tn  tGroupTn,tbl_device_map tDeviceGroup where tDeviceGroup.enterprise_id = ?  and tDeviceGroup.gateway_device_id is not null "
				+ "  and  tGroup.device_map_id = tDeviceGroup.device_map_id and  tGroupTn.group_id = tGroup.group_id "
				+ "  )  aa group by  aa.device_map_id  order by aa.device_map_id) gtwdeviceUsgCount, "
				+ " ( select gtw.gateway_device_id device_map_id, nvl(dBsType.max_num_ports,99999999999) maxPorts from tbl_gateway_device_info gtw,tbl_DEVICE_TYPES dType, tbl_device_bstype dBsType where gtw.device_type_id = dType.device_type_id "
				+ "       and dType.device_bstype_id = dBsType.device_bstype_id  )  gtwdeviceDetail "
				+ "       where gtwdeviceUsgCount.device_map_id = gtwdeviceDetail.device_map_id )   updResult  where updResult.device_map_id = updGtwdevice.gateway_device_id ) "
				+ "       where  exists "
				+ " ( select updResult.portUsage,updResult.availPorts from "
				+ " (  select gtwdeviceUsgCount.device_map_id,gtwdeviceUsgCount.portUsage,gtwdeviceDetail.maxPorts, (gtwdeviceDetail.maxPorts - gtwdeviceUsgCount.portUsage) availPorts from "
				+ " (  select aa.device_map_id  device_map_id,count(*) portUsage from  "
				+ " (  select  device_map_id  from tbl_subscriber_device tGroup  where device_map_id in (select gateway_device_id from tbl_device_map where gateway_device_id is not null and enterprise_id= ? ) "
				+ "  union all "
				+ "       select  tGroup.device_map_id device_map_id from tbl_group tGroup, tbl_group_tn  tGroupTn,tbl_device_map tDeviceGroup where tDeviceGroup.enterprise_id = ?  and tDeviceGroup.gateway_device_id is not null "
				+ "   and  tGroup.device_map_id = tDeviceGroup.device_map_id and  tGroupTn.group_id = tGroup.group_id "
				+ " )  aa group by  aa.device_map_id  order by aa.device_map_id) gtwdeviceUsgCount,  "
				+ " (select gtw.gateway_device_id device_map_id, nvl(dBsType.max_num_ports,99999999999) maxPorts from tbl_gateway_device_info gtw,tbl_DEVICE_TYPES dType, tbl_device_bstype dBsType where gtw.device_type_id = dType.device_type_id "
				+ " and dType.device_bstype_id = dBsType.device_bstype_id  )  gtwdeviceDetail "
				+ " where gtwdeviceUsgCount.device_map_id = gtwdeviceDetail.device_map_id )    updResult  where updResult.device_map_id = updGtwdevice.gateway_device_id ) ";

		try {
			pStmt = dbCon.prepareStatement(gateWayDevicesql);
			log.info("EnterPriseId" + enterpriseID);
			log.info("SqlStatment" + gateWayDevicesql);
			if (pStmt != null) {
				pStmt.setString(1, enterpriseID);
				pStmt.setString(2, enterpriseID);
				pStmt.setString(3, enterpriseID);
				pStmt.setString(4, enterpriseID);
				pStmt.executeUpdate();
			}

		} catch (SQLException e) {
			e.printStackTrace();
			throw e;
		} finally {
			releaseResource(pStmt, rs);
		}
	}

	private void releaseResource(Statement stmt, ResultSet rs) {
		try {
			if (stmt != null) {
				stmt.close();
			}
			if (rs != null) {
				rs.close();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	/***
	 * this method used by cssop only. They requested few parameters to avoid
	 * Performance issues. this bean can't be used for update/read only data.
	 * 
	 * @return
	 */
	public boolean getEnterpriseDetails() {
		try {
			TblEnterpriseQuery entQry = new TblEnterpriseQuery();
			initilizeTODefault();
			// entQry.whereEnterpriseIdEQ(customerId);
			String whereClause = new String("");
			if (getAll == false)
				whereClause = " where enterprise_id = \'" + customerId
						+ "\' and active_ind = 1";
			else
				whereClause = " where enterprise_id = \'" + customerId
						+ "\' and active_ind != 0";
			log.info("Before entQry in getDetails:" + whereClause);
			entQry.queryByWhere(dbCon, whereClause);
			log.info("after entQry in getDetails");
			if (entQry.size() == 1) {
				TblEnterpriseDbBean enterpriseDBBean = entQry.getDbBean(0);
				setEnterpriseId(enterpriseDBBean.getEnterpriseId());
				setCustomerType(enterpriseDBBean.getCustType());
				setCustMarket(enterpriseDBBean.getCustMarket());
				setPlatformIndicator(enterpriseDBBean.getPlatformIndicator());
				setVmPartitionId(enterpriseDBBean.getVmPartitionId());
				setPubIp(enterpriseDBBean.getPubip());
				setOnNetInterco(enterpriseDBBean.getOnNetInterco());
				setSipDomain(enterpriseDBBean.getSipDomain());
				setEntCclInd(enterpriseDBBean.getEntcclInd());
				setQosInd(enterpriseDBBean.getQosInd());
				setIeanLength(enterpriseDBBean.getIeanLength());
				setVnetCorpId(enterpriseDBBean.getVnetCorpId());
				setContractInd(enterpriseDBBean.getContractInd());
				setAgencyHierCode(enterpriseDBBean.getAgencyHierCode());
				setXrefCustomerId(enterpriseDBBean.getXrefCustomerId());
				setCallingPlanId(enterpriseDBBean.getCallingPlanId());
				setAuthServicesId(enterpriseDBBean.getAuthServicesId());
				setEnvOrderId(enterpriseDBBean.getEnvOrderId());
				setCreatedBy(enterpriseDBBean.getCreatedBy());
				setModifiedBy(enterpriseDBBean.getModifiedBy());
				setCreationDate(enterpriseDBBean.getCreationDate());
				setLastModifiedDate(enterpriseDBBean.getLastModifiedDate());
				setEntActiveInd(enterpriseDBBean.getActiveInd());
				setBsBlockInd(enterpriseDBBean.getBsBlockInd());
				setIsRIVCustomer(enterpriseDBBean.getRivCustomer());
				// 53938.AA Business Continuity Ph 1 - changes for july 2011
				setLorFlag(enterpriseDBBean.getLorFlag());
				setSoEnabled(enterpriseDBBean.getSoEnabled());
				setUsLdAndLocalBestPool(enterpriseDBBean
						.getUsLdAndLocalBestPool());
				setUsLdOnlyBestPool(enterpriseDBBean.getUsLdOnlyBestPool());
				setEmeaApacBestPool(enterpriseDBBean.getEmeaApacBestPool());
				setUsLdAndLocalBestPlusPool(enterpriseDBBean
						.getUsLdAndLocalBestPlusPool());
				setUsLdOnlyBestPlusPool(enterpriseDBBean
						.getUsLdOnlyBestPlusPool());
				setEmeaApacBestPlusPool(enterpriseDBBean
						.getEmeaApacBestPlusPool());
				setApprovedCcl(enterpriseDBBean.getApprovedCcl());
				setEntTrunkCclSum(enterpriseDBBean.getEntTrunkCclSum());
				setCustPriceBookId(enterpriseDBBean.getCustPriceBookId());
				setContractId(enterpriseDBBean.getContractId());
				setQuoteId(enterpriseDBBean.getQuoteId());
				setCatalogueReferenceTime(enterpriseDBBean
						.getCatalogueReferenceTime());
				setDesignId(enterpriseDBBean.getDesignId());
				setEntCumCcl(enterpriseDBBean.getEntCumCcl());
			} else {
				setStatus(InvErrorCode.DATA_NOTFOUND);
				// setStatusDesc("Couldn't find any Enterprise with the given EnterpriseId");
				return false;
			}

			// IR #1484223: Enterprise getDetails API do not return OnNetStat
			// parameter
			TblDialPlanQuery dialPlanQuery = new TblDialPlanQuery();
			dialPlanQuery.whereEnterpriseIdEQ(customerId);
			dialPlanQuery.whereDefaultFlagEQ(1);
			dialPlanQuery.query(dbCon);

			if (dialPlanQuery.size() > 0) {
				log.info(" OnNetSat "
						+ dialPlanQuery.getDbBean(0).getOnNetStat());
				setOnNetStat(dialPlanQuery.getDbBean(0).getOnNetStat());
			}
			log.info(" GetOnNetStat " + getOnNetStat());

			TblCustomerQuery custQry = new TblCustomerQuery();
			// custQry.whereCustomerIdEQ(customerId);

			String whereClauseCust = new String("");
			if (getAll == false)
				whereClauseCust = " where customer_id = \'" + customerId
						+ "\' and active_ind = 1";
			else
				whereClauseCust = " where customer_id = \'" + customerId
						+ "\' and active_ind != 0";

			log.info("before custQry");
			custQry.queryByWhere(dbCon, whereClauseCust);
			log.info("after custQry");
			if (custQry.size() == 1) {
				TblCustomerDbBean customerDBBean = custQry.getDbBean(0);
				setCustomerId(customerDBBean.getCustomerId());
				setCustomerName(customerDBBean.getCustomerName());
				setAccountName(customerDBBean.getAccountName());
				setRegionId(customerDBBean.getRegionId());
				setProductType(customerDBBean.getProductType());
				if (customerDBBean.getUsBillingSystem() != 0)
					setBillingSystem(customerDBBean.getUsBillingSystem());
				else
					setBillingSystem(customerDBBean.getEmeaBillingSystem());
				setEmeaBillingSystem(customerDBBean.getEmeaBillingSystem());
				setOrderSource(customerDBBean.getOrderSource());
				setContactFirstName(customerDBBean.getContactFirstName());
				setContactLastName(customerDBBean.getContactLastName());
				setContactTitle(customerDBBean.getContactTitle());
				setContactPrimaryPhone(customerDBBean.getContactPriPhone());
				setContactAltPhone(customerDBBean.getContactAltPhone());
				setContactFax(customerDBBean.getContactFax());
				setContactCell(customerDBBean.getContactCell());
				setContactPager(customerDBBean.getContactPager());
				setContactEmail(customerDBBean.getContactEmail());
				setContactAddr1(customerDBBean.getContactAddr1());
				setContactAddr2(customerDBBean.getContactAddr2());
				setContactCity(customerDBBean.getContactCity());
				setContactState(customerDBBean.getContactState());
				setContactZip(customerDBBean.getContactZip());
				setContactCountry(customerDBBean.getContactCountry());
				setBillContactPriPhone(customerDBBean.getBillContactPriPhone());
				setBillContactAltPhone(customerDBBean.getBillContactAltPhone());
				setBillContactCell(customerDBBean.getBillContactCell());
				setBillContactPager(customerDBBean.getBillContactPager());
				setBillContactEmail(customerDBBean.getBillContactEmail());
				setBillContactAddr1(customerDBBean.getBillContactAddr1());
				setBillContactAddr2(customerDBBean.getBillContactAddr2());
				setBillContactCity(customerDBBean.getBillContactCity());
				setBillContactState(customerDBBean.getBillContactState());
				setBillContactZip(customerDBBean.getBillContactZip());
				setBillContactCountry(customerDBBean.getBillContactCountry());
				setSalesSegment(customerDBBean.getSalesSegment());
				setEnterpriseTrunkingType(customerDBBean
						.getEnterpriseTrunkingType());
				setE2eiSensitivityLevel(customerDBBean
						.getE2eiSensitivityLevel());
				setSalesRepId(customerDBBean.getSalesRepId());
				setSalesRepName(customerDBBean.getSalesRepName());
				setSalesRepPhone(customerDBBean.getSalesRepPhone());
				setSalesRepEmail(customerDBBean.getSalesRepEmail());
				setCustCorpId(customerDBBean.getCustCorpId());
				setOrderVerification(customerDBBean.getOrderVerification());
				setSupportName(customerDBBean.getSupportName());
				setSupportPhone(customerDBBean.getSupportPhone());
				setEmeaServiceSupport(customerDBBean.getEmeaServiceSupport());
				setCustSensitivityLevel(customerDBBean
						.getCustSensitivityLevel());
				setCustGarmStatus(customerDBBean.getCustGarmStatus());
				setCommonCustomerId(customerDBBean.getCommonCustomerId());
				setVpnName(customerDBBean.getVpnName());
				// jan 2011 Rel changes
				setNaspId(customerDBBean.getNaspId());
				setCommonCustomerName(customerDBBean.getCommonCustomerName());

				setCustActiveInd(customerDBBean.getActiveInd());
				setEnvOrderId(customerDBBean.getEnvOrderId());
				setE2eiMigStatus(customerDBBean.getE2eiMigFlag());
				setE2eiMigLock(customerDBBean.getE2eiMigLock());
				setE2eiMigDate(customerDBBean.getE2eiMigDate());
				
				setCalnetSubContractId(customerDBBean.getCalnetSubContractId());		//added by z658915 
			}
		} catch (SQLException e) {
			setStatus(InvErrorCode.DB_EXCEPTION);
			e.printStackTrace();
			// setStatusDesc("DB_FAILURE in getDetails Enterprise");
			return false;
		} catch (Exception e) {
			e.printStackTrace();
			setStatus(InvErrorCode.INTERNAL_ERROR);
			// setStatusDesc("FAILURE in getDetails Enterprise");
			return false;
		}
		setStatus(InvErrorCode.SUCCESS);
		// setStatusDesc("Successfully retrieved enterprise from the DB");
		return true;
	}

	public boolean getAuthDetailsForCSSOPEnterprise() {
		try {
			TblEnterpriseQuery entQry = new TblEnterpriseQuery();
			String whereClause = new String("");
			if (getAll == false)
				whereClause = " where enterprise_id = \'" + customerId
						+ "\' and active_ind = 1";
			else
				whereClause = " where enterprise_id = \'" + customerId
						+ "\' and active_ind != 0";
			log.info("Before entQry in getauthDetails" + whereClause);
			entQry.queryByWhere(dbCon, whereClause);
			log.info("Before entQry in getAuthDetails");
			if (entQry.size() == 1) {
				long authSerId = (entQry.getDbBean(0)).getAuthServicesId();
				if (authSerId > 0) {
					if (!getAuthFeaturesByAuthServicesIdForCSSOP((int) authSerId)) {
						setStatus(InvErrorCode.INTERNAL_ERROR);
						// setStatusDesc("FAILURE in getAuthDetails Enterprise. No auth services for the given  auth services id.");
						System.out
								.println("FAILURE in getAuthDetails Enterprise. No auth services for the given  auth services id.");
						return false;
					}
				} else {
					setStatus(InvErrorCode.INTERNAL_ERROR);
					// setStatusDesc("FAILURE in getAuthDetails Enterprise. Invalid auth services id for enterprise");
					System.out
							.println("FAILURE in getAuthDetails Enterprise. Invalid auth services id for enterprise");
					return false;
				}
			} else {
				setStatus(InvErrorCode.INTERNAL_ERROR);
				// setStatusDesc("FAILURE in getAuthDetails Enterprise. Invalid enterprise for the given enterprise id");
				System.out
						.println("FAILURE in getAuthDetails Enterprise. Invalid enterprise for the given enterprise id");
				return false;
			}
		} catch (Exception e) {
			e.printStackTrace();
			setStatus(InvErrorCode.DB_EXCEPTION);
			// setStatusDesc("DB FAILURE in getAuthDetails for Enterprise");
			return false;
		}
		setStatus(InvErrorCode.SUCCESS);
		// setStatusDesc("Successfully retrieved auth details for enterprise from the DB");
		return true;
	}

	boolean getAuthFeaturesByAuthServicesIdForCSSOP(int authServId)
			throws Exception {
		TblAuthServicesQuery authQry = new TblAuthServicesQuery();
		authQry.whereAuthServiceIdEQ(authServId);
		authQry.setOrderBy("FEATURE_ID");
		log.info("before authFeaturesQry");
		authQry.query(dbCon);
		log.info("after authFeaturesQry");
		int authResultSize = authQry.size();
		if (authResultSize > 0) {
			int[] TblVzbFeatureIds = new int[authResultSize];
			for (int i = 0; i < authResultSize; i++) {
				TblAuthServicesDbBean authDBbean = authQry.getDbBean(i);
				TblVzbFeatureIds[i] = (int) authDBbean.getFeatureId();
			}
			TblVzbFeaturesQuery vzbFeatQry = new TblVzbFeaturesQuery();
			vzbFeatQry.whereFeatureIdIn(TblVzbFeatureIds);
			vzbFeatQry.setOrderBy("FEATURE_ID");
			vzbFeatQry.query(dbCon);
			for (int j = 0; j < authResultSize; j++) {
				TblAuthServicesDbBean authDBbean = authQry.getDbBean(j);
				FeaturesBean featObj = new FeaturesBean();
				if (authDBbean.getIsAuthorized() != null
						&& ((authDBbean.getIsAuthorized())
								.equalsIgnoreCase("Y"))) {
					featObj.setIsAuthorized(true);
				} else {
					featObj.setIsAuthorized(false);
				}
				if (authDBbean.getEnvOrderId() > 0)
					featObj.setEnvOrderId(authDBbean.getEnvOrderId());
				DBTblVzbFeatures vzbFeatObj = new DBTblVzbFeatures();
				TblVzbFeaturesDbBean vzbFeatDBBean = vzbFeatQry.getDbBean(j);
				if (authDBbean.getFeatureId() == vzbFeatDBBean.getFeatureId()) {
					vzbFeatObj.copyFromBean(vzbFeatDBBean);
					featObj.setFeaturesDbBean(vzbFeatObj);
					authFeaturesList.add(featObj);
				}

			}
			if (authFeaturesList.size() <= 0) {
				log.info("authFeatures list size is 0");
				return false;
			}
			log.info("auth featrues list size:"
					+ authFeaturesList.size());
		} else {
			System.out
					.println("No auth services entry in db with this auth services id");
			return false;
		}
		return true;
	}

	

	

	

	public boolean setDeletePending() throws SQLException, Exception {
		if (getEnterpriseId() == null
				|| getEnterpriseId().trim().equalsIgnoreCase("")) {
			setStatus(InvErrorCode.INVALID_INPUT);
			return false;
		}
		DBTblCustomer custDb = new DBTblCustomer();
		custDb.whereCustomerIdEQ(getEnterpriseId());
		custDb.setActiveInd(VzbVoipEnum.ActiveInd.DELETE_PENDING);
		custDb.updateSpByWhere(dbCon);
		DBTblEnterprise entDb = new DBTblEnterprise();
		entDb.whereEnterpriseIdEQ(getEnterpriseId());
		entDb.setActiveInd(VzbVoipEnum.ActiveInd.DELETE_PENDING);
		entDb.updateSpByWhere(dbCon);

		TblLocationQuery locQry = new TblLocationQuery();
		locQry.whereEnterpriseIdEQ(getEnterpriseId());
		locQry.query(dbCon);
		for (int i = 0; i < locQry.size(); i++) {
			DBTblLocation locationDb = new DBTblLocation();
			locationDb.whereLocationIdEQ(locQry.getDbBean(i).getLocationId());
			locationDb.setActiveInd(VzbVoipEnum.ActiveInd.DELETE_PENDING);
			locationDb.updateSpByWhere(dbCon);
		}
		return true;
	}

	

	

	public boolean isEnterpriseNameExists(String entName) throws SQLException {
		log.info("In isEnterpriseNameExists()");
		entName.replace('&', '%');
		ArrayList<TblCustomerDbBean> resultList = null;
		TblCustomerDbBean custDbBean = new TblCustomerDbBean();
		boolean isExists = true;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		StringBuffer sql = new StringBuffer();

		sql.append(" select count(*) from tbl_customer where");
		sql.append(" upper(replace(replace(CUSTOMER_NAME, '  ', ' '), '  ', ' ')) like upper(replace(replace(?,'  ',' '), '  ', ' '))");

		log.info(" sql " + sql.toString());

		try {
			pstmt = dbCon.prepareStatement(sql.toString());
			pstmt.setString(1, entName);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				if (rs.getInt(1) >= 1)
					isExists = false;

			}

		} catch (Exception e) {
			e.printStackTrace();
			System.out
					.println("ERROR: Exception caught while trying to get Customer_Name from tbl_customer");
		} finally {
			if (rs != null)
				rs.close();
			if (pstmt != null)
				pstmt.close();
		}

		return isExists;
	}

	public long getEntTrunkCclSumByEnterpriseId(String enterpriseId) {
		log.info("Entering getEntTrunkCclSumByEnterpriseId");
		long cclSum = 0;
		try {
			TblEnterpriseQuery entQry = new TblEnterpriseQuery();
			entQry.whereEnterpriseIdEQ(enterpriseId);
			entQry.query(dbCon);
			if (entQry.size() > 0) {
				cclSum = entQry.getDbBean(0).getEntTrunkCclSum();
				log.info("Retrieved EntTrunkCclSum [" + cclSum
						+ "] by Enterprise Id [" + enterpriseId + "]");
			} else
				log.info("Enterprise Id [" + enterpriseId
						+ "] Not Found");
		} catch (SQLException e) {
			setStatus(InvErrorCode.DB_EXCEPTION);
			e.printStackTrace();
			return cclSum;
		} catch (Exception e) {
			e.printStackTrace();
			setStatus(InvErrorCode.INTERNAL_ERROR);
			return cclSum;
		}
		setStatus(InvErrorCode.SUCCESS);
		return cclSum;
	}

	public HashMap<Integer, String> getAllowedEnumIStatfieldValue(
			String enterpriseId) throws SQLException {

		log.info("In getAllowedEnumIStatfieldValue()");
		int enumIstatvalue = -1;
		StringBuffer locationIds = new StringBuffer();
		HashMap<Integer, String> mapObj = new HashMap<Integer, String>();
		String locIds = "";

		try {
			TblLocationQuery queryLocation = new TblLocationQuery();

			// Set EnumIStat = 0 for all RIV customers which has following
			// attributes set at any location for that customer:
			// ViPER = OFF OR UnscreenedANI = ON

			String whereCls = "where (enhanced_ani_ind = 1 or  voip_club = 0 or pub_ip = 0 )  and  enterprise_id = \'"
					+ enterpriseId + "\'";
			log.info("whereCls:" + whereCls);

			queryLocation.queryByWhere(dbCon, whereCls);

			if (queryLocation.size() > 0) {
				enumIstatvalue = 0;

				ArrayList<TblLocationDbBean> locations = queryLocation
						.getResultArrayList();
				int size = 0;

				if (locations != null && locations.size() > 0) {

					// Display first five location ids to the user
					if (locations.size() > 5)
						size = 5;
					else
						size = locations.size();

					for (int k = 0; k < size; k++) {
						TblLocationDbBean locationObject = new TblLocationDbBean();
						locationObject = locations.get(k);
						locationIds.append(locationObject.getLocationId());
						locationIds.append(",");
					}
					locIds = locationIds.toString();
					locIds = locIds.substring(0, (locIds.length() - 1));
				}
				mapObj.put(enumIstatvalue, locIds);
				System.out
						.println("Found atleast one location with ViPER = OFF  OR UnscreenedANI = ON for the enterprsie ....");
			} else {
				// read value from table config params
				TblConfigParamsQuery queryConfigParam = new TblConfigParamsQuery();
				// String enumIStatWhere =
				// "select param_value from tbl_config_params where param_name='ENUMISTAT_CONFIG'";
				queryConfigParam.whereParamNameEQ("ENUMISTAT_CONFIG");
				queryConfigParam.query(dbCon);

				ArrayList resultList = queryConfigParam.getResultArrayList();

				if (null != resultList) {
					System.out
							.println(" EnumIstat available in the Database for the enterprise = "
									+ enterpriseId + ":" + resultList);
					if (resultList.size() == 1) {
						Iterator iter = resultList.iterator();
						if (iter.hasNext()) {
							TblConfigParamsDbBean configParamDbBean = (TblConfigParamsDbBean) (iter
									.next());
							enumIstatvalue = Integer.parseInt(configParamDbBean
									.getParamValue());
							log.info(" EnumIstat_value = "
									+ enumIstatvalue);
						}
					} else if (resultList.size() > 1) {
						System.out
								.println("Multiple Config params found in the Database for the param ENUMISTAT_CONFIG .."
										+ ":" + resultList);
						Iterator iter = resultList.iterator();
						if (iter.hasNext()) {
							TblConfigParamsDbBean configParamDbBean = (TblConfigParamsDbBean) (iter
									.next());
							enumIstatvalue = Integer.parseInt(configParamDbBean
									.getParamValue());
							log.info(" EnumIstat_value = "
									+ enumIstatvalue);
						}
					}
				} else {
					System.out
							.println("No EnumIstats is available in the Database for the config param  ENUMISTAT_CONFIG "
									+ enterpriseId);
					enumIstatvalue = 1;
				}

				TblLocationQuery queryLocation2 = new TblLocationQuery();
				String whereCls2 = "where (enhanced_ani_ind = 0 and  voip_club = 1 and pub_ip = 1)  and  enterprise_id = \'"
						+ enterpriseId + "\'";
				queryLocation2.queryByWhere(dbCon, whereCls2);

				if (queryLocation2.size() > 0) {
					ArrayList<TblLocationDbBean> locations2 = queryLocation2
							.getResultArrayList();
					int size = 0;
					if (locations2 != null && locations2.size() > 0) {
						if (locations2.size() > 5)
							size = 5;
						else
							size = locations2.size();

						for (int k = 0; k < size; k++) {
							TblLocationDbBean locationObject = new TblLocationDbBean();
							locationObject = locations2.get(k);
							locationIds.append(locationObject.getLocationId());
							locationIds.append(",");
						}
					}
					locIds = locationIds.toString();
					locIds = locIds.substring(0, (locIds.length() - 1));
				}
				mapObj.put(enumIstatvalue, locIds);
			}
		} catch (SQLException e) {
			e.printStackTrace();
			System.out
					.println("ERROR: Exception occured while validating enumIstat value, enumIstatvalue = "
							+ enumIstatvalue);
		}
		return mapObj;
	}

	/*
	 * This method validates whether the ENUMISTAT field can be toggled ON/OFF
	 * from GUI. It returns a map with a boolean value and a string to the GUI.
	 * If the map contains true, toggle of enumistat field from ON to OFF, or
	 * from OFF to ON is allowed. If the map contains false, then toggle of
	 * enumistat field from ON to OFF, or from OFF to ON is NOT allowed. And the
	 * user will be shown a message why the toggle is not allowed.
	 */
	public HashMap<Boolean, String> validateEnumIstatUpdate(
			String newEnumIstatValue, String enterpriseId) throws SQLException {

		log.info("In validateEnumIstatUpdate()");
		log.info("newEnumIstatValue= " + newEnumIstatValue);
		log.info("enterpriseId= " + enterpriseId);

		Boolean resultFlag = false;
		String message = "";
		int validEnumIstatValue = -1;

		HashMap<Integer, String> validateObj = new HashMap<Integer, String>();
		HashMap<Boolean, String> retObj = new HashMap<Boolean, String>();
		String enabledOrDesbled = getConfigParamValue("RIV_INV",
				"IS_ENUMISTAT_IMPL_IN_NSRS");

		if ("YES".equalsIgnoreCase(enabledOrDesbled)) {

			if ((null != newEnumIstatValue && newEnumIstatValue.length() != 0)
					&& (null != enterpriseId && enterpriseId.length() != 0)) {

				validateObj = getAllowedEnumIStatfieldValue(enterpriseId);

				Set set = validateObj.keySet();
				Iterator iter = set.iterator();

				Integer i = -1;

				while (iter.hasNext()) {
					i = (Integer) iter.next();
					message = (String) validateObj.get(i);
				}
				validEnumIstatValue = i;

				log.info("validEnumIstatValue= "+ validEnumIstatValue);

				if (validEnumIstatValue == Integer.parseInt(newEnumIstatValue)) { // compare
																					// the
																					// value
																					// that
																					// user
																					// is
																					// changing,
																					// with
																					// the
																					// allowable
																					// value
					resultFlag = true;
					retObj.put(resultFlag, new String(""));
				} else {
					resultFlag = false;
					String str = "";
					if (validEnumIstatValue == 0) {
						//str = "EnumIstat field cannot be set to ON. Either ViPER=OFF or PUBIP=OFF or UnscreenedANI=ON at any of the following locations under the enterprise, This Condition is valid only if the customer is on 890 RS. Location ids : ";
						str = "Atleast one of the Locations under this Customer has PubIP=OFF or Unscreened ANI=ON. If the Customer is on RS-890s, its advisable NOT to turn ON ENUM !, If you still want to continue press OK ";
					} else {
						str = "EnumIstat field cannot be set to OFF. All the following locations has ViPER=ON and PUBIP=ON and UnscreenedANI=OFF under the enterprise. Location ids : ";
					}
					// String str =
					// "EnumIstat field cannot be set to OFF/ON. Please check ViPER and ANI flag at the following locations under the enterprise. Location ids : ";
					//retObj.put(resultFlag, (str + message + " If you still want to continue press OK "));
					retObj.put(resultFlag, str);
				}
			} else {
				System.out
						.println("ERROR:  Required arguments to validateEnumIstatUpdate() are passed as null");
				resultFlag = false;
				retObj.put(
						resultFlag,
						"Unable to validate Enumistat update, as the required arguments are not provided to validate");
				return retObj;
			}
		} else {
			System.out
					.println("ENUMISTAT implementation is not done in NSRS.Hence not applied the rules of the Enumistat PCR for updating enumistat field");
			resultFlag = true;
			retObj.put(resultFlag, "");
			log.info("returning Map= " + retObj);
		}
		return retObj;
	}

	public String getConfigParamValue(String processName, String paramName)
			throws SQLException {
		String paramValue = "";

		TblConfigParamsQuery paramsQ = new TblConfigParamsQuery();
		if (processName != null)
			paramsQ.whereProcessNameEQ(processName);
		if (paramName != null)
			paramsQ.whereParamNameEQ(paramName);
		paramsQ.query(dbCon);

		if (paramsQ.size() <= 0) {
			return paramValue;
		}

		TblConfigParamsDbBean cpBean = paramsQ.getDbBean(0);
		paramValue = cpBean.getParamValue();
		return paramValue;
	}

	public boolean isCustomerMigrationElligible(String enterpriseId)
			throws Exception {

		int count = 0;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			String sql = "select count(*) as count "
					+ "from tbl_customer c, tbl_enterprise e, tbl_location l, tbl_device_map dm, tbl_gateway_device_info gd "
					+ "where l.enterprise_id = e.enterprise_id and e.enterprise_id = c.customer_id and dm.enterprise_id(+) = l.enterprise_id "
					+ "and dm.active_ind=1 and dm.GATEWAY_DEVICE_ID = gd.GATEWAY_DEVICE_ID and gd.DEVICE_CHAR_ID is not null "
					+ "and c.ORDER_PLATFORM in (1,3) and c.product_type!=7 and  ( l.HYBRID_SERVICE_TYPE is null or l.HYBRID_SERVICE_TYPE = 0 ) and l.voip_service_type in(2,3,4) and gd.DEVICE_CHAR_ID not in (1,2,3) "
					+ "and l.enterprise_id  in (select l.enterprise_id from tbl_location l, tbl_access_category ac, tbl_access_type at "
					+ "where at.access_category = ac.access_category_id and l.access_type = at.access_type_id having count(distinct ac.access_category_id) = 1 group by l.enterprise_id) "
					+ "and l.enterprise_id  in (select customer_id from tbl_sbc_order where sbc_order_status=101 having count(distinct vpn_name) = 1 group by customer_id) "
					+ "and l.enterprise_id = " + "'" + enterpriseId + "'";
			log.info("Elligible Customers For Migration Query = "
					+ sql);
			ps = dbCon.prepareStatement(sql);
			rs = ps.executeQuery();
			while (rs.next()) {
				count = rs.getInt("count");
			}

		} catch (SQLException e) {
			e.printStackTrace();
			throw e;
		} finally {
			try {
				if (null != ps)
					ps.close();
				if (null != rs)
					rs.close();
			} catch (Exception e) {
				e.printStackTrace();
				throw e;
			}
		}
		if (count == 0) {
			return false;
		} else {
			return true;
		}

	}

	public String isCustomerMigrationElligibleWithReason(String enterpriseId)
			throws Exception {
		int count = 0;
		PreparedStatement ps = null;
		ResultSet rs = null;
		String reasonSql = null;
		String reason = null;
		try {
			// Case 1: NON RIV
			// Case 2: IPCC
			reasonSql = "select c.order_platform,c.product_type,l.voip_service_type,l.hybrid_service_type,e.so_enabled from tbl_customer c, tbl_location l,tbl_enterprise e  where c.customer_id = e.enterprise_id and c.customer_id = l.enterprise_id and  customer_id = "
					+ "'" + enterpriseId + "'";
			ps = dbCon.prepareStatement(reasonSql);
			rs = ps.executeQuery();
			while (rs.next()) {
				if (rs.getLong(1) == 2) {
					reason = "Customer is NON RIV. Not eligible";
				}
				if (rs.getLong(2) == 7) {
					reason = "IPCC Customer. Not eligible";
				}
				if (rs.getLong(3) != 2 && rs.getLong(3) != 3
						&& rs.getLong(3) != 4) {
					reason = "IPIA/IPT location doesnot exists for customer. Not eligible";
				}
				if (rs.getLong(4) > 0) {
					reason = "Hybrid location exists for Customer. Not eligible";
				}
				/*if (rs.getLong(5) == 1) {
					reason = "Customer is already Service Optimized. Not eligible";
				}*/
				if (reason != null)
					return reason;
			}
			 reasonSql =  "select count(*) as count from tbl_customer c, tbl_enterprise e, tbl_location l,	tbl_device_map dm , tbl_gateway_device_info gd 	where l.enterprise_id = e.enterprise_id and e.enterprise_id = c.customer_id and dm.enterprise_id(+) = l.enterprise_id and dm.active_ind=1 and dm.GATEWAY_DEVICE_ID = gd.GATEWAY_DEVICE_ID and gd.DEVICE_CHAR_ID is not null and gd.DEVICE_CHAR_ID in(1,2,3) and l.enterprise_id = "+"'"+enterpriseId+"'";
        	 ps = dbCon.prepareStatement(reasonSql);
        	 rs = ps.executeQuery();
        	 while(rs.next()){
        		 count = rs.getInt("count");
        		 if(count > 0){
        			 reason = "Customer has CPE Local Gateway/IPCC/Reg Client device. Not eligible";
        			 return reason;
        		 }
        	 }
			//IR - 4506944
			//reasonSql =  "select count(distinct l.access_type) as count from tbl_location l, tbl_access_category ac,tbl_access_type tat  where tat.access_category = ac.access_category_id and l.enterprise_id = "+"'"+enterpriseId+"'";
			reasonSql = "select count(distinct ac.access_category_id) as count from tbl_location l, tbl_access_category ac, tbl_access_type at where at.access_category = ac.access_category_id and l.access_type = at.access_type_id and l.enterprise_id = "+"'"+enterpriseId+"'";
			ps = dbCon.prepareStatement(reasonSql);
			rs = ps.executeQuery();
			while(rs.next()){
				count = rs.getInt("count");
				if(count > 1){
					reason = "Customer has Multiple Access Types. Not eligible";
					return reason;
				}
			}


			reasonSql = "select count(*) as count from tbl_sbc_order where sbc_order_status=101 having count(distinct vpn_name) > 1 and customer_id= "
					+ "'" + enterpriseId + "' group by customer_id";
			ps = dbCon.prepareStatement(reasonSql);
			rs = ps.executeQuery();
			while (rs.next()) {
				count = rs.getInt("count");
				if (count > 0) {
					reason = "Customer has Multi VPN. Not eligible";
					return reason;
				}
			}

		} catch (SQLException e) {
			e.printStackTrace();
			throw e;
		} finally {
			try {
				if (null != ps)
					ps.close();
				if (null != rs)
					rs.close();
			} catch (Exception e) {
				e.printStackTrace();
				throw e;
			}
		}
		return reason;
	}

	public boolean updateTsoVampEntityMigForEnt(String NewEnterpriseId,
			String OldEnterpriseId, String EnterpriseReferenceId)
			throws Exception {
		boolean new_ent = true;
		PreparedStatement ps = null;
		StringBuffer sql = new StringBuffer();
		sql.append("update tbl_vamp_entity_reference set tso_enterprise_id = "
				+ "'" + NewEnterpriseId + "'" + " where enterprise_id =" + "'"
				+ OldEnterpriseId + "'" + " and vamp_ref_id =" + "'"
				+ EnterpriseReferenceId + "'");
		try {
			ps = dbCon.prepareStatement(sql.toString());
			if (null != ps)
				ps.executeUpdate();
			dbCon.commit();
		} catch (Exception e) {
			new_ent = false;
			throw e;
		} finally {
			try {
				if (null != ps)
					ps.close();
			} catch (Exception e) {
				e.printStackTrace();
				new_ent = false;
			}
		}
		return new_ent;
	}
	// added by z658915 for calnet changes starts
	public int updateCalnetSubContractId(short calnetSubContractId) {
		int enterpriseRecCountUpdated = 0;
		
		DBTblCustomer tblCustomer = new DBTblCustomer();
		tblCustomer.setCalnetSubContractId(calnetSubContractId);
		tblCustomer.whereCustomerIdEQ(customerId);
		try {
			enterpriseRecCountUpdated = tblCustomer.updateSpByWhere(dbCon);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return enterpriseRecCountUpdated;
	}
	// added by z658915 for calnet changes ends
	
	public int updateContractInd(String cntInd) {
		int enterpriseRecCountUpdated = 0;
		
		DBTblEnterprise tblEnt = new DBTblEnterprise();
		tblEnt.setContractInd(cntInd);
		tblEnt.whereEnterpriseIdEQ(customerId);
		try {
			enterpriseRecCountUpdated = tblEnt.updateSpByWhere(dbCon);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return enterpriseRecCountUpdated;
	}

	public boolean updateTblTsoEntityMigForEnt(String NewEnterpriseId,
			String OldEnterpriseId) throws Exception {
		boolean new_tso_ent = true;
		PreparedStatement ps = null;
		StringBuffer sql = new StringBuffer();
		sql.append("update tbl_tso_entity_migration set tso_enterprise_id = "
				+ "'" + NewEnterpriseId + "'" + " where enterprise_id =" + "'"
				+ OldEnterpriseId + "'");
		try {
			ps = dbCon.prepareStatement(sql.toString());
			if (null != ps)
				ps.executeUpdate();
			dbCon.commit();
		} catch (Exception e) {
			new_tso_ent = false;
			throw e;
		} finally {
			try {
				if (null != ps)
					ps.close();
			} catch (Exception e) {
				e.printStackTrace();
				new_tso_ent = false;
			}
		}
		return new_tso_ent;
	}
	
	public boolean isTsoCustomer(String entId) throws SQLException {
		log.info("In isTsoCustomer()");
		boolean isTsoCust = false;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		StringBuffer sql = new StringBuffer();
		sql.append(" select so_enabled from tbl_enterprise where enterprise_id = ? ");

		log.info(" sql " + sql.toString());

		try {
			pstmt = dbCon.prepareStatement(sql.toString());
			pstmt.setString(1, entId);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				if (rs.getShort(1) >= 1)
					isTsoCust = true;
			}

		} catch (Exception e) {
			e.printStackTrace();
			System.out
					.println("ERROR: Exception caught while trying to get so_enabled from tbl_enterprise");
		} finally {
			if (rs != null)
				rs.close();
			if (pstmt != null)
				pstmt.close();
		}

		return isTsoCust;
	}
	
	public boolean addToDB() throws SQLException, Exception {
		// try {
		// Create device - this id will be updated at the time of device
		// creation
		// Create Authservices - this will be default value
		// If customer is Riv Customer we are by passing flow.
		int authSerId = 0;
		// Start --added for XO changes --policy and policy service pack
		int policySerId = 0;
		int servicepackserId = 0;
		// end
		if (isRIVCustomer != VzbVoipEnum.YesNoType.N) {
			int defaultAuthSerId = 0;
			if (orderPlatform == VzbVoipEnum.OrderPlatform.E2EI) {
				defaultAuthSerId = 6;// 4/TODO
			} else if (platformIndicator == VzbVoipEnum.Platform.IASA) {
				defaultAuthSerId = 0;
			} else if (platformIndicator == VzbVoipEnum.Platform.ICP) {
				if (regionId == VzbVoipEnum.RegionType.EMEA) {
					defaultAuthSerId = 2;
				} else {
					defaultAuthSerId = 1;
				}
			}
			authSerId = addDefaultAuthFeatures(defaultAuthSerId);
			addAuthFeatureToEnterprise();

			setLogTrail("Auth Services added for Enterprise.");
		}
		//1.add policy features 
		policySerId = addDefaultPolicyFeatures("EAP");// TODO get EAP Value from TOD
	//	addAuthFeatureToEnterprise();
		//2. service pack features
		servicepackserId = addDefaultServicePackFeatures("ESIP");// TODO get EAP Value from TOD
		
		DBTblEnterprise entDbObj = new DBTblEnterprise();
		DBTblCustomer custDbObj = new DBTblCustomer();
		// Create AS BS -this will be updated at location creation
		custDbObj.setCustomerId(customerId);
		if (!"NONE".equals(customerName) && !"".equals(customerName))
			custDbObj.setCustomerName(customerName.trim());
		custDbObj.setAccountName(accountName);
		custDbObj.setRegionId(regionId);
		custDbObj.setIcpMigrated(custIcpMigrated);
		custDbObj.setSbcMigInd(custSbcMigInd);
		custDbObj.setProductType(productType);
		if (isRIVCustomer == -1) {
			custDbObj.setRivCustomer(VzbVoipEnum.YesNoType.Y);
		} else {
			custDbObj.setRivCustomer(isRIVCustomer);
		}
		if (restrictedAccess >= 0) {
			custDbObj.setRestrictedAccess(restrictedAccess);
		}
		if (enterpriseTrunkingType >= 0) {
			custDbObj.setEnterpriseTrunkingType(enterpriseTrunkingType);
		}
		if (!"NONE".equals(gchId) && !"".equals(gchId)) {
			custDbObj.setGchId(gchId);
		}
		custDbObj.setE2eiSensitivityLevel(e2eiSensitvityLevel);
		if (orderPlatform > 0)
			custDbObj.setOrderPlatform(orderPlatform);
		if (billingSystem > 0)
			custDbObj.setUsBillingSystem(billingSystem);
		if (emeaBillingSystem != -1)
			custDbObj.setEmeaBillingSystem(emeaBillingSystem);
		if (!"NONE".equals(orderSource) && !"".equals(orderSource))
			custDbObj.setOrderSource(orderSource);
		if (!"NONE".equals(contactFirstName) && !"".equals(contactFirstName))
			custDbObj.setContactFirstName(contactFirstName);
		if (!"NONE".equals(contactLastName) && !"".equals(contactLastName))
			custDbObj.setContactLastName(contactLastName);
		if (!"NONE".equals(contactTitle) && !"".equals(contactTitle))
			custDbObj.setContactTitle(contactTitle);
		if (!"NONE".equals(contactPrimaryPhone) && !"".equals(contactPrimaryPhone))
			custDbObj.setContactPriPhone(contactPrimaryPhone);
		if (!"NONE".equals(contactAltPhone) && !"".equals(contactAltPhone))
			custDbObj.setContactAltPhone(contactAltPhone);
		if (!"NONE".equals(contactFax) && !"".equals(contactFax))
			custDbObj.setContactFax(contactFax);
		if (!"NONE".equals(contactCell) && !"".equals(contactCell))
			custDbObj.setContactCell(contactCell);
		if (!"NONE".equals(contactPager) && !"".equals(contactPager))
			custDbObj.setContactPager(contactPager);
		if (!"NONE".equals(contactEmail) && !"".equals(contactEmail))
			custDbObj.setContactEmail(contactEmail);
		if (!"NONE".equals(contactAddr1) && !"".equals(contactAddr1))
			custDbObj.setContactAddr1(contactAddr1);
		if (!"NONE".equals(contactAddr2) && !"".equals(contactAddr2))
			custDbObj.setContactAddr2(contactAddr2);
		if (!"NONE".equals(contactCity) && !"".equals(contactCity))
			custDbObj.setContactCity(contactCity);
		if (!"NONE".equals(contactState) && !"".equals(contactState))
			custDbObj.setContactState(contactState);
		if (!"NONE".equals(contactZip) && !"".equals(contactZip))
			custDbObj.setContactZip(contactZip);
		if (!"NONE".equals(contactCountry) && !"".equals(contactCountry))
			custDbObj.setContactCountry(contactCountry);
		if (!"NONE".equals(billContactPriPhone) && !"".equals(billContactPriPhone))
			custDbObj.setBillContactPriPhone(billContactPriPhone);
		if (!"NONE".equals(billContactAltPhone) && !"".equals(billContactAltPhone))
			custDbObj.setBillContactAltPhone(billContactAltPhone);
		if (!"NONE".equals(billContactCell) && !"".equals(billContactCell))
			custDbObj.setBillContactCell(billContactCell);
		if (!"NONE".equals(billContactPager) && !"".equals(billContactPager))
			custDbObj.setBillContactPager(billContactPager);
		if (!"NONE".equals(billContactEmail) && !"".equals(billContactEmail))
			custDbObj.setBillContactEmail(billContactEmail);
		if (!"NONE".equals(billContactAddr1) && !"".equals(billContactAddr1))
			custDbObj.setBillContactAddr1(billContactAddr1);
		if (!"NONE".equals(billContactAddr2) && !"".equals(billContactAddr2))
			custDbObj.setBillContactAddr2(billContactAddr2);
		if (!"NONE".equals(billContactCity) && !"".equals(billContactCity))
			custDbObj.setBillContactCity(billContactCity);
		if (!"NONE".equals(billContactState) && !"".equals(billContactState))
			custDbObj.setBillContactState(billContactState);
		if (!"NONE".equals(billContactZip) && !"".equals(billContactZip))
			custDbObj.setBillContactZip(billContactZip);
		if (!"NONE".equals(billContactCountry) && !"".equals(billContactCountry))
			custDbObj.setBillContactCountry(billContactCountry);
		if (salesSegment == -1)
			custDbObj.setSalesSegment(0);
		else
			custDbObj.setSalesSegment(salesSegment);
		if (!"NONE".equals(salesRepId) && !"".equals(salesRepId))
			custDbObj.setSalesRepId(salesRepId);
		if (!"NONE".equals(salesRepName) && !"".equals(salesRepName))
			custDbObj.setSalesRepName(salesRepName);
		if (!"NONE".equals(salesRepPhone) && !"".equals(salesRepPhone))
			custDbObj.setSalesRepPhone(salesRepPhone);
		if (!"NONE".equals(salesRepEmail) && !"".equals(salesRepEmail))
			custDbObj.setSalesRepEmail(salesRepEmail);
		if (!"NONE".equals(custCorpId) && !"".equals(custCorpId))
			custDbObj.setCustCorpId(custCorpId);
		if (orderVerification == -1)
			custDbObj.setOrderVerification(0);
		else
			custDbObj.setOrderVerification(orderVerification);
		if (!"NONE".equals(supportName) && !"".equals(supportName))
			custDbObj.setSupportName(supportName);
		if (!"NONE".equals(supportPhone) && !"".equals(supportPhone))
			custDbObj.setSupportPhone(supportPhone);
		if (emeaServiceSupport > 0)
			custDbObj.setEmeaServiceSupport(emeaServiceSupport);
		custDbObj.setCustSensitivityLevel(custSensitivityLevel);
		if (custGarmStatus > 0)
			custDbObj.setCustGarmStatus(custGarmStatus);
		if (custActiveInd > 0)
			custDbObj.setActiveInd(custActiveInd);

		/* Newly added by Vijaykumar.S on (24-08-09) */
		log.info("commonCustomerId:{}", commonCustomerId);
		if (!"NONE".equals(commonCustomerId) && !"".equals(commonCustomerId))
			custDbObj.setCommonCustomerId(commonCustomerId);
		log.info("vpnName:{}", vpnName);
		if (!"NONE".equals(vpnName) && !"".equals(vpnName))
			custDbObj.setVpnName(vpnName);

		// Jan 2011 Release changes

		if (!"NONE".equals(naspId) && !"".equals(naspId))
			custDbObj.setNaspId(naspId);

		log.info(" naspId :: {},custDbObj.getNaspId() ::{}", naspId, custDbObj.getNaspId());

		if (!"NONE".equals(commonCustomerName) && !"".equals(commonCustomerName))
			custDbObj.setCommonCustomerName(commonCustomerName);

		if (getEnvOrderId() > 0)
			custDbObj.setEnvOrderId(getEnvOrderId());
		else
			custDbObj.setEnvOrderIdNull();
		if (createdBy != null && !createdBy.trim().equals(""))
			custDbObj.setCreatedBy(createdBy);
		else
			custDbObj.setCreatedBy("ESAP_INV");

		if (modifiedBy != null && !modifiedBy.trim().equals(""))
			custDbObj.setModifiedBy(modifiedBy);
		else
			custDbObj.setModifiedBy("ESAP_INV");

		custDbObj.setCalnetSubContractId(calnetSubContractId); // added by
																// z658915
		log.info(" calnetSubContractId :: {} , custDbObj.getCalnetSubContractId() :: {}", calnetSubContractId,
				custDbObj.getCalnetSubContractId());

		custDbObj.setCreationDate(new Timestamp(System.currentTimeMillis()));
		custDbObj.setLastModifiedDate(new Timestamp(System.currentTimeMillis()));
		printCustDbObj(custDbObj);

		TblCustomerQuery custQry = new TblCustomerQuery();
		custQry.whereCustomerIdEQ(getCustomerId());
		custQry.query(dbCon);
		if (custQry.size() > 0 && migration) {
			if (custQry.getDbBean(0).getRivCustomer() == VzbVoipEnum.YesNoType.N) {
				custDbObj.whereCustomerIdEQ(getCustomerId());
				custDbObj.updateSpByWhere(dbCon);
			} else {
				setStatus(InvErrorCode.RIV_CUSTOMER_ALREADY_EXISTS);
				return false;
			}
		} // 1455284: JAN DEV APAC Orders failed in Adding Enterprise to
			// Invemtory
		else if (custQry.size() > 0 && getCustMarket() == VzbVoipEnum.CustMarketType.APAC) {
			custDbObj.whereCustomerIdEQ(getCustomerId());
			custDbObj.updateSpByWhere(dbCon);
		} else {
			custDbObj.insert(dbCon);
		}

		setLogTrail("Customer Record added to DB.");
		entDbObj.setEnterpriseId(customerId);
		if (customerType > 0)
			entDbObj.setCustType(customerType);
		entDbObj.setCustMarket(custMarket);

		if (isRIVCustomer == -1)
			entDbObj.setRivCustomer(VzbVoipEnum.YesNoType.Y);
		else
			entDbObj.setRivCustomer(isRIVCustomer);

		entDbObj.setPlatformIndicator(platformIndicator);
		entDbObj.setSbcMigInd(entSbcMigInd);
		if (!"NONE".equals(vmPartitionId) && !"".equals(vmPartitionId))
			entDbObj.setVmPartitionId(vmPartitionId);
		if (pubIp == -1)
			entDbObj.setPubip(0);
		else
			entDbObj.setPubip(pubIp);
		entDbObj.setOnNetInterco(onNetInterco);
		if (!"NONE".equals(sipDomain) && !"".equals(sipDomain))
			entDbObj.setSipDomain(sipDomain);
		if (asId > 0)
			entDbObj.setAsId(asId);
		entDbObj.setEntcclInd(entCclInd);
		entDbObj.setQosInd(qosInd);
		if (ieanLength > 0)
			entDbObj.setIeanLength(ieanLength);
		if (!"NONE".equals(vnetCorpId) && !"".equals(vnetCorpId))
			entDbObj.setVnetCorpId(vnetCorpId);
		if (!"NONE".equals(contractInd) && !"".equals(contractInd))
			entDbObj.setContractInd(contractInd);
		if (!"NONE".equals(agencyHierCode) && !"".equals(agencyHierCode))
			entDbObj.setAgencyHierCode(agencyHierCode);
		if (!"NONE".equals(xrefCustomerId) && !"".equals(xrefCustomerId))
			entDbObj.setXrefCustomerId(xrefCustomerId);
		if (callingPlanId > 0)
			entDbObj.setCallingPlanId(callingPlanId);

		if (soEnabled >= 0) {
			entDbObj.setSoEnabled(soEnabled);
		}
		if (usLdAndLocalBestPool >= 0) {
			entDbObj.setUsLdAndLocalBestPool(usLdAndLocalBestPool);
		}
		if (usLdOnlyBestPool >= 0) {
			entDbObj.setUsLdOnlyBestPool(usLdOnlyBestPool);
		}
		if (emeaApacBestPool >= 0) {
			entDbObj.setEmeaApacBestPool(emeaApacBestPool);
		}
		if (usLdAndLocalBestPlusPool >= 0) {
			entDbObj.setUsLdAndLocalBestPlusPool(usLdAndLocalBestPlusPool);
		}
		if (usLdOnlyBestPlusPool >= 0) {
			entDbObj.setUsLdOnlyBestPlusPool(usLdOnlyBestPlusPool);
		}
		if (emeaApacBestPlusPool >= 0) {
			entDbObj.setEmeaApacBestPlusPool(emeaApacBestPlusPool);
		}

		if (!"NONE".equals(lorId) && !"".equals(lorId)) {
			entDbObj.setLorId(lorId);
		}
		if (!"NONE".equals(address) && !"".equals(address)) {
			entDbObj.setAddress(address);
		}
		if (!"NONE".equals(city) && !"".equals(city)) {
			entDbObj.setCity(city);
		}
		if (!"NONE".equals(state) && !"".equals(state)) {
			entDbObj.setState(state);
		}
		if (!"NONE".equals(zip) && !"".equals(zip)) {
			entDbObj.setZip(zip);
		}
		if (!"".equals(country)) {
			entDbObj.setCountry(country);
		}
		if (hybridInd >= 0) {
			entDbObj.setHybridInd(hybridInd);
		}

		if (approvedCcl >= 0) {
			entDbObj.setApprovedCcl(approvedCcl);
		}

		if (entTrunkCclSum >= 0) {
			entDbObj.setEntTrunkCclSum(entTrunkCclSum);
		}

		if (!"NONE".equals(custPriceBookId) && !"".equals(custPriceBookId)) {
			entDbObj.setCustPriceBookId(custPriceBookId);
		}
		if (!"NONE".equals(contractId) && !"".equals(contractId)) {
			entDbObj.setContractId(contractId);
		}

		if (!"NONE".equals(quoteId) && !"".equals(quoteId)) {
			entDbObj.setQuoteId(quoteId);
		}
		if (!"NONE".equals(catalogueReferenceTime) && !"".equals(catalogueReferenceTime)) {
			entDbObj.setCatalogueReferenceTime(catalogueReferenceTime);
		}
		if (designId >= 0) {
			entDbObj.setDesignId(designId);
		}
		if (!migration || (migration && callingPlanId <= 0)) {

			if (platformIndicator == VzbVoipEnum.Platform.IASA) {
				entDbObj.setCallingPlanId(0);
				setLogTrail("CallingPlan:0 mapped to enterprise.");
			}
			if (platformIndicator == VzbVoipEnum.Platform.ICP) {
				entDbObj.setCallingPlanId(1);
				setLogTrail("CallingPlan:1 mapped to enterprise.");
			}
		}

		if (authSerId > 0)
			entDbObj.setAuthServicesId(authSerId);
		//KR -start added for XO changes
		if (policySerId > 0)
			entDbObj.setPolicyServiceId(policySerId);
		if (servicepackserId > 0)
			entDbObj.setServicepackServiceId(servicepackserId);
		 entDbObj.setBwEnterpriseId(bwEnterPrsiseId);
		
		//KR -end
		entDbObj.setActiveInd(entActiveInd);
		entDbObj.setBsBlockInd(bsBlockInd);
		if (!"NONE".equals(sbcActivationSystem) && !"".equals(sbcActivationSystem))
			entDbObj.setSbcActivationSystem(sbcActivationSystem);
		// entDbObj.setCreatedBy("Opro");
		// entDbObj.setModifiedBy("Opro");


		// 53938.AA Business Continuity Ph 1 - changes for july 2011
		if (!"NONE".equals(lorFlag) && !"".equals(lorFlag))
			entDbObj.setLorFlag(lorFlag);

		entDbObj.setLoadSharing(loadSharing);

		entDbObj.setEntCumCcl(entCumCcl);
		if (getEnvOrderId() > 0)
			entDbObj.setEnvOrderId(getEnvOrderId());
		else
			entDbObj.setEnvOrderIdNull();
		if (createdBy != null && !createdBy.trim().equals(""))
			entDbObj.setCreatedBy(createdBy);
		else
			entDbObj.setCreatedBy("ESAP_INV");
		if (modifiedBy != null && !modifiedBy.trim().equals(""))
			entDbObj.setModifiedBy(modifiedBy);
		else
			entDbObj.setModifiedBy("ESAP_INV");
		entDbObj.setCreationDate(new Timestamp(System.currentTimeMillis()));
		entDbObj.setLastModifiedDate(new Timestamp(System.currentTimeMillis()));
		printEntDbObj(entDbObj);

		TblEnterpriseQuery entQry = new TblEnterpriseQuery();
		entQry.whereEnterpriseIdEQ(getCustomerId());
		entQry.query(dbCon);
		if (entQry.size() > 0 && migration) {
			if (entQry.getDbBean(0).getRivCustomer() == VzbVoipEnum.YesNoType.N) {
				entDbObj.whereEnterpriseIdEQ(getCustomerId());
				entDbObj.updateSpByWhere(dbCon);
			} else {
				setStatus(InvErrorCode.RIV_CUSTOMER_ALREADY_EXISTS);
				return false;
			}
		} else {
			entDbObj.insert(dbCon);
		}

		setLogTrail("Enterprise Record added to DB.");
		if (!migration && (isRIVCustomer != VzbVoipEnum.YesNoType.N)) {
			DialPlan dialPlan = new DialPlan(dbCon);
			dialPlan.setEnterpriseId(customerId);
			dialPlan.setDialPlanName(customerName.trim());
			dialPlan.setDefaultFlag(1);
			dialPlan.setEmergencyIndicator(0);
			dialPlan.setTermntind(0);
			dialPlan.setPresacceptstatus(0);
			dialPlan.setPresscreenstatus(0);
			dialPlan.setPresscreenlist(0);
			dialPlan.setOrigcallregstat(0);
			dialPlan.setNumconreg(1);
			dialPlan.setRegtimeext(600);
			dialPlan.setLocalDaStat(0);
			dialPlan.setPublicNetwGw(0);
			dialPlan.setBlockAllCall(0);
			dialPlan.setOnNetStat(0);
			dialPlan.setOcsstat(1);
			dialPlan.setOcs(0);
			dialPlan.setEnumStat(0);
			dialPlan.setMaxenterprise(0);
			dialPlan.setActiveInd(1);
			dialPlan.setEnvOrderId(getEnvOrderId());

			switch (Integer.parseInt(getRegionId() + "")) {
			case VzbVoipEnum.RegionType.US:
				dialPlan.setEnumistat((short) 1);
				break;
			case VzbVoipEnum.RegionType.EMEA:
				dialPlan.setEnumistat((short) 0);
				break;
			case VzbVoipEnum.RegionType.APAC:
				dialPlan.setEnumistat((short) 0);
				break;
			default:
				break;
			}
			// setting zero as a default value to enumistat field, refer the IR#
			// 1963965.

			/*
			 * // Setting ENUMISTAT to 1 for US RIV Customer. if ( regionId ==
			 * VzbVoipEnum.RegionType.US) dialPlan.setEnumistat((short)1);
			 */
			if (createdBy != null && createdBy.equals(""))
				dialPlan.setCreatedBy(createdBy);
			else
				dialPlan.setCreatedBy("ESAP_INV");
			if (modifiedBy != null && modifiedBy.equals(""))
				dialPlan.setModifiedBy(modifiedBy);
			else
				dialPlan.setModifiedBy("ESAP_INV");
			// dialPlan.setCreationDate(new
			// Timestamp(System.currentTimeMillis()));
			// dialPlan.setLastModifiedDate(new
			// Timestamp(System.currentTimeMillis()));
			if (dialPlan.addDialPlan()) {
				setLogTrail("DialPlan:" + customerName + " added to DB.");
				SipDomain sipDomainBean = new SipDomain(dbCon);
				sipDomainBean.setDialPlanId(dialPlan.getDialPlanId());
				sipDomainBean.setDomainName(sipDomain);
				// sipDomainBean.setCreatedBy("Opro");
				// sipDomainBean.setModifiedBy("Opro");
				sipDomainBean.setEnvOrderId(getEnvOrderId());
				if (createdBy != null && !createdBy.trim().equals(""))
					sipDomainBean.setCreatedBy(createdBy);
				else
					sipDomainBean.setCreatedBy("ESAP_INV");
				if (modifiedBy != null && !modifiedBy.trim().equals(""))
					sipDomainBean.setModifiedBy(modifiedBy);
				else
					sipDomainBean.setModifiedBy("ESAP_INV");
				sipDomainBean.setCreationDate(new Timestamp(System.currentTimeMillis()));
				sipDomainBean.setLastModifiedDate(new Timestamp(System.currentTimeMillis()));
				if (sipDomainBean.addSipDomain())
					setLogTrail("SipDomain:" + sipDomain + " added to DB.");
			}
			if (addTermRoutingForMwi(dialPlan.getDialPlanId(), sipDomain) != true) {
				log.info("Failed to Add Term Routing For MWI");
				setStatus(InvErrorCode.ERROR_ADDING_MWI_TERM_ROUTING);
				return false;
			}
		}
		if (entBillFeatBeanList != null) {
			for (int i = 0; i < entBillFeatBeanList.size(); i++) {
				TblEntBillFeaturesBean entBillFeatBean = entBillFeatBeanList.get(i);
				TblEntBillFeatures entBillFeat = new TblEntBillFeatures(dbCon);

				if (entBillFeatBean.getFeatureInstanceId() != null)
					entBillFeat.setFeatureInstanceId(entBillFeatBean.getFeatureInstanceId());
				if (entBillFeatBean.getEnterpriseId() != null)
					entBillFeat.setEnterpriseId(entBillFeatBean.getEnterpriseId());
				if (entBillFeatBean.getEnterpriseId() != null)
					entBillFeat.setEnterpriseId(entBillFeatBean.getEnterpriseId());
				if (entBillFeatBean.getLocationId() != null)
					entBillFeat.setLocationId(entBillFeatBean.getLocationId());
				if (entBillFeatBean.getFeatureCode() != null)
					entBillFeat.setFeatureCode(entBillFeatBean.getFeatureCode());
				if (entBillFeatBean.getPbli() != null)
					entBillFeat.setPbli(entBillFeatBean.getPbli());
				if (entBillFeatBean.getChargeType() != null)
					entBillFeat.setChargeType(entBillFeatBean.getChargeType());
				if (entBillFeatBean.getChargeFrequency() != null)
					entBillFeat.setChargeFrequency(entBillFeatBean.getChargeFrequency());
				if (entBillFeatBean.getUnitOfMeasure() != null)
					entBillFeat.setUnitOfMeasure(entBillFeatBean.getUnitOfMeasure());
				if (entBillFeatBean.getBillTime() != null)
					entBillFeat.setBillTime(entBillFeatBean.getBillTime());
				if (entBillFeatBean.getCatalogueReferenceTime() != null)
					entBillFeat.setCatalogueReferenceTime(entBillFeatBean.getCatalogueReferenceTime());
				if (entBillFeatBean.getFeatureType() != 0)
					entBillFeat.setFeatureType(entBillFeatBean.getFeatureType());
				if (entBillFeat.addToDB()) {
					setLogTrail("TblEntBillFeature Record added to DB");
				} else {
					setLogTrail("Failed to add Record to TblEntBillFeatures");
					return false;
				}
			}
		}
		setStatus(InvErrorCode.SUCCESS);
		return true;
	}
	
	public boolean addAuthFeatureToEnterprise() throws Exception, SQLException {
		if (authFeaturesList.size() > 0) {
			for (int i = 0; i < authFeaturesList.size(); i++) {
				FeaturesBean featureDbBean = authFeaturesList.get(i);
				log.info(" *** Feature Id is <{}>", featureDbBean.getFeaturesDbBean().getFeatureId());
				Features feature = new Features(featureDbBean, dbCon);
				feature.setAuthServiceId((int) getAuthServicesId());
				log.info("Feature Id is <{}>", feature.getFeaturesDbBean().getFeatureId());
				if (!feature.addAuthServices()) {
					setStatus(InvErrorCode.INTERNAL_ERROR);
					log.info(feature.getStatusDesc());
					return false;
				}
			}
		} else {
			setStatus(InvErrorCode.SUCCESS);
			log.info("No AuthFeature to add");
			return true;
		}
		setStatus(InvErrorCode.SUCCESS);
		return true;
	}
	
	// added by Praveen Kumar
	
	public boolean modifyInDB() throws SQLException, Exception {
		// try {
		if (customerId == null) {
			setStatus(InvErrorCode.INTERNAL_ERROR);
			// setStatusDesc("FAILURE in modifyInDB Enterprise. enterprise Id missing.");
			System.out
					.println("FAILURE in modifyInDB Enterprise. enterprise Id missing.");
			return false;
		}
		DBTblEnterprise enterpriseDbBean = getEnterpriseToUpdate();
		enterpriseDbBean.whereEnterpriseIdEQ(customerId);
		if (enterpriseDbBean.updateSpByWhere(dbCon) <= 0) {
			return false;
		}
		if (customerId == null) {
			setStatus(InvErrorCode.INTERNAL_ERROR);
			// setStatusDesc("FAILURE in modifyInDB Enterprise. Customer Id missing.");
			System.out
					.println("FAILURE in modifyInDB Enterprise. Customer Id missing.");
			return false;
		}
		DBTblCustomer customerDbBean = getCustomerToUpdate();
		customerDbBean.whereCustomerIdEQ(customerId);
		if (customerDbBean.updateSpByWhere(dbCon) <= 0) {
			return false;
		}

		log.info("Before size " + entBillFeatBeanList.size());
		if (entBillFeatBeanList.size() > 0) {
			for (int i = 0; i < entBillFeatBeanList.size(); i++) {
				TblEntBillFeaturesBean entBillFeatBean = entBillFeatBeanList
						.get(i);
				TblEntBillFeatures entBillFeat = new TblEntBillFeatures(dbCon);
				entBillFeat.setFeatureInstanceId(entBillFeatBean
						.getFeatureInstanceId());
				if (entBillFeatBean.getEnterpriseId() != null)
					entBillFeat.setEnterpriseId(entBillFeatBean
							.getEnterpriseId());
				if (entBillFeatBean.getLocationId() != null)
					entBillFeat.setLocationId(entBillFeatBean.getLocationId());
				if (entBillFeatBean.getFeatureCode() != null)
					entBillFeat
							.setFeatureCode(entBillFeatBean.getFeatureCode());
				if (entBillFeatBean.getPbli() != null)
					entBillFeat.setPbli(entBillFeatBean.getPbli());
				if (entBillFeatBean.getChargeType() != null)
					entBillFeat.setChargeType(entBillFeatBean.getChargeType());
				if (entBillFeatBean.getChargeFrequency() != null)
					entBillFeat.setChargeFrequency(entBillFeatBean
							.getChargeFrequency());
				if (entBillFeatBean.getUnitOfMeasure() != null)
					entBillFeat.setUnitOfMeasure(entBillFeatBean
							.getUnitOfMeasure());
				if (entBillFeatBean.getBillTime() != null)
					entBillFeat.setBillTime(entBillFeatBean.getBillTime());
				if (entBillFeatBean.getCatalogueReferenceTime() != null)
					entBillFeat.setCatalogueReferenceTime(entBillFeatBean.getCatalogueReferenceTime());
				if (entBillFeatBean.getFeatureType() != 0)
					entBillFeat.setFeatureType(entBillFeatBean.getFeatureType());
				TblEntBillFeaturesQuery lentBillQry = new TblEntBillFeaturesQuery();
				lentBillQry.whereFeatureInstanceIdEQ(entBillFeatBean
						.getFeatureInstanceId());
				lentBillQry.query(dbCon);
				if (lentBillQry.size() == 1) {
					if (entBillFeat.modifyInDB()) {
						setLogTrail("TblEntBillFeature Record updated to DB");
					} else {
						setLogTrail("Failed to update Record to TblEntBillFeatures");
						return false;
					}
				} else {
					if (entBillFeat.addToDB()) {
						setLogTrail("TblEntBillFeature Record inserted into DB");
					} else {
						setLogTrail("Failed to insert Record to TblEntBillFeatures");
						return false;
					}
				}

			}
		} else {
			System.out
					.println("Nothing in the list so nothing to add in feature");
		}

		/*
		 * if(getEntBillFeatBean() != null){ DBTblEntBillFeatures
		 * tblEntBillFeatDbBean = getEnterpriseBillFeaturesToUpdate();
		 * tblEntBillFeatDbBean.whereEnterpriseIdEQ(customerId); if
		 * (tblEntBillFeatDbBean.updateSpByWhere(dbCon) <= 0 ) { return false; }
		 * } else{
		 * LogUtil.info(" No EnterpriseBill Features record to update:" );
		 * }
		 */
		/*
		 * } catch (SQLException s) { s.printStackTrace();
		 * setStatus(InvErrorCode.DB_EXCEPTION);
		 * //setStatusDesc("DB_FAILURE in modifyInDB Enterprise");
		 * LogUtil.info("DB_FAILURE in modifyInDB Enterprise"); return
		 * false; }
		 */
		setStatus(InvErrorCode.SUCCESS);
		// setStatusDesc("Successfully UPDATED Location into the DB");
		return true;
	}
	
	public boolean getDevicesForEnterprise() throws SQLException, Exception {
		Device devObj = new Device(dbCon);
		devObj.setEnterpriseId(customerId);
		devObj.setGetAll(true);
		if (devObj.getGatewayDeviceIdByEnterpriseId()) {
			log.info("getGatewayDeviceIdByEnterpriseId() is true");
			List<Long> gwDevIdList = devObj.getGwDeviceIdList();
			if (gwDevIdList.size() > 0) {
				log.info("gwDevIdList.size():" + gwDevIdList.size());
				for (int i = 0; i < gwDevIdList.size(); i++) {
					GatewayDevice gtwDev = new GatewayDevice(dbCon);
					gtwDev.setGatewayDeviceId((gwDevIdList.get(i)).longValue());
					if (gtwDev.getGwDeviceDetailsByGatewayDeviceId()) {
						System.out
								.println("getGwDeviceDetailsByGatewayDeviceId() is true");
						deviceList.add(gtwDev);
					}
				}
				if (deviceList.size() <= 0)
					return false;
			} else
				return false;
		} else {
			setStatus(InvErrorCode.NOTFOUND_GATEWAYDEVICE_ID);
			return false;
		}
		return true;
	}
	
	public boolean deleteFromDB() throws SQLException, Exception {
		// try {
		if (getCustomerId() == null || getCustomerId().equalsIgnoreCase("")) {
			log.info("Invalid Input");
			setStatus(InvErrorCode.INVALID_INPUT);
			return false;
		}

		/*
		 * If there is any Location associated to the Enterprise then do not
		 * delete the same.
		 */
		/*
		 * if ( isLocationAssociatedToEnterprise() == true ) {
		 * LogUtil.info(
		 * "Couldnot delete Enterprise since Location is assiociated with enterprise"
		 * ); setStatus(InvErrorCode.FOUND_LOCATION); return false; }
		 */

		TblEnterpriseQuery tblEnterpriseQuery = new TblEnterpriseQuery();
		String whereEnterpriseClause = " where ENTERPRISE_ID = \'" + customerId
				+ "\'";
		tblEnterpriseQuery.queryByWhere(dbCon, whereEnterpriseClause);
		if (tblEnterpriseQuery.size() > 0) {
			int rivCustomer = (int) tblEnterpriseQuery.getDbBean(0)
					.getRivCustomer();
			if (shellMigration && rivCustomer == VzbVoipEnum.YesNoType.Y) {
				System.out
						.println("Delete came as part of sbc migration, but customer is already riv customer, so bypassing the delete enterprise");
				setStatus(InvErrorCode.SUCCESS);
				return true;
			}
			// delete AuthServices
			Features features = new Features(dbCon);
			features.setAuthServiceId((int) tblEnterpriseQuery.getDbBean(0)
					.getAuthServicesId());
			features.deleteAuthServices();
			// delete PerfixRotuing
			TblPrefixRoutingQuery tblPrefixRoutingQuery = new TblPrefixRoutingQuery();
			String wherePrifixClause = " where ENTERPRISE_ID = \'" + customerId
					+ "\'";
			tblPrefixRoutingQuery.queryByWhere(dbCon, wherePrifixClause);
			if (tblPrefixRoutingQuery.size() > 0) {
				PrefixRouting prefixRouting = new PrefixRouting(dbCon);
				for (int i = 0; i < tblPrefixRoutingQuery.size(); i++) {
					prefixRouting.setPrefixId(tblPrefixRoutingQuery
							.getDbBean(i).getPrefixRoutingId());
					prefixRouting.deletePrefixRouting();
				}
			}
			long callPlanId = 0;
			// delete CallingPlanId Entree
			if (tblEnterpriseQuery.getDbBean(0).getCallingPlanId() > 1) {
				callPlanId = tblEnterpriseQuery.getDbBean(0).getCallingPlanId();
			}
			// delete Devices
			if (getDevicesForEnterprise() == true) {
				if (getDeviceList().size() > 0) {
					log.info("Enterprise devices:"
							+ getDeviceList().size());
					for (int i = 0; i < getDeviceList().size(); i++) {
						log.info("Enterprise gw device Id:"
								+ getDeviceList().get(i).getGatewayDeviceId());
						if (migration
								&& getDeviceList().get(i).getSbcMigInd() == 1) {
							System.out
									.println("Enterprise gw device Id:"
											+ getDeviceList().get(i)
													.getGatewayDeviceId()
											+ " is not being deleted since its sbc migrated");
						} else {
							TblDeviceMapQuery dviceMapQuery = new TblDeviceMapQuery();
							dviceMapQuery
									.whereGatewayDeviceIdEQ(getDeviceList()
											.get(i).getGatewayDeviceId());
							dviceMapQuery.query(dbCon);
							if (dviceMapQuery.size() > 0) {
								Device deviceBean = new Device(dbCon);
								deviceBean.setDeviceMapId(dviceMapQuery
										.getDbBean(0).getDeviceMapId());
								deviceBean.deleteDevice();
							}
						}
					}
				}
			}
			// Deleting Enterprise Admin Entry - Added by Vijaykumar S
			TblEnterpriseAdminQuery entAdminQry = new TblEnterpriseAdminQuery();
			wherePrifixClause = " where ENTERPRISE_ID = \'" + customerId + "\'";
			entAdminQry.queryByWhere(dbCon, wherePrifixClause);
			if (entAdminQry.size() > 0) {
				EnterpriseAdmin enterpriseAdmin = new EnterpriseAdmin(dbCon);
				for (int i = 0; i < entAdminQry.size(); i++) {
					enterpriseAdmin.setEnterpriseId(entAdminQry.getDbBean(i)
							.getEnterpriseId());
					enterpriseAdmin.deleteEnterpriseAdmin();
				}
			}

			// delete DailPlan Entree
			TblDialPlanQuery dialPlanQry = new TblDialPlanQuery();
			dialPlanQry.whereEnterpriseIdEQ(customerId);
			dialPlanQry.query(dbCon);
			if (dialPlanQry.size() > 0) {
				DialPlan dialPlanBean = new DialPlan(dbCon);
				for (int i = 0; i < dialPlanQry.size(); i++) {
					dialPlanBean.setDialPlanId(dialPlanQry.getDbBean(i)
							.getDialPlanId());
					dialPlanBean.setRollbackFlag(rollbackFlag);
					dialPlanBean.deleteDialPlan();
				}
			}

			// Delete department
			TblDepartmentQuery deptQry = new TblDepartmentQuery();
			deptQry.whereEnterpriseIdEQ(customerId);
			deptQry.query(dbCon);
			if (deptQry.size() > 0) {
				Department deptBean = new Department(dbCon);
				for (int i = 0; i < deptQry.size(); i++) {
					deptBean.setDepartmentId(deptQry.getDbBean(i)
							.getDepartmentId());
					deptBean.deleteDepartment();
				}
			}
			DigitString digitStringObj = new DigitString(dbCon);
			digitStringObj.setCallingPlanId((int) callPlanId);
			digitStringObj.deleteCallingPlanDigits();
			digitStringObj.setEnterpriseId(customerId);
			digitStringObj.deleteDigitStringByEnterpriseId();

			System.out
					.println("*** Before deleting the TBL_IPCC_LoadSharing ***");
			log.info("*** CustomerId:" + customerId);
			DBTblIpccLoadsharing loadShareBean = new DBTblIpccLoadsharing();
			loadShareBean.whereEnterpriseIdEQ(customerId);
			loadShareBean.deleteByWhere(dbCon);
			setLogTrail("Deleted details related to enterprise: " + customerId
					+ " from Tbl_IPCC_LOADSHARING");

			log.info("*** Before deleting the TBL_IPCC_SBC_MAP ***");
			DBTblIpccSbcMap dbBean = new DBTblIpccSbcMap();
			dbBean.whereEnterpriseIdEQ(customerId);
			dbBean.deleteByWhere(dbCon);
			setLogTrail("Deleted details related to enterprise: " + customerId
					+ " from TBL_IPCC_SBC_MAP ");
			System.out
					.println("*** DONE deleting the TBL_IPCC_LOADSHARING AND TBL_IPCC_SBC_MAP ***");

			DBTblEnterpriseLorSbcMap tsoEntLorSbcBean = new DBTblEnterpriseLorSbcMap();
			tsoEntLorSbcBean.whereEnterpriseIdEQ(customerId);
			tsoEntLorSbcBean.deleteByWhere(dbCon);
			setLogTrail("Deleted details related to enterprise: " + customerId
					+ " from tbl_enterprise_lor_sbc_map");

			DBTblTsoEnterpriseSbcMap tsoEntSbcBean = new DBTblTsoEnterpriseSbcMap();
			tsoEntSbcBean.whereEnterpriseIdEQ(customerId);
			tsoEntSbcBean.deleteByWhere(dbCon);
			setLogTrail("Deleted details related to enterprise: " + customerId
					+ " from tbl_tso_enterprise_sbc_map");

			TblTsoEnterpriseTrunkQuery tsoEntTrunkQry = new TblTsoEnterpriseTrunkQuery();
			String whereClausea = "where ENTERPRISE_ID = '" + customerId + "'";
			tsoEntTrunkQry.queryByWhere(dbCon, whereClausea);
			if (tsoEntTrunkQry.size() > 0) {
				for (int i = 0; i < tsoEntTrunkQry.size(); i++) {
					long enterpriseTrunkId = tsoEntTrunkQry.getDbBean(i)
							.getEnterpriseTrunkId();
					TsoEnterpriseTrunk tsoEnterpriseTrunk = new TsoEnterpriseTrunk(
							dbCon);
					tsoEnterpriseTrunk.setEnterpriseTrunkId(enterpriseTrunkId);
					tsoEnterpriseTrunk.deleteFromDB();
				}
			}

			TblTsoRoutingGroupQuery tsoRoutingGroupQry = new TblTsoRoutingGroupQuery();
			String whereClauseb = "where ENTERPRISE_ID = '" + customerId + "'";
			tsoRoutingGroupQry.queryByWhere(dbCon, whereClauseb);
			if (tsoRoutingGroupQry.size() > 0) {
				for (int i = 0; i < tsoRoutingGroupQry.size(); i++) {
					String routingGroupId = tsoRoutingGroupQry.getDbBean(i)
							.getRoutingGroupId();
					TsoRoutingGroup tsoRoutingGroup = new TsoRoutingGroup(dbCon);
					tsoRoutingGroup.setRoutingGroupId(routingGroupId);
					tsoRoutingGroup.deleteFromDB();
				}
			}

			TblTsoEbiQuery tsoEbiQry = new TblTsoEbiQuery();
			String whereClausebi = "where ENTERPRISE_ID = '" + customerId + "'";
			tsoEbiQry.queryByWhere(dbCon, whereClausebi);
			if (tsoEbiQry.size() > 0) {
				for (int i = 0; i < tsoEbiQry.size(); i++) {
					long ebiId = tsoEbiQry.getDbBean(i).getEbiId();
					TsoEbi tsoEbiObj = new TsoEbi(dbCon);
					tsoEbiObj.setEnvOrderId(getEnvOrderId());
					tsoEbiObj.setEbiId(ebiId);
					tsoEbiObj.deleteFromDB();
				}
			}
			setLogTrail("Deleted details related to enterprise: " + customerId
					+ " from DBTblTsoEbi");

			/**
			 * Delete Record from TblEntBillFeatures , if any, for this
			 * enterprise
			 **/
			DBTblEntBillFeatures entBillFeatures = new DBTblEntBillFeatures();
			entBillFeatures.whereEnterpriseIdEQ(customerId);
			entBillFeatures.deleteByWhere(dbCon);
			setLogTrail("Deleted TblEntBillFeatures record for this Enterprise:"
					+ customerId);
	        //E2Ei IPCC Enterprise dependencies
	        long orderPlatform = 0;
	        long productType = 0;
	        TblCustomerQuery custQuery = new TblCustomerQuery();
	        custQuery.whereCustomerIdEQ(customerId);
	        custQuery.query(dbCon);
	        
	        if(custQuery.size() > 0){
	        	orderPlatform = custQuery.getDbBean(0).getOrderPlatform();
	        	productType = custQuery.getDbBean(0).getProductType();
	        	if(orderPlatform == VzbVoipEnum.OrderPlatform.E2EI && productType == VzbVoipEnum.ProductType.IPCCC){
	        		setLogTrail("Delete E2Ei-IPCC dependent details");
	        		DBTblIpccIptermSbcMap iptermSbcDetails = new DBTblIpccIptermSbcMap();
	        		iptermSbcDetails.whereEnterpriseIdEQ(customerId);
	        		iptermSbcDetails.deleteByWhere(dbCon);
	        		setLogTrail("Deleted TblIpccIptermSbcMap record for this Enterprise:"+customerId);
	        		
	        		DBTblIpccIpTerm iptermDetails = new DBTblIpccIpTerm();
	        		iptermDetails.whereEnterpriseIdEQ(customerId);
	        		iptermDetails.deleteByWhere(dbCon);
	        		setLogTrail("Deleted TblLocation record for this Enterprise:"+customerId);
	        		
	        		TblLocationQuery locQuery = new TblLocationQuery();
	        		locQuery.whereEnterpriseIdEQ(customerId);
	        		locQuery.query(dbCon);
	                if(locQuery.size() > 0){
	                	String locationId = locQuery.getDbBean(0).getLocationId();
	                	
	                	DBTblPublicTnPool publicPoolDetails = new DBTblPublicTnPool();
	            		publicPoolDetails.whereLocationIdEQ(locationId);
	            		publicPoolDetails.deleteByWhere(dbCon);
	            		setLogTrail("Deleted DBTblPublicTnPool record for this Enterprise:"+customerId);
	                }
	                	
	        		DBTblLocation locationDetails = new DBTblLocation();
	        		locationDetails.whereEnterpriseIdEQ(customerId);
	        		locationDetails.deleteByWhere(dbCon);
	        		setLogTrail("Deleted TblLocation record for this Enterprise:"+customerId);
	        		
	        	}
	        }
			/*
			 * TblEntBillFeaturesQuery billFeatQry = new
			 * TblEntBillFeaturesQuery();
			 * billFeatQry.whereEnterpriseIdEQ(customerId);
			 * billFeatQry.query(dbCon); if(billFeatQry.size() > 0 ){
			 * TblEntBillFeatures entBillFeatures = new
			 * TblEntBillFeatures(dbCon); entBillFeatures.setEnterpriseId (
			 * billFeatQry.getDbBean(0).getEnterpriseId()); if
			 * (entBillFeatures.deleteFromDB() ) setLogTrail( " C ); } else {
			 * LogUtil.info("No Records to delete"); }
			 */

			DBTblEnterprise enterpriseDbBean = new DBTblEnterprise();
			enterpriseDbBean.whereEnterpriseIdEQ(customerId);
			DBTblCustomer customerDbBean = new DBTblCustomer();
			customerDbBean.whereCustomerIdEQ(customerId);
			long sbcMigInd = tblEnterpriseQuery.getDbBean(0).getSbcMigInd();

			if (migration && sbcMigInd == 1) {
				enterpriseDbBean.setActiveInd(1);
				enterpriseDbBean.setRivCustomer(VzbVoipEnum.YesNoType.N);
				enterpriseDbBean.setCallingPlanIdNull();
				enterpriseDbBean.updateSpByWhere(dbCon);
				customerDbBean.setActiveInd(1);
				customerDbBean.setRivCustomer(VzbVoipEnum.YesNoType.N);
				customerDbBean.updateSpByWhere(dbCon);
			} else {
				log.info("Before deleting the Ent and customer");
				enterpriseDbBean.deleteByWhere(dbCon);
				customerDbBean.deleteByWhere(dbCon);
			}
			if (callPlanId > 0) {
				CallingPlan callingPlanObj = new CallingPlan(dbCon);
				callingPlanObj.setCallingPlanId((int) callPlanId);
				callingPlanObj.deleteCallingPlan();
			}
		}
		if (migration)
			deleteGUITempDataFromDB();

		/*
		 * } catch (Exception s) { s.printStackTrace();
		 * setStatus(InvErrorCode.DB_EXCEPTION);
		 * //setStatusDesc("DB_FAILURE in deleteFromDB Enterprise");
		 * LogUtil.info("DB_FAILURE in deleteFromDB Enterprise"); return
		 * false; }
		 */
		setStatus(InvErrorCode.SUCCESS);
		// setStatusDesc("Successfully DELETED Location into the DB");
		return true;
	}
}
