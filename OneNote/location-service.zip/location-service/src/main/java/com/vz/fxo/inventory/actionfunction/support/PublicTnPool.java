package com.vz.fxo.inventory.actionfunction.support;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Timestamp;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.vz.fxo.inventory.tn.EsapRestClient;

import EsapEnumPkg.VzbVoipEnum;
import esap.db.DBTblGatewayDeviceInfo;
import esap.db.DBTblLocation;
import esap.db.DBTblPublicTnPool;
import esap.db.DBTblTerminatingRouting;
import esap.db.DBTblTsoEtTn;
import esap.db.TblBsAsQuery;
import esap.db.TblConfigParamsDbBean;
import esap.db.TblConfigParamsQuery;
import esap.db.TblEnterpriseQuery;
import esap.db.TblGatewayDeviceInfoQuery;
import esap.db.TblGroupTnQuery;
import esap.db.TblLocationDbBean;
import esap.db.TblLocationQuery;
import esap.db.TblPublicTnPoolDbBean;
import esap.db.TblPublicTnPoolQuery;
import esap.db.TblTerminatingRoutingQuery;
import esap.db.TblVmAccessQuery;

public class PublicTnPool extends PublicTnPoolBean {
	// members

	private static Logger log = LoggerFactory.getLogger(PublicTnPool.class.toString());

	private Connection connection;
	InvErrorCode status = InvErrorCode.INTERNAL_ERROR;
	// APAC LNP sep 2011 rel
	private TnPorting tnPorting = null;
	
	private boolean rollbackFlag = false;
	private boolean removeTnFlag = false;
	private boolean isExistingTn = false;
	
	public boolean isRollbackFlag() {
		return rollbackFlag;
	}

	public void setRollbackFlag(boolean rollbackFlag) {
		this.rollbackFlag = rollbackFlag;
	}

	public boolean isRemoveTnFlag() {
		return removeTnFlag;
	}

	public void setRemoveTnFlag(boolean removeTnFlag) {
		this.removeTnFlag = removeTnFlag;
	}

	public boolean isExistingTn() {
		return isExistingTn;
	}

	public void setExistingTn(boolean isExistingTn) {
		this.isExistingTn = isExistingTn;
	}
	public PublicTnPool() {
		this.connection = null;
	}
	
	public PublicTnPool(Connection connection) {
		this.connection = connection;
	}

	public PublicTnPool(Connection connection, PublicTnPoolBean poolBean) {
		super(poolBean);
		this.connection = connection;
	}

	public Connection getConnection() {
		return connection;
	}

	public void setConnection(Connection connection) {
		this.connection = connection;
	}

	public int getStatusCode() {
		return status.getErrorCode();
	}

	public String getStatusDesc() {
		return status.getErrorDesc();
	}

	// APAC LNP sep 2011 rel
	/**
	 * @return the tnPortingBean
	 */

	public boolean validatePublicTnPool() {
		return true;
	}

	/**
	 * @param tnPortingBean
	 *            the tnPortingBean to set
	 */
	public void setTnPorting(TnPorting tnPorting) {
		this.tnPorting = tnPorting;
	}

	/**
	 * The method to modify the PublicTnPool record.
	 *
	 * PublicTnPool Id should be set before calling this method.
	 *
	 * @return true Record has been updated SUCCESSFULLY false PublicTnPool Id
	 *         missing / Record update Unsuccessful / Some Error occured.
	 */
	public boolean updatePublicTnPool() throws SQLException, Exception {
		log.info("updatePublicTnPool getTnPoolId() ==>" + getTnPoolId());
		log.info("updatePublicTnPool getTn() ==>" + getTn());
		// try
		// {
		if (getTnPoolId() <= 0) {
			if (getTn().equals("")) {
				setStatusCode(InvErrorCode.INVALID_INPUT);
				log.info("FAILURE in modifyInDB PublicTnPool. PublicTnPoolId/Tn.");
				return false;
			}
		}

		TblPublicTnPoolQuery tQry = new TblPublicTnPoolQuery();
		if (getTnPoolId() > 0) {
			tQry.whereTnPoolIdEQ(getTnPoolId());
		} else {
			tQry.whereTnEQ(getTn());
		}
		tQry.query(connection);

		log.info("Received Ported Status [" + getPortedStatus() + "]");
		if (tQry.size() > 0) {
			setLocationId(tQry.getDbBean(0).getLocationId());

			if (getPortedStatus() == null
					|| (getPortedStatus() != null && (getPortedStatus().equals("") || getPortedStatus().equals("NONE")))) {
				setPortedStatus(tQry.getDbBean(0).getPortedStatus());
				log.info("Set Ported Status to [" + getPortedStatus() + "]");
			}

			if (getTnStatus() <= 0) {
				setTnStatus(tQry.getDbBean(0).getTnStatus());
				log.info("Set Tn Status to [" + getTnStatus() + "]");
			}

			if (getPortinType() == 3 && getPortedStatus().equals("" + VzbVoipEnum.PortStatus.PORTED))// WINBACK
			{
				setPortedStatus("0"); // NATIVE
			}

		}

		DBTblPublicTnPool publicTNPoolBean = getPublicTnPoolToUpdate();
		log.info("Retrieved Ported Status [" + getPortedStatus() + "] for Update");
		if (getTnPoolId() > 0) {
			publicTNPoolBean.whereTnPoolIdEQ(getTnPoolId());
			log.info("updatePublicTnPool:" + getTnPoolId());
		} else {
			publicTNPoolBean.whereTnEQ(getTn());
			log.info("updatePublicTnPool:" + getTn());
		}

		if (getBsTnActivation() != true) {
			log.info("Failed to Retrieve BsTnAct");
			return false;
		}

		FkValidationUtil.isValidPublicTNPoolForMod(connection, publicTNPoolBean);
		// long oldPubip = getPubip();
		long oldActDeact = getActDeact();
		if (deriveActDeact() != true) {
			log.info("Failed to Derive Act Deact");
			return false;
		}
		/*
		 * if (oldPubip > -1) { publicTNPoolBean.setPubip(oldPubip); } else if
		 * (getPubip() > -1) { publicTNPoolBean.setPubip(getPubip()); }
		 */
		if (oldActDeact > 0) {
			publicTNPoolBean.setActDeact((short) oldActDeact);
		} else if (getActDeact() > 0) {
			publicTNPoolBean.setActDeact((short) getActDeact());
		}

		log.info("TN Type [" + publicTNPoolBean.getTnType() + "]");
		// VMA Tn's are never configured in Broadsoft and hence are not
		// candidates for Deactivation or Activation either from ESAP GUI or
		// CSSOP . ESAP GUI will not display VMA TN as a candidate for
		// Activation/Deactivation
		if (publicTNPoolBean.getActDeact() <= 0 || publicTNPoolBean.getTnType() == 2) {
			publicTNPoolBean.setActDeactNull();
		}

		log.info("publicTNPoolBean getPortedStatus :: " + publicTNPoolBean.getPortedStatus());
		log.info("getPortedStatus :: " + getPortedStatus());
		// VOV april changes
		publicTNPoolBean = derivePubipValues(publicTNPoolBean);

		// APAC LNP sep2011
		if (getTnPorting() != null && !(getPortedStatus().equals("" + VzbVoipEnum.PortStatus.NATIVE))) {
			TnPorting tnPortingObj = new TnPorting(connection);
			tnPortingObj.setTnPoolId(getTnPoolId());
			tnPortingObj.updateTnPorting();
			log.info("TnPortingInfo is updated successfully for pool id : " + getTnPoolId());
		} else {
			log.info("update : getTnPorting() is null");
		}

		if (publicTNPoolBean.updateSpByWhere(connection) < 0) {
			return false;
		}
		log.info(" Location STN update ");
		if (updateLocForSTN(publicTNPoolBean.getLocationId(), getTnPoolId())) {
			log.info("STN disassociated from Location ");
		}

		/*
		 * } catch(SQLException s) { s.printStackTrace();
		 * setStatusCode(InvErrorCode.DB_EXCEPTION);
		 * log.info("DB_FAILURE in modifyInDB PublicTnPool"); return false;
		 * }catch( Exception s) { s.printStackTrace();
		 * setStatusCode(InvErrorCode.DB_EXCEPTION); //
		 * log.info("DB_FAILURE in modifyInDB PublicTnPool"); return false; }
		 */
		setStatusCode(InvErrorCode.SUCCESS);
		return true;
	}

	public void setStatusCode(InvErrorCode status) {
		this.status = status;
	}

	public TnPorting getTnPorting() {
		return tnPorting;
	}

	/**
	 * @Param getDetails
	 * @description:
	 * @return boolean
	 * @author Thejas
	 * @editedby
	 */
	public boolean getDetails() {
		try {
			log.info("In PublicTnPool getDetails; PublicTnPoolId=" + getTnPoolId());
			TblPublicTnPoolQuery publicTnPoolQry = new TblPublicTnPoolQuery();
			String whereClause = new String("");
			if (getAll == false) {
				whereClause = " where tn_pool_id = " + getTnPoolId() + " and active_ind = 1";
			} else {
				whereClause = " where tn_pool_id = " + getTnPoolId() + " and active_ind != 0";
			}
			publicTnPoolQry.queryByWhere(connection, whereClause);
			if (publicTnPoolQry.size() == 1) {
				setLocationId((publicTnPoolQry.getDbBean(0)).getLocationId());
				setDepartmentId((publicTnPoolQry.getDbBean(0)).getDepartmentId());
				setTspCode((publicTnPoolQry.getDbBean(0)).getTspCode()); // Jan
																			// 2013
																			// Release
																			// -
																			// E2EI
				setReplacementCli((publicTnPoolQry.getDbBean(0)).getReplacementCli()); // Jan
																						// 2013
																						// Release
																						// -
																						// E2EI
				setTn((publicTnPoolQry.getDbBean(0)).getTn());
				setEnvOrderId((publicTnPoolQry.getDbBean(0)).getEnvOrderId());
				setTnStatus((publicTnPoolQry.getDbBean(0)).getTnStatus());
				setNpaSplitStatus((publicTnPoolQry.getDbBean(0)).getNpaSplitStatus());
				setSwitchClli((publicTnPoolQry.getDbBean(0)).getSwitchClli());
				setTrunk((publicTnPoolQry.getDbBean(0)).getTrunk());
				setActiveInd((publicTnPoolQry.getDbBean(0)).getActiveInd());
				setTnOnOff((publicTnPoolQry.getDbBean(0)).getTnOnOff());
				setPortedStatus((publicTnPoolQry.getDbBean(0)).getPortedStatus());
				setCreatedBy((publicTnPoolQry.getDbBean(0)).getCreatedBy());
				setCreationDate((publicTnPoolQry.getDbBean(0)).getCreationDate());
				setModifiedBy((publicTnPoolQry.getDbBean(0)).getModifiedBy());
				setLastModifiedDate((publicTnPoolQry.getDbBean(0)).getLastModifiedDate());
				setTransitionType((publicTnPoolQry.getDbBean(0)).getTransitionType());
				setPsAli((publicTnPoolQry.getDbBean(0)).getPsAli());
				setVerizonBtn((publicTnPoolQry.getDbBean(0)).getVerizonBtn());
				// APAC LNP sep2011
				TnPorting tnPortingObj = new TnPorting(connection);
				tnPortingObj.setTnPoolId(getTnPoolId());
				boolean result = tnPortingObj.getDetails();
				if (result) {
					setTnPorting(tnPortingObj);
					log.info("PublicTnPool:getDetails(). TnPorting object is set successfully");
				} else {
					log.info("PublicTnPool:getDetails(). TnPorting object is not set");
				}

			} else {
				setStatusCode(InvErrorCode.NOTFOUND_TN);
				return false;
			}

		} catch (SQLException s) {
			s.printStackTrace();
			setStatusCode(InvErrorCode.DB_EXCEPTION);
			return false;
		}
		setStatusCode(InvErrorCode.SUCCESS);
		return true;
	}

	/**
	 * The current PublicTnPool details are extracted using getDetails() and the
	 * new field values are updated over that. The method will update the fields
	 * that are supplied on the current instance if they are different from the
	 * default values for the respective field.
	 *
	 * @return The PublicTnPool to be updated.
	 */
	@SuppressWarnings("unused")
	private DBTblPublicTnPool getPublicTnPoolToUpdate() {
		DBTblPublicTnPool publicTnPoolDbBean = new DBTblPublicTnPool();

		/*
		 * Create a new instance of PublicTnPoolBean. The new instance would
		 * hold default values for the all the PublicTnPool fields.
		 */
		PublicTnPoolBean defaultPublicTnPoolBean = new PublicTnPoolBean();

		PublicTnPool inputPublicTnPool = this;
		/* Set the new fields if required. */
		publicTnPoolDbBean.setTnPoolId(getTnPoolId());

		if (inputPublicTnPool.getLocationId() != null && !inputPublicTnPool.getLocationId().equals(defaultPublicTnPoolBean.getLocationId())) {
			publicTnPoolDbBean.setLocationId(inputPublicTnPool.getLocationId());
		}

		if (inputPublicTnPool.getDepartmentId() != null
				&& !inputPublicTnPool.getDepartmentId().equals(defaultPublicTnPoolBean.getDepartmentId())) {
			if (!"".equals(inputPublicTnPool.getDepartmentId())) {
				publicTnPoolDbBean.setDepartmentId(inputPublicTnPool.getDepartmentId());
			} else {
				publicTnPoolDbBean.setDepartmentIdNull();
			}
		}

		// Jan 2013 release - E2EI
		if (inputPublicTnPool.getTspCode() != null && !inputPublicTnPool.getTspCode().equals(defaultPublicTnPoolBean.getTspCode())) {
			if (!"".equals(inputPublicTnPool.getTspCode())) {
				publicTnPoolDbBean.setTspCode(inputPublicTnPool.getTspCode());
			} else {
				publicTnPoolDbBean.setTspCodeNull();
			}
		}

		// May 2013 release
		if (inputPublicTnPool.getReplacementCli() != null
				&& !inputPublicTnPool.getReplacementCli().equals(defaultPublicTnPoolBean.getReplacementCli())) {
			if (!"".equals(inputPublicTnPool.getReplacementCli())) {
				publicTnPoolDbBean.setReplacementCli(inputPublicTnPool.getReplacementCli());
			} else {
				publicTnPoolDbBean.setReplacementCliNull();
			}
		}

		if (inputPublicTnPool.getPortedStatus() != null
				&& !inputPublicTnPool.getPortedStatus().equals(defaultPublicTnPoolBean.getPortedStatus())) {
			if (!"".equals(inputPublicTnPool.getPortedStatus())) {
				publicTnPoolDbBean.setPortedStatus(inputPublicTnPool.getPortedStatus());
				if (getPortedStatus().equals("" + VzbVoipEnum.PortStatus.PORTED)
						&& (inputPublicTnPool.getTnOnOff() == defaultPublicTnPoolBean.getTnOnOff())) {
					PublicTnPool temp = new PublicTnPool(connection);
					if (getTnPoolId() > 0) {
						temp.setTnPoolId(getTnPoolId());
						temp.getPublicTnPoolDetailsByTnPoolId();
					} else {
						temp.setTn(getTn());
						temp.getPublicTnPoolDetailsByTn();
					}
					if ((getPortedStatus().equals("" + VzbVoipEnum.PortStatus.PORTED) && temp.getPortedStatus().equals(
							"" + VzbVoipEnum.PortStatus.PORT_PENDING))) {
						publicTnPoolDbBean.setTnOnOff(1);
					}
				}
			} else {
				publicTnPoolDbBean.setPortedStatusNull();
			}
		}

		if (inputPublicTnPool.getTn() != null && !inputPublicTnPool.getTn().equals(defaultPublicTnPoolBean.getTn())) {
			publicTnPoolDbBean.setTn(inputPublicTnPool.getTn());
		}
		if (inputPublicTnPool.getEnvOrderId() != defaultPublicTnPoolBean.getEnvOrderId()) {
			if (inputPublicTnPool.getEnvOrderId() != 0) {
				publicTnPoolDbBean.setEnvOrderId(inputPublicTnPool.getEnvOrderId());
			} else {
				publicTnPoolDbBean.setEnvOrderIdNull();
			}
		}
		if (inputPublicTnPool.getTnType() != defaultPublicTnPoolBean.getTnType()) {
			if (inputPublicTnPool.getTnType() != 0) {
				publicTnPoolDbBean.setTnType(inputPublicTnPool.getTnType());
			} else {
				publicTnPoolDbBean.setTnTypeNull();
			}
		}

		if (inputPublicTnPool.getTnStatus() != defaultPublicTnPoolBean.getTnStatus()) {
			publicTnPoolDbBean.setTnStatus(inputPublicTnPool.getTnStatus());
			if (inputPublicTnPool.getTnStatus() == VzbVoipEnum.TnStatus.AVAILABLE) {
				publicTnPoolDbBean.setTnType(VzbVoipEnum.TnType.RES);
			}
		}

		if (inputPublicTnPool.getNpaSplitStatus() != defaultPublicTnPoolBean.getNpaSplitStatus()) {
			if (inputPublicTnPool.getNpaSplitStatus() != 0) {
				publicTnPoolDbBean.setNpaSplitStatus(inputPublicTnPool.getNpaSplitStatus());
			} else {
				publicTnPoolDbBean.setNpaSplitStatusNull();
			}
		}
		if (inputPublicTnPool.getSwitchClli() != defaultPublicTnPoolBean.getSwitchClli()) {
			if (!"".equals(inputPublicTnPool.getSwitchClli())) {
				publicTnPoolDbBean.setSwitchClli(inputPublicTnPool.getSwitchClli());
			} else {
				publicTnPoolDbBean.setSwitchClliNull();
			}
		}
		if (inputPublicTnPool.getTrunk() != defaultPublicTnPoolBean.getTrunk()) {
			if (!"".equals(inputPublicTnPool.getTrunk())) {
				publicTnPoolDbBean.setTrunk(inputPublicTnPool.getTrunk());
			} else {
				publicTnPoolDbBean.setTrunkNull();
			}
		}

		log.info("inputPublicTnPool.getActiveInd() Ind:" + inputPublicTnPool.getActiveInd());
		log.info("defaultPublicTnPoolBean.getActiveInd() Ind:" + defaultPublicTnPoolBean.getActiveInd());
		if (inputPublicTnPool.getActiveInd() != defaultPublicTnPoolBean.getActiveInd()) {
			if (inputPublicTnPool.getActiveInd() != 0) {
				publicTnPoolDbBean.setActiveInd(inputPublicTnPool.getActiveInd());
			} else {
				publicTnPoolDbBean.setActiveIndNull();
			}
		}
		log.info("Active Ind:" + inputPublicTnPool.getActiveInd());

		if (inputPublicTnPool.getTnOnOff() != defaultPublicTnPoolBean.getTnOnOff()) {
			publicTnPoolDbBean.setTnOnOff(inputPublicTnPool.getTnOnOff());

		}

		log.info("ActDeact Indicator: " + inputPublicTnPool.getActDeact());
		if (inputPublicTnPool.getActDeact() != defaultPublicTnPoolBean.getActDeact()) {
			publicTnPoolDbBean.setActDeact((short) inputPublicTnPool.getActDeact());
		}

		log.info("Li Indicator: " + inputPublicTnPool.getLiInd());
		if (inputPublicTnPool.getLiInd() != defaultPublicTnPoolBean.getLiInd()) {
			publicTnPoolDbBean.setLiInd((short) inputPublicTnPool.getLiInd());
		}

		log.info("PubIp : " + inputPublicTnPool.getPubip());
		if (inputPublicTnPool.getPubip() != defaultPublicTnPoolBean.getPubip()) {
			publicTnPoolDbBean.setPubip(inputPublicTnPool.getPubip());
		}

		log.info("PubIpIn : " + inputPublicTnPool.getPubipIn());
		if (inputPublicTnPool.getPubipIn() != defaultPublicTnPoolBean.getPubipIn()) {
			publicTnPoolDbBean.setPubipIn(inputPublicTnPool.getPubipIn());
		}

		log.info("PubIpOut : " + inputPublicTnPool.getPubipOut());
		if (inputPublicTnPool.getPubipOut() != defaultPublicTnPoolBean.getPubipOut()) {
			publicTnPoolDbBean.setPubipOut(inputPublicTnPool.getPubipOut());
		}

		if (inputPublicTnPool.getModifiedBy() != null && !("".equalsIgnoreCase(inputPublicTnPool.getModifiedBy()))) {
			publicTnPoolDbBean.setModifiedBy(inputPublicTnPool.getModifiedBy());
		} else {
			publicTnPoolDbBean.setModifiedBy("ESAP_INV");
		}

		// AUS portin type
		if ((inputPublicTnPool.getPortinType() != 0) && (inputPublicTnPool.getPortinType() != defaultPublicTnPoolBean.getPortinType())) {
			publicTnPoolDbBean.setPortinType(inputPublicTnPool.getPortinType());
		}

		if (inputPublicTnPool.getTransitionType() != defaultPublicTnPoolBean.getTransitionType()) {
			if (inputPublicTnPool.getTransitionType() != 0) {
				publicTnPoolDbBean.setTransitionType(inputPublicTnPool.getTransitionType());
			} else {
				publicTnPoolDbBean.setTransitionTypeNull();
			}
		}

		if (!inputPublicTnPool.getPsAli().equalsIgnoreCase(defaultPublicTnPoolBean.getPsAli())) {
			if (inputPublicTnPool.getPsAli() != null) {
				publicTnPoolDbBean.setPsAli(inputPublicTnPool.getPsAli());
			}
		}

		if (inputPublicTnPool.getVerizonBtn() != null && !inputPublicTnPool.getVerizonBtn().equals(defaultPublicTnPoolBean.getVerizonBtn())) {
			if (!"".equals(inputPublicTnPool.getVerizonBtn())) {
				publicTnPoolDbBean.setVerizonBtn(inputPublicTnPool.getVerizonBtn());
			} else {
				publicTnPoolDbBean.setVerizonBtnNull();
			}
		}
		log.info("publicTnPoolDbBean====>" + publicTnPoolDbBean);
		publicTnPoolDbBean.setLastModifiedDate(new Timestamp(System.currentTimeMillis()));
		return publicTnPoolDbBean;
	}

	public boolean getBsTnActivation() {
		log.info("Entering getBsTnActivation");
		try {
			if (getLocationId() == null || (getLocationId() != null && "".equals(getLocationId()))) {
				log.info("LocationId not set");
				TblPublicTnPoolQuery tQry = new TblPublicTnPoolQuery();
				if (getTnPoolId() > 0) {
					tQry.whereTnPoolIdEQ(getTnPoolId());
				} else {
					tQry.whereTnEQ(getTn());
				}
				tQry.query(connection);

				if (tQry.size() > 0) {
					setLocationId(tQry.getDbBean(0).getLocationId());
				}
			} else {
				log.info("Location Id Recieved as [" + getLocationId() + "]");
			}
			TblLocationQuery lQry = new TblLocationQuery();
			lQry.whereLocationIdEQ(getLocationId());
			lQry.query(connection);
			if (lQry.size() <= 0) {
				log.info("LocationId [" + getLocationId() + "] Not Found");
				return false;
			}

			TblEnterpriseQuery eQry = new TblEnterpriseQuery();
			eQry.whereEnterpriseIdEQ(lQry.getDbBean(0).getEnterpriseId());
			eQry.query(connection);
			if (eQry.size() <= 0) {
				log.info("EnterpriseId [" + lQry.getDbBean(0).getEnterpriseId() + "] Not Found");
				return false;
			}
			setCustMarket(eQry.getDbBean(0).getCustMarket());
			if (getTnType() != VzbVoipEnum.TnType.VILO) {
				TblBsAsQuery bQry = new TblBsAsQuery();
				bQry.whereBsAsIdEQ((int) eQry.getDbBean(0).getAsId());
				bQry.query(connection);
				if (bQry.size() <= 0) {
					log.info("Bs As Id[" + eQry.getDbBean(0).getAsId() + "] Not Found");
					return false;
				}
				setBsTnAct(bQry.getDbBean(0).getTnActivation());
			}
		} catch (SQLException e) {
			setStatusCode(InvErrorCode.DB_EXCEPTION);
			log.info("Failed to retrieve BsTnAct ");
			e.printStackTrace();
			return false;
		}
		setStatusCode(InvErrorCode.SUCCESS);
		log.info("Successfully retrived BsTnAct [" + getBsTnAct() + "]");
		return true;
	}

	// Note: DoNOT touch act_deact field if BnTnActivation=off.
	// As null is being looked at by OM to figure out which PP tns were prestage
	// before BsTnActivation was turned ON
	// and are indeed in the pipeline. So that OM can still invoke the old WF
	// for these PP tn when activated
	// (after BsTnActivation is set to ON).
	public boolean deriveActDeact() {
		log.info("Entering deriveActDeact");
		// long nPubip = -1;
		try {
			if (getLocationId() == null) {
				throw new Exception("Location id not found for" + getLocationId());
			}

			/*
			 * TblLocationQuery locQry = new TblLocationQuery();
			 * locQry.whereLocationIdEQ(getLocationId());
			 * locQry.query(connection); if (locQry != null && locQry.size() >
			 * 0) { nPubip = locQry.getDbBean(0).getPubIp(); }
			 * log.info("nPubip " + nPubip);
			 */
			if (getCustMarket() == VzbVoipEnum.CustMarketType.US || getCustMarket() == VzbVoipEnum.CustMarketType.APAC) {
				log.info("US/APAC Region");
				/*
				 * if (getBsTnAct() == VzbVoipEnum.TnActivation.OFF) {
				 * log.info("BS Tn Activation is OFF");
				 * log.info("TN Status is : " + getTnStatus()); if
				 * (getTnStatus() == VzbVoipEnum.TnStatus.AVAILABLE) {
				 * log.info("TN Status is Available. Set PubIp to OFF");
				 * setPubip(VzbVoipEnum.PubIpOnOff.PUB_OFF); } else if
				 * (getTnStatus() == VzbVoipEnum.TnStatus.ASSIGNED &&
				 * (getPortedStatus().equals("" + VzbVoipEnum.PortStatus.PORTED)
				 * || getPortedStatus().equals("" +
				 * VzbVoipEnum.PortStatus.NATIVE))) { log.info(
				 * "TN Status is Assigned and Ported Status is Native/Ported. Set PubIp to ON"
				 * ); setPubip(VzbVoipEnum.PubIpOnOff.PUB_ON); } else if
				 * (getTnStatus() == VzbVoipEnum.TnStatus.ASSIGNED &&
				 * getPortedStatus().equals("" +
				 * VzbVoipEnum.PortStatus.PORT_PENDING)) { log.info(
				 * "TN Status is Assigned and Ported Status is PortPending. Set PubIp to OFF"
				 * ); setPubip(VzbVoipEnum.PubIpOnOff.PUB_OFF); } } else
				 */
				if (getBsTnAct() == VzbVoipEnum.TnActivation.ON) {
					log.info("BS Tn Activation is ON");
					log.info("TN Status is : " + getTnStatus());
					if (getTnStatus() == VzbVoipEnum.TnStatus.AVAILABLE) {
						log.info("TN Status is Available. Set PubIp to OFF. And ActDeact to Deactivated");
						setActDeact(VzbVoipEnum.ActDeact.DEACTIVATED);
						// setPubip(VzbVoipEnum.PubIpOnOff.PUB_OFF);
					} else if (getTnStatus() == VzbVoipEnum.TnStatus.ASSIGNED
							&& (getPortedStatus().equals("" + VzbVoipEnum.PortStatus.PORTED) || getPortedStatus().equals(
									"" + VzbVoipEnum.PortStatus.NATIVE))) {
						log.info("TN Status is Assigned and Ported Status is Native/Ported. Set PubIp to ON and ActDeact to Activated");
						setActDeact(VzbVoipEnum.ActDeact.ACTIVATED);
						// setPubip(VzbVoipEnum.PubIpOnOff.PUB_ON);
						/*
						 * if (nPubip == 1) {
						 * setPubip(VzbVoipEnum.PubIpOnOff.PUB_ON); } else {
						 * setPubip(VzbVoipEnum.PubIpOnOff.PUB_OFF); }
						 */

					} else if (getTnStatus() == VzbVoipEnum.TnStatus.ASSIGNED
							&& getPortedStatus().equals("" + VzbVoipEnum.PortStatus.PORT_PENDING)) {
						log.info("TN Status is Assigned and Ported Status is PortPending. Set PubIp to OFF and ActDeact to Deactivated");
						setActDeact(VzbVoipEnum.ActDeact.DEACTIVATED);
						// setPubip(VzbVoipEnum.PubIpOnOff.PUB_OFF);
					}
				}
			} /*
			 * else { log.info("Act/Deact PubIP Rules for EMEA"); if
			 * (getTnStatus() == VzbVoipEnum.TnStatus.AVAILABLE) {
			 * log.info("TN Status is Available. Set PubIp to OFF");
			 * setPubip(VzbVoipEnum.PubIpOnOff.PUB_OFF); } else if
			 * (getTnStatus() == VzbVoipEnum.TnStatus.ASSIGNED &&
			 * (getPortedStatus().equals("" + VzbVoipEnum.PortStatus.PORTED) ||
			 * getPortedStatus().equals("" + VzbVoipEnum.PortStatus.NATIVE))) {
			 * log.info(
			 * "TN Status is Assigned and Ported Status is Native/Ported. Set PubIp to ON"
			 * ); //setPubip(VzbVoipEnum.PubIpOnOff.PUB_ON); if(nPubip >= 0)
			 * setPubip
			 * (VzbVoipEnum.YesNoType.valueByName(Long.toString(nPubip))); if
			 * (nPubip == 1) { setPubip(VzbVoipEnum.PubIpOnOff.PUB_ON); } else {
			 * setPubip(VzbVoipEnum.PubIpOnOff.PUB_OFF); } } else if
			 * (getTnStatus() == VzbVoipEnum.TnStatus.ASSIGNED &&
			 * getPortedStatus().equals("" +
			 * VzbVoipEnum.PortStatus.PORT_PENDING)) { log.info(
			 * "TN Status is Assigned and Ported Status is PortPending. Set PubIp to OFF"
			 * ); setPubip(VzbVoipEnum.PubIpOnOff.PUB_OFF); }
			 * 
			 * }
			 */
		} catch (Exception e) {
			log.info("Failed to retrieve ActDeact");
			e.printStackTrace();
			return false;
		}
		setStatusCode(InvErrorCode.SUCCESS);
		log.info("Successfully retrived ActDeact");
		return true;
	}

	public DBTblPublicTnPool derivePubipValues(DBTblPublicTnPool tnDbBean) {
		// VOV 2014 April changes
		// pubip logic
		// Native and locationlevel pubip on - activated, pubip - 1, in - 1, out
		// - 1
		// Native - deactivated, pubip - 0, in - 0, out - 0
		// portpending - activated, pubip - NA, in - NA, out - NA
		// portpending - deactivated, pubip - 0, in - 0, out - 0
		// ported and locationlevel pubip on - activated, pubip - 1, in - 1, out
		// - 1
		// ported - deactivated, pubip - 0, in - 0, out - 0
		log.info("Entering derivePubipValues");
		long nPubip = -1;
		try {
			if (getLocationId() == null) {
				throw new Exception("Location id not found for" + getLocationId());
			}

			TblLocationQuery locQry = new TblLocationQuery();
			locQry.whereLocationIdEQ(getLocationId());
			locQry.query(connection);
			if (locQry != null && locQry.size() > 0) {
				nPubip = locQry.getDbBean(0).getPubIp();
			}
			log.info("nPubip " + nPubip);
			log.info("tnDbBean.getActDeact()::" + tnDbBean.getActDeact() + "getPortedStatus :: " + getPortedStatus());
			long pubIpValue = 0;
			if (tnDbBean.getActDeact() > 0) {
				if (tnDbBean.getActDeact() == VzbVoipEnum.ActDeact.DEACTIVATED) {
					pubIpValue = VzbVoipEnum.PubIpOnOff.PUB_OFF;
				} else if (tnDbBean.getActDeact() == VzbVoipEnum.ActDeact.ACTIVATED && nPubip == 1) {
					if (getPortedStatus().equals("" + VzbVoipEnum.PortStatus.NATIVE)) {
						pubIpValue = VzbVoipEnum.PubIpOnOff.PUB_ON;
					} else if (getPortedStatus().equals("" + VzbVoipEnum.PortStatus.PORTED)) {
						pubIpValue = VzbVoipEnum.PubIpOnOff.PUB_ON;
					}
				}
			} else {
				log.info("EMEA Region");
				log.info("here :: " + tnDbBean.getTnOnOff());

				log.info("Act/Deact PubIP Rules for EMEA");
				if (getTnStatus() == VzbVoipEnum.TnStatus.AVAILABLE) {
					log.info("TN Status is Available. Set PubIp to OFF");
					pubIpValue = VzbVoipEnum.PubIpOnOff.PUB_OFF;
				} else if (getTnStatus() == VzbVoipEnum.TnStatus.ASSIGNED
						&& (getPortedStatus().equals("" + VzbVoipEnum.PortStatus.PORTED) || getPortedStatus().equals(
								"" + VzbVoipEnum.PortStatus.NATIVE))) {
					log.info("TN Status is Assigned and Ported Status is Native/Ported. Set PubIp to ON");
					// setPubip(VzbVoipEnum.PubIpOnOff.PUB_ON);
					/*
					 * if(nPubip >= 0)
					 * setPubip(VzbVoipEnum.YesNoType.valueByName
					 * (Long.toString(nPubip)));
					 */
					if (nPubip == 1) {
						pubIpValue = VzbVoipEnum.PubIpOnOff.PUB_ON;
					} else {
						pubIpValue = VzbVoipEnum.PubIpOnOff.PUB_OFF;
					}
				} else if (getTnStatus() == VzbVoipEnum.TnStatus.ASSIGNED
						&& getPortedStatus().equals("" + VzbVoipEnum.PortStatus.PORT_PENDING)) {
					log.info("TN Status is Assigned and Ported Status is PortPending. Set PubIp to OFF");
					pubIpValue = VzbVoipEnum.PubIpOnOff.PUB_OFF;
				}

				/*
				 * if(tnDbBean.getTnOnOff() == VzbVoipEnum.OnOffType.OFF){
				 * pubIpValue = 0; }else if(tnDbBean.getTnOnOff() ==
				 * VzbVoipEnum.OnOffType.ON && nPubip == 1){
				 * if(getPortedStatus().equals("" +
				 * VzbVoipEnum.PortStatus.NATIVE)){ pubIpValue = 1; }else
				 * if(getPortedStatus().equals("" +
				 * VzbVoipEnum.PortStatus.PORTED)){ pubIpValue = 1; } }
				 */
			}

			tnDbBean.setPubip(pubIpValue);
			tnDbBean.setPubipIn(pubIpValue);
			tnDbBean.setPubipOut(pubIpValue);
		} catch (Exception e) {
			log.info("Failed to retrieve ActDeact");
			e.printStackTrace();
			return tnDbBean;
		}
		setStatusCode(InvErrorCode.SUCCESS);
		log.info("Successfully retrived pubipvalues");
		return tnDbBean;
	}

	public boolean updateLocForSTN(String locId, int tnPoolId) throws SQLException {
		log.info(" updateLocForSTN api called ");
		PreparedStatement psm = null;
		int rowsUpdated = -1;
		String updateStmt = "UPDATE TBL_LOCATION SET STN_POOL_ID = NULL WHERE STN_POOL_ID = ? AND LOCATION_ID = ?";
		try {
			psm = connection.prepareStatement(updateStmt);
			psm.setLong(1, new Long(tnPoolId));
			psm.setString(2, locId);
			rowsUpdated = psm.executeUpdate();
			if (rowsUpdated >= 0) {
				log.info(rowsUpdated + " updated ");
				return true;
			}

		} catch (SQLException e) {
			e.printStackTrace();
			throw e;
		} finally {
			if (psm != null) {
				psm.close();
			}
		}
		return false;

	}

	public boolean addTerminatingRouting() throws Exception, SQLException {
		log.info("Entering TerminatingRouting::addTerminatingRouting");
		/*
		 * try {
		 */
		if (noa < 0) {
			noa = 1;
			setNoa(1);
		}

		TblPublicTnPoolQuery pnpQry = new TblPublicTnPoolQuery();
		pnpQry.whereTnEQ(getRangeStart());
		pnpQry.query(connection);

		if (pnpQry != null && pnpQry.size() > 0) {
			if (pnpQry.getDbBean(0).getStnInd() == VzbVoipEnum.YesNoType.Y) {
				log.info("TN [" + getRangeStart() + " is a STN");
				TblLocationQuery locQry = new TblLocationQuery();
				locQry.whereLocationIdEQ(pnpQry.getDbBean(0).getLocationId());
				locQry.query(connection);
				if (locQry != null && locQry.size() > 0 && locQry.getDbBean(0).getServiceLevel() == VzbVoipEnum.ServiceLevel.LD_AND_ON_NET) {
					log.info("TN [" + getRangeStart() + " is a STN in LD Only Location. Skip Termrouting");
					return true;
				}
			}
		}

		String addTriEnabledFlag = getConfigParamValue("TRI", "ADD_TRI_ENABLED");// get
																					// it
																					// from
																					// TBL_CONFIG_PARAMS
		boolean triChangesEnabled = "YES".equalsIgnoreCase(addTriEnabledFlag) ? true : false;
		if (triChangesEnabled) {
			// Move below logic to new function which can be invoked from either
			// from here or any Micro service later
			return addTriTnData();
		} else {
			// BAU Logic
			DBTblTerminatingRouting termDbBean = new DBTblTerminatingRouting();
			TblTerminatingRoutingQuery termQry = new TblTerminatingRoutingQuery();
			String whereCls = " where (to_number(\'" + getRangeStart()
					+ "\') between to_number(range_start) and to_number(range_end)) and (to_number(\'" + getRangeEnd()
					+ "\') between to_number(range_start) and to_number(range_end)) and  noa = " + getNoa();
			log.info("whereCls" + whereCls);
			termQry.queryByWhere(connection, whereCls);
			if (termQry.size() > 0) {
				termDbBean.copyFromBean(termQry.getDbBean(0));
				log.info("Term Routing already exists for the Dial Plan Id : " + termDbBean.getDialPlanId());
				setTerminatingRoutingId(termDbBean.getTerminatingRoutingId());
				if (getDialPlanId() == termDbBean.getDialPlanId()) {
					return true;
				} else {
					return false;
				}
			} else {
				int termSeqId = termDbBean.getTerminatingRoutingIdSeqNextVal(connection);
				log.info("Term Routing does not exists");
				termDbBean.setTerminatingRoutingId(termSeqId);
				termDbBean.setDialPlanId(getDialPlanId());
				termDbBean.setNoa(getNoa());
				termDbBean.setRangeStart(getRangeStart());
				if (!"NONE".equals(getRangeEnd()) && !"".equals(getRangeEnd())) {
					termDbBean.setRangeEnd(getRangeEnd());
				}
				if (!"NONE".equals(getP1url()) && !"".equals(getP1url())) {
					termDbBean.setP1url(getP1url());
				}
				if (!"NONE".equals(getPringtime()) && !"".equals(getPringtime())) {
					termDbBean.setPringtime(getPringtime());
				}
				if (!"NONE".equals(getPtrid()) && !"".equals(getPtrid())) {
					termDbBean.setPtrid(getPtrid());
				}
				if (!"NONE".equals(getPprefixdgts()) && !"".equals(getPprefixdgts())) {
					termDbBean.setPprefixdgts(getPprefixdgts());
				}
				if (getPsuffixnum() != -1) {
					termDbBean.setPsuffixnum(getPsuffixnum());
				}
				if (!"NONE".equals(getA1url()) && !"".equals(getA1url())) {
					termDbBean.setA1url(getA1url());
				}
				if (!"NONE".equals(getA1ringtime()) && !"".equals(getA1ringtime())) {
					termDbBean.setA1ringtime(getA1ringtime());
				}
				if (!"NONE".equals(getA1trid()) && !"".equals(getA1trid())) {
					termDbBean.setA1trid(getA1trid());
				}
				if (!"NONE".equals(getA1prefixdgts()) && !"".equals(getA1prefixdgts())) {
					termDbBean.setA1prefixdgts(getA1prefixdgts());
				}
				if (getA1suffixnum() != -1) {
					termDbBean.setA1suffixnum(getA1suffixnum());
				}
				if (!"NONE".equals(getA2url()) && !"".equals(getA2url())) {
					termDbBean.setA2url(getA2url());
				}
				if (!"NONE".equals(getA2ringtime()) && !"".equals(getA2ringtime())) {
					termDbBean.setA2ringtime(getA2ringtime());
				}
				if (!"NONE".equals(getA2trid()) && !"".equals(getA2trid())) {
					termDbBean.setA2trid(getA2trid());
				}
				if (!"NONE".equals(getA2prefixdgts()) && !"".equals(getA2prefixdgts())) {
					termDbBean.setA2prefixdgts(getA2prefixdgts());
				}
				if (getA2suffixnum() != -1) {
					termDbBean.setA2suffixnum(getA2suffixnum());
				}
				if (getEnvOrderId() > 0) {
					termDbBean.setEnvOrderId(getEnvOrderId());
				} else {
					termDbBean.setEnvOrderIdNull();
				}

				if (!getCreatedBy().equals("")) {
					termDbBean.setCreatedBy(getCreatedBy());
				} else {
					termDbBean.setCreatedBy("ESAP_INV");
				}
				if (!getModifiedBy().equals("")) {
					termDbBean.setModifiedBy(getModifiedBy());
				} else {
					termDbBean.setModifiedBy("ESAP_INV");
				}
				termDbBean.setLastModifiedDate(new Timestamp(System.currentTimeMillis()));
				termDbBean.setCreationDate(new Timestamp(System.currentTimeMillis()));
				termDbBean.insert(connection);
			}
		}

		/*
		 * } catch (SQLException s) { s.printStackTrace();
		 * setStatusCode(InvErrorCode.DB_EXCEPTION); return false; }
		 */

		return true;
	}

	public boolean getPublicTnPoolDetailsByTnPoolId() {
		log.info("Entering PublicTnPool::getPublicTnPoolDetailsByTnPoolId");

		try {
			TblPublicTnPoolQuery tnQry = new TblPublicTnPoolQuery();
			initilizeTODefault();
			log.info("Querying publicpooltn for id: " + getTnPoolId());
			tnQry.whereTnPoolIdEQ(getTnPoolId());
			if (getAll == false) {
				tnQry.whereActiveIndEQ(1);
			} else {
				tnQry.whereActiveIndNE(0);
			}

			tnQry.query(connection);
			if (tnQry.size() <= 0) {
				log.info("Tn not Found");
				return false;
			}
			TblPublicTnPoolDbBean tnDbBean = tnQry.getDbBean(0);
			setTnPoolId(tnDbBean.getTnPoolId());
			setLocationId(tnDbBean.getLocationId());
			setDepartmentId(tnDbBean.getDepartmentId());
			setTspCode(tnDbBean.getTspCode()); // Jan 2013 Release - E2EI
			setReplacementCli(tnDbBean.getReplacementCli()); // May 2013 Release
																// -
			setTn(tnDbBean.getTn());
			setEnvOrderId(tnDbBean.getEnvOrderId());
			setTnStatus(tnDbBean.getTnStatus());
			setPortedStatus(tnDbBean.getPortedStatus());
			setNpaSplitStatus(tnDbBean.getNpaSplitStatus());
			setSwitchClli(tnDbBean.getSwitchClli());
			setTrunk(tnDbBean.getTrunk());
			setActiveInd(tnDbBean.getActiveInd());
			setLiInd(tnDbBean.getLiInd());
			setPubip(tnDbBean.getPubip());
			setPubipIn(tnDbBean.getPubipIn());
			setPubipOut(tnDbBean.getPubipOut());
			setCreatedBy(tnDbBean.getCreatedBy());
			setModifiedBy(tnDbBean.getModifiedBy());
			setTnOnOff(tnDbBean.getTnOnOff());
			setStnInd(tnDbBean.getStnInd());
			setPortinType(tnDbBean.getPortinType()); // AUS portin
			setTransitionType(tnDbBean.getTransitionType());
			setPsAli(tnDbBean.getPsAli());
			setVerizonBtn(tnDbBean.getVerizonBtn());
		} catch (SQLException s) {
			s.printStackTrace();
			setStatusCode(InvErrorCode.DB_EXCEPTION);
			return false;
		}

		return true;
	}

	public String getConfigParamValue(String processName, String paramName) throws SQLException {
		String paramValue = "";

		TblConfigParamsQuery paramsQ = new TblConfigParamsQuery();
		if (processName != null)
			paramsQ.whereProcessNameEQ(processName);
		if (paramName != null)
			paramsQ.whereParamNameEQ(paramName);
		paramsQ.query(connection);

		if (paramsQ.size() <= 0) {
			log.info("No Config Entry Found by ProcessName [" + processName + "] and ParamName [" + paramName + "]");
			return paramValue;
		}

		TblConfigParamsDbBean cpBean = paramsQ.getDbBean(0);
		paramValue = cpBean.getParamValue();
		log.info("Successfully Retrieved Param Value [" + paramValue + "]");
		return paramValue;
	}

	public boolean addTriTnData() throws Exception {
		// EsapRestClient client = new EsapRestClient(connection);
		// return client.addTriTnData(this);
		return false;
	}

	public boolean getPublicTnPoolDetailsByTn() {
		log.info("Entering PublicTnPool::getPublicTnPoolDetailsByTnPoolId");

		try {
			TblPublicTnPoolQuery tnQry = new TblPublicTnPoolQuery();
			tnQry.whereTnEQ(getTn());
			if (getAll == false) {
				tnQry.whereActiveIndEQ(1);
			} else {
				tnQry.whereActiveIndNE(0);
			}
			tnQry.query(connection);
			if (tnQry.size() <= 0) {
				setStatusCode(InvErrorCode.NOTFOUND_TN);
				return false;
			}
			TblPublicTnPoolDbBean tnDbBean = tnQry.getDbBean(0);
			setTnPoolId(tnDbBean.getTnPoolId());
			setLocationId(tnDbBean.getLocationId());
			setDepartmentId(tnDbBean.getDepartmentId());
			setTspCode(tnDbBean.getTspCode()); // Jan 2013 Release - E2EI
			setReplacementCli(tnDbBean.getReplacementCli()); // May 2013 Release
																// -
			setTn(tnDbBean.getTn());
			setEnvOrderId(tnDbBean.getEnvOrderId());
			setTnStatus(tnDbBean.getTnStatus());
			setPortedStatus(tnDbBean.getPortedStatus());
			setNpaSplitStatus(tnDbBean.getNpaSplitStatus());
			setSwitchClli(tnDbBean.getSwitchClli());
			setTrunk(tnDbBean.getTrunk());
			setActiveInd(tnDbBean.getActiveInd());
			setCreatedBy(tnDbBean.getCreatedBy());
			setModifiedBy(tnDbBean.getModifiedBy());
			setStnInd(tnDbBean.getStnInd());
			setLiInd(tnDbBean.getLiInd());
			setPortinType(tnDbBean.getPortinType()); // AUS portin
			setTransitionType(tnDbBean.getTransitionType());
			setPsAli(tnDbBean.getPsAli());
			setVerizonBtn(tnDbBean.getVerizonBtn());
		} catch (SQLException s) {
			s.printStackTrace();
			setStatusCode(InvErrorCode.DB_EXCEPTION);
			return false;
		}

		return true;
	}

	public boolean addPublicTnPool() throws SQLException, Exception {
		log.info("Entering PublicTnPool::addPublicTnPool");
		DBTblPublicTnPool tnDbBean = new DBTblPublicTnPool();
		try {
			if (getBsTnActivation() != true) {
				log.info("Failed to Retrieve BSTnAct");
				return false;
			}
			TblPublicTnPoolQuery tnPoolQry = new TblPublicTnPoolQuery();
			String whereCls = " where tn =\'" + getTn() + "\'";
			log.info("whereCls:" + whereCls);
			tnPoolQry.queryByWhere(connection, whereCls);
			if (tnPoolQry.size() > 0) {
				tnDbBean.copyFromBean(tnPoolQry.getDbBean(0));
				setTnPoolId(tnDbBean.getTnPoolId());
				log.info(" getLocationId() " + getLocationId());
				if (tnDbBean.getLocationId().equals(getLocationId())) {
					// Do NOT Update the status if the tn is part of VmAccess
					TblVmAccessQuery vmAccessQry = new TblVmAccessQuery();
					vmAccessQry.wherePublicPoolIdEQ(getTnPoolId());
					vmAccessQry.query(connection);
					if (vmAccessQry.size() <= 0) {
						tnDbBean.setTnStatus(getTnStatus());
						if (getTnStatus() == VzbVoipEnum.TnStatus.AVAILABLE) {
							tnDbBean.setTnType(VzbVoipEnum.TnType.RES);
						}
						if (getTnType() > 0) {
							tnDbBean.setTnType(getTnType());
						}
					}
					log.info("getPortedStatus  is " + getPortedStatus());
					if ((getPortedStatus().equals("" + VzbVoipEnum.PortStatus.PORTED) && tnDbBean.getPortedStatus().equals(
							"" + VzbVoipEnum.PortStatus.PORT_PENDING))
							|| (getPortedStatus().equals("" + VzbVoipEnum.PortStatus.PORT_PENDING) && tnDbBean.getPortedStatus().equals(
									"" + VzbVoipEnum.PortStatus.NATIVE))
							|| (getPortedStatus().equals("" + VzbVoipEnum.PortStatus.NATIVE) && tnDbBean.getPortedStatus().equals(
									"" + VzbVoipEnum.PortStatus.PORT_PENDING))) {
						tnDbBean.setPortedStatus(getPortedStatus());
					}

					// AUS portin type - needs review
					if (getPortinType() != 0) {
						tnDbBean.setPortinType(getPortinType());
						if (getPortinType() == 3 && getPortedStatus().equals("" + VzbVoipEnum.PortStatus.PORTED)) // WINBACK
						{
							tnDbBean.setPortedStatus("0"); // NATIVE
						}
					}

					if (getModifiedBy() != null && !getModifiedBy().equalsIgnoreCase("")) {
						tnDbBean.setModifiedBy(getModifiedBy());
					} else {
						tnDbBean.setModifiedBy("ESAP_INV");
					}
					tnDbBean.setLastModifiedDate(new Timestamp(System.currentTimeMillis()));

					if (getEnvOrderId() != -1 && getEnvOrderId() > 0) {
						tnDbBean.setEnvOrderId(getEnvOrderId());
					}

					if ((getPortedStatus().equals("" + VzbVoipEnum.PortStatus.PORTED) && tnDbBean.getPortedStatus().equals(
							"" + VzbVoipEnum.PortStatus.PORT_PENDING))) {
						tnDbBean.setTnOnOff(1);
					}

					// STN Code here
					log.info("Getting record from DB - getStnInd() in PNP Class " + getStnInd());
					if (getStnInd() > 0) {
						tnDbBean.setStnInd(getStnInd());
					}

					tnDbBean.whereTnPoolIdEQ(tnDbBean.getTnPoolId());
					FkValidationUtil.isValidPublicTNPoolForMod(connection, tnDbBean);
					// long oldPubip = getPubip();
					long oldActDeact = getActDeact();
					if (deriveActDeact() != true) {
						log.info("Failed to Derive Act Deact");
						return false;
					}
					/*
					 * if (oldPubip > -1) { tnDbBean.setPubip(oldPubip); } else
					 * if (getPubip() > -1) { tnDbBean.setPubip(getPubip()); }
					 */
					if (oldActDeact > 0) {
						tnDbBean.setActDeact((short) oldActDeact);
					} else if (getActDeact() > 0) {
						tnDbBean.setActDeact((short) getActDeact());
					}

					log.info("TN Type [" + tnDbBean.getTnType() + "]");
					// VMA Tn's are never configured in Broadsoft and hence are
					// not candidates for Deactivation or Activation either from
					// ESAP GUI or CSSOP . ESAP GUI will not display VMA TN as a
					// candidate for Activation/Deactivation
					if (tnDbBean.getActDeact() <= 0 || tnDbBean.getTnType() == 2) {
						tnDbBean.setActDeactNull();
					}

					// /VOV 2015 changes here
					tnDbBean = derivePubipValues(tnDbBean);

					// Jan 2013 Release - E2EI
					if (getTspCode() != null && !getTspCode().equalsIgnoreCase("")) {
						tnDbBean.setTspCode(getTspCode());
					}

					if (getReplacementCli() != null && !getReplacementCli().equalsIgnoreCase("")) {
						tnDbBean.setReplacementCli(getReplacementCli());
					}

					if (getTransitionType() != -1 && getTransitionType() > 0) {
						tnDbBean.setTransitionType(getTransitionType());
					}
					if (getPsAli() != null && getPsAli().trim().length() > 0) {
						tnDbBean.setPsAli(getPsAli());
					} else {
						tnDbBean.setPsAli("N");
					}
					if (getVerizonBtn() != null && !getVerizonBtn().equalsIgnoreCase("")) {
						tnDbBean.setVerizonBtn(getVerizonBtn());
					}
					tnDbBean.updateSpByWhere(connection);
					log.info("Tn already exists for same location updating the tn and port status");

					// APAC LNP sep 2011 rel
					if (getTnPorting() != null && !(getPortedStatus().equals("" + VzbVoipEnum.PortStatus.NATIVE))) {
						TnPorting tnPortingObj = getTnPorting();
						// As Tn is already present in publicTnPool, need to
						// update the required info.
						tnPortingObj.setTnPoolId(getTnPoolId());
						tnPortingObj.updateTnPorting();
						log.info("TnPortingInfo is updated successfully for tnPoolId : " + getTnPoolId());
					} else {
						log.info("getTnPorting() is null.");
					}
				} else {
					log.info("Tn already exists for different location" + tnDbBean.getLocationId());
					return false;
				}
			} else {
				log.info("Tn does not exist, inserting new row");
				int tnPoolSeqId = tnDbBean.getTnPoolIdSeqNextVal(connection);
				tnDbBean.setTnPoolId(tnPoolSeqId);
				setTnPoolId(tnDbBean.getTnPoolId());
				log.info(" getLocationId() " + getLocationId());
				tnDbBean.setLocationId(getLocationId());
				if (!getDepartmentId().equals("") && !getDepartmentId().equals("NONE")) {
					tnDbBean.setDepartmentId(getDepartmentId());
				}

				// Jan 2013 Release - E2EI
				if (!getTspCode().equals("") && !getTspCode().equals("NONE")) {
					tnDbBean.setTspCode(getTspCode());
				}

				if (!getReplacementCli().equals("") && !getReplacementCli().equals("NONE")) {
					tnDbBean.setReplacementCli(getReplacementCli());
				}

				tnDbBean.setTn(getTn());
				tnDbBean.setTnStatus(getTnStatus());
				if (getTnStatus() != -1) {
					if (getTnStatus() == VzbVoipEnum.TnStatus.AVAILABLE) {
						tnDbBean.setTnType(VzbVoipEnum.TnType.RES);
					}
					if (getTnType() > 0) {
						tnDbBean.setTnType(getTnType());
					}
				}
				if (!"NONE".equals(getPortedStatus()) && !"".equals(getPortedStatus())) {
					tnDbBean.setPortedStatus(getPortedStatus());
				}
				if (getNpaSplitStatus() != -1) {
					tnDbBean.setNpaSplitStatus(getNpaSplitStatus());
				}
				if (!"NONE".equals(getSwitchClli()) && !"".equals(getSwitchClli())) {
					tnDbBean.setSwitchClli(getSwitchClli());
				}
				if (!"NONE".equals(getTrunk()) && !"".equals(getTrunk())) {
					tnDbBean.setTrunk(getTrunk());
				}
				if (getActiveInd() != -1) {
					tnDbBean.setActiveInd(getActiveInd());
				} else {
					tnDbBean.setActiveInd(1);
				}
				// make it default value is off for port pending
				if (getTnOnOff() != -1) {
					if (getPortedStatus().equals("" + VzbVoipEnum.PortStatus.PORT_PENDING)) {
						tnDbBean.setTnOnOff(0);
					} else {
						tnDbBean.setTnOnOff(getTnOnOff());
					}
				} else {
					if (getPortedStatus().equals("" + VzbVoipEnum.PortStatus.PORT_PENDING)) {
						tnDbBean.setTnOnOff(0);
					} else {
						tnDbBean.setTnOnOff(1);
					}
				}
				log.info("EnvOrderId = <" + getEnvOrderId() + ">");
				if (getEnvOrderId() != -1 && getEnvOrderId() > 0) {
					tnDbBean.setEnvOrderId(getEnvOrderId());
				}

				log.info("EnvOrderId = <" + tnDbBean.getEnvOrderId() + ">");

				if (getCreatedBy() != null && !getCreatedBy().equalsIgnoreCase("")) {
					tnDbBean.setCreatedBy(getCreatedBy());
				} else {
					tnDbBean.setCreatedBy("ESAP_INV");
				}

				if (getModifiedBy() != null && !getModifiedBy().equalsIgnoreCase("")) {
					tnDbBean.setModifiedBy(getModifiedBy());
				} else {
					tnDbBean.setModifiedBy("ESAP_INV");
				}

				// STN Code here
				log.info("creating new record getStnInd() in PNP Class " + getStnInd());
				if (getStnInd() > 0) {
					tnDbBean.setStnInd(getStnInd());

				}// IR #1413315. PublicTnPoolbean class is not intialized when
					// calling Actionfunctions. So initializing 0 here.
				else {
					tnDbBean.setStnInd(VzbVoipEnum.YesNoType.N);
				}

				if (getLiInd() > 0) {
					tnDbBean.setLiInd((short) getLiInd());
				}

				if (getPubip() > 0) {
					tnDbBean.setPubip(getPubip());
				}

				if (getTransitionType() != -1 && getTransitionType() > 0) {
					tnDbBean.setTransitionType(getTransitionType());
				}
				if (getPsAli() != null && getPsAli().trim().length() > 0) {
					tnDbBean.setPsAli(getPsAli());
				} else {
					tnDbBean.setPsAli("N");
				}
				if (!getVerizonBtn().equals("") && !getVerizonBtn().equals("NONE")) {
					tnDbBean.setVerizonBtn(getVerizonBtn());
				}
				tnDbBean.setCreationDate(new Timestamp(System.currentTimeMillis()));
				tnDbBean.setLastModifiedDate(new Timestamp(System.currentTimeMillis()));
				FkValidationUtil.isValidPublicTNPool(connection, tnDbBean);
				long oldPubip = getPubip();
				long oldActDeact = getActDeact();
				if (deriveActDeact() != true) {
					log.info("Failed to Derive Act Deact");
					return false;
				}
				/*
				 * if (oldPubip > -1) { tnDbBean.setPubip(oldPubip); } else if
				 * (getPubip() > -1) { tnDbBean.setPubip(getPubip()); }
				 */

				log.info("TN Type [" + tnDbBean.getTnType() + "]");
				// VMA Tn's are never configured in Broadsoft and hence are not
				// candidates for Deactivation or Activation either from ESAP
				// GUI or CSSOP . ESAP GUI will not display VMA TN as a
				// candidate for Activation/Deactivation
				if (getTnType() != 2) {
					if (oldActDeact > 0) {
						tnDbBean.setActDeact((short) oldActDeact);
					} else if (getActDeact() > 0) {
						tnDbBean.setActDeact((short) getActDeact());
					}
				}

				// AUS portin type - needs review
				if (getPortinType() != 0) {
					tnDbBean.setPortinType(getPortinType());
					if (getPortinType() == 3 && getPortedStatus().equals("" + VzbVoipEnum.PortStatus.PORTED)) // WINBACK
					{
						tnDbBean.setPortedStatus("0"); // NATIVE
					}
				}

				// VOV 2015 changes here
				tnDbBean = derivePubipValues(tnDbBean);

				tnDbBean.insert(connection);

				// APAC LNP sep 2011 rel
				if (getTnPorting() != null && !(getPortedStatus().equals("" + VzbVoipEnum.PortStatus.NATIVE))) {
					TnPorting tnPortingObj = getTnPorting();
					// the newly inserted record's pool id is set, so need to
					// get that
					tnPortingObj.setTnPoolId(getTnPoolId());
					tnPortingObj.addTnPorting();
					log.info("TnPortingInfo is added successfully. Added pool id is :" + getTnPoolId());
				} else {
					log.info("getTnPorting() is null.");
				}
			}
		} catch (SQLException s) {
			// Query the PNP again and check if STN is already there, if its
			// unique constraint.
			// IR #1409101 ERROR_CODE : ESP_VZB_INV_ADD_RESERVED_TN_FAILED
			// ERROR_DESC : ORA-00001: unique constraint
			// (ESAP.IDX_PUBLIC_TN_POOL_1) violated

			log.info(" SQL Exception message " + s.getMessage());
			if (s.getMessage().contains("unique constraint")) {

				log.info(" Unique Constraint Violation ...Querying the TblPublicTn to check TN again " + getTn());

				TblPublicTnPoolQuery tnPoolQryAgain = new TblPublicTnPoolQuery();
				String whereCls = " where tn =\'" + getTn() + "\'";
				log.info("whereCls:" + whereCls);
				tnPoolQryAgain.queryByWhere(connection, whereCls);

				if (tnPoolQryAgain.size() > 0) {
					log.info(" Checking Whether its STN from DB :: " + tnPoolQryAgain.getDbBean(0).getStnInd());
					log.info(" STN Input ::  " + getStnInd());
					/*
					 * if ( tnPoolQryAgain.getDbBean(0).getStnInd() > 0 ){
					 * log.info(" Updating the PublicTnPool");
					 * updatePublicTnPool(); return true; }
					 */

					// Checking the input is STN.
					if (getStnInd() == VzbVoipEnum.YesNoType.Y) {
						log.info(" Input TN is STN ");
						tnDbBean.setTnPoolId(tnPoolQryAgain.getDbBean(0).getTnPoolId());
						tnDbBean.setStnInd(getStnInd());
						tnDbBean.whereTnPoolIdEQ(tnPoolQryAgain.getDbBean(0).getTnPoolId());
						tnDbBean.updateSpByWhere(connection);
						log.info(" Updating the PublicTnPool Successfull");
						return true;
					}

					// Checking the DB VALUE is STN. No need to update
					if (tnPoolQryAgain.getDbBean(0).getStnInd() == VzbVoipEnum.YesNoType.Y) {
						log.info(" Existing TN is STN. So no need to update");
						log.info(" Updating the PublicTnPool");
						return true;
					}

				}
			}

			log.info(" Not Unique Constraint Violation Exception..Rethrowing");

			s.printStackTrace();
			setStatusCode(InvErrorCode.DB_EXCEPTION);
			throw s;
			// return false;
		}

		return true;
	}

	public boolean isTnDeletable() {
		try {
			log.info("getTnPoolId()====>" + getTnPoolId());
			log.info("getTn()====>" + getTn());
			if (getTnPoolId() <= 0) {
				if (getTn().equals("")) {
					setStatusCode(InvErrorCode.INVALID_INPUT);
					return false;
				} else {
					int pubTnId = getTnPoolIdByTn(getTn());
					log.info("pubTnId()====>" + pubTnId);
					if (pubTnId > 0) {
						setTnPoolId(pubTnId);
					} else {
						setStatusCode(InvErrorCode.INVALID_INPUT);
						return false;
					}
				}
			}
			TblLocationQuery locQry = new TblLocationQuery();
			String whereCls = " where emer_pool_id = " + getTnPoolId() + " or btn_pool_id = " + getTnPoolId() + " or rpid_pool_id = "
					+ getTnPoolId();
			log.info("whereCls in isTnDeletable:" + whereCls);
			locQry.queryByWhere(connection, whereCls);
			if (locQry.size() > 0) {
				log.info("Tn is being used as RpidTn/EmerTn/Btn.");
				setStatusCode(InvErrorCode.TN_IS_IN_USE);
				return false;
			}
		} catch (SQLException s) {
			s.printStackTrace();
			setStatusCode(InvErrorCode.DB_EXCEPTION);
			log.info("DB_FAILURE in deleteFromDB publicTnPool");
			return false;
		}
		setStatusCode(InvErrorCode.SUCCESS);
		return true;

	}

	public int getTnPoolIdByTn(String tn) {
		log.info("Entering Location::getTnPoolIdByTn");
		log.info("!! Tn " + tn);
		log.info("!! AFter printing");
		int tnPoolId = 0;
		try {
			TblPublicTnPoolQuery tnQry = new TblPublicTnPoolQuery();
			tnQry.whereTnEQ(tn);
			tnQry.query(connection);
			if (tnQry.size() <= 0) {
				log.info("TN [" + tn + "] Not Found");
				return tnPoolId;
			}
			tnPoolId = tnQry.getDbBean(0).getTnPoolId();
			log.info("Retrieved TN Id [" + tnPoolId + "] For Tn [" + tn + "]");
		} catch (SQLException e) {
			setStatusCode(InvErrorCode.DB_EXCEPTION);
			log.info("Failed to retrieve TN Id");
			e.printStackTrace();
			return tnPoolId;
		}
		setStatusCode(InvErrorCode.SUCCESS);
		log.info("Successfully retrived TN Id");
		return tnPoolId;
	}

	/**
	 * @Param deletePublicTnPool
	 * @description: Deletes the Public tn pool from DB
	 * @return boolean
	 * @author Thejas
	 * @editedby
	 */
	public boolean deletePublicTnPool() throws SQLException, Exception {
		// try
		// {
		log.info("getTnPoolId()====>" + getTnPoolId());
		log.info("getTn()====>" + getTn());
		if (getTnPoolId() <= 0) {
			if (getTn().equals("")) {
				setStatusCode(InvErrorCode.INVALID_INPUT);
				return false;
			} else {
				int pubTnId = getTnPoolIdByTn(getTn());
				log.info("pubTnId()====>" + pubTnId);
				if (pubTnId > 0) {
					setTnPoolId(pubTnId);
				} else {
					setStatusCode(InvErrorCode.INVALID_INPUT);
					return false;
				}
			}
		}
		// Prodn fix, INV action function is failing to rollback ADD LOC order
		// with STN
		// IR #1440267 , checking PNP is STN
		// If stn_ind = 1, then set stn_pool_id=null in
		// tbl_location/tbl_gateway_device_info
		// If PNP is STN, get the location/device by using tnpoolid and assign
		// stnpoolid to null in device/location table.
		// This has to be done otherwise it will throw Referential integrity
		// constraint when we delete pnp

		log.info(" TnPoolid " + getTnPoolId());

		TblPublicTnPoolQuery tblPublicTnPoolQuery = new TblPublicTnPoolQuery();
		tblPublicTnPoolQuery.whereTnPoolIdEQ(getTnPoolId());
		tblPublicTnPoolQuery.query(connection);

		TblLocationDbBean tblLocationDbBeanObj = null;
		TblLocationDbBean tblLocationDbBeanObj2 = null;

		 boolean publicTnPoolFoundForTnPoolId = false;
		if (tblPublicTnPoolQuery.size() > 0) {
			publicTnPoolFoundForTnPoolId= true;
			TblLocationQuery tblLocationQuery = new TblLocationQuery();
			tblLocationQuery.whereLocationIdEQ(tblPublicTnPoolQuery.getDbBean(0).getLocationId());
			tblLocationQuery.query(connection);

			if (tblLocationQuery.size() > 0) {
				// APAC LNP sep2011
				tblLocationDbBeanObj2 = (TblLocationDbBean) tblLocationQuery.getDbBean(0);
			} else {
				log.info("Unable to find record for locationId : " + tblPublicTnPoolQuery.getDbBean(0).getLocationId());
			}

			if (tblPublicTnPoolQuery.getDbBean(0).getStnInd() > 0) {

				tblLocationQuery = new TblLocationQuery();
				tblLocationQuery.whereStnPoolIdEQ(getTnPoolId());
				tblLocationQuery.query(connection);

				if (tblLocationQuery.size() > 0) {

					tblLocationDbBeanObj = (TblLocationDbBean) tblLocationQuery.getDbBean(0);

					String locId = tblLocationQuery.getDbBean(0).getLocationId();
					log.info(" TN " + getTn() + " is STN at Location :: " + locId);
					DBTblLocation tblLocation = new DBTblLocation();
					tblLocation.setStnPoolIdNull();
					tblLocation.whereLocationIdEQ(locId);
					int locationRecCountUpdated = tblLocation.updateSpByWhere(connection);
					log.info("Successfully Location Updated STNPOOLID to NULL " + locationRecCountUpdated);
				} else {
					log.info(" TN " + getTn() + " is not STN at Location level.");

					TblGatewayDeviceInfoQuery tblDevInfoQuery = new TblGatewayDeviceInfoQuery();
					tblDevInfoQuery.whereStnPoolIdEQ(getTnPoolId());
					tblDevInfoQuery.query(connection);

					if (tblDevInfoQuery.size() > 0) {
						long gwydevId = tblDevInfoQuery.getDbBean(0).getGatewayDeviceId();
						log.info(" TN " + getTn() + " is STN at Device :: " + gwydevId);
						DBTblGatewayDeviceInfo tblGatewayDeviceInfo = new DBTblGatewayDeviceInfo();
						tblGatewayDeviceInfo.setStnPoolIdNull();
						tblGatewayDeviceInfo.whereGatewayDeviceIdEQ(gwydevId);
						int gatewayDeviceInfoRecCountUpdated = tblGatewayDeviceInfo.updateSpByWhere(connection);
						// setLogTrail("Successfully GatewayDevice Updated STNPOOLID to NULL"
						// + gatewayDeviceInfoRecCountUpdated);
						log.info("Successfully Device Updated STNPOOLID to NULL " + gatewayDeviceInfoRecCountUpdated);
					} else {
						log.info(" TN " + getTn() + " is not STN at Device level.");
					}
				}
			}
		}

		if (tblLocationDbBeanObj2 != null) {
			log.info(" deletePublicTnPool *** update TBL_LOCATION STN ");

			updateLocForSTN(tblLocationDbBeanObj2.getLocationId(), getTnPoolId());
		}

		// APAC LNP sep2011
		if (tblLocationDbBeanObj2 != null) {
			String locCountryInfo = tblLocationDbBeanObj2.getLocCountry();
			if (locCountryInfo.equals("AU") || locCountryInfo.equals("HK") || locCountryInfo.equals("SG")) {
				TnPorting tnPortingObj = new TnPorting(connection);
				tnPortingObj.setTnPoolId(getTnPoolId());
				setTnPorting(tnPortingObj);
				log.info("Going to delete TnPortingInfo  for tn pool id :" + getTnPoolId());
				tnPortingObj.deleteTnPorting();
				log.info("TnPortingInfo deleted for : " + getTnPoolId());
			}
		} else {
			log.info("tblLocationDbBeanObj2() is null.");
		}

		if(publicTnPoolFoundForTnPoolId){
	    	  log.info("Deleting record from TSO ET TN table for TN Pool ID:"+getTnPoolId());
	          DBTblTsoEtTn etTnDbBean = new DBTblTsoEtTn();
	          etTnDbBean.whereTnPoolIdEQ(getTnPoolId());
	          int deletedRecordCount = etTnDbBean.deleteByWhere(connection);
	          log.info("Record deleted from TSO ET TN table for TN Pool ID:"+getTnPoolId()+". Deleted Records count :"+deletedRecordCount);
	          
	    	  DBTblPublicTnPool publicTnPoolDbBean = new DBTblPublicTnPool();
		      log.info("Deleting TN Pool ID from TBL_PUBLIC_TN_POOL :TN Pool ID :" + getTnPoolId());
		      publicTnPoolDbBean.whereTnPoolIdEQ(getTnPoolId());
		      int pubTnPoolDeleted = publicTnPoolDbBean.deleteByWhere(connection);
		      log.info("Deleting TN Pool ID from TBL_PUBLIC_TN_POOL :" + pubTnPoolDeleted+" for TN Pool ID:"+getTnPoolId());
		      
		      /*long envOrderId= getEnvOrderId();//orderParam.getByNameSearch("EnvOrderId") != null ?orderParam.getByNameSearch("EnvOrderId").getParamValue():"0";
		      log.info("Inserting records in TBL_TN_DELETE_TRACKING :Tn Pool ID : " + getTnPoolId()+" For envelop order id :"+envOrderId + " Batch Range :"+getBatchRange());
		      insertTnDeleteTrackingRecord(connection,envOrderId,getTnPoolId(),getBatchRange(),getTn());*/
	      }
		setStatusCode(InvErrorCode.SUCCESS);
		return true;
	}

	public boolean deleteTriTnData() throws Exception {
		EsapRestClient client = new EsapRestClient(connection);
		return client.deleteTriTnData(this);

	}

	public boolean isPublicTNPoolTiedToTblGroupTN() {
		try {
			// check if the department is associated to a TN Group (PBX/Key)
			TblGroupTnQuery qry = new TblGroupTnQuery();
			String whereClause = " where tn_pool_id = " + getTnPoolId();
			qry.queryByWhere(connection, whereClause);
			if (qry.size() <= 0) {
				log.info("TN Pool Id [" + getTnPoolId() + "] not found in tbl_group_tn");
			} else {
				log.info("TN Pool Id [" + getTnPoolId() + "] found in tbl_group_tn");
				return true;
			}
		} catch (SQLException s) {
			setStatusCode(InvErrorCode.DB_EXCEPTION);
			log.error("DB_FAILURE in isPublicTNPoolTiedToTblGroupTN");
			s.printStackTrace();
			return false;
		}
		return false;
	}
	
	/**************************Adding by Praveen****************************/
	public boolean updatePubIpbyLocation(long viper, String locid) {
	    try {
	    	
	    	
	    	log.info(" PublicTnPool : Inside updatePubIpbyLocation method ");
	       String whereCls = null;
	       if (viper == -1) {
	          //Fetch the location object if Viper is not available
	          TblLocationQuery locQry = new TblLocationQuery();
	          locQry.whereLocationIdEQ(locid);
	          locQry.query(connection);
	          if (locQry != null && locQry.size() > 0) {
	             viper = locQry.getDbBean(0).getVoipClub();
	          }
	       }
	       log.info(" PublicTnPool : Inside updatePubIpbyLocation method  :" , viper);
	
	       TblPublicTnPoolQuery tnPoolQry = new TblPublicTnPoolQuery();
	       if (viper == 1) {
	          whereCls = " where location_id = '" + locid + "' and (act_deact = 2 OR act_deact is null OR act_deact = 0) "
	                  + " and ported_status !=1 and TN_STATUS=1 ";
	       } else if (viper == 0) {
	          whereCls = " where location_id = '" + locid + "' and (act_deact = 2 OR act_deact is null OR act_deact = 0) ";
	       }
	
	       tnPoolQry.queryByWhere(connection, whereCls);
	       if (tnPoolQry.size() > 0) {
	          for (int i = 0; i < tnPoolQry.size(); i++) {
	             DBTblPublicTnPool tnDbBean = new DBTblPublicTnPool();
	             tnDbBean.copyFromBean(tnPoolQry.getDbBean(i));
	             tnDbBean.setModifiedBy("ESAP_INV");
	             tnDbBean.setPubip(viper);
	             tnDbBean.setPubipIn(viper);
	             tnDbBean.setPubipOut(viper);
	             tnDbBean.setLastModifiedDate(new Timestamp(System.currentTimeMillis()));
	             tnDbBean.whereLocationIdEQ(locid);
	             tnDbBean.whereTnEQ(tnPoolQry.getDbBean(i).getTn());
	             tnDbBean.updateSpByWhere(connection);
	          }
	       }
	    } catch (SQLException s) {
	    	log.error(" PublicTnPool : Inside updatePubIpbyLocation method(): SQLException  ",s.getMessage());
	       return false;
	    }
	    return true;
	 }
		//

	public void setBatchRange(String batchRange) {
		// TODO Auto-generated method stub

	}
}// EOF