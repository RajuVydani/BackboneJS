package com.vz.fxo.inventory.actionfunction.support;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import esap.db.DBTblTsoEnterpriseTrunk;
import esap.db.DBTblTsoEtTgMap;
import esap.db.TblTsoEnterpriseTrunkQuery;
import esap.db.TblTsoEtTnQuery;

public class TsoEnterpriseTrunk extends TsoEnterpriseTrunkBean{
	
	private static Logger log = LoggerFactory.getLogger(TsoEnterpriseTrunk.class.toString());
	
	private InvErrorCode status;
    Connection dbCon;
    String statusDesc;
	boolean rollbackFlag;
	/**
	 * @return the rollbackFlag
	 */
	public boolean isRollbackFlag() {
		return rollbackFlag;
	}

	/**
	 * @param rollbackFlag the rollbackFlag to set
	 */
	public void setRollbackFlag(boolean rollbackFlag) {
		this.rollbackFlag = rollbackFlag;
	}
	boolean migration;
	boolean shellMigration;
	// Constructor
	public TsoEnterpriseTrunk(Connection connection) {
		super();
		this.dbCon = connection;
		this.rollbackFlag = false;                                                                       
		this.migration = false;                                                                       
		this.shellMigration = false;
	}
	
    public String getStatusDesc() {
		return statusDesc;
	}
	public void setStatusDesc(String statusDesc) {
		this.statusDesc = statusDesc;
	}
	/*public TsoEnterpriseTrunk(Connection dbCon){
        this.dbCon = dbCon;
	 }*/
    public TsoEnterpriseTrunk(TsoEnterpriseTrunkBean tsoEnterpriseTrunkBean, Connection dbCon){
        super(tsoEnterpriseTrunkBean);
        this.dbCon = dbCon;
    }
	public InvErrorCode getStatus() {
		return status;
	}
	public void setStatus(InvErrorCode status) {
		this.status = status;
	}
	public Connection getDbCon() {
		return dbCon;
	}
	public void setDbCon(Connection dbCon) {
		this.dbCon = dbCon;
	}
    
	public boolean addToDB() throws SQLException,Exception{
		
		
		setLogTrail("Calling addToDB.");
		DBTblTsoEnterpriseTrunk  tsoEnterpriseTrunkDbBean=new DBTblTsoEnterpriseTrunk();
			    
		tsoEnterpriseTrunkDbBean.setEnterpriseTrunkId(enterpriseTrunkId);
		tsoEnterpriseTrunkDbBean.setEnterpriseTrunkName(enterpriseTrunkName);
		tsoEnterpriseTrunkDbBean.setEnterpriseId(enterpriseId);
		tsoEnterpriseTrunkDbBean.setMaxRerouteAttempts(maxRerouteAttempts);
		tsoEnterpriseTrunkDbBean.setMaxRerouteAttemptsPriority(maxRerouteAttemptsPriority);
		tsoEnterpriseTrunkDbBean.setRouteExhaustActivated(routeExhaustActivated);
		tsoEnterpriseTrunkDbBean.setRouteExhaustAction(routeExhaustAction);
		if (  !"NONE".equals(getRouteExhaustFwdTn())){
			tsoEnterpriseTrunkDbBean.setRouteExhaustFwdTn(routeExhaustFwdTn);
		}
		
		if (createdBy != null && !createdBy.trim().equals(""))
			tsoEnterpriseTrunkDbBean.setCreatedBy(createdBy);
		else
			tsoEnterpriseTrunkDbBean.setCreatedBy("ESAP_INV");
		
		if (modifiedBy != null && !modifiedBy.trim().equals(""))
			tsoEnterpriseTrunkDbBean.setModifiedBy(modifiedBy);
		else
			tsoEnterpriseTrunkDbBean.setModifiedBy("ESAP_INV");
		
		tsoEnterpriseTrunkDbBean.setCreationDate(new Timestamp(System.currentTimeMillis()));
		tsoEnterpriseTrunkDbBean.setLastModifiedDate(new Timestamp(System.currentTimeMillis()));
		printEntTrunkDbObj(tsoEnterpriseTrunkDbBean);	
		tsoEnterpriseTrunkDbBean.insert(dbCon);
		setLogTrail("Enterprise Record added to DB.");
		return true;
	}
	
	public void printEntTrunkDbObj(DBTblTsoEnterpriseTrunk entTrunkDbObj) {
		StringBuffer buffer = new StringBuffer();
		buffer.append("EnterpriseTrunkId=").append(entTrunkDbObj.getEnterpriseTrunkId())
		.append("\n");
		buffer.append("EnterpriseId=").append(entTrunkDbObj.getEnterpriseId())
				.append("\n");
		buffer.append("EnterpriseTrunkName=").append(entTrunkDbObj.getEnterpriseTrunkName())
		.append("\n");
		buffer.append("MaxRerouteAttempts=").append(entTrunkDbObj.getMaxRerouteAttempts())
		.append("\n");
		buffer.append("MaxRerouteAttemptsPriority=").append(entTrunkDbObj.getMaxRerouteAttemptsPriority())
		.append("\n");
		buffer.append("RouteExhaustActivated=").append(entTrunkDbObj.getRouteExhaustActivated())
		.append("\n");
		buffer.append("RouteExhaustAction=").append(entTrunkDbObj.getRouteExhaustAction())
		.append("\n");
		buffer.append("RouteExhaustFwdTn=").append(entTrunkDbObj.getRouteExhaustFwdTn())
		.append("\n");
		buffer.append("CreatedBy=").append(entTrunkDbObj.getCreatedBy())
		.append("\n");
		buffer.append("CreationDate=").append(entTrunkDbObj.getCreationDate())
		.append("\n");
		buffer.append("ModifiedBy=").append(entTrunkDbObj.getModifiedBy())
		.append("\n");
		buffer.append("LastModifiedDate=").append(entTrunkDbObj.getLastModifiedDate())
		.append("\n");		
      log.info(buffer.toString());
	}
	
	 public boolean modifyInDB() throws SQLException, Exception {
		
	           if (enterpriseTrunkId == 0)
	            {
	                log.info("FAILURE in modifyInDB enterpriseTrunk. enterpriseTrunk Id missing.");
	                return false;
	            }
	            DBTblTsoEnterpriseTrunk tsoEnterpriseTrunkDbBean = getTsoEnterpriseTrunkToUpdate();
	            log.info("Got enterpriseTrunk Details to Update for enterpriseTrunkId:" + enterpriseTrunkId);
	            tsoEnterpriseTrunkDbBean.whereEnterpriseTrunkIdEQ(enterpriseTrunkId);
	            log.info("Going to Update TsoenterpriseTrunk in DB");
	            //FkValidationUtil.isValidLocationForMod(dbCon,tsoEnterpriseDbBean);
	            
	            if ( tsoEnterpriseTrunkDbBean.updateSpByWhere(dbCon) <= 0 ) {
	            	log.info("No TsoEnterpriseTrunk updated");
	            	return false;
	            }
	            log.info("Successfully updated TsoEnterpriseTrunk");
	            setStatus(InvErrorCode.SUCCESS);
	            log.info("Successfully UPDATED TsoEnterpriseTrunk into the DB");
	        return true;
	 }
	        
	  private DBTblTsoEnterpriseTrunk getTsoEnterpriseTrunkToUpdate() throws SQLException {
		  DBTblTsoEnterpriseTrunk  tsoEnterpriseTrunkDbBean=new DBTblTsoEnterpriseTrunk();
	        /* Create a new instance of TsoEnterpriseTrunkBean. The new instance
	         * would hold default values for the all the TsoEnterpriseTrunkBean fields.*/
		  TsoEnterpriseTrunkBean defaultTsoEnterpriseTrunkBean = new TsoEnterpriseTrunkBean();
		  TsoEnterpriseTrunk inputTsoEnterprise = this;
		  tsoEnterpriseTrunkDbBean.setEnterpriseTrunkId(enterpriseTrunkId);
		  TblTsoEnterpriseTrunkQuery tsoEntQry=new TblTsoEnterpriseTrunkQuery();
		  tsoEntQry.whereEnterpriseTrunkIdEQ(inputTsoEnterprise.getEnterpriseTrunkId());
		  tsoEntQry.query(dbCon);
		  if (inputTsoEnterprise.getEnterpriseTrunkName() != null
	                && !inputTsoEnterprise.getEnterpriseTrunkName().equals(defaultTsoEnterpriseTrunkBean.getEnterpriseTrunkName())){
			  tsoEnterpriseTrunkDbBean.setEnterpriseTrunkName(inputTsoEnterprise.getEnterpriseTrunkName());
	        }
		  /*if (tsoEnterpriseTrunkDbBean.getEnterpriseId() != null
	                && !tsoEnterpriseTrunkDbBean.getEnterpriseId().equals(defaultTsoEnterpriseTrunkBean.getEnterpriseId())){
			  tsoEnterpriseTrunkDbBean.setEnterpriseId(inputTsoEnterprise.getEnterpriseId());
		  }*/
		  if (inputTsoEnterprise.getMaxRerouteAttempts()!=defaultTsoEnterpriseTrunkBean.getMaxRerouteAttempts()){
			  tsoEnterpriseTrunkDbBean.setMaxRerouteAttempts(inputTsoEnterprise.getMaxRerouteAttempts());
		  }
		  if (inputTsoEnterprise.getMaxRerouteAttemptsPriority()!=defaultTsoEnterpriseTrunkBean.getMaxRerouteAttemptsPriority()){
			  tsoEnterpriseTrunkDbBean.setMaxRerouteAttemptsPriority(inputTsoEnterprise.getMaxRerouteAttemptsPriority());
		  }
		  if (inputTsoEnterprise.getRouteExhaustActivated() !=defaultTsoEnterpriseTrunkBean.getRouteExhaustActivated()){
			  tsoEnterpriseTrunkDbBean.setRouteExhaustActivated(inputTsoEnterprise.getRouteExhaustActivated());
		  }
		  if (inputTsoEnterprise.getRouteExhaustAction()!=defaultTsoEnterpriseTrunkBean.getRouteExhaustAction()){
			  tsoEnterpriseTrunkDbBean.setRouteExhaustAction(inputTsoEnterprise.getRouteExhaustAction());
		  }
		  if (inputTsoEnterprise.getRouteExhaustFwdTn() != null
	                && !inputTsoEnterprise.getRouteExhaustFwdTn().equals(defaultTsoEnterpriseTrunkBean.getRouteExhaustFwdTn())){
			  tsoEnterpriseTrunkDbBean.setRouteExhaustFwdTn(inputTsoEnterprise.getRouteExhaustFwdTn());
		  }
			if("".equals(inputTsoEnterprise.getRouteExhaustFwdTn())){
			  tsoEnterpriseTrunkDbBean.setRouteExhaustFwdTnNull();
		  }
		  if (inputTsoEnterprise.getModifiedBy() != null
	                && !inputTsoEnterprise.getModifiedBy().equals(defaultTsoEnterpriseTrunkBean.getModifiedBy())){
			  tsoEnterpriseTrunkDbBean.setModifiedBy(inputTsoEnterprise.getModifiedBy());
		  }
		  if (inputTsoEnterprise.getLastModifiedDate()!= null
	                && !inputTsoEnterprise.getLastModifiedDate().equals(defaultTsoEnterpriseTrunkBean.getLastModifiedDate())){
			  tsoEnterpriseTrunkDbBean.setLastModifiedDate(inputTsoEnterprise.getLastModifiedDate());
		  }
        return tsoEnterpriseTrunkDbBean;
	   }   
	  
	  public boolean deleteFromDB() throws SQLException, Exception {
				
		if(enterpriseTrunkId <= 0)
		{
			log.info("Invalid Input");
			setStatus(InvErrorCode.INVALID_INPUT);
			return false;
		}
        DBTblTsoEtTgMap tsoEtTgBean = new DBTblTsoEtTgMap();
        tsoEtTgBean.whereEnterpriseTrunkIdEQ(enterpriseTrunkId);
        tsoEtTgBean.deleteByWhere(dbCon);
        setLogTrail("Deleted details related to EnterpriseTrunk: "+ enterpriseTrunkId + " from tbl_tso_et_tg_map");
        deleteETTnForET();
		
		DBTblTsoEnterpriseTrunk  tsoEnterpriseDbBean=new DBTblTsoEnterpriseTrunk();
		tsoEnterpriseDbBean.whereEnterpriseTrunkIdEQ(enterpriseTrunkId);
		
		if ( tsoEnterpriseDbBean.deleteByWhere(dbCon) <= 0 ) {
			log.info("No EnterpriseTrunk found to delete "+enterpriseTrunkId);
            return false;
        }
		
		log.info("Successfully deleted TsoEnterpriseTrunk");
		setStatusDesc("Successfully deleted TsoEnterpriseTrunk ");
			
		return true;
	}
	  
	  public long deleteETTnForET() throws SQLException, Exception {

		  log.info("deleteETTnForET ::");

		  TblTsoEtTnQuery etTnQuery = new TblTsoEtTnQuery();
		  etTnQuery.whereEnterpriseTrunkIdEQ(getEnterpriseTrunkId());
		  etTnQuery.query(dbCon);
		  long rowSize = etTnQuery.size();
		  log.info("deleteETTnForET :: etTnQuery size" + etTnQuery.size());
		  for(int i = 0; i < etTnQuery.size(); i++)
		  {
			  TsoEtTn tsoEtTn = new TsoEtTn(dbCon);
			  tsoEtTn.setEtTnId(etTnQuery.getDbBean(i).getEtTnId());
			  tsoEtTn.setModifiedBy(getModifiedBy());
			  tsoEtTn.deleteFromDB();
			  log.info("deleteETTnForET:: deleted tsoEtTn with groupTnId:"+tsoEtTn.getEtTnId());
		  }

		  // Recursive call to make sure we are not picking up only 
		  // DB generated max rows!!
		  if(rowSize != 0) {
			  log.info("Calling deleteETTnForET() recursively to make sure there is no rec left in db.");
			  deleteETTnForET();
		  }

		  return rowSize;
	  }
	  
	public TsoEnterpriseTrunkBean getEnterpriseTrunkByEnterpriseTrunkId(String enterpriseId, long enterpriseTrunkId) throws SQLException,Exception {
			TsoEnterpriseTrunkBean tsoEnterpriseTrunkBean = null;
		
			log.info("Got the enterpriseid  " + enterpriseId);
			if (enterpriseId == null || "".equals(enterpriseId)) {
				log.info("enterpriseId  is null or empty");
				return tsoEnterpriseTrunkBean;
			}
			log.info("Got enterpriseTrunkId " + enterpriseTrunkId);
			if (enterpriseTrunkId <= 0) {
				log.info("enterpriseTrunkId  is null or empty");
				return tsoEnterpriseTrunkBean;
			}
		
			StringBuffer sql = new StringBuffer();
			PreparedStatement pStmt = null;
			ResultSet rs = null;			
			log.info("EntID "+enterpriseId);
			log.info("EntTrunkID "+enterpriseTrunkId);
			sql.append("select * from tbl_tso_enterprise_trunk where ENTERPRISE_ID= ? and ENTERPRISE_TRUNK_ID = ?");
			log.info("tbl_tso_enterprise_trunk query executed" + sql);
			
			try {
				log.info("Inside try block");
				pStmt = dbCon.prepareStatement(sql.toString());
				if (pStmt != null) {
					pStmt.setString(1, enterpriseId);
					pStmt.setLong(2, enterpriseTrunkId);
					log.info("AFTER tbl_tso_enterprise_trunk query executed" + sql);	
					rs = pStmt.executeQuery();
					while (rs.next()) {
						tsoEnterpriseTrunkBean = new TsoEnterpriseTrunkBean();
						log.info("Inside resultset loop ");
						
						tsoEnterpriseTrunkBean.setEnterpriseId(rs.getString(1));
						tsoEnterpriseTrunkBean.setEnterpriseTrunkName(rs.getString(2));
						tsoEnterpriseTrunkBean.setEnterpriseTrunkId(rs.getLong(3));
						tsoEnterpriseTrunkBean.setMaxRerouteAttempts(rs.getLong(4));
						tsoEnterpriseTrunkBean.setMaxRerouteAttemptsPriority(rs.getShort(5));
						tsoEnterpriseTrunkBean.setRouteExhaustActivated(rs.getLong(6));
						tsoEnterpriseTrunkBean.setRouteExhaustAction(rs.getLong(7));
						tsoEnterpriseTrunkBean.setRouteExhaustFwdTn(rs.getString(8));
						tsoEnterpriseTrunkBean.setCreatedBy(rs.getString(9));
						tsoEnterpriseTrunkBean.setCreationDate(rs.getTimestamp(10));
						tsoEnterpriseTrunkBean.setModifiedBy(rs.getString(11));
						tsoEnterpriseTrunkBean.setLastModifiedDate(rs.getTimestamp(12));
					}
					log.info("Set tsoEnterpriseTrunkBean object "	+ tsoEnterpriseTrunkBean);
								
				}
			} catch (SQLException sqe) {
				log.error("Exception during getEnterpriseTrunkByEnterpriseTrunkId() :",sqe);
				log.error("DB_FAILURE in tbl_tso_enterprise_trunk");
			} catch (Exception e) {
				log.error("Exception during getEnterpriseTrunkByEnterpriseTrunkId() :",e);
				log.error("DB_FAILURE in tbl_tso_enterprise_trunk");
			} finally {
				if (pStmt != null) {
					pStmt.close();
				}
				if (rs != null) {
					rs.close();
				}
		
			}
		
			return tsoEnterpriseTrunkBean;
		
	}
}
