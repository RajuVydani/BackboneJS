package com.vz.fxo.inventory.actionfunction.support;

import esap.db.TblTerminatingRoutingDbBean;

public class TerminatingRoutingBean {
    protected int terminatingRoutingId;
    protected long dialPlanId;
    protected long noa;
    protected String rangeStart;
    protected String rangeEnd;
    protected String p1URL;
    protected String pringTime;
    protected String ptrId;
    protected String pPrefixDgts;
    protected long pSuffixNum;
    protected String a1URL;
    protected String a1RingTime;
    protected String a1TRId;
    protected String a1PrefixDgts;
    protected long a1SuffixNum;
    protected String a2URL;
    protected String a2RingTime;
    protected String a2TRId;
    protected String a2PrefixDgts;
    protected long a2SuffixNum;
    protected String createdBy;
    protected String modifiedBy;
    protected java.sql.Timestamp creationDate;
    protected java.sql.Timestamp lastModifiedDate;
    protected long envOrderId;
    	/**
	 * Default Constructor -- Initializes all fields to default values.
	 */
    	public TerminatingRoutingBean() {
    		this.terminatingRoutingId = 0;
		this.dialPlanId = 0;
		this.noa = -1;
		this.rangeStart = new String("");
		this.rangeEnd = new String("NONE");
		p1URL = new String("NONE");
		this.pringTime = new String("NONE");
		this.ptrId = new String("NONE");
		pPrefixDgts = new String("NONE");
		pSuffixNum = -1;
		a1URL = new String("NONE");
		a1RingTime = new String("NONE");
		a1TRId = new String("NONE");
                a1PrefixDgts = new String("NONE");
		a1SuffixNum = -1;
		a2URL =  new String("NONE");
		a2RingTime =  new String("NONE");
		a2TRId =  new String("NONE");
		a2PrefixDgts =  new String("NONE");
		a2SuffixNum = -1;
		this.createdBy =  new String("");
		this.modifiedBy =  new String("");
		this.envOrderId = -1;
	}

    	/**
     	* Constructor
     	* @param terminatingRoutingBean
     	*/
    	public TerminatingRoutingBean(TerminatingRoutingBean terminatingRoutingBean) {
    		this.terminatingRoutingId = terminatingRoutingBean.terminatingRoutingId;
		this.dialPlanId = terminatingRoutingBean.dialPlanId;
		this.noa = terminatingRoutingBean.noa;
		this.rangeStart = terminatingRoutingBean.rangeStart;
		this.rangeEnd = terminatingRoutingBean.rangeEnd;
		p1URL = terminatingRoutingBean.p1URL;
		this.pringTime = terminatingRoutingBean.pringTime;
		this.ptrId = terminatingRoutingBean.ptrId;
		pPrefixDgts = terminatingRoutingBean.pPrefixDgts;
		pSuffixNum = terminatingRoutingBean.pSuffixNum;
		a1URL = terminatingRoutingBean.a1URL;
		a1RingTime = terminatingRoutingBean.a1RingTime;
		a1TRId = terminatingRoutingBean.a1TRId;
		a1PrefixDgts = terminatingRoutingBean.a1PrefixDgts;
		a1SuffixNum = terminatingRoutingBean.a1SuffixNum;
		a2URL = terminatingRoutingBean.a2URL;
		a2RingTime = terminatingRoutingBean.a2RingTime;
		a2TRId = terminatingRoutingBean.a2TRId;
		a2PrefixDgts = terminatingRoutingBean.a2PrefixDgts;
		a2SuffixNum = terminatingRoutingBean.a2SuffixNum;
		this.createdBy = terminatingRoutingBean.createdBy;
		this.modifiedBy = terminatingRoutingBean.modifiedBy;
		this.creationDate = terminatingRoutingBean.creationDate;
		this.lastModifiedDate = terminatingRoutingBean.lastModifiedDate;
		this.envOrderId = terminatingRoutingBean.envOrderId;
	}

    public String toString(){
        final String NEWLINE = "\n";
        StringBuffer retValue = new StringBuffer();
        retValue.append("TerminatingRoutingBean ( ");
        retValue.append(super.toString()).append(NEWLINE);
        retValue.append("terminatingRoutingId = ").append(this.terminatingRoutingId).append(NEWLINE);
        retValue.append("dialPlanId = ").append(this.dialPlanId).append(NEWLINE);
        retValue.append("createdBy = ").append(this.createdBy).append(NEWLINE);
        retValue.append("modifiedBy = ").append(this.modifiedBy).append(NEWLINE);
        retValue.append("lastModifiedDate = ").append(this.lastModifiedDate).append(NEWLINE);
        retValue.append(" )");
        return retValue.toString();
    }
    
    public java.sql.Timestamp getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(java.sql.Timestamp creationDate) {
		this.creationDate = creationDate;
	}

	public int getTerminatingRoutingId() {
        return terminatingRoutingId;
    }
    public void setTerminatingRoutingId(int terminatingRoutingId) {
        this.terminatingRoutingId = terminatingRoutingId;
    }
    public long getDialPlanId() {
        return dialPlanId;
    }
    public void setDialPlanId(long dialPlanId) {
        this.dialPlanId = dialPlanId;
    }
    public String getCreatedBy() {
        return createdBy;
    }
    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }
    public String getModifiedBy() {
        return modifiedBy;
    }
    public void setModifiedBy(String modifiedBy) {
        this.modifiedBy = modifiedBy;
    }
    public java.sql.Timestamp getLastModifiedDate() {
        return lastModifiedDate;
    }
    public void setLastModifiedDate(java.sql.Timestamp lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }
	public String getA1PrefixDgts() {
		return a1PrefixDgts;
	}
	public void setA1PrefixDgts(String prefixDgts) {
		a1PrefixDgts = prefixDgts;
	}
	public String getA1RingTime() {
		return a1RingTime;
	}
	public void setA1RingTime(String ringTime) {
		a1RingTime = ringTime;
	}
	public long getA1SuffixNum() {
		return a1SuffixNum;
	}
	public void setA1SuffixNum(long suffixNum) {
		a1SuffixNum = suffixNum;
	}
	public String getA1TRId() {
		return a1TRId;
	}
	public void setA1TRId(String id) {
		a1TRId = id;
	}
	public String getA1URL() {
		return a1URL;
	}
	public void setA1URL(String a1url) {
		a1URL = a1url;
	}
	public String getA2PrefixDgts() {
		return a2PrefixDgts;
	}
	public void setA2PrefixDgts(String prefixDgts) {
		a2PrefixDgts = prefixDgts;
	}
	public String getA2RingTime() {
		return a2RingTime;
	}
	public void setA2RingTime(String ringTime) {
		a2RingTime = ringTime;
	}
	public long getA2SuffixNum() {
		return a2SuffixNum;
	}
	public void setA2SuffixNum(long suffixNum) {
		a2SuffixNum = suffixNum;
	}
	public String getA2TRId() {
		return a2TRId;
	}
	public void setA2TRId(String id) {
		a2TRId = id;
	}
	public String getA2URL() {
		return a2URL;
	}
	public void setA2URL(String a2url) {
		a2URL = a2url;
	}
	public long getNoa() {
		return noa;
	}
	public void setNoa(long noa) {
		this.noa = noa;
	}
	public String getP1URL() {
		return p1URL;
	}
	public void setP1URL(String p1url) {
		p1URL = p1url;
	}
	public String getPPrefixDgts() {
		return pPrefixDgts;
	}
	public void setPPrefixDgts(String prefixDgts) {
		pPrefixDgts = prefixDgts;
	}
	public String getPringTime() {
		return pringTime;
	}
	public void setPringTime(String pringTime) {
		this.pringTime = pringTime;
	}
	public long getPSuffixNum() {
		return pSuffixNum;
	}
	public void setPSuffixNum(long suffixNum) {
		pSuffixNum = suffixNum;
	}
	public String getPtrId() {
		return ptrId;
	}
	public void setPtrId(String ptrId) {
		this.ptrId = ptrId;
	}
	public String getRangeEnd() {
		return rangeEnd;
	}
	public void setRangeEnd(String rangeEnd) {
		this.rangeEnd = rangeEnd;
	}
	public String getRangeStart() {
		return rangeStart;
	}
	public void setRangeStart(String rangeStart) {
		this.rangeStart = rangeStart;
	}

	public void copyFrom(TblTerminatingRoutingDbBean dbBean) {
		setTerminatingRoutingId(dbBean.getTerminatingRoutingId());
		setDialPlanId(dbBean.getDialPlanId());
		setNoa(dbBean.getNoa());
		setRangeStart(dbBean.getRangeStart());
		setRangeEnd(dbBean.getRangeEnd());
		setP1URL(dbBean.getP1url());
		setPringTime(dbBean.getPringtime());
		setPtrId(dbBean.getPtrid());
		setPPrefixDgts(dbBean.getPprefixdgts());
		setPSuffixNum(dbBean.getPsuffixnum());
		setA1URL(dbBean.getA1url());
		setA1RingTime(dbBean.getA1ringtime());
		setA1TRId(dbBean.getA1trid());
		setA1PrefixDgts(dbBean.getA1prefixdgts());
		setA1SuffixNum(dbBean.getA1suffixnum());
		setA2URL(dbBean.getA2url());
		setA2RingTime(dbBean.getA2ringtime());
		setA2TRId(dbBean.getA2trid());
		setA2PrefixDgts(dbBean.getA2prefixdgts());
		setA2SuffixNum(dbBean.getA2suffixnum());
		setCreatedBy(dbBean.getCreatedBy());
		setModifiedBy(dbBean.getModifiedBy());
		setLastModifiedDate(dbBean.getLastModifiedDate());
		setEnvOrderId(dbBean.getEnvOrderId());
	}

	public long getEnvOrderId() {
		return envOrderId;
	}
	public void setEnvOrderId(long envOrderId) {
		this.envOrderId = envOrderId;
	}
	public void initilizeTODefault() {
		this.noa = -1;
		this.rangeStart = new String("");
		this.rangeEnd = new String("");
		p1URL = new String("");
		this.pringTime = new String("");
		this.ptrId = new String("");
		pPrefixDgts = new String("");
		pSuffixNum = -1;
		a1URL = new String("");
		a1RingTime = new String("");
		a1TRId = new String("");
        a1PrefixDgts = new String("");
		a1SuffixNum = -1;
		a2URL =  new String("");
		a2RingTime =  new String("");
		a2TRId =  new String("");
		a2PrefixDgts =  new String("");
		a2SuffixNum = -1;
		this.createdBy =  new String("");
		this.modifiedBy =  new String("");
		this.envOrderId = -1;
	}
}


