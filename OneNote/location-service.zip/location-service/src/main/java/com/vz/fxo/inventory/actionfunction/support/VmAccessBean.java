package com.vz.fxo.inventory.actionfunction.support;



public class VmAccessBean
{
	//members
	protected int vmAccessId;
	protected String enterpriseId;
	protected String locationId;
	protected String subId;
	protected String publicNumber;
	protected long publicPoolId;
	protected String privateNumber;
	protected long npaSplitStatus;
	protected String createdBy;
	protected java.sql.Timestamp creationDate;
    protected java.sql.Timestamp lastModifiedDate;
	protected String modifiedBy;
	protected long envOrderId;

	/**
	 * Default Constructor -- Initializes all fields to default values.
	 */
    	public VmAccessBean() 
	{
		this.vmAccessId = 0;
		this.enterpriseId = new String("");
		this.locationId = new String("");
		this.subId = new String("");
		this.publicNumber = new String("");
		this.publicPoolId = 0;
		this.privateNumber = new String("");
		this.npaSplitStatus = 0;
		this.createdBy = new String("");
		this.creationDate = null;
		this.lastModifiedDate = null;
		this.modifiedBy =  new String("");
		this.envOrderId = 0;
	}
	/**
	 * Constructor
	 * @param vmBean
	 */
	public VmAccessBean(VmAccessBean vmBean)
    	{
		this.vmAccessId = vmBean.vmAccessId;
		this.enterpriseId = vmBean.enterpriseId;
		this.locationId = vmBean.locationId;
		this.subId = vmBean.subId;
		this.publicNumber = vmBean.publicNumber;
		this.publicPoolId = vmBean.publicPoolId;
		this.privateNumber = vmBean.privateNumber;
		this.npaSplitStatus = vmBean.npaSplitStatus;
		this.createdBy = vmBean.createdBy;
		this.creationDate = vmBean.creationDate;
		this.lastModifiedDate = vmBean.lastModifiedDate;
		this.modifiedBy = vmBean.modifiedBy;
		this.envOrderId = vmBean.envOrderId ;
    	}


	public int getVmAccessId() {
		return vmAccessId;
	}
	public void setVmAccessId(int vmAccessid) {
		this.vmAccessId = vmAccessid;
	}
	public String getEnterpriseId() {
		return enterpriseId;
	}
	public void setEnterpriseId(String enterpriseId) {
		this.enterpriseId = enterpriseId;
	}
	public String getLocationId() {
		return locationId;
	}
	public void setLocationId(String locationId) {
		this.locationId = locationId;
	}
	public String getSubId() {
                return subId;
        }
        public void setSubId(String subId) {
                this.subId = subId;
        }
	public long getPublicPoolId() {
		return publicPoolId;
	}
	public void setPublicPoolId(long publicPoolId) {
		this.publicPoolId = publicPoolId;
	}
	public String getPublicNumber() {
		return publicNumber;
	}
	public void setPublicNumber(String publicNumber) {
		this.publicNumber = publicNumber;
	}
	public String getPrivateNumber() {
		return privateNumber;
	}
	public void setPrivateNumber(String privateNumber) {
		this.privateNumber = privateNumber;
	}
	public long getNpaSplitStatus() {
		return npaSplitStatus;
	}
	public void setNpaSplitStatus(long npaSplitStatus) {
		this.npaSplitStatus = npaSplitStatus;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public java.sql.Timestamp getCreationDate() {
		return creationDate;
	}
	public void setCreationDate(java.sql.Timestamp creationDate) {
		this.creationDate = creationDate;
	}
	public java.sql.Timestamp getLastModifiedDate() {
		return lastModifiedDate;
	}
	public void setLastModifiedDate(java.sql.Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}
	public String getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	
	public long getEnvOrderId() {
		return envOrderId;
	}
	public void setEnvOrderId(long envOrderId) {
		this.envOrderId = envOrderId;
	}

}
