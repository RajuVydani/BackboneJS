package com.vz.fxo.inventory.tn.controller;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeoutException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.BindException;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.vz.esap.api.model.BSServiceRequest;
import com.vz.fxo.inventory.tn.model.ResponseObject;
import com.vz.fxo.inventory.tn.service.InventoryFxoLocationServiceImpl;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;


@RestController
@RequestMapping("/inventory/fxo/location")
@Api(value = "inventory", description = "Inventory LOCATION Operations Service API")
public class InventoryFxoLocationServiceController {

	@Autowired
	private InventoryFxoLocationServiceImpl locationServiceImpl;
	
	ObjectMapper mapper = new ObjectMapper();

	private static Logger log = LoggerFactory
			.getLogger(InventoryFxoLocationServiceController.class);

	@RequestMapping(value = "/delSuspendLocation", method = RequestMethod.POST, produces = "application/json")
	@ApiResponses(value = { @ApiResponse(code = 0, message = "Successful"),
			@ApiResponse(code = 1, message = "Internal Server Error"), })
	public ResponseObject delSuspendLocation(
			@RequestBody BSServiceRequest bsRequestEntity)
			throws InterruptedException, ExecutionException, TimeoutException,
			BindException, JsonProcessingException {
	
		log.info("delSuspendLocation() Request Object   :"
				+ mapper.writerWithDefaultPrettyPrinter().writeValueAsString(
						bsRequestEntity));

		int flag = locationServiceImpl.delSuspendLocation(bsRequestEntity);

		ResponseObject object = new ResponseObject();
		if (flag == ResponseObject.SUCCESS) {
			object.setStatusCode(ResponseObject.SUCCESS);
			object.setStatusDescription("DEL SUSPEND LOCATION Job is completed");
		} else {
			object.setStatusCode(ResponseObject.FAILURE);
			object.setStatusDescription("DEL SUSPEND LOCATION Job is failed");
		}
		log.info("delSuspendLocation() Operation Completed response Object  :"
				+ mapper.writerWithDefaultPrettyPrinter().writeValueAsString(
						object));
		return object;
	}
	
	@RequestMapping(value = "/modLocationCnam", method = RequestMethod.POST, produces = "application/json")
	@ApiResponses(value = { @ApiResponse(code = 0, message = "Successful"),
			@ApiResponse(code = 1, message = "Internal Server Error"), })
	public ResponseObject modLocationCnam(
			@RequestBody BSServiceRequest bsRequestEntity)
			throws InterruptedException, ExecutionException, TimeoutException,
			BindException, JsonProcessingException {
	
		log.info("modLocationCnam() Request Object   :"
				+ mapper.writerWithDefaultPrettyPrinter().writeValueAsString(
						bsRequestEntity));

		int flag = locationServiceImpl.modLocationCnam(bsRequestEntity);

		ResponseObject object = new ResponseObject();
		if (flag == ResponseObject.SUCCESS) {
			object.setStatusCode(ResponseObject.SUCCESS);
			object.setStatusDescription("MOD LOCATION CNAM Job is completed");
		} else {
			object.setStatusCode(ResponseObject.FAILURE);
			object.setStatusDescription("MOD LOCATION CNAM Job is failed");
		}
		log.info("modLocationCnam() Operation Completed response Object  :"
				+ mapper.writerWithDefaultPrettyPrinter().writeValueAsString(
						object));
		return object;
	}

	@RequestMapping(value = "/pcModLocation", method = RequestMethod.POST, produces = "application/json")
	@ApiResponses(value = { @ApiResponse(code = 0, message = "Successful"),
			@ApiResponse(code = 1, message = "Internal Server Error"), })
	public ResponseObject pcModLocation(
			@RequestBody BSServiceRequest bsRequestEntity)
					throws InterruptedException, ExecutionException, TimeoutException,
					BindException, JsonProcessingException {
	
	log.info("pcModLocation() Request Object   :{}"
				, mapper.writerWithDefaultPrettyPrinter().writeValueAsString(
						bsRequestEntity));

		int flag = locationServiceImpl.pcModLocation(bsRequestEntity);
		ResponseObject object = new ResponseObject();
		if (flag == ResponseObject.SUCCESS) {
			object.setStatusDescription("PC MOD LOCATION Job is completed");
		} else {
			object.setStatusCode(ResponseObject.FAILURE);
			object.setStatusDescription("PC MOD LOCATION Job is failed");
		}
		log.info("pcModLocation() Operation Completed response Object  :{}"
				,mapper.writerWithDefaultPrettyPrinter().writeValueAsString(
						object));
		return object;
	}
	
	
	@RequestMapping(value = "/invModLocation", method = RequestMethod.POST, produces = "application/json")
	@ApiResponses(value = { @ApiResponse(code = 0, message = "Successful"),
			@ApiResponse(code = 1, message = "Internal Server Error"), })
	public ResponseObject invModLocation(

			@RequestBody BSServiceRequest bsRequestEntity)
			throws InterruptedException, ExecutionException, TimeoutException,
			BindException, JsonProcessingException {
	

		log.info("invModLocation() Request Object   :"
				+ mapper.writerWithDefaultPrettyPrinter().writeValueAsString(
						bsRequestEntity));

		int flag = locationServiceImpl.invModLocation(bsRequestEntity);


		ResponseObject object = new ResponseObject();
		if (flag == ResponseObject.SUCCESS) {
			object.setStatusCode(ResponseObject.SUCCESS);

			object.setStatusDescription("INV MOD LOCATION Job is completed");
		} else {
			object.setStatusCode(ResponseObject.FAILURE);
			object.setStatusDescription("INV MOD LOCATION Job is failed");
		}
		log.info("invModLocation() Operation Completed response Object  :"

				+ mapper.writerWithDefaultPrettyPrinter().writeValueAsString(
						object));
		return object;
	}
	
	@RequestMapping(value = "/pcCompleteLocation", method = RequestMethod.POST, produces = "application/json")
	@ApiResponses(value = { @ApiResponse(code = 0, message = "Successful"),
			@ApiResponse(code = 1, message = "Internal Server Error"), })
	public ResponseObject pcCompleteLocation(

			@RequestBody BSServiceRequest bsRequestEntity)
			throws InterruptedException, ExecutionException, TimeoutException,
			BindException, JsonProcessingException {
	

		log.info("pcCompleteLocation() Request Object   :"
				+ mapper.writerWithDefaultPrettyPrinter().writeValueAsString(
						bsRequestEntity));

		int flag = locationServiceImpl.pcCompleteLocation(bsRequestEntity);


		ResponseObject object = new ResponseObject();
		if (flag == ResponseObject.SUCCESS) {
			object.setStatusCode(ResponseObject.SUCCESS);

			object.setStatusDescription("PC COMPLETE LOCATION Job is completed");
		} else {
			object.setStatusCode(ResponseObject.FAILURE);
			object.setStatusDescription("PC COMPLETE LOCATION Job is failed");
		}
		log.info("pcCompleteLocation() Operation Completed response Object  :"

				+ mapper.writerWithDefaultPrettyPrinter().writeValueAsString(
						object));
		return object;
	}
	
	
	@RequestMapping(value = "/addLocation", method = RequestMethod.POST, produces = "application/json")
	@ApiResponses(value = { @ApiResponse(code = 0, message = "Successful"),
			@ApiResponse(code = 1, message = "Internal Server Error"), })
	public ResponseObject addLocation(
			@RequestBody BSServiceRequest bsRequestEntity)
			throws InterruptedException, ExecutionException, TimeoutException,
			BindException, JsonProcessingException {
	
		log.info("addLocation() Request Object   :"
				+ mapper.writerWithDefaultPrettyPrinter().writeValueAsString(
						bsRequestEntity));

		int flag = locationServiceImpl.addLocation(bsRequestEntity);

		ResponseObject object = new ResponseObject();
		if (flag == ResponseObject.SUCCESS) {
			object.setStatusCode(ResponseObject.SUCCESS);
			object.setStatusDescription("ADD LOCATION Job is completed");
		} else {
			object.setStatusCode(ResponseObject.FAILURE);
			object.setStatusDescription("ADD LOCATION Job is failed");
		}
		log.info("addLocation() Operation Completed response Object  :"
				+ mapper.writerWithDefaultPrettyPrinter().writeValueAsString(
						object));
		return object;
	}
	
	@RequestMapping(value = "/delLocation", method = RequestMethod.POST, produces = "application/json")
	@ApiResponses(value = { @ApiResponse(code = 0, message = "Successful"),
			@ApiResponse(code = 1, message = "Internal Server Error"), })
	public ResponseObject delLocation(
			@RequestBody BSServiceRequest bsRequestEntity)
			throws InterruptedException, ExecutionException, TimeoutException,
			BindException, JsonProcessingException {
	
		log.info("delLocation() Request Object   :"
				+ mapper.writerWithDefaultPrettyPrinter().writeValueAsString(
						bsRequestEntity));

		int flag = locationServiceImpl.delLocation(bsRequestEntity);

		ResponseObject object = new ResponseObject();
		if (flag == ResponseObject.SUCCESS) {
			object.setStatusCode(ResponseObject.SUCCESS);
			object.setStatusDescription("DEL LOCATION Job is completed");
		} else {
			object.setStatusCode(ResponseObject.FAILURE);
			object.setStatusDescription("DEL LOCATION Job is failed");
		}
		log.info("delLocation() Operation Completed response Object  :"
				+ mapper.writerWithDefaultPrettyPrinter().writeValueAsString(
						object));
		return object;
	}
} 