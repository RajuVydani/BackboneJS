package com.vz.fxo.inventory.actionfunction.support; 

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import EsapEnumPkg.VzbVoipEnum;
//import esap.db.DBTblFeaturePkg;
import esap.db.DBTblFmcgDevice;
import esap.db.DBTblFmcgSubscriber;
import esap.db.DBTblFmcgVendorDialplan;
import esap.db.TblFmcgSubscriberDbBean;
import esap.db.TblFmcgSubscriberQuery;

/**
 * 
 * @author z987637
 * 
 */
public class FmcgSubscriber extends FmcgSubscriberBean
{

	private static Logger log = LoggerFactory.getLogger(FmcgSubscriber.class.toString());
    private Connection connection;
    InvErrorCode status = InvErrorCode.INTERNAL_ERROR;
    boolean rollbackFlag;
    boolean updateNeeded = false;

    public Connection getConnection()
    {
        return connection;
    }

    public void setConnection(Connection connection)
    {
        this.connection = connection;
    }

    public int getStatusCode()
    {
        return status.getErrorCode();
    }

    public void setStatus(InvErrorCode status)
    {
        this.status = status;
    }

    public String getStatusDesc()
    {
        return status.getErrorDesc();
    }

    public boolean validateSbc()
    {
        return true;
    }

    public FmcgSubscriber(Connection con)
    {
        this.connection = con;
        this.rollbackFlag = false;
    }

    public boolean isRollbackFlag()
    {
        return rollbackFlag;
    }

    public void setRollbackFlag(boolean rollbackFlag)
    {
        this.rollbackFlag = rollbackFlag;
    }

    /**
     * 
     * @param con
     * @param fmcgSubscriber
     */
    public FmcgSubscriber(Connection con, FmcgSubscriberBean fmcgSubscriberBean)
    {
        super(fmcgSubscriberBean);
        this.connection = con;
        this.rollbackFlag = false;
    }

    public boolean addFmcgSubscriber() throws Exception,SQLException
    {
        log.info("Entering FmcgSubscriber::addFmcgSubscriber");

        /*try
        {*/
            DBTblFmcgSubscriber fmcgSubscriberDb = new DBTblFmcgSubscriber();
			if(getFmcgSubId() <= 0 )
            {
				int fmcgSubscriberSeqId = fmcgSubscriberDb.getFmcgSubIdSeqNextVal(connection);
				setFmcgSubId(fmcgSubscriberSeqId);
			}
            fmcgSubscriberDb.setFmcgSubId(getFmcgSubId());
            if(!"NONE".equals(getMobileNumber()) && !"".equals(getMobileNumber()))
            	fmcgSubscriberDb.setMobileNumber(getMobileNumber());
            if(getFeaturePkgId() !=  -1 )
            	fmcgSubscriberDb.setFeaturePkgId(getFeaturePkgId());
            if(!"NONE".equals(getOutboundAlterNum()) && !"".equals(getOutboundAlterNum()))
            	fmcgSubscriberDb.setOutboundAlternateNumber(getOutboundAlterNum());
           if(getFmcgDeviceId() != -1)  {
				if(getFmcgDeviceId() <= 0)
	            	fmcgSubscriberDb.setFmcgDeviceIdNull();
				else
	            	fmcgSubscriberDb.setFmcgDeviceId(getFmcgDeviceId());
           }
            fmcgSubscriberDb.setFmcgType(getFmcgType());
            if(getFmcgDialPlanId() != -1)
            	fmcgSubscriberDb.setFmcgDialPlanId(getFmcgDialPlanId());
            if(!"NONE".equals(getPortalPin()) && !"".equals(getPortalPin()))
            	fmcgSubscriberDb.setPortalPin(getPortalPin());
			if(getUniversalClid() != -1) {
			 if(getUniversalClid() < 1 )	
            	fmcgSubscriberDb.setUniversalClid(0);
			else
            	fmcgSubscriberDb.setUniversalClid(getUniversalClid());
			}
			if(getNotificationMethod() != -1)
				fmcgSubscriberDb.setNotificationMethod(getNotificationMethod());
			if(!"NONE".equals(getNotificationEmail()) && !"".equals(getNotificationEmail()))
				fmcgSubscriberDb.setNotificationEmail(getNotificationEmail());
			if(getAnsConfirmation() != -1)
				fmcgSubscriberDb.setAnswerConfirmation(getAnsConfirmation());
			else
				fmcgSubscriberDb.setAnswerConfirmation(VzbVoipEnum.YesNoType.N);
			
			if(getActRetryCount() != -1)
				fmcgSubscriberDb.setActivationRetryCount(getActRetryCount());
            fmcgSubscriberDb.setActivationDate(new Timestamp(System.currentTimeMillis()));
            if(!"NONE".equals(getImei()) && !"".equals(getImei()))
            	fmcgSubscriberDb.setImei(getImei());
            if(!"NONE".equals(getEas()) && !"".equals(getEas()))
            fmcgSubscriberDb.setEas(getEas());
            fmcgSubscriberDb.setCreationDate(new Timestamp(System.currentTimeMillis()));
            fmcgSubscriberDb.setLastModifiedDate(new Timestamp(System.currentTimeMillis()));

           	if (!getCreatedBy().equals("") &&  ! "NONE".equals(getCreatedBy()) )
                fmcgSubscriberDb.setCreatedBy(getCreatedBy());
            else
                fmcgSubscriberDb.setCreatedBy("ESAP_INV");

            if (!getModifiedBy().equals("") &&  ! "NONE".equals(getModifiedBy()))
                fmcgSubscriberDb.setModifiedBy(getModifiedBy());
            else
                fmcgSubscriberDb.setModifiedBy("ESAP_INV");
            
            //FMCg Phase II
            if (getRequestType() != -1)
                fmcgSubscriberDb.setRequestType(getRequestType());

            if (!"NONE".equals(getDevicePin()) && !"".equals(getDevicePin()))
                fmcgSubscriberDb.setDevicePin(getDevicePin());

            if (!"NONE".equals(getBesEnabled()) && !"".equals(getBesEnabled()))
                fmcgSubscriberDb.setBesEnabled(getBesEnabled());

            if (getReadyStatus() != -1)
                fmcgSubscriberDb.setReadyStatus(getReadyStatus());

            if (getReadyDate() != null)
                fmcgSubscriberDb.setReadyDate(getReadyDate());

            if (getNotifyConfigUpdate() != null)
                fmcgSubscriberDb.setNotifyConfigUpdate(getNotifyConfigUpdate());

            if (getNotifyInstall() != null)
                fmcgSubscriberDb.setNotifyInstall(getNotifyInstall());

            fmcgSubscriberDb.insert(connection);
        /*}
        catch (SQLException s)
        {
            s.printStackTrace();
            setStatus(InvErrorCode.DB_EXCEPTION);
            return false;
        }*/
        setStatus(InvErrorCode.SUCCESS);
        return true;
    }

    /**
     * getFmcgSubscriberDetailsById
     * 
     * @return
     */
    public boolean getFmcgSubscriberDetailsById()
    {
        log.info("Entering FmcgSubscriber::getFmcgSubscriberDetailsById");

        try
        {
            TblFmcgSubscriberQuery fmcgSubscriberQuery = new TblFmcgSubscriberQuery();
            initilizeTODefault();
            log.info("Querying Subscriber Details for id: " + getFmcgSubId());
            fmcgSubscriberQuery.whereFmcgSubIdEQ(getFmcgSubId());
			fmcgSubscriberQuery.query(connection);
            if (fmcgSubscriberQuery.size() <= 0)
            {
                log.info("Failed to Retrieve FmcgSubscriber");
                return false;
            }

            TblFmcgSubscriberDbBean fmcgSubscriberBean = fmcgSubscriberQuery.getDbBean(0);

            setFmcgSubId(fmcgSubscriberBean.getFmcgSubId());
            setMobileNumber(fmcgSubscriberBean.getMobileNumber());
            setFeaturePkgId(fmcgSubscriberBean.getFeaturePkgId());
            setOutboundAlterNum(fmcgSubscriberBean.getOutboundAlternateNumber());
            setFmcgDeviceId(fmcgSubscriberBean.getFmcgDeviceId());
            setFmcgType(fmcgSubscriberBean.getFmcgType());
            setFmcgDialPlanId((int)fmcgSubscriberBean.getFmcgDialPlanId());
            setPortalPin(fmcgSubscriberBean.getPortalPin());
            setNotificationMethod(fmcgSubscriberBean.getNotificationMethod());
            setNotificationEmail(fmcgSubscriberBean.getNotificationEmail());
            setUniversalClid(fmcgSubscriberBean.getUniversalClid());
            setAnsConfirmation(fmcgSubscriberBean.getAnswerConfirmation());
            setActRetryCount(fmcgSubscriberBean.getActivationRetryCount());
            setActDate(fmcgSubscriberBean.getActivationDate());
            setImei(fmcgSubscriberBean.getImei());
            setEas(fmcgSubscriberBean.getEas());
            //setCreatedBy(fmcgSubscriberBean.getCreatedBy());
            //setCreationDate(fmcgSubscriberBean.getCreationDate());
           // setModifiedBy(fmcgSubscriberBean.getModifiedBy());
           // setLastModifiedDate(fmcgSubscriberBean.getLastModifiedDate());
           // setEnvOrderId(fmcgSubscriberBean.getEnvOrderId());
            //FMCg Phase II
            setRequestType(fmcgSubscriberBean.getRequestType());
            setDevicePin(fmcgSubscriberBean.getDevicePin());
            setBesEnabled(fmcgSubscriberBean.getBesEnabled());
            setReadyStatus(fmcgSubscriberBean.getReadyStatus());
            setReadyDate(fmcgSubscriberBean.getReadyDate());
            setNotifyConfigUpdate(fmcgSubscriberBean.getNotifyConfigUpdate());
            setNotifyInstall(fmcgSubscriberBean.getNotifyInstall());
        }
        catch (Exception s)
        {
            s.printStackTrace();
            setStatus(InvErrorCode.DB_EXCEPTION);
            return false;
        }
        setStatus(InvErrorCode.SUCCESS);
        return true;
    }

    /**
     * This method is for fetching Feature Package for Fmcg Subscriber
     * 
     * @return
     */
    public boolean getFeaturePackageForFmcgSubscriber()
    {
        try
        {
            //retrieve FmcgSubscriber details to get the FeaturePackageId(FEATURE_PKG_ID)
            boolean ret = getFmcgSubscriberDetailsById();
            if (!ret)
            {
                setStatus(InvErrorCode.INV_FAILURE);
                log.info("FAILURE in getDetailsByGroupTnId KeyGroupTn. KeyGroupTn.getDetailsByGroupTnId returned false in getFeaturePackageForFmcgSubscriber");
                return false;
            }
            log.info("In the Inventry, the FeaturePackage Id for FmcgSubscriber = " + fmcgSubId + " is -> "
                    + featurePkgId);
            //if PublicTnPoolId is valid, query the PublicTnPool class for details.
            FeaturePackage futpkgObj = new FeaturePackage(connection);
            futpkgObj.setFeaturePackageId(new Long(featurePkgId).intValue());
            ret = futpkgObj.getPackageDetails();
            if (!ret)
            {
                setStatus(InvErrorCode.INV_FAILURE);
                log.info("FAILURE in futpkgObj.getPackageDetails() returned false in getFeaturePackageForFmcgSubscriber");
                return false;
            }
            setFeaturePackageObj((FeaturePackageBean) futpkgObj);
        }
        catch (Exception e)
        {
            e.printStackTrace();
            setStatus(InvErrorCode.ERROR_GETTING_FEATURE_PACKAGE_SUBSCRIBER);
            log.info("FAILURE in getDetails KeyGroupTn");
            return false;
        }
        setStatus(InvErrorCode.SUCCESS);
        log.info("Successfully retrieved Feature Package from the DB");
        return true;
    }

    /**
     * This method is for fetching Fmcg Device for Fmcg Subscriber
     * 
     * @return
     */
    public boolean getFmcgDeviceForFmcgSubscriber()
    {
        try
        {
            //retrieve FmcgSubscriber details to get the FmcgDeviceId(fmcg_device_id)
            boolean ret = getFmcgSubscriberDetailsById();
            if (!ret)
            {
                setStatus(InvErrorCode.INV_FAILURE);
                log.info("FAILURE in getFeaturePackageForFmcgSubscriber");
                return false;
            }
            log.info("In the Inventry, the Fmcg Device Id for FmcgSubscriber = " + fmcgSubId + " is -> "
                    + fmcgDeviceId);
            //if PublicTnPoolId is valid, query the PublicTnPool class for details.
            FmcgDevice fmcgDeviceObj = new FmcgDevice(connection);
            fmcgDeviceObj.setFmcgDeviceId(new Long(fmcgDeviceId).intValue());
            ret = fmcgDeviceObj.getFmcgDeviceDetailsById();
            if (!ret)
            {
                setStatus(InvErrorCode.INV_FAILURE);
                log.info("FAILURE in fmcgDeviceObj.getFmcgDeviceDetailsById() returned false in getFmcgDeviceForFmcgSubscriber");
                return false;
            }
            setFmcgDeviceObj((FmcgDeviceBean) fmcgDeviceObj);
        }
        catch (Exception e)
        {
            e.printStackTrace();
            setStatus(InvErrorCode.ERROR_GETTING_FMCG_DEVICE_SUBSCRIBER);
            log.info("FAILURE in getDetails KeyGroupTn");
            return false;
        }
        setStatus(InvErrorCode.SUCCESS);
        log.info("Successfully retrieved Fmcg Device from the DB");
        return true;
    }

    /**
     * This method is for fetching Vendor DialPlan for Fmcg Subscriber
     * 
     * @return boolean
     */
    public boolean getFmcgVendorDialPlanForFmcgSubscriber()
    {
        try
        {
            //retrieve FmcgSubscriber details to get the FmcgVendorDialPlanId(fmcg_dial_plan_id)
            boolean ret = getFmcgSubscriberDetailsById();
            if (!ret)
            {
                setStatus(InvErrorCode.INV_FAILURE);
                log.info("FAILURE in getDetailsByGroupTnId KeyGroupTn. KeyGroupTn.getDetailsByGroupTnId returned false in getFeaturePackageForFmcgSubscriber");
                return false;
            }
            log.info("In the Inventry, the Fmcg Device Id for FmcgSubscriber = " + fmcgSubId + " is -> "
                    + fmcgDeviceId);
            //if DialplanId is valid, query the VendorDialplan class for details.
            FmcgVendorDialplan fmcgVendorDialplanObj = new FmcgVendorDialplan(connection);
            fmcgVendorDialplanObj.setFmcgDialPlanId(new Long(fmcgDialPlanId).intValue());
            ret = fmcgVendorDialplanObj.getFmcgVendorDialplanDetailsById();
            if (!ret)
            {
                setStatus(InvErrorCode.INV_FAILURE);
                log.info("FAILURE in fmcgVendorDialplanObj.getFmcgDeviceDetailsById() returned false in getFmcgDeviceForFmcgSubscriber");
                return false;
            }
            setFmcgVendorDialPlanObj((FmcgVendorDialplanBean) fmcgVendorDialplanObj);
        }
        catch (Exception e)
        {
            e.printStackTrace();
            setStatus(InvErrorCode.ERROR_GETTING_VENDOR_DIAL_PLAN_SUBSCRIBER);
            log.info("FAILURE in getDetails KeyGroupTn");
            return false;
        }
        setStatus(InvErrorCode.SUCCESS);
        log.info("Successfully retrieved Fmcg Vendor DialPlan from the DB");
        return true;
    }

    /**
     * The wrapper method to Add Feature Package to a Fmcg Subscriber
     * 
     * @return boolean
     */
    public boolean addFeaturePackageToFmcgSubscriber()
    {
        try
        {
            FeaturePackage featurePackage = new FeaturePackage(featurePackageObj, connection);

            if (!featurePackage.addFeaturesToPackage())
            {
                setStatus(InvErrorCode.INTERNAL_ERROR);
                log.info(featurePackage.getStatusDesc());
                return false;
            }
            /*DBTblFeaturePkg featurePkgDbBean = new DBTblFeaturePkg();
            featurePkgDbBean.setFeaturePkgId(featurePackage.getFeaturePackageId());
            featurePkgDbBean.setFeature(featurePackage.getFeaturePackageName());
            if (featurePackage.getModifiedBy() != null && !"".equals(featurePackage.getModifiedBy()))
                featurePkgDbBean.setModifiedBy(featurePkgDbBean.getModifiedBy());
            else
                featurePkgDbBean.setModifiedBy("ESAP_INV");
            featurePkgDbBean.setLastModifiedDate(new Timestamp(System.currentTimeMillis()));
            featurePkgDbBean.whereFeaturePkgIdEQ(getFeaturePkgId());*/
            //groupTnDbBean.updateSpByWhere(dbCon);
          /*  if (featurePkgDbBean.updateSpByWhere(connection) <= 0)
            {
                return false;
            }*/

        }
        catch (Exception e)
        {
            e.printStackTrace();
            setStatus(InvErrorCode.ERROR_ADDING_PUBLICTNPOOL_TO_GROUP_TN);
            log.info("FAILURE in addFeaturePackageToFmcgSubscriber.");
            return false;
        }
        setStatus(InvErrorCode.SUCCESS);
        return true;
    }

    /**
     * The wrapper method to Add Fmcg Device to a Fmcg Subscriber
     * 
     * @return boolean
     */
    public boolean addFmcgDeviceToFmcgSubscriber()
    {
        try
        {
            FmcgDevice fmcgDevice = new FmcgDevice(connection, fmcgDeviceObj);

            if (!fmcgDevice.addFmcgDevice())
            {
                setStatus(InvErrorCode.INTERNAL_ERROR);
                log.info(fmcgDevice.getStatusDesc());
                return false;
            }
            DBTblFmcgDevice fmcgDeviceDbBean = new DBTblFmcgDevice();
            fmcgDeviceDbBean.setFmcgDeviceId(fmcgDeviceObj.getFmcgDeviceId());
            fmcgDeviceDbBean.setFmcgType(fmcgDeviceObj.getFmcgType());
            if (fmcgDeviceObj.getModifiedBy() != null && !"".equals(fmcgDeviceObj.getModifiedBy()))
                fmcgDeviceDbBean.setModifiedBy(fmcgDeviceDbBean.getModifiedBy());
            else
                fmcgDeviceDbBean.setModifiedBy("ESAP_INV");
            fmcgDeviceDbBean.setLastModifiedDate(new Timestamp(System.currentTimeMillis()));
            fmcgDeviceDbBean.whereFmcgDeviceIdEQ((int)getFmcgDeviceId());
            //groupTnDbBean.updateSpByWhere(dbCon);
            if (fmcgDeviceDbBean.updateSpByWhere(connection) <= 0)
            {
                return false;
            }
        }
        catch (Exception e)
        {
            e.printStackTrace();
            setStatus(InvErrorCode.ERROR_ADDING_FMCG_DEVICE_TO_FMCG_SUBSCRIBER);
            log.info("FAILURE in addFmcgDeviceToFmcgSubscriber()");
            return false;
        }
        setStatus(InvErrorCode.SUCCESS);
        return true;
    }

    /**
     * The wrapper method to Add Vendor DialPlan to a Fmcg Subscriber
     * 
     * @throws SQLException
     *             If any DB Error occurs.
     */
    public boolean addFmcgVendorDialPlanToFmcgSubscriber()
    {
    	try
        {
            FmcgVendorDialplan fmcgVendorDialplan = new FmcgVendorDialplan(connection, fmcgVendorDialPlanObj);

            if (!fmcgVendorDialplan.addFmcgVendorDialplan())
            {
                setStatus(InvErrorCode.INTERNAL_ERROR);
                log.info(fmcgVendorDialplan.getStatusDesc());
                return false;
            }
            DBTblFmcgVendorDialplan fmcgVendorDialplanDbBean = new DBTblFmcgVendorDialplan();
            fmcgVendorDialplanDbBean.setFmcgDialPlanId(fmcgVendorDialplan.getFmcgDialPlanId());
            fmcgVendorDialplanDbBean.setFmcgType(fmcgVendorDialplan.getFmcgType());
            if (fmcgVendorDialplan.getModifiedBy() != null && !"".equals(fmcgVendorDialplan.getModifiedBy()))
                fmcgVendorDialplanDbBean.setModifiedBy(fmcgVendorDialplanDbBean.getModifiedBy());
            else
                fmcgVendorDialplanDbBean.setModifiedBy("ESAP_INV");
            fmcgVendorDialplanDbBean.setLastModifiedDate(new Timestamp(System.currentTimeMillis()));
            fmcgVendorDialplanDbBean.whereFmcgDialPlanIdEQ(getFmcgDialPlanId());
            if (fmcgVendorDialplanDbBean.updateSpByWhere(connection) <= 0)
            {
                return false;
            }

        }
        catch (Exception e)
        {
            e.printStackTrace();
            setStatus(InvErrorCode.ERROR_ADDING_FMCG_DIAL_PLAN_TO_FMCG_SUBSCRIBER);
            log.info("FAILURE in addFmcgVendorDialPlanToFmcgSubscriber.");
            return false;
        }
        setStatus(InvErrorCode.SUCCESS);
        return true;
    }

    /**
     * This method is for deleting Fmcg Subscriber entry from DB
     * 
     * @return
     */
    public boolean deleteFromDB() throws SQLException, Exception
    {
       // try
        //{
            if (fmcgSubId <= 0)
            {
                setStatus(InvErrorCode.INVALID_INPUT);
                log.info("FAILURE in deleteFromDB FmcgSubscriber. fmcgSubId missing.");
                return false;
            }
            //deleteExcludedFeaturesForGroupTn();
            TblFmcgSubscriberQuery fmcgSubscriberQuery = new TblFmcgSubscriberQuery();
            fmcgSubscriberQuery.whereFmcgSubIdEQ(getFmcgSubId());
            fmcgSubscriberQuery.query(connection);
            int fmcgSubId = (int) fmcgSubscriberQuery.getDbBean(0).getFmcgSubId();
            DBTblFmcgSubscriber fmcgSubscriberDbBean = new DBTblFmcgSubscriber();
            fmcgSubscriberDbBean.whereFmcgSubIdEQ(getFmcgSubId());
            if (fmcgSubscriberDbBean.deleteByWhere(connection) <= 0)
            {
                setStatus(InvErrorCode.ERROR_DELETING_FMCG_SUBSCRIBER);
                log.info("Error while deleting PBXGroupTn.");
                return false;
            }
            FeaturePackage featurePackage = new FeaturePackage(connection);
            featurePackage.setFeaturePackageId((int)featurePkgId);
            if (rollbackFlag)
            {
                if (!featurePackage.deleteFeaturesFromPackage())
                {
                    setStatus(InvErrorCode.ERROR_DELETING_FEATURE_PKG_FROM_FMCG_SUBSCRIBER);
                    log.info("Error while deleting FEATURE PKG from FMCG SUBSCRIBER.");
                    return false;
                }
            } else
            {
                //featurePackage.setStatusDesc(VzbVoipEnum.featurePackageStatus.AVAILABLE);
                featurePackage.setActiveInd(VzbVoipEnum.ActiveInd.ACTIVE);
                if (featurePackage.updateFeaturesToPackage())
                {
                    setStatus(InvErrorCode.ERROR_DELETING_FEATURE_PKG_FROM_FMCG_SUBSCRIBER);
                    log.info("Error while deleting Public Tn Poll from PBXGroupTn.");
                    return false;
                }

            }
        /*}
        catch (SQLException s)
        {
            setStatus(InvErrorCode.DB_EXCEPTION);
            log.info("DB_FAILURE in deleteFromDB FmcgSubscriber");
            s.printStackTrace();
            return false;
        }*/
        setStatus(InvErrorCode.SUCCESS);
        return true;
    }

    /**
     * This method is for deleting the Feature Package for Fmcg Subscriber
     * 
     * @throws SQLException
     */
    public void deleteFeaturePackageForFmcgSubscriber() throws SQLException,Exception
    {

        TblFmcgSubscriberQuery fmcgSubscriberQuery = new TblFmcgSubscriberQuery();
        fmcgSubscriberQuery.whereFmcgSubIdEQ(getFmcgSubId());
        fmcgSubscriberQuery.query(connection);

        FeaturePackage featurePackage = new FeaturePackage(connection);
        for (int i = 0; i < fmcgSubscriberQuery.size(); i++)
        {
            featurePackage.setFeaturePackageId((int) fmcgSubscriberQuery.getDbBean(i).getFeaturePkgId());
            if (rollbackFlag)
            {
                if (!featurePackage.deleteFeaturesFromPackage())
                {
                    setStatus(InvErrorCode.ERROR_DELETING_FEATURE_PKG_FROM_FMCG_SUBSCRIBER);
                    log.info("Error while deleting FEATURE_PKG from FMCG_SUBSCRIBER.");
                }

            } else
            {
                //featurePackage.setTnStatus(VzbVoipEnum.featurePackageStatus.AVAILABLE);
                featurePackage.setActiveInd(VzbVoipEnum.ActiveInd.ACTIVE);
                if (!featurePackage.updateFeaturesToPackage())
                {
                    setStatus(InvErrorCode.ERROR_DELETING_FEATURE_PKG_FROM_FMCG_SUBSCRIBER);
                    log.info("Error while deleting Public Tn Poll from PBXGroupTn.");
                }
            }
        }
    }

    /**
     * This method is for deleting the Fmcg Device for Fmcg Subscriber
     * 
     * @throws SQLException
     */
    public void deleteFmcgDeviceForFmcgSubscriber() throws SQLException, Exception
    {

        TblFmcgSubscriberQuery fmcgSubscriberQuery = new TblFmcgSubscriberQuery();
        fmcgSubscriberQuery.whereFmcgSubIdEQ(getFmcgSubId());
        fmcgSubscriberQuery.query(connection);

        FmcgDevice fmcgDevice = new FmcgDevice(connection);
        for (int i = 0; i < fmcgSubscriberQuery.size(); i++)
        {
            fmcgDevice.setFmcgDeviceId((int) fmcgSubscriberQuery.getDbBean(i).getFeaturePkgId());
            if (rollbackFlag)
            {
                if (!fmcgDevice.deleteFmcgDevice())
                {
                    setStatus(InvErrorCode.ERROR_DELETING_FMCG_DEVICE_FROM_FMCG_SUBSCRIBER);
                    log.info("Error while deleting FEATURE_PKG from FMCG_SUBSCRIBER.");
                }

            } else
            {
                //fmcgDevice.setTnStatus(VzbVoipEnum.featurePackageStatus.AVAILABLE);
                //fmcgDevice.setActiveInd(VzbVoipEnum.ActiveInd.ACTIVE);
                if (!fmcgDevice.updateFmcgDevice())
                {
                    setStatus(InvErrorCode.ERROR_DELETING_FMCG_DEVICE_FROM_FMCG_SUBSCRIBER);
                    log.info("Error while deleting Public Tn Poll from PBXGroupTn.");
                }
            }
        }
    }

    /**
     * This method is for deleting the Fmcg Vendor DialPlan for Fmcg Subscriber
     * 
     * @throws SQLException
     */
    public void deleteFmcgVendorDialPlanForFmcgSubscriber() throws SQLException, Exception
    {

        TblFmcgSubscriberQuery fmcgSubscriberQuery = new TblFmcgSubscriberQuery();
        fmcgSubscriberQuery.whereFmcgSubIdEQ(getFmcgSubId());
        fmcgSubscriberQuery.query(connection);

        FmcgVendorDialplan fmcgVendorDialplan = new FmcgVendorDialplan(connection);
        for (int i = 0; i < fmcgSubscriberQuery.size(); i++)
        {
            fmcgVendorDialplan.setFmcgDialPlanId((int) fmcgSubscriberQuery.getDbBean(i).getFmcgDialPlanId());
            if (rollbackFlag)
            {
                if (!fmcgVendorDialplan.deleteFromDB())
                {
                    setStatus(InvErrorCode.ERROR_DELETING_FEATURE_PKG_FROM_FMCG_SUBSCRIBER);
                    log.info("Error while deleting FEATURE_PKG from FMCG_SUBSCRIBER.");
                }

            } else
            {
                //fmcgVendorDialplan.setTnStatus(VzbVoipEnum.dialplanStatus.AVAILABLE);
                fmcgVendorDialplan.setActiveInd(VzbVoipEnum.ActiveInd.ACTIVE);
                if (!fmcgVendorDialplan.updateFmcgVendorDialPlan())
                {
                    setStatus(InvErrorCode.ERROR_DELETING_FEATURE_PKG_FROM_FMCG_SUBSCRIBER);
                    log.info("Error while deleting Public Tn Poll from PBXGroupTn.");
                }
            }
        }
    }

    /**
     * This method is for updating the Fmcg Subscriber
     * 
     * @return
     */
    public boolean updateFmcgSubscriber()
    {
    	log.info("In updateFmcgSubscriber Method====>."+fmcgSubId);
        try
        {
            if (fmcgSubId < 0)
            {
                setStatus(InvErrorCode.INVALID_INPUT);
                log.info("FAILURE in updateFmcgSubscriber fmcgSubId missing.");
                return false;
            }
            DBTblFmcgSubscriber fmcgSubscriberDb = getFmcgSubscriberInfoToUpdate();
            fmcgSubscriberDb.whereFmcgSubIdEQ(getFmcgSubId());
            log.info("fmg subId" + fmcgSubscriberDb.getPortalPin());
            log.info("fmg subId" +  connection);
            log.info("fmg subId" +  getFmcgSubId());
            log.info("updateNeeded" +  updateNeeded);
			if(updateNeeded)
			{
            	if (fmcgSubscriberDb.updateSpByWhere(connection) <= 0)
                return false;
			}
        }
        catch (SQLException s)
        {
            setStatus(InvErrorCode.DB_EXCEPTION);
            log.info("DB_FAILURE in updateFmcgDevice FmcgDevice");
            s.printStackTrace();
            return false;
        }
        setStatus(InvErrorCode.SUCCESS);
        return true;
    }

    /**
     * The wrapper method to Add FeaturePackage to a FmcgSubscriber
     * 
     * @throws SQLException
     *             If any DB Error occurs.
     */
    public boolean updateFeaturePackageToFmcgSubscriber()
    {
        try
        {
            FeaturePackage featurePackage = new FeaturePackage(featurePackageObj, connection);
            //publicTnPool.setTnPoolId(new Long(getTnPoolId()).intValue());
            if (!featurePackage.updateFeaturesToPackage())
            {
                setStatus(InvErrorCode.INTERNAL_ERROR);
                ////setStatusDesc(publicTnPool.getStatusDesc());
                log.info(featurePackage.getStatusDesc());
                return false;
            }
        }
        catch (Exception e)
        {
            e.printStackTrace();
            setStatus(InvErrorCode.ERROR_MODIFYING_FEATURE_PKG_TO_FMCG_SUBSCRIBER);
            ////setStatusDesc("FAILURE in updateFeaturePackageToFmcgSubscriber.");
            log.info("FAILURE in updateFeaturePackageToFmcgSubscriber.");
            return false;
        }
        setStatus(InvErrorCode.SUCCESS);
        ////setStatusDesc("Successfully updated PublicTnPool to PBXGroupTn");
        return true;
    }

    /**
     * The wrapper method to Add Fmcg Device to a FmcgSubscriber
     * 
     * @throws SQLException
     *             If any DB Error occurs.
     */
    public boolean updateFmcgDeviceToFmcgSubscriber()
    {
        try
        {
            FmcgDevice fmcgDevice = new FmcgDevice(connection, fmcgDeviceObj);
            //publicTnPool.setTnPoolId(new Long(getTnPoolId()).intValue());
            if (!fmcgDevice.updateFmcgDevice())
            {
                setStatus(InvErrorCode.INTERNAL_ERROR);
                ////setStatusDesc(publicTnPool.getStatusDesc());
                log.info(fmcgDevice.getStatusDesc());
                return false;
            }
        }
        catch (Exception e)
        {
            e.printStackTrace();
            setStatus(InvErrorCode.ERROR_MODIFYING_FMCG_DEVICE_TO_FMCG_SUBSCRIBER);
            log.info("FAILURE in updateFmcgDeviceToFmcgSubscriber.");
            return false;
        }
        setStatus(InvErrorCode.SUCCESS);
        return true;
    }

    /**
     * The wrapper method to Add FeaturePackage to a FmcgSubscriber
     * 
     * @throws SQLException
     *             If any DB Error occurs.
     */
    public boolean updateVendorDialPlanToFmcgSubscriber()
    {
        try
        {
            FmcgVendorDialplan fmcgVendorDialplan = new FmcgVendorDialplan(connection, fmcgVendorDialPlanObj);
            //publicTnPool.setTnPoolId(new Long(getTnPoolId()).intValue());
            if (!fmcgVendorDialplan.updateFmcgVendorDialPlan())
            {
                setStatus(InvErrorCode.INTERNAL_ERROR);
                ////setStatusDesc(publicTnPool.getStatusDesc());
                log.info(fmcgVendorDialplan.getStatusDesc());
                return false;
            }
        }
        catch (Exception e)
        {
            e.printStackTrace();
            setStatus(InvErrorCode.ERROR_MODIFYING_FMCG_DIAL_PLAN_TO_FMCG_SUBSCRIBER);
            ////setStatusDesc("FAILURE in updateVendorDialPlanToFmcgSubscriber.");
            log.info("FAILURE in updateVendorDialPlanToFmcgSubscriber.");
            return false;
        }
        setStatus(InvErrorCode.SUCCESS);
        return true;
    }

	public List<FmcgSubscriber> getFmcgSubscriberListByDeviceId()
	{
		log.info("Entering FmcgSubscriber::getFmcgSubscriberListByDeviceId");
		List<FmcgSubscriber> fmcgSubList = new ArrayList<FmcgSubscriber>();
		try
		{
			TblFmcgSubscriberQuery fmcgSubscriberQuery = new TblFmcgSubscriberQuery();
			log.info("Querying Subscriber Details for Device id: " + getFmcgDeviceId());
			fmcgSubscriberQuery.whereFmcgDeviceIdEQ(getFmcgDeviceId());
			fmcgSubscriberQuery.query(connection);
			if (fmcgSubscriberQuery.size() <= 0)
			{
				log.info("Failed to Retrieve FmcgSubscriber");
				return fmcgSubList;
			}

			for(int i=0; i<fmcgSubscriberQuery.size(); i++)
			{
				TblFmcgSubscriberDbBean fmcgSubscriberBean = fmcgSubscriberQuery.getDbBean(i);
				FmcgSubscriber fmcgSub = new FmcgSubscriber(connection);
				fmcgSub.setFmcgSubId(fmcgSubscriberBean.getFmcgSubId());
				fmcgSub.setMobileNumber(fmcgSubscriberBean.getMobileNumber());
				fmcgSub.setFeaturePkgId(fmcgSubscriberBean.getFeaturePkgId());
				fmcgSub.setOutboundAlterNum(fmcgSubscriberBean.getOutboundAlternateNumber());
				fmcgSub.setFmcgDeviceId(fmcgSubscriberBean.getFmcgDeviceId());
				fmcgSub.setFmcgType(fmcgSubscriberBean.getFmcgType());
				fmcgSub.setFmcgDialPlanId((int)fmcgSubscriberBean.getFmcgDialPlanId());
				fmcgSub.setPortalPin(fmcgSubscriberBean.getPortalPin());
				fmcgSub.setNotificationMethod(fmcgSubscriberBean.getNotificationMethod());
				fmcgSub.setNotificationEmail(fmcgSubscriberBean.getNotificationEmail());
				fmcgSub.setUniversalClid(fmcgSubscriberBean.getUniversalClid());
				fmcgSub.setAnsConfirmation(fmcgSubscriberBean.getAnswerConfirmation());
				fmcgSub.setActRetryCount(fmcgSubscriberBean.getActivationRetryCount());
				fmcgSub.setActDate(fmcgSubscriberBean.getActivationDate());
				fmcgSub.setImei(fmcgSubscriberBean.getImei());
				fmcgSub.setEas(fmcgSubscriberBean.getEas());
				fmcgSubList.add(fmcgSub);
				//FMCg Phase II
				fmcgSub.setRequestType(fmcgSubscriberBean.getRequestType());
                fmcgSub.setDevicePin(fmcgSubscriberBean.getDevicePin());
                fmcgSub.setBesEnabled(fmcgSubscriberBean.getBesEnabled());
                fmcgSub.setReadyStatus(fmcgSubscriberBean.getReadyStatus());
                fmcgSub.setReadyDate(fmcgSubscriberBean.getReadyDate());
                fmcgSub.setNotifyConfigUpdate(fmcgSubscriberBean.getNotifyConfigUpdate());
                fmcgSub.setNotifyInstall(fmcgSubscriberBean.getNotifyInstall());
			}
		}
		catch (Exception s)
		{
			s.printStackTrace();
			setStatus(InvErrorCode.DB_EXCEPTION);
			return fmcgSubList;
		}
		setStatus(InvErrorCode.SUCCESS);
		log.info("Retrieved [" + fmcgSubList.size() + "] Fmcg Subscribers by Device Id [ " + getFmcgDeviceId() + "]");
		return fmcgSubList;
	}

    /**
     * This method is for getting Fmcg Subscriber for updation
     * 
     * @return
     */
    private DBTblFmcgSubscriber getFmcgSubscriberInfoToUpdate()
    {
		updateNeeded = false;
        DBTblFmcgSubscriber fmcgSubscriberDb = new DBTblFmcgSubscriber();
        FmcgSubscriberBean defFmcgSubscriberBean = new FmcgSubscriberBean();
        FmcgSubscriber inputFmcgSubscriber = this;
        fmcgSubscriberDb.setFmcgSubId(fmcgSubId);

        if (inputFmcgSubscriber.getActDate() != null
                && !inputFmcgSubscriber.getActDate().equals(defFmcgSubscriberBean.getActDate()))
        {
			updateNeeded = true;
            fmcgSubscriberDb.setActivationDate(inputFmcgSubscriber.getActDate());
        }
        if (inputFmcgSubscriber.getFmcgType() != defFmcgSubscriberBean.getFmcgType())
        {
			updateNeeded = true;
            fmcgSubscriberDb.setFmcgType(inputFmcgSubscriber.getFmcgType());
        }
        if (inputFmcgSubscriber.getActRetryCount() != defFmcgSubscriberBean.getActRetryCount())
        {
			updateNeeded = true;
			if(inputFmcgSubscriber.getActRetryCount() !=0 )
				fmcgSubscriberDb.setActivationRetryCount(inputFmcgSubscriber.getActRetryCount());
			else
				fmcgSubscriberDb.setActivationRetryCountNull();
        }
        if (inputFmcgSubscriber.getAnsConfirmation() != defFmcgSubscriberBean.getAnsConfirmation())
        {
			updateNeeded = true;
			log.info("UPDATING Answer Confirmation : "+inputFmcgSubscriber.getAnsConfirmation());
			fmcgSubscriberDb.setAnswerConfirmation(inputFmcgSubscriber.getAnsConfirmation());
        }
		if (inputFmcgSubscriber.getFmcgDialPlanId() != defFmcgSubscriberBean.getFmcgDialPlanId())
        {
            updateNeeded = true;
            if(inputFmcgSubscriber.getFmcgDialPlanId()!=0 )
            	fmcgSubscriberDb.setFmcgDialPlanId(inputFmcgSubscriber.getFmcgDialPlanId());
            else
            	fmcgSubscriberDb.setFmcgDialPlanIdNull();
        }
		if (inputFmcgSubscriber.getFmcgDeviceId() != defFmcgSubscriberBean.getFmcgDeviceId())
        {
            updateNeeded = true;
            if(inputFmcgSubscriber.getFmcgDeviceId() !=0 )
            	fmcgSubscriberDb.setFmcgDeviceId(inputFmcgSubscriber.getFmcgDeviceId());
            else
            	fmcgSubscriberDb.setFmcgDeviceIdNull();
        }


        if (inputFmcgSubscriber.getEas() != null
                && !inputFmcgSubscriber.getEas().equals(defFmcgSubscriberBean.getEas()))
        {
        	if(! "".equals(inputFmcgSubscriber.getEas()))
        			fmcgSubscriberDb.setEas(inputFmcgSubscriber.getEas());
        	else
        		 fmcgSubscriberDb.setEasNull();
			updateNeeded = true;
        }
        if (inputFmcgSubscriber.getImei() != null
                && !inputFmcgSubscriber.getImei().equals(defFmcgSubscriberBean.getImei()))
        {
        	if(! "".equals(inputFmcgSubscriber.getImei()))
        		fmcgSubscriberDb.setImei(inputFmcgSubscriber.getImei());
        	else
        		fmcgSubscriberDb.setImeiNull();
			updateNeeded = true;
        }
		log.info("In base class Monile no:"+inputFmcgSubscriber.getMobileNumber());
        if (inputFmcgSubscriber.getMobileNumber() != null
                && !inputFmcgSubscriber.getMobileNumber().equals(defFmcgSubscriberBean.getMobileNumber()))
        {
        	if(! "".equals(inputFmcgSubscriber.getMobileNumber()))
        		fmcgSubscriberDb.setMobileNumber(inputFmcgSubscriber.getMobileNumber());
        	else
        		fmcgSubscriberDb.setMobileNumberNull();
			updateNeeded = true;
        }
        if (inputFmcgSubscriber.getNotificationEmail() != null
                && !inputFmcgSubscriber.getNotificationEmail().equals(defFmcgSubscriberBean.getNotificationEmail()))
        {
        	if(! "".equals(inputFmcgSubscriber.getNotificationEmail()))
        		fmcgSubscriberDb.setNotificationEmail(inputFmcgSubscriber.getNotificationEmail());
        	else
        		fmcgSubscriberDb.setNotificationEmailNull();
			updateNeeded = true;
        }

		log.info("In base class Alt NUm no:"+inputFmcgSubscriber.getOutboundAlterNum());
        if (inputFmcgSubscriber.getOutboundAlterNum() != null
                && !inputFmcgSubscriber.getOutboundAlterNum().equals(defFmcgSubscriberBean.getOutboundAlterNum()))
        {
        	if(! "".equals(inputFmcgSubscriber.getOutboundAlterNum()))
        		fmcgSubscriberDb.setOutboundAlternateNumber(inputFmcgSubscriber.getOutboundAlterNum());
        	else
        		fmcgSubscriberDb.setOutboundAlternateNumberNull();
			updateNeeded = true;
        }
		log.info("In base class Portal Pin:"+inputFmcgSubscriber.getPortalPin());
        if (inputFmcgSubscriber.getPortalPin() != null
                && !inputFmcgSubscriber.getPortalPin().equals(defFmcgSubscriberBean.getPortalPin()))
        {
        	if(! "".equals(inputFmcgSubscriber.getPortalPin()))
        		fmcgSubscriberDb.setPortalPin(inputFmcgSubscriber.getPortalPin());
        	else
        		fmcgSubscriberDb.setPortalPinNull();
			updateNeeded = true;
        }
        if (inputFmcgSubscriber.getNotificationMethod() != defFmcgSubscriberBean.getNotificationMethod())
        {
        	if(inputFmcgSubscriber.getNotificationMethod() !=0 )
        		fmcgSubscriberDb.setNotificationMethod(inputFmcgSubscriber.getNotificationMethod());
        	else
        		fmcgSubscriberDb.setNotificationMethodNull();
			updateNeeded = true;
        }
		if (inputFmcgSubscriber.getUniversalClid() != defFmcgSubscriberBean.getUniversalClid())
        {
			if(inputFmcgSubscriber.getUniversalClid() != 0 )
				fmcgSubscriberDb.setUniversalClid(inputFmcgSubscriber.getUniversalClid());
			else
				fmcgSubscriberDb.setUniversalClidNull();
			updateNeeded = true;
        }

        if (inputFmcgSubscriber.getEnvOrderId() != defFmcgSubscriberBean.getEnvOrderId())
        {
            //fmcgSubscriberDb.setEnvOrderId(inputFmcgSubscriber.getEnvOrderId());
        }

        if (inputFmcgSubscriber.getFeaturePkgId() != defFmcgSubscriberBean.getFeaturePkgId())
        {
			updateNeeded = true;
			if(defFmcgSubscriberBean.getFeaturePkgId() !=0 )
				fmcgSubscriberDb.setFeaturePkgId(inputFmcgSubscriber.getFeaturePkgId());
			else
				fmcgSubscriberDb.setFeaturePkgIdNull();
        }
       /* if (inputFmcgSubscriber.getCreatedBy() != null && !("".equalsIgnoreCase(inputFmcgSubscriber.getCreatedBy())))
            fmcgSubscriberDb.setCreatedBy(getCreatedBy());
        else
            fmcgSubscriberDb.setCreatedBy("ESAP_INV");

        fmcgSubscriberDb.setCreateDate(new Timestamp(System.currentTimeMillis()));
		*/

        if (inputFmcgSubscriber.getModifiedBy() != null && !("".equalsIgnoreCase(inputFmcgSubscriber.getModifiedBy())))
            fmcgSubscriberDb.setModifiedBy(getModifiedBy());
        else
            fmcgSubscriberDb.setModifiedBy("ESAP_INV");

        fmcgSubscriberDb.setLastModifiedDate(new Timestamp(System.currentTimeMillis()));
        
        //FMCg Phase II
        if (inputFmcgSubscriber.getRequestType() != defFmcgSubscriberBean.getRequestType()){
            fmcgSubscriberDb.setRequestType(inputFmcgSubscriber.getRequestType());
            updateNeeded = true;
        }
        
        if (inputFmcgSubscriber.getDevicePin() != null
                && !inputFmcgSubscriber.getDevicePin().equals(defFmcgSubscriberBean.getDevicePin()))
        {
                if(! "".equals(inputFmcgSubscriber.getDevicePin()))
                        fmcgSubscriberDb.setDevicePin(inputFmcgSubscriber.getDevicePin());
                else
                        fmcgSubscriberDb.setDevicePinNull();
                        updateNeeded = true;
        }
        
        if (inputFmcgSubscriber.getBesEnabled() != null && !inputFmcgSubscriber.getBesEnabled().equals(defFmcgSubscriberBean.getBesEnabled())){
            if(! "".equals(inputFmcgSubscriber.getBesEnabled()))
                    fmcgSubscriberDb.setBesEnabled(inputFmcgSubscriber.getBesEnabled());
            updateNeeded = true;
        }
        
        if (inputFmcgSubscriber.getReadyStatus() != defFmcgSubscriberBean.getReadyStatus()){
            if (inputFmcgSubscriber.getReadyStatus() != -1)
                    fmcgSubscriberDb.setReadyStatus(inputFmcgSubscriber.getReadyStatus());
            if(inputFmcgSubscriber.getReadyStatus() == VzbVoipEnum.FmcgReadyStatusType.NONE)
            	fmcgSubscriberDb.setReadyDateNull();
            updateNeeded = true;
        }
        
        if (inputFmcgSubscriber.getReadyDate() != null && !inputFmcgSubscriber.getReadyDate().equals(defFmcgSubscriberBean.getReadyDate())){
        	fmcgSubscriberDb.setReadyDate(inputFmcgSubscriber.getReadyDate());
        	updateNeeded = true;
        }
        
        if (inputFmcgSubscriber.getNotifyConfigUpdate() != null && 
        		!inputFmcgSubscriber.getNotifyConfigUpdate().equals(defFmcgSubscriberBean.getNotifyConfigUpdate())){
        	fmcgSubscriberDb.setNotifyConfigUpdate(inputFmcgSubscriber.getNotifyConfigUpdate());
        	updateNeeded = true;
        }
        
        if (inputFmcgSubscriber.getNotifyInstall() != null && 
        		!inputFmcgSubscriber.getNotifyInstall().equals(defFmcgSubscriberBean.getNotifyInstall())){
        	fmcgSubscriberDb.setNotifyInstall(inputFmcgSubscriber.getNotifyInstall());
        	updateNeeded = true;
        }

        log.info("updateNeeded:"+updateNeeded);
        return fmcgSubscriberDb;

    }
    
    /**
     * This method is for incrementing ActivationRetrCount of Fmcg Subscriber.
     * 
     * @return
     */
    
    public  long  getIncrActRetrCount( Connection connection,int fmcgSubId) {
     
    try {	
		TblFmcgSubscriberQuery fmcgSubscriberQuery = new TblFmcgSubscriberQuery();
		log.info("Querying FmcgSubscriber Details for  FmcgId: " + fmcgSubId);
		fmcgSubscriberQuery.whereFmcgSubIdEQ(fmcgSubId);
		fmcgSubscriberQuery.query(connection);
		if (fmcgSubscriberQuery.size() <= 0)
		{
				return 0;
		}

		TblFmcgSubscriberDbBean fmcgSubscriberBean = fmcgSubscriberQuery.getDbBean(0);
        DBTblFmcgSubscriber fmcgSubscriberDb = new DBTblFmcgSubscriber();
        fmcgSubscriberDb.setActivationRetryCount(fmcgSubscriberBean.getActivationRetryCount() +  1);
        fmcgSubscriberDb.whereFmcgSubIdEQ(fmcgSubId);
        if (fmcgSubscriberDb.updateSpByWhere(connection) <= 0) {
            return fmcgSubscriberBean.getActivationRetryCount();
        } else	{
        	connection.commit();
        	return (fmcgSubscriberBean.getActivationRetryCount() +  1); 
        }	
        
    }  catch (Exception ee)	 {
    	log.info("Querying FmcgSubscriber Details failed  for FmcgId : " + fmcgSubId);
    	return 0;
    }
    	
    }
}
