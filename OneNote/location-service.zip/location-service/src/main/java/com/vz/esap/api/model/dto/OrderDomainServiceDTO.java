package com.vz.esap.api.model.dto;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import org.springframework.context.ApplicationContextException;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.vz.esap.api.model.ResponseObject;
import com.vz.esap.api.model.ordering.EntityBatch;
import com.vz.esap.api.model.ordering.OrderHeader;

public class OrderDomainServiceDTO implements Serializable {
	
	private static final long serialVersionUID = -4036268784425336034L;
	
	private OrderHeader orderHeader;
	
	// Map<EntityType, Map<entityKey,Map<ParamKey,ParamInfo> 
	// Map<String, Map<String,Map<String,ParamDetail>>> entityTypeMap;
	private Map<String, EntityBatch> entityTypeMap;
	private ResponseObject responseObj;

	public OrderDomainServiceDTO(OrderDomainServiceDTOBuilder orderDomainServiceDTOBuilder) {
		this.orderHeader = orderDomainServiceDTOBuilder.orderHeader;
		this.entityTypeMap = orderDomainServiceDTOBuilder.entityTypeMap;
	}

	public OrderHeader getOrderHeader() {
		return orderHeader;
	}

	public void setOrderHeader(OrderHeader orderHeader) {
		this.orderHeader = orderHeader;
	}

	public Map<String, EntityBatch> getEntityTypeMap() {
		
		if (this.entityTypeMap != null && (!entityTypeMap.isEmpty())){
			return entityTypeMap;
		}else{
			throw new ApplicationContextException("EntityBatch is empty , no data found for given Entity Type" );
		}
	}

	public void setEntityTypeMap(Map<String, EntityBatch> entityTypeMap) {
		this.entityTypeMap = entityTypeMap;
	}

	public ResponseObject getResponseObj() {
		return responseObj;
	}

	public void setResponseObj(ResponseObject responseObj) {
		this.responseObj = responseObj;
	}
	
		
	@Override
	public String toString() {
		Gson gson = new GsonBuilder().setPrettyPrinting().create();
		String json = gson.toJson(this);
		return json;
		
		/*StringBuilder builder = new StringBuilder();
		builder.append("\n OrderDomainServiceDTO \n [orderHeader=");
		builder.append(orderHeader);
		builder.append(", entityTypeMap=");
		builder.append(entityTypeMap);
		builder.append(", responseObj=");
		builder.append(responseObj);
		builder.append("]");
		return builder.toString();*/
	}



	public static class OrderDomainServiceDTOBuilder {
		private OrderHeader orderHeader;
		private Map<String, EntityBatch> entityTypeMap = new HashMap<>();
		
		public OrderDomainServiceDTOBuilder withOrderHeader(OrderHeader orderHeader) {
			this.orderHeader = orderHeader;
			return this;
		}
		public OrderDomainServiceDTOBuilder putEntityBatch(EntityBatch entityBatch) {
			this.entityTypeMap.put(entityBatch.getEntityType(), entityBatch);
			return this;
		}
		
		public OrderDomainServiceDTO build() {
			return new OrderDomainServiceDTO(this);
		}
		
	}

}
