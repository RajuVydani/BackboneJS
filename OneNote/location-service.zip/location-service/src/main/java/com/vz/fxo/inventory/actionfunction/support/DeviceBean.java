package com.vz.fxo.inventory.actionfunction.support;

import java.util.List;
import java.util.ArrayList;
import java.sql.Timestamp;

import esap.db.IpcomDeviceXrefDbBean;
import esap.db.IpcomGatewayInfoDbBean;

public class DeviceBean
{

	//members
	protected int deviceMapId;
	protected String enterpriseId;
	protected String locationId;
	protected String departmentId;
	protected long gwDeviceId;
	protected long sipDeviceId;
	protected String sipDeviceName;
	protected String gwDeviceName;
        protected long envOrderId;
	protected String modifiedBy;
	protected String createdBy;
	protected String deviceNameId; // Added by Diptiranjan on 25th Jan 2011
	protected long activeInd;//YesNoType
	protected Timestamp creationDate;
	protected Timestamp lastModifiedDate;
	protected List<Integer> deviceIdList;
        protected List<Long> gwDeviceIdList;
        protected List<SipDevice> sipDvObjList;
        protected List<GatewayDevice> gwDvObjList;
        protected List<String> groupIdList;
        protected List<String> subIdList;
	protected List<String> logTrail;
	protected boolean getAll;

	public DeviceBean()
	{
		this.deviceMapId = 0;
		this.enterpriseId = new String("");
		this.locationId = new String("");
		this.departmentId = new String("NONE");
		this.gwDeviceId = 0;
		this.sipDeviceId = 0;
		this.activeInd = 1;
		this.sipDeviceName = new String("");
		this.gwDeviceName = new String("");
                this.envOrderId = 0; 	
          	this.modifiedBy = new String("");
		this.createdBy = new String("");
		this.deviceNameId = new String("");
		this.creationDate = null;
		this.lastModifiedDate = null;
		this.deviceIdList = null;
		this.gwDeviceIdList = null;
		this.sipDvObjList = null;
		this.gwDvObjList = null;
		this.groupIdList = null;
		this.subIdList = null;
		this.logTrail = null;
		this.getAll = false;

		//Pls Verify
		deviceIdList = new ArrayList<Integer>();
		gwDeviceIdList = new ArrayList<Long>();
		sipDvObjList = new ArrayList<SipDevice>();
		gwDvObjList = new ArrayList<GatewayDevice>();
		logTrail = new ArrayList<String>();
	}
	
	/**
	 * Constructor
	 * @param devBean
	 */
	public DeviceBean(DeviceBean devBean)
	{
		this.deviceMapId = devBean.deviceMapId;
		this.enterpriseId = devBean.enterpriseId;
		this.locationId = devBean.locationId;
		this.activeInd = devBean.activeInd;
		this.departmentId = devBean.departmentId;
		this.gwDeviceId = devBean.gwDeviceId;
		this.sipDeviceId = devBean.sipDeviceId;
		this.sipDeviceName = devBean.sipDeviceName;
		this.gwDeviceName = devBean.gwDeviceName;
                this.envOrderId = devBean.envOrderId;	
        	this.modifiedBy = devBean.modifiedBy;
		this.createdBy = devBean.createdBy;
		this.deviceNameId = devBean.deviceNameId;
		this.creationDate = devBean.creationDate;
		this.lastModifiedDate = devBean.lastModifiedDate;
		this.deviceIdList = devBean.deviceIdList;
		this.gwDeviceIdList = devBean.gwDeviceIdList;
		this.sipDvObjList = devBean.sipDvObjList;
		this.gwDvObjList = devBean.gwDvObjList;
		this.groupIdList = devBean.groupIdList;
		this.subIdList = devBean.subIdList;
		this.logTrail = devBean.logTrail;
		this.getAll = devBean.getAll;
	}
	
	public DeviceBean(IpcomGatewayInfoDbBean gwInfoBean,IpcomDeviceXrefDbBean devXref)
	{
		if ( gwInfoBean != null ){
			this.deviceMapId = (int) gwInfoBean.getGatewayDevid();
			this.gwDeviceId = (int) gwInfoBean.getGatewayDevid();
			this.enterpriseId = gwInfoBean.getCustId();
		    if ( gwInfoBean.getLocid() == 0)
			{
				this.locationId = null;
                System.out.println("locationId = null");
			}else{	
                this.locationId = Long.toString(gwInfoBean.getLocid());
                System.out.println("locationId = "+Long.toString(gwInfoBean.getLocid()));
            }			
            //this.activeInd = gwInfoBean.get
			//this.departmentId = devBean.departmentId;
			//this.gwDeviceId = devBean.gwDeviceId;
			//this.sipDeviceId = devBean.sipDeviceId;
			//this.sipDeviceName = devBean.sipDeviceName;
			this.gwDeviceName = gwInfoBean.getGatewayname();
	        //this.envOrderId = devBean.envOrderId;	
	        
			//this.deviceIdList = devBean.deviceIdList;
			//this.gwDeviceIdList = devBean.gwDeviceIdList;
			//this.sipDvObjList = devBean.sipDvObjList;
			//this.gwDvObjList = devBean.gwDvObjList;
			//this.logTrail = devBean.logTrail;
			//this.getAll = devBean.getAll;
			
		}
		
		if ( devXref != null ){
	
			this.deviceMapId = (int)devXref.getLocDevid();
			this.enterpriseId = devXref.getCustId();
			if (devXref.getLocid() == 0){
                this.locationId = null;
            }else{
                this.locationId = Long.toString(devXref.getLocid());
            }    			
            //this.activeInd = devBean.activeInd;
			//this.departmentId = devBean.departmentId;
			this.gwDeviceId = devXref.getLocDevid();
			//this.sipDeviceId = devBean.sipDeviceId;
			//this.sipDeviceName = devBean.sipDeviceName;
			this.gwDeviceName = devXref.getName();
	        //this.envOrderId = devBean.envOrderId;	
	        //this.creationDate = devBean.creationDate;
			//this.lastModifiedDate = devBean.lastModifiedDate;
			//this.deviceIdList = devBean.deviceIdList;
			//this.gwDeviceIdList = devBean.gwDeviceIdList;
			//this.sipDvObjList = devBean.sipDvObjList;
			//this.gwDvObjList = devBean.gwDvObjList;
			//this.logTrail = devBean.logTrail;
			//this.getAll = devBean.getAll;
		}	
		
		this.modifiedBy = "SBC_MIG";
		this.createdBy = "SBC_MIG";
		this.creationDate = getCreationDate();
		this.lastModifiedDate = getLastModifiedDate();
		this.activeInd = 1;
		
		this.deviceIdList = new ArrayList<Integer>();
		this.gwDeviceIdList = new ArrayList<Long>();
		this.sipDvObjList = new ArrayList<SipDevice>();
		this.gwDvObjList = new ArrayList<GatewayDevice>();
		this.logTrail = new ArrayList<String>();
	}

	public void setLogTrail(String logStr)
        {
                logTrail.add(logStr);
        }
        public List<String> getLogTrail()
        {
                return logTrail;
        }
	
	public List<Integer> getDeviceIdList() {
                return deviceIdList;
        }

        public List<SipDevice> getSipDvObjList() {
                return sipDvObjList;
        }

        public void setSipDvObjList(List<SipDevice> sipDvObjList) {
                this.sipDvObjList = sipDvObjList;
        }

        public List<GatewayDevice> getGwDvObjList() {
                return gwDvObjList;
        }

        public void setGwDvObjList(List<GatewayDevice> gwDvObjList) {
                this.gwDvObjList = gwDvObjList;
        }

		public List<String> getGroupIdList() {
                return groupIdList;
        }

        public void setGroupIdList(List<String> groupIdList) {
                this.groupIdList = groupIdList;
        }

		public List<String> getSubIdList() {
                return subIdList;
        }

        public void setSubIdList(List<String> subIdList) {
                this.subIdList = subIdList;
        }

	 public void setDeviceIdList(List<Integer> deviceIdList) {
                this.deviceIdList = deviceIdList;
        }

        public List<Long> getGwDeviceIdList() {
                return gwDeviceIdList;
        }

        public void setGwDeviceIdList(List<Long> gwDeviceIdList) {
                this.gwDeviceIdList = gwDeviceIdList;
        }
	
	public String getSipDeviceName() {
		return sipDeviceName;
	}
	public void setSipDeviceName(String sipDeviceName) {
		this.sipDeviceName = sipDeviceName;
	}
	public String getGwDeviceName() {
		return gwDeviceName;
	}
	public void setGwDeviceName(String gwDeviceName) {
		this.gwDeviceName = gwDeviceName;
	}
	public String getModifiedBy() {
		return modifiedBy;
	}
	public int getDeviceMapId() {
		return deviceMapId;
	}
	public void setDeviceMapId(int deviceMapId) {
		this.deviceMapId = deviceMapId;
	}
	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
        }
        public String getDepartmentId() {
		return departmentId;
	}
	public void setDepartmentId(String departmentId) {
		this.departmentId = departmentId;
	}
	public String getEnterpriseId() {
		return enterpriseId;
	}
	public void setEnterpriseId(String enterpriseId) {
		this.enterpriseId = enterpriseId;
	}
	public String getLocationId() {
		return locationId;
	}
	public void setLocationId(String locationId) {
		this.locationId = locationId;
	}
	public long getGwDeviceId() {
		return gwDeviceId;
	}
	public void setGwDeviceId(long gwDeviceId) {
		this.gwDeviceId = gwDeviceId;
	}
	public long getActiveInd() {
                return activeInd;
        }
        public void setActiveInd(long activeInd) {
                this.activeInd = activeInd;
        }

	public long getSipDeviceId() {
		return sipDeviceId;
	}
	public void setSipDeviceId(long sipDeviceId) {
		this.sipDeviceId = sipDeviceId;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public String getDeviceNameId() {
		return this.deviceNameId;
	}

	public void setDeviceNameId(String _deviceNameId) {
		this.deviceNameId = _deviceNameId;
	}
	public Timestamp getCreationDate() {
		return this.creationDate;
	}

	public void setCreationDate(Timestamp creationDate) {
		this.creationDate = creationDate;
	}

	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}

	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}
        public long getEnvOrderId() {
	      return envOrderId;
	}
	public void setEnvOrderId(long envOrderId) {
		this.envOrderId = envOrderId;
	}	
	public boolean getGetAll() {
        return getAll;
    }

    public void setGetAll(boolean getAll) {
        this.getAll = getAll;
    }
	
}
