/**
 * 
 */
package com.vz.esap.api.connector.service;

import java.util.List;

import com.vz.esap.api.model.OrderErrorLogInfo;
import com.vz.esap.api.model.OrderLogInfo;
import com.vz.esap.api.model.OrderRspInfo;
import com.vz.esap.api.model.TaskCompletionLogInfo;

/**
 * @author Aricent
 *
 */
public interface IOrderLogService {

	/**
	 * @param logRequestObj
	 */
	void insertOrderLog(OrderLogInfo logRequestObj);

	/**
	 * @param logRequestObjList
	 */
	void insertOrderLog(List<OrderLogInfo> logRequestObjList);

	/**
	 * @param logRequestObjList
	 */
	void insertOrderLogError(List<OrderErrorLogInfo> logRequestObjList);

	void insertOrderRsp(List<OrderRspInfo> orderRspInfoList);

	void insertTaskCompletionLog(List<TaskCompletionLogInfo> taskCompletionLogInfoList);
}
