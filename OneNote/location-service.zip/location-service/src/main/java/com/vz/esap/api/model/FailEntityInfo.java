package com.vz.esap.api.model;

import java.util.Date;

public class FailEntityInfo {
    private String envOrderId;
    private String entityType;
    private String trackingId;
    private String orderId;
    private String tn;
    private String taskName;
    private String errorCode;
    private Date updatedTimestamp;
    private String errorDesc;
    private String workOrderNumber;
    private String workOrderVersion;
    private static final long serialVersionUID = 1L;
    
	public String getEnvOrderId() {
		return envOrderId;
	}
	public void setEnvOrderId(String envOrderId) {
		this.envOrderId = envOrderId;
	}
	public String getEntityType() {
		return entityType;
	}
	public void setEntityType(String entityType) {
		this.entityType = entityType;
	}
	public String getTrackingId() {
		return trackingId;
	}
	public void setTrackingId(String trackingId) {
		this.trackingId = trackingId;
	}
	public String getOrderId() {
		return orderId;
	}
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
	public String getTn() {
		return tn;
	}
	public void setTn(String tn) {
		this.tn = tn;
	}
	public String getTaskName() {
		return taskName;
	}
	public void setTaskName(String taskName) {
		this.taskName = taskName;
	}
	public String getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	public Date getUpdatedTimestamp() {
		return updatedTimestamp;
	}
	public void setUpdatedTimestamp(Date updatedTimestamp) {
		this.updatedTimestamp = updatedTimestamp;
	}
	public String getErrorDesc() {
		return errorDesc;
	}
	public void setErrorDesc(String errorDesc) {
		this.errorDesc = errorDesc;
	}
	public String getWorkOrderNumber() {
		return workOrderNumber;
	}
	public void setWorkOrderNumber(String workOrderNumber) {
		this.workOrderNumber = workOrderNumber;
	}
	public String getWorkOrderVersion() {
		return workOrderVersion;
	}
	public void setWorkOrderVersion(String workOrderVersion) {
		this.workOrderVersion = workOrderVersion;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
    
    

}