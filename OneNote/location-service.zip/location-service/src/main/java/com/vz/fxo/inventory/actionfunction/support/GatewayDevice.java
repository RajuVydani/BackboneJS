package com.vz.fxo.inventory.actionfunction.support;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import EsapEnumPkg.VzbVoipEnum;
import esap.db.DBTblGatewayDeviceInfo;
import esap.db.DBTblPublicTnPool;
import esap.db.TblDeviceMapQuery;
import esap.db.TblGatewayDeviceInfoDbBean;
import esap.db.TblGatewayDeviceInfoQuery;
import esap.db.TblGroupDbBean;
import esap.db.TblGroupQuery;
import esap.db.TblGroupTnQuery;
import esap.db.TblPublicTnPoolQuery;
import esap.db.TblSubscriberDeviceQuery;

public class GatewayDevice extends GatewayDeviceBean
{
	private static Logger log = LoggerFactory.getLogger(GatewayDevice.class.toString());
	//members
	private Connection connection;
	private Connection iasaConnection; // No need to close this connection; whoever set this;they should close 
	private String statusCode;
	private String statusDesc;
	public GatewayDevice(Connection con)
	{
		connection = con;
	}
	
	public GatewayDevice(Connection con,Connection iasaCon)
	{
		connection = con;
		iasaConnection = iasaCon;
	}
	
	public GatewayDevice(GatewayDeviceBean gwDevBean, Connection con)
	{
		super(gwDevBean);
		connection = con;
	}
	
	public GatewayDevice(GatewayDeviceBean gwDevBean, Connection con, Connection iasaCon)
	{
		super(gwDevBean);
		connection = con;
		iasaConnection = iasaCon;
	}
	
	
	//getters - setters
	InvErrorCode status = InvErrorCode.INTERNAL_ERROR;
	public int getStatusCode() {
		return status.getErrorCode();
	}

	public void setStatus(InvErrorCode status) {
		this.status = status;
	}

	public String getStatusDesc() {
		return status.getErrorDesc();
	}
	public Connection getConnection() {
		return connection;
	}
	public void setConnection(Connection connection) {
		this.connection = connection;
	}
	public boolean getGwDeviceDetailsByGatewayDeviceId() 
	{
		log.info("Entering Device::getGwDeviceDetailsByDeviceId");
		try
		{
			TblGatewayDeviceInfoQuery gwDvQry = new TblGatewayDeviceInfoQuery();
			gwDvQry.whereGatewayDeviceIdEQ(getGatewayDeviceId());
			gwDvQry.query(connection);
			if(gwDvQry.size() <= 0)
			{
				log.info("Gateway Device not Found");
				setStatus(InvErrorCode.NO_GATEWAY_DEVICES_FOUND);
				return false;
			}
			TblGatewayDeviceInfoDbBean gwDvBean = gwDvQry.getDbBean(0);
			setGatewayDeviceId(gwDvBean.getGatewayDeviceId());
			setDeviceName(gwDvBean.getDeviceName());
			setDeviceTypeId(gwDvBean.getDeviceTypeId());
			setSbcMigInd(gwDvBean.getSbcMigInd());
			if(getDeviceTypeId() > -1)
			{
				DeviceType devType = new DeviceType(connection);
				devType.setDeviceTypeId((int)getDeviceTypeId());
				if(devType.getDetails())
					deviceTypeBean = devType;
			}
			setGatewayAddress(gwDvBean.getGatewayAddress());
			setGatewaySecAddress(gwDvBean.getGatewaySecAddress());
			setCallingPartyFormat(gwDvBean.getCallingPartyFormat());
			setTermCallingInd(gwDvBean.getTermCallingInd());
			setDeviceCharId(gwDvBean.getDeviceCharId());
			setSbcProvMethod(gwDvBean.getSbcProvMethod());
			setTransport(gwDvBean.getTransport());
			setSbcId(gwDvBean.getSbcId());
			setSecSbcId(gwDvBean.getSecSbcId());
			setFqdn(gwDvBean.getGatewayFqdn());
			if(gwDvBean.getSbcId() > 0)
			  {
			  log.info("Retrieve SBC Info");
			  Long sId = Long.valueOf(getSbcId());
			  Sbc sbc = new Sbc(connection);
			  sbc.setSbcId(sId.intValue());
			  if(!sbc.getSbcDetailsBySbcId())
			  {
			  log.info("Failed to Retrieve Sbc");
			  //return false;
			  }
			  //sbcBean = sbc;
			}
		        setEnvOrderId(gwDvBean.getEnvOrderId()); 	
                        setCreatedBy(gwDvBean.getCreatedBy());
			setCreationDate(gwDvBean.getCreationDate());
			setModifiedBy(gwDvBean.getModifiedBy());
			setLastModifiedDate(gwDvBean.getLastModifiedDate());
            setGatewayHunt(gwDvBean.getGatewayHunt());
            setIasaGatewayDeviceId(gwDvBean.getIasaCpeLocalGwyid());
            //STN Code here
            setSTnPoolId(gwDvBean.getStnPoolId());
            setInternalAdmin(gwDvBean.getInternalAdmin());
			setSTn(getTnByTnPoolId(gwDvBean.getStnPoolId()));
			//SBC Capacity Allocation code
			setAggregateOffnetCcl(gwDvBean.getAggregateOffnetCcl());
			setSignalingTierLookupValue(gwDvBean.getSignalingTierLookupValue());
			setTierOverrideFlag(gwDvBean.getTierOverrideFlag());
			setIpVersion(gwDvBean.getIpVersion());
			setPqInstanceId(gwDvBean.getPqInstanceId());
			setTsoMigLock(gwDvBean.getTsoMigLock());
			setUpdateComment(gwDvBean.getUpdateComment());
		}
		catch(SQLException s)
		{
			s.printStackTrace();	
			setStatus(InvErrorCode.DB_EXCEPTION);
			return false;
		}
		setStatus(InvErrorCode.SUCCESS);
		return true;
	}
	public boolean validateGatewayDevice()
	{
		return true;
	}
	public boolean addGatewayDevice() throws SQLException, Exception
	{
		log.info("Entering GatewayDevice::addGatewayDevice");
		//try
		//{
		
			DBTblGatewayDeviceInfo gwDvDB = new DBTblGatewayDeviceInfo();
			if(getGatewayDeviceId() > 0)
				gwDvDB.setGatewayDeviceId(getGatewayDeviceId());
			else{
				long gwDvSeqId = gwDvDB.getGatewayDeviceIdSeqNextVal(connection);
				setGatewayDeviceId(gwDvSeqId);
			}
			if(getDeviceName() != "")
				gwDvDB.setDeviceName(getDeviceName());
			if(getDeviceTypeId() > -1)
				gwDvDB.setDeviceTypeId(getDeviceTypeId());
			else if((getDeviceTypeBean()).getDeviceTypeName() != null && (getDeviceTypeBean()).getDeviceTypeName() != "")
			{
				DeviceType devType = new DeviceType(connection,getDeviceTypeBean());
				if( devType.getDeviceTypeIdByDeviceTypeName() )
				{
					gwDvDB.setDeviceTypeId(devType.getDeviceTypeId());
				}
			}
			/*if(gwDvDB.getDeviceTypeId() <= 0)
			{
                log.info("INV_FAILURE in addGwDevice.DeviceTypeId cannot be null/less than 0");
				setStatus(InvErrorCode.INTERNAL_ERROR);
				return false;
			}*/
			if(!"".equals(getGatewayAddress()) && !"NONE".equals(getGatewayAddress())){
				gwDvDB.setGatewayAddress(getGatewayAddress());
			}
			else{
				gwDvDB.setGatewayAddress("");
			}
			if(!"".equals(getGatewaySecAddress()) && !"NONE".equals(getGatewaySecAddress())){
			gwDvDB.setGatewaySecAddress(getGatewaySecAddress());
			}else{
				gwDvDB.setGatewaySecAddress(" ");
			}
			if(getCallingPartyFormat() != -1)
				gwDvDB.setCallingPartyFormat(getCallingPartyFormat());
			else
				gwDvDB.setCallingPartyFormat(VzbVoipEnum.CallingPartyFormat.NATIONAL_STRIP);
			gwDvDB.setSbcMigInd(getSbcMigInd());
			if(getTermCallingInd()!=-1){
			gwDvDB.setTermCallingInd(getTermCallingInd());
			}
			else{
				gwDvDB.setTermCallingInd(0);
			}
			if(!"".equals(getFqdn()) && !"NONE".equals(getFqdn())){
				gwDvDB.setGatewayFqdn(getFqdn());
				}else{
					gwDvDB.setGatewayFqdnNull();
				}
			
			if(!"".equals(getSTnLinePort()) && !"NONE".equals(getSTnLinePort())){
				gwDvDB.setStnLinePort(getSTnLinePort());
				}else{
					gwDvDB.setStnLinePortNull();
				}
			
			if(getSbcProvMethod()!=-1){
				gwDvDB.setSbcProvMethod(getSbcProvMethod());
			}else{
				gwDvDB.setSbcProvMethod(0);
			}
			
			if(getSbcId() > 0)
				gwDvDB.setSbcId(getSbcId());
			
			if(getDeviceCharId()!=-1){
			gwDvDB.setDeviceCharId(getDeviceCharId());
			}
			
			
			if(getTransport()!=-1){
			gwDvDB.setTransport(getTransport());
			}else{
				gwDvDB.setTransportNull(); 
			}
			//gwDvDB.setStripCcInd(getStripCcInd());
		        if (getEnvOrderId() > 0)
				gwDvDB.setEnvOrderId(getEnvOrderId());
			else
				gwDvDB.setEnvOrderIdNull(); 	
			if(getModifiedBy() != null && !getModifiedBy().equals("")) 
				gwDvDB.setModifiedBy(getModifiedBy());
			else
				gwDvDB.setModifiedBy("ESAP_INV");
			if(getCreatedBy() != null && !getCreatedBy().equals("") )
				gwDvDB.setCreatedBy(getCreatedBy());
			else
				gwDvDB.setCreatedBy("ESAP_INV");
			gwDvDB.setLastModifiedDate(new Timestamp(System.currentTimeMillis()));
			gwDvDB.setCreationDate(new Timestamp(System.currentTimeMillis()));
			gwDvDB.setPortsAssigned(0);
			
            if(getGatewayHunt() != null)
                gwDvDB.setGatewayHunt(getGatewayHunt());
            FkValidationUtil.isValidGatewayDeviceInfo(connection, gwDvDB);
            gwDvDB.setIasaCpeLocalGwyid(getIasaGatewayDeviceId());
			gwDvDB.setInternalAdmin(getInternalAdmin());
			
			//SBC Capacity Allocation code
			gwDvDB.setAggregateOffnetCcl(getAggregateOffnetCcl());
			gwDvDB.setSignalingTierLookupValue(getSignalingTierLookupValue());
			gwDvDB.setTierOverrideFlag(getTierOverrideFlag());
			gwDvDB.setIpVersion(getIpVersion());
			gwDvDB.setPqInstanceId(getPqInstanceId());
			if(getTsoMigLock() > -1){
				gwDvDB.setTsoMigLock(getTsoMigLock());
			}else{
				gwDvDB.setTsoMigLock((short)0);
			}
			gwDvDB.setIpsecTunnelId(getIpsecTunnelId());
			
			gwDvDB.insert(connection);
			
			//STN Code here
			log.info(" STN check " + sTn);
			if ( sTn != null && !(sTn.trim()).equalsIgnoreCase("") &&  !(sTn.trim()).equalsIgnoreCase("NONE") ){
				log.info(" sTn :: " + sTn + " stnid :: " + VzbVoipEnum.YesNoType.Y);
				if(StnExistsInTnPublicPool(sTn)){
					sTnPoolId = updateStnInTnpublicPool(sTn);
				} else {
					sTnPoolId = addToPublicPool(sTn, VzbVoipEnum.TnStatus.AVAILABLE, VzbVoipEnum.TnType.RES,VzbVoipEnum.YesNoType.Y);
				}
				log.info("addGatewayDevice sTnPoolId :: " + sTnPoolId);
            	if (sTnPoolId > 0)
                {
            		DBTblGatewayDeviceInfo gwDvInfoUpd = new DBTblGatewayDeviceInfo();
            		gwDvInfoUpd.whereGatewayDeviceIdEQ(gatewayDeviceId);
            		log.info(" gwDvInfoUpd " + gwDvInfoUpd);
            		if ( gwDvInfoUpd != null){
            			gwDvInfoUpd.setStnPoolId(sTnPoolId);
            			gwDvInfoUpd.updateSpByWhere(connection);
            			setLogTrail("Added Screened TN to DB:" + sTn);
            		}
                } else
                {
                    log.info("Device Class - Failed to Add Screened TN");
                    setLogTrail("Failed to Add Screened TN to DB:" + sTn);
                    setStatus(InvErrorCode.FAILED_ADD_SCREENED_TN);
                    return false;
                }
            	
            }
			
		/*}
		catch(SQLException s)
		{
			s.printStackTrace();	
			setStatus(InvErrorCode.DB_EXCEPTION);
			return false;
		}*/
		return true;
	}
	
	 public long updateStnInTnpublicPool(String sTn) {
		setLogTrail("STN ::::" +sTn);
		long tnPoolId = 0;
		PreparedStatement pStmnt = null;
		ResultSet rSet = null;
		String sql = null;
		if(sTn != null){
			DBTblPublicTnPool tblPublicTnPool = new DBTblPublicTnPool();
			tblPublicTnPool.setStnInd(VzbVoipEnum.YesNoType.Y);
			tblPublicTnPool.whereTnEQ(sTn);
			try {
				tblPublicTnPool.updateSpByWhere(connection);
				setLogTrail("Successfully update STN ind in PNP.");
				sql = "SELECT TN_POOL_ID FROM TBL_PUBLIC_TN_POOL WHERE TN = ?";
				pStmnt = connection.prepareStatement(sql);
				pStmnt.setString(1, sTn);
				rSet = pStmnt.executeQuery();
				while(rSet.next()){
						tnPoolId  = rSet.getInt(1);
				}
			} catch (SQLException e) {
				e.printStackTrace();
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				try {
					if(pStmnt != null)
						pStmnt.close();
					if(rSet != null)
						rSet.close();
				} catch(SQLException e) {
					e.printStackTrace();
				}
			}
		} else {
			setLogTrail("STN comming null.");
		}
        return tnPoolId;
	}

	private boolean StnExistsInTnPublicPool(String sTn) {
		PreparedStatement pStmnt = null;
		ResultSet rSet = null;
		boolean StnExist = false;
		String sql = null;
		try {
				sql = "SELECT COUNT(*) FROM TBL_PUBLIC_TN_POOL WHERE TN = ?";
				pStmnt = connection.prepareStatement(sql);
				pStmnt.setString(1, sTn);
				rSet = pStmnt.executeQuery();
				while(rSet.next()){
					if(rSet.getInt(1) > 0){
						StnExist = true;
					}
				}
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if(pStmnt != null)
					pStmnt.close();
				if(rSet != null)
					rSet.close();
			} catch(SQLException e) {
				e.printStackTrace();
			}
		}
		 return StnExist;
	}

	public long addToPublicPool(String tn, int tnStatus, long tnType, long stnInd)
	    {
	        log.info("Entering Location::addToPublicPool");
	        long tnId = 0;
	        try
	        {
				PublicTnPool pubTnPoolObj = new PublicTnPool(connection);
				log.info("locationId " + locationId);
	            pubTnPoolObj.setLocationId(locationId);
	            pubTnPoolObj.setTn(tn);
	            pubTnPoolObj.setTnStatus(tnStatus);
	            pubTnPoolObj.setTnType(tnType);
	            pubTnPoolObj.setPortedStatus("" + VzbVoipEnum.PortStatus.NATIVE);
	            pubTnPoolObj.setModifiedBy("ESAP_INV");
	            pubTnPoolObj.setCreatedBy("ESAP_INV");
	            pubTnPoolObj.setLastModifiedDate(new Timestamp(System.currentTimeMillis()));
	            pubTnPoolObj.setCreationDate(new Timestamp(System.currentTimeMillis()));
	            pubTnPoolObj.setEnvOrderId(getEnvOrderId());
	            //STN Code here
	            log.info(" stnInd " + stnInd);
	            pubTnPoolObj.setStnInd(stnInd);
	            pubTnPoolObj.addPublicTnPool();
				tnId = pubTnPoolObj.getTnPoolId();
	        }
	        catch (Exception e)
	        {
		    setStatus(InvErrorCode.DB_EXCEPTION);
		    log.info("DB_FAILURE in addToPublicPool");
	            e.printStackTrace();
	            return tnId;
	        }
	        setStatus(InvErrorCode.SUCCESS);
	        log.info("Successfully inserted Tn");
	        return tnId;
	    }

	public boolean deleteGatewayDevice() throws SQLException, Exception

	{
//		try
//		{
			if(getGatewayDeviceId() <= 0)
			{
				setStatus(InvErrorCode.GATEWAY_DEVICE_DEVICE_TYPE_ID_NULL);
				return false;
			}
			log.info("In deleteGatewayDevice");
			if(!stnUsedByAnyDevice()){
				//STN Code here
				updateStn();
			} else {
				setLogTrail("STN is assigned to another Device.");
			}
			
			 //IPsec code here
			IpSec ipsecObj = new IpSec(connection);
			long ipsecTunId = ipsecObj.getIpsecTunnelIdForDevice(getGatewayDeviceId(), (short)VzbVoipEnum.IpsecDeviceType.DEVICE);
			log.info("ipsecTunId :: "+ipsecTunId);
			if(ipsecObj.countofDeviceForIpsecTunnel(ipsecTunId, (short)VzbVoipEnum.IpsecDeviceType.DEVICE) == 1){
				log.info(" countofDeviceForIpsecTunnel is 1 "); 	
				ipsecObj.createIpseqDeleteRequest(getGatewayDeviceId(),(short)VzbVoipEnum.IpsecDeviceType.DEVICE, getEnvOrderId(),true);
			}
			
			DBTblGatewayDeviceInfo gatewayDeviceBean = new DBTblGatewayDeviceInfo();
			gatewayDeviceBean.whereGatewayDeviceIdEQ(getGatewayDeviceId());
			int gwDevDeleted = gatewayDeviceBean.deleteByWhere(connection);
			log.info("Number of gwDevDeleted :"+gwDevDeleted);
			
/*		}
		catch(SQLException s)
		{
			s.printStackTrace();	
			setStatus(InvErrorCode.DB_EXCEPTION);
			log.info("DB_FAILURE in delete Gateway Device");
			return false;
		}*/
		setStatus(InvErrorCode.SUCCESS);
		return true;
	}
	private boolean stnUsedByAnyDevice() {
		PreparedStatement pStmnt = null;
		ResultSet rSet = null;
		boolean secDevice = false;
		long stnPoolId = 0;
		TblGatewayDeviceInfoQuery tblGwyDevinfoQuery = new TblGatewayDeviceInfoQuery();
		tblGwyDevinfoQuery.whereGatewayDeviceIdEQ(getGatewayDeviceId());
		try {
			tblGwyDevinfoQuery.query(connection);
			if(tblGwyDevinfoQuery.size() > 0) {
				if (  tblGwyDevinfoQuery.getDbBean(0).getStnPoolId() > 0){
					stnPoolId = tblGwyDevinfoQuery.getDbBean(0).getStnPoolId();
					String sql = null;

					sql = "SELECT COUNT(*) FROM TBL_GATEWAY_DEVICE_INFO WHERE STN_POOL_ID = ?";
					pStmnt = connection.prepareStatement(sql);
					pStmnt.setLong(1, stnPoolId);
					rSet = pStmnt.executeQuery();
					while(rSet.next()){
						if(rSet.getInt(1) > 1){
							secDevice = true;
						}
					}
				}
				
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if(pStmnt != null)
					pStmnt.close();
				if(rSet != null)
					rSet.close();
			} catch(SQLException e) {
				e.printStackTrace();
			}
		}
		return secDevice;
	}

	public void updateStn() throws Exception {
		TblGatewayDeviceInfoQuery tblGwyDevinfoQuery = new TblGatewayDeviceInfoQuery();
		tblGwyDevinfoQuery.whereGatewayDeviceIdEQ(getGatewayDeviceId());
		tblGwyDevinfoQuery.query(connection);

		log.info(" TblGatewayDeviceInfoQuery size " + tblGwyDevinfoQuery.size());
		if (tblGwyDevinfoQuery.size() > 0) {
			log.info(" tblGwyDevinfoQuery.getDbBean(0).getStnPoolId() " + tblGwyDevinfoQuery.getDbBean(0).getStnPoolId());
			if (  tblGwyDevinfoQuery.getDbBean(0).getStnPoolId() > 0){
				
				//No need to delete the PNP as it may be reserved TN and may be assigned to trunk group.
				/*TblGroupTnQuery tblGroupTnQry = new TblGroupTnQuery();
				tblGroupTnQry.whereTnPoolIdEQ(tblGwyDevinfoQuery.getDbBean(0).getStnPoolId());
				tblGroupTnQry.query(connection);
				log.info(" tblGroupTnQry.size() " + tblGroupTnQry.size());

				// If STN is assigned to Trunk group then reset stnInd in PNP else delete STN from TN_PUBLIC_POOL
				if ( tblGroupTnQry.size() > 0 ){

					DBTblPublicTnPool tblPublicTnPool = new DBTblPublicTnPool();
					tblPublicTnPool.setStnInd(VzbVoipEnum.YesNoType.N);
					tblPublicTnPool.whereTnPoolIdEQ((int)tblGwyDevinfoQuery.getDbBean(0).getStnPoolId());
					int rec = tblPublicTnPool.updateSpByWhere(connection);
					log.info("Number of PNP rec updated :"+ rec);
                    setLogTrail("Successfully update old STN ind in PNP.");

						DBTblGroupTn tblGrpTn = new DBTblGroupTn();
						tblGrpTn.setTnPoolId(VzbVoipEnum.YesNoType.N);
						tblGrpTn.whereTnPoolIdEQ(tblGwyDevinfoQuery.getDbBean(0).getStnPoolId());
						tblGrpTn.updateSpByWhere(connection);
				}else{*/
				
					DBTblPublicTnPool tblPublicTnPool = new DBTblPublicTnPool();
					tblPublicTnPool.setStnInd(VzbVoipEnum.YesNoType.N);
					tblPublicTnPool.whereTnPoolIdEQ((int)tblGwyDevinfoQuery.getDbBean(0).getStnPoolId());
					int rec = tblPublicTnPool.updateSpByWhere(connection);
					log.info("Number of PNP rec deleted :"+ rec);
	                setLogTrail("Successfully update old STN ind in PNP.");
					
					//Check the reference of STN Pool Id in the GatewayDevice table and update with null.
					DBTblGatewayDeviceInfo tblGatewayDeviceInfo = new DBTblGatewayDeviceInfo();
					tblGatewayDeviceInfo.setStnPoolIdNull();
					tblGatewayDeviceInfo.whereGatewayDeviceIdEQ(getGatewayDeviceId());
					int gatewayDeviceInfoRecCountUpdated = tblGatewayDeviceInfo.updateSpByWhere(connection);
					setLogTrail("Successfully GatewayDevice Updated STNPOOLID to NULL" + gatewayDeviceInfoRecCountUpdated);
			        log.info("Successfully Location Updated STNPOOLID to NULL " + gatewayDeviceInfoRecCountUpdated);
			        
					
				//}
			}
		} else {
             setLogTrail("No old STN found in gtwy table.");
		}
	}

	public boolean updateGatewayDevice() throws SQLException, Exception
	{
//		try
//		{
			if ( getGatewayDeviceId() <= 0) {
				setStatus(InvErrorCode.GATEWAY_DEVICE_DEVICE_TYPE_ID_NULL);
				log.info("FAILURE in updateGateway device. GatewayDeviceId missing.");
				return false;
			}
			DBTblGatewayDeviceInfo gatewayDeviceBean = getGatewayDeviceToUpdate();

			// if new STN pool id is set, then make sure u take care of the old stn pool id if exist.
			if(gatewayDeviceBean.isStnPoolIdSet() == true) {
				TblGatewayDeviceInfoQuery tblGwyDevinfoQuery = new TblGatewayDeviceInfoQuery();
				tblGwyDevinfoQuery.whereGatewayDeviceIdEQ(getGatewayDeviceId());
				tblGwyDevinfoQuery.query(connection);
				//Checking the New and Old Stn pool id is there.
				log.info(" Old Stn " + tblGwyDevinfoQuery.getDbBean(0).getStnPoolId());
				log.info(" New Stn " + gatewayDeviceBean.getStnPoolId());
				if ( tblGwyDevinfoQuery.getDbBean(0).getStnPoolId() != gatewayDeviceBean.getStnPoolId()){
					updateStn();
				}
			}
			// gatewayDeviceBean.whereGatewayDeviceIdEQ((int)deviceTypeId);
			gatewayDeviceBean.whereGatewayDeviceIdEQ(getGatewayDeviceId());
			log.info("BASE2 GatewayAddress <" + gatewayDeviceBean.getGatewayAddress() + ">");
			log.info("BASE3 deviceTypeId <" + deviceTypeId  + ">");
			FkValidationUtil.isValidGatewayDeviceInfoForMod(connection, gatewayDeviceBean);
			gatewayDeviceBean.updateSpByWhere(connection);
			//	gatewayDeviceBean.update(connection);
/*		} catch(SQLException s) {
			s.printStackTrace();	
			setStatus(InvErrorCode.DB_EXCEPTION);
			log.info("DB_FAILURE in updateSipDevice SipDevice");
			return false;
		}*/
		setStatus(InvErrorCode.SUCCESS);
		return true;
	}
	/**
	 * The current Gateway details are extracted using getDetails()
	 * and the new field values are updated over that. The method
	 * will update the fields that are supplied on the current instance
	 * iff they are different from the default values for the respective field.
	 *
	 * @return The GatewayDevice to be updated.
	 * @throws SQLException 
	 */
	private DBTblGatewayDeviceInfo getGatewayDeviceToUpdate() throws SQLException {
		DBTblGatewayDeviceInfo gtwyDeviceinfoDbBean = new DBTblGatewayDeviceInfo();
		/* Create a new instance of GatewayDeviceBean. The new instance
		 * would hold default values for the all the Gateway Device fields.*/
		GatewayDeviceBean defaultGatewayDeviceBean = new GatewayDeviceBean();
		GatewayDevice inputGatewayDevice = this;
		/*Set the new fields if required.*/
		gtwyDeviceinfoDbBean.setGatewayDeviceId(getGatewayDeviceId());
		log.info("inputGatewayDevice.getDeviceName()  ==>"+inputGatewayDevice.getDeviceName() );
		log.info("defaultGatewayDeviceBean.getDeviceName()  ==>"+defaultGatewayDeviceBean.getDeviceName() );
		if ( inputGatewayDevice.getDeviceName() != null &&
				!inputGatewayDevice.getDeviceName().equals(defaultGatewayDeviceBean.getDeviceName()) ){
			gtwyDeviceinfoDbBean.setDeviceName(inputGatewayDevice.getDeviceName());
		}
		if ( inputGatewayDevice.getDeviceTypeId() != defaultGatewayDeviceBean.getDeviceTypeId()){
			gtwyDeviceinfoDbBean.setDeviceTypeId(inputGatewayDevice.getDeviceTypeId());
		}
		if ( inputGatewayDevice.getGatewayAddress() != null &&
				!inputGatewayDevice.getGatewayAddress().equals(defaultGatewayDeviceBean.getGatewayAddress()) ){
			gtwyDeviceinfoDbBean.setGatewayAddress(inputGatewayDevice.getGatewayAddress());
			log.info("BASE GatewayAddress <" + inputGatewayDevice.getGatewayAddress() + ">");
		}
		if ( inputGatewayDevice.getFqdn() != null &&
				!inputGatewayDevice.getFqdn().equals(defaultGatewayDeviceBean.getFqdn()) ){
			gtwyDeviceinfoDbBean.setGatewayFqdn(inputGatewayDevice.getFqdn());
			log.info("BASE getFqdn <" + inputGatewayDevice.getFqdn() + ">");
		}
		
		if ( inputGatewayDevice.getGatewayHunt() != null &&
				!inputGatewayDevice.getGatewayHunt().equals(defaultGatewayDeviceBean.getGatewayHunt()) ){
			gtwyDeviceinfoDbBean.setGatewayHunt(inputGatewayDevice.getGatewayHunt());
			log.info("BASE getGatewayHunt <" + inputGatewayDevice.getGatewayHunt() + ">");
		}
		
		if ( inputGatewayDevice.getSTnLinePort() != null &&
				!inputGatewayDevice.getSTnLinePort().equals(defaultGatewayDeviceBean.getSTnLinePort()) ){
			gtwyDeviceinfoDbBean.setStnLinePort(inputGatewayDevice.getSTnLinePort());
			log.info("BASE LinePort <" + gtwyDeviceinfoDbBean.getStnLinePort() + ">");
		}
		
		log.info("BASE1 GatewayAddress <" + inputGatewayDevice.getGatewayAddress() + ">");
		if ( inputGatewayDevice.getGatewaySecAddress() != null &&
				!inputGatewayDevice.getGatewaySecAddress().equals(defaultGatewayDeviceBean.getGatewaySecAddress()) ){
			gtwyDeviceinfoDbBean.setGatewaySecAddress(inputGatewayDevice.getGatewaySecAddress());
		}
		if ( inputGatewayDevice.getCallingPartyFormat() != defaultGatewayDeviceBean.getCallingPartyFormat()) {
	           if(inputGatewayDevice.getCallingPartyFormat() != -2 )
	        	   gtwyDeviceinfoDbBean.setCallingPartyFormat(inputGatewayDevice.getCallingPartyFormat());
	           else
	        	   gtwyDeviceinfoDbBean.setCallingPartyFormatNull(); 
		}
		if ( inputGatewayDevice.getTermCallingInd() != defaultGatewayDeviceBean.getTermCallingInd()){
			gtwyDeviceinfoDbBean.setTermCallingInd(inputGatewayDevice.getTermCallingInd());
		}
		log.info(" inputGatewayDevice.getSbcId() " + inputGatewayDevice.getSbcId());
		if ( inputGatewayDevice.getSbcId() != defaultGatewayDeviceBean.getSbcId()){
			if (inputGatewayDevice.getSbcId() > 0 )
				gtwyDeviceinfoDbBean.setSbcId(inputGatewayDevice.getSbcId());
			/*else
				gtwyDeviceinfoDbBean.setSbcIdNull();
			*/
		}
		log.info(" gtwyDeviceinfoDbBean.getSbcId() " + gtwyDeviceinfoDbBean.getSbcId());
		if ( inputGatewayDevice.getDeviceCharId() != defaultGatewayDeviceBean.getDeviceCharId()){
			if (inputGatewayDevice.getDeviceCharId() > 0 )
				gtwyDeviceinfoDbBean.setDeviceCharId(inputGatewayDevice.getDeviceCharId());
			else
				gtwyDeviceinfoDbBean.setDeviceCharIdNull();
		}
		if ( inputGatewayDevice.getTransport() != defaultGatewayDeviceBean.getTransport()){
			if (inputGatewayDevice.getTransport() > 0 )
				gtwyDeviceinfoDbBean.setTransport(inputGatewayDevice.getTransport());
			else
				gtwyDeviceinfoDbBean.setTransportNull();
		}

		if ( inputGatewayDevice.getInternalAdmin() != defaultGatewayDeviceBean.getInternalAdmin())
			gtwyDeviceinfoDbBean.setInternalAdmin(inputGatewayDevice.getInternalAdmin());

		/*if ( inputGatewayDevice.getStripCcInd() != defaultGatewayDeviceBean.getStripCcInd()){
			if (inputGatewayDevice.getStripCcInd() > 0 )
				gtwyDeviceinfoDbBean.setStripCcInd(inputGatewayDevice.getStripCcInd());
			else
				gtwyDeviceinfoDbBean.setStripCcIndNull();
		}*/
	       if (inputGatewayDevice.getEnvOrderId() != defaultGatewayDeviceBean
				.getEnvOrderId()) {
			gtwyDeviceinfoDbBean.setEnvOrderId(inputGatewayDevice
					.getEnvOrderId());
		}	
	       
	       if (inputGatewayDevice.getSbcProvMethod() != defaultGatewayDeviceBean
					.getSbcProvMethod()) {
				gtwyDeviceinfoDbBean.setSbcProvMethod(inputGatewayDevice
						.getSbcProvMethod());
			}	
	       
	       if (inputGatewayDevice.getSbcMigInd() != defaultGatewayDeviceBean
					.getSbcMigInd()) {
				gtwyDeviceinfoDbBean.setSbcMigInd(inputGatewayDevice
						.getSbcMigInd());
			}
	       
	       
	       if (inputGatewayDevice.getIasaGatewayDeviceId() != defaultGatewayDeviceBean
					.getIasaGatewayDeviceId()) {
				gtwyDeviceinfoDbBean.setIasaCpeLocalGwyid(inputGatewayDevice
						.getIasaGatewayDeviceId());
			}	
	       
	       
		if( inputGatewayDevice.getModifiedBy() != null &&
				!( "".equalsIgnoreCase(inputGatewayDevice.getModifiedBy()) ) ) {
			gtwyDeviceinfoDbBean.setModifiedBy(inputGatewayDevice.getModifiedBy());
		} else {
			gtwyDeviceinfoDbBean.setModifiedBy("ESAP_INV");
		}
		gtwyDeviceinfoDbBean.setLastModifiedDate(new Timestamp(System.currentTimeMillis()));
        if(inputGatewayDevice.getGatewayHunt() != null)
           gtwyDeviceinfoDbBean.setGatewayHunt(inputGatewayDevice.getGatewayHunt());
        
      //STN Code here
        log.info("inputGatewayDevice.getSTnPoolId():" + inputGatewayDevice.getSTnPoolId());
        if(inputGatewayDevice.getSTnPoolId() > 0)
        {
        	gtwyDeviceinfoDbBean.setStnPoolId(inputGatewayDevice.getSTnPoolId());
            //locationDbBean.setEmerPoolId((int)inputLocation.getSTnPoolId());
        } else if (inputGatewayDevice.getSTn() != null
                && !inputGatewayDevice.getSTn().trim().equals(defaultGatewayDeviceBean.getSTn()))
        {
        	log.info("inputGatewayDevice.getSTn():" + inputGatewayDevice.getSTn());
        	log.info(" Screened Tn:" + sTn);
        	
			if(inputGatewayDevice.getSTn().trim().equals("")){
				gtwyDeviceinfoDbBean.setStnPoolIdNull();
				log.info(" gtwyDeviceinfoDbBean.getSTnPoolId() : setting null " + inputGatewayDevice.getSTnPoolId() );
			} 
			else{
            //Check if the pool entry is already there for this tn.
            long sTnPoolId = getTnPoolIdByTn(getSTn());
            log.info("sTnPoolId Getting from DB :" + sTnPoolId);
            if (sTnPoolId > 0) {
            	gtwyDeviceinfoDbBean.setStnPoolId(sTnPoolId);
            	
            	//IR #1420244 52627.AA / ANI Toggle from N/Y - STN is not reflecting in TN Mgmt  
            	// need to set the stn_ind=Y in PNP
				DBTblPublicTnPool dbPnp = new DBTblPublicTnPool();
				dbPnp.whereTnPoolIdEQ((int)sTnPoolId);
				dbPnp.setStnInd(VzbVoipEnum.YesNoType.Y);
				dbPnp.updateSpByWhere(connection);
				setLogTrail("Successfully set stn_ind to: Y for new STN = " + getSTn() + "." );
				log.info("Successfully set stn_ind to: Y for new STN = " + getSTn() + "." );
            
            } else
            {
                sTnPoolId = addToPublicPool(sTn, VzbVoipEnum.TnStatus.AVAILABLE, VzbVoipEnum.TnType.RES,VzbVoipEnum.YesNoType.Y);
                log.info("creating new addToPublicPool-->sTnPoolId :" + sTnPoolId);
                if (sTnPoolId > 0)
                {
                	gtwyDeviceinfoDbBean.setStnPoolId(sTnPoolId);
                    //locationDbBean.setEmerPoolId((int)billTnPoolId);
                    setLogTrail("Added  Screened Tn to DB:" + sTn);
                } else
                {
                    log.info("Failed to Add Screened Tn");
                    setLogTrail("Failed to Add Screened Tn to DB:" + sTn);
                }
            }
			}
        }
        
      //SBC Capacity Allocation code
        if (inputGatewayDevice.getAggregateOffnetCcl() != defaultGatewayDeviceBean
				.getAggregateOffnetCcl()) {
			gtwyDeviceinfoDbBean.setAggregateOffnetCcl(inputGatewayDevice
					.getAggregateOffnetCcl());
		}
        if (inputGatewayDevice.getSignalingTierLookupValue() != defaultGatewayDeviceBean
				.getSignalingTierLookupValue()) {
			gtwyDeviceinfoDbBean.setSignalingTierLookupValue(inputGatewayDevice
					.getSignalingTierLookupValue());
		}
        //if (inputGatewayDevice.getTierOverrideFlag() != defaultGatewayDeviceBean
		//		.getTierOverrideFlag()) {
			gtwyDeviceinfoDbBean.setTierOverrideFlag(inputGatewayDevice
					.getTierOverrideFlag());
		//}
			if (inputGatewayDevice.getIpVersion() != defaultGatewayDeviceBean.getIpVersion()) {
				gtwyDeviceinfoDbBean.setIpVersion(inputGatewayDevice.getIpVersion());				
			}
			
			if (inputGatewayDevice.getPqInstanceId() != defaultGatewayDeviceBean.getPqInstanceId()) {
				gtwyDeviceinfoDbBean.setPqInstanceId(inputGatewayDevice.getPqInstanceId());				
			}
			if (inputGatewayDevice.getTsoMigLock() != defaultGatewayDeviceBean.getTsoMigLock()) {
				gtwyDeviceinfoDbBean.setTsoMigLock(inputGatewayDevice.getTsoMigLock());
			}
			
			if (inputGatewayDevice.getUpdateComment() != defaultGatewayDeviceBean.getUpdateComment()) {
				gtwyDeviceinfoDbBean.setUpdateComment(inputGatewayDevice.getUpdateComment());
			}
			
		return gtwyDeviceinfoDbBean;
	}
	
	public long getTnPoolIdByTn(String tn)
    {
        log.info("Entering Location::getTnPoolIdByTn");
        log.info("!! Tn " + tn);
        log.info("!! AFter printing");
        long tnPoolId = 0;
        if (tn == null || tn.trim().equals(""))
        {
            tn = "0";
        }
        try
        {
            TblPublicTnPoolQuery tnQry = new TblPublicTnPoolQuery();
            tnQry.whereTnEQ(tn);
            tnQry.query(connection);
            if (tnQry.size() <= 0)
            {
                log.info("TN [" + tn + "] Not Found");
                return tnPoolId;
            }
            tnPoolId = tnQry.getDbBean(0).getTnPoolId();
            log.info("Retrieved TN Id [" + tnPoolId + "] For Tn [" + tn + "]");
        }
        catch (SQLException e)
        {
            setStatus(InvErrorCode.DB_EXCEPTION);
            log.info("Failed to retrieve TN Id");
            e.printStackTrace();
            return tnPoolId;
        }
        setStatus(InvErrorCode.SUCCESS);
        log.info("Successfully retrived TN Id");
        return tnPoolId;
    }
	
	public boolean getDetails() 
	{
		try
		{
			log.info("In Gateway Device getDetails; Gateway device id="+getGatewayDeviceId());
			TblGatewayDeviceInfoQuery gtwyDeviceQry = new TblGatewayDeviceInfoQuery();
			String whereClause = " where gateway_device_id = \'"+getGatewayDeviceId()+"\'";
			gtwyDeviceQry.queryByWhere(connection, whereClause);
			if(gtwyDeviceQry.size() == 1){
				setDeviceName((gtwyDeviceQry.getDbBean(0)).getDeviceName());
				setDeviceTypeId((gtwyDeviceQry.getDbBean(0)).getDeviceTypeId());
				setGatewayAddress((gtwyDeviceQry.getDbBean(0)).getGatewayAddress());
				setGatewaySecAddress((gtwyDeviceQry.getDbBean(0)).getGatewaySecAddress());
				setCallingPartyFormat((gtwyDeviceQry.getDbBean(0)).getCallingPartyFormat());
				setPortsAssigned((gtwyDeviceQry.getDbBean(0)).getPortsAssigned());
				setSbcProvMethod((gtwyDeviceQry.getDbBean(0)).getSbcProvMethod());
				setTermCallingInd((gtwyDeviceQry.getDbBean(0)).getTermCallingInd());
				setSbcId((gtwyDeviceQry.getDbBean(0)).getSbcId());
				setSecSbcId((gtwyDeviceQry.getDbBean(0)).getSecSbcId());
			        setEnvOrderId((gtwyDeviceQry.getDbBean(0)).getEnvOrderId()); 	
                                setCreationDate((gtwyDeviceQry.getDbBean(0)).getCreationDate());
				setLastModifiedDate((gtwyDeviceQry.getDbBean(0)).getLastModifiedDate());
				setCreatedBy((gtwyDeviceQry.getDbBean(0)).getCreatedBy());
				setModifiedBy((gtwyDeviceQry.getDbBean(0)).getModifiedBy());
				//STN Code here
				setSTnPoolId((gtwyDeviceQry.getDbBean(0)).getStnPoolId());
				setSTn(getTnByTnPoolId((gtwyDeviceQry.getDbBean(0)).getStnPoolId()));
				//SBC Capacity Allocation code
				setAggregateOffnetCcl((gtwyDeviceQry.getDbBean(0)).getAggregateOffnetCcl());
				setSignalingTierLookupValue((gtwyDeviceQry.getDbBean(0)).getSignalingTierLookupValue());
				setTierOverrideFlag((gtwyDeviceQry.getDbBean(0)).getTierOverrideFlag());
				setIpVersion((gtwyDeviceQry.getDbBean(0)).getIpVersion());
				setPqInstanceId((gtwyDeviceQry.getDbBean(0)).getPqInstanceId());
				setTsoMigLock((gtwyDeviceQry.getDbBean(0)).getTsoMigLock());
				setUpdateComment((gtwyDeviceQry.getDbBean(0)).getUpdateComment());
			}else
			{
				setStatus(InvErrorCode.NO_GATEWAY_DEVICES_FOUND);
				return false;
			}
		}catch(SQLException s)
		{
			s.printStackTrace();	
			setStatus(InvErrorCode.DB_EXCEPTION);
			return false;
		}
		setStatus(InvErrorCode.SUCCESS);
		return true;
	}
	public long getLinesAssigned()
    {
        long linesAssigned = 0;
		try
		{
        if(gatewayDeviceId <= 0)
        {
            log.info("Invalid input, have to set gwDeviceId");
			setStatus(InvErrorCode.GATEWAY_DEVICE_DEVICE_TYPE_ID_NULL);
            return 0;
        }
        TblDeviceMapQuery devQry = new TblDeviceMapQuery();
        devQry.whereGatewayDeviceIdEQ(gatewayDeviceId);
        devQry.query(connection);
        if(devQry.size() <= 0)
        {
            log.info("INvalid Device");
            return 0;
        }
        TblSubscriberDeviceQuery subDevQry = new TblSubscriberDeviceQuery();
        subDevQry.whereDeviceMapIdEQ(devQry.getDbBean(0).getDeviceMapId());
        subDevQry.query(connection);
        linesAssigned = subDevQry.size();
		TblGroupQuery grpQry = new TblGroupQuery();
		grpQry.whereDeviceMapIdEQ(devQry.getDbBean(0).getDeviceMapId());
		grpQry.query(connection);
		for(int i = 0; i < grpQry.size(); i++)
		{
			TblGroupTnQuery grpTnQry = new TblGroupTnQuery();
			grpTnQry.whereGroupIdEQ(grpQry.getDbBean(i).getGroupId());
			grpTnQry.query(connection);
			int grpTnCount = grpTnQry.size();
			linesAssigned = linesAssigned + grpTnCount;
		}
		}
		catch(SQLException s)
        {
            s.printStackTrace();
            setStatus(InvErrorCode.DB_EXCEPTION);
            return 0;
        }

        return linesAssigned;
    }
	
	public Connection getIasaConnection() {
		return iasaConnection;
	}
	public void setIasaConnection(Connection iasaConnection) {
		this.iasaConnection = iasaConnection;
	}
	
	/* get all ENTPRISE_GTWY/CPE_LOCAL_GTWY devices for locations managed by IASA which belong to this NODE 
	 *    Note : SKIP it for locations not belong to this NODE ??
	 */
	/*public List<Device> getAllGatewayDevices(String locationId,String microNode) throws Exception
	{
		List<Device> iasaLocGatewayDevices =  new  ArrayList<Device>();
		
		// Get all Local Gateway
		List<Device> iasaCpeLocalGtwDevList  = getAllCpeLocalGatewayDevices(locationId, microNode);
		// Get all Enterprise Gateway
		List<Device> iasaEnterpriseGtwDevList = getAllEnterpriseGatewayDevices(locationId, microNode);
		
		// Now push all local gateways into the GatewayDevice List
		if ( iasaCpeLocalGtwDevList != null){
			Iterator iasaCpeLocalGtwDevItr = iasaCpeLocalGtwDevList.iterator();
			while ( iasaCpeLocalGtwDevItr.hasNext()){
				Device iasaCpeLocalGtwDev = (Device)iasaCpeLocalGtwDevItr.next();
				if ( iasaCpeLocalGtwDev != null){
					iasaLocGatewayDevices.add(iasaCpeLocalGtwDev);
				}
			}
		}
		
		// Now push all Enterprise gateways into the GatewayDevice List
		if ( iasaEnterpriseGtwDevList != null){
			Iterator iasaEnterpriseGtwDevItr = iasaEnterpriseGtwDevList.iterator();
			while ( iasaEnterpriseGtwDevItr.hasNext()){
				Device iasaEnterpriseGtwDev = (Device)iasaEnterpriseGtwDevItr.next();
				if ( iasaEnterpriseGtwDev != null){
					iasaLocGatewayDevices.add(iasaEnterpriseGtwDev);
				}
			}
		}
		
		return iasaLocGatewayDevices;
	}*/

	/* get all PENDING ENTPRISE_GTWY/CPE_LOCAL_GTWY devices for locations managed by IASA which belong to this NODE
	 *    Note : SKIP it for locations not belong to this NODE ??
	 */
	/*public List<Device> getAllPendGatewayDevices(String locationId,String microNode) throws Exception
	{
		List<Device> iasaLocGatewayDevices =  new  ArrayList<Device>();

		// Get all pending Local Gateway
		List<Device> iasaCpeLocalGtwDevList  = getAllPendCpeLocalGatewayDevices(locationId, microNode);
		// Get all pending Enterprise Gateway
		List<Device> iasaEnterpriseGtwDevList = getAllPendEnterpriseGatewayDevices(locationId, microNode);

		// Now push all pending local gateways into the GatewayDevice List
		if ( iasaCpeLocalGtwDevList != null){
			Iterator iasaCpeLocalGtwDevItr = iasaCpeLocalGtwDevList.iterator();
			while ( iasaCpeLocalGtwDevItr.hasNext()){
				Device iasaCpeLocalGtwDev = (Device)iasaCpeLocalGtwDevItr.next();
				if ( iasaCpeLocalGtwDev != null){
					iasaLocGatewayDevices.add(iasaCpeLocalGtwDev);
				}
			}
		}

		// Now push all pending Enterprise gateways into the GatewayDevice List
		if ( iasaEnterpriseGtwDevList != null){
			Iterator iasaEnterpriseGtwDevItr = iasaEnterpriseGtwDevList.iterator();
			while ( iasaEnterpriseGtwDevItr.hasNext()){
				Device iasaEnterpriseGtwDev = (Device)iasaEnterpriseGtwDevItr.next();
				if ( iasaEnterpriseGtwDev != null){
					iasaLocGatewayDevices.add(iasaEnterpriseGtwDev);
				}
			}
		}

		return iasaLocGatewayDevices;
	}*/
	
	/*public List<Device> getAllCpeLocalGatewayDevices(String locationId,String microNode) throws Exception
	{
		log.info(" getAllCpeLocalGatewayDevices(locationId="+locationId+",microNode="+microNode+")");
		List<Device> iasaCpeLocalGtwDevList = new ArrayList<Device>();

		//Connection iasa_connection = null;
		try
		{
			//iasa_connection = IASAConnectionHelper.getIASAConnection(connection);
			if (iasaConnection == null)
				throw new Exception("Iasa DB Connection is not set");

			SBCMigration sbcMigHandler = new SBCMigration(connection, iasaConnection);

			List<IpcomGatewayInfoDbBean> ipcomGatewayInfoDbBeanList =
				sbcMigHandler.getCpeLclGtwyByLocidAndMicNode(locationId, microNode);

			log.info(" ipcomGatewayInfoDbBeanList.size = " +ipcomGatewayInfoDbBeanList.size());
			log.info(" ipcomGatewayInfoDbBeanList = " +ipcomGatewayInfoDbBeanList);

			if ( ipcomGatewayInfoDbBeanList != null){
				Iterator ipcomGatewayInfoDbBeanItr = ipcomGatewayInfoDbBeanList.iterator();

				while ( ipcomGatewayInfoDbBeanItr.hasNext()){
					IpcomGatewayInfoDbBean ipcomGatewayInfo = (IpcomGatewayInfoDbBean)ipcomGatewayInfoDbBeanItr.next();
					if ( ipcomGatewayInfo != null ){
						log.info("Converting to ESAP Device for ipcomGatewayInfo="+ipcomGatewayInfo);
						Device iasaDeviceMap = new Device(ipcomGatewayInfo,null,connection);

						// For CPE Local Gateway Device use esap DeviceMapId seq id ..
						DBTblDeviceMap deviceDB = new DBTblDeviceMap();

						int deviceSeqId = deviceDB.getDeviceMapIdSeqNextVal(connection);
			            iasaDeviceMap.setDeviceMapId(deviceSeqId);
			            iasaDeviceMap.setGwDeviceId(deviceSeqId);
			            log.info("new esap DeviceMapId seq id ="+deviceSeqId);
						GatewayDevice iasaCpeLocalGtwDev = new GatewayDevice(ipcomGatewayInfo,null,connection,iasaConnection);

						// use same DeviceMapId as GatewayDeviceId
						iasaCpeLocalGtwDev.setGatewayDeviceId((long)deviceSeqId);
						iasaDeviceMap.gwDvObjList.add(iasaCpeLocalGtwDev);
						iasaCpeLocalGtwDevList.add(iasaDeviceMap);
					}
				}
			}


		}catch (Exception e)
		{
			setStatus(InvErrorCode.DB_EXCEPTION);
			log.info("DB_FAILURE in getLocationFromIasa Location");
			e.printStackTrace();
			throw new Exception(e);
		}/*finally{
			if (iasa_connection != null){
				iasa_connection.close();
				iasa_connection = null;
			}

		}*/
	/*	return iasaCpeLocalGtwDevList;
	}*/

	/*public List<Device> getAllPendCpeLocalGatewayDevices(String locationId,String microNode) throws Exception
	{
		log.info(" getAllPendCpeLocalGatewayDevices(locationId="+locationId+",microNode="+microNode+")");
		List<Device> iasaCpeLocalGtwDevList = new ArrayList<Device>();
		
		//Connection iasa_connection = null;
		try
		{
			//iasa_connection = IASAConnectionHelper.getIASAConnection(connection);
			if (iasaConnection == null)
				throw new Exception("Iasa DB Connection is not set");
			
			SBCMigration sbcMigHandler = new SBCMigration(connection, iasaConnection);
			
			List<IpcomGatewayInfoDbBean> ipcomGatewayInfoDbBeanList = 
				sbcMigHandler.getPendCpeLclGtwyByLocidAndMicNode(locationId, microNode);
			
			log.info(" pending ipcomGatewayInfoDbBeanList.size = " +ipcomGatewayInfoDbBeanList.size());
			log.info(" pending ipcomGatewayInfoDbBeanList = " +ipcomGatewayInfoDbBeanList);
			
			if ( ipcomGatewayInfoDbBeanList != null){
				Iterator ipcomGatewayInfoDbBeanItr = ipcomGatewayInfoDbBeanList.iterator();
				
				while ( ipcomGatewayInfoDbBeanItr.hasNext()){
					IpcomGatewayInfoDbBean ipcomGatewayInfo = (IpcomGatewayInfoDbBean)ipcomGatewayInfoDbBeanItr.next();
					if ( ipcomGatewayInfo != null ){
						log.info("Converting to ESAP Device for ipcomGatewayInfo="+ipcomGatewayInfo);
						Device iasaDeviceMap = new Device(ipcomGatewayInfo,null,connection);
						
						// For CPE Local Gateway Device use esap DeviceMapId seq id ..
						DBTblDeviceMap deviceDB = new DBTblDeviceMap();
						
						int deviceSeqId = deviceDB.getDeviceMapIdSeqNextVal(connection);
			            iasaDeviceMap.setDeviceMapId(deviceSeqId);
			            iasaDeviceMap.setGwDeviceId(deviceSeqId);
			            
			            log.info("new esap DeviceMapId seq id ="+deviceSeqId);
						GatewayDevice iasaCpeLocalGtwDev = new GatewayDevice(ipcomGatewayInfo,null,connection,iasaConnection);
						
						// use same DeviceMapId as GatewayDeviceId
						iasaCpeLocalGtwDev.setGatewayDeviceId((long)deviceSeqId);
						iasaDeviceMap.gwDvObjList.add(iasaCpeLocalGtwDev);
						iasaCpeLocalGtwDevList.add(iasaDeviceMap);
					}
				}
			}
			
			
		}catch (Exception e)
		{
			setStatus(InvErrorCode.DB_EXCEPTION);
			log.info("DB_FAILURE in getLocationFromIasa Location");
			e.printStackTrace();
			throw new Exception(e);
		}/*finally{
			if (iasa_connection != null){
				iasa_connection.close(); 
				iasa_connection = null;
			}

		}*/	
		/*return iasaCpeLocalGtwDevList;
	}*/
	
	/* get all Enterprise Gateways for the loc and mic node
	 * returns list of GatewayDevice object
	 */
	/*public List<Device> getAllEnterpriseGatewayDevices(String locationId,String microNode) throws Exception
	{
		log.info("Inside getAllEnterpriseGatewayDevices(locationId="+locationId+",microNode="+microNode);
		List<Device> iasaEnterpriseGtwDevList = new ArrayList<Device>();
		
		//Connection iasa_connection = null;
		try
		{
			//iasa_connection = IASAConnectionHelper.getIASAConnection(connection);
			if (iasaConnection == null)
				throw new Exception("Iasa DB Connection is not set");
			
			SBCMigration sbcMigHandler = new SBCMigration(connection, iasaConnection);
			
			List<IpcomDeviceXrefDbBean> ipcomDevXrefDbBeanList = 
				sbcMigHandler.getEntGtwyByLocIdAndMicNode(locationId, microNode);
			log.info("ipcomDevXrefDbBeanList.size()="+ipcomDevXrefDbBeanList.size());
			if ( ipcomDevXrefDbBeanList != null){
				log.info("ipcomDevXrefDbBeanList is NOT NULL");
				Iterator ipcomDevXrefDbBeanItr = ipcomDevXrefDbBeanList.iterator();
				
				while ( ipcomDevXrefDbBeanItr.hasNext()){
					log.info("Adding ipcomDevXrefDbBeanItr="+ipcomDevXrefDbBeanItr);
					IpcomDeviceXrefDbBean ipcomDevXrefDbBean = (IpcomDeviceXrefDbBean)ipcomDevXrefDbBeanItr.next();
					if ( ipcomDevXrefDbBean != null ){
						log.info("Add INV DEV ipcomDevXrefDbBean="+ipcomDevXrefDbBean.getLocDevid());
						Device iasaDeviceMap = new Device(null,ipcomDevXrefDbBean,connection);
						GatewayDevice iasaEntGtwDev = new GatewayDevice(null,ipcomDevXrefDbBean,connection,iasaConnection);
						iasaDeviceMap.gwDvObjList.add(iasaEntGtwDev);
						iasaEnterpriseGtwDevList.add(iasaDeviceMap);
					}else{
						log.info("ipcomDevXrefDbBean is NULL");
					}
				}
			}else{
				log.info("ipcomDevXrefDbBeanList is NULL");
			}
			
			
		}catch (Exception e)
		{
			setStatus(InvErrorCode.DB_EXCEPTION);
			log.info("DB_FAILURE in getLocationFromIasa Location");
			e.printStackTrace();
			throw new Exception(e);
		}finally{
			/*if (iasa_connection != null){
				iasa_connection.close(); 
				iasa_connection = null;
			}*/

		/*}		
		return iasaEnterpriseGtwDevList;
	}*/

	/* get all Pending Enterprise Gateways for the loc and mic node
	 * returns list of GatewayDevice object
	 */
	/*public List<Device> getAllPendEnterpriseGatewayDevices(String locationId,String microNode) throws Exception
	{
		log.info("Inside getPendAllEnterpriseGatewayDevices(locationId="+locationId+",microNode="+microNode);
		List<Device> iasaEnterpriseGtwDevList = new ArrayList<Device>();

		//Connection iasa_connection = null;
		try
		{
			//iasa_connection = IASAConnectionHelper.getIASAConnection(connection);
			if (iasaConnection == null)
				throw new Exception("Iasa DB Connection is not set");

			SBCMigration sbcMigHandler = new SBCMigration(connection, iasaConnection);

			List<IpcomDeviceXrefDbBean> ipcomDevXrefDbBeanList =
				sbcMigHandler.getPendEntGtwyByLocIdAndMicNode(locationId, microNode);
			log.info("pending ipcomDevXrefDbBeanList.size()="+ipcomDevXrefDbBeanList.size());
			if ( ipcomDevXrefDbBeanList != null){
				log.info("pending ipcomDevXrefDbBeanList is NOT NULL");
				Iterator ipcomDevXrefDbBeanItr = ipcomDevXrefDbBeanList.iterator();

				while ( ipcomDevXrefDbBeanItr.hasNext()){
					log.info("Adding pending ipcomDevXrefDbBeanItr="+ipcomDevXrefDbBeanItr);
					IpcomDeviceXrefDbBean ipcomDevXrefDbBean = (IpcomDeviceXrefDbBean)ipcomDevXrefDbBeanItr.next();
					if ( ipcomDevXrefDbBean != null ){
						log.info("Add INV DEV pending ipcomDevXrefDbBean="+ipcomDevXrefDbBean.getLocDevid());
						Device iasaDeviceMap = new Device(null,ipcomDevXrefDbBean,connection);
						GatewayDevice iasaEntGtwDev = new GatewayDevice(null,ipcomDevXrefDbBean,connection,iasaConnection);
						iasaDeviceMap.gwDvObjList.add(iasaEntGtwDev);
						iasaEnterpriseGtwDevList.add(iasaDeviceMap);
					}else{
						log.info("pending ipcomDevXrefDbBean is NULL");
					}
				}
			}else{
				log.info("pending ipcomDevXrefDbBeanList is NULL");
			}


		}catch (Exception e)
		{
			setStatus(InvErrorCode.DB_EXCEPTION);
			log.info("DB_FAILURE in getLocationFromIasa Location");
			e.printStackTrace();
			throw new Exception(e);
		}finally{
			/*if (iasa_connection != null){
				iasa_connection.close();
				iasa_connection = null;
			}*/

		/*}
		return iasaEnterpriseGtwDevList;
	}*/
	
	

	
	
	
	
	
	
	
	

	

	

	
	
    public String getTnByTnPoolId(long tnPoolId)
    {
        log.info("Entering Location::getTnByTnPoolId");
        String tn = "";
        try
        {
            TblPublicTnPoolQuery tnQry = new TblPublicTnPoolQuery();
            tnQry.whereTnPoolIdEQ((int) tnPoolId);
            tnQry.query(connection);
            if (tnQry.size() <= 0)
            {
                log.info("TN [" + tn + "] Not Found");
                return tn;
            }
            tn = tnQry.getDbBean(0).getTn();
            log.info("Retrieved TN [" + tn + "] For TnId [" + tnPoolId + "]");
        }
        catch (SQLException e)
        {
            setStatus(InvErrorCode.DB_EXCEPTION);
            log.info("Failed to retrieve TN");
            e.printStackTrace();
            return tn;
        }
        setStatus(InvErrorCode.SUCCESS);
        log.info("Successfully retrived TN");
        return tn;
    }
    
public ArrayList<TblGroupDbBean> getGroupbyGatewayDeviceId(String pDeviceMapId) throws Exception{
		
		log.info(" Entering getGroupbyGatewayDeviceId  querying");
		ArrayList<TblGroupDbBean> resultList = null;
		TblGroupDbBean tblGroupDbBean = null;
		PreparedStatement pStmt = null;
		ResultSet rs = null;
		StringBuffer sql = new StringBuffer();
		sql.append("select * from tbl_group where device_map_id = ?");
		sql.append(" and device_map_id in (select device_map_id from tbl_device_map where device_map_id = ? and gateway_device_id in (  ");
		sql.append("  select gateway_device_id from tbl_gateway_device_info ");
		sql.append("  where device_type_id in (select device_type_id from tbl_device_types where device_realtype_id = 4))) ");
		
		log.info("getGroupbyGatewayDeviceId sql string :  "+sql.toString());
		
		try {
			pStmt = connection.prepareStatement(sql.toString());
			pStmt.setString(1, pDeviceMapId);
			pStmt.setString(2, pDeviceMapId);
			
			if (null != pStmt)
				rs = pStmt.executeQuery();
			if ( rs != null ){
				resultList = new ArrayList<TblGroupDbBean>();
				while (rs.next()) {
					tblGroupDbBean = new TblGroupDbBean();
					
					tblGroupDbBean.setGroupId((int)rs.getLong(1));
					tblGroupDbBean.setLocationId(rs.getString(2));
					tblGroupDbBean.setDepartmentId(rs.getString(3));
					tblGroupDbBean.setGroupName(rs.getString(4));
					tblGroupDbBean.setGroupType(rs.getLong(5));
					tblGroupDbBean.setPackageId(rs.getLong(6));
					tblGroupDbBean.setDeviceMapId(rs.getLong(7));
					tblGroupDbBean.setCidFirstName(rs.getString(8));
					tblGroupDbBean.setCidLastName(rs.getString(9));
					tblGroupDbBean.setPbxPilotPoolId(rs.getLong(10));
					tblGroupDbBean.setExtension(rs.getString(11));
					tblGroupDbBean.setPrivateNumber(rs.getString(12));
					tblGroupDbBean.setLinePort(rs.getString(13));
					tblGroupDbBean.setPbxCidPoolId(rs.getLong(14));
					tblGroupDbBean.setPbxMaxCclLimit(rs.getLong(15));
					tblGroupDbBean.setKeyTerminationType(rs.getLong(16));
					tblGroupDbBean.setKeyFwdTn(rs.getString(17));
					tblGroupDbBean.setKeyVmMaxsizeId(rs.getLong(18));
					tblGroupDbBean.setKeyVmBoxNum(rs.getString(19));
					tblGroupDbBean.setCreatedBy(rs.getString(20));
					tblGroupDbBean.setCreationDate(rs.getTimestamp(21));
					tblGroupDbBean.setModifiedBy(rs.getString(22));
					tblGroupDbBean.setLastModifiedDate(rs.getTimestamp(23));
					tblGroupDbBean.setActiveInd(rs.getLong(24));
					tblGroupDbBean.setPbxRedirectTn(rs.getString(25));
					tblGroupDbBean.setPbxRedirectTn(rs.getString(26));
					tblGroupDbBean.setEnvOrderId(rs.getLong(27));
					tblGroupDbBean.setLinePortLength(rs.getLong(28));
					tblGroupDbBean.setInvitationTimer(rs.getLong(29));
					tblGroupDbBean.setPqInstanceId(rs.getLong(30));
					resultList.add(tblGroupDbBean);
				}
				
				log.info(" Entering getGroupbyGatewayDeviceId  Result size " + resultList.size());
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw e;
		} finally {
			try {
				if (null != pStmt)
					pStmt.close();
				if (null != rs)
					rs.close();
			} catch (Exception e) {
				e.printStackTrace();
				throw e;
			}
		}
		
		return resultList;
		
	}

	public boolean unfreezeDevice (ArrayList<Long> deviceIds) throws SQLException
	{
		String deviceIdStr = "";
		if(deviceIds.size() >1){
			for(int i =0 ;i<deviceIds.size();i++){
				deviceIdStr += deviceIds.get(i)+",";
			}
			deviceIdStr = deviceIdStr.substring(0, deviceIdStr.length()-1);
		}else{
			deviceIdStr = deviceIds.get(0).toString();
		}
		
		return updateMigLockonDevices(deviceIdStr+"", (short)0);
	}
	
	public boolean freezeDevice (ArrayList<Long> deviceIds) throws SQLException
	{
		String deviceIdStr = "";
		if(deviceIds.size() >1){
			for(int i =0 ;i<deviceIds.size();i++){
				deviceIdStr += deviceIds.get(i)+",";
			}
			deviceIdStr = deviceIdStr.substring(0, deviceIdStr.length()-1);
		}else{
			deviceIdStr = deviceIds.get(0).toString();
		}
		
		return updateMigLockonDevices(deviceIdStr+"",  (short)1);
	}
	
	public boolean updateMigLockonDevices (String deviceIds,short lockValue) throws SQLException
	{
		boolean isUpdated = false;
		Statement stmt = null;
		try
		{
			deviceIds = deviceIds.replaceAll(":", ",");
			String deviceQry = "UPDATE tbl_gateway_device_info SET tso_mig_lock = "+lockValue+" WHERE gateway_device_id in("+deviceIds+")";
			stmt = connection.createStatement();
			stmt.executeUpdate(deviceQry);
			isUpdated = true;
		}catch (Exception e)
		{
			e.printStackTrace();
			return false;
		}
		finally{
			if(stmt != null){
				stmt.close();
			}
		}
		return isUpdated;
	}

}

