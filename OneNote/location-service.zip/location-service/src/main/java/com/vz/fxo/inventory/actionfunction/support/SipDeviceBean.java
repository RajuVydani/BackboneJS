package com.vz.fxo.inventory.actionfunction.support;

import java.util.ArrayList;
import java.util.List;
import java.sql.Connection;
import java.sql.Timestamp;

import esap.db.DBTblSipDeviceInfo;
import esap.db.TblSipDeviceInfoQuery;
import esap.db.TblSipDeviceInfoDbBean;
import java.sql.Timestamp;
import java.sql.SQLException;


public class SipDeviceBean
{
	
	//members
	protected int sipDeviceId;
	protected String deviceName;
	protected long deviceTypeId;
	protected DeviceTypeBean deviceTypeBean;
	protected String macAddress;
	protected String ipAddress;
	protected String ipSecAddress;
	protected String serialNumber;
	protected long portsAvailable;
	protected long portsAssigned;
	protected String cpeUserName;
	protected String cpePassword;
	protected long codecId;
	protected String businessLocation;
	protected String stationLocation;
	protected String deviceLocation;
	protected long firmwareVersionId;
	protected long isManaged;
    protected long envOrderId;
	protected String createdBy;
	protected String modifiedBy;
	protected java.sql.Timestamp creationDate;
	protected java.sql.Timestamp lastModifiedDate;
	protected long brixInd;
	protected String bsDeviceId;
	protected List<String> logTrail;
	//Jan 2011 Release Changes
	protected String cpeNetworkFeatures;
	protected short internalAdmin;

    	/**
	 * Default Constructor -- Initializes all fields to default values.
	 */
    	public SipDeviceBean()
	{
		this.sipDeviceId = 0;
		this.deviceName = new String("");
		this.deviceTypeId = 0;
		this.deviceTypeBean = null;
		this.macAddress = new String("NONE");
		this.ipAddress = new String("NONE");
		this.ipSecAddress = new String("NONE");
		this.serialNumber = new String("NONE");
		this.portsAvailable = -1;
		this.portsAssigned  = -1;
		this.cpeUserName = new String("NONE");
		this.cpePassword = new String("NONE");
		this.codecId = -1;
		this.businessLocation = new String("NONE");
		this.stationLocation = new String("NONE");
		this.deviceLocation = new String("NONE");
		this.firmwareVersionId =-1;
		this.isManaged = 0;
                this.envOrderId = 0;	
          	this.createdBy = new String("");
		this.modifiedBy = new String("");
		this.creationDate = null;
		this.lastModifiedDate = null;
		this.brixInd=-1;
		this.bsDeviceId = new String("NONE");
		deviceTypeBean = new DeviceTypeBean();
		this.logTrail = null;
		logTrail = new ArrayList<String>();
		//Jan 2011 Release Changes
		this.cpeNetworkFeatures = "";
		this.internalAdmin = -1;
	}
	/**
	 * Constructor
	 * @param sipDevice
	 */
	public SipDeviceBean(SipDeviceBean sipDevice)
	{
		this.sipDeviceId = sipDevice.sipDeviceId;
		this.deviceName = sipDevice.deviceName;
		this.deviceTypeId = sipDevice.deviceTypeId;
		this.deviceTypeBean = sipDevice.deviceTypeBean;
		this.macAddress = sipDevice.macAddress;
		this.ipAddress = sipDevice.ipAddress;
		this.ipSecAddress = sipDevice.ipSecAddress;
		this.serialNumber = sipDevice.serialNumber;
		this.portsAvailable = sipDevice.portsAvailable;
		this.portsAssigned =  sipDevice.portsAssigned;
		this.cpeUserName = sipDevice.cpeUserName;
		this.cpePassword = sipDevice.cpePassword;
		this.codecId = sipDevice.codecId;
		this.businessLocation = sipDevice.businessLocation;
		this.stationLocation = sipDevice.stationLocation;
		this.deviceLocation = sipDevice.deviceLocation;
		this.firmwareVersionId = sipDevice.firmwareVersionId;
		this.isManaged = sipDevice.isManaged;
                this.envOrderId = sipDevice.envOrderId;		
        	this.createdBy = sipDevice.createdBy;
		this.modifiedBy = sipDevice.modifiedBy;
		this.creationDate = sipDevice.creationDate;
		this.brixInd = sipDevice.brixInd;
		this.bsDeviceId = sipDevice.bsDeviceId;
		this.lastModifiedDate = sipDevice.lastModifiedDate;
		this.logTrail = sipDevice.logTrail;
		//Jan 2011 Release Changes
		this.cpeNetworkFeatures = sipDevice.cpeNetworkFeatures;
		this.internalAdmin = sipDevice.internalAdmin;
	}

	//getters - setters
	
	public int getSipDeviceId() {
		return sipDeviceId;
	}
	public java.sql.Timestamp getCreationDate() {
		return creationDate;
	}
	public void setCreationDate(java.sql.Timestamp creationDate) {
		this.creationDate = creationDate;
	}
	public java.sql.Timestamp getLastModifiedDate() {
		return lastModifiedDate;
	}
	public void setLastModifiedDate(java.sql.Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}
	public void setSipDeviceId(int sipDeviceId) {
		this.sipDeviceId = sipDeviceId;
	}
	public DeviceTypeBean getDeviceTypeBean() {
                return deviceTypeBean;
        }
        public void setDeviceTypeBean(DeviceTypeBean deviceTypeBean) {
                this.deviceTypeBean = deviceTypeBean;
        }
	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public long getCodecId() {
		return codecId;
	}

	public void setCodecId(long codecId) {
		this.codecId = codecId;
	}

	public String getDeviceName() {
		return deviceName;
	}

	public void setDeviceName(String deviceName) {
		this.deviceName = deviceName;
	}

	public long getDeviceTypeId() {
		return deviceTypeId;
	}

	public void setDeviceTypeId(long deviceTypeId) {
		this.deviceTypeId = deviceTypeId;
	}

	public String getMacAddress() {
		return macAddress;
	}

	public void setMacAddress(String macAddress) {
		this.macAddress = macAddress;
	}
	public String getIpAddress() {
		return ipAddress;
	}

	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}
	public String getIpSecAddress() {
		return ipSecAddress;
	}

	public void setIpSecAddress(String ipSecAddress) {
		this.ipSecAddress = ipSecAddress;
	}

	public String getSerialNumber() {
		return serialNumber;
	}

	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}

	public long getPortsAvailable() {
		return portsAvailable;
	}

	public void setPortsAvailable(long portsAvailable) {
		this.portsAvailable = portsAvailable;
	}
	public long getPortsAssigned() {
		return portsAssigned;
	}

	public void setPortsAssigned(long portsAssigned) {
		this.portsAssigned = portsAssigned;
	}	

	public String getCpeUserName() {
		return cpeUserName;
	}

	public void setCpeUserName(String cpeUserName) {
		this.cpeUserName = cpeUserName;
	}

	public String getCpePassword() {
		return cpePassword;
	}

	public void setCpePassword(String cpePassword) {
		this.cpePassword = cpePassword;
	}

	public String getBusinessLocation() {
		return businessLocation;
	}

	public void setBusinessLocation(String businessLocation) {
		this.businessLocation = businessLocation;
	}

	public String getStationLocation() {
		return stationLocation;
	}

	public void setStationLocation(String stationLocation) {
		this.stationLocation = stationLocation;
	}

	public String getDeviceLocation() {
                return deviceLocation;
        }

        public void setDeviceLocation(String deviceLocation) {
                this.deviceLocation = deviceLocation;
        }

	public long getFirmwareVersionId() {
		return firmwareVersionId;
	}

	public void setFirmwareVersionId(long firmwareVersionId) {
		this.firmwareVersionId = firmwareVersionId;
	}

	public long getIsManaged() {
		return isManaged;
	}

	public void setIsManaged(long isManaged) {
		this.isManaged = isManaged;
	}
			
        public long getEnvOrderId() {
		return envOrderId;
	}
	public void setEnvOrderId(long envOrderId) {
		this.envOrderId = envOrderId;
	}
	public long getBrixInd() {
		return brixInd;
	}
	public void setBrixInd(long brixInd) {
		this.brixInd = brixInd;
	} 
	public String getBsDeviceId() {
		return bsDeviceId;
	}

	public void setBsDeviceId(String bsDeviceId) {
		this.bsDeviceId = bsDeviceId;
	}
	public void setLogTrail(String logStr)
    {
            logTrail.add(logStr);
    }
    public List<String> getLogTrail()
    {
            return logTrail;
    }
    //Jan 2011 Release Changes
    public String getCpeNetworkFeatures() {
		return cpeNetworkFeatures;
	}
	public void setCpeNetworkFeatures(String cpeNetworkFeatures) {
		this.cpeNetworkFeatures = cpeNetworkFeatures;
	}

	public short getInternalAdmin() {
        return internalAdmin;
    }
    public void setInternalAdmin(short internalAdmin) {
        this.internalAdmin = internalAdmin;
    }

	 public void initilizeTODefault() {
			this.sipDeviceId = 0;
			this.deviceName = new String("");
			this.deviceTypeId = 0;
			this.deviceTypeBean = null;
			this.macAddress = new String("NONE");
			this.ipAddress = new String("NONE");
			this.ipSecAddress = new String("NONE");
			this.serialNumber = new String("NONE");
			this.portsAvailable = -1;
			this.cpeUserName = new String("NONE");
			this.cpePassword = new String("NONE");
			this.codecId = -1;
			this.businessLocation = new String("NONE");
			this.stationLocation = new String("NONE");
			this.deviceLocation = new String("NONE");
			this.firmwareVersionId = -1;
			this.isManaged = 0;
	        this.envOrderId = 0;	
	        this.createdBy = new String("");
			this.modifiedBy = new String("");
			this.creationDate = null;
			this.lastModifiedDate = null;
			this.brixInd=-1;
			this.bsDeviceId = new String("");
			deviceTypeBean = new DeviceTypeBean();
			//Jan 2011 Release Changes
			this.cpeNetworkFeatures = "";
			this.internalAdmin = -1;
	 }
	
}
