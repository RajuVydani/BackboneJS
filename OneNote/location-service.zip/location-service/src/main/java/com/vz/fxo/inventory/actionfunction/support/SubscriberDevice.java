package com.vz.fxo.inventory.actionfunction.support;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Timestamp;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import esap.db.DBTblGatewayDeviceInfo;
import esap.db.DBTblSipDeviceInfo;
import esap.db.DBTblSubscriberDevice;
import esap.db.TblDeviceMapDbBean;
import esap.db.TblDeviceMapQuery;
import esap.db.TblSubscriberDeviceDbBean;
import esap.db.TblSubscriberDeviceQuery;


public class SubscriberDevice extends SubscriberDeviceBean
{	
	
	private static Logger log = LoggerFactory.getLogger(SubscriberDevice.class.toString());
	//members
	private Connection connection;
	//private String statusCode;
	//private String statusDesc;

	public SubscriberDevice(Connection con)
	{
		this.connection = con;
	}
	public SubscriberDevice(Connection con, SubscriberDeviceBean subDevBean)
	{
		super(subDevBean);
		this.connection = con;
	}
		
	public Connection getConnection() {
		return connection;
	}
	public void setConnection(Connection connection) {
		this.connection = connection;
	}
	InvErrorCode status = InvErrorCode.INTERNAL_ERROR;
	public int getStatusCode() {
		return status.getErrorCode();
	}

	public void setStatus(InvErrorCode status) {
		this.status = status;
	}

	public String getStatusDesc() {
		return status.getErrorDesc();
	}

	public boolean validateSubscriberDevice()
	{
		return true;
	}
	
	public boolean addSubscriberDevice() throws SQLException, Exception
	{
		log.info("Entering Subscriberdevice::addSubscriberDevice");
	    	
	//	try
	//	{
		    DBTblSubscriberDevice subDevDB = new DBTblSubscriberDevice();
		    subDevDB.getSubDeviceIdSeqNextVal(connection);	
		    subDevDB.setSubId(getSubId());
		    if(getDeviceMapId() > 0)		
		    	subDevDB.setDeviceMapId(getDeviceMapId());
		    else if(getSipDeviceId() > 0)
		    {
			TblDeviceMapQuery devMapQry = new TblDeviceMapQuery();
			devMapQry.whereSipDeviceIdEQ(getSipDeviceId());
			devMapQry.query(connection);
			if(devMapQry.size() == 1)
				subDevDB.setDeviceMapId((devMapQry.getDbBean(0)).getDeviceMapId());
			else
			{
				log.info("Device map id/sipdeviceid/gatewaydeviceId must be provided to add Subscriber device");
				setStatus(InvErrorCode.NO_DEVICE_MAP_ID_OR_SIP_GATEWAY_DEVICE_ID);
				return false;
			}		
		    }
		    else if(getGatewayDeviceId() > 0)
		    {
			TblDeviceMapQuery devMapQry = new TblDeviceMapQuery();
			devMapQry.whereGatewayDeviceIdEQ(getGatewayDeviceId());
			devMapQry.query(connection);
			if(devMapQry.size() == 1)
				subDevDB.setDeviceMapId((devMapQry.getDbBean(0)).getDeviceMapId());
			else
			{
				log.info("Device map id/sipdeviceid/gatewaydeviceId must be provided to add Subscriber device");
				setStatus(InvErrorCode.NO_DEVICE_MAP_ID_OR_SIP_GATEWAY_DEVICE_ID);
				return false;
			}		
		    }
		    else
		    {
			log.info("Device map id/sipdeviceid/gatewaydeviceId must be provided to add Subscriber device");
			setStatus(InvErrorCode.NO_DEVICE_MAP_ID_OR_SIP_GATEWAY_DEVICE_ID);
			return false;
		    }									
		    subDevDB.setLinePort(getLinePort());
		    subDevDB.setLineKey(getLineKey());
		    subDevDB.setCallsPerLine(getCallsPerLine());
		    subDevDB.setPortNum(getPortNum());
		    subDevDB.setScaLineLabel(getScaLineLabel());
		    subDevDB.setScaType(getScaType());
		    subDevDB.setScaAuthUserid(getScaAuthUserid());
		    subDevDB.setBlfAttdntRegline(getBlfAttdntRegline());
		    subDevDB.setBlfUrl(getBlfUrl());

		    log.info("EnvOrderId = <" + getEnvOrderId() + ">");
		    if(getEnvOrderId() > 0)
    	    		subDevDB.setEnvOrderId(getEnvOrderId());
		    else
    	    		subDevDB.setEnvOrderIdNull();
	

            // subDevDB.setCreatedBy(getCreatedBy());
            subDevDB.setCreatedBy("SYSTEM");
            // subDevDB.setModifiedBy(getModifiedBy());
            subDevDB.setModifiedBy("SYSTEM");
            subDevDB.setCreationDate(new Timestamp(System.currentTimeMillis()));
            subDevDB.setLastModifiedDate(new Timestamp(System.currentTimeMillis()));

	            subDevDB.insert(connection);		
			Device devObj = new Device(connection);
			devObj.setDeviceMapId((int)subDevDB.getDeviceMapId());
			if(devObj.getDetails())
			{
				if(devObj.getSipDeviceId() > 0)
				{
					SipDevice sipDev = new SipDevice(connection);
					sipDev.setSipDeviceId((int)devObj.getSipDeviceId());
					if(sipDev.getDetails())
					{
		    			DBTblSipDeviceInfo sipDevObj = new DBTblSipDeviceInfo();
						sipDevObj.whereSipDeviceIdEQ(sipDev.getSipDeviceId());	
						long tmpPortsAva = 0;
							int updatedCount = 0;
						if(sipDev.getPortsAssigned() >0){
							sipDevObj.setPortsAssigned(sipDev.getPortsAssigned() +  1);	
						} else {
							sipDevObj.setPortsAssigned(1);
						}
						if(sipDev.getPortsAvailable() > 0)
						{
							tmpPortsAva = sipDev.getPortsAvailable() - 1;
							sipDevObj.setPortsAvailable(tmpPortsAva);
						}
						FkValidationUtil.isValidSipDeviceInfoForMod(connection,sipDevObj);
						updatedCount = sipDevObj.updateSpByWhere(connection);
						log.info("Sip Device:"+sipDev.getSipDeviceId()+" updated no of rows:"+updatedCount+ " to portsAvailable:"+tmpPortsAva);
						
					}
				}
				if(devObj.getGwDeviceId() > 0)
				{
					GatewayDevice gwDev = new GatewayDevice(connection);
                    gwDev.setGatewayDeviceId(devObj.getGwDeviceId());
                    if(gwDev.getDetails())
                    {
                        DBTblGatewayDeviceInfo gwDevObj = new DBTblGatewayDeviceInfo();
                        gwDevObj.whereGatewayDeviceIdEQ(gwDev.getGatewayDeviceId());
                        long tmpPortsAva = 0;
                            int updatedCount = 0;
    						if(gwDev.getPortsAssigned() >0){
    							gwDevObj.setPortsAssigned(gwDev.getPortsAssigned() +  1);	
    						} else {
    							gwDevObj.setPortsAssigned(1);
    						}    
                        /*if(gwDev.getPortsAvailable() > 0)
                        {
                            tmpPortsAva = gwDev.getPortsAvailable() - 1;
                            gwDevObj.setPortsAvailable(tmpPortsAva);
                            updatedCount = gwDevObj.updateSpByWhere(connection);
                        }*/
    						  updatedCount = gwDevObj.updateSpByWhere(connection);	
                        log.info("Gw Device:"+gwDev.getGatewayDeviceId()+" updated no of rows:"+updatedCount+ " to portsAvailable:"+tmpPortsAva);

                    }
				}
			}
		/*}
		catch(SQLException e)
                {
			e.printStackTrace();	
			log.info("DB_FAILURE in addSubscriberDevice");
			setStatus(InvErrorCode.DB_EXCEPTION);
                        return false;
                }*/
		
		return true;
	}
	
	public boolean getSubDeviceDetailsBySubDeviceId()
	{
		log.info("Entering Subscriber::getSubscriberDetailsBySubId");
		
		try
		{
			TblSubscriberDeviceQuery subDevQry = new TblSubscriberDeviceQuery();
			subDevQry.whereSubDeviceIdEQ(getSubDeviceId());
			subDevQry.query(connection);
			if(subDevQry.size() <= 0)
			{
				log.info("Subscriber device not Found");
				setStatus(InvErrorCode.NO_SUBSCRIBER_DEVICE_TO_SUBSCRIBER);
				return false;
			}
			TblSubscriberDeviceDbBean subDevBean = subDevQry.getDbBean(0);
			//TODO populate remaining members
			setSubDeviceId(subDevBean.getSubDeviceId());
			setDeviceMapId(subDevBean.getDeviceMapId());
			
		}
		catch(SQLException e)
		{
			e.printStackTrace();	
			setStatus(InvErrorCode.DB_EXCEPTION);
			return false;
		}

		setStatus(InvErrorCode.SUCCESS);
		return true;
	}

	public boolean deleteSubscriberDevice() throws SQLException, Exception


	{ 
//		try {
			if(subDeviceId <= 0)
			{
				if(subId == null || subId.equalsIgnoreCase("") || deviceMapId <= 0) 
				{
					setStatus(InvErrorCode.INVALID_SUBSCRIBER_DEVICE_ID);
                                return false;
				}
			}
			DBTblSubscriberDevice subDevDB = new DBTblSubscriberDevice();
			
		    decrementPortsAssigned(); 	
			if(subDeviceId > 0)
			{
                        subDevDB.whereSubDeviceIdEQ(subDeviceId);
						log.info("subDeviceId:"+subDeviceId);
			}
			else
			{
						subDevDB.whereSubIdEQ(subId);
						subDevDB.whereDeviceMapIdEQ(deviceMapId);
						log.info("subId:"+subId+"DeviceMapId"+deviceMapId);
			}

			int  noOfDel = subDevDB.deleteByWhere(connection);
			log.info("No of sub devices deleted:"+noOfDel);
		/*}catch(SQLException s){
			s.printStackTrace();	
			setStatus(InvErrorCode.DB_EXCEPTION);
			return false;
		} catch (Exception ee) {
			ee.printStackTrace();	
			setStatus(InvErrorCode.DB_EXCEPTION);
			return false;
		}*/
		setStatus(InvErrorCode.SUCCESS);

		return true;
	}

	
public void decrementPortsAssigned() throws Exception {
	getSubDeviceDetailsBySubDeviceId();
	TblDeviceMapQuery deviceMapqry = new TblDeviceMapQuery();
	deviceMapqry.whereDeviceMapIdEQ((int)getDeviceMapId());
	deviceMapqry.query(connection);
	if(deviceMapqry.size() > 0) {
		TblDeviceMapDbBean deviceMapbean = deviceMapqry.getDbBean(0);
		if(deviceMapbean.getSipDeviceId() >0) {
			SipDevice sipDev = new SipDevice(connection);
			sipDev.setSipDeviceId((int)deviceMapbean.getSipDeviceId());
			if(sipDev.getDetails())
			{
    			DBTblSipDeviceInfo sipDevObj = new DBTblSipDeviceInfo();
				sipDevObj.whereSipDeviceIdEQ(sipDev.getSipDeviceId());	
				int updatedCount = 0;
				if(sipDev.getPortsAssigned() >0){
					sipDevObj.setPortsAssigned(sipDev.getPortsAssigned() -  1);	
				} else {
					sipDevObj.setPortsAssignedNull();
				}

				FkValidationUtil.isValidSipDeviceInfoForMod(connection,sipDevObj);
				updatedCount = sipDevObj.updateSpByWhere(connection);
				
				
			}
			
		} else if(deviceMapbean.getGatewayDeviceId()>0){
			GatewayDevice gwDev = new GatewayDevice(connection);
            gwDev.setGatewayDeviceId(deviceMapbean.getGatewayDeviceId());
            if(gwDev.getDetails())
            {
            		DBTblGatewayDeviceInfo gwDevObj = new DBTblGatewayDeviceInfo();
                    gwDevObj.whereGatewayDeviceIdEQ(gwDev.getGatewayDeviceId());
                    int updatedCount = 0;
					if(gwDev.getPortsAssigned() >1){
						gwDevObj.setPortsAssigned(gwDev.getPortsAssigned() -  1);	
					} else {
						gwDevObj.setPortsAssignedNull();
					}    
					  updatedCount = gwDevObj.updateSpByWhere(connection);	
                

            }
			
		}
	}
}
public boolean modifySubscriberDevice() {
		try {
			if (subDeviceId <= 0 ) {
				if(subId == null || subId.equals("") || deviceMapId <= 0)
				{
				setStatus(InvErrorCode.INVALID_SUBSCRIBER_DEVICE_ID);
				log.info("FAILURE in modifySubscriberDevice SubscriberDevice. subDeviceId/subId and DeviceMapId missing.");
				return false;
				}
			}
			DBTblSubscriberDevice subDevDBBean = getSubDeviceToUpdate();
			if(subDeviceId > 0)
            {
						subDevDBBean.whereSubDeviceIdEQ(subDeviceId);
                        log.info("subDeviceId:"+subDeviceId);
            }
            else
            {
						subDevDBBean.whereSubIdEQ(subId);
						subDevDBBean.whereDeviceMapIdEQ(deviceMapId);
                        log.info("subId:"+subId+"DeviceMapId"+deviceMapId);
            }


			if ( subDevDBBean.updateSpByWhere(connection) <= 0 ){
				setStatus(InvErrorCode.NO_SUBSCRIBER_DEVICE_UPDATED);
				log.info("Could not update Subscriber Device");
				return false;
			}
			
		} catch (SQLException s) {
			setStatus(InvErrorCode.DB_EXCEPTION);
			log.info("DB_FAILURE in modifySubscriberDevice");
			s.printStackTrace();	
			return false;
		}
		setStatus(InvErrorCode.SUCCESS);
		log.info("SUCCESS in modifySubscriberDevice");
		return true;
	}
         private DBTblSubscriberDevice getSubDeviceToUpdate() {
		DBTblSubscriberDevice subsDbBean = new DBTblSubscriberDevice();
	
		/* Create a new instance of DialPlanBean. The new instance would hold
		 * default values for the all the DialPlan fields.
		 */
		SubscriberDeviceBean defSubBean = new SubscriberDeviceBean();
		SubscriberDevice inputSub = this;
		subsDbBean.setSubDeviceId(subDeviceId);
		if (inputSub.getSubId() != null 
				&& !inputSub.getSubId().equals(defSubBean.getSubId())) {
			subsDbBean.setSubId(inputSub.getSubId());
		}
		if (inputSub.getDeviceMapId() != defSubBean.getDeviceMapId()) {
			subsDbBean.setDeviceMapId(inputSub.getDeviceMapId());
		}
		if (inputSub.getLinePort() != null 
				&& !inputSub.getLinePort().equals(defSubBean.getLinePort())) {
			subsDbBean.setLinePort(inputSub.getLinePort());
		}
		if (inputSub.getLineKey() != defSubBean.getLineKey()) {
			subsDbBean.setLineKey(inputSub.getLineKey());
		}
		if (inputSub.getCallsPerLine() != defSubBean.getCallsPerLine()) {
			subsDbBean.setCallsPerLine(inputSub.getCallsPerLine());
		}
		if (inputSub.getPortNum() != defSubBean.getPortNum()) {
			subsDbBean.setPortNum(inputSub.getPortNum());
		}
		if (inputSub.getScaLineLabel() != null 
				&& !inputSub.getScaLineLabel().equals(defSubBean.getScaLineLabel())) {
			subsDbBean.setScaLineLabel(inputSub.getScaLineLabel());
		}
        if(inputSub.getScaLineLabel() == "" ){
			subsDbBean.setScaLineLabelNull();
        }
        if (inputSub.getScaType() != null 
				&& !inputSub.getScaType().equals(defSubBean.getScaType())) {
			subsDbBean.setScaType(inputSub.getScaType());
		}
		if (inputSub.getScaAuthUserid() != null 
				&& !inputSub.getScaAuthUserid().equals(defSubBean.getScaAuthUserid())) {
			subsDbBean.setScaAuthUserid(inputSub.getScaAuthUserid());
		}
		if (inputSub.getBlfAttdntRegline() != defSubBean.getBlfAttdntRegline()) {
			subsDbBean.setBlfAttdntRegline(inputSub.getBlfAttdntRegline());
		}
		if (inputSub.getBlfUrl() != null && !inputSub.getBlfUrl().equals(defSubBean.getBlfUrl())) {
			subsDbBean.setBlfUrl(inputSub.getBlfUrl());
		}

        	if (inputSub.getEnvOrderId() != defSubBean.getEnvOrderId()) {
        		subsDbBean.setEnvOrderId(inputSub.getEnvOrderId());
        	}

		if (inputSub.getModifiedBy() != null && ! "".equals(inputSub.getModifiedBy()) )
			subsDbBean.setModifiedBy(inputSub.getModifiedBy());
		else
			subsDbBean.setModifiedBy("ESAP_INV");
		
                subsDbBean.setLastModifiedDate(new Timestamp(System.currentTimeMillis()));
		
		return subsDbBean;
	}	
	
}
