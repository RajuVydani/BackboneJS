package com.vz.fxo.inventory.actionfunction.support;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import esap.db.DBTblVzbPprules;
import esap.db.TblVzbPprulesDbBean;
import esap.db.TblVzbPprulesQuery;

public class PPRules extends PPRulesBean{

	private static Logger log = LoggerFactory.getLogger(PPRules.class.toString());

	private InvErrorCode status = InvErrorCode.INTERNAL_ERROR;;
    Connection connection;
    
    public PPRules(Connection dbCon)
    {
    	super();
        this.connection = dbCon;
    }
    
    public PPRules(PPRulesBean pprulesBean, Connection dbCon)
    {
        super(pprulesBean);
        this.connection = dbCon;
    }

	/*public PPRules(PPRangeBean pprBean, Connection dbCon)
	{
		this.connection = dbCon;
		setPrefixPlanId(pprBean.getPrefixPlanId());
		setPrefix(pprBean.getRangeStart());
		setNumstrip(pprBean.getNumstrip());
		setAddPrefix(pprBean.getAddPrefix());
		setNoa(pprBean.getNoa());
		setBlkstat(pprBean.getBlkstat());
		setCreatedBy(pprBean.getCreatedBy());
		setModifiedBy(pprBean.getModifiedBy());
		setCreationDate(pprBean.getCreationDate());
		setLastModifiedDate(pprBean.getLastModifiedDate());
	}*/
        
    public int getStatusCode() {
		return status.getErrorCode();
	}
 
	public String getStatusDesc() {
		return status.getErrorDesc();
	}

	public void setStatus(InvErrorCode status) {
		this.status = status;
	}

	public Connection getDbCon() {
		return connection;
	}

	public void setDbCon(Connection dbCon) {
		this.connection = dbCon;
	}

	public boolean getPPRulesListByPrefixPlanId() throws SQLException
    {
		log.info(" Entering getPPRulesListByPrefixPlanId");
		PPRulesBean pprBean = null;
		ArrayList<PPRulesBean> pprBeanList = null;
		try
		{
			TblVzbPprulesQuery pprQuery = new  TblVzbPprulesQuery();
			pprQuery.wherePrefixPlanIdEQ(getPrefixPlanId());
			pprQuery.query(connection);
			
			if ( pprQuery.size() > 0)
			{
				pprBeanList = new ArrayList<PPRulesBean>();
				for ( int i=0 ; i < pprQuery.size() ; i++)
				{
					pprBean = new PPRulesBean();
					TblVzbPprulesDbBean pprDbBean = pprQuery.getDbBean(i);
					pprBean.setPrefixPlanId(pprDbBean.getPrefixPlanId());
					pprBean.setPrefix(pprDbBean.getPrefix());
					pprBean.setNumstrip(pprDbBean.getNumstrip());
					pprBean.setAddPrefix(pprDbBean.getAddPrefix());
					pprBean.setNoa(pprDbBean.getNoa());
					pprBean.setBlkstat(pprDbBean.getBlkstat());
					pprBean.setCreatedBy(pprDbBean.getCreatedBy());
					pprBean.setCreationDate(pprDbBean.getCreationDate());
					pprBean.setModifiedBy(pprDbBean.getModifiedBy());
					pprBean.setLastModifiedDate(pprDbBean.getLastModifiedDate());
					pprBeanList.add(pprBean);
				}
				this.setPPRulesBeanList(pprBeanList);
			}
			else
			{
				log.info("No Prefix Plan Rules Found by Prefix Plan Id [" + getPrefixPlanId() + "]");
				setStatus(InvErrorCode.NOT_FOUND_VZB_PPRULES);
                return false;
			}
		
	    }
		catch(SQLException s)
	    {
	    	s.printStackTrace();
	        setStatus(InvErrorCode.DB_EXCEPTION);
	        return false;
	    }
		
		setStatus(InvErrorCode.SUCCESS);
	    log.info("Successfully Retrieved Prefix Plan Rules");
		return true;
    }

	public boolean getPPRulesDetails() throws SQLException
    {
        log.info(" Entering getPPRulesDetails");
        PPRulesBean pprBean = null;
        ArrayList<PPRulesBean> pprBeanList = null;
        try
        {
            TblVzbPprulesQuery pprQuery = new  TblVzbPprulesQuery();
			if(getPrefixPlanId() > 0)
            	pprQuery.wherePrefixPlanIdEQ(getPrefixPlanId());
			if(getPrefix() != null && !"".equals(getPrefix()))
				pprQuery.wherePrefixEQ(getPrefix());
            pprQuery.query(connection);

            if ( pprQuery.size() > 0)
            {
                pprBeanList = new ArrayList<PPRulesBean>();
                for ( int i=0 ; i < pprQuery.size() ; i++)
                {
                    pprBean = new PPRulesBean();
                    TblVzbPprulesDbBean pprDbBean = pprQuery.getDbBean(i);
                    pprBean.setPrefixPlanId(pprDbBean.getPrefixPlanId());
                    pprBean.setPrefix(pprDbBean.getPrefix());
                    pprBean.setNumstrip(pprDbBean.getNumstrip());
                    pprBean.setAddPrefix(pprDbBean.getAddPrefix());
                    pprBean.setNoa(pprDbBean.getNoa());
                    pprBean.setBlkstat(pprDbBean.getBlkstat());
                    pprBean.setCreatedBy(pprDbBean.getCreatedBy());
                    pprBean.setCreationDate(pprDbBean.getCreationDate());
                    pprBean.setModifiedBy(pprDbBean.getModifiedBy());
                    pprBean.setLastModifiedDate(pprDbBean.getLastModifiedDate());
                    pprBeanList.add(pprBean);
                }
                this.setPPRulesBeanList(pprBeanList);
            }
            else
            {
                log.info("No Prefix Plan Rules Found by Prefix Plan Id [" + getPrefixPlanId() + "]");
                setStatus(InvErrorCode.NOT_FOUND_VZB_PPRULES);
                return false;
            }

        }
        catch(SQLException s)
        {
            s.printStackTrace();
            setStatus(InvErrorCode.DB_EXCEPTION);
            return false;
        }

        setStatus(InvErrorCode.SUCCESS);
        log.info("Successfully Retrieved Prefix Plan Rules");
        return true;
    }

	public boolean addPPRules() throws SQLException, Exception
    {
        log.info("Entering addPPRules");
        try
        {
            DBTblVzbPprules pprDbBean = new DBTblVzbPprules();
            pprDbBean.setPrefixPlanId(getPrefixPlanId());
            
            if ( getPrefix() != null && !"".equals(getPrefix())){
            	pprDbBean.setPrefix(getPrefix());
            }
            
            if ( getNumstrip() > -1 ){
            	pprDbBean.setNumstrip(getNumstrip());
            }
			else
				pprDbBean.setNumstrip(0);
            
            if (getAddPrefix() != null && !"".equals(getAddPrefix())){
            	pprDbBean.setAddPrefix(getAddPrefix());
            }
            
            if ( getNoa() > -1 ){
            	pprDbBean.setNoa(getNoa());
            }
            
            if ( getBlkstat() > -1){
            	pprDbBean.setBlkstat(getBlkstat());
            }

            if(getCreatedBy() != null && !getCreatedBy().equals(""))
                pprDbBean.setCreatedBy(getCreatedBy());
            else
                pprDbBean.setCreatedBy("ESAP_INV");

            if(getModifiedBy() != null && !getModifiedBy().equals(""))
                pprDbBean.setModifiedBy(getModifiedBy());
            else
                pprDbBean.setModifiedBy("ESAP_INV");

            pprDbBean.setCreationDate(new Timestamp(System.currentTimeMillis()));
            pprDbBean.setLastModifiedDate(new Timestamp(System.currentTimeMillis()));
            pprDbBean.insertSpecific(connection);
        }
        catch(SQLException s)
        {
            log.info("SQL Exception in addPPRules");
            throw s;
        }

        setStatus(InvErrorCode.SUCCESS);
        log.info("Successfully Inserted Prefix Plan Rules");
        return true;
    }
	
	public boolean deletePPRules()
    {
        log.info("Entering deletePPRules");
        try
        {
            if(getPrefixPlanId() <= 0 )
            {
                setStatus(InvErrorCode.NOT_FOUND_VZB_PPRULES);
                return false;
            }

            DBTblVzbPprules pprDbBean = new DBTblVzbPprules();
            pprDbBean.wherePrefixPlanIdEQ(getPrefixPlanId());
			if(getPrefix() != null && !"".equals(getPrefix()))
            	pprDbBean.wherePrefixEQ(getPrefix());
            int pprDeleted = pprDbBean.deleteByWhere(connection);
            log.info("Deleted [" + pprDeleted + "] Prefix Plan Rules");
        }
        catch(SQLException s)
        {
            s.printStackTrace();
            setStatus(InvErrorCode.DB_EXCEPTION);
            log.info("DB_FAILURE in deletePPRules");
            return false;
        }
        setStatus(InvErrorCode.SUCCESS);
        log.info("Successfully Deleted Prefix Plan Rules");
        return true;
    }

	public boolean updatePPRules()
   	{
		log.info("Entering updatePPRules");
    	try
   		{ 
			if ( getPrefixPlanId() <= 0 || (getPrefix() == null || (getPrefix() != null && "".equals(getPrefix())))) 
			{
                log.info("FAILURE in updatePPRules. Prefix Plan Id / Range Start Not Found");
				setStatus(InvErrorCode.NOT_FOUND_VZB_PPRULES);
                return false;
           	}

            DBTblVzbPprules pprDbBean = getPprulesToUpdate();
            pprDbBean.wherePrefixPlanIdEQ(getPrefixPlanId());
            pprDbBean.wherePrefixEQ(getPrefix());
            pprDbBean.updateSpByWhere(connection);            

    	} 
		catch(SQLException s) 
		{
        	s.printStackTrace();
            setStatus(InvErrorCode.DB_EXCEPTION);
            return false;
     	}

        setStatus(InvErrorCode.SUCCESS);
		log.info("Successfully Updated Prefix Plan Rules By Prefix Plan Id [" + getPrefixPlanId() + "]");
        return true;
  	}

	private DBTblVzbPprules getPprulesToUpdate() throws SQLException
	{
		log.info("Entering getPprulesToUpdate");
		DBTblVzbPprules pprDbBean = new DBTblVzbPprules();
		PPRulesBean defaultPPRBean = new PPRulesBean();
		PPRules ppr = this;

		pprDbBean.setPrefixPlanId(getPrefixPlanId());
		if(ppr.getNumstrip() != defaultPPRBean.getNumstrip())
		{
			pprDbBean.setNumstrip(ppr.getNumstrip());
		}
				
		if(ppr.getAddPrefix() != null &&
            ! ppr.getAddPrefix().equals(defaultPPRBean.getAddPrefix()))
        {
			pprDbBean.setAddPrefix(ppr.getAddPrefix());
        }
		if(ppr.getNoa() != defaultPPRBean.getNoa())
        {
            pprDbBean.setNoa(ppr.getNoa());
        }
		if(ppr.getBlkstat() != defaultPPRBean.getBlkstat())
        {
            pprDbBean.setBlkstat(ppr.getBlkstat());
        }
		if(ppr.getModifiedBy() != null && !("".equalsIgnoreCase(defaultPPRBean.getModifiedBy())))
			pprDbBean.setModifiedBy(getModifiedBy());
		else
			pprDbBean.setModifiedBy("ESAP_INV");
		pprDbBean.setLastModifiedDate(new Timestamp(System.currentTimeMillis()));

		log.info("Successfully Retrieved Prefix Plan Rules");
		return pprDbBean;	
	}

}
