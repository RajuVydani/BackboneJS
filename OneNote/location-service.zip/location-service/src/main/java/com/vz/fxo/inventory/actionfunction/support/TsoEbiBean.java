
package com.vz.fxo.inventory.actionfunction.support;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

public class TsoEbiBean implements Serializable {
	
	protected long ebiId;
	protected String enterpriseId;
	protected String ebiName;
	protected String ebiIp;
	protected long ebiPort;
    protected String ebiFqdn;
    protected short ipVersion;
    protected String vpnName;
    protected long accessType;
    protected String circuitId;
    protected String streetAddress;
    protected String city;
    protected String state;
    protected String countryCode;
    protected String createdBy;
    protected Timestamp creationDate;
    protected String modifiedBy;
    protected Timestamp lastModifiedDate;
    protected List<String> logTrail;
    protected String zip;
    protected String bsDeviceType;
    protected long ipsecTunnelId;
    protected long envOrderId;
    protected short isPwg;
    public  TsoEbiBean(){
    	this.ebiId=0;
    	this.enterpriseId = new String("");
    	this.ebiName=new String("");
    	this.ebiIp=new String("");
    	this.ebiPort=-1;
    	this.ebiFqdn=new String("");
    	this.ipVersion=0;
    	this.vpnName=new String("");
    	this.accessType = -1;
    	this.circuitId=new String("");
    	this.streetAddress=new String("");
    	this.city=new String("");
    	this.state=new String("");
    	this.countryCode=new String("");
    	this.createdBy = new String("");
		this.creationDate = null;
		this.modifiedBy = new String("");
		this.lastModifiedDate = null;
		logTrail = new ArrayList<String>();
		this.zip = new String("");
		this.bsDeviceType = new String("");
		this.ipsecTunnelId = 0;
		this.envOrderId = 0;
		this.isPwg = 0;
    }
    
    
    public  TsoEbiBean(TsoEbiBean tsoEbiBean){
    	
    	this.ebiId=tsoEbiBean.ebiId;
    	this.ebiName=tsoEbiBean.ebiName;
    	this.ebiIp=tsoEbiBean.ebiIp;
    	this.ebiPort=tsoEbiBean.ebiPort;
    	this.ebiFqdn=tsoEbiBean.ebiFqdn;
    	this.ipVersion=tsoEbiBean.ipVersion;
    	this.vpnName=tsoEbiBean.vpnName;
    	this.streetAddress=tsoEbiBean.streetAddress;
    	this.city=tsoEbiBean.city;
    	this.state=tsoEbiBean.state;
    	this.countryCode=tsoEbiBean.countryCode;
    	this.createdBy=tsoEbiBean.createdBy;
		this.creationDate=tsoEbiBean.creationDate;
		this.modifiedBy=tsoEbiBean.modifiedBy;
		this.lastModifiedDate=tsoEbiBean.lastModifiedDate;
		this.logTrail = tsoEbiBean.logTrail;
		this.zip = tsoEbiBean.zip;
		this.ipsecTunnelId = tsoEbiBean.ipsecTunnelId;
		this.envOrderId = tsoEbiBean.envOrderId;
		this.isPwg = tsoEbiBean.isPwg;
    }
    
    /**
	 * @return the logTrail
	 */
	public List<String> getLogTrail() {
		return logTrail;
	}

	/**
	 * @param logTrail the logTrail to set
	 */
	public void setLogTrail(String logStr) {
		logTrail.add(logStr);
	}
	
	public long getEbiId() {
		return ebiId;
	}

	public void setEbiId(long ebiId) {
		this.ebiId = ebiId;
	}

	public String getEbiName() {
		return ebiName;
	}

	public void setEbiName(String ebiName) {
		this.ebiName = ebiName;
	}

	public String getEbiIp() {
		return ebiIp;
	}

	public void setEbiIp(String ebiIp) {
		this.ebiIp = ebiIp;
	}

	public long getEbiPort() {
		return ebiPort;
	}

	public void setEbiPort(long ebiPort) {
		this.ebiPort = ebiPort;
	}

	public String getEbiFqdn() {
		return ebiFqdn;
	}

	public void setEbiFqdn(String ebiFqdn) {
		this.ebiFqdn = ebiFqdn;
	}

	public short getIpVersion() {
		return ipVersion;
	}

	public void setIpVersion(short ipVersion) {
		this.ipVersion = ipVersion;
	}

	public String getVpnName() {
		return vpnName;
	}

	public void setVpnName(String vpnName) {
		this.vpnName = vpnName;
	}

	public String getStreetAddress() {
		return streetAddress;
	}

	public void setStreetAddress(String streetAddress) {
		this.streetAddress = streetAddress;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getCountryCode() {
		return countryCode;
	}

	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(Timestamp creationDate) {
		this.creationDate = creationDate;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Timestamp getLastModifiedDate() {
		return lastModifiedDate;
	}

	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public String getEnterpriseId() {
		return enterpriseId;
	}

	public void setEnterpriseId(String enterpriseId) {
		this.enterpriseId = enterpriseId;
	}

	public long getAccessType() {
		return accessType;
	}

	public void setAccessType(long accessType) {
		this.accessType = accessType;
	}

	public String getCircuitId() {
		return circuitId;
	}

	public void setCircuitId(String circuitId) {
		this.circuitId = circuitId;
	}

	public String getZip() {
		return zip;
	}

	public void setZip(String zip) {
		this.zip = zip;
	}

	public String getBsDeviceType() {
		return bsDeviceType;
	}

	public void setBsDeviceType(String bsDeviceType) {
		this.bsDeviceType = bsDeviceType;
	}

	public long getIpsecTunnelId() {
		return ipsecTunnelId;
	}

	public void setIpsecTunnelId(long ipsecTunnelId) {
		this.ipsecTunnelId = ipsecTunnelId;
	}

	public long getEnvOrderId() {
		return envOrderId;
	}

	public void setEnvOrderId(long envOrderId) {
		this.envOrderId = envOrderId;
	}

	public short getIsPwg() {
		return isPwg;
	}

	public void setIsPwg(short isPwg) {
		this.isPwg = isPwg;
	}
	
}
