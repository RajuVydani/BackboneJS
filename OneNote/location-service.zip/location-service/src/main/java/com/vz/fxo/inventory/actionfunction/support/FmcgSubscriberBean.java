package com.vz.fxo.inventory.actionfunction.support;

import java.io.Serializable;
import java.sql.Timestamp;

/**
 * @author z987637
 * 
 */
public class FmcgSubscriberBean implements Serializable
{
    protected FeaturePackageBean featurePackageObj;
    protected FmcgDeviceBean fmcgDeviceObj;
    protected FmcgVendorDialplanBean fmcgVendorDialPlanObj;
    protected int fmcgSubId;
    protected String mobileNumber;
    protected long featurePkgId;
    protected String outboundAlterNum;
    protected long fmcgDeviceId;
    protected long fmcgType;
    protected int fmcgDialPlanId;
    protected String portalPin;
    protected long notificationMethod;
    protected String notificationEmail;
    protected long ansConfirmation;
    protected long actRetryCount;
    protected Timestamp actDate;
    protected String imei;
    protected String eas;
    protected long universalClid;
    private String createdBy;
    private Timestamp creationDate;
    private String modifiedBy;
    private Timestamp lastModifiedDate;
    private long envOrderId;
    //FMCg Phase II
    protected long requestType; //Phase II
    protected String devicePin;
    protected String besEnabled;
    protected long readyStatus;
    protected Timestamp readyDate;
    protected Timestamp notifyConfigUpdate;
    protected Timestamp notifyInstall;

    public long getEnvOrderId()
    {
        return envOrderId;
    }

    public void setEnvOrderId(long envOrderId)
    {
        this.envOrderId = envOrderId;
    }
	public long getUniversalClid()
    {
        return universalClid;
    }
                                                                                                                             
    public void setUniversalClid(long universalClid)
    {
        this.universalClid = universalClid;
    }


    /**
     * 
     * @param fmcgSubscriberBean
     */
    public FmcgSubscriberBean(FmcgSubscriberBean fmcgSubscriberBean)
    {
        this.featurePackageObj = fmcgSubscriberBean.featurePackageObj;
        this.fmcgDeviceObj = fmcgSubscriberBean.fmcgDeviceObj;
        this.fmcgVendorDialPlanObj = fmcgSubscriberBean.fmcgVendorDialPlanObj;
        this.fmcgSubId = fmcgSubscriberBean.fmcgSubId;
        this.mobileNumber = fmcgSubscriberBean.mobileNumber;
        this.featurePkgId = fmcgSubscriberBean.featurePkgId;
        this.outboundAlterNum = fmcgSubscriberBean.outboundAlterNum;
        this.fmcgDeviceId = fmcgSubscriberBean.fmcgDeviceId;
        this.fmcgType = fmcgSubscriberBean.fmcgType;
        this.fmcgDialPlanId = fmcgSubscriberBean.fmcgDialPlanId;
        this.portalPin = fmcgSubscriberBean.portalPin;
        this.notificationMethod = fmcgSubscriberBean.notificationMethod;
        this.notificationEmail = fmcgSubscriberBean.notificationEmail;
        this.ansConfirmation = fmcgSubscriberBean.ansConfirmation;
        this.actRetryCount = fmcgSubscriberBean.actRetryCount;
        this.actDate = fmcgSubscriberBean.actDate;
        this.imei = fmcgSubscriberBean.imei;
        this.eas = fmcgSubscriberBean.eas;
        this.createdBy = fmcgSubscriberBean.createdBy;
        this.creationDate = fmcgSubscriberBean.creationDate;
        this.modifiedBy = fmcgSubscriberBean.modifiedBy;
        this.lastModifiedDate = fmcgSubscriberBean.lastModifiedDate;
        this.envOrderId = fmcgSubscriberBean.envOrderId;
        this.universalClid = fmcgSubscriberBean.universalClid;
        this.requestType = fmcgSubscriberBean.requestType;
        this.devicePin = fmcgSubscriberBean.devicePin;
        this.besEnabled = fmcgSubscriberBean.besEnabled;
        this.readyStatus = fmcgSubscriberBean.readyStatus;
        this.readyDate = fmcgSubscriberBean.readyDate;
        this.notifyConfigUpdate = fmcgSubscriberBean.notifyConfigUpdate;
        this.notifyInstall = fmcgSubscriberBean.notifyInstall;
    }

    /**
     * Default Constructor
     */
    public FmcgSubscriberBean()
    {
        this.featurePackageObj = new FeaturePackageBean();
        this.fmcgDeviceObj = new FmcgDeviceBean();
        this.fmcgVendorDialPlanObj = new FmcgVendorDialplanBean();
        this.fmcgSubId = 0;
        this.mobileNumber = new String("NONE");
        this.featurePkgId = -1;
        this.outboundAlterNum = new String("NONE");
        this.fmcgDeviceId = -1;
        this.fmcgType = 0;
        this.fmcgDialPlanId = -1;
        this.portalPin = new String("NONE");
        this.notificationMethod = -1;
        this.notificationEmail = new String("NONE");
        this.ansConfirmation = -1;
        this.actRetryCount = -1;
        this.actDate = null;
        this.imei = new String("NONE");
        this.eas = new String("NONE");
        this.createdBy = new String("NONE");
        this.creationDate = null;
        this.modifiedBy = new String("NONE");
        this.lastModifiedDate = null;
        this.envOrderId = 0;
        this.universalClid = -1;
        this.requestType = -1;
        this.devicePin = new String("NONE");
        this.besEnabled = new String("NONE");
        this.readyStatus = -1;
        this.readyDate = null;
        this.notifyConfigUpdate = null;
        this.notifyInstall = null;
    }

    public FeaturePackageBean getFeaturePackageObj()
    {
        return featurePackageObj;
    }

    public void setFeaturePackageObj(FeaturePackageBean featurePackageObj)
    {
        this.featurePackageObj = featurePackageObj;
    }

    public FmcgDeviceBean getFmcgDeviceObj()
    {
        return fmcgDeviceObj;
    }

    public void setFmcgDeviceObj(FmcgDeviceBean fmcgDeviceObj)
    {
        this.fmcgDeviceObj = fmcgDeviceObj;
    }

    public FmcgVendorDialplanBean getFmcgVendorDialPlanObj()
    {
        return fmcgVendorDialPlanObj;
    }

    public void setFmcgVendorDialPlanObj(FmcgVendorDialplanBean fmcgVendorDialPlanObj)
    {
        this.fmcgVendorDialPlanObj = fmcgVendorDialPlanObj;
    }

    public Timestamp getActDate()
    {
        return actDate;
    }

    public void setActDate(Timestamp actDate)
    {
        this.actDate = actDate;
    }

    public long getActRetryCount()
    {
        return actRetryCount;
    }

    public void setActRetryCount(long actRetryCount)
    {
        this.actRetryCount = actRetryCount;
    }

    public long getAnsConfirmation()
    {
        return ansConfirmation;
    }

    public void setAnsConfirmation(long ansConfirmation)
    {
        this.ansConfirmation = ansConfirmation;
    }

    public String getEas()
    {
        return eas;
    }

    public void setEas(String eas)
    {
        this.eas = eas;
    }

    public long getFeaturePkgId()
    {
        return featurePkgId;
    }

    public void setFeaturePkgId(long featurePkgId)
    {
        this.featurePkgId = featurePkgId;
    }

    public int getFmcgDialPlanId()
    {
        return fmcgDialPlanId;
    }

    public void setFmcgDialPlanId(int fmcgDialPlanId)
    {
        this.fmcgDialPlanId = fmcgDialPlanId;
    }

    public long getFmcgDeviceId()
    {
        return fmcgDeviceId;
    }

    public void setFmcgDeviceId(long fmcgDeviceId)
    {
        this.fmcgDeviceId = fmcgDeviceId;
    }

    public int getFmcgSubId()
    {
        return fmcgSubId;
    }

    public void setFmcgSubId(int fmcgSubId)
    {
        this.fmcgSubId = fmcgSubId;
    }

    public long getFmcgType()
    {
        return fmcgType;
    }

    public void setFmcgType(long fmcgType)
    {
        this.fmcgType = fmcgType;
    }

    public String getImei()
    {
        return imei;
    }

    public void setImei(String imei)
    {
        this.imei = imei;
    }

    public String getMobileNumber()
    {
        return mobileNumber;
    }

    public void setMobileNumber(String mobileNumber)
    {
        this.mobileNumber = mobileNumber;
    }

    public String getNotificationEmail()
    {
        return notificationEmail;
    }

    public void setNotificationEmail(String notificationEmail)
    {
        this.notificationEmail = notificationEmail;
    }

    public long getNotificationMethod()
    {
        return notificationMethod;
    }

    public void setNotificationMethod(long notificationMethod)
    {
        this.notificationMethod = notificationMethod;
    }

    public String getOutboundAlterNum()
    {
        return outboundAlterNum;
    }

    public void setOutboundAlterNum(String outboundAlterNum)
    {
        this.outboundAlterNum = outboundAlterNum;
    }

    public String getPortalPin()
    {
        return portalPin;
    }

    public void setPortalPin(String portalPin)
    {
        this.portalPin = portalPin;
    }

    public String getCreatedBy()
    {
        return createdBy;
    }

    public void setCreatedBy(String createdBy)
    {
        this.createdBy = createdBy;
    }

    public Timestamp getCreationDate()
    {
        return creationDate;
    }

    public void setCreationDate(Timestamp creationDate)
    {
        this.creationDate = creationDate;
    }

    public String getModifiedBy()
    {
        return modifiedBy;
    }

    public void setModifiedBy(String modifiedBy)
    {
        this.modifiedBy = modifiedBy;
    }

    public Timestamp getLastModifiedDate()
    {
        return lastModifiedDate;
    }

    public void setLastModifiedDate(Timestamp lastModifiedDate)
    {
        this.lastModifiedDate = lastModifiedDate;
    }

    public long getRequestType() {
        return requestType;
    }

    public void setRequestType(long requestType) {
        this.requestType = requestType;
    }

    public String getDevicePin() {
        return devicePin;
    }

    public void setDevicePin(String devicePin) {
        this.devicePin = devicePin;
    }

    public String getBesEnabled() {
        return besEnabled;
    }

    public void setBesEnabled(String besEnabled) {
        this.besEnabled = besEnabled;
    }

    public long getReadyStatus() {
        return readyStatus;
    }

    public void setReadyStatus(long readyStatus) {
        this.readyStatus = readyStatus;
    }

    public Timestamp getReadyDate() {
        return readyDate;
    }

    public void setReadyDate(Timestamp readyDate) {
        this.readyDate = readyDate;
    }

    public Timestamp getNotifyConfigUpdate() {
        return notifyConfigUpdate;
    }

    public void setNotifyConfigUpdate(Timestamp notifyConfigUpdate) {
        this.notifyConfigUpdate = notifyConfigUpdate;
    }

    public Timestamp getNotifyInstall() {
        return notifyInstall;
    }

    public void setNotifyInstall(Timestamp notifyInstall) {
        this.notifyInstall = notifyInstall;
    }

    public String toString()
    {
        return "FmcgSubscriberBean [actDate=" + actDate + ", actRetryCount=" + actRetryCount + ", ansConfirmation="
                + ansConfirmation + ", createdBy=" + createdBy + ", creationDate=" + creationDate + ", eas=" + eas
                + ", envOrderId=" + envOrderId + ", featurePkgId=" + featurePkgId + ", fmcgDialPlanId="
                + fmcgDialPlanId + ", fmcgDeviceId=" + fmcgDeviceId + ", fmcgSubId=" + fmcgSubId + ", fmcgType="
                + fmcgType + ", imei=" + imei + ", lastModifiedDate=" + lastModifiedDate + ", mobileNumber="
                + mobileNumber + ", modifiedBy=" + modifiedBy + ", notificationEmail=" + notificationEmail
                + ", notificationMethod=" + notificationMethod + ", outboundAlterNum=" + outboundAlterNum
                + ", portalPin=" + portalPin + ", requestType=" + requestType + ",devicePin=" + devicePin
                + ",besEnabled=" + besEnabled + ",readyStatus=" + readyStatus + ",readyDate=" + readyDate
                + ",notifyConfigUpdate=" + notifyConfigUpdate + ", notifyInstall=" + notifyInstall +"]";

    }
    public void initilizeTODefault() {
        this.featurePackageObj = new FeaturePackageBean();
        this.fmcgDeviceObj = new FmcgDeviceBean();
        this.fmcgVendorDialPlanObj = new FmcgVendorDialplanBean();
        //this.fmcgSubId = 0;
        this.mobileNumber = new String("");
        this.featurePkgId = 0;
        this.outboundAlterNum = new String("");
        this.fmcgDeviceId = 0;
        this.fmcgType = 0;
        this.fmcgDialPlanId = 0;
        this.portalPin = new String("");
        this.notificationMethod = 0;
        this.notificationEmail = new String("");
        this.ansConfirmation = 0;
        this.actRetryCount = 0;
        this.actDate = null;
        this.imei = new String("");
        this.eas = new String("");
        this.createdBy = new String("");
        this.creationDate = null;
        this.modifiedBy = new String("");
        this.lastModifiedDate = null;
        this.envOrderId = 0;
        this.universalClid = 0; 
        this.requestType = 0;
        this.devicePin = new String("");
        this.besEnabled = new String("");
        this.readyStatus = -1;
        this.readyDate = null;
        this.notifyConfigUpdate = null;
        this.notifyInstall = null;
    }
}
