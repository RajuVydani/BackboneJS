package com.vz.fxo.inventory.actionfunction.support;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Random;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import EsapEnumPkg.VzbVoipEnum;

import esap.db.DBTblGatewayDeviceInfo;
import esap.db.DBTblIpsecProvRequest;
import esap.db.DBTblIpsecProvRequestDetails;
import esap.db.DBTblIpsecTunnel;
import esap.db.DBTblTsoEbi;
import esap.db.TblGatewayDeviceInfoQuery;
import esap.db.TblIpsecProvRequestDbBean;
import esap.db.TblIpsecProvRequestDetailsDbBean;
import esap.db.TblIpsecProvRequestDetailsQuery;
import esap.db.TblIpsecProvRequestQuery;
import esap.db.TblIpsecTunnelDbBean;
import esap.db.TblIpsecTunnelQuery;
import esap.db.TblLocationDbBean;
import esap.db.TblLocationQuery;
import esap.db.TblTsoEbiQuery;

public class IpSec extends IpSecBean{
	
	private static Logger log = LoggerFactory.getLogger(IpSec.class.toString());

	private static final long serialVersionUID = 1L;
	private InvErrorCode status;
	Connection dbCon;
	String statusDesc;
	boolean rollbackFlag;
	
	public IpSec(Connection dbCon){
		this.dbCon=dbCon;
	}
	public InvErrorCode getStatus() {
		return status;
	}
	public void setStatus(InvErrorCode status) {
		this.status = status;
	}
	public Connection getDbCon() {
		return dbCon;
	}
	public void setDbCon(Connection dbCon) {
		this.dbCon = dbCon;
	}
	public String getStatusDesc() {
		return statusDesc;
	}
	public void setStatusDesc(String statusDesc) {
		this.statusDesc = statusDesc;
	}
	public boolean isRollbackFlag() {
		return rollbackFlag;
	}
	public void setRollbackFlag(boolean rollbackFlag) {
		this.rollbackFlag = rollbackFlag;
	}
	
	public boolean addToDBTblIpSecTunnel() throws SQLException, Exception {
		 TblIpsecTunnelQuery tblipsecTunnelQuery = new TblIpsecTunnelQuery();
		 tblipsecTunnelQuery.whereIpsecTunnelIdEQ(getIpsecTunnelId());
		 tblipsecTunnelQuery.query(dbCon);
		 if(tblipsecTunnelQuery.getDbBean(0) != null && tblipsecTunnelQuery.getDbBean(0).getIpsecTunnelId() >0){
			 log.info("IPsec Tunnel already exists");
			 updateDevicewithIpsecTunnel(getDeviceId(), getDeviceType(), getIpsecTunnelId());
		 }else{
			 	DBTblIpsecTunnel tunnelBean=new DBTblIpsecTunnel();
			 	
			 	String EGWN="01";
			 	if(isIpsecTunnelExists(getIpsecTunnelId())){
			 		updateDevicewithIpsecTunnel(getDeviceId(), getDeviceType(),getIpsecTunnelId());
			 		log.info("updated tunnel id to device as tunnel already exists in db");
			 		return true;
			 	}
				tunnelBean.setIpsecTunnelId(getIpsecTunnelId());
				tunnelBean.setIkeIp(getIkeIp());
				tunnelBean.setSignalingHostSubnetIp(getHostSubIP());
				tunnelBean.setSignalingHostSubnetMask(getHostSubMask());
				tunnelBean.setEgwType(getEgwType());
				tunnelBean.setTunnelStatus((short)1);
				getCustomerDetails(getEnterpriseId());
				String custName= getCustName();
				tunnelBean.setCustomerName(custName);
                custName = custName.replaceAll("[^a-zA-Z0-9]", "");
                custName = custName.replaceAll("\\s+", "");
				if (custName != null && custName.length()>= 4)
				{
					custName= custName.substring(0, 4);
				}
				
				
				
				HashMap<String, String> hshLocMap=new HashMap<String, String>();
				 
				hshLocMap=getLocation(dbCon);
				
                String city = hshLocMap.get("CITY");
				String state = hshLocMap.get("STATE");
				String circuitId = hshLocMap.get("CIRCUIT_ID");
				tunnelBean.setCity(city);
				tunnelBean.setState(state);
				tunnelBean.setCircuitId(circuitId);
			    if (city != null) {
                city = city.replaceAll("[^a-zA-Z0-9]", "");
                city = city.replaceAll("\\s+", "");
				if (city != null && city.length() >=4)
				{
					city = city.substring(0, 4);
				}
				}	

				if (state != null) {
                state = state.replaceAll("[^a-zA-Z0-9]", "");
                state = state.replaceAll("\\s+", "");	
				}

				String extranetDevice = getIpsecTunnelId()+"_"+EGWN+"_"+custName+"_"+city+"_"+state;
				log.info(" extranetDevice " + extranetDevice);
				tunnelBean.setExtranetDevice(extranetDevice);

				String preshare=EGWN+"_"+city+"_"+custName+"_"+state;
				log.info("preshare :  "+preshare);
				String tmp=IpSecUtil.encrypt(preshare);
				log.info("encoded :  "+tmp);
					if(tmp.length()>27)
						preshare=tmp.substring(0, 27);
					else 
						preshare=tmp;

				String protectedResource =  "IDASBC"+"_"+getIpsecTunnelId()+"_"+EGWN+"_"+custName+"_"+city+"_"+state;
				tunnelBean.setPreshareKey(preshare);
				tunnelBean.setProtectedResource(protectedResource);
				tunnelBean.insert(dbCon);
				log.info("IPsec Tunnel details inserted");
				//Defect#105789 : multiple order requests
				addToDBTblIpsecProvRequest() ;
		 }
		
		return true;
	}
	
	
	public HashMap<String,String> getLocation(Connection conn) throws Exception{
		 PreparedStatement stmt = null;
		 ResultSet rs = null;
		 
		 HashMap <String,String> hshLocMap=new HashMap<String,String>();
		 
		 
		 
		 try{
		 	 
		 
		 short deviceType=0;
		 long deviceId=0;
		 
		 deviceType=getDeviceType();
		 deviceId=getDeviceId();
		 
		 if(deviceType == VzbVoipEnum.IpsecDeviceType.EBI){
	 		
			 String queryLocation="select city,state,circuit_id from tbl_tso_ebi where ebi_id=?";
			 stmt=conn.prepareStatement(queryLocation);
			 stmt.setLong(1, deviceId);
			 rs=stmt.executeQuery();
			 
			 if(rs.next()){			 
				 hshLocMap.put("CITY", rs.getString("CITY"));
				 hshLocMap.put("STATE", rs.getString("STATE"));			 
				 hshLocMap.put("CIRCUIT_ID", rs.getString("CIRCUIT_ID"));
			 }
			 
			 else{
				 log.info("No City or State Associated With Specified ipsec_tunnel_id: "+ipsecTunnelId);
			 }
			 
	 	}
		 else if(deviceType == VzbVoipEnum.IpsecDeviceType.DEVICE){
	 		
	 		
	 		String queryLocation="select loc_city,loc_state,circuit_id from tbl_location tl, tbl_device_map tdm, tbl_gateway_device_info "+
	 "tgd where tgd.gateway_device_id=tdm.gateway_device_id and tl.location_id=tdm.location_id " + 
	" and tgd.gateway_device_id=?";
	 		stmt=conn.prepareStatement(queryLocation);
	 		stmt.setLong(1, deviceId);
	 		rs=stmt.executeQuery();
	 		
	 		if(rs.next()){
	 			hshLocMap.put("CITY", rs.getString("LOC_CITY"));
				 hshLocMap.put("STATE", rs.getString("LOC_STATE"));	
				 hshLocMap.put("CIRCUIT_ID", rs.getString("CIRCUIT_ID"));
	 			
	 		}
	 		
	 		else{
				 log.info("No City or State Associated With Specified device Id :  "+deviceId);
			 }
	 		
	 	}
		 
		 
		 }catch(Exception ex){
			 ex.printStackTrace();
		 }finally {
			if (rs != null)
			rs.close();
			if (stmt != null)
			stmt.close();
		}
		return hshLocMap; 
	 }
	
	
	
	
	
	public boolean isIpsecTunnelExists(long ipsecTunId) throws Exception{
		PreparedStatement ps = null;
		ResultSet res  = null;
		int cnt =0;
		boolean exists = false;
		try{
			String newIKEIPQry  = "SELECT count(*) FROM TBL_IPSEC_TUNNEL WHERE IPSEC_TUNNEL_ID  = ? AND TUNNEL_STATUS = 1";
			ps = dbCon.prepareStatement(newIKEIPQry);
				ps.setLong(1, ipsecTunId);
				res = ps.executeQuery();
				if (res.next())
				{
					cnt = res.getInt(1);
				}
				if(cnt >0){
					exists = true;
				}
		}catch (Exception e) {
			e.printStackTrace();
		}finally{
			if(ps != null){
				ps.close();
			}
			if(res != null){
				res.close();
			}
		}
		return exists;
	}
	
	public boolean addToDBTblIpsecProvRequest() throws SQLException, Exception {
	
		DBTblIpsecProvRequest ipsecProvReq=new DBTblIpsecProvRequest();
		String ipProvSecReqId=getIpProvReqSeqNextVal();
		
		ipsecProvReq.setIpsecTunnelId(getIpsecTunnelId());
		ipsecProvReq.setIpsecProvRequestId(Long.parseLong(ipProvSecReqId));
		ipsecProvReq.setRequestType(getRequestType());
		ipsecProvReq.setRequestInstallDate(new Timestamp(System.currentTimeMillis()));
		ipsecProvReq.setRequestDate(new Timestamp(System.currentTimeMillis()));
		ipsecProvReq.setRequestBy(getRequestBy());
		ipsecProvReq.setEnterpriseId(getEnterpriseId());
		ipsecProvReq.setDeviceType(getDeviceType());
		ipsecProvReq.setEnvOrderId(getEnvOrderId());
		ipsecProvReq.setRequestStatus(getRequestStatus());
		ipsecProvReq.setCompletionDate(null);
		ipsecProvReq.setCompletedBy(null);
		ipsecProvReq.insert(dbCon);
		addToDBTblIpsecProvRequestDetails(ipsecProvReq.getIpsecProvRequestId());
		if(getDeviceType() ==VzbVoipEnum.IpsecDeviceType.DEVICE){
			if (getRequestType()==  VzbVoipEnum.IpsecProvRequestType.ADD){
			log.info("update ipsec tunnel for ADD Request only - gwy");
			updateIpsecTunnelId(getDeviceId(), getIpsecTunnelId());
			}
		}else if(getDeviceType() ==VzbVoipEnum.IpsecDeviceType.EBI){
			if (getRequestType()==  VzbVoipEnum.IpsecProvRequestType.ADD){
			log.info("update ipsec tunnel for ADD Request only - ebi");

			TsoEbi tsoEbiObj = new TsoEbi(dbCon);
			tsoEbiObj.setEbiId(deviceId);
			tsoEbiObj.updateIpsecTunnelId(getDeviceId(), getIpsecTunnelId());
			}
		}
		
		return true;
	}
	
	public boolean addToDBTblIpsecProvRequestDetails(long provReqId) throws SQLException, Exception {
		if(getIpseqReqDetailsList() != null){
			for(int i = 0;i<getIpseqReqDetailsList().size();i++){
				IpSecRequestDetailsBean reqBean = getIpseqReqDetailsList().get(i);
				DBTblIpsecProvRequestDetails reqDetails=new DBTblIpsecProvRequestDetails();
				reqDetails.setIpsecProvRequestId(provReqId);
				reqDetails.setName(reqBean.getName());
				reqDetails.setProvValue(reqBean.getProvValue());
				reqDetails.setProvAction(reqBean.getProvAction());
				reqDetails.insert(dbCon);
			}
		}

		
	
		return true;
	}

	 public long getIpSecTunnelIdSeqNextVal() throws SQLException
	 {
		 log.info("Entering getCustIdSeqNextVal");
		 long ipsecTunnelId = 0;
		 PreparedStatement ps = null;
		 ResultSet rs = null;
		 try
		 {
			 ps = dbCon.prepareStatement("SELECT IPSEC_TUNNEL_ID_SEQ.NEXTVAL FROM DUAL");
			 rs = ps.executeQuery();
			 if (rs.next())
				 ipsecTunnelId = rs.getLong(1);
		 }
		 catch (SQLException e)
		 {
			 throw e;
		 }
		 finally
		 {
			 try
			 {
				 if (null != rs)
					 rs.close();
				 if (null != ps)
					 ps.close();
			 }
			 catch (Exception e)
			 {
				 e.printStackTrace();
			 }
		 }
		 return ipsecTunnelId;
	 }
	 
	 public String getIpProvReqSeqNextVal() throws SQLException
     {
     log.info("Entering getCustIdSeqNextVal");
     String custId = "0";

     PreparedStatement ps = null;
     ResultSet rs = null;
     try
             {
         ps = dbCon.prepareStatement("SELECT IPSEC_PROV_REQUEST_SEQ.NEXTVAL FROM DUAL");
         rs = ps.executeQuery();
         if (rs.next())
             custId = rs.getString(1);
     }
     catch (SQLException e)
             {
         throw e;
             }
     finally
             {
         try
                     {
             if (null != rs)
                 rs.close();
             if (null != ps)
                 ps.close();
         }
         catch (Exception e)
                     {
                             e.printStackTrace();
                     }
     }
     return custId;
 }
	
	 
	 
	 public void updateIpsecTunnelId(long deviceId,long ipsecTunnelId) throws Exception {
		 DBTblGatewayDeviceInfo tblGatewayDeviceInfo = new DBTblGatewayDeviceInfo();
		 tblGatewayDeviceInfo.setIpsecTunnelId(ipsecTunnelId);
		 tblGatewayDeviceInfo.whereGatewayDeviceIdEQ(deviceId);
		 int gatewayDeviceInfoRecCountUpdated = tblGatewayDeviceInfo.updateSpByWhere(dbCon);
		 if(gatewayDeviceInfoRecCountUpdated == 0){
			 log.info("No Records Updated");
		 }else{
			 log.info("Successfully GatewayDevice Updated For IpSecTunnelId" + gatewayDeviceInfoRecCountUpdated);
		 }
	 }
	 
	 
	 
	 public void getCustomerDetails(String custId) throws SQLException{
		 
		 	PreparedStatement stmt = null;
		    ResultSet rs = null;
		    
		    try {
		     String query = "SELECT CUSTOMER_NAME,CONTACT_CITY,CONTACT_STATE FROM TBL_CUSTOMER WHERE CUSTOMER_ID = ?";
		     stmt = dbCon.prepareStatement(query);
		     stmt.setString(1, custId);
		     rs = stmt.executeQuery();
		     
		     if(rs.next()) {
		    	 setCustName(rs.getString("CUSTOMER_NAME"));
		         setCity(rs.getString("CONTACT_CITY"));
		         setState(rs.getString("CONTACT_STATE"));
		     }
		    }
		 catch(SQLException e) {
		     e.printStackTrace();
		 } finally{
			  if(stmt != null){
				  stmt.close();
			  }
			  if(rs != null){
				  rs.close();
			  }
		 	}	
	 }
	 
	 
	 
	 public void createDelProvRequestAndDetails(long ipsecTunnelId, long envOrderId) throws Exception {
		 PreparedStatement ps = null;
		 ResultSet rs = null;
		 long ipsecProvReqId = 0;
		 try
		 {
			 ps = dbCon.prepareStatement("select max(ipsec_prov_request_id) from tbl_ipsec_prov_request where ipsec_tunnel_id = "+ipsecTunnelId);
			 rs = ps.executeQuery();
			 if (rs.next())
				 ipsecProvReqId = rs.getLong(1);

			 TblIpsecProvRequestQuery tblProvQuery = new TblIpsecProvRequestQuery();
			 tblProvQuery.whereIpsecProvRequestIdEQ(ipsecProvReqId);
			 tblProvQuery.query(dbCon);
			 if(tblProvQuery.getDbBean(0) != null){
				 TblIpsecProvRequestDbBean provReqBean= tblProvQuery.getDbBean(0);
				 setIpsecTunnelId(ipsecTunnelId);
				 setRequestType((short)VzbVoipEnum.IpsecProvRequestType.DEL);
				 setRequestBy("SYSTEM");

				 setEnterpriseId(provReqBean.getEnterpriseId());
				 setDeviceType(provReqBean.getDeviceType());
				 setEnvOrderId(envOrderId);
				 setRequestStatus((short)VzbVoipEnum.IpsecProvRequestStatus.PENDING);

				 TblIpsecProvRequestDetailsQuery tblProvDetailsQuery = new TblIpsecProvRequestDetailsQuery();
				 tblProvDetailsQuery.whereIpsecProvRequestIdEQ(ipsecProvReqId);
				 tblProvDetailsQuery.query(dbCon);
				 List<IpSecRequestDetailsBean> ipsecDetailsList = new ArrayList<IpSecRequestDetailsBean>();
				 if(tblProvDetailsQuery.getResultArrayList() != null){
					 for(int i = 0;i<tblProvDetailsQuery.getResultArrayList().size();i++ ){
						 TblIpsecProvRequestDetailsDbBean provreqDetailBean = (TblIpsecProvRequestDetailsDbBean)tblProvDetailsQuery.getResultArrayList().get(i);
						if(provreqDetailBean.getProvAction().equalsIgnoreCase("o")){
							log.info(" Ignore this sbc as it already have a delete request :: "+provreqDetailBean.getProvValue());
						}else{
							 IpSecRequestDetailsBean ipseqReqBean= new IpSecRequestDetailsBean();
							 ipseqReqBean.setName(provreqDetailBean.getName());
							 ipseqReqBean.setProvValue(provreqDetailBean.getProvValue());
							 ipseqReqBean.setProvAction("o");
							 ipsecDetailsList.add(ipseqReqBean);
						}
					 }
				 }
				 if(ipsecDetailsList.size() >0){
					 setIpseqReqDetailsList(ipsecDetailsList);
					 addToDBTblIpsecProvRequest(); 
				 }else{
					 log.info("Request cannot be created as no sbc request is pending");
				 }
				 
			 }
		 }
		 catch (SQLException e)
		 {
			 throw e;
		 }
		 finally
		 {
			 try
			 {
				 if (null != rs)
					 rs.close();
				 if (null != ps)
					 ps.close();
			 }
			 catch (Exception e)
			 {
				 e.printStackTrace();
			 }
		 }
	 }

	 public void createIpseqDeleteRequest(long deviceId, short deviceType, long envOrderId, boolean updateTunnelStatus) throws Exception {
		 long ipsecTunnelId = 0;
		 try{
			ipsecTunnelId =getIpsecTunnelIdForDevice(deviceId,deviceType);
			 if(ipsecTunnelId >0){
				 if(updateTunnelStatus){
					 updateIpsecTunnelStatus(ipsecTunnelId);
				 }
				 setIpsecTunnelId(ipsecTunnelId);
				 createDelProvRequestAndDetails(ipsecTunnelId, envOrderId);
			 }
		 }catch (Exception e)
		 {
			 e.printStackTrace();
		 }
	 }
	 
	 public void updateIpsecTunnelStatus(long ipsecTunnelId) throws Exception {
		 DBTblIpsecTunnel ipsecTunnelObj = new DBTblIpsecTunnel();
		 ipsecTunnelObj.setTunnelStatus((short)0);
		 ipsecTunnelObj.whereIpsecTunnelIdEQ(ipsecTunnelId);
		 int recCountUpdated = ipsecTunnelObj.updateSpByWhere(dbCon);
		 if(recCountUpdated == 0){
			 log.info("No Records Updated");
		 }else{
			 log.info("Successfully Updated Tunel Status For IpSecTunnelId" + recCountUpdated);
		 }
	 }
	 
	 
	 public void createNewAndDeleteOldIpsecTunnel(long deviceId, short deviceType, long envOrderId, boolean updateTunnelStatus, String enterpriseId,String orgSystem) throws Exception {
		 long oldIpsecTunnelId = 0;
		 try{
			 
			 if(deviceType == VzbVoipEnum.IpsecDeviceType.DEVICE){
				 TblGatewayDeviceInfoQuery tbldevcieQuery = new TblGatewayDeviceInfoQuery();
				 tbldevcieQuery.whereGatewayDeviceIdEQ(deviceId);
				 tbldevcieQuery.query(dbCon);
				 if(tbldevcieQuery.getDbBean(0) != null && tbldevcieQuery.getDbBean(0).getIpsecTunnelId() >0){
					 oldIpsecTunnelId = tbldevcieQuery.getDbBean(0).getIpsecTunnelId();
				 }else{
					 log.info("No ipsec request associated for deviceid :: "+deviceId);
				 }
			 }else if(deviceType == VzbVoipEnum.IpsecDeviceType.EBI){
				 TblTsoEbiQuery tblebiQuery = new TblTsoEbiQuery();
				 tblebiQuery.whereEbiIdEQ(deviceId);
				 tblebiQuery.query(dbCon);
				 if(tblebiQuery.getDbBean(0) != null && tblebiQuery.getDbBean(0).getIpsecTunnelId() >0){
					 oldIpsecTunnelId = tblebiQuery.getDbBean(0).getIpsecTunnelId();
				 }else{
					 log.info("No ipsec request associated for EbiID :: "+deviceId);
				 }
			 }
			 addNewIpsecTunnelDetails(oldIpsecTunnelId, deviceId, deviceType, enterpriseId, orgSystem, envOrderId);
			 if(deviceType >0){
				 if(updateTunnelStatus){
					 updateIpsecTunnelStatus(oldIpsecTunnelId);
				 }
				 setIpsecTunnelId(oldIpsecTunnelId);
				 createDelProvRequestAndDetails(oldIpsecTunnelId, envOrderId);
			 }
		 }catch (Exception e)
		 {
			 e.printStackTrace();
		 }
	 }
	 
	 private long getMaxIpsecProvRequestId(long ipsecTunnId) throws Exception{
		 PreparedStatement ps = null;
		 ResultSet rs = null;
		 long ipsecProvReqId = 0;
		 try
		 {
			 ps = dbCon.prepareStatement("select max(ipsec_prov_request_id) from tbl_ipsec_prov_request where ipsec_tunnel_id = "+ipsecTunnId);
			 rs = ps.executeQuery();
			 if (rs.next())
				 ipsecProvReqId = rs.getLong(1); 
		 }catch (SQLException e)
		 {
			 throw e;
		 }
		 finally
		 {
			 try
			 {
				 if (null != rs)
					 rs.close();
				 if (null != ps)
					 ps.close();
			 }
			 catch (Exception e)
			 {
				 e.printStackTrace();
			 }
		 }
		return ipsecProvReqId;
	 }
	 
	 public void addNewIpsecTunnelDetails(long oldIpsecTunnelId,long deviceId, short deviceType, String enterprisId,String orgSystem,long envOrdId) throws Exception{
		 TblIpsecTunnelQuery ipsecTunnelQry = new TblIpsecTunnelQuery();
		 ipsecTunnelQry.whereIpsecTunnelIdEQ(oldIpsecTunnelId);
		 ipsecTunnelQry.query(dbCon);
		 if (ipsecTunnelQry.size() == 1) {
			 log.info("In getIpsecTunnel ipsecTunnelId"+oldIpsecTunnelId);
			 //TblIpsecTunnelDbBean ipsecTunnelDbBean = ipsecTunnelQry.getDbBean(0);

			 setIpsecTunnelId(getIpSecTunnelIdSeqNextVal());
			 /*setIkeIp(ipsecTunnelDbBean.getIkeIp());
			 setHostSubIP(ipsecTunnelDbBean.getSignalingHostSubnetIp());
			 setHostSubMask(ipsecTunnelDbBean.getSignalingHostSubnetMask());
			 setEgwType(ipsecTunnelDbBean.getEgwType());*/
			 setEnterpriseId(enterprisId);
			 setRequestType((short)VzbVoipEnum.IpsecProvRequestType.ADD);
			 setRequestBy(orgSystem);
			 setEnvOrderId(envOrdId);
			 setRequestStatus((short)VzbVoipEnum.IpsecProvRequestStatus.PENDING);
			 setDeviceType(deviceType);
			 setDeviceId(deviceId);

			 
			 long ipsecProvreqId = getMaxIpsecProvRequestId(oldIpsecTunnelId);
			 TblIpsecProvRequestDetailsQuery tblProvDetailsQuery = new TblIpsecProvRequestDetailsQuery();
			 tblProvDetailsQuery.whereIpsecProvRequestIdEQ(ipsecProvreqId);
			 tblProvDetailsQuery.query(dbCon);
			 List<IpSecRequestDetailsBean> ipsecDetailsList = new ArrayList<IpSecRequestDetailsBean>();
			 if(tblProvDetailsQuery.getResultArrayList() != null){
				 for(int i = 0;i<tblProvDetailsQuery.getResultArrayList().size();i++ ){
					 TblIpsecProvRequestDetailsDbBean provreqDetailBean = (TblIpsecProvRequestDetailsDbBean)tblProvDetailsQuery.getResultArrayList().get(i);
					if(provreqDetailBean.getProvAction().equalsIgnoreCase("o")){
						log.info(" Ignore this sbc as it already have a delete request :: "+provreqDetailBean.getProvValue());
					}else{
						 IpSecRequestDetailsBean ipseqReqBean= new IpSecRequestDetailsBean();
						 ipseqReqBean.setName(provreqDetailBean.getName());
						 ipseqReqBean.setProvValue(provreqDetailBean.getProvValue());
						 ipseqReqBean.setProvAction("n");
						 ipsecDetailsList.add(ipseqReqBean);
					}
				 }
			 }
			 if(ipsecDetailsList.size() >0){
				 setIpseqReqDetailsList(ipsecDetailsList);
				 //addToDBTblIpsecProvRequest(); 
			 }else{
				 log.info("Request cannot be created as no sbc request is pending");
			 }
			 addToDBTblIpSecTunnel();
		 }
	 }
	 
	 public void updateIpsecTunnelValues(long ipsecTunId) throws Exception{
		 try
		 {
			 DBTblIpsecTunnel ipsecTunnelBean = new DBTblIpsecTunnel();
			 ipsecTunnelBean.setEgwType(getEgwType());
			 ipsecTunnelBean.setSignalingHostSubnetMask(getHostSubMask());
			 ipsecTunnelBean.setSignalingHostSubnetIp(getHostSubIP());
			 ipsecTunnelBean.whereIpsecTunnelIdEQ(ipsecTunId);
				if (ipsecTunnelBean.updateSpByWhere(dbCon) <= 0) {
					log.info("ipSectunnel updated");
				}
		 }catch (SQLException e)
		 {
			 throw e;
		 }
	 }
	 
	 public void updateDevicewithIpsecTunnel(long devId, short deviceType, long ipsecTunId) throws Exception{
		 try
		 {
		     if(ipsecTunId > 0){
		    	 if(deviceType == VzbVoipEnum.IpsecDeviceType.EBI){
			    	 TsoEbi tsoEbiObj = new TsoEbi(dbCon);
						tsoEbiObj.setEbiId(devId);
						tsoEbiObj.updateIpsecTunnelId(devId, ipsecTunId);
			     }else if(deviceType == VzbVoipEnum.IpsecDeviceType.DEVICE){
			    	 updateIpsecTunnelId(devId, ipsecTunId);
			     }
		     }
		 }catch (SQLException e)
		 {
			 throw e;
		 }
	 }
	 
	 public long getIpsecTunnelIdForDevice(long deviceId,short deviceType) throws Exception{
		 long ipsecTunId = 0;
		 try{
			 if(deviceType == VzbVoipEnum.IpsecDeviceType.DEVICE){
				 TblGatewayDeviceInfoQuery tbldevcieQuery = new TblGatewayDeviceInfoQuery();
				 tbldevcieQuery.whereGatewayDeviceIdEQ(deviceId);
				 tbldevcieQuery.query(dbCon);
				 if(tbldevcieQuery.getDbBean(0) != null && tbldevcieQuery.getDbBean(0).getIpsecTunnelId() >0){
					 ipsecTunId = tbldevcieQuery.getDbBean(0).getIpsecTunnelId();
				 }else{
					 log.info("No ipsec request associated for deviceid :: "+deviceId);
				 }
			 }else if(deviceType == VzbVoipEnum.IpsecDeviceType.EBI){
				 TblTsoEbiQuery tblebiQuery = new TblTsoEbiQuery();
				 tblebiQuery.whereEbiIdEQ(deviceId);
				 tblebiQuery.query(dbCon);
				 if(tblebiQuery.getDbBean(0) != null && tblebiQuery.getDbBean(0).getIpsecTunnelId() >0){
					 ipsecTunId = tblebiQuery.getDbBean(0).getIpsecTunnelId();
				 }else{
					 log.info("No ipsec request associated for EbiID :: "+deviceId);
				 }
			 }
		 }catch(Exception e){
			 e.printStackTrace();
		 }
		 return ipsecTunId;
	 }
	 
	 public int countofDeviceForIpsecTunnel(long ipsecTunId,short deviceType) throws Exception{
		 int cnt = 0;
		 try{
			 if(deviceType == VzbVoipEnum.IpsecDeviceType.DEVICE){
				 TblGatewayDeviceInfoQuery tbldevcieQuery = new TblGatewayDeviceInfoQuery();
				 tbldevcieQuery.whereIpsecTunnelIdEQ(ipsecTunId);
				 tbldevcieQuery.query(dbCon);
				 cnt = tbldevcieQuery.size();
			 }else if(deviceType == VzbVoipEnum.IpsecDeviceType.EBI){
				 TblTsoEbiQuery tblebiQuery = new TblTsoEbiQuery();
				 tblebiQuery.whereIpsecTunnelIdEQ(ipsecTunId);
				 tblebiQuery.query(dbCon);
				cnt = tblebiQuery.size();
			 }
		 }catch(Exception e){
			 e.printStackTrace();
		 }
		 return cnt;
	 }
	 
	 public boolean isTunnelExistsInDb(long ipsecTunnId) throws Exception{
		 PreparedStatement ps = null;
		 ResultSet rs = null;
		 long count = 0;
		 try
		 {
			 ps = dbCon.prepareStatement("select count(*) from tbl_ipsec_tunnel where ipsec_tunnel_id = "+ipsecTunnId);
			 rs = ps.executeQuery();
			 if (rs.next())
				 count = rs.getLong(1); 
			 if(count>0)
				 return true;
		 }catch (SQLException e)
		 {
			 throw e;
		 }
		 finally
		 {
			 try
			 {
				 if (null != rs)
					 rs.close();
				 if (null != ps)
					 ps.close();
			 }
			 catch (Exception e)
			 {
				 e.printStackTrace();
			 }
		 }
		return false;
	 }
	 
}

