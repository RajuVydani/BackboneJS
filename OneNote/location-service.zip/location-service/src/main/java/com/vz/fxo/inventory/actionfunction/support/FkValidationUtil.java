package com.vz.fxo.inventory.actionfunction.support;

import java.sql.Connection;
import java.sql.SQLException;

import esap.db.DBTblBsAsMapping;
import esap.db.DBTblDeviceFirmwares;
import esap.db.DBTblDeviceMap;
import esap.db.DBTblDeviceTypes;
import esap.db.DBTblGatewayDeviceInfo;
import esap.db.DBTblGroup;
import esap.db.DBTblLocation;
import esap.db.DBTblPublicTnPool;
import esap.db.DBTblSipDeviceInfo;
import esap.db.DBTblSubscriber;
import esap.db.TblCallingPlansQuery;
import esap.db.TblCcMapQuery;
import esap.db.TblCodecTypeQuery;
import esap.db.TblDaylightSavingRegionsQuery;
import esap.db.TblDepartmentQuery;
import esap.db.TblDeviceBstypeQuery;
import esap.db.TblDeviceFirmwaresQuery;
import esap.db.TblDeviceRealtypeQuery;
import esap.db.TblDeviceTypesQuery;
import esap.db.TblFirmwareVersionQuery;
import esap.db.TblLanguageQuery;
import esap.db.TblPackageQuery;
import esap.db.TblTimeZoneQuery;



public class FkValidationUtil {

	/** This method checks some of the FK value of subscriber ***/

	public static void isValidSubscriberObj(Connection connection,
			DBTblSubscriber subObj) throws VzbInvFkException, SQLException {

		if (subObj.getDepartmentId() != null
				&& !subObj.getDepartmentId().equalsIgnoreCase("")) {
			isValidDepartmentID(connection, subObj.getDepartmentId());
		}

		if (subObj.getWebLang() >= 0) {
			isValidWebLang(connection, (int) subObj.getWebLang());
		} else {
			throw new VzbInvFkException("ESP_VZB_INV_PARENT_KEY_NOT_FOUND",
					"WebLang id is invalid ::" + subObj.getWebLang());
		}

		if (subObj.getVmLang() >= 0) {
			isValidVmLANG(connection, (int) subObj.getVmLang());
		} else {
			throw new VzbInvFkException("ESP_VZB_INV_PARENT_KEY_NOT_FOUND",
					"VMLang id is invalid ::" + subObj.getVmLang());
		}

		if (subObj.getCallingPlanId() > 0) {
			isValidCallingPlanID(connection, (int) subObj.getCallingPlanId());
		}

		if (subObj.getFeaturePkgId() > 0) {
			isValidFeaturePkgID(connection, (int) subObj.getFeaturePkgId());
		}

	}

	public static void isValidSipDeviceInfo(Connection connection,
			DBTblSipDeviceInfo sipDeviceInfoObj) throws VzbInvFkException,
			SQLException {

		if (sipDeviceInfoObj.getDeviceTypeId() > 0) {
			isValidDeviceTypeID(connection,
					(int) sipDeviceInfoObj.getDeviceTypeId());
		}
		if (sipDeviceInfoObj.getCodecId() >= 0) {
			isValidCodecID(connection, (int) sipDeviceInfoObj.getCodecId());
		} else {
			throw new VzbInvFkException("ESP_VZB_INV_PARENT_KEY_NOT_FOUND",
					"CodecId is invalid ::" + sipDeviceInfoObj.getCodecId());
		}
		if (sipDeviceInfoObj.getFirmwareVersionId() > 0) {
			isValidDeviceFirmWareID(connection,
					(int) sipDeviceInfoObj.getFirmwareVersionId());
		}
	}

	public static void isValidPublicTNPool(Connection connection,
			DBTblPublicTnPool publicTnPoolObj) throws VzbInvFkException,
			SQLException {
		if (publicTnPoolObj.getDepartmentId() != null
				&& !publicTnPoolObj.getDepartmentId().equalsIgnoreCase("")) {
			isValidDepartmentID(connection, publicTnPoolObj.getDepartmentId());
		}
	}

	public static void isValidLocation(Connection connection,
			DBTblLocation locationObj) throws VzbInvFkException, SQLException {
		if (locationObj.getLocCountry() != null
				&& !locationObj.getLocCountry().equalsIgnoreCase("")) {
			isValidLocationCountry(connection, locationObj.getLocCountry());
		} else {
			throw new VzbInvFkException("ESP_VZB_INV_PARENT_KEY_NOT_FOUND",
					"Location County is Invalid::"
							+ locationObj.getLocCountry());
		}

		if (locationObj.getTimeZone() > 0) {
			isValidTimeZone(connection, (int) locationObj.getTimeZone());
		}

		if (locationObj.getDaylightSavingsRegion() > 0) {
			isValidDaylightSavingRegion(connection,
					(int) locationObj.getDaylightSavingsRegion());
		}

		if (locationObj.getWebLang() >= 0) {
			isValidWebLang(connection, (int) locationObj.getWebLang());
		} else {
			throw new VzbInvFkException("ESP_VZB_INV_PARENT_KEY_NOT_FOUND",
					"WebLang id is invalid::" + locationObj.getWebLang());
		}

	}

	public static void isValidGroup(Connection connection, DBTblGroup groupObj)
			throws VzbInvFkException, SQLException {
		if (groupObj.getDepartmentId() != null
				&& !groupObj.getDepartmentId().equalsIgnoreCase("")) {
			isValidDepartmentID(connection, groupObj.getDepartmentId());
		}
	}

	public static void isValidGatewayDeviceInfo(Connection connection,
			DBTblGatewayDeviceInfo gatewayDeviceInfoObj)
			throws VzbInvFkException, SQLException {
		if (gatewayDeviceInfoObj.getDeviceTypeId() > 0) {
			isValidDeviceTypeID(connection,
					(int) gatewayDeviceInfoObj.getDeviceTypeId());
		}
	}

	public static void isValidDeviceTypes(Connection connection,
			DBTblDeviceTypes deviceTypesObj) throws VzbInvFkException,
			SQLException {
		if (deviceTypesObj.getDeviceBstypeId() > 0) {
			isValidDeviceBsTypeID(connection,
					(int) deviceTypesObj.getDeviceBstypeId());
		}
		if (deviceTypesObj.getDeviceRealtypeId() > 0) {
			isValidDeviceRealTypeID(connection,
					(int) deviceTypesObj.getDeviceRealtypeId());
		}
	}

	public static void isValidDeviceMap(Connection connection,
			DBTblDeviceMap deviceMapObj) throws VzbInvFkException, SQLException {
		// IR #1457935 Migration Failure while trying to migrate
		if (deviceMapObj.getDepartmentId() != null
				&& !deviceMapObj.getDepartmentId().equalsIgnoreCase("")
				&& !deviceMapObj.getDepartmentId().equalsIgnoreCase("NONE")) {
			isValidDepartmentID(connection, deviceMapObj.getDepartmentId());
		}
	}

	public static void isValidDeviceFirmWares(Connection connection,
			DBTblDeviceFirmwares deviceFirmwaresObj) throws VzbInvFkException,
			SQLException {
		if (deviceFirmwaresObj.getFirmwareVersionId() >= 0) {
			isValidFirmwareVersionID(connection,
					(int) deviceFirmwaresObj.getFirmwareVersionId());
		} else {
			throw new VzbInvFkException("ESP_VZB_INV_PARENT_KEY_NOT_FOUND",
					"Firmware version id is invalid::"
							+ deviceFirmwaresObj.getFirmwareVersionId());
		}
	}

	public static void isValidBsAsMapping(Connection connection,
			DBTblBsAsMapping bsAsMappingObj) throws VzbInvFkException,
			SQLException {
		if (bsAsMappingObj.getIsoCountryCode() != null
				&& !bsAsMappingObj.getIsoCountryCode().equalsIgnoreCase("")) {
			isValidIsoCountryCode(connection,
					bsAsMappingObj.getIsoCountryCode());
		} else {
			throw new VzbInvFkException("ESP_VZB_INV_PARENT_KEY_NOT_FOUND",
					"Iso Country code is invalid::"
							+ bsAsMappingObj.getIsoCountryCode());
		}
	}

	public static void isValidBsASObj(Connection connection,
			DBTblBsAsMapping bsAsMapObj) throws VzbInvFkException, SQLException {

		if (bsAsMapObj.getIsoCountryCode() != null
				&& !bsAsMapObj.getIsoCountryCode().equalsIgnoreCase("")) {
			isValidIsoCountryCode(connection, bsAsMapObj.getIsoCountryCode());
		}
	}

	/*************** modified object ****************************/
	public static void isValidSubscriberObjForMod(Connection connection,
			DBTblSubscriber subObj) throws VzbInvFkException, SQLException {

		DBTblSubscriber localObj = new DBTblSubscriber();
		if (localObj.getDepartmentId() != subObj.getDepartmentId()) {
			if (subObj.getDepartmentId() != null
					&& !subObj.getDepartmentId().equalsIgnoreCase("")) {
				isValidDepartmentID(connection, subObj.getDepartmentId());
			}
		}

		if (localObj.getWebLang() != subObj.getWebLang()) {
			if (subObj.getWebLang() >= 0) {
				isValidWebLang(connection, (int) subObj.getWebLang());
			} else {
				throw new VzbInvFkException("ESP_VZB_INV_PARENT_KEY_NOT_FOUND",
						"WebLang id is invalid::" + subObj.getWebLang());
			}
		}

		if (localObj.getVmLang() != subObj.getVmLang()) {
			if (subObj.getVmLang() >= 0) {
				isValidVmLANG(connection, (int) subObj.getVmLang());
			} else {
				throw new VzbInvFkException("ESP_VZB_INV_PARENT_KEY_NOT_FOUND",
						"VMLang id is invalid::" + subObj.getVmLang());
			}
		}

		if (localObj.getCallingPlanId() != subObj.getCallingPlanId()) {
			if (subObj.getCallingPlanId() > 0) {
				isValidCallingPlanID(connection,
						(int) subObj.getCallingPlanId());
			}
		}

		if (localObj.getFeaturePkgId() != subObj.getFeaturePkgId()) {
			if (subObj.getFeaturePkgId() > 0) {
				isValidFeaturePkgID(connection, (int) subObj.getFeaturePkgId());
			}
		}

	}

	public static void isValidSipDeviceInfoForMod(Connection connection,
			DBTblSipDeviceInfo sipDeviceInfoObj) throws VzbInvFkException,
			SQLException {

		DBTblSipDeviceInfo localObj = new DBTblSipDeviceInfo();

		if (localObj.getDeviceTypeId() != sipDeviceInfoObj.getDeviceTypeId()) {
			if (sipDeviceInfoObj.getDeviceTypeId() > 0) {
				isValidDeviceTypeID(connection,
						(int) sipDeviceInfoObj.getDeviceTypeId());
			}
		}
		if (localObj.getCodecId() != sipDeviceInfoObj.getCodecId()) {
			if (sipDeviceInfoObj.getCodecId() >= 0) {
				isValidCodecID(connection, (int) sipDeviceInfoObj.getCodecId());
			} else {
				throw new VzbInvFkException("ESP_VZB_INV_PARENT_KEY_NOT_FOUND",
						"CodecId is invalid::" + sipDeviceInfoObj.getCodecId());
			}
		}
		if (localObj.getFirmwareVersionId() != sipDeviceInfoObj
				.getFirmwareVersionId()) {
			if (sipDeviceInfoObj.getFirmwareVersionId() > 0) {
				isValidDeviceFirmWareID(connection,
						(int) sipDeviceInfoObj.getFirmwareVersionId());
			}
		}
	}

	public static void isValidPublicTNPoolForMod(Connection connection,
			DBTblPublicTnPool publicTnPoolObj) throws VzbInvFkException,
			SQLException {
		DBTblPublicTnPool localObj = new DBTblPublicTnPool();
		if (localObj.getDepartmentId() != publicTnPoolObj.getDepartmentId()) {
			if (publicTnPoolObj.getDepartmentId() != null
					&& !publicTnPoolObj.getDepartmentId().equalsIgnoreCase("")) {
				isValidDepartmentID(connection,
						publicTnPoolObj.getDepartmentId());
			}
		}
	}

	public static void isValidLocationForMod(Connection connection,
			DBTblLocation locationObj) throws VzbInvFkException, SQLException {

		DBTblLocation localObj = new DBTblLocation();
		if (localObj.getLocCountry() != locationObj.getLocCountry()) {
			if (locationObj.getLocCountry() != null
					&& !locationObj.getLocCountry().equalsIgnoreCase("")) {
				isValidLocationCountry(connection, locationObj.getLocCountry());
			} else {
				throw new VzbInvFkException("ESP_VZB_INV_PARENT_KEY_NOT_FOUND",
						"Location County is Invalid::"
								+ locationObj.getLocCountry());
			}
		}

		if (localObj.getTimeZone() != locationObj.getTimeZone()) {
			if (locationObj.getTimeZone() > 0) {
				isValidTimeZone(connection, (int) locationObj.getTimeZone());
			}
		}

		if (localObj.getDaylightSavingsRegion() != locationObj
				.getDaylightSavingsRegion()) {
			if (locationObj.getDaylightSavingsRegion() > 0) {
				isValidDaylightSavingRegion(connection,
						(int) locationObj.getDaylightSavingsRegion());
			}
		}

		if (localObj.getWebLang() != locationObj.getWebLang()) {
			if (locationObj.getWebLang() >= 0) {
				isValidWebLang(connection, (int) locationObj.getWebLang());
			} else {
				throw new VzbInvFkException("ESP_VZB_INV_PARENT_KEY_NOT_FOUND",
						"WebLang id is invalid::" + locationObj.getWebLang());
			}
		}
	}

	public static void isValidGroupForMod(Connection connection,
			DBTblGroup groupObj) throws VzbInvFkException, SQLException {
		DBTblGroup localObj = new DBTblGroup();
		if (localObj.getDepartmentId() != groupObj.getDepartmentId()) {
			if (groupObj.getDepartmentId() != null
					&& !groupObj.getDepartmentId().equalsIgnoreCase("")) {
				isValidDepartmentID(connection, groupObj.getDepartmentId());
			}
		}
	}

	public static void isValidGatewayDeviceInfoForMod(Connection connection,
			DBTblGatewayDeviceInfo gatewayDeviceInfoObj)
			throws VzbInvFkException, SQLException {
		DBTblGatewayDeviceInfo localObj = new DBTblGatewayDeviceInfo();
		if (localObj.getDeviceTypeId() != gatewayDeviceInfoObj
				.getDeviceTypeId()) {
			if (gatewayDeviceInfoObj.getDeviceTypeId() > 0) {
				isValidDeviceTypeID(connection,
						(int) gatewayDeviceInfoObj.getDeviceTypeId());
			}
		}
	}

	public static void isValidDeviceTypesForMod(Connection connection,
			DBTblDeviceTypes deviceTypesObj) throws VzbInvFkException,
			SQLException {
		DBTblDeviceTypes localObj = new DBTblDeviceTypes();

		if (localObj.getDeviceBstypeId() != deviceTypesObj.getDeviceBstypeId()) {
			if (deviceTypesObj.getDeviceBstypeId() > 0) {
				isValidDeviceBsTypeID(connection,
						(int) deviceTypesObj.getDeviceBstypeId());
			}
		}
		if (localObj.getDeviceRealtypeId() != deviceTypesObj
				.getDeviceRealtypeId()) {
			if (deviceTypesObj.getDeviceRealtypeId() > 0) {
				isValidDeviceRealTypeID(connection,
						(int) deviceTypesObj.getDeviceRealtypeId());
			}
		}
	}

	public static void isValidDeviceMapForMod(Connection connection,
			DBTblDeviceMap deviceMapObj) throws VzbInvFkException, SQLException {
		DBTblDeviceMap localObj = new DBTblDeviceMap();
		if (localObj.getDepartmentId() != deviceMapObj.getDepartmentId()) {
			if (deviceMapObj.getDepartmentId() != null
					&& !deviceMapObj.getDepartmentId().equalsIgnoreCase("")) {
				isValidDepartmentID(connection, deviceMapObj.getDepartmentId());
			}
		}
	}

	public static void isValidDeviceFirmWaresForMod(Connection connection,
			DBTblDeviceFirmwares deviceFirmwaresObj) throws VzbInvFkException,
			SQLException {
		DBTblDeviceFirmwares localObj = new DBTblDeviceFirmwares();
		if (localObj.getFirmwareVersionId() != deviceFirmwaresObj
				.getFirmwareVersionId()) {
			if (deviceFirmwaresObj.getFirmwareVersionId() >= 0) {
				isValidFirmwareVersionID(connection,
						(int) deviceFirmwaresObj.getFirmwareVersionId());
			} else {
				throw new VzbInvFkException("ESP_VZB_INV_PARENT_KEY_NOT_FOUND",
						"Firmware version id is invalid::"
								+ deviceFirmwaresObj.getFirmwareVersionId());
			}
		}
	}

	public static void isValidBsAsMappingForMod(Connection connection,
			DBTblBsAsMapping bsAsMappingObj) throws VzbInvFkException,
			SQLException {

		if (bsAsMappingObj.getIsoCountryCode() != null
				&& !bsAsMappingObj.getIsoCountryCode().equalsIgnoreCase("")) {
			isValidIsoCountryCode(connection,
					bsAsMappingObj.getIsoCountryCode());
		}/*
		 * else { throw new
		 * VzbInvFkException("ESP_VZB_INV_PARENT_KEY_NOT_FOUND",
		 * "Iso Country code is invalid::" +
		 * bsAsMappingObj.getIsoCountryCode()); }
		 */

	}

	/************ end modify *******************/

	public static void isValidDepartmentID(Connection connection, String deptId)
			throws VzbInvFkException, SQLException {
		// select 1 from TBL_DEPARTMENT where DEPARTMENT_ID ='5911';
		TblDepartmentQuery departmentQry = new TblDepartmentQuery();
		departmentQry.whereDepartmentIdEQ(deptId);
		departmentQry.query(connection);
		if (departmentQry.size() <= 0) {
			throw new VzbInvFkException("ESP_VZB_INV_PARENT_KEY_NOT_FOUND",
					"Parent Key not found table::TBL_DEPARTMENT key/DEPARTMENT_ID="
							+ deptId);
		}

	}

	public static void isValidWebLang(Connection connection, int langCode)
			throws VzbInvFkException, SQLException {
		// select 1 from TBL_LANGUAGE where LANG_CODE =5;
		TblLanguageQuery langQry = new TblLanguageQuery();
		langQry.whereLangCodeEQ(langCode);
		langQry.query(connection);
		if (langQry.size() <= 0) {
			throw new VzbInvFkException("ESP_VZB_INV_PARENT_KEY_NOT_FOUND",
					"Parent Key not found table::TBL_LANGUAGE key/LANG_CODE="
							+ langCode);
		}
	}

	public static void isValidVmLANG(Connection connection, int langCode)
			throws VzbInvFkException, SQLException {
		// select 1 from TBL_LANGUAGE where LANG_CODE = 5;
		TblLanguageQuery langQry = new TblLanguageQuery();
		langQry.whereLangCodeEQ(langCode);
		langQry.query(connection);
		if (langQry.size() <= 0) {
			throw new VzbInvFkException("ESP_VZB_INV_PARENT_KEY_NOT_FOUND",
					"Parent Key not found table::TBL_LANGUAGE key/LANG_CODE="
							+ langCode);
		}
	}

	public static void isValidCallingPlanID(Connection connection,
			int callingPlanId) throws VzbInvFkException, SQLException {
		// select 1 from TBL_CALLING_PLANS where CALLING_PLAN_ID = 350
		TblCallingPlansQuery callingPlanQry = new TblCallingPlansQuery();
		callingPlanQry.whereCallingPlanIdEQ(callingPlanId);
		callingPlanQry.query(connection);
		if (callingPlanQry.size() <= 0) {
			throw new VzbInvFkException("ESP_VZB_INV_PARENT_KEY_NOT_FOUND",
					"Parent Key not found table::TBL_CALLING_PLANS  key/CALLING_PLAN_ID="
							+ callingPlanId);
		}
	}

	public static void isValidFeaturePkgID(Connection connection, int packageId)
			throws VzbInvFkException, SQLException {
		// select 1 from TBL_PACKAGE where PACKAGE_ID =1460;
		TblPackageQuery packageQry = new TblPackageQuery();
		packageQry.wherePackageIdEQ(packageId);
		packageQry.query(connection);
		if (packageQry.size() <= 0) {
			throw new VzbInvFkException("ESP_VZB_INV_PARENT_KEY_NOT_FOUND",
					"Parent Key not found table::TBL_PACKAGE key/PACKAGE_ID="
							+ packageId);
		}
	}

	public static void isValidDeviceTypeID(Connection connection,
			int deviceTypeId) throws VzbInvFkException, SQLException {
		// select 1 from TBL_DEVICE_TYPES where DEVICE_TYPE_ID =2544;
		TblDeviceTypesQuery deviceTypesQry = new TblDeviceTypesQuery();
		deviceTypesQry.whereDeviceTypeIdEQ(deviceTypeId);
		deviceTypesQry.query(connection);
		if (deviceTypesQry.size() <= 0) {
			throw new VzbInvFkException("ESP_VZB_INV_PARENT_KEY_NOT_FOUND",
					"Parent Key not found table::TBL_DEVICE_TYPES key/DEVICE_TYPE_ID="
							+ deviceTypeId);
		}
	}

	public static void isValidCodecID(Connection connection, int codecId)
			throws VzbInvFkException, SQLException {
		// select 1 from TBL_CODEC_TYPE where CODEC_ID =4

		TblCodecTypeQuery codecTypeQry = new TblCodecTypeQuery();
		codecTypeQry.whereCodecIdEQ(codecId);
		codecTypeQry.query(connection);
		if (codecTypeQry.size() <= 0) {
			throw new VzbInvFkException("ESP_VZB_INV_PARENT_KEY_NOT_FOUND",
					"Parent Key not found table::TBL_CODEC_TYPE key/CODEC_ID="
							+ codecId);
		}
	}

	public static void isValidFirmwareVersionID(Connection connection,
			int firmwareVersionId) throws VzbInvFkException, SQLException {
		// select 1 from TBL_FIRMWARE_VERSION where FIRMWARE_VERSION_ID =4;
		TblFirmwareVersionQuery firmwareVersionQry = new TblFirmwareVersionQuery();
		firmwareVersionQry.whereFirmwareVersionIdEQ(firmwareVersionId);
		firmwareVersionQry.query(connection);
		if (firmwareVersionQry.size() <= 0) {
			throw new VzbInvFkException("ESP_VZB_INV_PARENT_KEY_NOT_FOUND",
					"Parent Key not found table::TBL_FIRMWARE_VERSION key/FIRMWARE_VERSION_ID="
							+ firmwareVersionId);
		}
	}

	public static void isValidLocationCountry(Connection connection,
			String countryCode) throws VzbInvFkException, SQLException {
		// select 1 from TBL_CC_MAP where CNTRY_CODE = 'DE'
		TblCcMapQuery ccMapQry = new TblCcMapQuery();
		ccMapQry.whereCntryCodeEQ(countryCode);
		ccMapQry.query(connection);
		if (ccMapQry.size() <= 0) {
			throw new VzbInvFkException("ESP_VZB_INV_PARENT_KEY_NOT_FOUND",
					"Parent Key not found table::TBL_CC_MAP key/CNTRY_CODE="
							+ countryCode);
		}
	}

	public static void isValidTimeZone(Connection connection, int timeZoneId)
			throws VzbInvFkException, SQLException {
		// select 1 from TBL_TIME_ZONE where TIME_ZONE_ID = 1;
		TblTimeZoneQuery timeZoneQry = new TblTimeZoneQuery();
		timeZoneQry.whereTimeZoneIdEQ(timeZoneId);
		timeZoneQry.query(connection);
		if (timeZoneQry.size() <= 0) {
			throw new VzbInvFkException("ESP_VZB_INV_PARENT_KEY_NOT_FOUND",
					"Parent Key not found table::TBL_TIME_ZONE key/TIME_ZONE_ID="
							+ timeZoneId);
		}
	}

	public static void isValidDaylightSavingRegion(Connection connection,
			int daylightSavingRegionsId) throws VzbInvFkException, SQLException {
		// select 1 from TBL_DAYLIGHT_SAVING_REGIONS where
		// DAYLIGHT_SAVING_REGIONS_ID =26;
		TblDaylightSavingRegionsQuery daylightSavingRegionsQry = new TblDaylightSavingRegionsQuery();
		daylightSavingRegionsQry
				.whereDaylightSavingRegionsIdEQ(daylightSavingRegionsId);
		daylightSavingRegionsQry.query(connection);
		if (daylightSavingRegionsQry.size() <= 0) {
			throw new VzbInvFkException(
					"ESP_VZB_INV_PARENT_KEY_NOT_FOUND",
					"Parent Key not found table::TBL_DAYLIGHT_SAVING_REGIONS key/DAYLIGHT_SAVING_REGIONS_ID="
							+ daylightSavingRegionsId);
		}
	}

	public static void isValidDeviceBsTypeID(Connection connection,
			int deviceBstypeId) throws VzbInvFkException, SQLException {
		// select 1 from TBL_DEVICE_BSTYPE where DEVICE_BSTYPE_ID =46;
		TblDeviceBstypeQuery deviceBsTypeQry = new TblDeviceBstypeQuery();
		deviceBsTypeQry.whereDeviceBstypeIdEQ(deviceBstypeId);
		deviceBsTypeQry.query(connection);
		if (deviceBsTypeQry.size() <= 0) {
			throw new VzbInvFkException("ESP_VZB_INV_PARENT_KEY_NOT_FOUND",
					"Parent Key not found table::TBL_DEVICE_BSTYPE key/DEVICE_BSTYPE_ID="
							+ deviceBstypeId);
		}
	}

	public static void isValidDeviceRealTypeID(Connection connection,
			int deviceRealtypeId) throws VzbInvFkException, SQLException {
		// select 1 from TBL_DEVICE_REALTYPE where DEVICE_REALTYPE_ID =2;
		TblDeviceRealtypeQuery deviceRealTypeQry = new TblDeviceRealtypeQuery();
		deviceRealTypeQry.whereDeviceRealtypeIdEQ(deviceRealtypeId);
		deviceRealTypeQry.query(connection);
		if (deviceRealTypeQry.size() <= 0) {
			throw new VzbInvFkException("ESP_VZB_INV_PARENT_KEY_NOT_FOUND",
					"Parent Key not found table::TBL_DEVICE_REALTYPE key/DEVICE_REALTYPE_ID="
							+ deviceRealtypeId);
		}
	}

	public static void isValidIsoCountryCode(Connection connection,
			String countryCode) throws VzbInvFkException, SQLException {
		// select 1 from TBL_CC_MAP where CNTRY_CODE = 'AT';
		TblCcMapQuery ccMapQry = new TblCcMapQuery();
		ccMapQry.whereCntryCodeEQ(countryCode);
		ccMapQry.query(connection);
		if (ccMapQry.size() <= 0) {
			throw new VzbInvFkException("ESP_VZB_INV_PARENT_KEY_NOT_FOUND",
					"Parent Key not found table::TBL_CC_MAP key/CNTRY_CODE="
							+ countryCode);
		}
	}

	public static void isValidDeviceFirmWareID(Connection connection,
			int deviceFirmwareId) throws VzbInvFkException, SQLException {
		// select 1 from TBL_DEVICE_FIRMWARES where DEVICE_FIRMWARES_ID=1
		TblDeviceFirmwaresQuery deviceFirmwareQry = new TblDeviceFirmwaresQuery();
		deviceFirmwareQry.whereDeviceFirmwaresIdEQ(deviceFirmwareId);
		deviceFirmwareQry.query(connection);
		if (deviceFirmwareQry.size() <= 0) {
			throw new VzbInvFkException("ESP_VZB_INV_PARENT_KEY_NOT_FOUND",
					"Parent Key not found table::TBL_DEVICE_FIRMWARES key/DEVICE_FIRMWARES_ID="
							+ deviceFirmwareId);
		}
	}

}
