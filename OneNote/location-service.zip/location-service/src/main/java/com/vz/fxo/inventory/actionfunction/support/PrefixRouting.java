package com.vz.fxo.inventory.actionfunction.support;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Timestamp;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import esap.db.DBTblPrefixRouting;
import esap.db.TblPrefixRoutingDbBean;
import esap.db.TblPrefixRoutingQuery;

public class PrefixRouting extends PrefixRoutingBean{

	private static Logger log = LoggerFactory.getLogger(PrefixRouting.class.toString());
	
	Connection dbCon;
	String statusCode; 
	String statusDesc;

	InvErrorCode status = InvErrorCode.INTERNAL_ERROR;
	public int getStatusCode() {
		return status.getErrorCode();
	}

	public void setStatus(InvErrorCode status) {
		this.status = status;
	}

	public String getStatusDesc() {
		return status.getErrorDesc();
	}
	public Connection getDbCon() {
		return dbCon;
	}
	public void setDbCon(Connection dbCon) {
		this.dbCon = dbCon;
	}

	public PrefixRouting(Connection dbCon)
	{
		this.dbCon = dbCon;
	}

	public PrefixRouting(PrefixRoutingBean prefixRoutingBean, Connection dbCon)
	{
		super(prefixRoutingBean);
		this.dbCon = dbCon;
	}

	//Methods
	public boolean addPrefixRouting() throws SQLException, Exception
	{
		log.info("Entering Prefix Routing : addPrefixRouting()");
	//	try
		//{

			DBTblPrefixRouting prDbBean = new DBTblPrefixRouting();

			if(getPrefixId() <= 0)
				this.setPrefixId(prDbBean.getPrefixRoutingIdSeqNextVal(dbCon));

			//set prefix routing db bean attributes
			prDbBean.setPrefixRoutingId(getPrefixId());
			prDbBean.setEnterpriseId(getEnterpriseId());
			if(!"NONE".equals(getLocationId()) && !"".equals(getLocationId()))
				prDbBean.setLocationId(getLocationId());
			prDbBean.setPrefixType(getPrefixType());
			if(!"NONE".equals(getInterLocationPrefix()) && !"".equals(getInterLocationPrefix()))
				prDbBean.setInterLocationPrefix(getInterLocationPrefix());
			if(getInterLocationExtLength() != -1)
				prDbBean.setInterLocationExtLength(getInterLocationExtLength());
			if(!"NONE".equals(getInterLocationPrefixAdd()) && !"".equals(getInterLocationPrefixAdd()))
				prDbBean.setInterLocationPrefixAdd(getInterLocationPrefixAdd());
			if(getInterLocationDigitStrip() != -1)
			prDbBean.setInterLocationDigitsStrip(getInterLocationDigitStrip());

			log.info("EnvOrderId = <" + getEnvOrderId() + ">");
    	    		if(getEnvOrderId() > 0)
    	    			prDbBean.setEnvOrderId(getEnvOrderId());
			else
    	    			prDbBean.setEnvOrderIdNull();

			if(getModifiedBy() != null && !getModifiedBy().equals(""))
				prDbBean.setModifiedBy(getModifiedBy());
			else
				prDbBean.setModifiedBy("ESAP_INV");
			if(getCreatedBy() != null && !getCreatedBy().equals(""))
				prDbBean.setCreatedBy(getCreatedBy());
			else
				prDbBean.setCreatedBy("ESAP_INV");
				
			prDbBean.setCreationDate(new Timestamp(System.currentTimeMillis()));
			prDbBean.setLastModifiedDate(new Timestamp(System.currentTimeMillis()));
			prDbBean.setCreationDate(new Timestamp(System.currentTimeMillis()));
			
			prDbBean.insert(dbCon);

/*	}
		catch(SQLException s)
		{
			s.printStackTrace();	
			setStatus(InvErrorCode.DB_EXCEPTION);
			log.info("DB_FAILURE in addPrefixRouting");
			return false;
		}*/
		setStatus(InvErrorCode.SUCCESS);
		return true;
	}

	public boolean getPrefixRoutingByPrefixId()
	{
		log.info("Entering Prefix Routing : getPrefixRoutingByPrefixId()");
		try
		{
            TblPrefixRoutingQuery prQry = new TblPrefixRoutingQuery();
            initilizeTODefault();
            prQry.wherePrefixRoutingIdEQ(getPrefixId());
            prQry.query(dbCon);
            if(prQry.size() <= 0){
				log.info("Prefix Routing Id not Found");
				return false;
            }
            TblPrefixRoutingDbBean prBean = prQry.getDbBean(0);
            setEnterpriseId(prBean.getEnterpriseId());
            setLocationId(prBean.getLocationId());
            setPrefixType(prBean.getPrefixType());
            setInterLocationPrefix(prBean.getInterLocationPrefix());
            setInterLocationExtLength(prBean.getInterLocationExtLength());
            setInterLocationPrefixAdd(prBean.getInterLocationPrefixAdd());
            setInterLocationDigitStrip(prBean.getInterLocationDigitsStrip());
            setCreatedBy(prBean.getCreatedBy()) ;
            setModifiedBy(prBean.getModifiedBy()) ;
            setLastModifiedDate(prBean.getLastModifiedDate());            
	    setEnvOrderId(prBean.getEnvOrderId());
		}
		catch(SQLException e)
		{
			e.printStackTrace();	
			setStatus(InvErrorCode.DB_EXCEPTION);
			return false;
		}
		catch(Exception e)
		{
			e.printStackTrace();	
			setStatus(InvErrorCode.ERROR_GETTING_PREFIX_ROUTING);
			return false;
		}

		setStatus(InvErrorCode.SUCCESS);
		return true;
	}

	public boolean getPrefixRoutingByEnterpriseId()
	{
		log.info("Entering Prefix Routing : getPrefixRoutingByEnterpriseId()");
		try
		{
		    TblPrefixRoutingQuery prQry = new TblPrefixRoutingQuery();
		    initilizeTODefault();
		    prQry.whereEnterpriseIdEQ(getEnterpriseId());
            prQry.query(dbCon);
            if(prQry.size() <= 0){
				log.info("Enterprise Id not Found");
				return false;
            }
            TblPrefixRoutingDbBean prBean = prQry.getDbBean(0);
            setEnterpriseId(prBean.getEnterpriseId());
            setLocationId(prBean.getLocationId());
            setPrefixType(prBean.getPrefixType());
            setInterLocationPrefix(prBean.getInterLocationPrefix());
            setInterLocationExtLength(prBean.getInterLocationExtLength());
            setInterLocationPrefixAdd(prBean.getInterLocationPrefixAdd());
            setInterLocationDigitStrip(prBean.getInterLocationDigitsStrip());
            setCreatedBy(prBean.getCreatedBy()) ;
            setModifiedBy(prBean.getModifiedBy()) ;
            setLastModifiedDate(prBean.getLastModifiedDate());   
            setEnvOrderId(prBean.getEnvOrderId());
		}
		catch(SQLException e)
		{
			e.printStackTrace();	
			setStatus(InvErrorCode.DB_EXCEPTION);
			return false;
		}
		catch(Exception e)
		{
			e.printStackTrace();	
			setStatus(InvErrorCode.ERROR_GETTING_PREFIX_ROUTING);
			return false;
		}

		setStatus(InvErrorCode.SUCCESS);
		return true;
	}
	
	public boolean updatePrefixRouting() throws SQLException, Exception
	{
		log.info("Entering Prefix Routing : updatePrefixRouting()");
	//	try
	//	{

			if(getPrefixId() <= 0)
                        {
								setStatus(InvErrorCode.INTERNAL_ERROR);
                                return false;
                        }

			DBTblPrefixRouting prDbBean = new DBTblPrefixRouting();
			//Deletion of parameters - TBD
			
			prDbBean.setPrefixRoutingId(getPrefixId());
			if(getEnterpriseId() != null && getEnterpriseId() != "")
				prDbBean.setEnterpriseId(getEnterpriseId());
			// IR #1137825   if(getLocationId() != null && getLocationId() != "" && getLocationId() != "NONE")
			if(!"NONE".equals(getLocationId()) && !"".equals(getLocationId()))
				prDbBean.setLocationId(getLocationId());
			// else
			  // prDbBean.setLocationIdNull();
			if(getPrefixType() > 0)
				prDbBean.setPrefixType(getPrefixType());	
			// IR #1137825 if(getInterLocationPrefix() != null && getInterLocationPrefix() != "" && getInterLocationPrefix() != "NONE")
			
			//IR #1365177  changed the "Digits after Identifier" and "Digits to Add" fields.
			
			if(!"NONE".equals(getInterLocationPrefix()) && !"".equals(getInterLocationPrefix())){
				prDbBean.setInterLocationPrefix(getInterLocationPrefix());
			}
			//else
				//prDbBean.setInterLocationPrefixNull();
			
			//IR#1446734 0 in "Digits after Location Identifier" and "digits To Strip " 
			if(getInterLocationExtLength() > 0)
				prDbBean.setInterLocationExtLength(getInterLocationExtLength());
			else
				prDbBean.setInterLocationExtLength(0);
			// IR #1137825 if(getInterLocationPrefixAdd() != null && getInterLocationPrefixAdd() != "" && getInterLocationPrefixAdd() != "NONE")
			
			//IR #1365177  changed the "Digits after Identifier" and "Digits to Add" fields.
			if(!"NONE".equals(getInterLocationPrefixAdd()) && !"".equals(getInterLocationPrefixAdd())){
				prDbBean.setInterLocationPrefixAdd(getInterLocationPrefixAdd());
			}
			//else
				//prDbBean.setInterLocationPrefixAddNull();
			
			log.info("getInterLocationDigitStrip======>" +getInterLocationDigitStrip());
			
			//IR#1446734 0 in "Digits after Location Identifier" and "digits To Strip " 
			if(getInterLocationDigitStrip() > 0){
				prDbBean.setInterLocationDigitsStrip(getInterLocationDigitStrip());
			}else{
				prDbBean.setInterLocationDigitsStrip(0);
			}

	        	if (getEnvOrderId() > 0) {
	        		prDbBean.setEnvOrderId(getEnvOrderId());
	        	}
			else
	        		prDbBean.setEnvOrderIdNull();

			if(getModifiedBy() != null &&
			    !( "".equalsIgnoreCase(getModifiedBy()) ) )
				prDbBean.setModifiedBy(getModifiedBy());
            		else
            			prDbBean.setModifiedBy("ESAP_INV");
			prDbBean.setLastModifiedDate(new Timestamp(System.currentTimeMillis()));
                        prDbBean.wherePrefixRoutingIdEQ(getPrefixId());

			if ( prDbBean.updateSpByWhere(dbCon) <= 0 ){
				return false;
			}
		/*}
		catch(SQLException s)
		{
			s.printStackTrace();	
			setStatus(InvErrorCode.DB_EXCEPTION);
			log.info("DB_FAILURE in updatePrefixRouting");
			return false;
		}*/
		setStatus(InvErrorCode.SUCCESS);
		return true;
	}

	public boolean deletePrefixRouting() throws SQLException, Exception{

		log.info("Entering deletePrefixRouting()");
//		try{
			if(getPrefixId() <= 0)
			{
				setStatus(InvErrorCode.INTERNAL_ERROR);
				return false;
			}

			DBTblPrefixRouting prefixRoutingDbBean = new DBTblPrefixRouting();
			prefixRoutingDbBean.wherePrefixRoutingIdEQ(getPrefixId());
			prefixRoutingDbBean.deleteByWhere(dbCon);
		/*}
		catch(SQLException e){
			e.printStackTrace();
			setStatus(InvErrorCode.DB_EXCEPTION);
			return false;
		}*/
		setStatus(InvErrorCode.SUCCESS);
		return true;

	}


}
