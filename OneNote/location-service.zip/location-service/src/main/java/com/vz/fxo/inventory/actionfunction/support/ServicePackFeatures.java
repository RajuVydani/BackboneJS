package com.vz.fxo.inventory.actionfunction.support;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Timestamp;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import esap.db.DBTblAuthServices;
import esap.db.DBTblPolicies;
import esap.db.DBTblPoliciesService;
import esap.db.DBTblServicepack;
import esap.db.DBTblServicepackService;
import esap.db.DBTblVzbFeatures;
import esap.db.TblAuthServicesQuery;
import esap.db.TblPoliciesDbBean;
import esap.db.TblPoliciesQuery;
import esap.db.TblPoliciesServiceQuery;
import esap.db.TblServicepackDbBean;
import esap.db.TblServicepackQuery;
import esap.db.TblServicepackServiceQuery;
import esap.db.TblVzbFeaturesDbBean;
import esap.db.TblVzbFeaturesQuery;

public class ServicePackFeatures extends ServicePackFeaturesBean
{
	private static Logger log = LoggerFactory.getLogger(ServicePackFeatures.class.toString());
	
	Connection dbCon;
    String statusDesc;
    InvErrorCode statusCode = InvErrorCode.INTERNAL_ERROR;

	public int getStatusCode() {
		return statusCode.getErrorCode();
	}
	public void setStatusCode(InvErrorCode statusCode) {
		this.statusCode = statusCode;
	}
    public String getStatusDesc()
    {
        return statusDesc;
    }

    public void setStatusDesc(String statusDesc)
    {
        this.statusDesc = statusDesc;
    }

    public Connection getDbCon()
    {
        return dbCon;
    }

    public void setDbCon(Connection dbCon)
    {
        this.dbCon = dbCon;
    }

    public ServicePackFeatures(Connection dbCon)
    {
        this.dbCon = dbCon;
    }

    public ServicePackFeatures(ServicePackFeaturesBean featsBean, Connection dbCon)
    {
        super(featsBean);
        this.dbCon = dbCon;
    }

	public boolean addServicePackServices()
	{
		log.info("Entering Features : addAuthServices()");
		try
		{
			DBTblServicepackService servicepackServiceDbBean = new DBTblServicepackService();
			servicepackServiceDbBean.setServicepackServiceId(getServicepackServiceId());
			log.info("ServicepackServiceId is {}" , getServicepackServiceId());
			servicepackServiceDbBean.setServicepackId(getServicePackFeaturesDbBean().getServicepackId());
			
               if(getEnvOrderId() > 0)
            	   servicepackServiceDbBean.setEnvOrderId((int)getEnvOrderId());	
		//	else
			//	servicepackServiceDbBean.setEnvOrderId();	
            if(getCreatedBy() != null && !getCreatedBy().equals("") )
            	servicepackServiceDbBean.setCreatedBy(getCreatedBy());
			else
				servicepackServiceDbBean.setCreatedBy("ESAP_INV");
			if(getModifiedBy() != null && !getModifiedBy().equals(""))
				servicepackServiceDbBean.setModifiedBy(getModifiedBy());
			else
				servicepackServiceDbBean.setModifiedBy("ESAP_INV");

			servicepackServiceDbBean.setCreationDate(new Timestamp(System.currentTimeMillis()));
			servicepackServiceDbBean.setLastModifiedDate(new Timestamp(System.currentTimeMillis()));

            log.info("ServicepackId is {}" , servicepackServiceDbBean.getServicepackId());

            servicepackServiceDbBean.insert(dbCon);
		}
		catch(SQLException s)
		{
			s.printStackTrace();
			setStatusCode(InvErrorCode.DB_EXCEPTION);
			setStatusDesc("DB_FAILURE in addServicePackServices");
			log.info("DB_FAILURE in addServicePackServices");
			return false;
		}
		setStatusCode(InvErrorCode.SUCCESS);
		setStatusDesc("Successfully inserted addServicePackServices");
		return true;
	}

    public boolean getServicePackFeatureByNameAndType(String name, String type)
    {
    	log.info("Entering ServicePackFeatures : getServicePackFeatureByNameAndType(), arg= {}, {}",name,type);
        try
        {
        	TblServicepackQuery servicePackQry = new TblServicepackQuery();
            String whereClause = " where servicepack_name='"+name+"' and type='"+type+"'";
            servicePackQry.queryByWhere(dbCon, whereClause);

            if (servicePackQry.size() <= 0)
            {
                setStatusCode(InvErrorCode.NOTFOUND_VZB_FEATURE);
                log.info("ServicePackFeature not Found in Tbl_servicepack with matching the inputs");
                return false;
            }

            TblServicepackDbBean servicepackFeatBean = servicePackQry.getDbBean(0);

            servicePackFeaturesDbBean.setStatus(servicepackFeatBean.getStatus());
            servicePackFeaturesDbBean.setDescription(servicepackFeatBean.getDescription());
            servicePackFeaturesDbBean.setServicepackName(servicepackFeatBean.getServicepackName());
            servicePackFeaturesDbBean.setServicepackId(servicepackFeatBean.getServicepackId());
        }
        catch (SQLException e)
        {
            e.printStackTrace();
            setStatusCode(InvErrorCode.DB_EXCEPTION);
            setStatusDesc("DB_FAILURE in getServicePackFeatureByNameAndType");
            return false;
        }
        catch (Exception e)
        {
            e.printStackTrace();
            setStatusCode(InvErrorCode.DB_EXCEPTION);
            setStatusDesc("FAILURE in getServicePackFeatureByNameAndType");
            return false;
        }

        setStatusCode(InvErrorCode.SUCCESS);
        setStatusDesc("Successfully retrieved getServicePackFeatureByNameAndType");
        return true;
    }

    //EnterpriseId will be set before calling this method.
    /*public boolean getFeatureByEnterpriseId()
    {
        try
        {
            TblVzbFeaturesQuery featQry = new TblVzbFeaturesQuery();

            featQry.query(dbCon);
            if (featQry.size() <= 0)
            {
                LogUtil.info("Feature Id not Found");
            }
            TblVzbFeaturesDbBean featBean = featQry.getDbBean(0);

            setLastModifiedDate(featBean.getLastModifiedDate());
            // setBroadsoftHidden(featBean.getIsBroadsoftHidden());//TODO getIsBroadsoftHidden is undefined for type TblVzbFeaturesDbBean
            setModifiedBy(featBean.getModifiedBy());
            setFeatureType(featBean.getFeatureType());
            setFeatureId(featBean.getFeatureId());
              if(featBean.getIsBillable() == 1)
            	  setIsBillable(true);
              else
            	  setIsBillable(false);
              if(featBean.getIsAuthorized() == 1)
            	  setIsAuthorized(true);
              else
            	  setIsAuthorized(false);
            setIcpId(featBean.getIcpId());
            setIasaId(featBean.getIasaId());
            setPlatformIndicator(featBean.getPlatformIndicator());
            setDescription(featBean.getDescription());
            setName(featBean.getName());

        }
        catch (SQLException e)
        {
            e.printStackTrace();
            setStatusCode(InvErrorCode.DB_EXCEPTION);
            setStatusDesc("DB_FAILURE in getFeatureByEnterpriseId");
            return false;
        }
        catch (Exception e)
        {
            e.printStackTrace();
            setStatusCode(InvErrorCode.DB_EXCEPTION);
            setStatusDesc("FAILURE in getFeatureByEnterpriseId");
            return false;
        }

        setStatusCode(InvErrorCode.SUCCESS);
        setStatusDesc("Successfully retrieved feature");
        return true;
    }*/

    public boolean deleteServicePackServices() throws SQLException, Exception
	{
    	log.info("Entering ::deleteServicePackServices");

	//	try
	//	{
			if(getServicepackServiceId() <= 0)
                        {
                        setStatusCode(InvErrorCode.INVALID_INPUT);
                        return false;
                        }

			DBTblServicepackService servicepackServiceDbBean = new DBTblServicepackService();
			servicepackServiceDbBean.whereServicepackServiceIdEQ(getServicepackServiceId());
			servicepackServiceDbBean.deleteByWhere(dbCon);
		/*}
		catch (SQLException s)
		{
			s.printStackTrace();
			setStatusCode(InvErrorCode.DB_EXCEPTION);
			setStatusDesc("DB_FAILURE in delete policyServiceDbBean");
			return false;
		}*/
		setStatusCode(InvErrorCode.SUCCESS);
		setStatusDesc("Successfully deleted policyService ");
		return true;
	}

    public boolean updateServicePackServices()
	{
		try
		{
			if(getServicepackServiceId() <= 0){
				setStatusCode(InvErrorCode.INTERNAL_ERROR);
				log.info("FAILURE in updatePolicyServices. PolicyServiceId missing.");
				return false;
			}
			DBTblServicepackService servicepackServiceDbBean = getServicePackServicesToUpdate();
			servicepackServiceDbBean.whereServicepackServiceIdEQ(getServicepackServiceId());
            if(servicepackServiceDbBean.updateSpByWhere(dbCon) <= 0)
				return false; 

		} catch(SQLException s) {
            		s.printStackTrace();
			setStatusCode(InvErrorCode.DB_EXCEPTION);
			log.info("DB_FAILURE in updateAuthServices");
			return false;
		}
		setStatusCode(InvErrorCode.SUCCESS);
		setStatusDesc("Successfully update AuthServices");
		return true;
	}
        private DBTblServicepackService getServicePackServicesToUpdate() throws SQLException {
        	DBTblServicepackService servicepackServiceDbBean = new DBTblServicepackService();
        	ServicePackFeaturesBean defaultServicePackFeatureBean = new ServicePackFeaturesBean();


		ServicePackFeatures inputFeatures = this;

		/*Set the new fields if required.*/

		servicepackServiceDbBean.setServicepackServiceId(getServicepackServiceId());

		if((inputFeatures.getServicePackFeaturesDbBean()).getServicepackId() != (defaultServicePackFeatureBean.getServicePackFeaturesDbBean()).getServicepackId()){
			servicepackServiceDbBean.setServicepackId((long)inputFeatures.getServicePackFeaturesDbBean().getServicepackId());
		}

	
        if(inputFeatures.getEnvOrderId() != defaultServicePackFeatureBean.getEnvOrderId()){
        	servicepackServiceDbBean.setEnvOrderId((int)inputFeatures.getEnvOrderId());
		} 
		if(inputFeatures.getModifiedBy() != null &&
				!( "".equalsIgnoreCase(inputFeatures.getModifiedBy()) ))
			servicepackServiceDbBean.setModifiedBy(getModifiedBy());
		else
			servicepackServiceDbBean.setModifiedBy("ESAP_INV");

		servicepackServiceDbBean.setLastModifiedDate(new Timestamp(System.currentTimeMillis()));
		return servicepackServiceDbBean;
	}

	public boolean getServicePackServicesDetails() throws SQLException
	{
		try
		{
			log.info("In  ServicePackServicesDetails; ServicepackServiceId ="+getServicepackServiceId());
			TblServicepackServiceQuery servicePackServiceQry = new TblServicepackServiceQuery();
			String whereClause = " where servicepack_service_id = \'"+getServicepackServiceId()+"\'";
			servicePackServiceQry.queryByWhere(dbCon, whereClause);
			if(servicePackServiceQry.size() == 1){

				setServicepackServiceId((servicePackServiceQry.getDbBean(0)).getServicepackServiceId());				
				TblServicepackQuery  servicePackQuery = new TblServicepackQuery();
				servicePackQuery.whereServicepackIdEQ((int)(servicePackServiceQry.getDbBean(0)).getServicepackId());
				servicePackQuery.query(dbCon);
				if(servicePackQuery.size() >  0)
				{
					DBTblServicepack vzbFeatDbBean = new DBTblServicepack();
					vzbFeatDbBean.copyFromBean(servicePackQuery.getDbBean(0));
					setServicePackFeaturesDbBean(vzbFeatDbBean);
				}
			
	             setEnvOrderId((servicePackServiceQry.getDbBean(0)).getEnvOrderId());		
                 setCreatedBy((servicePackServiceQry.getDbBean(0)).getCreatedBy());
				setModifiedBy((servicePackServiceQry.getDbBean(0)).getModifiedBy());

			}else
			{
				setStatusCode(InvErrorCode.DB_EXCEPTION);
				setStatusDesc("FAILURE in getServicePackServicesDetails .Couldn't find any entry with the given PolicyServiceId");
				return false;
			}
		}catch(SQLException s)
		{
            		s.printStackTrace();
			setStatusCode(InvErrorCode.DB_EXCEPTION);
			setStatusDesc("DB_FAILURE in getServicePackServicesDetails");
			return false;
		}
		setStatusCode(InvErrorCode.SUCCESS);
		setStatusDesc("Successfully retrieved getServicePackServicesDetails from db");
		return true;
	}

}
