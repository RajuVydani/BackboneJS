package com.vz.fxo.inventory.actionfunction.support;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import esap.db.DBTblDialPlan;
import esap.db.DBTblSipDomain;
import esap.db.DBTblTerminatingRouting;
import esap.db.TblDialPlanQuery;
import esap.db.TblSipDomainQuery;
import esap.db.TblTerminatingRoutingQuery;
public class DialPlan extends DialPlanBean
{
	
	private static Logger log = LoggerFactory.getLogger(DialPlan.class.toString());
	Connection dbCon;
	InvErrorCode status = InvErrorCode.INTERNAL_ERROR;
	boolean rollbackFlag;
	boolean migration;

	public int getStatusCode() {
		return status.getErrorCode();
	}
	public void setStatus(InvErrorCode status) {
		this.status = status;
	}
	public String getStatusDesc() {
		return status.getErrorDesc();
	}
	public Connection getDbCon() {
		return dbCon;
	}
	public void setDbCon(Connection dbCon) {
		this.dbCon = dbCon;
	}
	public DialPlan(Connection dbCon)
	{
		this.dbCon = dbCon;
		this.rollbackFlag = false;
	}
	public DialPlan(DialPlanBean dialPlanBean, Connection dbCon)
	{
		super(dialPlanBean);
		this.dbCon = dbCon;
		this.rollbackFlag = false;
		this.migration = false;
	}
	public boolean getRollbackFlag()
    	{
        	return rollbackFlag;
    	}
                                                                                
    	public void setRollbackFlag(boolean rollbackFlag)
    	{
        	this.rollbackFlag = rollbackFlag;
    	}
	public boolean getMigration()
        {
                return migration;
        }

        public void setMigration(boolean migration)
        {
                this.migration = migration;
        }
	public boolean addDialPlan() throws SQLException, Exception
	{
	//	try
	//	{
			DBTblDialPlan dpDbBean = new DBTblDialPlan();
			//set dial plan db bean attributes
			int dpSeqId = dpDbBean.getDialPlanIdSeqNextVal(dbCon);            			
			setDialPlanId(dpSeqId);
			if(!"NONE".equals(getEnterpriseId()) && !"".equals(getEnterpriseId()))
				dpDbBean.setEnterpriseId(getEnterpriseId());
			if(getDefaultFlag() == 1)
			{
			TblDialPlanQuery dialPlanQry = new TblDialPlanQuery();
			dialPlanQry.whereEnterpriseIdEQ(getEnterpriseId());
			dialPlanQry.whereDefaultFlagEQ(1);
			dialPlanQry.query(dbCon);
			if(dialPlanQry.size() > 0)
			{
				DBTblDialPlan dpUpdDbBean = new DBTblDialPlan();
				dpUpdDbBean.whereEnterpriseIdEQ(getEnterpriseId());
				dpUpdDbBean.whereDefaultFlagEQ(1);
				dpUpdDbBean.setDefaultFlag(0);
				int updatedRows = dpUpdDbBean.updateSpByWhere(dbCon);
				log.info("In Dial Plan add, number of dial plans made non default:"+updatedRows);
			}
			} 
			dpDbBean.setDialPlanName(getDialPlanName());
			dpDbBean.setDefaultFlag(getDefaultFlag());
			dpDbBean.setEmergencyIndicator(getEmergencyIndicator());
			dpDbBean.setTermntind(getTermntind());
			dpDbBean.setPresacceptstatus(getPresacceptstatus());
			dpDbBean.setPresscreenstatus(getPresscreenstatus());
			dpDbBean.setPresscreenlist(getPresscreenlist());
			dpDbBean.setOrigcallregstat(getOrigcallregstat());
			dpDbBean.setNumconreg(getNumconreg());
			dpDbBean.setRegtimeext(getRegtimeext());
			dpDbBean.setLocalDaStat(getLocalDaStat());
			if(getPublicNetwGw() != -1)
				dpDbBean.setPublicNetwGw(getPublicNetwGw());
			if(getPublicDefaultGw() != -1)
				dpDbBean.setPublicDefaultGw(getPublicDefaultGw());
			if(getBlockAllCall() != -1)
				dpDbBean.setBlockAllCall(getBlockAllCall());
			dpDbBean.setOnNetStat(getOnNetStat());
			if(migration) {
				if(!"NONE".equals(getBillingno()) && !"".equals(getBillingno()))
					dpDbBean.setBillingno(getBillingno());
			} else
			{
				String strDpid = "3" + Long.toString(dpSeqId);
				dpDbBean.setBillingno(strDpid);
			}
			dpDbBean.setOcsstat(getOcsstat());
			dpDbBean.setOcs(getOcs());
			dpDbBean.setEnumStat(getEnumStat());
			if(!"NONE".equals(getPrimaryEnumDomain()) && !"".equals(getPrimaryEnumDomain()))
				dpDbBean.setPrimaryEnumDomain(getPrimaryEnumDomain());
			if(!"NONE".equals(getAltEnumDomain()) && !"".equals(getAltEnumDomain()))
				dpDbBean.setAltEnumDomain(getAltEnumDomain());
			dpDbBean.setMaxenterprise(getMaxenterprise());
			dpDbBean.setActiveInd(getActiveInd());
			if(iasaDialPlanId != -1 )
				dpDbBean.setIasaDialPlanId(getIasaDialPlanId());

			log.info("EnvOrderId = <" + getEnvOrderId() + ">");
    	    		if(getEnvOrderId()!= -1)
    	    			dpDbBean.setEnvOrderId(getEnvOrderId());
    	    		//else
    	    		//	dpDbBean.setEnvOrderIdNull();

			if(getLiInd() > -1)
				dpDbBean.setLiInd((short) getLiInd());

			if(getApacInd() > -1)
                dpDbBean.setApacInd((short) getApacInd());

			//if(getOldOnNetStat() > -1)
			//	dpDbBean.setOldOnNetStat(getOldOnNetStat());
			// for newly added dialplan oldOnNetStat should be set to -1 by default.
			dpDbBean.setOldOnNetStat((short)(-1));

			if(getEnumistat() > -1)
				dpDbBean.setEnumistat(getEnumistat());



			//dpDbBean.setCreatedBy(getCreatedBy());
			//dpDbBean.setModifiedBy(getModifiedBy());
			if (createdBy != null && !"".equals(createdBy))
				dpDbBean.setCreatedBy(createdBy);
			else
				dpDbBean.setCreatedBy("ESAP_INV");
			if (modifiedBy != null && !"".equals(modifiedBy))
				dpDbBean.setModifiedBy(modifiedBy);
			else
				dpDbBean.setModifiedBy("ESAP_INV");
			dpDbBean.setLastModifiedDate(new Timestamp(System.currentTimeMillis()));
			dpDbBean.setCreationDate(new Timestamp(System.currentTimeMillis()));
			
			dpDbBean.insert(dbCon);
		/*}
		catch(SQLException s)
		{
			setStatus(InvErrorCode.DB_EXCEPTION);
			//setStatusDesc("DB_FAILURE in addDialPlan");
			s.printStackTrace();
			log.info("DB_FAILURE in addDialPlan");
			return false;
		}*/
		setStatus(InvErrorCode.SUCCESS);
		//setStatusDesc("Successfully inserted Dial Plan");
		return true;
	}
	public boolean deleteDialPlan() throws SQLException, Exception
	{
	//	try
	//	{
			if(getDialPlanId() <= 0)
                        {
                        setStatus(InvErrorCode.INVALID_INPUT);
                        return false;
                        }

			log.info("In deleteDialPlan");
			DBTblSipDomain sipDomainBean = new DBTblSipDomain();
			sipDomainBean.whereDialPlanIdEQ(getDialPlanId());
			int sipDomainsDeleted = sipDomainBean.deleteByWhere(dbCon);
			log.info("Number of sipDomains deleted:"+sipDomainsDeleted);
			DBTblTerminatingRouting termRoutingBean = new DBTblTerminatingRouting();
			termRoutingBean.whereDialPlanIdEQ(getDialPlanId());
			int termRoutingDeleted = termRoutingBean.deleteByWhere(dbCon);
			log.info("Number of termRoutingDeleted deleted:"+termRoutingDeleted);
			DBTblDialPlan dialPlanBean = new DBTblDialPlan();
			dialPlanBean.whereDialPlanIdEQ(getDialPlanId());
			//if(rollbackFlag)
			//{
				int dialPlansDeleted = dialPlanBean.deleteByWhere(dbCon);
				log.info("Number of dialPlans deleted:"+dialPlansDeleted);
			/*}
			else
			{
				dialPlanBean.setActiveInd(0);
				dialPlanBean.updateSpByWhere(dbCon);
			}*/
			
		/*}
		catch(SQLException s)
		{
			setStatus(InvErrorCode.DB_EXCEPTION);
			s.printStackTrace();
			//setStatusDesc("DB_FAILURE in deleteDialPlan");
			log.info("DB_FAILURE in deleteDialPlan");
			return false;
		}*/
		setStatus(InvErrorCode.SUCCESS);
		//setStatusDesc("Successfully deleted dial plan");
		return true;
	}
         public boolean modifyInDB() throws SQLException, Exception {
		//try {
			if (dialPlanId < 0) {
				setStatus(InvErrorCode.INTERNAL_ERROR);
				//setStatusDesc("FAILURE in modifyInDB Enterprise. enterprise Id missing.");
				log.info("FAILURE in modifyInDB Enterprise. enterprise Id missing.");
				return false;
			}
			DBTblDialPlan dialPlanDbBean = getDilaPlanToUpdate();
			dialPlanDbBean.whereDialPlanIdEQ(dialPlanId);

			if ( dialPlanDbBean.updateSpByWhere(dbCon) <= 0 ){
				return false;
			}
		
		/*} catch (SQLException s) {
			s.printStackTrace();
			setStatus(InvErrorCode.DB_EXCEPTION);
			//setStatusDesc("DB_FAILURE in modifyInDB Enterprise");
			log.info("DB_FAILURE in modifyInDB Enterprise");
			return false;
		}*/
		setStatus(InvErrorCode.SUCCESS);
		//setStatusDesc("Successfully UPDATED Location into the DB");
		return true;
	}
	
	private DBTblDialPlan getDilaPlanToUpdate() throws SQLException{
		DBTblDialPlan dialPlanDbBean = new DBTblDialPlan();
		/*
		 * Create a new instance of DialPlanBean. The new instance would hold
		 * default values for the all the DialPlan fields.
		 */
		DialPlanBean defDialPlanBean = new DialPlanBean();

		DialPlan inputDialPlan = this;
		dialPlanDbBean.setDialPlanId(dialPlanId);

		if (inputDialPlan.getEnterpriseId() != null && !inputDialPlan.getEnterpriseId().equals(defDialPlanBean.getEnterpriseId())) {
			if(! "".equals(inputDialPlan.getEnterpriseId()))
				dialPlanDbBean.setEnterpriseId(inputDialPlan.getEnterpriseId());
			else
				dialPlanDbBean.setEnterpriseIdNull();	
		}

		if (inputDialPlan.getDialPlanName() != null 
				&& !inputDialPlan.getDialPlanName().equals(defDialPlanBean.getDialPlanName())) {
			dialPlanDbBean.setDialPlanName(inputDialPlan.getDialPlanName());
		}

		if (inputDialPlan.getDefaultFlag() != defDialPlanBean.getDefaultFlag()) {
	
			if(inputDialPlan.getDefaultFlag() == 1)
			{
			TblDialPlanQuery dialPlanQry = new TblDialPlanQuery();
			dialPlanQry.whereEnterpriseIdEQ(getEnterpriseId());
			dialPlanQry.whereDefaultFlagEQ(1);
			dialPlanQry.query(dbCon);
			if(dialPlanQry.size() > 0)
			{
				DBTblDialPlan dpUpdDbBean = new DBTblDialPlan();
				dpUpdDbBean.whereEnterpriseIdEQ(getEnterpriseId());
				dpUpdDbBean.whereDefaultFlagEQ(1);
				dpUpdDbBean.setDefaultFlag(0);
				int updatedRows = dpUpdDbBean.updateSpByWhere(dbCon);
				log.info("In Dial Plan add, number of dial plans made non default:"+updatedRows);
			}
			} 
			dialPlanDbBean.setDefaultFlag(inputDialPlan.getDefaultFlag());
		}

		if (inputDialPlan.getEmergencyIndicator() != defDialPlanBean.getEmergencyIndicator()) {
			dialPlanDbBean.setEmergencyIndicator(inputDialPlan.getEmergencyIndicator());
		}

		if (inputDialPlan.getTermntind() != defDialPlanBean.getTermntind()) {
			dialPlanDbBean.setTermntind(inputDialPlan.getTermntind());
		}
		if (inputDialPlan.getIasaDialPlanId() != defDialPlanBean.getIasaDialPlanId()) {
				if(getIasaDialPlanId() >0 )
                        dialPlanDbBean.setIasaDialPlanId(inputDialPlan.getIasaDialPlanId());
                else
                	dialPlanDbBean.setIasaDialPlanIdNull();
		}	

		if (inputDialPlan.getPresacceptstatus() != defDialPlanBean.getPresacceptstatus()) {
			dialPlanDbBean.setPresacceptstatus(inputDialPlan.getPresacceptstatus());
		}

		if (inputDialPlan.getPresscreenstatus() != defDialPlanBean.getPresscreenstatus()) {
			dialPlanDbBean.setPresscreenstatus(inputDialPlan.getPresscreenstatus());
		}

		if (inputDialPlan.getPresscreenlist() != defDialPlanBean.getPresscreenlist()) {
			dialPlanDbBean.setPresscreenlist(inputDialPlan.getPresscreenlist());
		}

		if (inputDialPlan.getOrigcallregstat() != defDialPlanBean.getOrigcallregstat()) {
			dialPlanDbBean.setOrigcallregstat(inputDialPlan.getOrigcallregstat());
		}

		if (inputDialPlan.getNumconreg() != defDialPlanBean.getNumconreg()) {
			dialPlanDbBean.setNumconreg(inputDialPlan.getNumconreg());
		}

		if (inputDialPlan.getRegtimeext() != defDialPlanBean.getRegtimeext()) {
			dialPlanDbBean.setRegtimeext(inputDialPlan.getRegtimeext());
		}

		if (inputDialPlan.getLocalDaStat() != defDialPlanBean.getLocalDaStat()) {
			dialPlanDbBean.setLocalDaStat(inputDialPlan.getLocalDaStat());
		}

		if (inputDialPlan.getPublicNetwGw() != defDialPlanBean.getPublicNetwGw()) {
			if( inputDialPlan.getPublicNetwGw() > 0 )
				dialPlanDbBean.setPublicNetwGw(inputDialPlan.getPublicNetwGw());
			else
				dialPlanDbBean.setPublicNetwGwNull();
		}

		if (inputDialPlan.getPublicDefaultGw() != defDialPlanBean.getPublicDefaultGw()) {
			dialPlanDbBean.setPublicDefaultGw(inputDialPlan.getPublicDefaultGw());
		}

		if (inputDialPlan.getBlockAllCall() != defDialPlanBean.getBlockAllCall()) {
			dialPlanDbBean.setBlockAllCall(inputDialPlan.getBlockAllCall());
		}

		if (inputDialPlan.getOnNetStat() != defDialPlanBean.getOnNetStat()) {
			dialPlanDbBean.setOnNetStat(inputDialPlan.getOnNetStat());
		}

		if (inputDialPlan.getBillingno() != null && !inputDialPlan.getBillingno().equals(defDialPlanBean.getBillingno())) {
			if(! "".equals(inputDialPlan.getBillingno()))
				dialPlanDbBean.setBillingno(inputDialPlan.getBillingno());
			else
				dialPlanDbBean.setBillingnoNull();
		}

		if (inputDialPlan.getOcsstat() != defDialPlanBean.getOcsstat()) {
			dialPlanDbBean.setOcsstat(inputDialPlan.getOcsstat());
		}

		if (inputDialPlan.getOcs() != defDialPlanBean.getOcs()) {
			dialPlanDbBean.setOcs(inputDialPlan.getOcs());
		}

		if (inputDialPlan.getEnumStat() != defDialPlanBean.getEnumStat()) {
			dialPlanDbBean.setEnumStat(inputDialPlan.getEnumStat());
		}

		if (inputDialPlan.getPrimaryEnumDomain() != null && !inputDialPlan.getPrimaryEnumDomain().equals(defDialPlanBean.getPrimaryEnumDomain())) {
			if(! "".equals(inputDialPlan.getPrimaryEnumDomain()))
				dialPlanDbBean.setPrimaryEnumDomain(inputDialPlan.getPrimaryEnumDomain());
			else
				dialPlanDbBean.setPrimaryEnumDomainNull();
		}

		if (inputDialPlan.getAltEnumDomain() != null && !inputDialPlan.getAltEnumDomain().equals(defDialPlanBean.getAltEnumDomain())) {
			if(! "".equals(inputDialPlan.getAltEnumDomain()))
				dialPlanDbBean.setAltEnumDomain(inputDialPlan.getAltEnumDomain());
			else
				dialPlanDbBean.setAltEnumDomainNull();
		}

		if (inputDialPlan.getMaxenterprise() != defDialPlanBean.getMaxenterprise()) {
			dialPlanDbBean.setMaxenterprise(inputDialPlan.getMaxenterprise());
		}

		if (inputDialPlan.getActiveInd() != defDialPlanBean.getActiveInd()) {
			dialPlanDbBean.setActiveInd(inputDialPlan.getActiveInd());
		}

        if (inputDialPlan.getEnvOrderId() != defDialPlanBean.getEnvOrderId()) {
        	if(inputDialPlan.getEnvOrderId() >0 )
        		dialPlanDbBean.setEnvOrderId(inputDialPlan.getEnvOrderId());
        	else
        		dialPlanDbBean.setEnvOrderIdNull();
        }

		if (inputDialPlan.getLiInd() != defDialPlanBean.getLiInd()) 
        	dialPlanDbBean.setLiInd((short) inputDialPlan.getLiInd());

		if (inputDialPlan.getApacInd() != defDialPlanBean.getApacInd())
            dialPlanDbBean.setApacInd((short) inputDialPlan.getApacInd());

		// OldOnNetStat is an internal field and will only be updated by IASA_ONNET_UDPATE AF.
		//if (inputDialPlan.getOldOnNetStat() != defDialPlanBean.getOldOnNetStat())
        //	dialPlanDbBean.setOldOnNetStat(inputDialPlan.getOldOnNetStat());
	
		if (inputDialPlan.getEnumistat() != defDialPlanBean.getEnumistat()) 
        	dialPlanDbBean.setEnumistat(inputDialPlan.getEnumistat());

		if (inputDialPlan.getModifiedBy() != null
				&& !("".equalsIgnoreCase(inputDialPlan.getModifiedBy())))
			dialPlanDbBean.setModifiedBy(inputDialPlan.getModifiedBy());
		else
			dialPlanDbBean.setModifiedBy("ESAP_INV");
		dialPlanDbBean.setLastModifiedDate(new Timestamp(System.currentTimeMillis()));
		
		return dialPlanDbBean;
	}

	// dialPlanId will be set before calling this method.
	public boolean getDialPlanByDialPlanId() {
		try {
			TblDialPlanQuery dpQry = new TblDialPlanQuery();
			initilizeTODefault();
			// populate dial plan bean from inventory
			log.info("before dpQry");
			//dpQry.whereDialPlanIdEQ(dialPlanId);
			//dpQry.query(dbCon);
			String whereClause = new String("");
			if(getAll == false)
				whereClause = " where dial_plan_id = " + dialPlanId +" and active_ind = 1";
			else
				whereClause = " where dial_plan_id = " + dialPlanId +" and active_ind != 0";

			log.info("Before entQry in getDetails");
			dpQry.queryByWhere(dbCon, whereClause);
			
			log.info("after dpQry");
			if (dpQry.size() == 1) {
		      	    ((DialPlanBean)this).copyFrom(dpQry.getDbBean(0));
			}else {
				return false;
			}
		} catch (SQLException e) {
			setStatus(InvErrorCode.DB_EXCEPTION);
			 e.printStackTrace();
			//setStatusDesc("DB_FAILURE in getDialPlanByDialPlanId");
			return false;
		} catch (Exception e) {
			setStatus(InvErrorCode.NOTFOUND_DIAL_PLAN);
			e.printStackTrace();
			//setStatusDesc("FAILURE in getDialPlanByDialPlanId");
			return false;
		}
		setStatus(InvErrorCode.SUCCESS);
		//setStatusDesc("Successfully retrieved Dial plan");
		return true;
	}
	/**
	 * The method to get SIP Domains corresponding to the current Dial Plan.
	 * 
	 * Note: DialPlanId should be set before calling this method.
	 * 
	 * @return 	true		The SIP Domains retrieved successfully.
	 * 			false		The error occured while retrieving SIP Domains.
	 * 
	 * @author banala
	 */
	public boolean getSipDomains(){
		try {
			if (getDialPlanId() == 0) {
				setStatus(InvErrorCode.INTERNAL_ERROR);
				//setStatusDesc("INV_FAILURE in getSipDomains. Invalid Input");
				return false;
			} else {
				TblSipDomainQuery sipQry = new TblSipDomainQuery();
			//	sipQry.whereDialPlanIdEQ(getDialPlanId());
			//	sipQry.query(dbCon);
				log.info("before dpQry");
				String whereClause = " where dial_plan_id = " + dialPlanId;
				log.info("Before entQry in getDetails");
				sipQry.queryByWhere(dbCon, whereClause);	
	                        if (sipQry.size() > 0) {
					List<SipDomainBean> sipDomains = new ArrayList<SipDomainBean>();
					SipDomainBean sipDomainBean;
					for (int i = 0; i < sipQry.size(); i++) {
						sipDomainBean = new SipDomainBean();
						sipDomainBean.copyFrom(sipQry.getDbBean(i));
                          			sipDomains.add(sipDomainBean);
					}
					setSipDomainDbList(sipDomains);
				} else {
					return false;
				}
			}
		} catch (SQLException e) {
			setStatus(InvErrorCode.DB_EXCEPTION);
			 e.printStackTrace();
			//setStatusDesc("DB_FAILURE in getSipDomains");
			return false;
		} catch (Exception e) {
			setStatus(InvErrorCode.NO_SIP_DOMAIN_FOR_DIAL_PLAN);
			e.printStackTrace();
			//setStatusDesc("FAILURE in getSipDomains");
			return false;
		}
		setStatus(InvErrorCode.SUCCESS);
		//setStatusDesc("Successfully retrieved SipDomains for the Dial Plan Id"+ getDialPlanId());
		return true;
	}
	/**
	 * The method to get Terminating Routings corresponding to the current Dial Plan.
	 * 
	 * Note: DialPlanId should be set before calling this method.
	 * 
	 * @return 	true		The Terminating Routings retrieved successfully.
	 * 			false		The error occured while retrieving Terminating Routings.
	 * 
	 * @author banala
	 */
	public boolean getTerminatingRoutings(){
		try {
			if (getDialPlanId() == 0) {
				setStatus(InvErrorCode.INTERNAL_ERROR);
				//setStatusDesc("INV_FAILURE in getTerminatingRoutings. Invalid Input");
				return false;
			} else {
				TblTerminatingRoutingQuery trQry = new TblTerminatingRoutingQuery();
			//	trQry.whereDialPlanIdEQ(getDialPlanId());
			//	trQry.query(dbCon);
				log.info("before dpQry");
				String whereClause = " where dial_plan_id = " + dialPlanId;
				log.info("Before entQry in getDetails");
				trQry.queryByWhere(dbCon, whereClause);	
                                       if (trQry.size() > 0) {
					List<TerminatingRoutingBean> termRoutings = new ArrayList<TerminatingRoutingBean>();
					TerminatingRoutingBean terminatingRoutingBean;
					for (int i = 0; i < trQry.size(); i++) {
						terminatingRoutingBean = new TerminatingRoutingBean();
						terminatingRoutingBean.initilizeTODefault();
						terminatingRoutingBean.copyFrom(trQry.getDbBean(i));
						termRoutings.add(terminatingRoutingBean);
					}
					setTermRoutingDbList(termRoutings);
				} else {
					return false;
				}
			}
		} catch (SQLException e) {
			setStatus(InvErrorCode.DB_EXCEPTION);
			 e.printStackTrace();
			//setStatusDesc("DB_FAILURE in getTerminatingRoutings");
			return false;
		} catch (Exception e) {
			setStatus(InvErrorCode.NO_TERM_ROUTING_FOR_DIAL_PLAN);
			e.printStackTrace();
			//setStatusDesc("FAILURE in getTerminatingRoutings");
			return false;
		}
		setStatus(InvErrorCode.SUCCESS);
		//setStatusDesc("Successfully retrieved TerminatingRoutings for the Dial Plan Id"+ getDialPlanId());
		return true;
	}

	
}


