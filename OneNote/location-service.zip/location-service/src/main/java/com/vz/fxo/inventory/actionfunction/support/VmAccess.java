
package com.vz.fxo.inventory.actionfunction.support; 

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Timestamp;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

//import esap.vzbvoip.inventory.query.Criteria;
import esap.db.DBTblVmAccess;
import esap.db.TblVmAccessDbBean;
import esap.db.TblVmAccessQuery;
import esap.db.DBTblPublicTnPool;
import esap.db.TblPublicTnPoolQuery;
import EsapEnumPkg.VzbVoipEnum;

public class VmAccess extends VmAccessBean
{
	private static Logger log = LoggerFactory.getLogger(VmAccess.class.toString());
	
	//members
	private Connection connection;
	//private String statusCode;
	//private String statusDesc;
	
	public VmAccess(Connection con)
	{
		this.connection = con;
	}

	public VmAccess(VmAccessBean vmaBean, Connection con)
	{
		super(vmaBean);
		this.connection = con;
	}
	
	//getters - setters
	public Connection getConnection() {
		return connection;
	}

	public void setConnection(Connection connection) {
		this.connection = connection;
	}

	InvErrorCode status = InvErrorCode.INTERNAL_ERROR;
	public int getStatusCode() {
		return status.getErrorCode();
	}

	public void setStatus(InvErrorCode status) {
		this.status = status;
	}

	public String getStatusDesc() {
		return status.getErrorDesc();
	}


	public boolean addVmAccess() throws SQLException, Exception
	{
		log.info("Entering VmAccess::addVmAccess");
	
	//	try
     //   {
            DBTblVmAccess vmDB = new DBTblVmAccess();
            setVmAccessId(vmDB.getVmAccessIdSeqNextVal(connection));

            vmDB.setVmAccessId(getVmAccessId());
            vmDB.setEnterpriseId(enterpriseId);
            vmDB.setLocationId(locationId);
            vmDB.setSubId(subId);
            if(publicPoolId > 0 )
                vmDB.setPublicPoolId(publicPoolId);
            else
            {
                if (getPublicNumber() == null || (getPublicNumber().trim()).equalsIgnoreCase(""))
                {
                    log.info("InvalidInput for VMA. Failed to Add VM Access Public Tn");
                    setStatus(InvErrorCode.INVALID_PUBLIC_TN);
                    return false;
                }
                long poolId = addToPublicPool(getPublicNumber(),  VzbVoipEnum.TnStatus.ASSIGNED, VzbVoipEnum.TnType.VMA);
                if(poolId <= 0)
                {
                    log.info("Failed to Add VM Access Public Tn");
                    setStatus(InvErrorCode.ERROR_ADDING_PUBLIC_TN_TO_VMA);
                    return false;
                }
                vmDB.setPublicPoolId(poolId);
            }
            TblVmAccessQuery vmQry = new TblVmAccessQuery();
            String whereCls = " where public_pool_id = " + getPublicPoolId() + " and location_id = \'"+getLocationId()+"\'";
            log.info("whereCls in vmAccess.addToDb:whereCls:"+whereCls);
            vmQry.queryByWhere(connection,whereCls);
            if(vmQry.size() > 0)
            {
            	setStatus(InvErrorCode.VM_ALREADY_EXISTS);
                log.info("SUCCESS. VmAccess is already present in db with this public tn for this location"+getPublicPoolId());
                return true;
            }
            else
                log.info("VmAccess not present in db with this tn. Can be added to DB"+getPublicPoolId());
            vmDB.setPrivateNumber(privateNumber);
            vmDB.setNpaSplitStatus(npaSplitStatus);

            log.info("EnvOrderId = <" + getEnvOrderId() + ">");
            if(getEnvOrderId() > 0)
                vmDB.setEnvOrderId(getEnvOrderId());
            else
                vmDB.setEnvOrderIdNull();

            vmDB.setLastModifiedDate(new Timestamp(System.currentTimeMillis()));
            vmDB.setCreationDate(new Timestamp(System.currentTimeMillis()));
            if(getModifiedBy() != null  && !getModifiedBy().equals(""))
                vmDB.setModifiedBy(getModifiedBy());
            else
                vmDB.setModifiedBy("ESAP_INV");
            if(getCreatedBy() != null  && !getCreatedBy().equals(""))
                vmDB.setCreatedBy(getCreatedBy());
            else
                vmDB.setCreatedBy("ESAP_INV");
            vmDB.insert(connection);
      /*  }		
		catch(SQLException s)
		{
			setStatus(InvErrorCode.DB_EXCEPTION);
			s.printStackTrace();	
			return false;
		}*/
		return true;
	}
	
	public boolean getVmAccessDetailsByVmAccessId()
	{
		log.info("Entering VmAccess::getVmAccessDetailsByVmAccessId");
		
		try
		{
			TblVmAccessQuery vmQry = new TblVmAccessQuery();
			vmQry.whereVmAccessIdEQ(vmAccessId);
			vmQry.query(connection);
			if(vmQry.size() <= 0)
			{
				log.info("Vm Access Id not Found");
				return false;
			}
			TblVmAccessDbBean vmDbBean = vmQry.getDbBean(0);
			setEnterpriseId(vmDbBean.getEnterpriseId());
			setLocationId(vmDbBean.getLocationId());
			setSubId(vmDbBean.getSubId());
			setPublicPoolId(vmDbBean.getPublicPoolId());
			setPrivateNumber(vmDbBean.getPrivateNumber());
			setNpaSplitStatus(vmDbBean.getNpaSplitStatus());
			setCreatedBy(vmDbBean.getCreatedBy());
			setModifiedBy(vmDbBean.getModifiedBy());
			setCreationDate(vmDbBean.getCreationDate());
			setLastModifiedDate(vmDbBean.getLastModifiedDate());
			setEnvOrderId(vmDbBean.getEnvOrderId());
		}
		catch(SQLException e)
		{
			setStatus(InvErrorCode.DB_EXCEPTION);
			e.printStackTrace();	
			return false;
		}

		setStatus(InvErrorCode.SUCCESS);
		return true;
	}

	/**
	 * @Param deleteFromDB
	 * @description: Deletes the VmAccess from DB
	 * @return boolean
	 * @author Thejas
	 * @editedby
	 */
	public boolean deleteFromDB() throws Exception
	{
		try
		{

			if ( getVmAccessId() <= 0) 
			{
				if(getPublicNumber() == null || getPublicNumber().trim().equalsIgnoreCase("") || getLocationId() == null || getLocationId().trim().equalsIgnoreCase(""))
				{
					setStatus(InvErrorCode.INVALID_VM_PUBLIC_TN_LOCATION_ID);
         	log.info("FAILURE in deleteFromDB VmAccess. VmAccessId/Public Number/LocationId missing.");
                                	return false;
				}
				TblPublicTnPoolQuery pbTnQry = new TblPublicTnPoolQuery();
				//String whereCls = " where tn = "+getPublicNumber()+" and location_id = "+getLocationId();
				pbTnQry.whereTnEQ(getPublicNumber());
				pbTnQry.whereLocationIdEQ(getLocationId());
				pbTnQry.query(connection);
				if(pbTnQry.size() > 0)
        {
            setPublicPoolId(pbTnQry.getDbBean(0).getTnPoolId());
        }

				if(getPublicPoolId() > 0)
				{
					//whereCls = " where public_pool_id  = "+ getPublicPoolId()+" and location_id = "+getLocationId();
					TblVmAccessQuery vmQry = new TblVmAccessQuery();
					vmQry.wherePublicPoolIdEQ(getPublicPoolId());
					vmQry.whereLocationIdEQ(getLocationId());
					vmQry.query(connection);
					if(vmQry.size() > 0)
					{
						setVmAccessId(vmQry.getDbBean(0).getVmAccessId());
					}
					else
					{
				setStatus(InvErrorCode.DB_EXCEPTION);
         		log.info("FAILURE in deleteFromDB VmAccess. VmAccessId/Public Number/LocationId missing.");
         		return false;
					}
                        	}
				else
				{
					setStatus(InvErrorCode.INVALID_VM_PUBLIC_TN_LOCATION_ID);
          log.info("FAILURE in deleteFromDB VmAccess. VmAccessId/Public Number/LocationId missing.");
          return false;
				}
			}

			if(getPublicPoolId() <= 0)
			{
				TblVmAccessQuery vmQry = new TblVmAccessQuery();
				vmQry.whereVmAccessIdEQ(getVmAccessId());
				vmQry.query(connection);
				if(vmQry.size() > 0 )
				{
					setPublicPoolId(vmQry.getDbBean(0).getPublicPoolId());	
				}
			}

			DBTblVmAccess vmAccessDbBean = new DBTblVmAccess();
			vmAccessDbBean.whereVmAccessIdEQ(getVmAccessId());
			vmAccessDbBean.deleteByWhere(connection);	

			if(getPublicPoolId() > 0)
			{
				DBTblPublicTnPool tnDb = new DBTblPublicTnPool();
				tnDb.whereTnPoolIdEQ((int)getPublicPoolId());
				tnDb.setTnStatus(VzbVoipEnum.TnStatus.AVAILABLE);
				tnDb.setTnType(VzbVoipEnum.TnType.RES);
				FkValidationUtil.isValidPublicTNPoolForMod(connection,tnDb);
				tnDb.updateSpByWhere(connection);
				log.info("Updated Vm Tn to Available status");
			}
		} 
    catch(SQLException s) 
		{
    	    setStatus(InvErrorCode.DB_EXCEPTION);
			log.info("DB_FAILURE in deleteFromDB VmAccess:" + s.getMessage());
			s.printStackTrace();	
			return false;
		}
    setStatus(InvErrorCode.SUCCESS);
	
		return true;
	}

	/**
	 * The current VmAccess details are extracted using getDetails()
	 * and the new field values are updated over that. The method
	 * will update the fields that are supplied on the current instance
	 * if they are different from the default values for the respective field.
	 *
	 * @return The VmAccess to be updated.
	 */
	@SuppressWarnings("unused")
	private DBTblVmAccess getVmAccessToUpdate() {
		DBTblVmAccess vmAccessDbBean = new DBTblVmAccess();

		/* Create a new instance of VmAccessBean. The new instance
		 * would hold default values for the all the VmAccess fields.*/
		VmAccessBean defaultVmAccessBean = new VmAccessBean();

		VmAccess inputVmAccess = this;

		vmAccessDbBean.setVmAccessId(getVmAccessId());

		if ( inputVmAccess.getLocationId() != null &&
				!inputVmAccess.getLocationId().equals(defaultVmAccessBean.getLocationId()) ){
			vmAccessDbBean.setLocationId(inputVmAccess.getLocationId());
		}
		if ( inputVmAccess.getSubId() != null &&
				!inputVmAccess.getSubId().equals(defaultVmAccessBean.getSubId()) ){
			vmAccessDbBean.setSubId(inputVmAccess.getSubId());
		}

		if ( inputVmAccess.getEnterpriseId() != null &&
				!inputVmAccess.getEnterpriseId().equals(defaultVmAccessBean.getEnterpriseId()) ){
			vmAccessDbBean.setEnterpriseId(inputVmAccess.getEnterpriseId());
		}
		
		if ( inputVmAccess.getPrivateNumber() != null &&
				!inputVmAccess.getPrivateNumber().equals(defaultVmAccessBean.getPrivateNumber()) ){
			vmAccessDbBean.setPrivateNumber(inputVmAccess.getPrivateNumber());
		}
		
		if ( inputVmAccess.getPublicPoolId() != defaultVmAccessBean.getPublicPoolId()){
			vmAccessDbBean.setPublicPoolId(inputVmAccess.getPublicPoolId());
		}
		
		if ( inputVmAccess.getNpaSplitStatus() != defaultVmAccessBean.getNpaSplitStatus()){
			vmAccessDbBean.setNpaSplitStatus(inputVmAccess.getNpaSplitStatus());
		}

        	if (inputVmAccess.getEnvOrderId() != defaultVmAccessBean.getEnvOrderId()) {
        		vmAccessDbBean.setEnvOrderId(inputVmAccess.getEnvOrderId());
        	}

		if(inputVmAccess.getModifiedBy() != null && ! "".equals(inputVmAccess.getModifiedBy()) )
			vmAccessDbBean.setModifiedBy(inputVmAccess.getModifiedBy());
		else
			vmAccessDbBean.setModifiedBy("ESAP_INV");

		vmAccessDbBean.setLastModifiedDate(new Timestamp(System.currentTimeMillis()));
		return vmAccessDbBean;
	}

	/**
	 * @Param getDetails
	 * @description: 
	 * @return boolean
	 * @author Thejas
	 * @editedby
	 */
	public boolean getDetails()
	{
		try
		{
			log.info("In VmAccess getDetails; VmAccessId="+getVmAccessId());
			TblVmAccessQuery vmAccessQry = new TblVmAccessQuery();
			String whereClause = " where vm_access_id = \'"+getVmAccessId()+"\'";
			vmAccessQry.queryByWhere(connection, whereClause);
			if(vmAccessQry.size() == 1){
				setLocationId((vmAccessQry.getDbBean(0)).getLocationId());
				setEnterpriseId((vmAccessQry.getDbBean(0)).getEnterpriseId());
				setSubId((vmAccessQry.getDbBean(0)).getSubId());
				setPrivateNumber((vmAccessQry.getDbBean(0)).getPrivateNumber());
				setPublicPoolId((vmAccessQry.getDbBean(0)).getPublicPoolId());
				setNpaSplitStatus(vmAccessQry.getDbBean(0).getNpaSplitStatus());
				setCreatedBy((vmAccessQry.getDbBean(0)).getCreatedBy());
				setCreationDate((vmAccessQry.getDbBean(0)).getCreationDate());
				setModifiedBy((vmAccessQry.getDbBean(0)).getModifiedBy());
				setLastModifiedDate((vmAccessQry.getDbBean(0)).getLastModifiedDate());
				setEnvOrderId((vmAccessQry.getDbBean(0)).getEnvOrderId());
				
			}else
			{
				setStatus(InvErrorCode.NO_VM_RECORD_FOUND);
				return false;
			}
			
		}catch(SQLException s)
		{
			setStatus(InvErrorCode.DB_EXCEPTION);
			s.printStackTrace();	
			return false;
		}
		setStatus(InvErrorCode.SUCCESS);
		return true;
	}

	/**
	 * The method to modify the VmAccess record.
	 *
	 * VmAccess Id should be set before calling this method.
	 *
	 * @return	true	Record has been updated SUCCESSFULLY
	 * 			false	VmAccess Id missing / Record update Unsuccessful /
	 * 					Some Error occured.
	 */
	public boolean modifyInDB(){
		try
		{
			if ( getVmAccessId() <= 0) {
				setStatus(InvErrorCode.INTERNAL_ERROR);
				log.info("FAILURE in modifyInDB VmAccess. VmAccessId missing.");
				return false;
			}
	
			DBTblVmAccess vmAccessbean = getVmAccessToUpdate();
	        	vmAccessbean.whereVmAccessIdEQ(getVmAccessId());

			if ( vmAccessbean.updateSpByWhere(connection) <= 0 ) {
				return false;	
			}
		} catch(SQLException s) {
			setStatus(InvErrorCode.DB_EXCEPTION);
			log.info("DB_FAILURE in modifyInDB VmAccess");
			s.printStackTrace();	
			return false;
		}
		setStatus(InvErrorCode.SUCCESS);
	
		return true;
	}
	public long addToPublicPool(String tn, int tnStatus, long tnType) throws Exception
    {
        log.info("Entering VmAccess::addToPublicPool");
        long tnId = 0;
        try
        {
            TblPublicTnPoolQuery tnPoolQry = new TblPublicTnPoolQuery();
            String whereCls = " where tn =\'"+ tn+"\'";
			log.info("whereCls in VmAccess, addToPublicPool:"+whereCls+":");
            tnPoolQry.queryByWhere(connection,whereCls);
            if(tnPoolQry.size() > 0)
            {
                if(tnPoolQry.getDbBean(0).getTnStatus() == VzbVoipEnum.TnStatus.AVAILABLE && 
						tnPoolQry.getDbBean(0).getLocationId().equals(locationId))
                {
					PublicTnPool tnObj = new PublicTnPool(connection);
					tnObj.setTnPoolId(tnPoolQry.getDbBean(0).getTnPoolId());
					tnObj.setTnStatus(tnStatus);
					tnObj.setTnType(tnType);
					tnObj.setActiveInd(VzbVoipEnum.ActiveInd.ACTIVE);
					tnObj.setModifiedBy("ESAP_INV");
					tnObj.setLastModifiedDate(new Timestamp(System.currentTimeMillis()));
						
					if(tnObj.updatePublicTnPool() != true)
					{
						log.info("Failed to Update tn [" + tn + "]");
						return tnId;
					}
					tnId = tnPoolQry.getDbBean(0).getTnPoolId();
                }
                else
                {
                    log.info("TN location id [" + locationId + "] Invalid for Tn [" + tn + "]");
                    return tnId;
                }
            }
            else
            {
				PublicTnPool tnObj = new PublicTnPool(connection);
				tnObj.setLocationId(locationId);
				tnObj.setTn(tn);
				tnObj.setActiveInd(VzbVoipEnum.ActiveInd.ACTIVE);
				tnObj.setTnStatus(tnStatus);
				tnObj.setTnType(tnType);
				tnObj.setPortedStatus("" + VzbVoipEnum.PortStatus.NATIVE);
				tnObj.setModifiedBy("ESAP_INV");
				tnObj.setCreatedBy("ESAP_INV");
				tnObj.setLastModifiedDate(new Timestamp(System.currentTimeMillis()));
				tnObj.setCreationDate(new Timestamp(System.currentTimeMillis()));
				if(tnObj.addPublicTnPool() != true)
				{
					log.info("Failed to add Tn ["+ tn + "]");
					return tnId;
				}
				TblPublicTnPoolQuery tnQry = new TblPublicTnPoolQuery();
            	String wCls = " where tn =\'"+ tn +"\'";
            	log.info("whereCls:"+wCls);
            	tnQry.queryByWhere(connection,wCls);
            	if(tnQry.size() > 0)
				{
					tnId = tnQry.getDbBean(0).getTnPoolId();
					log.info("Inserted Tn Pool Id [" + tnId + "]");	
				}
				else
					log.info("Strange. TN Not Found");
            }
        }
        catch (SQLException e)
        {
        	setStatus(InvErrorCode.DB_EXCEPTION);
            log.info("DB_FAILURE in addToPublicPool");
		e.printStackTrace();	
            return tnId;
        }
        setStatus(InvErrorCode.SUCCESS);
        log.info("Successfully inserted Tn");
        return tnId;
    }

	
}
