/**
 * 
 */
package com.vz.fxo.inventory.tn;


import java.math.BigInteger;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.function.Supplier;

import org.omg.CORBA.portable.ApplicationException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import EsapEnumPkg.TaskExitEnum;
import EsapEnumPkg.VzbVoipEnum;

import com.mchange.v2.c3p0.ComboPooledDataSource;
import com.vz.esap.api.connector.service.impl.ConfigDomainDataServiceImpl;
import com.vz.esap.api.connector.service.impl.InventoryDomainDataServiceImpl;
import com.vz.esap.api.connector.service.impl.OrderDomainDataServiceImpl;
import com.vz.esap.api.connector.service.impl.OrderLogServiceImpl;
import com.vz.esap.api.exception.ApplicationInterfaceException;
import com.vz.esap.api.exception.VZBBSAFException;
import com.vz.esap.api.model.ESAPEntityEnum;
import com.vz.esap.api.model.FailEntityInfo;
import com.vz.esap.api.model.OrderDomainServiceRequest;
import com.vz.esap.api.model.OrderLogInfo;
import com.vz.esap.api.model.OrderRspInfo;
import com.vz.esap.api.model.TaskCompletionLogInfo;
import com.vz.esap.api.model.dto.OrderDomainServiceDTO;
import com.vz.esap.api.model.ordering.EntityBatch;
import com.vz.esap.api.model.ordering.EntityData;
import com.vz.esap.api.model.ordering.OrderHeader;
import com.vz.esap.api.model.ordering.OrderSearchFilter;
import com.vz.esap.api.model.ordering.OrderSearchFilter.OrderSearchFilterBuilder;
import com.vz.esap.api.model.ordering.TableOrderDetailsParam;
import com.vz.fxo.inventory.actionfunction.support.PublicTnPool;
import com.vz.fxo.inventory.actionfunction.support.TnPorting;
import com.vz.fxo.inventory.actionfunction.support.TsoEtTn;
import com.vz.fxo.inventory.actionfunction.support.VzbInvException;
import com.vz.fxo.inventory.tn.dao.model.TblTriTnData;
import com.vz.fxo.inventory.tn.helper.ActionFunctionHelper;
import com.vz.fxo.inventory.tn.helper.FxoBSErrorEntityMgmtHelper;

import esap.db.DBTblGatewayDeviceInfo;
import esap.db.DBTblTerminatingRouting;
import esap.db.DBTblVzbStateGatewayMap;
import esap.db.TblCodecTypeDbBean;
import esap.db.TblCodecTypeQuery;
import esap.db.TblConfigParamsDbBean;
import esap.db.TblConfigParamsQuery;
import esap.db.TblCustomerDbBean;
import esap.db.TblCustomerQuery;
import esap.db.TblDeviceFirmwaresQuery;
import esap.db.TblDeviceMapQuery;
import esap.db.TblDialPlanDbBean;
import esap.db.TblDialPlanQuery;
import esap.db.TblEndPointCharDbBean;
import esap.db.TblEndPointCharQuery;
import esap.db.TblFirmwareVersionQuery;
import esap.db.TblGatewayDeviceInfoQuery;
import esap.db.TblLocationDbBean;
import esap.db.TblLocationQuery;
import esap.db.TblPublicTnPoolQuery;
import esap.db.TblTerminatingRoutingDbBean;
import esap.db.TblTerminatingRoutingQuery;
import esap.db.TblVzbStateGatewayMapDbBean;
import esap.db.TblVzbStateGatewayMapQuery;

/**
 * This class implements the common methods that can be used by TN Action
 * Executors
 * 
 * @author Deepak Kumar
 * 
 */

public abstract class GenericActionFunction implements Runnable,Supplier<Integer>{

	private static Logger log = LoggerFactory
			.getLogger(GenericActionFunction.class.toString());

	public static final String PARAM_ACTION_IN = "n";
	public static final String PARAM_ACTION_OUT = "o";
	public static final String PARAM_ACTION_R = "r";
	public static final String PARAM_ACTION_C = "c";
	public static final String FRAUD_BLOCK_BY_BS = "BS";
	public static final int SUCCESS = 1 ;
	public static final int FAILURE = 2 ;
	protected int MAX_BS_COMMAND_CHAINING = 15;
	protected final int INV_SUCCESS = 1;
	protected final int INV_FAILURE = 2;
	protected final int LOG_TYPE_FAIL = 2;
	protected final int LOG_TYPE_SUCCESS = 7;
	protected final int LOG_TYPE_INFO = 1;
	protected static final String SOURCE = "INV";
	protected String wfServiceName = null;// SERVICE_NAME:VZB_BS_ADD_LOCATION
	

	public String getWfServiceName() {
		return wfServiceName;
	}

	public void setWfServiceName(String wfServiceName) {
		this.wfServiceName = wfServiceName;
	}

	protected OrderDomainDataServiceImpl orderDomainDataService;
	protected ConfigDomainDataServiceImpl configDomainDataService;
	protected OrderLogServiceImpl orderLogService;
	protected FxoBSErrorEntityMgmtHelper bsErrorEntityMgmtHelper;
	protected InventoryDomainDataServiceImpl inventoryDomainDataService;
	
	
	protected List<String> logTrailList = new ArrayList<String>();
	protected boolean logSucessFail = true;
	protected String logFinalMessage = "";
	//public Connection iasaConn = null;
	

	
	public Connection connection; 

	protected String workOrderNumber; // ORDER_NUMBER:334122170
	protected String workOrderNumberVersion; //{0,1,2,3}
	protected Long orderNumber = 0L; // WO_ID:ENTUSE2EIPBX00001710120951
	protected Long seqNo = 0L; // Use as a tracking ID// SEQNO:5
	protected String task = null;// TASK:VZB_BS_AUTHORIZE_LOC_FEATURES
	
	
	// ACTION_FUNCTION:esap.vzbvoip.rivactionfunction.broadsoft17.VZB_BS_AUTHORIZE_LOC_FEATURES_17
	// SERVICE_NAME:VZB_BS_ADD_LOCATION
	private String device; // DEVICE:DEV_RIVISTBSF01_36
	private String clliCode; // CLLI_CODE:RIVISTBSF01
	private String connType; // CONNECTION_TYPE:DeviceProxy_VZBAS
	private String sftwrLoad;// SFTWR_LOAD:17.0
	private int asyncFlag; // ASYNC_FLAG:0
	private String loopBackOn; // LOOPBACK_ON:0;
	public String envOrderId;
	/* number of max TN can be submitted to Broadsoft device */
	protected int tnBatchSizeBulk = 500;
	/* number of failed entity shall be read from DB */
	private int bsFaieldTNLimit = 1;
	/* number of max order can be processed at a time */
	private int orderProcessSize = 500;
	private boolean rangeFlag = false;
	public ESAPEntityEnum entityType = null;
	public String domain = null;
	public int entityId = 0;
	public String orderType;
	
	public boolean validateSystenDn = true;
	public String region;
	public String enterpriseId;
	public String locationId;
	public Integer failedTNCount = 0;
	public Integer orderProcessedCount = 0;
	public int totPages = 1;
	public int pageSize = tnBatchSizeBulk;
	public int currentPageNo = 1;
	
	// MultiThreading Changes
	public long maxIndex;
	protected List<String> failedTnList = new ArrayList<>();
	private ComboPooledDataSource comboPooledDataSource;
	
	public Connection getDBNewConnection() throws SQLException {
		if (comboPooledDataSource != null){
			return comboPooledDataSource.getConnection();
		}else{
			return connection;
		}
	}

	
	/**
	 * @return the maxIndex
	 */
	public long getMaxIndex() {
		return maxIndex;
	}

	/**
	 * @param maxIndex the maxIndex to set
	 */
	public void setMaxIndex(long maxIndex) {
		this.maxIndex = maxIndex;
	}
	
	/**
	 * @return the failedTnList
	 */
	public List<String> getFailedTnList() {
		return failedTnList;
	}
	
	/**
	 * @param failedTnList the failedTnList to set
	 */
	public void setFailedTnList(List<String> failedTnList) {
		this.failedTnList = failedTnList;
	}
	
	
	/**
	 * @return the comboPooledDataSource
	 */
	public ComboPooledDataSource getComboPooledDataSource() {
		return comboPooledDataSource;
	}
	
	/**
	 * @param comboPooledDataSource the comboPooledDataSource to set
	 */
	public void setComboPooledDataSource(ComboPooledDataSource comboPooledDataSource) {
		this.comboPooledDataSource = comboPooledDataSource;
	}

	// MultiThreading Changes
	@Override
	public void run() {
		log.info("Calling feature in Thread");
		this.go();
		
	}
	
	@Override
	public Integer get() {
		log.info("Inside get() method");
		return this.go();
	}
	
	public int doTask() {
		return doTask(false);
	}
	
	public int doTask(boolean isSystemUpdateTask) {
		try {
			if (isSystemUpdateTask){
				setBulkConfigData();
			}
			return go();
		} finally {
			// As discussed with Siva and Priya it is not required to update the order status 
			// after every task execution. 
			// Date : July 17 , 2017
			//if (isSystemUpdateTask)
				//updateOrderStatus();
		}
	}
	/*private void updateOrderStatus() {
		log.info("Entering updateOrderStatus");
		try {
			orderDomainDataService.updateTnOrderStatus(workOrderNumber, workOrderNumberVersion, envOrderId);
		} catch (Exception e) {
			log.error("Error in updateTnOrderStatus" + e.getMessage());
		}
		log.info("Exiting updateOrderStatus");
	}*/
	
	/**
	 * Every child class shall have to implement go method
	 * 
	 * @return
	 */
	public abstract int go();

	public OrderDomainDataServiceImpl getOrderDomainDataService() {
		return orderDomainDataService;
	}

	public void setOrderDomainDataService(
			OrderDomainDataServiceImpl orderDomainDataService) {
		this.orderDomainDataService = orderDomainDataService;
	}

	public ConfigDomainDataServiceImpl getConfigDomainDataService() {
		return configDomainDataService;
	}

	public void setConfigDomainDataService(
			ConfigDomainDataServiceImpl configDomainDataService) {
		this.configDomainDataService = configDomainDataService;
	}

	

	public OrderLogServiceImpl getOrderLogService() {
		return orderLogService;
	}

	public void setOrderLogService(OrderLogServiceImpl orderLogService) {
		this.orderLogService = orderLogService;
	}

	public FxoBSErrorEntityMgmtHelper getBsErrorEntityMgmtHelper() {
		return bsErrorEntityMgmtHelper;
	}

	public void setBsErrorEntityMgmtHelper(
			FxoBSErrorEntityMgmtHelper bsErrorEntityMgmtHelper) {
		this.bsErrorEntityMgmtHelper = bsErrorEntityMgmtHelper;
	}

	public InventoryDomainDataServiceImpl getInventoryDomainDataService() {
		return inventoryDomainDataService;
	}

	public void setInventoryDomainDataService(InventoryDomainDataServiceImpl inventoryDomainDataService) {
		this.inventoryDomainDataService = inventoryDomainDataService;
	}

	/**
	 * @return the tnBatchSizeBulk
	 */
	public int getTnBatchSizeBulk() {
		return tnBatchSizeBulk;
	}

	/**
	 * @param tnBatchSizeBulk
	 *            the tnBatchSizeBulk to set
	 */
	public void setTnBatchSizeBulk(int tnBatchSizeBulk) {
		this.tnBatchSizeBulk = tnBatchSizeBulk;
	}
	/**
	 * @return the orderNumber
	 */
	public Long getOrderNumber() {
		return orderNumber;
	}

	/**
	 * @param orderNumber
	 *            the orderNumber to set
	 */
	public void setOrderNumber(Long orderNumber) {
		this.orderNumber = orderNumber;
	}
	
	
	/**
	 * @return
	 */
	public Long getSeqNo() {
		return seqNo;
	}
	
	/**
	 * @param seqNo
	 */
	public void setSeqNo(Long seqNo) {
		this.seqNo = seqNo;
	}
	
	/**
	 * @return
	 */
	public String getTask() {
		return task;
	}
	
	/**
	 * @param task
	 */
	public void setTask(String task) {
		this.task = task;
	}

	/**
	 * @return the device
	 */
	public String getDevice() {
		return device;
	}

	/**
	 * @param device
	 *            the device to set
	 */
	public void setDevice(String device) {
		this.device = device;
	}

	/**
	 * @return the clliCode
	 */
	public String getClliCode() {
		return clliCode;
	}

	/**
	 * @param clliCode
	 *            the clliCode to set
	 */
	public void setClliCode(String clliCode) {
		this.clliCode = clliCode;
	}

	/**
	 * @return the connType
	 */
	public String getConnType() {
		return connType;
	}

	/**
	 * @param connType
	 *            the connType to set
	 */
	public void setConnType(String connType) {
		this.connType = connType;
	}

	/**
	 * @return the sftwrLoad
	 */
	public String getSftwrLoad() {
		return sftwrLoad;
	}

	/**
	 * @param sftwrLoad
	 *            the sftwrLoad to set
	 */
	public void setSftwrLoad(String sftwrLoad) {
		this.sftwrLoad = sftwrLoad;
	}

	/**
	 * @return the asyncFlag
	 */
	public int getAsyncFlag() {
		return asyncFlag;
	}

	/**
	 * @param asyncFlag
	 *            the asyncFlag to set
	 */
	public void setAsyncFlag(int asyncFlag) {
		this.asyncFlag = asyncFlag;
	}

	/**
	 * @return the loopBackOn
	 */
	public String getLoopBackOn() {
		return loopBackOn;
	}

	/**
	 * @param loopBackOn
	 *            the loopBackOn to set
	 */
	public void setLoopBackOn(String loopBackOn) {
		this.loopBackOn = loopBackOn;
	}

	/**
	 * @return the envOrderId
	 */
	public String getEnvOrderId() {
		return envOrderId;
	}

	/**
	 * @param envOrderId
	 *            the envOrderId to set
	 */
	public void setEnvOrderId(String envOrderId) {
		this.envOrderId = envOrderId;
	}

	
	/**
	 * @return the bsFaieldTNLimit
	 */
	public int getBsFaieldTNLimit() {
		return bsFaieldTNLimit;
	}

	/**
	 * @param bsFaieldTNLimit
	 *            the bsFaieldTNLimit to set
	 */
	public void setBsFaieldTNLimit(int bsFaieldTNLimit) {
		this.bsFaieldTNLimit = bsFaieldTNLimit;
	}

	/**
	 * @return the orderProcessSize
	 */
	public int getOrderProcessSize() {
		return orderProcessSize;
	}

	/**
	 * @param orderProcessSize
	 *            the orderProcessSize to set
	 */
	public void setOrderProcessSize(int orderProcessSize) {
		this.orderProcessSize = orderProcessSize;
	}
	/**
	 * @return the rangeFlag
	 */
	public boolean isRangeFlag() {
		return rangeFlag;
	}

	/**
	 * @param rangeFlag
	 *            the rangeFlag to set
	 */
	public void setRangeFlag(boolean rangeFlag) {
		this.rangeFlag = rangeFlag;
	}

	public int getEntityId() {
		return entityId;
	}

	public void setEntityId(int entityId) {
		this.entityId = entityId;
	}

	/**
	 * @return the entityType
	 */
	public ESAPEntityEnum getEntityType() {
		return entityType;
	}

	/**
	 * @param entityType the entityType to set
	 */
	public void setEntityType(String entityType) {
		this.entityType = ESAPEntityEnum.valueOf(entityType);
	}
	/**
	 * @return the orderType
	 */
	public String getOrderType() {
		return orderType;
	}

	/**
	 * @param orderType the orderType to set
	 */
	public void setOrderType(String orderType) {
		this.orderType = orderType;
	}
	/**
	 * This method will return the
	 * 
	 * @return
	 */
	private OrderHeader getOrderHeader() {
		OrderHeader orderHeader = new OrderHeader.OrderHeaderBuilder()
				.withEnterpriseId("")
				.withEnvOrderId(getEnvOrderId())
				.withFunctionCode("").withGchId("")
				.withNaspId("").withOrderType(getOrderType())
				.withResponseType("")
				.withTransactionID(UUID.randomUUID().toString())
				.withUnoServiceId("")
				.withVoipLocationId("")
				.withWorkOrderId(String.valueOf(getOrderNumber()))
				.withWorkOrderNumber(getWorkOrderNumber())
				.withWorkOrderVersion(getWorkOrderNumberVersion()).build();
		return orderHeader;
	}

	/**
	 * This method creates OrderDomainServiceRequest objects and use
	 * OrderDomainDataService to pull records .It also applied the filter
	 * 
	 * @param searchFilter
	 * @return
	 * @throws ApplicationException
	 * @throws ApplicationInterfaceException 
	 */
	public OrderDomainServiceDTO getOrderDomainDetail(
			OrderSearchFilter... searchFilters) throws ApplicationException, ApplicationInterfaceException {

		log.info("getOrderDomainDetail() pulling records from order domain service ");
		
		String systemEntityType = "BULK_SYSTEM_UPDATE";
		if (this.entityType == ESAPEntityEnum.PBX_TN) {
			systemEntityType = "BULK_PBX_SYS_UPD";
		}
		else if (this.entityType == ESAPEntityEnum.KEY_TN) {
			systemEntityType = "BULK_KEY_SYS_UPD";
		}
		else if (this.entityType == ESAPEntityEnum.RES_TN) {
			systemEntityType = "BULK_RES_SYS_UPD";
		}
		else if (this.entityType == ESAPEntityEnum.PBX) {
			systemEntityType = "PBX";
		}
		else if (this.entityType == ESAPEntityEnum.KEY) {
			systemEntityType = "KEY";
		}
		else if (this.entityType == ESAPEntityEnum.DEVICE) {
			systemEntityType = "DEVICE";
		}
		else if (this.entityType == ESAPEntityEnum.LOCATION) {
			systemEntityType = "LOCATION";
		}
		//KR-added new entity check for enterprise 
		else if (this.entityType == ESAPEntityEnum.ENTERPRISE) {
			systemEntityType = "ENTERPRISE";
		}
		//KR-End 
		String getOrderType = inventoryDomainDataService.getOrderType(getWfServiceName(), systemEntityType);
		
		this.setOrderType(getOrderType);
		
		OrderDomainServiceRequest.OrderDomainServiceRequestBuilder orderDomainServiceRequestBuilder = new OrderDomainServiceRequest.OrderDomainServiceRequestBuilder()
				.withOrderHeader(this.getOrderHeader());
		
		for (OrderSearchFilter filter : searchFilters) {
			orderDomainServiceRequestBuilder.addSearchFilter(filter);
		}
		OrderDomainServiceRequest orderDomainServiceRequest = orderDomainServiceRequestBuilder
				.build();
		log.debug("getOrderDomainDetail() request {}",orderDomainServiceRequest);
		OrderDomainServiceDTO orderDomainData = null;
		orderDomainData = orderDomainDataService.getOrderDomainData(orderDomainServiceRequest);
		return orderDomainData;

	}
	/**
	 * 
	 * @param esapEntityEnum
	 * @param paramList
	 * @param pageNo
	 * @param pageSize
	 * @param maxIndex
	 * @return
	 * @throws ApplicationException
	 * @throws ApplicationInterfaceException 
	 */
	public OrderDomainServiceDTO getOrderDomainDataPage(
			ESAPEntityEnum esapEntityEnum, List<String> paramList, int pageNo,
			int pageSize, Long maxIndex) throws ApplicationException, ApplicationInterfaceException {

		OrderDomainServiceDTO domainServiceDTO = null;
		long startIndex = ActionFunctionHelper.getStartPageIndex(pageSize,
				pageNo);
		long endIndex = ActionFunctionHelper.getEndPageIndex(pageSize, pageNo,
				maxIndex);

		OrderSearchFilterBuilder builder = new OrderSearchFilterBuilder();
		if (paramList != null && pageNo == 1){
			/* added some mandatory kind of the parameters in each request */
			paramList.add("CustomerId");
			paramList.add("LocationId");
			paramList.add("Region");
			paramList.add("DomainName");
			paramList.add("EnterpriseTrunkTN");
			paramList.add("TNRecord");
			for (String param : paramList){
				builder.addParamName(param);
			}
		}
		OrderSearchFilter searchFilter = builder
				.withEntityType(esapEntityEnum)
				.withStartIndex(startIndex).withEndIndex(endIndex).build();
		
		domainServiceDTO = getOrderDomainDetail(searchFilter);
		return domainServiceDTO;
	}


	
	/**
	 * This method shall pull configuration data from Configuration Domain
	 * service
	 * 
	 */
	public void setBulkConfigData() {

		log.trace("In BSActivationDeactivationUtil.getConfigtData()");
		String paramValue = null;
		String paramName = null;
		Map<String, String> map = null;

		try {
			map = configDomainDataService.getTblConfigParamMap(
					"BULK_API", "BS_TN_AF_BATCH");
			
			Iterator<String> keySetIterator = map.keySet().iterator();
			while (keySetIterator.hasNext()) {
				paramName = keySetIterator.next();
				paramValue = map.get(paramName);
				paramName = (paramName == null ?"":paramName.trim());
				paramValue = (paramValue == null ?"":paramValue.trim());
				if (paramName.equalsIgnoreCase("BS_TN_BATCH_SIZE")
						&& Integer.parseInt(paramValue) > 0) {
					if (paramValue != null && Integer.parseInt(paramValue) > 0) {
						tnBatchSizeBulk = Integer.parseInt(paramValue);
					}
				}
				else if (paramName.equalsIgnoreCase("BS_TN_FAIL_BATCH_SIZE")
						&& Integer.parseInt(paramValue) > 0) {
					if (Integer.parseInt(paramValue) > 0) {
						bsFaieldTNLimit = Integer.parseInt(paramValue);
					}
				}
				else if (paramName.equalsIgnoreCase("BS_TN_ORDER_SIZE")
						&& Integer.parseInt(paramValue) > 0) {
					if (Integer.parseInt(paramValue) > 0) {
						orderProcessSize = Integer.parseInt(paramValue);
					}
				}
				else if (paramName.equalsIgnoreCase("BS_TN_RANGE_FLAG")) {
					if (!ActionFunctionHelper.isEmpty(paramValue)) {
						rangeFlag = Boolean.valueOf(paramValue);
					}
				}
				else if (paramName.equalsIgnoreCase("BS_TN_SYSTEN_VALIDATE")) {
					if (!ActionFunctionHelper.isEmpty(paramValue)) {
						validateSystenDn = Boolean.valueOf(paramValue);
					}
				}				
			}

		} catch (Exception e) {
			log.error(
					"Exception caught while adding order details to OrderParams:",
					e);
		}
		log.info("In BSActivationDeactivationUtil.getConfigtData() BS_TN_BATCH_SIZE ==>{} BS_TN_RANGE_FLAG =={}"
				+ " BS_TN_SYSTEN_VALIDATE ==>{}", tnBatchSizeBulk,rangeFlag,validateSystenDn);

	}

	/**
	 * 
	 * @param esapEntityEnum
	 * @return
	 * @throws ApplicationException
	 * @throws ApplicationInterfaceException 
	 */
	public OrderDomainServiceDTO getOrderDomainDetail(ESAPEntityEnum... esapEntityEnums) throws ApplicationException, ApplicationInterfaceException {
		List<OrderSearchFilter> orderSearchFilterList = new ArrayList<>();

		OrderSearchFilter orderSearchFilter = null;
		for (ESAPEntityEnum esapEntityEnum : esapEntityEnums) {
			orderSearchFilter = new OrderSearchFilter.OrderSearchFilterBuilder().withEntityType(esapEntityEnum).build();
			orderSearchFilterList.add(orderSearchFilter);
		}
		OrderSearchFilter[] searchFilterArray = new OrderSearchFilter[orderSearchFilterList.size()];
		searchFilterArray = orderSearchFilterList.toArray(searchFilterArray);
		OrderDomainServiceDTO domainServiceDTO = getOrderDomainDetail(searchFilterArray);
		return domainServiceDTO;
	}
	/**
	 * @return the workOrderNumber
	 */
	public String getWorkOrderNumber() {
		return workOrderNumber;
	}
	/**
	 * @param workOrderNumber the workOrderNumber to set
	 */
	public void setWorkOrderNumber(String workOrderNumber) {
		this.workOrderNumber = workOrderNumber;
	}
	/**
	 * @return the workOrderNumberVersion
	 */
	public String getWorkOrderNumberVersion() {
		return workOrderNumberVersion;
	}
	/**
	 * @param workOrderNumberVersion the workOrderNumberVersion to set
	 */
	public void setWorkOrderNumberVersion(String workOrderNumberVersion) {
		this.workOrderNumberVersion = workOrderNumberVersion;
	}
	public void insertOrderLog(String msg) {
		OrderLogInfo logRequestObj = new OrderLogInfo();
		logRequestObj.setOrderId(orderNumber);
		logRequestObj.setLogText(msg);
		logRequestObj.setLogType(1);
		logRequestObj.setSeqNo(1L);
		logRequestObj.setLogDate(ActionFunctionHelper.getCurrentTimeStamp());
		logRequestObj.setLogIdentity(0L);

		orderLogService.insertOrderLog(logRequestObj);
	}
	public void insertOrderLog(List<String> msgList) {
		List<OrderLogInfo> orderLogInfoList = new ArrayList<OrderLogInfo>();
		String logDate = ActionFunctionHelper.getCurrentTimeStamp();
		OrderLogInfo logRequestObj = null;
		for (String msg : msgList) {
			logRequestObj = new OrderLogInfo();
			logRequestObj.setOrderId(orderNumber);
			logRequestObj.setLogText(msg);
			logRequestObj.setLogType(1);
			logRequestObj.setSeqNo(1L);
			logRequestObj.setLogDate(logDate);
			logRequestObj.setLogIdentity(0L);
			orderLogInfoList.add(logRequestObj);
		}
		
		orderLogService.insertOrderLog(orderLogInfoList);
	}
	
	public void insertOrderLogError(String msg) {
		OrderLogInfo logRequestObj = new OrderLogInfo();
		logRequestObj.setOrderId(orderNumber);
		logRequestObj.setLogText(msg);
		logRequestObj.setLogType(2);
		logRequestObj.setSeqNo(1L);
		logRequestObj.setLogDate(ActionFunctionHelper.getCurrentTimeStamp());
		logRequestObj.setLogIdentity(0L);
		orderLogService.insertOrderLog( logRequestObj);
	}
	
	/**
	 * This method inserts logs in bulk 
	 * 
	 * @param msgList
	 */
	public void insertOrderLogError(List<String> msgList) {
		
		List<OrderLogInfo> orderLogInfoList = new ArrayList<OrderLogInfo>();
		String logDate = ActionFunctionHelper.getCurrentTimeStamp();
		OrderLogInfo logRequestObj = null;
		for (String msg : msgList){
			logRequestObj = new OrderLogInfo();
			logRequestObj.setOrderId(orderNumber);
			logRequestObj.setLogText(msg);
			logRequestObj.setLogType(2);
			logRequestObj.setSeqNo(1L);
			logRequestObj.setLogDate(logDate);
			logRequestObj.setLogIdentity(0L);
			orderLogInfoList.add(logRequestObj);
		}
		orderLogService.insertOrderLog(orderLogInfoList);
		msgList.clear();
	}

	/**
	 * 
	 * @param paramMap
	 * @throws Exception
	 */
	public void persistResponseDetails(Map<String, String> paramMap)
			throws Exception {
		
		if (paramMap == null || paramMap.isEmpty()) {
			//throw new RuntimeException("Empty or Null Param Map for TBL_ORDER_RSP");
			return;
		}		
		List<OrderRspInfo> orderRspInfoList = new ArrayList<>();		
		for (Map.Entry<String,String> entry : paramMap.entrySet()) {
			String paramName = entry.getKey();
			String paramValue = entry.getValue();
		
			if (paramValue != null && paramName != null) {
				OrderRspInfo orderRspInfo = null;
				if (paramName.equals("ERROR_CODE") || paramName.equals("ERROR_DESC") || paramName.equals("ERROR_SOURCE")) {
					// deleteResponseDetails(paramName);
					// TODO Uncomment above line and implement API to delete from TBL_ORDER_RESP
					orderRspInfo = new OrderRspInfo();
					orderRspInfo.setOrderId(orderNumber); 
					orderRspInfo.setRspId(0L); 
					orderRspInfo.setParentId(0L);
					orderRspInfo.setSeqNo(0L);
					orderRspInfo.setFlowStatus(0L);
					orderRspInfo.setLeaf(1L);
					orderRspInfo.setParamType("P");
					orderRspInfo.setParamName(paramName);
					orderRspInfo.setParamValue(paramValue);
					orderRspInfoList.add(orderRspInfo);
				} else {
					orderRspInfo = new OrderRspInfo();
					orderRspInfo.setOrderId(orderNumber);
					orderRspInfo.setRspId(0L);
					orderRspInfo.setParentId(0L);
					orderRspInfo.setSeqNo(seqNo);
					orderRspInfo.setFlowStatus(0L);
					orderRspInfo.setLeaf(1L);
					orderRspInfo.setParamType("P");
					orderRspInfo.setParamName(paramName);
					orderRspInfo.setParamValue(paramValue);
					orderRspInfoList.add(orderRspInfo);
				}
				orderLogService.insertOrderRsp(orderRspInfoList);
			}			
		}
	}
	
	/**
	 * 
	 * @param description
	 * @param severity
	 * @param status
	 */
	public void insertTaskCompletionLog(String description, String severity, String status) {

		if (description == null){
			return;
		}
		TaskCompletionLogInfo taskCompletionLogInfo = 	prepareTaskCompletionLogInfo(description,severity,status);	
		ArrayList<TaskCompletionLogInfo> aList = new ArrayList<>();
		aList.add(taskCompletionLogInfo);
		orderLogService.insertTaskCompletionLog(aList);
	}
	/**
	 * 
	 * @param description
	 * @param severity
	 * @param status
	 * @return
	 */
	public TaskCompletionLogInfo prepareTaskCompletionLogInfo(String description, String severity, String status) {
		
		TaskCompletionLogInfo taskCompletionLogInfo = new TaskCompletionLogInfo();
		taskCompletionLogInfo.setDescription(description);
		taskCompletionLogInfo.setEventDate(ActionFunctionHelper.getCurrentTimeStamp());
		taskCompletionLogInfo.setOrderId(orderNumber);
		taskCompletionLogInfo.setSeqNo(seqNo);
		taskCompletionLogInfo.setSeverity(severity);
		taskCompletionLogInfo.setStatus(status);
		Long svcSeqNo = this.seqNo < 1 ? 0L : this.seqNo;
		taskCompletionLogInfo.setSvcSeqNo(svcSeqNo);
		taskCompletionLogInfo.setTaskName(task);
		return taskCompletionLogInfo;
	}
	
	/**
	 * 
	 * @param message
	 */
	public void insertTaskCompletionLog(String message)  {
		insertTaskCompletionLog(message, "HIGH",
				TaskExitEnum.ErrorType.acronym(TaskExitEnum.ErrorType.LOG));
		
	}

	/**
	 * 
	 * @param errorCode
	 * @param errorMessage
	 */
	public void handleActionFunctionError(String errorCode, String errorMessage) {
		try {
			Map<String, String> paramMap = new HashMap<>();
			paramMap.put("ERROR_CODE",  errorCode);
			paramMap.put("ERROR_DESC", errorMessage);
			paramMap.put("ERROR_SOURCE", "Broadsoft");
			persistResponseDetails(paramMap);
		} catch (Exception e) {
			log.info("Exception caught in FiosBroadsoftAction::handleActionFunctionError: " ,e);
			
		}
	}
	
	

	/**
	 * 
	 * @param failedTnList
	 * @return
	 * @throws ParseException
	 */
	public void insertFailRecords(List<Map<String, String>> failedTnList) {

		log.info("In insertFailRecords() EnvOrderID :{} , TASK_NAME :{}", envOrderId,task);
		List<FailEntityInfo> failEntityInfoList  = new ArrayList<FailEntityInfo>();
		FailEntityInfo failEntityInfo = null;
		try {
			for (Map<String, String> tnStatusMap : failedTnList) {
				failEntityInfo = new FailEntityInfo();
				failEntityInfo.setEntityType(entityType.toString());
				failEntityInfo.setEnvOrderId(envOrderId);
				failEntityInfo.setErrorCode(tnStatusMap.get("StatusCode"));
				failEntityInfo.setErrorDesc(tnStatusMap.get("StatusMessage"));
				failEntityInfo.setOrderId(String.valueOf(orderNumber));
				failEntityInfo.setTaskName(task);
				failEntityInfo.setTn(tnStatusMap.get("TN"));
				//failEntityInfo.setUpdatedTimestamp(sqlDate);
				failEntityInfo.setWorkOrderNumber(workOrderNumber);
				failEntityInfo.setWorkOrderVersion(workOrderNumberVersion);
				failEntityInfoList.add(failEntityInfo);				
			}
			orderDomainDataService.setTnFalloutStatus(failEntityInfoList);
			failedTnList.clear();
		} catch (Exception e) {
			log.error("Exception caught while storing failed TN infromation into Database:", e);
		}
	}
	
	/**
	 * @param tnBatchArray
	 * @param tnActivationResult
	 * @return
	 */
	public int clearSuccessTNFromList(List<String> tnBatchArray,
			HashMap<String, Integer> tnActivationResult) {
		
		if (tnActivationResult != null && tnActivationResult.size() > 0) {
			failedTNCount = tnActivationResult.size();
			/*
			 * removed all failed TN from original list Just keeping those
			 * TNs which are successfully added to location , will remove these
			 * TNs from failed TN list from DB
			 */
			tnBatchArray.removeAll(tnActivationResult.keySet());
			insertOrderLogError("Failed to add some TNs to location, check in  >> TBL_FAIL_ENTITY_INFO Table");
			return FAILURE;
		} else {
			log.info("addFailedTNToLocation() Successfully all TNs are added to Location: "
					+ tnBatchArray.toString());
			return SUCCESS;
		}
	}
	
	public TblLocationDbBean getLocationForLocationId(String locationId) throws SQLException {
		TblLocationDbBean locationDbBean = new TblLocationDbBean();
		ArrayList<TblLocationDbBean> resultList = null;
		try {
			TblLocationQuery locationQuery = new TblLocationQuery();
			locationQuery.whereLocationIdEQ(locationId);
			locationQuery.query(connection);

			resultList = locationQuery.getResultArrayList();
			if (resultList.size() > 0) {
				locationDbBean = (TblLocationDbBean) resultList.get(0);
			}
		} catch (SQLException | NullPointerException e) {
			log.error("ERROR: Exception caught while trying to get rpid from tbl_location", e);
		}
		return locationDbBean;

	}

	public int getRegion(String locationId) throws SQLException {
		log.info(" getRegion method");
		StringBuffer sql = new StringBuffer();
		PreparedStatement pStmt = null;
		ResultSet rs = null;
		sql.append(" select region_id from tbl_customer where customer_id = ");
		sql.append(" ( select enterprise_id from tbl_location where location_id= ?)");
		int regionId = 0;
		log.info(" Sql  " + sql.toString());
		log.info(" location id " + locationId);
		try {
			pStmt = connection.prepareStatement(sql.toString());
			pStmt.setString(1, locationId);
			if (pStmt != null) {
				rs = pStmt.executeQuery();
				if (rs.next()) {
					regionId = rs.getInt(1);
					log.info(" Region Id " + regionId);
				}
			}

		} catch (SQLException e) {
			log.error("Exception while getting region", e);
			// setStatus(InvErrorCode.DB_EXCEPTION);
			log.error("DB_FAILURE in getRegion", e);
			// return regionId;
			throw e;
		} finally {
			if (pStmt != null) {
				pStmt.close();
			}

			if (rs != null) {
				rs.close();
			}
		}
		// setStatus(InvErrorCode.SUCCESS);
		log.info("Successfully retrieved getRegion from db");
		log.info(" Region Id " + regionId);
		return regionId;
	}

	public DBTblVzbStateGatewayMap getVzbGatewayId(String locState, String regionType, String enterpriseId)
			throws Exception {

		int row = 0;
		DBTblVzbStateGatewayMap gatewayMap = new DBTblVzbStateGatewayMap();

		try {

			log.info(" getVzbGatewayId method");
			StringBuffer sql = new StringBuffer();
			PreparedStatement pStmt = null;
			ResultSet rs = null;
			sql.append(" select * from tbl_vzb_bs_as_ns_mapping where bs_as_id = ");
			sql.append(" ( select as_id from tbl_enterprise where enterprise_id = ?)");

			log.info(" Sql  " + sql.toString());
			log.info(" Enterprise Id  " + enterpriseId);
			try {
				pStmt = connection.prepareStatement(sql.toString());
				pStmt.setString(1, enterpriseId);
				if (pStmt != null) {
					rs = pStmt.executeQuery();
					if (rs.next()) {
						gatewayMap.setPrimaryGatewayid(rs.getString(3));
						gatewayMap.setPrimaryGatewayname(rs.getString(4));
						gatewayMap.setSecondaryGatewayid(rs.getString(5));
						gatewayMap.setSecondaryGatewayname(rs.getString(6));

						log.info("Successfully retrieved BsAsNsMapping from db");
						log.info(" PrimaryGatewayId " + gatewayMap.getPrimaryGatewayid() + " PrimaryGatewayName "
								+ gatewayMap.getPrimaryGatewayname());
						log.info(" SecondaryGatewayId " + gatewayMap.getSecondaryGatewayid() + " SecondaryGatewayName "
								+ gatewayMap.getSecondaryGatewayname());

						return gatewayMap;
					}
				}

			} catch (SQLException e) {
				log.error("Exception while getting VZBGateWayId", e);
				// setStatus(InvErrorCode.DB_EXCEPTION);
				log.error("DB_FAILURE in getVzbGatewayId", e);
				// return regionId;
				throw e;
			} finally {
				if (pStmt != null) {
					pStmt.close();
				}

				if (rs != null) {
					rs.close();
				}
			}

			log.info(" LocState :: " + locState + " regionType  :: " + regionType);
			TblVzbStateGatewayMapQuery gatewayMapQuery = new TblVzbStateGatewayMapQuery();
			gatewayMapQuery.whereStateMnemonicEQ(locState);
			// gatewayMapQuery.whereStateNameEQ(locState);
			gatewayMapQuery.whereRegionEQ(regionType);
			gatewayMapQuery.query(connection);

			ArrayList resultList = gatewayMapQuery.getResultArrayList();
			Iterator iter = resultList.iterator();
			if (iter.hasNext()) {
				TblVzbStateGatewayMapDbBean gatewayMapBean = (TblVzbStateGatewayMapDbBean) (iter.next());

				gatewayMap.setStateMnemonic(gatewayMapBean.getStateMnemonic());
				gatewayMap.setStateName(gatewayMapBean.getStateName());
				gatewayMap.setMissisippiRiverSide(gatewayMapBean.getMissisippiRiverSide());
				gatewayMap.setPrimaryGatewayid(gatewayMapBean.getPrimaryGatewayid());
				gatewayMap.setPrimaryGatewayname(gatewayMapBean.getPrimaryGatewayname());
				gatewayMap.setSecondaryGatewayid(gatewayMapBean.getSecondaryGatewayid());
				gatewayMap.setSecondaryGatewayname(gatewayMapBean.getSecondaryGatewayname());

			} else {
				/**
				 * gatewayMapQuery = new TblVzbStateGatewayMapQuery();
				 * gatewayMapQuery.whereStateMnemonicEQ(locState);
				 * gatewayMapQuery.query(connection); resultList =
				 * gatewayMapQuery.getResultArrayList(); iter =
				 * resultList.iterator(); if (iter.hasNext()) {
				 * TblVzbStateGatewayMapDbBean gatewayMapBean =
				 * (TblVzbStateGatewayMapDbBean) (iter.next());
				 * 
				 * gatewayMap.setStateMnemonic(gatewayMapBean.getStateMnemonic()
				 * ); gatewayMap.setStateName(gatewayMapBean.getStateName());
				 * gatewayMap.setMissisippiRiverSide(gatewayMapBean.
				 * getMissisippiRiverSide());
				 * gatewayMap.setPrimaryGatewayid(gatewayMapBean.
				 * getPrimaryGatewayid());
				 * gatewayMap.setPrimaryGatewayname(gatewayMapBean.
				 * getPrimaryGatewayname());
				 * gatewayMap.setSecondaryGatewayid(gatewayMapBean.
				 * getSecondaryGatewayid());
				 * gatewayMap.setSecondaryGatewayname(gatewayMapBean.
				 * getSecondaryGatewayname());
				 * 
				 * } else { //IR #1135999 throw new Exception(
				 * "No matching records were found"); }
				 ***/
				throw new Exception("No matching records were found");
			}

			log.info("getVzbGatewayId() - has  returned  rows [" + resultList.size() + "]");
		} catch (Exception e) {
			log.error("Error while trying to get tbl_vzb_state_gateway_map entries", e);
			throw new Exception("Execption caught while trying to get tbl_vzb_state_gateway_map entries");
		}

		log.info(" PrimaryGatewayId " + gatewayMap.getPrimaryGatewayid() + " PrimaryGatewayName "
				+ gatewayMap.getPrimaryGatewayname());
		log.info(" SecondaryGatewayId " + gatewayMap.getSecondaryGatewayid() + " SecondaryGatewayName "
				+ gatewayMap.getSecondaryGatewayname());

		return gatewayMap;
	}

	public void mergeTerminatingRouting(PublicTnPool pubTnBeanObj) throws Exception {
		long envOrderId = pubTnBeanObj.getEnvOrderId();
		long noa = pubTnBeanObj.getNoa();
		if (noa < 0) {
			noa = 1;
			pubTnBeanObj.setNoa(1);
		}
		boolean trNotReqd = false;
		if (pubTnBeanObj.getRangeStart() != null && !pubTnBeanObj.getRangeStart().equals("")) {
			pubTnBeanObj.setTn(pubTnBeanObj.getRangeStart());
			if (pubTnBeanObj.getPublicTnPoolDetailsByTn() == true) {
				log.info("TN [" + pubTnBeanObj.getTn() + "] with STN Ind [" + pubTnBeanObj.getStnInd() + "]");
				if (pubTnBeanObj.getStnInd() > 0) {
					TblLocationDbBean locationDbBean = getLocationForLocationId(pubTnBeanObj.getLocationId());
					pubTnBeanObj.setDialPlanId(locationDbBean.getDialPlanId());
					if (locationDbBean.getServiceLevel() == VzbVoipEnum.ServiceLevel.LD_AND_ON_NET) {
						log.info("STN under LDOnly Location");
						trNotReqd = true;
					} else
						log.info("STN not under LDOnly Location");
				}
			} else
				log.info("Failed to retrieve TN");
		} else
			log.info("TN Not found");
		long dialPlanId = pubTnBeanObj.getDialPlanId();
		/*
		 * if(triAlreadyExistsInDb(pubTnBeanObj)) { log.info(
		 * "Tri already exists in Db"); throw new Exception(
		 * "Tri already exists in Db"); }
		 */
		int triCheck = triAlreadyExistsInDb(pubTnBeanObj);
		if (triCheck == 0 && noa == 1) {
			String custName = null;
			long dpId = dpIdForAlreadyExistsTri(pubTnBeanObj);
			String entId = getCustIdForDialplanId(dpId);
			TblCustomerDbBean custDbBean = getCustomer(entId);
			if (custDbBean != null)
				custName = custDbBean.getCustomerName();
			log.info("Tri [" + pubTnBeanObj.getTn() + "] already exists in Db for differnt DPID = " + dpId
					+ " under Enterprise " + custName + " Id : " + entId);

			String explicitTriAdj = getConfigParamValue("TRI", "EXPLICIT_TRI_ADJUSTMENT_NEEDED");
			if ("YES".equalsIgnoreCase(explicitTriAdj)) {
				log.info("[" + pubTnBeanObj.getTn() + "] already exists in Db for differnt DPID = " + dpId
						+ " under Enterprise " + custName + " Id : " + entId + ".So delinking the TN from DPID:"
						+ dpId);

				PublicTnPool tnPool = new PublicTnPool(connection);
				tnPool.setDialPlanId(dpId);
				tnPool.setNoa(1L);
				tnPool.setEnvOrderId(envOrderId);
				tnPool.setRangeStart(pubTnBeanObj.getTn());
				tnPool.setRangeEnd(pubTnBeanObj.getTn());

				splitTerminatingRouting(tnPool);
			} else {
				throw new Exception("Tri [" + pubTnBeanObj.getTn() + "] already exists in Db for differnt DPID = "
						+ dpId + " under Enterprise " + custName + " Id : " + entId);
			}
		} else if (triCheck < 0 && trNotReqd == true) {
			log.info("TRI for STN [" + pubTnBeanObj.getTn() + "] in LD_AND_ON_NET Location. Skip Term Routing");
		} else if (triCheck == 1 && trNotReqd == true) {
			log.info("TRI for STN [" + pubTnBeanObj.getTn() + "] in LD_AND_ON_NET Location Exists. Removing...");
			splitTerminatingRouting(pubTnBeanObj);
		} else if (triCheck == 1) {
			log.info("Tri already exists in Db for same DPID so Nothing to do");
		} else {
			TblTerminatingRoutingQuery dbTermQry = new TblTerminatingRoutingQuery();
			dbTermQry.setLimitQry(false);
			dbTermQry.whereDialPlanIdEQ(dialPlanId);
			dbTermQry.whereNoaEQ(noa);
			if (pubTnBeanObj.getP1url() == null || "NONE".equals(pubTnBeanObj.getP1url())) {
				dbTermQry.whereP1urlIsNull();
			} else {
				dbTermQry.whereP1urlEQ(pubTnBeanObj.getP1url());
			}
			if (pubTnBeanObj.getA1url() == null || "NONE".equals(pubTnBeanObj.getA1url())) {

				dbTermQry.whereA1urlIsNull();
			} else {
				dbTermQry.whereA1urlEQ(pubTnBeanObj.getA1url());
			}

			dbTermQry.setOrderBy("RANGE_START FOR UPDATE");
			dbTermQry.query(connection);
			ArrayList<TblTerminatingRoutingDbBean> dbTriList = new ArrayList<TblTerminatingRoutingDbBean>();
			if (dbTermQry.size() > 0) {
				for (int i = 0; i < dbTermQry.size(); i++) {
					dbTriList.add(dbTermQry.getDbBean(i));
				}
			}
			DBTblTerminatingRouting dbTermRouting = new DBTblTerminatingRouting();
			// DBIpcomEnterpriseRouting dbIpcomEntRouting = new
			// DBIpcomEnterpriseRouting();
			String sInputRngStart = null;
			String sInputRngEnd = null;

			if (pubTnBeanObj != null) {
				sInputRngStart = pubTnBeanObj.getRangeStart();
				sInputRngEnd = pubTnBeanObj.getRangeEnd();
			} else {
				throw new Exception("Input is Null");
			}

			// fresh insert
			if (dbTriList == null || dbTriList.size() == 0) {
				log.info("There is no rec present in db for the dpid and noa. Insert fresh range: "
						+ pubTnBeanObj.getRangeStart() + "-" + pubTnBeanObj.getRangeEnd());

				pubTnBeanObj.addTerminatingRouting();
				return;
			}
			log.info("dbTriList.size=" + dbTriList.size());
			TblTerminatingRoutingDbBean newBean = new TblTerminatingRoutingDbBean();
			TblTerminatingRoutingDbBean oldBean = new TblTerminatingRoutingDbBean();

			Iterator itr = dbTriList.iterator();
			String action = null;
			while (itr.hasNext()) {
				oldBean.copyFrom((TblTerminatingRoutingDbBean) itr.next());
				newBean.copyFrom(oldBean);
				action = addTriRange(oldBean, newBean, sInputRngStart, sInputRngEnd);
				if ("NOACT".equalsIgnoreCase(action)) {
					// We found the new rng in the db range, so break
					break;
				}
				if ("Merge".equalsIgnoreCase(action)) {
					log.info("DELETE EXISTING REC " + oldBean.getRangeStart() + "-" + oldBean.getRangeEnd());
					dbTermRouting.copyFromBean(oldBean);
					dbTermRouting.delete(connection);
					// TODO Need to insert it in new del term routing table.

					sInputRngStart = newBean.getRangeStart();
					sInputRngEnd = newBean.getRangeEnd();
				}
			}

			if ("Merge".equalsIgnoreCase(action)) {
				log.info("Iteration is over now, Insert newBean with action = MERGE: " + newBean.getRangeStart() + "-"
						+ newBean.getRangeEnd());
				dbTermRouting.copyFromBean(newBean);
				long terminatingRoutingId;
				if (pubTnBeanObj.getTerminatingRoutingId() > 0)
					dbTermRouting.setTerminatingRoutingId((int) pubTnBeanObj.getTerminatingRoutingId());
				else {
					terminatingRoutingId = dbTermRouting.getTerminatingRoutingIdSeqNextVal(connection);
					dbTermRouting.setTerminatingRoutingId((int) terminatingRoutingId);
				}
				dbTermRouting.setEnvOrderId(envOrderId);
				dbTermRouting.insert(connection);
			}
			if ("Add".equalsIgnoreCase(action)) {
				log.info("Iteration is over now, Insert newBean with action = Add: " + newBean.getRangeStart() + "-"
						+ newBean.getRangeEnd());
				dbTermRouting.copyFromBean(newBean);
				long terminatingRoutingId;
				if (pubTnBeanObj.getTerminatingRoutingId() > 0)
					dbTermRouting.setTerminatingRoutingId((int) pubTnBeanObj.getTerminatingRoutingId());
				else {
					terminatingRoutingId = dbTermRouting.getTerminatingRoutingIdSeqNextVal(connection);
					dbTermRouting.setTerminatingRoutingId((int) terminatingRoutingId);
				}

				dbTermRouting.setEnvOrderId(envOrderId);
				dbTermRouting.insert(connection);
			}
		}
	}

	public Connection getConnection() {
		return connection;
	}

	public void setConnection(Connection connection) {
		this.connection = connection;
	}

	/**
	 * Closing 
	 * @param newDBConnection 
	 */
	public void closeConnection(Connection newDBConnection){
		if (newDBConnection != null){
			try {
				newDBConnection.close();
			} catch (SQLException e) {
			}
		}
	}
	
	public int triAlreadyExistsInDb(PublicTnPool pubTnBeanObj) throws Exception {
		int returnResult = -1;// Not there in db so go ahead with the merge
		TblTerminatingRoutingQuery termQry = new TblTerminatingRoutingQuery();
		termQry.setLimitQry(false);
		String whereCls = " where (to_number(\'" + pubTnBeanObj.getRangeStart()
				+ "\') between to_number(range_start) and to_number(range_end)) and (to_number(\'"
				+ pubTnBeanObj.getRangeEnd() + "\') between to_number(range_start) and to_number(range_end)) and noa = "
				+ pubTnBeanObj.getNoa();
		log.info("whereCls" + whereCls);
		termQry.queryByWhere(connection, whereCls);
		if (termQry.size() > 0) {
			for (int i = 0; i < termQry.size(); i++) {
				if (termQry.getDbBean(i).getDialPlanId() != pubTnBeanObj.getDialPlanId()) {
					returnResult = 0;// TRI exists with different DPID.Error out
					break;
				} else
					returnResult = 1;// TRI exists with same DPID. By pass
										// merging, return succ.
			}
		}
		return returnResult;
	}

	public long dpIdForAlreadyExistsTri(PublicTnPool pubTnBeanObj) throws Exception {

		TblTerminatingRoutingQuery termQry = new TblTerminatingRoutingQuery();
		termQry.setLimitQry(false);
		String whereCls = " where (to_number(\'" + pubTnBeanObj.getRangeStart()
				+ "\') between to_number(range_start) and to_number(range_end)) and (to_number(\'"
				+ pubTnBeanObj.getRangeEnd() + "\') between to_number(range_start) and to_number(range_end)) and noa = "
				+ pubTnBeanObj.getNoa();
		log.info("whereCls" + whereCls);
		termQry.queryByWhere(connection, whereCls);
		if (termQry.size() > 0) {
			for (int i = 0; i < termQry.size(); i++) {
				if (termQry.getDbBean(i).getDialPlanId() != pubTnBeanObj.getDialPlanId()) {
					return termQry.getDbBean(i).getDialPlanId();// TRI exists
																// with
																// different
																// DPID.Error
																// out

				}
			}
		}

		return 0;

	}

	public String getCustIdForDialplanId(long dpId) throws Exception {
		log.info(" *** getCustIdForDialplanId invoked *** " + dpId);
		try {
			TblDialPlanQuery dpQry = new TblDialPlanQuery();
			dpQry.whereDialPlanIdEQ((int) dpId);
			dpQry.query(connection);

			TblDialPlanDbBean dpDbBean = dpQry.getDbBean(0);
			return dpDbBean.getEnterpriseId();

		} catch (Exception e) {
			log.error("Exception caught while getting customerId for DialPlanId", e);
			throw e;
		}

	}

	public TblCustomerDbBean getCustomer(String custId) throws SQLException {
		log.info("In getCustomer()");
		ArrayList<TblCustomerDbBean> resultList = null;
		TblCustomerDbBean custDbBean = new TblCustomerDbBean();
		try {
			TblCustomerQuery customerQuery = new TblCustomerQuery();
			customerQuery.whereCustomerIdEQ(custId);
			customerQuery.query(connection);

			resultList = customerQuery.getResultArrayList();
			if (resultList.size() > 0) {
				custDbBean = (TblCustomerDbBean) resultList.get(0);
			}
		} catch (SQLException e) {
			log.error("ERROR: Exception caught while trying to get tbl_customer");
		}
		return custDbBean;
	}

	public String getConfigParamValue(String processName, String paramName) throws SQLException {
		String paramValue = "";

		TblConfigParamsQuery paramsQ = new TblConfigParamsQuery();
		if (processName != null)
			paramsQ.whereProcessNameEQ(processName);
		if (paramName != null)
			paramsQ.whereParamNameEQ(paramName);
		paramsQ.query(connection);

		if (paramsQ.size() <= 0) {
			log.info("No Config Entry Found by ProcessName [" + processName + "] and ParamName [" + paramName + "]");
			logTrailList.add(
					"No Config Entry Found by ProcessName [" + processName + "] and ParamName [" + paramName + "]");
			return paramValue;
		}

		TblConfigParamsDbBean cpBean = paramsQ.getDbBean(0);
		paramValue = cpBean.getParamValue();
		log.info("Successfully Retrieved Param Value [" + paramValue + "]");
		insertOrderLog("Successfully Retrieved Param Value [" + paramValue + "]");
		return paramValue;
	}

	public void splitTerminatingRouting(PublicTnPool pubTnBeanObj) throws Exception {
		long envOrderId = pubTnBeanObj.getEnvOrderId();
		long noa = pubTnBeanObj.getNoa();
		if (noa < 0)
			noa = 1;
		long dialPlanId = pubTnBeanObj.getDialPlanId();
		/* Test code */
		DBTblTerminatingRouting termDb = new DBTblTerminatingRouting();
		termDb.setDialPlanId(dialPlanId);
		// termDb.setLastModifiedDate(new
		// Timestamp(System.currentTimeMillis()));
		termDb.whereDialPlanIdEQ(dialPlanId);
		termDb.whereNoaEQ(noa);
		termDb.updateSpByWhere(connection);
		/* Test code */
		TblTerminatingRoutingQuery dbTermQry = new TblTerminatingRoutingQuery();
		dbTermQry.setLimitQry(false);
		dbTermQry.whereDialPlanIdEQ(dialPlanId);
		dbTermQry.whereNoaEQ(noa);
		dbTermQry.setOrderBy("RANGE_START");
		dbTermQry.query(connection);
		ArrayList<TblTerminatingRoutingDbBean> dbTriList = new ArrayList<TblTerminatingRoutingDbBean>();
		if (dbTermQry.size() > 0) {
			for (int i = 0; i < dbTermQry.size(); i++) {
				dbTriList.add(dbTermQry.getDbBean(i));
			}
		}
		String sInputRngStart = null;
		String sInputRngEnd = null;
		if (pubTnBeanObj != null) {
			sInputRngStart = pubTnBeanObj.getRangeStart();
			sInputRngEnd = pubTnBeanObj.getRangeEnd();
		} else {
			throw new Exception("Input is Null");
		}

		/*
		 * IpcomEnterpriseRoutingDbBean firstNewBean = new
		 * IpcomEnterpriseRoutingDbBean(); IpcomEnterpriseRoutingDbBean
		 * secondNewBean = new IpcomEnterpriseRoutingDbBean();
		 * IpcomEnterpriseRoutingDbBean oldBean = null; DBIpcomEnterpriseRouting
		 * dbIpcomEntRouting = new DBIpcomEnterpriseRouting();
		 */

		TblTerminatingRoutingDbBean firstNewBean = new TblTerminatingRoutingDbBean();
		TblTerminatingRoutingDbBean secondNewBean = new TblTerminatingRoutingDbBean();
		TblTerminatingRoutingDbBean oldBean = null;
		DBTblTerminatingRouting dbTermRouting = new DBTblTerminatingRouting();

		Iterator itr = dbTriList.iterator();
		String action = null;

		while (itr.hasNext()) {
			oldBean = (TblTerminatingRoutingDbBean) itr.next();
			firstNewBean.copyFrom(oldBean);
			secondNewBean.copyFrom(oldBean);
			action = delTriRange(oldBean, firstNewBean, secondNewBean, sInputRngStart, sInputRngEnd);
			if ("DELETE".equalsIgnoreCase(action)) {
				// System.out
				log.info("DELETE EXISTING REC " + oldBean.getRangeStart() + "-" + oldBean.getRangeEnd());
				dbTermRouting.copyFromBean(oldBean);
				dbTermRouting.delete(connection);
			} else if ("SPLIT".equalsIgnoreCase(action)) {
				// System.out
				log.info("DELETE EXISTING REC " + oldBean.getRangeStart() + "-" + oldBean.getRangeEnd());
				dbTermRouting.copyFromBean(oldBean);
				dbTermRouting.delete(connection);

				log.info("INSERT NEW REC " + firstNewBean.getRangeStart() + "-" + firstNewBean.getRangeEnd());
				dbTermRouting.copyFromBean(firstNewBean);
				long terminatingRoutingId = dbTermRouting.getTerminatingRoutingIdSeqNextVal(connection);
				dbTermRouting.setTerminatingRoutingId((int) terminatingRoutingId);
				dbTermRouting.insert(connection);

				log.info("INSERT NEW REC " + secondNewBean.getRangeStart() + "-" + secondNewBean.getRangeEnd());
				dbTermRouting.copyFromBean(secondNewBean);
				terminatingRoutingId = dbTermRouting.getTerminatingRoutingIdSeqNextVal(connection);
				dbTermRouting.setTerminatingRoutingId((int) terminatingRoutingId);
				dbTermRouting.setEnvOrderId(pubTnBeanObj.getEnvOrderId());
				dbTermRouting.insert(connection);

			}
			if ("PD".equalsIgnoreCase(action)) {
				// System.out
				log.info("DELETE EXISTING REC " + oldBean.getRangeStart() + "-" + oldBean.getRangeEnd());
				dbTermRouting.copyFromBean(oldBean);
				dbTermRouting.delete(connection);

				log.info("INSERT NEW REC " + firstNewBean.getRangeStart() + "-" + firstNewBean.getRangeEnd());
				dbTermRouting.copyFromBean(firstNewBean);
				long terminatingRoutingId = dbTermRouting.getTerminatingRoutingIdSeqNextVal(connection);
				dbTermRouting.setTerminatingRoutingId((int) terminatingRoutingId);
				dbTermRouting.setEnvOrderId(pubTnBeanObj.getEnvOrderId());
				dbTermRouting.insert(connection);
			}
		}
	}

	// Note:
	// For add if we add/merge incoming range to an existing range, then
	// there is no need to iterate any more for the same range
	// A.compareTo(B) ==> -1 ==> A <B
	// A.compareTo(B) ==> 0 ==> A =B
	// A.compareTo(B) ==> 1 ==> A >B
	//
	private String addTriRange(TblTerminatingRoutingDbBean oldBean, TblTerminatingRoutingDbBean newBean,
			String inputRngStart, String inputRngEnd) {
		String action = null;
		BigInteger nDbRngStart = new BigInteger(oldBean.getRangeStart());
		BigInteger nDbRngEnd = new BigInteger(oldBean.getRangeEnd());
		BigInteger nInputRngStart = new BigInteger(inputRngStart);
		BigInteger nInputRngEnd = new BigInteger(inputRngEnd);

		BigInteger bigOne = BigInteger.valueOf(1);

		// case 1 and 7
		if ((nInputRngStart.compareTo(nDbRngStart) == 1 || nInputRngStart.compareTo(nDbRngStart) == 0)
				&& (nInputRngEnd.compareTo(nDbRngEnd) == -1 || nInputRngEnd.compareTo(nDbRngEnd) == 0)) {
			action = "NOACT";
		}
		// case 8 and 9

		else if ((nInputRngEnd.compareTo(nDbRngStart) == -1 && ((nInputRngEnd.add(bigOne)).compareTo(nDbRngStart)) != 0)
				|| (nInputRngStart.compareTo(nDbRngEnd) == 1
						&& (nInputRngStart.subtract(bigOne).compareTo(nDbRngEnd)) != 0)) {
			newBean.setRangeStart(leftPad(nInputRngStart, inputRngStart.length()));
			newBean.setRangeEnd(leftPad(nInputRngEnd, inputRngEnd.length()));
			action = "ADD";
		}
		// case 2, 3, 4, 5, 6
		else {
			BigInteger nNewRngStart = new BigInteger(oldBean.getRangeStart());
			BigInteger nNewRngEnd = new BigInteger(oldBean.getRangeEnd());

			if (nInputRngStart.compareTo(nDbRngStart) == -1) {
				nNewRngStart = nInputRngStart;
			}
			if (nInputRngEnd.compareTo(nDbRngEnd) == 1) {
				nNewRngEnd = nInputRngEnd;
			}

			newBean.setRangeStart(leftPad(nNewRngStart, inputRngStart.length()));
			newBean.setRangeEnd(leftPad(nNewRngEnd, inputRngEnd.length()));

			action = "MERGE";
		}

		// log.info("Old DB range: " + oldBean.getRangeStart() + "-"
		// + oldBean.getRangeEnd() + " Input Range: " + nInputRngStart
		// + "-" + nInputRngEnd + " New Db Range: "
		// + newBean.getRangeStart() + "-" + newBean.getRangeEnd()
		// + " Action:" + action);
		return action;
	}

	private String delTriRange(TblTerminatingRoutingDbBean oldBean, TblTerminatingRoutingDbBean firstNewBean,
			TblTerminatingRoutingDbBean secondNewBean, String inputRngStart, String inputRngEnd) {
		String action = null;

		BigInteger nDbRngStart = new BigInteger(oldBean.getRangeStart());
		BigInteger nDbRngEnd = new BigInteger(oldBean.getRangeEnd());
		BigInteger nInputRngStart = new BigInteger(inputRngStart);
		BigInteger nInputRngEnd = new BigInteger(inputRngEnd);

		BigInteger bigOne = BigInteger.valueOf(1);

		// case 2, 4, 8, 9
		if (nInputRngEnd.compareTo(nDbRngStart) == -1 || nInputRngStart.compareTo(nDbRngEnd) == 1) {
			action = "NOACT";
		}
		// case 6, 7
		else if ((nInputRngStart.compareTo(nDbRngStart) == -1 || nInputRngStart.compareTo(nDbRngStart) == 0)
				&& (nInputRngEnd.compareTo(nDbRngEnd) == 1 || nInputRngEnd.compareTo(nDbRngEnd) == 0)) {
			action = "DELETE";
		}
		// Case 1 Split
		else if (nInputRngStart.compareTo(nDbRngStart) == 1 && nInputRngEnd.compareTo(nDbRngEnd) == -1) {
			action = "SPLIT";
			firstNewBean.setRangeStart(leftPad(nDbRngStart, inputRngStart.length()));
			firstNewBean.setRangeEnd(leftPad(nInputRngStart.subtract(bigOne), inputRngStart.length()));
			secondNewBean.setRangeStart(leftPad(nInputRngEnd.add(bigOne), inputRngEnd.length()));
			secondNewBean.setRangeEnd(leftPad(nDbRngEnd, inputRngEnd.length()));
		}
		// Case PD
		else {
			action = "PD";

			BigInteger nNewRngStart = new BigInteger(oldBean.getRangeStart());
			BigInteger nNewRngEnd = new BigInteger(oldBean.getRangeEnd());

			if (nInputRngStart.compareTo(nDbRngStart) == -1 || nInputRngStart.compareTo(nDbRngStart) == 0) {
				nNewRngStart = nInputRngEnd.add(bigOne);
				nNewRngEnd = nDbRngEnd;
			}
			if (nInputRngEnd.compareTo(nDbRngEnd) == 1 || nInputRngEnd.compareTo(nDbRngEnd) == 0) {
				nNewRngStart = nDbRngStart;
				nNewRngEnd = nInputRngStart.subtract(bigOne);
			}

			firstNewBean.setRangeStart(leftPad(nNewRngStart, inputRngStart.length()));
			firstNewBean.setRangeEnd(leftPad(nNewRngEnd, inputRngEnd.length()));
		}

		// log.info("Old db range: " + oldBean.getRangeStart() + "-"
		// + oldBean.getRangeEnd() + " Input Range: " + nInputRngStart
		// + "-" + nInputRngEnd + " New First db Range: "
		// + firstNewBean.getRangeStart() + "-"
		// + firstNewBean.getRangeEnd() + " New Second db Range: "
		// + secondNewBean.getRangeStart() + "-"
		// + secondNewBean.getRangeEnd() + " Action:" + action);

		return action;
	}

	public String leftPad(BigInteger nNum, int padding) {
		return nNum.toString();
		// return String.format("%0"+padding+"d", nNum.toString());
		// return String.format("%0"+padding+"d", nNum.valueOf());
		// while(sNum.length() < len) {
		// sNum = "0" + sNum;
		// }
		// return sNum;
	}

	public void addLogMessageToDb() {
		try {
			Iterator it = logTrailList.iterator();
			while (it.hasNext()) {
				String logTrailStr = it.next().toString();
				insertOrderLog(logTrailStr);
			}
		} catch (Exception e) {
			log.error("Exception caught while adding log message to DB", e );
		}

	}

	// March 2011 Changes end

	// APAC LNP Sep2011

	/**
	 * @param orderParam
	 *            TOD params
	 * @return TnPorting Object
	 */
	public TnPorting setPortingInfoForAPAC(EntityData entityData) {
		log.info("Entering into InventoryActionfunctionBase:setPortingInfoForAPAC() to set TnPortingInfo....");
		// TnPorting Object to hold the values
		TnPorting tnPorting = new TnPorting(connection);

		String portingIndicator = ActionFunctionHelper.getTableOrderDetailsParamValue(entityData, "PortingIndicator");

		// Update the tnPorting bean obj if TOD has values
		if ((!ActionFunctionHelper.isEmpty(portingIndicator)) && !("".equals(portingIndicator))) {
			tnPorting.setPortingInd(portingIndicator);
		}
		String subStatus = ActionFunctionHelper.getTableOrderDetailsParamValue(entityData, "SubStatus");

		if ((!ActionFunctionHelper.isEmpty(subStatus)) && !("".equals(subStatus))) {
			tnPorting.setPortingInd(subStatus);
		}

		String gatewayNumber = ActionFunctionHelper.getTableOrderDetailsParamValue(entityData, "GatewayNumber");
		if ((!ActionFunctionHelper.isEmpty(gatewayNumber)) && !("".equals(gatewayNumber))) {
			tnPorting.setPortingInd(gatewayNumber);
		}

		String losingCarrierPrefix = ActionFunctionHelper.getTableOrderDetailsParamValue(entityData,
				"LosingCarrierPrefix");
		if ((!ActionFunctionHelper.isEmpty(losingCarrierPrefix)) && !("".equals(losingCarrierPrefix))) {
			tnPorting.setPortingInd(losingCarrierPrefix);
		}
		String gainingCarrierPrefix = ActionFunctionHelper.getTableOrderDetailsParamValue(entityData,
				"GainingCarrierPrefix");
		if ((!ActionFunctionHelper.isEmpty(gainingCarrierPrefix)) && !("".equals(gainingCarrierPrefix))) {
			tnPorting.setPortingInd(gainingCarrierPrefix);
		}
		String originalCarrierPrefix = ActionFunctionHelper.getTableOrderDetailsParamValue(entityData,
				"OriginalCarrierPrefix");
		if ((!ActionFunctionHelper.isEmpty(originalCarrierPrefix)) && !("".equals(originalCarrierPrefix))) {
			tnPorting.setPortingInd(originalCarrierPrefix);
		}

		log.info("InventoryActionfunctionBase:setPortingInfoForAPAC() TnPortingInfo is set.");

		return tnPorting;
	}

	/*

		public void setParam(EntityData entityData,String key, String value) {
			log_msg(logging_level, "<order-number:" + getParam("ORDER_NUMBER") + "> <wo_id:" + getParam("WO_ID")
					+ "> Storing <" + key + "> = <" + value + ">");

			try {
				if (entityData != null) {
					entityData.setParamValue(value);
				} else
					entityData.add(key, value);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		*/
		public boolean updatePubipValues(Map<String, TableOrderDetailsParam> paramMap) throws Exception {
			String tn = null;
			String query = "";
			PreparedStatement pstmt = null;
			try{
				if (!( ActionFunctionHelper.getParam(paramMap,"TNRecord") == null ))
				{
					log.info("Check for Pubip Update");
					boolean updPubIp = false;
					List<TableOrderDetailsParam> paramListNode  = ActionFunctionHelper.getParam(paramMap,"TNRecord").getParamDetail();
					for (TableOrderDetailsParam tableOrderDetailsParam :paramListNode)
					{
						//ParamDetail tmp = (ParamDetail) paramListNode.get(i);
						if (tableOrderDetailsParam.getParamName().equals("TN"))
							tn = tableOrderDetailsParam.getParamValue();

						if (tableOrderDetailsParam.getAction().equals("n") && tableOrderDetailsParam.getParamName().equals("PubIp"))
						{
							query += " PUBIP = "+tableOrderDetailsParam.getParamValue()+",";
						}
						if (tableOrderDetailsParam.getAction().equals("n") && tableOrderDetailsParam.getParamName().equals("PubIpIn"))
						{
							query += " PUBIP_IN = "+tableOrderDetailsParam.getParamValue()+",";
						}
						if (tableOrderDetailsParam.getAction().equals("n") && tableOrderDetailsParam.getParamName().equals("PubIpOut"))
						{
							query += " PUBIP_OUT = "+tableOrderDetailsParam.getParamValue()+",";
						}
					}
					if(query.length() >0){
						query += "LAST_MODIFIED_DATE = ?, MODIFIED_BY = ?";
					}else{
						return false;
					}
					query = "update tbl_public_tn_pool set " + query+" where tn = ?";
					log.debug("Query to update in updatePubipValues "+query);
					pstmt = connection.prepareStatement(query);
					pstmt.setTimestamp(1, new Timestamp(System.currentTimeMillis()));
					pstmt.setString(2, "ESAP_INV");
					pstmt.setString(3, tn);
					pstmt.executeUpdate();
				}
			}catch(Exception e){
				log.info("Failed to update pubip values");
				e.printStackTrace();
			}finally{
				if(pstmt != null){
					pstmt.close();
				}
			}
			return true;
		}
		
		public String getTNPoolId (String lstrTN) throws Exception {
			 String lstrPoolId = null;
			 PreparedStatement selStmt = null;
			 ResultSet res = null;
			 String lsPoolQry = "SELECT TN_POOL_ID FROM TBL_PUBLIC_TN_POOL WHERE TN = '" + lstrTN + "'";
			 try 
			    {
			     selStmt = connection.prepareStatement(lsPoolQry);
			     res = selStmt.executeQuery(lsPoolQry);
			     if (res != null) 
			     {
			      while (res.next())
			      {
			       lstrPoolId = res.getString(1);
			      }
			     } 
			    }catch (Exception e)
			    {
			     e.printStackTrace();
			     throw e;
			    }finally{
			    	if(res != null){
			       		res.close();
			    		}
			   	 if(selStmt != null){
			   		selStmt.close();
					}
			 }
			 return lstrPoolId;
			}
		
		public String parseAndUpdInvErr(String errMsg) throws Exception {
			log.info("parseAndUpdInvErr :: errMsg " + errMsg);
			String finalMsg = errMsg;
			String constraintName = null;
			String[] constArry = new String[5];
			// StringTokenizer lstr = new StringTokenizer (errMsg, "(");
			if (errMsg != null && errMsg.indexOf("integrity constraint") != -1) {
				/*
				 * while (lstr.hasMoreTokens()) { log.info("  lstr.nextToken() " +
				 * lstr.nextToken()); constraintName = lstr.nextToken();
				 * log.info("constraintName change " + constraintName);
				 * constraintName = constraintName.replace(")", "");
				 * log.info("constraintName" + constraintName) ; constArry =
				 * constraintName.split(" "); constraintName = constArry[0];
				 * log.info("constraintName final " + constArry[0]) ; break; }
				 */

				constArry = errMsg.split(" ");
				constraintName = constArry[3];
				constraintName = constraintName.replace("(", "");
				constraintName = constraintName.replace(")", "");
				log.info(" final constraint " + constraintName);
				if (constraintName != null) {
					log.info(" invoking config param api ");
					finalMsg = getConfigParamValue("ESAP_INV_ERR_MAP", constraintName);
				}
			}

			return finalMsg;
		}
		
		public void removeTriByTn(PublicTnPool pubTnBeanObj) throws SQLException, Exception {
			//log.info("Entering removeTriByTn");
			TblLocationDbBean locationDbBean = getLocationForLocationId(pubTnBeanObj.getLocationId());
			long dialPlanId = locationDbBean.getDialPlanId();
			pubTnBeanObj.setDialPlanId(dialPlanId);

			TsoEtTn etTnObj = new TsoEtTn(connection);
			TblTriTnData triDataBean = new TblTriTnData();
			triDataBean.setDialPlanId(pubTnBeanObj.getDialPlanId());
			triDataBean.setTn(pubTnBeanObj.getTn());
			triDataBean.setEnvOrderId(pubTnBeanObj.getEnvOrderId());
			triDataBean.setLocationId(pubTnBeanObj.getLocationId());
			
			if (pubTnBeanObj.getTnPoolId() > 0) {
				log.info("Retrieved TN Pool Id[" + pubTnBeanObj.getTnPoolId() + "]");
				TblPublicTnPoolQuery pubTnQry = new TblPublicTnPoolQuery();
				pubTnQry.whereTnPoolIdEQ(pubTnBeanObj.getTnPoolId());
				pubTnQry.query(connection);
				if (pubTnQry.size() > 0) {
					pubTnBeanObj.setRangeStart(pubTnQry.getDbBean(0).getTn());
					pubTnBeanObj.setRangeEnd(pubTnQry.getDbBean(0).getTn());
//					splitTerminatingRouting(pubTnBeanObj);
					etTnObj.deleteTri(triDataBean);
					//etTnObj.consolidateTriInfo(triDataBean);
					//logTrailList.add("Removing TRI for Port Pending (PP) TN.");
				}
			} else if (pubTnBeanObj.getTn() != null && !(pubTnBeanObj.getTn()).equals("")) {
				log.info("Retrieved TN[" + pubTnBeanObj.getTn() + "]");
				pubTnBeanObj.setTn(pubTnBeanObj.getTn());
				pubTnBeanObj.setRangeStart(pubTnBeanObj.getTn());
				pubTnBeanObj.setRangeEnd(pubTnBeanObj.getTn());
//				splitTerminatingRouting(pubTnBeanObj);
				etTnObj.deleteTri(triDataBean);
				//etTnObj.consolidateTriInfo(triDataBean);
				//logTrailList.add("Removing TRI for Port Pending TN.");
			} else {
				//logTrailList.add("TN Pool id/Tn not found in the order");
				throw new VzbInvException("ESP_VZB_INV_TN_POOLID_NOT_FOUND", "ESP_VZB_INV_TN_POOLID_NOT_FOUND");
			}
		}
		
		public int getCodecId(String Codec) throws SQLException {
			int codec_id;
			log.info("Codec===>" + Codec);
			TblCodecTypeDbBean codecTypeDbBean = new TblCodecTypeDbBean();
			ArrayList<TblCodecTypeDbBean> resultList = null;
			try {
				TblCodecTypeQuery codecTypeQuery = new TblCodecTypeQuery();
				codecTypeQuery.whereCodecNameEQ(Codec);
				codecTypeQuery.query(connection);

				resultList = codecTypeQuery.getResultArrayList();
				if (resultList.size() > 0) {
					codecTypeDbBean = (TblCodecTypeDbBean) resultList.get(0);
					codec_id = codecTypeDbBean.getCodecId();
				} else
					return -1;

			} catch (SQLException e) {
				log.error("In GenericActionFunction : Exception {}", e);
				log.error(
				"ERROR: Exception caught while trying to get codec_id from tbl_codec_type");
				return -1;
			}

			return codec_id;
		}
		
		public long getFirmWareIdByDevTypeIdAndVersion(String deviceTypeId,
				String firmVer) throws Exception {
			long firmVerId = 0;
			try {
				TblDeviceFirmwaresQuery devFirmQry = new TblDeviceFirmwaresQuery();
				devFirmQry.whereDeviceTypeIdEQ(Long.valueOf(deviceTypeId));
				TblFirmwareVersionQuery firmQry = new TblFirmwareVersionQuery();
				firmQry.whereFirmwareDescEQ(firmVer);
				firmQry.query(connection);
				if (firmQry.size() > 0)
					devFirmQry.whereFirmwareVersionIdEQ(firmQry.getDbBean(0)
							.getFirmwareVersionId());
				else {
					log.info("Invalid firmware");
					return firmVerId;
				}
				devFirmQry.query(connection);
				if (devFirmQry.size() > 0) {
					firmVerId = devFirmQry.getDbBean(0).getDeviceFirmwaresId();
				}
			} catch (Exception e) {
				log.error("In GenericActionFunction : Exception {}", e);
				throw e;
			}
			return firmVerId;
		}
		
	public boolean isValidGatewayDeviceName(String deviceName, String deviceType, String locationId,
			String enterpriseId) {
		return isValidGatewayDeviceName(deviceName, deviceType, locationId, enterpriseId, null);
	}

	public boolean isValidGatewayDeviceName(String deviceName, String deviceType, String locationId,
			String enterpriseId, String gatewayDeviceId) {
		boolean returnCode = true;
		PreparedStatement pStmt = null;
		ResultSet rs = null;
		PreparedStatement pStmt1 = null;
		ResultSet rs1 = null;

		// For enterprise shared chk all devices.
		try {

			if (deviceType.equals("CPE_ENTPRISE_GTWY_SHARED")) {
				StringBuffer sql = new StringBuffer();
				sql.append(" select g.* from tbl_gateway_device_info g, tbl_device_map d");
				sql.append(" where d.enterprise_id = '" + enterpriseId + "'");
				sql.append(" and d.gateway_device_id = g.gateway_device_id and g.device_name = '" + deviceName + "'");
				if (gatewayDeviceId != null) {
					sql.append(" and d.gateway_device_id <> " + gatewayDeviceId);
				}
				log.info("Chk for CPE_ENTPRISE_GTWY_SHARED:sql:" + sql.toString());
				pStmt = connection.prepareStatement(sql.toString());
				if (null != pStmt)
					rs = pStmt.executeQuery();
				if (rs.next()) {
					returnCode = false;
				}
			} else {
				// Check the duplicate name at enterprise gtwy level
				StringBuffer sql1 = new StringBuffer();
				sql1.append(" select g.* from tbl_gateway_device_info g, tbl_device_map d, tbl_device_types dp");
				sql1.append(" where d.enterprise_id = '" + enterpriseId + "'");
				sql1.append(" and d.gateway_device_id = g.gateway_device_id and g.device_name = '" + deviceName + "'");
				sql1.append(" and g.device_type_id = dp.device_type_id and dp.device_realtype_id = 4 ");
				if (gatewayDeviceId != null) {
					sql1.append(" and d.gateway_device_id <> " + gatewayDeviceId);
				}
				log.info("Chk for NON SHared gtwy:sql:" + sql1.toString());
				pStmt = connection.prepareStatement(sql1.toString());
				if (null != pStmt)
					rs = pStmt.executeQuery();
				if (rs.next()) {
					returnCode = false;
				}
				if (returnCode == true) {
					// check the duplicate name at location level
					StringBuffer sql2 = new StringBuffer();
					sql2.append(" select g.* from tbl_gateway_device_info g, tbl_device_map d");
					sql2.append(" where d.enterprise_id = '" + enterpriseId + "'");
					sql2.append(
							" and d.gateway_device_id = g.gateway_device_id and g.device_name = '" + deviceName + "'");
					sql2.append(" and d.location_id = '" + locationId + "'");
					if (gatewayDeviceId != null) {
						sql2.append(" and d.gateway_device_id <> " + gatewayDeviceId);
					}

					log.info("Chk for Non Shared gtwy:sql2:" + sql2.toString());
					pStmt1 = connection.prepareStatement(sql2.toString());
					if (null != pStmt1)
						rs1 = pStmt1.executeQuery();
					if (rs1.next()) {
						returnCode = false;
					}
				}
			}
		} catch (Exception e) {
			log.error("In GenericActionFunction : Exception {}", e);
		} finally {
			try {
				if (null != pStmt)
					pStmt.close();
				if (null != rs)
					rs.close();
				if (null != pStmt1)
					pStmt1.close();
				if (null != rs1)
					rs1.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		return returnCode;
	}
	
	public int getEndPointCharId(String strDeviceCharId) throws SQLException {
		int END_POINT_CHAR_ID = -1;
		TblEndPointCharDbBean endPointCharDbBean = new TblEndPointCharDbBean();
		ArrayList<TblEndPointCharDbBean> resultList = null;
		try {
			TblEndPointCharQuery endPointCharQuery = new TblEndPointCharQuery();
			endPointCharQuery.whereCharacteristicEQ(strDeviceCharId);
			endPointCharQuery.query(connection);

			resultList = endPointCharQuery.getResultArrayList();
			if (resultList.size() > 0) {
				endPointCharDbBean = (TblEndPointCharDbBean) resultList.get(0);
				END_POINT_CHAR_ID = endPointCharDbBean.getEndPointCharId();
				log.info("END_POINT_CHAR_ID:{}",END_POINT_CHAR_ID);
			} else
			{
				log.info("END_POINT_CHAR_ID:{}",-1);
				return -1;
			}

		} catch (SQLException e) {
			log.error("In GenericActionFunction : Exception {}", e);
			log.info("ERROR: Exception caught while trying to get EndPointCharId from TblEndPointChar");
			log.error("END_POINT_CHAR_ID:"+-1);
			return -1;
		}

		return END_POINT_CHAR_ID;
	}
	
	public long isSharedDeviceExists(String customerId, String deviceName, String gwyAddress)
			throws Exception {
		long gatewayDeviceId = 0;

		TblGatewayDeviceInfoQuery gwDevQry;
		DBTblGatewayDeviceInfo gwDevDbBean = new DBTblGatewayDeviceInfo();
		try {
			gwDevQry = new TblGatewayDeviceInfoQuery();
			gwDevQry.whereDeviceNameEQ(deviceName);
			gwDevQry.whereGatewayAddressEQ(gwyAddress);
			gwDevQry.query(connection);
			if (gwDevQry.size() > 0) {
				for (int i = 0; i < gwDevQry.size(); i++) {
					TblDeviceMapQuery devMapQry = new TblDeviceMapQuery();
					devMapQry.whereGatewayDeviceIdEQ(gwDevQry.getDbBean(0).getGatewayDeviceId());
					devMapQry.whereEnterpriseIdEQ(customerId);
					devMapQry.query(connection);
					if (devMapQry.size() > 0) {
						gatewayDeviceId = devMapQry.getDbBean(0).getGatewayDeviceId();
						break;
					}
				}
			}

		} catch (Exception e) {
			log.error("In GenericActionFunction isSharedDeviceExists: Exception {}", e);
			throw e;
		}
		log.info("In isSharedDeviceExists, deviceName:" + deviceName + "gwyAddress:" + gwyAddress + "gatewayDeviceId:"
				+ gatewayDeviceId);

		return gatewayDeviceId;
	}

		/**
		 * Setting common fields which can be used by all action functions
		 * 
		 * @param entityBatch
		 * @throws VZBBSAFException
		 */
		public void setCommonFields(EntityBatch entityBatch) throws VZBBSAFException{
			log.info("setCommonFields start");
			region = ActionFunctionHelper.getRegion(entityBatch);
			log.info("setCommonFields region"+region);
			
			enterpriseId = ActionFunctionHelper.getEnterpriseId(entityBatch);
			log.info("setCommonFields enterpriseId"+enterpriseId);
			locationId = ActionFunctionHelper.getLocationId(entityBatch);			
			log.info("setCommonFields locationId"+locationId);	
			region="US";
			locationId="962221004";
			ActionFunctionHelper.checkForNull("EnterpriseId", enterpriseId);
			ActionFunctionHelper.checkForNull("LocationId", locationId);
			ActionFunctionHelper.checkForNull("Region", region);
			log.info("setCommonFields End");
		}
		
		

		/**
		 * This method shall only keep records for received order id and removed
		 * other order id details . It is required in cases where we will received
		 * data for multiple entities(More than one location , more than one
		 * enterprise trunk etc)
		 * 
		 * 
		 * @param entityBatch
		 * @param orderNumber
		 * @throws VZBBSAFException 
		 */
		public void cleanEntityBatchSetCommonFields(EntityBatch entityBatch, Long orderNumber) throws VZBBSAFException {
			
			log.info(
					"Cleaning the entityBatch and keep detail of corresponding orderNumber only : {}",
					orderNumber);
			if (entityBatch.getEntity().size() >0){
				List<String> removeKeyList = new ArrayList<String>();
				for (Map.Entry<String, EntityData> entry : entityBatch.getEntity()
						.entrySet()) {
					EntityData ed = entry.getValue();

					/*TableOrderDetailsParam detailsParam = ed

							.getParamMap().get("OrderNumber");*/
					TableOrderDetailsParam detailsParam = ActionFunctionHelper.getParam(ed
							.getParamMap(), "OrderNumber");
					log.info("detailsParam"+detailsParam);
					log.info("orderNumber"+orderNumber);
					if (orderNumber!=null && detailsParam!=null && !detailsParam.getOrderId().equals(orderNumber.toString())) {
						removeKeyList.add(entry.getKey());
					}
				}
				if (!removeKeyList.isEmpty()){
					log.info(
							"Cleaning the entityBatch , removing : {} entities",
							removeKeyList.size());
					for (String key: removeKeyList){
						entityBatch.getEntity().remove(key);
					}
				}
			}
			setCommonFields(entityBatch);
			log.info("cleanEntityBatchSetCommonFields end");
		}
		
		public void insertTrailLog(List<String> logTrailList) {
			try {
				Iterator it = logTrailList.iterator();
				while (it.hasNext()) {
					String logTrailStr = it.next().toString();
					insertOrderLog(logTrailStr);
				}
			} catch (Exception e) {
				log.error("Exception caught while adding log message to DB", e );
			}
		}
}