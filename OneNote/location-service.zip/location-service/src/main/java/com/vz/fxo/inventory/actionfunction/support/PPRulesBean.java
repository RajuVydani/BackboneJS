package com.vz.fxo.inventory.actionfunction.support;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

public class PPRulesBean {


	protected long prefixPlanId;
	protected String prefix;
	protected long numstrip;
	protected String addPrefix;
	protected long noa;
	protected long blkstat;
	protected String createdBy;
	protected Timestamp creationDate;
	protected Timestamp lastModifiedDate;
	protected String modifiedBy;
	protected List<String> logTrail;
	protected List<PPRulesBean> pPRulesBeanList;
	
	public PPRulesBean() {
		this.prefixPlanId = 0;
		this.prefix= new String("");
		this.numstrip = -1;
		this.addPrefix = new String("NONE");
		this.noa = -1;
		this.blkstat = -1;
		this.creationDate = null;
		this.lastModifiedDate = null;
		this.logTrail = new ArrayList<String>();
		this.pPRulesBeanList = null;
	}

	public PPRulesBean(PPRulesBean pPRules) {
		this.prefixPlanId = pPRules.getPrefixPlanId();
        this.prefix = pPRules.getPrefix();
        this.numstrip = pPRules.getNumstrip();
        this.addPrefix = pPRules.getAddPrefix();
        this.noa = pPRules.getNoa();
        this.blkstat = pPRules.getBlkstat();
		this.createdBy= pPRules.getCreatedBy();
		this.modifiedBy = pPRules.getModifiedBy();
		this.creationDate = pPRules.getCreationDate();
		this.lastModifiedDate = pPRules.getLastModifiedDate();
		this.pPRulesBeanList = pPRules.getPPRulesBeanList();
	}

	public long getPrefixPlanId() {
        return prefixPlanId;
    }
    public void setPrefixPlanId(long prefixPlanId) {
        this.prefixPlanId = prefixPlanId;
    }

	public String getPrefix() {
		return prefix;
	}
	public void setPrefix(String prefix) {
		this.prefix = prefix;
	}
	
	public long getNumstrip() {
		return numstrip;
	}
	public void setNumstrip(long numstrip) {
		this.numstrip = numstrip;
	}

	public String getAddPrefix() {
		return addPrefix;
	}
	public void setAddPrefix(String addPrefix) {
		this.addPrefix= addPrefix;
	}
	
	public long getNoa() {
        return noa;
    }
    public void setNoa(long noa) {
        this.noa= noa;
    }

	public long getBlkstat() {
        return blkstat;
    }
    public void setBlkstat(long blkstat) {
        this.blkstat = blkstat;
    }

	public void setCreationDate(Timestamp creationDate) {
		this.creationDate = creationDate;
	}

	public Timestamp getCreationDate() {
		return creationDate;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}	

	public Timestamp getLastModifiedDate() {
		return lastModifiedDate;
	}	

	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	
    public void setLogTrail(String logStr) {
		logTrail.add(logStr);
	}

	public List<String> getLogTrail() {
		return logTrail;
	}

	public void setPPRulesBeanList(List<PPRulesBean> pprBeanList) {
        this.pPRulesBeanList = pprBeanList;
    }

    public List<PPRulesBean> getPPRulesBeanList() {
        return pPRulesBeanList;
    }

}
