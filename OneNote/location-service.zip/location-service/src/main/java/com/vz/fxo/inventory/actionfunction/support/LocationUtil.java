package com.vz.fxo.inventory.actionfunction.support;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import EsapEnumPkg.VzbVoipEnum;
import EsapEnumPkg.WorkOrderEnum;
import esap.db.TblOrderDetailsDbBean;

public class LocationUtil {
	
	private static Logger log = LoggerFactory.getLogger(LocationUtil.class.toString());
	
	public String getServiceLevel(Connection dbcon, String locationId)
			throws SQLException {
		log.info("Enter LocationUtil.getServiceLevel: {}" , locationId);

		String serviceLvl = null;
		int svcLvl = -1;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		StringBuffer sql = new StringBuffer();

		sql.append("SELECT service_level from tbl_location WHERE location_id='")
				.append(locationId).append("'");

		try {
			pstmt = dbcon.prepareStatement(sql.toString());
			rs = pstmt.executeQuery();
			if (rs.next()) {
				svcLvl = rs.getInt(1);
				log.debug("service_level: {}" , svcLvl);
			}
			pstmt.close();
			if (svcLvl > 0) {
				serviceLvl = VzbVoipEnum.ServiceLevel.acronym(svcLvl);
			}
		} catch (SQLException e) {
			throw e;
		} finally {
			if (rs != null)
				rs.close();
			if (pstmt != null)
				pstmt.close();
		}

		log.info("Exit LocationUtil.getServiceLevel: {}" , svcLvl);

		return serviceLvl;
	}
	
	public String getLocatoinSTN(Connection dbcon, String locationId)
			throws SQLException {
		log.info("Enter LocationUtil.getLocatoinSTN: {}" , locationId);

		String tn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		StringBuffer sql = new StringBuffer();

		sql.append("SELECT tn from tbl_public_tn_pool WHERE location_id='")
				.append(locationId).append("'");
		sql.append(" AND stn_ind = 1");

		try {
			pstmt = dbcon.prepareStatement(sql.toString());
			rs = pstmt.executeQuery();
			if (rs.next()) {
				tn = rs.getString(1);
				log.debug("STN: {}" , tn);
			}
			pstmt.close();
		} catch (SQLException e) {
			throw e;
		} finally {
			if (rs != null)
				rs.close();
			if (pstmt != null)
				pstmt.close();
		}

		log.info("Exit LocationUtil.getLocatoinSTN: {}" , tn);

		return tn;
	}
	
	public String getWorkingTN(Connection dbcon, String locationId)
			throws SQLException {
		log.info("Enter LocationUtil.getWorkingTN: {}" , locationId);

		String tn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		StringBuffer sql = new StringBuffer();

		sql.append("SELECT tn from tbl_public_tn_pool WHERE location_id= '")
				.append(locationId).append("'");
		sql.append(" AND ported_status <>").append(
				VzbVoipEnum.PortStatus.PORT_PENDING);
		sql.append(" AND rownum = 1");

		try {
			pstmt = dbcon.prepareStatement(sql.toString());
			rs = pstmt.executeQuery();
			if (rs.next()) {
				tn = rs.getString(1);
				log.debug("TN: {}" , tn);
			}
			pstmt.close();
		} catch (SQLException e) {
			throw e;
		} finally {
			if (rs != null)
				rs.close();
			if (pstmt != null)
				pstmt.close();
		}

		log.info("Exit LocationUtil.getWorkingTN: {}" , tn);

		return tn;
	}
}
