package com.vz.fxo.inventory.actionfunction.support;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import EsapEnumPkg.OrderLogEnum;
import EsapEnumPkg.VzbVoipEnum;

import com.vz.esap.common.database.logging.DatabaseLogging;
import  com.vz.fxo.inventory.tn.dao.model.TBlTerminatingRouting;
import  com.vz.fxo.inventory.tn.dao.model.TblTriTnData;

import esap.db.DBTblTsoEtTn;
import esap.db.DBTblTsoEtTnExcldFeatures;
import esap.db.DBTblTsoEtTnFeatures;
import esap.db.TblPublicTnPoolQuery;
import esap.db.TblTsoEtTnDbBean;
import esap.db.TblTsoEtTnQuery;
import esap.db.TblVzbFeaturesQuery;

public class TsoEtTn extends TsoEtTnBean {

	private static Logger log = LoggerFactory.getLogger(TsoEtTn.class.toString());

	private InvErrorCode status;
	Connection dbCon;
	String statusDesc;
	boolean rollbackFlag;
	boolean removeTnFlag;
	private boolean isExistingTn;
	InvErrorCode errstatus = InvErrorCode.INTERNAL_ERROR;

	private String orderClassify;
	private PublicTnPool publicTnPool;
	String portingFlag = null;
	String systemUpdate = null;
	String broadSoftTnActivation = null;
	String batchRange = null;
	private List<TsoEtTn> tsoEtTnList = null;
	private String locationId;
	private TblTriTnData triTnData = null;

	private DatabaseLogging databaseLogging = null;
	
	String originatingSystem = null;

	// private ActionFunctionSupport actionFunctionSupport;
	public TsoEtTn() {
		this.rollbackFlag = false;
		this.removeTnFlag = false;
		this.isExistingTn = false;
		this.dbCon = null;
	}
	
	public TsoEtTn(DatabaseLogging databaseLogging, Connection connection) {
		this.rollbackFlag = false;
		this.removeTnFlag = false;
		this.isExistingTn = false;
		this.dbCon = connection;
		this.databaseLogging = databaseLogging;
		// this.actionFunctionSupport = actionFunctionSupport;
	}

	public TsoEtTn(Connection dbCon) {
		this.rollbackFlag = false;
		this.removeTnFlag = false;
		this.isExistingTn = false;
		this.dbCon = dbCon;
	}

	public TsoEtTn(TsoEtTnBean etTnBean, Connection dbCon) {
		super(etTnBean);
		this.rollbackFlag = false;
		this.removeTnFlag = false;
		this.isExistingTn = false;
		this.dbCon = dbCon;
	}
	public String getOriginatingSystem() {
		return originatingSystem;
	}

	public void setOriginatingSystem(String originatingSystem) {
		this.originatingSystem = originatingSystem;
	}
	public TblTriTnData getTriTnData() {
		return triTnData;
	}

	public void setTriTnData(TblTriTnData triTnData) {
		this.triTnData = triTnData;
	}

	public String getLocationId() {
		return locationId;
	}

	public void setLocationId(String locationId) {
		this.locationId = locationId;
	}
	
	public String getBatchRange() {
		return batchRange;
	}

	public void setBatchRange(String batchRange) {
		this.batchRange = batchRange;
	}

	public InvErrorCode getStatus() {
		return status;
	}

	public boolean getIsExistingTn() {
		return isExistingTn;
	}

	public void setIsExistingTn(boolean isExistingTn) {
		this.isExistingTn = isExistingTn;
	}

	public boolean getRollbackFlag() {
		return rollbackFlag;
	}

	public void setRollbackFlag(boolean rollbackFlag) {
		this.rollbackFlag = rollbackFlag;
	}

	public boolean getRemoveTnFlag() {
		return removeTnFlag;
	}

	public void setRemoveTnFlag(boolean removeTnFlag) {
		this.removeTnFlag = removeTnFlag;
	}

	public void setStatus(InvErrorCode status) {
		this.status = status;
	}

	public Connection getDbCon() {
		return dbCon;
	}

	public void setDbCon(Connection dbCon) {
		this.dbCon = dbCon;
	}

	public void setStatusDesc(String statusDesc) {
		this.statusDesc = statusDesc;
	}

	public int getStatusCode() {
		return errstatus.getErrorCode();
	}

	public void setErrstatus(InvErrorCode status) {
		this.errstatus = status;
	}

	public String getStatusDesc() {
		return errstatus.getErrorDesc();
	}

	public String getOrderClassify() {
		return orderClassify;
	}

	public void setOrderClassify(String orderClassify) {
		this.orderClassify = orderClassify;
	}

	public List<TsoEtTn> getTsoEtTnList() {
		return tsoEtTnList;
	}

	public void setTsoEtTnList(List<TsoEtTn> tsoEtTnList) {
		this.tsoEtTnList = tsoEtTnList;
	}

	public PublicTnPool getPublicTnPool() {
		return publicTnPool;
	}

	public void setPublicTnPool(PublicTnPool publicTnPool) {
		this.publicTnPool = publicTnPool;
	}

	public String getPortingFlag() {
		return portingFlag;
	}

	public void setPortingFlag(String portingFlag) {
		this.portingFlag = portingFlag;
	}

	public String getSystemUpdate() {
		return systemUpdate;
	}

	public void setSystemUpdate(String systemUpdate) {
		this.systemUpdate = systemUpdate;
	}

	public String getBroadSoftTnActivation() {
		return broadSoftTnActivation;
	}

	public void setBroadSoftTnActivation(String broadSoftTnActivation) {
		this.broadSoftTnActivation = broadSoftTnActivation;
	}

	public boolean addToDB() throws SQLException, Exception {

		DBTblTsoEtTn TsoEbiDbBean = new DBTblTsoEtTn();
		if (getEtTnId() > 0) {
			TsoEbiDbBean.setEtTnId(getEtTnId());
		} else {
			long etTnId = TsoEbiDbBean.getEtTnIdSeqNextVal(dbCon);
			setEtTnId(etTnId);
		}
		TsoEbiDbBean.setEnterpriseTrunkId(enterpriseTrunkId);
		if (getTnPoolId() > 0) {
			TsoEbiDbBean.setTnPoolId(getTnPoolId());
		} else if (!addToPublicTnPool()) {
			setErrstatus(InvErrorCode.DB_EXCEPTION);
			System.out.println("INV_FAILURE in addToDB TsoEtTn.Failed to ADD Public Tn Pool");
			return false;
		}
		log.info("TnPoolId = " + getTnPoolId());

		if (getTnPoolId() > 0) {
			TsoEbiDbBean.setTnPoolId(getTnPoolId());
		}

		if (!"NONE".equals(getPrivateNumber())) {
			TsoEbiDbBean.setPrivateNumber(getPrivateNumber());
		}
		if (!"".equals(getExtension()) && !"NONE".equals(getExtension())) {
			TsoEbiDbBean.setExtension(getExtension());
		}

		if (!"NONE".equals(getClidFirstName())) {
			TsoEbiDbBean.setClidFirstName(getClidFirstName());
		}

		if (!"NONE".equals(getClidLastName())) {
			TsoEbiDbBean.setClidLastName(getClidLastName());
		}

		if (!"NONE".equals(getVmBoxNum()))
			TsoEbiDbBean.setVmBoxNum(getVmBoxNum());

		if (getEnvOrderId() > 0)
			TsoEbiDbBean.setEnvOrderId(getEnvOrderId());
		else
			TsoEbiDbBean.setEnvOrderIdNull();
		if (getSubId().equals("NONE"))
			TsoEbiDbBean.setSubIdNull();
		else
			TsoEbiDbBean.setSubId(getSubId());
		long vmxSize = getVmMaxsizeId();
		if (vmxSize < 0)
			TsoEbiDbBean.setVmMaxsizeId(0);
		else
			TsoEbiDbBean.setVmMaxsizeId(getVmMaxsizeId());

		TsoEbiDbBean.setActiveInd(activeInd);
		if (pitSipTrxId == -1) {
			TsoEbiDbBean.setPitSipTrxId(0);
		} else {
			TsoEbiDbBean.setPitSipTrxId(pitSipTrxId);

		}
		TsoEbiDbBean.setCreatedBy(createdBy);
		TsoEbiDbBean.setModifiedBy(modifiedBy);
		TsoEbiDbBean.setLastModifiedDate(new Timestamp(System.currentTimeMillis()));
		TsoEbiDbBean.setCreationDate(new Timestamp(System.currentTimeMillis()));
		TsoEbiDbBean.insert(dbCon);

		for (int k = 0; k < etTnExclFeaturesList.size(); k++) {
			TblVzbFeaturesQuery vzbFeatQry = new TblVzbFeaturesQuery();
			vzbFeatQry.whereNameEQ(((etTnExclFeaturesList.get(k)).getFeaturesDbBean()).getName());
			vzbFeatQry.whereFeatureTypeNE("C");
			vzbFeatQry.query(dbCon);
			if (vzbFeatQry.size() == 1) {
				DBTblTsoEtTnExcldFeatures etTnExcldFeat = new DBTblTsoEtTnExcldFeatures();
				etTnExcldFeat.setEtTnExcldFeatureId(etTnExcldFeat.getEtTnExcldFeatureIdSeqNextVal(dbCon));
				etTnExcldFeat.setEtTnId(TsoEbiDbBean.getEtTnId());
				etTnExcldFeat.setFeatureId((vzbFeatQry.getDbBean(0)).getFeatureId());
				if (getEnvOrderId() > 0)
					etTnExcldFeat.setEnvOrderId(getEnvOrderId());
				else
					etTnExcldFeat.setEnvOrderIdNull();
				if (getCreatedBy() != null && !getCreatedBy().equals(""))
					etTnExcldFeat.setCreatedBy(getCreatedBy());
				else
					etTnExcldFeat.setCreatedBy("ESAP_INV");
				if (getModifiedBy() != null && !getModifiedBy().equals(""))
					etTnExcldFeat.setModifiedBy(getModifiedBy());
				else
					etTnExcldFeat.setModifiedBy("ESAP_INV");
				etTnExcldFeat.setLastModifiedDate(new Timestamp(System.currentTimeMillis()));
				etTnExcldFeat.setCreationDate(new Timestamp(System.currentTimeMillis()));
				etTnExcldFeat.insert(dbCon);
			} else {
				System.out.println("Valid Excluded feature not found in the db"
						+ ((etTnExclFeaturesList.get(k)).getFeaturesDbBean()).getName());
				return false;
			}

		}

		for (int i = 0; i < getEtTnFeaturesList().size(); i++) {
			TsoEtTnFeaturesBean etTnBean = getEtTnFeaturesList().get(i);
			DBTblTsoEtTnFeatures etTnFeaturesDbObj = new DBTblTsoEtTnFeatures();
			etTnFeaturesDbObj.setEtTnFeatureId(etTnFeaturesDbObj.getEtTnFeatureIdSeqNextVal(dbCon));
			etTnFeaturesDbObj.setEtTnId(TsoEbiDbBean.getEtTnId());
			etTnFeaturesDbObj.setFeatureId(etTnBean.getFeatureId());
			etTnFeaturesDbObj.setCreatedBy("ESAP_INV");
			etTnFeaturesDbObj.setCreationDate(new Timestamp(System.currentTimeMillis()));
			etTnFeaturesDbObj.setModifiedBy("ESAP_INV");
			etTnFeaturesDbObj.setLastModifiedDate(new Timestamp(System.currentTimeMillis()));
			etTnFeaturesDbObj.setEnvOrderId(etTnBean.getEnvOrderId());

			etTnFeaturesDbObj.insert(dbCon);
		}
		return true;
	}

	public boolean addToPublicTnPool() throws Exception, SQLException {
		log.info("Entering TsoEtTn::addToPublicTnPool");
		if (getPublicTnPoolObj().getTnPoolId() > 0) {
			log.info("TnPool Id found. Skip Tn Pool Insert");
			setTnPoolId(getPublicTnPoolObj().getTnPoolId());
			return true;
		}
		if (getPublicTnPoolObj().getTn().equals("")) {
			log.info("No Public Tn Found.");
			return false;
		}
		PublicTnPool pubTnObj = new PublicTnPool(dbCon, getPublicTnPoolObj());

		// APAC LNP sep 2011
		try {
			PublicTnPool pubTnObjToGetPorting = (PublicTnPool) getPublicTnPoolObj();
			pubTnObj.setTnPorting(pubTnObjToGetPorting.getTnPorting());
			log.info("TsoEtTn::addToPublicTnPool() : tn porting object is set");
		} catch (ClassCastException cce) {
			log.info("Exception while casting PublicTnPoolBean into PublicTnPool.");
			throw cce;
		}

		if (!pubTnObj.addPublicTnPool()) {
			log.info("Failed to Add Tn to Public Tn Pool");
			return false;
		}
		setTnPoolId(pubTnObj.getTnPoolId());
		log.info("TnPoolId = " + pubTnObj.getTnPoolId());
		log.info("Successfully inserted Public TN Pool");
		return true;
	}

	public void updateTNMigStatus(String tsoLocId) throws Exception {
		log.info(" In updateTNMigStatus " + tsoLocId);
		String dnrLocId = null;
		String lsTNQry = "SELECT COUNT(*) FROM TBL_PUBLIC_TN_POOL WHERE LOCATION_ID = ?";
		String lsUpdMigStatQry = "UPDATE TBL_TSO_ENTITY_MIGRATION SET MIGRATION_STATUS = '" + VzbVoipEnum.TsoMigrationStatus.TN_MIGRATION
				+ "' WHERE LOCATION_ID = ?";
		PreparedStatement ps = null;
		PreparedStatement prst = null;
		ResultSet selRs = null;
		int count = -1;
		try {
			prst = dbCon.prepareStatement(lsTNQry);
			prst.setString(1, tsoLocId);
			selRs = prst.executeQuery();
			while (selRs.next()) {
				log.info(" TN Pool query resultset ");
				count = selRs.getInt(1);
			}
			if (count > 1) {
				log.info(" Found TNs for new loc in tn pool table");
				dnrLocId = getDonorLoc(tsoLocId);
				ps = dbCon.prepareStatement(lsUpdMigStatQry);
				ps.setString(1, dnrLocId);
				ps.executeUpdate();
				log.info(" status update done for TN_MIGRATION ");
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (selRs != null) {
				selRs.close();
			}
			if (prst != null) {
				prst.close();
			}
			if (ps != null) {
				ps.close();
			}
		}
	}

	public String getDonorLoc(String recLocId) throws Exception {
		log.info(" In getDonorLoc " + recLocId);
		String lsDonorQry = "SELECT LOCATION_ID FROM TBL_TSO_ENTITY_MIGRATION WHERE TSO_LOCATION_ID = '" + recLocId + "'";
		String oldLoc = null;
		PreparedStatement pstmt = null;
		ResultSet res = null;
		try {
			pstmt = dbCon.prepareStatement(lsDonorQry);
			res = pstmt.executeQuery();
			while (res.next()) {
				oldLoc = res.getString(1);
				if (oldLoc != null && oldLoc.trim().length() > 0) {
					log.info(" oldLoc " + oldLoc);
					break;
				}

			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (res != null) {
				res.close();
			}
			if (pstmt != null) {
				pstmt.close();
			}
		}
		return oldLoc;
	}

	public void updateLecBtnMigStatus(String locationId, String TN, int status) throws Exception {
		// VzbVoipEnum.LecBtnMigStatus.TN_MIG_COMPLETED
		if(locationId != null && TN != null){
			String tnNoCntryCode = removeCountryCode(locationId, TN);
			log.info(" In updateLecBtnMigStatus " + TN);
			String lsUpdMigStatQry = "UPDATE tbl_ipro_lecbtn_mappings SET MIG_STATUS = " + status + " WHERE TN = ?";
			PreparedStatement ps = null;
			try {
				ps = dbCon.prepareStatement(lsUpdMigStatQry);
				ps.setString(1, tnNoCntryCode);
				ps.executeUpdate();
				log.info(" status update done for tbl_ipro_lecbtn_mappings for TN " + tnNoCntryCode);
	
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				if (ps != null) {
					ps.close();
				}
			}
		}
	}

	public String removeCountryCode(String locationId, String TN) {
		String cntryCode = getLocationCodeFromTn(locationId);
		if (cntryCode != null && TN != null) {
			log.info("[removeCountryCode] TN" + TN);
			boolean isValid = TN.startsWith(cntryCode);
			int index = TN.indexOf(cntryCode);
			if (index >= 0 && isValid) {
				TN = TN.substring(index + cntryCode.length(), TN.length());
				log.info("[removeCountryCode] TN" + TN.toString());
			}
		}
		log.info("[removeCountryCode] resTN" + TN.toString());
		return TN;
	}

	public String getLocationCodeFromTn(String locationId) {
		log.info("getLocationCodeFromTn " + locationId);
		Statement stmt = null;
		ResultSet rs = null;
		String cntryCode = null;
		String sql = "select dialing_country_code from tbl_location tl,tbl_public_tn_pool tn where tl.location_id=tn.location_id "
				+ " and tl.location_id='" + locationId + "'";

		try {
			stmt = dbCon.createStatement();
			rs = stmt.executeQuery(sql);

			while (rs.next()) {
				cntryCode = rs.getString("dialing_country_code");
			}
			log.info("cntryCode" + cntryCode);
		} catch (Exception e) {
			e.printStackTrace();

		} finally {
			try {
				if (rs != null)
					rs.close();
				if (stmt != null)
					stmt.close();
			} catch (Exception se) {

				se.printStackTrace();
			}
		}
		return cntryCode;
	}

	public void processBulkETTNAdd(List<TsoEtTn> tsoEtTnList, Connection connection) throws SQLException, VzbInvException, Exception {
		// Steps in this methods
		// 1.Add TNs to Public TN Pool
		// 2.Add ET TNs to TSO ET TN
		// 3.Add Exclude TN features List to TsoEtTnExcldFeatures
		// 4.Add ET TN features to TsoEtTnFeatures
		// 5.Add ET TN to TRI

		// HashMap<String, TsoEtTn> erroredTsoEtTnMap = new HashMap<String,
		// TsoEtTn>();

		// 1. Add to Public TN Pool if TNPoolID does't exist in ESAP
		for (TsoEtTn tsoEtTn : tsoEtTnList) {
			if (tsoEtTn.getTnPoolId() > 0 && isTnPoolIdExist(tsoEtTn.getTnPoolId(), connection)) {
				// TN Pool ID already exist. No need to add TN to public TN pool
				log.info("TEST - TN Pool ID already exist :" + tsoEtTn.getTnPoolId());
			} else {
				try {
					tsoEtTn.setDbCon(connection);
					if (!tsoEtTn.addToPublicTnPool()) {
						tsoEtTn.setErrstatus(InvErrorCode.DB_EXCEPTION);
						// erroredTsoEtTnMap.put(tsoEtTn.getEtTnId() + "",
						// tsoEtTn);
					}
				} catch (SQLException e) {
					log.info("ERROR: SQL Exception caught while addting TN : " + tsoEtTn.getPublicTnPoolObj().getTn()
							+ " to Public TN Pool");
					e.printStackTrace();
					throw new Exception("ERROR: SQL Exception caught while addting TN : " + tsoEtTn.getPublicTnPoolObj().getTn()
							+ " to Public TN Pool");
				} catch (Exception e) {
					log.info("ERROR: Exception caught while addting TN : " + tsoEtTn.getPublicTnPoolObj().getTn() + " to Public TN Pool");
					e.printStackTrace();
					throw new Exception("ERROR: Exception caught while addting TN : " + tsoEtTn.getPublicTnPoolObj().getTn()
							+ " to Public TN Pool");
				}
			}
		}

		// 2.Add ET TN to TSO ET TN
		etTnBatchInsert(connection, tsoEtTnList);

		// 3.Add Exclude TN features List to TsoEtTnExcldFeatures
		etTnExcludingFeaturesInsert(connection, tsoEtTnList);

		// 4.Add ET TN features to TsoEtTnFeatures
		etTnFeaturesInsert(connection, tsoEtTnList);

		// 5.Process By Order Classify
		processAddEtTnByOrderClassify(connection, tsoEtTnList);

		// 6.Update LEC BTN status
		processLecBtnMigStatus(connection, tsoEtTnList);

		// return erroredTsoEtTnMap;
	}

	public void processBulkPortPendingETTNAdd(List<TsoEtTn> tsoEtTnList, Connection connection) throws SQLException, VzbInvException,
			Exception {
		// Steps in this methods
		// 1.Add TNs to Public TN Pool
		// 2.Add ET TNs to TSO ET TN
		// 3.Add Exclude TN features List to TsoEtTnExcldFeatures
		// 4.Add ET TN features to TsoEtTnFeatures
		// 5.Add ET TN to TRI

		HashMap<String, TsoEtTn> erroredTsoEtTnMap = new HashMap<String, TsoEtTn>();

		// 1. Add to Public TN Pool if TNPoolID does't exist in ESAP
		for (TsoEtTn tsoEtTn : tsoEtTnList) {
			if (tsoEtTn.getTnPoolId() > 0 && isTnPoolIdExist(tsoEtTn.getTnPoolId(), connection)) {
				// TN Pool ID already exist. No need to add TN to public TN pool
				log.info("TEST - TN Pool ID already exist :" + tsoEtTn.getTnPoolId());
			} else {
				try {
					if (!tsoEtTn.addToPublicTnPool()) {
						tsoEtTn.setErrstatus(InvErrorCode.DB_EXCEPTION);
						erroredTsoEtTnMap.put(tsoEtTn.getEtTnId() + "", tsoEtTn);
					}
				} catch (SQLException e) {
					log.info("ERROR: SQL Exception caught while addting TN : " + tsoEtTn.getPublicTnPoolObj().getTn()
							+ " to Public TN Pool");
					e.printStackTrace();
				} catch (Exception e) {
					log.info("ERROR: Exception caught while addting TN : " + tsoEtTn.getPublicTnPoolObj().getTn() + " to Public TN Pool");
					e.printStackTrace();
				}
			}
		}

		// 2.Add ET TN to TSO ET TN
		etTnBatchInsert(connection, tsoEtTnList);

		// 3.Add Exclude TN features List to TsoEtTnExcldFeatures
		etTnExcludingFeaturesInsert(connection, tsoEtTnList);

		// 4.Add ET TN features to TsoEtTnFeatures
		etTnFeaturesInsert(connection, tsoEtTnList);

		// 5.Process By Order Classify
		processAddEtTnByOrderClassify(connection, tsoEtTnList);

		// return erroredTsoEtTnMap;
	}

	private boolean isTnPoolIdExist(long tnPoolId, Connection connection) {
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		String selectSQL = "select count(*) from TBL_PUBLIC_TN_POOL where TN_POOL_ID=?";
		boolean tnPoolExist = false;
		try {
			preparedStatement = connection.prepareStatement(selectSQL);
			preparedStatement.setLong(1, tnPoolId);

			resultSet = preparedStatement.executeQuery();
			int count = 0;
			while (resultSet.next()) {
				count = resultSet.getInt(1);
				if (count > 0) {
					tnPoolExist = true;
				}
			}

		} catch (SQLException e) {
			e.printStackTrace();
			log.error("failed to check isTnPoolIdExist ");
		} finally {
			try {
				if (resultSet != null) {
					resultSet.close();
					resultSet = null;
				}
				if (preparedStatement != null) {
					preparedStatement.close();
					preparedStatement = null;
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return tnPoolExist;
	}

	private void etTnBatchInsert(Connection connection, List<TsoEtTn> tsoEtTnList) throws Exception {
		PreparedStatement preparedStatement = null;
		String insertTableSQL = "INSERT INTO TBL_TSO_ET_TN(ET_TN_ID,ENTERPRISE_TRUNK_ID,TN_POOL_ID,EXTENSION,PRIVATE_NUMBER,CLID_FIRST_NAME,"
				+ "CLID_LAST_NAME,VM_MAXSIZE_ID,VM_BOX_NUM,ACTIVE_IND,ENV_ORDER_ID,SUB_ID,PIT_SIP_TRX_ID,CREATED_BY,CREATION_DATE,MODIFIED_BY,LAST_MODIFIED_DATE) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,sysdate,?,sysdate)";
		try {
			preparedStatement = connection.prepareStatement(insertTableSQL);
			String orderClassifyVal = "";
			boolean executeBatch = false;
			int rowCount = 0;
			for (TsoEtTn tsoEtTn : tsoEtTnList) {
				// if (!erroredTsoEtTnMap.containsKey(tsoEtTn.getEtTnId() + ""))
				// {// excluding
				// errored
				orderClassifyVal = tsoEtTn.getOrderClassify();
				if (!(orderClassifyVal.equals("LNP_ACTIVATE") || orderClassifyVal.equals("TN_ACTIVATE"))) {
					executeBatch = true;
					preparedStatement.setLong(1, tsoEtTn.getEtTnId());
					preparedStatement.setLong(2, tsoEtTn.getEnterpriseTrunkId());
					preparedStatement.setLong(3, tsoEtTn.getTnPoolId());
					preparedStatement.setString(4, tsoEtTn.getExtension());
					preparedStatement.setString(5, tsoEtTn.getPrivateNumber());
					preparedStatement.setString(6, tsoEtTn.getClidFirstName());
					preparedStatement.setString(7, tsoEtTn.getClidLastName());
					preparedStatement.setLong(8, tsoEtTn.getVmMaxsizeId());
					preparedStatement.setString(9, tsoEtTn.getVmBoxNum());
					preparedStatement.setLong(10, tsoEtTn.getActiveInd());
					preparedStatement.setLong(11, tsoEtTn.getEnvOrderId());
					preparedStatement.setString(12, tsoEtTn.getSubId());
					preparedStatement.setInt(13, tsoEtTn.getPitSipTrxId());
					preparedStatement.setString(14, tsoEtTn.getCreatedBy());
					// preparedStatement.setTimestamp(15,
					// tsoEtTn.getCreationDate());
					preparedStatement.setString(15, tsoEtTn.getModifiedBy());
					// preparedStatement.setTimestamp(17,
					// tsoEtTn.getLastModifiedDate());

					preparedStatement.addBatch();
					rowCount++;
				}
				// }
			}
			if (executeBatch) {
				preparedStatement.executeBatch();
			}
			// log.info("TblTsoEtTn data inserted. Total rows inserted :" +
			// (tsoEtTnList.size() - erroredTsoEtTnMap.size()));
			log.info("TblTsoEtTn data inserted. Total rows inserted :" + rowCount);
		} catch (SQLException e) {
			e.printStackTrace();
			log.error("TblTsoEtTn data insertion failed. ");
			throw new Exception("TblTsoEtTn data insertion failed.");
		} finally {
			if (preparedStatement != null) {
				try {
					preparedStatement.close();
					preparedStatement = null;
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}

	private void etTnExcludingFeaturesInsert(Connection connection, List<TsoEtTn> tsoEtTnList) throws Exception {
		PreparedStatement preparedStatement = null;
		String insertTableSQL = "INSERT INTO TBL_TSO_ET_TN_EXCLD_FEATURES(ET_TN_EXCLD_FEATURE_ID,ET_TN_ID,FEATURE_ID,CREATED_BY,CREATION_DATE,MODIFIED_BY,LAST_MODIFIED_DATE,ENV_ORDER_ID) VALUES (ET_TN_EXCLD_FEATURE_ID_SEQ.NEXTVAL,?,?,?,sysdate,?,sysdate,?)";
		try {
			preparedStatement = connection.prepareStatement(insertTableSQL);
			String orderClassifyVal = "";
			boolean executeBatch = false;
			int rowCount = 0;
			for (TsoEtTn tsoEtTn : tsoEtTnList) {
				// if (!erroredTsoEtTnMap.containsKey(tsoEtTn.getEtTnId() + ""))
				// {// excluding
				// errored
				// TNs
				orderClassifyVal = tsoEtTn.getOrderClassify();
				if (!(orderClassifyVal.equals("LNP_ACTIVATE") || orderClassifyVal.equals("TN_ACTIVATE"))) {
					executeBatch = true;
					for (int k = 0; k < tsoEtTn.getEtTnExclFeaturesList().size(); k++) {
						TblVzbFeaturesQuery vzbFeatQry = new TblVzbFeaturesQuery();
						vzbFeatQry.whereNameEQ(((tsoEtTn.getEtTnExclFeaturesList().get(k)).getFeaturesDbBean()).getName());
						vzbFeatQry.whereFeatureTypeNE("C");
						vzbFeatQry.query(connection);
						if (vzbFeatQry.size() == 1) {
							/*
							 * DBTblTsoEtTnExcldFeatures etTnExcldFeat = new
							 * DBTblTsoEtTnExcldFeatures();
							 * etTnExcldFeat.setEtTnExcldFeatureId(etTnExcldFeat
							 * .getEtTnExcldFeatureIdSeqNextVal(dbCon));
							 * etTnExcldFeat.setEtTnId(tsoEtTn.getEtTnId());
							 * etTnExcldFeat
							 * .setFeatureId((vzbFeatQry.getDbBean(0))
							 * .getFeatureId()); if (getEnvOrderId() > 0)
							 * etTnExcldFeat.setEnvOrderId(getEnvOrderId());
							 * else etTnExcldFeat.setEnvOrderIdNull(); if
							 * (getCreatedBy() != null &&
							 * !getCreatedBy().equals(""))
							 * etTnExcldFeat.setCreatedBy(getCreatedBy()); else
							 * etTnExcldFeat.setCreatedBy("ESAP_INV"); if
							 * (getModifiedBy() != null &&
							 * !getModifiedBy().equals(""))
							 * etTnExcldFeat.setModifiedBy(getModifiedBy());
							 * else etTnExcldFeat.setModifiedBy("ESAP_INV");
							 * etTnExcldFeat.setLastModifiedDate(new
							 * Timestamp(System .currentTimeMillis()));
							 * etTnExcldFeat.setCreationDate(new
							 * Timestamp(System .currentTimeMillis()));
							 * etTnExcldFeat.insert(dbCon);
							 */
							preparedStatement.setLong(1, tsoEtTn.getEtTnId());
							preparedStatement.setLong(2, (vzbFeatQry.getDbBean(0)).getFeatureId());

							if (tsoEtTn.getCreatedBy() != null && !tsoEtTn.getCreatedBy().equals("")) {
								preparedStatement.setString(3, tsoEtTn.getCreatedBy());
							} else {
								preparedStatement.setString(3, "ESAP_INV");
							}
							if (tsoEtTn.getModifiedBy() != null && !tsoEtTn.getModifiedBy().equals("")) {
								preparedStatement.setString(4, tsoEtTn.getModifiedBy());
							} else {
								preparedStatement.setString(4, "ESAP_INV");
							}

							if (tsoEtTn.getEnvOrderId() > 0) {
								preparedStatement.setLong(5, tsoEtTn.getEnvOrderId());
							} else {
								preparedStatement.setLong(5, -1);
							}

							preparedStatement.addBatch();
						} /*
						 * else { System.out.println(
						 * "Valid Excluded feature not found in the db" +
						 * ((etTnExclFeaturesList.get(k)).getFeaturesDbBean())
						 * .getName()); return false; }
						 */

					}
					rowCount++;
				}
				// }

			}

			if (executeBatch) {
				preparedStatement.executeBatch();
			}
			// log.info("TblTsoEtTnExcldFeatures data inserted. Total rows inserted :"
			// + (tsoEtTnList.size() - erroredTsoEtTnMap.size()));
			log.info("TblTsoEtTnExcldFeatures data inserted. Total rows inserted :" + rowCount);

		} catch (SQLException e) {
			e.printStackTrace();
			log.error("TblTsoEtTnExcldFeatures data insertion failed. ");
			throw new Exception("TblTsoEtTnExcldFeatures data insertion failed");
		} finally {
			if (preparedStatement != null) {
				try {
					preparedStatement.close();
					preparedStatement = null;
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}

	private void etTnFeaturesInsert(Connection connection, List<TsoEtTn> tsoEtTnList) throws Exception {
		PreparedStatement preparedStatement = null;
		String insertTableSQL = "INSERT INTO TBL_TSO_ET_TN_FEATURES(ET_TN_FEATURE_ID,ET_TN_ID,FEATURE_ID,CREATED_BY,CREATION_DATE,MODIFIED_BY,LAST_MODIFIED_DATE,ENV_ORDER_ID) VALUES (ET_TN_FEATURE_ID_SEQ.NEXTVAL,?,?,?,sysdate,?,sysdate,?)";
		try {
			preparedStatement = connection.prepareStatement(insertTableSQL);
			String orderClassifyVal = "";
			boolean executeBatch = false;
			int rowCount = 0;
			for (TsoEtTn tsoEtTn : tsoEtTnList) {
				// if (!erroredTsoEtTnMap.containsKey(tsoEtTn.getEtTnId() + ""))
				// {// excluding
				// errored
				// TNs
				if (!(orderClassifyVal.equals("LNP_ACTIVATE") || orderClassifyVal.equals("TN_ACTIVATE"))) {
					executeBatch = true;
					for (int i = 0; i < tsoEtTn.getEtTnFeaturesList().size(); i++) {
						TsoEtTnFeaturesBean etTnBean = tsoEtTn.getEtTnFeaturesList().get(i);
						/*
						 * DBTblTsoEtTnFeatures etTnFeaturesDbObj = new
						 * DBTblTsoEtTnFeatures();
						 * etTnFeaturesDbObj.setEtTnFeatureId(etTnFeaturesDbObj
						 * .getEtTnFeatureIdSeqNextVal(dbCon));
						 * etTnFeaturesDbObj.setEtTnId(tsoEtTn.getEtTnId());
						 * etTnFeaturesDbObj
						 * .setFeatureId(etTnBean.getFeatureId());
						 * etTnFeaturesDbObj.setCreatedBy("ESAP_INV");
						 * etTnFeaturesDbObj.setCreationDate(new
						 * Timestamp(System .currentTimeMillis()));
						 * etTnFeaturesDbObj.setModifiedBy("ESAP_INV");
						 * etTnFeaturesDbObj.setLastModifiedDate(new
						 * Timestamp(System .currentTimeMillis()));
						 * etTnFeaturesDbObj
						 * .setEnvOrderId(etTnBean.getEnvOrderId());
						 * 
						 * etTnFeaturesDbObj.insert(dbCon);
						 */

						preparedStatement.setLong(1, tsoEtTn.getEtTnId());
						preparedStatement.setLong(2, etTnBean.getFeatureId());

						if (tsoEtTn.getCreatedBy() != null && !tsoEtTn.getCreatedBy().equals("")) {
							preparedStatement.setString(3, tsoEtTn.getCreatedBy());
						} else {
							preparedStatement.setString(3, "ESAP_INV");
						}
						if (tsoEtTn.getModifiedBy() != null && !tsoEtTn.getModifiedBy().equals("")) {
							preparedStatement.setString(4, tsoEtTn.getModifiedBy());
						} else {
							preparedStatement.setString(4, "ESAP_INV");
						}
						if (tsoEtTn.getEnvOrderId() > 0) {
							preparedStatement.setLong(5, tsoEtTn.getEnvOrderId());
						} else {
							preparedStatement.setLong(5, -1);
						}
					}
					rowCount++;
				}
				// }
			}
			if (executeBatch) {
				preparedStatement.executeBatch();
			}

			// log.info("TblTsoEtTnFeatures data inserted. Total rows inserted :"
			// + (tsoEtTnList.size() - erroredTsoEtTnMap.size()));
			log.info("TblTsoEtTnFeatures data inserted. Total rows inserted :" + rowCount);

		} catch (SQLException e) {
			e.printStackTrace();
			log.error("TblTsoEtTnFeatures data insertion failed. ");
			throw new Exception("TblTsoEtTnFeatures data insertion failed.");
		} finally {
			if (preparedStatement != null) {
				try {
					preparedStatement.close();
					preparedStatement = null;
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}

	public void processAddEtTnByOrderClassify(Connection connection, List<TsoEtTn> tsoEtTnList) throws SQLException, VzbInvException,
			Exception {
		String orderClassify = null;
		try {
			PublicTnPool pubTnBeanObj = null;
			// VZB_INV_ADD_ET_TN actionFunctionSupport = new
			// VZB_INV_ADD_ET_TN();
			this.dbCon = connection;
			boolean triSynchComplete = false;
			for (TsoEtTn tsoEtTn : tsoEtTnList) {
				// if (!erroredTsoEtTnMap.containsKey(tsoEtTn.getEtTnId() + ""))
				// {// excluding
				// errored
				// TNs
				orderClassify = tsoEtTn.getOrderClassify();
				pubTnBeanObj = tsoEtTn.getPublicTnPool();
				portingFlag = tsoEtTn.getPortingFlag();

				pubTnBeanObj.setConnection(connection);
				tsoEtTn.setDbCon(connection);

				TblTriTnData triDataBean = new TblTriTnData();

				triDataBean.setTnId(1L);// some dummy number. it will be
										// taken from sequence
				triDataBean.setDialPlanId(pubTnBeanObj.getDialPlanId());
				triDataBean.setLocationId(pubTnBeanObj.getLocationId());
				triDataBean.setNoa(pubTnBeanObj.getNoa());
				triDataBean.setTn(pubTnBeanObj.getTn());
				
				if(!triSynchComplete){
					//Commented since we introduced stored procs to take care of TRI
					//triDataSynch(triDataBean);
					triSynchComplete = true;
				}

				if (!"NONE".equals(pubTnBeanObj.getP1url()) && !"".equals(pubTnBeanObj.getP1url())) {
					triDataBean.setP1url(pubTnBeanObj.getP1url());
				}
				if (!"NONE".equals(pubTnBeanObj.getPringtime()) && !"".equals(pubTnBeanObj.getPringtime())) {
					triDataBean.setPringtime(pubTnBeanObj.getPringtime());
				}
				if (!"NONE".equals(pubTnBeanObj.getPtrid()) && !"".equals(pubTnBeanObj.getPtrid())) {
					triDataBean.setPtrid(pubTnBeanObj.getPtrid());
				}
				if (!"NONE".equals(pubTnBeanObj.getPprefixdgts()) && !"".equals(pubTnBeanObj.getPprefixdgts())) {
					triDataBean.setPprefixdgts(pubTnBeanObj.getPprefixdgts());
				}
				if (pubTnBeanObj.getPsuffixnum() != -1) {
					triDataBean.setPsuffixnum(pubTnBeanObj.getPsuffixnum());
				}
				if (!"NONE".equals(pubTnBeanObj.getA1url()) && !"".equals(pubTnBeanObj.getA1url())) {
					triDataBean.setA1url(pubTnBeanObj.getA1url());
				}
				if (!"NONE".equals(pubTnBeanObj.getA1ringtime()) && !"".equals(pubTnBeanObj.getA1ringtime())) {
					triDataBean.setA1ringtime(pubTnBeanObj.getA1ringtime());
				}
				if (!"NONE".equals(pubTnBeanObj.getA1trid()) && !"".equals(pubTnBeanObj.getA1trid())) {
					triDataBean.setA1trid(pubTnBeanObj.getA1trid());
				}
				if (!"NONE".equals(pubTnBeanObj.getA1prefixdgts()) && !"".equals(pubTnBeanObj.getA1prefixdgts())) {
					triDataBean.setA1prefixdgts(pubTnBeanObj.getA1prefixdgts());
				}
				if (pubTnBeanObj.getA1suffixnum() != -1) {
					triDataBean.setA1suffixnum(pubTnBeanObj.getA1suffixnum());
				}
				if (!"NONE".equals(pubTnBeanObj.getA2url()) && !"".equals(pubTnBeanObj.getA2url())) {
					triDataBean.setA2url(pubTnBeanObj.getA2url());
				}
				if (!"NONE".equals(pubTnBeanObj.getA2ringtime()) && !"".equals(pubTnBeanObj.getA2ringtime())) {
					triDataBean.setA2ringtime(pubTnBeanObj.getA2ringtime());
				}
				if (!"NONE".equals(pubTnBeanObj.getA2trid()) && !"".equals(pubTnBeanObj.getA2trid())) {
					triDataBean.setA2trid(pubTnBeanObj.getA2trid());
				}
				if (!"NONE".equals(pubTnBeanObj.getA2prefixdgts()) && !"".equals(pubTnBeanObj.getA2prefixdgts())) {
					triDataBean.setA2prefixdgts(pubTnBeanObj.getA2prefixdgts());
				}
				if (pubTnBeanObj.getA2suffixnum() != -1) {
					triDataBean.setA2suffixnum(pubTnBeanObj.getA2suffixnum());
				}
				if (pubTnBeanObj.getEnvOrderId() > 0) {
					triDataBean.setEnvOrderId(pubTnBeanObj.getEnvOrderId());
				} else {
					triDataBean.setEnvOrderId(-1L);
				}

				if (!pubTnBeanObj.getCreatedBy().equals("")) {
					triDataBean.setCreatedBy(pubTnBeanObj.getCreatedBy());
				} else {
					triDataBean.setCreatedBy("ESAP_INV");
				}
				if (!pubTnBeanObj.getModifiedBy().equals("")) {
					triDataBean.setModifiedBy(pubTnBeanObj.getModifiedBy());
				} else {
					triDataBean.setModifiedBy("ESAP_INV");
				}

				triDataBean.setEnvOrderId(pubTnBeanObj.getEnvOrderId());

				if (orderClassify.equals("LNP_ACTIVATE") || orderClassify.equals("TN_ACTIVATE")) {

					pubTnBeanObj.setTnStatus(VzbVoipEnum.TnStatus.ASSIGNED);
					pubTnBeanObj.setTnType(VzbVoipEnum.TnType.ET);
					// if (pubTnBeanObj.getPortedStatus().equals("" +
					// VzbVoipEnum.PortStatus.PORT_PENDING))
					pubTnBeanObj.setPortedStatus("" + VzbVoipEnum.PortStatus.PORTED);

					if (pubTnBeanObj.updatePublicTnPool()) {
						// insertOrderLog(INV_SUCCESS,
						// "Successfully added PBX Group in ESAP inventory");
						databaseLogging.setOrderLog("Successfully added ET TN in ESAP inventory", OrderLogEnum.EventType.INFORMATION);
					} else {
						databaseLogging.setOrderLog("Inventory Base Returned Error ::" + pubTnBeanObj.getStatusDesc() + "::",
								OrderLogEnum.EventType.ESAP_ERROR);
						log.info("Inventory Base Returned Error <" + pubTnBeanObj.getStatusDesc() + ">");
						connection.rollback();
						throw new VzbInvException("ESP_VZB_INV_ADD_ET_TN_FAILED", "ESP_VZB_INV_ADD_ET_TN_FAILED");
					}

					//Commented since we introduced stored procs to take care of TRI
					//addTri(triDataBean);

				} else if (orderClassify.equals("RELEASE") && portingFlag.equals("Y")) {
					log.info("In OrderClassify-RELEASE and PortingFlag-Y - updating Public TN Pool data");
					pubTnBeanObj.setTnStatus(VzbVoipEnum.TnStatus.ASSIGNED);
					pubTnBeanObj.setTnType(VzbVoipEnum.TnType.ET);
					log.info("In OrderClassify-RELEASE and PortingFlag-Y - Before calling addToDB");
					/*
					 * if (tsoEtTn.addToDB()) { log.info(
					 * "In OrderClassify-RELEASE and PortingFlag-Y - in addToDB IF"
					 * ); databaseLogging.addTrailList(tsoEtTn.getLogTrail(),
					 * OrderLogEnum.EventType.INFORMATION);
					 * databaseLogging.setOrderLog
					 * ("Successfully added Enterprise Trunk TN in ESAP inventory"
					 * , OrderLogEnum.EventType.INFORMATION); } else {
					 * log.info("Inventory Base Returned Error <" +
					 * pubTnBeanObj.getStatusDesc() + ">");
					 * databaseLogging.addTrailList(tsoEtTn.getLogTrail(),
					 * OrderLogEnum.EventType.INFORMATION);
					 * databaseLogging.setOrderLog
					 * ("Inventory Base Returned Error ::" +
					 * pubTnBeanObj.getStatusDesc() + "::",
					 * OrderLogEnum.EventType.ESAP_ERROR);
					 * connection.rollback(); throw new
					 * VzbInvException("ESP_VZB_INV_ADD_ET_TN_FAILED",
					 * "ESP_VZB_INV_ADD_ET_TN_FAILED"); }
					 */
					log.info("In OrderClassify-RELEASE and PortingFlag-Y - Before updating Public TN Pool data");
					if (pubTnBeanObj.updatePublicTnPool()) {
						log.info("In OrderClassify-RELEASE and PortingFlag-Y - in updatePublicTnPool IF");
						// insertOrderLog(INV_SUCCESS,
						// "Successfully added PBX Group in ESAP inventory");
						databaseLogging.setOrderLog("Successfully added ET TN in ESAP inventory", OrderLogEnum.EventType.INFORMATION);
					} else {
						databaseLogging.setOrderLog("Inventory Base Returned Error ::" + pubTnBeanObj.getStatusDesc() + "::",
								OrderLogEnum.EventType.ESAP_ERROR);
						log.info("Inventory Base Returned Error <" + pubTnBeanObj.getStatusDesc() + ">");
						connection.rollback();
						throw new VzbInvException("ESP_VZB_INV_ADD_ET_TN_FAILED", "ESP_VZB_INV_ADD_ET_TN_FAILED");
					}
					log.info("In OrderClassify-RELEASE and PortingFlag-Y - After updating Public TN Pool data");
				} else if (orderClassify.equals("INITIAL") && portingFlag.equals("Y")) {
					/*
					 * if (tsoEtTn.addToDB()) { log.info(
					 * "In OrderClassify-INITIAL and PortingFlag-Y - in addToDB IF"
					 * ); databaseLogging.addTrailList(tsoEtTn.getLogTrail(),
					 * OrderLogEnum.EventType.INFORMATION);
					 * databaseLogging.setOrderLog
					 * ("Successfully added Enterprise Trunk TN in ESAP inventory"
					 * , OrderLogEnum.EventType.INFORMATION); } else {
					 * log.info("Inventory Base Returned Error <" +
					 * pubTnBeanObj.getStatusDesc() + ">");
					 * databaseLogging.addTrailList(tsoEtTn.getLogTrail(),
					 * OrderLogEnum.EventType.INFORMATION);
					 * databaseLogging.setOrderLog
					 * ("Inventory Base Returned Error ::" +
					 * pubTnBeanObj.getStatusDesc() + "::",
					 * OrderLogEnum.EventType.ESAP_ERROR);
					 * connection.rollback(); throw new
					 * VzbInvException("ESP_VZB_INV_ADD_ET_TN_FAILED",
					 * "ESP_VZB_INV_ADD_ET_TN_FAILED"); }
					 */
					PublicTnPool pubTn = new PublicTnPool(connection);
					pubTn.setTnStatus(VzbVoipEnum.TnStatus.ASSIGNED);
					pubTn.setTnType(VzbVoipEnum.TnType.ET);
					pubTn.setTn(pubTnBeanObj.getTn());

					// setting it to default to avoid the update
					pubTnBeanObj.setPortedStatus("");

					if (pubTn.updatePublicTnPool()) {
						// insertOrderLog(INV_SUCCESS,
						// "Successfully updated Tn Status in ESAP inventory");
						databaseLogging.setOrderLog("Successfully added ET TN in ESAP inventory", OrderLogEnum.EventType.INFORMATION);
					} else {
						log.info("Inventory Base Returned Error <" + pubTnBeanObj.getStatusDesc() + ">");
						databaseLogging.setOrderLog("Inventory Base Returned Error ::" + pubTnBeanObj.getStatusDesc() + "::",
								OrderLogEnum.EventType.ESAP_ERROR);
						connection.rollback();
						throw new VzbInvException("ESP_VZB_INV_ADD_ET_TN_FAILED", "ESP_VZB_INV_ADD_ET_TN_FAILED");
					}

					//Commented since we introduced stored procs to take care of TRI
					//addTri(triDataBean);

				} else {
					pubTnBeanObj.setTnStatus(VzbVoipEnum.TnStatus.ASSIGNED);
					pubTnBeanObj.setTnType(VzbVoipEnum.TnType.ET);

					PublicTnPool pubTn = new PublicTnPool(connection);
					pubTn.setTnStatus(VzbVoipEnum.TnStatus.ASSIGNED);
					pubTn.setTnType(VzbVoipEnum.TnType.ET);
					pubTn.setTn(pubTnBeanObj.getTn());

					if (pubTn.updatePublicTnPool()) {
						databaseLogging.setOrderLog("Successfully added ET TN Group in ESAP inventory", OrderLogEnum.EventType.INFORMATION);
					} else {
						log.info("Inventory Base Returned Error <" + pubTnBeanObj.getStatusDesc() + ">");
						databaseLogging.setOrderLog("Inventory Base Returned Error ::" + pubTnBeanObj.getStatusDesc() + "::",
								OrderLogEnum.EventType.ESAP_ERROR);
						connection.rollback();
						throw new VzbInvException("ESP_VZB_INV_ADD_ET_TN_FAILED", "ESP_VZB_INV_ADD_ET_TN_FAILED");
					}

					//Commented since we introduced stored procs to take care of TRI
					//addTri(triDataBean);

				}
				if (!(tsoEtTn.getBroadSoftTnActivation() == null) && Integer.parseInt(tsoEtTn.getBroadSoftTnActivation()) == 1
						&& pubTnBeanObj.getPortedStatus().equals("" + VzbVoipEnum.PortStatus.PORT_PENDING)
						&& pubTnBeanObj.getTnStatus() == VzbVoipEnum.TnStatus.ASSIGNED) {

					//Commented since we introduced stored procs to take care of TRI
					//addTri(triDataBean);

				}

				// tsoEtTn.addToDB();
				/*
				 * tsoEtTn.updateTNMigStatus(orderParam.getByName("LocationId"
				 * ).getParamValue()); String locId = null; if (!(
				 * orderParam.getByName("LocationId") == null )){ locId =
				 * orderParam.getByName("LocationId").getParamValue();
				 * log.info("LocationId " + locId); }
				 * 
				 * tsoEtTn.updateLecBtnMigStatus(locId,mainTN,VzbVoipEnum.
				 * LecBtnMigStatus.TN_MIG_COMPLETED); connection.commit();
				 * log.info("Successfully added the ET_TN ");
				 */

				// }
			}
			if (pubTnBeanObj != null) {
				TsoEtTn tsoEtTn = new TsoEtTn(connection);

				String locId = pubTnBeanObj.getLocationId();
				log.info("LocationId " + locId);

				tsoEtTn.updateTNMigStatus(locId);

				// TriDataBean triDataBean = new TriDataBean();
				TblTriTnData triDataBean = new TblTriTnData();

				triDataBean.setDialPlanId(pubTnBeanObj.getDialPlanId());
				triDataBean.setLocationId(pubTnBeanObj.getLocationId());
				triDataBean.setEnvOrderId(pubTnBeanObj.getEnvOrderId());

				//Commented since we introduced stored procs to take care of TRI
				//consolidateTriInfo(triDataBean);
			}
		} catch (Exception e) {
			throw e;
		}
	}

	public void processLecBtnMigStatus(Connection connection, List<TsoEtTn> tsoEtTnList) throws Exception {
		PublicTnPool pubTnBeanObj = null;
		String cntryCode = null;
		String tn = null;
		try {
			for (TsoEtTn tsoEtTn : tsoEtTnList) {
				// if (!erroredTsoEtTnMap.containsKey(tsoEtTn.getEtTnId() + ""))
				// {// excluding
				// errored
				// TNs
				pubTnBeanObj = tsoEtTn.getPublicTnPool();
				tsoEtTn.setDbCon(connection);
				if (cntryCode == null) {
					cntryCode = getLocationCodeFromTn(pubTnBeanObj.getLocationId());
				}
				tn = pubTnBeanObj.getTn();
				if (cntryCode != null && tn != null) {
					log.info("[removeCountryCode] TN" + tn);
					boolean isValid = tn.startsWith(cntryCode);
					int index = tn.indexOf(cntryCode);
					if (index >= 0 && isValid) {
						tn = tn.substring(index + cntryCode.length(), tn.length());
						log.info("[removeCountryCode] from TN" + tn.toString());
					}
				}

				// tsoEtTn.updateLecBtnMigStatus(locId,mainTN,VzbVoipEnum.LecBtnMigStatus.TN_MIG_COMPLETED);
				tsoEtTn.updateLecBtnMigStatus(tn, VzbVoipEnum.LecBtnMigStatus.TN_MIG_COMPLETED);

				// }
			}
		} catch (Exception e) {
			throw e;
		}
	}

	public void updateLecBtnMigStatus(String tn, int status) throws Exception {

		log.info(" In updateLecBtnMigStatus " + tn);
		String lsUpdMigStatQry = "UPDATE tbl_ipro_lecbtn_mappings SET MIG_STATUS = ? WHERE TN = ?";
		PreparedStatement ps = null;
		try {
			ps = dbCon.prepareStatement(lsUpdMigStatQry);
			ps.setInt(1, status);
			ps.setString(2, tn);
			ps.executeUpdate();
			log.info(" status update done for tbl_ipro_lecbtn_mappings for TN :" + tn);

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			if (ps != null) {
				ps.close();
			}
		}
	}

	public void processBulkETTNMod(List<TsoEtTn> tsoEtTnList, Connection connection) throws SQLException, VzbInvException, Exception {
		// Steps in this methods
		// 1.Add TNs to Public TN Pool
		// 2.Add ET TNs to TSO ET TN
		// 3.Add Exclude TN features List to TsoEtTnExcldFeatures
		// 4.Add ET TN features to TsoEtTnFeatures
		// 5.Add ET TN to TRI

		// HashMap<String, TsoEtTn> erroredTsoEtTnMap = new HashMap<String,
		// TsoEtTn>();

		deleteExcludedfeaturesListForEntTrunk(connection, tsoEtTnList);

		etTnExcludingFeaturesInsert(connection, tsoEtTnList);
		modifyInDB(connection, tsoEtTnList);

		// return erroredTsoEtTnMap;
	}

	private void deleteExcludedfeaturesListForEntTrunk(Connection connection, List<TsoEtTn> tsoEtTnList) {
		PreparedStatement preparedStatement = null;
		String deleteSQL = "DELETE FROM TBL_TSO_ET_TN_EXCLD_FEATURES WHERE FEATURE_ID = ? AND ET_TN_ID = ?";
		try {
			preparedStatement = connection.prepareStatement(deleteSQL);

			for (TsoEtTn tsoEtTn : tsoEtTnList) {
				// if (!erroredTsoEtTnMap.containsKey(tsoEtTn.getEtTnId() + ""))
				// {// excluding
				// errored
				// TNs
				for (int k = 0; k < tsoEtTn.getEtTnExclFeaturesList().size(); k++) {

					preparedStatement.setLong(1, (tsoEtTn.getEtTnExclFeaturesList().get(k)).getFeaturesDbBean().getFeatureId());
					preparedStatement.setLong(2, tsoEtTn.getEtTnId());

					preparedStatement.addBatch();

				}

				// }
			}

			preparedStatement.executeBatch();

			// log.info("TblTsoEtTnExcldFeatures data deleted. Total rows deleted :"
			// + (tsoEtTnList.size() - erroredTsoEtTnMap.size()));
			log.info("TblTsoEtTnExcldFeatures data deleted. Total rows deleted :" + tsoEtTnList.size());

		} catch (SQLException e) {
			e.printStackTrace();
			log.error("TblTsoEtTnExcldFeatures data deletion failed. ");
		} finally {
			if (preparedStatement != null) {
				try {
					preparedStatement.close();
					preparedStatement = null;
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}

	public boolean modifyInDB(Connection connection, List<TsoEtTn> tsoEtTnList) throws SQLException, Exception {
		// PreparedStatement ps = null;
		DBTblTsoEtTn tsoEtTnDbBean = null;
		try {
			int count = 0;

			PreparedStatement ps = connection
					.prepareStatement("UPDATE TBL_TSO_ET_TN SET EXTENSION=?,PRIVATE_NUMBER=?,CLID_FIRST_NAME=?,CLID_LAST_NAME=?,VM_MAXSIZE_ID=?,VM_BOX_NUM=?,ACTIVE_IND=?,ENV_ORDER_ID=?,SUB_ID=?,PIT_SIP_TRX_ID=?,CREATED_BY=?,MODIFIED_BY=?,LAST_MODIFIED_DATE=? WHERE ET_TN_ID=?");

			// ps = connection.prepareStatement(updateStmt.toString());
			for (TsoEtTn tsoEtTn : tsoEtTnList) {
				tsoEtTnDbBean = new DBTblTsoEtTn();
				tsoEtTnDbBean = getTsoEtTnToUpdate(connection, tsoEtTn);
				// if (!erroredTsoEtTnMap.containsKey(tsoEtTnDbBean.getEtTnId()
				// + "")) {// excluding
				// errored
				// TNs
				int idx = 1;
				log.info(" Modify for ET TN ID  " + tsoEtTnDbBean.getEtTnId());

				if (tsoEtTnDbBean.isExtensionSet()) {
					ps.setString(1, tsoEtTnDbBean.getExtension());
				} else {
					ps.setNull(1, java.sql.Types.VARCHAR);
				}
				if (tsoEtTnDbBean.isPrivateNumberSet()) {
					ps.setString(2, tsoEtTnDbBean.getPrivateNumber());
				} else {
					ps.setNull(2, java.sql.Types.VARCHAR);
				}
				if (tsoEtTnDbBean.isClidFirstNameSet()) {
					ps.setString(3, tsoEtTnDbBean.getClidFirstName());
				} else {
					ps.setNull(3, java.sql.Types.VARCHAR);
				}

				if (tsoEtTnDbBean.isClidLastNameSet()) {
					ps.setString(4, tsoEtTnDbBean.getClidLastName());
				} else {
					ps.setNull(4, java.sql.Types.VARCHAR);
				}
				if (tsoEtTnDbBean.isVmMaxsizeIdSet()) {
					ps.setLong(5, tsoEtTnDbBean.getVmMaxsizeId());
				} else {
					ps.setNull(5, java.sql.Types.NUMERIC);
				}
				if (tsoEtTnDbBean.isVmBoxNumSet()) {
					ps.setString(6, tsoEtTnDbBean.getVmBoxNum());
				} else {
					ps.setNull(6, java.sql.Types.VARCHAR);
				}
				if (tsoEtTnDbBean.isActiveIndSet()) {
					ps.setLong(7, tsoEtTnDbBean.getActiveInd());
				} else {
					ps.setNull(7, java.sql.Types.VARCHAR);
				}
				if (tsoEtTnDbBean.isEnvOrderIdSet()) {
					ps.setInt(8, tsoEtTnDbBean.getEnvOrderId());
				} else {
					ps.setNull(8, java.sql.Types.VARCHAR);
				}
				if (tsoEtTnDbBean.isSubIdSet()) {
					ps.setString(9, tsoEtTnDbBean.getSubId());
				} else {
					ps.setNull(9, java.sql.Types.VARCHAR);
				}
				if (tsoEtTnDbBean.isPitSipTrxIdSet()) {
					ps.setInt(10, tsoEtTnDbBean.getPitSipTrxId());
				} else {
					ps.setNull(10, java.sql.Types.VARCHAR);
				}
				ps.setString(11, "ESAP");
				ps.setString(12, modifiedBy);
				ps.setTimestamp(13, new Timestamp(System.currentTimeMillis()));
				ps.setLong(14, tsoEtTnDbBean.getEtTnId());

				ps.addBatch();

				// }
			}
			try {

				ps.executeBatch();
				log.info(" UPDATE CNT " + ps.getUpdateCount());
			} finally {
				if (ps != null)
					ps.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}

		setStatus(InvErrorCode.SUCCESS);

		return true;
	}

	private DBTblTsoEtTn getTsoEtTnToUpdate(Connection connection, TsoEtTn tsoEtTn) throws SQLException {
		log.info(" getTsoEtTnToUpdate invoked ");
		/*
		 * Create a new instance of TsoEbiDbBean. The new instance would hold
		 * default values for the all the TsoEbiDbBean fields.
		 */
		// List<DBTblTsoEtTn> tsoEtTnUpdList = new ArrayList<DBTblTsoEtTn>();
		// for (TsoEtTn tsoEtTn : tsoEtTnList) {
		DBTblTsoEtTn tsoEtTnDbBean = new DBTblTsoEtTn();

		TsoEtTnBean defaultTsoEtTnBean = new TsoEtTnBean();
		TsoEtTn inputTsoEtTn = tsoEtTn;
		tsoEtTnDbBean.setEtTnId(tsoEtTn.getEtTnId());
		TblTsoEtTnQuery tsoEtTnQry = new TblTsoEtTnQuery();
		tsoEtTnQry.whereEtTnIdEQ(tsoEtTn.getEtTnId());
		tsoEtTnQry.query(connection);

		TblTsoEtTnDbBean bean = tsoEtTnQry.getDbBean(0);
		log.info(" updating the Bean from existing record ");
		tsoEtTnDbBean.copyFromBean(bean);

		if (inputTsoEtTn.getEnterpriseTrunkId() != 0 && inputTsoEtTn.getEnterpriseTrunkId() != defaultTsoEtTnBean.getEnterpriseTrunkId()) {
			tsoEtTnDbBean.setEnterpriseTrunkId(inputTsoEtTn.getEnterpriseTrunkId());

		}
		if (inputTsoEtTn.getTnPoolId() != 0 && inputTsoEtTn.getTnPoolId() != defaultTsoEtTnBean.getTnPoolId()) {
			tsoEtTnDbBean.setTnPoolId(inputTsoEtTn.getTnPoolId());
		}
		if (inputTsoEtTn.getExtension() != null && !inputTsoEtTn.getExtension().equals(defaultTsoEtTnBean.getExtension())) {
			tsoEtTnDbBean.setExtension(inputTsoEtTn.getExtension());
		}
		if (inputTsoEtTn.getExtension() == null || "".equals(inputTsoEtTn.getExtension())) {
			tsoEtTnDbBean.setExtensionNull();
		}

		if (inputTsoEtTn.getPrivateNumber() != null && !inputTsoEtTn.getPrivateNumber().equals(defaultTsoEtTnBean.getPrivateNumber())) {
			tsoEtTnDbBean.setPrivateNumber(inputTsoEtTn.getPrivateNumber());
		}
		if ("".equals(inputTsoEtTn.getPrivateNumber())) {
			tsoEtTnDbBean.setPrivateNumberNull();
		}
		log.info(" CLID FIRST NAME ::  " + inputTsoEtTn.getClidFirstName());
		if (inputTsoEtTn.getClidFirstName() != null && !inputTsoEtTn.getClidFirstName().equals(defaultTsoEtTnBean.getClidFirstName())) {
			log.info(" CLID FIRST NAME set to new val ");
			tsoEtTnDbBean.setClidFirstName(inputTsoEtTn.getClidFirstName());
		}
		if ("".equals(inputTsoEtTn.getClidFirstName())) {
			tsoEtTnDbBean.setClidFirstNameNull();
		}

		if (inputTsoEtTn.getClidLastName() != null && !inputTsoEtTn.getClidLastName().equals(defaultTsoEtTnBean.getClidLastName())) {
			tsoEtTnDbBean.setClidLastName(inputTsoEtTn.getClidLastName());
		}
		if ("".equals(inputTsoEtTn.getClidLastName())) {
			tsoEtTnDbBean.setClidLastNameNull();
		}
		if (inputTsoEtTn.getVmMaxsizeId() != -1 && inputTsoEtTn.getVmMaxsizeId() != defaultTsoEtTnBean.getVmMaxsizeId()) {
			tsoEtTnDbBean.setVmMaxsizeId(inputTsoEtTn.getVmMaxsizeId());
		}
		if (inputTsoEtTn.getVmMaxsizeId() == 0) {
			tsoEtTnDbBean.setVmMaxsizeId(0);
		}

		if (inputTsoEtTn.getVmBoxNum() != null && !inputTsoEtTn.getVmBoxNum().equals(defaultTsoEtTnBean.getVmBoxNum())) {
			tsoEtTnDbBean.setVmBoxNum(inputTsoEtTn.getVmBoxNum());
		}
		if ("".equals(inputTsoEtTn.getVmBoxNum())) {
			tsoEtTnDbBean.setVmBoxNumNull();
		}

		if (inputTsoEtTn.getActiveInd() != 0 && inputTsoEtTn.getActiveInd() != defaultTsoEtTnBean.getActiveInd()) {
			tsoEtTnDbBean.setActiveInd(inputTsoEtTn.getActiveInd());
		}
		if (inputTsoEtTn.getEnvOrderId() != 0 && inputTsoEtTn.getEnvOrderId() != defaultTsoEtTnBean.getEnvOrderId()) {
			tsoEtTnDbBean.setEnvOrderId(inputTsoEtTn.getEnvOrderId());
		}
		if (inputTsoEtTn.getSubId() != null && !inputTsoEtTn.getSubId().equals(defaultTsoEtTnBean.getSubId())) {
			tsoEtTnDbBean.setSubId(inputTsoEtTn.getSubId());
		}
		if (inputTsoEtTn.getPitSipTrxId() != -1 && inputTsoEtTn.getPitSipTrxId() != defaultTsoEtTnBean.getPitSipTrxId()) {
			tsoEtTnDbBean.setPitSipTrxId(inputTsoEtTn.getPitSipTrxId());
		}
		if (inputTsoEtTn.getPitSipTrxId() == 0) {
			tsoEtTnDbBean.setPitSipTrxId(0);
		}

		if (inputTsoEtTn.getModifiedBy() != null && !inputTsoEtTn.getModifiedBy().equals(defaultTsoEtTnBean.getModifiedBy())) {
			tsoEtTnDbBean.setModifiedBy(inputTsoEtTn.getModifiedBy());
		}
		if (inputTsoEtTn.getLastModifiedDate() != null
				&& !inputTsoEtTn.getLastModifiedDate().equals(defaultTsoEtTnBean.getLastModifiedDate())) {
			tsoEtTnDbBean.setLastModifiedDate(inputTsoEtTn.getLastModifiedDate());
		}

		return tsoEtTnDbBean;
	}

	public HashMap<String, TsoEtTnFeatures> processEtTnFeatBulk(List<TsoEtTnFeatures> tsoEtTnFeatAddList,
			List<TsoEtTnFeatures> tsoEtTnFeatDelList, Connection connection) throws Exception {

		HashMap<String, TsoEtTnFeatures> erroredTsoEtTnMap = new HashMap<String, TsoEtTnFeatures>();
		if (tsoEtTnFeatAddList != null && tsoEtTnFeatAddList.size() > 0) {
			etTnFeaturesBulkInsert(connection, tsoEtTnFeatAddList, erroredTsoEtTnMap);
		}
		if (tsoEtTnFeatDelList != null && tsoEtTnFeatDelList.size() > 0) {
			etTnFeaturesBulkDel(connection, tsoEtTnFeatDelList, erroredTsoEtTnMap);
		}
		return null;

	}

	private void etTnFeaturesBulkInsert(Connection connection, List<TsoEtTnFeatures> tsoEtTnFeatList,
			HashMap<String, TsoEtTnFeatures> erroredTsoEtTnMap) {
		PreparedStatement preparedStatement = null;
		String insertTableSQL = "INSERT INTO TBL_TSO_ET_TN_FEATURES(ET_TN_FEATURE_ID,ET_TN_ID,FEATURE_ID,CREATED_BY,CREATION_DATE,MODIFIED_BY,LAST_MODIFIED_DATE,ENV_ORDER_ID) VALUES (ET_TN_FEATURE_ID_SEQ.NEXTVAL,?,?,?,sysdate,?,sysdate,?)";
		try {
			preparedStatement = connection.prepareStatement(insertTableSQL);

			for (TsoEtTnFeatures tsoEtTnFeat : tsoEtTnFeatList) {
				if (!erroredTsoEtTnMap.containsKey(tsoEtTnFeat.getEtTnId() + "")) {// excluding
																					// errored
																					// TNs

					// TsoEtTnFeaturesBean etTnBean =
					// tsoEtTn.getEtTnFeaturesList().get(i);
					/*
					 * DBTblTsoEtTnFeatures etTnFeaturesDbObj = new
					 * DBTblTsoEtTnFeatures();
					 * etTnFeaturesDbObj.setEtTnFeatureId(etTnFeaturesDbObj
					 * .getEtTnFeatureIdSeqNextVal(dbCon));
					 * etTnFeaturesDbObj.setEtTnId(tsoEtTn.getEtTnId());
					 * etTnFeaturesDbObj.setFeatureId(etTnBean.getFeatureId());
					 * etTnFeaturesDbObj.setCreatedBy("ESAP_INV");
					 * etTnFeaturesDbObj.setCreationDate(new Timestamp(System
					 * .currentTimeMillis()));
					 * etTnFeaturesDbObj.setModifiedBy("ESAP_INV");
					 * etTnFeaturesDbObj.setLastModifiedDate(new
					 * Timestamp(System .currentTimeMillis()));
					 * etTnFeaturesDbObj
					 * .setEnvOrderId(etTnBean.getEnvOrderId());
					 * 
					 * etTnFeaturesDbObj.insert(dbCon);
					 */

					preparedStatement.setLong(1, tsoEtTnFeat.getEtTnId());
					preparedStatement.setLong(2, tsoEtTnFeat.getFeatureId());

					if (tsoEtTnFeat.getCreatedBy() != null && !tsoEtTnFeat.getCreatedBy().equals("")) {
						preparedStatement.setString(3, tsoEtTnFeat.getCreatedBy());
					} else {
						preparedStatement.setString(3, "ESAP_INV");
					}
					if (tsoEtTnFeat.getModifiedBy() != null && !tsoEtTnFeat.getModifiedBy().equals("")) {
						preparedStatement.setString(4, tsoEtTnFeat.getModifiedBy());
					} else {
						preparedStatement.setString(4, "ESAP_INV");
					}
					if (tsoEtTnFeat.getEnvOrderId() > 0) {
						preparedStatement.setLong(5, tsoEtTnFeat.getEnvOrderId());
					} else {
						preparedStatement.setLong(5, -1);
					}
					preparedStatement.addBatch();
				}
			}

			preparedStatement.executeBatch();

			log.info("TblTsoEtTnFeatures data inserted. Total rows inserted :" + (tsoEtTnFeatList.size() - erroredTsoEtTnMap.size()));

		} catch (SQLException e) {
			e.printStackTrace();
			log.error("TblTsoEtTnFeatures data insertion failed. ");
		} finally {
			if (preparedStatement != null) {
				try {
					preparedStatement.close();
					preparedStatement = null;
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}

	private void etTnFeaturesBulkDel(Connection connection, List<TsoEtTnFeatures> tsoEtTnFeatDelList,
			HashMap<String, TsoEtTnFeatures> erroredTsoEtTnMap) {
		PreparedStatement preparedStatement = null;
		String deleteSQL = "DELETE FROM TBL_TSO_ET_TN_FEATURES WHERE FEATURE_ID = ? AND ET_TN_ID = ?";
		try {
			preparedStatement = connection.prepareStatement(deleteSQL);

			for (TsoEtTnFeatures tsoEtTnFeat : tsoEtTnFeatDelList) {
				if (!erroredTsoEtTnMap.containsKey(tsoEtTnFeat.getEtTnId() + "")) {// excluding
																					// errored
																					// TNs

					preparedStatement.setLong(1, tsoEtTnFeat.getFeatureId());
					preparedStatement.setLong(2, tsoEtTnFeat.getEtTnId());

					preparedStatement.addBatch();

				}
			}

			preparedStatement.executeBatch();

			log.info("TblTsoEtTnFeatures data deleted. Total rows deleted :" + (tsoEtTnFeatDelList.size() - erroredTsoEtTnMap.size()));

		} catch (SQLException e) {
			e.printStackTrace();
			log.error("TblTsoEtTnFeatures data deletion failed. ");
		} finally {
			if (preparedStatement != null) {
				try {
					preparedStatement.close();
					preparedStatement = null;
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}

	public boolean deleteFromDBExceptPNP(long entTrnkId, String TN, long orderId) throws SQLException, Exception {
		// try {
		if (etTnId <= 0) {
			setErrstatus(InvErrorCode.INVALID_INPUT);
			System.out.println("FAILURE in deleteFromDB TsoETTn. etTnId missing.");
			return false;
		}
		// Changes as part of E2Ei: PROD : Please provide script to correct ET
		// TN iD mismatch - JIRA -ESVRRS-1318
		boolean etTnFlag = getETTNmismatchFlag(dbCon);
		if (etTnFlag) {
			TblTsoEtTnQuery etTnQuery = new TblTsoEtTnQuery();
			etTnQuery.whereEtTnIdEQ(getEtTnId());
			etTnQuery.query(dbCon);
			if (etTnQuery.getDbBean(0) == null) {
				log.info("ET TN query object is  null.");
				log.info("Enterprise TrunkId is :." + entTrnkId);
				log.info("TN is .:" + TN);
				long etTn = updateETTN(dbCon, entTrnkId, TN, orderId);
				log.info("ET TN is #.:" + TN);
				setEtTnId(etTn);
				deleteExcludedFeaturesForEtTn();
				// deleting tn features in tbl_tso_et_tn_features for the ettnid
				deleteEtTnFeatures();
				TblTsoEtTnQuery etTnQuery1 = new TblTsoEtTnQuery();
				etTnQuery1.whereEtTnIdEQ(getEtTnId());
				etTnQuery1.query(dbCon);
				int tnPoolId = (int) etTnQuery1.getDbBean(0).getTnPoolId();
				setEtTnId((int) etTnQuery1.getDbBean(0).getEtTnId());
				String subId = new String("");
				subId = etTnQuery1.getDbBean(0).getSubId();
				// incrementORdecrementPortsAssigned("N");

				DBTblTsoEtTn etTnDbBean = new DBTblTsoEtTn();
				etTnDbBean.whereEtTnIdEQ(getEtTnId());
				if (etTnDbBean.deleteByWhere(dbCon) <= 0) {
					setErrstatus(InvErrorCode.ERROR_DELETING_ET_TN);
					log.info("Error while deleting ETTn.");
					return false;
				}
				if (subId != null && !subId.equalsIgnoreCase("")) {
					Subscriber subobj = new Subscriber(dbCon);
					subobj.setSubId(subId);
					subobj.delSubscriber();
				}

				PublicTnPool publicTnPool = new PublicTnPool(dbCon);
				publicTnPool.setTnPoolId(tnPoolId);
				publicTnPool.setEnvOrderId(getEnvOrderId());
				publicTnPool.setModifiedBy(getModifiedBy());
				publicTnPool.setLastModifiedDate(new Timestamp(System.currentTimeMillis()));

				log.info("tnPoolId : getDbBean===>" + tnPoolId);
				log.info("rollbackFlag: getDbBean===>" + rollbackFlag);
				log.info("removeTnFlag : getDbBean===>" + removeTnFlag);

				String tn = getTnForTnPool(tnPoolId);
				log.info(" tn : getDbBean " + tn);
				TblPublicTnPoolQuery tblPublicTnPoolQuery = new TblPublicTnPoolQuery();
				tblPublicTnPoolQuery.whereTnPoolIdEQ(tnPoolId);
				tblPublicTnPoolQuery.query(dbCon);

				String locId = tblPublicTnPoolQuery.getDbBean(0).getLocationId();
				log.info(" locId in deleteFromDB: getDbBean " + locId);
				updateLecBtnMigStatus(locId, tn, VzbVoipEnum.LecBtnMigStatus.MIG_NOT_STARTED);
				if ((rollbackFlag && !isExistingTn) || removeTnFlag) {
					/**
					 * Commenting below PublicTnPool delete code to handle it in
					 * System Update
					 */
					/*
					 * if (!publicTnPool.deletePublicTnPool()) {
					 * setErrstatus(InvErrorCode
					 * .ERROR_DELETING_PUBLIC_TN_POOL_FROM_ET_TN); System.out
					 * .println
					 * ("Error while deleting Public Tn Poll from ETTn.");
					 * return false; }
					 */
					/**
					 * Commenting above PublicTnPool delete code to handle it in
					 * System Update
					 */
				} else {
					publicTnPool.setTnStatus(VzbVoipEnum.TnStatus.AVAILABLE);
					publicTnPool.setActiveInd(VzbVoipEnum.ActiveInd.ACTIVE);
					if (!publicTnPool.updatePublicTnPool()) {
						setErrstatus(InvErrorCode.ERROR_DELETING_PUBLIC_TN_POOL_FROM_ET_TN);
						System.out.println("Error while deleting Public Tn Poll from ETTn.");
						return false;
					}

				}
				setErrstatus(InvErrorCode.SUCCESS);
				return true;
			} else {
				// BAU flow
				deleteExcludedFeaturesForEtTn();
				// deleting tn features in tbl_tso_et_tn_features for the ettnid
				deleteEtTnFeatures();
				TblTsoEtTnQuery etTnQuery2 = new TblTsoEtTnQuery();
				etTnQuery2.whereEtTnIdEQ(getEtTnId());
				etTnQuery2.query(dbCon);
				int tnPoolId = (int) etTnQuery2.getDbBean(0).getTnPoolId();
				setEtTnId((int) etTnQuery2.getDbBean(0).getEtTnId());
				String subId = new String("");
				subId = etTnQuery2.getDbBean(0).getSubId();
				// incrementORdecrementPortsAssigned("N");

				DBTblTsoEtTn etTnDbBean = new DBTblTsoEtTn();
				etTnDbBean.whereEtTnIdEQ(getEtTnId());
				if (etTnDbBean.deleteByWhere(dbCon) <= 0) {
					setErrstatus(InvErrorCode.ERROR_DELETING_ET_TN);
					log.info("Error while deleting ETTn.");
					return false;
				}
				if (subId != null && !subId.equalsIgnoreCase("")) {
					Subscriber subobj = new Subscriber(dbCon);
					subobj.setSubId(subId);
					subobj.delSubscriber();
				}

				PublicTnPool publicTnPool = new PublicTnPool(dbCon);
				publicTnPool.setTnPoolId(tnPoolId);
				publicTnPool.setEnvOrderId(getEnvOrderId());
				publicTnPool.setModifiedBy(getModifiedBy());
				publicTnPool.setLastModifiedDate(new Timestamp(System.currentTimeMillis()));

				log.info("tnPoolId===>" + tnPoolId);
				log.info("rollbackFlag===>" + rollbackFlag);
				log.info("removeTnFlag===>" + removeTnFlag);

				String tn = getTnForTnPool(tnPoolId);
				log.info(" tn " + tn);
				TblPublicTnPoolQuery tblPublicTnPoolQuery = new TblPublicTnPoolQuery();
				tblPublicTnPoolQuery.whereTnPoolIdEQ(tnPoolId);
				tblPublicTnPoolQuery.query(dbCon);

				String locId = tblPublicTnPoolQuery.getDbBean(0).getLocationId();
				log.info(" locId in deleteFromDB " + locId);
				updateLecBtnMigStatus(locId, tn, VzbVoipEnum.LecBtnMigStatus.MIG_NOT_STARTED);
				if ((rollbackFlag && !isExistingTn) || removeTnFlag) {
					/**
					 * Commenting below PublicTnPool delete code to handle it in
					 * System Update
					 */
					/*
					 * if (!publicTnPool.deletePublicTnPool()) {
					 * setErrstatus(InvErrorCode
					 * .ERROR_DELETING_PUBLIC_TN_POOL_FROM_ET_TN); System.out
					 * .println
					 * ("Error while deleting Public Tn Poll from ETTn.");
					 * return false; }
					 */
					/**
					 * Commenting above PublicTnPool delete code to handle it in
					 * System Update
					 */
				} else {
					publicTnPool.setTnStatus(VzbVoipEnum.TnStatus.AVAILABLE);
					publicTnPool.setActiveInd(VzbVoipEnum.ActiveInd.ACTIVE);
					if (!publicTnPool.updatePublicTnPool()) {
						setErrstatus(InvErrorCode.ERROR_DELETING_PUBLIC_TN_POOL_FROM_ET_TN);
						System.out.println("Error while deleting Public Tn Poll from ETTn.");
						return false;
					}
				}
			}
		}
		setErrstatus(InvErrorCode.SUCCESS);
		return true;
	}

	public boolean getETTNmismatchFlag(Connection connection) {

		log.info("Inside getETTNmismatchFlag()  ");
		StringBuffer sql = new StringBuffer();
		Statement statement = null;
		ResultSet resultSet = null;
		boolean tmp = false;
		sql.append("select param_value from tbl_config_params where param_name ='ET_TN_MISMATCH' and process_name = 'ET_TN_MISMATCH'");

		log.info("Query is " + sql.toString());
		try {
			statement = connection.createStatement();
			resultSet = statement.executeQuery(sql.toString());
			if (resultSet.next()) {
				String str = resultSet.getString("param_value");
				if (str != null && str.equals("ON")) {
					tmp = true;
				}
				log.info(" getMQConfigFlag  tmp is " + tmp);

			}
		} catch (SQLException sqle) {
			sqle.printStackTrace();
		} finally {
			try {
				if (resultSet != null)
					resultSet.close();
				if (statement != null)
					statement.close();
			} catch (SQLException sqle) {
				sqle.printStackTrace();
			}
		}
		return tmp;
	}

	public long updateETTN(Connection dbCon, long entTrnkId, String TN, long orderId) throws Exception {
		log.info(" In getTnPoolfrmTrunkAndTN  entTrnkId :" + entTrnkId + "TN :" + TN + "");
		String tnPoolTNQry = "select et.tn_pool_id from tbl_tso_et_tn et,tbl_public_tn_pool pnp where et.tn_pool_id = pnp.tn_pool_id and et.enterprise_trunk_id =? and pnp.tn = ?";
		String etTNQry = "select et_tn_id from tbl_tso_et_tn where tn_pool_Id = ?";
		String UpdtblOrderQry = "update tbl_order_details set param_value= ? where param_name='EnterpriseTrunkTNId' and order_id=?";
		PreparedStatement etTnPs = null;
		PreparedStatement tnPoolPs = null;
		PreparedStatement tblOrdPs = null;
		ResultSet tnpoolRs = null;
		ResultSet selRs1 = null;
		long tnPoolId = -1;
		long etTnId = -1;
		try {
			tnPoolPs = dbCon.prepareStatement(tnPoolTNQry);
			tnPoolPs.setLong(1, entTrnkId);
			tnPoolPs.setString(2, TN);
			tnpoolRs = tnPoolPs.executeQuery();
			while (tnpoolRs.next()) {
				log.info(" TN Pool query resultset ");
				tnPoolId = tnpoolRs.getLong(1);
				log.info(" TN Pool Id id is " + tnPoolId);
			}
			if (tnPoolId > 1) {
				log.info(" Found TN Pool Id");
				etTnPs = dbCon.prepareStatement(etTNQry);
				etTnPs.setLong(1, tnPoolId);
				selRs1 = etTnPs.executeQuery();
				while (selRs1.next()) {
					log.info(" ET TN query resultset ");
					etTnId = selRs1.getLong(1);
					log.info(" etTnId is " + etTnId);
				}
				log.info(" Aftre ET TN id");
			}
			if (etTnId > 1) {
				log.info("found  ET TN id");
				tblOrdPs = dbCon.prepareStatement(UpdtblOrderQry);
				tblOrdPs.setLong(1, etTnId);
				tblOrdPs.setLong(2, orderId);
				int updflag = tblOrdPs.executeUpdate();
				log.info(" update falg value is " + updflag);
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (tnpoolRs != null)
					tnpoolRs.close();
				if (selRs1 != null)
					selRs1.close();
				if (etTnPs != null)
					etTnPs.close();
				if (tnPoolPs != null)
					tnPoolPs.close();
				if (tblOrdPs != null)
					tblOrdPs.close();
			} catch (SQLException sqle) {
				sqle.printStackTrace();
			}

		}
		return etTnId;
	}

	public void deleteExcludedFeaturesForEtTn() throws SQLException {
		DBTblTsoEtTnExcldFeatures excTnFeaturesDbBean = new DBTblTsoEtTnExcldFeatures();
		log.info("getEtTnId()====>" + getEtTnId());
		excTnFeaturesDbBean.whereEtTnIdEQ(getEtTnId());
		if (excTnFeaturesDbBean.deleteByWhere(dbCon) < 0) {
			setErrstatus(InvErrorCode.ERROR_DELETING_EXCLD_FEATURE_TO_ET_TN);
			System.out.println("Error while deleting Exclude Features from PBXGroupTn.");
		}
	}

	public void deleteEtTnFeatures() throws SQLException, Exception {
		DBTblTsoEtTnFeatures etTnFeatDbBean = new DBTblTsoEtTnFeatures();
		log.info("getEtTnId()====>" + getEtTnId());
		etTnFeatDbBean.whereEtTnIdEQ(getEtTnId());
		if (etTnFeatDbBean.deleteByWhere(dbCon) < 0) {
			System.out.println("Error while deleting ET Tn Features from EtTn.");
		}
	}

	public String getTnForTnPool(long tnPoolId) throws Exception {
		log.info(" In getTnForTnPool " + tnPoolId);
		String lsDonorQry = "SELECT TN FROM TBL_PUBLIC_TN_POOL WHERE TN_POOL_ID = " + tnPoolId;
		String tn = null;
		PreparedStatement pstmt = null;
		ResultSet res = null;
		try {
			pstmt = dbCon.prepareStatement(lsDonorQry);
			res = pstmt.executeQuery();
			while (res.next()) {
				tn = res.getString(1);
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (res != null) {
				res.close();
			}
			if (pstmt != null) {
				pstmt.close();
			}
		}
		return tn;
	}

	public boolean deleteFromDB() throws SQLException, Exception {
		// try {
		if (etTnId <= 0) {
			setErrstatus(InvErrorCode.INVALID_INPUT);
			System.out.println("FAILURE in deleteFromDB TsoETTn. etTnId missing.");
			return false;
		}
		int tnPoolId = (int) getTnPoolId();
		deleteExcludedFeaturesForEtTn();
		// deleting tn features in tbl_tso_et_tn_features for the ettnid
		deleteEtTnFeatures();
		TblTsoEtTnQuery etTnQuery = new TblTsoEtTnQuery();
		etTnQuery.whereEtTnIdEQ(getEtTnId());
		etTnQuery.query(dbCon);
		TblTsoEtTnDbBean dbBean = etTnQuery.getDbBean(0);
		log.info("TblTsoEtTnDbBean : " + dbBean);
		if (dbBean != null) {
			tnPoolId = (int) dbBean.getTnPoolId();
			setEtTnId((int) dbBean.getEtTnId());
			String subId = new String("");
			subId = dbBean.getSubId();
			// incrementORdecrementPortsAssigned("N");
			log.info("Before deleting  DBTblTsoEtTn entry for ET TN ID:" + getEtTnId() + " Subscriber ID:" + subId);
			DBTblTsoEtTn etTnDbBean = new DBTblTsoEtTn();
			etTnDbBean.whereEtTnIdEQ(getEtTnId());
			if (etTnDbBean.deleteByWhere(dbCon) <= 0) {
				setErrstatus(InvErrorCode.ERROR_DELETING_ET_TN);
				log.info("Error while deleting ETTn.");
				return false;
			}
			if (subId != null && !subId.equalsIgnoreCase("")) {
				Subscriber subobj = new Subscriber(dbCon);
				subobj.setSubId(subId);
				subobj.delSubscriber();
			}
		}
		log.info("Before preparing  PublicTnPool object : tnPoolId: " + tnPoolId);
		PublicTnPool publicTnPool = new PublicTnPool(dbCon);
		publicTnPool.setTnPoolId(tnPoolId);
		publicTnPool.setEnvOrderId(getEnvOrderId());
		publicTnPool.setModifiedBy(getModifiedBy());
		publicTnPool.setLastModifiedDate(new Timestamp(System.currentTimeMillis()));
		publicTnPool.setBatchRange(batchRange);

		log.info("tnPoolId===>" + tnPoolId + " rollbackFlag===>" + rollbackFlag + " removeTnFlag===>" + removeTnFlag);

		String tn = getTnForTnPool(tnPoolId);
		log.info(" tn " + tn);
		TblPublicTnPoolQuery tblPublicTnPoolQuery = new TblPublicTnPoolQuery();
		tblPublicTnPoolQuery.whereTnPoolIdEQ(tnPoolId);
		tblPublicTnPoolQuery.query(dbCon);

		if(tblPublicTnPoolQuery != null){
			String locId = tblPublicTnPoolQuery.getDbBean(0) != null ? tblPublicTnPoolQuery.getDbBean(0).getLocationId():getLocationId();
			log.info(" locId in deleteFromDB " + locId);
			updateLecBtnMigStatus(locId, tn, VzbVoipEnum.LecBtnMigStatus.MIG_NOT_STARTED);
			if ((rollbackFlag && !isExistingTn) || removeTnFlag) {
				if (!publicTnPool.deletePublicTnPool()) {
					setErrstatus(InvErrorCode.ERROR_DELETING_PUBLIC_TN_POOL_FROM_ET_TN);
					System.out.println("Error while deleting Public Tn Poll from ETTn.");
					return false;
				}
			} else {
				publicTnPool.setTnStatus(VzbVoipEnum.TnStatus.AVAILABLE);
				publicTnPool.setActiveInd(VzbVoipEnum.ActiveInd.ACTIVE);
				if (!publicTnPool.updatePublicTnPool()) {
					setErrstatus(InvErrorCode.ERROR_DELETING_PUBLIC_TN_POOL_FROM_ET_TN);
					System.out.println("Error while deleting Public Tn Poll from ETTn.");
					return false;
				}
	
			}
		}
		setErrstatus(InvErrorCode.SUCCESS);

		return true;
	}

	public void triDataSynch(TblTriTnData triDataBean) throws Exception{
		log.info("Inside TsoEtTn.triDataSynch()*********** ");
		List<TBlTerminatingRouting> tblTerminatingRoutingList = selectTblTerminatingRoutingByDpId(triDataBean.getDialPlanId());
		List<String> rangesList = getTriTnDataRanges(triDataBean.getDialPlanId());
		String terminatingRoutingRange = "";
		List<TBlTerminatingRouting> tblTerminatingRoutingNewList = new ArrayList<TBlTerminatingRouting>();
		boolean foundRange = false;

		for (TBlTerminatingRouting terminatingRouting : tblTerminatingRoutingList) {
			terminatingRoutingRange = terminatingRouting.getRangeStart()+"-"+terminatingRouting.getRangeEnd();
			foundRange = false;
			if(!rangesList.contains(terminatingRoutingRange)){
				tblTerminatingRoutingNewList.add(terminatingRouting);
			}
		}
		for(String newRange : rangesList){
			foundRange = false;
			for (TBlTerminatingRouting terminatingRouting : tblTerminatingRoutingList) {
				terminatingRoutingRange = terminatingRouting.getRangeStart()+"-"+terminatingRouting.getRangeEnd();
				if(terminatingRoutingRange.equals(newRange)){
					foundRange = true;
				}
			}
			if(!foundRange){
				String rangeArr[] = null;
				rangeArr = newRange.split("-");
				//delete newRange.which may contains old data.delete existing range of data to make sure duplicates are not getting inserted.
				deleteExistingTriTnDataByRange(triDataBean.getDialPlanId(),rangeArr[0],rangeArr[1]);
			}
		}
		
		
		if(tblTerminatingRoutingNewList.size() > 0){
			explodeRanges(tblTerminatingRoutingNewList);
		}
		log.info("Exit from TsoEtTn.triDataSynch()*********** ");
	}
	public void addTri(TblTriTnData triDataBean) throws Exception {
		log.info("Inside TriService.addTri()*********** ");
		
		try {
			Map<String, Object> params = new HashMap<String, Object>();
			params.put("dialPlanId", triDataBean.getDialPlanId());

			// int rowCount = tblTriTnDataMapper.countByDpId(params);
			int rowCount = countByDpId(triDataBean.getDialPlanId());
			if (rowCount <= 0) {
				// explode ranges from TBL_TERMINATING_ROUTING and add each
				// individual TN entry in TBL_TRI_TN_DATA
				// List<TBlTerminatingRouting> tblTerminatingRoutingList =
				// tBlTerminatingRoutingMapper.selectByDpId(params);
				List<TBlTerminatingRouting> tblTerminatingRoutingList = selectTblTerminatingRoutingByDpId(triDataBean.getDialPlanId());
				if (tblTerminatingRoutingList.size() > 0) {
					// add TN entries in TBL_TRI_TN_DATA
					explodeRanges(tblTerminatingRoutingList);
				}
			}
			// tblTriTnDataMapper.insertSelectiveParams(triDataBean);
			insertTblTriTnData(triDataBean);
		} catch (Exception e) {
			// e.printStackTrace();
			log.info(" failed! {}", e);
			log.error(e.getMessage());
			throw e;
		}
	}

	public void deleteTri(TblTriTnData triDataBean) throws Exception {
		log.info("Inside TriService.deleteTri()*********** ");
		try {
			Map<String, Object> paramsMap = new HashMap<String, Object>();
			paramsMap.put("dialPlanId", triDataBean.getDialPlanId());

			// int rowCount = tblTriTnDataMapper.countByDpId(paramsMap);
			int rowCount = countByDpId(triDataBean.getDialPlanId());
			if (rowCount <= 0) {
				// explode ranges from TBL_TERMINATING_ROUTING and add each
				// individual TN entry in TBL_TRI_TN_DATA
				// List<TBlTerminatingRouting> tblTerminatingRoutingList =
				// tBlTerminatingRoutingMapper.selectByDpId(params);
				List<TBlTerminatingRouting> tblTerminatingRoutingList = selectTblTerminatingRoutingByDpId(triDataBean.getDialPlanId());
				if (tblTerminatingRoutingList.size() > 0) {
					// add TN entries in TBL_TRI_TN_DATA
					explodeRanges(tblTerminatingRoutingList);
				}
			}

			// Map<String, Object> params = new HashMap<String, Object>();
			// params.put("teleNum", triDataBean.getTn());

			// int count = tblTriTnDataMapper.deleteByTN(params);
			int count = deleteTblTriTnDataByTn(triDataBean.getTn());

			log.info("Inside TriService.deleteTri()- TN :" + triDataBean.getTn() + " successfully. Delete rows count :" + count);
		} catch (Exception e) {
			// e.printStackTrace();
			log.info(" failed! {}", e);
			log.error(e.getMessage());
			throw e;
		}
	}

	public void consolidateTriInfo(TblTriTnData triDataBean) throws Exception {
		log.info("Inside TriService.consolidateTriInfo()*********** ");
		try {
			String locationId = triDataBean.getLocationId();
			long dialPlanId = triDataBean.getDialPlanId();
			long envOrderId = triDataBean.getEnvOrderId();

			Map<String, Object> paramsMap = new HashMap<String, Object>();
			paramsMap.put("dialPlanId", triDataBean.getDialPlanId());

			// int rowCount = tblTriTnDataMapper.countByDpId(paramsMap);
			int rowCount = countByDpId(triDataBean.getDialPlanId());
			// List<TBlTerminatingRouting> tblTerminatingRoutingList =
			// tBlTerminatingRoutingMapper.selectByDpId(params);
			List<TBlTerminatingRouting> tblTerminatingRoutingList = selectTblTerminatingRoutingByDpId(triDataBean.getDialPlanId());
			if (rowCount <= 0) {
				// explode ranges from TBL_TERMINATING_ROUTING and add each
				// individual TN entry in TBL_TRI_TN_DATA

				if (tblTerminatingRoutingList.size() > 0) {
					// add TN entries in TBL_TRI_TN_DATA
					explodeRanges(tblTerminatingRoutingList);
				}
			}

			HashMap<String, String> existingRangesMap = new HashMap<String, String>();
			TBlTerminatingRouting tmpTerminatingRouting = null;
			for (TBlTerminatingRouting terminatingRouting : tblTerminatingRoutingList) {
				tmpTerminatingRouting = terminatingRouting;
				existingRangesMap.put(terminatingRouting.getRangeStart() + "-" + terminatingRouting.getRangeEnd(),
						terminatingRouting.getTerminatingRoutingId() + "");
			}

			log.info("Location ID:" + locationId + "  Dial Plan ID:" + dialPlanId + "  Envelop Order ID:" + envOrderId);

			Map<String, Object> params = new HashMap<String, Object>();
			// params.put("locationId", locationId);
			params.put("dialPlanId", dialPlanId);
			// params.put("envOrderId", envOrderId);

			// 1. Get the data from TBL_TRI_TN_DATA for a given Dial Plan ID and also capture first data object into triTnData
			List<String> rangesList = getTriTnDataRanges(dialPlanId);
			
			log.info("Inside TriService.consolidateTriInfo()- Final Ranges List: " + rangesList.toString());

			// Check for existing ranges and retain them. this retainRangesList
			// will
			// help to decide whether to delete the range from
			// TBL_TERMINATING_ROUTING or not.
			// If retainRangesList is having, no need to delete that row.
			List<String> retainRangesList = new ArrayList<String>();
			for (String newRange : rangesList) {
				if (existingRangesMap.containsKey(newRange)) {
					retainRangesList.add(newRange);
				}
			}

			List<String> finalRangesList = rangesList;

			// 3. Delete the TN Ranges from TBL_TERMINATING_ROUTING, which are
			// associated to Dial Plan ID. Lock the table intentionally
			Iterator<String> ite = existingRangesMap.keySet().iterator();
			String existingRange = null;
			while (ite.hasNext()) {
				existingRange = ite.next();
				if (retainRangesList.contains(existingRange)) {
					// this range is available in newly prepare ranges list.so
					// no
					// need to delete from TBL_TERMINATING_ROUTING. Just remove
					// that
					// entry from finalRangesList

					finalRangesList.remove(existingRange);

					continue;
				}
				params = new HashMap<String, Object>();
				// params.put("locationId", locationId);
				params.put("TerminatingRoutingId", existingRangesMap.get(existingRange));
				// tBlTerminatingRoutingMapper.deleteByTerminatingRoutingId(params);
				deleteTblTerminatingRoutingByTerminatingRoutingId(existingRangesMap.get(existingRange));
			}

			// 4. Add new ranges(data prepared into finalRangesList list) to
			// TBL_TERMINATING_ROUTING
			String rangeArr[] = null;
			TBlTerminatingRouting tBlTerminatingRouting = null;

			for (String range : finalRangesList) {
				rangeArr = range.split("-");
				if (triTnData != null) {
					tBlTerminatingRouting = new TBlTerminatingRouting();
					tBlTerminatingRouting.setDialPlanId(dialPlanId);
					tBlTerminatingRouting.setNoa(1L);
					tBlTerminatingRouting.setRangeStart(rangeArr[0]);
					tBlTerminatingRouting.setRangeEnd(rangeArr[1]);
					tBlTerminatingRouting.setP1url(triTnData.getP1url());
					tBlTerminatingRouting.setPringtime(triTnData.getPringtime());
					tBlTerminatingRouting.setPtrid(triTnData.getPtrid());
					tBlTerminatingRouting.setPprefixdgts(triTnData.getPprefixdgts());
					tBlTerminatingRouting.setPsuffixnum(triTnData.getPsuffixnum());
					tBlTerminatingRouting.setA1url(triTnData.getA1url());
					tBlTerminatingRouting.setA1ringtime(triTnData.getA1ringtime());
					tBlTerminatingRouting.setA1trid(triTnData.getA1trid());
					tBlTerminatingRouting.setA1prefixdgts(triTnData.getA1prefixdgts());
					tBlTerminatingRouting.setA1suffixnum(triTnData.getA1suffixnum());
					tBlTerminatingRouting.setA2url(triTnData.getA2url());
					tBlTerminatingRouting.setA2ringtime(triTnData.getA2ringtime());
					tBlTerminatingRouting.setA2trid(triTnData.getA2trid());
					tBlTerminatingRouting.setA2prefixdgts(triTnData.getA2prefixdgts());
					tBlTerminatingRouting.setA2suffixnum(triTnData.getA2suffixnum());
					tBlTerminatingRouting.setCreatedBy(triTnData.getCreatedBy() == null ? "ESAPADM":triTnData.getCreatedBy());
					tBlTerminatingRouting.setCreationDate(triTnData.getCreationDate());
					tBlTerminatingRouting.setModifiedBy(triTnData.getModifiedBy()== null ? "ESAPADM":triTnData.getModifiedBy());
					tBlTerminatingRouting.setLastModifiedDate(triTnData.getLastModifiedDate());
					tBlTerminatingRouting.setEnvOrderId(envOrderId);

					// tBlTerminatingRoutingMapper.insertSelectiveParams(tBlTerminatingRouting);
					insertTblTerminatingRouting(tBlTerminatingRouting);

					log.info("Inside TriService.consolidateTriInfo()- Range: <" + range + "> is inserted successfully.");
				}
			}
		} catch (Exception e) {
			// e.printStackTrace();
			log.info(" failed! {}", e);
			log.error(e.getMessage());
			// throw e;
		}
	}

	private List<String> getTriTnDataRanges(long dialPlanId) throws SQLException {
		// 1. Get the data from TBL_TRI_TN_DATA for a given Dial Plan ID
		List<TblTriTnData> tblTriTnDataList = selectTblTriTnDataByDpId(dialPlanId);

		List<String> rangesList = new ArrayList<String>();

		long tnRangeStart = -1;
		long tnRangeEnd = -1;
		long counter = 0;
		String tn = null;
		
		// 2. Prepare Ranges for a given Dial Plan ID
		for (TblTriTnData tnData : tblTriTnDataList) {
			tn = tnData.getTn();
			// System.out.println(tn);
			if (tnRangeStart == -1) {
				tnRangeStart = Long.parseLong(tn);
				tnRangeEnd = Long.parseLong(tn);

				// capture first bean for the TRI information
				setTriTnData(tnData);
			} else {
				if (tnRangeEnd + 1 == Long.parseLong(tn)) {
					tnRangeEnd = Long.parseLong(tn);
				} else if (tnRangeEnd == Long.parseLong(tn)) {
					tnRangeEnd = Long.parseLong(tn);
				} else {
					if (tnRangeStart != -1 && tnRangeEnd != -1) {
						// Range split is done here..so put one Start-End
						// Range
						// entry in rangesList
						rangesList.add(tnRangeStart + "-" + tnRangeEnd);
					}

					// set the current TN value as Range start and Range end
					tnRangeStart = Long.parseLong(tn);
					tnRangeEnd = Long.parseLong(tn);
				}
			}
			counter++;
		}

		// to handle last TN in the list
		if (counter == tblTriTnDataList.size()) {
			if (tnRangeStart != -1 && tnRangeEnd != -1) {
				// Range split is done here..so put one Range start-Range
				// end
				// entry in rangesList
				rangesList.add(tnRangeStart + "-" + tnRangeEnd);
			}
		}

		return rangesList;
	}
	private void explodeRanges(List<TBlTerminatingRouting> tblTerminatingRoutingList) throws SQLException {
		long tnRangeStart = -1;
		long tnRangeEnd = -1;
		TblTriTnData triDataBean = null;
		String sqlText = "insert into TBL_TRI_TN_DATA (" + "TN_ID, DIAL_PLAN_ID, LOCATION_ID, NOA, " + "TN, P1URL, PRINGTIME, PTRID, "
				+ "PPREFIXDGTS, PSUFFIXNUM, A1URL, A1RINGTIME, " + "A1TRID, A1PREFIXDGTS, A1SUFFIXNUM, A2URL,"
				+ " A2RINGTIME, A2TRID, A2PREFIXDGTS, A2SUFFIXNUM, " + "CREATED_BY, CREATION_DATE,MODIFIED_BY, LAST_MODIFIED_DATE, "
				+ "ENV_ORDER_ID ) values "
				+ "( TN_ID_TRI_SEQ.nextval, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, sysdate, ?,sysdate, ? )";
		
		PreparedStatement preparedStatement = null;
		try{
			preparedStatement = dbCon.prepareStatement(sqlText);
			
			for (TBlTerminatingRouting terminatingRouting : tblTerminatingRoutingList) {
				tnRangeStart = Long.parseLong(terminatingRouting.getRangeStart());
				tnRangeEnd = Long.parseLong(terminatingRouting.getRangeEnd());
				
				//delete existing range of data to make sure duplicates are not getting inserted.
				deleteExistingTriTnDataByRange(terminatingRouting.getDialPlanId(),terminatingRouting.getRangeStart(),terminatingRouting.getRangeEnd());
				
				log.info("Reload ranges into TBL_TRI_TN_DATA -Start Range :" + tnRangeStart + " and End Range:"+tnRangeEnd);
				int iteration = 1;
				for (long tn = tnRangeStart; tn <= tnRangeEnd; tn++) {
					triDataBean = new TblTriTnData();
	
					triDataBean.setTnId(1L);// dummy TN ID value
					triDataBean.setDialPlanId(terminatingRouting.getDialPlanId());
					triDataBean.setLocationId("-1");// Updating -1 for new exploded
													// rows. Later get the Location
													// ID for this TN and update in
													// TBL_TRI_TN_DATA for a given
													// TN
					triDataBean.setNoa(terminatingRouting.getNoa());
					triDataBean.setTn(tn + "");
					triDataBean.setP1url(terminatingRouting.getP1url());
					triDataBean.setPringtime(terminatingRouting.getPringtime());
					triDataBean.setPtrid(terminatingRouting.getPtrid());
					triDataBean.setPprefixdgts(terminatingRouting.getPprefixdgts());
					triDataBean.setPsuffixnum(terminatingRouting.getPsuffixnum());
					triDataBean.setA1url(terminatingRouting.getA1url());
					triDataBean.setA1ringtime(terminatingRouting.getA1ringtime());
					triDataBean.setA1trid(terminatingRouting.getA1trid());
					triDataBean.setA1prefixdgts(terminatingRouting.getA1prefixdgts());
					triDataBean.setA1suffixnum(terminatingRouting.getA1suffixnum());
					triDataBean.setA2url(terminatingRouting.getA2url());
					triDataBean.setA2ringtime(terminatingRouting.getA2ringtime());
					triDataBean.setA2trid(terminatingRouting.getA2trid());
					triDataBean.setA2prefixdgts(terminatingRouting.getA2prefixdgts());
					triDataBean.setA2suffixnum(terminatingRouting.getA2suffixnum());
					triDataBean.setCreatedBy(terminatingRouting.getCreatedBy());
					// triDataBean.setCreationDate(Calendar.getInstance().getTime());
					triDataBean.setModifiedBy(terminatingRouting.getModifiedBy());
					// triDataBean.setLastModifiedDate(Calendar.getInstance().getTime());
					triDataBean.setEnvOrderId(terminatingRouting.getEnvOrderId());
	
					//tblTriTnDataMapper.insertSelectiveParams(triDataBean);
					insertTblTriTnData(triDataBean,preparedStatement);
					if(iteration % 100 == 0){
						if(preparedStatement != null){
							int[] insertCount = preparedStatement.executeBatch();
							log.info("Last batch inserted upto TN :"+tn+"- Rows inserted into TBL_TRI_TN_DATA in this iteration is :" + insertCount.length);
							if(preparedStatement != null){
								preparedStatement.close();
								preparedStatement = null;
							}
							preparedStatement = dbCon.prepareStatement(sqlText);
						}
					}
					iteration++;
				}
				if(iteration % 100 > 0){
					if(preparedStatement != null){
						int[] insertCount = preparedStatement.executeBatch();
						log.info("Inserted upto TN :"+tnRangeEnd+"- Rows inserted into TBL_TRI_TN_DATA in this iteration is :" +insertCount.length);
						if(preparedStatement != null){
							preparedStatement.close();
							preparedStatement = null;
						}
						preparedStatement = dbCon.prepareStatement(sqlText);
					}
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw e;
		} finally {
			try {
				if (preparedStatement != null) {
					preparedStatement.close();
					preparedStatement = null;
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	private void deleteExistingTriTnDataByRange(long dialPlanId,String startRange,String endRange) throws SQLException{
		String deleteTriTnDataByRangeSql = "delete from tbl_tri_tn_data where DIAL_PLAN_ID=? and tn >= ? and tn <=?";
	
		PreparedStatement delPreparedStatement = null;
		try{
		delPreparedStatement = dbCon.prepareStatement(deleteTriTnDataByRangeSql);
		delPreparedStatement.setLong(1, dialPlanId);
		delPreparedStatement.setString(2, startRange);
		delPreparedStatement.setString(3, endRange);
		
		int rowsCount= delPreparedStatement.executeUpdate();
		
		log.info("Rows deleted from TBL_TRI_TN_DATA for range -Start Range :" + startRange + " and End Range:"+endRange+". Deleted rows count :" + rowsCount);
		} catch (SQLException e) {
			throw e;
		} finally {
			try {
				if(delPreparedStatement !=null){
					delPreparedStatement.close();
					delPreparedStatement = null;
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	private int countByDpId(long dpid) throws SQLException {
		String sqlText = "select count(*) from TBL_TRI_TN_DATA where DIAL_PLAN_ID=? and NOA=1";
		int count = 0;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		try {
			preparedStatement = dbCon.prepareStatement(sqlText);
			preparedStatement.setLong(1, dpid);

			resultSet = preparedStatement.executeQuery();

			while (resultSet.next()) {
				count = resultSet.getInt(1);
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw e;
		} finally {
			try {
				if (resultSet != null) {
					resultSet.close();
					resultSet = null;
				}
				if (preparedStatement != null) {
					preparedStatement.close();
					preparedStatement = null;
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return count;
	}

	private List<TBlTerminatingRouting> selectTblTerminatingRoutingByDpId(long dpid) throws SQLException {
		String sqlText = "select TERMINATING_ROUTING_ID, DIAL_PLAN_ID, NOA, RANGE_START, RANGE_END, P1URL, PRINGTIME, "
				+ "PTRID, PPREFIXDGTS, PSUFFIXNUM, A1URL, A1RINGTIME, A1TRID, A1PREFIXDGTS, A1SUFFIXNUM,"
				+ "A2URL, A2RINGTIME, A2TRID, A2PREFIXDGTS, A2SUFFIXNUM, CREATED_BY, CREATION_DATE,"
				+ "MODIFIED_BY, LAST_MODIFIED_DATE, ENV_ORDER_ID from TBL_TERMINATING_ROUTING where DIAL_PLAN_ID=? and NOA=1 ORDER BY TERMINATING_ROUTING_ID asc";
		int count = 0;
		List<TBlTerminatingRouting> tblTerminatingRoutingList = new ArrayList<TBlTerminatingRouting>();

		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		try {
			preparedStatement = dbCon.prepareStatement(sqlText);
			preparedStatement.setLong(1, dpid);

			resultSet = preparedStatement.executeQuery();
			TBlTerminatingRouting terminatingRouting = null;
			while (resultSet.next()) {
				terminatingRouting = new TBlTerminatingRouting();
				terminatingRouting.setTerminatingRoutingId(resultSet.getLong(1));
				terminatingRouting.setDialPlanId(resultSet.getLong(2));
				terminatingRouting.setNoa(resultSet.getLong(3));
				terminatingRouting.setRangeStart(resultSet.getString(4));
				terminatingRouting.setRangeEnd(resultSet.getString(5));
				terminatingRouting.setP1url(resultSet.getString(6));
				terminatingRouting.setPringtime(resultSet.getString(7));
				terminatingRouting.setPtrid(resultSet.getString(8));
				terminatingRouting.setPprefixdgts(resultSet.getString(9));
				terminatingRouting.setPsuffixnum(resultSet.getLong(10));
				terminatingRouting.setA1url(resultSet.getString(11));
				terminatingRouting.setA1ringtime(resultSet.getString(12));
				terminatingRouting.setA1trid(resultSet.getString(13));
				terminatingRouting.setA1prefixdgts(resultSet.getString(14));
				terminatingRouting.setA1suffixnum(resultSet.getLong(15));
				terminatingRouting.setA2url(resultSet.getString(16));
				terminatingRouting.setA2ringtime(resultSet.getString(17));
				terminatingRouting.setA2trid(resultSet.getString(18));
				terminatingRouting.setA2prefixdgts(resultSet.getString(19));
				terminatingRouting.setA2suffixnum(resultSet.getLong(20));
				terminatingRouting.setCreatedBy(resultSet.getString(21));
				terminatingRouting.setCreationDate(resultSet.getDate(22));
				terminatingRouting.setModifiedBy(resultSet.getString(23));
				terminatingRouting.setLastModifiedDate(resultSet.getDate(24));
				terminatingRouting.setEnvOrderId(resultSet.getLong(25));
				tblTerminatingRoutingList.add(terminatingRouting);
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw e;
		} finally {
			try {
				if (resultSet != null) {
					resultSet.close();
					resultSet = null;
				}
				if (preparedStatement != null) {
					preparedStatement.close();
					preparedStatement = null;
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return tblTerminatingRoutingList;
	}

	private void insertTblTriTnData(TblTriTnData triDataBean,PreparedStatement preparedStatement) throws SQLException {
//		String sqlText = "insert into TBL_TRI_TN_DATA (" + "TN_ID, DIAL_PLAN_ID, LOCATION_ID, NOA, " + "TN, P1URL, PRINGTIME, PTRID, "
//				+ "PPREFIXDGTS, PSUFFIXNUM, A1URL, A1RINGTIME, " + "A1TRID, A1PREFIXDGTS, A1SUFFIXNUM, A2URL,"
//				+ " A2RINGTIME, A2TRID, A2PREFIXDGTS, A2SUFFIXNUM, " + "CREATED_BY, CREATION_DATE,MODIFIED_BY, LAST_MODIFIED_DATE, "
//				+ "ENV_ORDER_ID ) values "
//				+ "( TN_ID_TRI_SEQ.nextval, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, sysdate, ?,sysdate, ? )";
		//PreparedStatement preparedStatement = null;

		try {
			//preparedStatement = dbCon.prepareStatement(sqlText);
			preparedStatement.setLong(1, triDataBean.getDialPlanId());
			preparedStatement.setString(2, triDataBean.getLocationId());
			preparedStatement.setLong(3, triDataBean.getNoa());
			preparedStatement.setString(4, triDataBean.getTn());
			preparedStatement.setString(5, triDataBean.getP1url());
			preparedStatement.setString(6, triDataBean.getPringtime());
			preparedStatement.setString(7, triDataBean.getPtrid());
			preparedStatement.setString(8, triDataBean.getPprefixdgts());
			preparedStatement.setLong(9, triDataBean.getPsuffixnum() != null ? triDataBean.getPsuffixnum() : 0);
			preparedStatement.setString(10, triDataBean.getA1url());
			preparedStatement.setString(11, triDataBean.getA1ringtime());
			preparedStatement.setString(12, triDataBean.getA1trid());
			preparedStatement.setString(13, triDataBean.getA1prefixdgts());
			preparedStatement.setLong(14, triDataBean.getA1suffixnum() != null ? triDataBean.getA1suffixnum() : 0);
			preparedStatement.setString(15, triDataBean.getA2url());
			preparedStatement.setString(16, triDataBean.getA2ringtime());
			preparedStatement.setString(17, triDataBean.getA2trid());
			preparedStatement.setString(18, triDataBean.getA2prefixdgts());
			preparedStatement.setLong(19, triDataBean.getA2suffixnum() != null ? triDataBean.getA2suffixnum() : 0);
			preparedStatement.setString(20, triDataBean.getCreatedBy());
			preparedStatement.setString(21, triDataBean.getModifiedBy());
			preparedStatement.setLong(22, triDataBean.getEnvOrderId());

			//int rowsCount = preparedStatement.executeUpdate();
			preparedStatement.addBatch();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw e;
		} finally {
			
		}
	}
	private void insertTblTriTnData(TblTriTnData triDataBean) throws SQLException {
		String sqlText = "insert into TBL_TRI_TN_DATA (" + "TN_ID, DIAL_PLAN_ID, LOCATION_ID, NOA, " + "TN, P1URL, PRINGTIME, PTRID, "
				+ "PPREFIXDGTS, PSUFFIXNUM, A1URL, A1RINGTIME, " + "A1TRID, A1PREFIXDGTS, A1SUFFIXNUM, A2URL,"
				+ " A2RINGTIME, A2TRID, A2PREFIXDGTS, A2SUFFIXNUM, " + "CREATED_BY, CREATION_DATE,MODIFIED_BY, LAST_MODIFIED_DATE, "
				+ "ENV_ORDER_ID ) values "
				+ "( TN_ID_TRI_SEQ.nextval, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, sysdate, ?,sysdate, ? )";
		PreparedStatement preparedStatement = null;
		try {
			//delete existing range of data to make sure duplicates are not getting inserted.
			deleteExistingTriTnDataByRange(triDataBean.getDialPlanId(),triDataBean.getTn(),triDataBean.getTn());
			
			//Reload the data
			preparedStatement = dbCon.prepareStatement(sqlText);
			preparedStatement.setLong(1, triDataBean.getDialPlanId());
			preparedStatement.setString(2, triDataBean.getLocationId());
			preparedStatement.setLong(3, triDataBean.getNoa());
			preparedStatement.setString(4, triDataBean.getTn());
			preparedStatement.setString(5, triDataBean.getP1url());
			preparedStatement.setString(6, triDataBean.getPringtime());
			preparedStatement.setString(7, triDataBean.getPtrid());
			preparedStatement.setString(8, triDataBean.getPprefixdgts());
			preparedStatement.setLong(9, triDataBean.getPsuffixnum() != null ? triDataBean.getPsuffixnum() : 0);
			preparedStatement.setString(10, triDataBean.getA1url());
			preparedStatement.setString(11, triDataBean.getA1ringtime());
			preparedStatement.setString(12, triDataBean.getA1trid());
			preparedStatement.setString(13, triDataBean.getA1prefixdgts());
			preparedStatement.setLong(14, triDataBean.getA1suffixnum() != null ? triDataBean.getA1suffixnum() : 0);
			preparedStatement.setString(15, triDataBean.getA2url());
			preparedStatement.setString(16, triDataBean.getA2ringtime());
			preparedStatement.setString(17, triDataBean.getA2trid());
			preparedStatement.setString(18, triDataBean.getA2prefixdgts());
			preparedStatement.setLong(19, triDataBean.getA2suffixnum() != null ? triDataBean.getA2suffixnum() : 0);
			preparedStatement.setString(20, triDataBean.getCreatedBy());
			preparedStatement.setString(21, triDataBean.getModifiedBy());
			preparedStatement.setLong(22, triDataBean.getEnvOrderId());

			int rowsCount = preparedStatement.executeUpdate();
			log.info("Rows inserted into TBL_TRI_TN_DATA is :" + rowsCount);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw e;
		} finally {
			try {
				if (preparedStatement != null) {
					preparedStatement.close();
					preparedStatement = null;
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	private int deleteTblTriTnDataByTn(String tn) throws SQLException {
		String sqlText = "delete from TBL_TRI_TN_DATA where TN=?";
		PreparedStatement preparedStatement = null;
		int rowsCount = 0;
		try {
			preparedStatement = dbCon.prepareStatement(sqlText);
			preparedStatement.setString(1, tn);

			rowsCount = preparedStatement.executeUpdate();

			log.info("Rows delete from TBL_TRI_TN_DATA for TN :" + tn + " Deleted rows count :" + rowsCount);

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw e;
		} finally {
			try {

				if (preparedStatement != null) {
					preparedStatement.close();
					preparedStatement = null;
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();

			}
		}
		return rowsCount;
	}

	private List<TblTriTnData> selectTblTriTnDataByDpId(long dpid) throws SQLException {
		String sqlText = "select TN_ID, DIAL_PLAN_ID, LOCATION_ID, NOA, TN, P1URL, PRINGTIME, PTRID, PPREFIXDGTS, "
				+ "  PSUFFIXNUM, A1URL, A1RINGTIME, A1TRID, A1PREFIXDGTS, A1SUFFIXNUM, A2URL, A2RINGTIME,"
				+ " A2TRID, A2PREFIXDGTS, A2SUFFIXNUM, CREATED_BY, CREATION_DATE, MODIFIED_BY, LAST_MODIFIED_DATE,"
				+ " ENV_ORDER_ID from TBL_TRI_TN_DATA where DIAL_PLAN_ID=? and (NOA=1 or NOA=0) ORDER BY TN asc";
		int count = 0;
		List<TblTriTnData> tblTriTnDataList = new ArrayList<TblTriTnData>();

		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		try {
			preparedStatement = dbCon.prepareStatement(sqlText);
			preparedStatement.setLong(1, dpid);

			resultSet = preparedStatement.executeQuery();
			TblTriTnData tblTriTnData = null;
			while (resultSet.next()) {
				tblTriTnData = new TblTriTnData();
				tblTriTnData.setTnId(resultSet.getLong(1));
				tblTriTnData.setDialPlanId(resultSet.getLong(2));
				tblTriTnData.setLocationId(resultSet.getString(3));
				tblTriTnData.setNoa(resultSet.getLong(4));
				tblTriTnData.setTn(resultSet.getString(5));
				tblTriTnData.setP1url(resultSet.getString(6));
				tblTriTnData.setPringtime(resultSet.getString(7));
				tblTriTnData.setPtrid(resultSet.getString(8));
				tblTriTnData.setPprefixdgts(resultSet.getString(9));
				tblTriTnData.setPsuffixnum(resultSet.getLong(10));
				tblTriTnData.setA1url(resultSet.getString(11));
				tblTriTnData.setA1ringtime(resultSet.getString(12));
				tblTriTnData.setA1trid(resultSet.getString(13));
				tblTriTnData.setA1prefixdgts(resultSet.getString(14));
				tblTriTnData.setA1suffixnum(resultSet.getLong(15));
				tblTriTnData.setA2url(resultSet.getString(16));
				tblTriTnData.setA2ringtime(resultSet.getString(17));
				tblTriTnData.setA2trid(resultSet.getString(18));
				tblTriTnData.setA2prefixdgts(resultSet.getString(19));
				tblTriTnData.setA2suffixnum(resultSet.getLong(20));
				tblTriTnData.setCreatedBy(resultSet.getString(21));
				tblTriTnData.setCreationDate(resultSet.getDate(22));
				tblTriTnData.setModifiedBy(resultSet.getString(23));
				tblTriTnData.setLastModifiedDate(resultSet.getDate(24));
				tblTriTnData.setEnvOrderId(resultSet.getLong(25));
				tblTriTnDataList.add(tblTriTnData);
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw e;
		} finally {
			try {
				if (resultSet != null) {
					resultSet.close();
					resultSet = null;
				}
				if (preparedStatement != null) {
					preparedStatement.close();
					preparedStatement = null;
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return tblTriTnDataList;
	}

	private int deleteTblTerminatingRoutingByTerminatingRoutingId(String terminatingRoutingId) throws SQLException {
		String sqlText = "delete from TBL_TERMINATING_ROUTING where TERMINATING_ROUTING_ID=?";
		PreparedStatement preparedStatement = null;
		int rowsCount = 0;
		try {
			preparedStatement = dbCon.prepareStatement(sqlText);
			preparedStatement.setString(1, terminatingRoutingId);

			rowsCount = preparedStatement.executeUpdate();

			log.info("Rows delete from TBL_TERMINATING_ROUTING for terminatingRoutingId :" + terminatingRoutingId + " Deleted rows count :"
					+ rowsCount);

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw e;
		} finally {
			try {

				if (preparedStatement != null) {
					preparedStatement.close();
					preparedStatement = null;
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return rowsCount;
	}

	private void insertTblTerminatingRouting(TBlTerminatingRouting tBlTerminatingRouting) throws SQLException {
		String sqlText = "insert into TBL_TERMINATING_ROUTING (TERMINATING_ROUTING_ID, DIAL_PLAN_ID,"
				+ "      NOA, RANGE_START, RANGE_END," + "      P1URL, PRINGTIME, PTRID," + "      PPREFIXDGTS, PSUFFIXNUM, A1URL,"
				+ "      A1RINGTIME, A1TRID, A1PREFIXDGTS," + "      A1SUFFIXNUM, A2URL, A2RINGTIME,"
				+ "      A2TRID, A2PREFIXDGTS, A2SUFFIXNUM," + "      CREATED_BY, CREATION_DATE, MODIFIED_BY,"
				+ "      LAST_MODIFIED_DATE, ENV_ORDER_ID)" + "   values (TERMINATING_ROUTING_ID_SEQ.nextval, ?," + "      ?, ?, ?,"
				+ "      ?, ?, ?," + "      ?, ?, ?, " + "     ?, ?, ?, " + "      ?, ?, ?," + "     ?, ?, ?," + "      ?, sysdate, ?,"
				+ "      sysdate, ?)";
		PreparedStatement preparedStatement = null;
		try {
			preparedStatement = dbCon.prepareStatement(sqlText);
			preparedStatement.setLong(1, tBlTerminatingRouting.getDialPlanId());
			preparedStatement.setLong(2, tBlTerminatingRouting.getNoa());
			preparedStatement.setString(3, tBlTerminatingRouting.getRangeStart());
			preparedStatement.setString(4, tBlTerminatingRouting.getRangeEnd());
			preparedStatement.setString(5, tBlTerminatingRouting.getP1url());
			preparedStatement.setString(6, tBlTerminatingRouting.getPringtime());
			preparedStatement.setString(7, tBlTerminatingRouting.getPtrid());
			preparedStatement.setString(8, tBlTerminatingRouting.getPprefixdgts());
			preparedStatement.setLong(9, tBlTerminatingRouting.getPsuffixnum() != null ? tBlTerminatingRouting.getPsuffixnum() : 0);
			preparedStatement.setString(10, tBlTerminatingRouting.getA1url());
			preparedStatement.setString(11, tBlTerminatingRouting.getA1ringtime());
			preparedStatement.setString(12, tBlTerminatingRouting.getA1trid());
			preparedStatement.setString(13, tBlTerminatingRouting.getA1prefixdgts());
			preparedStatement.setLong(14, tBlTerminatingRouting.getA1suffixnum() != null ? tBlTerminatingRouting.getA1suffixnum() : 0);
			preparedStatement.setString(15, tBlTerminatingRouting.getA2url());
			preparedStatement.setString(16, tBlTerminatingRouting.getA2ringtime());
			preparedStatement.setString(17, tBlTerminatingRouting.getA2trid());
			preparedStatement.setString(18, tBlTerminatingRouting.getA2prefixdgts());
			preparedStatement.setLong(19, tBlTerminatingRouting.getA2suffixnum() != null ? tBlTerminatingRouting.getA2suffixnum() : 0);
			preparedStatement.setString(20, tBlTerminatingRouting.getCreatedBy());
			preparedStatement.setString(21, tBlTerminatingRouting.getModifiedBy());
			preparedStatement.setLong(22, tBlTerminatingRouting.getEnvOrderId());

			int rowsCount = preparedStatement.executeUpdate();

			log.info("Rows inserted into TBL_TERMINATING_ROUTING is :" + rowsCount);

		} catch (SQLException e) {
			e.printStackTrace();
			
			//handle the exception if it is unique constraint error
			if(e.toString().indexOf("ORA-00001") >= 0){
				log.info("Entered into catch block to handle SQLIntegrityConstraintViolationException-SQL Error Code :"+e.getErrorCode()+" SQL State :"+e.getSQLState());
				//delete existing range to avoid unique constraint
				deleteTblTerminatingRoutingByDpidNoaRangeStart(tBlTerminatingRouting.getDialPlanId(),tBlTerminatingRouting.getNoa(),tBlTerminatingRouting.getRangeStart());
				//then insert new range
				int rowsCount = preparedStatement.executeUpdate();
				log.info("Inserting row again into TBL_TERMINATING_ROUTING. Inserted rows count is :" + rowsCount);
				
			}else{
				throw e;
			}
		} finally {
			try {
				if (preparedStatement != null) {
					preparedStatement.close();
					preparedStatement = null;
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	private int deleteTblTerminatingRoutingByDpidNoaRangeStart(long dpid,long noa,String rangeStart) throws SQLException {
		String sqlText = "delete from tbl_terminating_routing where Dial_Plan_Id=? and noa=? and range_start=?";
		PreparedStatement preparedStatement = null;
		int rowsCount = 0;
		try {
			preparedStatement = dbCon.prepareStatement(sqlText);
			preparedStatement.setLong(1, dpid);
			preparedStatement.setLong(2, noa);
			preparedStatement.setString(3, rangeStart);

			rowsCount = preparedStatement.executeUpdate();

			log.info("Delete row from TBL_TERMINATING_ROUTING for DIAL PLAN ID :" + dpid + " and NOA:"+noa+" and Range Start :"+rangeStart+". Deleted Rows count :"+
					+ rowsCount);

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw e;
		} finally {
			try {

				if (preparedStatement != null) {
					preparedStatement.close();
					preparedStatement = null;
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return rowsCount;
	}
}// EOF

