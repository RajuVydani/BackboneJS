package com.vz.fxo.inventory.actionfunction.support;


import java.sql.Timestamp;

public class IpSecSearchBean {

	public IpSecSearchBean(){
		ipsecRequestStatus = -1;
        ipsecTunnelId=-1;
    }
	private String ikeIp;
	private String custId;
	private String name;
	private String requestDtFrom;
	private String requestDtTo;
	private String requestInstallFrom;
	private String requestInstallTo;
	private String requestBy;  
    private int ipsecTunnelId;
    private int ipsecRequestStatus;
    private String preshareKey;
    private String custIdOrCustName;
    private int regionType;
	
	public String getIkeIp() {
		return ikeIp;
	}
	public void setIkeIp(String ikeIp) {
		this.ikeIp = ikeIp;
	}
	public String getCustId() {
		return custId;
	}
	public void setCustId(String custId) {
		this.custId = custId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	/*public Timestamp getRequestDate() {
		return requestDate;
	}
	public void setRequestDate(Timestamp requestDate) {
		this.requestDate = requestDate;
	}
	public Timestamp getRequestInstall() {
		return requestInstall;
	}
	public void setRequestInstall(Timestamp requestInstall) {
		this.requestInstall = requestInstall;
	}*/
	public String getRequestBy() {
		return requestBy;
	}
	public void setRequestBy(String requestBy) {
		this.requestBy = requestBy;
	}
	public String getRequestDtFrom() {
		return requestDtFrom;
	}
	public void setRequestDtFrom(String requestDtFrom) {
		this.requestDtFrom = requestDtFrom;
	}
	public String getRequestDtTo() {
		return requestDtTo;
	}
	public void setRequestDtTo(String requestDtTo) {
		this.requestDtTo = requestDtTo;
	}
	public String getRequestInstallFrom() {
		return requestInstallFrom;
	}
	public void setRequestInstallFrom(String requestInstallFrom) {
		this.requestInstallFrom = requestInstallFrom;
	}
	public String getRequestInstallTo() {
		return requestInstallTo;
	}
	public void setRequestInstallTo(String requestInstallTo) {
		this.requestInstallTo = requestInstallTo;
	}
    public int getIpsecTunnelId() {
		return ipsecTunnelId;
	}
	public void setIpsecTunnelId(int ipsecTunnelId) {
		this.ipsecTunnelId = ipsecTunnelId;
	}
	public int getIpsecRequestStatus() {
		return ipsecRequestStatus;
	}
	public void setIpsecRequestStatus(int ipsecRequestStatus) {
		this.ipsecRequestStatus = ipsecRequestStatus;
	}
	public String getPreshareKey() {
		return preshareKey;
	}
	public void setPreshareKey(String preshareKey) {
		this.preshareKey = preshareKey;
	}
	public String getCustIdOrCustName() {
		return custIdOrCustName;
	}
	public void setCustIdOrCustName(String custIdOrCustName) {
		this.custIdOrCustName = custIdOrCustName;
	}
	public int getRegionType() {
		return regionType;
	}
	public void setRegionType(int regionType) {
		this.regionType = regionType;
	}
	
	
}
