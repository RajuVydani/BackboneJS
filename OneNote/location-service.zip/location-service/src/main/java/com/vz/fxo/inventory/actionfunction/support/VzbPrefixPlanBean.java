package com.vz.fxo.inventory.actionfunction.support;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

public class VzbPrefixPlanBean {
	

	protected String locationId;
	protected long prefixPlanId;
	protected String customerId;
	protected String prefixName;
	protected long mobile;
	protected String createdBy;
	protected Timestamp creationDate;
	protected Timestamp lastModifiedDate;
	protected String modifiedBy;
	protected List<String> logTrail;
	
	public VzbPrefixPlanBean() {
		this.locationId= new String("");
		this.prefixPlanId= 0;
		this.customerId= new String("");
		this.prefixName= new String("");
		this.mobile = 0;
		this.creationDate = null;
		this.lastModifiedDate = null;
		this.logTrail = new ArrayList<String>();
	}

	public VzbPrefixPlanBean(VzbPrefixPlanBean vpp) {
		this.locationId = vpp.getLocationId();
        this.prefixPlanId = vpp.getPrefixPlanId();
        this.customerId = vpp.getCustomerId();
        this.prefixName = vpp.getPrefixName();
        this.mobile = vpp.getMobile();
		this.createdBy= vpp.getCreatedBy();
		this.modifiedBy = vpp.getModifiedBy();
		this.creationDate = vpp.getCreationDate();
		this.lastModifiedDate = vpp.getLastModifiedDate();
		this.logTrail = vpp.logTrail;
	}

	public String getLocationId() {
		return locationId;
	}
	public void setLocationId(String locationId) {
		this.locationId = locationId;
	}
	
	public long getPrefixPlanId() {
		return prefixPlanId;
	}
	public void setPrefixPlanId(long prefixPlanId) {
		this.prefixPlanId = prefixPlanId;
	}

	public String getCustomerId() {
        return customerId;
    }
    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

	public String getPrefixName() {
		return prefixName;
	}
	public void setPrefixName(String prefixName) {
		this.prefixName = prefixName;
	}
	
	public long getMobile() {
		return mobile;
	}
	public void setMobile(long mobile) {
		this.mobile = mobile;
	}

	public void setCreationDate(Timestamp creationDate) {
		this.creationDate = creationDate;
	}

	public Timestamp getCreationDate() {
		return creationDate;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}	

	public Timestamp getLastModifiedDate() {
		return lastModifiedDate;
	}	

	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	
    public void setLogTrail(String logStr) {
		logTrail.add(logStr);
	}

	public List<String> getLogTrail() {
		return logTrail;
	}

	public String toString() {
		return "VzbPrefixPlanBean=[" + "locationId=" + locationId+ ", "
				+ "customerId=" + customerId+ ", " + "prefixName="
				+ prefixName + ", " + "mobile=" + mobile + ", " 
				+"createdBy=" + createdBy + ", " + "creationDate="
				+ creationDate + ", " + "lastModifiedDate=" + lastModifiedDate + ","
				+ "modifiedBy=" + modifiedBy +"]";
	}



}
