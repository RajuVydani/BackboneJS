package com.vz.fxo.inventory.actionfunction.support;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import EsapEnumPkg.VzbVoipEnum;
import esap.db.DBTblBsAs;
import esap.db.IpcomLocationDbBean;

public class LocationBean implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	// members
	//Xo changes
	protected List<PolicyFeaturesBean> policyFeaturesList;
	protected String eslId;
	protected String redundency; 
	protected String redundencyId; 
	protected String billingTN;
	protected String broadworksPortalNumber;
	protected String groupUserLimit;
	protected String locGroupId;
	protected String redundencyPriorityType;
	protected long policyServicesId;
	protected String policyType;
	
	/*protected String bwEnterpriseId;
	
	protected String eslBwGroupId;
	protected String bsTimeZone;
	protected String adminFirstName;
	protected String adminLastName;	
	protected String adminEmail;	
	protected String adminWebLoginId;
	protected String adminPassword;
	protected String domainName;
	protected String billingTN;
	//protected String broadworksPortalNumber;
	//protected String groupUserLimit;
	protected String outgoingOriginatingPlan;
	protected String outgoingRedirectingPlan;
	protected String outgoingRedirectedPlan;
	protected String outgoingDigitOriginatingPlan;
	protected String outgoingDigitRedirectingPlan;
	protected String incomingPlan;
	protected String incomingDigitPattern;*/

	
	public String getPolicyType() {
		return policyType;
	}

	public void setPolicyType(String policyType) {
		this.policyType = policyType;
	}

	//Xo changes end
	protected List<FeaturePackageBean> featurePkgList;
	protected List<GatewayDeviceBean> deviceList;
	protected List<VmAccessBean> vmAccessList;
	protected List<AcctAuthCodesBean> authCodesList;
	protected List<PrefixPlanBean> prefixPlanList;
	protected DBTblBsAs bsAsDbBean;
	protected CallingPlanBean callingPlanBean;
	protected List<PrefixRoutingBean> prefixRouting;
	protected List<PublicTnPoolBean> publicTnPool;
	protected List<DialPlanBean> dialPlanList;
	protected List<FeaturesBean> locationFeatures;
	protected List<String> logTrail;
	protected String locationId;
	protected String enterpriseId;
	protected long dialPlanId;
	protected String orderSource;
	protected String locationName;
	protected String locAddress;
	protected String locCity;
	protected String locState;
	protected String locZip;
	protected String locCountry;
	protected String npaNxx;
	protected String timeZone;// chk tbl
	protected int timeZoneId;
	protected long useDaylightSaving;// YesNoType
	protected String dayLightSavingsRegion;
	protected long webLang;
	protected String webLangStr;
	protected long ixPlusId;
	protected String ixPlusEnvId;
	protected String billTn; // emergencycallLine from the order
	protected long billTnPoolId;
	protected int billType;
	protected String billAccountNumber;
	protected String netcomServiceId;
	protected long cv2Service; // YesNoType
	protected String clin; // SIP Truning Clin changes
	protected long managedService; // YesNoType
	protected long enableDhcp; // YesNoType
	protected String DNS1Address;
	protected String DNS2Address;
	protected long serviceTypeOffering; // platform
	protected long voipServiceType;
	protected long hybridServiceType;
	protected long pubIp;// yesNoType
	protected long accessType;
	protected String circuitId;
	protected String uunetSiteId;
	protected String sipDomain;
	protected long sbcInd;
	protected long sbcId;
	protected long sipEnabled;
	protected long publicGtwyDpid;
	protected long defaultGtwyDpid;
	protected long trunkType;
	protected String trunk;
	protected long voipClub; // YesNoType
	protected long serviceLevel;
	protected long locMarket;// LocationMarketType
	protected long maxExtLength;
	protected long extLength;
	protected long privateNumLength;
	protected long linePortLength;
	protected String abbrDialingCode;// YesNOType
	protected long enableCallPark;
	protected long overrideCidNum;
	protected long overrideCidName;
	protected String cidTn;
	protected String contactPhone;
	protected String contactName;
	protected String contactEmail;
	protected String actTeamPhone;
	protected String actTeamName;
	protected String actTeamEmail;
	protected long enableAccountCode;
	protected String enableAuthCode;
	protected String localDirAssistance; // enums??
	protected String natDirAssistance;// enums??
	protected long concCallStat;
	protected long maxConcurrentCalls;
	protected long maxConcurrentOffnet;
	protected long maxInbound;
	protected long maxSlg;
	protected long maxNg;
	protected long maxSubscribers;
	protected long maxPublicTn;
	protected long blockAllCalls; // YesNoType
	protected String rpid;
	protected long rpidPriv;
	protected String rpidTn;
	protected long rpidPoolId;
	protected long hicrService;
	protected long premiseVm;
	protected long callingPlanId;
	protected long vmLang;
	protected String vmLangStr;
	protected long maxVmBox;
	protected long activeInd;// YesNoType
	protected long sbcMigInd;// YesNoType
	protected long productionIndicator;// YesNoType
	protected long vmType;
	protected long overrideSubPrivate;
	protected String switchClli;
	protected String vmCpeIpAddress;
	protected long vmSmdiAuthToggle = -1;
	protected java.sql.Timestamp activeDate;
	protected String createdBy;
	protected String modifiedBy;
	protected java.sql.Timestamp creationDate;
	protected java.sql.Timestamp lastModifiedDate;
	protected boolean getAll;
	protected long envOrderId;
	protected int emerPoolId;
	protected String emerBtn;
	protected String emerLocationCode;
	protected String emerLocationCodeDesc;
	protected long emerLocationCodeId;
	protected long locationType;
	protected long fmcgLocationType;
	protected String hubLocationId;
	protected long hubGatewayDeviceId;
	protected long baPortalPoolId;
	protected long locationMask;
	protected long aNumMask;
	protected long bNumMask;
	protected long qosInd;
	protected String vpnName;
	protected int tblVpnIdMappingId;
	protected long sbcProvMethod;
	protected long rivLocation;
	protected long asId;
	protected long afterHoursInstallFlag;
	protected long highVolumeInstallFlag;
	protected long expedite;
	protected long locCclInd;
	protected long billingActivated;
	protected long callingNameInd;
	protected long enhancedAniInd;
	protected long sTnPoolId;
	protected String sTn; // screened TN from the order
	protected String teleworkerFqdn; // FMCg Phase II
	protected int twSbcId; // FMCg Phase II
	// Jan 2011 Release Changes
	protected String iasaOrderId;
	protected String locTerritory;
	protected String locRegion;
	protected long billingSystem;
	protected long defaultPpId;
	protected String productIdentifier;
	protected long configAllowed;
	// May 2011 release change
	protected short alternativeCallerIdInd;
	protected short e911Service;
	// 53938.AA Business Continuity Ph 1 - changes for july 2011
	protected String varrsFlag;
	// protected long isrDesignId;
	protected String subAgencyHierCode;
	protected String physicalLocationId;
	protected String physicalLocationName;
	protected String dialingCountryCode;
	protected short restrictedAccess;
	protected String callFwdPlanName;
	protected String lorId;
	protected short hybridAssigned;
	protected short e2eimigflag;
	protected long enterpriseTrunkId;
	protected long pqInstanceId;

	protected short uiProvFlag; // added by z658915 for UI_PROV_FLAG
	protected short calnetSubContractId; // added by z658915 for CALNET_SUB_CONTRACT_ID
	protected String addressId;
	protected String pendingRpid;
	protected long isrDesignId;
	protected List<TblEntBillFeaturesBean> entBillFeatBeanList;
	protected long CnamUpdateStatus;
	protected short tsoMigLock;
	protected java.sql.Timestamp CnamUpdateDate;
	protected String vce;
    protected String BANID; 

	public String getBANID() {
		return BANID;
	}

	public void setBANID(String bANID) {
		BANID = bANID;
	}
        

	/**
	 * Default Constructor -- Initializes all fields to default values.
	 */
	public LocationBean() {
		this.featurePkgList = new ArrayList<FeaturePackageBean>();
		this.deviceList = new ArrayList<GatewayDeviceBean>();
		this.prefixPlanList = new ArrayList<PrefixPlanBean>();
		this.bsAsDbBean = new DBTblBsAs();
		this.authCodesList = new ArrayList<AcctAuthCodesBean>();
		this.vmAccessList = new ArrayList<VmAccessBean>();
		this.prefixRouting = new ArrayList<PrefixRoutingBean>();
		this.publicTnPool = new ArrayList<PublicTnPoolBean>();
		this.dialPlanList = new ArrayList<DialPlanBean>();
		this.locationFeatures = new ArrayList<FeaturesBean>();
		this.policyFeaturesList = new ArrayList<PolicyFeaturesBean>();
		this.logTrail = new ArrayList<String>();
		this.locationId = new String("NONE");
		this.enterpriseId = new String("NONE");
		this.dialPlanId = -1;
		this.orderSource = new String("NONE");
		this.locationName = new String("NONE");
		this.locAddress = new String("NONE");
		this.locCity = new String("NONE");
		this.locState = new String("NONE");
		this.locZip = new String("NONE");
		this.locCountry = new String("NONE");
		this.npaNxx = new String("NONE");
		this.timeZone = new String("NONE");
		this.timeZoneId = -1;
		this.useDaylightSaving = -1;
		this.dayLightSavingsRegion = new String("NONE");
		this.webLang = -1;
		this.webLangStr = new String("NONE");
		this.ixPlusId = -1;
		this.ixPlusEnvId = new String("NONE");
		this.billTn = new String("NONE");
		this.billTnPoolId = -1;
		this.billType = -1;
		this.billAccountNumber = new String("NONE");
		this.netcomServiceId = new String("NONE");
		this.clin = new String("NONE");
		this.cv2Service = -1;
		this.managedService = -1;
		this.qosInd = -1;
		this.enableDhcp = -1;
		DNS1Address = new String("NONE");
		DNS2Address = new String("NONE");
		this.serviceTypeOffering = -1;
		this.voipServiceType = -1;
		this.hybridServiceType = -1;
		this.pubIp = -1;
		this.accessType = -1;
		this.circuitId = new String("NONE");
		this.uunetSiteId = new String("NONE");
		this.sipDomain = new String("NONE");
		this.trunk = new String("NONE");
		this.sbcInd = -1;
		this.sbcId = -1;
		this.sipEnabled = -1;
		this.publicGtwyDpid = -1;
		this.defaultGtwyDpid = -1;
		this.trunkType = -1;
		this.voipClub = -1;
		this.serviceLevel = -1;
		this.locMarket = -1;
		this.maxExtLength = -1;
		this.extLength = -1;
		this.privateNumLength = -1;
		this.linePortLength = -1;
		this.abbrDialingCode = new String("NONE");
		this.enableCallPark = -1;
		this.overrideCidNum = -1;
		this.overrideCidName = -1;
		this.cidTn = new String("NONE");
		this.contactPhone = new String("NONE");
		this.contactName = new String("NONE");
		this.contactEmail = new String("NONE");
		this.actTeamPhone = new String("NONE");
		this.actTeamName = new String("NONE");
		this.actTeamEmail = new String("NONE");
		this.enableAccountCode = -1;
		this.enableAuthCode = new String("NONE");
		this.localDirAssistance = new String("NONE");
		this.natDirAssistance = new String("NONE");
		this.concCallStat = -1;
		this.maxConcurrentCalls = -1;
		this.maxConcurrentOffnet = -1;
		this.maxInbound = -1;
		this.maxSlg = -1;
		this.maxNg = -1;
		this.maxSubscribers = -1;
		this.maxPublicTn = -1;
		this.blockAllCalls = -1;
		this.rpid = new String("NONE");
		this.rpidPriv = -1;
		this.pendingRpid = new String("NONE");
		this.rpidTn = new String("NONE");
		this.rpidPoolId = -1;
		this.hicrService = -1;
		this.premiseVm = -1;
		this.callingPlanId = -1;
		this.vmLang = -1;
		this.vmLangStr = new String("NONE");
		this.maxVmBox = -1;
		this.activeInd = 1;
		this.sbcMigInd = 0;
		this.productionIndicator = -1;
		this.vmType = -1;
		this.overrideSubPrivate = -1;
		this.switchClli = new String("NONE");
		this.vmCpeIpAddress = new String("NONE");
		this.vmSmdiAuthToggle = -1;
		this.createdBy = new String("NONE");
		this.modifiedBy = new String("NONE");
		this.creationDate = null;
		this.activeDate = null;
		this.lastModifiedDate = null;
		this.getAll = false;
		this.envOrderId = -1;
		this.emerPoolId = -1;
		this.emerBtn = new String("NONE");
		this.emerLocationCode = new String("NONE");
		this.emerLocationCodeDesc = new String("NONE");
		this.emerLocationCodeId = -1;
		this.locationType = -1;
		this.fmcgLocationType = -1;
		this.hubLocationId = new String("NONE");
		this.hubGatewayDeviceId = -1;
		this.baPortalPoolId = -1;
		this.locationMask = -1;
		this.aNumMask = -1;
		this.bNumMask = -1;
		this.vpnName = new String("NONE");
		this.tblVpnIdMappingId = -1;
		this.sbcProvMethod = -1;
		this.rivLocation = -1;
		this.afterHoursInstallFlag = -1;
		this.highVolumeInstallFlag = -1;
		this.expedite = -1;
		this.locCclInd = -1;
		this.billingActivated = -1;
		this.callingNameInd = -1;
		this.enhancedAniInd = -1;
		this.sTn = new String("NONE");
		this.sTnPoolId = -1;
		this.teleworkerFqdn = new String("NONE"); // FMCg Phase II
		this.twSbcId = -1; // FMCg Phase II
		// Jan 2011 Release changes
		this.iasaOrderId = "NONE";
		this.locTerritory = "NONE";
		this.locRegion = "NONE";
		this.billingSystem = -1;
		this.defaultPpId = -1;
		this.productIdentifier = "";
		this.configAllowed = -1;
		// May 2011 release change
		this.alternativeCallerIdInd = 0;
		this.e911Service = -1;
		// 53938.AA Business Continuity Ph 1 - changes for july 2011
		this.varrsFlag = "N";
		// this.isrDesignId = -1;
		this.subAgencyHierCode = "NONE";
		// Jan 2013 Release - E2EI
		this.physicalLocationId = "NONE";
		this.physicalLocationName = "NONE";
		this.dialingCountryCode = "NONE";
		this.restrictedAccess = -1;
		this.callFwdPlanName = "NONE";
		this.lorId = "NONE";
		this.hybridAssigned = -1;
		this.enterpriseTrunkId = -1;
		this.e2eimigflag = -1;
		this.pqInstanceId = -1;

		this.uiProvFlag = -1; // added by z658915
		this.calnetSubContractId = -1; // added by z658915
		this.addressId = null;
		this.isrDesignId = -1;
		this.CnamUpdateStatus = -1;
		this.CnamUpdateDate = null;
		this.tsoMigLock = -1;
		entBillFeatBeanList = new ArrayList<TblEntBillFeaturesBean>();
                this.BANID="NONE";
        // VCE changes
        this.vce = new String("NONE");
               

	}

	public void clearLocation() {
		this.enterpriseId = "";
		this.orderSource = "";
		this.locationName = "";
		this.locAddress = "";
		this.locCity = "";
		this.locState = "";
		this.locZip = "";
		this.locCountry = "";
		this.npaNxx = "";
		this.timeZone = "";
		this.dayLightSavingsRegion = "";
		this.webLangStr = "";
		this.ixPlusEnvId = "";
		this.billTn = "";
		this.billAccountNumber = "";
		this.netcomServiceId = "";
		DNS1Address = "";
		DNS2Address = "";
		this.circuitId = "";
		this.uunetSiteId = "";
		this.sipDomain = "";
		this.trunk = "";
		this.cidTn = "";
		this.abbrDialingCode = "";
		this.contactPhone = "";
		this.contactName = "";
		this.contactEmail = "";
		this.actTeamPhone = "";
		this.actTeamName = "";
		this.actTeamEmail = "";
		this.enableAuthCode = "";
		this.localDirAssistance = "";
		this.natDirAssistance = "";
		this.rpid = "";
		this.rpidTn = "";
		this.pendingRpid = "";
		this.vmLangStr = "";
		this.switchClli = "";
		this.vmCpeIpAddress = "";
		this.createdBy = "";
		this.modifiedBy = "";
		this.emerLocationCode = "";
		this.emerLocationCodeDesc = "";
		this.hubLocationId = "";
		this.vpnName = "";
		this.sbcProvMethod = -1;
		this.emerBtn = "";
		this.sTn = "";
		this.teleworkerFqdn = ""; // FMCg Phase II
		// Jan 2011 Release changes
		this.iasaOrderId = "";
		this.locTerritory = "";
		this.locRegion = "";
		this.billingSystem = -1;
		this.defaultPpId = -1;
		this.productIdentifier = "";
		this.configAllowed = -1;
		// May 2011 release change
		this.alternativeCallerIdInd = 0;
		this.e911Service = -1;
		// 53938.AA Business Continuity Ph 1 - changes for july 2011
		this.varrsFlag = "N";
		// this.isrDesignId = -1;
		this.subAgencyHierCode = "";
		// Jan 2013 Release - E2EI
		this.physicalLocationId = "";
		this.physicalLocationName = "";
		this.dialingCountryCode = "";
		this.restrictedAccess = 0;
		this.callFwdPlanName = "";
		this.lorId = "";
		this.hybridAssigned = -1;
		this.e2eimigflag = -1;
		this.enterpriseTrunkId = -1;
		this.pqInstanceId = -1;

		this.uiProvFlag = -1; // added by z658915
		this.calnetSubContractId = -1; // added by z658915
		this.addressId = "";
		this.isrDesignId = -1;
                this.BANID="";
        // VCE changes
        this.vce = "";
        
	}

	/**
	 * Constructor
	 * 
	 * @param locBean
	 */
	public LocationBean(LocationBean locBean) {
		this.featurePkgList = locBean.featurePkgList;
		this.deviceList = locBean.deviceList;
		this.vmAccessList = locBean.vmAccessList;
		this.authCodesList = locBean.authCodesList;
		this.prefixPlanList = locBean.prefixPlanList;
		this.bsAsDbBean = locBean.bsAsDbBean;
		this.callingPlanBean = locBean.callingPlanBean;
		this.prefixRouting = locBean.prefixRouting;
		this.publicTnPool = locBean.publicTnPool;
		this.dialPlanList = locBean.dialPlanList;
		this.locationFeatures = locBean.locationFeatures;
		this.logTrail = locBean.logTrail;
		this.locationId = locBean.locationId;
		this.enterpriseId = locBean.enterpriseId;
		this.dialPlanId = locBean.dialPlanId;
		this.orderSource = locBean.orderSource;
		this.locationName = locBean.locationName;
		this.locAddress = locBean.locAddress;
		this.locCity = locBean.locCity;
		this.locState = locBean.locState;
		this.locZip = locBean.locZip;
		this.locCountry = locBean.locCountry;
		this.npaNxx = locBean.npaNxx;
		this.timeZone = locBean.timeZone;
		this.timeZoneId = locBean.timeZoneId;
		this.useDaylightSaving = locBean.useDaylightSaving;
		this.dayLightSavingsRegion = locBean.dayLightSavingsRegion;
		this.webLang = locBean.webLang;
		this.webLangStr = locBean.webLangStr;
		this.ixPlusId = locBean.ixPlusId;
		this.ixPlusEnvId = locBean.ixPlusEnvId;
		this.billTn = locBean.billTn;
		this.billTnPoolId = locBean.billTnPoolId;
		this.billType = locBean.billType;
		this.billAccountNumber = locBean.billAccountNumber;
		this.netcomServiceId = locBean.netcomServiceId;
		this.clin = locBean.clin;
		this.cv2Service = locBean.cv2Service;
		this.managedService = locBean.managedService;
		this.qosInd = locBean.qosInd;
		this.enableDhcp = locBean.enableDhcp;
		DNS1Address = locBean.DNS1Address;
		DNS2Address = locBean.DNS2Address;
		this.serviceTypeOffering = locBean.serviceTypeOffering;
		this.voipServiceType = locBean.voipServiceType;
		this.hybridServiceType = locBean.hybridServiceType;
		this.pubIp = locBean.pubIp;
		this.accessType = locBean.accessType;
		this.circuitId = locBean.circuitId;
		this.uunetSiteId = locBean.uunetSiteId;
		this.sipDomain = locBean.sipDomain;
		this.trunk = locBean.trunk;
		this.sbcInd = locBean.sbcInd;
		this.sbcId = locBean.sbcId;
		this.sipEnabled = locBean.sipEnabled;
		this.publicGtwyDpid = locBean.publicGtwyDpid;
		this.defaultGtwyDpid = locBean.defaultGtwyDpid;
		this.trunkType = locBean.trunkType;
		this.voipClub = locBean.voipClub;
		this.serviceLevel = locBean.serviceLevel;
		this.locMarket = locBean.locMarket;
		this.maxExtLength = locBean.maxExtLength;
		this.extLength = locBean.extLength;
		this.privateNumLength = locBean.privateNumLength;
		this.linePortLength = locBean.linePortLength;
		this.abbrDialingCode = locBean.abbrDialingCode;
		this.enableCallPark = locBean.enableCallPark;
		this.overrideCidNum = locBean.overrideCidNum;
		this.overrideCidName = locBean.overrideCidName;
		this.cidTn = locBean.cidTn;
		this.contactPhone = locBean.contactPhone;
		this.contactName = locBean.contactName;
		this.contactEmail = locBean.contactEmail;
		this.actTeamPhone = locBean.actTeamPhone;
		this.actTeamName = locBean.actTeamName;
		this.actTeamEmail = locBean.actTeamEmail;
		this.enableAccountCode = locBean.enableAccountCode;
		this.enableAuthCode = locBean.enableAuthCode;
		this.localDirAssistance = locBean.localDirAssistance;
		this.natDirAssistance = locBean.natDirAssistance;
		this.concCallStat = locBean.concCallStat;
		this.maxConcurrentCalls = locBean.maxConcurrentCalls;
		this.maxConcurrentOffnet = locBean.maxConcurrentOffnet;
		this.maxInbound = locBean.maxInbound;
		this.maxSlg = locBean.maxSlg;
		this.maxNg = locBean.maxNg;
		this.maxSubscribers = locBean.maxSubscribers;
		this.maxPublicTn = locBean.maxPublicTn;
		this.blockAllCalls = locBean.blockAllCalls;
		this.rpid = locBean.rpid;
		this.rpidPriv = locBean.rpidPriv;
		this.pendingRpid = locBean.pendingRpid;
		this.rpidTn = locBean.rpidTn;
		this.rpidPoolId = locBean.rpidPoolId;
		this.hicrService = locBean.hicrService;
		this.premiseVm = locBean.premiseVm;
		this.callingPlanId = locBean.callingPlanId;
		this.vmLang = locBean.vmLang;
		this.vmLangStr = locBean.vmLangStr;
		this.maxVmBox = locBean.maxVmBox;
		this.activeInd = locBean.activeInd;
		this.sbcMigInd = locBean.sbcMigInd;
		this.vmType = locBean.vmType;
		this.overrideSubPrivate = locBean.overrideSubPrivate;
		this.switchClli = locBean.switchClli;
		this.vmCpeIpAddress = locBean.vmCpeIpAddress;
		this.vmSmdiAuthToggle = locBean.vmSmdiAuthToggle;
		this.createdBy = locBean.createdBy;
		this.modifiedBy = locBean.modifiedBy;
		this.creationDate = locBean.creationDate;
		this.activeDate = locBean.activeDate;
		this.lastModifiedDate = locBean.lastModifiedDate;
		this.getAll = locBean.getAll;
		this.envOrderId = locBean.envOrderId;
		this.emerPoolId = locBean.emerPoolId;
		this.emerBtn = locBean.emerBtn;
		this.emerLocationCode = locBean.emerLocationCode;
		this.emerLocationCodeDesc = locBean.emerLocationCodeDesc;
		this.emerLocationCodeId = locBean.emerLocationCodeId;
		this.locationType = locBean.locationType;
		this.fmcgLocationType = locBean.fmcgLocationType;
		this.hubLocationId = locBean.hubLocationId;
		this.hubGatewayDeviceId = locBean.hubGatewayDeviceId;
		this.baPortalPoolId = locBean.baPortalPoolId;
		this.locationMask = locBean.locationMask;
		this.aNumMask = locBean.aNumMask;
		this.bNumMask = locBean.bNumMask;
		this.vpnName = locBean.vpnName;
		this.tblVpnIdMappingId = locBean.tblVpnIdMappingId;
		this.sbcProvMethod = locBean.sbcProvMethod;
		this.rivLocation = locBean.rivLocation;
		this.afterHoursInstallFlag = locBean.afterHoursInstallFlag;
		this.highVolumeInstallFlag = locBean.highVolumeInstallFlag;
		this.expedite = locBean.expedite;
		this.locCclInd = locBean.locCclInd;
		this.billingActivated = locBean.billingActivated;
		this.callingNameInd = locBean.callingNameInd;
		this.enhancedAniInd = locBean.enhancedAniInd;
		this.sTn = locBean.sTn;
		this.sTnPoolId = locBean.sTnPoolId;
		this.teleworkerFqdn = locBean.teleworkerFqdn; // FMCg Phase II
		this.twSbcId = locBean.twSbcId;
		// Jan 2011 Release changes
		this.iasaOrderId = locBean.iasaOrderId;
		this.locTerritory = locBean.locTerritory;
		this.locRegion = locBean.locRegion;
		this.billingSystem = locBean.billingSystem;
		this.defaultPpId = locBean.defaultPpId;
		this.productIdentifier = locBean.productIdentifier;
		this.configAllowed = locBean.configAllowed;
		// May 2011 release change
		this.alternativeCallerIdInd = locBean.alternativeCallerIdInd;
		this.e911Service = locBean.e911Service;
		// 53938.AA Business Continuity Ph 1 - changes for july 2011
		this.varrsFlag = locBean.varrsFlag;
		// this.isrDesignId = locBean.isrDesignId;
		this.subAgencyHierCode = locBean.subAgencyHierCode;
		// Jan 2013 Release - E2EI
		this.physicalLocationId = locBean.physicalLocationId;
		this.physicalLocationName = locBean.physicalLocationName;
		this.dialingCountryCode = locBean.dialingCountryCode;
		this.restrictedAccess = locBean.restrictedAccess;
		this.callFwdPlanName = locBean.callFwdPlanName;
		this.lorId = locBean.lorId;
		this.hybridAssigned = locBean.hybridAssigned;
		this.e2eimigflag = locBean.e2eimigflag;
		this.tsoMigLock = locBean.tsoMigLock;
		this.enterpriseTrunkId = locBean.enterpriseTrunkId;
		this.pqInstanceId = locBean.pqInstanceId;

		this.uiProvFlag = locBean.uiProvFlag; // added by z658915
		this.calnetSubContractId = locBean.calnetSubContractId; // added by z658915
		this.addressId = locBean.addressId;
		this.isrDesignId = locBean.isrDesignId;
		this.entBillFeatBeanList = locBean.entBillFeatBeanList;
		this.CnamUpdateStatus = locBean.CnamUpdateStatus;
		this.CnamUpdateDate = locBean.CnamUpdateDate;
        this.BANID=locBean.BANID;
        // VCE changes
        this.vce = locBean.vce;
        //xo changes
        this.policyFeaturesList = locBean.policyFeaturesList;
		this.eslId=locBean.eslId;
		this.redundency=locBean.redundency;
		this.redundencyId=locBean.redundencyId;
		this.redundencyPriorityType=locBean.redundencyPriorityType;
		this.groupUserLimit=locBean.groupUserLimit;
		this.billingTN=locBean.billingTN;
		this.broadworksPortalNumber=locBean.broadworksPortalNumber;
		this.locGroupId=locBean.locGroupId;
        


	}

	public LocationBean(IpcomLocationDbBean iasaLocBean) {
		// this.featurePkgList = iasaLocBean.featurePkgList;
		// this.deviceList = iasaLocBean.deviceList;
		// this.vmAccessList = iasaLocBean.vmAccessList;
		// this.authCodesList = iasaLocBean.authCodesList;
		// this.prefixPlanList = iasaLocBean.prefixPlanList;
		// this.bsAsDbBean = iasaLocBean.bsAsDbBean;
		// this.callingPlanBean = iasaLocBean.callingPlanBean;
		// this.prefixRouting = iasaLocBean.prefixRouting;
		// this.publicTnPool = iasaLocBean.publicTnPool;
		// this.dialPlanList = iasaLocBean.dialPlanList;
		// this.locationFeatures = iasaLocBean.locationFeatures;
		// this.logTrail = iasaLocBean.logTrail;
		this.locationId = Long.toString(iasaLocBean.getLocid());
		this.enterpriseId = Long.toString(iasaLocBean.getMasterAcctOid());
		this.dialPlanId = iasaLocBean.getDpid(); // ESAP and IASA DP_ID are diff
		this.orderSource = iasaLocBean.getOrderSource();
		this.locationName = iasaLocBean.getLocname();
		this.locAddress = iasaLocBean.getLocAddress();
		this.locCity = iasaLocBean.getLocCity();
		this.locState = iasaLocBean.getLocState();
		this.locZip = iasaLocBean.getLocZip();
		this.locCountry = iasaLocBean.getLocCountry();
		this.npaNxx = iasaLocBean.getNpanxx();
		if (iasaLocBean.getTimeZone() == 0) {
			this.timeZone = VzbVoipEnum.TimeZone.name(1);
		} else {
			this.timeZone = VzbVoipEnum.TimeZone.name((int) iasaLocBean
					.getTimeZone());
		}
		this.timeZoneId = (int) iasaLocBean.getTimeZone();
		this.useDaylightSaving = iasaLocBean.getUseDaylightSavings();
		this.dayLightSavingsRegion = Long.toString(iasaLocBean
				.getDaylightSavingsRegion());
		this.webLang = iasaLocBean.getWebLang();
		this.webLangStr = VzbVoipEnum.Language.name((int) iasaLocBean
				.getWebLang());
		this.ixPlusId = iasaLocBean.getIxplusid();
		this.ixPlusEnvId = iasaLocBean.getEnvironmentId();
		// this.billTn = iasaLocBean.billTn;
		// this.billTnPoolId = iasaLocBean.billTnPoolId;
		// this.billType = iasaLocBean.billType;
		this.billAccountNumber = iasaLocBean.getBillAcctNum();
		this.netcomServiceId = iasaLocBean.getNetcomServiceId();
		this.cv2Service = iasaLocBean.getCv2Service();
		this.managedService = iasaLocBean.getManagedService();
		this.qosInd = iasaLocBean.getQosInd();
		// this.enableDhcp = iasaLocBean.enableDhcp;
		// DNS1Address = iasaLocBean.DNS1Address;
		// DNS2Address = iasaLocBean.DNS2Address;
		// this.serviceTypeOffering = iasaLocBean.;
		this.voipServiceType = iasaLocBean.getVoipServiceType();
		this.hybridServiceType = iasaLocBean.getHybridServiceType();
		this.pubIp = iasaLocBean.getPubip();

		if (iasaLocBean.getAccessType() == 23) {
			this.accessType = VzbVoipEnum.AccessType.PRIVATE_IP;
		} else {
			this.accessType = iasaLocBean.getAccessType();
		}

		this.circuitId = iasaLocBean.getCircuitId();
		this.uunetSiteId = iasaLocBean.getUunetSiteId();
		this.sipDomain = iasaLocBean.getSipDomain();
		this.trunk = VzbVoipEnum.TrunkGroupType.name(iasaLocBean
				.getSharedTrunk());
		this.sbcInd = iasaLocBean.getSbcInd();
		// this.sbcId = iasaLocBean.sbcId;
		this.sipEnabled = iasaLocBean.getSipEnabled();
		this.publicGtwyDpid = iasaLocBean.getE164gwdpid();
		this.defaultGtwyDpid = iasaLocBean.getE164defdpid();
		this.trunkType = iasaLocBean.getSharedTrunk();
		this.voipClub = iasaLocBean.getOnnetInterco();
		this.serviceLevel = iasaLocBean.getServiceLevel();
		this.locMarket = iasaLocBean.getLocMarket();
		this.maxExtLength = iasaLocBean.getExtLengthMax();
		if (iasaLocBean.getExtLength() != null) {
			this.extLength = Long.parseLong(iasaLocBean.getExtLength());
		}
		this.privateNumLength = iasaLocBean.getExtLengthMax();
		this.linePortLength = iasaLocBean.getLinePortLength();
		// this.abbrDialingCode = iasaLocBean.abbrDialingCode;
		// this.enableCallPark = iasaLocBean.enableCallPark;
		// this.overrideCidNum = iasaLocBean.overrideCidNum;
		// this.overrideCidName = iasaLocBean.overrideCidName;
		// this.cidTn = iasaLocBean.cidTn;
		// this.contactPhone = iasaLocBean.contactPhone;
		// this.contactName = iasaLocBean.contactName;
		// this.contactEmail = iasaLocBean.contactEmail;
		// this.actTeamPhone = iasaLocBean.actTeamPhone;
		// this.actTeamName = iasaLocBean.actTeamName;
		// this.actTeamEmail = iasaLocBean.actTeamEmail;
		// this.enableAccountCode = iasaLocBean.enableAccountCode;
		// this.enableAuthCode = locBean.enableAuthCode;
		this.localDirAssistance = iasaLocBean.getWz1dalocal();
		this.natDirAssistance = iasaLocBean.getWz1dae164();
		this.concCallStat = iasaLocBean.getConccallstat();
		this.maxConcurrentCalls = iasaLocBean.getMaxoffloc();
		this.maxConcurrentOffnet = iasaLocBean.getMaxoffnet();
		this.maxInbound = iasaLocBean.getMaxinbound();
		this.maxSlg = iasaLocBean.getMaxslg();
		this.maxNg = iasaLocBean.getMaxng();
		this.maxSubscribers = iasaLocBean.getProfileMax();
		this.maxPublicTn = iasaLocBean.getPublicNumMax();
		this.blockAllCalls = iasaLocBean.getBlockallcalls();
		this.rpid = iasaLocBean.getRpid();
		this.rpidPriv = iasaLocBean.getRpidpriv();
		// this.rpidTn = iasaLocBean.rpidTn; // TODO:
		// this.rpidPoolId = iasaLocBean.rpidPoolId; // ESAP and IASA has diff
		// poolid
		this.hicrService = iasaLocBean.getHicrService();
		// this.premiseVm = iasaLocBean.premiseVm;
		// this.callingPlanId = iasaLocBean.callingPlanId;
		this.vmLang = iasaLocBean.getVmLang();
		this.vmLangStr = VzbVoipEnum.Language.name((int) iasaLocBean
				.getVmLang());
		this.maxVmBox = iasaLocBean.getVmBoxMax();
		this.activeInd = iasaLocBean.getActive();
		// this.vmType = iasaLocBean.getvmType();
		this.overrideSubPrivate = iasaLocBean.getPsaliind();
		this.switchClli = iasaLocBean.getSwitchclli();
		// this.vmCpeIpAddress = iasaLocBean.vmCpeIpAddress;
		// this.vmSmdiAuthToggle = iasaLocBean.vmSmdiAuthToggle;
		this.createdBy = iasaLocBean.getSystemUser();
		this.modifiedBy = iasaLocBean.getSystemUser();
		this.creationDate = getCreationDate();
		this.activeDate = getActiveDate();
		this.lastModifiedDate = getCreationDate();
		// this.getAll = iasaLocBean.getAll;
		// this.envOrderId = iasaLocBean.envOrderId;
		// this.emerPoolId = iasaLocBean.emerPoolId;
		this.emerBtn = iasaLocBean.getEmerSvcsBtn();
		// this.emerLocationCode = iasaLocBean.getEmerLocCodeId();
		this.emerLocationCodeId = iasaLocBean.getEmerLocCodeId();
		// this.locationType = iasaLocBean.getl;
		this.fmcgLocationType = iasaLocBean.getFmcgInd();
		// this.hubLocationId = iasaLocBean.hubLocationId;
		// this.hubGatewayDeviceId = iasaLocBean.hubGatewayDeviceId;
		// this.baPortalPoolId = iasaLocBean.baPortalPoolId;
		this.locationMask = iasaLocBean.getProductionIndicator(); // need to
																	// check
		this.aNumMask = iasaLocBean.getANumMask();
		this.bNumMask = iasaLocBean.getBNumMask();
		// this.vpnName = iasaLocBean.vpnName;
		// this.tblVpnIdMappingId = iasaLocBean.tblVpnIdMappingId;
		this.sbcProvMethod = iasaLocBean.getSbcProv();
		this.asId = iasaLocBean.getAsId();
		// this.afterHoursInstallFlag = iasaLocBean.getAfterHoursInstallFlag();
		// this.highVolumeInstallFlag = iasaLocBean.getHighVolumeInstallFlag();
		// this.expedite = iasaLocBean.getExpedite();
		this.logTrail = new ArrayList<String>();
		// Jan 2011 Release changes
		/*
		 * this.iasaOrderId = iasaLocBean.iasaOrderId; this.locTerritory =
		 * iasaLocBean.locTerritory; this.locRegion = iasaLocBean.locRegion;
		 * this.billingSystem =iasaLocBean.billingSystem;
		 */
		this.billingActivated = iasaLocBean.getBillingStatus();

		if (iasaLocBean.getLocDesignInd() == 0) {
			this.locationType = VzbVoipEnum.LocationType.STANDARD;
		} else {
			this.locationType = iasaLocBean.getLocDesignInd();
		}
		// May 2011 release change
		this.alternativeCallerIdInd = iasaLocBean.getTwocli();
		// 53938.AA Business Continuity Ph 1 - changes for july 2011
		// this.varrsFlag = iasaLocBean.varrsFlag;
		// this.isrDesignId = iasaLocBean.isrDesignId;
		this.subAgencyHierCode = iasaLocBean.getSubagencyHierCode();

	}

	/**
	 * @return the cnamUpdateStatus
	 */
	public long getCnamUpdateStatus() {
		return CnamUpdateStatus;
	}

	/**
	 * @param cnamUpdateStatus
	 *            the cnamUpdateStatus to set
	 */
	public void setCnamUpdateStatus(long cnamUpdateStatus) {
		CnamUpdateStatus = cnamUpdateStatus;
	}

	/**
	 * @return the cnamUpdateDate
	 */
	public java.sql.Timestamp getCnamUpdateDate() {
		return CnamUpdateDate;
	}

	public short getTsoMigLock() {
		return tsoMigLock;
	}

	public void setTsoMigLock(short tsoMigLock) {
		this.tsoMigLock = tsoMigLock;
	}

	/**
	 * @param cnamUpdateDate
	 *            the cnamUpdateDate to set
	 */
	public void setCnamUpdateDate(java.sql.Timestamp cnamUpdateDate) {
		CnamUpdateDate = cnamUpdateDate;
	}

	public java.sql.Timestamp getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(java.sql.Timestamp creationDate) {
		this.creationDate = creationDate;
	}

	public java.sql.Timestamp getActiveDate() {
		return activeDate;
	}

	public void setActiveDate(java.sql.Timestamp activeDate) {
		this.activeDate = activeDate;
	}

	public java.sql.Timestamp getLastModifiedDate() {
		return lastModifiedDate;
	}

	public void setLastModifiedDate(java.sql.Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public void setLogTrail(String logStr) {
		logTrail.add(logStr);
	}

	public List<String> getLogTrail() {
		return logTrail;
	}

	public long getProductionIndicator() {
		return productionIndicator;
	}

	public void setProductionIndicator(long productionIndicator) {
		this.productionIndicator = productionIndicator;
	}

	public void setWebLang(long webLang) {
		this.webLang = webLang;
	}

	public String getVmCpeIpAddress() {
		return vmCpeIpAddress;
	}

	public void setVmCpeIpAddress(String vmCpeIpAddress) {
		this.vmCpeIpAddress = vmCpeIpAddress;
	}

	public long getVmSmdiAuthToggle() {
		return vmSmdiAuthToggle;
	}

	public void setVmSmdiAuthToggle(long vmSmdiAuthToggle) {
		this.vmSmdiAuthToggle = vmSmdiAuthToggle;
	}

	public String getSwitchClli() {
		return switchClli;
	}

	public void setSwitchClli(String switchClli) {
		this.switchClli = switchClli;
	}

	public long getOverrideSubPrivate() {
		return overrideSubPrivate;
	}

	public void setOverrideSubPrivate(long overrideSubPrivate) {
		this.overrideSubPrivate = overrideSubPrivate;
	}

	public long getVmType() {
		return vmType;
	}

	public void setVmType(long vmType) {
		this.vmType = vmType;
	}

	public long getAccessType() {
		return accessType;
	}

	public void setAccessType(long accessType) {
		this.accessType = accessType;
	}

	public List<AcctAuthCodesBean> getAuthCodesList() {
		return authCodesList;
	}

	public void setAuthCodesList(List<AcctAuthCodesBean> authCodesList) {
		this.authCodesList = authCodesList;
	}

	public List<VmAccessBean> getVmAccessList() {
		return vmAccessList;
	}

	public void setVmAccessList(List<VmAccessBean> vmAccessList) {
		this.vmAccessList = vmAccessList;
	}

	public String getBillTn() {
		return billTn;
	}

	public void setBillTn(String billTn) {
		this.billTn = billTn;
	}

	public long getBillTnPoolId() {
		return billTnPoolId;
	}

	public void setBillTnPoolId(long billTnPoolId) {
		this.billTnPoolId = billTnPoolId;
	}

	public List<FeaturePackageBean> getFeaturePkgList() {
		return featurePkgList;
	}

	public void setFeaturePkgList(List<FeaturePackageBean> featurePkgList) {
		this.featurePkgList = featurePkgList;
	}

	/*
	 * public List<DBTblPublicTnPool> getPublicTnPoolList() { return
	 * publicTnPoolList; } public void
	 * setPublicTnPoolList(List<DBTblPublicTnPool> publicTnPoolList) {
	 * this.publicTnPoolList = publicTnPoolList; }
	 */
	public List<GatewayDeviceBean> getDeviceList() {
		return deviceList;
	}

	public void setDeviceList(List<GatewayDeviceBean> deviceList) {
		this.deviceList = deviceList;
	}

	public List<PrefixPlanBean> getPrefixPlanList() {
		return prefixPlanList;
	}

	public void setPrefixPlanList(List<PrefixPlanBean> prefixPlanList) {
		this.prefixPlanList = prefixPlanList;
	}

	/*
	 * public DBTblDialPlan getDialPlanDbBean() { return dialPlanDbBean; }
	 * public void setDialPlanDbBean(DBTblDialPlan dialPlanDbBean) {
	 * this.dialPlanDbBean = dialPlanDbBean; }
	 */
	public CallingPlanBean getCallingPlanBean() {
		return callingPlanBean;
	}

	public void setCallingPlanBean(CallingPlanBean callingPlanBean) {
		this.callingPlanBean = callingPlanBean;
	}

	public String getLocationId() {
		return locationId;
	}

	public void setLocationId(String locationId) {
		this.locationId = locationId;
	}

	public String getEnterpriseId() {
		return enterpriseId;
	}

	public void setEnterpriseId(String enterpriseId) {
		this.enterpriseId = enterpriseId;
	}

	public long getDialPlanId() {
		return dialPlanId;
	}

	public void setDialPlanId(long dialPlanId) {
		this.dialPlanId = dialPlanId;
	}

	public String getOrderSource() {
		return orderSource;
	}

	public void setOrderSource(String orderSource) {
		this.orderSource = orderSource;
	}

	public String getLocationName() {
		return locationName;
	}

	public void setLocationName(String locationName) {
		this.locationName = locationName;
	}

	public String getLocAddress() {
		return locAddress;
	}

	public void setLocAddress(String locAddress) {
		this.locAddress = locAddress;
	}

	public String getLocCity() {
		return locCity;
	}

	public void setLocCity(String locCity) {
		this.locCity = locCity;
	}

	public String getLocState() {
		return locState;
	}

	public void setLocState(String locState) {
		this.locState = locState;
	}

	public String getLocZip() {
		return locZip;
	}

	public void setLocZip(String locZip) {
		this.locZip = locZip;
	}

	public String getLocCountry() {
		return locCountry;
	}

	public void setLocCountry(String locCountry) {
		this.locCountry = locCountry;
	}

	public String getNpaNxx() {
		return npaNxx;
	}

	public void setNpaNxx(String npaNxx) {
		this.npaNxx = npaNxx;
	}

	public int getTimeZoneId() {
		return timeZoneId;
	}

	public void setTimeZoneId(int timeZoneId) {
		this.timeZoneId = timeZoneId;
	}

	public String getTimeZone() {
		return timeZone;
	}

	public void setTimeZone(String timeZone) {
		this.timeZone = timeZone;
	}

	public long getUseDaylightSaving() {
		return useDaylightSaving;
	}

	public void setUseDaylightSaving(long useDaylightSaving) {
		this.useDaylightSaving = useDaylightSaving;
	}

	public String getDayLightSavingsRegion() {
		return dayLightSavingsRegion;
	}

	public void setDayLightSavingsRegion(String dayLightSavingsRegion) {
		this.dayLightSavingsRegion = dayLightSavingsRegion;
	}

	public Long getWebLang() {
		return webLang;
	}

	public void setWebLang(Long webLang) {
		this.webLang = webLang;
	}

	/**
	 * @return the enterpriseTrunkId
	 */
	public long getEnterpriseTrunkId() {
		return enterpriseTrunkId;
	}

	/**
	 * @param enterpriseTrunkId
	 *            the enterpriseTrunkId to set
	 */
	public void setEnterpriseTrunkId(long enterpriseTrunkId) {
		this.enterpriseTrunkId = enterpriseTrunkId;
	}

	public long getPqInstanceId() {
		return pqInstanceId;
	}

	public void setPqInstanceId(long pqInstanceId) {
		this.pqInstanceId = pqInstanceId;
	}

	// added by z658915 - starts
	public short getUiProvFlag() {
		return uiProvFlag;
	}

	public void setUiProvFlag(short uiProvFlag) {
		this.uiProvFlag = uiProvFlag;
	}

	// added by z658915 - ends

	// added by z658915 starts for calnet changes
	public short getCalnetSubContractId() {
		return calnetSubContractId;
	}

	public void setCalnetSubContractId(short calnetSubContractId) {
		this.calnetSubContractId = calnetSubContractId;
	}

	// added by z658915 ends for calnet changes

	public long getIsrDesignId() {
		return isrDesignId;
	}

	public void setIsrDesignId(long isrDesignId) {
		this.isrDesignId = isrDesignId;
	}

	public String getWebLangStr() {
		return webLangStr;
	}

	public void setWebLangStr(String webLang) {
		this.webLangStr = webLang;
	}

	public long getIxPlusId() {
		return ixPlusId;
	}

	public void setIxPlusId(long ixPlusId) {
		this.ixPlusId = ixPlusId;
	}

	public String getIxPlusEnvId() {
		return ixPlusEnvId;
	}

	public void setIxPlusEnvId(String ixPlusEnvId) {
		this.ixPlusEnvId = ixPlusEnvId;
	}

	public int getBillType() {
		return billType;
	}

	public void setBillType(int billType) {
		this.billType = billType;
	}

	public String getBillAccountNumber() {
		return billAccountNumber;
	}

	public void setBillAccountNumber(String billAccountNumber) {
		this.billAccountNumber = billAccountNumber;
	}

	public String getNetcomServiceId() {
		return netcomServiceId;
	}

	public void setNetcomServiceId(String netcomServiceId) {
		this.netcomServiceId = netcomServiceId;
	}
	
	public String getClin() {
		return clin;
	}

	public void setClin(String clin) {
		this.clin = clin;
	}

	public long getCv2Service() {
		return cv2Service;
	}

	public void setCv2Service(long cv2Service) {
		this.cv2Service = cv2Service;
	}

	public long getManagedService() {
		return managedService;
	}

	public void setManagedService(long managedService) {
		this.managedService = managedService;
	}

	public long getQosInd() {
		return qosInd;
	}

	public void setQosInd(long qosInd) {
		this.qosInd = qosInd;
	}

	public long getEnableDhcp() {
		return enableDhcp;
	}

	public void setEnableDhcp(long enableDhcp) {
		this.enableDhcp = enableDhcp;
	}

	public String getDNS1Address() {
		return DNS1Address;
	}

	public void setDNS1Address(String address) {
		DNS1Address = address;
	}

	public String getDNS2Address() {
		return DNS2Address;
	}

	public void setDNS2Address(String address) {
		DNS2Address = address;
	}

	public long getServiceTypeOffering() {
		return serviceTypeOffering;
	}

	public void setServiceTypeOffering(long serviceTypeOffering) {
		this.serviceTypeOffering = serviceTypeOffering;
	}

	public long getVoipServiceType() {
		return voipServiceType;
	}

	public void setVoipServiceType(long voipServiceType) {
		this.voipServiceType = voipServiceType;
	}

	public long getHybridServiceType() {
		return hybridServiceType;
	}

	public void setHybridServiceType(long hybridServiceType) {
		this.hybridServiceType = hybridServiceType;
	}

	public long getPubIp() {
		return pubIp;
	}

	public void setPubIp(long pubIp) {
		this.pubIp = pubIp;
	}

	public String getCircuitId() {
		return circuitId;
	}

	public void setCircuitId(String circuitId) {
		this.circuitId = circuitId;
	}

	public String getUunetSiteId() {
		return uunetSiteId;
	}

	public void setUunetSiteId(String uunetSiteId) {
		this.uunetSiteId = uunetSiteId;
	}

	public String getSipDomain() {
		return sipDomain;
	}

	public void setSipDomain(String sipDomain) {
		this.sipDomain = sipDomain;
	}

	public String getTrunk() {
		return trunk;
	}

	public void setTrunk(String trunk) {
		this.trunk = trunk;
	}

	public long getSbcInd() {
		return sbcInd;
	}

	public void setSbcInd(long sbcInd) {
		this.sbcInd = sbcInd;
	}

	public long getSbcId() {
		return sbcId;
	}

	public void setSbcId(long sbcId) {
		this.sbcId = sbcId;
	}

	public long getSipEnabled() {
		return sipEnabled;
	}

	public void setSipEnabled(long sipEnabled) {
		this.sipEnabled = sipEnabled;
	}

	public long getPublicGtwyDpid() {
		return publicGtwyDpid;
	}

	public void setPublicGtwyDpid(long publicGtwyDpid) {
		this.publicGtwyDpid = publicGtwyDpid;
	}

	public long getDefaultGtwyDpid() {
		return defaultGtwyDpid;
	}

	public void setDefaultGtwyDpid(long defaultGtwyDpid) {
		this.defaultGtwyDpid = defaultGtwyDpid;
	}

	public long getTrunkType() {
		return trunkType;
	}

	public void setTrunkType(long trunkType) {
		this.trunkType = trunkType;
	}

	public long getVoipClub() {
		return voipClub;
	}

	public void setVoipClub(long voipClub) {
		this.voipClub = voipClub;
	}

	public long getServiceLevel() {
		return serviceLevel;
	}

	public void setServiceLevel(long serviceLevel) {
		this.serviceLevel = serviceLevel;
	}

	public long getLocMarket() {
		return locMarket;
	}

	public void setLocMarket(long locMarket) {
		this.locMarket = locMarket;
	}

	public long getMaxExtLength() {
		return maxExtLength;
	}

	public void setMaxExtLength(long maxExtLength) {
		this.maxExtLength = maxExtLength;
	}

	public long getExtLength() {
		return extLength;
	}

	public void setExtLength(long extLength) {
		this.extLength = extLength;
	}

	public long getPrivateNumLength() {
		return privateNumLength;
	}

	public void setPrivateNumLength(long privateNumLength) {
		this.privateNumLength = privateNumLength;
	}

	public long getLinePortLength() {
		return linePortLength;
	}

	public void setLinePortLength(long linePortLength) {
		this.linePortLength = linePortLength;
	}

	public String getAbbrDialingCode() {
		return abbrDialingCode;
	}

	public void setAbbrDialingCode(String abbrDialingCode) {
		this.abbrDialingCode = abbrDialingCode;
	}

	public long getEnableCallPark() {
		return enableCallPark;
	}

	public void setEnableCallPark(long enableCallPark) {
		this.enableCallPark = enableCallPark;
	}

	public long getOverrideCidNum() {
		return overrideCidNum;
	}

	public void setOverrideCidNum(long overrideCidNum) {
		this.overrideCidNum = overrideCidNum;
	}

	public long getOverrideCidName() {
		return overrideCidName;
	}

	public void setOverrideCidName(long overrideCidName) {
		this.overrideCidName = overrideCidName;
	}

	public String getCidTn() {
		return cidTn;
	}

	public void setCidTn(String cidTn) {
		this.cidTn = cidTn;
	}

	public String getContactPhone() {
		return contactPhone;
	}

	public void setContactPhone(String contactPhone) {
		this.contactPhone = contactPhone;
	}

	public String getContactName() {
		return contactName;
	}

	public void setContactName(String contactName) {
		this.contactName = contactName;
	}

	public String getContactEmail() {
		return contactEmail;
	}

	public void setContactEmail(String contactEmail) {
		this.contactEmail = contactEmail;
	}

	public String getActTeamPhone() {
		return actTeamPhone;
	}

	public void setActTeamPhone(String actTeamPhone) {
		this.actTeamPhone = actTeamPhone;
	}

	public String getActTeamName() {
		return actTeamName;
	}

	public void setActTeamName(String actTeamName) {
		this.actTeamName = actTeamName;
	}

	public String getActTeamEmail() {
		return actTeamEmail;
	}

	public void setActTeamEmail(String actTeamEmail) {
		this.actTeamEmail = actTeamEmail;
	}

	public long getEnableAccountCode() {
		return enableAccountCode;
	}

	public void setEnableAccountCode(long enableAccountCode) {
		this.enableAccountCode = enableAccountCode;
	}

	public String getEnableAuthCode() {
		return enableAuthCode;
	}

	public void setEnableAuthCode(String enableAuthCode) {
		this.enableAuthCode = enableAuthCode;
	}

	public String getLocalDirAssistance() {
		return localDirAssistance;
	}

	public void setLocalDirAssistance(String localDirAssistance) {
		this.localDirAssistance = localDirAssistance;
	}

	public String getNatDirAssistance() {
		return natDirAssistance;
	}

	public void setNatDirAssistance(String natDirAssistance) {
		this.natDirAssistance = natDirAssistance;
	}

	public long getConcCallStat() {
		return concCallStat;
	}

	public void setConcCallStat(long concCallStat) {
		this.concCallStat = concCallStat;
	}

	public long getMaxConcurrentCalls() {
		return maxConcurrentCalls;
	}

	public void setMaxConcurrentCalls(long maxConcurrentCalls) {
		this.maxConcurrentCalls = maxConcurrentCalls;
	}

	public long getMaxConcurrentOffnet() {
		return maxConcurrentOffnet;
	}

	public void setMaxConcurrentOffnet(long maxConcurrentOffnet) {
		this.maxConcurrentOffnet = maxConcurrentOffnet;
	}

	public long getMaxInbound() {
		return maxInbound;
	}

	public void setMaxInbound(long maxInbound) {
		this.maxInbound = maxInbound;
	}

	public long getMaxSlg() {
		return maxSlg;
	}

	public void setMaxSlg(long maxSlg) {
		this.maxSlg = maxSlg;
	}

	public long getMaxNg() {
		return maxNg;
	}

	public void setMaxNg(long maxNg) {
		this.maxNg = maxNg;
	}

	public long getMaxSubscribers() {
		return maxSubscribers;
	}

	public void setMaxSubscribers(long maxSubscribers) {
		this.maxSubscribers = maxSubscribers;
	}

	public long getMaxPublicTn() {
		return maxPublicTn;
	}

	public void setMaxPublicTn(long maxPublicTn) {
		this.maxPublicTn = maxPublicTn;
	}

	public long getBlockAllCalls() {
		return blockAllCalls;
	}

	public void setBlockAllCalls(long blockAllCalls) {
		this.blockAllCalls = blockAllCalls;
	}

	public String getRpid() {
		return rpid;
	}

	public void setRpid(String rpid) {
		this.rpid = rpid;
	}

	public long getRpidPriv() {
		return rpidPriv;
	}

	public void setRpidPriv(long rpidPriv) {
		this.rpidPriv = rpidPriv;
	}

	public String getRpidTn() {
		return rpidTn;
	}

	public void setRpidTn(String rpidTn) {
		this.rpidTn = rpidTn;
	}

	public String getPendingRpid() {
		return pendingRpid;
	}

	public void setPendingRpid(String pendingRpid) {
		this.pendingRpid = pendingRpid;
	}

	public long getHicrService() {
		return hicrService;
	}

	public void setHicrService(long hicrService) {
		this.hicrService = hicrService;
	}

	public long getPremiseVm() {
		return premiseVm;
	}

	public void setPremiseVm(long premiseVm) {
		this.premiseVm = premiseVm;
	}

	public long getCallingPlanId() {
		return callingPlanId;
	}

	public void setCallingPlanId(long callingPlanId) {
		this.callingPlanId = callingPlanId;
	}

	public long getVmLang() {
		return vmLang;
	}

	public void setVmLang(long vmLang) {
		this.vmLang = vmLang;
	}

	public String getVmLangStr() {
		return vmLangStr;
	}

	public void setVmLangStr(String vmLang) {
		this.vmLangStr = vmLang;
	}

	public long getMaxVmBox() {
		return maxVmBox;
	}

	public void setMaxVmBox(long maxVmBox) {
		this.maxVmBox = maxVmBox;
	}

	public long getActiveInd() {
		return activeInd;
	}

	public void setActiveInd(long activeInd) {
		this.activeInd = activeInd;
	}

	public long getSbcMigInd() {
		return sbcMigInd;
	}

	public void setSbcMigInd(long sbcMigInd) {
		this.sbcMigInd = sbcMigInd;
	}

	public List<PrefixRoutingBean> getPrefixRouting() {
		return prefixRouting;
	}

	public void setPrefixRouting(List<PrefixRoutingBean> prefixRouting) {
		this.prefixRouting = prefixRouting;
	}

	public List<PublicTnPoolBean> getPublicTnPool() {
		return publicTnPool;
	}

	public void setPublicTnPool(List<PublicTnPoolBean> publicTnPool) {
		this.publicTnPool = publicTnPool;
	}

	public long getRpidPoolId() {
		return rpidPoolId;
	}

	public void setRpidPoolId(long rpidPoolId) {
		this.rpidPoolId = rpidPoolId;
	}

	public DBTblBsAs getBsAsDbBean() {
		return bsAsDbBean;
	}

	public void setBsAsDbBean(DBTblBsAs bsAsDbBean) {
		this.bsAsDbBean = bsAsDbBean;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public List<DialPlanBean> getDialPlanList() {
		return dialPlanList;
	}

	public void setDialPlanList(List<DialPlanBean> dialPlanList) {
		this.dialPlanList = dialPlanList;
	}

	public List<FeaturesBean> getLocationFeatures() {
		return locationFeatures;
	}

	public void setLocationFeatures(List<FeaturesBean> locationFeatures) {
		this.locationFeatures = locationFeatures;
	}

	public boolean getGetAll() {
		return getAll;
	}

	public void setGetAll(boolean getAll) {
		this.getAll = getAll;
	}

	public long getEnvOrderId() {
		return envOrderId;
	}

	public void setEnvOrderId(long envOrderId) {
		this.envOrderId = envOrderId;
	}

	/**
	 * @return Returns the aNumMask.
	 */
	public long getANumMask() {
		return aNumMask;
	}

	/**
	 * @param numMask
	 *            The aNumMask to set.
	 */
	public void setANumMask(long numMask) {
		aNumMask = numMask;
	}

	/**
	 * @return Returns the baPortalPoolId.
	 */
	public long getBaPortalPoolId() {
		return baPortalPoolId;
	}

	/**
	 * @param baPortalPoolId
	 *            The baPortalPoolId to set.
	 */
	public void setBaPortalPoolId(long baPortalPoolId) {
		this.baPortalPoolId = baPortalPoolId;
	}

	/**
	 * @return Returns the bNumMask.
	 */
	public long getBNumMask() {
		return bNumMask;
	}

	/**
	 * @param numMask
	 *            The bNumMask to set.
	 */
	public void setBNumMask(long numMask) {
		bNumMask = numMask;
	}

	/**
	 * @return Returns the emerLocationCode.
	 */
	public String getEmerLocationCode() {
		return emerLocationCode;
	}

	/**
	 * @param emerLocationCode
	 *            The emerLocationCode to set.
	 */
	public void setEmerLocationCode(String emerLocationCode) {
		this.emerLocationCode = emerLocationCode;
	}

	public String getEmerLocationCodeDesc() {
		return emerLocationCodeDesc;
	}

	public void setEmerLocationCodeDesc(String emerLocationCodeDesc) {
		this.emerLocationCodeDesc = emerLocationCodeDesc;
	}

	public long getEmerLocationCodeId() {
		return emerLocationCodeId;
	}

	public void setEmerLocationCodeId(long emerLocationCodeId) {
		this.emerLocationCodeId = emerLocationCodeId;
	}

	/**
	 * @return Returns the emerPoolId.
	 */
	public int getEmerPoolId() {
		return emerPoolId;
	}

	/**
	 * @param emerPoolId
	 *            The emerPoolId to set.
	 */
	public void setEmerPoolId(int emerPoolId) {
		this.emerPoolId = emerPoolId;
	}

	public String getEmerBtn() {
		return emerBtn;
	}

	public void setEmerBtn(String emerBtn) {
		this.emerBtn = emerBtn;
	}

	/**
	 * @return Returns the fmcgLocationType.
	 */
	public long getFmcgLocationType() {
		return fmcgLocationType;
	}

	/**
	 * @param fmcgLocationType
	 *            The fmcgLocationType to set.
	 */
	public void setFmcgLocationType(long fmcgLocationType) {
		this.fmcgLocationType = fmcgLocationType;
	}

	/**
	 * @return Returns the hubGatewayDeviceId.
	 */
	public long getHubGatewayDeviceId() {
		return hubGatewayDeviceId;
	}

	/**
	 * @param hubGatewayDeviceId
	 *            The hubGatewayDeviceId to set.
	 */
	public void setHubGatewayDeviceId(long hubGatewayDeviceId) {
		this.hubGatewayDeviceId = hubGatewayDeviceId;
	}

	/**
	 * @return Returns the hubLocationId.
	 */
	public String getHubLocationId() {
		return hubLocationId;
	}

	/**
	 * @param hubLocationId
	 *            The hubLocationId to set.
	 */
	public void setHubLocationId(String hubLocationId) {
		this.hubLocationId = hubLocationId;
	}

	/**
	 * @return Returns the locationMask.
	 */
	public long getLocationMask() {
		return locationMask;
	}

	/**
	 * @param locationMask
	 *            The locationMask to set.
	 */
	public void setLocationMask(long locationMask) {
		this.locationMask = locationMask;
	}

	/**
	 * @return Returns the locationType.
	 */
	public long getLocationType() {
		return locationType;
	}

	/**
	 * @param locationType
	 *            The locationType to set.
	 */
	public void setLocationType(long locationType) {
		this.locationType = locationType;
	}

	public String getVpnName() {
		return vpnName;
	}

	public void setVpnName(String vpnName) {
		this.vpnName = vpnName;
	}

	public int getTblVpnIdMappingId() {
		return tblVpnIdMappingId;
	}

	public void setTblVpnIdMappingId(int tblVpnIdMappingId) {
		this.tblVpnIdMappingId = tblVpnIdMappingId;
	}

	public long getSbcProvMethod() {
		return sbcProvMethod;
	}

	public void setSbcProvMethod(long sbcProvMethod) {
		this.sbcProvMethod = sbcProvMethod;
	}

	public void setRivLocation(long rivLocation) {
		this.rivLocation = rivLocation;
	}

	public long getRivLocation() {
		return this.rivLocation;
	}

	public long getAfterHoursInstallFlag() {
		return afterHoursInstallFlag;
	}

	public void setAfterHoursInstallFlag(long afterHoursInstallFlag) {
		this.afterHoursInstallFlag = afterHoursInstallFlag;
	}

	public long getHighVolumeInstallFlag() {
		return highVolumeInstallFlag;
	}

	public void setHighVolumeInstallFlag(long highVolumeInstallFlag) {
		this.highVolumeInstallFlag = highVolumeInstallFlag;
	}

	public long getExpedite() {
		return expedite;
	}

	public void setExpedite(long expedite) {
		this.expedite = expedite;
	}

	public long getLocCclInd() {
		return locCclInd;
	}

	public void setLocCclInd(long locCclInd) {
		this.locCclInd = locCclInd;
	}

	public long getBillingActivated() {
		return billingActivated;
	}

	public void setBillingActivated(long billingActivated) {
		this.billingActivated = billingActivated;
	}

	public long getCallingNameInd() {
		return callingNameInd;
	}

	public void setCallingNameInd(long callingNameInd) {
		this.callingNameInd = callingNameInd;
	}

	public long getEnhancedAniInd() {
		return enhancedAniInd;
	}

	public void setEnhancedAniInd(long enhancedAniInd) {
		this.enhancedAniInd = enhancedAniInd;
	}

	public long getSTnPoolId() {
		return sTnPoolId;
	}

	public void setSTnPoolId(long stnPoolId) {
		this.sTnPoolId = stnPoolId;
	}

	public String getSTn() {
		return sTn;
	}

	public void setSTn(String tn) {
		sTn = tn;
	}

	public String getTeleworkerFqdn() {
		return teleworkerFqdn;
	}

	public void setTeleworkerFqdn(String teleworkerFqdn) {
		this.teleworkerFqdn = teleworkerFqdn;
	}

	public int getTwSbcId() {
		return twSbcId;
	}

	public void setTwSbcId(int twSbcId) {
		this.twSbcId = twSbcId;
	}

	// Jan 2011 Release changes
	public String getIasaOrderId() {
		return iasaOrderId;
	}

	public void setIasaOrderId(String iasaOrderId) {
		this.iasaOrderId = iasaOrderId;
	}

	public String getLocTerritory() {
		return locTerritory;
	}

	public void setLocTerritory(String locTerritory) {
		this.locTerritory = locTerritory;
	}

	public String getLocRegion() {
		return locRegion;
	}

	public void setLocRegion(String locRegion) {
		this.locRegion = locRegion;
	}

	public long getBillingSystem() {
		return billingSystem;
	}

	public void setBillingSystem(long billingSystem) {
		this.billingSystem = billingSystem;
	}

	public String getProductIdentifier() {
		return productIdentifier;
	}

	public void setProductIdentifier(String productIdentifier) {
		this.productIdentifier = productIdentifier;
	}

	public long getConfigAllowed() {
		return configAllowed;
	}

	public void setConfigAllowed(long configAllowed) {
		this.configAllowed = configAllowed;
	}

	public long getDefaultPpId() {
		return defaultPpId;
	}

	public void setDefaultPpId(long defaultPpId) {
		this.defaultPpId = defaultPpId;
	}

	// May 2011 - 2CLI change
	public short getAlternativeCallerIdInd() {
		return alternativeCallerIdInd;
	}

	public void setAlternativeCallerIdInd(short alternativeCallerIdInd) {
		this.alternativeCallerIdInd = alternativeCallerIdInd;
	}

	public short getE911Service() {
		return e911Service;
	}

	public void setE911Service(short e911Service) {
		this.e911Service = e911Service;
	}

	// 53938.AA Business Continuity Ph 1 - changes for july 2011
	public String getVarrsFlag() {
		return varrsFlag;
	}

	public void setVarrsFlag(String varrsFlag) {
		this.varrsFlag = varrsFlag;
	}

	/**
	 * @return the subAgencyHierCode
	 */
	public String getSubAgencyHierCode() {
		return subAgencyHierCode;
	}

	/**
	 * @param subAgencyHierCode
	 *            the subAgencyHierCode to set
	 */
	public void setSubAgencyHierCode(String subAgencyHierCode) {
		this.subAgencyHierCode = subAgencyHierCode;
	}

	public String getPhysicalLocationId() {
		return physicalLocationId;
	}

	public void setPhysicalLocationId(String physicalLocationId) {
		this.physicalLocationId = physicalLocationId;
	}

	public String getPhysicalLocationName() {
		return physicalLocationName;
	}

	public void setPhysicalLocationName(String physicalLocationName) {
		this.physicalLocationName = physicalLocationName;
	}

	public String getDialingCountryCode() {
		return dialingCountryCode;
	}

	public void setDialingCountryCode(String dialingCountryCode) {
		this.dialingCountryCode = dialingCountryCode;
	}

	public short getRestrictedAccess() {
		return restrictedAccess;
	}

	public void setRestrictedAccess(short restrictedAccess) {
		this.restrictedAccess = restrictedAccess;
	}

	public String getCallFwdPlanName() {
		return callFwdPlanName;
	}

	public void setCallFwdPlanName(String callFwdPlanName) {
		this.callFwdPlanName = callFwdPlanName;
	}

	public void setLorId(final String lorId) {
		this.lorId = lorId;
	}

	public String getLorId() {
		return this.lorId;
	}

	public short getHybridAssigned() {
		return hybridAssigned;
	}

	public short getE2eimigflag() {
		return e2eimigflag;
	}

	public void setE2eimigflag(short e2eimigflag) {
		this.e2eimigflag = e2eimigflag;
	}

	public void setHybridAssigned(short hybridAssigned) {
		this.hybridAssigned = hybridAssigned;
	}

	public List<TblEntBillFeaturesBean> getEntBillFeatBeanList() {
		return entBillFeatBeanList;
	}

	public void setEntBillFeatBeanList(
			List<TblEntBillFeaturesBean> entBillFeatBeanList) {
		this.entBillFeatBeanList = entBillFeatBeanList;
	}

	public String getAddressId() {
		return addressId;
	}

	public void setAddressId(String addressId) {
		this.addressId = addressId;
	}

	public String getVce() {
		return vce;
	}

	public void setVce(String vce) {
		this.vce = vce;
	}
	
	//KR start-XO changes
	public List<PolicyFeaturesBean> getPolicyFeaturesList() {
		return policyFeaturesList;
	}

	public void setPolicyFeaturesList(List<PolicyFeaturesBean> policyFeaturesList) {
		this.policyFeaturesList = policyFeaturesList;
	}

	public String getEslId() {
		return eslId;
	}

	public void setEslId(String eslId) {
		this.eslId = eslId;
	}

	public String getRedundency() {
		return redundency;
	}

	public void setRedundency(String redundency) {
		this.redundency = redundency;
	}

	public String getRedundencyId() {
		return redundencyId;
	}

	public void setRedundencyId(String redundencyId) {
		this.redundencyId = redundencyId;
	}

	public String getBillingTN() {
		return billingTN;
	}

	public void setBillingTN(String billingTN) {
		billingTN = billingTN;
	}

	public String getBroadworksPortalNumber() {
		return broadworksPortalNumber;
	}

	public void setBroadworksPortalNumber(String broadworksPortalNumber) {
		this.broadworksPortalNumber = broadworksPortalNumber;
	}

	public String getGroupUserLimit() {
		return groupUserLimit;
	}

	public void setGroupUserLimit(String groupUserLimit) {
		this.groupUserLimit = groupUserLimit;
	}

	public String getLocGroupId() {
		return locGroupId;
	}

	public void setLocGroupId(String locGroupId) {
		this.locGroupId = locGroupId;
	}

	public String getRedundencyPriorityType() {
		return redundencyPriorityType;
	}

	public void setRedundencyPriorityType(String redundencyPriorityType) {
		this.redundencyPriorityType = redundencyPriorityType;
	}
	
	public void setPolicyServicesId(long policyServicesId) {
     	this.policyServicesId = policyServicesId;
		}
		
	public long getPolicyServicesId() {
			return policyServicesId;
		}
	//End


	//
} // EOF

