package com.vz.fxo.inventory.actionfunction.support;

import esap.db.DBTblPolicies;
import esap.db.DBTblPoliciesService;
import esap.db.DBTblServicepack;



public class ServicePackFeaturesBean
{
	//This class will have DBTblServicepack and servicePackservices
	protected DBTblServicepack servicePackFeaturesDbBean;
	
	protected int servicepackServiceId; 
    protected long envOrderId;	
    protected String createdBy;  
	protected String modifiedBy;
	

	public ServicePackFeaturesBean()
	{
		
		servicepackServiceId = 0;
	    envOrderId = 0;		
        servicePackFeaturesDbBean = new DBTblServicepack();
              
	}

	public ServicePackFeaturesBean(ServicePackFeaturesBean servicePackFeatBean)
	{
		// featuresDbBean = new DBTblVzbFeatures();
		servicePackFeaturesDbBean = servicePackFeatBean.getServicePackFeaturesDbBean();
        this.servicepackServiceId = servicePackFeatBean.servicepackServiceId;
		this.envOrderId = servicePackFeatBean.envOrderId;	
        this.modifiedBy = servicePackFeatBean.modifiedBy;
        this.createdBy = servicePackFeatBean.createdBy;
              
	}
    public int getServicepackServiceId() {
		return servicepackServiceId;
	}

	public void setServicepackServiceId(int servicePackServiceId) {
		this.servicepackServiceId = servicePackServiceId;
	}
    
      public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getModifiedBy()
	{
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy)
	{
		this.modifiedBy = modifiedBy;
	}

	public DBTblServicepack getServicePackFeaturesDbBean()
	{
		return servicePackFeaturesDbBean;
	}

	public void setServicePackFeaturesDbBean(DBTblServicepack servicePackFeaturesDbBean)
	{
		this.servicePackFeaturesDbBean = servicePackFeaturesDbBean;
        }
        public long getEnvOrderId() {
		return envOrderId;
	}
	public void setEnvOrderId(long envOrderId) {
		this.envOrderId = envOrderId;
	} 
	
   
}


