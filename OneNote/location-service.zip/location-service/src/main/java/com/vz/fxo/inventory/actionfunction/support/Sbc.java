package com.vz.fxo.inventory.actionfunction.support;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.Connection;
import esap.db.DBTblSbcInfo;
import esap.db.TblSbcInfoQuery;
import esap.db.TblSbcInfoDbBean;
import java.sql.Timestamp;
import java.sql.SQLException;

public class Sbc extends SbcBean {
	private static Logger log = LoggerFactory.getLogger(Sbc.class.toString());

	private Connection connection;
	InvErrorCode status = InvErrorCode.INTERNAL_ERROR;

	public Sbc(Connection con) {
		this.connection = con;
	}

	// getters - setters

	public Connection getConnection() {
		return connection;
	}

	public void setConnection(Connection connection) {
		this.connection = connection;
	}

	public int getStatusCode() {
		return status.getErrorCode();
	}

	public void setStatus(InvErrorCode status) {
		this.status = status;
	}

	public String getStatusDesc() {
		return status.getErrorDesc();
	}

	public boolean validateSbc() {
		return true;
	}

	public boolean getSbcDetailsBySbcId() {
		log.info("Entering Sbc::getSbcDetailsBySbcId");
		try {
			if (getSbcId() <= 0) {
				setStatus(InvErrorCode.INVALID_INPUT);
				log.info("sbc ID is  < 0, Invalid Input ");
				return false;
			}
			TblSbcInfoQuery sbcQry = new TblSbcInfoQuery();
			sbcQry.whereSbcIdEQ(getSbcId());
			sbcQry.query(connection);
			// sbcQry.queryByWhere(connection,whereClause);
			if (sbcQry.size() <= 0) {
				log.info("Failed to Retrieve Sbc");
				return false;
			}
			TblSbcInfoDbBean sbcDbBean = sbcQry.getDbBean(0);
			setCarrFqdn(sbcDbBean.getCarrFqdn());
			setCarrIpAddress(sbcDbBean.getCarrIpAddress());
			setCarrPort(sbcDbBean.getCarrPort());
			setCustFqdn(sbcDbBean.getCustFqdn());
			setCustIpAddress(sbcDbBean.getCustIpAddress());
			setCustPort(sbcDbBean.getCustPort());
			setEnvOrderId(sbcDbBean.getEnvOrderId());
			setCreatedBy(sbcDbBean.getCreatedBy());
			setModifiedBy(sbcDbBean.getModifiedBy());
		} catch (SQLException s) {
			s.printStackTrace();
			setStatus(InvErrorCode.DB_EXCEPTION);
			// setStatusDesc("DB_FAILURE in getSbcDetailsBySbcId");
			return false;
		}
		setStatus(InvErrorCode.SUCCESS);
		return true;
	}

	public boolean addSbc() throws Exception, SQLException {
		log.info("Entering Sbc::addSbc");

		/*
		 * try {
		 */
		DBTblSbcInfo sbcDb = new DBTblSbcInfo();

		int sbcSeqId = sbcDb.getSbcIdSeqNextVal(connection);
		sbcDb.setSbcId(sbcSeqId);
		setSbcId(sbcSeqId);
		sbcDb.setCarrFqdn(getCarrFqdn());
		sbcDb.setCarrIpAddress(getCarrIpAddress());
		sbcDb.setCarrPort(getCarrPort());
		sbcDb.setCustFqdn(getCustFqdn());
		sbcDb.setCustIpAddress(getCustIpAddress());
		sbcDb.setCustPort(getCustPort());
		if (getEnvOrderId() > 0)
			sbcDb.setEnvOrderId(getEnvOrderId());
		else
			sbcDb.setEnvOrderIdNull();
		if (!getCreatedBy().equals(""))
			sbcDb.setCreatedBy(getCreatedBy());
		else
			sbcDb.setCreatedBy("ESAP_INV");

		if (!getModifiedBy().equals(""))
			sbcDb.setModifiedBy(getModifiedBy());
		else
			sbcDb.setModifiedBy("ESAP_INV");

		sbcDb.setLastModifiedDate(new Timestamp(System.currentTimeMillis()));
		sbcDb.setCreationDate(new Timestamp(System.currentTimeMillis()));
		sbcDb.insert(connection);

		/*
		 * } catch(SQLException s) { s.printStackTrace();
		 * setStatus(InvErrorCode.DB_EXCEPTION); // setStatusDesc(
		 * "DB_FAILURE in addSbc"); return false; }
		 */
		setStatus(InvErrorCode.SUCCESS);
		return true;
	}

	public boolean deleteSbc() throws Exception, SQLException {
		// try {
		if (getSbcId() <= 0) {
			setStatus(InvErrorCode.INVALID_INPUT);
			return false;
		}

		// Todo Remove the child records of EnterPrise
		DBTblSbcInfo sbcInfoDbBean = new DBTblSbcInfo();
		sbcInfoDbBean.whereSbcIdEQ(sbcId);
		// sbcInfoDbBean.setSbcId(sbcId);
		sbcInfoDbBean.deleteByWhere(connection);
		/*
		 * } catch (SQLException s) { setStatus(InvErrorCode.DB_EXCEPTION);
		 * //setStatusDesc("DB_FAILURE in deleteFromDB Enterprise"); log.info(
		 * "DB_FAILURE in deleteFromDB Sbc"); s.printStackTrace(); return false;
		 * }
		 */
		setStatus(InvErrorCode.SUCCESS);
		// setStatusDesc("Successfully DELETED Location into the DB");
		return true;
	}

	public boolean updateSbc() {
		try {
			if (sbcId < 0) {
				setStatus(InvErrorCode.INTERNAL_ERROR);
				// setStatusDesc("FAILURE in modifyInDB Enterprise. Customer Id
				// missing.");
				log.info("FAILURE in updateSbc Sbc. Sbc Id missing.");
				return false;
			}
			DBTblSbcInfo sbcInfoDbBean = getSbcInfoToUpdate();
			sbcInfoDbBean.whereSbcIdEQ(getSbcId());
			if (sbcInfoDbBean.updateSpByWhere(connection) <= 0)
				return false;
		} catch (SQLException s) {
			setStatus(InvErrorCode.DB_EXCEPTION);
			// setStatusDesc("DB_FAILURE in deleteFromDB Enterprise");
			log.info("DB_FAILURE in deleteFromDB Enterprise");
			s.printStackTrace();
			return false;
		}
		setStatus(InvErrorCode.SUCCESS);
		return true;
	}

	private DBTblSbcInfo getSbcInfoToUpdate() {
		DBTblSbcInfo sbcInfoDbBean = new DBTblSbcInfo();

		SbcBean defSbcBean = new SbcBean();

		Sbc inputSbc = this;

		sbcInfoDbBean.setSbcId(sbcId);

		if (inputSbc.getCarrFqdn() != null && !inputSbc.getCarrFqdn().equals(defSbcBean.getCarrFqdn())) {
			sbcInfoDbBean.setCarrFqdn(inputSbc.getCarrFqdn());
		}

		if (inputSbc.getCarrIpAddress() != null && !inputSbc.getCarrIpAddress().equals(defSbcBean.getCarrIpAddress())) {
			sbcInfoDbBean.setCarrIpAddress(inputSbc.getCarrIpAddress());
		}

		if (inputSbc.getCarrPort() != defSbcBean.getCarrPort()) {
			sbcInfoDbBean.setCarrPort(inputSbc.getCarrPort());
		}

		if (inputSbc.getCustFqdn() != null && !inputSbc.getCustFqdn().equals(defSbcBean.getCustFqdn())) {
			sbcInfoDbBean.setCustFqdn(inputSbc.getCustFqdn());
		}

		if (inputSbc.getCustIpAddress() != null && !inputSbc.getCustIpAddress().equals(defSbcBean.getCustIpAddress())) {
			sbcInfoDbBean.setCustIpAddress(inputSbc.getCustIpAddress());
		}

		if (inputSbc.getCustPort() != defSbcBean.getCustPort()) {
			sbcInfoDbBean.setCustPort(inputSbc.getCustPort());
		}
		if (inputSbc.getEnvOrderId() != defSbcBean.getEnvOrderId()) {
			sbcInfoDbBean.setEnvOrderId(inputSbc.getEnvOrderId());
		}
		if (inputSbc.getModifiedBy() != null && !("".equalsIgnoreCase(inputSbc.getModifiedBy())))
			sbcInfoDbBean.setModifiedBy(getModifiedBy());
		else
			sbcInfoDbBean.setModifiedBy("ESAP_INV");

		sbcInfoDbBean.setLastModifiedDate(new Timestamp(System.currentTimeMillis()));

		return sbcInfoDbBean;

	}
}
