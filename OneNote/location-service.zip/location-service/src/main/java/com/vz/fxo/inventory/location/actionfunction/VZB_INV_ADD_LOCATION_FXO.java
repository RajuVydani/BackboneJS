package com.vz.fxo.inventory.location.actionfunction;

import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.vz.fxo.inventory.actionfunction.support.VmAccessBean;
import com.vz.fxo.inventory.actionfunction.support.VzbInvException;
import com.vz.fxo.inventory.tn.GenericActionFunction;
import com.vz.fxo.inventory.tn.helper.ActionFunctionHelper;

import EsapEnumPkg.VzbVoipEnum;
import esap.db.DBTblVzbStateGatewayMap;
import esap.db.TblCustomerDbBean;
import esap.db.TblEnterpriseDbBean;
import esap.db.TblLocationDbBean;

import static com.vz.fxo.inventory.tn.helper.ActionFunctionHelper.*;
import static com.vz.fxo.inventory.tn.helper.TNActionFunction.*;
import com.vz.esap.api.model.ESAPEntityEnum;
import com.vz.esap.api.model.dto.OrderDomainServiceDTO;
import com.vz.esap.api.model.ordering.EntityBatch;
import com.vz.esap.api.model.ordering.TableOrderDetailsParam;
import com.vz.fxo.inventory.actionfunction.support.AcctAuthCodes;
import com.vz.fxo.inventory.actionfunction.support.AcctAuthCodesBean;
import com.vz.fxo.inventory.actionfunction.support.Location;
import com.vz.fxo.inventory.actionfunction.support.PublicTnPool;
import com.vz.fxo.inventory.actionfunction.support.PublicTnPoolBean;
import com.vz.fxo.inventory.actionfunction.support.TblEntBillFeaturesBean;
import com.vz.fxo.inventory.actionfunction.support.VmAccess;

public class VZB_INV_ADD_LOCATION_FXO extends GenericActionFunction {
	
	private static Logger log = LoggerFactory.getLogger(VZB_INV_ADD_LOCATION_FXO.class.toString());
	private LocationUtil lutil = new LocationUtil();
	public int go() {
		
		log.info("Task VZB_INV_ADD_LOCATION Started WorkOrderNumber : {}",this.workOrderNumber);
		OrderDomainServiceDTO domainServiceDTO = null;
		
		try {
			//List<String> paramList = null;
			entityType = ESAPEntityEnum.LOCATION;
			domainServiceDTO = getOrderDomainDetail(entityType);
			
			Map<String, EntityBatch> map = domainServiceDTO.getEntityTypeMap();
			EntityBatch entityBatch = map.get(entityType.toString());
			log.info("entityBatch.toString:::"+entityBatch.toString());
			log.info("cleanEntityBatchSetCommonFields start"+this.orderNumber);
			cleanEntityBatchSetCommonFields(entityBatch,this.orderNumber);
			
			Location location;

//			location = new Location(connection);
			location = lutil.getLocation();
			List<VmAccessBean> vmAccessList = new ArrayList<VmAccessBean>();

			String envOrderId = getEnvOrderId();
			if (envOrderId != null && !(envOrderId.isEmpty()))
				location.setEnvOrderId(Long.valueOf(envOrderId));
			log.info("XO changes start---> {}" , envOrderId);
			
			TableOrderDetailsParam eslId = getTableOrderDetailsParam(entityBatch,"ESLid");
			if (eslId != null && eslId.getParamValue() != null)
				location.setEslId(eslId.getParamValue());
			
			TableOrderDetailsParam redundency  = getTableOrderDetailsParam(entityBatch,"Redundency");
			if (redundency != null && redundency.getParamValue() != null)
				location.setRedundency(redundency.getParamValue());
			
			TableOrderDetailsParam redundencyPriorityType  = getTableOrderDetailsParam(entityBatch,"RedundencyPriorityType");
			if (redundencyPriorityType != null && redundencyPriorityType.getParamValue() != null)
				location.setRedundencyPriorityType(redundencyPriorityType.getParamValue());
			
			TableOrderDetailsParam billingTN  = getTableOrderDetailsParam(entityBatch,"BillingTN");
			if (billingTN != null && billingTN.getParamValue() != null)
				location.setBillingTN(billingTN.getParamValue());
			
			TableOrderDetailsParam broadworksPortalNumber  = getTableOrderDetailsParam(entityBatch,"BroadworksPortalNumber");
			if (broadworksPortalNumber != null && broadworksPortalNumber.getParamValue() != null)
				location.setBroadworksPortalNumber(broadworksPortalNumber.getParamValue());
			
			
			TableOrderDetailsParam groupUserLimit  = getTableOrderDetailsParam(entityBatch,"GroupUserLimit");
			if (broadworksPortalNumber != null && broadworksPortalNumber.getParamValue() != null)
				location.setGroupUserLimit(broadworksPortalNumber.getParamValue());
			
			TableOrderDetailsParam locGroupId  = getTableOrderDetailsParam(entityBatch,"EslBwGroupId");
			if (locGroupId != null && locGroupId.getParamValue() != null)
				location.setLocGroupId(locGroupId.getParamValue());
			
			
			
			log.info("XO changes start---> {}" , envOrderId);
			
			
			TableOrderDetailsParam prefixPlanId = getTableOrderDetailsParam(entityBatch,"PrefixPlanId");
			if (prefixPlanId != null && prefixPlanId.getParamValue() != null)
				location.setDefaultPpId(Long.valueOf(prefixPlanId.getParamValue()));

			String locationId = getLocationId(entityBatch);
			if (locationId != null){
				location.setLocationId(locationId);
			}
			//KR start 
			//if(locationId==null || "".equalsIgnoreCase(locationId)){
				//TableOrderDetailsParam featureInstanceId = getTableOrderDetailsParamByName(entityBatch., "LocationId");
		//	}
			else{
				TableOrderDetailsParam LocationId = getTableOrderDetailsParam(entityBatch,"LocationId");
				if (LocationId != null && LocationId.getParamValue() != null)
					location.setLocationId(locationId);
			}
			// kr end
			log.info("XO changes start locationId---> {}" , locationId);
			TableOrderDetailsParam customerId = getTableOrderDetailsParam(entityBatch,"CustomerId");
			if (customerId != null && customerId.getParamValue() != null)
				location.setEnterpriseId(customerId.getParamValue());

			
			TableOrderDetailsParam pendingRPID = getTableOrderDetailsParam(entityBatch,"PendingRPID");
			if (pendingRPID != null && pendingRPID.getParamValue() != null)
				location.setPendingRpid(pendingRPID.getParamValue());

			TableOrderDetailsParam originatingSystem = getTableOrderDetailsParam(entityBatch,"OriginatingSystem");
			if (originatingSystem != null && originatingSystem.getParamValue() != null)
				location.setOrderSource(originatingSystem.getParamValue());

			TableOrderDetailsParam name = getTableOrderDetailsParam(entityBatch,"Name");
			if (name != null && name.getParamValue() != null
					&& !name.getParamValue().equalsIgnoreCase("")) {
				location.setLocationName(name.getParamValue());
			} else { //delete once testing done
				String errorMessage = "Location Name is invalid/not present in the order";
				log.error(errorMessage);
				throw new VzbInvException("VZB_INV_ADD_LOCATION_FAILED",
						errorMessage);
			}
			//CLIN Chnages - 2016
			TableOrderDetailsParam clin = getTableOrderDetailsParam(entityBatch,"Clin");
			if (clin != null && clin.getParamValue() != null)
				location.setClin(clin.getParamValue());
			
			//CLIN Chnages - 2016 -end
			// IR #1650835- Changes
			TableOrderDetailsParam address = getTableOrderDetailsParam(entityBatch,"Address");
			if (address != null && address.getParamValue() != null)
				location.setLocAddress(address.getParamValue());

			TableOrderDetailsParam city = getTableOrderDetailsParam(entityBatch,"City");
			if (city != null && city.getParamValue() != null)
				location.setLocCity(city.getParamValue());

			TableOrderDetailsParam state = getTableOrderDetailsParam(entityBatch,"State");
			if (state != null && state.getParamValue() != null)
				location.setLocState(state.getParamValue());

			TableOrderDetailsParam zip = getTableOrderDetailsParam(entityBatch,"Zip");
			if (zip != null && zip.getParamValue() != null)
				location.setLocZip(zip.getParamValue());

			TableOrderDetailsParam npaNxx = getTableOrderDetailsParam(entityBatch,"NpaNxx");
			if ( npaNxx != null && npaNxx.getParamValue() != null)
				location.setNpaNxx(npaNxx.getParamValue());

			// E2EI
			TableOrderDetailsParam lorID = getTableOrderDetailsParam(entityBatch,"LORID");
			if (lorID != null && lorID.getParamValue() != null)
				location.setLorId(lorID.getParamValue());
			
			TableOrderDetailsParam hybridService = getTableOrderDetailsParam(entityBatch,"HybridService");
			if (hybridService != null && hybridService.getParamValue() != null) {
				location.setHybridAssigned(Short.parseShort(hybridService.getParamValue()));
			}
			
			TableOrderDetailsParam is_E2E = getTableOrderDetailsParam(entityBatch,"isE2E");
			if (is_E2E != null
					&& is_E2E.getParamValue().equalsIgnoreCase("Y")) {
				location.setE2eimigflag((short) 2);
			}
			
			TableOrderDetailsParam enterpriseTrunkId = getTableOrderDetailsParam(entityBatch,"EnterpriseTrunkId");
			if (enterpriseTrunkId != null && enterpriseTrunkId.getParamValue() != null) {
				location.setEnterpriseTrunkId(Long.parseLong(enterpriseTrunkId.getParamValue()));
			}
			
			TableOrderDetailsParam pQ_InstanceId = getTableOrderDetailsParam(entityBatch,"PQInstanceId");
			if (pQ_InstanceId != null && pQ_InstanceId.getParamValue() != null) {
				location.setPqInstanceId(Long.parseLong(pQ_InstanceId.getParamValue()));
			}
			
			TableOrderDetailsParam physicalLocationId = getTableOrderDetailsParam(entityBatch,"PhysicalLocationId");
			if (physicalLocationId != null && physicalLocationId.getParamValue() != null)
				location.setPhysicalLocationId(physicalLocationId.getParamValue());

			TableOrderDetailsParam physicalLocationName = getTableOrderDetailsParam(entityBatch,"PhysicalLocationName");
			if (physicalLocationName != null && physicalLocationName.getParamValue() != null)
				location.setPhysicalLocationName(physicalLocationName.getParamValue());

			TableOrderDetailsParam dialingCountryCode = getTableOrderDetailsParam(entityBatch,"DialingCountryCode");
			if (dialingCountryCode != null && dialingCountryCode.getParamValue() != null)
				location.setDialingCountryCode(dialingCountryCode.getParamValue());

			TableOrderDetailsParam callForwardPlanName = getTableOrderDetailsParam(entityBatch,"CallForwardPlanName");
			if (callForwardPlanName != null && callForwardPlanName.getParamValue() != null)
				location.setCallFwdPlanName(callForwardPlanName.getParamValue());

			TableOrderDetailsParam contactPhone = getTableOrderDetailsParam(entityBatch,"ContactPhone");
			if (contactPhone != null && contactPhone.getParamValue() != null)
				location.setContactPhone(contactPhone.getParamValue());

			TableOrderDetailsParam abbrDialingCode = getTableOrderDetailsParam(entityBatch,"AbbrDialingCode");
			if (abbrDialingCode != null && abbrDialingCode.getParamValue() != null)
				location.setAbbrDialingCode(abbrDialingCode.getParamValue());

			TableOrderDetailsParam contactEmail = getTableOrderDetailsParam(entityBatch,"ContactEmail");
			if (contactEmail != null && contactEmail.getParamValue() != null)
				location.setContactEmail(contactEmail.getParamValue());

			TableOrderDetailsParam contactName = getTableOrderDetailsParam(entityBatch,"ContactName");
			if (contactName != null && contactName.getParamValue() != null)
				location.setContactName(contactName.getParamValue());
			
			TableOrderDetailsParam enableAccountCode = getTableOrderDetailsParam(entityBatch,"EnableAccountCode");
			if (enableAccountCode != null && enableAccountCode.getParamValue() != null) {
				if (VzbVoipEnum.YesNoType.name(VzbVoipEnum.YesNoType.Y)
						.equalsIgnoreCase(enableAccountCode.getParamValue())) {
					location.setEnableAccountCode(VzbVoipEnum.YesNoType.Y);
				} else {
					location.setEnableAccountCode(VzbVoipEnum.YesNoType.N);
				}
			}

			TableOrderDetailsParam acctTeamPhone = getTableOrderDetailsParam(entityBatch,"AcctTeamPhone");
			if (acctTeamPhone != null && acctTeamPhone.getParamValue() != null)
				location.setActTeamPhone(acctTeamPhone.getParamValue());

			TableOrderDetailsParam acctTeamEmail = getTableOrderDetailsParam(entityBatch,"AcctTeamEmail");
			if (acctTeamEmail != null && acctTeamEmail.getParamValue() != null)
				location.setActTeamEmail(acctTeamEmail.getParamValue());

			TableOrderDetailsParam acctTeamName = getTableOrderDetailsParam(entityBatch,"AcctTeamName");
			if (acctTeamName != null && acctTeamName.getParamValue() != null)
				location.setActTeamName(acctTeamName.getParamValue());

			TableOrderDetailsParam country = getTableOrderDetailsParam(entityBatch,"Country");
			if (country != null && country.getParamValue() != null)
				location.setLocCountry(country.getParamValue());
			
			TableOrderDetailsParam timeZone = getTableOrderDetailsParam(entityBatch,"TimeZone");
			if (timeZone != null && timeZone.getParamValue() != null) {
				location.setTimeZone(""
						+ VzbVoipEnum.TimeZone
								.valueByAcronym(VzbVoipEnum.TimeZone
										.acronym(Integer.parseInt(timeZone.getParamValue()))));
			}

			// TBL_ DAYLIGHT_SAVINGS_REGIONS.DAYLIGHT_SAVINGS_REGIONS_ID -
			// getDaylightSavingsRegionId()
			if (timeZone != null && timeZone.getParamValue() != null)
				location.setDayLightSavingsRegion(""
						+ getDaylightSavingsRegionId(connection,timeZone.getParamValue()));

			// TBL_LANGUAGE.LANG_CODE - getLangCode(String lang)
			TableOrderDetailsParam webLanguage = getTableOrderDetailsParam(entityBatch,"WebLanguage");
			if (webLanguage != null && webLanguage.getParamValue() != null)
				location.setWebLang(VzbVoipEnum.Language
						.valueByAcronym(webLanguage.getParamValue()));

			// If market Type is Bundled Then conforms to (4 + I + six digits)
			// formatIf market Type is A la Carte, Then must conform to the
			// following format rules: - 8 byte field- First byte always
			// numeric.- Second byte always alphabetic.
			TableOrderDetailsParam netcomSvcId = getTableOrderDetailsParam(entityBatch,"NetcomSvcId");
			if (netcomSvcId != null && netcomSvcId.getParamValue() != null)
				location.setNetcomServiceId(netcomSvcId.getParamValue());

			TableOrderDetailsParam circuitId = getTableOrderDetailsParam(entityBatch,"CircuitId");
			TableOrderDetailsParam UNumber = getTableOrderDetailsParam(entityBatch,"UNumber");
			if (circuitId != null
					&& circuitId.getParamValue() != null
					&& !circuitId.getParamValue().equals(""))
				location.setCircuitId(circuitId.getParamValue());
			else if (UNumber != null
					&& UNumber.getParamValue() != null
					&& !UNumber.getParamValue().equals("")) {
				log.info("DEBUG : using UNumber without checking");
				location.setCircuitId(UNumber.getParamValue());
			}

			TableOrderDetailsParam uunetSiteId = getTableOrderDetailsParam(entityBatch,"UunetSiteId");
			if (uunetSiteId != null && uunetSiteId.getParamValue() != null)
				location.setUunetSiteId(uunetSiteId.getParamValue());
			
			TableOrderDetailsParam productId = getTableOrderDetailsParam(entityBatch,"ProductId");
			if (productId != null && productId.getParamValue() != null) {
				log.info("Product ID is not null");
				location.setProductIdentifier(productId.getParamValue());
			}

			
			TableOrderDetailsParam switchClli = getTableOrderDetailsParam(entityBatch,"SwitchClli");
			if (switchClli != null && switchClli.getParamValue() != null)
				location.setSwitchClli(switchClli.getParamValue());

			TableOrderDetailsParam trunk = getTableOrderDetailsParam(entityBatch,"Trunk");
			if (trunk != null && trunk.getParamValue() != null)
				location.setTrunk(trunk.getParamValue());

			TableOrderDetailsParam trunkType = getTableOrderDetailsParam(entityBatch,"TrunkType");
			if (trunkType != null && trunkType.getParamValue() != null)
				location.setTrunkType(Integer.parseInt(trunkType.getParamValue()));
			else
				location.setTrunkType(1);

			TableOrderDetailsParam sipDomain = getTableOrderDetailsParam(entityBatch,"SipDomain");
			if (sipDomain != null && sipDomain.getParamValue() != null)
				location.setSipDomain(sipDomain.getParamValue());

			TableOrderDetailsParam vmLanguage = getTableOrderDetailsParam(entityBatch,"VmLanguage");
			if (vmLanguage != null && vmLanguage.getParamValue() != null)
				location.setVmLang(VzbVoipEnum.Language
						.valueByAcronym(vmLanguage.getParamValue()));

			TableOrderDetailsParam ixPlusRegion = getTableOrderDetailsParam(entityBatch,"IxPlusRegion");
			if (ixPlusRegion != null && ixPlusRegion.getParamValue() != null)
				location.setIxPlusEnvId(ixPlusRegion.getParamValue());

			TableOrderDetailsParam privateNumberLength = getTableOrderDetailsParam(entityBatch,"PrivateNumberLength");
			if (privateNumberLength != null && privateNumberLength.getParamValue() != null)
				location.setPrivateNumLength(Integer
						.parseInt(privateNumberLength.getParamValue()));

			TableOrderDetailsParam maxConcurrentSlg = getTableOrderDetailsParam(entityBatch,"MaxConcurrentSlg");
			if (maxConcurrentSlg != null && maxConcurrentSlg.getParamValue() != null)
				location.setMaxSlg(Integer.parseInt(maxConcurrentSlg.getParamValue()));

			TableOrderDetailsParam maxConcurrentInbound = getTableOrderDetailsParam(entityBatch,"MaxConcurrentInbound");
			if (maxConcurrentInbound != null && maxConcurrentInbound.getParamValue() != null)
				location.setMaxInbound(Integer.parseInt(maxConcurrentInbound.getParamValue()));

			TableOrderDetailsParam totalVoiceMailAccts = getTableOrderDetailsParam(entityBatch,"TotalVoiceMailAccts");
			if (totalVoiceMailAccts != null && totalVoiceMailAccts.getParamValue() != null)
				location.setMaxVmBox(Integer
						.parseInt(totalVoiceMailAccts.getParamValue()));

			TableOrderDetailsParam daylightSavingInd = getTableOrderDetailsParam(entityBatch,"DaylightSavingInd");
			if (daylightSavingInd != null && daylightSavingInd.getParamValue() != null) {
				location.setUseDaylightSaving(VzbVoipEnum.YesNoType
						.valueByName(daylightSavingInd.getParamValue()));
				log.info("DaylightSavingInd {}"
						, daylightSavingInd.getParamValue());
				log.info("location useDayLightSaving: {}"
						, location.getUseDaylightSaving());
			}
			
			TableOrderDetailsParam qosIndicator = getTableOrderDetailsParam(entityBatch,"QosIndicator");
			if (qosIndicator != null && qosIndicator.getParamValue() != null)
				location.setQosInd(VzbVoipEnum.QosIndicator
						.valueByAcronym(qosIndicator.getParamValue()));

			TableOrderDetailsParam ixPlusID = getTableOrderDetailsParam(entityBatch,"IxPlusID");
			if (ixPlusID != null && ixPlusID.getParamValue() != null)
				location.setIxPlusId(Long.parseLong(ixPlusID.getParamValue()));

			TableOrderDetailsParam cv2Service = getTableOrderDetailsParam(entityBatch,"Cv2Service");
			if (cv2Service != null && cv2Service.getParamValue() != null)
				location.setCv2Service(VzbVoipEnum.YesNoType
						.valueByName(cv2Service.getParamValue()));

			TableOrderDetailsParam managedFlag = getTableOrderDetailsParam(entityBatch,"ManagedFlag");
			if (managedFlag != null && managedFlag.getParamValue() != null)
				location.setManagedService(VzbVoipEnum.YesNoType
						.valueByName(managedFlag.getParamValue()));

			TableOrderDetailsParam voipServiceType = getTableOrderDetailsParam(entityBatch,"VoipServiceType");
			if (voipServiceType != null && voipServiceType.getParamValue() != null)
				location.setVoipServiceType(VzbVoipEnum.VoipServiceType
						.valueByAcronym(voipServiceType.getParamValue()));

			TableOrderDetailsParam hybridServiceType = getTableOrderDetailsParam(entityBatch,"HybridServiceType");
			if (hybridServiceType != null && hybridServiceType.getParamValue() != null)
				location.setHybridServiceType(VzbVoipEnum.HybridServiceType
						.valueByAcronym(hybridServiceType.getParamValue()));

			TableOrderDetailsParam maxConcurrentCalls = getTableOrderDetailsParam(entityBatch,"MaxConcurrentCalls");
			if (maxConcurrentCalls != null && maxConcurrentCalls.getParamValue() != null)
				location.setMaxConcurrentCalls(Integer.parseInt(maxConcurrentCalls.getParamValue()));

			TableOrderDetailsParam maxConcurrentOffNet = getTableOrderDetailsParam(entityBatch,"MaxConcurrentOffNet");
			if (maxConcurrentOffNet != null && maxConcurrentOffNet.getParamValue() != null)
				location.setMaxConcurrentOffnet(Integer
						.parseInt(maxConcurrentOffNet.getParamValue()));

			TableOrderDetailsParam maxNg = getTableOrderDetailsParam(entityBatch,"MaxNg");
			if (maxNg != null && maxNg.getParamValue() != null) {
				location.setMaxNg(Integer.parseInt(maxNg.getParamValue()));
			}

			TableOrderDetailsParam marketType = getTableOrderDetailsParam(entityBatch,"MarketType");
			if (marketType != null && marketType.getParamValue() != null)
				location.setLocMarket(VzbVoipEnum.LocationMarketType
						.valueByAcronym(marketType.getParamValue()));

			TableOrderDetailsParam premise_VMSMDI = getTableOrderDetailsParam(entityBatch,"PremiseVMSMDI");
			log.info("PremiseVMSMDI Value is ==== > {}", premise_VMSMDI);

			if (premise_VMSMDI != null) {
				String premiseVMSMDI = premise_VMSMDI.getParamValue();
				if (premiseVMSMDI.equalsIgnoreCase(VzbVoipEnum.YesNoType
						.acronym(VzbVoipEnum.YesNoType.Y))) {
					location.setVmSmdiAuthToggle(VzbVoipEnum.YesNoType.Y);
				} else {
					location.setVmSmdiAuthToggle(VzbVoipEnum.YesNoType.N);
				}

			}
			
			TableOrderDetailsParam serviceLevel = getTableOrderDetailsParam(entityBatch,"ServiceLevel");
			if (serviceLevel != null && serviceLevel.getParamValue() != null)
				location.setServiceLevel(VzbVoipEnum.ServiceLevel
						.valueByAcronym(serviceLevel.getParamValue()));

			// IASA sets E911_service to 1(i.e block) if the service level is LD
			// and On-Net(2)/Onnet Only(3) and Inbound Only(5)..
			if (serviceLevel != null && serviceLevel.getParamValue() != null) {
				int e911 = VzbVoipEnum.ServiceLevel.valueByAcronym(serviceLevel.getParamValue());
				if ((e911 != VzbVoipEnum.ServiceLevel.LD_LOCAL_AND_ON_NET)
						&& (e911 != VzbVoipEnum.ServiceLevel.LOCAL_AND_ON_NET))
					location.setE911Service((short) VzbVoipEnum.YesNoType.Y);
				else
					location.setE911Service((short) VzbVoipEnum.YesNoType.N);
			}

			TableOrderDetailsParam extensionLength = getTableOrderDetailsParam(entityBatch,"ExtensionLength");
			if (extensionLength != null && extensionLength.getParamValue() != null)
				location.setExtLength(Integer.parseInt(extensionLength.getParamValue()));

			
			TableOrderDetailsParam totalSubscribers = getTableOrderDetailsParam(entityBatch,"TotalSubscribers");
			if (totalSubscribers != null && totalSubscribers.getParamValue() != null)
				location.setMaxSubscribers(Integer.parseInt(totalSubscribers.getParamValue()));

			TableOrderDetailsParam totalPublicNumbers = getTableOrderDetailsParam(entityBatch,"TotalPublicNumbers");
			if (totalPublicNumbers != null && totalPublicNumbers.getParamValue() != null)
				location.setMaxPublicTn(Integer.parseInt(totalPublicNumbers.getParamValue()));

			TableOrderDetailsParam billingType = getTableOrderDetailsParam(entityBatch,"BillingType");
			if (billingType != null && billingType.getParamValue() != null)
				location.setBillType(VzbVoipEnum.BillingType
						.valueByAcronym(billingType.getParamValue()));

			TableOrderDetailsParam advantageClub = getTableOrderDetailsParam(entityBatch,"AdvantageClub");
			if (advantageClub != null && advantageClub.getParamValue() != null)
				location.setVoipClub(VzbVoipEnum.YesNoType
						.valueByName(advantageClub.getParamValue()));

			TableOrderDetailsParam pubIp = getTableOrderDetailsParam(entityBatch,"PubIp");
			if (pubIp != null && pubIp.getParamValue() != null)
				location.setPubIp(VzbVoipEnum.YesNoType.valueByName(pubIp.getParamValue()));

			TableOrderDetailsParam emergencyCallLine = getTableOrderDetailsParam(entityBatch,"EmergencyCallLine");
			if (emergencyCallLine != null && emergencyCallLine.getParamValue() != null)
				location.setBillTn(emergencyCallLine.getParamValue());
		
			// Added as per Nov-09 release changes --Start

			
			TableOrderDetailsParam emer_PoolId = getTableOrderDetailsParam(entityBatch,"emerPoolId");
			log.info("emer_PoolId in AF---> {}" , emer_PoolId);
			if (emer_PoolId != null && emer_PoolId.getParamValue() != null)
				location.setEmerPoolId(Integer.parseInt(emer_PoolId.getParamValue()));

			TableOrderDetailsParam emerLocationCode = getTableOrderDetailsParam(entityBatch,"EmerLocationCode");
			log.info("emerLocationCode in AF---> {}" , emerLocationCode);
			if (emerLocationCode != null && emerLocationCode.getParamValue() != null)
				location.setEmerLocationCode(emerLocationCode.getParamValue());

			TableOrderDetailsParam typeOfLoc = getTableOrderDetailsParam(entityBatch,"TypeOfLoc");
			log.info("typeOfLoc in AF---> {}" , typeOfLoc);
			if (typeOfLoc != null && typeOfLoc.getParamValue() != null)
				location.setLocationType(VzbVoipEnum.LocationType
						.valueByAcronym(typeOfLoc.getParamValue()));

			TableOrderDetailsParam fmcLocation = getTableOrderDetailsParam(entityBatch,"FmcLocation");
			log.info("fmcLocation in AF---> {}" , fmcLocation);
			if (fmcLocation != null && fmcLocation.getParamValue() != null)
				location.setFmcgLocationType(VzbVoipEnum.FmcgLocationType
						.valueByAcronym(fmcLocation.getParamValue()));

			TableOrderDetailsParam hubLocationId = getTableOrderDetailsParam(entityBatch,"HubLocationId");
			log.info("hubLocationId in AF---> {}" , hubLocationId);
			if (hubLocationId != null && hubLocationId.getParamValue() != null)
				location.setHubLocationId(hubLocationId.getParamValue());

			TableOrderDetailsParam hubGatewayDeviceId = getTableOrderDetailsParam(entityBatch,"HubGatewayDeviceId");
			log.info("hubGatewayDeviceId in AF---> {}" , hubGatewayDeviceId);
			if (hubGatewayDeviceId != null && hubGatewayDeviceId.getParamValue() != null)
				location.setHubGatewayDeviceId(Long.valueOf(hubGatewayDeviceId.getParamValue()));

			TableOrderDetailsParam locationMask = getTableOrderDetailsParam(entityBatch,"LocationMask");
			if (locationMask != null && locationMask.getParamValue() != null)
				location.setLocationMask(Long.valueOf(locationMask.getParamValue()));

			TableOrderDetailsParam aNumMask = getTableOrderDetailsParam(entityBatch,"ANumMask");
			if (aNumMask != null && aNumMask.getParamValue() != null)
				location.setANumMask(Long.valueOf(aNumMask.getParamValue()));

			TableOrderDetailsParam bNumMask = getTableOrderDetailsParam(entityBatch,"BNumMask");
			if (bNumMask != null && bNumMask.getParamValue() != null)
				location.setBNumMask(Long.valueOf(bNumMask.getParamValue()));

			// End

			if (originatingSystem != null) {
				location.setCreatedBy(originatingSystem.getParamValue());
				location.setModifiedBy(originatingSystem.getParamValue());
			} else {
				location.setCreatedBy("SYSTEM");
				location.setModifiedBy("SYSTEM");
			}

			TableOrderDetailsParam rIVLocation = getTableOrderDetailsParam(entityBatch,"RIVLocation");
			if (rIVLocation != null && rIVLocation.getParamValue() != null) {
				location.setRivLocation(VzbVoipEnum.YesNoType
						.valueByAcronym(rIVLocation.getParamValue()));
			}
			
			TableOrderDetailsParam rIVCustomer = getTableOrderDetailsParam(entityBatch,"RIVCustomer");
			if (rIVCustomer != null
					&& "N".equals(rIVCustomer.getParamValue())) {
				location.setSbcMigInd(VzbVoipEnum.YesNoType.Y);
				location.setRivLocation(VzbVoipEnum.YesNoType.N);
			}
			log.info("rIVCustomer {}", rIVCustomer);
			TableOrderDetailsParam sbcAccessType = getTableOrderDetailsParam(entityBatch,"SbcAccessType");
			if (sbcAccessType != null) {
				String sbc_AccessType = sbcAccessType.getParamValue();
				if ("S".equals(sbc_AccessType)) {
					log.info("Its a IDA location");
					location.setSbcAccessType(sbc_AccessType);
				} else {
					log.info("Its a Non-IDA location");
				}
			}
		//	log.info("sbc_AccessType {}", sbc_AccessType);
			TableOrderDetailsParam productType = getTableOrderDetailsParam(entityBatch,"ProductType");
			if (productType != null) {
				String product_Type = productType.getParamValue();
				log.info("productType {}", product_Type);
				if ("7".equals(product_Type)) {
					log.info("Its a IPCC Customer");
					location.setProductType(product_Type);
				} else {
					log.info("Its a Non-IPCC Customer");
				}
			}

			// get it from tbl_enterprise for the given customer_id
			TblEnterpriseDbBean enterpriseDbBean = getEnterpriseForEnterpriseId(connection,
					location.getEnterpriseId());
			log.info("enterpriseDbBean {}", enterpriseDbBean);
			if(enterpriseDbBean!=null){
			location.setServiceTypeOffering(Integer.parseInt(""
					+ enterpriseDbBean.getPlatformIndicator()));
			log.info("enterpriseDbBean {}", location.getServiceTypeOffering());
			location.setConcCallStat(Integer.parseInt(""
					+ enterpriseDbBean.getEntcclInd()));
			}
			location.setEnableDhcp(0);
			
			TableOrderDetailsParam blockAllCalls = getTableOrderDetailsParam(entityBatch,"BlockAllCalls");
			if (blockAllCalls != null && blockAllCalls.getParamValue() != null)
				location.setBlockAllCalls(VzbVoipEnum.YesNoType
						.valueByAcronym(blockAllCalls.getParamValue()));
			location.setActiveInd(1);
			log.info("processClid start");
			processClid(entityBatch, location); 
			log.info("processClid end");
			TableOrderDetailsParam accessType = getTableOrderDetailsParam(entityBatch,"AccessType");
			if (accessType != null && accessType.getParamValue() != null) {
				location.setAccessType(VzbVoipEnum.AccessType
						.valueByAcronym(accessType.getParamValue()));

				boolean isSbcEsap = isEsapSbcOrder(location.getEnterpriseId(),connection);

				log.info("isSbcEsap in AF---> {}" , isSbcEsap);
				log.info("location.getAccessType()---> {}"
						, location.getAccessType());

				if (isSbcEsap && location.getAccessType() == -1) {
					throw new VzbInvException(
							"ESP_VZB_INV_ACCESS_TYPE_NOT_FOUND",
							"ESP_VZB_INV_ACCESS_TYPE_NOT_FOUND");
				}

			}

			TableOrderDetailsParam linePortLength = getTableOrderDetailsParam(entityBatch,"LinePortLength");
			if (linePortLength != null && linePortLength.getParamValue() != null) {
				location.setLinePortLength(Long.valueOf(linePortLength.getParamValue()));
			}

			TableOrderDetailsParam callingPlanId = getTableOrderDetailsParam(entityBatch,"CallingPlanId");
			if (callingPlanId != null && callingPlanId.getParamValue() != null) {
				location.setCallingPlanId(Long.valueOf(callingPlanId.getParamValue()));
			}

			TableOrderDetailsParam publicGtwyDpid = getTableOrderDetailsParam(entityBatch,"PublicGtwyDpid");
			if (publicGtwyDpid != null && publicGtwyDpid.getParamValue() != null) {
				location.setPublicGtwyDpid(Integer.parseInt(publicGtwyDpid.getParamValue()));
			}

			TableOrderDetailsParam defaultGtwyDpid = getTableOrderDetailsParam(entityBatch,"DefaultGtwyDpid");
			if (defaultGtwyDpid != null && defaultGtwyDpid.getParamValue() != null) {
				location.setDefaultGtwyDpid(Integer.parseInt(defaultGtwyDpid.getParamValue()));
			}

			TableOrderDetailsParam subAgencyHierCode = getTableOrderDetailsParam(entityBatch,"SubAgencyHierCode");
			if (subAgencyHierCode != null && subAgencyHierCode.getParamValue() != null) {
				location.setSubAgencyHierCode(subAgencyHierCode.getParamValue());
			}
			//KR start
			//String customer_Id="1000000000080";//kr delete once testing done
			//if(customerId!=null){
			String customer_Id = customerId.getParamValue();
			//customer_Id = customerId.getParamValue();
			TblCustomerDbBean customerDbBean;
			customerDbBean = getCustomer(customer_Id);
			if (customerDbBean.getRegionId() == VzbVoipEnum.RegionType.EMEA)
				location.setProductionIndicator(VzbVoipEnum.YesNoType.N);
			else
				location.setProductionIndicator(VzbVoipEnum.YesNoType.Y);
			//}//end

		    /**
		    * Changes: z658915 - Starts
		    * 
		    */
		   
		    
		    boolean isE2eMig = false;
		    if (( is_E2E != null ) && (is_E2E.getParamValue() != null)
		    		&& is_E2E.getParamValue().equalsIgnoreCase("Y"))
		    {
		    	isE2eMig = true;
		    }
		    int order_platform = 0;
		    int ui_prov_flag = 0;
		    order_platform = getOrdPlatform(customer_Id,connection);

		    if (order_platform != -1) {
		    	if (order_platform == 1 && isE2eMig)
		    		ui_prov_flag = 5;
		    	if (order_platform == 3)
		    		ui_prov_flag = 5;
		    	location.setUiProvFlag((short)ui_prov_flag);
		    }
		    /**
		    * Changes: z658915 - Ends
		    * 
		    */

			// added by z658915 for calnet changes
		    TableOrderDetailsParam calnetSubContractInd = getTableOrderDetailsParam(entityBatch,"CalnetSubContractInd");
		    if (calnetSubContractInd != null && calnetSubContractInd.getParamValue() != null) {
				location.setCalnetSubContractId(Short.parseShort(calnetSubContractInd.getParamValue()));
			} else {
				location.setCalnetSubContractId(location.getCalnetIndFromEnterprise(customer_Id));
			}

			/*****************************/

			/*****************************/

		    if (null!=getTableOrderDetailsParam(entityBatch,"VoiceMailAccess")) {// 
					List<TableOrderDetailsParam> todList1 = searchParamListNew(entityBatch,"VoiceMailAccess");
					for (TableOrderDetailsParam tod1 : todList1) {
					VmAccess vmAccessObj = new VmAccess(connection);

					if (customerId != null && customerId.getParamValue()!= null)
						vmAccessObj.setEnterpriseId(customerId.getParamValue());

					if (locationId != null)
						vmAccessObj.setLocationId(locationId);

					 TableOrderDetailsParam subscriberId = getTableOrderDetailsParam(entityBatch,"SubscriberId");
					if (subscriberId != null && subscriberId.getParamValue() != null)
						vmAccessObj.setSubId(subscriberId.getParamValue());

					vmAccessObj.setNpaSplitStatus(0);

					if (originatingSystem != null) {
						vmAccessObj.setCreatedBy(originatingSystem.getParamValue());
						vmAccessObj.setModifiedBy(originatingSystem.getParamValue());
					} else {
						vmAccessObj.setCreatedBy("SYSTEM");
						vmAccessObj.setModifiedBy("SYSTEM");
					}

					String orderDetailId = tod1.getOrderDetailId();

					boolean isParamNameFound = false;
					//Vector paramListNode = pd.getParams();
					List<TableOrderDetailsParam> childTodList = tod1.getParamDetail();
					for (TableOrderDetailsParam childTod: childTodList) {
						
						if (childTod.getParentId() !=null   && childTod.getParentId().equalsIgnoreCase(orderDetailId) ) {
							isParamNameFound = true;
							if (childTod.getParamName().equals("PublicNumber"))
								vmAccessObj.setPublicNumber(childTod
										.getParamValue());

							if (childTod.getParamName().equals("PrivateNumber")) {
								if (isIeanExistsForEnterprise(
										childTod.getParamValue(), customerId.getParamValue(), connection)) {
									insertOrderLog("Private Number Already Exists for this Enterprise EnterpriseId ::"
													+ customerId.getParamValue()
													+ "  PrivateNumber::"
													+ childTod.getParamValue());
								
								} else
									vmAccessObj.setPrivateNumber(childTod.getParamValue());
							}

						}

					}// for

					if (isParamNameFound)
						vmAccessList.add(vmAccessObj);
				}// for 
			}// if

			// if SBC Access Type is Not "D", Set Vpn Name to Enterprise Id.
			// Else Do Not Set VPN Name - Anand
			if (location.validAccessType()) {
				log.info("Setting VPN as enterpriseId");
				location.setVpnName(location.getEnterpriseId());
			}
			TableOrderDetailsParam sbcProvMethod = getTableOrderDetailsParam(entityBatch,"SbcProvMethod");
			if (sbcProvMethod != null) {
				if (sbcProvMethod.getParamValue() == null
						|| sbcProvMethod.getParamValue().equals("IASA"))
					location.setSbcProvMethod(VzbVoipEnum.SbcProvMethodType.IASA);
				else
					location.setSbcProvMethod(VzbVoipEnum.SbcProvMethodType.ESAP);
			}

			TableOrderDetailsParam expedite = getTableOrderDetailsParam(entityBatch,"Expedite");
			if (expedite != null) {
				if (expedite.getParamValue() != null
						&& "Y".equals(expedite.getParamValue())) {
					location.setExpedite(VzbVoipEnum.YesNoType.Y);
				} else {
					location.setExpedite(VzbVoipEnum.YesNoType.N);
				}
			}

			TableOrderDetailsParam highVolume = getTableOrderDetailsParam(entityBatch,"HighVolume");
			if (highVolume != null) {
				if (highVolume.getParamValue() != null
						&& "Y".equals(highVolume.getParamValue())) {
					location.setHighVolumeInstallFlag(VzbVoipEnum.YesNoType.Y);
				} else {
					location.setHighVolumeInstallFlag(VzbVoipEnum.YesNoType.N);
				}
			}

			TableOrderDetailsParam afterHourInstallFee = getTableOrderDetailsParam(entityBatch,"AfterHourInstallFee");
			if (afterHourInstallFee != null) {
				if (afterHourInstallFee.getParamValue() != null
						&& "Y".equals(afterHourInstallFee.getParamValue())) {
					location.setAfterHoursInstallFlag(VzbVoipEnum.YesNoType.Y);
				} else {
					location.setAfterHoursInstallFlag(VzbVoipEnum.YesNoType.N);
				}
			}

			log.info("Expedite : {}" , location.getExpedite());
			log.info("HighVolume : {}" , location.getHighVolumeInstallFlag());
			log.info(
					"AfterHourInstallFee {}"
							, location.getAfterHoursInstallFlag());

			insertOrderLog("Expedite : {}" + location.getExpedite() + ">");
			insertOrderLog("HighVolume <"
					+ location.getHighVolumeInstallFlag() + ">");
			insertOrderLog("AfterHourInstallFee <"
					+ location.getAfterHoursInstallFlag() + ">");

			TableOrderDetailsParam locationCclIndicator = getTableOrderDetailsParam(entityBatch,"LocationCclIndicator");
			if (locationCclIndicator != null) {
				if (locationCclIndicator.getParamValue() != null) {
					location.setLocCclInd(VzbVoipEnum.YesNoType
							.valueByAcronym(locationCclIndicator.getParamValue()));
				}
			}

			//System.out
			log.info(" LocationCclIndicator in Add Location Action Function {}"
							, location.getLocCclInd());

			TableOrderDetailsParam billingActivated = getTableOrderDetailsParam(entityBatch,"BillingActivated");
			if (billingActivated != null) {
				//System.out
				log.info("Billing_Activated is present on the oder null");
				if (billingActivated.getParamValue() != null) {
					log.info("Billing_Activated value is = {}"
							, VzbVoipEnum.YesNoType.valueByAcronym(billingActivated.getParamValue()));
					location.setBillingActivated(VzbVoipEnum.YesNoType
							.valueByAcronym(billingActivated.getParamValue()));
				}
				if ("Y".equals(getParamValueWithAction(entityBatch,
						"BillingActivated", "n"))) {
					log.info("Billing is Y and action n");
					location.setActiveDate(new Timestamp(System
							.currentTimeMillis()));
				}
			}
			//System.out
			log.info(" BillingActivated in Add Location Action Function {}"
							, location.getBillingActivated());

			// CallingNameInd changes
			TableOrderDetailsParam callingNameInd = getTableOrderDetailsParam(entityBatch,"CallingNameInd");
			if (callingNameInd != null) {
				if (callingNameInd.getParamValue() != null) {
					location.setCallingNameInd(VzbVoipEnum.YesNoType
							.valueByAcronym(callingNameInd.getParamValue()));
				}
			}
			//System.out
			log.info(" CallingNameInd in Add Location Action Function {}"
							, location.getCallingNameInd());

			TableOrderDetailsParam enhancedANIInd = getTableOrderDetailsParam(entityBatch,"EnhancedANIInd");
			if (enhancedANIInd != null) {
				if (enhancedANIInd.getParamValue() != null) {
					location.setEnhancedAniInd(VzbVoipEnum.YesNoType
							.valueByAcronym(enhancedANIInd.getParamValue()));
				}
			}
			//System.out
			log.info(" EnhancedANIInd in Add Location Action Function {}"
							, location.getEnhancedAniInd());

			// STN Code here
			// Search the STN in the root level Only. Use GetByName to get the
			// STN from RootLevel.
			// For Remote, it will be in root level and for Remote, STN will be
			// in CPEGATEWAYDEVICE level
			TableOrderDetailsParam STN = getTableOrderDetailsParam(entityBatch,"STN");
			if (STN != null) {
				if (STN.getParamValue() != null) {
					location.setSTn(STN.getParamValue());
				}
			}

			log.info(" STN in Add Location Action Function {}"
					, location.getSTn());
			// 53938.AA Business Continuity Ph 1 - changes for july 2011
			TableOrderDetailsParam VARRS = getTableOrderDetailsParam(entityBatch,"VARRS");
			if (VARRS != null && VARRS.getParamValue() != null) {

				location.setVarrsFlag(VARRS.getParamValue());
			}
			TableOrderDetailsParam designId = getTableOrderDetailsParam(entityBatch,"DesignId");
			if (designId != null
					&& designId.getParamValue() != null) {
				location.setIsrDesignId(Long.parseLong(designId.getParamValue()));
			}

			// Jan 2011 Release Changes

			TableOrderDetailsParam region_param = getTableOrderDetailsParam(entityBatch,"Region");
			if (region_param != null && region_param.getParamValue() != null) {
				location.setLocRegion(region_param.getParamValue());
			}
			log.info(" Region in Add Location Action Function {}"
					, location.getLocRegion());

			if (VzbVoipEnum.RegionType.name(VzbVoipEnum.RegionType.APAC)
					.equals(location.getLocRegion())) {
				TableOrderDetailsParam PBBAN = getTableOrderDetailsParam(entityBatch,"PBBAN");
				if (PBBAN != null) {
					if (PBBAN.getParamValue() != null) {
						location.setBillAccountNumber(PBBAN.getParamValue());
					}
					//System.out
					log.info(" PBBAN in Add Location Action Function {}"
									, location.getBillAccountNumber());
				}

			} else {
				TableOrderDetailsParam billAcctNum = getTableOrderDetailsParam(entityBatch,"BillAcctNum");
				if (billAcctNum != null) {
					if (billAcctNum.getParamValue() != null) {
						location.setBillAccountNumber(billAcctNum.getParamValue());
					}
					//System.out
					log.info(" BillAcctNum in Add Location Action Function {}"
									, location.getBillAccountNumber());
				}
			}

			location.setConfigAllowed(1);
			
			// SEP Changes.. 2CLI AlternativeCallerId default value for new RIV
			// locations.. Start
			String region = null;
			int nRegion = 0;
			if (region_param == null) {
				throw new Exception("REGION not found in orderParam");
			} else {
				region = region_param.getParamValue();
				nRegion = VzbVoipEnum.RegionType.valueByAcronym(region);
			}

			if (nRegion == VzbVoipEnum.RegionType.EMEA) {
				TableOrderDetailsParam alternativeCallerIdFlag = getTableOrderDetailsParam(entityBatch,"AlternativeCallerIdFlag");
				if (alternativeCallerIdFlag != null && alternativeCallerIdFlag.getParamValue() != null) {
					String alternativeCallerIdInd = Integer
							.toString(VzbVoipEnum.AlternativeCallerId
									.valueByAcronym(alternativeCallerIdFlag.getParamValue()));
					location.setAlternativeCallerIdInd(Short
							.parseShort(alternativeCallerIdInd));
				} else {
					String emeaAlternativeCallerIdInd = getConfigParamValue(
							"RIV_INV", "EmeaAlternativeCallerIdInd");
					if (emeaAlternativeCallerIdInd.equals(""))
						emeaAlternativeCallerIdInd = Integer
								.toString(VzbVoipEnum.AlternativeCallerId.NOTIMPLEMENTED);
					location.setAlternativeCallerIdInd(Short
							.parseShort(emeaAlternativeCallerIdInd));
					insertOrderLog("Task - AlternativeCallerId successfully set to "
									+ emeaAlternativeCallerIdInd + " .");
				}
			}

			else
				location.setAlternativeCallerIdInd((short) VzbVoipEnum.AlternativeCallerId.NOTIMPLEMENTED);

			// SEP Changes.. 2CLI AlternativeCallerId default value for new RIV
			// locations.. End

			TableOrderDetailsParam territory = getTableOrderDetailsParam(entityBatch,"Territory");
			if (territory != null) {
				if (territory.getParamValue() != null) {
					location.setLocTerritory(territory.getParamValue());
				}
			}
			log.info(" LocTerritory in Add Location Action Function {}"
					, location.getLocTerritory());

			TableOrderDetailsParam billingSystem = getTableOrderDetailsParam(entityBatch,"BillingSystem");
			if (billingSystem != null && billingSystem.getParamValue() != null) {
				location.setBillingSystem(VzbVoipEnum.BillingSystemType
						.valueByAcronym(billingSystem.getParamValue()));
			}
			//System.out
			log.info(" BillingSystem in Add Location Action Function {}"
							, location.getBillingSystem());

			log.info("VMA  LIST  SIZE : {}" , vmAccessList.size());
			location.setVmAccessList(vmAccessList);

			location.setLocationFeatures(getLocationFeatures(entityBatch,"n",connection));
			// IR #1353335 addLocationFeaturesToLocation Called in addtoDB
			// method of Location class. So Commented here


			/*** Z562196 Code Start ****/
			insertOrderLog("Adding Account Auth codes to DB");
			log.info("Adding Account Auth codes to DB ");
			//Vector authParamList = orderParam.getParams();
			
			List<AcctAuthCodesBean> authCodesList = new ArrayList<AcctAuthCodesBean>();
			if (null!=getTableOrderDetailsParam(entityBatch,"AccountAuthCode")) {// 
				List<TableOrderDetailsParam> todList2 = searchParamListNew(entityBatch,"AccountAuthCode");
				for (TableOrderDetailsParam tod2 : todList2) {
					if (tod2.getParamName().equals("AccountAuthCode")) {
						AcctAuthCodes acctAuthCodessObj = new AcctAuthCodes(
								connection);
						if (!(locationId == null))
							acctAuthCodessObj.setStrLocationId(locationId);
						acctAuthCodessObj.setStrCreatedBy("ESAP_INV");
						acctAuthCodessObj.setStrModifiedBy("ESAP_INV");
						//Vector paramListNode = pd.getParams();
						List<TableOrderDetailsParam> childTodList2 = tod2.getParamDetail();
						for (TableOrderDetailsParam childTod2: childTodList2) {

							if (childTod2.getParamName().equals("Code")){
								if(childTod2.getParamValue() != null)
									acctAuthCodessObj.setStrAcctAuthCode(childTod2.getParamValue());
							}
								

							if (childTod2.getParamName().equals("Desc")){
								if(childTod2.getParamValue() != null)
									acctAuthCodessObj.setStrAcctAuthDesc(childTod2.getParamValue());
							}

							if (childTod2.getParamName().equals("Type")){
								if(childTod2.getParamValue() != null)
									acctAuthCodessObj.setLongCodeType(Long
										.valueOf(VzbVoipEnum.AcctAuthCodeType
												.valueByAcronym(childTod2.getParamValue())));
							}
						}

						authCodesList.add(acctAuthCodessObj);
					}
				}
			}

			location.setAuthCodesList(authCodesList);
			location.setSbcInd(VzbVoipEnum.YesNoType.Y);
			/*** Z562196 Code End ****/

			/*****************************/
			/**
			 * Inserts Location INserts Vm Access Inserts Dial Plan Inserts Sip
			 * Domain Inserts Package Query
			 * 
			 */

			List<TableOrderDetailsParam> pricingInfoList = searchParamListNew(entityBatch,"PricingInfo");
			List<TblEntBillFeaturesBean> billFeaturesList = new ArrayList<TblEntBillFeaturesBean>();
			for (TableOrderDetailsParam tmp : pricingInfoList) {
				TblEntBillFeaturesBean tblEntBillFeaturesBean = new TblEntBillFeaturesBean();

				/*****************
				 * New TOD Fields for TBL_ENT_BILL_FEATURES Information
				 * available on order will be set here
				 ******/
				/*********** ORDERING fields starts here ****/

				TableOrderDetailsParam featureInstanceId = getTableOrderDetailsParamByName(tmp, "FeatureInstanceId");
				if (featureInstanceId != null && featureInstanceId.getParamValue() != null)
					tblEntBillFeaturesBean.setFeatureInstanceId(Long
							.parseLong(featureInstanceId.getParamValue()));

				if (locationId != null)
					tblEntBillFeaturesBean.setLocationId(locationId);

				if (customerId != null && customerId.getParamValue() != null)
					tblEntBillFeaturesBean.setEnterpriseId(customerId.getParamValue());

				TableOrderDetailsParam featureCode = getTableOrderDetailsParamByName(tmp, "FeatureCode");
				if (featureCode != null && featureCode.getParamValue() != null)
					tblEntBillFeaturesBean.setFeatureCode(featureCode.getParamValue());

				TableOrderDetailsParam PBLI = getTableOrderDetailsParamByName(tmp, "PBLI");
				if (PBLI != null && PBLI.getParamValue() != null)
					tblEntBillFeaturesBean.setPbli(PBLI.getParamValue());

				TableOrderDetailsParam chargeType = getTableOrderDetailsParamByName(tmp, "ChargeType");
				if (chargeType != null && chargeType.getParamValue() != null)
					tblEntBillFeaturesBean.setChargeType(chargeType.getParamValue());

				TableOrderDetailsParam chargeFrequency = getTableOrderDetailsParamByName(tmp, "ChargeFrequency");
				if (chargeFrequency != null && chargeFrequency.getParamValue() != null)
					tblEntBillFeaturesBean
							.setChargeFrequency(chargeFrequency.getParamValue());

				TableOrderDetailsParam unitOfMeasure = getTableOrderDetailsParamByName(tmp, "UnitOfMeasure");
				if (unitOfMeasure != null && unitOfMeasure.getParamValue() != null)
					tblEntBillFeaturesBean.setUnitOfMeasure(unitOfMeasure.getParamValue());

				TableOrderDetailsParam billTime = getTableOrderDetailsParamByName(tmp, "BillTime");
				if (billTime != null && billTime.getParamValue() != null)
					tblEntBillFeaturesBean.setBillTime(billTime.getParamValue());
				
				TableOrderDetailsParam catalogueReferenceTime = getTableOrderDetailsParamByName(tmp, "CatalogueReferenceTime");
				if (catalogueReferenceTime != null && catalogueReferenceTime.getParamValue() != null){
					 Timestamp ts = Timestamp.valueOf(catalogueReferenceTime.getParamValue());
					 tblEntBillFeaturesBean.setCatalogueReferenceTime(ts);
				}
				
				TableOrderDetailsParam servicePlan = getTableOrderDetailsParamByName(tmp, "ServicePlan");
				if (servicePlan != null && servicePlan.getParamValue() != null){
                    tblEntBillFeaturesBean.setFeatureType( VzbVoipEnum.ServiceLevel.valueByAcronym(servicePlan.getParamValue()));
            }
				billFeaturesList.add(tblEntBillFeaturesBean);

			}

			if (billFeaturesList.size() > 0) {
				location.setEntBillFeatBeanList(billFeaturesList);
			}
			//Adding Address_Id as part of ECM
			TableOrderDetailsParam addressId = getTableOrderDetailsParam(entityBatch,"AddressId");
			if(addressId != null && addressId.getParamValue() != null){
				location.setAddressId(addressId.getParamValue());
			}
			
			// Added as part of VCE changes
			TableOrderDetailsParam VCE = getTableOrderDetailsParam(entityBatch,"VCE");
			if(VCE != null && VCE.getParamValue() != null){
				location.setVce(VCE.getParamValue());
			}

			insertOrderLog("Adding Location to inventory ");
			log.info("Adding Location to inventory LocationName :{}",location.getLocationName());
			if (location.addToDB()) {
				insertOrderLog(location.getLogTrail());
				insertOrderLog("Successfuly added Location in ESAP inventory");
			} else {
				insertOrderLog(location.getLogTrail());
				insertOrderLog("Inventory Base Returned Error :: {}"
						+ location.getStatusDesc() + "::");
				log.info(
						"Inventory Base Returned Error : {}"
								, location.getStatusDesc());
				connection.rollback();
				throw new VzbInvException("ESP_VZB_INV_ADD_LOCATION_FAILED",
						"ESP_VZB_INV_ADD_LOCATION_FAILED");

			}

			if (location.getRivLocation() != VzbVoipEnum.YesNoType.N) {
				insertOrderLog("Adding Termination Routing ");
				/*** Adding Tbl_termination Filed START *****/
				PublicTnPoolBean publicTnPoolObj = new PublicTnPoolBean();
				TblLocationDbBean locationDbBean = getLocationForLocationId(location
						.getLocationId());
				publicTnPoolObj.setDialPlanId(locationDbBean.getDialPlanId());
				publicTnPoolObj.setPtrid("");
				publicTnPoolObj.setPprefixdgts("");
				publicTnPoolObj.setA1trid("");
				publicTnPoolObj.setA1prefixdgts("");
				publicTnPoolObj.setA2url("");
				publicTnPoolObj.setA2ringtime("");
				publicTnPoolObj.setA2trid("");
				publicTnPoolObj.setA2prefixdgts("");
				publicTnPoolObj.setNoa(1);
				publicTnPoolObj.setPringtime("252");
				publicTnPoolObj.setPsuffixnum(32);
				publicTnPoolObj.setA1ringtime("252");
				publicTnPoolObj.setA1suffixnum(32);
				DBTblVzbStateGatewayMap gatewayMap = new DBTblVzbStateGatewayMap();
				if (location.getLocCountry() != null
						&& !location.getLocCountry().equals("US")
						&& !location.getLocCountry().equals("USA")
						&& !location.getLocCountry().equals("CA")) {
					if (getRegion(location.getLocationId()) == VzbVoipEnum.RegionType.APAC) {
						gatewayMap = getVzbGatewayId(location.getLocCountry(),
								VzbVoipEnum.RegionType
										.name(VzbVoipEnum.RegionType.APAC),
								locationDbBean.getEnterpriseId());
					} else {
						gatewayMap = getVzbGatewayId(location.getLocCountry(),
								VzbVoipEnum.RegionType
										.name(VzbVoipEnum.RegionType.EMEA),
								locationDbBean.getEnterpriseId());
					}
				} else {
					gatewayMap = getVzbGatewayId(location.getLocState(),
							VzbVoipEnum.RegionType
									.name(VzbVoipEnum.RegionType.US),
							locationDbBean.getEnterpriseId());
				}

				publicTnPoolObj.setP1url(gatewayMap.getPrimaryGatewayid());
				publicTnPoolObj.setA1url(gatewayMap.getSecondaryGatewayid());
				publicTnPoolObj.setEnvOrderId(location.getEnvOrderId());
				publicTnPoolObj.setCreatedBy(location.getCreatedBy());
				publicTnPoolObj.setModifiedBy(location.getModifiedBy());
				publicTnPoolObj.setLastModifiedDate(new Timestamp(System
						.currentTimeMillis()));
				publicTnPoolObj.setCreationDate(new Timestamp(System
						.currentTimeMillis()));

				if (location.getBillTn() != null
						&& !(location.getBillTn().trim()).equalsIgnoreCase("")
						&& !(location.getBillTn().trim())
								.equalsIgnoreCase("NONE")) {
					PublicTnPool pubTnBeanObj = new PublicTnPool(connection,
							publicTnPoolObj);
					pubTnBeanObj.setRangeStart(location.getBillTn());
					pubTnBeanObj.setRangeEnd(location.getBillTn());
					mergeTerminatingRouting(pubTnBeanObj);
					//System.out
							log.info("mergtermROuting is successful ::: Billing Tn/EmergencyCallLine Tn : {}"
									, location.getBillTn());

				}
				if (location.getRpidTn() != null
						&& !(location.getRpidTn().trim()).equalsIgnoreCase("")
						&& !(location.getRpidTn().trim())
								.equalsIgnoreCase("NONE")) {
					PublicTnPool pubTnBeanObj = new PublicTnPool(connection,
							publicTnPoolObj);
					pubTnBeanObj.setRangeStart(location.getRpidTn());
					pubTnBeanObj.setRangeEnd(location.getRpidTn());
					mergeTerminatingRouting(pubTnBeanObj);
					//System.out
					log.info("mergtermROuting is successful::: Calling Party Tn : {}"
									, location.getRpidTn());

				}
				// STN Code here
				log.info("Location Service Level : {}"
						, location.getServiceLevel());
				if (location.getSTn() != null
						&& !(location.getSTn().trim()).equalsIgnoreCase("")
						&& !(location.getSTn().trim()).equalsIgnoreCase("NONE")
						&& location.getServiceLevel() != VzbVoipEnum.ServiceLevel.LD_AND_ON_NET) {
					PublicTnPool pubTnBeanObj = new PublicTnPool(connection,
							publicTnPoolObj);
					pubTnBeanObj.setRangeStart(location.getSTn());
					pubTnBeanObj.setRangeEnd(location.getSTn());
					mergeTerminatingRouting(pubTnBeanObj);
					//System.out
					log.info("mergtermROuting is successful::: Screened Tn : {}"
									, location.getSTn());
				}

				insertOrderLog("Adding Termination Routing to VmAccess");
				log.info("Adding Termination Routing to VmAccess");
				if (!vmAccessList.isEmpty()) {
					for (int _i = 0; _i < vmAccessList.size(); _i++) {
						VmAccessBean _vma = vmAccessList.get(_i);
						if (_vma.getPublicNumber() != null
								&& !(_vma.getPublicNumber().trim())
										.equalsIgnoreCase("")
								&& !(_vma.getPublicNumber().trim())
										.equals("NONE")) {
							PublicTnPool pubTnBeanObj = new PublicTnPool(
									connection, publicTnPoolObj);
							pubTnBeanObj.setRangeStart(_vma.getPublicNumber());
							pubTnBeanObj.setRangeEnd(_vma.getPublicNumber());
							mergeTerminatingRouting(pubTnBeanObj);
							//System.out
							log.info("mergtermROuting is successful::: VMA Tn::  {}"
											, _vma.getPublicNumber());
						}

					}
				}
				/*** Adding Tbl_termination Filed END *****/
			}

			// sep 2011 P360 changes start

			String locationId1 = ""; // TODO Need to discuss with Deepak Kumar
			String typeOfLocation = "";

			if (locationId != null)
				locationId1 = locationId;

			if (typeOfLoc != null)
				typeOfLocation = typeOfLoc.getParamValue();

			log.info(" locationId1 and  typeOfLocation values are .... {} ,{}"
					, locationId1 , typeOfLocation);

			if ((locationId1 != null && locationId1.length() != 0)
					&& (typeOfLocation != null && typeOfLocation.length() != 0)) {
				log.info(" Calling circuitIdAndVpnNameUpdateForRemoteAndHubLocations() ....  ");

				if (!circuitIdAndVpnNameUpdateForRemoteAndHubLocations(
						entityBatch,"LOCATION", locationId1, typeOfLocation,connection)) {
					throw new Exception();
				}
			}
			
			boolean isRivCustomer = false;

			if (rIVCustomer != null
					&& "Y".equals(rIVCustomer.getParamValue())) {
				isRivCustomer = true;
			}

		
			String LocationReferenceId = "";
			String NewLocationId = "";
			String OldLocationId = "";
			TableOrderDetailsParam location_ReferenceId = getTableOrderDetailsParam(entityBatch,"LocationReferenceId");
			if (location_ReferenceId != null) {
				LocationReferenceId = location_ReferenceId.getParamValue();
			}
			
			TableOrderDetailsParam New_LocationId = getTableOrderDetailsParam(entityBatch,"NewLocationId");
			if (New_LocationId != null) {
				NewLocationId = New_LocationId.getParamValue();
			}
			
			TableOrderDetailsParam Old_LocationId = getTableOrderDetailsParam(entityBatch,"OldLocationId");
			if (Old_LocationId != null) {
				OldLocationId = Old_LocationId.getParamValue();
			}

			if (NewLocationId != null) {
				if (!location.updateTsoVampEntityMigForLoc(NewLocationId,
						OldLocationId, LocationReferenceId)) {
					log.info("Unable to update Tso_location_id in tbl_vamp_entity_reference ");
					throw new VzbInvException(
							"ESP_VZB_INV_ADD_LOCATION_FAILED",
							"updateTsoVampEntityMigForLoc() failed");
				}
				if (!location.updateTblTsoEntityMigForLoc(NewLocationId,
						OldLocationId)) {
					log.info("Unable to update Tso_location_id in tbl_tso_entity_migration ");
					throw new VzbInvException(
							"ESP_VZB_INV_ADD_LOCATION_FAILED",
							"updateTblTsoEntityMigForLoc() failed");
				}
			}
			
			if (isRivCustomer) {
				log.info(" **** RIVCustomer ****");
				String cktId = null;

				cktId = getParamValueWithAction(entityBatch, "CircuitId",  "n");
				if (cktId != null && cktId.equals("")) {
					log.info(" **** circuit Id change **** {}"
							, cktId);
					location.updateTblLocationwithCktId(
							location.getLocationId(), cktId);

				}
			}
			
			
			// At the end commit transactions
			connection.commit();
		} catch (VzbInvException e) {
			log.error("VzbInvException occurred while Adding Location ", e.getMessage());
			e.printStackTrace();
			try {
				connection.rollback();
			} catch (Exception e1) {
				log.error("Exception occurred while rollback connection ", e1.getMessage());
			}
			
			logFinalMessage = e.getMessage();
			logSucessFail = false;
			handleActionFunctionError(e.getMessage(), e.getMessage());
			return INV_FAILURE;
		} catch (SQLException e) {
			log.error(" SQL Exception occurred while Adding Location ", e.getMessage());
			e.printStackTrace();
			try {
				connection.rollback();
			} catch (Exception e1) {
				log.error("Exception occurred while rollback connection ", e1.getMessage());
			}
			logFinalMessage = e.getMessage();
			logSucessFail = false;
			log.error("In VZB_INV_ADD_LOC e.getErrorCode(): {}"
					, e.getErrorCode());
			if (e.getErrorCode() == -60)
				handleActionFunctionError("ESP_VZB_INV_DEADLOCK",
						e.getMessage());
			else
				handleActionFunctionError("ESP_VZB_INV_ADD_LOC_FAILED",
						e.getMessage());
			return INV_FAILURE;
		}

		catch (Exception e) {
			log.error("Exception occurred while ADD Location ",e.getMessage());
			e.printStackTrace();
			try {
				connection.rollback();
			} catch (Exception e1) {
				log.error("Exception occurred while rollback connection ", e1.getMessage());
			}
			// insertOrderLog(LOG_TYPE_FAIL,e.getMessage());
			logFinalMessage = e.getMessage();
			logSucessFail = false;
			handleActionFunctionError("VZB_INV_ADD_LOCATION_FAILED",
					e.getMessage());
			// handleActionFunctionError(e.getMessage(), e.getMessage());
			return INV_FAILURE;
		} finally {
			addLogMessageToDb();
			if (logSucessFail)
				insertOrderLog("Task - VZB_INV_ADD_LOCATION  completed successfully");
			else
				insertOrderLogError(logFinalMessage);
		}

		return INV_SUCCESS;
	}

}
