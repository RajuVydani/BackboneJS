package com.vz.fxo.inventory.actionfunction.support;

public class PublicTnPoolBean {
   //members

   protected int tnPoolId;
   protected String locationId;
   protected String departmentId;
   protected String tn;
   protected long envOrderId;
   protected long tnStatus;
   protected long tnType;
   protected String portedStatus;
   protected long npaSplitStatus;
   protected int terminatingRoutingId;
   protected long dialPlanId;
   protected long noa;
   protected String rangeStart;
   protected String rangeEnd;
   protected String p1url;
   protected String pringtime;
   protected String ptrid;
   protected String pprefixdgts;
   protected long psuffixnum;
   protected String a1url;
   protected String a1ringtime;
   protected String a1trid;
   protected String a1prefixdgts;
   protected long a1suffixnum;
   protected String a2url;
   protected String a2ringtime;
   protected String a2trid;
   protected String a2prefixdgts;
   protected long a2suffixnum;
   protected String switchClli;
   protected String trunk;
   protected long activeInd;
   protected long tnOnOff;
   protected String createdBy;
   protected String modifiedBy;
   protected java.sql.Timestamp creationDate;
   protected java.sql.Timestamp lastModifiedDate;
   protected boolean getAll;
   protected long stnInd;
   protected long actDeact;
   protected long liInd;
   protected long pubip;
   protected long bsTnAct;
   protected long custMarket;
   protected short portinType; //Added for aus porting - june2011
   protected String tspCode;
   protected String replacementCli;
   protected short transitionType;
   protected String psAli;
   protected long CnamUpdateStatus;
   protected java.sql.Timestamp CnamUpdateDate;
   protected String verizonBtn;
   protected long pubipIn;
   protected long pubipOut;
   /**
    * Default Constructor -- Initializes all fields to default values.
    */
   public PublicTnPoolBean() {
      this.tnPoolId = 0;
      this.locationId = "";
      this.departmentId = "NONE";
      this.tn = "";
      this.activeInd = -1;
      this.tnOnOff = -1;
      this.envOrderId = -1;
      this.tnStatus = 0;
      this.tnType = -1;
      this.portedStatus = "NONE";
      this.npaSplitStatus = -1;
      this.terminatingRoutingId = 0;
      this.dialPlanId = 0;
      this.noa = -1;
      this.rangeStart = "";
      this.rangeEnd = "NONE";
      this.p1url = "NONE";
      this.pringtime = "NONE";
      this.ptrid = "NONE";
      this.pprefixdgts = "NONE";
      this.psuffixnum = -1;
      this.a1url = "NONE";
      this.a1ringtime = "NONE";
      this.a1trid = "NONE";
      this.a1prefixdgts = "NONE";
      this.a1suffixnum = -1;
      this.a2url = "NONE";
      this.a2ringtime = "NONE";
      this.a2trid = "NONE";
      this.a2prefixdgts = "NONE";
      this.a2suffixnum = -1;
      this.createdBy = "";
      this.modifiedBy = "";
      this.getAll = false;
      this.stnInd = 0;
      this.actDeact = 0;
      this.liInd = -1;
      this.pubip = -1;
      this.bsTnAct = -1;
      this.custMarket = -1;
      this.portinType = 0;
      this.tspCode = "";
      this.switchClli = "";
      this.trunk = "";
      this.replacementCli = "";
      this.transitionType = 0;
      this.psAli = "";
      this.CnamUpdateStatus = -1;
      this.CnamUpdateDate = null;
      this.verizonBtn = "";
      this.pubipIn = 2;
      this.pubipOut = 2;
   }

   /**
    * Constructor
    *
    * @param poolBean
    */
   public PublicTnPoolBean(PublicTnPoolBean poolBean) {
      this.tnPoolId = poolBean.tnPoolId;
      this.locationId = poolBean.locationId;
      this.departmentId = poolBean.departmentId;
      this.tn = poolBean.tn;
      this.envOrderId = poolBean.envOrderId;
      this.tnStatus = poolBean.tnStatus;
      this.tnType = poolBean.tnType;
      this.portedStatus = poolBean.portedStatus;
      this.npaSplitStatus = poolBean.npaSplitStatus;
      this.terminatingRoutingId = poolBean.terminatingRoutingId;
      this.dialPlanId = poolBean.dialPlanId;
      this.noa = poolBean.noa;
      this.rangeStart = poolBean.rangeStart;
      this.rangeEnd = poolBean.rangeEnd;
      this.p1url = poolBean.p1url;
      this.pringtime = poolBean.pringtime;
      this.ptrid = poolBean.ptrid;
      this.pprefixdgts = poolBean.pprefixdgts;
      this.psuffixnum = poolBean.psuffixnum;
      this.a1url = poolBean.a1url;
      this.a1ringtime = poolBean.a1ringtime;
      this.a1trid = poolBean.a1trid;
      this.a1prefixdgts = poolBean.a1prefixdgts;
      this.a1suffixnum = poolBean.a1suffixnum;
      this.a2url = poolBean.a2url;
      this.a2ringtime = poolBean.a2ringtime;
      this.a2trid = poolBean.a2trid;
      this.a2prefixdgts = poolBean.a2prefixdgts;
      this.a2suffixnum = poolBean.a2suffixnum;
      this.activeInd = poolBean.activeInd;
      this.tnOnOff = poolBean.tnOnOff;
      this.createdBy = poolBean.createdBy;
      this.modifiedBy = poolBean.modifiedBy;
      this.creationDate = poolBean.creationDate;
      this.lastModifiedDate = poolBean.lastModifiedDate;
      this.getAll = poolBean.getAll;
      this.stnInd = poolBean.stnInd;
      this.actDeact = poolBean.actDeact;
      this.liInd = poolBean.liInd;
      this.pubip = poolBean.pubip;
      this.bsTnAct = poolBean.bsTnAct;
      this.custMarket = poolBean.custMarket;
      this.portinType = poolBean.portinType;
      this.tspCode = poolBean.tspCode;
      this.switchClli = poolBean.switchClli;
      this.trunk = poolBean.trunk;
      this.replacementCli = poolBean.replacementCli;
      this.transitionType = poolBean.transitionType;
      this.psAli = poolBean.psAli;
      this.CnamUpdateStatus = poolBean.CnamUpdateStatus;
      this.CnamUpdateDate = poolBean.CnamUpdateDate;
      this.verizonBtn = poolBean.verizonBtn;
      this.pubipIn = poolBean.pubipIn;
      this.pubipOut = poolBean.pubipOut;
   }

   public long getActiveInd() {
      return activeInd;
   }

   public void setActiveInd(long activeInd) {
      this.activeInd = activeInd;
   }

   public long getTnOnOff() {
      return tnOnOff;
   }

   public void setTnOnOff(long tnOnOff) {
      this.tnOnOff = tnOnOff;
   }

   public java.sql.Timestamp getCreationDate() {
      return creationDate;
   }

   public void setCreationDate(java.sql.Timestamp creationDate) {
      this.creationDate = creationDate;
   }

   public java.sql.Timestamp getLastModifiedDate() {
      return lastModifiedDate;
   }

   public void setLastModifiedDate(java.sql.Timestamp lastModifiedDate) {
      this.lastModifiedDate = lastModifiedDate;
   }

   public int getTerminatingRoutingId() {
      return terminatingRoutingId;
   }

   public void setTerminatingRoutingId(int terminatingRoutingId) {
      this.terminatingRoutingId = terminatingRoutingId;
   }

   public long getDialPlanId() {
      return dialPlanId;
   }

   public void setDialPlanId(long dialPlanId) {
      this.dialPlanId = dialPlanId;
   }

   public long getNoa() {
      return noa;
   }

   public void setNoa(long noa) {
      this.noa = noa;
   }

   public String getRangeStart() {
      return rangeStart;
   }

   public void setRangeStart(String rangeStart) {
      this.rangeStart = rangeStart;
   }

   public String getRangeEnd() {
      return rangeEnd;
   }

   public void setRangeEnd(String rangeEnd) {
      this.rangeEnd = rangeEnd;
   }

   public String getP1url() {
      return p1url;
   }

   public void setP1url(String p1url) {
      this.p1url = p1url;
   }

   public String getPringtime() {
      return pringtime;
   }

   public void setPringtime(String pringtime) {
      this.pringtime = pringtime;
   }

   public String getPtrid() {
      return ptrid;
   }

   public void setPtrid(String ptrid) {
      this.ptrid = ptrid;
   }

   public String getPprefixdgts() {
      return pprefixdgts;
   }

   public void setPprefixdgts(String pprefixdgts) {
      this.pprefixdgts = pprefixdgts;
   }

   public long getPsuffixnum() {
      return psuffixnum;
   }

   public void setPsuffixnum(long psuffixnum) {
      this.psuffixnum = psuffixnum;
   }

   public String getA1url() {
      return a1url;
   }

   public void setA1url(String a1url) {
      this.a1url = a1url;
   }

   public String getA1ringtime() {
      return a1ringtime;
   }

   public void setA1ringtime(String a1ringtime) {
      this.a1ringtime = a1ringtime;
   }

   public String getA1trid() {
      return a1trid;
   }

   public void setA1trid(String a1trid) {
      this.a1trid = a1trid;
   }

   public String getA1prefixdgts() {
      return a1prefixdgts;
   }

   public void setA1prefixdgts(String a1prefixdgts) {
      this.a1prefixdgts = a1prefixdgts;
   }

   public long getA1suffixnum() {
      return a1suffixnum;
   }

   public void setA1suffixnum(long a1suffixnum) {
      this.a1suffixnum = a1suffixnum;
   }

   public String getA2url() {
      return a2url;
   }

   public void setA2url(String a2url) {
      this.a2url = a2url;
   }

   public String getA2ringtime() {
      return a2ringtime;
   }

   public void setA2ringtime(String a2ringtime) {
      this.a2ringtime = a2ringtime;
   }

   public String getA2trid() {
      return a2trid;
   }

   public void setA2trid(String a2trid) {
      this.a2trid = a2trid;
   }

   public String getA2prefixdgts() {
      return a2prefixdgts;
   }

   public void setA2prefixdgts(String a2prefixdgts) {
      this.a2prefixdgts = a2prefixdgts;
   }

   public long getA2suffixnum() {
      return a2suffixnum;
   }

   public void setA2suffixnum(long a2suffixnum) {
      this.a2suffixnum = a2suffixnum;
   }

   public int getTnPoolId() {
      return tnPoolId;
   }

   public void setTnPoolId(int tnPoolId) {
      this.tnPoolId = tnPoolId;
   }

   public String getLocationId() {
      return locationId;
   }

   public void setLocationId(String locationId) {
      this.locationId = locationId;
   }

   public String getDepartmentId() {
      return departmentId;
   }

   public void setDepartmentId(String departmentId) {
      this.departmentId = departmentId;
   }

   public String getTn() {
      return tn;
   }

   public void setTn(String tn) {
      this.tn = tn;
   }

   public long getEnvOrderId() {
      return envOrderId;
   }

   public void setEnvOrderId(long envOrderId) {
      this.envOrderId = envOrderId;
   }

   public long getTnStatus() {
      return tnStatus;
   }

   public void setTnStatus(long tnStatus) {
      this.tnStatus = tnStatus;
   }

   public long getTnType() {
      return tnType;
   }

   public void setTnType(long tnType) {
      this.tnType = tnType;
   }

   public String getPortedStatus() {
      return portedStatus;
   }

   public void setPortedStatus(String portedStatus) {
      this.portedStatus = portedStatus;
   }

   public long getNpaSplitStatus() {
      return npaSplitStatus;
   }

   public void setNpaSplitStatus(long npaSplitStatus) {
      this.npaSplitStatus = npaSplitStatus;
   }

   public String getCreatedBy() {
      return createdBy;
   }

   public void setCreatedBy(String createdBy) {
      this.createdBy = createdBy;
   }

   public String getModifiedBy() {
      return modifiedBy;
   }

   public void setModifiedBy(String modifiedBy) {
      this.modifiedBy = modifiedBy;
   }

   public String getSwitchClli() {
      return switchClli;
   }

   public void setSwitchClli(String switchClli) {
      this.switchClli = switchClli;
   }

   public String getTrunk() {
      return trunk;
   }

   public void setTrunk(String trunk) {
      this.trunk = trunk;
   }

   public boolean getGetAll() {
      return getAll;
   }

   public void setGetAll(boolean getAll) {
      this.getAll = getAll;
   }

   public long getStnInd() {
      return stnInd;
   }

   public void setStnInd(long stnInd) {
      this.stnInd = stnInd;
   }

   public long getActDeact() {
      return actDeact;
   }

   public void setActDeact(long actDeact) {
      this.actDeact = actDeact;
   }

   public long getLiInd() {
      return liInd;
   }

   public void setLiInd(long liInd) {
      this.liInd = liInd;
   }

   public long getPubip() {
      return pubip;
   }

   public void setPubip(long pubip) {
      this.pubip = pubip;
   }

   public long getBsTnAct() {
      return bsTnAct;
   }

   public void setBsTnAct(long bsTnAct) {
      this.bsTnAct = bsTnAct;
   }

   public long getCustMarket() {
      return custMarket;
   }

   public void setCustMarket(long custMarket) {
      this.custMarket = custMarket;
   }

   //Added for aus porting - june2011
   /**
    * @return the portinType
    */
   public short getPortinType() {
      return portinType;
   }

   /**
    * @param portinType the portinType to set
    */
   public void setPortinType(short portinType) {
      this.portinType = portinType;
   }

   //Jan 2013 Release E2EI
   public String getTspCode() {
      return tspCode;
   }

   public void setTspCode(String tspCode) {
      this.tspCode = tspCode;
   }

   /**
    * @return the replacementCli
    */
   public String getReplacementCli() {
      return replacementCli;
   }

   /**
    * @param replacementCli the replacementCli to set
    */
   public void setReplacementCli(String replacementCli) {
      this.replacementCli = replacementCli;
   }

   public short getTransitionType() {
      return transitionType;
   }

   public void setTransitionType(short transitionType) {
      this.transitionType = transitionType;
   }
   
   public String getPsAli() {
	  return psAli;
   }

   public void setPsAli(String ps_ali) {
	   this.psAli = ps_ali;
   }
   
   public long getCnamUpdateStatus() {
      return CnamUpdateStatus;
   }

   public void setCnamUpdateStatus(long CnamUpdateStatus) {
      this.CnamUpdateStatus = CnamUpdateStatus;
   }
   
   public java.sql.Timestamp getCnamUpdateDate() {
      return CnamUpdateDate;
   }

   public void setCnamUpdateDate(java.sql.Timestamp CnamUpdateDate) {
      this.CnamUpdateDate = CnamUpdateDate;
   }

   public String getVerizonBtn() {
	   return verizonBtn;
   }

   public void setVerizonBtn(String verizonBtn) {
	   this.verizonBtn = verizonBtn;
   }

	public long getPubipIn() {
		return pubipIn;
	}
	
	public void setPubipIn(long pubipIn) {
		this.pubipIn = pubipIn;
	}
	
	public long getPubipOut() {
		return pubipOut;
	}
	
	public void setPubipOut(long pubipOut) {
		this.pubipOut = pubipOut;
	}

public void initilizeTODefault() {
      this.locationId = "";
      this.departmentId = "";
      this.tn = "";
      this.activeInd = 1;
      this.envOrderId = 0;
      this.tnStatus = 0;
      this.tnType = 0;
      this.portedStatus = "";
      this.npaSplitStatus = 0;
      this.terminatingRoutingId = 0;
      this.dialPlanId = 0;
      this.noa = 0;
      this.rangeStart = "";
      this.rangeEnd = "";
      this.p1url = "";
      this.pringtime = "";
      this.ptrid = "";
      this.pprefixdgts = "";
      this.psuffixnum = 0;
      this.a1url = "";
      this.a1ringtime = "";
      this.a1trid = "";
      this.a1prefixdgts = "";
      this.a1suffixnum = 0;
      this.a2url = "";
      this.a2ringtime = "";
      this.a2trid = "";
      this.a2prefixdgts = "";
      this.a2suffixnum = 0;
      this.createdBy = "";
      this.modifiedBy = "";
      this.actDeact = 0;
      this.liInd = -1;
      this.pubip = -1;
      this.portinType = 0; //
      this.tspCode = "";
      this.switchClli = "";
      this.trunk = "";
      this.replacementCli = "";
      this.transitionType = 0;
      this.psAli = "";
      this.CnamUpdateStatus = -1;
      this.CnamUpdateDate = null;
      this.verizonBtn = "";
      this.pubipIn = 2;
      this.pubipOut = 2;
   }
   //
} //EOF