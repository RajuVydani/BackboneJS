package com.vz.fxo.inventory.actionfunction.support;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Timestamp;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import esap.db.DBTblVzbPrefixPlanTplt;
import esap.db.TblVzbPrefixPlanTpltDbBean;
import esap.db.TblVzbPrefixPlanTpltQuery;

public class PrefixPlanTplt extends PrefixPlanTpltBean {

	private static Logger log = LoggerFactory.getLogger(PrefixPlanTplt.class.toString());
	
	Connection dbCon;
	InvErrorCode status = InvErrorCode.INTERNAL_ERROR;

	public int getStatusCode() {
		return status.getErrorCode();
	}

	public void setStatus(InvErrorCode status) {
		this.status = status;
	}

	public String getStatusDesc() {
		return status.getErrorDesc();
	}

	public Connection getDbCon() {
		return dbCon;
	}
	public void setDbCon(Connection dbCon) {
		this.dbCon = dbCon;
	}
	public PrefixPlanTplt(Connection dbCon)
	{
		this.dbCon = dbCon;
	}
	public PrefixPlanTplt(PrefixPlanTpltBean pPTBean, Connection dbCon)
	{
		super(pPTBean);
		this.dbCon = dbCon;
	}
	

	public boolean addPrefixPlanTplt() throws SQLException, Exception
	{
		log.info("Entering addPrefixPlanTplt ");
		try
		{
			DBTblVzbPrefixPlanTplt pptDbBean = new DBTblVzbPrefixPlanTplt();
			pptDbBean.setCntryCode(getCountryCode());
			pptDbBean.setPlatformIndicator(getPlatformIndicator());
			pptDbBean.setPrefixName(getPrefixName());
			pptDbBean.setMobile(getMobile());

			if(getCreatedBy() != null && !getCreatedBy().equals(""))
				pptDbBean.setCreatedBy(getCreatedBy());
			else
				pptDbBean.setCreatedBy("ESAP_INV");

			if(getModifiedBy() != null && !getModifiedBy().equals(""))
				pptDbBean.setModifiedBy(getModifiedBy());
			else
				pptDbBean.setModifiedBy("ESAP_INV");

			pptDbBean.setCreationDate(new Timestamp(System.currentTimeMillis()));
			pptDbBean.setLastModifiedDate(new Timestamp(System.currentTimeMillis()));
			pptDbBean.insertSpecific(dbCon);
		}
		catch(SQLException s)
		{
			log.info("SQL Exception in addPrefixPlanTplt");
			throw s;
		}

		setStatus(InvErrorCode.SUCCESS);
		log.info("Successfully Inserted Prefix Plan Tplt");
		return true;
	}
	
	public boolean deletePrefixPlanTplt()
	{
		log.info("Entering deletePrefixPlanTplt");
		try
		{
			if(getCountryCode() == null || (getCountryCode() != null && !"".equals(getCountryCode())))
			{
				setStatus(InvErrorCode.NOTFOUND_COUNTRYCODE);
                return false;
			}
		
			DBTblVzbPrefixPlanTplt pptDbBean = new DBTblVzbPrefixPlanTplt();
			pptDbBean.whereCntryCodeEQ(getCountryCode());
			int pptDeleted = pptDbBean.deleteByWhere(dbCon);
			log.info("Deleted [" + pptDeleted + "] Prefix Plan Tplt");
		}
		catch(SQLException s)
		{
			s.printStackTrace();	
			setStatus(InvErrorCode.DB_EXCEPTION);
			log.info("DB_FAILURE in deletePrefixPlanTplt");
			return false;
		}
		setStatus(InvErrorCode.SUCCESS);
		log.info("Successfully Deleted Prefix Plan Tplt");
		return true;
	}

	
	public boolean getPrefixPlanTpltByCountryCode() 
	{
		log.info("Entering getPrefixPlanTpltByCountryCode");
		try 
		{
			TblVzbPrefixPlanTpltQuery pptQry = new TblVzbPrefixPlanTpltQuery();
			pptQry.whereCntryCodeEQ(getCountryCode());
			pptQry.query(dbCon);

			if (pptQry.size() <= 0) 
			{
				setStatus(InvErrorCode.NOTFOUND_COUNTRYCODE);
				log.info("Country Code [" + getCountryCode() + "] Not Found");
				return false;
			}
			TblVzbPrefixPlanTpltDbBean pptBean = pptQry.getDbBean(0);	
			setCountryCode(pptBean.getCntryCode());
			setPlatformIndicator(pptBean.getPlatformIndicator());
			setPrefixName(pptBean.getPrefixName());
			setMobile(pptBean.getMobile());
			setCreatedBy(pptBean.getCreatedBy());
			setCreationDate(pptBean.getCreationDate());
			setModifiedBy(pptBean.getModifiedBy());
			setLastModifiedDate(pptBean.getLastModifiedDate());
		}
		catch(SQLException e)
		{
			e.printStackTrace();	
			setStatus(InvErrorCode.DB_EXCEPTION);
			return false;
		}
		catch(Exception e)
		{
			e.printStackTrace();	
			setStatus(InvErrorCode.ERROR_GETTING_SIP_DOMAIN_DETAILS);
			return false;
		}
		setStatus(InvErrorCode.SUCCESS);
		return true;
	}
	

}
