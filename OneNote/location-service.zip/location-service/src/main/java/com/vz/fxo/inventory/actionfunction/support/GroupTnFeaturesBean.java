package com.vz.fxo.inventory.actionfunction.support;
import java.io.Serializable;
import java.sql.Timestamp;

public class GroupTnFeaturesBean implements Serializable{
	
	    /**
	 * Member Declaration
	 */

		protected int grpTnFeatureId;;
	    protected long groupTnId;
	    protected long featureId;
	    protected String createdBy;
	    protected Timestamp creationDate;
	    protected String modifiedBy;
	    protected Timestamp lastModifiedDate;
	    protected long envOrderId;

		/**
	     * 
	     *Default Constructor -- Initializes all fields to default values.
	     */
	    public GroupTnFeaturesBean()
	    {
	    	this.grpTnFeatureId=0;
	    	this.groupTnId=0;
	    	this.featureId=0;
	    	this.createdBy=new String("");
	    	this.creationDate=null;
	    	this.modifiedBy=new String("");
	    	this.lastModifiedDate=null;
	    	this.envOrderId=0;
	   
	    }

	    /**
	     * Constructor
	     * 
	     * @param groupTnFeaturesDbBean
	     */
	    public GroupTnFeaturesBean(GroupTnFeaturesBean groupTnFeaturesDbBean)
	    {
	      this.grpTnFeatureId=groupTnFeaturesDbBean.grpTnFeatureId;
	        this.groupTnId=groupTnFeaturesDbBean.groupTnId;
	        this.featureId=groupTnFeaturesDbBean.featureId;
	        this.createdBy=groupTnFeaturesDbBean.createdBy;
	        this.creationDate=groupTnFeaturesDbBean.creationDate;
	        this.modifiedBy=groupTnFeaturesDbBean.modifiedBy;
	        this.lastModifiedDate=groupTnFeaturesDbBean.lastModifiedDate;
	        this.envOrderId=groupTnFeaturesDbBean.envOrderId;
	    }
	    
	
		
	    public long getEnvOrderId() {
			return envOrderId;
		}

		public int getGrpTnFeatureId() {
			return grpTnFeatureId;
		}

		public void setGrpTnFeatureId(int grpTnFeatureId) {
			this.grpTnFeatureId = grpTnFeatureId;
		}

		public long getGroupTnId() {
			return groupTnId;
		}

		public void setGroupTnId(long groupTnId) {
			this.groupTnId = groupTnId;
		}

		public long getFeatureId() {
			return featureId;
		}

		public void setFeatureId(long featureId) {
			this.featureId = featureId;
		}

		public String getCreatedBy() {
			return createdBy;
		}

		public void setCreatedBy(String createdBy) {
			this.createdBy = createdBy;
		}

		public Timestamp getCreationDate() {
			return creationDate;
		}

		public void setCreationDate(Timestamp creationDate) {
			this.creationDate = creationDate;
		}
		
		
		public String getModifiedBy() {
			return modifiedBy;
		}

		public void setModifiedBy(String modifiedBy) {
			this.modifiedBy = modifiedBy;
		}

		public Timestamp getLastModifiedDate() {
			return lastModifiedDate;
		}

		public void setLastModifiedDate(Timestamp lastModifiedDate) {
			this.lastModifiedDate = lastModifiedDate;
		}

		public void setEnvOrderId(long envOrderId) {
			this.envOrderId = envOrderId;
		}
	
}
