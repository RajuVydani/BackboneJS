package com.vz.esap.api.model;

public class OrderErrorLogInfo {
	
	/*	  "createdBy": "string",
		  "creationDate": "string",
		  "entityType": "string",
		  "entityValue": "string",
		  "envOrderId": 0,
		  "errorSource": "string",
		  "errorType": "string",
		  "sourceErrorCode": "string",
		  "sourceErrorDesc": "string"
	*/
	private Long envOrderId;
	private String entityType;
	private String entityValue;
	private String errorType;
	private String errorSource;
	private String createdBy;
	private String creationDate;
	private String sourceErrorCode;
	private String sourceErrorDesc;
	public Long getEnvOrderId() {
		return envOrderId;
	}
	public void setEnvOrderId(Long envOrderId) {
		this.envOrderId = envOrderId;
	}
	public String getEntityType() {
		return entityType;
	}
	public void setEntityType(String entityType) {
		this.entityType = entityType;
	}
	public String getEntityValue() {
		return entityValue;
	}
	public void setEntityValue(String entityValue) {
		this.entityValue = entityValue;
	}
	public String getErrorType() {
		return errorType;
	}
	public void setErrorType(String errorType) {
		this.errorType = errorType;
	}
	public String getErrorSource() {
		return errorSource;
	}
	public void setErrorSource(String errorSource) {
		this.errorSource = errorSource;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public String getCreationDate() {
		return creationDate;
	}
	public void setCreationDate(String creationDate) {
		this.creationDate = creationDate;
	}
	public String getSourceErrorCode() {
		return sourceErrorCode;
	}
	public void setSourceErrorCode(String sourceErrorCode) {
		this.sourceErrorCode = sourceErrorCode;
	}
	public String getSourceErrorDesc() {
		return sourceErrorDesc;
	}
	public void setSourceErrorDesc(String sourceErrorDesc) {
		this.sourceErrorDesc = sourceErrorDesc;
	}
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("OrderErrorLogInfo [envOrderId=");
		builder.append(envOrderId);
		builder.append(", entityType=");
		builder.append(entityType);
		builder.append(", entityValue=");
		builder.append(entityValue);
		builder.append(", errorType=");
		builder.append(errorType);
		builder.append(", errorSource=");
		builder.append(errorSource);
		builder.append(", createdBy=");
		builder.append(createdBy);
		builder.append(", creationDate=");
		builder.append(creationDate);
		builder.append(", sourceErrorCode=");
		builder.append(sourceErrorCode);
		builder.append(", sourceErrorDesc=");
		builder.append(sourceErrorDesc);
		builder.append("]");
		return builder.toString();
	}
	
	

}
