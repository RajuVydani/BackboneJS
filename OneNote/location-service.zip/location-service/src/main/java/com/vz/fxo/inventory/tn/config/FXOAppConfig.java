package com.vz.fxo.inventory.tn.config;

import java.text.SimpleDateFormat;

import ma.glasnost.orika.MapperFacade;
import ma.glasnost.orika.MapperFactory;
import ma.glasnost.orika.impl.DefaultMapperFactory;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.converter.json.Jackson2ObjectMapperBuilder;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.vz.esap.common.database.logging.DatabaseLogging;
/*import com.vz.fxo.inventory.tn.actionfunction.VZB_INV_ACTIVATE_TN_FXO;
import com.vz.fxo.inventory.tn.actionfunction.VZB_INV_ADD_ET_TN_FXO;
import com.vz.fxo.inventory.tn.actionfunction.VZB_INV_ADD_PORTED_ET_TN_FXO;//VZB_INV_ADD_PORTED_ET_TN;
import com.vz.fxo.inventory.tn.actionfunction.VZB_INV_DEACTIVATE_TN_FXO;
import com.vz.fxo.inventory.tn.actionfunction.VZB_INV_DEL_ET_TN_FXO;
import com.vz.fxo.inventory.tn.actionfunction.VZB_INV_MOD_ET_TN_FXO;
import com.vz.fxo.inventory.tn.actionfunction.VZB_INV_MOD_TRUNK_CLLI_FXO;
import com.vz.fxo.inventory.tn.order.dao.FxoTnUtilDaoImpl;
import com.vz.fxo.inventory.tn.service.InvFxoModTrunkClliService;
import com.vz.fxo.inventory.tn.service.InventoryFxoTNService;*/

/**
 * 
 * @author Siva Adabala
 *
 */

@Configuration
@EnableTransactionManagement
public class FXOAppConfig 
{
	/*@Bean
	@ConfigurationProperties(prefix = "inventory.service.datasource")
	public DataSource getdataserviceDS() {
		return DataSourceBuilder.create().build();
	}*/

	@Bean
	public Jackson2ObjectMapperBuilder jacksonBuilder() {
		Jackson2ObjectMapperBuilder builder = new Jackson2ObjectMapperBuilder();
		builder.indentOutput(true).dateFormat(
				new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"));
		return builder;
	}

	@Bean
	MapperFacade mapperFacade() {

		MapperFactory factory = new DefaultMapperFactory.Builder().build();
		
		return factory.getMapperFacade();
	}
	
	/*@Bean
	public InventoryFxoTNService inventoryTNService(){
		return new InventoryFxoTNService();
	}
	
	@Bean
	public VZB_INV_ACTIVATE_TN_FXO vzbInvActivateTn(){
		return new VZB_INV_ACTIVATE_TN_FXO();
	}
	
	@Bean
	public DatabaseLogging databaseLogging(){
		return new DatabaseLogging();
	}
	
	@Bean
	public VZB_INV_ADD_ET_TN_FXO vzbInvAddEtTn(){
		return new VZB_INV_ADD_ET_TN_FXO();
	}
	
	@Bean
	public VZB_INV_DEACTIVATE_TN_FXO vzbInvDeactivateTn(){
		return new VZB_INV_DEACTIVATE_TN_FXO();
	}
	@Bean
	public VZB_INV_MOD_ET_TN_FXO vzbInvModEtTn(){
		return new VZB_INV_MOD_ET_TN_FXO();
	}
	
	@Bean
	public VZB_INV_DEL_ET_TN_FXO vzbInvDeleteTn(){
		return new VZB_INV_DEL_ET_TN_FXO();
	}
	
	@Bean
	public VZB_INV_ADD_PORTED_ET_TN_FXO vzbInvAddPortedEtTn(){
		return new VZB_INV_ADD_PORTED_ET_TN_FXO();
	}
	
	@Bean
	public VZB_INV_MOD_TRUNK_CLLI_FXO invModTrunkClli(){
		return new VZB_INV_MOD_TRUNK_CLLI_FXO();
	}
	
	@Bean
	public InvFxoModTrunkClliService invModTrunkClliService(){
		return new InvFxoModTrunkClliService();
	}
	
	@Bean
	public FxoTnUtilDaoImpl tnUtilDaoImpl(){
		return new FxoTnUtilDaoImpl();
	}*/
}
