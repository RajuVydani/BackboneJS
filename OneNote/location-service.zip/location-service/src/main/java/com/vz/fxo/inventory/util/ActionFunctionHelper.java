package com.vz.fxo.inventory.util;

import java.sql.Connection;
import java.sql.SQLException;

import org.springframework.stereotype.Component;

import com.vz.esap.api.connector.service.impl.ConfigDomainDataServiceImpl;
import com.vz.esap.api.connector.service.impl.InventoryDomainDataServiceImpl;
import com.vz.esap.api.connector.service.impl.OrderDomainDataServiceImpl;
import com.vz.esap.api.connector.service.impl.OrderLogServiceImpl;
import com.vz.esap.api.model.BSServiceRequest;
import com.vz.esap.api.model.ESAPEntityEnum;
import com.vz.fxo.inventory.tn.GenericActionFunction;
//import com.vz.esap.inventory.tn.helper.ServiceHelper;
import com.vz.fxo.inventory.tn.helper.FxoBSErrorEntityMgmtHelper;
import com.vz.fxo.inventory.tn.helper.FxoServiceHelper;

@Component
public class ActionFunctionHelper {

      public <T extends GenericActionFunction> GenericActionFunction getActionFunctionImpl(T obj,
                  BSServiceRequest request,ConfigDomainDataServiceImpl configDomainDataService,
                  OrderDomainDataServiceImpl  orderDomainDataService,
                  OrderLogServiceImpl orderLogService,
                  InventoryDomainDataServiceImpl inventoryDomainDataService,
                  FxoBSErrorEntityMgmtHelper bsErrorEntityMgmtHelper,
                  Connection connection) throws SQLException {

    	    FxoServiceHelper.setRequestAttributes(request, obj, ESAPEntityEnum.ENTERPRISE.toString());
	        obj.setConfigDomainDataService(configDomainDataService);
	        obj.setOrderDomainDataService(orderDomainDataService);
	        obj.setOrderLogService(orderLogService);
	        obj.setInventoryDomainDataService(inventoryDomainDataService);
	        obj.setBsErrorEntityMgmtHelper(bsErrorEntityMgmtHelper);
	        obj.setConnection(connection);

            return obj;
      }
      
      public <T extends GenericActionFunction> GenericActionFunction getLocActionFunctionImpl(T obj,
  			BSServiceRequest request, ConfigDomainDataServiceImpl configDomainDataService,
            OrderDomainDataServiceImpl  orderDomainDataService,
            OrderLogServiceImpl orderLogService,
            InventoryDomainDataServiceImpl inventoryDomainDataService,
            FxoBSErrorEntityMgmtHelper bsErrorEntityMgmtHelper,
            Connection connection) throws SQLException {

  		FxoServiceHelper.setRequestAttributes(request, obj, ESAPEntityEnum.LOCATION.toString());
  		obj.setConfigDomainDataService(configDomainDataService);
  		obj.setOrderDomainDataService(orderDomainDataService);
  		obj.setOrderLogService(orderLogService);
  		obj.setInventoryDomainDataService(inventoryDomainDataService);
  		obj.setBsErrorEntityMgmtHelper(bsErrorEntityMgmtHelper);
  		obj.setConnection(connection);

  		return obj;
  	}


}
