package com.vz.fxo.inventory.actionfunction.support;

import esap.db.TblSipDomainDbBean;

public class SipDomainBean
{
		protected int sipDomainId;
        protected long dialPlanId;
        protected String domainName;
        protected long PPId=0;
        protected String createdBy;
        protected String modifiedBy;
        protected java.sql.Timestamp creationDate;
        protected java.sql.Timestamp lastModifiedDate;
        protected long envOrderId;

        /**
    	 * Default Constructor -- Initializes all fields to default values.
    	 */
        public SipDomainBean() {
        	this.sipDomainId = 0;
		this.dialPlanId = 0;
		this.domainName = new String("");
		PPId = 0;
		this.createdBy = new String("");
		this.modifiedBy = new String("");
		this.creationDate = null;
		this.lastModifiedDate = null;
		this.envOrderId = 0;
	}
        /**
         * Constructor
         * @param sipDomainBean
         */
        public SipDomainBean(SipDomainBean sipDomainBean) {
        	this.sipDomainId = sipDomainBean.sipDomainId;
		this.dialPlanId = sipDomainBean.dialPlanId;
		this.domainName = sipDomainBean.domainName;
		PPId = sipDomainBean.PPId;
		this.createdBy = sipDomainBean.createdBy;
		this.modifiedBy = sipDomainBean.modifiedBy;
		this.creationDate = sipDomainBean.creationDate;
		this.lastModifiedDate = sipDomainBean.lastModifiedDate;
		this.envOrderId = sipDomainBean.envOrderId ;
	}

        public String toString()
        {
            final String NEWLINE = "\n";
            StringBuffer retValue = new StringBuffer();
            retValue.append("SipDomainBean ( ");
            retValue.append(super.toString()).append(NEWLINE);
            retValue.append("sipDomainId = ").append(this.sipDomainId).append(NEWLINE);
            retValue.append("dialPlanId = ").append(this.dialPlanId).append(NEWLINE);
            retValue.append("createdBy = ").append(this.createdBy).append(NEWLINE);
            retValue.append("modifiedBy = ").append(this.modifiedBy).append(NEWLINE);
            retValue.append("lastModifiedDate = ").append(this.lastModifiedDate).append(NEWLINE);
            retValue.append(" )");
            return retValue.toString();
        }
        
        public java.sql.Timestamp getCreationDate() {
			return creationDate;
		}

		public void setCreationDate(java.sql.Timestamp creationDate) {
			this.creationDate = creationDate;
		}

		public String getCreatedBy() {
			return createdBy;
		}
		public void setCreatedBy(String createdBy) {
			this.createdBy = createdBy;
		}
		public long getDialPlanId() {
			return dialPlanId;
		}
		public void setDialPlanId(long dialPlanId) {
			this.dialPlanId = dialPlanId;
		}
		public String getDomainName() {
			return domainName;
		}
		public void setDomainName(String domainName) {
			this.domainName = domainName;
		}
		public java.sql.Timestamp getLastModifiedDate() {
			return lastModifiedDate;
		}
		public void setLastModifiedDate(java.sql.Timestamp lastModifiedDate) {
			this.lastModifiedDate = lastModifiedDate;
		}
		public String getModifiedBy() {
			return modifiedBy;
		}
		public void setModifiedBy(String modifiedBy) {
			this.modifiedBy = modifiedBy;
		}
		public long getPPId() {
			return PPId;
		}
		public void setPPId(long id) {
			PPId = id;
		}
		public int getSipDomainId() {
			return sipDomainId;
		}
		public void setSipDomainId(int sipDomainId) {
			this.sipDomainId = sipDomainId;
		}

		public void copyFrom(TblSipDomainDbBean tblSipDomainDbBean){
			setSipDomainId(tblSipDomainDbBean.getSipDomainId());
			setDialPlanId(tblSipDomainDbBean.getDialPlanId());
			setDomainName(tblSipDomainDbBean.getDomainName());
			setPPId(tblSipDomainDbBean.getPpId());
			setCreatedBy(tblSipDomainDbBean.getCreatedBy());
			setModifiedBy(tblSipDomainDbBean.getModifiedBy());
			setLastModifiedDate(tblSipDomainDbBean.getLastModifiedDate());
			setEnvOrderId(tblSipDomainDbBean.getEnvOrderId());
		}

	public long getEnvOrderId() {
    		return envOrderId;
    	}
    	public void setEnvOrderId(long envOrderId) {
    		this.envOrderId = envOrderId;
    	}
}

