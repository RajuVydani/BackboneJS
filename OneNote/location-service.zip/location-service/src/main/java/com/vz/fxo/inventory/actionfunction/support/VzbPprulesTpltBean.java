package com.vz.fxo.inventory.actionfunction.support;

import java.util.List;

public class VzbPprulesTpltBean {
	
	protected String cntryCode;
	protected String region;
	protected short platformIndicator;
	protected String prefixName;
	protected String prefix;
	protected long numstrip;
	protected String addPrefix;
	protected long noa;
	protected long blkstat;
	protected String createdBy;
	protected java.sql.Timestamp creationDate;
	protected String modifiedBy;
	protected java.sql.Timestamp lastModifiedDate;
	protected List<VzbPprulesTpltBean> vzbPprulesTpltBeanList;
	
	public VzbPprulesTpltBean(){
		cntryCode = "NONE";
		region = "NONE";
		platformIndicator = -1;
		prefixName = "NONE";
		prefix = "NONE";
		numstrip = -1;
		addPrefix = "NONE";
		noa = -1;
		blkstat = -1;
		createdBy = "NONE";
		creationDate = null;
		modifiedBy = null;
		lastModifiedDate = null;
		this.vzbPprulesTpltBeanList = null;
	}
	
	public VzbPprulesTpltBean(VzbPprulesTpltBean vzbPprulesTpltBean){
		this.cntryCode = vzbPprulesTpltBean.cntryCode;
		this.region = vzbPprulesTpltBean.region;
		this.platformIndicator = vzbPprulesTpltBean.platformIndicator;
		this.prefixName = vzbPprulesTpltBean.prefixName;
		this.prefix = vzbPprulesTpltBean.prefix;
		this.numstrip = vzbPprulesTpltBean.numstrip;
		this.addPrefix = vzbPprulesTpltBean.addPrefix;
		this.noa = vzbPprulesTpltBean.noa;
		this.blkstat = vzbPprulesTpltBean.blkstat;
		this.createdBy = vzbPprulesTpltBean.createdBy;
		this.creationDate = vzbPprulesTpltBean.creationDate;
		this.modifiedBy = vzbPprulesTpltBean.modifiedBy;
		this.lastModifiedDate = vzbPprulesTpltBean.lastModifiedDate;
		this.vzbPprulesTpltBeanList = vzbPprulesTpltBean.vzbPprulesTpltBeanList;
	}
	
	public String toString() {
		return(""+"cntryCode="+cntryCode+"\n"+"region="+region+"\n"+"platformIndicator="+platformIndicator+"\n"+"prefixName="+prefixName+"\n"+"prefix="+prefix+"\n"+"numstrip="+numstrip+"\n"+"addPrefix="+addPrefix+"\n"+"noa="+noa+"\n"+"blkstat="+blkstat+"\n"+"createdBy="+createdBy+"\n"+"creationDate="+creationDate+"\n"+"modifiedBy="+modifiedBy+"\n"+"lastModifiedDate="+lastModifiedDate+"\n");
	}
	public void setCntryCode(String cntryCode) {
		this.cntryCode = cntryCode;
	}
	public String getCntryCode(){
		return this.cntryCode;
	}
	public void setRegion(String region) {
		this.region = region;
	}
	public String getRegion(){
		return this.region;
	}
	public void setPlatformIndicator(short platformIndicator) {
		this.platformIndicator = platformIndicator;
	}
	public short getPlatformIndicator(){
		return this.platformIndicator;
	}
	public void setPrefixName(String prefixName) {
		this.prefixName = prefixName;
	}
	public String getPrefixName(){
		return this.prefixName;
	}
	public void setPrefix(String prefix) {
		this.prefix = prefix;
	}
	public String getPrefix(){
		return this.prefix;
	}
	public void setNumstrip(long numstrip) {
		this.numstrip = numstrip;
	}
	public long getNumstrip(){
		return this.numstrip;
	}
	public void setAddPrefix(String addPrefix) {
		this.addPrefix = addPrefix;
	}
	public String getAddPrefix(){
		return this.addPrefix;
	}
	public void setNoa(long noa) {
		this.noa = noa;
	}
	public long getNoa(){
		return this.noa;
	}
	public void setBlkstat(long blkstat) {
		this.blkstat = blkstat;
	}
	public long getBlkstat(){
		return this.blkstat;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public String getCreatedBy(){
		return this.createdBy;
	}
	public void setCreationDate(java.sql.Timestamp creationDate) {
		this.creationDate = creationDate;
	}
	public java.sql.Timestamp getCreationDate(){
		return this.creationDate;
	}
	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public String getModifiedBy(){
		return this.modifiedBy;
	}
	public void setLastModifiedDate(java.sql.Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}
	public java.sql.Timestamp getLastModifiedDate(){
		return this.lastModifiedDate;
	}
	
	
	public List<VzbPprulesTpltBean> getVzbPprulesTpltBeanList() {
		return vzbPprulesTpltBeanList;
	}

	public void setVzbPprulesTpltBeanList(
			List<VzbPprulesTpltBean> vzbPprulesTpltBeanList) {
		this.vzbPprulesTpltBeanList = vzbPprulesTpltBeanList;
	}




}
