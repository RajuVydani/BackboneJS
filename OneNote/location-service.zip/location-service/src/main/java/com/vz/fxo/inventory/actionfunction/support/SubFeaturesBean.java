package com.vz.fxo.inventory.actionfunction.support;



public class SubFeaturesBean
{
	//members
    protected int subFeatureId;
	protected String subId;
	protected long featureId;
	protected String featureName;
	protected String featureDesc;
	protected long isBillable;
	protected String selected;
        protected long envOrderId;
	protected String modifiedBy;
	protected String createdBy;
	
	public SubFeaturesBean()
	{
		subFeatureId = 0;
		subId = new String("");
		featureId = 0;
		featureName  = new String("");
		featureDesc = new String("");
		isBillable = 0;
		selected = new String("NONE");
             	envOrderId = -1;		
        	modifiedBy = new String("");
		createdBy = new String("");
	}
	public SubFeaturesBean(SubFeaturesBean subFeatBean)
	{
		subFeatureId = subFeatBean.subFeatureId;
		subId = subFeatBean.subId;
		featureId = subFeatBean.featureId;
		featureName = subFeatBean.featureName;
		featureDesc = subFeatBean.featureDesc;
		isBillable = subFeatBean.isBillable;
		selected = subFeatBean.selected;
                envOrderId = subFeatBean.envOrderId;		
        	modifiedBy =subFeatBean.modifiedBy;
		createdBy = subFeatBean.createdBy;
	}
	
	//getter - setters
	public String getSubId() {
		return subId;
	}

	public void setSubId(String subId) {
		this.subId = subId;
	}
	public String getFeatureName() {
                return featureName;
        }

        public void setFeatureName(String featureName) {
                this.featureName = featureName;
        }
	public String getFeatureDesc() {
                return featureDesc;
        }

        public void setFeatureDesc(String featureDesc) {
                this.featureDesc = featureDesc;
        }
	public long getFeatureId() {
		return featureId;
	}

	public void setFeatureId(long featureId) {
		this.featureId = featureId;
	}
	public long getIsBillable() {
                return isBillable;
        }

        public void setIsBillable(long isBillable) {
                this.isBillable = isBillable;
        }

	public String getSelected() {
		return selected;
	}

	public void setSelected(String selected) {
		this.selected = selected;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
        public int getSubFeatureId() {
		return subFeatureId;
	}

	public void setSubFeatureId(int subFeatureId) {
		this.subFeatureId = subFeatureId;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
        }	
        public long getEnvOrderId() {
		return envOrderId;
	}
	public void setEnvOrderId(long envOrderId) {
		this.envOrderId = envOrderId;
        }
	 public void initilizeTODefault() {
			subId = new String("");
			featureId = 0;
			featureName  = new String("");
			featureDesc = new String("");
			isBillable = 0;
			selected = new String("");
	             	envOrderId = 0;		
	        	modifiedBy = new String("");
			createdBy = new String("");
	 }
}

