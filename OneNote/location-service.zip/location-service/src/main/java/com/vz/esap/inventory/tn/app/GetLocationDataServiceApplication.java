package com.vz.esap.inventory.tn.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.context.annotation.ComponentScan;

//@EnableDiscoveryClient
@SpringBootApplication
@ComponentScan("com.vz")
public class GetLocationDataServiceApplication {
 
	public static void main(String[] args) {
		System.out.println("Started Location service...!!!");
        SpringApplication.run(GetLocationDataServiceApplication.class, args);
        System.out.println("Booted...!!!");
	}
	
}