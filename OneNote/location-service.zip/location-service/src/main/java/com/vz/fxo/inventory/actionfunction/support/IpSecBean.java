package com.vz.fxo.inventory.actionfunction.support;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class IpSecBean implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public long ipsecTunnelId;
	public String ikeIp;
	public short hostSubMask;
	public String hostSubIP;
	public String egwType;
	public short deviceType;
	public long deviceId;
	public String enterpriseId;
	public long envOrderId;
	public String requestBy;
	public List<IpSecRequestDetailsBean> ipseqReqDetailsList;
	public short requestType;
	public short requestStatus;
	
	public String custName;
	public String city;
	public String state;
	public short tunnelStatus;
	
	public boolean tunnelValuesChanged;
	public IpSecBean(){
		this.ipsecTunnelId=0;
		this.ikeIp="";
		this.hostSubMask=0;
		this.hostSubIP="";
		this.egwType = "";
		this.deviceType = 0;
		this.deviceId = 0;
		this.enterpriseId = "";
		this.envOrderId = 0;
		this.requestBy = "";
		this.ipseqReqDetailsList =new ArrayList<IpSecRequestDetailsBean>();
		tunnelStatus = 1;
		tunnelValuesChanged = false;
	}
	
	public IpSecBean(IpSecBean ipBean){
		this.ipsecTunnelId=ipBean.ipsecTunnelId;
		this.ikeIp=ipBean.ikeIp;
		this.hostSubMask=ipBean.hostSubMask;
		this.hostSubIP=ipBean.hostSubIP;
		this.egwType =ipBean.egwType;
		this.deviceType = ipBean.deviceType;
		this.deviceId = ipBean.deviceId;
		this.enterpriseId = ipBean.enterpriseId;
		this.envOrderId = ipBean.envOrderId;
		this.requestBy = ipBean.requestBy;
		this.ipseqReqDetailsList = ipBean.ipseqReqDetailsList;
		this.tunnelStatus = ipBean.tunnelStatus;
	}
	
	public long getIpsecTunnelId() {
		return ipsecTunnelId;
	}

	public void setIpsecTunnelId(long ipsecTunnelId) {
		this.ipsecTunnelId = ipsecTunnelId;
	}
	
	public String getIkeIp() {
		return ikeIp;
	}
	public void setIkeIp(String ikeIp) {
		this.ikeIp = ikeIp;
	}
	
	public String getHostSubIP() {
		return hostSubIP;
	}
	public void setHostSubIP(String hostSubIP) {
		this.hostSubIP = hostSubIP;
	}
	
	public short getHostSubMask() {
		return hostSubMask;
	}

	public void setHostSubMask(short hostSubMask) {
		this.hostSubMask = hostSubMask;
	}
	
	public String getEgwType() {
		return egwType;
	}

	public void setEgwType(String egwType) {
		this.egwType = egwType;
	}

	public short getDeviceType() {
		return deviceType;
	}

	public void setDeviceType(short deviceType) {
		this.deviceType = deviceType;
	}

	public long getDeviceId() {
		return deviceId;
	}

	public void setDeviceId(long deviceId) {
		this.deviceId = deviceId;
	}

	public String getEnterpriseId() {
		return enterpriseId;
	}

	public void setEnterpriseId(String enterpriseId) {
		this.enterpriseId = enterpriseId;
	}

	public long getEnvOrderId() {
		return envOrderId;
	}

	public void setEnvOrderId(long envOrderId) {
		this.envOrderId = envOrderId;
	}

	public String getRequestBy() {
		return requestBy;
	}

	public void setRequestBy(String requestBy) {
		this.requestBy = requestBy;
	}

	public List<IpSecRequestDetailsBean> getIpseqReqDetailsList() {
		return ipseqReqDetailsList;
	}

	public void setIpseqReqDetailsList(
			List<IpSecRequestDetailsBean> ipseqReqDetailsList) {
		this.ipseqReqDetailsList = ipseqReqDetailsList;
	}

	public short getRequestType() {
		return requestType;
	}

	public void setRequestType(short requestType) {
		this.requestType = requestType;
	}

	public short getRequestStatus() {
		return requestStatus;
	}

	public void setRequestStatus(short requestStatus) {
		this.requestStatus = requestStatus;
	}
	public String getCustName() {
		return custName;
	}

	public void setCustName(String custName) {
		this.custName = custName;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public short getTunnelStatus() {
		return tunnelStatus;
	}

	public void setTunnelStatus(short tunnelStatus) {
		this.tunnelStatus = tunnelStatus;
	}

	public boolean isTunnelValuesChanged() {
		return tunnelValuesChanged;
	}

	public void setTunnelValuesChanged(boolean tunnelValuesChanged) {
		this.tunnelValuesChanged = tunnelValuesChanged;
	}
	
}

