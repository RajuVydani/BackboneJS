/**
 * 
 */
package com.vz.fxo.inventory.tn.service;

import java.sql.Connection;
import java.sql.SQLException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mchange.v2.c3p0.ComboPooledDataSource;
import com.vz.esap.api.connector.service.impl.ConfigDomainDataServiceImpl;
import com.vz.esap.api.connector.service.impl.InventoryDomainDataServiceImpl;
import com.vz.esap.api.connector.service.impl.OrderDomainDataServiceImpl;
import com.vz.esap.api.connector.service.impl.OrderLogServiceImpl;
import com.vz.esap.api.model.BSServiceRequest;
import com.vz.esap.api.model.ESAPEntityEnum;
import com.vz.esap.api.model.ResponseObject;
import com.vz.fxo.inventory.util.ActionFunctionHelper;
import com.vz.fxo.inventory.location.actionfunction.VZB_INV_ADD_LOCATION_FXO;
/*import com.vz.fxo.inventory.location.actionfunction.VZB_INV_DEL_LOCATION_FXO;
import com.vz.fxo.inventory.location.actionfunction.VZB_INV_DEL_SUSPEND_LOCATION_FXO;
import com.vz.fxo.inventory.location.actionfunction.VZB_INV_MOD_LOCATION_FXO;
import com.vz.fxo.inventory.location.actionfunction.VZB_INV_MOD_LOC_CNAM_FXO;
import com.vz.fxo.inventory.location.actionfunction.VZB_PC_MOD_LOCATION;
import com.vz.fxo.inventory.location.actionfunction.VZB_PC_COMPLETE_LOCATION;*/
import com.vz.fxo.inventory.tn.GenericActionFunction;
import com.vz.fxo.inventory.tn.helper.FxoBSErrorEntityMgmtHelper;
import com.vz.fxo.inventory.tn.helper.FxoServiceHelper;

/**
 * BSTNServiceImpl is service class which defines methods to provision LOCATION
 * Entity on Broad soft device
 * 
 * @author Jivitesh Kumar
 * 
 */
@Service
public class InventoryFxoLocationServiceImpl {

	@Autowired
	public OrderDomainDataServiceImpl orderDomainDataService;
	@Autowired
	public ConfigDomainDataServiceImpl configDomainDataService;
	
	@Autowired
	public FxoBSErrorEntityMgmtHelper bsErrorEntityMgmtHelper;

	@Autowired
	public OrderLogServiceImpl orderLogService;

	@Autowired
	private ComboPooledDataSource comboPooledDataSource;

	@Autowired
	private InventoryDomainDataServiceImpl inventoryDomainDataService;
	
	@Autowired
	private ActionFunctionHelper afHelper;

	private Connection getConnection() throws SQLException {
		return comboPooledDataSource.getConnection();
	}

	private static Logger log = LoggerFactory.getLogger(InventoryFxoLocationServiceImpl.class.toString());

	/**
	 * This method invokes the VZB_INV_DEL_SUSPEND_LOCATION action function to delete the Location from inventory.
	 * @param bsRequestEntity
	 * @return
	 */
	/*public int delSuspendLocation(BSServiceRequest bsRequestEntity) {

		log.info("delSuspendLocation request received and calling corresponding action service");
		int processResult = ResponseObject.FAILURE;
		GenericActionFunction obj = null;
		try {
//			obj = getActionFunctionImpl(new VZB_INV_DEL_SUSPEND_LOCATION(), bsRequestEntity);
			obj = afHelper.getLocActionFunctionImpl(new VZB_INV_DEL_SUSPEND_LOCATION_FXO(),					
					bsRequestEntity,
                    configDomainDataService,
                    orderDomainDataService,
                    orderLogService,
                    inventoryDomainDataService,
                    bsErrorEntityMgmtHelper,
                    getConnection()                           
                 );
			processResult = obj.doTask(true);
		} catch (SQLException e) {
			log.error("Error while executing delSuspendLocation action function ",e);
		}finally {
			if (obj!= null && obj.getConnection() != null){
				try {
					obj.getConnection().close();
				} catch (SQLException e) {
					log.error("Error whiling closing SQL Connection",e);
				}
			}
		}		
		return processResult;
	}
	
	*//**
	 * This method invokes the VZB_INV_MOD_LOC_CNAM action function to Modify the Location from inventory.
	 * @param bsRequestEntity
	 * @return
	 *//*
	public int modLocationCnam(BSServiceRequest bsRequestEntity) {

		log.info("modLocationCnam request received and calling corresponding action service");
		int processResult = ResponseObject.FAILURE;
		GenericActionFunction obj = null;
		try {
			//obj = getActionFunctionImpl(new VZB_INV_MOD_LOC_CNAM(), bsRequestEntity);
			obj = afHelper.getLocActionFunctionImpl(new VZB_INV_MOD_LOC_CNAM_FXO(),					
					bsRequestEntity,
                    configDomainDataService,
                    orderDomainDataService,
                    orderLogService,
                    inventoryDomainDataService,
                    bsErrorEntityMgmtHelper,
                    getConnection()                           
                 );
			processResult = obj.doTask(true);
		} catch (SQLException e) {
			log.error("Error while executing modLocationCnam action function ",e);
		}finally {
			if (obj!= null && obj.getConnection() != null){
				try {
					obj.getConnection().close();
				} catch (SQLException e) {
					log.error("Error whiling closing SQL Connection",e);
				}
			}
		}		
		return processResult;
	}
	

	*//**
	 * This method invokes the VZB_PC_COMPLETE_LOCATION action function to complete the Location
	 *  Activation from inventory.
	 * @param bsRequestEntity
	 * @return
	 *//*
	public int pcCompleteLocation(BSServiceRequest bsRequestEntity) {

		log.info("pcCompleteLocation request received and calling corresponding action service");
		int processResult = ResponseObject.FAILURE;
		GenericActionFunction obj = null;
		try {
//			obj = getActionFunctionImpl(new VZB_PC_COMPLETE_LOCATION(), bsRequestEntity);
			obj = afHelper.getLocActionFunctionImpl(new VZB_PC_COMPLETE_LOCATION(),					
					bsRequestEntity,
                    configDomainDataService,
                    orderDomainDataService,
                    orderLogService,
                    inventoryDomainDataService,
                    bsErrorEntityMgmtHelper,
                    getConnection()                           
                 );
			processResult = obj.doTask(true);
		} catch (SQLException e) {
			log.error("Error while executing pcCompleteLocation action function ",e);
		}finally {
			if (obj!= null && obj.getConnection() != null){
				try {
					obj.getConnection().close();
				} catch (SQLException e) {
					log.error("Error whiling closing SQL Connection in pcCompleteLocation action function",e.getMessage());
				}
			}
		}		
		return processResult;
	}
	


	*//**
	 * This method invokes the VZB_INV_MOD_LOCATION action function to Modify the Location from inventory.
	 * @param bsRequestEntity
	 * @return
	 *//*
	public int invModLocation(BSServiceRequest bsRequestEntity) {

		log.info("invModLocation request received and calling corresponding action service");
		int processResult = ResponseObject.FAILURE;
		GenericActionFunction obj = null;
		try {
//			obj = getActionFunctionImpl(new VZB_INV_MOD_LOCATION(), bsRequestEntity);
			obj = afHelper.getLocActionFunctionImpl(new VZB_INV_MOD_LOCATION_FXO(),					
					bsRequestEntity,
                    configDomainDataService,
                    orderDomainDataService,
                    orderLogService,
                    inventoryDomainDataService,
                    bsErrorEntityMgmtHelper,
                    getConnection()                           
                 );
			processResult = obj.doTask(true);
		} catch (SQLException e) {
			log.error("Error while executing invModLocation action function ",e.getMessage());
		}finally {
			if (obj!= null && obj.getConnection() != null){
				try {
					obj.getConnection().close();
				} catch (SQLException e) {

					log.error("Error whiling closing SQL Connection in invModLocation action function",e.getMessage());
				}
			}
		}		
		return processResult;
	}
	
	*//**
	 * This method invokes the VZB_PC_MOD_LOCATION action function to Modify the Location from inventory.
	 * @param bsRequestEntity
	 * @return
	 *//*
	public int pcModLocation(BSServiceRequest bsRequestEntity) {

		log.info("pcModLocation request received and calling corresponding action service");
		int processResult = ResponseObject.FAILURE;
		GenericActionFunction obj = null;
		try {
//			obj = getActionFunctionImpl(new VZB_PC_MOD_LOCATION(), bsRequestEntity);
			obj = afHelper.getLocActionFunctionImpl(new VZB_PC_MOD_LOCATION(),					
					bsRequestEntity,
                    configDomainDataService,
                    orderDomainDataService,
                    orderLogService,
                    inventoryDomainDataService,
                    bsErrorEntityMgmtHelper,
                    getConnection()                           
                 );
			processResult = obj.doTask(true);
		} catch (SQLException e) {
			log.error("Error while executing pcModLocation action function ",e);
		}
		finally {
			if (obj!= null && obj.getConnection() != null){
				try {
					obj.getConnection().close();
				} catch (SQLException e) {
					log.error("Error whiling closing SQL Connection",e);
				}
			}
		}		
		return processResult;
	}*/

	 /* This method invokes the VZB_INV_ADD_LOCATION action function to add the Location from inventory.
	 * @param bsRequestEntity
	 * @return
	 */
	public int addLocation(BSServiceRequest bsRequestEntity) {

		log.info("addLocation request received and calling corresponding action service");
		int processResult = ResponseObject.FAILURE;
		GenericActionFunction obj = null;
		try {
//			obj = getActionFunctionImpl(new VZB_INV_ADD_LOCATION(), bsRequestEntity);
			obj = afHelper.getLocActionFunctionImpl(new VZB_INV_ADD_LOCATION_FXO(),					
					bsRequestEntity,
                    configDomainDataService,
                    orderDomainDataService,
                    orderLogService,
                    inventoryDomainDataService,
                    bsErrorEntityMgmtHelper,
                    getConnection()                           
                 );
			processResult = obj.doTask(true);
		} catch (SQLException e) {
			log.error("Error while executing Add Location action function ",e);
		}finally {
			if (obj!= null && obj.getConnection() != null){
				try {
					obj.getConnection().close();
				} catch (SQLException e) {
					log.error("Error whiling closing SQL Connection",e);
				}
			}
		}		
		return processResult;
	}
	
	/**
	 * This method invokes the VZB_INV_DEL_LOCATION action function to delete the Location from inventory.
	 * @param bsRequestEntity
	 * @return
	 */
	/*public int delLocation(BSServiceRequest bsRequestEntity) {

		log.info("delLocation request received and calling corresponding action service");
		int processResult = ResponseObject.FAILURE;
		GenericActionFunction obj = null;
		try {
//			obj = getActionFunctionImpl(new VZB_INV_DEL_LOCATION(), bsRequestEntity);
			obj = afHelper.getLocActionFunctionImpl(new VZB_INV_DEL_LOCATION_FXO(),					
					bsRequestEntity,
                    configDomainDataService,
                    orderDomainDataService,
                    orderLogService,
                    inventoryDomainDataService,
                    bsErrorEntityMgmtHelper,
                    getConnection()                           
                 );
			processResult = obj.doTask(true);
		} catch (SQLException e) {
			log.error("Error while executing Delete Location action function ",e);
		}finally {
			if (obj!= null && obj.getConnection() != null){
				try {
					obj.getConnection().close();
				} catch (SQLException e) {
					log.error("Error whiling closing SQL Connection",e);
				}
			}
		}		
		return processResult;
	}*/
}