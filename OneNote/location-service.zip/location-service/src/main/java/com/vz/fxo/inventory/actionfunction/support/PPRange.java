package com.vz.fxo.inventory.actionfunction.support;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import esap.db.DBTblVzbPprange;
import esap.db.TblVzbPprangeDbBean;
import esap.db.TblVzbPprangeQuery;

public class PPRange extends PPRangeBean {

	private static Logger log = LoggerFactory.getLogger(PPRange.class.toString());

	private InvErrorCode status = InvErrorCode.INTERNAL_ERROR;;
    Connection connection;
    
    public PPRange(Connection dbCon)
    {
    	super();
        this.connection = dbCon;
    }
    
    public PPRange(PPRangeBean pprangeBean, Connection dbCon)
    {
        super(pprangeBean);
        this.connection = dbCon;
    }
        
    public int getStatusCode() {
		return status.getErrorCode();
	}
 
	public String getStatusDesc() {
		return status.getErrorDesc();
	}

	public void setStatus(InvErrorCode status) {
		this.status = status;
	}

	public Connection getDbCon() {
		return connection;
	}

	public void setDbCon(Connection dbCon) {
		this.connection = dbCon;
	}

	public boolean getPPRangeListByPrefixPlanId() throws SQLException
    {
		log.info(" Entering getPPRangeListByPrefixPlanId");
		PPRangeBean pprBean = null;
		ArrayList<PPRangeBean> pprBeanList = null;
		try
		{
			TblVzbPprangeQuery pprQuery = new  TblVzbPprangeQuery();
			pprQuery.wherePrefixPlanIdEQ(getPrefixPlanId());
			pprQuery.query(connection);
			
			if ( pprQuery.size() > 0)
			{
				pprBeanList = new ArrayList<PPRangeBean>();
				for ( int i=0 ; i < pprQuery.size() ; i++)
				{
					pprBean = new PPRangeBean();
					TblVzbPprangeDbBean pprDbBean = pprQuery.getDbBean(i);
					pprBean.setPrefixPlanId(pprDbBean.getPrefixPlanId());
					pprBean.setRangeStart(pprDbBean.getRangeStart());
					pprBean.setRangeEnd(pprDbBean.getRangeEnd());
					pprBean.setNumstrip(pprDbBean.getNumstrip());
					pprBean.setAddPrefix(pprDbBean.getAddPrefix());
					pprBean.setNoa(pprDbBean.getNoa());
					pprBean.setBlkstat(pprDbBean.getBlkstat());
					pprBean.setCreatedBy(pprDbBean.getCreatedBy());
					pprBean.setCreationDate(pprDbBean.getCreationDate());
					pprBean.setModifiedBy(pprDbBean.getModifiedBy());
					pprBean.setLastModifiedDate(pprDbBean.getLastModifiedDate());
					pprBeanList.add(pprBean);
				}
				this.setPPRangeBeanList(pprBeanList);
			}
			else
			{
				log.info("No Prefix Plan Range Found by Prefix Plan Id [" + getPrefixPlanId() + "]");
				setStatus(InvErrorCode.NOT_FOUND_VZB_PPRANGE);
                return false;
			}
		
	    }
		catch(SQLException s)
	    {
	    	s.printStackTrace();
	        setStatus(InvErrorCode.DB_EXCEPTION);
	        return false;
	    }
		
		setStatus(InvErrorCode.SUCCESS);
	    log.info("Successfully Retrieved Prefix Plan Range");
		return true;
    }

	public boolean getPPRangeDetails() throws SQLException
    {
        log.info(" Entering getPPRangeDetails");
        PPRangeBean pprBean = null;
        ArrayList<PPRangeBean> pprBeanList = null;
        try
        {
            TblVzbPprangeQuery pprQuery = new  TblVzbPprangeQuery();
			if(getPrefixPlanId() > 0)
            	pprQuery.wherePrefixPlanIdEQ(getPrefixPlanId());
			if(getRangeStart() != null && !"".equals(getRangeStart()))
				pprQuery.whereRangeStartEQ(getRangeStart());
			if(getRangeEnd() != null && !"".equals(getRangeEnd()))
                pprQuery.whereRangeEndEQ(getRangeEnd());
            pprQuery.query(connection);

            if ( pprQuery.size() > 0)
            {
                pprBeanList = new ArrayList<PPRangeBean>();
                for ( int i=0 ; i < pprQuery.size() ; i++)
                {
                    pprBean = new PPRangeBean();
                    TblVzbPprangeDbBean pprDbBean = pprQuery.getDbBean(i);
                    pprBean.setPrefixPlanId(pprDbBean.getPrefixPlanId());
                    pprBean.setRangeStart(pprDbBean.getRangeStart());
                    pprBean.setRangeEnd(pprDbBean.getRangeEnd());
                    pprBean.setNumstrip(pprDbBean.getNumstrip());
                    pprBean.setAddPrefix(pprDbBean.getAddPrefix());
                    pprBean.setNoa(pprDbBean.getNoa());
                    pprBean.setBlkstat(pprDbBean.getBlkstat());
                    pprBean.setCreatedBy(pprDbBean.getCreatedBy());
                    pprBean.setCreationDate(pprDbBean.getCreationDate());
                    pprBean.setModifiedBy(pprDbBean.getModifiedBy());
                    pprBean.setLastModifiedDate(pprDbBean.getLastModifiedDate());
                    pprBeanList.add(pprBean);
                }
                this.setPPRangeBeanList(pprBeanList);
            }
            else
            {
                log.info("No Prefix Plan Range Found by Prefix Plan Id [" + getPrefixPlanId() + "]");
                setStatus(InvErrorCode.NOT_FOUND_VZB_PPRANGE);
                return false;
            }

        }
        catch(SQLException s)
        {
            s.printStackTrace();
            setStatus(InvErrorCode.DB_EXCEPTION);
            return false;
        }

        setStatus(InvErrorCode.SUCCESS);
        log.info("Successfully Retrieved Prefix Plan Range");
        return true;
    }

	public boolean addPPRange() throws SQLException, Exception
    {
        log.info("Entering addPPRange");
        try
        {
			if(! isNumber(getRangeStart()) || ! isNumber(getRangeStart()))
			{
				log.info("Range Start [" + getRangeStart() + "] And Range End [" + getRangeEnd() + "] Should be Numeric");
				return false;
			}
            DBTblVzbPprange pprDbBean = new DBTblVzbPprange();
            pprDbBean.setPrefixPlanId(getPrefixPlanId());
            
            if ( getRangeStart() != null && !"".equals(getRangeStart())){
            	pprDbBean.setRangeStart(getRangeStart());
            }
            
            if ( getRangeEnd() != null && !"".equals(getRangeEnd())){
            	pprDbBean.setRangeEnd(getRangeEnd());
            }
            
            if ( getNumstrip() > -1 ){
            	pprDbBean.setNumstrip(getNumstrip());
            }
			else
				pprDbBean.setNumstrip(0);
            
            if (getAddPrefix() != null && !"".equals(getAddPrefix())){
            	pprDbBean.setAddPrefix(getAddPrefix());
            }
            
            
            if ( getNoa() > -1 ){
            	pprDbBean.setNoa(getNoa());
            }
            
            if ( getBlkstat() > -1){
            	pprDbBean.setBlkstat(getBlkstat());
            }

            if(getCreatedBy() != null && !getCreatedBy().equals(""))
                pprDbBean.setCreatedBy(getCreatedBy());
            else
                pprDbBean.setCreatedBy("ESAP_INV");

            if(getModifiedBy() != null && !getModifiedBy().equals(""))
                pprDbBean.setModifiedBy(getModifiedBy());
            else
                pprDbBean.setModifiedBy("ESAP_INV");

            pprDbBean.setCreationDate(new Timestamp(System.currentTimeMillis()));
            pprDbBean.setLastModifiedDate(new Timestamp(System.currentTimeMillis()));
            pprDbBean.insertSpecific(connection);
        }
        catch(SQLException s)
        {
            log.info("SQL Exception in addPPRange");
            throw s;
        }

        setStatus(InvErrorCode.SUCCESS);
        log.info("Successfully Inserted Prefix Plan Range");
        return true;
    }
	
	public boolean deletePPRange()
    {
        log.info("Entering deletePPRange");
        try
        {
            if(getPrefixPlanId() <= 0)
            {
                setStatus(InvErrorCode.NOT_FOUND_VZB_PPRANGE);
                return false;
            }

            DBTblVzbPprange pprDbBean = new DBTblVzbPprange();
            pprDbBean.wherePrefixPlanIdEQ(getPrefixPlanId());
            pprDbBean.whereRangeStartEQ(getRangeStart());
            int pprDeleted = pprDbBean.deleteByWhere(connection);
            log.info("Deleted [" + pprDeleted + "] Prefix Plan Range");
        }
        catch(SQLException s)
        {
            s.printStackTrace();
            setStatus(InvErrorCode.DB_EXCEPTION);
            log.info("DB_FAILURE in deletePPRange");
            return false;
        }
        setStatus(InvErrorCode.SUCCESS);
        log.info("Successfully Deleted Prefix Plan Range");
        return true;
    }

	public boolean updatePPRange()
   	{
		log.info("Entering updatePPRange");
    	try
   		{ 
			if ( getPrefixPlanId() <= 0 || (getRangeStart() == null || (getRangeStart() != null && "".equals(getRangeStart())))) 
			{
                log.info("FAILURE in updatePPRange. Prefix Plan Id / Range Start Not Found");
				setStatus(InvErrorCode.NOT_FOUND_VZB_PPRANGE);
                return false;
           	}

            DBTblVzbPprange pprDbBean = getPprangeToUpdate();
            pprDbBean.wherePrefixPlanIdEQ(getPrefixPlanId());
            pprDbBean.whereRangeStartEQ(getRangeStart());
            pprDbBean.updateSpByWhere(connection);

    	} 
		catch(SQLException s) 
		{
        	s.printStackTrace();
            setStatus(InvErrorCode.DB_EXCEPTION);
            return false;
     	}

        setStatus(InvErrorCode.SUCCESS);
		log.info("Successfully Updated Prefix Plan Range By Prefix Plan Id [" + getPrefixPlanId() + "]");
        return true;
  	}

	private DBTblVzbPprange getPprangeToUpdate() throws SQLException
	{
		log.info("Entering getPprangeToUpdate");
		DBTblVzbPprange pprDbBean = new DBTblVzbPprange();
		PPRangeBean defaultPPRBean = new PPRangeBean();
		PPRange ppr = this;

		pprDbBean.setPrefixPlanId(getPrefixPlanId());
		if(ppr.getRangeEnd() != null && isNumber(ppr.getRangeEnd()) && 
            ! ppr.getRangeEnd().equals(defaultPPRBean.getRangeEnd()))
        {	
			pprDbBean.setRangeEnd(ppr.getRangeEnd());
		}
		if(ppr.getNumstrip() != defaultPPRBean.getNumstrip())
		{
			pprDbBean.setNumstrip(ppr.getNumstrip());
		}
		if(ppr.getAddPrefix() != null &&
            ! ppr.getAddPrefix().equals(defaultPPRBean.getAddPrefix()))
        {
            pprDbBean.setAddPrefix(ppr.getAddPrefix());
        }
		if(ppr.getNoa() != defaultPPRBean.getNoa())
        {
            pprDbBean.setNoa(ppr.getNoa());
        }
		if(ppr.getBlkstat() != defaultPPRBean.getBlkstat())
        {
            pprDbBean.setBlkstat(ppr.getBlkstat());
        }
		if(ppr.getModifiedBy() != null && !("".equalsIgnoreCase(defaultPPRBean.getModifiedBy())))
			pprDbBean.setModifiedBy(getModifiedBy());
		else
			pprDbBean.setModifiedBy("ESAP_INV");
		pprDbBean.setLastModifiedDate(new Timestamp(System.currentTimeMillis()));

		log.info("Successfully Retrieved Prefix Plan Range");
		return pprDbBean;	
	}

	public boolean isNumber(String range)
	{
		try
		{
			Integer.parseInt(range);
			return true;
		}
		catch (Exception e)
		{
			log.info("Range [" + range + "] Not numeric");
			return false;
		}
	}
	
	public boolean isRangeValidForAddMod(long prefixPlanId, String rangeStart, String rangeEnd, String action) throws Exception
	{
		log.info(" prefixPlanId : " + prefixPlanId + " rangeStart : " + rangeStart +  
				" rangeEnd : " + rangeEnd + " action : " + action );
		boolean checkMod = false;
		if ( action != null && action.equals("MOD")){
			TblVzbPprangeQuery tblVzbPpRangeQuery = new TblVzbPprangeQuery();
			tblVzbPpRangeQuery.whereRangeStartEQ(rangeStart);
			tblVzbPpRangeQuery.whereRangeEndEQ(rangeEnd);
			tblVzbPpRangeQuery.wherePrefixPlanIdEQ(prefixPlanId);
			tblVzbPpRangeQuery.query(connection);
			
			log.info(" Size " + tblVzbPpRangeQuery.size());
			if ( tblVzbPpRangeQuery.size() > 0){
				log.info(" Exact match found for MOD with " + "prefixPlanId : " + prefixPlanId + " rangeStart : " + rangeStart +  
					" rangeEnd : " + rangeEnd);
				return true;
			}else {
				checkMod = true;
			}
					
		}
		
		if (checkMod || (action != null && action.equals("ADD")) ){
			
			PreparedStatement pstmt = null;
			ResultSet rs = null;
			StringBuffer sql = new StringBuffer();

			sql.append(" select * from tbl_vzb_pprange where (( ");
			sql.append("? between to_number(range_start) and to_number(range_end)) or ( " );
			sql.append("? between to_number(range_start) and to_number(range_end))) and prefix_plan_id=?" );
			sql.append(" UNION ");
			sql.append(" select * from tbl_vzb_pprange ");
			sql.append(" where(to_number(range_start) between ? and ?) and (to_number(range_end) between ? and ?)" );
			sql.append(" and prefix_plan_id=?" );
			
			log.info(" sql " + sql.toString());
			
			try {
				pstmt = connection.prepareStatement(sql.toString());
				pstmt.setString(1, rangeStart);
				pstmt.setString(2, rangeEnd);
				pstmt.setLong(3, prefixPlanId);
				pstmt.setString(4, rangeStart);
				pstmt.setString(5, rangeEnd);
				pstmt.setString(6, rangeStart);
				pstmt.setString(7, rangeEnd);
				pstmt.setLong(8, prefixPlanId);
				
				rs = pstmt.executeQuery();
				if (rs.next()) {
					return false;
				}else{
					return true;
				}
				
				
			} catch (Exception e) {
				e.printStackTrace();
				throw e;
			}finally{
				if ( pstmt != null)
				pstmt.close();
				
				if ( rs != null )
					rs.close();
			}
		}
		
		return false;
	}

}
