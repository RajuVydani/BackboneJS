package com.vz.fxo.inventory.tn.model;

public class ResponseObject {
	public final static int SUCCESS = 1;
	public final static int FAILURE = 2;
	
	int statusCode;
	public int getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(int statusCode) {
		this.statusCode = statusCode;
	}
	public String getStatusDescription() {
		return statusDescription;
	}
	public void setStatusDescription(String statusDescription) {
		this.statusDescription = statusDescription;
	}
	String statusDescription;
}
