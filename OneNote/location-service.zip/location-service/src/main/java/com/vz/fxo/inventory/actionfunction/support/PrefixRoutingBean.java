package com.vz.fxo.inventory.actionfunction.support;

public class PrefixRoutingBean
{
		protected int prefixId;
        protected String enterpriseId;
		
        //Sabareesh
        protected String locationId;
        protected long prefixType;
        protected String interLocationPrefix;
        protected long interLocationExtLength;
        protected String interLocationPrefixAdd;
        protected long interLocationDigitStrip; 
        protected long envOrderId;

        //add all dial plan attributes
        protected String createdBy;
        protected String modifiedBy;
        protected java.sql.Timestamp creationDate;
        protected java.sql.Timestamp lastModifiedDate;

        /**
    	 * Default Constructor -- Initializes all fields to default values.
    	 */
        public PrefixRoutingBean() {
		this.prefixId = 0;
		this.enterpriseId = new String("");
		this.locationId = new String("NONE");
		this.prefixType = -1;
		this.interLocationPrefix = new String("NONE");
		this.interLocationExtLength = -1;
		this.interLocationPrefixAdd = new String("NONE");
		this.interLocationDigitStrip = -1;
		this.createdBy = new String("");
		this.modifiedBy = new String("");
		this.creationDate = null;
		this.lastModifiedDate = null;
		this.envOrderId = 0;
	}
    	/**
    	 * Constructor
    	 * @param prefixRoutingBean
    	 */
    	public PrefixRoutingBean(PrefixRoutingBean prefixRoutingBean) {
    		this.prefixId = prefixRoutingBean.prefixId;
    		this.enterpriseId = prefixRoutingBean.enterpriseId;
    		this.locationId = prefixRoutingBean.locationId;
    		this.prefixType = prefixRoutingBean.prefixType;
    		this.interLocationPrefix = prefixRoutingBean.interLocationPrefix;
    		this.interLocationExtLength = prefixRoutingBean.interLocationExtLength;
    		this.interLocationPrefixAdd = prefixRoutingBean.interLocationPrefixAdd;
    		this.interLocationDigitStrip = prefixRoutingBean.interLocationDigitStrip;
    		this.createdBy = prefixRoutingBean.createdBy;
    		this.modifiedBy = prefixRoutingBean.modifiedBy;
    		this.creationDate = prefixRoutingBean.creationDate;
    		this.lastModifiedDate = prefixRoutingBean.lastModifiedDate;
		this.envOrderId = prefixRoutingBean.envOrderId;
    	}

        public java.sql.Timestamp getCreationDate() {
			return creationDate;
		}


		public void setCreationDate(java.sql.Timestamp creationDate) {
			this.creationDate = creationDate;
		}

	public String getEnterpriseId(){
        	return enterpriseId;
        }
        public void setEnterpriseId(String enterpriseId){
        	this.enterpriseId = enterpriseId;
        }
        public int getPrefixId(){
        	return prefixId;
        }
        public void setPrefixId(int prefixId){
        	this.prefixId = prefixId;
        }
        public String getLocationId(){
        	return locationId;
        }
        public void setLocationId(String locationId){
        	this.locationId = locationId;
        }
        public long getPrefixType(){
        	return prefixType;
        }
        public void setPrefixType(long prefixType){
        	this.prefixType = prefixType;
        }
        public String getInterLocationPrefix(){
        	return interLocationPrefix;
        }
        public void setInterLocationPrefix(String interLocationPrefix){
        	this.interLocationPrefix = interLocationPrefix;
        }
        public long getInterLocationExtLength(){
        	return interLocationExtLength;
        }
        public void setInterLocationExtLength(long interLocationExtLength){
        	this.interLocationExtLength = interLocationExtLength;
        }
        public String getInterLocationPrefixAdd(){
        	return interLocationPrefixAdd;
        }
        public void setInterLocationPrefixAdd(String interLocationPrefixAdd){
        	this.interLocationPrefixAdd = interLocationPrefixAdd;
        }
        public long getInterLocationDigitStrip(){
        	return interLocationDigitStrip;
        }
        public void setInterLocationDigitStrip(long interLocationDigitStrip){
        	this.interLocationDigitStrip = interLocationDigitStrip;
        }
    	public String getCreatedBy() {
    		return createdBy;
    	}
    	public void setCreatedBy(String createdBy) {
    		this.createdBy = createdBy;
    	}
    	public String getModifiedBy() {
    		return modifiedBy;
    	}
    	public void setModifiedBy(String modifiedBy) {
    		this.modifiedBy = modifiedBy;
    	}
    	public java.sql.Timestamp getLastModifiedDate()
    	{
    		return lastModifiedDate;
    	}

    	public void setLastModifiedDate(java.sql.Timestamp lastModifiedDate)
    	{
    		this.lastModifiedDate = lastModifiedDate;
    	}

    	public long getEnvOrderId() {
    		return envOrderId;
    	}
    	public void setEnvOrderId(long envOrderId) {
    		this.envOrderId = envOrderId;
    	}
    	public void initilizeTODefault() {
    		this.locationId = new String("");
    		this.prefixType = 0;
    		this.interLocationPrefix = new String("");
    		this.interLocationExtLength = 0;
    		this.interLocationPrefixAdd = new String("");
    		this.interLocationDigitStrip = 0;
    		this.createdBy = new String("");
    		this.modifiedBy = new String("");
    		this.creationDate = null;
    		this.lastModifiedDate = null;
    		this.envOrderId = 0;
    	}
}

