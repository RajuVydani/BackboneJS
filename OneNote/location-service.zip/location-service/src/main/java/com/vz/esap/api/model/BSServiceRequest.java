package com.vz.esap.api.model;

import java.io.Serializable;


/**
 * Request Entity class for BroadSoft Service . 
 * 
 * @author Deepak Kumar
 *
 */
public class BSServiceRequest implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String workOrderNumber; //ENTUSE2EIPBX00001710120951 
	private String workOrderNumberVersion; //{0,1,2,3}
	private String orderNumber; //ORDER_NUMBER:334122170 //TABLE_ORDER_ID
	private String seqNo;
	private String task;
	private String service;
	//SEQNO:5
	//TASK:VZB_BS_AUTHORIZE_LOC_FEATURES
	//ACTION_FUNCTION:esap.vzbvoip.rivactionfunction.broadsoft17.VZB_BS_AUTHORIZE_LOC_FEATURES_17
	//SERVICE_NAME:VZB_BS_ADD_LOCATION
	private String device; //DEVICE:DEV_RIVISTBSF01_36
	private String clliCode; //CLLI_CODE:RIVISTBSF01
	private String connType ; //CONNECTION_TYPE:DeviceProxy_VZBAS
	private String sftwrLoad ;//SFTWR_LOAD:17.0
	private int asyncFlag ; //ASYNC_FLAG:0
	private String loopBackOn; //LOOPBACK_ON:0;
	private String envOrderId;
	private String orderType; //{I,C,O}
	private String entityType; //{ET_TN,PBX_TN,KEY_TN,LOCATION,ENTERPRISE}
	
	
	public String getOrderNumber() {
		return orderNumber;
	}
	public void setOrderNumber(String orderNumber) {
		this.orderNumber = orderNumber;
	}
	public String getDevice() {
		return device;
	}
	public void setDevice(String device) {
		this.device = device;
	}
	public String getClliCode() {
		return clliCode;
	}
	public void setClliCode(String clliCode) {
		this.clliCode = clliCode;
	}
	public String getConnType() {
		return connType;
	}
	public void setConnType(String connType) {
		this.connType = connType;
	}
	public String getSftwrLoad() {
		return sftwrLoad;
	}
	public void setSftwrLoad(String sftwrLoad) {
		this.sftwrLoad = sftwrLoad;
	}
	public int getAsyncFlag() {
		return asyncFlag;
	}
	public void setAsyncFlag(int asyncFlag) {
		this.asyncFlag = asyncFlag;
	}
	public String getLoopBackOn() {
		return loopBackOn;
	}
	public void setLoopBackOn(String loopBackOn) {
		this.loopBackOn = loopBackOn;
	}
	public String getEnvOrderId() {
		return envOrderId;
	}
	public void setEnvOrderId(String envOrderId) {
		this.envOrderId = envOrderId;
	}
	/**
	 * @return the workOrderNumber
	 */
	public String getWorkOrderNumber() {
		return workOrderNumber;
	}
	/**
	 * @param workOrderNumber the workOrderNumber to set
	 */
	public void setWorkOrderNumber(String workOrderNumber) {
		this.workOrderNumber = workOrderNumber;
	}
	/**
	 * @return the workOrderNumberVersion
	 */
	public String getWorkOrderNumberVersion() {
		return workOrderNumberVersion;
	}
	/**
	 * @param workOrderNumberVersion the workOrderNumberVersion to set
	 */
	public void setWorkOrderNumberVersion(String workOrderNumberVersion) {
		this.workOrderNumberVersion = workOrderNumberVersion;
	}
	/**
	 * @return the seqNo
	 */
	public String getSeqNo() {
		return seqNo;
	}
	/**
	 * @param seqNo the seqNo to set
	 */
	public void setSeqNo(String seqNo) {
		this.seqNo = seqNo;
	}
	/**
	 * @return the task
	 */
	public String getTask() {
		return task;
	}
	/**
	 * @param task the task to set
	 */
	public void setTask(String task) {
		this.task = task;
	}
	/**
	 * @return the service
	 */
	public String getService() {
		return service;
	}
	/**
	 * @param service the service to set
	 */
	public void setService(String service) {
		this.service = service;
	}
	/**
	 * @return the orderType
	 */
	public String getOrderType() {
		return orderType;
	}
	/**
	 * @param orderType the orderType to set
	 */
	public void setOrderType(String orderType) {
		this.orderType = orderType;
	}
	/**
	 * @return the entityType
	 */
	public String getEntityType() {
		return entityType;
	}
	/**
	 * @param entityType the entityType to set
	 */
	public void setEntityType(String entityType) {
		this.entityType = entityType;
	}
	
	
}
