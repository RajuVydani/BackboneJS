/**
 * 
 */
package com.vz.fxo.inventory.actionfunction.support;
import java.io.Serializable;
import java.sql.Timestamp;

/**
 * @author v034934
 *
 */
public class FmcgDeviceBean implements Serializable {
	protected int fmcgDeviceId;
	protected int fmcgVendorId;
    protected String brand;
	protected String model;
	protected long fmcgType;
	protected String fmcgVendorName;
    protected String besSupport;
	protected String createdBy;
	protected Timestamp creationDate;
	protected String modifiedBy;
	protected Timestamp lastModifiedDate;
	
	/**
	 * 
	 *Default Constructor -- Initializes all fields to default values.
	 */
    public FmcgDeviceBean() {
            this.fmcgDeviceId = 0;
            this.fmcgVendorId = 0;
            this.brand = new String("");
            this.model = new String("");
            this.besSupport = new String("N");
            this.fmcgType = 0;
            this.createdBy = new String("");
            this.modifiedBy = new String("");
            this.creationDate = null;
            this.lastModifiedDate = null;
            this.fmcgVendorName = new String();
    }
	
	/**
	 * Constructor
	 * @param fmcgDeviceDbBean
	 */
	public FmcgDeviceBean(FmcgDeviceBean fmcgDeviceBean) {
		this.fmcgDeviceId = fmcgDeviceBean.fmcgDeviceId;
		this.fmcgVendorId = fmcgDeviceBean.fmcgVendorId;
		this.brand = fmcgDeviceBean.brand;
		this.model = fmcgDeviceBean.model;
        this.besSupport = fmcgDeviceBean.besSupport;
		this.fmcgType = fmcgDeviceBean.fmcgType;
		this.createdBy = fmcgDeviceBean.createdBy;
		this.creationDate = fmcgDeviceBean.creationDate;
		this.modifiedBy = fmcgDeviceBean.modifiedBy;
		this.lastModifiedDate = fmcgDeviceBean.lastModifiedDate;
		this.fmcgVendorName = fmcgDeviceBean.fmcgVendorName;
	}
	
	public int getFmcgVendorId()
    {
        return fmcgVendorId;
    }

    public void setFmcgVendorId(int fmcgVendorId)
    {
        this.fmcgVendorId = fmcgVendorId;
    }
	public String getBrand() {
		return brand;
	}
	public void setBrand(String brand) {
		this.brand = brand;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public Timestamp getCreationDate() {
		return creationDate;
	}
	public void setCreationDate(Timestamp creationDate) {
		this.creationDate = creationDate;
	}
	public int getFmcgDeviceId() {
		return fmcgDeviceId;
	}
	public void setFmcgDeviceId(int fmcgDeviceId) {
		this.fmcgDeviceId = fmcgDeviceId;
	}
	public long getFmcgType() {
		return fmcgType;
	}
	public void setFmcgType(long fmcgType) {
		this.fmcgType = fmcgType;
	}
	public Timestamp getLastModifiedDate() {
		return lastModifiedDate;
	}
	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
    public String getBesSupport() {
		return besSupport;
	}
	public void setBesSupport(String besSupport) {
		this.besSupport = besSupport;
	}
	public String getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	
	public String getFmcgVendorName() {
		return fmcgVendorName;
	}
	
	public void setFmcgVendorName(String fmcgVendorName) {
		this.fmcgVendorName = fmcgVendorName;
	}
	
	public String toString(){
		StringBuilder sb = new StringBuilder();
		String nl = System.getProperty("line.separator");
		
		sb.append(nl)
		.append("fmcgDeviceId: 		").append(fmcgDeviceId).append(nl)
		.append("fmcgVendorId:      ").append(fmcgVendorId).append(nl)
		.append("brand:    			").append(brand).append(nl)
		.append("model:         	").append(model).append(nl)
		.append("besSupport:        ").append(besSupport).append(nl)
		.append("fmcgVendorName:    ").append(fmcgVendorName).append(nl)
		.append("fmcgType:  		").append(fmcgType).append(nl)
		.append("createdBy:   		").append(createdBy).append(nl)
		.append("creationDate:  	").append(creationDate).append(nl)
		.append("modifiedBy:   		").append(modifiedBy).append(nl)
		.append("lastModifiedDate:  ").append(lastModifiedDate).append(nl);
		
		return sb.toString();
	}
	
}
