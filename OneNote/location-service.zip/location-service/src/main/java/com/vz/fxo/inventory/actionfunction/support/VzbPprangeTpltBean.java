package com.vz.fxo.inventory.actionfunction.support;

import java.util.List;

public class VzbPprangeTpltBean {
	


	protected String cntryCode;
	protected String region;
	protected short platformIndicator;
	protected String prefixName;
	protected String rangeStart;
	protected String rangeEnd;
	protected long numstrip;
	protected String addPrefix;
	protected long noa;
	protected long blkstat;
	protected String createdBy;
	protected java.sql.Timestamp creationDate;
	protected String modifiedBy;
	protected java.sql.Timestamp lastModifiedDate;
	protected List<VzbPprangeTpltBean> vzbPprangeTpltBeanList;
	
	public VzbPprangeTpltBean(){
		cntryCode = "NONE";
		region = "NONE";
		platformIndicator = -1;
		prefixName = "NONE";
		rangeStart = "NONE";
		rangeEnd = "NONE";
		numstrip = -1;
		addPrefix = "NONE";
		noa = -1;
		blkstat = -1;
		createdBy = "NONE";
		creationDate = null;
		modifiedBy = null;
		lastModifiedDate = null;
		this.vzbPprangeTpltBeanList = null;
	}
	
	public VzbPprangeTpltBean(VzbPprangeTpltBean vzbPprangeTpltBean){
		this.cntryCode = vzbPprangeTpltBean.cntryCode;
		this.region = vzbPprangeTpltBean.region;
		this.platformIndicator = vzbPprangeTpltBean.platformIndicator;
		this.prefixName = vzbPprangeTpltBean.prefixName;
		this.rangeStart = vzbPprangeTpltBean.rangeStart;
		this.rangeEnd = vzbPprangeTpltBean.rangeEnd;
		this.numstrip = vzbPprangeTpltBean.numstrip;
		this.addPrefix = vzbPprangeTpltBean.addPrefix;
		this.noa = vzbPprangeTpltBean.noa;
		this.blkstat = vzbPprangeTpltBean.blkstat;
		this.createdBy = vzbPprangeTpltBean.createdBy;
		this.creationDate = vzbPprangeTpltBean.creationDate;
		this.modifiedBy = vzbPprangeTpltBean.modifiedBy;
		this.lastModifiedDate = vzbPprangeTpltBean.lastModifiedDate;
		this.vzbPprangeTpltBeanList = vzbPprangeTpltBean.vzbPprangeTpltBeanList;
	}
	
	public String toString() {
		return(""+"cntryCode="+cntryCode+"\n"+"region="+region+"\n"+"platformIndicator="+platformIndicator+"\n"+"prefixName="+prefixName+"\n"+"rangeStart="+rangeStart+"\n"+"numstrip="+numstrip+"\n"+"addPrefix="+addPrefix+"\n"+"noa="+noa+"\n"+"blkstat="+blkstat+"\n"+"createdBy="+createdBy+"\n"+"creationDate="+creationDate+"\n"+"modifiedBy="+modifiedBy+"\n"+"lastModifiedDate="+lastModifiedDate+"\n");
	}
	public void setCntryCode(String cntryCode) {
		this.cntryCode = cntryCode;
	}
	public String getCntryCode(){
		return this.cntryCode;
	}
	public void setRegion(String region) {
		this.region = region;
	}
	public String getRegion(){
		return this.region;
	}
	public void setPlatformIndicator(short platformIndicator) {
		this.platformIndicator = platformIndicator;
	}
	public short getPlatformIndicator(){
		return this.platformIndicator;
	}
	public void setPrefixName(String prefixName) {
		this.prefixName = prefixName;
	}
	public String getPrefixName(){
		return this.prefixName;
	}
	public void setRangeStart(String rangeStart) {
		this.rangeStart = rangeStart;
	}
	public String getRangeStart(){
		return this.rangeStart;
	}
	public void setRangeEnd(String rangeEnd) {
		this.rangeEnd = rangeEnd;
	}
	public String getRangeEnd(){
		return this.rangeStart;
	}
	public void setNumstrip(long numstrip) {
		this.numstrip = numstrip;
	}
	public long getNumstrip(){
		return this.numstrip;
	}
	public void setAddPrefix(String addPrefix) {
		this.addPrefix = addPrefix;
	}
	public String getAddPrefix(){
		return this.addPrefix;
	}
	public void setNoa(long noa) {
		this.noa = noa;
	}
	public long getNoa(){
		return this.noa;
	}
	public void setBlkstat(long blkstat) {
		this.blkstat = blkstat;
	}
	public long getBlkstat(){
		return this.blkstat;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public String getCreatedBy(){
		return this.createdBy;
	}
	public void setCreationDate(java.sql.Timestamp creationDate) {
		this.creationDate = creationDate;
	}
	public java.sql.Timestamp getCreationDate(){
		return this.creationDate;
	}
	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public String getModifiedBy(){
		return this.modifiedBy;
	}
	public void setLastModifiedDate(java.sql.Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}
	public java.sql.Timestamp getLastModifiedDate(){
		return this.lastModifiedDate;
	}
	
	
	public List<VzbPprangeTpltBean> getVzbPprangeTpltBeanList() {
		return vzbPprangeTpltBeanList;
	}

	public void setVzbPprangeTpltBeanList(
			List<VzbPprangeTpltBean> vzbPprangeTpltBeanList) {
		this.vzbPprangeTpltBeanList = vzbPprangeTpltBeanList;
	}



}
