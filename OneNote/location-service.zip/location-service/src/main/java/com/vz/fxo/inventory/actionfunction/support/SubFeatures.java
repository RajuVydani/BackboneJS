package com.vz.fxo.inventory.actionfunction.support;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Timestamp;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import EsapEnumPkg.VzbVoipEnum;
//import esap.vzbvoip.rivactionfunction.inventory.VzbInvException;
import esap.db.DBTblSubFeature;
import esap.db.DBTblSubscriber;
import esap.db.TblSubscriberQuery;


public class SubFeatures extends SubFeaturesBean
{
	
	private static Logger log = LoggerFactory.getLogger(SubFeatures.class.toString());
	private Connection connection;
	private long ReceptionistFeatures = 48;
    InvErrorCode statusCode = InvErrorCode.INTERNAL_ERROR;
	
	public SubFeatures(Connection con)
	{
		this.connection = con;
	}
	public SubFeatures(Connection con, SubFeaturesBean subFeatBean)
	{
		super(subFeatBean);
		this.connection = con;
	}
	
	public Connection getConnection() {
		return connection;
	}

	public void setConnection(Connection connection) {
		this.connection = connection;
	}

        public int getStatusCode() {
		return statusCode.getErrorCode();
	}
	public void setStatusCode(InvErrorCode statusCode) {
		this.statusCode = statusCode;
	}
/*	public String getStatusDesc() {
		return statusDesc;
	}

	public void setStatusDesc(String statusDesc) {
		this.statusDesc = statusDesc;
	}
	*/

	public boolean validateSubFeatures()
	{
		return true;
	}
	
	public boolean addSubFeatures()
	{
		log.info("Entering SubFeatures::addSubFeatures");
		
		try
		{
			DBTblSubFeature subFeatDB = new DBTblSubFeature();
			int subFeatSeqId = subFeatDB.getSubFeatureIdSeqNextVal(connection);
			subFeatDB.setSubFeatureId(subFeatSeqId);
			log.info("subFeatSeqId:"+subFeatSeqId);
			
			log.info("subId:"+subId);
			if(!subId.equals(""))
			{
				subFeatDB.setSubId(subId);
			}
			if(featureId > 0)
				subFeatDB.setFeatureId(featureId);
			log.info("featureId:"+featureId);
			if(selected != "" && !"NONE".equals(getEnvOrderId()) )
				subFeatDB.setIsSelected(selected);
	                if(getEnvOrderId() > 0)
				subFeatDB.setEnvOrderId(getEnvOrderId()); 	
                  	if(!createdBy.equals(""))
				subFeatDB.setCreatedBy(createdBy);
			else
				subFeatDB.setCreatedBy("ESAP_INV");
			if(!modifiedBy.equals(""))
				subFeatDB.setModifiedBy(modifiedBy);
			else
		    	subFeatDB.setModifiedBy("ESAP_INV");
			
			subFeatDB.setCreationDate(new Timestamp(System.currentTimeMillis()));
		    subFeatDB.setLastModifiedDate(new Timestamp(System.currentTimeMillis()));
		    if( getEnvOrderId()  != -1 )
		    	subFeatDB.setEnvOrderId(getEnvOrderId());
		    subFeatDB.insert(connection);

		    log.info("Add Features FeatureId " + featureId);
			if (featureId  == ReceptionistFeatures){ // Feature is Receptionist
		    	log.info("Before calling updateReceptionistTypeFlag subscriberObj.getSubId() in Add Features " + subId);
		    	updateReceptionistTypeFlag(subId,"n");
		    }
		  
		}
		catch(SQLException s)
		{
			s.printStackTrace();	
			setStatusCode(InvErrorCode.DB_EXCEPTION);
			return false;
		}catch(Exception e){
			e.printStackTrace();	
			setStatusCode(InvErrorCode.DB_EXCEPTION);
			return false;
		}
		return true;
	}
	
        public boolean deleteSubFeatures()
	{
		try {
			log.info("getSubFeatureId() Value i==>" +getSubFeatureId());
			log.info("getSubId() Value i==>" +getSubId());
			if(getSubFeatureId() <= 0 )
			{
				if(getSubId() == null || getSubId().equals("") || getFeatureId() <= 0)
				{
					setStatusCode(InvErrorCode.INVALID_INPUT);
					return false;
				}
			}

			DBTblSubFeature subFeatureDbBean = new DBTblSubFeature();
			if(getSubFeatureId() > 0)
			{
				log.info("getSubFeatureId():"+getSubFeatureId());
				subFeatureDbBean.whereSubFeatureIdEQ(getSubFeatureId());
			}
			else
			{
				log.info("getSubId():"+getSubId()+"getFeatureId()"+getFeatureId());
				subFeatureDbBean.whereSubIdEQ(getSubId());
				subFeatureDbBean.whereFeatureIdEQ(getFeatureId());
			}
			int i = subFeatureDbBean.deleteByWhere(connection);
			log.info("No of sub features deleted:"+i);

			log.info("Delete Features FeatureId " + getFeatureId());
			if (getFeatureId() == ReceptionistFeatures){ // Feature is Receptionist
				log.info("Before calling updateReceptionistTypeFlag subscriberObj.getSubId() in Delete Features " + getSubId());
				updateReceptionistTypeFlag(getSubId(),"o");
			}
		}
		catch (SQLException s) {
			s.printStackTrace();
			setStatusCode(InvErrorCode.DB_EXCEPTION);
			log.info("DB_FAILURE in deleteSubFeatures");
			return false;
		}catch(Exception e){
			e.printStackTrace();	
			setStatusCode(InvErrorCode.DB_EXCEPTION);
			return false;
		}
		
		setStatusCode(InvErrorCode.SUCCESS);
		return true;
	}	
	public boolean updateSubFeature()
	{
		log.info("Entering SubFeatures::updateSubFeature");
		
		try
		{

			if(getSubFeatureId() <= 0)
                        {
                                setStatusCode(InvErrorCode.INVALID_INPUT);
                                return false;
                        }

			DBTblSubFeature subFeatDB = new DBTblSubFeature();
			/*int subFeatSeqId = subFeatDB.getSubFeatureIdSeqNextVal(connection);
			subFeatDB.setSubFeatureId(subFeatSeqId);*/
			
			if(subId != "")
				subFeatDB.setSubId(subId);
			if(featureId > 0)
				subFeatDB.setFeatureId(featureId);
			if(selected != "")
				subFeatDB.setIsSelected(selected);
			else
				subFeatDB.setIsSelectedNull();
			
               if(getEnvOrderId() > 0)
				subFeatDB.setEnvOrderId(envOrderId);  
               else
            	   subFeatDB.setEnvOrderIdNull();
               
           		if(modifiedBy != null && !"".equals(modifiedBy) )
				subFeatDB.setModifiedBy(modifiedBy);
			else
		    		subFeatDB.setModifiedBy("ESAP_INV");
			
		    subFeatDB.setLastModifiedDate(new Timestamp(System.currentTimeMillis()));
	  	    subFeatDB.whereSubFeatureIdEQ(getSubFeatureId());
		    subFeatDB.updateSpByWhere(connection);	
		    //subFeatDB.update(connection);
		  
		}
		catch(SQLException s)
		{
			s.printStackTrace();	
			setStatusCode(InvErrorCode.DB_EXCEPTION);
			return false;
		}
		log.info("Successfully Updated Subscriber Feature");
		return true;
	}

	public void updateReceptionistTypeFlag(String subId, String receptionistFlag)
	throws SQLException, Exception {

		log.info("Entering updateReceptionistTypeFlag in SubFeature Class");
		log.info("receptionTypeflag " + receptionistFlag);

		TblSubscriberQuery subQry = new TblSubscriberQuery();
		String subWhereCls = " where sub_id = \'" + subId + "\'";
		subQry.queryByWhere(connection, subWhereCls);

		log.info("subQry.size() " + subQry.size());
		if (subQry.size() > 0) {
			long receptionistType = subQry.getDbBean(0).getReceptionistType();
			log.info(" receptionistType " + receptionistType);
			// logTrailList.add("receptionistType " + receptionistType);
			if (receptionistType <= 0) {
				if ("n".equals(receptionistFlag)) {
					DBTblSubscriber tblSubscriber = new DBTblSubscriber();
					tblSubscriber.setReceptionistType((short) VzbVoipEnum.ReceptionistType.DYNAMIC);
					tblSubscriber.whereSubIdEQ(subId);
					if (tblSubscriber.updateSpByWhere(connection) <= 0) {
						log.info("Failed to Update ReceptionistType Subscriber");
						throw new Exception(
								"VZB_INV_RECEPTIONIST_TYPE_UPDATED_FAILED -	Receptionist Type failed  to set Dynamic in Inv");
					}
				}
			} else {
				if ("o".equals(receptionistFlag)) {
					DBTblSubscriber tblSubscriber = new DBTblSubscriber();
					tblSubscriber.setReceptionistTypeNull();
					tblSubscriber.whereSubIdEQ(subId);
					if (tblSubscriber.updateSpByWhere(connection) <= 0) {
						log.info("Failed to Update ReceptionistType Subscriber");
						throw new Exception(
								"VZB_INV_RECEPTIONIST_TYPE_UPDATED_FAILED -	Receptionist Type failed  to set Null in Inv ");
					}
				}
			}

		}
	}

}

