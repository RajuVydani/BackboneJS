/**
 * ESAPDataManagerProps.java
 * esap.vzbvoip.migration.api.esap
 */
package com.vz.fxo.inventory.actionfunction.support;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;


public class ESAPDataManagerProps {
	  private String sqlServerDriver = null;
	  private String ssiUrl = null;
	  private String ssiDbUser = null;
	  private String ssiDbPassword = null;
	 
	  public static final String SQL_SERVER_DRIVER = "SQL_SERVER_DRIVER";
	  public static final String SSI_MIG_PWD = "SSI_MIG_PWD";
	  public static final String SSI_MIG_UID = "SSI_MIG_UID";
	  public static final String SSI_MIG_URL = "SSI_MIG_URL";
	  public static final String ORACLE_DRIVER = "ORACLE_DRIVER";
	

	 
	 /**
	 * @Param Connection
	 * @description: 
	 * @return void
	 * @throws Exception
	 * @author 
	 * @editedby
	 */
	public void getSSIConnProperties(Connection con)throws Exception {
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		 try {
			 	ps = con.prepareStatement("select PARAM_NAME, PARAM_VALUE from tbl_Config_params " +
			"where  param_name in " +
			"('SSI_MIG_URL','SSI_MIG_UID','SSI_MIG_PWD','SQL_SERVER_DRIVER') " +
			"and process_name = 'RIV MIGRATION' order by 1");
						 	
			 	rs = ps.executeQuery();

			 	if(rs!=null) {
			 		while(rs.next()) {
			 			
			 			if(rs.getString("PARAM_NAME")!=null && SQL_SERVER_DRIVER.equals(rs.getString("PARAM_NAME")))
		 					setSqlServerDriver(rs.getString("PARAM_VALUE"));
			 			if(rs.getString("PARAM_NAME")!=null && SSI_MIG_URL.equals(rs.getString("PARAM_NAME")))
		 					setSsiUrl(rs.getString("PARAM_VALUE"));
			 			if(rs.getString("PARAM_NAME")!=null && SSI_MIG_UID.equals(rs.getString("PARAM_NAME")))
		 					setSsiDbUser(rs.getString("PARAM_VALUE"));
			 			if(rs.getString("PARAM_NAME")!=null && SSI_MIG_PWD.equals(rs.getString("PARAM_NAME")))
		 					setSsiDbPassword(rs.getString("PARAM_VALUE"));
			 		}
			 	}
		 }catch(Exception e) {
			 throw e;
		 }finally {
			 if(rs!=null) {
				 rs.close();
				 rs = null;
			 }
			 if(ps!=null) {
				 ps.close();
				 ps = null;
			 }
			 
		 }
		 
	 }
	  public String toString() {
		StringBuilder toString = new StringBuilder(500);
	    toString.append("================================================").append("\n");
		
		toString.append("sqlServerDriver   =").append(getSqlServerDriver()).append("\n");
	    toString.append("ssiJdbcUrl        =").append(getSsiUrl()).append("\n");
		toString.append("ssiDbUser         =").append(getSsiDbUser()).append("\n");
	    toString.append("ssiDbPassword     =").append("xxxxxxx").append("\n");
	    return toString.toString();
	  }
	
	/**
	 * @return the sqlServerDriver
	 */
	public String getSqlServerDriver() {
		return this.sqlServerDriver;
	  }


	/**
	 * @param sqlServerDriver the sqlServerDriver to set
	 */
	public void setSqlServerDriver(String sqlServerDriver) {
		this.sqlServerDriver = sqlServerDriver;
	  }


	/**
	 * @return the ssiUrl
	 */
	public String getSsiUrl() {
		return this.ssiUrl;
	}
	/**
	 * @param ssiUrl the ssiUrl to set
	 */
	public void setSsiUrl(String ssiUrl) {
		this.ssiUrl = ssiUrl;
	}
	/**
	 * @return the ssiDbUser
	 */
	public String getSsiDbUser() {
		return this.ssiDbUser;
	  }
	/**
	 * @param ssiDbUser the ssiDbUser to set
	 */
	public void setSsiDbUser(String ssiDbUser) {
		this.ssiDbUser = ssiDbUser;
	  }
	/**
	 * @return the ssiDbPassword
	 */
	public String getSsiDbPassword() {
		return this.ssiDbPassword;
	  }

	/**
	 * @param ssiDbPassword the ssiDbPassword to set
	 */
	public void setSsiDbPassword(String ssiDbPassword) {
		this.ssiDbPassword = ssiDbPassword;
	  }

}
