package com.vz.fxo.inventory.actionfunction.support;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
public class ServerConnectionInfo {
    public String getInteractiveKeyboard() {
        return interactiveKeyboard;
    }
    public void setInteractiveKeyboard(String interactiveKeyboard) {
        this.interactiveKeyboard = interactiveKeyboard;
    }
    private String hostName = null;
    private int port = 22;
    private String userName = null;
    private String password = null;
    private String terminalType = null;
    private int timeOut = 10;
    private ServerConnectionType type;
    private String loginSequence = null;
    private String interactiveKeyboard = null;
    private Map parameters = null;
    private boolean loopback;
    public ServerConnectionInfo() {
        parameters = new HashMap();
    }
    public String toString() {
        StringBuffer buffer = new StringBuffer();
        buffer.append("Terminal Information\n");
        ;
        buffer.append("HostName=").append(hostName).append("\n");
        buffer.append("port=").append(port).append("\n");
        buffer.append("userName=").append(userName).append("\n");
        buffer.append("password=").append(password).append("\n");
        buffer.append("terminalType=").append(terminalType).append("\n");
        buffer.append("TimeOut=").append(timeOut).append("\n");
        buffer.append("Connection type=").append(type).append("\n");
        buffer.append("Loopback=").append(loopback).append("\n");
        buffer.append("LoginSequence=").append(loginSequence).append("\n");
        buffer.append("interactiveKeyboard=").append(interactiveKeyboard).append("\n");
        if (null != parameters && parameters.size() > 0) {
            for (Iterator j = parameters.entrySet().iterator(); j.hasNext();) {
                Map.Entry e = (Map.Entry) j.next();
                buffer.append("ParamName=").append(e.getKey()).append(" ParamValue=").append(e.getValue()).append("\n");
            }
        } else {
            buffer.append("Parameter List is Empty").append("\n");
        }
        return buffer.toString();
    }
    public String getHostName() {
        return hostName;
    }
    public void setHostName(String hostName) {
        this.hostName = hostName;
    }
    public int getPort() {
        return port;
    }
    public void setPort(int port) {
        this.port = port;
    }
    public String getUserName() {
        return userName;
    }
    public void setUserName(String userName) {
        this.userName = userName;
    }
    public String getPassword() {
        return password;
    }
    public void setPassword(String password) {
        this.password = password;
    }
    public int getTimeOut() {
        return timeOut;
    }
    public void setTimeOut(int timeOut) {
        this.timeOut = timeOut;
    }
    public String getTerminalType() {
        return terminalType;
    }
    public void setTerminalType(String terminalType) {
        this.terminalType = terminalType;
    }
    public ServerConnectionType getType() {
        return type;
    }
    public void setType(ServerConnectionType type) {
        this.type = type;
    }
    public String getLoginSequence() {
        return loginSequence;
    }
    public void setLoginSequence(String loginSequence) {
        this.loginSequence = loginSequence;
    }
    public Map getParameters() {
        return parameters;
    }
    public void setParameters(Map parameters) {
        this.parameters = parameters;
    }
    public void addParameters(String key, String value) {
        if (null == parameters) {
            parameters = new HashMap();
        }
        parameters.put(key, value);
    }
    public boolean isLoopback() {
        return loopback;
    }
    public void setLoopback(boolean loopback) {
        this.loopback = loopback;
    }
}
