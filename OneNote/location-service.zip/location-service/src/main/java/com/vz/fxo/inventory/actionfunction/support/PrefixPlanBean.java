package com.vz.fxo.inventory.actionfunction.support;

import java.util.List;

public class PrefixPlanBean {
	protected String PPId;
	protected String locationId;
	protected String planName;
	protected int isDefault;
    
    protected String emergencyCall;
    protected String natureOfCall;
    protected String blockingStatus;
    protected int digitStrip;
    protected int digitAdded;
    protected int mobileUser;

    	/**
	 * Default Constructor -- Initializes all fields to default values.
	 */
	public PrefixPlanBean() {
		this.PPId = new String("");
		this.locationId = new String("");
		this.planName = new String("");
		this.isDefault = 0;
		this.emergencyCall = new String("");
		this.natureOfCall = new String("");
		this.blockingStatus = new String("");
		this.digitStrip = 0;
		this.digitAdded = 0;
		this.mobileUser = 0;
	}
	/**
	 * Constructor
	 * @param prefixPlanBean
	 */
	public PrefixPlanBean(PrefixPlanBean prefixPlanBean ) {
		this.PPId = prefixPlanBean.PPId;
		this.locationId = prefixPlanBean.locationId;
		this.planName = prefixPlanBean.planName;
		this.isDefault = prefixPlanBean.isDefault;
		this.emergencyCall = prefixPlanBean.emergencyCall;
		this.natureOfCall = prefixPlanBean.natureOfCall;
		this.blockingStatus = prefixPlanBean.blockingStatus;
		this.digitStrip = prefixPlanBean.digitStrip;
		this.digitAdded = prefixPlanBean.digitAdded;
		this.mobileUser = prefixPlanBean.mobileUser;
	}

	public PrefixPlanBean(String PPId, String locationId, String planName, int isDefault) {
		this.PPId = PPId;
		this.locationId = locationId;
		this.planName = planName;
		this.isDefault = isDefault;
	}

	public String getPPId() {
		return PPId;
	}

	public void setPPId(String PPId) {
		this.PPId = PPId;
	}

	public String getLocationId() {
		return locationId;
	}

	public void setLocationId(String locationId) {
		this.locationId = locationId;
	}

	public String getPlanName() {
		return planName;
	}

	public void setPlanName(String planName) {
		this.planName = planName;
	}

	public int getIsDefault() {
		return isDefault;
	}

	public void setIsDefault(int isDefault) {
		this.isDefault = isDefault;
	}
	
	public String getEmergencyCall() {
		return emergencyCall;
	}
	public void setEmergencyCall(String emergencyCall) {
		this.emergencyCall = emergencyCall;
	}
	public String getNatureOfCall() {
		return natureOfCall;
	}
	public void setNatureOfCall(String natureOfCall) {
		this.natureOfCall = natureOfCall;
	}
	public String getBlockingStatus() {
		return blockingStatus;
	}
	public void setBlockingStatus(String blockingStatus) {
		this.blockingStatus = blockingStatus;
	}
	public int getDigitStrip() {
		return digitStrip;
	}
	public void setDigitStrip(int digitStrip) {
		this.digitStrip = digitStrip;
	}
	public int getDigitAdded() {
		return digitAdded;
	}
	public void setDigitAdded(int digitAdded) {
		this.digitAdded = digitAdded;
	}
	public int getMobileUser() {
		return mobileUser;
	}
	public void setMobileUser(int mobileUser) {
		this.mobileUser = mobileUser;
	}
}

