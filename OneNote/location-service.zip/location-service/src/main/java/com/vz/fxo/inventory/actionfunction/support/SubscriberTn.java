package com.vz.fxo.inventory.actionfunction.support; 

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import EsapEnumPkg.VzbVoipEnum;
import EsapEnumPkg.VzbVoipEnum.SubscriberTnType;
import esap.db.DBTblSubscriberTn;
import esap.db.TblLocationQuery;
import esap.db.TblSubscriberQuery;
import esap.db.TblSubscriberTnQuery;



public class SubscriberTn extends SubscriberTnBean
{
	
	private static Logger log = LoggerFactory.getLogger(SubscriberTn.class.toString());
	//members
	private Connection connection;
	private InvErrorCode statusCode;
	//private String statusDesc;
	private  boolean rollbackFlag;
	private  boolean isExistingTn;
	private  boolean tnRemoveFlag;	
	
	public SubscriberTn(Connection con)
	{
		this.connection = con;
		this.rollbackFlag = false;
		this.isExistingTn = false;
		this.tnRemoveFlag = false;
	}
	public SubscriberTn(Connection con, SubscriberTnBean subTnObj)
        {
		super(subTnObj);
                this.connection = con;
		this.rollbackFlag = false;
		this.isExistingTn = false;
		this.tnRemoveFlag = false;
        }

	
	//getter - setters
	public boolean getRollbackFlag()
    	{
        	return rollbackFlag;
    	}
                                                                                
    	public void setRollbackFlag(boolean rollbackFlag)
    	{
        	this.rollbackFlag = rollbackFlag;
    	}
		 public boolean getIsExistingTn()
        {
            return isExistingTn;
        }

        public void setIsExistingTn(boolean isExistingTn)
        {
            this.isExistingTn = isExistingTn;
        }

	
	public boolean isTnRemoveFlag() {
		return tnRemoveFlag;
	}

	public void setTnRemoveFlag(boolean tnRemoveFlag) {
		this.tnRemoveFlag = tnRemoveFlag;
	}


	public Connection getConnection() {
		return connection;
	}
	public void setConnection(Connection connection) {
		this.connection = connection;
	}
	public InvErrorCode getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(InvErrorCode statusCode) {
		this.statusCode = statusCode;
	}
	public String getStatusDesc() {
		return statusCode.getErrorDesc();
	}
	//public void setStatusDesc(String statusDesc) {
	//	this.statusDesc = statusDesc;
	//}
	
	
	
	public boolean getByNatUserId()
	{
		return true;
	}
	
	public boolean validateSubscriberTn()
	{
		return true;
	}
	
	public boolean addSubscriberTn() throws SQLException, Exception
	{
		log.info("Entering SubscriberTn::addSubscriberTn");
        PreparedStatement pstmt=null;
		ResultSet rs=null;
		int subTnId = 0;
		try
		{
			//For extension subscribers userid will be 0 hence skipping this validation
			if(!getUserId().equals("") && !getUserId().equals("0")){
				String stnQry = "select subscriber_tn_id from tbl_subscriber_tn where nat_user_id = ? and user_id = ? and sub_id = ?";

				pstmt=connection.prepareStatement(stnQry);
				pstmt.setLong(1, getNatUserId());
				pstmt.setString(2, getUserId());
				pstmt.setString(3, getSubId());
				rs=pstmt.executeQuery();
				while(rs.next()){
					subTnId=rs.getInt(1);
				}
			}
			if(subTnId == 0){
				DBTblSubscriberTn subTnDB = new DBTblSubscriberTn();
				subTnDB.getSubscriberTnIdSeqNextVal(connection);

				if(getNatUserId() > 0)
					subTnDB.setNatUserId(getNatUserId());
				if(!getUserId().equals(""))
					subTnDB.setUserId(getUserId());
				if(!getSubId().equals(""))
					subTnDB.setSubId(getSubId());
				if(getNpaSplitStatus() > 0)
					subTnDB.setNpaSplitStatus(getNpaSplitStatus());

				if(!getExtension().equals("NONE") ) {
					subTnDB.setExtension(getExtension());
				}
				if(getSlotNo() != -1) {
					subTnDB.setSlotNumber(getSlotNo());
				}

				log.info("EnvOrderId = <" + getEnvOrderId() + ">");
				if(getEnvOrderId() > 0)
					subTnDB.setEnvOrderId(getEnvOrderId());
				else
					subTnDB.setEnvOrderIdNull();

				if(getCreatedBy() !=null && !getCreatedBy().equals(""))
					subTnDB.setCreatedBy(getCreatedBy());
				else
					subTnDB.setCreatedBy("ESAP_INV");
				if(getModifiedBy() != null && !getModifiedBy().equals(""))
					subTnDB.setModifiedBy(getModifiedBy());
				else
					subTnDB.setModifiedBy("ESAP_INV");

				subTnDB.setCreationDate(new Timestamp(System.currentTimeMillis()));
				subTnDB.setLastModifiedDate(new Timestamp(System.currentTimeMillis()));
				subTnDB.insert(connection);
				setSubscriberTnId(subTnDB.getSubscriberTnId());
			}else{
				throw new Exception("UserID already exists for same Subscriber ");
			}
		}catch(SQLException s)
		{
			s.printStackTrace();	
			setStatusCode(InvErrorCode.DB_EXCEPTION);
			//setStatusDesc("DB_FAILURE in addSubscriberTn");
			return false;
		}finally{
			if(rs != null){
				rs.close();
			}
			if(pstmt != null){
				pstmt.close();
			}
		}
		return true;
	}
	
	public boolean deleteSubscriberTn() throws SQLException, Exception

	{
//		try
//		{
			if(getSubscriberTnId() <= 0)
                	{
                        setStatusCode(InvErrorCode.INVALID_INPUT);
                        return false;
                	}
			TblSubscriberTnQuery subTnQry = new TblSubscriberTnQuery
();
                        subTnQry.whereSubscriberTnIdEQ(getSubscriberTnId());
                        subTnQry.query(connection);
                        if(subTnQry.size() > 0)
                        {
				String subscriberId = (subTnQry.getDbBean(0)).getSubId();
				String userId = (subTnQry.getDbBean(0)).getUserId();
				long dialPlanId = 0;
				DBTblSubscriberTn subTnDelete = new DBTblSubscriberTn();
				subTnDelete.whereSubscriberTnIdEQ(getSubscriberTnId());
				int subscriberTnIdDelete = subTnDelete.deleteByWhere(connection);
				log.info("subscriberTnIdDelete : " + subscriberTnIdDelete);

				if ( subscriberTnIdDelete  <= 0 ) {
					setStatusCode(InvErrorCode.NO_SUBSCRIBER_TN_DELETED);
					return false;
				}

				if(userId != null && !userId.trim().equalsIgnoreCase(""))
                                {
					log.info("UserId/tn:"+userId);
					PublicTnPool pubTnPool = new PublicTnPool(connection);
					pubTnPool.setTn(userId);
					if((rollbackFlag && !isExistingTn) || tnRemoveFlag) //if TNRemove is Y, remove SubTN
					{
						if(pubTnPool.isTnDeletable())
						{
						if ( pubTnPool.deletePublicTnPool() == false ){
							log.info("Unable to delete Public Tn Pool for Subscriber Tn.");
							setStatusCode(InvErrorCode.ERROR_DELETING_PUBLICTNPOOL_FOR_SUBSCRIBER);
							return false;
						}

					TblSubscriberQuery subQry = new TblSubscriberQuery();
					subQry.whereSubIdEQ(subscriberId);
					subQry.query(connection);
					if(subQry.size() > 0)
					{
						TblLocationQuery locQry = new TblLocationQuery();
						locQry.whereLocationIdEQ(subQry.getDbBean(0).getLocationId());
						locQry.query(connection);
						if(locQry.size() > 0)
							dialPlanId = locQry.getDbBean(0).getDialPlanId();
					}

					if(dialPlanId > 0)
					{
						log.info("TRI delete for tn :"+userId);
                TerminatingRouting termObj = new TerminatingRouting(connection);
                termObj.setRangeStart(userId);
                termObj.setRangeEnd(userId);
                termObj.setDialPlanId(dialPlanId);
                termObj.setEnvOrderId(getEnvOrderId());
                TerminatingRouting.splitTerminatingRoutingForDP(termObj, connection);
					}
					}
					else
					{
						pubTnPool.setTnStatus(VzbVoipEnum.TnStatus.AVAILABLE);
						pubTnPool.setTnType(VzbVoipEnum.TnType.RES);
                        pubTnPool.setActiveInd(VzbVoipEnum.ActiveInd.ACTIVE);
                        if ( pubTnPool.updatePublicTnPool() == false ) {
                            log.info("Rollback flag is false.");
                            log.info("Unable to update Public Tn Pool for Subscriber Tn as Available.");
                            setStatusCode(InvErrorCode.ERROR_MODIFYING_PUBLICTNPOOL_FOR_SUBSCRIBER);
                            return false;
                        }

					}

					}
					else
					{
						pubTnPool.setTnStatus(VzbVoipEnum.TnStatus.AVAILABLE);
						pubTnPool.setTnType(VzbVoipEnum.TnType.RES);
						pubTnPool.setActiveInd(VzbVoipEnum.ActiveInd.ACTIVE);
						if ( pubTnPool.updatePublicTnPool() == false ) {
							log.info("Rollback flag is false.");
							log.info("Unable to update Public Tn Pool for Subscriber Tn as Available.");
							setStatusCode(InvErrorCode.ERROR_MODIFYING_PUBLICTNPOOL_FOR_SUBSCRIBER);
							return false;
						}
					}
                                }
			}
			
		/*} catch(SQLException s) {
			s.printStackTrace();	
			setStatusCode(InvErrorCode.INTERNAL_ERROR);
			//setStatusDesc("DB_FAILURE in deleteSubscriberTn");
			log.info("DB_FAILURE in deleteSubscriberTn");
			return false;
		}catch (Exception ee) {
			ee.printStackTrace();	
			setStatusCode(InvErrorCode.INTERNAL_ERROR);
			//setStatusDesc("DB_FAILURE in deleteSubscriberTn");
			log.info("DB_FAILURE in deleteSubscriberTn");
			return false;	
		}*/
		setStatusCode(InvErrorCode.SUCCESS);
		//setStatusDesc("Successfully DELETED VmAccess from  the DB");
		return true;
	}

	/**
	 * The method to updateSubscriberTn the SubscriberTn record.
	 *
	 * SubscriberTn Id should be set before calling this method.
	 *
	 * @return	true	Record has been updated SUCCESSFULLY
	 * 			false	SubscriberTn Id missing / Record update Unsuccessful /
	 * 					Some Error occured.
	 */
	public boolean updateSubscriberTn() throws SQLException, Exception
	{
		//try
		//{
			if ( getSubscriberTnId() <= 0) {
				setStatusCode(InvErrorCode.INTERNAL_ERROR);
				//setStatusDesc("FAILURE in modifyInDB SubscriberTn. SubscriberTnId missing.");
				log.info("FAILURE in updateSubscriberTn. SubscriberTnId missing.");
				return false;
			}
	
			DBTblSubscriberTn subTnbean = getSubscriberTnToUpdate();
			subTnbean.whereSubscriberTnIdEQ(getSubscriberTnId());	
			
			if ( subTnbean.updateSpByWhere(connection) <= 0 ) {
				setStatusCode(InvErrorCode.NO_SUBSCRIBER_TN_UPDATED);
				return false;
			}
	



		/*} catch(SQLException s) {
			s.printStackTrace();	
			setStatusCode(InvErrorCode.DB_EXCEPTION);
			//setStatusDesc("DB_FAILURE in updateSubscriberTn");
			log.info("DB_FAILURE in updateSubscriberTn");
			return false;
		}*/
		setStatusCode(InvErrorCode.SUCCESS);
		//setStatusDesc("Successfully UPDATED SubscriberTn into the DB");
		return true;
	}
	
	/**
	 * The current SubscriberTn details are extracted using getSubscriberTnDetails()
	 * and the new field values are updated over that. The method
	 * will update the fields that are supplied on the current instance
	 * if they are different from the default values for the respective field.
	 *
	 * @return The VmAccess to be updated.
	 */
	@SuppressWarnings("unused")
	private DBTblSubscriberTn getSubscriberTnToUpdate() {
		DBTblSubscriberTn subTnDbBean = new DBTblSubscriberTn();

		/* Create a new instance of VmAccessBean. The new instance
		 * would hold default values for the all the VmAccess fields.*/
		SubscriberTnBean defaultSubTnBean = new SubscriberTnBean();

		SubscriberTn inputSubTn = this;

		subTnDbBean.setSubscriberTnId(getSubscriberTnId());

		if ( inputSubTn.getNatUserId() != defaultSubTnBean.getNatUserId()){
			subTnDbBean.setNatUserId(inputSubTn.getNatUserId());
		}


		if ( inputSubTn.getUserId() != defaultSubTnBean.getUserId()){
			subTnDbBean.setUserId(inputSubTn.getUserId());
		}
		
		if ( inputSubTn.getSubId() != null &&
				!inputSubTn.getSubId().equals(defaultSubTnBean.getSubId()) ){
			subTnDbBean.setSubId(inputSubTn.getSubId());
		}
		
		if(inputSubTn.getExtension() != null && !inputSubTn.getExtension().equals(defaultSubTnBean.getExtension()) ){
        	if(! "".equals(inputSubTn.getExtension()))
        			subTnDbBean.setExtension(inputSubTn.getExtension());
        	else
        		subTnDbBean.setExtensionNull();
		}
		if(inputSubTn.getSlotNo() != defaultSubTnBean.getSlotNo() ){
				if(inputSubTn.getSlotNo() != -2) {
					subTnDbBean.setSlotNumber(inputSubTn.getSlotNo());
				} else {
					subTnDbBean.setSlotNumberNull();
				}
		}
		
		
		if ( inputSubTn.getNpaSplitStatus() != defaultSubTnBean.getNpaSplitStatus()){
			subTnDbBean.setNpaSplitStatus(inputSubTn.getNpaSplitStatus());
		}
		
        	if (inputSubTn.getEnvOrderId() != defaultSubTnBean.getEnvOrderId()) {
        		subTnDbBean.setEnvOrderId(inputSubTn.getEnvOrderId());
        	}

	        if(inputSubTn.getModifiedBy() != null && !"".equals(inputSubTn.getModifiedBy()) )
			subTnDbBean.setModifiedBy(inputSubTn.getModifiedBy());
		else
			subTnDbBean.setModifiedBy("ESAP_INV");

		subTnDbBean.setLastModifiedDate(new Timestamp(System.currentTimeMillis()));
                return subTnDbBean;
	}

	public String checkWhetherAlternateTNAlreadyExists(String subscriberId,String tn) throws Exception{
		String subTnId="";
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		log.info("checkWhetherAlternateTNAlreadyExists sub id is====> " + subscriberId);
		log.info("checkWhetherAlternateTNAlreadyExists natUserIdis====> " + tn);
		String sqlQuery="select SUBSCRIBER_TN_ID from tbl_subscriber_tn where nat_user_id=? and SUB_id=? and user_id=?";
		try{
			pstmt=connection.prepareStatement(sqlQuery);
			pstmt.setInt(1, SubscriberTnType.ALTERNATE);
			pstmt.setString(2, subscriberId);
			pstmt.setString(3, tn);
			rs=pstmt.executeQuery();
			while(rs.next()){
				subTnId=String.valueOf(rs.getInt(1));
			}
		}catch(Exception e){
			
		}finally{
			if(pstmt!=null) pstmt.close();
			if(rs!=null) rs.close();
		}
		log.info("Sub Tn id Value is =======> "+subTnId );
		return subTnId;
	}
	public boolean getSubscriberTnDetails()
	{
		try
		{
			log.info("In VmAccess getDetails; SubscriberTnId="+getSubscriberTnId());
			TblSubscriberTnQuery subTnQry = new TblSubscriberTnQuery();
			String whereClause = " where SUBSCRIBER_TN_ID = "+getSubscriberTnId();
			subTnQry.queryByWhere(connection, whereClause);
			if(subTnQry.size() == 1){
				setNatUserId((subTnQry.getDbBean(0)).getNatUserId());
				if(!(subTnQry.getDbBean(0)).getUserId().equalsIgnoreCase("0"))
					setUserId((subTnQry.getDbBean(0)).getUserId());
				setSubId((subTnQry.getDbBean(0)).getSubId());
				setNpaSplitStatus(subTnQry.getDbBean(0).getNpaSplitStatus());
				setCreatedBy((subTnQry.getDbBean(0)).getCreatedBy());
				setCreationDate((subTnQry.getDbBean(0)).getCreationDate());
				setModifiedBy((subTnQry.getDbBean(0)).getModifiedBy());
				setLastModifiedDate((subTnQry.getDbBean(0)).getLastModifiedDate());
				setEnvOrderId((subTnQry.getDbBean(0)).getEnvOrderId());	
			}else
			{
				setStatusCode(InvErrorCode.INTERNAL_ERROR);
				//setStatusDesc("FAILURE in getSubscriberTnDetails SubscriberTn.Couldn't find any SubscriberTn with the given SubscriberTnsId");
				return false;
			}
			
		}catch(SQLException s)
		{
			s.printStackTrace();	
			setStatusCode(InvErrorCode.DB_EXCEPTION);
			//setStatusDesc("DB_FAILURE in getSubscriberTnDetails SubscriberTn");
			return false;
		}
		setStatusCode(InvErrorCode.SUCCESS);
		//setStatusDesc("Successfully retrieved SubscriberTn from db");
		return true;
	}
	
 public boolean addTnOrExtnToDB() throws SQLException, Exception
{
//	 try{
	    String whereClause = " where SUB_ID = '"+ getSubId() + "' and  SLOT_NUMBER  = " + getSlotNo(); 
	 	if( !isRecordExistsWithTnORExtn(whereClause)) {
	 		logTrail.add("Adding Subscribet to subscriber tn table");
	 		if(getUserId().equals("") ||  getUserId()== null) {
	 			// userId is not null coloumn, since putting default value for userId as zero. 
	 			setUserId("0");
	 		}
	 		addSubscriberTn();
	 	} else {
	 		logTrail.add("updating  Subscribet to subscriber tn table with SUBSCRIBER_TN_ID" + getSubscriberTnId());
	 		updateSubscriberTn();
	 	}
	 /*} catch (Exception ee) {
			ee.printStackTrace();	
			setStatusCode(InvErrorCode.DB_EXCEPTION);
			return false;
	 }*/
	 	 
		setStatusCode(InvErrorCode.SUCCESS);
		return true; 
 }
 
 public boolean isRecordExistsWithTnORExtn(String whereClause) throws Exception {
        	TblSubscriberTnQuery subTnQry = new TblSubscriberTnQuery();
			logTrail.add("Checking whether record  record exists in db with subscriberId and slotNo");
			log.info(whereClause);
			subTnQry.queryByWhere(connection, whereClause);
			if(subTnQry.size() == 1){
				setSubscriberTnId((subTnQry.getDbBean(0)).getSubscriberTnId());
				return true;
			}
             
		return false;	
 }
	
public boolean deleteTnOrExtnToDB() throws SQLException, Exception{
	logTrail.add("Delete/Updating subscriber tn record");
//try {	
		deleteSubTn();
		
/*	}  catch (Exception ee) {
		ee.printStackTrace();	
		setStatusCode(InvErrorCode.DB_EXCEPTION);
		return false;
	}*/
 	 
	setStatusCode(InvErrorCode.SUCCESS);
	return true; 
}	

public boolean deleteSubTn() throws SQLException, Exception
{
	boolean retValue = true;
	log.info("Entering deleteSubTnForSubUserId");
   //try
   //{
      DBTblSubscriberTn subTnDelete = new DBTblSubscriberTn();
      log.info("Subscriber Id Value ::: " + getSubId());
      log.info("SlotNo ::: " + getSlotNo());
      subTnDelete.whereSubIdEQ(getSubId());
      subTnDelete.whereSlotNumberEQ(getSlotNo());
      int subscriberTnIdDelete = subTnDelete.deleteByWhere(connection);
      log.info("subscriberTnIdDelete : " + subscriberTnIdDelete);

   /*} catch(SQLException s) {
      log.info("DB_FAILURE in deleteSubscriberTn");
      retValue = false;
   }*/
		return retValue;
}
 
}

